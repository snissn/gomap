"""Root-owned finite comparison of unchanged, landed service benchmarks."""
import importlib.util
import json
from pathlib import Path
import re
import signal
import statistics
import subprocess
import sys

ROOT = Path('/mnt/fast4tb/gomap-mongo-execution-20261024')
WORK = ROOT / 'shared-text-selected-extraction1'
HERE = Path(__file__).resolve().parent
GO = Path('/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.linux-amd64/bin/go')
BASE = 'a621e9a4ac0904dfe012b9c9e101954cebd503d0'
HEAD = '171737eb194961c7183fec471440cb761e51dcf3'
FILES = ['TreeDB/collections/text_v2_search.go', 'TreeDB/collections/text_v2_phrase.go']
HARNESS = 'TreeDB/documentservice/shared_cow_consumers_bench_test.go'
SELECTOR = '^BenchmarkServiceSharedCOWConsumers$/(keyword|hybrid)$'
spec = importlib.util.spec_from_file_location('owned', ROOT / 'evidence/native-query-work-witness1/run.py')
H = importlib.util.module_from_spec(spec)
spec.loader.exec_module(H)
signal.signal(signal.SIGTERM, H.interrupted)
signal.signal(signal.SIGINT, H.interrupted)
ENV = H.safe_env({'GOTOOLCHAIN':'local', 'GOMAXPROCS':'4', 'GOCACHE':str(ROOT/'gocache'),
                 'TMPDIR':str(ROOT/'tmp'), 'GOPROXY':'off', 'GOSUMDB':'off',
                 'GOMAP_SERVICE_BENCH_BACKEND':'legacy',
                 'GOMAP_SERVICE_BENCH_PROFILE':'command_wal_durable'})
PLAN = HERE / 'plan.json'

def state():
    return {'head':H.git(WORK,'rev-parse','HEAD'), 'tree':H.git(WORK,'rev-parse','HEAD^{tree}'),
            'status':H.git(WORK,'status','--porcelain')}

def bindings():
    paths = [Path(__file__), GO, ROOT/'evidence/native-query-work-witness1/run.py', HERE/'baseline-overlay.json', WORK/HARNESS]
    paths += [WORK/p for p in FILES]
    paths += [Path(p) for p in json.loads((HERE/'baseline-overlay.json').read_text())['Replace'].values()]
    return {str(p):H.digest(p) for p in paths}

def once(name, argv, wall):
    target = HERE/(name+'-receipt.json')
    if target.exists():
        raise SystemExit('refuse receipt overwrite '+name)
    before = state()
    result = H.run_process(argv,str(WORK),ENV,HERE/(name+'.log'),wall)
    result.update(source_before=before,source_after=state(),plan_sha256=H.digest(PLAN))
    result['source_unchanged'] = before == result['source_after']
    H.write_json(target,result)
    if not result['process_ok'] or not result['source_unchanged']:
        raise SystemExit('process/source failure '+name)
    return result

def parse(log):
    raw = Path(log).read_text()
    errors, rows = [], []
    pending = None
    for line in raw.splitlines():
        named = re.match(r'^BenchmarkServiceSharedCOWConsumers/(keyword|hybrid)(?:-(\d+))?(?:\s+(.*))?$',line)
        if named:
            pending = (named.group(1),named.group(2))
            rest = named.group(3) or ''
        else:
            rest = line
        number = re.match(r'^\s*(\d+)\s+(.+\bns/op\b.*)$',rest)
        if number:
            if pending is None:
                errors.append('unattributed numeric row')
                continue
            metrics = {unit:float(value) for value,unit in re.findall(r'([0-9]+(?:\.[0-9]+)?(?:[eE][+-]?\d+)?)\s+(ns/op|B/op|allocs/op|postings/op|docs_fetched/op)',number.group(2))}
            rows.append({'benchmark':pending[0],'cpu_suffix':pending[1], 'iterations':int(number.group(1)), 'metrics':metrics, 'raw':line})
            pending = None
        if re.match(r'^BenchmarkServiceSharedCOWConsumers/(get|dense)',line):
            errors.append('unselected benchmark')
    headers = re.findall(r'backend=(\S+) profile=(\S+) requested_memtable=(\S+) resolved_strategy=(\S+) rows=(\d+) load_batch=(\d+)',raw)
    expected = ('legacy','command_wal_durable','cow_btree','column_graph','4096','128')
    if not headers or any(h != expected for h in headers):
        errors.append('wrong or missing service profile/strategy header')
    if not re.search(r'(?m)^PASS\s*$',raw) or re.search(r'(?m)^FAIL\b|--- FAIL:|--- SKIP:|panic:',raw):
        errors.append('PASS/failure/skip mismatch')
    if sorted(r['benchmark'] for r in rows) != ['hybrid','keyword']:
        errors.append('expected exactly two selected rows')
    for row in rows:
        m = row['metrics']
        if row['iterations'] != 1000 or row['cpu_suffix'] != '4' or any(k not in m for k in ('ns/op','B/op','allocs/op','postings/op')):
            errors.append('iterations/CPU/metrics mismatch')
        if m.get('postings/op') != (640 if row['benchmark']=='keyword' else 1024):
            errors.append('posting work mismatch')
        if row['benchmark']=='hybrid' and m.get('docs_fetched/op') != 10:
            errors.append('fetch work mismatch')
    return {'complete':not errors,'errors':errors,'headers':headers,'rows':rows}

mode = sys.argv[1]
if mode == 'freeze':
    if PLAN.exists():
        raise SystemExit('refuse plan overwrite')
    source = state()
    if source['head'] != HEAD or source['status']:
        raise SystemExit('unexpected head or dirty source')
    overlay = {}
    for p in FILES:
        target = HERE/('baseline-'+Path(p).name)
        with target.open('xb') as output:
            output.write(subprocess.check_output(['git','-C',str(WORK),'show',BASE+':'+p]))
        overlay[str(WORK/p)] = str(target)
    H.write_json(HERE/'baseline-overlay.json',{'Replace':overlay})
    original_harness = subprocess.check_output(['git','-C',str(WORK),'show',BASE+':'+HARNESS])
    if original_harness != (WORK/HARNESS).read_bytes():
        raise SystemExit('landed harness differs')
    plan = {'purpose':'#5238 independent shared text selected-sidecar subdelivery; existing public service, both arms legacy ColumnGraph',
            'source':source,'baseline_commit':BASE,'bindings':bindings(),'selector':SELECTOR,'iterations':1000,
            'order':['baseline1','candidate1','candidate2','baseline2'], 'build_wall_seconds':300,'process_wall_seconds':120,
            'contract':'Public service queries on 4096 documents, 128-document durable ingestion requests, 16 tenants, Top10, same explicit command_wal_durable profile and legacy backend. Setup/warmup/Optimize outside query timer. Requested cow_btree is overridden to btree by the backend-only cached opener; this comparison claims shared text improvement, no native/COW activation or durable query ACK.',
            'validity':'Every process PASS and exactly keyword/hybrid 1000-iteration rows at GOMAXPROCS4; expected 640/1024 postings and Hybrid10 fetched; unchanged original harness assertions verify tenant/projection, no full-scan/fail-closed and legacy snapshot; exact source/overlay/toolchain/ELF bindings and owned process cleanup. Preserve every sample; no retries.',
            'predeclared_selection':'For EACH query, median B/op decreases at least20%, median ns/op increases at most5%, median allocs/op increases at most1. Any miss needs a source/structural decision; no favorable repeat. This finite comparison selects this narrow shared text delivery, not native-default acceptance or a statistical universal no-regression claim.',
            'infrastructure':'Task-owned ext4 paths, caches and prebuilt ELFs outside timed runs; shared host, no concurrent root workload selected; no dedicated hardware reservation.'}
    H.write_json(PLAN,plan)
    print(json.dumps({'plan':str(PLAN),'sha256':H.digest(PLAN),'source':source}),flush=True)
    raise SystemExit(0)

plan = json.loads(PLAN.read_text())
if state()!=plan['source'] or bindings()!=plan['bindings']:
    raise SystemExit('frozen inputs changed')
if mode == 'build':
    for arm in ['baseline','candidate']:
        target = HERE/(arm+'.test')
        if target.exists():
            raise SystemExit('refuse ELF overwrite')
        argv = [str(GO),'test','-c','-o',str(target)]
        if arm=='baseline':
            argv += ['-overlay='+str(HERE/'baseline-overlay.json')]
        argv += ['./TreeDB/documentservice']
        result = once('build-'+arm,argv,300)
        result.update(elf=str(target),elf_sha256=H.digest(target),bindings=bindings())
        H.write_json(HERE/('build-'+arm+'-receipt.json'),result)
        print(json.dumps({'arm':arm,'elf_sha256':result['elf_sha256'],'elapsed':result['elapsed_seconds']}),flush=True)
elif mode == 'run':
    samples = []
    for name in plan['order']:
        arm = 'baseline' if name.startswith('baseline') else 'candidate'
        build = json.loads((HERE/('build-'+arm+'-receipt.json')).read_text())
        target = Path(build['elf'])
        if H.digest(target)!=build['elf_sha256']:
            raise SystemExit('ELF drift')
        result = once(name,[str(target),'-test.run=^$','-test.bench='+SELECTOR,'-test.benchtime=1000x','-test.count=1','-test.benchmem','-test.v','-test.timeout=90s'],120)
        observed = parse(result['log'])
        result.update(observed=observed,elf_sha256_before=build['elf_sha256'],elf_sha256_after=H.digest(target))
        H.write_json(HERE/(name+'-receipt.json'),result)
        if not observed['complete'] or result['elf_sha256_after']!=build['elf_sha256'] or state()!=plan['source'] or bindings()!=plan['bindings']:
            raise SystemExit('invalid sample or post-run drift '+name)
        samples.append({'sample':name,'rows':observed['rows']})
        print(json.dumps(samples[-1]),flush=True)
    comparisons = []
    for query in ['keyword','hybrid']:
        arms = {}
        for arm in ['baseline','candidate']:
            selected = [r for s in samples if s['sample'].startswith(arm) for r in s['rows'] if r['benchmark']==query]
            arms[arm] = {k:statistics.median(r['metrics'][k] for r in selected) for k in ('ns/op','B/op','allocs/op')}
        b,c = arms['baseline'],arms['candidate']
        delta = {k:100*(c[k]/b[k]-1) for k in b}
        passed = c['B/op']<=0.8*b['B/op'] and c['ns/op']<=1.05*b['ns/op'] and c['allocs/op']<=b['allocs/op']+1
        comparisons.append({'benchmark':query,'medians':arms,'percent_change':delta,'selection_pass':passed})
    outcome = {'plan_sha256':H.digest(PLAN),'samples':samples,'comparisons':comparisons,'complete':True,'narrow_selection_pass':all(c['selection_pass'] for c in comparisons),'native_default_qualification':None}
    H.write_json(HERE/'outcomes.json',outcome)
    print(json.dumps({'comparisons':comparisons,'narrow_selection_pass':outcome['narrow_selection_pass']}),flush=True)
else:
    raise SystemExit('unknown mode')
