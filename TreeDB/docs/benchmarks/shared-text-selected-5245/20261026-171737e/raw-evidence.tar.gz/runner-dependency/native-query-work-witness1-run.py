#!/usr/bin/env python3
"""Root-executed fixed work-population witness; no performance acceptance."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
PLAN_SHA = "ca2d8eb9e07408d211e3da9db43b5822bb9b2aa8082e0bf916b7198713af0fe6"
BUILD_WALL_SECONDS = 600
CELL_WALL_SECONDS = 210


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    temporary = Path(str(path) + ".partial")
    with temporary.open("w") as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write("\n")
    temporary.replace(path)


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def source_state(plan):
    repo = Path(plan["source"]["repo"])
    state = {"head": git(repo, "rev-parse", "HEAD"),
             "status": git(repo, "status", "--porcelain", "--untracked-files=normal"),
             "files": {p: digest(repo / p) for p in plan["source"]["files"]},
             "plan_sha256": digest(HERE / "plan.json"),
             "overlay_sha256": digest(plan["overlay"]["path"]),
             "overlay_source_sha256": digest(plan["overlay"]["source"]),
             "patch_sha256": digest(HERE / "source.patch")}
    state["valid"] = (state["head"] == plan["source"]["head"] and not state["status"]
        and state["files"] == plan["source"]["files"] and state["plan_sha256"] == PLAN_SHA
        and state["overlay_sha256"] == plan["overlay"]["sha256"]
        and state["overlay_source_sha256"] == plan["overlay"]["source_sha256"]
        and state["patch_sha256"] == plan["overlay"]["patch_sha256"])
    return state


def safe_env(extra=None):
    # No inherited GOFLAGS, GOROOT, profile, benchmark or credential variables.
    env = {k: os.environ[k] for k in ("PATH", "HOME", "USER", "LANG", "LC_ALL", "TZ") if k in os.environ}
    env.update({"LANG": "C.UTF-8", "GOFLAGS": "", "GOWORK": "off"})
    env.update(extra or {})
    return env


def group_alive(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False


def terminate_group(proc):
    result = {"pgid": proc.pid, "alive_before_cleanup": group_alive(proc.pid), "signals": []}
    if result["alive_before_cleanup"]:
        for sig, grace in ((signal.SIGTERM, 2.0), (signal.SIGKILL, 2.0)):
            if not group_alive(proc.pid):
                break
            try:
                os.killpg(proc.pid, sig)
                result["signals"].append(sig.name)
            except ProcessLookupError:
                break
            deadline = time.monotonic() + grace
            while group_alive(proc.pid) and time.monotonic() < deadline:
                proc.poll()  # reap our leader before testing its group again
                time.sleep(0.02)
    try:
        proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
        result["leader_wait_timeout"] = True
    result["alive_after_cleanup"] = group_alive(proc.pid)
    return result


def run_process(argv, cwd, env, log, timeout):
    receipt = {"argv": argv, "cwd": cwd, "environment_policy": "explicit whitelist plus frozen cell values; no full environment dump",
               "start_utc": utc(), "wall_limit_seconds": timeout, "exit_code": None,
               "timed_out": False, "error": None, "cleanup": None}
    start = time.monotonic()
    proc = None
    with Path(log).open("xb") as output:
        try:
            proc = subprocess.Popen(argv, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT,
                                    start_new_session=True)
            receipt["pid"] = proc.pid
            try:
                receipt["exit_code"] = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                receipt["timed_out"] = True
        except (OSError, KeyboardInterrupt) as exc:
            receipt["error"] = {"type": type(exc).__name__, "message": str(exc)}
        finally:
            if proc is not None:
                receipt["cleanup"] = terminate_group(proc)
                receipt["exit_code"] = proc.returncode
    receipt.update(end_utc=utc(), elapsed_seconds=time.monotonic() - start,
                   log=str(log), log_sha256=digest(log))
    receipt["process_ok"] = (receipt["exit_code"] == 0 and not receipt["timed_out"]
        and receipt["error"] is None and receipt["cleanup"] is not None
        and not receipt["cleanup"]["alive_before_cleanup"]
        and not receipt["cleanup"]["alive_after_cleanup"])
    return receipt


def parse_output(log, backend):
    raw = Path(log).read_text(errors="replace")
    errors, rows, queries, storage, pending = [], [], [], [], None
    name_re = re.compile(r"^(BenchmarkServiceSharedCOWConsumers/(keyword|hybrid)(?:-(\d+))?)(?:\s+(.*))?$")
    numeric_re = re.compile(r"^\s*(\d+)\s+(.+\bns/op\b.*)$")
    metric_re = re.compile(r"([0-9]+(?:\.[0-9]+)?(?:[eE][+-]?\d+)?)\s+(ns/op|B/op|allocs/op|postings/op|docs_fetched/op)")
    for line in raw.splitlines():
        if re.match(r"^BenchmarkServiceSharedCOWConsumers/(get|dense)(?:-\d+)?(?:\s|$)", line):
            errors.append("unexpected unselected benchmark: " + line)
        named = name_re.match(line)
        numeric = None
        if named:
            pending = (named.group(2), named.group(3))
            numeric = numeric_re.match(named.group(4) or "")
        else:
            numeric = numeric_re.match(line)
        if numeric:
            if pending is None:
                errors.append("unattributed numeric benchmark row")
            else:
                metrics = {unit: float(value) for value, unit in metric_re.findall(numeric.group(2))}
                rows.append({"benchmark": pending[0], "cpu_suffix": pending[1],
                             "iterations": int(numeric.group(1)), "incidental_metrics": metrics,
                             "raw_numeric_line": line})
                pending = None
        if "WORK_POPULATION_STORAGE " in line:
            match = re.search(r"WORK_POPULATION_STORAGE backend=(\S+) benchmark=(\S+) stats=(\{.*\})$", line)
            if not match:
                errors.append("malformed storage diagnostic")
            else:
                try:
                    storage.append({"backend": match.group(1), "benchmark": match.group(2), "stats": json.loads(match.group(3))})
                except (ValueError, TypeError) as exc:
                    errors.append("storage JSON: " + str(exc))
        elif "WORK_POPULATION " in line:
            try:
                queries.append(json.loads(line.split("WORK_POPULATION ", 1)[1]))
            except (ValueError, TypeError) as exc:
                errors.append("query JSON: " + str(exc))
    headers = re.findall(r"backend=(\S+) profile=(\S+) requested_memtable=(\S+) resolved_strategy=(\S+) rows=(\d+) load_batch=(\d+)", raw)
    if not headers or any(h[0] != backend or h[1] != "command_wal_durable" or h[2] != "cow_btree" or h[4:] != ("4096", "128") for h in headers):
        errors.append("missing or wrong activation/profile/fixture header")
    if not re.search(r"(?m)^PASS\s*$", raw) or re.search(r"(?m)^(?:FAIL\b|panic:)|--- FAIL:|--- SKIP:", raw):
        errors.append("missing PASS or failure/skip in log")
    if sorted(r["benchmark"] for r in rows) != ["hybrid", "keyword"]:
        errors.append("expected exactly one keyword and one hybrid numeric row")
    for row in rows:
        m = row["incidental_metrics"]
        if row["iterations"] != 1 or row["cpu_suffix"] != "4" or any(k not in m for k in ("ns/op", "B/op", "allocs/op", "postings/op")):
            errors.append("wrong iteration/CPU/metrics: " + row["benchmark"])
        if m.get("postings/op") != (640 if row["benchmark"] == "keyword" else 1024):
            errors.append("unexpected original postings count: " + row["benchmark"])
        if row["benchmark"] == "hybrid" and m.get("docs_fetched/op") != 10:
            errors.append("unexpected original fetched count")
    expected_kinds = {"DIAGNOSTIC_extra_untimed_keyword_text_only_hybrid", "DIAGNOSTIC_original_hybrid_final_response"}
    if len(queries) != 2 or {q.get("kind") for q in queries} != expected_kinds:
        errors.append("expected exactly two distinct query diagnostics")
    for q in queries:
        stats = q.get("hybrid_stats", {})
        expected_postings = 640 if q.get("kind") == "DIAGNOSTIC_extra_untimed_keyword_text_only_hybrid" else 1024
        if (q.get("backend") != backend or stats.get("text_postings_scanned", 0) != expected_postings
                or stats.get("documents_fetched", 0) != 10 or stats.get("fail_closed", 0)
                or stats.get("full_document_scan_fallbacks", 0)):
            errors.append("query activation/work/failure mismatch")
        if bool(q.get("snapshot", {}).get("native", False)) != (backend == "native"):
            errors.append("diagnostic snapshot owner mismatch")
        if q.get("kind") == "DIAGNOSTIC_extra_untimed_keyword_text_only_hybrid":
            original = q.get("original_keyword_stats", {})
            translations = {"candidates_requested": "text_candidates_requested", "candidates_returned": "text_candidates_returned",
                "postings_scanned": "text_postings_scanned", "candidates_scored": "text_candidates_scored"}
            for key in ("documents_fetched", "documents_missing", "full_document_scan_fallbacks", "fail_closed", "fail_closed_reason",
                        "scalar_prefilter_ids", "scalar_filter_lookups", "scalar_filter_input_ids", "scalar_filter_intersection_steps", "scalar_filter_final_ids"):
                translations[key] = key
            for key, other in translations.items():
                default = "" if key == "fail_closed_reason" else 0
                if original.get(key, default) != stats.get(other, default):
                    errors.append("mapped keyword counter mismatch: " + key)
            if bool(original.get("truncated", False)) != (stats.get("truncated", 0) > 0):
                errors.append("mapped keyword truncation mismatch")
    if len(storage) != 2 or sorted(s["benchmark"] for s in storage) != ["hybrid", "keyword"]:
        errors.append("expected exactly two storage diagnostics")
    required = ("Documents", "Version", "EncodedBytes", "V2NormBlocks", "V2DocMapBlocks", "V2NormBlockBytes", "V2DocMapBytes", "V2RootGeneration", "V2StatsGeneration", "V2SealedPostingBlocks", "V2DeltaPostingBlocks", "V2MicroPostingBlocks")
    for s in storage:
        if s["backend"] != backend or any(k not in s["stats"] for k in required):
            errors.append("storage activation or complete inventory mismatch")
    return {"complete": not errors, "errors": errors, "activation_headers": headers,
            "benchmark_rows": rows, "query_statistics": queries, "storage_statistics": storage,
            "decoded_bytes_entries_unique_blocks": None,
            "unavailable_reason": "Public counters do not expose query-decoded bytes/entries or unique decoded norm/docmap blocks"}


def population_only(observed):
    result = {key: value for key, value in observed.items() if key != "benchmark_rows"}
    result["original_row_checks"] = [{"benchmark": row["benchmark"], "iterations": row["iterations"],
        "cpu_suffix": row["cpu_suffix"], "postings": row["incidental_metrics"].get("postings/op"),
        "documents_fetched": row["incidental_metrics"].get("docs_fetched/op")}
        for row in observed["benchmark_rows"]]
    return result


def interrupted(signum, frame):
    raise KeyboardInterrupt("runner received signal " + str(signum))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="Root grants runtime for the frozen two-cell diagnostic")
    args = parser.parse_args()
    if not args.execute:
        parser.error("This runner is inert without --execute; no build or workload was started")
    plan = json.loads((HERE / "plan.json").read_text())
    outputs = [HERE / name for name in ("execution-start.json", "preflight.json", "build.log", "build-receipt.json",
                                       "outcomes.json", "population-summary.json", "incidental-timings.json")]
    outputs += [Path(c[key]) for c in plan["cells"] for key in ("combined_log", "receipt")]
    if any(path.exists() for path in outputs):
        raise SystemExit("Existing execution artifact; refusing rerun or overwrite")
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    # Exclusive marker prevents reruns, overwrites and hidden replacement attempts.
    with (HERE / "execution-start.json").open("x") as f:
        json.dump({"started_utc": utc(), "runner_sha256": digest(__file__), "plan_expected_sha256": PLAN_SHA}, f, indent=2)
    plan = json.loads((HERE / "plan.json").read_text())
    records = [{"slot": c["slot"], "backend": c["backend"], "status": "not_run", "reason": None,
                "population": None, "incidental_timing": None} for c in plan["cells"]]
    outcome = {"schema": "native-query-work-witness-outcomes-v1", "plan_sha256": digest(HERE / "plan.json"),
               "runner_sha256": digest(__file__), "build": None, "records": records, "errors": []}
    binary = Path(plan["build"]["binary"])
    binary_sha = None
    try:
        preflight = source_state(plan)
        write_json(HERE / "preflight.json", preflight)
        if not preflight["valid"]:
            raise ValueError("clean exact source/plan/overlay preflight failed")
        if binary.exists():
            raise ValueError("planned binary already exists; refusing to overwrite or reuse")
        outcome["build"] = run_process(plan["build"]["argv"], plan["build"]["cwd"], safe_env(), HERE / "build.log", BUILD_WALL_SECONDS)
        outcome["build"]["source_after"] = source_state(plan)
        if binary.exists():
            binary_sha = digest(binary)
        outcome["build"]["binary_sha256"] = binary_sha
        write_json(HERE / "build-receipt.json", outcome["build"])
        if not outcome["build"]["process_ok"] or not outcome["build"]["source_after"]["valid"] or binary_sha is None:
            raise ValueError("build failed or source changed")
        for cell, record in zip(plan["cells"], records):
            before = source_state(plan)
            if not before["valid"] or digest(binary) != binary_sha:
                raise ValueError("source/binary invariance failed before cell")
            record["status"] = "running"
            write_json(HERE / "outcomes.json", outcome)
            receipt = run_process(cell["argv"], cell["cwd"], safe_env(cell["env"]), cell["combined_log"], CELL_WALL_SECONDS)
            receipt.update(slot=cell["slot"], backend=cell["backend"], runtime_env=cell["env"], source_before=before,
                           source_after=source_state(plan), binary_sha256=binary_sha,
                           binary_sha256_after=digest(binary) if binary.exists() else None)
            invariance = receipt["source_after"]["valid"] and receipt["binary_sha256_after"] == binary_sha
            try:
                observed = parse_output(cell["combined_log"], cell["backend"])
            except Exception as exc:
                observed = {"complete": False, "errors": [{"type": type(exc).__name__, "message": str(exc)}],
                            "benchmark_rows": [], "query_statistics": None, "storage_statistics": None}
            receipt.update(invariance_ok=invariance, observed=observed)
            valid = receipt["process_ok"] and invariance and observed["complete"]
            record.update(status="valid" if valid else "failed", receipt=cell["receipt"],
                          reason=None if valid else "process, invariance or four-row/population checks failed",
                          population=population_only(observed) if valid else None,
                          incidental_timing=observed["benchmark_rows"] if valid else None)
            write_json(cell["receipt"], receipt)
            write_json(HERE / "outcomes.json", outcome)
            if receipt["error"] and receipt["error"]["type"] == "KeyboardInterrupt":
                raise KeyboardInterrupt("interrupted cell; remaining attempt is not run")
            if not invariance:
                raise ValueError("source/binary changed; later planned cell remains not_run/null")
    except (OSError, ValueError, subprocess.SubprocessError, KeyboardInterrupt) as exc:
        outcome["errors"].append({"type": type(exc).__name__, "message": str(exc)})
        for record in records:
            if record["status"] in ("not_run", "running"):
                record.update(status="not_run", reason="blocked by retained setup/invariance/interruption failure")
    finally:
        if outcome["build"] is not None:
            write_json(HERE / "build-receipt.json", outcome["build"])
        for cell, record in zip(plan["cells"], records):
            if not Path(cell["receipt"]).exists():
                write_json(cell["receipt"], {"slot": cell["slot"], "backend": cell["backend"],
                    "status": record["status"], "reason": record["reason"], "exit_code": None,
                    "cleanup": None, "population": None, "binary_sha256": binary_sha})
        outcome["finished_utc"] = utc()
        outcome["complete_population_witness"] = len(records) == 2 and all(r["status"] == "valid" for r in records) and not outcome["errors"]
        outcome["performance_verdict"] = None
        outcome["performance_reason"] = "1x work/layout witness only; post-keyword diagnostic/inspection can warm later Hybrid"
        write_json(HERE / "outcomes.json", outcome)
        population = {"complete": outcome["complete_population_witness"], "plan_sha256": PLAN_SHA,
                      "records": [{"backend": r["backend"], "status": r["status"], "population": r["population"]} for r in records],
                      "decoded_bytes_entries_unique_blocks": None, "unavailable": plan["unavailable"], "performance_verdict": None}
        write_json(HERE / "population-summary.json", population)
        write_json(HERE / "incidental-timings.json", {"performance_verdict": None,
            "reason": outcome["performance_reason"], "records": [{"backend": r["backend"],
                "status": r["status"], "metrics": r["incidental_timing"]} for r in records]})
    return 0 if outcome["complete_population_witness"] else 1


if __name__ == "__main__":
    sys.exit(main())
