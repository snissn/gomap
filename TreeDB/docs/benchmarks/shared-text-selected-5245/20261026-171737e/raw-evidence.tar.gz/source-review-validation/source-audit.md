# Shared selected-sidecar extraction: source audit

One raw candidate frozen on main a621e9a4ac0904dfe012b9c9e101954cebd503d0. Only the four files listed in manifest.json changed. No Go, build, tests, formatter, benchmark/profile, commit, ticket or GitHub action ran in this worker. Root owns runtime, formatting, independent review, integration and acceptance. Existing #5238 remains open; this packet does not accept native timing, resource/default promotion or close #5241.

## Extracted production scope

The two production files are exactly the shared search/phrase diffs from 513f381eeef646b34e9c40791b1044dc85baf383, followed by only the search file's monotonic-selection diff from 51f7dc92aa3be9de91fdf0fb34bd52c136337a66. Both original diffs applied cleanly without context surgery. Search adds an immutable allow-set pointer to the existing per-query block cache; all four exact/single/AND/OR cache constructors and the phrase constructor pass their existing allow-set. The two cache loads invoke selected decoders. The existing full decoder functions call selected decoders with nil.

The selection descriptor borrows one immutable block-local sorted ordinal slice and advances only its own slice header. Sorted entry validation still happens before keep(); no shared mutation or cache is introduced. Retained capacity is min(source entry count, selected ordinals in this block), never the global scalar cardinality. Both norm descriptor/field arrays and docmap descriptor arrays are bounded. Zero/nil/all/historical and sparse selections retain the original semantics. Nil/all keep full source populations, including historical entries.

## Validation and ranking preservation

Selected decoding parses every entry in a consumed record. Existing header, range/ordinal order, generation, flag, field-width, ID-presence, truncation and trailing-byte validation statements remain in place; excluded fields are parsed and checked before omission. Missing selected ordinals remain missing and trigger the existing scorer/bound behavior. Root/value contextual checks remain after decoding.

The original forward-ID-to-ordinal allow-set construction is byte-identical; no identity/generation tuple is added. Every original inverse docmap point/range call remains. Actual inverse raw records are still read through collectionGetAppendAtCatalogRoot(..., nil); every structurally corrupt excluded entry within a consumed inverse block still fails. This extraction does not adopt the later forward-identity corruption-scope change or skip inverse DATA consumption. The original normEntry/docMapEntry and all four norm/ID bound routines are byte-identical (whole-function hashes recorded in manifest.json). Strict bounds still enumerate selected ordinals, while nil/all bounds still see full blocks. Lexical ties, generation/tombstone consistency, exact fallback, posting/work budgets and final result copying are unchanged.

All production cache constructors were checked. The rewrite consumer in text_v2_rewrite.go keeps its zero-value cache, hence nil/full decode. The existing test-created cache also remains valid. No writer, maintenance constructor, codec, key, metadata, storage format, native owner/capture/iterator, HNSW, document service or default was imported. No fresh pool, API, governor, refund or cross-query cache exists.

## Ownership and lifetime

The existing backend snapshot and catalog choose each source root. collectionGetAppendAtCatalogRoot calls GetAppendAtRoot with nil destination, retaining the existing owned read result. Norm decoded arrays own their backing; no raw aliases escape norm decoding. Docmap IDs intentionally keep slices into that complete owned raw record, retaining its backing for the existing query/cache lifetime. Smaller descriptor arrays do not imply early raw release/refund. Existing candidate/top-K/final result copies are unchanged. The allow-set is constructed and sorted once before search, remains immutable, and outlives its query-local cache; each decode has an independent monotonic selection descriptor.

## Assertions and limits

The unchanged 208-line legacy-compatible test from 51f7 was frozen before production edits (raw-tests/, raw-tests.patch, test-first-manifest.json). Three maintained tests cover exact retained lengths/capacities for nil/all/strict/empty/other-block; values, tombstones and raw docmap backing; excluded zero-generation/flags/out-of-block/duplicate/truncated/trailing/field-overflow/empty-ID errors; missing selected entries; sparse differential results, wide ordinals, immutable allow-set and overflow refusal. Tests compare selected errors against full decoding and selected records against independently filtered source entries. Their exact bytes remain unchanged in the candidate.

There is no claimed public behavioral RED: old main lacks the new private selected-decoder symbols, and a compilation failure would not qualify. This is the documented representation exception, not a correctness waiver. Existing public owning controls and source review must establish unchanged results/errors. No speed, bytes/objects, writer, runtime GREEN or integration claim is made. The prior dense/native timings do not measure this exact slice. Dense's writer negative and native Hybrid allocation uncertainty remain recorded elsewhere; neither is fixed, accepted or imported as a mechanism here.
