# Independent source review: selected shared text extraction 1

Verdict: **ACCEPT source**. No material correctness, retained-backing, validation, or scope blocker found in this bounded four-file packet. Runtime, public cost, merge readiness, and broader #5238 acceptance are not established by this review. No Go, formatter, build, test, benchmark, GitHub operation, commit, or product edit was performed.

## Exact identity and closure

Reviewed worktree `/mnt/fast4tb/gomap-mongo-execution-20261024/shared-text-selected-extraction1`, HEAD/base `a621e9a4ac0904dfe012b9c9e101954cebd503d0`. The worktree has exactly the four intended changed/untracked paths. Each current file matches its archived `source/` snapshot, manifest byte count and SHA256. All three tracked base-blob SHA256 values also match the manifest. No native, dense, HNSW, writer, forward-identity, root/cache API or inverse-lookup change is included.

Manifest SHA256: `d1062bfa00d1937b2f88d1cbf008d276ce93df3a7bff1fee82a7a1a8dfe96751`.
Candidate patch SHA256: `de0b2bab0f58d118e562d39738e65fd58b365dd1df63b8e2706e67ecbee3c4a5`.
Test-first manifest SHA256: `d048ebd22a36ed5c69a9d2140ac9ea5225d7240fda497f810a8ef948e12ba769`.

| Path | SHA256 |
| --- | --- |
| TreeDB/collections/text_v2_search.go | 8e1eabaaa475f86fe4d68088fdc10c6d74eb78d0242c2e8c6e7907682c3277c6 |
| TreeDB/collections/text_v2_phrase.go | e1275325ba1f343f7436283bad95c1fc241ce8332c5fbbef1ac5f439ee3d108c |
| TreeDB/collections/text_v2_selected_sidecar_test.go | bf6bd2bc0593f9c38832bf7b4579ebe5bc659fa1b4533223525a51f222e761c6 |
| TreeDB/docs/spec/collection-text-v2-contract.md | a5df22e431f4ec34be1ea41d4fcd66e1a5a6ce7e904d7bfb9ec0eddf6b958c29 |

## Source findings

1. **One maintained decoder, complete validation.** The original norm/doc-map decoder entry points delegate with nil selection. Their selected implementations retain original header, integer/capacity, range/order/generation/flag, per-field uint32, nonempty ID and trailing-byte validation. Selection only gates appending the decoded descriptor/field lengths. Excluded entries are still fully consumed and validated; malformed excluded data is not hidden. This preserves the historical consumed-block validation policy rather than introducing forward-ID or unconsumed-inverse exceptions.

2. **Bounded monotonic selection.** `newTextV2SearchBlockSelection` (`text_v2_search.go:2603`) borrows the immutable allow-set's sorted range, clamps retained capacity by source entry count, and saturates only the selection range's overflowing endpoint. Existing header/entry validation still rejects malformed source ranges. Each decoder creates its own cursor header; `keep` advances that header, never the shared backing or the allow-set's sorted slice. Source entries are validated as strictly increasing before selection. Nil/all preserves complete historical decoding; empty/disjoint selection keeps zero entries while validating the whole block. Selected-but-absent ordinals remain absent, preserving downstream missing-record behavior.

3. **Custody is accurate.** Norm field lengths are in a newly owned, exactly pre-sized selected array; retained entry field slices reference that backing and do not escape a scratch buffer. Doc-map ID slices borrow the complete owned raw record from `collectionGetAppendAtCatalogRoot(..., nil)` (`api.go:25507`), through `Snapshot.GetAppendAtRoot` (`db/root_snapshot.go:107`) and `Tree.GetAppend` (`tree/tree.go:1055`), which appends/copies inline or pointer bytes into caller-owned destination storage. Retained selected IDs therefore keep the original raw record backing live. The change does not claim to retain only selected raw bytes, refund raw backing, or shorten its lifetime. Existing final result/ID copying remains unchanged. The new test deliberately checks this raw-ID alias relationship.

4. **Every serving cache has the same immutable selection.** Exact search (`text_v2_search.go:347`), single-term block-max (`:651`), AND (`:922`), OR (`:1533`) and phrase (`text_v2_phrase.go:65`) bind their existing `allowSet` when constructing the cache. The two shared cache load sites (`search.go:2830,3009`) use it. Rewrite's zero-value cache remains nil/full. Strict scoring paths only request allowed candidate identities, and strict bound routines enumerate that same allow-set. Nil/all bound routines still see full blocks. Existing block-max fallback creates a fresh exact-search cache on the same snapshot; it does not reuse a cache with incompatible selection or relax cumulative fallback limits.

5. **Authority and errors remain unchanged.** Independently compared base/current function bodies for allow-set construction, `contains`, `rangeBounds`, `normEntry`, `docMapEntry`, both full-range and both allowed-range bound helpers: all are byte-identical. Forward docID resolution, missing norm/doc-map handling, generation/status checks, tombstone decisions, lexical ordering/ties, full inspector behavior, snapshot binding and existing format-validation policy are not changed. No new owner, view, pool, cache policy, receipt or admission callback is introduced.

6. **The representation exception is honest.** The new tests reference new private symbols and cannot be advertised as an old-source public behavioral RED. The packet's test-first note expressly uses the justified representation-only exception; expected public results and errors remain identical. The existing public harness/work counters and a same-owner, same-profile comparison must establish activation and cost. No test compilation failure or absent benchmark is a behavioral outcome.

## Test source and remaining validation

The three new test groups cover nil/all/strict/empty/other-block retention capacity, raw docID backing aliasing, excluded invalid generation/flags/range/order/field overflow/empty IDs/truncation/trailing data, absent selected ordinals, sparse and high-ordinal blocks, tombstones/generations, full-decoder differential values and unchanged shared sorted allow-set state. Their exact malformed-error comparison protects the relevant historical failure boundary.

No additional blocking test omission was found for this extraction. A cache-level interleaved norm/doc-map multi-block witness would strengthen activation coverage, but is supplementary: each decode has independent cursor state, the existing sparse differential source exercises repeated use of the shared allow-set, and maintained public suites cover scoring/fallback/capture behavior. New tests alone do not establish public-path parity or measured savings.

Root should run the new `^TestTextV2SelectedSidecar` controls and maintained scalar pruning parity/missing-ID/reopen controls; AND/OR scalar-prefilter and overlap-fallback cases; randomized block-max exactness/fallbacks; corruption across query shapes; phrase scalar-allow-set and snapshot/reopen controls. The existing full-decoder rewrite/maintenance controls remain applicable. Root-owned focused/race/public work must preserve raw failures and bind separately formatted source hashes if formatting changes this packet. No tests were run during this review.

The spec accurately describes selected decoded retention, complete consumed-block validation, unchanged inverse-data policy and original owned raw-record lifetime. This acceptance concerns this exact source slice only.
