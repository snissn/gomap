import hashlib
import importlib.util
import json
import pathlib
import signal
import subprocess
import sys

ROOT = pathlib.Path('/mnt/fast4tb/gomap-mongo-execution-20261024')
WORK = ROOT / 'shared-text-selected-extraction1'
PACKET = pathlib.Path(__file__).parent
spec = importlib.util.spec_from_file_location('owned_process', ROOT / 'evidence/native-query-work-witness1/run.py')
H = importlib.util.module_from_spec(spec)
spec.loader.exec_module(H)
signal.signal(signal.SIGTERM, H.interrupted)
signal.signal(signal.SIGINT, H.interrupted)

def source():
    paths = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=WORK, text=True).splitlines()
    paths += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
    return {'head': H.git(WORK, 'rev-parse', 'HEAD'),
            'tree': H.git(WORK, 'rev-parse', 'HEAD^{tree}'),
            'status': H.git(WORK, 'status', '--porcelain'),
            'changed_files': {name: H.digest(WORK / name) for name in sorted(set(paths))}}

def overlays(args):
    bindings = {}
    for arg in args:
        if arg.startswith('-overlay='):
            path = pathlib.Path(arg.split('=', 1)[1])
            bindings[str(path)] = H.digest(path)
            for target in json.loads(path.read_text())['Replace'].values():
                if not target:
                    raise SystemExit('deletion overlay is not selected')
                bindings[target] = H.digest(pathlib.Path(target))
    return bindings

name, args = sys.argv[1], sys.argv[2:]
if not name.replace('-', '').isalnum():
    raise SystemExit('invalid attempt name')
receipt, log = PACKET / (name + '-receipt.json'), PACKET / (name + '.log')
if receipt.exists() or log.exists():
    raise SystemExit('refuse overwriting attempt')
before, overlay_before = source(), overlays(args)
command = ['/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.linux-amd64/bin/go', 'test', '-json', '-count=1', '-timeout=4m', *args]
H.write_json(PACKET / (name + '-plan.json'), {'source': before, 'command': command, 'overlay_bindings': overlay_before, 'outer_wall_seconds': 360})
env = H.safe_env({'GOTOOLCHAIN': 'local', 'GOMAXPROCS': '4',
    'GOCACHE': str(ROOT / 'gocache'), 'TMPDIR': str(ROOT / 'tmp')})
result = H.run_process(command, str(WORK), env, log, 360)
result.update(source_before=before, source_after=source(), overlay_before=overlay_before, overlay_after=overlays(args))
result['source_unchanged'] = result['source_before'] == result['source_after']
result['overlay_unchanged'] = result['overlay_before'] == result['overlay_after']
H.write_json(receipt, result)
print(json.dumps(result))
sys.exit(0 if result['process_ok'] and result['source_unchanged'] and result['overlay_unchanged'] else 1)
