# Native pointer reads after dictionary training: causal review

Reviewed source at clean `be187fa54c2e1f22b929158eb08e807ed7b1e72c`, source/artifact only. No builds, tests, measured workloads, profiling, source edits or delegation. This review does not disposition the unrelated PRIMARY/race/public-capture failures.

## Concrete failure and cause

The retained relaxed/eight-writer resource receipts in `qualification-be187/resources/pair1-command_wal_relaxed-writers8-candidate.log` and pair2 publish a trained single_value dictionary immediately before update failures at operations 8659 and 8663. IDs respectively 3846347829832147513 and 11622552943187977097; trained definitions are 131072 bytes. Both resource receipts truthfully retain attempted=9666, completed=9664, failed=true and null latency quantiles. They remain failed evidence.

**The production writer and native pointer reader disagree about an ordinary supported encoding.** The failure is a deliberate bridge eligibility rejection, not missing zstd support in the bounded decoder:

1. `collections/native_domain_build.go:164–176` projects oversized logical document values through `RootPublicationBuildGroup.AppendNativeValueLogValues` (`db/root_publication_native_build.go:145`). That calls the normal `DB.AppendValueLogValues` and existing caching value-log appender, retaining normal segment pins and dependency flush/sync.
2. `caching/value_log_appender.go:141–153` calls `appendValueLogForRecords`; `caching/db.go:3059–3122` selects the current dictionary by payload class. Normal auto compression legitimately transitions to dictionary frames after training (`vlog_compression_selector.go:1704–1774`). The writer emits grouped compressed frames with Reserved=0 and DictID nonzero (`internal/valuelog/writer.go:1947–1951`, 2167–2171).
3. Reads and update old-value reads select the original native collection cut, then `NativeJSONRead.readValue` (`collections/native_json_read.go:197–199`) invokes `NativePhysicalValueReader.NativeValueAtPointer`. Both the native capture and conditional transaction dispatch to `cowBackendBasis.nativeValueAtPointer`.
4. **`caching/cow_native_physical_read.go:112–113` rejects every compressed DictID!=0 with the exact observed error.** Its shared physical workspace deliberately has snapshot/basis nil. Merely deleting this guard moves the same failure to `cowReadWorkspace.definition` (`cow_read_workspace.go:226–228`).
5. `internal/valuelog/cow_reader.go:125–131` already accepts trained dictionary frame metadata; `NewCOWDecoder:472–503` validates content identity and constructs an admitted owned dictionary decoder; `Decode:520–541` checks the producer identity and decodes into exact caller storage. Existing `TestCOWDecoderHotGlobalCacheCannotSupplyDefinition` and `TestCOWNativeWindowBoundary/dictionary` cover this lower capability. There is no need to relax record validation, change the disk format, disable compression, raise budgets or use process-global decoder caches.

The retained logs do not contain the offending record bytes or a stack. The source rejection and the actual writer's eligible transition explain the precise observed error; a deterministic regression should additionally inspect the real produced pointer and assert Compressed=true/DictID!=0 before exercising the failing native bridge.

## Smallest coherent repair

Keep the existing original-cache shared physical workspace and its physicalMu, admission, decoder replacement and close paths. Supply **independently owned, identity-verified dictionary definitions** to its existing codec constructor on dictionary cache misses. A narrow explicit per-call resolver, or a narrow pure provider installed with SetDictStore, is sufficient; a new decoder/cache framework is unnecessary.

The built-in `dictdb.Store.AcquireDictionaryReadDefinition` (`internal/dictdb/read_definition.go:101–109`) already provides that pure bounded capability. It looks up append-only bytes/<content ID>, validates SHA identity, owns copied bytes plus any exact source pin, and releases its temporary backend snapshot before return. Its existing Prepare sibling plus ReleaseCapture is equivalent but requires explicit cleanup on every success/refusal branch. Reuse `cowCache.admitDictionaryRead`, `COWDecoderRetentionSizes`, `cowReadCodec.definition`, and `cowReadCodec.close` for the existing separate admission/refund/retention rules. The workspace must retain the independent definition owner, not any borrowed capture, cut, callback or DB scope. Clear transient provider/context bindings before returning even on refusal.

Do **not** temporarily assign `shared.snapshot=callerSnapshot` and then restore it: existing `definition()` may borrow generation-owned bytes with a nil owner, while the shared cached decoder outlives the caller cut. Restoring the field does not repair that missing custody. Do not use allocating GetDictBytes, the global codec cache, a fresh collection capture, or durable CaptureDictionaryResources as a read-time substitute.

Lock assessment for the built-in pure provider: dictionary storage is a separate backend (`public.go:988–1022`); Acquire does not acquire Store.mu, main-cache writer/cut/basis locks or physicalMu. Its staged budget admissions release their budget lock before backend capture. No reverse edge to physicalMu was found in the built-in provider. Therefore physicalMu -> pure dictionary backend capture/admission is consistent with the inspected implementation. Prepare/ReleaseCapture and failure Close may release snapshots/physical pins and perform storage cleanup: do not move them under writer/admission/publication locks. A custom provider must explicitly supply this pure capability; do not infer the same lock contract from generic DictStore. Obtaining an owned definition outside physicalMu and installing it after a recheck is an alternative if the provider cannot promise purity; it needs admitted loser cleanup and is a larger change.

An original-cut local workspace is lawful if it reuses the actual transaction Snapshot, or constructs an admitted wrapper for the exact already retained capture cut (no independent logical recapture), and keeps that wrapper until decoder close. It reuses existing dictionary authority but duplicates the large zstd envelope per short-lived native read/transaction. Prefer shared owned definitions for this ordinary update path; do not add that repeated large allocation merely to bypass the rejection.

Lifetime obligations: native scopes already retain the exact physical basis file until copy-out; keep output admission before independent allocation under the existing serialization. Close decoder and clear input/raw/definition aliases before refund. Missing/corrupt dictionaries, unsupported providers, and finite-budget refusal remain errors with complete partial cleanup. Cold reads from a scope retained across DB.Close need an explicit control: the existing `TestCOWNativeValueWorkspaceAdmissionAndLifetime` exercises post-close reads only after decoder warmup, so it does not prove that a closed dictionary backend can supply a previously unneeded definition. Do not fix that case by borrowing a live current cut or hot global cache.

## Bounded discriminator before qualification

Extend the maintained native value-workspace fixture with a real built-in dictdb definition, current-ID selection and actual writer-produced compressed pointer; assert its inspected shape, then exercise both capture and original conditional transaction NativeValueAtPointer. Include an actual ordinary BSON update/read after materialization, with retained old capture, fresh capture, checkpoint and reopen in the supported profiles. Keep the resource campaign failures and require a fresh exact-source resource qualification after repair.

Retain the existing constrained-budget output/refusal/retry and final-zero ownership assertions, and add definition/decoder refusal cleanup, missing/corrupt definition despite hot global cache, concurrent shared reads, and held-capture close (including cold-definition case). Existing useful lower controls: `TestCOWDecoderHotGlobalCacheCannotSupplyDefinition`, `TestCOWNativeWindowBoundary`, `TestCOWNativeValueWorkspaceAdmissionAndLifetime`, and `cow_dictionary_cleanup_test.go`. Update the NativePhysicalValueReader comment (`db/native_semantic_state.go:343–346`) when the bridge's eligibility contract changes. No disk-format change is needed.

## Reviewed exact blobs

- internal/valuelog/cow_reader.go: `7536e9d69f1bb2a95ba22ff6e1402d87ee64c0b1`
- caching/cow_native_physical_read.go: `ed0aba1febe92b67ce6649a8669f8e5ccf70bb14`
- caching/cow_read_workspace.go: `68bdd42942af8e883863dc52ecb2105b457d9088`
- db/root_publication_native_build.go: `3e1020ed209bdde88c90affb0ea7e10f0ea55ff4`
- internal/dictdb/read_definition.go: `27e79a96917b5622066aa00a7601ef654c36c2d9`
- caching/value_log_appender.go: `2fcb158610ad79f2fe2df8506b1fa9d73e2f77d1`
- collections/native_json_read.go: `410e533ee98b458136c192d3a04020e2d5e5fc37`


## Source-only repair review, be187 + dictionary overlay

Bounded ACCEPT of reviewed overlay (production source only; runtime receipts below supplied by root). Shared physical workspace stays snapshot/basis-free. Each trained pointer read supplies a stack/per-call provider descriptor; no borrowed provider/cut gets installed in `cowReadCodec`. Cold codec construction calls existing pure `PrepareDictionaryReadDefinition` with original cache admission, releases its temporary capture, and retains the independent SHA-verified owner in the existing codec slot. `DictionaryReadDefinition.Close` is nil-safe and once-only; new Prepare error branch closes a partial owner. Existing replacement, decoder-admission failure, constructor failure and final cache close retire the same owner. Added NativeSemanticCapture provider field is covered by existing unsafe.Sizeof admission and scrubbed on Close. Existing physicalMu excludes scratch readers/replacement; built-in provider operates on separate dictdb backend, with no reverse physicalMu acquisition found. No profile/CRC/dictionary identity check was weakened.

Controls source-check actual trained producer shape/ID, shared capture + transaction decoder reuse, strict retained output receipt, warm post-DBClose lifetime, cold closed-owner refusal without fresh lease growth, and second-stage provider admission failure after actual first-stage owner admission with exact stable reservation. Parent reports original+dictionary+closedcold+replacement+dictcleanup race PASS2.783s; actual opt-in held-reader relaxed8 10000x4KiB workload PASS2.882s; earlier accidental opt-in SKIP retained and is not validation. New partial-stage control was source-read, not executed by adviser. Failed old campaign remains failed; repaired-source campaign qualification is separate.

Reviewed overlay blobs:
- cow_native_physical_read.go `d5e4ca2181ed101997be7c35c5ea313da68fdab2`
- cow_native_semantic.go `7317ef9cb319023eab48af61b9f5bce71c19c863`
- cow_read_workspace.go `e91871f331e15b0e39b2bdd730ccb1d9d7cd2077`
- cow_native_physical_read_test.go `78f8b2e1a59b94ab290739f47e158b29013e7245`
- docs/spec/cow-cache-publication.md `ee09e1fca94ba688431af6bbf869df34691f3b09`

No tests/builds/runtime or production edits performed by adviser. This scoped source ACCEPT does not certify the full product/campaign or unresolved PRIMARY concurrency failure.
