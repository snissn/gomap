# PRIMARY concurrent capture causal review

Source-only review of `be187fa54c2e1f22b929158eb08e807ed7b1e72c`; no runtime or source mutation. CI receipt `race1-be187.log` preserves `TestOwnedBackendSuccessorPrimaryAndConcurrentCaptures` failure at line 128, followed by secondary reader ErrClosed during deferred teardown.

## Concrete race found

`zipper/primary_directory.go:77` `claimPrimaryComponent` calls `Arena.PrepareClaim(Component)` and then separately `Claim.Step`. `internal/primaryarena/arena.go:324` rejects *any* intervening global arena epoch change as bare `ErrStale`, before bank installation. Concurrent root coordinator `rootPublicationRuntimeV1.Prepare` (`db/root_publication_activation.go:1439`) calls `preparePrimarySealV5` (`db/durable_primary_runtime_v5.go:501`), which materializes the dependency manifest (`:542`) through `materializePrimaryManifestV5` (`:252`), `primaryBankConstructionV5.claim` (`db/primary_bank_construction_v5.go:75`), and `ClaimMetadataBanksIntoOrdinary` (`internal/primaryarena/metadata_range.go:11`). That real claim increments the same epoch (`:78`).

This overlap is permitted: relaxed nonsync ordinary Set waits for admission but not final sealing (`root_publication_activation.go:1399`); its next optimistic Apply releases rootReuse after base capture (`db/batch.go:394`) and does not retain the coordinator preparation gate. Coordinator durablePublish/rootReuse locks therefore do not exclude component preparation. This is a concrete valid interleaving producing the observed bare error. The CI error lacks a stage receipt, so source alone cannot establish it was the sole origin of that particular ErrStale.

## Read owner tracing

`db/pools.go:51` obtains an exclusive private pooled wrapper. Capture (`db/db.go:1784`) holds rootReuse RLock through registering, physical-owner retain and exact bank Acquire (`db/snapshot_primary_retention.go:13`). Arena Acquire/Drop are mutex-protected (`arena.go:603,630`). Private ordinary close (`db.go:2327`) only drops that bank edge; without primaryMetadata enrollment it does not drain a retirement queue or advance epoch. Physical owner release retains the DB edge, so it cannot close the arena while DB remains open. No source evidence supports blaming concurrent captures, pooling, or weakening supported concurrent Set/read behavior.

## Smallest repair and discriminator

Retry only the uninstalled component claim's Step epoch refusal in `claimPrimaryComponent`, after successful exact Cancel. Preserve other Step errors and Cancel failures. Reprepare a new claim; do not rerun Apply, callbacks, logical publication, or an assigned WAL command. `Step` checks epoch before installing, and Cancel cleans its actual wrapper/private chunk/growth. A one-lock ordinary component helper sharing existing claim internals is a larger alternative if bounded nonretry admission is required; taking DB-wide writer locks through all Apply would unnecessarily serialize work.

Deterministic lower control: prepare Component claim; perform actual ordinary Manifest bank claim; verify old Step ErrStale and successful Cancel/refund; the repaired ordinary helper must cancel/reprepare and install exactly one fresh component with no abandoned custody. Add or reuse a narrow test interleave around the helper if required, rather than scheduling sleeps. Retain the unchanged public concurrent capture test and its exact owned bytes/pin/Close assertions. The deterministic interleave confirms this defect, while public reproduction or stage-specific receipt is required to bind the CI failure conclusively.

## Reviewed blobs

- TreeDB/zipper/primary_directory.go `0794ddadd3896f5c1810b18eeb9a20e4c38210bd`
- TreeDB/internal/primaryarena/arena.go `341f4514024fc643e7cf626c5650eebe61de0b89`
- TreeDB/internal/primaryarena/metadata_range.go `261b1ce855af5cba9e1f458c0fcbe62df40547ff`
- TreeDB/db/durable_primary_runtime_v5.go `985a047f37d12e9d717cdbd244f541de181b3f55`
- TreeDB/db/pools.go `35deb550f86d1da2819db82f49237a6ca9b7a463`
- TreeDB/db/db.go `cfb3920cbfbbadc128e7bab0de50dbd6f60986e5`
- TreeDB/db/owned_successor_test.go `6ca56028ff093efbeba88ed73e0f929a33662323`

## Selected repair rationale (parent decision)

Parent selected an atomic ordinary component claim, sharing extracted lock-held Prepare/Step bodies and retaining the phased API/epoch refusal. This avoids retry/starvation and reexecuting any callback/command. Existing Step already holds arena.mu across pager growth/install (arena → pager allocMu/growMu/mu); an outer ordinary mutex scope preserves that direction. Cancel must consume the actual private claim on every error before releasing the lock, retaining cleanup error custody. No existing atomic Component helper was found; metadata range claiming is restricted and changes the reuse algorithm.

Routing caveat sent before implementation: the sole production `claimPrimaryComponent` caller (`zipper/primary_directory.go:528–530`) always supplies a nonnil `OrdinalScanWork` with MaxUint64 limits for ordinary metrics. A nil-work branch alone would never repair Set. The actual ordinary caller must explicitly select the atomic route while preserving truthful Records/Bytes; nonnil metering is not evidence of a bounded native consumer. Parent-reported unchanged public race50 PASS7.542s is a useful control, not proof of the sole old CI origin. Implementation not yet reviewed in this addendum.

## Atomic implementation source review (dirty overlay)

Successful claim/actual route: ACCEPT. `ClaimOrdinary` shares extracted lock-held Prepare and Step bodies, retains class/admission/epoch validation, and holds arena.mu through selection and install. The real zipper caller now routes its nonnil unlimited meter unconditionally; bounded false/nil refusal becomes an explicit zipper error, not a zero page. Normal split/atomic work and counters remain equivalent by construction. Existing phased Prepare/Step API remains available with its original stale rejection. Pager unlimited Step completes its phase loop without a voluntary yield, so one Step suffices here.

Actionable cleanup residual: `arena.go:412` ignores Cancel's ready result and returns only a zero ref plus joined error. `pager/grow_work.go:562,576` can fail to unmap a private mapping, leaving the actual Claim/growth/chunk and metadata charge live. Returning a plain error loses the local Claim payload; no existing Arena sink or returned receipt retains it. The old zipper helper had analogous exposure, but the new ordinary API must preserve the original failed private owner instead of claiming every error canceled it. Parent notified: retain SAME claim via a narrow typed cleanup receipt/physical owner sink or return custody to its caller; never retry/drop/refund it after uncertain cleanup. Pending fix, this is not unconditional packet ACCEPT.

Test coverage source: deterministic split Prepare → actual metadata allocation → stale Step and cancellation checks the identified race. Split/atomic exact work+counters and bounded postprepare refusal cleanup are meaningful. Concurrent component/metadata allocation checks independent live refs and exact Drop. The test currently called ConcurrentMetadataSealing performs no SealMetadata; rename to Allocation or explicitly construct/seal valid metadata before claiming sealing coverage. Public concurrent Set/read test remains required unchanged. No adviser runtime.

Reviewed blobs: arena.go `686678feef065676110cc160cfb3cd249720c881`; zipper/primary_directory.go `7db7e4fe84e174fc8d09bd520f283cb8bacd1570`; ordinary_claim_test.go `93583d5763307673b60f7d745c1d309d5eb544a4`.

## Final narrow cleanup correction review

Bounded source ACCEPT of atomic ordinary PRIMARY repair plus original failed-disposal custody. New embedded `ordinaryClaimDisposalFailure` is charged by existing sizeof(Arena) constructor admission. Atomic refusal consumes Cancel's ready/error outcome; failed disposal retains the SAME Claim in the arena's original embedded receipt, preserving both causes without a new per-operation allocation. prepareClaimLocked refuses a later claim before replacement, and physical Close checks that receipt before closing pager, clearing chunks or refunding metadata. The exact failed payload cannot be overwritten by another atomic claim, because all entry/retention transitions hold arena.mu and preparation refuses after first failure. No callback/retry, weaker stale check, allocation strategy change or new lock order is introduced.

Renamed test truthfully covers concurrent metadata allocation. Failed-disposal test directly exercises retention with a real prepared Claim and injected cause objects, verifying aliases, exact receipt identity, original charge and repeated allocation/Close outcome. It does not inject a real OS unmap failure or execute ClaimOrdinary's Cancel-error branch; that limit is explicit. Pager retains its separate physical unmap coverage. Parent reports focused race2 PASS1.025s; adviser did not execute runtime.

Final reviewed dirty blobs: TreeDB/internal/primaryarena/arena.go `8327f12abfba185a4d49304ae98c748d2e32c797`; TreeDB/internal/primaryarena/physical_close_work.go `9ea542e44660fe05653687174c517e3f87adba7f`; TreeDB/zipper/primary_directory.go `7db7e4fe84e174fc8d09bd520f283cb8bacd1570`; TreeDB/internal/primaryarena/ordinary_claim_test.go `f14681a1005b7c563a1d21e053b07099eaf57cb8`. Previous cleanup residual resolved for this scoped packet. Public/CI qualification and exact original CI-origin binding remain root-owned.
