## Public PRIMARY replacement cost

- Verdict: PASS
- Exact base/head: `f906b8a2aa1279ed6b6627028cba71d491db04c3` / `950976af8688ba0a5ed7eaced44b82da25c44181`
- Eight alternating AB/BA pairs; 128 durable public replacements per sample.
- Median paired time delta: +0.409% (limit +5%).
- Raw gates: `{"allocations": true, "bytes": true, "candidate_primary_activation": true, "timing": true}`; measurement pass: True; quiet: True.
- Timing acceptance: `PASS`; bytes acceptance: `PASS`; bound runtime/input equivalent: False.
- Scope: this public replacement workload; not final graph qualification.
