## Public PRIMARY replacement cost

- Verdict: FAIL
- Exact base/head: `f906b8a2aa1279ed6b6627028cba71d491db04c3` / `be187fa54c2e1f22b929158eb08e807ed7b1e72c`
- Eight alternating AB/BA pairs; 128 durable public replacements per sample.
- Median paired time delta: -0.538% (limit +5%).
- Raw gates: `{"allocations": true, "bytes": false, "candidate_primary_activation": true, "timing": true}`; measurement pass: False; quiet: True.
- Timing acceptance: `PASS`; bytes acceptance: `FAIL`; bound runtime/input equivalent: False.
- Scope: this public replacement workload; not final graph qualification.
