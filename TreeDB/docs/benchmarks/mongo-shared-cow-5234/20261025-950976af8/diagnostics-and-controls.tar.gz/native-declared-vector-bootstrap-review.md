# Declared ordinary HNSW bootstrap: repair first packet

Bounded source review of a12a5609a06bd05383506cc514dc20433ed5ebfc vector-only delta against be187/c51, 2026-10-24. No runtime/build/tests or source edits.

Material first-packet gap: nativeJSONMeta already accepts normalized ordinary HNSW VectorIndexes, while prepareNativeJSONCreate creates no corresponding named graph domain. buildNativeHNSW (native_hnsw.go:337) records interpretation only if that domain exists; validateNativeHNSWRead (:418) unconditionally requires it. Native CRUD can publish rows and build/register a runtime whose next validation fails stale-root. A fixture that calls CreateVectorIndex after CreateCollection takes a different bootstrap path and does not prove this public declaration path.

Move the vector-only empty-domain initialization into the first packet before qualification. Normalize/eligibility remains unchanged. Compute vectorDomainCount only for nativeOrdinaryHNSWMeta(meta): ColumnStore must be nil and all definitions must use the ordinary native runtime. Pass this count into newNativeEnginePreparation (ownedDomains backing is preadmitted there) and domainBuilder. For each ordinary declaration obtain collectionRootStoragePolicy and create newNativeDomainState(relative name, baseRoot=0, interpretation=1, pending=nil), append its original reference to p.ownedDomains before domainBuilder.Set. The existing shared preparation cleanup then owns every failure edge. No pending-domain insert or pending capacity is needed: these empty clean domains contain no dirty graph image. Root=0/version=1 matches existing importer defaults, so no new metadata record/format/WAL discriminator is required.

Do not transplant a12's unconditional all-VectorIndexes loop wholesale: nativeJSONMeta also separately admits nativeSourceImportMetaV2, whose ColumnGraph declarations are source metadata rather than ordinary ANN capability (native_source_import_v2.go:21-43). Adding graph domains/charges there is unnecessary cross-capability expansion. Existing normalization validates index identity/path/dimensions/strategy/encoding and canonical storage policy before preparation. Keep typed/source-import behavior unchanged.

Bounded proof: public CreateCollection with vector metadata directly, Insert/Update/Delete, active Search and Save, checkpoint/close/fresh reopen/load/search; include empty declared graph and prepublication admission refusal/cleanup. This is a correctness requirement; old c51 timing/resources remain bound to old source and cannot become corrected-source qualification by relabeling.

Reviewed source references: native_json_public.go a12 blob 2d0df2901 (full identity in git); native_hnsw.go:26-34, :337, :418-431, :435-465; native_domain_state.go:37-51; native_engine_prepare.go:54-66; native_json_import.go:236-260; api.go:25397, :26056, :26331. Source-only recommendation, not executed proof.

## First-packet repair source recheck

Source-only ACCEPT for the three-file dirty repair against c51bc1e05ad3272dab99e6392b0d7b210a825d05. Exact reviewed blobs:

- native_json_public.go: 478e4e6191bbb5121457d9df5f8463ac737a40b4
- api.go: e25492ede831ee2136f5cff269a01445a1dfa157
- native_hnsw_public_test.go: cd8958d4cc13a60d241cb02fd77cec9663308615

`prepareNativeJSONCreate` :179-228 computes vectorDomains only for nativeOrdinaryHNSWMeta, preadmits its original ownedDomains backing and owned map builder, creates canonical-policy/root0/interpretation1/pendingnil descriptors, and appends each original owner before builder.Set can fail. Existing deferred preparation cleanup retains and releases both directory edges and original domain references. Empty declarations remain zero-capacity, typed/source-import declarations skip the loop, and the pending builder remains zero because no graph image needs materialization. Normalization/eligibility and ACK/publication paths are unchanged.

`StoredDocumentJSONMaterializer.StoredDocumentJSON` api.go:571 now calls nativeRead.templateJSON only for TemplateV1. JSON follows its maintained owned bytes.Clone path; BSON follows validation/canonical Extended JSON. This also preserves captured native template resolution and avoids an unrelated mutable lookup. No new lifetime/lock owner is introduced.

The renamed `TestNativeHNSWPublicDocumentLifecycle` expands the same maintained body to 12 cases (three profiles × JSON/BSON × declared/later-DDL) with a format-aware document helper and constructor choice. It retains default exact-underfill plus ANN, save/checkpoint/close/reopen, mutation, held old/current graph replacement, stale-generation and drop/recreate controls. Source search found no old test-name reference in maintained scripts/docs searched. The retained old-source red log native-hnsw-declared-format-red1.log reports nine expected failing new cases: six declared postpublication maintenance ambiguity failures and three JSON exact-underfill template errors; the three preexisting BSON/later-DDL cases do not fail. It is a real red result, not green evidence. Root owns green race, finite-create-refusal control and broad owning suites; this acceptance is limited to the reviewed source repair and fixture semantics.
