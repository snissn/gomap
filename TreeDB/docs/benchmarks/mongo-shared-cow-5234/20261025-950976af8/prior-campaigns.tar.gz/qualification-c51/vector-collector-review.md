# Fixed vector collector source pre-review

Source-only ACCEPT for capture/retention scope, 2026-10-24. Reviewed collect_vectors.py SHA256 434d0c6a2af8ce3fed628aedfb141e06bc0c12f702ee59fe288fef7b63e9cec5 and qualification-c51/manifest.json. No execution or acceptance of measurements.

The collector constructs exactly 18 fixed cells: three alternating pairs × BuildSaveLoad/SaveReopenLoad/Search × baseline/candidate. Each cell is a fresh frozen test binary process, exact anchored benchmark selector, -test.run=^$, count=1, benchmem/verbose; 10x for the two build/save cells and 10000x Search, GOMAXPROCS=4 and task TMPDIR. The frozen manifest binds baseline f906 binary SHA9870ef48..., candidate c51bc1e05ad3272dab99e6392b0d7b210a825d05 SHA0277fe6e..., the identical reviewed harnesses and maintained driver SHA91a849.... Recorded environment is Go1.26.0. No rebuild is performed by the collector.

Plan/manifest/receipts are written before workload execution; host inventory and raw combined output are retained per cell. Nonzero process returns are retained as failed and collection continues through the fixed rows. Successful process return means completed_unvalidated, not parsed, valid or accepted. A startup/invocation exception leaves running/not_run rows visible and cannot be accepted as a completed fixed batch. No retry or sample replacement exists. Output directory must be new, preventing overwrite of prior batches. Final counts are process-status counts only.

Independent raw review must verify route/fixture/source/metrics/host and all 18 cells; the collector deliberately does not parse or declare acceptance. The new declared-vector-bootstrap correctness gap means these c51 binaries must not be promoted as corrected-source qualification after a product fix. Preserve any captured c51 receipts with their original identity.

Small operational limit: digest checks use Python assert and therefore require ordinary Python execution (no -O/PYTHONOPTIMIZE); use explicit exceptions if the invocation environment cannot guarantee that. This does not alter the fixed benchmark protocol or acceptance rule.
