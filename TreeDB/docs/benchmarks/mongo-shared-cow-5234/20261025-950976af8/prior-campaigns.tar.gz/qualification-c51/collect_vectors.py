"""Capture the fixed vector guard batch once; process completion is not acceptance."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "manifest.json").read_text())
spec = importlib.util.spec_from_file_location("reviewed_driver", manifest["driver"]["path"])
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
assert driver.digest(manifest["driver"]["path"]) == manifest["driver"]["sha256"]
for side in ("baseline", "candidate"):
    assert driver.digest(manifest[side]["binary"]) == manifest[side]["sha256"]
out = ROOT / "vectors"
out.mkdir(exist_ok=False)
rows = []
for pair in range(1, 4):
    for benchmark, operations in (("BuildSaveLoad", 10), ("SaveReopenLoad", 10), ("Search", 10000)):
        for side in (("baseline", "candidate") if pair % 2 else ("candidate", "baseline")):
            rows.append(dict(pair=pair, benchmark=benchmark, operations=operations, route=side,
                label=f"pair{pair}-{benchmark}-{side}", status="not_run", returncode=None,
                command=[manifest[side]["binary"], "-test.run=^$", "-test.count=1",
                    "-test.timeout=20m", f"-test.bench=^BenchmarkStandalonePublicVector{benchmark}$",
                    f"-test.benchtime={operations}x", "-test.benchmem", "-test.v"]))
driver.write_json(out / "plan.json", rows)
driver.write_json(out / "manifest.json", dict(source=manifest,
    collector_sha256=driver.digest(__file__), acceptance="separate raw-output/route/fixture/metrics/host review required; no retry"))
driver.write_json(out / "receipts.json", rows)
env = dict(os.environ, GOMAXPROCS="4", TMPDIR=manifest["tmpdir"])
for row in rows:
    driver.host_inventory(out / (row["label"] + "-host.txt"))
    row["status"], row["start_unix"] = "running", time.time()
    driver.write_json(out / "receipts.json", rows)
    with (out / (row["label"] + ".log")).open("w") as stream:
        result = subprocess.run(row["command"], cwd=manifest[row["route"]]["cwd"],
            env=env, stdout=stream, stderr=subprocess.STDOUT)
    row["returncode"], row["end_unix"] = result.returncode, time.time()
    row["status"] = "completed_unvalidated" if result.returncode == 0 else "failed"
    driver.write_json(out / "receipts.json", rows)
print(json.dumps(dict(planned=len(rows), statuses={status:sum(r["status"] == status for r in rows)
    for status in sorted({r["status"] for r in rows})})))
