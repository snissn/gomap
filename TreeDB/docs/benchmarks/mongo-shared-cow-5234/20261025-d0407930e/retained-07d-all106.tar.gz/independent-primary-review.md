# Independent primary review: qualification 07dca301b

**ACCEPT the completeness, provenance and numerical primary-gate result for exact candidate `07dca301b28dbef0e505c0ec2d9a825ea6221b43`.** This is a primary-only evidence verdict, not whole-product/performance promotion. Resources and vectors are outside this review and remain separately required.

Review performed 2026-10-25 using only source/artifact reads and Python analysis; no Go, build, test, benchmark, profile, checkout, source changes or delegation. The candidate and manifest were immutable during the reviewed primary batch.

## Source and executable bindings

- Candidate: `07dca301b28dbef0e505c0ec2d9a825ea6221b43`; binary SHA-256 `c2733a06b25c6f515d42a965c0d7999c004901fe2d8252d6b18e61574f79b356` (64,340,086 bytes). Independently streamed the retained executable and matched the manifest.
- Baseline: landed harness commit `eb9a4ab4a8e7c2c4ff34b53552b2cdde9a9c7144`, representing unchanged product `f906b8a2aa1279ed6b6627028cba71d491db04c3`; binary SHA-256 `2218517aa643004a19590bb530bb2e83e236a77ee954d4c98b18cc467784182a` (63,989,159 bytes), independently matched. The eb9/f906 changed-path inventory contains only the landed harness/tests/docs and CI metadata, not product runtime changes.
- Independently checked all seven harness blob records against both exact commits and landed eb9; all match. Maintained driver blob is `54fb0acf9e2a7068b297e3efb2246497e4965feb`, measurement protocol `3c8ab5bc8a316f68ad0e8647a122acbb9ce02bc0`. All 18 non-CI pressure paths match reviewed 6647. CI is now separately identified instead of falsely declared identical.
- The e806/07d diff contains only the two reviewed refusal tests and the CI discovery hash. The candidate executable SHA is identical to the e806 executable recorded before the test-only repair. Retained build-info identifies Go 1.26.0; source correspondence is supplied by these source/build/manifest records, not an embedded VCS attestation.

## Files and independent checks

Read the frozen root and copied primary `manifest.json`, `primary/plan.json`, all 64 `primary/pair*-*.log`, all 64 corresponding `-host.txt` snapshots, `primary/receipts.json`, `primary/summary.json`, all 64 rows of `primary-operator.log`, final build-info, and the landed driver/protocol. Root and primary manifest bytes match.

The plan and receipts have exactly 64 unique ordered labels: eight pairs × durable/relaxed × one/eight writers × baseline/candidate. Odd pairs execute B/C and even pairs C/B. Every receipt agrees with its planned command, is terminal valid/exit zero, and has one corresponding raw log and host snapshot; operator receipts agree. Recorded launch intervals are sequential. There are no failed, null, dropped, duplicate, substituted or retried attempts in this completed primary batch. Other prior failures are not claimed repaired or reclassified by these results.

Independently parsed every raw log instead of trusting stored metrics. Every final row has exactly 1,000 operations, the expected anchored cell, GOMAXPROCS suffix 4, and the correct BSON product opener/profile/native activation, w:1/j:unspecified ACK, 64 rows per writer, 256-byte payload and two secondary indexes. Both calibration and final route logs are retained. Each log terminates PASS without failure/panic markers. Raw ns/op, ACK/s, B/op, allocs/op and final WAL sync counters agree exactly with receipt metrics. Calibration is not counted as a separate retained 1,000-operation sample. Both calibration/final disconnect/Close durations remain outside the ACK timer and present in raw output.

Recomputed all 32 paired candidate/baseline triples and the median of each set of eight ratios; every pair, median and `numeric_target_pass` value agrees exactly with the summary. The unchanged landed targets apply: durable/one-writer time reduction at least 10%; all other time cells at least 25%; B/op and allocs/op at least 20% in every cell. Their stronger limits also satisfy the comparable-primary 5% regression guardrail.

| Cell | Median ns/op reduction | Median B/op reduction | Median allocs/op reduction | Individual paired time-ratio range |
|---|---:|---:|---:|---:|
| command_wal_durable/writers=1 | 10.7936% | 55.0633% | 44.2416% | 0.853987–0.900480 |
| command_wal_durable/writers=8 | 80.8041% | 78.3133% | 76.4763% | 0.189740–0.695110 |
| command_wal_relaxed/writers=1 | 75.6952% | 62.1430% | 43.3501% | 0.239161–0.290908 |
| command_wal_relaxed/writers=8 | 96.1096% | 80.2118% | 73.8270% | 0.036064–0.108297 |

## Dispersion and interpretation

All four numerical cells pass. Durable/one-writer median reduction is 10.7936%, relatively near its 10% threshold; one individual pair is below 10%, which does not violate the predefined median-of-eight rule. Baseline durable/eight-writer ns/op ranges 1.830–6.709 ms while candidate ranges 1.272–1.286 ms. Baseline final sync counts by pair are `[999,1000,250,998,250,999,1000,998]`, versus `[250,250,250,250,250,250,250,250]` candidate. Thus the large median improvement includes scheduling/grouping variation observable in the maintained product path; it should not be presented as an invariant per-request speedup. All those samples, including the two faster baseline pairs, remain included. Durable/one-writer records 1,000 syncs on each side in every pair; every relaxed cell records zero timed syncs. This does not weaken durable ACK for the comparison.

Host inventory is preserved per attempt; no recognized Go/compiler/build executable appeared in the 64 snapshots. The disclosed shared-host fallback remains a limitation: snapshots/cumulative ps percentages cannot prove continuous exclusive CPU or absence of external I/O. No numerical uncertainty or host-isolation certification is inferred beyond this fixed batch. Resource tails, deferred maintenance, memory/files, vector allocation tradeoffs, capability/recovery, exact-head CI/review and the independent PRIMARY issue remain separate gates; these primary results waive none of them.

## Immutable artifact identities

- `manifest.json` SHA-256 `0d7ab42962c96c30e44c623192cba52cd5cdb71dcf7f56435a39afd6b5dbb136`.
- `primary/plan.json` SHA-256 `85cbc57e998e8299a3606c9a5266a02fe957278ddc398f82d5a6613b5f902daf`.
- `primary/receipts.json` SHA-256 `3278cd78b9557b9744a376defd15e4d4828e19437fe6a4e49d53daa3b95018bd`.
- `primary/summary.json` SHA-256 `12450b43baad3edd9e378b4484874a607c492dae9f4132e82be51c2b1fef2c6d`.
- `primary-operator.log` SHA-256 `92c60c13209bbab0ff8b1f03b5ba41062d77b804ab3d1bf1b62cef1549e64358`.
- Combined raw/host set SHA-256 `afa9759eb195c8abd79ef4da2dd6a39e0bf198452d00277f205b7e08c4e1f0a2`: SHA-256 of lexicographically sorted UTF-8 lines `label SPACE sha256(raw-log) SPACE sha256(host-snapshot) LF`, all 64 labels.
