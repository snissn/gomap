# Independent resource/vector evidence review: 07dca301b

**ACCEPT completeness and the independently recomputed numeric summaries for all 24 resource and 18 vector attempts. Promotion remains OPEN: the fresh Search allocation increase requires its own causal disposition; the old 950 tradeoff acceptance does not waive it.** Resource maximum latency also remains a material reported tradeoff, rather than being canceled by favorable p99/memory results.

Exact candidate `07dca301b28dbef0e505c0ec2d9a825ea6221b43`; baseline `eb9a4ab4a8e7c2c4ff34b53552b2cdde9a9c7144` represents f906 product plus the landed identical harness/schema. This audit extends `independent-primary-review.md`, including its independently checked executable SHA, seven harness blobs, 18 pressure blobs and test-only final-head binding. No runtime/build/tests/benchmark/profile/source edits/delegation performed. Python was used only to read and independently analyze artifacts.

## Completeness, provenance and validation

Read frozen manifest/plans, every raw log and host snapshot for these 42 attempts, resource receipts/analysis/operator log, vector original process receipts/final validated receipts/summary, and the landed diagnostic/vector Go harness. There are exactly 24 and 18 unique raw logs, host files and terminal receipts respectively. Plans and receipt identities/commands/order agree; recorded launches are sequential within each batch, with no missing, duplicate or replacement attempt. Resources use three alternating B/C then C/B then B/C pairs for all four profile/writer cells. Vectors use the same alternation for each of three benchmark cells. Every process exits zero and its raw output ends PASS, with no failure/panic markers. All fixed-plan outcomes are retained; no failed/null sample exists in either completed batch.

The resource manifest equals the frozen root manifest byte-for-byte, and copied vector plan equals frozen root vector-plan byte-for-byte. Original vector `operator-process-receipts.json` remains completed_unvalidated/null metrics. Its commands, environment, timing, errors and process outcomes exactly agree with subsequently validated receipts; only validation/metrics/status were added/changed. No prior unvalidated receipt was erased or represented as an original validated measurement.

For each resource attempt, independently checked the exact selected subtest, product opener/profile/native flag/BSON/ACK/64-rows-per-writer/4096-byte payload, one PUBLIC_RESOURCE_JSON record, 10,000 operations/attempted/completed, failed=false, positive ordered nonnull quantiles, and whole JSON equality with receipt metrics. Each has before, zero or more held-churn, after-ACK-held, reader-released, idle-2s and closed-GC phases in order, with monotone timestamps and at least two seconds between release and idle sample. Held membership/documents are checked by the landed Go harness before release: all seed index membership plus one seed payload, not every seed payload. Finish/held-read/sampler failures set t.Failed, null quantiles or fail the process; all observed attempts are successful. The raw logs do not retain individual latency slots, so quantiles are authenticated to the maintained harness computation, not independently reconstructed from request timestamps.

For each vector attempt, independently checked exact anchored benchmark, final row count, no_wal_fast product opener, route activation, 512 BSON rows, eight dimensions and M=16. Both calibration/final fixture records remain raw. Final operation counts are 10 Build/Save/hotLoad, 10 Save/Close/reopen/Load/validatingSearch, and 10,000 warmed ANN Search. Exact raw ns/op/B/op/allocs/op agrees with final metrics. GOMAXPROCS suffix/environment is 4; explicit operator environment records Go1.26.0/GOWORK=off/task TMPDIR. The unchanged landed Go source defines actual timing boundaries and validates fallback-disabled TopK=5 steady Search; this is ordinary API through the standalone owner, not a Mongo vector-wire performance measurement.

## Independently recomputed resource numbers

Recomputed all 12 paired records and all median ratios directly from raw resource JSON. Per-attempt footprint is the maximum across **all available recorded phases**, including final Close/GC, for HeapAlloc/HeapInuse/RSS/logical regular-file bytes; these are sampled high-water values, not continuous peaks. Every underlying pair, sampled maximum, ratio and median agrees exactly with resource-analysis.json.

| Cell | ACK seconds C/B | p99 C/B | max C/B | sampled HeapAlloc C/B | sampled RSS C/B | sampled file bytes C/B |
|---|---:|---:|---:|---:|---:|---:|
| command_wal_durable/writers=1 | 0.839203 | 0.514690 | 4.001685 | 0.571894 | 0.232831 | 0.042144 |
| command_wal_durable/writers=8 | 0.630286 | 0.528376 | 1.096920 | 0.484301 | 0.447306 | 0.293102 |
| command_wal_relaxed/writers=1 | 0.288027 | 0.078764 | 8.141186 | 0.486221 | 0.228717 | 0.036721 |
| command_wal_relaxed/writers=8 | 0.116779 | 0.080444 | 1.462035 | 0.387707 | 0.430647 | 0.177825 |

Candidate request maxima range **131.660–149.942 ms**, exceeding the previous developmental 119–146 ms range. Lower p99 and sampled footprint do not waive maximum latency. The mechanism remains source/data-consistent with synchronous bounded producer-pressure checkpointing: current `PrepareNativeProducer` invokes original Checkpoint at >=3/4 reservation or exhausted source/generation capacity, serialized before captures/consumer locks, followed by the reviewed original-worker cleanup frontier join. `cow_checkpoint.go` is unchanged versus 950; the pressure predicate/cleanup joining changed, so this is not a claim of identical request topology or duration. Current relaxed/one-writer checkpoint.max_ms values are 120.195, 121.863 and 127.518 ms; corresponding request maxima are 133.194, 134.713 and 147.066 ms. This supports the existing checkpoint-tail explanation/classification. It does **not** prove the exact slowest request's stack, attribute its extra milliseconds, or constitute a fresh trace. Zero legacy per-stage counters do not prove absent stage work. The previous actual 950 trace and rejected early-wake experiment remain source-bound historical evidence, not new-head measurements.

Every candidate after-ACK-held sample has six sources, and every idle-2s sample has zero sources. Idle reserved bytes remain approximately 270.48–290.59 MB, including fixed maintenance/live owners; zero sources is not zero reserved memory or RSS. Closed-GC stats omit the COW source/reservation keys: missing counters remain unavailable, never fabricated final zero. The successful harness Finish/Close path plus separate maintained full-zero lifecycle controls must be stated separately. Logical file bytes include WAL and are not allocated filesystem blocks or WAL-excluded size. Shared-host/sampled-memory limitations from the frozen protocol remain applicable; three pairs do not establish universal tail/space bounds.

## Independently recomputed vector numbers

Recomputed all nine paired triples and all medians directly from final raw rows; each stored pair/summary agrees exactly.

| Benchmark | ns/op C/B | B/op C/B | allocs/op C/B |
|---|---:|---:|---:|
| BenchmarkStandalonePublicVectorBuildSaveLoad | 1.012245 | 0.233438 | 0.407453 |
| BenchmarkStandalonePublicVectorSaveReopenLoad | 0.750005 | 0.226163 | 0.895249 |
| BenchmarkStandalonePublicVectorSearch | 0.317263 | 0.484286 | 1.400000 |

Build/Save/hotLoad time is +1.2245% at the median while bytes/allocations improve; physical Save/reopen/Load time improves about25%. Search time improves68.2737% and bytes51.5714%, but allocations rise **15→21 in every pair (+40%)**. This is a fresh adverse result. The former developmental candidate19-versus-baseline15 comparison was a different source and is not an automatic waiver; no performance promotion for the fresh increase is asserted here. A source-bound attribution/decision is required from root before final disposition. The fixed vector guardrail calls for qualitative explicit tradeoff review, not an invented new universal threshold or selective retry.

## Immutable reviewed artifacts

- `manifest.json` SHA-256 `0d7ab42962c96c30e44c623192cba52cd5cdb71dcf7f56435a39afd6b5dbb136`.
- `resources/plan.json` SHA-256 `aedac6594b6bc4b9f69a01404d3fe284e3fb6e9c0b16709539fe97998db29cf0`.
- `resources/receipts.json` SHA-256 `f900f75138ae24e17266a59db6c3aa7a904753c60d3e673e022257610be61a22`.
- `resources-operator.log` SHA-256 `3460dde708bc4d9386d6545bb6191b2bb67966b40be6a54153abd3ff89c48677`.
- `resource-analysis.json` SHA-256 `c69dc03bea68adcc0009509d44bdf52606953cf168fb2dfbd5228d91ac833fe6`.
- `vector-plan.json` SHA-256 `95da9027c95ea98a78cf46017e77865a74b1900f90bc9e052056ebdcf258585d`.
- `vectors/plan.json` SHA-256 `95da9027c95ea98a78cf46017e77865a74b1900f90bc9e052056ebdcf258585d`.
- `vectors/operator-process-receipts.json` SHA-256 `848afd83abfe1452ed721b82944b14f3c986b32c20f3005c8b3df4942a2047cd`.
- `vectors/receipts.json` SHA-256 `c4a65d10d2293a747f43f26c05ddddad34ffcab366bcbbf521c7f62cc7db1cb7`.
- `vectors/summary.json` SHA-256 `80bb7ba060ae3d8e53af32e38751de3122ddb1c4841d8b6ee1a44de1d60ae60a`.
- `resources` complete raw/host set digest `d5ea03674dab727116a3e4e01c3d1abaf7c78c09e90b7ce96babbb1a000a394a`: SHA-256 of sorted UTF-8 `label SPACE sha256(raw) SPACE sha256(host) LF` lines, 24 attempts.
- `vectors` complete raw/host set digest `39c26f9e3061115f0c7574cb8127f06b83d143c8a578388eb6f44f204882fe78`: SHA-256 of sorted UTF-8 `label SPACE sha256(raw) SPACE sha256(host) LF` lines, 18 attempts.

No material completeness, provenance or summary-accounting defect found. This evidence-only ACCEPT leaves Search-allocation attribution, explicit max-latency tradeoff disposition, latest-head correctness/CI/review and broader adoption obligations with root. No failed evidence is invalidated or waived by this review.
