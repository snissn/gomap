# Native source-pressure contract: bounded source review

Decision: extend the existing synchronous pre-producer drain, rather than add a publication retry, capacity, scheduler, or checkpoint under a captured operation. This is an implementation recommendation, not acceptance of an unbuilt repair or the text packet.

Reviewed identities (both clean when read): integration `d3ccef3c87cff2f71ead9dfeb20a94b9af153e72`; native-text-wave `1d43afa2ee17511b55b0738e2ca0bbc7516c911a` (parent constructor3e785, which still needs the separately accepted4798 registry repair). Read root/TreeDB AGENTS. No runtime/build/test/profile/checkout or source edits. The worker handoff and retained source-slot failure were read; no new leak or recovery claim is inferred.

## Cause and existing ownership

- `TreeDB/caching/cow_native_txn.go:19,44` calls the existing pressure helper before opening P1. Its sole predicate is ReservedBytes >= 3/4 MaxInFlightBytes; the existing nativePressureMu serializes/rechecks one explicit Checkpoint.
- `TreeDB/internal/memtable/cow_native_source.go:24` reserves a source cell through the original budget BEFORE NewCOWWriter. A native fork reuses that source cell. The original generation and captured source keep true references to it; only their final release decrements Sources. `native_domain_prepare.go:22` forks a pending root, otherwise requests a new native writer. This explains a real independent source ceiling without proving a leak.
- The text handoff records Sources32/32, Generations36/64, Reserved43,617,632/67,108,864, Total44,156,000/536,870,912 at final ANN Save. The byte-only helper cannot detect this state. Save replaces one named graph domain and therefore needs a new source cell even if most byte capacity remains free.
- `caching/cow_generation_preflight.go:96` already treats discrete source/generation headroom independently of bytes for raw successors. Native domains must use the same finite counters, not raw mutated-byte prediction.
- `caching/cow_checkpoint.go:29,107,128` provides the maintained full frontier/handoff/WAL-cleanup boundary and joins the captured accepted endpoint. Native source rollover uses the preadmitted original cell, not another source slot. Old cuts remain valid; they can legitimately retain source slots after physical handoff. A checkpoint is not a promise to admit the next operation.

## Minimal shared API and decision

Expose `PrepareNativeProducer() error` on the fixed `db.NativeSemanticBridge` (`db/native_semantic_state.go:215`) and forward through backend DB to the same caching owner. Its body reuses/refactors `checkpointNativeProducerPressure`, including the SAME nativePressureMu and explicit Checkpoint.

Predicate, before and after taking that mutex:

```
existing ReservedBytes >= (MaxInFlightBytes - MaxInFlightBytes/4)
OR Sources >= normalized MaxSources
OR Generations >= normalized MaxGenerations
```

Perform at most one checkpoint for this invocation, then return its actual error (or success). No loop until capacity appears, force pass, asynchronous wake, cap raise, second journal, or caller callback retry. Retain original final allocator refusal. Normalized limits are already positive. The source/generation checks use the exact finite ceiling; they introduce no arbitrary new watermark.

This is advisory maintenance, not a reservation/ticket, a proof that the caller will allocate a source, or a universal successful-admission guarantee. Concurrent producers may consume headroom after return. A multi-domain operation can need more than the remaining slots before the ceiling is reached; it still must fail privately through original admission. The frozen failure is a one-source Save at the exact ceiling, so no request-size predictor is needed to discriminate this repair. Do not advertise universal multi-domain headroom from this change. If future evidence requires predictive draining, use source-qualified newly needed cells like the existing raw successor predictor, not a fraction of MaxSources or a new hidden count budget.

Keep CaptureNativeSemanticState/CaptureNativeCut read-only and pressure-free. Keep WriteNativePublication and PrepareNativePublication free of pressure checkpoint/retry. They already hold a captured basis, private receipts or command authority; opening maintenance there is too late.

## Required lock placement and caller factoring

There is an existing placement hazard to repair in the same batch: `collections/native_existing.go:50` and `native_json_crud.go:36,119,288` take the HNSW mutation gate BEFORE NativeJSONManager.Begin -> backend Begin -> pressure checkpoint. Adding preflight to DDL/Save alone leaves that edge intact.

Preserve the existing checked backend/caching Begin for direct callers. Extract its opening-only allocation/InitOwnedCOWTxn body into a trusted `BeginPreparedNativeConditionalTxn` method on the SAME bridge; checked Begin runs PrepareNativeProducer then that body. Add a private NativeJSONManager beginPrepared using that body. This is only the lock-order adapter; it has no token, queue, reservation, publication authority or different admission. Public NativeJSONManager.Begin remains checked. Avoid a second checked Begin after taking a collection lock: races can make that second check checkpoint under the gate despite an earlier successful preflight.

Call the shared preparation after cheap nil/closed/input/profile rejection, but before collection locks or the operation capture:

| Producer | Placement / reuse |
|---|---|
| ordinary Insert, Update, Delete, conditional delete | outer facade preflights before lockNativeHNSWMutationIfNeeded; use private beginPrepared/insertPrepared below that gate. Original staged txn and callback execute once. NativeJSONManager public Insert/Begin remain checked. |
| scalar/vector/text index DDL | before lockVectorIndexMutation in nativeMutateIndexes, nativeCreateVectorIndex, nativeDropVectorIndex, nativeMutateTextIndex; mutateIndexFamilies remains lock-held and pressure-free. Keep CWAL text-DDL rejection before maintenance. |
| collection create/status | public/live create entry before nativeCreateMu/schemaMu and m.mu. Preserve4798 DB-scoped mutex repair. Recovery/apply paths must enter the existing pressure-free planner; never checkpoint from apply/replay while original write ownership may be held. |
| ANN SaveSnapshot / DeltaSave | saveNativeHNSW: preflight before mutation gate, UseMu, capture and persistence allocation. saveNativeHNSWWithMutationHeld remains pressure-free. |
| ANN Rebuild followed by Save | rebuildNativeOrdinaryHNSW needs the same outer preflight: it calls the lock-held Save helper directly. Do not add maintenance to that helper. |

Core files are caching/cow_native_txn.go and db/native_semantic_state.go; collection changes are thin entry adapters in native_json_txn.go, native_json_insert.go/native_existing.go, native_json_crud.go, native_json_public.go, native_hnsw.go/native_hnsw_schema.go and worker native_text_ddl.go. No change to domain representation, COW budget/source cell, read bridge, native publication/WAL owner or legacy collection planner is needed. The two-method core adapter preserves the existing checked Begin behavior; a boolean skip flag would be less explicit and easier to misuse.

Calling SyncNativeSemanticPrefix unconditionally from each operation is fewer bridge lines but forces full durability work without pressure; putting a conditional call in collections would duplicate private governor policy and still needs bridge stats. Background low-watermark scheduling is unnecessary for this exact count ceiling and repeats the rejected early-wake experiment's unrelated policy. Allocator-time checkpointing is unsafe under writer/captured/collection ownership. The selected shared pre-entry seam is the smallest coherent repair.

## Required discriminator and changed-risk controls

1. Keep the exact frozen V2 three Create/Drop concurrent Update workload and caps, then original final graph Save; require success and original held cut, current graph/search and fresh reopen semantics. Bind source identities and retain the original32/32 failure. A successful focused run is not full text adoption/performance acceptance.
2. Core exact-ceiling control: exhaust source cells with genuine native publications while bytes remain below the old watermark; preflight must invoke the real original checkpoint before opening a new transaction/capture. Do not use fake stats or change caps. Include a generation-ceiling variant where a drain is actually possible; preserve final refusal if no room can be reclaimed.
3. Held-old-cut and actual blocker control: if genuine old source edges pin capacity after one drain, original typed capacity refusal must leave logical sequence/LSN/WAL/catalog/graph unchanged and close private receipts. Releasing the blocker permits the same public operation; full close returns zero. Do not turn an advisory counter check into unconditional capacity rejection: forks may reuse existing source cells.
4. Lock/callback control: pause the real checkpoint frontier/drain, start same/sibling collection CRUD and DDL/Save, then release. Prove no collection mutation/schema/manager/Use gate is held during preflight and no callback is replayed. Checked public Begin and prepared facade Begin must exercise the same opening/admission implementation. Include Rebuild's direct lock-held Save path.
5. Preserve command-WAL ACK/replay and installed-error custody controls. Preflight checkpoint errors return before application callback/staging/assignment; failures after successful preflight retain existing no-effect versus assigned/installed error classification. Close racing preflight uses existing checkpoint/bridge shutdown errors and cleanup.

## Reviewed source binding

Integration blobs: caching/cow_native_txn.go `6f738a244e7d152e234421cc5f5343f9597c482e`; db/native_semantic_state.go `da129b4be8500bb63a6f0dbfb43af813c956d112`; collections/native_json_txn.go `f2db09fee18af50ec1b3ee36c6574ee7ceb42bde`; native_existing.go `ea10ddf81fa494a92ee7e5444dcf289b97f5e95d`; native_json_crud.go `3510c64a80e11f014f788ed9dc189309d2c54f60`; native_hnsw.go `ebd4e89e9952e14222ba398d59ea9aba1abe9aff`; native_domain_prepare.go `f14ded52cf94332c8b947e790300d0bcebf52f1e`; internal/memtable/cow_native_source.go `76bafbe2c0e7247dcd9715588c8a384c75362bb7`; caching/cow_checkpoint.go `78c7a8f9ba780e9a89ed86bf1be4450090fd9036`.

Text-packet blobs: native_text_ddl.go `797f89488e08471dc8f13111eab6d04b9a49be23`; native_index_ddl.go `861cd0ba8d2c04f43a44ca2ecbc3bec0047c85f1`; native_json_public.go `dc94aa71816c893dff64d192ba56b20cc4be8791`.

## Mutable source-pressure-wave callsite and retirement addendum

Read the first nine-production-file delta on base d3ccef3, without runtime. Ordinary public Insert/InsertBatch/validated BSON/Update/Delete/BSONSet and public template/typed/prepared/source-import entrypoints select their native role before legacy schema/admission locks. Scalar/vector DDL and Save/Rebuild new outer preflight placements precede mutation/use locks; public create precedes manager locking. Recovery native prepare and captured/read-only paths remain pressure-free. Constructor4798 and textDDL1d43 are not yet projected and are not accepted as implemented by this pass.

Two actionable entry/lifetime gaps were reported to root:

1. `api.go:12077` NativewireInsertBatchNoResultIDs takes schema read/coverage admission before its generic executor reaches nativeInsertBatch for trustedValidBSON=false. The new preflight therefore runs under schemaMu.RLock. Select native dispatch at that outer entry before legacy locks; preserve the existing native eligibility/result contract.
2. `native_typed_upsert_group.go:74,179` captures request reads and retains independent staging receipts through the queue, then executeNative calls checked Begin. No coordinator mutex is held during execute, but the pressure checkpoint runs after those captured-prefix pins exist. Preflight before the request Capture and use opening-only beginPrepared during execution. Keep exact original queue/OCC/publisher; no retry.

The first repair runtime is root-owned: both WAL profiles passed, NoWAL failed final Save at source32. Source explains a missing maintenance-completion boundary, not necessarily retained application pins: cowReadCut.releaseSemanticState (`cow_semantic_cleanup.go:39`) only enqueues a detached EngineVersion record. Native directories/root/source release runs later in nativeEngineVersion.FinishSemanticCleanup (`native_engine_state.go:99`) on the sole flush worker. Checkpoint WaitAccepted joins original accepted-custody release, not this separate semantic queue. Normal successful flush consumes frontier (frontier=nil); completeCOWHandoff/h.release release cut edges and enqueue cleanup before Checkpoint returns. The deferred frontier release is not the sole normal-success explanation. No new runtime or leak claim by this adviser.

Selected minimal join design for root implementation: existing semantic queue gets fixed enqueued/completed counters plus a cond under semanticMu. After the one pressure Checkpoint returns, capture a fixed enqueued target (therefore after its deferred releases), wake the SAME flush worker, and join through that target only. Increment completed only after clearing record aliases, actual completion.Complete refunds, and cleanup scope departure. Current semanticRunning=false precedes refund and cannot certify reclaim. FIFO worker processing of failed original work advances processed completion but returns its retained original failure and preserves parked custody; never retries destruction. Broadcast progress/stop and refuse a stopped/no-worker target that cannot complete. Do not wait for all cuts or later enqueues, and never call drainSemanticCleanup concurrently. Apply the existing ownedCloseGuard.CheckClose reentry check before pressure mutex/checkpoint/join: NotifyError or Finish callbacks on either protected lane must refuse rather than wait for their own completion. Other goroutines remain allowed. The new fixed metadata belongs to the charged cowCache; no replacement task, queue, journal or ownership lane.

This addendum identifies the remaining bounded changes; it does not accept any subsequently modified/frozen source or its tests.
