# d040 maximum-latency and Search-object disposition consultation

**Source-bound explanation supports a narrowed coordinator tradeoff decision; no new correctness blocker or demonstrated safely removable work was found in this bounded pass. This is not independent performance promotion.** No workload, test, build, Go tool, new profile, source edit or delegation was executed. The existing compact offline intervals, CPU text summaries and immutable d040 source were read. Only this artifact was written.

Diagnostic source `d0407930ef138915306e1a89c2c80522174c50ad`, recorded ELF SHA256 `52bc3afbc46088218e0e8f8d0b59598b434e69d343d9c861d52cb5f1553a9455`, Go1.26.0/GOMAXPROCS4, actual relaxed1 public10,000-operation/4096B held-view workload. The existing receipt is exit0/valid_causal_diagnostic with10,000 attempted/completed, failed=false. CPU/trace flags perturb timing: this single run explains a mechanism and does not replace any retained qualification row. The first slow trace client interval and the diagnostic report's global maximum are different observations.

## Exact timing evidence

Times are milliseconds relative to the existing trace origin. Independently checked the compact interval exports:

| Observation | Interval / duration |
|---|---|
| First slow client G114 FD.Read wait |291.017792→423.859840 =132.842048ms |
| Matching server G47 coalescer wait |291.045312→423.808576 =132.763264ms |
| Producer G84 backend durable-prefix WaitThrough |346.849856→410.180352 =63.330496ms |
| Producer's semantic-frontier Cond waits |193 intervals, first410.940224, last end423.134976; sum1.028993ms |

Before WaitThrough, producer G84 performs genuine checkpoint operations: CWAL segment rotation/fsync (7.678400ms), created-log namespace sync (5.369152ms), value-log creation/namespace proofs and lane rotations, manifest persistence and compatibility-view/namespace stabilization. After WaitThrough there is a further0.673152ms journal-sync interval at410.249856→410.923008. These call stacks identify work on the actual producer; this is stronger than aggregate fsync CPU attribution. The checkpoint's captured recovery frontier, dependency/index/meta order and original custody remain the durability authority (`cow_checkpoint.go:77–139`, `db.go:4886–4965`). WaitThrough actively requests the coordinator's durable prefix; it is not an unexplained scheduling timer (`rootpublication/coordinator.go:538`). No source/evidence here proves these distinct file/namespace operations are redundant or permits suppressing their durability obligations.

The join's first-to-last wait envelope is12.194752ms, **not12.194752ms continuously blocked on Cond**. The193 waits sum only1.028993ms; worker completion, waking, producer scheduling/lock reacquisition and other execution interleave. The exported producer states over the approximate290.7–423.3ms window sum53.777405ms Syscall,64.513921ms Waiting,11.191103ms Runnable and3.037827ms Running; these are goroutine states, not CPU-stack attribution for every running instant. A runtime.Stack sample cannot be assigned to the full join envelope from these exports.

The diagnostic report's maximum is132.887845ms. The retained qualification has candidate maxima125.136607–167.414703ms; the largest167.414703ms durable8 attempt has endpoint checkpoint correlation, **not its own traced request attribution**. This one relaxed1 trace establishes the maintenance/retirement mechanism for the matched132.842048ms client stall, not exact causal decomposition of every retained maximum.

## Cleanup and close guard

`PrepareNativeProducer` checks finite byte/source/generation pressure before captures or consumer locks, serializes one original checkpoint and then joins the fixed semantic frontier (`cow_native_txn.go:44–85`). Returning after the physical checkpoint alone previously failed the real NoWAL source32/32 workload because original source slots had not yet actually retired. Removing this join or letting capacity checks assume promised refunds would reopen that correctness defect.

The sole existing cleanup worker removes one original record, enters the existing cleanup callback guard, calls Finish, preserves/poisons original failure custody and synchronously notifies errors, completes the independent refund receipt, leaves cleanup scope, then advances semanticCompleted and broadcasts (`cow_semantic_cleanup.go:84–161`). The join snapshots semanticEnqueued under semanticMu and waits only through that fixed target; parked original errors and worker stop wake/terminate it (`:167–185`). Old retained cuts and later producers are not part of that target. These completion/notification boundaries are the reviewed protocol, with **no demonstrated redundant safe omission** in this evidence.

`OwnedCallbackCloseGuard.EnterCleanup` uses runtime.Stack/currentGoroutineID to mark the serialized cleanup lane, and CheckClose rejects callback reentry before a public/cache/backend Close or pressure join can wait on its own worker (`owned_finish_callback_scope_v6.go:18–61`, `db.go:3758–3780`). Protecting actual destruction and synchronous NotifyError, preserving failed original custody, and completing refunds before advancing the frontier are correctness requirements. The exact implementation is not asserted theoretically minimal.

The CPU summary has2.07s sampled CPU over4.02s diagnostic wall time. It attributes0.23s cumulative to drainSemanticCleanup and0.22s cumulative to EnterCleanup/currentGoroutineID/runtime.Stack across the **whole process**, including many records and non-request maintenance. That0.22s is not a132ms per-request cost,12ms join cost, or evidence that this guard caused the fsync/WaitThrough interval. It is a real aggregate optimization lead. Coalescing guard scopes or completion notifications would require preserving per-record failure/reentry/refund ordering and fixed-frontier progress; waiting merely for queue-empty could starve behind later work. No such equivalent coalescing is demonstrated, measured or selected here. Dropping the guard, moving callbacks outside protection or early-advancing completion is not a safe simplification.

## Search19 versus15 objects

The fresh retained d040 vector Search samples consistently report19 allocations/op and12,760B/op versus baseline15 allocations/op and approximately27,143B/op. Median paired time/bytes/objects ratios are0.3270915884/0.4701027889/1.2666666667. This is a measured26.667% object-count cost despite better time/bytes, not waived by old950 acceptance or by the primary targets.

The prior exact950/07d allocation profiles localized the avoidable+2 objects to the indirect rerank dispatch/function-entry and trace allocation; the reviewed direct dispatch repair removed that demonstrated regression, and the fresh three pairs independently restore19. Those older diagnostic profiles are not a fresh d040 allocation profile and do not attribute the exact four-object delta against baseline by themselves.

Current Search captures its original native read, admits per-query workspace, authenticates full schema/incarnation/domain/document generation, returns owned IDs/documents and captures/authenticates the post-search cut (`vector_index.go:4135–4215`, `native_hnsw.go:432`). Attachment reuses ranked backing and the same captured read (`vector_index.go:4930`); it does not introduce another document read capture. The native capture/receipt objects and copied result bytes represent independent lifetimes and finite admission. Removing post-authentication, returning borrowed IDs/documents after releasing capture, borrowing a retained global scratch pool or dropping admission receipts would weaken those contracts. No remaining compiler-escape/duplicate capture or allocation shown by the supplied evidence is an obvious safe omission comparable to the repaired+2. This does **not** prove19 is the irreducible minimum; further allocation coalescing remains unproven and outside this bounded disposition.

## Recommendation and limits

The coordinator can make an explicit **narrowed acceptance of the measured d040 maximum/Close and19-versus15 owned-object tradeoffs**, with all retained samples and this causal limit disclosed. Source supports correctness-required synchronous recovery-frontier/retirement work rather than an unexplained120ms timer or a removable per-request0.22s Stack call. No new SLO, tolerance, retry, gate relaxation, scheduler, pool or guard is justified by this consultation. The unsuccessful early-wake experiment remains rejected and is not a repair in this source. Primary numeric acceptance, correctness/CI and wider consumers remain separate obligations. This artifact neither accepts the largest167ms as precisely traced nor makes the root's promotion decision.

## Immutable bindings

Reviewed d040 Git blobs:

| Path | Blob |
|---|---|
| TreeDB/caching/cow_native_txn.go | e37bff0102a96fba66510e09aa2baa3d2e781e5f |
| TreeDB/caching/cow_checkpoint.go | 78c7a8f9ba780e9a89ed86bf1be4450090fd9036 |
| TreeDB/caching/cow_semantic_cleanup.go | f42438bf7d630ef7655777c6ecbfc72398b31358 |
| TreeDB/db/owned_finish_callback_scope_v6.go | e62637d59e8f6c3120b7244335224cc1a67932af |
| TreeDB/db/db.go | cfb3920cbfbbadc128e7bab0de50dbd6f60986e5 |
| TreeDB/collections/vector_index.go | 6be57a48b9d8cad61924db4961c95e22494d626d |

SHA256 of consulted existing diagnostic artifacts (raw CPU/trace binary payloads were not rehashed):

| Artifact | SHA256 |
|---|---|
| plan.json | 46215c484ab8eb30ae10fba33e913a6e45b3660b6a3a49aa160b81090a31ff8a |
| receipt.json | 58bd1af8c6a31a924e9883d256648c92811ba4a5e3895ac3f4d9c7b5fe55f0d9 |
| raw.log | 7913ec0bcc6dc6e14b815344eb950504a35ced31748b7e3b715305a0c2011e66 |
| cpu-top.txt | 67983ec3b9806b1ce22ee125679ac634a5e6374f6a89c482e95c2eb15c3ab2e7 |
| cpu-cumulative.txt | e1c2fec64636c614d7ebe2fb8708d6419a162d6feb9a502d915d2d4e751d68b3 |
| trace-parser-receipt.json | a1ba5a3f55fa06e1f75756ea233abc28d9c9f59956ed93e69a85fc94dd1fb9be |
| pressure-state-intervals.json | 9621eedfd4aa29ffdd2dcfe8695371bb95b9cc380fd1460bf5bd6fb3f10de832 |
| first-pressure-cleanup-join-intervals.json | 8f5e72e7b190758ec1cc527e9d89546925b52ad52bc5c42a310ad7f5fd3a314f |
| first-pressure-producer-all-intervals.json | bed36f566e6ba64e4ec087b3a9ff8ff8e17dc6862a99add1c25da14bdf6a7b4f |
