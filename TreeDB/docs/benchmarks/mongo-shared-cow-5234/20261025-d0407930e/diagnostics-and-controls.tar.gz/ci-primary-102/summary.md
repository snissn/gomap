## Public PRIMARY replacement cost

- Verdict: FAIL
- Exact base/head: `f906b8a2aa1279ed6b6627028cba71d491db04c3` / `1020677c783240162746c2d5032feeefcc8637ef`
- Eight alternating AB/BA pairs; 128 durable public replacements per sample.
- Median paired time delta: -2.757% (limit +5%).
- Raw gates: `{"allocations": true, "bytes": false, "candidate_primary_activation": true, "timing": true}`; measurement pass: False; quiet: True.
- Timing acceptance: `PASS`; bytes acceptance: `FAIL`; bound runtime/input equivalent: False.
- Scope: this public replacement workload; not final graph qualification.
