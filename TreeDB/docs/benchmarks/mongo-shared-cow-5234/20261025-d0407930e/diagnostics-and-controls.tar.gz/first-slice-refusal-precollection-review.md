# First-slice refusal tests and precollection review

Source-only review on 2026-10-25. Candidate HEAD `e80600b184b71c5e37cc2caaf220db277f868931`; reviewed the staged two-test delta, existing fixture cleanup, retained owning-package failures, landed measurement contract, manifest and all 18 vector-plan rows. No runtime, builds, tests, binary hashing or source changes performed.

## Disposition

**ACCEPT the exact two-test repair.** **Precollection plan is coherent, but the current manifest needs its CI provenance entry corrected and the promised final source/binary rebind before any sample.** No performance or final qualification verdict is given.

Reviewed test blobs (HEAD -> staged/worktree):

- `TreeDB/collections/native_hnsw_public_test.go`: `74aa80ceb47252904868a195a4f2139b9fa724f6` -> `7ccf0b5c1cf95d3b3d0fc231ca100f5d51693e18`.
- `TreeDB/collections/native_hnsw_schema_ddl_review_test.go`: `cc3694bbc4c09f6d2670fcee49c36fdff2af2cfb` -> `605e0fb5fa935835ca7eee1fcc18abc04a22e1b6`.

The original log contains exactly the two reported failures: declared-create reserved bytes/leases decreased by 8,576/4, and schema-DDL by 12,864/6. The repair permits old physical custody refunds while still forbidding increased reserved bytes or leases over each of three attempts. It retains the finite budget and capacity error, adds explicit WAL-next-LSN stability, and checks logical sequence, schema identity/full metadata, collection incarnation and document generation. Declared-create additionally checks catalog absence, catalog cardinalities and next incarnation. Physical engine-state pointer identity is correctly removed: pressure checkpoint rebase may change that pointer without changing logical contents. Schema-DDL still preserves the exact runtime schema/lease/charge and deep-equal graph. Both fixtures retain eventual success and full Close zero; unchanged query/capture/Build-scratch controls retain exact receipt equality. The test proves net no-added-debt, not absence of every transient allocation or a particular partial-domain failure stage.

## Provenance and fixed plan

Reviewed manifest SHA-256 `147ec020a5bbf05f719a75793111845c08f38ef30e7f1d43d954755e9933b9a6`; vector-plan SHA-256 `3bef93683d1a2bd23b3e4a2b93739946e7c9dffbf5f732e29d71200e4cc58c69`. These identify the provisional e806 plan, which must remain superseded/retained when final test-only-head records are written.

Independently checked all seven manifest harness blobs against candidate e806 and landed baseline `eb9a4ab4a8e7c2c4ff34b53552b2cdde9a9c7144`: all match their recorded identities. Baseline diff against f906 comprises harness/tests/docs and CI inventory, with no product runtime changes. The local `main` ref is stale and does not contain the harness; landed provenance must bind eb9, not rely on that local ref.

**One factual manifest correction:** `reviewed_pressure_blobs[".github/ci/ci_impact.json"].projected` currently claims `467394c94fd5662bf26490f7ca1416432bcc18a6` (6647), whereas e806 actually has `d5f4231cc8a9dfd62c9c0e3bbfbebd4d1669883c`. All other 18 listed pressure paths do match 6647 exactly. Separate the CI inventory/hash-only refresh from runtime identity; the currently staged CI change is solely `discovery_source_sha256`, old `810c1b...` -> new `a7c8b0...`, with the 17/63 inventory unchanged. This is provenance bookkeeping, not product drift, but should not remain an equality claim.

The fixed primary/resource plan is 64/24 fresh processes with alternating route order, typed infrastructure unavailability, all failed/null receipts retained and no retries. The vector plan has exactly 18 unique rows: 3 alternating pairs x 3 benchmarks x 2 routes, anchored selectors, count=1, 10 Build/Save/Load operations, 10 Save/reopen/Load operations and 10,000 Search operations. All are currently not_run with null results; operator commands invoke the unchanged landed Go benchmarks and add no replacement parser/test harness. The landed specification supplies their timing and validity boundaries. Commands/receipts must preserve actual environment, process status, binary SHA, raw output and calibration separately; successful process exit alone is not validated evidence.

Before first sample: freeze the final test-only head and actual binary digest, replace candidate paths/identities in both plans, record owning-package failures plus focused/race repair disposition, and record the worker runtime-quiet acknowledgment and host process inventory. Shared-host fallback is explicitly disclosed; contamination remains retained/inconclusive. This review does not waive exact-head CI, broader adoption, performance gates or unexplained material resource regressions, and does not relabel earlier developmental evidence as landed qualification.
