# Native source pressure review — 6647

**ACCEPT**, bounded to immutable `6647cb5d37967b2b7daea3340d947168987a38c0` against `d3ccef3c87cff2f71ead9dfeb20a94b9af153e72` in `source-pressure-wave`. The worktree was clean when read. No material correctness, ownership, lock-order, or maintainability defect found in this exact delta. This is independent source review, not a runtime or performance verdict.

## Scope and invariants checked

Read the complete production delta and the changed-risk fixtures across the 19 changed paths below; followed the existing flush worker, checkpoint return/release, cleanup guard, native transaction opening, facade dispatch, HNSW mutation gate and typed group call sites as needed.

- `caching/cow_native_txn.go:49`: pressure retains the existing byte watermark and adds the actual discrete source/generation ceilings. The outer preparation serializes at most one existing checkpoint, rechecks after serialization, and then joins transferred cleanup. It grants no capacity, retries no transaction/callback, and leaves immutable admission responsible for old pinned cuts or concurrent producers. The cleanup/publication callback guard runs before blocking on the pressure mutex or checkpoint.
- `caching/cow_semantic_cleanup.go:15,91,167`: enqueue/completion counters are protected by the original semantic mutex. The join snapshots a fixed FIFO target including already-running work; no second destructor or queue was introduced. Success requires the original completion receipt's actual refund and `LeaveCleanup` to precede the completed increment/broadcast (`:149-160`). Later enqueueing cannot extend that target. The condition variable is initialized by the sole production cache constructor (`cow_cut.go:296`) and the added fixed fields are covered by the existing `sizeof(cowCache)` admission charge (`:250`).
- Failed cleanup retains the same original parked record/work/error and charge. The join returns that original failure instead of retrying or manufacturing a successful reclaim. Its failure return may precede unrelated later cleanup; that is a truthful error return, not a successful completion promise. The worker remains responsible for destruction and termination. Terminal worker state broadcasts to waiters; successful join does not wait for retained cuts to disappear. Existing Close/cleanup callback reentry guards preserve the original ownership and avoid joining one's own worker.
- The public wrappers in `native_existing.go`, `native_json_crud.go`, `native_hnsw.go`, `native_hnsw_schema.go`, and `native_json_public.go` prepare before their own mutation/manager gates and captures, then use the shared opening-only adapter. `api.go:12084` dispatches nativewire before the legacy schema/admission locks; its preexisting trusted-BSON rejection remains explicit. `native_typed_upsert_group.go:73` prepares before retaining request captures, and grouped execution uses the original planner through `beginPrepared` rather than checkpointing under those pins. No second publication/WAL authority was added.
- The bridge additions forward to the same backend; `BeginPreparedNativeConditionalTxn` is an opening-only contract, not a capacity reservation. Reads do not gain pressure side effects. Creation's explicit apply/replay branch does not invoke the new preflight.

The fixtures read cover discrete ceilings below byte pressure, pinned finite refusal, original failed custody and reentry, fixed-frontier exclusion of later cleanup, actual public save saturation in three profiles, and five paused actual checkpoint/gate controls. Parent-reported results: final public family PASS 0.868s; core changed-risk family PASS 1.083s; paused public gate controls PASS 0.926s. I did not execute or independently certify these runs. Earlier red/failing attempts remain evidence, not replacement successes.

## Limits / integration obligations

This verdict excludes future projection of constructor `3e785`/`4798`, text `1d43`, and stats `3fd64`, which were absent here. Any new outer create/text adapter must preserve preparation before every schema/manager/mutation gate or retained capture; moving checked Begin underneath those gates would reintroduce the reviewed deadlock/retention hazard. Finite refusal under genuinely retained old-cut capacity remains lawful. No extra force-pass, capacity raise, automatic scheduling policy, ACK change, or performance claim is accepted by this source review. Root owns final race/package and integration checks.

## Exact changed blobs

```text
100644 blob 467394c94fd5662bf26490f7ca1416432bcc18a6	.github/ci/ci_impact.json
100644 blob 18472a678e74d9e40b6eb24a82408ded1934bd3b	TreeDB/caching/cow_cut.go
100644 blob e37bff0102a96fba66510e09aa2baa3d2e781e5f	TreeDB/caching/cow_native_txn.go
100644 blob d0c18066cc04bd7ee99a74abaf6408b411e777e0	TreeDB/caching/cow_native_txn_test.go
100644 blob f42438bf7d630ef7655777c6ecbfc72398b31358	TreeDB/caching/cow_semantic_cleanup.go
100644 blob c5826f15f608c04d1a1969003a8a7eb826764e62	TreeDB/caching/cow_semantic_cleanup_test.go
100644 blob ef505af995a5ca6725c7ce71f172f5da0b1be366	TreeDB/collections/api.go
100644 blob a42155db7b89f2ff76f794c4745185228006789a	TreeDB/collections/native_existing.go
100644 blob 025e158cb5c098ce717c41984dd15eaae65666ac	TreeDB/collections/native_hnsw.go
100644 blob 21688d3fd612f89c823d1b897f00d50470690b28	TreeDB/collections/native_hnsw_schema.go
100644 blob 182dd2461239a2a6d6cd76953d28412161d3d6dd	TreeDB/collections/native_json_crud.go
100644 blob 0ba4f2eb63f11240b5e2eb0ea81aee66686a1e56	TreeDB/collections/native_json_insert.go
100644 blob 8a1486faa7b0d7e607faf63aac644ac84ce94915	TreeDB/collections/native_json_public.go
100644 blob d327d272a9e6515cb63448a4533815f57ba3c942	TreeDB/collections/native_json_txn.go
100644 blob a46cc8e405b23f23cbbc77b45b6626b5a64222ef	TreeDB/collections/native_source_pressure_public_test.go
100644 blob 47967c06b5a0899f096c8502680fd38ddc00f7f2	TreeDB/collections/native_typed_upsert_group.go
100644 blob b4926e8118a96221ae44077d491cf9637188609d	TreeDB/db/native_semantic_state.go
100644 blob ce5275d9f271c9b6ff65f4573c390c8b5d539864	TreeDB/docs/spec/collections-write-domain.md
100644 blob b00063d8d50be5f2cd189e8b266526702610b038	TreeDB/native_collection_pressure_test.go
```
