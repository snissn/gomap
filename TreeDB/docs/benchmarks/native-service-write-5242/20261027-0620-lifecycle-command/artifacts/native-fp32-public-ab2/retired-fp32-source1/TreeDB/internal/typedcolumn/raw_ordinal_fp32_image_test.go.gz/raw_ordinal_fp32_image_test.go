package typedcolumn

import (
	"bytes"
	"errors"
	"fmt"
	"math"
	"reflect"
	"runtime"
	"strings"
	"testing"
)

// This is the ordinary publisher's two-column layout: internal DeltaVarint
// ordinals, raw fixed-dimension FP32 values, and the original default compression.
// Float32 is the existing borrowed carrier; its vector interpretation comes
// from the advertised definition and checked Rows*FixedWidthElements shape.
func directFP32TestInput(rows, dims int, compressed bool) (Options, RawOrdinalColumnValues, ColumnPartImageOptions, Batch) {
	primaryCompression, sectionCompression := CompressionNone, CompressionNone
	if compressed {
		primaryCompression, sectionCompression = CompressionLZ4, CompressionZSTD
	}
	opts := Options{
		SchemaVersion: 23, SchemaMode: ColumnSchemaFixed,
		Columns: []ColumnDefinition{
			{Name: "__treedb_primary_id", Type: ColumnTypeInt64, Encoding: EncodingDeltaVarint, Compression: primaryCompression, CompressionSet: true, StatsDisabled: true},
			{Name: "embedding", Type: ColumnTypeFloat32Vector, Encoding: EncodingRawFloat32Vector, CompressionSet: true, FixedWidthElements: dims},
		},
		LogicalPrimaryKey: LogicalPrimaryKey{Columns: []string{"__treedb_primary_id"}},
		SortKey:           SortKey{Columns: []SortKeyColumn{{Column: "__treedb_primary_id"}}},
		PartPolicy:        ColumnPartPolicy{RowsPerGranule: DefaultRowsPerGranule},
	}
	values := RawOrdinalColumnValues{Rows: rows, Float32: make([]float32, rows*dims)}
	ids := make([]int64, rows)
	for row := 0; row < rows; row++ {
		ids[row] = int64(row)
		for dim := 0; dim < dims; dim++ {
			values.Float32[row*dims+dim] = float32((row+dim)%17) / 17
		}
	}
	if len(values.Float32) != 0 {
		values.Float32[0] = math.Float32frombits(1 << 31)
	}
	if len(values.Float32) > 1 {
		values.Float32[1] = math.Float32frombits(1)
	}
	imageOpts := ColumnPartImageOptions{
		SectionCompression: sectionCompression,
		Dictionaries:       map[string]map[string]int64{"__treedb_adapter_metadata": {strings.Repeat("embedding:float32_vector;", 16): 0}},
		LayoutLogicalTypes: map[string]string{"embedding": "float32_vector"},
	}
	batch := Batch{Rows: rows, Columns: map[string][]int64{"__treedb_primary_id": ids}, Float32Vectors: map[string][]float32{"embedding": values.Float32}}
	return opts, values, imageOpts, batch
}

func TestRawOrdinalFP32DefaultCompressedGenericParity(t *testing.T) {
	for _, tc := range []struct {
		rows, dims int
		compressed bool
	}{{1, 2, true}, {4096, 2, true}, {DefaultRowsPerGranule + 1, 3, true}, {33, 2, false}} {
		t.Run(fmt.Sprintf("rows%d/dims%d/compressed%t", tc.rows, tc.dims, tc.compressed), func(t *testing.T) {
			opts, values, imageOpts, batch := directFP32TestInput(tc.rows, tc.dims, tc.compressed)
			// Each construction borrows its own real operation-local codec. Neither
			// constructor may replace it with a global pool or create a new owner.
			var referenceCodec, directCodec BuildCodec
			defer referenceCodec.Close()
			defer directCodec.Close()
			opts.BuildCodec, imageOpts.BuildCodec = &referenceCodec, &referenceCodec
			part, err := BuildColumnPart(91, opts, batch)
			if err != nil {
				t.Fatalf("maintained generic fixture: %v", err)
			}
			want, err := BuildColumnPartImage(part, imageOpts)
			if err != nil {
				t.Fatalf("maintained generic image: %v", err)
			}
			// The reference must advertise the original codecs, not a raw-ordinal
			// or compression-off substitute manufactured for the fast path.
			if part.Columns["__treedb_primary_id"].Definition.Encoding != EncodingDeltaVarint || part.Columns["embedding"].Definition.FixedWidthElements != tc.dims {
				t.Fatal("reference fixture changed ordinal/vector representation")
			}
			opts.BuildCodec, imageOpts.BuildCodec = &directCodec, &directCodec
			shape := RawOrdinalColumnShape{Rows: tc.rows, Type: ColumnTypeFloat32Vector, ValueCount: uint64(len(values.Float32))}
			plan, err := PlanRawOrdinalColumnPartImageShape(opts, shape, imageOpts)
			if err != nil {
				t.Fatalf("direct constructor cannot pre-admit actual ordinary FP32 layout: %v", err)
			}
			actualPlan, err := PlanRawOrdinalColumnPartImage(opts, values, imageOpts)
			if err != nil || actualPlan != plan {
				t.Fatalf("shape/actual plan mismatch: shape=%+v actual=%+v err=%v", plan, actualPlan, err)
			}
			got, err := BuildRawOrdinalColumnPartImage(91, opts, values, imageOpts)
			if err != nil {
				t.Fatalf("pre-admitted direct construction: %v", err)
			}
			if got.Charge != plan || plan.ConstructorBytes == 0 || plan.RetainedBytes > plan.ConstructorBytes || len(got.Image.Bytes) > plan.ImageBytesUpperBound {
				t.Fatalf("inconsistent complete charge/image bound: plan=%+v charge=%+v image=%d", plan, got.Charge, len(got.Image.Bytes))
			}
			if !bytes.Equal(got.Image.Bytes, want.Bytes) || !reflect.DeepEqual(got.Image.Sections, want.Sections) {
				t.Fatalf("existing compressed representation changed: direct=%d generic=%d", len(got.Image.Bytes), len(want.Bytes))
			}
			wantAccounting := part.ByteAccountingFromImage(want)
			// Separate constructions observe different elapsed compression times.
			// Preserve exact equality for every byte, codec and count field.
			for _, accounting := range []*ColumnPartByteAccounting{&got.Accounting, &wantAccounting} {
				for i := range accounting.ColumnsDetail {
					accounting.ColumnsDetail[i].CompressionNanos = 0
				}
				for i := range accounting.CompressionDetail {
					accounting.CompressionDetail[i].CompressionNanos = 0
				}
			}
			if !reflect.DeepEqual(got.Accounting, wantAccounting) {
				t.Fatal("image accounting differs from maintained generic publisher")
			}
			if _, err = CertifyColumnPartLayoutContractFromImage(got.Image); err != nil {
				t.Fatalf("writer certification: %v", err)
			}
			decoded, err := ColumnPartFromImage(got.Image)
			if err != nil {
				t.Fatalf("reopened maintained decoder: %v", err)
			}
			wantDecoded, err := ColumnPartFromImage(want)
			if err != nil {
				t.Fatal(err)
			}
			if !reflect.DeepEqual(decoded.Descriptor, wantDecoded.Descriptor) || !reflect.DeepEqual(decoded.Columns, wantDecoded.Columns) || !reflect.DeepEqual(decoded.ColumnStats, wantDecoded.ColumnStats) || !reflect.DeepEqual(decoded.PruningMetadata, wantDecoded.PruningMetadata) {
				t.Fatal("reopened descriptor/payload/stats/pruning differ")
			}
			if tc.compressed && directCodec.encoder == nil {
				t.Fatal("borrowed operation-local image codec was not used")
			}
		})
	}
}

func TestRawOrdinalFP32UnsupportedAndInvalidShapes(t *testing.T) {
	for _, tc := range []struct {
		name   string
		change func(*Options, *RawOrdinalColumnValues, *ColumnPartImageOptions)
	}{
		{"wrong value codec", func(o *Options, _ *RawOrdinalColumnValues, _ *ColumnPartImageOptions) {
			o.Columns[1].Encoding = EncodingRawFloat32
		}},
		{"compressed vector", func(o *Options, _ *RawOrdinalColumnValues, _ *ColumnPartImageOptions) {
			o.Columns[1].Compression = CompressionLZ4
		}},
		{"adaptive granules", func(o *Options, _ *RawOrdinalColumnValues, _ *ColumnPartImageOptions) {
			o.PartPolicy.AdaptiveMarkSizing.Enabled = true
		}},
		{"wrong vector width", func(o *Options, _ *RawOrdinalColumnValues, _ *ColumnPartImageOptions) {
			o.Columns[1].FixedWidthElements = 0
		}},
		{"short source", func(_ *Options, v *RawOrdinalColumnValues, _ *ColumnPartImageOptions) {
			v.Float32 = v.Float32[:len(v.Float32)-1]
		}},
		{"extra source owner", func(_ *Options, v *RawOrdinalColumnValues, _ *ColumnPartImageOptions) { v.Int64 = []int64{1} }},
	} {
		t.Run(tc.name, func(t *testing.T) {
			opts, values, imageOpts, _ := directFP32TestInput(8, 2, true)
			var codec BuildCodec
			defer codec.Close()
			opts.BuildCodec, imageOpts.BuildCodec = &codec, &codec
			tc.change(&opts, &values, &imageOpts)
			if _, err := PlanRawOrdinalColumnPartImage(opts, values, imageOpts); err == nil {
				t.Fatal("invalid/unsupported shape admitted")
			}
			if _, err := BuildRawOrdinalColumnPartImage(19, opts, values, imageOpts); err == nil {
				t.Fatal("invalid/unsupported shape constructed")
			}
			if codec.encoder != nil {
				t.Fatal("rejected preflight allocated the borrowed codec")
			}
		})
	}
	opts, _, imageOpts, _ := directFP32TestInput(1, 2, true)
	if _, err := PlanRawOrdinalColumnPartImageShape(opts, RawOrdinalColumnShape{Rows: 1, Type: ColumnTypeFloat32Vector, ValueCount: math.MaxUint64}, imageOpts); err == nil {
		t.Fatal("overflow/mismatched vector shape admitted")
	}
	// A foreign sort key remains an explicit unsupported layout, not a covert
	// change of requested ordering or a second constructor after partial work.
	opts.SortKey.Columns = []SortKeyColumn{{Column: "embedding"}}
	if _, err := PlanRawOrdinalColumnPartImageShape(opts, RawOrdinalColumnShape{Rows: 1, Type: ColumnTypeFloat32Vector, ValueCount: 2}, imageOpts); !errors.Is(err, ErrRawOrdinalImageUnsupported) {
		t.Fatalf("unsupported selection lost: %v", err)
	}
}

func TestRawOrdinalFP32ColdCodecAllocationCohorts(t *testing.T) {
	for _, rows := range []int{4096, DefaultRowsPerGranule + 1} {
		t.Run(fmt.Sprintf("rows%d", rows), func(t *testing.T) {
			opts, values, imageOpts, _ := directFP32TestInput(rows, 2, true)
			// Warm only shared certification/CRC/runtime state; the measured operation
			// gets an entirely fresh codec, whose construction is covered separately by
			// the original workspace promise rather than hidden in the image plan.
			var warmCodec BuildCodec
			opts.BuildCodec, imageOpts.BuildCodec = &warmCodec, &warmCodec
			if _, err := BuildRawOrdinalColumnPartImage(90, opts, values, imageOpts); err != nil {
				t.Fatal(err)
			}
			if err := warmCodec.Close(); err != nil {
				t.Fatal(err)
			}
			var coldCodec BuildCodec
			opts.BuildCodec, imageOpts.BuildCodec = &coldCodec, &coldCodec
			plan, err := PlanRawOrdinalColumnPartImage(opts, values, imageOpts)
			if err != nil {
				t.Fatal(err)
			}
			workspace := BuildCodecCapacity()
			if plan.ConstructorBytes > math.MaxUint64-workspace {
				t.Fatal("test total promise overflows")
			}
			var before, after runtime.MemStats
			runtime.ReadMemStats(&before)
			got, err := BuildRawOrdinalColumnPartImage(91, opts, values, imageOpts)
			closeErr := coldCodec.Close()
			runtime.ReadMemStats(&after)
			if err != nil || closeErr != nil {
				t.Fatalf("construction=%v close=%v", err, closeErr)
			}
			runtime.KeepAlive(got)
			if used := after.TotalAlloc - before.TotalAlloc; used > plan.ConstructorBytes+workspace {
				t.Fatalf("cold constructor allocation cohorts=%d exceed image=%d + original codec=%d", used, plan.ConstructorBytes, workspace)
			}
		})
	}
}
