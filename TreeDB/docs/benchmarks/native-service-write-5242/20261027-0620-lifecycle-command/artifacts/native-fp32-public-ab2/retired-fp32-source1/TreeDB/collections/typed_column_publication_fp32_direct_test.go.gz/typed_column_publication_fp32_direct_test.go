package collections

import (
	"bytes"
	"fmt"
	"testing"

	"github.com/snissn/gomap/TreeDB/internal/typedcolumn"
)

// These controls use the original prepared-publication APIs. The generic
// reference is independent of the dispatcher, so parity survives a disabled
// optimization. The existing phase metric distinguishes an image constructor
// from construction of an intermediate generic ColumnPart.
func TestTypedColumnPublicationFP32DirectUnchangedPromise(t *testing.T) {
	for _, tc := range []struct {
		name                   string
		rows, dims             int
		section                typedcolumn.Compression
		ordinal                bool
		granuleRows            int
		excessPreparedCapacity bool
		wantDirect             bool
	}{
		{name: "default", rows: 4096, dims: 128, section: typedcolumn.CompressionZSTD, ordinal: true, wantDirect: true},
		{name: "sections_none", rows: 4096, dims: 128, section: typedcolumn.CompressionNone, ordinal: true, wantDirect: true},
		{name: "sections_lz4", rows: 4096, dims: 128, section: typedcolumn.CompressionLZ4, ordinal: true, wantDirect: true},
		{name: "multiple_granules", rows: 8193, dims: 3, section: typedcolumn.CompressionZSTD, ordinal: true, wantDirect: true},
		{name: "small_constructor_does_not_fit", rows: 1, dims: 3, section: typedcolumn.CompressionZSTD, ordinal: true},
		{name: "nonordinal_identity", rows: 4096, dims: 3, section: typedcolumn.CompressionZSTD},
		{name: "explicit_granule_geometry", rows: 4096, dims: 3, section: typedcolumn.CompressionZSTD, ordinal: true, granuleRows: 128},
		{name: "unsupported_section_codec", rows: 4096, dims: 3, section: typedcolumn.CompressionSnappy, ordinal: true},
		{name: "preserve_prepared_capacity", rows: 4096, dims: 128, section: typedcolumn.CompressionZSTD, ordinal: true, excessPreparedCapacity: true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			field := typedColumnAdapterField("embedding", ColumnStoreValueFloat32Vector)
			field.VectorDims = tc.dims
			opts := typedColumnAdapterOptions{
				PartID: 73, SchemaVersion: 23, Fields: []TypedStorageField{field},
				DefaultCompression: typedcolumn.CompressionLZ4, DefaultCompressionSet: true, DefaultCompressionOnlySupported: true,
				SectionCompression: tc.section, SectionCompressionSet: true, RowsPerGranule: tc.granuleRows,
			}
			rows := make([]typedColumnAdapterRow, tc.rows)
			for row := range rows {
				vector := make([]float32, tc.dims)
				for dim := range vector {
					vector[dim] = float32((row+dim)%17) / 17
				}
				id := int64(row)
				if !tc.ordinal {
					id += 101
				}
				rows[row] = typedColumnAdapterRow{PrimaryID: id, Values: map[string]columnDeclaredValue{
					"embedding": {Type: ColumnStoreValueFloat32Vector, Present: true, Float32Vector: vector},
				}}
			}
			prepared, err := prepareTypedColumnAdapterBatchFromSource(opts, typedColumnAdapterRowsSource(rows))
			if err != nil {
				t.Fatalf("prepare original carrier: %v", err)
			}
			if tc.excessPreparedCapacity {
				original := prepared.Batch.Float32Vectors["embedding"]
				oversized := make([]float32, len(original), len(original)*32)
				copy(oversized, original)
				prepared.Batch.Float32Vectors["embedding"] = oversized
			}
			var referenceCodec, selectedCodec typedcolumn.BuildCodec
			defer referenceCodec.Close()
			defer selectedCodec.Close()
			referencePrepared := *prepared
			referencePrepared.Options.BuildCodec = &referenceCodec
			reference, err := buildTypedColumnAdapterPartFromPreparedBatch(&referencePrepared, 73)
			if err != nil {
				t.Fatalf("generic reference: %v", err)
			}
			want, err := reference.buildImage()
			if err != nil {
				t.Fatalf("generic image: %v", err)
			}
			got, err := buildTypedColumnPartImageFromPreparedBatchWithCodec(prepared, 73, &selectedCodec)
			if err != nil {
				t.Fatalf("selected constructor: %v", err)
			}
			if !bytes.Equal(got.Bytes, want.Bytes) || got.Rows != tc.rows || len(got.TypedGranuleRowOrder) != 0 {
				t.Fatalf("publication changed bytes/rows/order: bytes=%d/%d rows=%d order=%v", len(got.Bytes), len(want.Bytes), got.Rows, got.TypedGranuleRowOrder)
			}
			image, err := typedcolumn.ParseColumnPartImage(got.Bytes)
			if err != nil {
				t.Fatalf("parse published image: %v", err)
			}
			reopened, err := typedcolumn.ColumnPartFromImage(image)
			if err != nil {
				t.Fatalf("reopen published image: %v", err)
			}
			vector, err := reopened.DenseFloat32VectorColumn("embedding", nil)
			if err != nil {
				t.Fatalf("read published vector: %v", err)
			}
			for row := range rows {
				if _, ok := reopened.Locators[rows[row].PrimaryID]; !ok {
					t.Fatalf("original ordinal identity lost at row %d", row)
				}
				for dim, wantValue := range rows[row].Values["embedding"].Float32Vector {
					if vector.Values[row*tc.dims+dim] != wantValue {
						t.Fatal(fmt.Sprintf("vector changed at row=%d dim=%d", row, dim))
					}
				}
			}
			if got.Metrics.DictionaryBuild != prepared.Metrics.DictionaryBuild || got.Metrics.RowMaterialization != prepared.Metrics.BatchAllocation+prepared.Metrics.BatchFill || got.Metrics.ImageBuild <= 0 {
				t.Fatalf("prepared/publication phase metrics lost: %+v", got.Metrics)
			}
			// All semantic/representation oracles precede the causal dispatch
			// gate. Baseline is expected to fail only eligible direct cases.
			direct := got.Metrics.PartBuild == prepared.Metrics.PartBuild
			if direct != tc.wantDirect {
				t.Fatalf("direct image phase=%t want %t (generic PartBuild=%s)", direct, tc.wantDirect, got.Metrics.PartBuild-prepared.Metrics.PartBuild)
			}
		})
	}
}
