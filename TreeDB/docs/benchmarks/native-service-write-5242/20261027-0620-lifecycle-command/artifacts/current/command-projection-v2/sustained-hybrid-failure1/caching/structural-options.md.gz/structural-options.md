# Structural decoder alternative (source-only decision)

**A maintained algorithm exists:** use the already-pinned snissn/compress `NewBoundedReader` in `BoundedRaw` mode, instead of ordinary `NewReader`/`DecodeAll`, behind the existing admitted COW decoder. This is a credible structural successor, not permission to reduce the current envelope. It requires a small caller bridge and one policy gap resolved before adoption; it is not a drop-in replacement today. No implementation or runtime was performed.

## What is actually pinned

Current go.mod:25 pins `github.com/snissn/compress` **88a027b09341**, not the older 87fb149e4721 named by the stale comment in `valuelog/cow_reader.go:435`. The companion JSON binds the actual module/source files. Current COW decoding already selects concurrency=1, lowmem=true, DecodeAllCapLimit=true, bounded MaxMemory/MaxWindow (`cow_reader.go:525–527`). No ordinary decoder option removes its general constructor/table/pool machinery. Global `dict_codec_cache.go:83–105` uses less constrained pooled ordinary decoders; borrowing that cache would abandon original receipt ownership and is unsuitable.

## Why bounded Raw is materially different

Pinned `zstd/decoder_bounded.go:95–108` constructs only an admitted Decoder plus a continuation; it explicitly avoids global-table/pool initialization. `Begin` at114 accepts existing admitted input, original input owner, complete raw output capacity and an independently owned immutable dictionary. `BoundedRaw` reuses this existing raw backing; it never invokes segmented-history allocation (`emit`1102–1115). Sequence/FSE state lives in the continuation and the original sequential state machine, with no max-sequence slice. Dictionary parsing at373–471 borrows definition bytes and certifies their Huff/FSE tables and offsets; there is no ordinary `loadDict` content copy.

Actual allocation families for this mode are explicit and admitted before allocation:

- Decoder + bounded continuation: `NewBoundedReader`, exact library `AllocationCharge(sizeof(...))` through `Retain`.
- At most two Huff table states (frame and dictionary), each with FSE Scratch, 2048×uint16 decode table and 256-entry prior table: `huff0/decompress_step.go:80–97,175–205`; each allocation is preceded by `Retain`, with charged alias-clear/refund in `ClearStep`.
- One literal buffer of 128 KiB+16 bytes, allocated once at `decoder_bounded.go:700–711`, including malformed literal paths. It is not sized from the optimistic 4 KiB leaf result.
- Original caller input/raw buffers and independently retained definition remain charged by their original owners throughout use. The enclosing COW wrapper, interface/adapter and receipt/control backing must also remain charged.

`Begin` avoids the extra maximum-block input buffer owned by `BeginStream`. No new file reader, representation, dictionary cache or owner registry is needed. This algorithm can replace the old **reservation envelope** (64×256KiB plus 24×98,047-byte sequence bound etc.); the source does not claim those conservative amounts are actual heap allocations removed. A complete numeric integrated peak remains null pending the bridge; `Retain` exposes private containing sizes before each actual allocation, so no guessed replacement coefficient is necessary.

## Required integration proof; no shortcuts

1. Bridge DecoderWork to the SAME existing COW decoder receipt. `Retain` must admit growth before allocation; `Release` only follows actual alias removal. `Reserve`/`Available` must have real finite same-operation work operands and guarantee charged error cleanup; always-true unpriced work callbacks or an infinite pause loop are invalid. Gomap currently has no production `NewBoundedReader`/DecoderWork adapter. This is local integration work, not an existing drop-in seam.
2. Preserve original physical pinned-file/record/CRC admission and full decode before any selected leaf is returned. Continue checking outer 64-bit producer SHA identity. `BorrowedDictionary.ID` is the dictionary's embedded 32-bit ZSTD ID, **not** a truncation of that 64-bit content identity. Retain the existing dictionary owner until reset/Close clears its aliases. Preserve exact output length and backing checks in COWDecoder.Decode.
3. Preserve current explicit per-frame window/decoded-size rejection, including concatenated/skippable frames. Bounded phase6 currently checks library MaxWindowSize and64GiB, not the current COW caller's smaller windowCap/MaxMemory (`decoder_bounded.go:555–567`). Raw capacity prevents output allocation/growth but does **not** preserve that rejection policy. First-header-only checks miss later concatenated frames. A maintained per-frame limit seam in the bounded engine, or a complete equivalent existing-policy proof, is required; do not silently broaden accepted windows or reject previously supported concatenation.
4. Drive charged ResetStep/CloseStep through completion on success/error/refusal. `BoundedControlSize` at1209 identifies exported Decoder control that remains caller reachable after continuation detachment: refund its charge only after dropping the final decoder pointer. Keep existing physicalMu exclusion; no callback into the cache, recapture or retry-to-fit.

Pinned upstream already contains actual GoMap dictionary producer fixtures (`TestBoundedActualGomapProducerFrames`), concatenated-frame/dictionary/reset controls, malformed-allocation and Close lifecycle tests. They establish maintained intent, not new validation or a claim they were run here.

## Alternative: writer placement

The existing rewrite writer already has a dictionary-free Snappy/LZ4 leaf lane: `leafPageBlockCodecFromOptions` at `db/vlog_rewrite.go:428`, split-leaf batch preparation at4552+, and maintained `NewCOWBlockDecoder` at `valuelog/cow_reader.go:481`. Auto/balanced chooses LZ4; pack currently calls `prepareCurrentRewriteLeafDict` and `SetLeafDictMode` (`leaf_generation_pack.go:312–356`), which can supersede it. An explicit future packed-leaf policy could choose block coding and keep ordinary value dictionaries. That changes storage/ratio policy and must honor configured codecs; it cannot lawfully decode or reinterpret the already-published dictionary leaf causing this failure. Old immutable dictionary records still require admitted support until replaced. This is a broader representation decision, so prefer the bounded-reader integration inquiry.

## Smallest next causal proof

Before production adoption: exercise the ORIGINAL COW decoder/read API with a real maintained writer-produced dictionary leaf under finite headroom where the existing 19.8MB envelope refuses. Preserve full exact leaf/CRC/dictionary/provider/ownership assertions, rejection controls (including later-frame window limits), held capture and Close-zero. Original should fail only the finite-admission/activation terminal oracle; bounded candidate should construct and decode through the same receipt without fallback. Then repeat the original fresh-process sustained Hybrid workload once under unchanged caps/fixtures; this alone can establish whether the structural successor resolves the observed peak and public cost. No claim that a helper improvement meets parent performance gates.
