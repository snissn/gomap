# Sustained native mixed Hybrid: collections ownership inquiry

Source-bound finding, not a repair or qualification. Source is command-diagnostic-source1 HEAD773a90e6bbcbaf9ecf4d36f076d0d859f3d791b4 plus root's frozen staged overlay. `source.json` binds each consumed source and the four retained failure artifacts. No source or runtime was changed.

## Actual failing phase

The existing server error logger already exposes the underlying cause. The retained serve.log contains:

```
*documentservice.Error: index_unavailable: hybrid search index is unavailable
<- *fmt.wrapErrors: collections: hybrid search index unavailable:
hybrid scalar filter index "meta_tenant" lookup failed:
immutable memtable capacity exhausted
```

This is not an opaque HNSW cold-load/ColumnGraph failure. It is the scalar-prefilter lookup, before the mixed request starts text/vector candidate generation. The public result remains a real failure after 662/1000 measured responses, not valid timing; six later wire cases remain unattempted. The last returned successful plan's exact/vector mode, complete_exact scalar plan and source counters describe the preceding response, not the failed request.

`Service.SearchHybrid` (service.go:1505–1626) acquires the service collection entry and defers its RUnlock, constructs one request context/options object, then maps the collection error. `mappedHybridSearchError` (rag_routes.go:848–857) delegates this non-truncated failure to service.go:3055–3070. ErrHybridSearchIndexUnavailable becomes the observed index_unavailable message; errors.go:86–89 makes that HTTP503. http.go:351–378 logs the full unwrap chain while returning the stable service vocabulary.

The scalar execution route is hybrid_executor.go:722–804. It installs the request's same catalog/read view, reserves the map, and calls leafProbeBeforeCopy. visitLeafIDs (:841–932) can produce the exact lookup wrapper on scalar iterator construction, iterator/source work or merged-scan/per-ID admission. It does not identify which underlying Acquire/Resize refused. Its iterator has a deferred Close; construction error cleanup is also maintained by nativeTextCatalog.iterator. This request did not reach candidate execution (:218 onward). Hence a vector buffer leak in this *failed request* or final-fetch allocation cannot be the immediate refusing site, though retained state from earlier requests remains a hypothesis.

## Lifecycle audit

- Native search creates one fresh CollectionReadView and native operation lease each request (native_existing.go:125–137), plus fresh hybridNativeScratch (hybrid_executor.go:1620–1651). Its charged counter is per request, not facade/global state.
- searchHybridWithCandidateBudgetPolicy (:108–130) installs a defer immediately after successful view open. It clears catalog callbacks and native scratch aliases, then closes the view on every return, joining close errors. The native view Close (document_materializer.go:416–433) drops aliases and closes NativeJSONRead followed by the native operation lease.
- NativeJSONRead.Close (native_json_read.go:435–493) detaches scratch, schema/state/capture and all read-owned receipts; ongoing borrowed visitors postpone disposal only until the last visitor closes. The scalar lookup runs before text serving config is selected, so its ordinary scalar iterator does not acquire the selected-text heldVisit. Its cursor still closes through its ordinary defer. No missing scalar iterator close was found.
- Current-snapshot checks (:296–315) close each temporary semantic probe even on error. The request still uses its original full read view for scalar/text/vector/fusion/final fetch; no final-fetch recapture is introduced on the native path.
- For successful requests the parallel candidate path (:1104–1121) waits for the vector goroutine before returning either error. The view therefore does not close while candidate work still runs. The default mixed+scalar budget policy (hybrid_candidate_budget.go:100–102) uses one fixed source attempt, not adaptive reruns accumulating unbounded work.
- Native vector adaptation (hybrid_vector_candidates.go:145–183) creates a local buffer and defers Reset. searchNativeHNSWAtReadView (vector_index_search.go:3045–3184) resets on entry/error, admits one original query receipt, and releases the Use gate on return. VectorIndexSearchBuffer.Reset (:950–960) drops buffer backing before closing its receipt. Candidate conversion owns copies admitted on the request's view, so Reset does not invalidate fused result IDs.
- planNativeScalarFilterAtLookup with the already-complete allow-set returns CompleteExact before the plan-cache path (vector_index_scalar_filter.go:936–947). More generally the admitted native path does not populate the unadmitted plan cache. This fixture does not generate a distinct retained scalar-plan cache entry per request.
- Final document fetch (:1309–1350) borrows the same view, admits output through the original scratch and transfers independent output; it occurs after both candidate branches have joined. NativeJSONRead.getAdmitted and read scope remain closed by the outer defer.

No missing per-request view/buffer/cursor release or obvious collections cumulative owner was found. That is a source audit result, not proof that each allocator receipt is refunded at runtime. It does not audit caching's physical decoder/basis lifetime, which belongs to the other helper.

## Capacity evidence and one discriminator

Before measured requests, after warmup, the retained diagnostics show Reserved/ExternalBytes=46,851,072; ExternalLeases=17; Total=46,903,040; Views=0; Sources=0; Generations=4; History=51,712; maintenance capacity=33,554,432 and used=199,024. The 64MiB in-flight budget leaves 20,257,792 bytes at this snapshot. These are initial owner totals, not failure-time totals. The failed report's After contains RSS/file bytes only; it has no end-of-query COW counters. Thus neither a linear receipt leak nor a legitimate transient fixed-owner overlap is established. Repeated successes and a late scalar refusal prioritize distinguishing those possibilities, not reducing a scalar charge or retrying.

The smallest necessary observer is a failure-only trace at the **original allocator rejection**: exact Acquire/Resize request/prior charge, stack, Reserved/External/leases/Views/generations and existing fixed-maintenance/decoder owner counters. Add request scalar progress only at the existing lookup failure (input IDs/inspected count and same hybridNativeScratch charged total); then record owner totals after the outer view defer closes, before service teardown. Existing source error logging already identifies the public phase and needs no second public error mechanism. The caching helper can identify the exact parent/basis/decoder lease; do not speculate it from these totals.

Discrimination: monotonic retained lease/reserved growth after each fully closed request would prove missing lifecycle release; constant quiescent totals with an extra concurrently live known owner at the failing allocation would instead prove transient co-residency. The failure-time stack also distinguishes iterator construction/physical read from merged-index scratch or per-ID output growth. Preserve original 4096/fixed128 corpus, 64+64 candidate limits, exact unchanged scalar filter, request once, original cap, durability and Close. No caller retry, GC/sleep workaround, extra checkpoint, prewarming, cap/charge discount or graph/route switch is justified by current evidence.

After the owner is causally identified, one maintained regression should repeat the actual mixed request with the original finite owners and assert per-request quiescent receipt/capture equality and refusal cleanup; a known-owner overlap should instead use that real owner's existing bounded witness. Do not select either implementation before the allocation/owner trace. Existing retained failure/nulls remain immutable; hard correctness and performance gates remain open.
