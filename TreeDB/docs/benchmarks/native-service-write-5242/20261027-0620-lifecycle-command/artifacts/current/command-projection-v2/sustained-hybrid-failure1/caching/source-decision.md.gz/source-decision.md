# Sustained Hybrid scalar refusal: caching half

Bound to source.json: HEAD773a90e6bbcbaf9ecf4d36f076d0d859f3d791b4, root-selected index ee160f070e079763b75369d01de9c0b9df67d218. Source-only inquiry; no production/source/index edits, Go/runtime, build, formatting or GitHub work. The retained serve.log directly confirms meta_tenant scalar lookup ErrCOWCapacity. No failing admission was yet attributed. Do not relabel the failed 662/1000 cell as accepted timing or infer a ColumnGraph/HNSW cause.

## Actual bridge and possible admissions

The actual scalar cursor is nativeTextIterator/nativeDomainCursor, NOT caching Snapshot.Iterator. That distinction prevents blaming the public iterator wrapper for this request.

- nativeTextCatalog.iterator/seek (native_text_catalog.go:187,257) uses the request's physicalScratch and original admission callback. physicalScratch (native_json_read.go:101) calls capture.NativeAllocator().AdmitNativeBytes. Cursor projection/key/value/per-ID copies can call the enclosing collections receipt's Resize. The collections adviser owns that caller ledger.
- NativeJSONRead.loadLeaf (:356) calls the ORIGINAL capture.NativeLeafPage. cow_native_physical_read.go:68–95 takes basis.readMu, admits/reuses its basis workspace, then readPhysicalLeafWithDictionary (workspace.go:748).
- A leaf miss may admit a physical workspace (workspace.go:79–87), codec-slot array (166–182), input/output growth cohort (193–223), or actual decoder (289–402). Dictionary preparation separately admits original definition/snapshot metadata in cow_resources.go:111–128 and cow_cut.go:916–931. Record CRC/identity/shape work remains mandatory.
- NativeValueAtPointer (cow_native_physical_read.go:109–143) holds physicalMu, prepares/decodes on the cache workspace, THEN invokes caller admitOutput before copying. Thus a stack through this method can represent either original decoder AcquireExternal OR the original collections receipt Resize; the outer public wrapper does not distinguish them.
- Verified leaf-cache admission (workspace.go:815; db/bounded_read_owner.go:124–135) is a preexisting backend cache store and returns identity/read errors, not a new parent COW byte admission. A verified hit avoids decoder growth but still checks the exact pinned file/shape. Do not attribute ErrCOWCapacity to this cache store without an original allocation trace.

All relevant byte admissions converge on the SAME parent COWBudget: NativeAllocator returns cache.budget (native_semantic.go:49–54); AdmitNativeBytes pre-rounds its supplied aggregate then AcquireExternal adds the receipt header (cow_budget.go:437). AcquireExternal itself does not re-round the aggregate beyond that header. Resize adds the same receipt header to its requested target and charges only positive target-current delta (:199–240). A refusal leaves that lease/budget unchanged.

Exact independent refusal predicates under budget.mu:

    ReservedBytes + delta > MaxInFlightBytes
    HistoryBytes + ReservedBytes + DeferredBytes + delta > MaxRetiredBytes
    TotalBytes + delta > MaxTotalBytes

Acquire additionally checks nativeSource MaxSources for that special producer and external-count overflow; neither should be silently interpreted as a scalar byte peak. Native ordinary allocator uses nativeSource=false. Include arithmetic-overflow refusal separately. No explanation based only on the 64MiB in-flight limit is complete without the other two original predicates.

Two caching ErrCOWCapacity sites can bypass budget rejection logging: addCodecSlot len(codecs)>=MaxResources (workspace.go:168), and dictionary read Snapshot.ValueLog MapHint/FileCount >MaxResources (resources.go:113). If allocator logs no refusal, observe these exact guards; do not add retry or classify the error as transient. Metadata EnrollPair uses the same budget's AcquireRetention and is visible to the original allocator witness.

## Owner/lifetime assessment

1. NativeSemanticCapture has one independently admitted wrapper, original cut reference and immutable dictionary capability. Close detaches them, releases the cut and closes that same lease (native_semantic.go:24–76). NativeAllocator/receipts own no capture/cache backpointer.
2. Basis workspace and its fixed THREE opportunistic read slots are deliberately retained across queries, shared by successor cuts. They close only at the last basis reference (cow_cut.go:22–96). Their existence after a successful request is not itself a leak.
3. Cache physicalReader is another deliberate longer-lived owner (workspace.go:105–149). Each decoder owns its actual independently admitted definition, input/raw arrays and decoder lease. Generic cache decoding keeps only the current incompatible producer; replacement closes old storage before admission (:291–310,330–337). Nil codec slots are reused (:305–324), so there is no source-supported one-slot-per-request accumulation. Same producer only grows when actual required capacities grow. Raw Snappy/LZ4 codec slots can coexist under the existing resource limit.
4. Workspace grow charges every geometrically grown buffer cohort and linked allocation record until that workspace closes (:193–223,415–449). Superseded arrays may be unreachable yet their reservation remains deliberately conservative. Thus cumulative charged bytes can exceed current live capacities without a missing Close. For a repeated identical fixed-record population this should plateau, not grow once per request; changing records/producers/bases must be observed rather than assumed.
5. A public caching snapshot-bound iterator, if another path uses one, closes merge children/workspace/lease (cow_read.go:209–230), unregisters from its snapshot and closes its independent bound-wrapper receipt (snapshot_iterator_lifetime.go:261–301). Snapshot.Close waits for active reads/bound children, then drains snapshot scratch/pin/cut (snapshot.go:393–437). This is a negative/control audit, not the actual scalar cursor path.
6. Actual native scalar buffers and cumulative scan/output admission are request-owned upstream. No caching branch resets or borrows their credit. Failed physical preparation may legitimately leave successful-prefix scratch in a basis/cache owner for reuse; post-failure parent totals alone cannot label that stranded memory.

No source-confirmed missing caching Close or uncapped per-request resource registry was found. This does not prove runtime receipts are all returned. A late failure after hundreds of successes requires original-owner evidence; current initial counters and terminal RSS cannot select leak versus a real overlap.

## Smallest causal attribution witness

Use the diagnostic-only original allocator rejection/refund overlay being prepared by publication_seam; do not build a second observer. At AcquireExternal/Resize rejection, atomically capture budget pointer, original lease pointer if any, raw requested bytes, final target including header, prior charge/delta, all COWStats and exact limits/predicate bits while holding its existing mutex. Emit the original call stack and scalar record AFTER releasing that mutex. Do not call cache diagnostics or recursively Stats() under budget.mu; the caller may already hold physicalMu or basis.readMu. Success admission semantics stay unchanged.

At the existing AFTER-request-view-Close boundary (also on the failed request), take the existing COWMemoryStats fixed-size snapshot; it neither reads storage nor creates a retained owner (cow_stats.go:9–17). Retain warmup-final, periodic closed-request and failure-final scalar totals, same process/budget identity and request ordinal. This needs no new query, recapture, GC, forced cleanup, trim, sleep, checkpoint, reservation, cap change or body retry. Keep original fixture and all failed evidence. A fixed bounded record buffer/counters or direct diagnostic logs suffice; no owner registry is justified.

Classification: (a) stable quiescent Reserved/ExternalLeases plus returned refused-phase bytes supports a real simultaneous peak, whose stack identifies the original constructor/caller; (b) rising after-Close Reserved/ExternalLeases supports retained debt but requires matching named owner/receipts before repair; (c) stable lease count with rising charge can be same-receipt Resize or conservative buffer-growth debt, not proof of leaked wrappers; (d) History/Deferred growth with flat External points to cleanup/generation debt; (e) no allocator refusal points first to the two resource-count guards above or collections arithmetic/work guards. The original-source wrapper alone cannot decide among these.

If fixed-owner attribution is still needed, after the request unwinds inspect ONLY the existing current basis.reader/readSlots and cache.physicalReader under their own locks: workspace identity, allocation-list length, input/output capacities, codec IDs/capacities/definition and original receipt identities. Do not acquire those locks from the rejecting allocator; do not scan storage or introduce a cache pointer into allocator objects. This distinguishes retained allowed scratch/cohort debt from an outstanding request lease without changing product ownership.

## Existing maintained proof controls (no execution requested here)

- TestCOWNativeBasisWorkspaceLifetime; TestCOWNativeLeafWorkspaceAdmissionAndLifetime; TestCOWNativeValueWorkspaceAdmissionAndLifetime; TestCOWNativeValueDictionaryColdAfterClose (cow_native_physical_read_test.go:25,494,148,153).
- TestCOWReadWorkspaceMetadataAdmissionRefusalAndDrain (cow_read_metadata_admission_test.go:13).
- TestCOWPhysicalIteratorWorkspaceSharesAdmission and TestCOWPhysicalIteratorConstructorErrorDrainsWorkspace (cow_iterator_workspace_test.go:19,151).
- TestCOWDictionaryTwoLiveIteratorsDefaultBudget; TestCOWDictionaryIteratorPointerOwnershipAndTransitions; TestCOWDictionaryIteratorCRCAndAdmissionRefusal (cow_iterator_dictionary_capacity_test.go:24,187,289).

One next meaningful public test is the SAME bounded sustained mixed request with this attribution overlay, not another repair or benchmark campaign. Select the owner-specific correction only after the original rejecting operation and final cleanup totals are concrete. Root owns execution, integration and product gates.
