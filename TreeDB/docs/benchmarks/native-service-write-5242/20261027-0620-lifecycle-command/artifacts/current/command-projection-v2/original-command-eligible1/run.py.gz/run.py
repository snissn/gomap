#!/usr/bin/env python3
"""Fixed original-command B/L/N collection. Inert without --execute; never accepts performance."""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import socket
import statistics
import subprocess
import threading
import sys

TASK = Path('/mnt/fast4tb/gomap-mongo-execution-20261024')
DRIVER = 'cmd/treedb-document-service/command_public_bench_test.go'
DRIVER_SHA = '9a1ebc077be73e44ece496903b644aefa0dafbc0429f155952a31d6c28d35d4d'
ELIGIBILITY_DECISION_SHA = '0b8cf34618958d5403fb79fbbfe77a05e8605fbc1d304723f2f2d75935d04427'
BASELINE_HEAD = 'a621e9a4ac0904dfe012b9c9e101954cebd503d0'
HELPER = TASK / 'evidence/native-query-work-witness1/run.py'
CASES = (('http', 'keyword'), ('http', 'dense'), ('http', 'hybrid'),
         ('native', 'dense'), ('native', 'crud'))
ORDERS = ('BLN', 'NLB', 'LBN', 'NBL', 'BNL')
FLAGS = ['-test.run=^TestCommandPublicPerformance$', '-test.count=1', '-test.timeout=12m', '-test.v']
SHAPE = {'dimensions': 8, 'rows': 4096, 'batch_size': 128, 'batches': 32,
         'payload_repeats': 32, 'tenants': 16, 'measured_operations': 1000,
         'warmup_requests': 1, 'concurrency': 1, 'strategy': 'native_runtime',
         'profile': 'command_wal_durable', 'M': 16, 'EfConstruction': 128, 'EfSearch': 64}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    # Immutable stage artifacts, including the plan, never replace an earlier run.
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], timeout=60)


def absolute_task_path(value):
    require(isinstance(value, str), 'unbound absolute task path')
    p = Path(value)
    require(p.is_absolute() and p.resolve().is_relative_to(TASK.resolve()), 'path outside task root: ' + value)
    return p


def source_state(binding, mode):
    repo = absolute_task_path(binding['path'])
    require(repo.is_dir(), 'required source unavailable: ' + str(repo))
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    tree = git(repo, 'rev-parse', 'HEAD^{tree}').decode().strip()
    require(re.fullmatch('[0-9a-f]{40}', str(binding['head'])) is not None, 'unbound source head')
    require(re.fullmatch('[0-9a-f]{40}', str(binding['tree'])) is not None, 'unbound source tree')
    status = git(repo, 'status', '--porcelain=v1', '-z', '--untracked-files=all').hex()
    paths = set(git(repo, 'diff', '--name-only', '-z', 'HEAD').split(b'\0'))
    paths.update(git(repo, 'ls-files', '--others', '--exclude-standard', '-z').split(b'\0'))
    paths.discard(b'')
    dirty = {}
    for raw in sorted(paths):
        relative = os.fsdecode(raw)
        p = repo / relative
        if p.is_symlink():
            dirty[relative] = 'symlink:' + os.readlink(p)
        else:
            dirty[relative] = sha(p) if p.is_file() else None
    require(head == binding['head'] and tree == binding['tree'], 'source head/tree mismatch: ' + str(repo))
    require(dirty == binding['dirty_files'], 'dirty source inventory mismatch: ' + str(repo))
    if mode == 'final75' or head == BASELINE_HEAD:
        require(not status and not dirty, 'final/baseline source must be clean: ' + str(repo))
    return {'path': str(repo), 'head': head, 'tree': tree, 'status_porcelain_z_hex': status,
            'dirty_files': dirty, 'diff_head_binary_sha256': hashlib.sha256(git(repo, 'diff', '--binary', 'HEAD')).hexdigest()}


def inventory(binding):
    # Complete tracked and nonignored untracked file bytes, outside measured work.
    repo = Path(binding['path'])
    ignored = git(repo, 'ls-files', '--others', '--ignored', '--exclude-standard', '-z')
    require(not ignored, 'source contains unbound ignored files; select an isolated source without them: ' + repr(ignored[:2048]))
    files = {}
    for raw in sorted(set(git(repo, 'ls-files', '--cached', '--others', '--exclude-standard', '-z').split(b'\0')) - {b''}):
        name = os.fsdecode(raw)
        p = repo / name
        require(not p.is_dir(), 'submodule/directory source input requires explicit resolution: ' + name)
        files[name] = ('symlink:' + os.readlink(p)) if p.is_symlink() else (sha(p) if p.is_file() else None)
    return files


def file_binding(binding):
    p = absolute_task_path(binding['path'])
    require(re.fullmatch('[0-9a-f]{64}', str(binding['sha256'])) is not None, 'unbound artifact SHA256')
    require(sha(p) == binding['sha256'], 'artifact hash mismatch: ' + str(p))
    return p


def report_validation(path, slot, binaries):
    r = json.loads(path.read_text(), parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    latencies = r.get('OperationNanoseconds')
    index = r.get('Index', {})
    rate, duration = r.get('OperationsPerSecond'), r.get('DurationSeconds')
    checks = {
        'identity': r.get('version') == 'actual-command-v1' and r.get('Label') == slot['name'],
        'case': (r.get('Command'), r.get('Operation')) == (slot['command'], slot['operation']),
        'owner': r.get('LegacyFlag') is (slot['role'] == 'L'),
        'shape': r.get('Requested') == 1000 and r.get('Completed') == 1000 and r.get('SeedRows') == 4096,
        'index': all(index.get(k) == v for k, v in {'dimension': 8, 'metric': 'cosine',
            'vector_strategy': 'native_runtime', 'vector_m': 16, 'vector_ef_construction': 128, 'vector_ef_search': 64}.items()),
        'scalars': {(x.get('field'), x.get('value_type')) for x in index.get('scalar_fields', [])} ==
            {('meta.tenant', 'string'), ('meta.rank', 'int64')},
        'durable': r.get('Profile') == 'command_wal_durable',
        'complete': r.get('Phase') == 'complete' and not r.get('failure') and not r.get('cleanup_errors') and 'failed_operation' not in r,
        'directory': r.get('Directory') == slot['prefix'] + '.db',
        'allocations_unavailable': 'ServerAllocatedBytes' in r and r['ServerAllocatedBytes'] is None and
            'ServerMallocs' in r and r['ServerMallocs'] is None,
        'timing': all(type(x) in (int, float) and math.isfinite(x) and x > 0 for x in (rate, duration)) and
            math.isclose(rate * duration, 1000, rel_tol=1e-10),
        'attempts': isinstance(latencies, list) and len(latencies) == 1000 and all(type(x) is int and x > 0 for x in latencies or []),
        'close': type(r.get('CloseNanoseconds')) is int and r['CloseNanoseconds'] > 0,
        'child_logs': all(Path(slot['prefix'] + suffix).is_file() for suffix in ('.seed.log', '.serve.log')),
    }
    for kind, field in (('http', 'HTTPBinary'), ('native', 'NativeBinary')):
        checks[kind + '_binary'] = r.get(field) == binaries[kind]['path'] and r.get(field + 'SHA256') == binaries[kind]['sha256']
    if checks['attempts']:
        ordered = sorted(latencies)
        expected = {name: ordered[max(0, math.ceil(q * 1000) - 1)] for name, q in (('P50', .5), ('P95', .95), ('P99', .99), ('Max', 1))}
        checks['percentiles'] = r.get('LatencyNanoseconds') == expected
    else:
        checks['percentiles'] = False
    # The immutable original driver owns per-request route/result/ACK oracles.
    # Its success is necessary; do not copy its query engine or invent counters here.
    if slot['operation'] == 'dense':
        checks['dense_route'] = r.get('LastDenseRoute') == 'ann'
    valid = all(checks.values())
    metrics = None
    if valid:
        metrics = {key: r[key] for key in ('DurationSeconds', 'OperationsPerSecond', 'LatencyNanoseconds', 'CloseNanoseconds', 'Before', 'After')}
        metrics.update(ServerAllocatedBytes=None, ServerMallocs=None)
    return {'valid': valid, 'checks': checks, 'report_sha256': sha(path), 'metrics': metrics,
            'raw_failure': r.get('failure'), 'raw_cleanup_errors': r.get('cleanup_errors', [])}


def summaries(slots, records, final_valid):
    groups = []
    for command, operation in CASES:
        for role in 'BLN':
            selected = [s for s in slots if (s['command'], s['operation'], s['role']) == (command, operation, role)]
            samples = [{'slot': s['name'], 'round': s['round'], 'status': records[s['name']]['status'],
                        'metrics': records[s['name']].get('metrics')} for s in selected]
            medians = None
            if final_valid and len(samples) == 5 and all(s['metrics'] is not None for s in samples):
                medians = {key: statistics.median(s['metrics'][key] for s in samples)
                           for key in ('DurationSeconds', 'OperationsPerSecond', 'CloseNanoseconds')}
                medians['LatencyNanoseconds'] = {key: statistics.median(s['metrics']['LatencyNanoseconds'][key] for s in samples)
                                                for key in ('P50', 'P95', 'P99', 'Max')}
            groups.append({'command': command, 'operation': operation, 'role': role, 'samples': samples,
                           'five_sample_medians': medians, 'ServerAllocatedBytes': None, 'ServerMallocs': None})
    return groups


def competing_go():
    try:
        result = subprocess.run(['ps', '-C', 'go', '-o', 'pid=,ppid=,pgid=,etimes=,comm='], text=True, capture_output=True, timeout=5)
    except (OSError, subprocess.TimeoutExpired) as error:
        return ['observer_error:' + type(error).__name__]
    if result.returncode not in (0, 1):
        return ['observer_error:ps_exit_' + str(result.returncode)]
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def measured_process(helper, argv, cwd, env, log, wall):
    observations = []
    stopped = threading.Event()
    def observe():
        while not stopped.is_set():
            found = competing_go()
            if found:
                observations.append({'utc': helper.utc(), 'processes': found})
            stopped.wait(1)
    thread = threading.Thread(target=observe, daemon=True)
    thread.start()
    try:
        receipt = helper.run_process(argv, cwd, env, log, wall)
    finally:
        stopped.set()
        thread.join(timeout=10)
    if thread.is_alive():
        observations.append({'utc': helper.utc(), 'observer_error': 'observer_did_not_finish'})
    receipt['competing_go_observations'] = list(observations)
    return receipt



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--mode', required=True, choices=('diagnostic15',))
    parser.add_argument('--contract', required=True, type=Path)
    parser.add_argument('--expected-contract-sha256', required=True)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    if not args.execute:
        parser.error('inert construction: execution requires --execute')
    require(sha(args.contract) == args.expected_contract_sha256, 'selected contract hash mismatch')
    contract = json.loads(args.contract.read_text())
    require(set(contract) == {'schema', 'mode', 'shape', 'sources', 'helper_sha256', 'go_binary', 'environment', 'selection'}, 'contract schema drift')
    require(contract['schema'] == 'original-command-eligible1' and contract['mode'] == args.mode, 'mode mismatch')
    require(contract['shape'] == SHAPE, 'original workload shape drift')
    require(set(contract['sources']) == {'baseline', 'candidate'}, 'B/L/N source drift')
    require(contract['sources']['baseline']['head'] == BASELINE_HEAD, 'original baseline changed')
    out = absolute_task_path(str(args.output_dir))
    require(out.resolve() != TASK.resolve(), 'output must be a new child directory')
    for binding in contract['sources'].values():
        if binding['path'] is not None:
            require(not out.resolve().is_relative_to(Path(binding['path']).resolve()), 'output inside source worktree')
    require(TASK.is_dir() and os.access(TASK, os.W_OK), 'task mount unavailable or unwritable')
    out.mkdir(mode=0o700)  # No overwrite, resume, retry, or automatic final-mode escalation.
    (out / 'bin').mkdir()
    orders = ORDERS[:1] if args.mode == 'diagnostic15' else ORDERS
    slots = []
    for command, operation in CASES:
        for round_number, order in enumerate(orders, 1):
            for role in order:
                name = f'{len(slots)+1:02d}-{command}-{operation}-r{round_number}-{role}'
                slots.append({'name': name, 'command': command, 'operation': operation, 'round': round_number,
                              'role': role, 'prefix': str(out / name), 'legacy': '1' if role == 'L' else '0',
                              'source_eligible': not (role == 'B' and command == 'http' and operation == 'hybrid')})
    write(out / 'contract.json', contract)
    write(out / 'plan.json', {'schema': contract['schema'], 'mode': args.mode, 'slots': slots,
        'role_order_by_round': list(orders), 'case_order': CASES, 'shape': SHAPE, 'driver_sha256': DRIVER_SHA,
        'runner_sha256': sha(__file__), 'selected_contract_sha256': args.expected_contract_sha256,
        'retries': 0, 'qualification_verdict': None, 'server_total_alloc': None, 'server_mallocs': None,
        'threshold': 'material unexplained regression blocks; numeric margin unresolved; no automatic verdict',
        'timeouts_seconds': {'metadata': 60, 'toolchain': 30, 'build_each': 240, 'cell_outer': 780},
        'original_driver_boundaries': ['seed HTTP: CreateIndex, 32 fixed batches, Optimize, clean stop',
            'fresh serve reopen; one warm request; 1000 serial measured operations',
            'FlushAllWithAck(AckFlushed), CheckpointWithAck(AckSynced), serving Close'],
        'server_cli_template': ['-dir <fresh-prefix.db>', '-profile command_wal_durable', '-addr <loopback:ephemeral>',
            '-pprof <loopback:ephemeral>', 'HTTP: -native-addr <loopback:ephemeral>', 'L only: -legacy-storage'],
        'baseline_close_limit': 'a621 standalone ignores deferred service/backend Close errors; unavailable, never inferred'})
    for slot in slots:
        write(out / (slot['name'] + '.slot.json'), slot)
    records = {s['name']: {'status': 'unattempted', 'metrics': None, 'reason': None} for s in slots}
    failure, helper, before, full_before, binaries = None, None, {}, {}, {}
    selection_path = None
    try:
        require(sha(HELPER) == contract['helper_sha256'], 'maintained process helper changed')
        spec = importlib.util.spec_from_file_location('owned_process', HELPER)
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        signal.signal(signal.SIGTERM, helper.interrupted)
        signal.signal(signal.SIGINT, helper.interrupted)
        selection_path = file_binding(contract['selection'])
        selection = json.loads(selection_path.read_text())
        require(selection.get('eligibility_decision', {}).get('sha256') == ELIGIBILITY_DECISION_SHA,
                'unbound source eligibility decision')
        file_binding(selection['eligibility_decision'])
        required = {'mode': args.mode, 'candidate_head': contract['sources']['candidate']['head'],
            'driver_sha256': DRIVER_SHA, 'source_review_accepted': True, 'public_correctness_accepted': True,
            'runtime_safe': True, 'exclusive_measurement_slot': True, 'original_thresholds_preserved': True}
        if args.mode == 'final75':
            required.update(candidate_landed=True, driver_landed=True, qualification_collection_authorized=True)
        require(all(selection.get(k) == v for k, v in required.items()), 'missing root source/safety/landed/collection gate')
        write(out / 'selection.json', selection)
        for label, binding in contract['sources'].items():
            require(set(binding) == {'path', 'head', 'tree', 'dirty_files'}, 'source binding schema drift')
            before[label] = source_state(binding, args.mode)
            full_before[label] = inventory(binding)
        require(before['baseline']['path'] != before['candidate']['path'], 'independent baseline source required')
        candidate = Path(before['candidate']['path'])
        require(sha(candidate / DRIVER) == DRIVER_SHA, 'original driver source changed')
        if args.mode == 'final75':
            require(hashlib.sha256(git(candidate, 'show', 'HEAD:' + DRIVER)).hexdigest() == DRIVER_SHA, 'driver not committed at selected final HEAD')
        write(out / 'source-before.json', before)
        write(out / 'source-files-before.json', full_before)
        inherited = [k for k in os.environ if k.startswith(('GOMAP_', 'TREEDB_'))]
        require(not inherited, 'unset inherited application overrides before running: ' + ','.join(sorted(inherited)))
        expected_env_keys = {'GOTOOLCHAIN', 'GOWORK', 'GOMAXPROCS', 'GOCACHE', 'TMPDIR', 'GODEBUG', 'GOMEMLIMIT', 'CGO_ENABLED', 'CC'}
        require(set(contract['environment']) == expected_env_keys, 'environment schema drift')
        require(all(contract['environment'][k] == v for k, v in {'GOTOOLCHAIN': 'go1.26.0', 'GOWORK': 'off', 'GOMAXPROCS': '4'}.items()), 'toolchain/scheduler drift')
        env = {k: os.environ[k] for k in ('PATH', 'HOME', 'USER', 'LANG', 'LC_ALL', 'TZ') if k in os.environ}
        env['LANG'] = 'C.UTF-8'
        env.update({k: v for k, v in contract['environment'].items() if v is not None})
        for key in ('GOCACHE', 'TMPDIR'):
            p = absolute_task_path(env[key])
            require(p.is_dir() and os.access(p, os.W_OK), 'missing/unwritable task environment path: ' + key)
        go = Path(contract['go_binary'])
        require(go.is_absolute() and go.is_file(), 'unbound absolute Go executable')
        go_sha = sha(go)
        write(out / 'environment.json', {'effective': env, 'go_binary': str(go), 'go_sha256': go_sha,
            'unset': ['GOROOT', 'GOFLAGS', 'all nonwhitelisted environment'], 'hostname': socket.gethostname(),
            'uname': list(os.uname()), 'cpuinfo': Path('/proc/cpuinfo').read_text(),
            'loadavg_before': Path('/proc/loadavg').read_text(), 'affinity': sorted(os.sched_getaffinity(0))})

        def custody():
            require(sha(args.contract) == args.expected_contract_sha256 and sha(HELPER) == contract['helper_sha256'], 'contract/helper drift')
            file_binding(contract['selection'])
            file_binding(selection['eligibility_decision'])
            require(sha(go) == go_sha and sha(candidate / DRIVER) == DRIVER_SHA, 'toolchain/driver drift')
            for label, binding in contract['sources'].items():
                require(source_state(binding, args.mode) == before[label], 'source changed: ' + label)
            for value in binaries.values():
                require(sha(value['path']) == value['sha256'], 'built ELF changed')

        def step(name, argv, repo, timeout, extra=None):
            custody()
            measured = name in {slot['name'] for slot in slots}
            if measured:
                competing = competing_go()
                write(out / (name + '.known-go-preflight.json'), {'utc': helper.utc(), 'processes': competing,
                    'policy': 'Any observation/error refuses this cell before start; no retry or substitute.'})
                require(not competing, 'known competing Go or observer error before ' + name + ': ' + repr(competing))
            write(out / (name + '.attempt.json'), {'argv': argv, 'cwd': str(repo), 'environment': extra or env,
                                                    'timeout_seconds': timeout})
            if measured:
                result = measured_process(helper, argv, str(repo), extra or env, out / (name + '.log'), timeout)
            else:
                result = helper.run_process(argv, str(repo), extra or env, str(out / (name + '.log')), timeout)
            try:
                custody()
                result['source_and_binary_unchanged'] = True
            except BaseException as exc:
                result['source_and_binary_unchanged'] = False
                result['custody_error'] = repr(exc)
            write(out / (name + '.receipt.json'), result)
            require(result['process_ok'] and result['source_and_binary_unchanged'], 'process/custody failure: ' + name)
            if measured:
                require(not result['competing_go_observations'], 'known competing Go or observer error during ' + name)
            return result

        step('toolchain-version', [str(go), 'version'], candidate, 30)
        require((out / 'toolchain-version.log').read_text().startswith('go version go1.26.0 '), 'wrong compiler version')
        step('toolchain-env', [str(go), 'env', '-json', 'GOTOOLCHAIN', 'GOROOT', 'GOVERSION', 'GOTOOLDIR', 'CGO_ENABLED', 'CC', 'GOMODCACHE'], candidate, 30)
        toolenv = json.loads((out / 'toolchain-env.log').read_text())
        require(toolenv['GOVERSION'] == 'go1.26.0', 'resolved toolchain version mismatch')
        step('toolchain-compiler', [str(go), 'tool', 'compile', '-V'], candidate, 30)
        require((out / 'toolchain-compiler.log').read_text().startswith('compile version go1.26.0'), 'actual compiler mismatch')
        resolved_tools = [Path(toolenv['GOROOT']) / 'bin/go', Path(toolenv['GOTOOLDIR']) / 'compile']
        require(resolved_tools[1].parent.is_relative_to(Path(toolenv['GOROOT'])), 'compiler outside resolved Go root')
        write(out / 'resolved-toolchain.json', {'go_env': toolenv, 'tools': [
            {'path': str(p), 'sha256': sha(p)} for p in resolved_tools]})
        for label, binding in contract['sources'].items():
            for kind, package in (('http', './cmd/treedb-document-service'), ('native', './cmd/treedb-native-server')):
                key = label + '-' + kind
                path = out / 'bin' / key
                step('build-' + key, [str(go), 'build', '-p=1', '-o', str(path), package], binding['path'], 240)
                binaries[key] = {'path': str(path), 'sha256': sha(path), 'source': label}
        driver = out / 'bin' / 'command-driver.test'
        step('build-driver', [str(go), 'test', '-c', '-p=1', '-o', str(driver), './cmd/treedb-document-service'], candidate, 240)
        binaries['driver'] = {'path': str(driver), 'sha256': sha(driver), 'source': 'candidate', 'driver_source_sha256': DRIVER_SHA}
        for key, value in binaries.items():
            step('buildinfo-' + key, [str(go), 'version', '-m', value['path']], candidate, 30)
        custody()
        write(out / 'execution-freeze.json', {'sources': before, 'binaries': binaries,
            'driver_argv': [str(driver), *FLAGS], 'toolchain': toolenv, 'environment': env,
            'role_sources': {'B': 'baseline', 'L': 'candidate', 'N': 'candidate'}, 'role_orders': list(orders)})
        for slot in slots:
            record = records[slot['name']]
            if not slot['source_eligible']:
                record.update(status='source_ineligible', metrics=None,
                    reason='Original a621 service entry rejects mixed text+vector native_runtime Hybrid; no timed B comparator exists. L/N remain independent eligible cells.')
                write(out / (slot['name'] + '.validation.json'), record)
                continue
            record['status'] = 'attempted_invalid'
            label = 'baseline' if slot['role'] == 'B' else 'candidate'
            pair = {kind: binaries[label + '-' + kind] for kind in ('http', 'native')}
            cell_env = dict(env, GOMAP_COMMAND_PERF='1', GOMAP_COMMAND_PERF_OPERATIONS='1000',
                GOMAP_COMMAND_PERF_HTTP_BINARY=pair['http']['path'], GOMAP_COMMAND_PERF_NATIVE_BINARY=pair['native']['path'],
                GOMAP_COMMAND_PERF_COMMAND=slot['command'], GOMAP_COMMAND_PERF_OPERATION=slot['operation'],
                GOMAP_COMMAND_PERF_LABEL=slot['name'], GOMAP_COMMAND_PERF_OUTPUT=slot['prefix'], GOMAP_COMMAND_PERF_LEGACY=slot['legacy'])
            try:
                record['process'] = step(slot['name'], [str(driver), *FLAGS], candidate, 780, cell_env)
                validation = report_validation(Path(slot['prefix'] + '.json'), slot, pair)
                record.update(validation=validation, metrics=validation['metrics'])
                require(validation['valid'], 'invalid original-driver report: ' + slot['name'])
                record['status'] = 'valid'
            except BaseException as exc:
                record['reason'] = repr(exc)
                # Raw failed JSON/logs stay intact; no successful timing attribution.
                record['metrics'] = None
                if not (out / (slot['name'] + '.attempt.json')).exists():
                    record['status'] = 'unattempted'
                raise
            finally:
                record['artifacts'] = {suffix: {'path': slot['prefix'] + suffix, 'sha256': sha(slot['prefix'] + suffix)}
                    for suffix in ('.json', '.seed.log', '.serve.log', '.log', '.receipt.json') if Path(slot['prefix'] + suffix).is_file()}
                write(out / (slot['name'] + '.validation.json'), record)
    except BaseException as exc:
        failure = repr(exc)
    finally:
        # The owned process helper has already cleaned its session. Retain the
        # terminal custody/summary without a second termination interrupting it.
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        after, full_after, final_errors = {}, {}, []
        for label, binding in contract['sources'].items():
            try:
                after[label] = source_state(binding, args.mode)
                full_after[label] = inventory(binding)
                require(label in before and after[label] == before[label] and full_after[label] == full_before[label], 'final source mismatch: ' + label)
            except BaseException as exc:
                final_errors.append(label + ': ' + repr(exc))
        for key, value in binaries.items():
            try:
                require(sha(value['path']) == value['sha256'], 'final binary mismatch: ' + key)
            except BaseException as exc:
                final_errors.append(repr(exc))
        if final_errors:
            failure = (failure + '; ' if failure else '') + '; '.join(final_errors)
        write(out / 'source-after.json', after)
        write(out / 'source-files-after.json', full_after)
        write(out / 'binaries-after.json', {k: dict(v, observed_sha256=sha(v['path']) if Path(v['path']).is_file() else None) for k, v in binaries.items()})
        complete = failure is None and all(r['status'] == 'valid' for r in records.values())
        eligible_complete = failure is None and all(records[s['name']]['status'] == ('valid' if s['source_eligible'] else 'source_ineligible') for s in slots)
        write(out / 'summary.json', {'mode': args.mode, 'collection_complete': complete,
            'eligible_collection_complete': eligible_complete,
            'source_ineligible_slots': [s['name'] for s in slots if not s['source_eligible']], 'failure': failure,
            'records': records, 'groups': summaries(slots, records, complete and args.mode == 'final75'),
            'unattempted_slots': [s['name'] for s in slots if records[s['name']]['status'] == 'unattempted'],
            'performance_qualification': False, 'qualification_verdict': None, 'numeric_threshold': None,
            'baseline_discarded_close_errors': None, 'ServerAllocatedBytes': None, 'ServerMallocs': None,
            'interpretation': 'Original parent gates remain open. Full five-sample collection is evidence, not automatic acceptance.'})
    print(json.dumps({'directory': str(out), 'collection_complete': complete, 'eligible_collection_complete': eligible_complete,
        'failure': failure, 'performance_qualification': False}))
    return 0 if eligible_complete else 1


if __name__ == '__main__':
    sys.exit(main())
