Existing HTTP process counters (diagnostic only)

The driver statement that TotalAlloc/Mallocs are not exported is stale: diagnostics.work.memory contains both. This packet derives only matched PID/origin process-interval deltas from the already collected reports. It performs no new runtime work. The counters include process-wide background/diagnostic work between snapshots and use a broader boundary than timed requests; normalized values are not pure request B/op or acceptance evidence. Native Hybrid has no After snapshot, so its deltas remain null. Top-level allocation metrics and qualification stay null.

Source contracts: consumer-canonical/TreeDB/internal/workstats/stats.go:144-188; TreeDB/documentservice/diagnostics.go:85-88; cmd/treedb-document-service/command_public_bench_test.go:246-269,626-643.

| Slot | Process bytes delta / completed request | Process mallocs delta / completed request |
|---|---:|---:|
| 01-http-keyword-r1-B | 745117.808 | 2644.947 |
| 02-http-keyword-r1-L | 271899.056 | 2577.363 |
| 03-http-keyword-r1-N | 419532.352 | 3363.042 |
| 04-http-dense-r1-B | 323066.256 | 971.542 |
| 05-http-dense-r1-L | 127292.824 | 960.345 |
| 06-http-dense-r1-N | 311337.152 | 2040.707 |
| 08-http-hybrid-r1-L | 378568.704 | 2962.609 |
| 09-http-hybrid-r1-N | None | None |
