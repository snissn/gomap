# Causal cell 1: caching attribution (source only)

The refusal is a real foreground coexistence peak. It is not evidence of one leaked reader per successful request. No caching-only teardown/retry repair is supported by this cell.

## Observed original owner accounting

The first refusal at serve.log:7 is parent budget `0x1c6263f704e0`, cache workspace `0x1c626401c870`, dictionary producer `3005277357160178422`, raw 19,833,056 / charged 19,833,088 bytes. Reserved 47,803,200 + requested 19,833,088 = 67,636,288, exceeding 67,108,864 by **527,424**. Retirement and total predicates pass. Views=0 is not absence of a native capture: the native capture owns an external lease rather than a public Snapshot view count.

Before the HTTP error at line 2421, the original request refunds **1,020,656 bytes / 26 parent leases**, ending at **46,782,544 / 14**, below initial warmup **46,851,072 / 17**. Parent refunds (not shutdown):

| Actual cleanup owner | Bytes | Leases |
| --- | ---: | ---: |
| Failed new dictionary definition owner | 287,040 | 2 |
| Private catalog OwnedMapCompletion | 334,688 | 19 |
| Private catalog nativeEngineRefund | 1,056 | 1 |
| NativeSemanticCapture | 96 | 1 |
| NativeJSONRead scratch | 34,880 | 2 |
| CollectionReadView operation scope | 362,896 | 1 |

There is no parent codec/workspace close on this request unwind. The 21 interleaved child-budget refund markers before error belong to physical-maintenance retention work; the fixed parent reservation remains unchanged. Do not add those child refunds to parent headroom.

The observer begins logging refunds only after the first refusal. It therefore cannot reconstruct all prior acquisitions or prove that prior requests never caused a permanent legitimate change. It does show the failed request itself fully returns temporary accounting, with no cumulative leak established.

## Original decoder and basis lifecycle

`cow_read_workspace.go:289–337` already retains/reuses matching producer capacities and, under the original cache physical mutex, detaches/closes incompatible generic codecs or the same producer's undersized codec **before** new admission. The refusing call is the shared cache workspace: `readPhysicalLeafWithDictionary` calls `shared.readInspected` at lines 788–801. It is not a generic decoder on the original basis reader. The original basis and captured file remain authority; independent dictionary bytes have their own owner and are released on admission failure (lines 343–385).

The borrowed-reader-only idle-trim branch at lines 376–382 does not apply: shared workspace has snapshot=nil/basis=nil, and already holds physicalMu. Adding the same TryLock cleanup there cannot obtain that mutex and cannot release a generic owner already removed by the existing pre-admission loop. No new retry is justified.

A later shutdown record identifies the SAME shared workspace's remaining small block decoder receipt as 65,792 bytes (line 15636); no 20 MB idle generic receipt is observed. This is lifetime/identity evidence only, not pre-error headroom. Even removing that whole block receipt would leave **461,632 bytes** of this admission deficit and destroy useful warmed reuse. Do not select it as a fix.

`cow_cut.go:68–105` closes basis scratch only at the last original basis reference; request capture release alone must not destroy scratch or file/pin authority still belonging to the current cut. Subsequent background adoption drains the old basis through `adoptPrivateCOWLeafBasis`; no evidence authorizes early release of its live snapshot/metadata.

## Maintenance and the late request

`cow_leaf_maintenance.go:163–168,185–194,228–273` can pack/rewrite, adopt the actual replacement basis, and then GC/adopt again without changing the logical command frontier. The failing stack reads a dictionary-coded leaf in file 6 and concurrent child refund stacks are from recoverable-root generation enumeration/GC. This supports the structural trigger: identical logical requests can encounter a newly published physical dictionary producer. The retained log does not establish the exact first publication/cache-miss moment; it cannot distinguish a freshly adopted dictionary leaf from a later miss of a previously verified page. That distinction is unnecessary for the proven required new-decoder peak.

`cow_budget.go:101–147` reserves the maintenance partition once in the parent and returns it only when the original child closes and control ownership ends. Its roughly 32 MiB parent reservation is not idle scratch transferable to an ordinary query. No proportional refund, flush, checkpoint, cap change or partition borrowing is authorized by this evidence.

## Smallest coherent next decision

Keep caching owner/admission semantics unchanged. Let the collections owner assess original-capture persistent catalog bootstrap/current-cut reuse: the observed private catalog maps+engine cost is **335,744 bytes**, which alone is **191,680 bytes short** of this request's deficit. A valid repair must prove another legitimately eliminated or shortened cohort; it may not assume all 362,896 operation-scope bytes are optional. Preserve the dictionary definition and complete decoder admission, original CRC/provider/file checks and held-view authority. The current public causal cell is enough to motivate that structural owner repair; no broad observer rerun or new caching mechanism is warranted here.

The companion JSON seals original source hashes, full relevant parent markers and exact arithmetic. Root owns runtime/integration; this followup made no canonical edits and invoked no Go/runtime.
