#!/usr/bin/env python3
"""One original-workload causal cell; diagnostic only, no retries or acceptance."""
import sys
sys.dont_write_bytecode=True
import importlib.util,json,pathlib,os,subprocess,hashlib
ROOT=pathlib.Path('/mnt/fast4tb/gomap-mongo-execution-20261024')
HERE=ROOT/'evidence/command-projection-v2/sustained-hybrid-failure1'
PREV=ROOT/'evidence/command-projection-v2/original-command-eligible-diagnostic1'
SOURCE=ROOT/'command-diagnostic-source1'
GO_ROOT=pathlib.Path('/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.linux-amd64')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def loadmod(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
helper_path=ROOT/'evidence/native-query-work-witness1/run.py'
assert sha(helper_path)=='1b0d99b3cb70c785fcd9faa0453ccc82b3cda2b6c5fb20ccb955dd92aa6e1132'
runner_path=ROOT/'evidence/command-projection-v2/original-command-eligible1/run.py'
assert sha(runner_path)=='7b35dcd3536297a51ce2908697693b223a7b7bd00cd8c0b402612f1b8ea96c97'
h=loadmod('root_process_helper',helper_path);r=loadmod('reviewed_command_helpers',runner_path)
assert os.path.ismount('/mnt/fast4tb') and os.access(ROOT,os.W_OK)
assert not r.competing_go(),'No Go build or cell starts while known Go work is observed'
out=HERE/'causal-cell1';out.mkdir();(out/'bin').mkdir()
contract=json.loads((PREV/'contract.json').read_text());binding=contract['sources']['candidate']
state=r.source_state(binding,'diagnostic15');inventory=r.inventory(binding)
assert inventory==json.loads((PREV/'source-files-before.json').read_text())['candidate']
r.write(out/'source-before.json',state);r.write(out/'source-files-before.json',inventory)
obs=HERE/'observer1';cache=json.loads((obs/'caching-refusals-bindings.json').read_text())
originals=[(SOURCE/'TreeDB/internal/memtable/cow_budget.go',obs/'cow_budget.diagnostic.go')]
originals += [(SOURCE/x['path'],pathlib.Path(x['replacement'])) for x in cache['files']]
formatted=out/'formatted';formatted.mkdir();replace={}
for src,replacement in originals:
 dest=formatted/src.name;dest.write_bytes(replacement.read_bytes());replace[str(src)]=str(dest)
env=h.safe_env({'GOROOT':str(GO_ROOT),'GOTOOLCHAIN':'local','GOMAXPROCS':'4','GOCACHE':str(ROOT/'gocache'),'TMPDIR':str(ROOT/'tmp')})
formatting=h.run_process([str(GO_ROOT/'bin/gofmt'),'-w',*replace.values()],str(SOURCE),env,str(out/'gofmt.log'),60);r.write(out/'gofmt.receipt.json',formatting);assert formatting['process_ok']
overlay=out/'overlay.json';r.write(overlay,{'Replace':replace})
protected={str(p):sha(p) for p in [pathlib.Path(__file__),helper_path,runner_path,overlay,*map(pathlib.Path,replace.values()),GO_ROOT/'bin/go',PREV/'bin/command-driver.test',PREV/'bin/candidate-native']}
plan={'frozen_utc':h.utc(),'kind':'one-cell causal observation; not performance','source':state,'source_files_sha256':sha(out/'source-files-before.json'),'protected_files':protected,'shape':r.SHAPE,'command':'http','operation':'hybrid','role':'N','attempts':1,'original_contract_sha256':sha(PREV/'contract.json'),'original_failure_retained':str(PREV/'09-http-hybrid-r1-N.json'),'observer_originals':[{str(a):sha(a),'diagnostic_unformatted':str(b),'diagnostic_unformatted_sha256':sha(b)} for a,b in originals],'failure_action':'retain any failure/inconclusive result, no unchanged retry or cap/strategy/fixture change','qualification':None}
r.write(out/'plan.json',plan)
binary=out/'bin/diagnostic-http'
build=h.run_process([str(GO_ROOT/'bin/go'),'build','-overlay',str(overlay),'-o',str(binary),'./cmd/treedb-document-service'],str(SOURCE),env,str(out/'build-http.log'),600);r.write(out/'build-http.receipt.json',build);assert build['process_ok'],'diagnostic build failed'
protected[str(binary)]=sha(binary);r.write(out/'binaries.json',{str(p):sha(p) for p in [binary,PREV/'bin/command-driver.test',PREV/'bin/candidate-native']})
known=r.competing_go();r.write(out/'known-go-preflight.json',{'utc':h.utc(),'processes':known});assert not known,'no causal cell starts with known Go work'
for p,digest in protected.items():assert sha(p)==digest,('protected changed',p)
assert r.source_state(binding,'diagnostic15')==state and r.inventory(binding)==inventory
attempt=json.loads((PREV/'09-http-hybrid-r1-N.attempt.json').read_text());cellenv=attempt['environment'];cellenv['GOMAP_COMMAND_PERF_HTTP_BINARY']=str(binary);cellenv['GOMAP_COMMAND_PERF_LABEL']='causal-native-hybrid1';cellenv['GOMAP_COMMAND_PERF_OUTPUT']=str(out/'native-hybrid');cellenv['GOROOT']=str(GO_ROOT);cellenv['GOTOOLCHAIN']='local'
r.write(out/'cell.attempt.json',{'argv':attempt['argv'],'cwd':str(SOURCE),'environment':cellenv,'timeout_seconds':780,'diagnostic_only':True})
receipt=r.measured_process(h,attempt['argv'],str(SOURCE),cellenv,str(out/'cell.log'),780)
receipt['source_unchanged']=r.source_state(binding,'diagnostic15')==state and r.inventory(binding)==inventory
receipt['protected_unchanged']=all(sha(p)==v for p,v in protected.items());r.write(out/'cell.receipt.json',receipt)
report=json.loads((out/'native-hybrid.json').read_text()) if (out/'native-hybrid.json').exists() else {}
serve=out/'native-hybrid.serve.log';seed=out/'native-hybrid.seed.log';serve_text=serve.read_text(errors='replace') if serve.exists() else '';seed_text=seed.read_text(errors='replace') if seed.exists() else ''
summary={'source_unchanged':receipt['source_unchanged'],'protected_unchanged':receipt['protected_unchanged'],'process_ok':receipt['process_ok'],'exit_code':receipt['exit_code'],'cleanup':receipt['cleanup'],'known_go_observations':receipt['competing_go_observations'],'phase':report.get('Phase'),'completed':report.get('Completed'),'failure':report.get('Failure'),'failed_operation':report.get('FailedOperation'),'serve_first_refusal_count':serve_text.count('first_refusal'),'seed_first_refusal_count':seed_text.count('first_refusal'),'serve_resource_refusals':serve_text.count('cow_resource_refusal'),'serve_refunds':serve_text.count('COW_ADMISSION_OBSERVER refund'),'qualification':None,'interpretation':'Causal instrumented result only. Original failed cell and seven valid diagnostics remain unchanged. No performance acceptance or retry.'}
r.write(out/'summary.json',summary);print(json.dumps(summary,indent=2))
