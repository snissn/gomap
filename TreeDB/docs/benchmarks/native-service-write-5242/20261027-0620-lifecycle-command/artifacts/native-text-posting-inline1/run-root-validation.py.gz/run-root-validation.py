import importlib.util
import json
import pathlib
import signal
import subprocess
import sys

ROOT = pathlib.Path('/mnt/fast4tb/gomap-mongo-execution-20261024')
WORK = ROOT / 'consumer-canonical'
PACKET = pathlib.Path(__file__).parent
spec = importlib.util.spec_from_file_location('owned_process', ROOT / 'evidence/native-query-work-witness1/run.py')
H = importlib.util.module_from_spec(spec)
spec.loader.exec_module(H)
signal.signal(signal.SIGTERM, H.interrupted)
signal.signal(signal.SIGINT, H.interrupted)

def source():
    paths = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=WORK, text=True).splitlines()
    paths += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
    return {'head': H.git(WORK, 'rev-parse', 'HEAD'), 'head_tree': H.git(WORK, 'rev-parse', 'HEAD^{tree}'),
            'staged_tree': H.git(WORK, 'write-tree'), 'status': H.git(WORK, 'status', '--porcelain'),
            'changed_files': {n: H.digest(WORK / n) if (WORK / n).exists() else None for n in sorted(set(paths))}}

name, args = sys.argv[1], sys.argv[2:]
assert name.replace('-', '').isalnum()
receipt, log = PACKET / (name + '-receipt.json'), PACKET / (name + '.log')
assert not receipt.exists() and not log.exists()
before = source()
extra_paths = [pathlib.Path(__file__)]
for arg in args:
    if arg.startswith('-overlay='):
        overlay_path = pathlib.Path(arg.split('=',1)[1])
        extra_paths += [overlay_path, *map(pathlib.Path, json.loads(overlay_path.read_text())['Replace'].values())]
extra_before = {str(f):H.digest(f) for f in extra_paths}
command = ['/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.linux-amd64/bin/go',
           'test', '-json', '-count=1', '-timeout=6m', *args]
H.write_json(PACKET / (name + '-plan.json'), {'source': before, 'extra_source':extra_before, 'command': command, 'outer_wall_seconds': 600,
    'scope': 'Posting local-owner transfer controls. Original-source-compatible characterization and existing transfer/parity controls; no fabricated semantic RED or compiler escape claim. Public allocation/time discriminator remains required; original native promises unchanged.'})
env = H.safe_env({'GOROOT': '/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.linux-amd64',
    'GOTOOLCHAIN': 'local', 'GOMAXPROCS': '4', 'GOCACHE': str(ROOT / 'gocache'), 'TMPDIR': str(ROOT / 'tmp')})
result = H.run_process(command, str(WORK), env, log, 600)
result.update(source_before=before, source_after=source(), extra_source_before=extra_before, extra_source_after={str(f):H.digest(f) for f in extra_paths})
result['source_unchanged'] = result['source_before'] == result['source_after'] and result['extra_source_before'] == result['extra_source_after']
H.write_json(receipt, result)
print(json.dumps({k: v for k, v in result.items() if k not in ('source_before', 'source_after', 'extra_source_before', 'extra_source_after')}))
sys.exit(0 if result['process_ok'] and result['source_unchanged'] else 1)

