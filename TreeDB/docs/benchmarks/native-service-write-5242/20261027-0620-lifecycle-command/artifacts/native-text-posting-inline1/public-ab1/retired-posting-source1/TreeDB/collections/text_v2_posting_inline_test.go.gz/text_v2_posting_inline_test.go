package collections

import (
	"fmt"
	"slices"
	"testing"
)

// Completed postings must retain their own frequency lanes after a later
// document uses either inline or spilled term descriptors. Both maintained
// inputs feed the same posting builder; no accumulator descriptor is output.
func TestTextV2PostingBatchCompletedDocumentsSurviveInlineAndSpill(t *testing.T) {
	for _, prepared := range []bool{false, true} {
		t.Run(fmt.Sprintf("prepared=%v", prepared), func(t *testing.T) {
			def := TextIndexDefinition{Fields: []TextIndexField{{Field: "title"}, {Field: "body"}}}
			counts := []int{1, 16, 17, 1, 41, 16}
			var builder textV2PostingBatchBuilder
			for doc, count := range counts {
				analysis := textAnalyzedDocument{Fields: []textAnalyzedField{
					{Field: "body", Terms: make(map[string]*textAnalyzedTerm)},
					{Field: "title", Terms: make(map[string]*textAnalyzedTerm)},
				}}
				for term := 0; term < count; term++ {
					name := fmt.Sprintf("term-%02d", term)
					analysis.Fields[0].Terms[name] = &textAnalyzedTerm{Term: name, Frequency: uint32(2*doc + 1)}
					analysis.Fields[1].Terms[name] = &textAnalyzedTerm{Term: name, Frequency: uint32(doc + 1)}
				}
				var err error
				if prepared {
					err = builder.addDocumentState(def, uint64(doc+1), uint64(doc+11), textDocumentStateValueFromAnalysis(analysis))
				} else {
					err = builder.addDocument(def, uint64(doc+1), uint64(doc+11), analysis)
				}
				if err != nil {
					t.Fatalf("document %d: %v", doc, err)
				}
				// The builder derives frequencies; completed output must not
				// borrow the mutable analysis term descriptors either.
				for _, field := range analysis.Fields {
					for _, term := range field.Terms {
						term.Frequency = 999
					}
				}
			}
			if builder.fieldCount != 2 || len(builder.byTerm) != 41 {
				t.Fatalf("field/term count: %d/%d", builder.fieldCount, len(builder.byTerm))
			}
			for term := 0; term < 41; term++ {
				name := fmt.Sprintf("term-%02d", term)
				entries := builder.byTerm[name]
				entryIndex := 0
				for doc, count := range counts {
					if term >= count {
						continue
					}
					if entryIndex >= len(entries) {
						t.Fatalf("%s missing document %d", name, doc)
					}
					entry := entries[entryIndex]
					wantFields := []uint32{uint32(doc + 1), uint32(2*doc + 1)}
					if entry.Ordinal != uint64(doc+1) || entry.Generation != uint64(doc+11) || entry.TermFrequency != uint32(3*doc+2) || !slices.Equal(entry.FieldFrequencies, wantFields) {
						t.Fatalf("%s document %d: %+v want fields %v", name, doc, entry, wantFields)
					}
					entryIndex++
				}
				if len(entries) != entryIndex {
					t.Fatalf("%s has %d entries want %d", name, len(entries), entryIndex)
				}
			}
		})
	}
}
