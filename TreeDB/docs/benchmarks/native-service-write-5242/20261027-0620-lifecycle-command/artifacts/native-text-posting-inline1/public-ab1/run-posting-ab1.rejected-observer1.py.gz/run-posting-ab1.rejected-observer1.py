import importlib.util
import json
import pathlib
import re
import signal
import statistics
import subprocess
import sys
import threading

ROOT = pathlib.Path('/mnt/fast4tb/gomap-mongo-execution-20261024')
WORK = ROOT / 'consumer-canonical'
PACKET = pathlib.Path(__file__).parent
if sys.argv[1:] != ['--execute']:
    raise SystemExit('Requires --execute and a frozen posting-ab-plan1.json; no work executed')
spec = importlib.util.spec_from_file_location('owned_process', ROOT / 'evidence/native-query-work-witness1/run.py')
H = importlib.util.module_from_spec(spec)
spec.loader.exec_module(H)
signal.signal(signal.SIGTERM, H.interrupted)
signal.signal(signal.SIGINT, H.interrupted)
PLAN = PACKET / 'posting-ab-plan1.json'
plan = json.loads(PLAN.read_text())
assert plan['status'] == 'frozen'
assert plan['fixed_order'] == ['before', 'after', 'after', 'before'] and plan['retries'] == 0
assert not (PACKET / 'ab-result2.json').exists()


def source():
    paths = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=WORK, text=True).splitlines()
    paths += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
    return {'head': H.git(WORK, 'rev-parse', 'HEAD'), 'head_tree': H.git(WORK, 'rev-parse', 'HEAD^{tree}'),
            'staged_tree': H.git(WORK, 'write-tree'), 'status': H.git(WORK, 'status', '--porcelain'),
            'changed_files': {n: H.digest(WORK / n) if (WORK / n).exists() else None for n in sorted(set(paths))}}


start = source()
assert start == plan['source_binding']
race_path = PACKET / plan['changed_risk_receipt']
assert H.digest(race_path) == plan['changed_risk_receipt_sha256']
race = json.loads(race_path.read_text())
assert race['process_ok'] and race['source_unchanged'] and not race['cleanup']['alive_after_cleanup']
assert race['source_before'] == race['source_after'] == start
assert H.digest(WORK / plan['harness']) == plan['harness_sha256']
overlay_path = PACKET / plan['control_overlay']
assert H.digest(overlay_path) == plan['control_overlay_sha256']
overlay = json.loads(overlay_path.read_text())['Replace']
assert list(overlay) == [str(WORK / 'TreeDB/collections/text_v2_write_path.go')]
assert {p: H.digest(pathlib.Path(p)) for p in overlay.values()} == plan['control_source_sha256']
extra = {str(PLAN): H.digest(PLAN), str(pathlib.Path(__file__)): H.digest(pathlib.Path(__file__)),
         str(overlay_path): H.digest(overlay_path), **plan['control_source_sha256']}


def unchanged():
    return source() == start and all(H.digest(pathlib.Path(p)) == digest for p, digest in extra.items())



def competing_go():
    try:
        result = subprocess.run(['ps', '-C', 'go', '-o', 'pid=,ppid=,pgid=,etimes=,comm='], text=True, capture_output=True, timeout=5)
    except (OSError, subprocess.TimeoutExpired) as error:
        return ['observer_error:' + type(error).__name__]
    if result.returncode not in (0, 1):
        return ['observer_error:ps_exit_' + str(result.returncode)]
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def measured_process(argv, env, log, wall):
    observations = []
    stopped = threading.Event()
    def observe():
        while not stopped.is_set():
            found = competing_go()
            if found:
                observations.append({'utc': H.utc(), 'processes': found})
            stopped.wait(1)
    thread = threading.Thread(target=observe, daemon=True)
    thread.start()
    try:
        receipt = H.run_process(argv, str(WORK), env, log, wall)
    finally:
        stopped.set()
        thread.join(timeout=5)
    receipt['competing_go_observations'] = observations
    return receipt


go_root = pathlib.Path(plan['toolchain'])
env = H.safe_env({'GOROOT': str(go_root), 'GOTOOLCHAIN': 'local', 'GOMAXPROCS': str(plan['gomaxprocs']),
                  'GOCACHE': str(ROOT / 'gocache'), 'TMPDIR': str(ROOT / 'tmp')})
elfs = {arm: PACKET / plan[arm + '_binary'] for arm in plan['arms']}
for arm, elf in elfs.items():
    assert not elf.exists() and unchanged()
    argv = [str(go_root / 'bin/go'), 'test', '-c', '-p=1']
    if arm == 'before':
        argv += ['-overlay=' + str(overlay_path)]
    argv += ['-o', str(elf), './TreeDB/documentservice']
    receipt = H.run_process(argv, str(WORK), env, PACKET / (arm + '-build2.log'), plan['build_wall_limit_seconds'])
    receipt['source_and_overlay_unchanged'] = unchanged()
    H.write_json(PACKET / (arm + '-build2-receipt.json'), receipt)
    assert receipt['process_ok'] and receipt['source_and_overlay_unchanged'], 'Build failed; no measurement started'
    print(json.dumps({'stage': 'build', 'arm': arm, 'elapsed_seconds': receipt['elapsed_seconds']}), flush=True)
hashes = {a: H.digest(f) for a, f in elfs.items()}
H.write_json(PACKET / 'ab-binary-binding2.json', {'source': start, 'elf_sha256': hashes, 'extra_sha256': extra,
                                              'go_sha256': H.digest(go_root / 'bin/go'), 'both_arms_share_lifecycle_repair': True})
rows, receipts = [], []
for i, arm in enumerate(plan['fixed_order'], 1):
    assert unchanged() and all(H.digest(f) == hashes[a] for a, f in elfs.items())
    competing = competing_go()
    if competing:
        H.write_json(PACKET / f'ab-cell-{i:02}-{arm}-not-started.json', {'utc': H.utc(), 'reason': 'known competing Go process before measurement', 'processes': competing, 'source_and_overlay_unchanged': unchanged(), 'attempted': False})
        break
    log = PACKET / f'ab-cell-{i:02}-{arm}.log'
    assert not log.exists()
    argv = [str(elfs[arm]), '-test.v', '-test.run=^$', '-test.bench=' + plan['public_bench'], '-test.benchmem',
            '-test.benchtime=1x', '-test.count=1', '-test.timeout=' + plan['test_timeout']]
    receipt = measured_process(argv, dict(env, GOMAP_SERVICE_BENCH_BACKEND=plan['backend'],
                                                GOMAP_SERVICE_BENCH_PROFILE=plan['profile']), log, plan['process_wall_limit_seconds'])
    raw, parsed = log.read_text(), []
    for line in raw.splitlines():
        match = re.match(r'^(BenchmarkServiceSharedCOWWriteLoad/writers(1|4)-\d+)\s+(\d+)\s+(.+)$', line)
        if match:
            fields = match.group(4).split()
            metrics = {fields[j + 1]: float(fields[j]) for j in range(0, len(fields) - 1, 2)}
            parsed.append({'cell': i, 'arm': arm, 'writers': int(match.group(2)), 'iterations': int(match.group(3)),
                           'metrics': metrics, 'raw': line})
    activation = all(f'backend=native profile=command_wal_durable requested_memtable=cow_btree resolved_strategy=column_graph metric=cosine rows=4096 batch=128 writers={n} defer_rebuild=true' in raw for n in [1, 4])
    completions = all(f'backend=native profile=command_wal_durable writers={n} loads=1 attempted=32 completed=32 request_retries=0' in raw for n in [1, 4])
    workload_valid = receipt['process_ok'] and unchanged() and activation and completions and len(parsed) == 2 and {r['writers'] for r in parsed} == {1, 4} and all(r['iterations'] == 1 and r['metrics'].get('requests/op') == 32 and r['metrics'].get('records/op') == 4096 for r in parsed)
    valid = workload_valid and not receipt['competing_go_observations']
    receipt.update(workload_valid=workload_valid, performance_eligible=valid, arm=arm, elf_sha256=hashes[arm], source_and_overlay_unchanged=unchanged(), activation_verified=activation,
                   durable_request_completions_verified=completions, rows=parsed, valid=valid)
    H.write_json(PACKET / f'ab-cell-{i:02}-{arm}-receipt.json', receipt)
    rows += parsed
    receipts.append(receipt)
    print(json.dumps({'cell': i, 'arm': arm, 'valid': valid, 'elapsed_seconds': receipt['elapsed_seconds'], 'rows': parsed}), flush=True)
    if not valid:
        break
valid = len(receipts) == len(plan['fixed_order']) and all(r['valid'] for r in receipts)
medians = {}
if valid:
    for writers in [1, 4]:
        medians[writers] = {}
        for metric in sorted(rows[0]['metrics']):
            pair = {arm: statistics.median(r['metrics'][metric] for r in rows if r['arm'] == arm and r['writers'] == writers) for arm in plan['arms']}
            medians[writers][metric] = dict(pair, change_percent=(pair['after'] / pair['before'] - 1) * 100 if pair['before'] else None)
result = {'utc': H.utc(), 'valid': valid, 'source_and_overlay_unchanged': unchanged(), 'rows': rows, 'medians': medians,
          'numeric_gate': None, 'qualification': None, 'retries': 0, 'unattempted_slots': plan['fixed_order'][len(receipts):],
          'plan_sha256': H.digest(PLAN), 'both_arms_share_lifecycle_repair': True}
H.write_json(PACKET / 'ab-source-after2.json', source())
H.write_json(PACKET / 'ab-result2.json', result)
print(json.dumps({'stage': 'complete', 'valid': valid, 'medians': medians, 'numeric_gate': None, 'qualification': None}), flush=True)
sys.exit(0 if valid and result['source_and_overlay_unchanged'] else 1)
