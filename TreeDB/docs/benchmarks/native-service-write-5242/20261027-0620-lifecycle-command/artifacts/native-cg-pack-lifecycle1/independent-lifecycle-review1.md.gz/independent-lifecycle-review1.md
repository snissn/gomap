# Independent lifecycle source review

Reviewer: /root/final_span_review. Verdict: ACCEPT scoped source/accounting; no material finding. This records the independently returned review, not runtime or performance acceptance.

Original complete constructor P, malformed-format validation and independent read/schema receipts remain unchanged. Only ErrCOWCapacity plus actual idle generic scratch detachment permits one identical pack reservation retry. Cleanup uses the existing physicalMu borrower exclusion and drops decoder references before refund.

Only complete successful maintained opening permits a same-original-lease phase shrink. R includes actual mapped page extent or heap, flat view and per-allocation chunk capacities, original state/control floors, manager/handle/private map controls, file/private backing/release closure, retained strings and original live-pin registration policy. Unsupported shapes, layout or overflow keep P. Existing error/Close ordering remains intact. No further compact simplification is necessary.

The unchanged process-global striped namespace-path cache has an independent owner and no pack enrollment/refund. It is excluded from this incremental refund; a later lookup is not guaranteed to hit. This is not a whole-process RSS or zero-global-retention claim.

Reviewer verified actual Go1.26.0 map/file source addendum and unchanged dependencies, plus raw-to-canonical whitespace-only formatting. The frozen stronger oldImage test remains unchanged. No reviewer edits or runtime.

Reviewed canonical SHA256:

- TreeDB/caching/cow_read_workspace.go: f73b837d77cfe37a7fbcf63cd78988f3a3bfbb5512d1bca66d6ffbde9cd88c4c
- TreeDB/caching/cow_native_semantic.go: d4cd16fa5a1229eace9f8fac3054b8d8f194708ea4feaa67451da70d5dfdedf7
- TreeDB/collections/native_ordinary_columngraph_search.go: 0588e0c932b1d2ba7269842ce52d56ce7bf7c3f5ee177d270ffa1ae67a341cb3
- TreeDB/internal/mappedresource/manager.go: 91fd19e7e5db78439434323e6c3d312bfb7712eb2fdc0ee750d052ee0c87227e
- TreeDB/caching/cow_native_idle_decoder_test.go: e31de5dc06e0409a2e3fd3e482be35b984c773a86a5ddbfbb3bf8b8f2c522361
- TreeDB/collections/native_ordinary_columngraph_pack_phase_test.go: b9235b58ac161f3b9d87adb75ec5334a01bdded20c96cd40bdefd685e0eb8ef3

Implementation manifest f5b6f58b992e03e774f93b1897c7ec6a204050c3e80abf05c7ea92fee8ce54b0. Formatting binding 0142d26012d477c0846b6a8df4fd8be1ec8241fdbde6b8c2a01e19f421e38a3d. Target addendum bd11583c529a67bf00769153d96924033707e6613e09d97666b0abd62ebf0fdb.
