# Actual designated Go 1.26.0 target source binding

Source-only followup; implementation1 and its proof/manifest/source remain immutable. Production edits stopped before this addendum.

Designated source: /home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.linux-amd64/src. The map Map definition/small-map construction, group implementation, ABI group constants and internal/poll/fd_unix.go are BYTE IDENTICAL to the previously bound Go1.26.8 sources. The proof's fresh single-map guard and its 16-pointer-word header/full-eight-slot envelope therefore hold on the designated .0 runtime without a patch-version inference. Map header is 48 bytes on amd64 from its actual fields; group slots=8 and indirect key/value thresholds=128 bytes from actual internal/abi/map.go.

os/file_unix.go is NOT byte identical. Its .8 version adds bool inRoot to private file and changes unrelated directory-entry construction/stat behavior. Actual .0 private file still contains poll.FD, name string, directory-info atomic pointer and three bools. Both sources allocate the public File wrapper and private file with newFile's &File{&file{...}}, initialize poll.FD and install the same finalizer. StableFileMetadataCharge reflects the EXECUTING target's actual os.File/private-field type metadata, so the bound does not assume .8's private size. os/types.go public File pointer-wrapper layout is also checked and bound. The mapped release closure shape belongs to unchanged repository source, not a Go patch-version claim.

No Go/runtime invoked; hashes and relevant source definitions compared directly. Source contract ACCEPT for the designated .0 toolchain. Root retains compile/race/public proof ownership.
