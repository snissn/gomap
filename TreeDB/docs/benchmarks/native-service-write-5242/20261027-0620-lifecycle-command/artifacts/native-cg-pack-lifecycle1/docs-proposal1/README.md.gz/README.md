# Paired native read lifecycle documentation proposal

Static proposal only, based on canonical773a90e6 plus the staged paired decoder/pack lifecycle and local posting accumulator changes. Root integrates after its source-bound measurement. No canonical/donor source or documentation was changed; no Go, gofmt, tests, runtime, Git mutation or GitHub write was performed.

The three proposed spec edits divide responsibilities: cow-cache-publication describes the original capture's nonblocking scratch operation; native-hybrid-read describes full construction admission followed by successful-open-only retained accounting; verification maps the two component controls, existing mapped/heap owner controls and original public4096/cold-reopen race commands. The commands are proposed verification instructions, not executed results. Full constructor validation, original state/control floors, finite64MiB parent/32MiB maintenance-child limits, legitimate refusals and handle-before-receipt cleanup remain unchanged. No default/performance promotion is claimed. Unknown pack shapes keep their original reservation.

The public API support gap is ALREADY FIXED at docs/TREEDB_DOCUMENT_SERVICE_API.md:269–280. It documents durable ordinary native ColumnGraph, zero-scalar FullJSON, effect-free relaxed/noWAL refusal, supported plain CRUD, immediate keyword/filtered-exact reads and explicit graph maintenance. No repeat patch to that guide or the constructor guide is needed.

The text V2 change places each inline accumulator in its final local owner and passes completed term slices to the existing posting builder. Validation, term/frequency semantics, posting format and public APIs remain unchanged. Its new inline/spill ownership control is source-bound in the manifest; a public API guide change would expose an internal allocation choice without changing user decisions. Its A/B and performance acceptance belong to root, not this packet.

FP32 direct publication is retired. The proposal contains no direct-builder claim, command, performance inference or new admission promise. Current generic library/caller hashes are bound for provenance only. Earlier test-plan artifacts containing retired paths remain historical evidence and are not rewritten.

Patch can be reviewed/applied against the three exact before hashes in manifest.json. The source context is frozen by all current staged path hashes and the complete staged diff hash. Rebind if root changes those bytes before integration.
