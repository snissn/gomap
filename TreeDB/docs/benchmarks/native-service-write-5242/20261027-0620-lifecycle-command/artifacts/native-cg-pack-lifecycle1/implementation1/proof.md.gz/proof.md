# Paired original-capture scratch / prepared-pack phase repair

Source-only candidate, base 773a90e6bbcbaf9ecf4d36f076d0d859f3d791b4. No Go, gofmt, build, tests, benchmark, commit, push or GitHub mutation by this worker. Root owns all execution. Frozen component REDs were reported by root; this packet makes no GREEN/product/performance claim.

## Scope and original authority

The original capacity envelope P is unchanged:

    P = 16 Q(asset.Ref.Length) + stateBacking + retainedCharge
    stateBacking = 16 (schemaBacking(state) + schemaBacking(graph))

The operation setup, temporary document-ID decoder, original read/capture/schema receipts, state/graph floors and control floor are unchanged. Parent 64 MiB and maintenance child 32 MiB remain unchanged. No raw #5243/#5244 dependency, new cache, owner, allocator backpointer, recapture, hidden flush/checkpoint, new reader or admission policy.

On original full-P Resize ErrCOWCapacity ONLY, collections asks the ORIGINAL capture for optional TryReleaseIdleNativeReadScratch. The cache uses physicalMu.TryLock, the exact prior generic-only eviction predicate, detaches the codec slot, closes decoder/definition/output and refunds its same original receipt. Busy readers return false immediately. Small raw Snappy/LZ4 block codecs remain. Allocator and receipt remain cache-free. Only an actual released generic codec permits one same-target Resize retry; there is no unchanged retry or loop. No proactive invalidation when full P already fits.

All cache-owned codec borrowers use physicalMu. Extraction reuses the existing fallback used by borrowed codec admission; no new synchronization order is introduced. The live capture protects the containing cache. Concurrent Close of the same capture is outside its existing unsynchronized borrow contract; different borrowers are protected by physicalMu. Definitions and buffers are detached before their receipt closes.

## Success-only retained ledger

ONLY after openCollectionVectorIndexPreparedExactSearchPack returns successfully, compute:

    R = retainedCharge + stateBacking + Rpack

Use ShrinkNativeBytes(P-R, R) on the SAME lease only if complete supported census and R<P. Preserve its receipt header (the primitive does so). Never grow after construction. Unsupported shape, overflow, unknown file layout or nonbeneficial R keeps P intact. Opener failure has no refund; any shrink refusal closes the prepared handles before the original outer lease cleanup. Cache publication occurs after this phase boundary. Warmed pack handles remain cached and reusable.

Rpack consists of separately rounded allocations, not rounded raw sums:

1. Q(handle.AccountedBytes): actual page-rounded mapping extent including alignment prefix; heap fallback uses the actual exact make length. Not merely header TotalLength.
2. Q(prepared view), Q(cap Sections * sizeof section), Q(cap AdjacencyLayers * sizeof layer), Q(cap adjacencyOffsetChunks * sizeof chunk), Q(cap adjacencyNeighborChunks * sizeof chunk).
3. Every fixed or layer chunk separately pays Q(cap values * sizeof slice header) plus Q(cap starts * sizeof uint64). This includes eight fixed chunks and both chunks for each layer. All typed value arrays, row references, document IDs and V3 auxiliary navigation alias the one file extent; no second payload backing is retained by the flat opener.
4. Q(Handle), Q(Manager), and two independently rounded manager-entry and global-entry reserves, reproducing the existing ConservativeHandleMetadataBytes contract with per-component rounding instead of rounding one aggregate. Private active-map header/group are additionally paid, so the indirect Pin object is conservatively overpaid rather than omitted.
5. Fresh Manager private-map backing: each extant map gets Q(16 pointer words) for its header plus Q(8*(key size+value size)+2 pointer words) for its entire first group. Actual success history is checked: one total acquire, nextID=1, one active handle, zero release, no denied entry, at most one fallback and one validation entry. Stats maps never delete keys, so these guards exclude prior growth histories. Go 1.26 Map is 48 bytes on amd64 and its small form is one eight-slot group without table/directory; the bound also dominates indirect Pin slots plus their separately paid Pin. Source bindings include actual Go 1.26.8 map/abi definitions. This is a bounded fresh-manager observation, not a general map-accounting API.
6. Separately Q every retained Key/Section/Scope/Pin string and each private stat-map key. Immutable aliases may be double-paid. Include full Pin.Path, Root, scope ID and collection/namespace strings.
7. Mapped case: maintained rootpublication.StableFileMetadataCharge(len(path)) covers os.File wrapper, target-derived private os.file/poll.FD backing and diagnostic path. Q of the actual source closure shape (entry pointer, mapped slice, file pointer, manager pointer). Additionally reserve twice the mmap registration entry (pointer+slice). Heap fallback has already closed its file and has no release closure, so no file remains to pay.
8. Q(len(prepared key)), assembled after the original control prelude. The unchanged control floor still pays prepared/cache-entry/cache-slot/channel/map controls and cloned definition/response strings; untouched state/graph floor is preserved in full, even though most of that decoded state does not escape the opener.

SingleFileRetainedCharge is ONLY for AcquireFileRange results, not borrowed AcquireBytes. Flat caller proves this route from the maintained opener. It rejects foreign source shapes and histories; collections rejects multi-handle/chunked/ephemeral/external-vector/quantized/searcher/captured-base shapes and retains P. It does not inspect storage a second time or parse wire metadata again. Q and all variable multiplications/sums are checked; failure keeps P.

The new metadata observer takes Handle.mu then Manager.mu, matching existing Handle.Release -> manager.release. It never takes physicalMu or budget locks. No callback enters the capture from an allocator. OS/runtime bookkeeping keeps the existing file/handle accounting policy; this is an owned-backing quota ledger, not whole-process RSS.

## Constructor, corruption, format and failure custody

Full P remains before opening/mapping/parsing. CRC, exact file range/key, manifest/base identity, section directory/ranges/shape checks, V3 navigation validation, V6 partition connectivity validation, row and document-ID checks execute unchanged. Their temporary directory/range/seen/queue/validation allocations remain protected through the complete helper return. No malformed or unsupported-format input gets construction credit. The bound does not assume only V1 or omit V3/V6 peaks. A successful supported flat V3/V6 view has the same alias/descriptor retained ledger; other layouts keep P.

Close order remains existing prepared Close: release file handles and drop pack before original nativeLease.Close. Existing cache invalidation/shared reader locks govern last-use; this change introduces no eager pack eviction. Global pin registrations use the maintained per-handle bound, and release remains unchanged.

## Unchanged independently owned process cache

The fixed striped namespace-path cache is outside the original per-pack reservation. It can miss/reconstruct during open; exclusion does NOT rely on prewarming. No new reference to its cache owner is introduced. Every actual path retained by the pack/file/closure/pin is paid above. This does not assert whole-process RSS bounds, cache deletion, or global-zero memory after Close.

## Test bindings and remaining execution

The two test-first files are byte-identical to test-first1. Root reports both baseline REDs reached intended terminal assertions after semantic/Close checks. They cover a real rewrite-produced generic dictionary decoder, busy TryLock refusal, exact finite lease refusal/retry, owned bytes after reconstruction, no-op empty trim, original lease closure and final budget zero; and actual flat pack warm reuse/fetch/Close custody.

The 512-row terminal image-only oracle remains UNCHANGED. Its exact sufficient inequality is R < 16 Q(image). A legitimate full-P refund requires only R<P, so that assertion is stronger than the lifecycle contract whenever the unchanged state/control floors are material. Source alone does not establish the fixture's numeric inequality. If it fails solely for that reason, retain original RED and record a source-required test correction against complete original P; do not silently weaken or reprice floors.

Root next: format/copy only four production paths plus exact test packet, compile/component GREEN and independent source/accounting review, then original BOTH-role public4096/fixed128 race lifecycle without a favorable retry campaign. Use the SAME paired lifecycle source in generic/direct A/B builds so the FP32 dispatch effect is isolated. Keep failed original receipts. Check original finite refusal/error cleanup, malformed packs, supported mmap/heap paths and concurrent cache Close. No public success or performance benefit is inferred from this source packet.

This supersedes retained-floor-checkpoint1 ONLY on the clarified independently owned process-cache scope; the old negative checkpoint remains intact.
