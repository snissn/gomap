import sys
sys.dont_write_bytecode=True
import pathlib,os,subprocess,json,hashlib,datetime
ROOT=pathlib.Path('/mnt/fast4tb/gomap-mongo-execution-20261024');p=ROOT/'evidence/command-projection-v2/sustained-hybrid-failure1/fresh-read-profile1/run1';o=p/'renders1';o.mkdir(exist_ok=False);g=pathlib.Path('/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.linux-amd64');binary=ROOT/'evidence/command-projection-v2/original-command-eligible-diagnostic1/bin/candidate-http';env={k:os.environ[k] for k in ['PATH','HOME','USER','LANG','LC_ALL'] if k in os.environ};env.update(GOROOT=str(g),GOTOOLCHAIN='local',GOWORK='off',GOCACHE=str(ROOT/'gocache'),TMPDIR=str(ROOT/'tmp'));rows=[]
for cell in ['01-http-keyword-L','02-http-keyword-N']:
 for metric in ['cpu','alloc_space','alloc_objects']:
  args=[str(g/'bin/go'),'tool','pprof','-top','-cum','-nodecount=45']
  paths=[binary]
  if metric=='cpu': paths.append(p/(cell+'.server-cpu.pprof'))
  else:
   args += ['-sample_index='+metric,'-base',str(p/(cell+'.server-allocs-before.pprof'))];paths.extend([p/(cell+'.server-allocs-before.pprof'),p/(cell+'.server-allocs-after.pprof')])
  args += [str(binary),str(paths[-1])];name=o/(cell+'-'+metric+'.txt');start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with name.open('x') as output:r=subprocess.run(args,env=env,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,timeout=60)
  row={'argv':args,'exit_code':r.returncode,'start_utc':start,'inputs':{str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in paths},'output':str(name),'output_sha256':hashlib.sha256(name.read_bytes()).hexdigest()};rows.append(row);assert r.returncode==0
(o/'receipt.json').write_text(json.dumps({'kind':'existing diagnostic profile rendering; no new workload or acceptance','rows':rows},indent=2)+'\n')
print('six cumulative CPU/allocation renders completed')
