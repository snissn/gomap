# Independent bounded COW decoder adapter repair2 review

**REJECT — material warm-route admission regression (P1), plus one ineffective refusal control (P2).** Static/source/accounting review only; no Go/gofmt/import/build/test/runtime/profile or source modification. Root supplied the focused2 failure observations; those are not independently executed results.

## P1: a warmed matching dictionary codec now requires fresh admission

`TreeDB/internal/valuelog/cow_bounded_decoder.go:295–296` completes every successful read by resetting with an empty dictionary. The selected upstream `zstd/decoder_bounded.go:1324–1427` clearBounded(false) clears history/Huffman/dictionary/literal storage and refunds dependent retained allocations, then permits a new binding. Therefore the next same-dictionary Decode at adapter line284 must parse/re-admit dictionary tables again. `cow_read_workspace.go:316–325` still treats matching input/raw capacity as a reusable warmed codec, while its original callers do not reserve an extra per-read dictionary construction peak.

This affects existing, concrete admission guarantees. `cow_native_physical_read_test.go:350–370` fills remaining budget AFTER warming the real decoder, then expects the original output admission callback to receive the exact output charge and refuse. `cow_native_physical_read.go:nativeValueAtPointer` decodes before that callback: the new dictionary Retain can refuse first, so the original output callback is never reached. Root reports precisely that failure. `cow_ordered_leaf_dictionary_test.go:391–450` warms the local dictionary decoder and leaves exactly the established fresh-lane/local-point capacity. Refunding the fresh lane alone now cannot make the reused local decoder’s additional dictionary construction fit. Root reports both busy-primary variants refusing there. These are real changed warm-route behaviors under original receipts/headroom, not obsolete or implementation-mirroring assertions. Preserve the original admitted warm-read/local fallback behavior while keeping complete SAME-ledger charging; this review does not prescribe a broader redesign or relax the caps.

## P2: post-constructor refusal test does not force a retention effect

`cow_bounded_decoder_test.go:109–127` leaves1024 bytes of spare budget and decodes a highly repetitive dictionary-free fixture, asserting an allocation refusal/closed decoder. That payload is not a witness that a bounded Retain must occur: upstream raw/simple-sequence/RLE paths can use caller raw output and existing fixed tables without growing retained backing. Root’s reported nil error, closed=false and retained66048 is consistent with precisely the two original fixed control/continuation charges and does not itself indicate missed allocation accounting. A source-bound payload/phase requiring real additional backing is needed to make this intended partial-operation refusal control meaningful. The existing constructor refusal and phase-only-yield controls retain their independent value.

## Scoped invariants otherwise established

The adapter admits its Sizeof wrapper and complete caller raw/input capacities first; every upstream concrete retention grows the SAME original COWExternalLease through bounded ResizeWork. The independent dictionary owner (or original retained snapshot for captured-only local readers) outlives decoder Close; definition producer authentication and complete dictionary grammar are preserved. No global dictionary cache, alternate receipt, generic fallback, cap increase or quota discount was introduced. The original generic COWDecoder path itself is unchanged; Snappy/LZ4 still select their original block kernel.

Original producer/shape/codec/input/output checks, exact returned output length/backing and maintained decoded/window limits remain. Successful Reset removes caller input/raw aliases before caller buffer reuse; error Close removes them before refund. Close is serialized with Decode, releases upstream continuation after alias detachment, drops the final exported decoder control pointer before its charge, and leaves wrapper/input/raw base accounting with the original containing codec. Cache cleanup closes decoder before buffers/definition/receipt. Constructor errors unwind through the same path, and actual capacity errors are not retried as scheduling pauses.

Repair2 correctly distinguishes a real failed Reserve on an unused quantum from legal finite phase-only Huffman cleanup yields. The selected empty huff0.TableState.ClearStep phase1 advances with no Reserve, so its false return must continue. Oversized actual units still refuse finitely; the added direct phase control exercises this real distinction. Per-callback work is bounded by the maintained ResizeWork primitive; the finite256-record/4MiB scheduling quanta replenish the same continuation rather than imposing an invented aggregate read-work cap. No source-based continuation/accounting-undercharge blocker beyond the admission integration above was found.

No performance, capacity-fit, complete correctness/race/owning-package or parent acceptance is certified. The existing failed selectors/raw evidence must remain intact. No additional campaign or unrelated gate is proposed.

## Exact review binding

Formatted binding SHA256: `2eb97e4c5c50a539d6d2714280bb34486d124ddbf0560c409a342fe778c67fd6`.

- `TreeDB/internal/valuelog/cow_bounded_decoder.go`: `9166a212f316e59d911ca4c3fb662fb74bd3d849f457a099f989dfd801d3759e`
- `TreeDB/internal/valuelog/cow_bounded_decoder_test.go`: `06206697ef6560450825aebc52cbd9f6e6ec82899850964c810238b5ef00fd55`
- `TreeDB/caching/cow_read_workspace.go`: `5083b7e403aeec296eeb2b279f4059b41091b8a1cb65b9ab75bcc43b7932b285`
- `TreeDB/caching/cow_bounded_decoder_test.go`: `16e064777ecb365fdd5c36570fc31b40e6dbbce540fd0bafe397fc5acf0b1d45`

Selected upstream source inspected directly (not executed):

- `/mnt/fast4tb/gomap-mongo-execution-20261024/bounded-reader-limits-compress1/zstd/decoder_bounded.go`: `dbe61aa81c302e1f08ea7598499b010afa7db2e86505baab5488474371ce1f4a`
- `/mnt/fast4tb/gomap-mongo-execution-20261024/bounded-reader-limits-compress1/huff0/decompress_step.go`: `0237fb6e908473f1924d7ce71d233c1ba18617663aa95bfc46481c1ba9756e59`
- `/mnt/fast4tb/gomap-mongo-execution-20261024/bounded-reader-limits-compress1/internal/decoderwork/work.go`: `8712a38d751544633a01a4d63c71445bb5f61d6e4dd16eb741026ebcc77d1cf9`
- `/mnt/fast4tb/gomap-mongo-execution-20261024/bounded-reader-limits-compress1/internal/decoderwork/allocation.go`: `3d2d25a319dcfe2b608fd466046a35c7b1a1543a7e599592ce491e99702d992b`
