## Public PRIMARY replacement cost

- Verdict: FAIL
- Exact base/head: `f429275bbf0c0bda2cedfc9d5862200cee067ff5` / `cb2330cf237b14ff8bcb6d90c57541168edab60e`
- Eight alternating AB/BA pairs; 128 durable public replacements per sample.
- Median paired time delta: -0.025% (limit +5%).
- Raw gates: `{"allocations": true, "bytes": false, "candidate_primary_activation": true, "timing": true}`; measurement pass: False; quiet: True.
- Timing acceptance: `PASS`; bytes acceptance: `FAIL`; bound runtime/input equivalent: False.
- Scope: this public replacement workload; not final graph qualification.
