# Independent source review: cold DDL borrowed catalog repair

Verdict: **ACCEPT, scoped source review; no material finding.** Reviewed the frozen four-file patch against the current canonical originals and affected constructors/publication/cleanup paths. No Go, gofmt, build, tests or application runtime executed. No canonical files changed. This is not runtime, race, performance, parent-budget or product acceptance.

## Binding

- `selected.patch`: `713cc1f8dff48622cb92ac4c54521fa46dbb0576d16a6f0805c1cd278eb358c8`
- `manifest.json`: `872bea761e131e13f85ae173bab9884d9b8fd6a0c2b49b0b1e0810018922004f`
- `README.md`: `5ee222e19f1579450a98b57692ec4afb97c14fbfd2e9851a337d427038a6137e`

| Selected after-source | SHA256 | Canonical at review |
|---|---|---|
| `TreeDB/collections/native_json_read.go` | `3f07b931124f7137fff27d23727f9bbf815a8c4f66bd5b4b724f6a300e5dc8f9` | selected after |
| `TreeDB/collections/native_index_ddl.go` | `f017a376e1c27405822736969416c11df8f9340b326bbf751ee3263e92b48a3c` | selected after |
| `TreeDB/collections/native_hnsw.go` | `463f73fed33c11af2f632810e023c1d227ff032597643b307621368d3a70a278` | selected after |
| `TreeDB/collections/native_text_rewrite.go` | `78aff0e0989663178d91b703562f48688605e4003ab63e73f553468dd911acd6` | selected after |

## Findings and ownership reasoning

1. **The new pointer is a borrow, not a second owner.** `NativeJSONRead.engine` is assigned only after successful State/projection/private-fallback resolution and before collection lookup (`after/native_json_read.go:93`). A successful cold projection still belongs solely to its exact retained cut. A failed projection's partial engine remains on `privateEngine` and the original deferred Close path; private fallback ownership is unchanged. Missing collection/domain-constructor failures also pass through that cleanup. No new Retain or Release is added. On actual disposal `engine` is cleared before private-engine Release or capture Close (:498); visitor-delayed Close retains both the pointer and its original capture until the last visitor finishes. The original cut releases its projection once through the maintained semantic cleanup queue at last-cut retirement (`cow_semantic_cleanup.go:43–69`).

2. **All three consumers hold the borrow through their use.** Index-family DDL (:236–256), HNSW save (:757–808), and text rewrite (:88–114) obtain a successful manager Capture and retain it across synchronous preparation, `WriteNativePublication`, and any unconsumed-publication cancellation. None accepts a synthetic read literal. The changed selection supplies the already resolved immutable engine where State/privateEngine selection previously missed a successful cold projection. No extra capture, re-import, mutable manager cache, owner registry or new lock is introduced. Existing public-reader serialization and captured-reader Close behavior remain.

3. **Mutation happens on private successors.** Index DDL calls `prepareNativeIndexMutation`, whose admitted private schema, domain builders and replacement collection feed `prepareNativeCatalogReplacement`. HNSW/text use `prepareNativeNamedDomains`/`prepareNativeCollectionChanges`. Those constructors allocate independent engine headers and COW builders; they never write fields of the borrowed base. Removal branches copy metadata before slice compaction; creation normalizers form private definitions. `newNativeEnginePreparation` and `sealPrivateBuilders` attach actual child/value edges on success and partial error. `OwnedMapBuilder.Seal` retains unchanged child edges and new values without mutating published headers. Resulting private states therefore survive closure of the borrowed read; partial states remain on the existing cleanup/custody path.

4. **Publication authority is unchanged.** All three `NativePreparedPublication.Basis` expressions remain `read.capture.State()`, with original StartSequence, effects, dependencies, WAL/error and command-WAL refusal handling. Derived engine is bootstrap input only. The existing installer validates original dependencies before invoking Reprepare with current semantic state/exact snapshot (`cow_batch.go:96–129`), then records the actual current Basis. Synchronous write/batch disposal detaches plans before producer Close; accepted custody retains concrete successor resources rather than a bootstrap-engine alias. No successful shared projection is moved to private cleanup.

5. **Accounting/lifetime change is bounded to one already charged header field.** Read construction, catalog-import probe and insert-plan census use `unsafe.Sizeof(NativeJSONRead{})`; they naturally cover the added pointer. No budget limit, maintained allocation receipt, recovery/format contract or dictionary ownership changes. Clearing the alias at actual disposal avoids keeping its referent through a refunded read scope.

No further machinery or additional tests are requested by this review. Root owns formatting/application and validation of the preserved original failing public tests and affected maintained lifecycle/race controls. Original failures remain failures until those receipts exist.

## Additional actual source bindings inspected

- `TreeDB/collections/native_engine_prepare.go`: `9b64083e52492878644b51b31b974a3c9ffab6b51241700f88ab44098d71a692`
- `TreeDB/collections/native_json_insert.go`: `d9e1a78a7e20a99a7c012317808c5620049e8eb7436a9814ea4a858392571cdb`
- `TreeDB/collections/native_catalog_directory.go`: `813fd00fdd3f83d94d6cdcef18506434f1a5e0a78852f14ba64197f21c8fb887`
- `TreeDB/collections/native_engine_state.go`: `7faeb8d6a91825935690bd8734b6293e1de1b4cf5719b22efce33ac5ff55db33`
- `TreeDB/collections/native_json_import.go`: `3225229b5c55027a414e7d8a1f0628cf9c82583251d89da3a45bebd65bd196b6`
- `TreeDB/collections/native_json_public.go`: `0e2d7bd73ae10dc05c103ef6aba2b643c5e1edc38a9802fb61bc9f89669bede4`
- `TreeDB/collections/native_collection_scan.go`: `0c5ee37fd9528728bba97713b9b596221a17e24bd7b355445e31751c3253f6c1`
- `TreeDB/collections/api.go`: `569a99dbb8ea379c7bd9d0c52ed49e1c7c682f93450b2caba253886282b534fb`
- `TreeDB/collections/text_catalog.go`: `6b1c438d07094dca5003952127a036732bd2feddd592a32dadeac67ce905b206`
- `TreeDB/caching/cow_native_semantic.go`: `d1f8162b1539fecb14e09eb87cae6b5275d05b8f1ec04348642044afe56b4917`
- `TreeDB/caching/cow_semantic_cleanup.go`: `ae7a8168d89f5445b8b9abf49b57de9dc3caa133c01323f604bcaa7934f760eb`
- `TreeDB/caching/cow_batch.go`: `bd77620ce402444dadf6f8f4c5775fedcf50ea6b75d4bc8669cb4b6e40170e98`
- `TreeDB/internal/cowbtree/owned_map.go`: `8fcc55d3d48aab5e431995937aaed82e8dfa93434a3971ec87c72cba154d8caa`
- `TreeDB/db/native_semantic_state.go`: `34719275931ef9787c0ef4f3cc9a007bc8a07bb925e69b8689ae307d278fbbdf`
