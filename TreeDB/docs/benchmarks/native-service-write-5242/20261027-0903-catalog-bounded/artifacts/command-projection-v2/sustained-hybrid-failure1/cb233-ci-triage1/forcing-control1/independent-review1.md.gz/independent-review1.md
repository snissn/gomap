# Independent source review — descriptor-only GC fence control

**ACCEPT, scoped source review. No material finding.** Reviewed the proposed original-test patch, supplemental control, and actual GC/capture/publisher/coordinator/cleanup callers at `cb2330cf237b14ff8bcb6d90c57541168edab60e`. No source edit, formatting, Go/build/test/runtime, or GitHub operation was performed. This verdict establishes source suitability for root-owned execution; it does not attribute the original hosted failure to a particular internal phase or waive it.

## Exact bindings

Independently hashed:

| Artifact | SHA-256 |
| --- | --- |
| forcing-control1/manifest.json | `d88e4df8ef5c91e5dcaee09905196d6970de4156fef68957ddf437768f2f13a4` |
| forcing-control1/maintenance_roots_gc_forcing_control_test.go | `9961d16ce63a138b5baed706764bf7db025fd720747c0ca7bfb435860d901266` |
| forcing-control1/overlay.json | `032b13ab77f079558cf69806e88039e6ce1970e1411253331dacf6b7db31e889` |
| forcing-control1/recipe.json | `af085dcad1a6bf2c8c45147b6e441de448c03d31e004af8f740a3f0ed96f12cb` |
| forcing-control1/README.md | `e9a9d717edc3687280bb5739a84b4d122bcec1bd92fb98e8a1518f5c493cd3bf` |
| source-triage1/manifest.json | `d17108f177ac245a156a3a64d0fde58e2775dd2bb47c0c3d82889cf5f2c02dbd` |
| source-triage1/selected.patch | `f923e11c46d4ae0df62515b8b6acb2aa4da2af071ba4f7306c9eb9c5c1137c96` |
| source-triage1/source-triage.md | `e5921b0bffc8970ab5276a71cb67bfcd3883e08fece6fccc7373ecb88c22a906` |
| canonical TreeDB/db/maintenance_roots_test.go, original | `7125361cc3ac0cda5db41dadbb46c9fa456ea4d0af01682809597f87baabd9fa` |
| canonical TreeDB/db/vlog_gc.go | `940a7ddbc39cd67ba742b69682025bce82410b33e514eb44691f629bc37ea9d1` |
| canonical TreeDB/db/root_publication_activation.go | `74beb12a9e479e14ef3656161d3ea902f2a803642443f1dc4266590d3a88dbc8` |
| canonical TreeDB/internal/rootpublication/coordinator.go | `9957da0e9670d3ceec426274de17070eab7a078ad9b4737c8696f64feefe21e1` |

The test artifact was reviewed at the raw hash above. Root may reconcile a subsequent formatting-only hash; no such later artifact is certified here.

## Findings and reasoning

1. **The original tracker oracle is preserved before the added fence.** The patch inserts only Checkpoint and the existing drained assertion after maintenance_roots_test.go:446. It retains the detached pointer root, empty root-ID builder result, descriptor update, tracker/full-scan comparison, successful GC requirement, specific unreferenced-file absence and referenced-file presence. Checkpoint seals the existing visible prefix and does not replace the system descriptor or advance its logical commit sequence (db.go:4760–4766, 4930–4948). The inserted fence therefore cannot repair tracking *before that existing oracle*. As before, the oracle is a point-in-time comparison; it is not a new claim to exclude all asynchronous preparation before comparison.

2. **The chosen authority pause is source-live for recovery capture.** Prepare owns durablePublishMu, but its invocation has completed before Publish. `preparedSealFor` releases runtime.mu before returning (root_publication_activation.go:1786–1801). Coordinator invokes Publish outside c.mu after Prepare (coordinator.go:905–931). The PRIMARY cut at root_publication_activation.go:1831 uses `WithPinnedFile`; resource_token.go:916 invokes its callback without a token mutex. The DATA cut at durable_root_runtime.go:2163 is likewise inside the storage transaction, before the later commit-state durablePublishMu acquisition at root_publication_activation.go:1946. Materialization and index synchronization have returned by this cut. No preparation, durable-publication, coordinator, or retained-file mutex is held by this selected pause that would itself prevent GC capture/root revalidation. The callback does not retain the borrowed file handle.

3. **The forced transition is after capture and before destructive validation.** GC builds/revalidates its recovery closure, then holds publishPrepareMu through classification and the pre-revalidation hook (vlog_gc.go:233–260, 583–598). The unfenced hook releases an already-prepared final candidate and waits on the original coordinator's exact visible sequence. Its physical finish needs the later durablePublishMu transition, not a new Prepare requiring GC's gate. Completion changes the coordinator reachability epoch (primary_terminal_completion_v6.go:62–65), so the captured capability must refuse before MarkZombie. CaptureReachability/RevalidateReachability can inspect the stable paused pending prefix because the publisher does not retain c.mu at the cut.

4. **Preliminary settling preserves the intended reachability geometry.** Control :76–91 seals only the earlier detached-root publication, before tracker priming and before observer installation. It does not replace the descriptor, invoke GC, rewrite the root, or mutate either original segment payload. Append-only detached-root construction protects its pages, and no page-reclamation operation is inserted. The final builder still attaches that exact root. The root-filtered one-shot callback plus exactly-one-pending/unsealed-visible-sequence assertions (:101–136) reject an unrelated or already-completed pause. The later fenced checkpoint is after the tracker oracle. Its final deletion and exact retained-value assertions also prevent a changed geometry from silently satisfying the test.

5. **Assertions distinguish real outcomes and do not retry GC.** Each variant makes one GC call and requires exactly one hook entry. Unfenced requires stale refusal, zero deletions, unchanged visible state, both exact segment files present and the original descriptor value readable. Fenced requires no GC error, positive deletion statistics, actual absence of the specific unreferenced file, presence of the referenced file and its exact value. Releasing immediately before Checkpoint does not guarantee Checkpoint itself blocks, but the maintained drained assertion proves the required completed-prefix precondition before GC; that is the relevant fence property.

6. **Observer and publisher cleanup have coherent ownership.** The test is sequential, uses a process-global serialized observer with exact root filtering, and has no test-created worker goroutine or scheduling sleep. Cleanup releases the one-shot channel before restoring the observer, clears the per-DB hook, drains the same coordinator and calls original DB.Close, which drains/stops it before teardown. The pause context remains alive until cleanup completes. Coordination waits are bounded; synchronous Checkpoint/Close retain their original API and the outer Go test timeout remains the final storage-hang bound, as stated in the packet. Hook variables are written/read on the synchronous GC test goroutine; the callback's one-shot uses atomic.Bool and sync.Once.

The existing lock/source evidence supports the proposed legal interleaving and fixture fence. Whether execution reaches these intended assertions and passes remains root-owned. A passing control would establish this causal route, not uniquely identify the phase responsible for the retained macOS stale-root-set failure.
