# Independent source review: frame reuse and adapter repair3

Verdict: **ACCEPT, scoped source review. No material finding.** Reviewed the actual upstream production diff and affected continuation/helpers, then the repair3 adapter and its existing workspace caller. No Go, formatting, build, test, application runtime, or GitHub operation was performed. This is not runtime, performance, parent-budget, or product acceptance.

## Source bindings

Upstream base: `623b987e62c8842428a6138906f15abbe22725b9`.

| Artifact/path | SHA-256 |
| --- | --- |
| upstream implementation1/manifest.json | `60cd81393c89a92e20545aa2f69ed468f87bf10e7d42526cbc6dd2fec327fd55` |
| upstream implementation1/selected.patch | `b579f399b10a58fb38c91aea4a2c145359b2bb14bce52286ebf1b3331696f8f5` |
| upstream root-validation1/formatted-source.json | `8d623b4279f4743285c43dbf4c1ddf2f8c161c056cea16f3f63c5c9d83e0858c` |
| upstream zstd/decoder_bounded.go | `35406ad79f2ead7e87da110cf6b24a414da160c42305c8baf187956a82928ff4` |
| upstream zstd/decoder_bounded_frame_reuse_test.go, formatted | `99616779cd5b9ea1dbc3ea2bfb2fd4a0df9cb0c1b05f5d1bab51a92ccc61a63e` |
| upstream zstd/BOUNDED_DECODER.md | `5b9546bf122a3b67e94c3d6dd3775fc0ec1dcb3871fd809d253dc9792d7d6819` |
| adapter repair3/manifest.json | `06774a18718c5cc99d9e148de93a23c402d94be6a3c74525e7da0bd2a74420af` |
| adapter root-validation1/formatted-source-repair3.json | `f04807c9cc0de0fae3e8505f71f9eaf08eab93eb5a3cd0b88a98a6d009b87816` |
| canonical TreeDB/internal/valuelog/cow_bounded_decoder.go | `7acdb4926dcfb2dd3c5b15fe87b692004568444b68dafe12b5da6abd8c1f2df2` |
| canonical TreeDB/internal/valuelog/cow_bounded_decoder_test.go, final fixture-repair4 | `c2be9de96df290b06b9b84f491a07e8e0d47b30c65c0b580df158f852cb3a006` |
| canonical TreeDB/caching/cow_read_workspace.go | `5083b7e403aeec296eeb2b279f4059b41091b8a1cb65b9ab75bcc43b7932b285` |
| canonical TreeDB/caching/cow_bounded_decoder_test.go | `16e064777ecb365fdd5c36570fc31b40e6dbbce540fd0bafe397fc5acf0b1d45` |

Actual files were hashed independently. Adapter donor production hash is `fb66cc2e078baf0f7d44dab77f62078a5e0f121a44e710ab5180b4d82e365742`; comparison to the canonical formatted production file showed only the inserted blank line before its comment. The upstream production file is byte-identical to its frozen packet. Existing helper hashes also match the packet: huff0/decompress_step.go `0237fb6e908473f1924d7ce71d233c1ba18617663aa95bfc46481c1ba9756e59`; fse/decompress_step.go `0a8a39228617f38947bebb2623a0a9be54276cd29d612acd2f6d6c700f519c71`.

## Reviewed invariants

- `ResetFrameStep` at decoder_bounded.go:1321 requires complete cold/dictionary preparation, a nonnil new owner and Raw output. It rejects terminal Close and a paused full reset before effects. It binds the original stored dictionary rather than accepting a replacement definition. Retaining its original Data/Owner/content/tables therefore has an explicit immutable-owner obligation; no identity cache or ownership transfer appears.
- Cleanup at :1345–1489 uses the existing charged phases. Parser/copy/entropy/history aliases are cleared, segmented history is retired, and Huffman/FSE `DetachInput` removes nested wire/output/bitreader aliases. Only actually admitted owned literal/table storage and the original dictionary context remain. The fixed detach bookkeeping has containing TableState/Scratch work envelopes; no new uncharged allocation or Retain discount is introduced. Caller-fed backing is still detached and released.
- Frame initialization at :618 onward resets recent offsets, Huffman permission and sequence decoders before selecting the original matching dictionary. Keeping mutable scratch capacity cannot authorize a previous frame's repeat or treeless entropy state. The unchanged header/block/checksum/output/window validation remains on every new frame; position/error resets establish a fresh allowance without changing configured limits.
- Full ResetStep/ResetStreamStep detect the retained-context latch even when frame cleanup finished but Begin paused. Full cleanup/Close promotion restarts the same phases and clears that latch once; already retired cohorts have zeroed ownership counters, so revisiting them does not double-refund. Close intent stays monotonic, and frame reuse cannot downgrade a started full cleanup. This includes partial frame/error states, not only successful decode completion.
- Adapter constructor at canonical cow_bounded_decoder.go:200–209 performs original full validation once, then an empty frame detach. Its reset dispatcher at :221–246 supplies stable operands across finite work pauses and propagates admission errors immediately. Decode at :292–311 checks exact Raw length/backing and finishes the empty frame detach before returning caller-owned output. Errors use the existing terminal cleanup; mutex serialization and Close at :313–334 preserve final-control-before-refund ordering.
- Existing SAME receipt Retain/Release callbacks, finite work accounting, independent dictionary owner/snapshot lifetime, and workspace teardown remain intact. Workspace construction at cow_read_workspace.go:402–410 passes the original definition owner; teardown at :422 onward closes the decoder before dropping input/raw/definition and closing the receipt. There is no new fallback, owner, pool, fixed warm envelope, cap relaxation, or generic decoder change in this delta.

## Control quality and scope

The upstream warm tests first require real extra Retain beyond constructor admission, then deny **every** Retain and assert both unchanged retained bytes and unchanged Retain-call count across three repeated actual producer frames (formatted test :105–132). Thus their intended witness distinguishes storage reuse from successful readmission. They also check old aliases and dictionary owner, reject stale repeat entropy against the ordinary oracle, preserve aggregate limits, recover from a failed frame, and exercise full-reset/Close promotion of paused detach.

Adapter repair3 added an explicit unpressured retained-growth witness before reconstructing cold state on the SAME receipt and applying pressure. Root subsequently reported that its pure low-alphabet random payload legitimately used no backing; that failure remains an actual failed witness, not a successful refusal control. I independently inspected the final fixture-repair4 source: it uses the maintained upstream rich-literal xorshift/low-63 shape with alternate repeated 1KiB spans, at the same 96KiB length and through the same encoder. It preserves the positive exact-output/actual-growth assertion, reconstructs cold state on the SAME receipt, and pressures the exact previously encoded payload. The refusal assertion still requires the original capacity error, closed decoder and zero retained library bytes. No production, budget, admission or retry semantics changed. The original repair3 test hash was `d2d92d3c3d0be6b369b4101149f0be2b0da6d49902739b09e15938b5830397f6`; the final test hash above was independently verified after this narrow test-only correction. Reported runtime outcomes were not independently executed or certified by this review.

No additional abstraction or cleanup mechanism is needed for this bounded delta: one explicit API and one latch reuse the existing retirement continuation. Runtime outcomes and public-path qualification remain root-owned; this review makes no claim that arbitrary future frames avoid allocation or that parent/performance gates have passed.
