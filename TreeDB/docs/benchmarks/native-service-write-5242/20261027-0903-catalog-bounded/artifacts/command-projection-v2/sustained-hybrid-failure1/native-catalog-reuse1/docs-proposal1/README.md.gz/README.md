# Exact-cut cold native catalog documentation proposal

Apply `selected.patch` only to the two declared spec paths after checking their
before hashes. The proposal describes catalog6's optional derived projection,
original importer and admission receipts, exact-cut ownership, partial-error
custody and existing terminal cleanup. Verification names the two maintained
controls and gives a focused race command.

The existing paired idle-decoder/ColumnGraph pack lifecycle documentation and
ordinary application/API documentation are preserved. This catalog ownership
change needs no additional public API guide edits: public operations, supported
schema, publication authority and durability boundaries do not change. No decoder
adapter behavior is proposed or accepted; provisional bounded adapter4 is excluded.

Source and evidence were read and hashed only. The source review accepts six
catalog paths. Root's retained RED, GREEN and 22-test race receipts are referenced
in the manifest, with log hashes independently checked; no runtime was executed
for this proposal. The original RED remains part of the evidence. These results
and this documentation do not establish sustained workload performance, a decoder
peak repair, changed capacity limits or native default acceptance.

Static validation: `git apply --check selected.patch` passed against the bound
canonical docs. Root owns integration and all further validation.
