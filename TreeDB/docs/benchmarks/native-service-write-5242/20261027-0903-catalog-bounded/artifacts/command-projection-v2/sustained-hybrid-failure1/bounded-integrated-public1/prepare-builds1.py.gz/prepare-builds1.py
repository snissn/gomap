from pathlib import Path
import sys,importlib.util,json,subprocess,hashlib
sys.dont_write_bytecode=True
R=Path('/mnt/fast4tb/gomap-mongo-execution-20261024');O=R/'evidence/command-projection-v2/sustained-hybrid-failure1/bounded-integrated-public1';U=R/'bounded-frame-reuse-compress1'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h=load('owned',R/'evidence/native-query-work-witness1/run.py');r=load('eligible',R/'evidence/command-projection-v2/original-command-eligible1/run.py')
def bind(p):return {'path':str(p),'sha256':h.digest(p)}
def source(p):
 head=r.git(p,'rev-parse','HEAD').decode().strip();tree=r.git(p,'rev-parse','HEAD^{tree}').decode().strip();paths=set(r.git(p,'diff','--name-only','-z','HEAD').split(b'\0'))|set(r.git(p,'ls-files','--others','--exclude-standard','-z').split(b'\0'));dirty={}
 for raw in sorted(paths-{b''}):
  n=raw.decode();q=p/n;dirty[n]=('symlink:'+str(q.readlink())) if q.is_symlink() else (h.digest(q) if q.is_file() else None)
 b={'path':str(p),'head':head,'tree':tree,'dirty_files':dirty};return b,r.source_state(b,'diagnostic15'),r.inventory(b)
G=Path('/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.linux-amd64');env=h.safe_env({'GOROOT':str(G),'GOTOOLCHAIN':'local','GOMAXPROCS':'4','GOCACHE':str(R/'gocache'),'TMPDIR':str(R/'tmp'),'CGO_ENABLED':'1'})
(O/'bin').mkdir()
mod=O/'development.mod';mod.write_bytes((R/'consumer-canonical/go.mod').read_bytes());mod.write_text(mod.read_text()+'\n// Provisional explicit frame reuse dependency; not landed/default/acceptance evidence.\nreplace github.com/snissn/compress => '+str(U)+'\n');sm=O/'development.sum';sm.write_bytes((R/'consumer-canonical/go.sum').read_bytes());protected={str(mod):h.digest(mod),str(sm):h.digest(sm)}
u,us,ui=source(U);h.write_json(O/'compress-source-state1.json',us);h.write_json(O/'compress-source-inventory1.json',ui)
variants={}
for key,name in [('A','public-read-source-A1')]:
 p=R/name;b,st,inv=source(p);h.write_json(O/(key+'-source-state1.json'),st);h.write_json(O/(key+'-source-inventory1.json'),inv)
 moduleargv=[str(G/'bin/go'),'list','-modfile',str(mod),'-m','-json','github.com/snissn/compress'];receipt=h.run_process(moduleargv,str(p),env,O/(key+'-module-resolution1.json'),90);h.write_json(O/(key+'-module-resolution1-receipt.json'),receipt)
 if not receipt['process_ok']:raise RuntimeError('module resolution failed '+key)
 resolved=json.loads((O/(key+'-module-resolution1.json')).read_text());assert resolved['Path']=='github.com/snissn/compress' and resolved['Replace']['Dir']==str(U)
 elf=O/'bin'/(key+'-http');argv=[str(G/'bin/go'),'build','-modfile',str(mod),'-o',str(elf),'./cmd/treedb-document-service'];h.write_json(O/(key+'-build1-attempt.json'),{'argv':argv,'cwd':str(p),'environment':env,'source_state_sha256':h.digest(O/(key+'-source-state1.json')),'source_inventory_sha256':h.digest(O/(key+'-source-inventory1.json')),'upstream_state_sha256':h.digest(O/'compress-source-state1.json'),'upstream_inventory_sha256':h.digest(O/'compress-source-inventory1.json'),'modfile':protected})
 rec=h.run_process(argv,str(p),env,O/(key+'-build1.log'),240);rec['source_unchanged']=r.source_state(b,'diagnostic15')==st and r.inventory(b)==inv and r.source_state(u,'diagnostic15')==us and r.inventory(u)==ui and all(h.digest(Path(f))==v for f,v in protected.items());h.write_json(O/(key+'-build1-receipt.json'),rec)
 if not rec['process_ok'] or not rec['source_unchanged']:raise RuntimeError('build/custody failed '+key)
 infoargv=[str(G/'bin/go'),'version','-m',str(elf)];info=h.run_process(infoargv,str(p),env,O/(key+'-buildinfo1.log'),30);h.write_json(O/(key+'-buildinfo1-receipt.json'),info)
 if not info['process_ok']:raise RuntimeError('buildinfo failed')
 variants[key]={'label':'bounded-plus-catalog','source':b,'source_state':bind(O/(key+'-source-state1.json')),'source_inventory':bind(O/(key+'-source-inventory1.json')),'http':bind(elf),'build_receipt':bind(O/(key+'-build1-receipt.json')),'module':{'source':u,'source_state':bind(O/'compress-source-state1.json'),'source_inventory':bind(O/'compress-source-inventory1.json'),'modfile':bind(mod),'sumfile':bind(sm),'resolution_receipt':bind(O/(key+'-module-resolution1.json'))}}
 h.write_json(O/'built-variants1.json',variants);print(json.dumps({'variant':key,'process_ok':rec['process_ok'],'source_unchanged':rec['source_unchanged'],'elf_sha256':h.digest(elf)}),flush=True)
