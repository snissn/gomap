from pathlib import Path
import importlib.util,sys,json
sys.dont_write_bytecode=True
r=Path("/mnt/fast4tb/gomap-mongo-execution-20261024")
out=r/"evidence/command-projection-v2/sustained-hybrid-failure1/native-catalog-reuse1/root-validation1"
spec=importlib.util.spec_from_file_location("runner",r/"evidence/native-query-work-witness1/run.py");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=json.loads((out/"catalog-risk-race1-plan.json").read_text());repo=Path(p["source"]["repo"])
go_root=Path(p["source"]["toolchain"]["GOROOT"])
env=m.safe_env({"GOROOT":str(go_root),"GOTOOLCHAIN":"local","GOMAXPROCS":"4","GOCACHE":str(r/"gocache"),"TMPDIR":str(r/"tmp"),"CGO_ENABLED":"1"})
if any(m.digest(repo/f)!=h for f,h in p["source"]["formatted_source"].items()):raise RuntimeError("source drift before tests")
receipt=m.run_process(p["argv"],str(repo),env,Path(p["output"]),p["wall_limit_seconds"])
receipt["source_unchanged"]=all(m.digest(repo/f)==h for f,h in p["source"]["formatted_source"].items())
events=[]
with Path(p["output"]).open() as f:
 for x in f:
  if x.startswith("{"):
   e=json.loads(x)
   if e.get("Action") in ["pass","fail","skip"]:events.append(e)
receipt["test_actions"]={a:sum(e.get("Action")==a and bool(e.get("Test")) for e in events) for a in ["pass","fail","skip"]}
receipt["failed_tests"]=[e.get("Test") for e in events if e.get("Action")=="fail"]
m.write_json(out/"catalog-risk-race1-receipt.json",receipt)
print(json.dumps({k:receipt[k] for k in ["process_ok","source_unchanged","elapsed_seconds","test_actions","failed_tests","log_sha256"]}),flush=True)
sys.exit(0 if receipt["process_ok"] and receipt["source_unchanged"] else 1)
