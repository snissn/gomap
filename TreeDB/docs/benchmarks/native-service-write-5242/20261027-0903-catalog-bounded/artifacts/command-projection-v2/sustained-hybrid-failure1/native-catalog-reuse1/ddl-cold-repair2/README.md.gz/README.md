# Cold catalog DDL repair proposal (source only)

Decision: integrate the four-file borrowed resolved-engine repair for independent review and root-owned validation. This packet is not compiled, formatted, tested, or product acceptance. Canonical source was not changed. `git apply --check selected.patch` passed against the bound canonical files.

## Cause and original evidence

Catalog6 `NativeJSONManager.Capture` (`native_json_read.go:59-89`) correctly resolves a cold catalog through `NativeCatalogProjection`, while deliberately leaving semantic `capture.State()` nil and `privateEngine` nil on successful cut-owned import. `cow_native_semantic.go:51-91` explicitly defines its result as borrowed until the original capture closes, outside publication/OCC state. `mutateIndexFamilies` still selects only State/privateEngine (`native_index_ddl.go:250-256`). Consequently successful cold capture reaches `base.allocator` with nil base. The same obsolete selection exists in HNSW save (`native_hnsw.go:806-810`) and text rewrite (`native_text_rewrite.go:107-111`).

The frozen owning1 log retains two matching panics: collections `TestNativeTextPublicDDL/v1/native` after reopen, original recreated CreateTextIndex at `native_text_ddl_public_test.go:206`; and TreeDB `TestNativeExistingBSONSetConditionalLifecycle/command_wal_durable`, original reopened DropAllIndexes at `native_existing_bson_validation_test.go:344`. Both enter `mutateIndexFamilies:256`. Log binding is in manifest.json. These failures are not waived; both package tails were interrupted and must complete after repair. This source explanation does not classify any additional hidden failure.

## Minimal ownership repair

Store the already resolved catalog as `NativeJSONRead.engine`, a borrowed immutable pointer. Initialize it after State/projection/private-fallback validation, before collection lookup. Clear it at actual read disposal, before releasing privateEngine or closing capture. Keep `privateEngine` solely as original private cleanup authority (including partial failed projection), never assign shared successful projection to it.

All three affected producers select this pointer. They already hold the original read through synchronous preparation/publication and cancellation. No second import, extra capture, projection lookup, owner/refcount, manager cache, release, mutation of shared engine, or silent fallback is introduced. Keep all `NativePreparedPublication.Basis: read.capture.State()` and StartSequence/dependency/WAL/refusal fields unchanged: derived catalog is bootstrap input only, never publication authority.

Existing private preparation supplies actual mutation ownership. DDL calls `prepareNativeIndexMutation` (`native_index_ddl.go:158`), which admits private schema/builders/domains/collection and uses `prepareNativeCatalogReplacement`; partial scratch is sealed/released on error. HNSW and text rewrite call `prepareNativeNamedDomains` (`native_json_insert.go:199`), which enters `prepareNativeCollectionChanges:211`, constructs `newNativeEnginePreparation`, immutable OwnedMap builders and new domains/collections. `native_engine_prepare.go:12-75` owns/seals partial builders; `native_catalog_source.go:63` retains concrete immutable directory edges, not an ancestor engine. Thus cloning the whole borrowed catalog before these maintained successor constructors would duplicate work/ownership without fixing another authority requirement. DDL removal copies metadata before slice compaction (`native_index_ddl.go:293-355`); creation passes through existing copying normalizers (`text_catalog.go:382`, `api.go:26755,26786`), as on the already shared warm-state path.

The extra pointer is inside the existing preadmitted read header: `native_json_read.go:46`, import scratch `native_json_import.go:36`, and producer plan `native_json_insert.go:126` use actual `unsafe.Sizeof(NativeJSONRead{})`. Transaction binding charge uses actual `unsafe.Sizeof(nativeJSONTxnBinding{})`. No capacity limit, allowance, or receipt policy changes. Visitor-deferred Close retains the pointer and original owner until actual disposal; immediate/error Close clears it first.

## Complete affected source call-site inventory

| Route | Current selection/owner | Disposition |
|---|---|---|
| Native Capture | read State, shared exact-cut projection, or private fallback (`native_json_read.go:59-89`); partial error/private Close at 494 | Add borrowed engine alias; retain original owners and cleanup |
| Scalar DDL | `api.go:4508,4883,4890,4904` -> `native_hnsw_schema.go:15` -> `mutateIndexFamilies` | Fixed by common DDL selection |
| Text DDL | `text_catalog.go` public create/drop -> `native_text_ddl.go:18-30` -> common DDL | Fixed by common DDL selection |
| Vector DDL | `api.go:4683,4783` -> `native_hnsw.go:53,68` -> common DDL | Fixed by common DDL selection |
| HNSW snapshot save/rebuild | `native_hnsw.go:757`, also called by rebuild at 1506 | Replace obsolete selection; existing private named-domain prepare unchanged |
| Text rewrite | `native_text_rewrite.go:88` | Replace obsolete selection; existing command-WAL rejection and private named-domain prepare unchanged |
| Native transaction import | `native_json_txn.go:125-134,588,712` directly imports exact original conditional transaction into owned `t.imported` | Unaffected; preserve private authority and release |
| Collection create | `native_json_public.go:114-131` directly imports original capture into private local base | Unaffected; preserve private import and original publication basis |
| Bounded collection list | `native_catalog_list.go:23-39` directly imports original capture with private cleanup | Unaffected; no projection widening |
| Import adapter | `native_json_read.go:111` / `native_json_import.go:22` | Existing static exact-cut builder remains unchanged |
| Borrowed/scratch probes | importer stack read, txn binding probe, tests in native_leaf_reuse and native_named_domain_replacement | Do not set engine: no affected producer consumes these literals; each producer obtains successful m.Capture |
| Other privateEngine references | native_hnsw_public_test:807 assertion, native_index_drop_test:314 diagnostic | No ownership/production consumer; unchanged |

The exhaustive production `privateEngine` inventory consists of Capture/Close plus the three obsolete fallbacks above. The remaining three production `read.capture.State()` uses are publication Basis and must stay unchanged. Other directly imported states never rely on read.privateEngine or successful cut-owned projection.

## Required root-owned verification

Preserve both original public failure tests byte-for-byte: all v1/v2 legacy/native `TestNativeTextPublicDDL` cases, admission cleanup and command-WAL guard companions; full original `TestNativeExistingBSONSetConditionalLifecycle` profile lifecycle. Both interrupted owning packages must finish. Exercise maintained HNSW snapshot save/reopen and text rewrite lifecycle paths affected by the other two replacements (`TestNativeHNSWPublicDocumentLifecycle`, `TestNativeHNSWPublicRepresentativeAndAdmission`, `TestNativeHNSWPublicSchemaDDLAdmission`, `TestNativeTextRewritePublicLifecycle`, `TestNativeTextRewriteCommandWALGuard`). Existing exact-cut projection lifetime/final-zero controls remain applicable (`TestCOWNativeCatalogProjectionOriginalCutLifetime`). Independent review should verify private partial cleanup, current-cut reprepare and no derived Basis substitution. Root decides proportional grouped/race execution; this source packet supplies no new green receipt or performance/default acceptance.
