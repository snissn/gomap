from pathlib import Path
import importlib.util,sys,json,collections
sys.dont_write_bytecode=True
r=Path('/mnt/fast4tb/gomap-mongo-execution-20261024')
p=Path(__file__).parent
spec=importlib.util.spec_from_file_location('owned',r/'evidence/native-query-work-witness1/run.py'); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=p/(sys.argv[1]+'-plan.json'); x=json.loads(plan.read_text())
def valid():
 return all(Path(f).is_file() and m.digest(f)==v for f,v in x['inputs'].items())
assert valid(),'input drift before execution'
env=m.safe_env({'GOROOT':'/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.linux-amd64','GOTOOLCHAIN':'local','GOMAXPROCS':'4','GOCACHE':str(r/'gocache'),'TMPDIR':str(r/'tmp'),'CGO_ENABLED':'1'})
z=m.run_process(x['argv'],x['cwd'],env,p/(sys.argv[1]+'.log'),x['wall_limit_seconds'])
z['inputs_unchanged']=valid();z['plan_sha256']=m.digest(plan)
counts=collections.Counter();failed=[];packages=[]
for line in Path(z['log']).open():
 try:e=json.loads(line)
 except ValueError:continue
 if e.get('Action') in ('pass','fail','skip'):
  if e.get('Test'):counts[e['Action']]+=1
  else:packages.append({k:e[k] for k in ('Package','Action','Elapsed') if k in e})
  if e['Action']=='fail':failed.append(e)
z['test_actions']=dict(counts);z['failed_tests']=failed;z['packages']=packages
m.write_json(p/(sys.argv[1]+'-receipt.json'),z)
print(json.dumps(z),flush=True)
sys.exit(0 if z['process_ok'] and z['inputs_unchanged'] else 1)
