package db

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/snissn/gomap/TreeDB/internal/durabilitycut"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
)

// Supplemental source-only control for the exact descriptor-only GC fixture.
// It uses the default resolved authority path and does not run in parallel:
// durabilitycut.Install owns a process-global observer.
func TestValueLogGCDeltaGroupDescriptorPublicationFenceCausalControl(t *testing.T) {
	for _, fenced := range []bool{false, true} {
		name := "unfenced_stale"
		if fenced {
			name = "checkpoint_fenced"
		}
		t.Run(name, func(t *testing.T) {
			const waitLimit = 30 * time.Second
			dir := t.TempDir()
			d, err := Open(Options{Dir: dir})
			if err != nil {
				t.Fatalf("open: %v", err)
			}
			var releasePublisher, restoreCuts, cancelPause func()
			t.Cleanup(func() {
				// Unblock the original publisher on every exit before restoring
				// observer ownership, stopping its scheduler or closing the DB.
				if releasePublisher != nil {
					releasePublisher()
				}
				if restoreCuts != nil {
					restoreCuts()
				}
				d.testValueLogGCBeforeRevalidateHook = nil
				if cancelPause != nil {
					defer cancelPause()
				}
				// Drain the same outstanding owner on an early test exit. Do
				// not Stop before Close: Close itself first drains the coordinator.
				if runtime := d.rootPublication; runtime != nil && runtime.coordinator != nil {
					ctx, cancel := context.WithTimeout(context.Background(), waitLimit)
					drainErr := runtime.coordinator.Drain(ctx)
					cancel()
					if drainErr != nil {
						t.Errorf("drain original publisher during cleanup: %v", drainErr)
					}
				}
				if err := d.Close(); err != nil {
					t.Errorf("close fixture: %v", err)
				}
			})

			unreferenced := appendPointersInNewSegment(t, dir, 0, 1, 80_000, 1, func(int) []byte {
				return bytes.Repeat([]byte("delta-group-unreferenced|"), 64)
			})[0]
			want := bytes.Repeat([]byte("delta-group-descriptor-live|"), 64)
			referenced := appendPointersInNewSegment(t, dir, 0, 2, 90_000, 1, func(int) []byte {
				return want
			})[0]
			appendPointersInNewSegment(t, dir, 0, 3, 100_000, 1, func(int) []byte {
				return bytes.Repeat([]byte("active-head|"), 64)
			})
			unreferencedPath := valueLogSegmentPath(t, dir, unreferenced.FileID)
			referencedPath := valueLogSegmentPath(t, dir, referenced.FileID)

			collectionRoot, err := d.PublishOrderedRootIterator(0, mustFrozenSystemPointerMemtable(t, "doc/p", referenced).NewIterator(nil, nil))
			if err != nil {
				t.Fatalf("publish unattached collection root: %v", err)
			}
			// Diagnostic coordination only: settle the earlier enqueue so the
			// one-shot pause below belongs to the final descriptor candidate.
			if err := d.Checkpoint(); err != nil {
				t.Fatalf("settle unattached-root publication: %v", err)
			}
			requireLeafGenerationGCPublisherDrained(t, d)
			coordinator := d.rootPublication.coordinator
			if _, err := d.referencedValueLogSegments(context.Background()); err != nil {
				t.Fatalf("prime value-log ref tracker: %v", err)
			}
			if _, ok := d.valueLogRefTracker.referencedSet(d.currentCommitSeq()); !ok {
				t.Fatal("expected primed value-log ref tracker")
			}

			entered := make(chan string, 1)
			release := make(chan struct{})
			var releaseOnce sync.Once
			releasePublisher = func() { releaseOnce.Do(func() { close(release) }) }
			pauseCtx, cancel := context.WithTimeout(context.Background(), waitLimit)
			cancelPause = cancel
			var paused atomic.Bool
			restoreCuts = durabilitycut.Install(func(event durabilitycut.Event) error {
				// Both authority implementations emit this role AFTER Prepare.
				// Retain only diagnostic Path, never event's borrowed handles.
				if event.Root != dir || event.Point != durabilitycut.BeforeMetaWrite || event.Resource != durabilitycut.ResourceMeta || !paused.CompareAndSwap(false, true) {
					return nil
				}
				entered <- event.Path
				select {
				case <-release:
					return nil
				case <-pauseCtx.Done():
					return pauseCtx.Err()
				}
			})
			if _, _, err := d.PublishOrderedRootDeltaGroupWithSystemBuilder(nil, func(rootIDs []uint64) (iterator.UnsafeIterator, error) {
				if len(rootIDs) != 0 {
					return nil, fmt.Errorf("rootIDs=%d want 0", len(rootIDs))
				}
				return mustFrozenRawMemtable(t, maintenanceTestCollectionRootKey, encodeMaintenanceRootID(collectionRoot)).NewIterator(nil, nil), nil
			}); err != nil {
				t.Fatalf("publish system descriptor via delta group builder: %v", err)
			}
			assertCandidateTrackerMatchesFullScan(t, d)
			select {
			case path := <-entered:
				t.Logf("paused final descriptor authority after Prepare: %s", path)
			case <-pauseCtx.Done():
				t.Fatalf("publisher did not reach authority pause: %v", pauseCtx.Err())
			}
			visible, ok := d.StateToken()
			if !ok || coordinator != d.rootPublication.coordinator {
				t.Fatal("missing original visible state/coordinator")
			}
			pending := coordinator.Stats()
			if pending.PendingCommits != 1 || pending.VisibleCommitSeq != visible.CommitSeq || pending.DurableCommitSeq >= visible.CommitSeq {
				t.Fatalf("pause did not retain exactly final unsealed descriptor: %+v visible=%+v", pending, visible)
			}

			if fenced {
				releasePublisher()
				if err := d.Checkpoint(); err != nil {
					t.Fatalf("checkpoint delta-group descriptor before GC: %v", err)
				}
				requireLeafGenerationGCPublisherDrained(t, d)
			}
			hookCalls := 0
			var hookErr error
			d.testValueLogGCBeforeRevalidateHook = func() {
				hookCalls++
				if !fenced {
					// This FINAL candidate has already completed Prepare. It can
					// finish without acquiring GC's held publishPrepareMu.
					releasePublisher()
					ctx, cancel := context.WithTimeout(context.Background(), waitLimit)
					hookErr = coordinator.WaitThrough(ctx, visible.CommitSeq)
					cancel()
					if hookErr != nil {
						return
					}
				}
				after, ok := d.StateToken()
				publication := coordinator.Stats()
				if !ok || after != visible || publication.PendingCommits != 0 || publication.DurableCommitSeq < visible.CommitSeq {
					hookErr = fmt.Errorf("unexpected post-seal state: visible=%+v after=%+v publication=%+v", visible, after, publication)
				}
			}
			ctx, cancelGC := context.WithTimeout(context.Background(), waitLimit)
			stats, gcErr := d.ValueLogGC(ctx, ValueLogGCOptions{})
			cancelGC()
			d.testValueLogGCBeforeRevalidateHook = nil
			if hookErr != nil || hookCalls != 1 {
				t.Fatalf("forced pre-revalidation transition: calls=%d error=%v GC=%v", hookCalls, hookErr, gcErr)
			}
			if !fenced {
				if !errors.Is(gcErr, ErrRecoverableRootSetStale) || stats.SegmentsDeleted != 0 {
					t.Fatalf("unfenced GC=%v stats=%+v; want stale and no deletion", gcErr, stats)
				}
				if after, ok := d.StateToken(); !ok || after != visible {
					t.Fatalf("stale refusal changed visible state: %+v want %+v", after, visible)
				}
				if _, err := os.Stat(unreferencedPath); err != nil {
					t.Fatalf("stale refusal removed unreferenced segment: %v", err)
				}
			} else {
				if gcErr != nil {
					t.Fatalf("ValueLogGC: %v", gcErr)
				}
				if stats.SegmentsDeleted == 0 {
					t.Fatalf("expected GC to delete an unreferenced segment, stats=%+v", stats)
				}
				if _, err := os.Stat(unreferencedPath); err == nil || !os.IsNotExist(err) {
					t.Fatalf("expected unreferenced segment to be removed, err=%v", err)
				}
			}
			if _, err := os.Stat(referencedPath); err != nil {
				t.Fatalf("expected delta-group descriptor-referenced segment %d to remain: %v", referenced.FileID, err)
			}
			if got := readCollectionRootValue(t, d, maintenanceTestCollectionRootKey, []byte("doc/p")); !bytes.Equal(got, want) {
				t.Fatalf("descriptor-referenced value=%q want %q", got, want)
			}
		})
	}
}
