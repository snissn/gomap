#!/usr/bin/env python3
"""Root-only prebuilt HTTP development discriminator; no builds, retries or acceptance."""
import sys
sys.dont_write_bytecode = True
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal

ROOT = Path('/mnt/fast4tb/gomap-mongo-execution-20261024')
PREV = ROOT / 'evidence/command-projection-v2/original-command-eligible-diagnostic1'
ELIGIBLE = ROOT / 'evidence/command-projection-v2/original-command-eligible1/run.py'
HELPER = ROOT / 'evidence/native-query-work-witness1/run.py'
PINNED = {
    ELIGIBLE: '7b35dcd3536297a51ce2908697693b223a7b7bd00cd8c0b402612f1b8ea96c97',
    HELPER: '1b0d99b3cb70c785fcd9faa0453ccc82b3cda2b6c5fb20ccb955dd92aa6e1132',
    PREV / 'bin/command-driver.test': '7a96d81e446a5a5f7c0acc10d8c61a5e28882c8471f9680198dea56caee38b8f',
    PREV / 'bin/candidate-native': 'cb73244062f87e301819c18b53fdbff1ecec3060d4fe523e05acc3c62b168312',
}
MODULE_HEAD = '623b987e62c8842428a6138906f15abbe22725b9'
REFS = {'hybrid-once': PREV / '09-http-hybrid-r1-N.attempt.json',
        'keyword-abba': PREV / '03-http-keyword-r1-N.attempt.json'}
FLAGS = ['-test.run=^TestCommandPublicPerformance$', '-test.count=1', '-test.timeout=12m', '-test.v']


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def process_interval(report):
    result = {'matched': False, 'allocated_bytes_delta': None, 'mallocs_delta': None,
        'allocated_bytes_delta_per_completed': None, 'mallocs_delta_per_completed': None,
        'scope': 'HTTP process snapshots after warmup through post-request diagnostics; includes background/diagnostic work outside request timing, not pure request B/op',
        'reason': None}
    try:
        before, after = [report[side]['diagnostics']['work'] for side in ('Before', 'After')]
        for key in ('schema_version', 'scope', 'pid', 'origin_kind', 'origin_unix_nano'):
            require(before[key] == after[key], 'mismatched process identity: ' + key)
        require(before['scope'] == 'process' and before['pid'] > 0 and before['origin_unix_nano'] > 0, 'unavailable process identity')
        start, end = before['snapshot_unix_nano'], after['snapshot_unix_nano']
        require(before['origin_unix_nano'] <= start < end and report['Completed'] == 1000, 'unavailable/nonmonotonic snapshots or incomplete requests')
        for key, output in (('total_alloc', 'allocated_bytes_delta'), ('mallocs', 'mallocs_delta')):
            a, b = before['memory'][key], after['memory'][key]
            require(type(a) is int and type(b) is int and 0 <= a <= b, 'nonmonotonic process counter: ' + key)
            result[output] = b - a
            result[output + '_per_completed'] = (b - a) / report['Completed']
        result.update(matched=True, pid=before['pid'], origin_kind=before['origin_kind'],
            origin_unix_nano=before['origin_unix_nano'], before_snapshot_unix_nano=start,
            after_snapshot_unix_nano=end, snapshot_interval_seconds=(end-start)/1e9,
            timed_request_seconds=report['DurationSeconds'])
    except (KeyError, TypeError, RuntimeError) as error:
        result.update(matched=False, allocated_bytes_delta=None, mallocs_delta=None,
            allocated_bytes_delta_per_completed=None, mallocs_delta_per_completed=None, reason=str(error))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--mode', required=True, choices=('hybrid-once', 'keyword-abba'))
    parser.add_argument('--plan', required=True, type=Path)
    parser.add_argument('--expected-plan-sha256', required=True)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    if not args.execute:
        parser.error('inert source packet; root must explicitly select --execute')
    require(sha(args.plan) == args.expected_plan_sha256, 'selected plan changed')
    for path, digest in PINNED.items():
        require(sha(path) == digest, 'frozen helper/ELF drift: ' + str(path))
    h, r = load('public_owned_process', HELPER), load('public_original_validation', ELIGIBLE)
    signal.signal(signal.SIGTERM, h.interrupted)
    signal.signal(signal.SIGINT, h.interrupted)
    plan = json.loads(args.plan.read_text())
    require(set(plan) == {'schema', 'mode', 'shape', 'reference_attempt', 'variants', 'selection'}, 'plan schema drift')
    require(plan['schema'] == 'public-read-discriminator1' and plan['mode'] == args.mode, 'mode drift')
    require(plan['shape'] == r.SHAPE, 'original driver shape drift')
    variants = ('A',) if args.mode == 'hybrid-once' else ('A', 'B')
    require(set(plan['variants']) == set(variants), 'variant drift')
    out = r.absolute_task_path(str(args.output_dir))
    require(out.resolve() != ROOT.resolve(), 'new child output required')
    for v in plan['variants'].values():
        for binding in (v['source'], v['module']['source']):
            if binding['path'] is not None:
                require(not out.resolve().is_relative_to(Path(binding['path']).resolve()), 'output inside protected source')
    require(os.path.ismount('/mnt/fast4tb') and os.access(out.parent, os.W_OK), 'task mount unavailable/unwritable')
    out.mkdir(mode=0o700)
    operation = 'hybrid' if args.mode == 'hybrid-once' else 'keyword'
    order = 'A' if args.mode == 'hybrid-once' else 'BAAB'
    cells = [{'name': f'{i:02d}-http-{operation}-{variant}-N', 'variant': variant, 'role': 'N',
              'command': 'http', 'operation': operation, 'prefix': str(out / f'{i:02d}-http-{operation}-{variant}-N')}
             for i, variant in enumerate(order, 1)]
    r.write(out / 'plan.json', dict(plan, order=order, cells=cells, runner_sha256=sha(__file__),
        selected_plan_sha256=args.expected_plan_sha256, purpose='DEVELOPMENT ONLY',
        retries=0, native_elf_role='UNUSED by HTTP; hashed by original driver; no standalone native-wire claim'))
    for cell in cells:
        r.write(out / (cell['name'] + '.slot.json'), cell)
    records = [{'name': c['name'], 'variant': c['variant'], 'role': 'N', 'status': 'unattempted',
                'metrics': None, 'process_interval': None, 'failure': None} for c in cells]
    failure, stage, states, inventories, protected = None, 'frozen_setup', {}, {}, {str(p): value for p, value in PINNED.items()}
    protected[str(args.plan)] = args.expected_plan_sha256
    protected[str(Path(__file__).resolve())] = sha(__file__)
    bindings = {}

    def bound(binding):
        path = r.file_binding(binding)
        protected[str(path)] = binding['sha256']
        return path

    def custody():
        for label, binding in bindings.items():
            require(r.source_state(binding, 'diagnostic15') == states[label], 'source state drift: ' + label)
            require(r.inventory(binding) == inventories[label], 'full source/module inventory drift: ' + label)
        for path, digest in protected.items():
            require(sha(path) == digest, 'protected artifact/ELF drift: ' + path)

    try:
        selection = json.loads(bound(plan['selection']).read_text())
        require(all(selection.get(key) is True for key in ('source_review_accepted', 'focused_and_risk_gates_pass',
            'runtime_safe', 'exclusive_measurement_slot')), 'root source/safety/focus/risk/quiet-slot selection missing')
        require(selection.get('mode') == args.mode and selection.get('plan_variants') == list(variants), 'selection scope mismatch')
        reference_path = bound(plan['reference_attempt'])
        require(reference_path.resolve() == REFS[args.mode].resolve(), 'wrong original N reference')
        reference = json.loads(reference_path.read_text())
        require(reference['argv'] == [str(PREV / 'bin/command-driver.test'), *FLAGS], 'original driver argv changed')
        env = reference['environment'].copy()
        require(env['GOMAP_COMMAND_PERF_LEGACY'] == '0' and env['GOMAP_COMMAND_PERF_OPERATIONS'] == '1000'
            and env['GOMAP_COMMAND_PERF_OPERATION'] == operation and env['GOMAP_COMMAND_PERF_COMMAND'] == 'http', 'reference environment shape changed')
        require(not [k for k in os.environ if k.startswith(('GOMAP_', 'TREEDB_'))], 'unset inherited application overrides')
        for key in ('GOCACHE', 'TMPDIR'):
            require(Path(env[key]).is_dir() and os.access(env[key], os.W_OK), 'reference task cache/tmp unavailable')
        pairs = {}
        for variant, value in plan['variants'].items():
            http = bound(value['http'])
            require(value['label'] == ('generic-plus-catalog' if variant == 'A' else 'generic-only'), 'variant label drift')
            for suffix, group in (('gomap', value), ('compress623', value['module'])):
                label = variant + '-' + suffix
                binding = group['source']
                if suffix == 'compress623':
                    require(binding['head'] == MODULE_HEAD, 'provisional compress623 source changed')
                state = r.source_state(binding, 'diagnostic15')
                inv = r.inventory(binding)
                require(state == json.loads(bound(group['source_state']).read_text()), 'root-frozen source state mismatch: ' + label)
                require(inv == json.loads(bound(group['source_inventory']).read_text()), 'root-frozen full inventory mismatch: ' + label)
                bindings[label], states[label], inventories[label] = binding, state, inv
            modfile = bound(value['module']['modfile'])
            bound(value['module']['sumfile'])
            module_receipt = json.loads(bound(value['module']['resolution_receipt']).read_text())
            replacement = module_receipt.get('Replace', {})
            require(module_receipt.get('Path') == 'github.com/snissn/compress' and
                replacement.get('Dir') == value['module']['source']['path'], 'local module resolution mismatch')
            build = json.loads(bound(value['build_receipt']).read_text())
            argv = build.get('argv', [])
            require(build.get('process_ok') is True and build.get('exit_code') == 0, 'HTTP build receipt not successful')
            require('build' in argv and '-o' in argv and argv[argv.index('-o')+1] == str(http), 'HTTP ELF/build output mismatch')
            require(('-modfile=' + str(modfile)) in argv or any(argv[i:i+2] == ['-modfile', str(modfile)] for i in range(len(argv))), 'build did not bind selected modfile')
            pairs[variant] = {'http': value['http'], 'native': {'path': str(PREV / 'bin/candidate-native'),
                'sha256': PINNED[PREV / 'bin/candidate-native']}}
        r.write(out / 'source-before.json', states)
        r.write(out / 'source-files-before.json', inventories)
        r.write(out / 'execution-freeze.json', {'protected_files': protected.copy(), 'cells': cells,
            'reference_environment': env, 'pairs': pairs, 'sources': states,
            'driver_source_sha256': r.DRIVER_SHA, 'driver_elf_sha256': PINNED[PREV / 'bin/command-driver.test'],
            'observation': 'known Go preflight plus existing 1Hz Go observer; not a complete host activity proof',
            'wall_seconds_per_cell': 780, 'qualification': None})
        for cell, record in zip(cells, records):
            stage = 'pre_cell_custody'
            custody()
            stage = 'known_go_preflight'
            found = r.competing_go()
            r.write(out / (cell['name'] + '.known-go.json'), {'utc': h.utc(), 'processes': found})
            require(not found, 'known_go_preflight: active Go process or observer error')
            pair = pairs[cell['variant']]
            cell_env = dict(env, GOMAP_COMMAND_PERF_HTTP_BINARY=pair['http']['path'],
                GOMAP_COMMAND_PERF_NATIVE_BINARY=pair['native']['path'],
                GOMAP_COMMAND_PERF_LABEL=cell['name'], GOMAP_COMMAND_PERF_OUTPUT=cell['prefix'])
            cwd = plan['variants'][cell['variant']]['source']['path']
            argv = [str(PREV / 'bin/command-driver.test'), *FLAGS]
            r.write(out / (cell['name'] + '.attempt.json'), {'argv': argv, 'cwd': cwd, 'environment': cell_env, 'timeout_seconds': 780})
            record['status'] = 'attempted_invalid'
            stage = 'original_driver_process'
            receipt = r.measured_process(h, argv, cwd, cell_env, str(out / (cell['name'] + '.log')), 780)
            try:
                custody()
                receipt['source_and_artifacts_unchanged'] = True
            except BaseException as error:
                receipt['source_and_artifacts_unchanged'] = False
                receipt['custody_error'] = repr(error)
            r.write(out / (cell['name'] + '.receipt.json'), receipt)
            require(receipt['source_and_artifacts_unchanged'], 'custody_drift: source/module/artifact/ELF changed')
            require(not receipt.get('competing_go_observations'), 'known_go_overlap: observed competing Go/observer error')
            require(receipt['process_ok'], 'process_failure: nonzero/timeout/interruption/residual owned group')
            stage = 'original_report_validation'
            validation = r.report_validation(Path(cell['prefix'] + '.json'), cell, pair)
            r.write(out / (cell['name'] + '.validation.json'), validation)
            require(validation['valid'], 'report_invalid: original driver contract failed')
            report = json.loads(Path(cell['prefix'] + '.json').read_text())
            record.update(status='valid', metrics=validation['metrics'], process_interval=process_interval(report))
    except BaseException as error:
        failure = {'kind': stage, 'type': type(error).__name__, 'message': str(error)}
        if 'record' in locals() and record['status'] == 'attempted_invalid':
            record['failure'] = failure
    finally:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        final_errors, after, full_after = [], {}, {}
        try:
            custody()
            for label, binding in bindings.items():
                after[label] = r.source_state(binding, 'diagnostic15')
                full_after[label] = r.inventory(binding)
        except BaseException as error:
            final_errors.append({'type': type(error).__name__, 'message': str(error)})
        r.write(out / 'source-after.json', after)
        r.write(out / 'source-files-after.json', full_after)
        for cell, record in zip(cells, records):
            report_path = Path(cell['prefix'] + '.json')
            record['artifacts'] = {suffix: {'path': cell['prefix'] + suffix, 'sha256': sha(cell['prefix'] + suffix)}
                for suffix in ('.json', '.log', '.seed.log', '.serve.log', '.receipt.json', '.validation.json') if Path(cell['prefix'] + suffix).is_file()}
            if report_path.is_file():
                try:
                    report = json.loads(report_path.read_text())
                    record.update(completed=report.get('Completed'), raw_failure=report.get('failure'),
                        failed_operation=report.get('failed_operation'), cleanup_errors=report.get('cleanup_errors', []), phase=report.get('Phase'))
                except (ValueError, OSError) as error:
                    record['report_parse_error'] = str(error)
            if record['status'] != 'valid' or final_errors:
                record['metrics'], record['process_interval'] = None, None
        all_valid = failure is None and not final_errors and all(x['status'] == 'valid' for x in records)
        r.write(out / 'summary.json', {'mode': args.mode, 'order': order, 'records': records,
            'failure': failure, 'terminal_custody_errors': final_errors, 'all_valid': all_valid,
            'unattempted': [x['name'] for x in records if x['status'] == 'unattempted'],
            'ServerAllocatedBytes': None, 'ServerMallocs': None, 'qualification': None,
            'scope': 'HTTP DEVELOPMENT ONLY; A/B are N-owner variants, not a621 anchors. Original earlier anchor/failures and all parent gates retained; no native-wire claim.'})
    print(json.dumps({'output': str(out), 'all_valid': all_valid, 'failure': failure, 'qualification': None}))
    return 0 if all_valid else 1


if __name__ == '__main__':
    sys.exit(main())
