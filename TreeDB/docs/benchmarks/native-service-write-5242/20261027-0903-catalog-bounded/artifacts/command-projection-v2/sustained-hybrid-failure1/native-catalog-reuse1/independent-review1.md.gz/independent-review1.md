# Independent cold-catalog reuse source review

**ACCEPT — scoped source review; no material finding.**

Reviewed canonical HEAD `cb2330cf237b14ff8bcb6d90c57541168edab60e` plus the exact six-path formatted integration below. Independently recalculated all six hashes and matched `root-validation1/formatted-source.json` (SHA256 `d41e8b08e7fc8dad5e41f5ddc665c10d2d202d54010b8b2c2dde9dc3aec64057`). Original implementation manifest SHA256 `24c2d092d5df9a2ddc82483e1fed93617d140901cdfe357564f5dad42089860a`; reviewed actual canonical diff and affected callers before consulting the implementation proof.

## Findings and scope

- **Authority and lifetime:** `cow_native_semantic.go:57–86` derives only from the same retained capture and stores the successful import’s original reference in that exact cut. `State()` remains the published semantic state; producer/OCC/publication paths do not consume the derived slot. Reads borrow descriptors while their existing capture owns the cut. The initial, ordinary successor, rollover and refreshed-basis constructors initialize a new zero slot; none copies the prior projection. Older held readers therefore retain the original catalog and snapshot across newer cuts/checkpoint/reopen.
- **Synchronization:** initialization takes capture mutex, then cut projection mutex, then the original importer read/physical/budget paths. No cut/publication/semantic queue latch is held during import. The sole production callback is static, synchronous and neither closes nor reenters its capture. Capture Close scrubs its aliases under its mutex, then releases the cut outside both projection locks. A retained initializer prevents last-cut retirement. No reverse acquisition path was found.
- **Error custody and cleanup:** `native_json_read.go:63–86` leaves failed partial imports on the original private read cleanup path after both new locks exit; it never installs them. A successful import, including a later missing-name failure, remains correctly cut-owned. At last cut, `cow_semantic_cleanup.go:51–70` detaches the projection edge, invokes the maintained constant-work engine Release and queues its original cleanup record before withdrawing activeCuts. The existing sole worker preserves failed Work/record/charge and detaches before refund; no destructor or new owner is introduced. Imported engines hold cache-free allocator capabilities, not capture/snapshot inventories.
- **Admission:** both control additions are embedded. Every cut constructor admits `cowCutCharge`, which uses `Sizeof(cowReadCut{})`; native capture admission uses `Sizeof(NativeSemanticCapture{})`. These formulas cover the new slot/interface/mutex and capture mutex. Catalog backing retains the unchanged importer’s independent admission/cleanup receipts. No cap or receipt credit changes. Coheld old/new catalogs remain subject to the original finite refusal.
- **Controls:** the maintained component covers same-cut single initialization, unchanged published authority, successor separation, refusal/partial-error cleanup, old-cut lifetime, closed capture and terminal receipt cleanup. The public test preserves semantic/schema/held-reader/checkpoint/reopen/Close-zero checks before its sharing discriminator. No source-based test-oracle gap requiring a repair was found.

The one fixed optional capability and static adapter are proportionate to the cross-package ownership boundary; no material simplification is required. Non-projection operations retain their preexisting borrowed-capture concurrency contract. This review does not claim successful runtime, Close-zero execution, throughput/allocation improvement, parent acceptance, or a repair of the separate generic decoder peak. Root owns those outcomes. No Go/gofmt/build/test/profile/runtime or source mutation was performed.

## Exact reviewed source hashes

- `TreeDB/caching/cow_cut.go`: `6b7a5392195a4176f05aff8583609423b9a728c860da1871526951e06694f1a7`
- `TreeDB/caching/cow_native_semantic.go`: `d1f8162b1539fecb14e09eb87cae6b5275d05b8f1ec04348642044afe56b4917`
- `TreeDB/caching/cow_semantic_cleanup.go`: `ae7a8168d89f5445b8b9abf49b57de9dc3caa133c01323f604bcaa7934f760eb`
- `TreeDB/collections/native_json_read.go`: `1d0a095aad5cb483fe3175f825ebad69c085ba1fb4d555371deadea5acaa9163`
- `TreeDB/caching/cow_native_catalog_projection_test.go`: `e5b8e3b0332d4c07b15fa8ee65f33ccc946ab52ae6cd8607bf61ad574b7a3231`
- `TreeDB/collections/native_catalog_reuse_test.go`: `854dedc2435488306cc5e94adb3771bea046e054df4e97f75c47fa7685d85442`
