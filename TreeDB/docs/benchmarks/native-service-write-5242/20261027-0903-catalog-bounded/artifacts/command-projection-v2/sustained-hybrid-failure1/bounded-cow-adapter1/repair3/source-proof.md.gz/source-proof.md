# Adapter repair3: explicit frame reuse, unchanged original receipt

Source-only incremental repair against root-formatted repair2, exact four before-images in manifest. Only the two valuelog adapter paths change; both caching paths are byte-identical. No Go/gofmt/build/test/runtime/commit/canonical changes were performed. Upstream sibling confirmed exact API `ResetFrameStep(input []byte, owner any, mode BoundedOutput, raw []byte) (bool,error)` in bounded-frame-reuse-compress1; this packet requires that separate reviewed prerequisite and does not add its implementation or module edits.

## Production delta

Constructor still validates exact GoMap SHA-derived producer identity and original immutable owner, admits same wrapper/input/raw floor, creates the same finite-work bounded engine with original memory/window limits, then performs full ResetStep with the original dictionary and runs the maintained validator once. After full validation it calls explicit ResetFrameStep(nil,d,BoundedRaw,nil) rather than full dictionary retirement. Each Decode calls ResetFrameStep(payload,d,BoundedRaw,dst), the same Step/RawResult checks, then ResetFrameStep(nil,d,BoundedRaw,nil) before returning. Full ResetStep is used only during initial validation. No dictionary replacement or identity lookup exists on frame reuse.

All calls remain under existing adapter mutex / workspace serialization; the input/output owner remains this adapter only during the operation and every previous caller input/raw alias must be detached before resetframe returns true. The immutable dictionary retains its original independent definition owner or original complete cut until Close. Actual parsed tables/reusable backing remain charged to the SAME lease through original Retain/Release. This fixes the warmed decoder contract by preserving actual owned storage, not by reserving an arbitrary envelope or accounting for freed memory as retained. Existing full Close and failure cleanup remain unchanged and retire all actual backing once aliases drop. Any capacity error is propagated; no pause loop retries it. Finite quantum/no-progress handling and cumulative work overflow guards are unchanged.

## Test correction and preserved controls

The old new-test repeat-only payload could validly decode using caller raw and cold predefined state without allocating. The new recipe uses maintained encoding of deterministic 32-symbol low-repeat bytes. An unpressured positive control must decode identical bytes and show actual retained storage beyond cold continuation. It then closes and reconstructs the cold continuation on the SAME lease and repeats the exact encoded payload under original budget pressure; a genuine new allocation must refuse, close and refund all continuation storage. If the recipe does not require Retain, the fixture explicitly fails instead of silently assuming allocation. The cold constructor admission refusal remains unchanged. Existing trained dictionary, native output-callback admission and busy/nonbusy successor tests are untouched. No quota, caps, fields, pool, generic decoder fallback, charge discount or public fixture change.

## Root-owned verification

1. Review upstream explicit frame reuse and detach/full-close promotion; format/build only after dependency projection.
2. Existing adapter component family incl true allocation refusal, phase-only cleanup and actual oversized Reserve; exact original native dictionary output admission, dictionary handoff and finite/cold/closed controls.
3. Changed-risk race including decode/Close, native captures/definition lifetime and successor fallback.
4. ORIGINAL fresh-server 4096/8D/fixed128/1000 mixed-Hybrid causal cell after focused/race source acceptance. Product viability/performance/CI/recovery gates remain open; prior focused1/focused2 and original662/598 failures remain retained. No source-only claim that this packet passes runtime.

Source edits stop at this packet for root formatting/integration/review.
