# Independent public read discriminator source review

**REJECT — one material dependency-binding defect (P1).** No execution/import/build/Go/runtime performed. The frozen rejected packet remains unchanged.

## Material finding

`run.py:168–169` requires the module-resolution receipt Path to be `github.com/klauspost/compress`. The selected adapter actually imports `github.com/snissn/compress/zstd` (`consumer-canonical/TreeDB/internal/valuelog/cow_bounded_decoder.go:11`); the canonical go.mod requires snissn/compress, and `bounded-cow-adapter1/root-validation1/development.mod` replaces **github.com/snissn/compress** with the selected local bounded-reader module. klauspost/compress is a separate indirect dependency with no replacement. The current check therefore refuses a truthful selected-library receipt, or attests the wrong dependency if a klauspost replacement is manufactured. README Root preparation repeats the incorrect `go list -m -json github.com/klauspost/compress` target. Correct the expected module identity and documentation to snissn/compress, preserving the selected source/head/inventory/modfile/sumfile and actual resolution receipt bindings. No library or workload substitution is needed.

## Other reviewed boundaries

No other material finding in the bounded runner review. One original Hybrid1000 A/N cell and Keyword B/A/A/B N-owner cells are fixed before setup. These are development variants, not new a621 anchors. The original driver ELF/argv, reference attempt environment, workload shape, durable ACK and lifecycle oracles remain unchanged. The original report validator remains responsible for completeness, identity, all1000 attempts, routes/results and actual binary hashes. Only the selected HTTP ELF changes; the pinned native ELF is explicitly hash-only/unused for HTTP server execution.

The source/module state and full inventories, modfile/sumfile, resolution/build receipts, selected-plan/selection/helper/ELF bytes are bound and rechecked through custody. README explicitly places prebuilt ELF/source/compiler linkage review with root; the runner does not claim to reconstruct historic build provenance. Selected templates remain intentionally incomplete until root freezes actual bindings and passing risk evidence.

Known-Go preflight runs before attempts. The accepted bounded observer records errors and unfinished threads, snapshots observations, and any overlap stops later cells. The maintained process helper owns a fresh session, bounds the driver, and terminates only its residual group; the driver owns orderly HTTP children. No unrelated job is targeted and no universal quiet-host proof is claimed.

Unexpected process/report/custody/observer failures stop the tail. Existing lowercase failure/failed_operation/cleanup_errors, completed prefix, phase and raw logs/reports/receipts are retained. Invalid cell metrics remain null; terminal custody errors null all successful metrics. Planned slots and unattempted tails remain explicit; no retry/resume or automatic second mode exists.

Process counter deltas require matching process/schema/scope/origin, ordered snapshots, nondecreasing integer counters and1000 completions. Their scope explicitly includes background/diagnostic work outside the request timer, not pure request B/op/allocs/op. Missing/invalid deltas remain null; top-level ServerAllocatedBytes/ServerMallocs and qualification remain null. No numeric/performance/parent acceptance is produced.

## Exact frozen bindings

Manifest SHA256: `c139af9059afa799918e2894da0a752505b7d2d8261054d8c8514c5f60adc8ce`.
Runner SHA256: `2d21b078791fe8b4f67492cb6c5f9567eaa40c761075802137fa777fc99343ae`.

Independently verified every manifest packet-file and referenced-input hash, including the unchanged helper and prebuilt driver/native ELF, by reading bytes only.

- `README.md`: `d6c9596758b6885b43a6fa403baa2de371057705fc6974e90b98b90165b0f11f`
- `checks.json`: `0d4360a81eb8c3c92cb3bf52263e26b9bbb7c29a599a8b0a9124b7884512ab6e`
- `hybrid-once.template.json`: `923a01d4f79df65d8d9df6008f45fcdef6eeb9b63abd658d90ac24317117a380`
- `keyword-abba.template.json`: `a5c1b7d56518ad93766884ffbaf616b8fb15f83cb575865d000a02908780bb71`
- `run.py`: `2d21b078791fe8b4f67492cb6c5f9567eaa40c761075802137fa777fc99343ae`
- `selection.template.json`: `4cd2271c79b13ee27b3d636bc8848abe84fb35c952e83f683ef2916bb311e645`
