# Busy shared dictionary fixture5 — independent source diagnosis

Disposition: **the original test's implicit capacity trigger changed; no production ownership regression is established by this failure.** The observed `unchanged=true, err=nil` is insufficient to certify a successful read. Preserve that failed owning-run result. A source-bound positive semantic witness and an explicitly admitted-pressure negative control are appropriate; no production change, cap increase, suppressed error, or failed-read retry is justified.

Source-only investigation. No canonical changes, Go/gofmt/build/test/application runtime, or GitHub operations. Root owns execution and implementation. This packet is a proposal, not a passing test or product acceptance.

## Exact snapshot

Canonical base `cb2330cf237b14ff8bcb6d90c57541168edab60e` plus root's dirty integration. Independently hashed actual sources:

| Path | SHA-256 |
| --- | --- |
| TreeDB/caching/cow_successor_dictionary_capacity_test.go | `4b0873723b7f6c2aa98e8091687a714493d8ba216e0fac4ea3df7aa5202d2df8` |
| TreeDB/caching/cow_read_workspace.go | `5083b7e403aeec296eeb2b279f4059b41091b8a1cb65b9ab75bcc43b7932b285` |
| TreeDB/caching/cow_read.go | `9adf8c8a55ee5529723bac509d7aff15a04728dae0b0656749f118e5fc203d6d` |
| TreeDB/internal/valuelog/cow_bounded_decoder.go | `7acdb4926dcfb2dd3c5b15fe87b692004568444b68dafe12b5da6abd8c1f2df2` |
| TreeDB/internal/valuelog/cow_reader.go | `78e3dab6d9334652e524e6ff500a0519e14db8322db51884368006e419baa20e` |
| TreeDB/internal/memtable/cow_budget.go | `ca90d711ef38bbbe10088b4f527352ec0b7fdb12e3673cbe26ab3a6b4d2161ce` |

## Causal trace

The fixture creates a real dictionary-compressed physical leaf, then a pending write using that producer. The cut owns its pending dictionary definition; the test proves `w.definition(shape.DictID)` returns actual bytes with no independent owner. Initial public successor decoding warms the independently owned shared physical codec. Hiding only the optional independent capture interface then sends the borrowed iterator through the original captured-only route.

At cow_read_workspace.go:785–790, a nonzero dictionary without an independent provider must use `w.readInspected` on the complete-cut owner before the verified page cache. Thus the successful iterator cannot simply bypass its local definition/admission requirement through that cache. The iterator has its own physical workspace (cow_read.go:304–371), and its captured-only codec is private to that workspace. Its Close drops workspace codecs before their receipts.

The failing test applies **no explicit pressure** at all. It locks physicalMu and assumes the additional private codec cannot coexist with the shared codec. Previously both admitted generic envelopes included 64 separately rounded 256KiB fixed cohorts (16MiB), `24*(0x7f00+0xffff)` sequence bytes (about 2.24MiB before rounding), at least another 512KiB raw envelope, and wrapper/input/dictionary capacities (cow_reader.go:444–457). Two such envelopes plus the original 32MiB maintenance reservation exceed the default 64MiB in-flight limit before other owners. The failure was therefore a useful negative admission/idle-reclaim control for that allocation policy.

The selected factory now uses `COWBoundedDecoderRetentionSizes` and `NewCOWBoundedDecoder` for both shared and captured-only dictionary/ZSTD owners (cow_read_workspace.go:371–410). Its base prices actual wrapper/input/raw capacities, then its SAME receipt grows through actual upstream Retain before control/table/scratch allocation. It has no generic 16MiB or sequence-array cohorts. The same parent limit can consequently admit both real owners; physicalMu being busy is not itself a prohibition on an independently admitted complete-cut decoder. No local successful path closes, detaches or borrows the busy shared codec.

The reclaim gate remains `physicalMu.TryLock`, returning false immediately when busy (cow_read_workspace.go:139–156). It is reached only on codec **base-lease** `AcquireExternal` refusal at :384–390. Later bounded constructor/table Retain refusal propagates through cleanup without this idle-trim retry. This distinction matters when choosing pressure: forcing only an outer wrapper failure or later table failure does not exercise this precise gate.

## Minimal test patch proposal

Keep the original real fixture, producer/definition checks, captured-only provider, default limits/reservation, busy physical mutex, deadline, shared codec identity/liveness assertions, owned-result immutability, capacity sentinel and successful public idle read. Do not replace this fixture or restore generic production allocation merely to manufacture refusal.

1. Add an unpressured busy **positive** characterization of the existing public `s.Iterator` route. In its worker, require nonnil iterator, `Valid`, key `a000`, exact value `want`, nil iterator Error and successful Close. Inspect its existing `snapshotBoundIterator` → `cowMergeIterator` workspace to require a local matching `*valuelog.COWBoundedDecoder`, no independent definition owner and the original cut/snapshot. While physicalMu remains locked, require unchanged shared workspace/codec/decoder/lease and unchanged `owned`. The present nil-only worker is not a semantic witness.

2. Preserve an explicit **negative** busy-owner admission control at the actual codec base-lease boundary. The smallest deterministic source-isolating variant uses the same real cut's fresh local workspace and common `readInspected` factory path: pre-admit its empty codec slot before pressure, prove no matching codec exists, then leave exactly `codecBase + leaseOverhead - 1` bytes of parent headroom. Compute `codecBase` from the same existing returned retention sizes and separately rounded codec/interface/wrapper/raw/input allocations used by :379–383; do not use an arbitrary byte constant. `AcquireExternal` itself adds its lease overhead. For pressure payload use `limit - before.ReservedBytes - leave - pressureLeaseOverhead`, with explicit checked subtraction. The captured definition path allocates no independent definition here. Under busy physicalMu, `readInspected` must refuse the base codec lease, execute the nonblocking TryLock guard, return `ErrCOWCapacity`, leave the slot empty, and return budget stats exactly to the pressured snapshot. Require the shared codec pointers/lease to remain intact and `owned` unchanged. Release pressure and keep the original successful public idle iterator/value/Close checks. This uses existing source seams only.

If root instead keeps the negative control entirely at public Iterator construction, allow the complete existing bound-wrapper/merge/source/inspection/empty-codec-slot admissions before making the codec base one byte short; derive those operands from the actual constructor, not a guessed headroom constant. Filling all remaining budget would refuse the outer wrapper and would not test busy codec reclamation. Measuring only nil/sentinel or only steady retained bytes is likewise insufficient to identify the targeted admission phase.

The two parts separate the now-legal unpressured coexistence from genuinely unavailable capacity while preserving the ownership invariant. They are a single targeted fixture correction, not a proposal for new production fallback or retry behavior. Actual byte/phase witnesses and the original failed batch remain root-owned evidence.
