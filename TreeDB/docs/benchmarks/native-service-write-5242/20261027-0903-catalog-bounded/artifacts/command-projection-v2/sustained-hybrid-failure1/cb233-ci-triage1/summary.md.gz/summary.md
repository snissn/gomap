## TreeDB MVCC raw-path gate

- verdict: **PASS**
- measured threshold observation: **PASS**
- baseline: `f429275bbf0c0bda2cedfc9d5862200cee067ff5`
- candidate: `cb2330cf237b14ff8bcb6d90c57541168edab60e`
- samples: 8 per revision, benchmark-group-paired alternating AB/BA order
- timing acceptance: median paired candidate/base relative delta <= 5% (base/head medians remain reported for context)
- allocs/op threshold: candidate median must not increase
- B/op jitter threshold: candidate median may increase by at most the smaller of 1% or 64 B; zero-B baselines remain strict

| Package | Baseline SHA-256 | Candidate SHA-256 | Relation |
| --- | --- | --- | --- |
| db | `57a0ea8f792a1d2a78e2008e184134c79dc1c03bfcfb0b1a00eb42a8501609d3` | `7e144766a88d0092918b8aa22512638fa2f59fa432dd96b27feaefe6968c2854` | DIFFERENT |
| caching | `1ec961614552a11a17b71fb82e5c5f79dd0843fe80dc152ef2b530176e7895ca` | `df5ba53fab0f0699020fe81973e8e8da7f9db7f9bdbf5f81007d0a917ad69188` | DIFFERENT |
| treedb | `9ddb387c87884c44642659286f11807fcb7bb53cf331d394f69b0d8623c5e78e` | `4afdeed943783303c6d5e88cd1d776ffd122eb2914f3d46563c15b6bfc9f481d` | DIFFERENT |

| Benchmark | Binary | Base ns/op | Head ns/op | Median delta | Paired delta | Base B/op | Head B/op | B tolerance | Base allocs/op | Head allocs/op | Measured | Attribution | Acceptance |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- | --- |
| BenchmarkGetVersioned | db DIFFERENT | 402.350 | 400.150 | -0.55% | +0.40% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkConditionalTxnBaselineBatchWrite | db DIFFERENT | 32117.000 | 31546.500 | -1.78% | -0.68% | 31463.500 | 31463.000 | 64.000 | 101.000 | 101.000 | PASS | CANDIDATE | PASS |
| BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek | treedb DIFFERENT | 204.600 | 208.150 | +1.74% | +0.94% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkRepeatedIterator | caching DIFFERENT | 174.650 | 173.950 | -0.40% | -0.00% | 112.000 | 112.000 | 1.120 | 1.000 | 1.000 | PASS | CANDIDATE | PASS |
| BenchmarkPublicCommandWALDurableTinyBatchWriteSync/placement=inline/shape=dirty_batch/ops=1 | treedb DIFFERENT | 93426.000 | 93774.000 | +0.37% | +0.89% | 4573.000 | 4576.000 | 45.730 | 16.000 | 16.000 | PASS | CANDIDATE | PASS |
