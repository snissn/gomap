# Prebuilt public read discriminator

Source-only development runner. No Go, formatting, builds, tests, benchmarks or servers have been run for this packet. Root reviews/freezes a selected plan and executes only after the selected adapter/catalog correctness and risk gates pass. No source worktree is written. No upstream/mainline adoption or performance acceptance is implied.

The two modes are fixed:

- `hybrid-once`: one original HTTP Hybrid1000 cell on integrated candidate A, native owner N (`legacy=0`).
- `keyword-abba`: original HTTP Keyword1000 in fixed **B/A/A/B** order. B=bounded-only adapter; A=same bounded decoder plus catalog reuse. Every cell uses native owner N (`legacy=0`). A/B are variant labels, **not the earlier pre-project a621 baseline**. Earlier anchor cells/failures and required legacy/performance gates stay retained.

Both use the existing original driver ELF at `original-command-eligible-diagnostic1/bin/command-driver.test`, SHA256 `7a96d81e446a5a5f7c0acc10d8c61a5e28882c8471f9680198dea56caee38b8f`, built from the frozen original driver9a source (`9a1ebc077be73e44ece496903b644aefa0dafbc0429f155952a31d6c28d35d4d`). The runner never rebuilds, overlays, formats, instruments or edits it. It reuses frozen eligible1 helpers (`7b35dcd...`) and owned-process helper (`1b0d99b...`) directly. Original `report_validation` runs on each successful process cell. The original driver remains responsible for every request's result/route/work/ACK/cleanup oracle.

The unchanged native ELF is hash-bound only because the original driver hashes both paths. It is **UNUSED** for HTTP server execution, so no standalone native-server/native-wire qualification is claimed. The original HTTP driver's same-owner native listener still performs the original final maintenance calls. The runner uses only root-prebuilt HTTP ELFs; it contains no build or toolchain command.

## Root preparation

Create a new selected plan from the corresponding mode template; never overwrite either template. Fill all null source heads/trees/dirty-file hashes and file bindings. A is root's integrated canonical candidate, including the reviewed selected changes; B is the isolated bounded-only source. Every source/module requires the exact maintained `source_state(..., 'diagnostic15')` JSON and complete `inventory(...)` JSON frozen **by root before execution**, with path/SHA256 bindings. Each expected JSON contains the direct state object or direct file map, not an outer `{candidate: ...}` wrapper. Dirty/staged bytes are explicit; they are never silently treated as pushed HEAD. The maintained inventory refuses ignored files and unresolved submodules: use isolated bound inputs, not source-local build outputs. No inventory is invented or accepted from current runtime state alone.

Bind the provisional local compress module at exact `623b987e62c8842428a6138906f15abbe22725b9` with its own state/full inventory, the selected `-modfile`, companion `.sum`, and root's existing module-resolution receipt. That receipt is `go list -m -json github.com/klauspost/compress` output and must identify `Replace.Dir` as the selected local module source. Bind the successful HTTP build receipt (`process_ok=true`, `exit_code=0`, actual `argv` including selected `-modfile` and `-o` HTTP ELF). All files/receipts/ELFs are hashed before/after each cell. Root must review the receipt's exact source/environment/compiler linkage before selecting the plan; this runner does not rebuild or infer upstream merge/landed status. The root plan binds that complete source/module/build chain for each variant.

Bind the root selection JSON from `selection.template.json`, identifying the mode and variants (`["A"]` or `["A", "B"]`) and affirming current source review, focused+risk gates, safe runtime and exclusive measurement slot. Include the actual evidence references. These are root attestations, not a new approval workflow or automatic acceptance. Numerical thresholds and final campaign modes are deliberately absent.

Reference attempts are frozen original NHybrid09 or NKeyword03. The exact effective environment is copied from that attempt, including scheduler/runtime controls and paths. Only HTTP ELF, the hash-only unused native ELF, label and fresh output prefix change. Inherited application overrides are refused. Work stays **8D,4096 rows,32 fixed128 batches,payload32,16 tenants+rank scalars,explicit native_runtime,M16/Ef128/Ef64,durable ACK,Optimize,seed shutdown,fresh serve reopen,warm1,1000 serial measured operations,Flushed FlushAll,Synced Checkpoint,Close**. No budget/cap, fixture, strategy, profile or request substitution exists. There are no additional profile captures or diagnostic HTTP requests inside a cell.

Later root invocation (not executed for this packet):

```text
python3 /mnt/fast4tb/gomap-mongo-execution-20261024/evidence/command-projection-v2/sustained-hybrid-failure1/public-read-discriminator1/run.py \
  --execute --mode hybrid-once \
  --plan /absolute/task-root/NEW-selected-plan.json \
  --expected-plan-sha256 <reviewed-plan-sha256> \
  --output-dir /absolute/task-root/NEW-run-directory
```

Use a distinct keyword plan and output directory for `keyword-abba`. Both are inert without `--execute`, reject plan/mode/shape drift, and refuse existing output directories. All cell slots are retained before setup. There are no retries, continuation/resume, automatic second mode, data deletion, alternate source selection or final75 mode.

## Evidence and failure boundaries

Before each cell the maintained known-Go preflight must be empty. The maintained measured-process wrapper observes known Go work at1Hz and retains all observations; any observation/error invalidates the cell and stops the tail. This observer is not a complete host-contention detector, so root still owns the exclusive quiet slot. Driver780s outer/12m test/10m internal limits and original readiness/shutdown limits remain. The owned helper starts a fresh process session and cleans only its group; the unchanged driver handles orderly child shutdown and the helper terminates residual descendants on failure. No unrelated process is targeted.

The first process/observation/report/source/module/ELF failure stops later slots. Failed raw report, completed prefix, lowercase `failure`/`failed_operation`, cleanup errors, phase, seed/serve/driver logs and process receipt stay intact; successful metrics are null for an invalid cell. Setup/observer failures leave untouched slots unattempted. Terminal full source/module inventories and protected-file/ELF custody are checked and saved; a terminal mismatch invalidates all successful attribution. There is no retry-to-green or threshold adaptation.

Successful HTTP reports can provide a separate process-interval allocation diagnostic from `Before/After.diagnostics.work.memory`. Deltas require matching PID/schema/scope/origin, increasing snapshot timestamps, nondecreasing counters and1000 completed operations. Raw integer deltas and normalized deltas retain their exact1000 denominator and snapshot timestamps. They include process-wide background work and diagnostics outside the request timer; they are **not pure request B/op or allocs/op**, and nontransactional snapshot limitations remain. Missing/mismatched/incomplete counters stay null with a reason. The original top-level ServerAllocatedBytes/ServerMallocs remain null. No driver allocations substitute for server evidence.

Every planned sample and variant order remains visible; no statistical or acceptance conclusion is produced from one Hybrid cell or four Keyword cells. Original route, retained-resource, legacy, public performance, upstream-module, CI/review and graph gates stay with root. `checks.json` and `manifest.json` contain source-only AST/JSON/hash construction checks, not runtime validation of this runner.
