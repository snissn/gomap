#!/usr/bin/env python3
"""Root-only fixed L/N server profiles. Inert without --execute; no retries."""
import sys
sys.dont_write_bytecode = True
import hashlib, importlib.util, json, os, pathlib, signal
ROOT = pathlib.Path('/mnt/fast4tb/gomap-mongo-execution-20261024')
HERE = pathlib.Path(__file__).resolve().parent
PREV = ROOT/'evidence/command-projection-v2/original-command-eligible-diagnostic1'
GO_ROOT = pathlib.Path('/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.linux-amd64')
HELPER = ROOT/'evidence/native-query-work-witness1/run.py'
ELIGIBLE = ROOT/'evidence/command-projection-v2/original-command-eligible1/run.py'
EXPECTED = {'manifest.json':'1701dcfc5140604d28ed8538e87bf4ecfc3b23d5234b3a205d2bf2a917250142',
 'plan.json':'4ac72e0c4f57be5408bb6464a1b60ad5fa1c0fb78f50b1feb8652012285e19e3',
 'candidate-driver.go':'b94cd8b3e74039ef220bbc58d0a04871857b5f2ca210826a9237a16e9315ab84',
 'overlay.json':'31097729589fa899c186e35755f9b55fa819ff2d3f473c87c412c571c7a0a657',
 'driver.patch':'476ec306ed16d02c22e39f74c9d95aaa5ee83395add596fe766648d92542f6c7'}
def sha(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''): h.update(block)
    return h.hexdigest()
def require(ok, message):
    if not ok: raise RuntimeError(message)
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def main():
    require(sys.argv[1:] == ['--execute'], 'Root execution requires exactly --execute')
    require(os.path.ismount('/mnt/fast4tb') and os.access(HERE, os.W_OK), 'task mount unavailable')
    require(sha(HELPER) == '1b0d99b3cb70c785fcd9faa0453ccc82b3cda2b6c5fb20ccb955dd92aa6e1132', 'process helper drift')
    require(sha(ELIGIBLE) == '7b35dcd3536297a51ce2908697693b223a7b7bd00cd8c0b402612f1b8ea96c97', 'eligible helper drift')
    h, r = load('profile_process', HELPER), load('profile_eligible', ELIGIBLE)
    signal.signal(signal.SIGTERM, h.interrupted); signal.signal(signal.SIGINT, h.interrupted)
    for name, digest in EXPECTED.items(): require(sha(HERE/name) == digest, 'frozen packet drift: '+name)
    plan = json.loads((HERE/'plan.json').read_text())
    contract = json.loads((PREV/'contract.json').read_text()); binding = contract['sources']['candidate']
    source = pathlib.Path(binding['path']); out = HERE/'run1'; out.mkdir(mode=0o700); (out/'bin').mkdir()
    records = [{'label': cell['label'], 'status':'unattempted', 'completed':None, 'failure':None, 'metrics':None} for cell in plan['attempts']]
    failure = None; state = None; inventory = None; protected = {}; build = None
    def custody():
        require(r.source_state(binding, 'diagnostic15') == state, 'source state changed')
        require(r.inventory(binding) == inventory, 'complete source inventory changed')
        for path, digest in protected.items(): require(sha(path) == digest, 'protected file changed: '+path)
    def known(name):
        found = r.competing_go(); r.write(out/(name+'.known-go.json'), {'utc':h.utc(),'processes':found})
        require(not found, 'known Go work or observer error before '+name)
    def step(name, argv, env, wall, observed=False):
        custody(); known(name)
        r.write(out/(name+'.attempt.json'), {'argv':argv,'cwd':str(source),'environment':env,'wall_seconds':wall})
        receipt = (r.measured_process(h, argv, str(source), env, str(out/(name+'.log')), wall) if observed
            else h.run_process(argv, str(source), env, str(out/(name+'.log')), wall))
        try: custody(); receipt['source_and_files_unchanged'] = True
        except BaseException as error: receipt['source_and_files_unchanged'] = False; receipt['custody_error'] = repr(error)
        r.write(out/(name+'.receipt.json'), receipt)
        require(receipt['process_ok'] and receipt['source_and_files_unchanged'], name+' process/custody failure')
        require(not receipt.get('competing_go_observations'), name+' known Go overlap or observer error')
        return receipt
    try:
        state = r.source_state(binding, 'diagnostic15'); inventory = r.inventory(binding)
        require(inventory == json.loads((PREV/'source-files-before.json').read_text())['candidate'], 'original candidate inventory changed')
        r.write(out/'source-before.json', state); r.write(out/'source-files-before.json', inventory)
        paths = [pathlib.Path(__file__), HELPER, ELIGIBLE, PREV/'contract.json', PREV/'source-files-before.json',
                 GO_ROOT/'bin/go', GO_ROOT/'bin/gofmt', *[HERE/name for name in EXPECTED]]
        for cell in plan['attempts']:
            original = pathlib.Path(cell['original_report']); require(sha(original) == cell['original_report_sha256'], 'original report drift')
            paths.append(original)
            old = json.loads(original.read_text())
            for key, expected in [('HTTPBinary', 'server_http_sha256'), ('NativeBinary','server_native_sha256')]:
                require(sha(old[key]) == json.loads((HERE/'manifest.json').read_text())[expected], 'selected server ELF drift')
                paths.append(pathlib.Path(old[key]))
        protected.update({str(path):sha(path) for path in paths})
        env = h.safe_env({'GOROOT':str(GO_ROOT),'GOTOOLCHAIN':'local','GOMAXPROCS':'4','GOGC':'100',
            'GOMEMLIMIT':'off','GODEBUG':'','GOCACHE':str(ROOT/'gocache'),'TMPDIR':str(ROOT/'tmp')})
        require(all(pathlib.Path(env[key]).is_dir() and os.access(env[key],os.W_OK) for key in ('GOCACHE','TMPDIR')), 'cache/tmp unavailable')
        step('toolchain', [str(GO_ROOT/'bin/go'),'version'], env, 30)
        require((out/'toolchain.log').read_text().startswith('go version go1.26.0 '), 'wrong toolchain')
        formatted = out/'command_public_bench_test.go'; formatted.write_bytes((HERE/'candidate-driver.go').read_bytes())
        step('gofmt', [str(GO_ROOT/'bin/gofmt'),'-w',str(formatted)], env, 60)
        protected[str(formatted)] = sha(formatted)
        overlay = out/'overlay.json'; r.write(overlay, {'Replace':{plan['source_path']:str(formatted)}})
        protected[str(overlay)] = sha(overlay)
        binary = out/'bin/driver.test'
        build = step('build-driver', [str(GO_ROOT/'bin/go'),'test','-c','-p=1','-overlay',str(overlay),'-o',str(binary),'./cmd/treedb-document-service'], env, 600)
        require(build['exit_code'] == 0, 'dependent driver build must exit successfully before cells')
        protected[str(binary)] = sha(binary)
        execution = {'frozen_utc':h.utc(),'kind':'two-cell server profile diagnostic; no timing qualification',
            'prepared_plan_sha256':EXPECTED['plan.json'],'source':state,'full_inventory_sha256':sha(out/'source-files-before.json'),
            'protected_files':dict(protected),'formatted_overlay_sha256':sha(overlay),'formatted_driver_sha256':sha(formatted),
            'driver_elf_sha256':sha(binary),'driver_build_receipt_sha256':sha(out/'build-driver.receipt.json'),
            'original_server_elves_unchanged':True,'cells':plan['attempts'],'retries':0,'qualification':None}
        r.write(out/'root-execution-plan.json',execution); protected[str(out/'root-execution-plan.json')] = sha(out/'root-execution-plan.json')
        for cell, record in zip(plan['attempts'], records):
            label = cell['label']; prefix = out/label
            record['status'] = 'attempted_invalid'
            cellenv = dict(env, **cell['env']); cellenv.update(GOROOT=str(GO_ROOT),GOTOOLCHAIN='local',GOMAP_COMMAND_PERF_OUTPUT=str(prefix))
            argv = [str(binary),*cell['driver_argv'][1:]]
            step(label, argv, cellenv, 780, observed=True)
            slot = {'name':label,'command':'http','operation':'keyword','role':('L' if cellenv['GOMAP_COMMAND_PERF_LEGACY']=='1' else 'N'),'prefix':str(prefix)}
            pair = {kind:{'path':cellenv[key], 'sha256':sha(cellenv[key])} for kind,key in [('http','GOMAP_COMMAND_PERF_HTTP_BINARY'),('native','GOMAP_COMMAND_PERF_NATIVE_BINARY')]}
            validation = r.report_validation(pathlib.Path(str(prefix)+'.json'),slot,pair)
            report = json.loads(pathlib.Path(str(prefix)+'.json').read_text()); profile = report.get('server_profiles',{})
            checks = {}
            for key,suffix in [('AllocsBefore','.server-allocs-before.pprof'),('AllocsAfter','.server-allocs-after.pprof'),('CPU','.server-cpu.pprof')]:
                artifact = profile.get(key,{ }); path = pathlib.Path(str(prefix)+suffix)
                checks[key] = (path.is_file() and artifact.get('Path') == str(path) and artifact.get('HTTPStatus') == 200
                    and not artifact.get('Error') and artifact.get('Bytes',0) > 0 and artifact.get('SHA256') == sha(path))
            checks['no_profile_errors'] = not profile.get('Errors') and bool(profile.get('Scope'))
            validation['profile_checks'] = checks; r.write(out/(label+'.validation.json'),validation)
            record.update(completed=report.get('Completed'),failure=report.get('failure'),profile_checks=checks)
            require(validation['valid'] and all(checks.values()), label+' original report/profile invalid')
            record['status'] = 'valid'
    except BaseException as error:
        failure = repr(error)
        if 'record' in locals() and record['status'] == 'attempted_invalid':
            record['failure'] = failure
            if not (out/(record['label']+'.attempt.json')).exists(): record['status'] = 'unattempted'
    finally:
        # No second interrupt may discard terminal failure/null and custody receipts.
        signal.signal(signal.SIGTERM, signal.SIG_IGN); signal.signal(signal.SIGINT, signal.SIG_IGN)
        final_errors = []
        try:
            after = r.source_state(binding,'diagnostic15'); inv_after = r.inventory(binding)
            r.write(out/'source-after.json',after); r.write(out/'source-files-after.json',inv_after)
            require(after == state and inv_after == inventory, 'terminal source mismatch')
            for path,digest in protected.items(): require(sha(path) == digest, 'terminal protected mismatch: '+path)
        except BaseException as error: final_errors.append(repr(error))
        for cell,record in zip(plan['attempts'],records):
            reportpath = out/(cell['label']+'.json')
            if reportpath.exists():
                try:
                    report = json.loads(reportpath.read_text()); record['completed'] = report.get('Completed'); record['product_profile_failure'] = report.get('failure'); record['cleanup_errors'] = report.get('cleanup_errors',[])
                except BaseException as error: record['report_parse_error'] = repr(error)
        summary = {'kind':'diagnostic_only','failure':failure,'terminal_custody_errors':final_errors,'records':records,
            'all_valid':failure is None and not final_errors and all(x['status']=='valid' for x in records),'qualification':None}
        r.write(out/'summary.json',summary)
        print(json.dumps({'output':str(out),'all_valid':summary['all_valid'],'failure':failure,'terminal_errors':len(final_errors),
            'cells':[{'label':x['label'],'status':x['status'],'completed':x['completed']} for x in records]}))
    return 0 if summary['all_valid'] else 1
if __name__ == '__main__': sys.exit(main())
