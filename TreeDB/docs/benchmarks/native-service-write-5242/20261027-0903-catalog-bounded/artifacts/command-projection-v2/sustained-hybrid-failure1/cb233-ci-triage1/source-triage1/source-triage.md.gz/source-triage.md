# Source-only causal triage and fixture proposal

The strongest source-supported hypothesis is outstanding asynchronous root
publication invalidating this fixture's GC capability. This is a concrete legal
interleaving, not a confirmed phase attribution for the recorded CI failure.
The original failure remains failed; this packet supplies no runtime result,
flake waiver, unrelated-change classification or CI acceptance.

## Recorded failure

Canonical HEAD cb2330cf237b14ff8bcb6d90c57541168edab60e; workflow 40463094876,
job 122052031101 (job identities supplied by root). Retained log
`../../cb233-macos2.log` is at the sustained-hybrid-failure1 level, one
level above cb233-ci-triage1. Lines 36942–36946 name
`TestValueLogGC_KeepsSegmentMadeReachableByDeltaGroupSystemDescriptorOnly`;
maintenance_roots_test.go:450 reports exactly
`ValueLogGC: treedb: recoverable root set changed`. The log does not identify the
internal GC phase or failed root-proof component.

## Causal route in the bound source

1. maintenance_roots_test.go:428 builds an unattached collection root, primes the
   tracker at 432–436, then attaches only its system descriptor through the
   delta-group builder at 438–445. The tracker/full-scan oracle at 446 verifies
   the logical update, but does not drain physical publication. No test goroutine
   or further logical write is needed for an outstanding publisher to advance.
2. ordered_root_publish.go:2269 and 2469 pass syncWrite=false into finalization.
   root_publication_activation.go:1389 waits for admission; its 1403–1405 seal
   wait is conditional on startup/prepared limits/sync. Open completes startup
   (db.go:3097), so these ordinary calls can return with coordinator-owned debt.
3. ValueLogGC first resolves visible references, then captures the recovery
   closure (vlog_gc.go:207–260). maintenanceMu excludes maintenance operations,
   but does not drain or exclude the root publisher. The source's scan retry
   fences visible commit sequence only, not completion of existing durable debt.
4. A seal can complete while GC consumes that capability. Publisher Prepare owns
   durablePublishMu (root_publication_activation.go:1456); durable commit updates
   slot/root/proof state under that mutex (same file:1946–2000 for DATA;
   durable_primary_runtime_v5.go:698–834 for PRIMARY). Coordinator completion
   increments reachabilityEpoch (primary_terminal_completion_v6.go:62–65).
   Visible document/schema roots need not change.
5. That can fail at more than one location. AcquireSnapshotForRoot revalidates
   and returns nil on any refusal (recoverable_root_set.go:739–744), mapped back
   to this exact sentinel at vlog_gc_incremental.go:794–796. At the final
   destructive guard (vlog_gc.go:589–593), durablePublishMu contention alone
   refuses via TryLock; coordinator epoch, visible/index/system epoch, or durable
   basis mismatch also refuses (recoverable_root_set.go:905–947). The bare
   sentinel in CI cannot distinguish these. Capture nonconvergence would append
   `capture did not converge`, which this log does not show.

The refusal precedes MarkZombie in this call (vlog_gc.go:592–598); preserving it
protects recovery-selectable reachability. A successful reference-tracker oracle
is consistent with this failure because that oracle proves counts, not stability
of the later recovery closure. CheckStorageMaintenanceReady is admission/poison
checking, not a publication drain (api.go:513).

The exact target and principal GC/publisher paths inspected have no committed
change from f429275bbf0c0bda2cedfc9d5862200cee067ff5 to HEAD. That narrows code
attribution but does not prove this occurrence unrelated to candidate execution
or timing. Root's earlier issue history is context only; no same-cause claim is
made from #4152/#4153, #3846 or #3839. The maintained leaf-generation fixture at
leaf_generation_gc_test.go:970–979 explicitly uses Checkpoint plus its drained
assertion for the same class of recovery-root stability requirement.

## Smallest selected repair

`selected.patch` changes only this target test. It inserts Checkpoint and existing
requireLeafGenerationGCPublisherDrained immediately AFTER the original
assertCandidateTrackerMatchesFullScan. Checkpoint seals the already-visible
prefix without advancing logical CommitSeq (db.go:4760–4766, 4930–4948); the
existing helper checks zero queued commits and durable >= visible (the helper
is at leaf_generation_gc_test.go:166–182).

Keeping the tracker oracle before the fence is essential: otherwise candidate
sealing could repair tracking before the tested delta-group update is checked.
The builder still receives no ordered roots, requires zero returned IDs and
installs exactly the descriptor under test. The original unreferenced deletion,
referenced retention, segment geometry and all other assertions remain byte-for-
byte intact. No production guard, scheduling, durability or resource limit is
changed. Do NOT use advancePastRetainedDurableSlotForTest: it replaces the system
root and would remove the live descriptor being tested. No product doc change
is needed for this fixture-only precondition.

## Next discriminating proof, using existing seams

A deterministic forcing control is feasible without production hooks. Root owns
implementation and runtime; this is a design, not an executed test:

- In an isolated diagnostic variant of this same fixture, first settle the
  unattached-root enqueue before installing the pause, then retain the original
  tracker prime, descriptor-only builder and tracker/full-scan oracle. This
  initial settling is diagnostic coordination only, not part of selected.patch.
- Install a root-directory-filtered, one-shot durabilitycut.Install pause at
  BeforeMetaWrite/ResourceMeta, which both selected authority paths emit
  (root_publication_activation.go:1831 and durable_root_runtime.go:2163). Arm it
  only for the final descriptor enqueue after earlier publication is drained.
  Wait on an entered channel, verify final visible sequence and pending debt.
  The pause occurs AFTER Prepare has completed, so the captured final candidate
  needs no later prepare admission to finish. Use a bounded failure deadline on
  coordination waits, never a scheduling sleep.
- For the OLD no-fence variant, run GC while the publisher is paused. Its existing
  per-DB testValueLogGCBeforeRevalidateHook releases that paused publisher and
  waits with a bounded context on the SAME coordinator.WaitThrough(finalVisibleSeq),
  not a new logical
  publish or retry. Assert unchanged visible StateToken, durable completion,
  hook entry, ErrRecoverableRootSetStale, zero deletions and both segment files
  still present. This forces a real durable/epoch transition between capture
  and destructive revalidation. Use WaitThrough directly inside this hook:
  GC already holds publishPrepareMu exclusively, so allowing a fresh Prepare or
  logical root publication here would create a lock-order deadlock. The pause
  must demonstrably belong to the already-prepared FINAL candidate.
- For the NEW fenced variant, release the same final publisher while the inserted
  Checkpoint is waiting, and require the existing drained assertion before GC.
  GC's pre-revalidation hook should merely verify no pending debt and stable
  visible/durable state. Require the original successful GC, unreferenced-file
  deletion and referenced-file retention; no second GC attempt or retry.
- Restore global durabilitycut hook and per-DB hook, release channels on failure,
  and join the publisher in cleanup. Existing controls to preserve/run alongside
  are TestRecoverableRootSetRejectsDurableAdvanceAfterCapture,
  TestReachabilityEpochInvalidatesOnEnqueueAndDurablePublish and the maintained
  `TestMarkValueLogZombieTreatsStaleRecoverableRootSetAsDeferred` at
  vlog_gc_test.go:414–477. Their existence already
  supports the guard's contract; the forcing control tests this fixture route.

This control would establish that the proposed fence eliminates the forced legal
interleaving, while keeping the original CI phase attribution explicitly unknown.
If repaired GC still refuses with a proved drained prefix, discriminate the
root-walk snapshot acquisition from final revalidation and record coordinator
epoch, visible/index/system epoch and durable basis before broadening the fix.
No blind CI rerun or production relaxation follows from this packet.

Static check only: git apply --check passed against the bound original test.
No Go/gofmt/tests/runtime/GitHub writes or canonical edits were performed.
