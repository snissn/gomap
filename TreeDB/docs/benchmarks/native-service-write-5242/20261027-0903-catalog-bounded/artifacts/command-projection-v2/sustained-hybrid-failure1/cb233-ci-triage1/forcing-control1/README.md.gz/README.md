# Deterministic descriptor-only GC forcing control (source-only)

The supplemental test uses the original segment IDs, payloads, detached pointer
root, tracker prime, descriptor-only delta-group builder and tracker/full-scan
oracle. A preliminary Checkpoint settles ONLY the earlier detached-root enqueue,
so the root-filtered one-shot BeforeMetaWrite pause belongs to the final descriptor
candidate. No profile, cap, live descriptor or reachability assertion is weakened.
The existing proposed repair patch is not included or changed.

The default resolved authority path is used, without selecting an alternate
engine or forcing both authority implementations. DATA and PRIMARY authority
writers both emit BeforeMetaWrite/ResourceMeta after Prepare; the observed path
is logged. The test refuses if exactly one final unsealed descriptor is not
pending. No borrowed Event handle is retained. WithPinnedFile invokes its callback
without holding a token mutex (resource_token.go:916), so the pause itself adds no
resource-clone lock to GC.

`unfenced_stale` keeps the final candidate paused while GC captures and classifies.
The existing per-DB pre-revalidation hook releases it and waits through its exact
visible sequence on the same coordinator. Prepare has already returned, so this
finish needs no GC-held publishPrepareMu. The control requires hook entry exactly
once, unchanged visible state, completed physical prefix, stale refusal, zero
deletions, both segments present and the descriptor's exact original value.
There is only one GC call per subtest.

`checkpoint_fenced` releases the same pause before the proposed Checkpoint fence,
then requires the maintained publisher-drained assertion before its single GC.
Its pre-revalidation hook verifies stable visible state and no pending prefix.
The original successful GC, unreferenced-segment deletion and descriptor-segment
retention assertions remain, plus an exact retained-value read. The tracker oracle
runs before the final Checkpoint in both variants.

Every test exit releases the pause, restores the global observer, clears the
per-DB hook, bounds an original-coordinator Drain, and invokes original DB.Close,
which joins/stops that scheduler before storage teardown. The pause context is
cancelled after cleanup. Stop must not precede Close: Close first calls Drain,
and Drain on an already-stopped coordinator would manufacture a cleanup failure. There are no test-created worker
goroutines, scheduling sleeps, second GC attempts, logical body retries or new
production seams. The 30-second contexts bound diagnostic coordination and
WaitThrough/Drain, not product performance; public Checkpoint/Close keep their
original synchronous API. If an actual storage operation stops responding to
coordinator cancellation, the enclosing root-owned Go test timeout remains the
outer process bound, as for the existing fixture.

`overlay.json` adds only the supplemental test file; canonical remains untouched.
`recipe.json` contains unexecuted focused and race argv. Root owns Go/gofmt,
compilation, API verification, execution, independent review and any integration.
Static source lookup confirmed referenced names/signatures and callback phase;
no Go parser/compiler/runtime ran here. In particular, the preliminary detached-root
Checkpoint and the paused recovery scan still require runtime confirmation. A
successful forcing control would prove this legal interleaving and the fence's
response; it would not uniquely attribute the retained CI failure's internal phase.
