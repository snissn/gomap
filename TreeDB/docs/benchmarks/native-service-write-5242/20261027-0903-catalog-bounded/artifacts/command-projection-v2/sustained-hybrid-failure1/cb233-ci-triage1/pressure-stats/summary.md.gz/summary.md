## Public Stats diagnostic

- Verdict: **FAIL**; product guard available: False.
- Exact base/head: `f429275bbf0c0bda2cedfc9d5862200cee067ff5` / `cb2330cf237b14ff8bcb6d90c57541168edab60e`.
- Three pairs AB/BA/AB, GOMAXPROCS=1, CPU0, 250ms; retained rows: 6/6.
- Detail: `{"gates": {"allocations": true, "bytes": false, "timing": true}, "measurement_pass": false, "median_paired_delta_percent": 1.7555840783136878, "medians": {"baseline": {"B/op": 719983.0, "allocs/op": 2806.0, "ns/op": 534466.0}, "candidate": {"B/op": 719997.0, "allocs/op": 2806.0, "ns/op": 548140.0}}, "paired_deltas_percent": [1.7555840783136878, 3.700872908066555, -0.8326130226162576], "quiet": true}`
- Diagnostic only; NULL/failure supplies no product acceptance. PRIMARY is unchanged.
