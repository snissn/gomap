# Adapter repair2: distinguish work refusal from phase progress

Source-only, unformatted; no Go/gofmt/build/runtime. The root's adapter-focused1 failure and all original tests remain unchanged. All four before-images exactly equal current root-formatted canonical files when captured. Only valuelog adapter and its test change; caching routing/lifetime tests and original data/workload/caps remain byte-identical.

## Causal source proof

Both retained failures panic from constructor error cleanup, rather than the final normal Close. Initial NewCOWBoundedDecoder calls ResetStep to establish the owned empty binding and complete grammar validation. Upstream zstd.clearBounded calls huff0.TableState.ClearStep. That maintained routine is a single switch, not a loop: its phase0 reserves/detaches input and returns false; phase1 advances to phase2 and returns false without any Reserve when the optional FSE scratch does not exist. The same empty TableState branch occurs for initial/reset/error/Close cleanup. It is progress in the private finite cleanup grammar, not an indivisible work unit that failed admission.

Candidate1 nextQuantum incorrectly tested started && quantum.Records==0 && quantum.Bytes==0 on every false continuation. This turns the legitimate phase1 yield into ErrCOWReadCapacity. Constructor then calls Close, whose cleanup reaches the same phase-only yield and panics, masking the initial spurious error. Larger quanta or altered cap/accounting cannot repair that semantic distinction.

Repair2 adds one scalar blocked flag in the already-admitted adapter. It is set ONLY when original OrdinalScanWork.Reserve actually refuses an otherwise non-overflowing request. nextQuantum rejects an unused fresh quantum only when that real refusal occurred. Every accepted replenishment clears blocked; beginOperation clears it as well. Failed atomic Reserve still has no operand effects. Stored capacity/overflow errors are checked first and never replenished. No work total, quantum size, admission expression, backing capacity or receipt changes. sizeof-based wrapper admission still covers the real type, including its scalar field.

## Sibling audit

- Constructor NewBoundedReaderWithLimits returns false only after a genuine Reserve refusal: fresh oversized control still fails, and Retain/capacity errors still unwind rather than retry.
- Initial/ordinary ResetStep and terminal/error CloseStep may yield between finite huff0 cleanup phases. They now continue normally, through the SAME phase graph and concrete refunds. No release/custody ordering changes.
- zstd/huff/fse work sites still reserve before consuming effects. Available-only emit/RLE/skip paths choose bounded chunks (at most4096 plus checksum state), so a fresh4MiB quantum cannot hit their no-byte tail cases; ordinary consumed-quantum tails replenish as before. No new negative-progress threshold is invented.
- The maintained empty Huffman ClearStep traverses four switch phases; exactly one no-Reserve phase exists when optional FSE is absent. Segmented history and optional allocated FSE cleanup retain original Reserve/Release paths. This finite grammar supplies the liveness witness for allowing phase-only false returns; arbitrary false/no-state-progress behavior would violate the selected upstream API.
- Retain/ResizeWork refusal remains stored in work.err and propagates before replenishment; cleanup starts its own finite operation after preserving the original error. All aliases still detach before original same-lease Release. No original decoder/input/dictionary owner changes.

## Added meaningful component control

TestCOWBoundedDecoderCleanupPhaseYieldAndOversizedUnit drives actual maintained huff0.TableState.ClearStep with the adapter work bridge until done. It requires observing the real false/no-Reserve phase and permits its next quantum. It then requests an actual oversized unit on a fresh quantum and requires the original finite ErrCOWReadCapacity. Candidate1 fails this phase-only control. Existing dictionary/reset/native packed-leaf, real finite refusal, malformed constructor, concurrency, concat/shape and overflow controls are preserved verbatim.

Root next: format these two changed files, run the same focused selectors plus this new component, then changed-risk race/owning controls and original fresh-server Hybrid1000 once. This source repair is not a claim of runtime success, capacity fit or performance acceptance. No unrelated root/canonical/ee160 source was changed.
