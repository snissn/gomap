# Independent observer1 source review

**ACCEPT for the stated diagnostic-only run; no material finding.** This review checks source and signatures only. No Go/gofmt/build/test/application runtime was executed, and canonical files were not modified. No timing, allocation, drain-count or product acceptance is supplied.

## Exact binding

- `diagnostic.patch`: `17c54c5b0a8a521f59f770897a3fe7740c6111afa0bfcb879fcc9e2d619c0528`
- `manifest.json`: `fbc8597d2d4dda02bf1b27731f0f296f95575cfff6c4f0012e431c858c96fc2e`
- `overlay.json`: `1858e1f60318f937ab1558669c806a62fb550163e1f25707ffb57c54cd0a6f29`
- `README.md`: `24cb3613243d9cc0dec01fbeeb21ad79facbc33d3cc84f3af7927c893b87658b`

Both canonical preimages and all manifest contract bindings matched at review. The Go overlay maps exactly the two listed canonical paths to their frozen external copies.

| Path | Canonical/preimage SHA256 | Overlay SHA256 |
|---|---|---|
| `TreeDB/caching/cow_native_txn.go` | `cc2e7970bae5fcc433487a6546c0668cf7a3214803e716044dde46fb7198ab2b` | `6267c86a89f5c1580a7816e79d9021461bf1c38700bdb58cf0149da2a76f0f37` |
| `TreeDB/documentservice/shared_cow_write_bench_test.go` | `dd6d7ebcb5638badbb938ba9891c557e51fe3e9c583fc1d679d4e8f02ec29263` | `14fbd946ea66e07d75b66a436cde39d143489036265900e0bbe0e5df10707737` |

## Scoped conclusions

- The maintained workload remains 4096 documents, fixed batches of 128 (32 calls), original worker allocation/order and writers1/writers4 selector. Every call still passes the original `ctx`, index, exact document slice and `DeferVectorIndexRebuild: true`. The overlay adds no request retry, new source query, altered batch condition or early-success path. Original response/ID/attempted/completed assertions, owned-directory cleanup, document checks, Optimize, query checks, Close, reopen, result parity and reopened Close are unchanged.
- Original timer boundaries remain StartTimer immediately before releasing the start channel and StopTimer after all workers complete. The new outer region encloses them; per-request tasks/regions/logs run within the instrumented request-load interval. Task allocation and formatting/trace overhead are therefore part of this diagnostic, not timing/allocation improvement evidence.
- Producer instrumentation uses only the original three observation results (initial, locked-before and after-cleanup), existing limits and scalar fields. `underPressure`, remembered-state comparison/update, close guard, pressure mutex, prefix-versus-checkpoint condition/calls, cleanup join, returned observations and all error branches remain unchanged. The helper repeats the original threshold operands only to label causes; its booleans cannot choose a branch. It neither retains the observed cut nor calls an observer, allocator, capture or source scanner.
- The original observation releases its cut before return, so formatting existing copied state does not prolong source/capture ownership. Trace APIs add no COW receipt, promise or maintenance owner, no cap relaxation and no shared mutation. The pressure wait region ends after Lock; held region covers the existing protected body and ends on each return before the deferred Unlock. Drain and cleanup regions end on their original error paths as well as success.
- Source signature checks pass against Go1.26.0 runtime/trace annotation declarations: NewTask returns context and *Task; StartRegion returns *Region; Log/Logf and End calls match. Original service UpsertDocuments returns the same response/error fields used in logging; pressure/limit field names and format operand types match current contracts. This is not a compiler receipt.
- Request context intentionally remains unchanged. Request task regions and background-task pressure regions must be joined by actual GoID/time containment, as the README says; task ID alone is not a join. Before/after snapshots are advisory, and concurrent logical suffix publication prevents treating their difference as exact reclaimed rows or debt. The packet correctly leaves drain rows null and supplies no collection materializer overlay.

No further framework or tests requested. Root owns the fresh diagnostic run, raw failures and source/ELF/trace bindings; instrumented observations do not replace acceptance evidence.
