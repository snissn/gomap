# Pressure-materializer Waiting attribution

This addendum substitutes exact state attribution within the frozen 494.394112 ms pressure-materializer union; it adds no measurement. The original 297.983360 ms Waiting component partitions as follows. There is no simultaneous pressure materializer in the frozen masks, so these elapsed intervals are disjoint across workers.

| Exact blocking stack/reason | Union ms | Observed blocked intervals |
|---|---:|---:|
| `PhysicalSealReceipt.Wait → Coordinator.WaitThrough`, `select` | 264.775424 | 10 |
| `ApplyWorkerPool.run → WaitGroup.Wait`, `sync` | 29.852480 | 67 |
| `prepareRows.func9 → chanrecv1`, typed-column result | 3.355456 | 10 |
| Total | 297.983360 | 87 |

The five distinct zipper ancestor paths remain separately recorded in `stack-groups.json`: ordered-root application 11.217024 ms, native-domain source build 9.493184 and 7.974656 ms, typed materialization 1.040704 and 0.126912 ms. All are woken by `ApplyWorkerPool.worker` completing its WaitGroup. The typed result waits are woken by `prepareRows.func8`. No timer, sleep, cleanup, or other blocked stack occurs in this Waiting partition. Blocked-interval counts are not request, drain, build, or syscall counts.

All ten seal-wait intervals are woken by goroutine 56 through `Coordinator.satisfyWaitersLocked → completePublicationLockedV6 → dispatchPublication`. Intersecting goroutine 56's exact state intervals with only these ten disjoint windows accounts for their entire 264.775424 ms:

| Publisher state/stack within seal-wait windows | Union ms |
|---|---:|
| Syscall `Fsync → File.Sync → stableio.SyncFile → StableResourceToken.syncThrough → StableResourceSet.SyncThrough → syncStableResourceDependenciesV1` | 209.594112 |
| Syscall `Fdatasync → pager.syncPageFileData → SyncIndexDataWithStableFileAtPath` | 32.961600 |
| Syscall `pwritev2 → pager.syncPageRangesData → SyncPagesWithStableFile` | 17.939200 |
| Other syscalls: close/fstat/openat/dup/fcntl | 0.232320 |
| Running, not assigned to a function | 3.954816 |
| Runnable | 0.093376 |
| Total | 264.775424 |

Thus 260.494912 ms of the seal wait overlaps the publisher's three explicit storage syscall families; all publisher Syscall intervals total 260.727232 ms (98.47% of the seal wait). This is syscall-state elapsed time, not a disk-service-time measurement. The publisher has no Waiting state inside these windows. These numbers replace attribution inside the original worker wait; they must not be added to the 297.983360 or 494.394112 ms unions, nor to the worker-74 additive partition. No function duration or operation count is inferred from a transition stack. Raw syscall grouping does not establish duplicate file/frontier syncs.

Source ties use the retained trace's `native-pressure-drain1` paths. `coordinator.go:538–587` creates the waiter, requests `WakeWaiter` at 558, signals at 560, and receives the completion channel at 562–564. This is an explicit publish request, not ordinary adaptive-coalescing timer dwell. `primary_terminal_completion_v6.go:62–76` installs the completed durable frontier before satisfying waiters; `coordinator.go:1288–1299` wakes only sequences covered by that frontier. `dispatchPublicationCallV6` invokes the real publisher (`coordinator.go:931`). `durable_root_runtime.go:2122–2147` preserves dependency→index→meta ordering and calls dependency synchronization; `resource_token.go:643–651` gives the maintained default content-fsync primitive. The independent pager callbacks are in `root_publication_activation.go:1874+`. The other waits are actual workers: `zipper/apply_worker_pool.go:90–124` sends task runs then waits at 123; `column_publish_write.go:1937–1973` starts typed building and receives its result at 1959.

Decision: the repeated foreground pressure path is chiefly waiting for real durable publication, not a removable timer or cleanup wait. This strengthens investigating fewer necessary physical publications or safely shared work over producer-lock microtuning. It does not authorize deleting durability fences or claim the current publisher syncs redundantly. The pending original-owner observer remains the smallest next discriminator: preserve its actual source/member and byte trigger operands and carried population. If source-count pressure dominates with byte headroom, a representation-only byte saving cannot change that frequency; an integration/grouping decision must preserve every original ACK/admission/namespace frontier. If byte pressure dominates, representation that safely permits more pending work may reduce these real fences. No grouping or representation implementation is selected from this trace alone: exact drain population, resource identities/frontiers and possible safely shareable syncs remain unavailable here. Original request/ACK semantics, finite limits and all frozen masks remain unchanged.
