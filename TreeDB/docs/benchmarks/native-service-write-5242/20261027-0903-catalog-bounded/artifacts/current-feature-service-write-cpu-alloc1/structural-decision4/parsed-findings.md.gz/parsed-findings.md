# Streamed retained trace result and next source-only observer

Official root-decoded Go1.26.0 parsed logs were streamed twice, never loaded whole. `stream_extraction.py`, `derive_masks.py`, compact interval arrays and summaries are frozen with input/output hashes in `parsed-analysis-binding.json`. No Go or custom binary parser was used here. Four original native workers are GoIDs74–77; legacy72–75. Both have zero state discontinuities and zero task/region/log annotations. All32 completed requests were verified by the original receipts, not reconstructed from event samples.

**Observed load:** native earliest original start-channel release to last worker exit727.761792ms, only5.684us below its actual instrumented benchmark727.767476ms. Legacy equivalent span98.739264ms. These are trace diagnostics; do not substitute their ratio for the uninstrumented diagnostic5 ratio. Worker74 is the last finisher; its release-to-exit span727.761472ms partitions ADDITIVELY as follows:

| Disjoint state/stack interval | ms |
|---|---:|
| Waiting on original DB pressure mutex |304.504512|
| Inside pressure materializer, Syscall |72.243264|
| Inside pressure materializer, Waiting |154.220416|
| Waiting on original collection mutation gate |117.147520|
| Direct own ACK Syscall |10.714560|
| Running, phase unattributed |67.059007|
| Runnable |1.526464|
| Cleanup-frontier wait |0.177089|
| Other syscall |0.161536|
| Other preparation wait |0.007104|
| **Sum, exactly worker74's span** |**727.761472**|

Across all workers, the concurrent-mask sweep sums exactly727.761792ms. At most ONE worker is observed in pressure materializer wait/syscall at a time. Its Waiting297.983360ms and Syscall196.410752ms have ZERO overlap, so their union is exactly**494.394112ms (67.93% of observed load)**. This is observed state occupancy, not removable fraction. Pressure-mutex waiting union523.277824ms overlaps that union by456.820224ms: DO NOT add them. The66.457600ms pressure-wait union outside observed materializer intervals can include owner Running work and observation/no-op calls; it is not proved wasted lock time. Collection-gate wait union150.306048ms is almost wholly outside observed materializer intervals (150.154368ms outside). Runnable union is only6.291070ms. No request boundaries, drain count or rows/drain are inferred from those intervals.

**Next choice:** pressure-induced physical work is the first representation/integration question; a general work-conserving ACK combiner or narrower collection gate cannot by itself remove the observed494.394112ms materializer state occupancy. The already maintained physical insert-span fold is active in this source, so another wrapper/span/appender is not selected. Before choosing a new representation, distinguish repeated small cuts from a small number of necessary large cuts and identify which original watermark fires. The next observer below supplies that minimum missing evidence, without changing ACK, caps, semantic publication, constructor promises or durability fences. No implementation is selected.

`observer1` is an UNEXECUTED external diagnostic-only overlay for exactly `cow_native_txn.go` and the original public benchmark file. It adds preparation/pressure-lock/actual-drain/cleanup regions; logs ONLY the already-computed initial, locked-before and after-cleanup scalar observations plus each original trigger operand; and marks original request task/member/result and load boundaries. Actual drain regions wrap ONLY the existing branch at157–161 and emit its original error. Skips under the watermark and unchanged remembered observations remain skips. There are no extra observations/captures/scans, no retry, new counter, governor, production flag, API or changed request context. Original context.Background still reaches the materializer and original ctx still reaches Upsert. Formatting/runtime validation is exclusively root's. Trace formatting/allocation perturbs timings: NO timing credit.

Crucial units: `NativeSemanticProducerPressure.Sources` is the actual pending typed-member count returned by the existing inventory (`native_typed_engine.go:21–52,387–405`); COW budget Sources is a distinct resource count. Log BOTH source limits and generation/byte limits so MaxSources32 is distinguishable from construction or live-byte pressure. **Actual selected/physical rows remain null in this two-file packet.** Pressure function has no materializer row slice; multiplying members by128 is not an observed row count. If row population remains necessary after original state logs, a separately reviewed minimal log at already-produced `len(w.input.deltas)`, `len(mutations)` and final `len(physical.rows)` (`native_typed_materialize.go:855–883,979+`) would expose it without storage inspection; that third-file overlay is not included or selected here. No new packet is needed just to infer rows speculatively.
