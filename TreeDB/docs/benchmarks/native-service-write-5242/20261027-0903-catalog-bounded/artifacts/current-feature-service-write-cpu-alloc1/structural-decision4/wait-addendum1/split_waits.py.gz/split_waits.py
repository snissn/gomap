"""Stream official parsed text; match frozen real waiting intervals by GoID/time."""
from pathlib import Path
import json,re,collections
O=Path(__file__).resolve().parent; P=O.parent
I=json.loads((P/'01-native-intervals.json').read_text())
target={(x['gid'],x['start']):x for x in I if x['category']=='Waiting:pressure_materialize'}
H=re.compile(r'^M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+)');T=re.compile(r'GoID=(\d+) (\w+)->(\w+) Reason="([^"]*)"')
p=Path('/mnt/fast4tb/gomap-mongo-execution-20261024/evidence/current-feature-service-write-trace3/parsed1/01-native.log')
def blocks():
 b=[]
 with p.open() as f:
  for line in f:
   if line.startswith('M='):
    if b:yield b
    b=[line]
   else:b.append(line)
 if b:yield b
found=[]
for b in blocks():
 h=H.match(b[0]);t=T.search(b[0])
 if not h or not t:continue
 key=(int(t[1]),int(h[5]));x=target.get(key)
 if x is None:continue
 assert t[3]=='Waiting'
 s=''.join(b);stack=s.split('TransitionStack=\n',1)[1].split('\nStack=\n',1)[0]
 symbols=[q.strip().split(' @ ')[0] for q in stack.splitlines() if q.startswith('\t') and not q.startswith('\t\t')]
 sites=[q.strip() for q in stack.splitlines() if q.startswith('\t\t')]
 found.append(dict(x,reason=t[4],transition_stack=stack,symbols=symbols,sites=sites))
assert len(found)==len(target),(len(found),len(target))
assert sum(x['end']-x['start'] for x in found)==297983360
agg={}
for x in found:
 # Exact symbols, including full caller ancestry; frame source sites retained per interval.
 key=(x['reason'],tuple(x['symbols']))
 row=agg.setdefault(key,{'reason':x['reason'],'symbols':x['symbols'],'wait_ns':0,'intervals':0,'worker_ns':collections.Counter(),'waker_symbols':collections.Counter(),'sample_sites':x['sites']})
 ns=x['end']-x['start'];row['wait_ns']+=ns;row['intervals']+=1;row['worker_ns'][x['gid']]+=ns;row['waker_symbols'][' / '.join(x['end_waker_symbols'])]+=ns
rows=sorted(agg.values(),key=lambda x:-x['wait_ns'])
for row in rows:row['worker_ns']=dict(row['worker_ns']);row['waker_symbols']=dict(row['waker_symbols'])
(O/'intervals.json').write_text(json.dumps(found,indent=2)+'\n');(O/'stack-groups.json').write_text(json.dumps(rows,indent=2)+'\n')
print('TOTAL',len(found),sum(x['wait_ns'] for x in rows))
for x in rows:print(json.dumps({'ms':x['wait_ns']/1e6,'intervals_NOTdrains':x['intervals'],'reason':x['reason'],'top':x['symbols'][:7],'waker':x['waker_symbols']},indent=2))
