"""Root freeze of the reviewed annotation-only observer after owning closes."""
from pathlib import Path
import hashlib,json,subprocess
R=Path('/mnt/fast4tb/gomap-mongo-execution-20261024'); P=Path(__file__).parent
W=R/'writer-pressure-observer4'; C=R/'consumer-canonical'
Q=R/'evidence/command-projection-v2/sustained-hybrid-failure1/integrated-qualification1'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
z=json.loads((Q/'owning2-receipt.json').read_text())
assert z['process_ok'] and z['inputs_unchanged'] and not z['cleanup']['alive_after_cleanup']
assert not (P/'plan.json').exists(),'never overwrite a frozen plan'
inputs={}
for f,h in json.loads((Q/'owning2-plan.json').read_text())['inputs'].items():
 q=Path(f)
 if q.is_relative_to(C):q=W/q.relative_to(C)
 assert q.is_file() and sha(q)==h, 'projection/module input drift: '+str(q)
 inputs[str(q)]=h
frozen=P.parent/'observer1'
manifest=json.loads((frozen/'manifest.json').read_text())
for rel,item in manifest['files'].items():
 assert sha(W/rel)==item['preimage_sha256']
 assert sha(frozen/'source'/rel)==item['overlay_sha256']
 # Formatted external copies are the sole annotation overlay.
 assert (P/'formatted-source'/rel).is_file()
extra=[P/'run.py',P/'freeze-plan.py',P/'overlay.json',
 R/'evidence/native-query-work-witness1/run.py',
 R/'evidence/command-projection-v2/original-command-eligible1/run.py',
 P.parent/'observer-source-projection1.json']
extra += [f for f in frozen.rglob('*') if f.is_file()]
extra += [f for f in (P/'formatted-source').rglob('*') if f.is_file()]
for f in extra:inputs[str(f)]=sha(f)
ignored=subprocess.check_output(['git','ls-files','--others','--ignored','--exclude-standard'],cwd=W,text=True)
assert not ignored.strip(),'ignored source/input present in isolated projection'
x={'scope':'Original 4096 fixed128 durable four-writer load; reviewed annotation-only external overlay, once per native/legacy, no timing credit or qualification',
 'source_dir':str(W),'toolchain':'/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.linux-amd64',
 'overlay':str(P/'overlay.json'),'fixed_order':['native','legacy'],
 'shape':{'rows':4096,'batch':128,'writers':4,'loads':1,'profile':'command_wal_durable'},
 'inputs':inputs,'frozen_observer_patch_sha256':manifest['patch_sha256'],
 'formatted_overlay_sha256':{str(f.relative_to(P)):sha(f) for f in (P/'formatted-source').rglob('*.go')},
 'qualification':None,'timing_credit':False}
(P/'plan.json').write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
print(json.dumps({'plan_sha256':sha(P/'plan.json'),'inputs':len(inputs),'formatted_overlay':x['formatted_overlay_sha256']}))
