from pathlib import Path
import json,re,collections
O=Path(__file__).resolve().parent
w=json.loads((O/'intervals.json').read_text());windows=[(x['start'],x['end']) for x in w if any('PhysicalSealReceipt.Wait' in s for s in x['symbols'])]
assert {x['end_waker'] for x in w if any('PhysicalSealReceipt.Wait' in s for s in x['symbols'])}=={56}
H=re.compile(r'^M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+)');T=re.compile(r'GoID=(\d+) (\w+)->(\w+) Reason="([^"]*)"')
p=Path('/mnt/fast4tb/gomap-mongo-execution-20261024/evidence/current-feature-service-write-trace3/parsed1/01-native.log')
def blocks():
 b=[]
 with p.open() as f:
  for line in f:
   if line.startswith('M='):
    if b:yield b
    b=[line]
   else:b.append(line)
 if b:yield b
r=[]
for b in blocks():
 h=H.match(b[0]);t=T.search(b[0])
 if not h or not t or t[1]!='56':continue
 s=''.join(b);stack=s.split('TransitionStack=\n',1)[1].split('\nStack=\n',1)[0] if 'TransitionStack=\n' in s else ''
 symbols=[q.strip().split(' @ ')[0] for q in stack.splitlines() if q.startswith('\t') and not q.startswith('\t\t')]
 sites=[q.strip() for q in stack.splitlines() if q.startswith('\t\t')]
 r.append({'time':int(h[5]),'from':t[2],'to':t[3],'reason':t[4],'symbols':symbols,'sites':sites})
r.sort(key=lambda x:x['time']);a={};total=0
for x,y in zip(r,r[1:]):
 overlap=sum(max(0,min(y['time'],end)-max(x['time'],start)) for start,end in windows)
 if not overlap:continue
 assert x['to']==y['from']
 symbols=tuple(x['symbols']) if x['to'] in ('Waiting','Syscall') else ()
 key=(x['to'],x['reason'] if x['to'] in ('Waiting','Syscall') else '',symbols)
 row=a.setdefault(key,{'state':key[0],'reason':key[1],'symbols':symbols,'ns':0,'sample_sites':x['sites']});row['ns']+=overlap;total+=overlap
rows=sorted(a.values(),key=lambda x:-x['ns']);assert total==264775424,total
(O/'publisher56-overlap.json').write_text(json.dumps({'overlap_ns':total,'rows':rows},indent=2)+'\n')
for x in rows:print(json.dumps({'ms':x['ns']/1e6,'state':x['state'],'reason':x['reason'],'symbols':x['symbols'][:9],'sites':x['sample_sites'][:5]},indent=2))
