# Observer annotation parser

Prepared only. No observer, Go command, binary trace decoder, benchmark or existing trace analysis was run for this packet. The five Python checks use synthetic official-format annotation text, not product/performance data. Run the standalone streaming parser after root's reviewed observer and official Go1.26 decode complete:

```sh
A=/mnt/fast4tb/gomap-mongo-execution-20261024/evidence/current-feature-service-write-cpu-alloc1/structural-decision4/observer-analysis1
RUN=/mnt/fast4tb/gomap-mongo-execution-20261024/evidence/current-feature-service-write-cpu-alloc1/structural-decision4/observer-run1
PYTHONDONTWRITEBYTECODE=1 python3 "$A/parse_observer.py" --arm native --log "$RUN/01-native-parsed.log" --out "$A/native-run1.json"
PYTHONDONTWRITEBYTECODE=1 python3 "$A/parse_observer.py" --arm legacy --log "$RUN/02-legacy-parsed.log" --out "$A/legacy-run1.json"
```

The parser refuses an existing output. It streams the input in binary lines, incrementally hashes every byte, ignores stacks and ordinary events, and retains only task/region/log annotations plus header-event counts. Memory is proportional to annotations, not the large decoded event log. It accepts the actual `Event.String` schema from Go1.26.0 `src/internal/trace/event.go:1262–1300`, including Go-quoted escaped string fields. Unknown relevant payload schema/nesting/operand mismatches raise an error. Incomplete regions are retained with `schema_valid=false`; complete missing task/load markers/counts produce explicit issues and exit 2. A schema-valid output is not a valid product run: root must separately preserve the exact source/ELF, decode and cell receipts and successful original workload assertions. No acceptance or performance result is generated.

`observer-run1/run.py` selects native then legacy, four writers, 4096 documents, fixed128, 32 requests, one durable command-WAL load per arm. `--expected-requests` defaults to32; do not change it for this observer. Preparation calls outside `original-request-load` remain in the records and are excluded from the load summary. Legacy may legitimately have no pressure preparation/drain annotations.

The source uses `context.Background()` for pressure regions/logs, hence Task0. The original `UpsertDocuments` receives its original `ctx`, not the newly created tracing task context. A preparation is associated with a public request only through an enclosing explicit `public-upsert-call` region on the SAME goroutine; the parser never invents propagated task/parent links. Recorded request member/result fields and load/task/call begin/end timestamps are preserved. Task duration, call region duration and pressure subregion duration remain distinct. Region durations include diagnostic annotation overhead and the exact declared marker boundaries; they do not claim exact method/lock-hold durations outside these markers. In particular `pressure-mutex-held` begins after Lock returns and ends before Unlock.

For every pressure preparation, output preserves `initial`, `locked-before`, `after-cleanup` observations if actually present, opaque `basis_raw`, exact logical sequence, reserved bytes, both construction thresholds, COW sources/generations and limits, and typed MEMBERS and their separate limit. Emitted `cause_*` booleans are checked against the original formulas (75% byte thresholds, exact count limits, construction!=0 guard); cause counts are nonexclusive and are not automatically causal drain counts. The decisive observation is `locked-before` of an actual drain, not a stale `initial` sample before mutex acquisition. Actual drain branch counts come only from paired `actual-pressure-drain` regions and their `captured-prefix`/`checkpoint` log, with original result text. Both skip branches remain separate. Before/after observed counter differences are explicitly not drained populations: concurrent suffix publication and lifetime release can change these counters. No source/resource identity is derived from opaque basis text.

Per load, merged global wall unions and all pairwise category intersections use half-open intervals. `disjoint_masks` partitions the entire load once, retaining concurrent-region population per category, including empty masks. Those segment durations sum exactly to the load wall span. Per-request output separately reports its own-goroutine phase unions and overlap with any goroutine's phase union. The latter exposes a producer waiting while another worker drains; never add those per-request overlaps across workers or add nested categories to the load wall. No goroutine state/CPU/syscall attribution is inferred by this annotation-only parser; that requires a separate join to the officially decoded transition intervals.

`actual_drain_rows`, `actual_drain_members`, `source_resource_identity`, qualification and timing credit remain null/false. Request-member `rows` is observed input cardinality, not drain rows. COW `Sources` is an independent budget source count, while the producer pressure's `Sources` is typed pending member count; neither is row count. The observer does not expose exact materializer entry row/source census or durable resource identities, so this parser cannot recover them.

Small tooling checks, already run on synthetic text only:

```sh
cd "$A"
PYTHONDONTWRITEBYTECODE=1 TMPDIR=/mnt/fast4tb/gomap-mongo-execution-20261024/tmp python3 -m unittest -v test_parser.py
```

All five passed: overlapping-worker wall unions and Task0 association; exact COW-vs-typed cause distinction; observed prefix deltas with null actual population; fail-closed operand mismatch; incomplete trace; legacy no-pressure; Go quoting and half-open boundary handling. These checks certify only parser behavior on the listed synthetic cases. Root's actual parser outputs remain unattempted and unavailable in this packet.
