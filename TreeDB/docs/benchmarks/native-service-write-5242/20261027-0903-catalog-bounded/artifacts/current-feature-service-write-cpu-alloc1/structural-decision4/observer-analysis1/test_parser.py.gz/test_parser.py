"""Synthetic format/interval checks only, not storage or performance evidence."""
import json
from pathlib import Path
import tempfile
import unittest
import parse_observer as P


def quoted(value):
    return json.dumps(value)


def event(g, name, time, attrs):
    return f'M=1 P=0 G={g} {name} Time={time} {attrs}\n'


def region(g, begin, time, name, task=0):
    return event(g, 'RegionBegin' if begin else 'RegionEnd', time, f'Task={task} Type={quoted(name)}')


def log(g, time, category, message, task=0):
    return event(g, 'Log', time, f'Task={task} Category={quoted(category)} Message={quoted(message)}')


def state(phase, *, construction=80, members=2, sources=1):
    return (f'phase={phase} logical_seq=4 basis={{11 22}} reserved=20 cow_limit=100 '
            f'cow_sources={sources} cow_max_sources=4 cow_generations=1 cow_max_generations=4 '
            f'construction={construction} construction_in_flight=100 construction_total=200 '
            f'typed_members={members} typed_max_members=2 cause_reserved=false cause_cow_sources={str(sources >= 4).lower()} '
            f'cause_generations=false cause_construction_in_flight={str(construction >= 75 and construction != 0).lower()} '
            f'cause_construction_total={str(construction >= 150 and construction != 0).lower()} '
            f'cause_typed_members={str(members >= 2 and construction != 0).lower()}')


def fixture():
    e = [region(10, True, 0, 'original-request-load'),
         event(20, 'TaskBegin', 1, 'ID=1 Parent=0 Type="public-upsert"'),
         log(20, 2, 'request-member', 'worker=0 batch=0 first=0 rows=128', 1),
         region(20, True, 3, 'public-upsert-call', 1),
         region(20, True, 4, 'producer-prepare'),
         log(20, 5, 'pressure-state', state('initial')),
         region(20, True, 6, 'pressure-mutex-wait'),
         event(21, 'TaskBegin', 7, 'ID=2 Parent=0 Type="public-upsert"'),
         log(21, 8, 'request-member', 'worker=1 batch=1 first=128 rows=128', 2),
         region(21, True, 9, 'public-upsert-call', 2),
         region(21, True, 10, 'producer-prepare'),
         log(21, 11, 'pressure-state', state('initial')),
         region(21, True, 12, 'pressure-mutex-wait'),
         region(20, False, 13, 'pressure-mutex-wait'),
         region(20, True, 14, 'pressure-mutex-held'),
         log(20, 15, 'pressure-state', state('locked-before')),
         region(20, True, 16, 'actual-pressure-drain'),
         log(20, 17, 'pressure-drain-mode', 'captured-prefix'),
         region(20, False, 30, 'actual-pressure-drain'),
         log(20, 31, 'pressure-drain-result', 'error=<nil>'),
         region(20, True, 32, 'pressure-cleanup-join'),
         region(20, False, 34, 'pressure-cleanup-join'),
         log(20, 35, 'pressure-state', state('after-cleanup', construction=0, members=0)),
         region(20, False, 36, 'pressure-mutex-held'),
         region(20, False, 37, 'producer-prepare'),
         region(21, False, 38, 'pressure-mutex-wait'),
         region(21, True, 39, 'pressure-mutex-held'),
         log(21, 40, 'pressure-state', state('locked-before', construction=0, members=0)),
         log(21, 41, 'pressure-outcome', 'skip-under-watermark'),
         region(21, False, 42, 'pressure-mutex-held'),
         region(21, False, 43, 'producer-prepare'),
         region(20, False, 44, 'public-upsert-call', 1),
         log(20, 45, 'request-result', 'batch=0 inserted=128 updated=0 error=<nil>', 1),
         event(20, 'TaskEnd', 46, 'ID=1 Parent=0 Type="public-upsert"'),
         region(21, False, 47, 'public-upsert-call', 2),
         log(21, 48, 'request-result', 'batch=1 inserted=128 updated=0 error=<nil>', 2),
         event(21, 'TaskEnd', 49, 'ID=2 Parent=0 Type="public-upsert"'),
         region(10, False, 50, 'original-request-load')]
    # Official stack text is not an event and must not affect annotation parsing.
    e.insert(9, '\tignored.Stack @ 0x0\n\t\t/source/file.go:4\n')
    return ''.join(e)


class ParserTests(unittest.TestCase):
    def run_fixture(self, value, count=2):
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory) / 'parsed.log'
            p.write_text(value)
            return P.parse(p, 'native', count)

    def test_overlaps_task_zero_same_goroutine_and_nulls(self):
        result = self.run_fixture(fixture())
        self.assertTrue(result['schema_valid'], result['issues'])
        load = result['loads'][0]
        self.assertEqual(load['wall_ns'], 50)
        self.assertEqual(load['region_union_ns']['producer-prepare'], 39)
        self.assertEqual(load['region_union_ns']['pressure-mutex-wait'], 32)
        self.assertEqual(load['region_union_ns']['actual-pressure-drain'], 14)
        overlap = next(x for x in load['region_intersections'] if
                       {x['left'], x['right']} == {'pressure-mutex-wait', 'actual-pressure-drain'})
        self.assertEqual(overlap['intersection_ns'], 14)
        self.assertEqual(sum(x['duration_ns'] for x in load['disjoint_masks']), 50)
        self.assertEqual(result['load_summary']['drain_branches'], {'captured-prefix': 1})
        self.assertEqual(result['load_summary']['observed_skip_branches'], {'skip-under-watermark': 1})
        first, second = result['preparations']
        self.assertEqual(first['request_task_id'], 1)
        self.assertEqual(second['request_task_id'], 2)
        self.assertEqual(first['states']['initial']['basis_raw'], '{11 22}')
        self.assertFalse(first['states']['initial']['cause_cow_sources'])
        self.assertTrue(first['states']['initial']['cause_typed_members'])
        self.assertEqual(first['after_minus_before_observed_counters']['typed_members'], -2)
        self.assertIsNone(first['actual_drain_members'])
        self.assertIsNone(first['actual_drain_rows'])
        self.assertIsNone(first['source_resource_identity'])
        self.assertEqual(result['tasks'][1]['own_goroutine_region_union_ns']['actual-pressure-drain'], 0)
        self.assertEqual(result['tasks'][1]['overlap_with_any_goroutine_region_union_ns']['actual-pressure-drain'], 14)

    def test_logged_operand_mismatch_fails_closed(self):
        with self.assertRaisesRegex(ValueError, 'causes disagree'):
            self.run_fixture(fixture().replace('cause_typed_members=true', 'cause_typed_members=false', 1))

    def test_incomplete_trace_retains_unclosed_regions(self):
        result = self.run_fixture(fixture().rsplit('M=1 P=0 G=10 RegionEnd', 1)[0])
        self.assertFalse(result['schema_valid'])
        self.assertTrue(any('unclosed region' in x for x in result['issues']))

    def test_legacy_no_pressure(self):
        text = ''.join([region(10, True, 0, 'original-request-load'),
            event(20, 'TaskBegin', 1, 'ID=1 Parent=0 Type="public-upsert"'),
            log(20, 2, 'request-member', 'worker=0 batch=0 first=0 rows=128', 1),
            region(20, True, 3, 'public-upsert-call', 1),
            region(20, False, 4, 'public-upsert-call', 1),
            log(20, 5, 'request-result', 'batch=0 inserted=128 updated=0 error=<nil>', 1),
            event(20, 'TaskEnd', 6, 'ID=1 Parent=0 Type="public-upsert"'),
            region(10, False, 7, 'original-request-load')])
        result = self.run_fixture(text, 1)
        self.assertTrue(result['schema_valid'], result['issues'])
        self.assertEqual(result['load_summary']['drain_branches'], {})
        self.assertEqual(result['loads'][0]['region_union_ns']['actual-pressure-drain'], 0)

    def test_go_quoted_escape_and_union_boundary(self):
        self.assertEqual(P.go_quote('"line\\n\\x41\\101\\u03b1"'), 'line\nAAα')
        self.assertEqual(P.merge([(0, 5), (5, 7), (2, 3)]), [[0, 7]])
        self.assertEqual(P.intersect([[0, 5]], [[5, 7]]), [])


if __name__ == '__main__':
    unittest.main()
