#!/usr/bin/env python3
"""Read official parsed text only; no binary trace parsing and no Go invocation."""
import collections, csv, hashlib, json, re
from pathlib import Path
R=Path('/mnt/fast4tb/gomap-mongo-execution-20261024')
E=R/'evidence/current-feature-service-write-trace3/parsed1'
O=R/'evidence/current-feature-service-write-cpu-alloc1/structural-decision4'
H=re.compile(r'^M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+)')
T=re.compile(r'GoID=(\d+) (\w+)->(\w+) Reason="([^"]*)"')
def blocks(p):
    b=[]
    with p.open() as f:
        for line in f:
            if line.startswith('M='):
                if b: yield b
                b=[line]
            else: b.append(line)
    if b: yield b

def label(s):
    # Full transition stack ancestry disambiguates physical seal from own ACK.
    if 'cow_native_txn.go:144' in s: return 'pressure_mutex'
    if 'lockVectorIndexMutation' in s: return 'collection_gate'
    if 'joinSemanticCleanupFrontier' in s: return 'cleanup_join'
    if 'PrepareNativeProducerObservation' in s:
        if 'materializeCOWPrefix' in s: return 'pressure_materialize'
        return 'pressure_other'
    if 'awaitPublicCommandWAL' in s or 'CompleteNativeCommandWAL' in s: return 'direct_ack'
    if 'lockCollectionDomainMutation' in s: return 'legacy_domain_lock'
    if 'lockCommandWALRawPublishWithTeardown' in s: return 'legacy_staging_lock'
    if 'lockVectorIndexCoverageMutationWithColdCarrier' in s: return 'legacy_coverage_lock'
    if 'AppendValueLogValues' in s or 'AppendValues' in s: return 'value_log'
    if 'materializeCOWPrefix' in s: return 'materialize_nonpressure_ancestry'
    if 'benchmarkSharedCOWWriteLoad.func2' in s and 'shared_cow_write_bench_test.go:197' in s: return 'start_channel'
    return 'other'

def analyze(arm):
    p=E/(arm+'.log'); workers=set(); annotations=collections.Counter()
    for b in blocks(p):
        h=H.match(b[0])
        if not h: continue
        s=''.join(b)
        if h[4] in ('TaskBegin','TaskEnd','RegionBegin','RegionEnd','Log'): annotations[h[4]]+=1
        if 'UpsertDocuments' in s and 'benchmarkSharedCOWWriteLoad.func2' in s: workers.add(int(h[3]))
    assert len(workers)==4,(arm,workers)
    records={g:[] for g in workers}
    for b in blocks(p):
        h=H.match(b[0]); t=T.search(b[0])
        if not h or not t or int(t[1]) not in workers: continue
        s=''.join(b); transition=s.split('TransitionStack=\n',1)[1].split('\nStack=\n',1)[0] if 'TransitionStack=\n' in s else ''
        wake_symbols=[line.strip().split(' @ ')[0] for line in s.split('\nStack=\n',1)[-1].splitlines() if line.startswith('\t') and not line.startswith('\t\t')][:4] if '\nStack=\n' in s else []
        records[int(t[1])].append({'time':int(h[5]),'from':t[2],'to':t[3],'reason':t[4],'label':label(transition),'waker':int(h[3]),'waker_symbols':wake_symbols})
    bounds={}; intervals=[]; totals={}; anomalies=[]
    for g,events in records.items():
        events.sort(key=lambda x:x['time'])
        start=next((x['time'] for x in events if x['from']=='Waiting' and x['to']=='Runnable' and any(y['to']=='Waiting' and y['label']=='start_channel' and y['time']<x['time'] for y in events)),None)
        # First post-channel runnable transition is worker launch; terminal exit follows all own requests.
        end=next((x['time'] for x in events if x['to']=='NotExist'),None)
        assert start is not None and end is not None,(g,start,end)
        bounds[g]={'start_release':start,'exit':end,'span_ns':end-start}
        total=collections.Counter()
        for a,b in zip(events,events[1:]):
            if b['time']<=start or a['time']>=end:continue
            if a['to']!=b['from']:anomalies.append([g,a['time'],a['to'],b['from']])
            lo=max(start,a['time']); hi=min(end,b['time'])
            if hi<=lo:continue
            state=a['to']; category=state+':'+(a['label'] if state in ('Waiting','Syscall') else 'unattributed')
            total[category]+=hi-lo
            intervals.append({'gid':g,'start':lo,'end':hi,'state':state,'category':category,'end_waker':b['waker'] if state=='Waiting' else None,'end_waker_symbols':b['waker_symbols'] if state=='Waiting' else []})
        totals[g]=dict(total)
    first=min(x['start_release'] for x in bounds.values()); last=max(x['exit'] for x in bounds.values())
    changes=collections.defaultdict(list)
    for x in intervals:
        changes[x['start']].append((x['gid'],x['category']));changes[x['end']].append((x['gid'],None))
    # Ends before starts at a shared endpoint; all interval categories partition each worker lifespan.
    live={}; masks=collections.Counter(); points=sorted(changes)
    for i,t in enumerate(points[:-1]):
        for gid,cat in sorted(changes[t],key=lambda q:q[1] is not None):
            if cat is None:live.pop(gid,None)
            else:live[gid]=cat
        counts=collections.Counter(live.values()); mask=tuple(sorted(counts.items()))
        masks[mask]+=points[i+1]-t
    unions=collections.Counter()
    for mask,ns in masks.items():
        for cat,count in mask:unions[cat]+=ns
    result={'workers':sorted(workers),'annotations':dict(annotations),'bounds':bounds,'observed_release_to_exit_wall_ns':last-first,'per_worker_disjoint_ns':totals,'category_wall_unions_ns_NONADDITIVE':dict(unions),'masks_ns':[{'mask':dict(k),'ns':v} for k,v in masks.most_common()],'state_discontinuities':anomalies,'request_count':None,'drain_count':None,'rows_per_drain':None,'exclusive_removable_wall_ns':None}
    (O/(arm+'-intervals.json')).write_text(json.dumps(intervals,separators=(',',':'))+'\n')
    (O/(arm+'-summary.json')).write_text(json.dumps(result,indent=2)+'\n')
    return {'workers':result['workers'],'bounds':bounds,'wall_ns':last-first,'totals':totals,'nonadditive_unions':dict(unions),'annotations':dict(annotations),'discontinuities':len(anomalies)}
for arm in ['01-native','02-legacy']:print(arm,json.dumps(analyze(arm)))
