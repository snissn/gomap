#!/usr/bin/env python3
"""Stream official Go 1.26 -d=parsed text; never decode binary traces or infer rows."""
import argparse
import collections
import hashlib
import itertools
import json
from pathlib import Path
import re

REGIONS = ('original-request-load', 'public-upsert-call', 'producer-prepare',
           'pressure-mutex-wait', 'pressure-mutex-held', 'actual-pressure-drain',
           'pressure-cleanup-join')
CATEGORIES = {'request-member', 'request-result', 'pressure-state', 'pressure-outcome',
              'pressure-drain-mode', 'pressure-drain-result'}
HEADER = re.compile(r'^M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+)(.*)$')
ATTR = re.compile(r'\s+(\w+)=("(?:[^"\\]|\\.)*"|-?\d+)')
KV = re.compile(r'(?:^| )([a-z_]+)=')
INT_FIELDS = ('logical_seq', 'reserved', 'cow_limit', 'cow_sources', 'cow_max_sources',
              'cow_generations', 'cow_max_generations', 'construction',
              'construction_in_flight', 'construction_total', 'typed_members', 'typed_max_members')
CAUSES = ('cause_reserved', 'cause_cow_sources', 'cause_generations',
          'cause_construction_in_flight', 'cause_construction_total', 'cause_typed_members')


def go_quote(value):
    """The string subset of Go strconv.Quote, including non-JSON x/octal escapes."""
    assert value[0] == value[-1] == '"'
    out, i = [], 1
    escapes = {'a': '\a', 'b': '\b', 'f': '\f', 'n': '\n', 'r': '\r', 't': '\t',
               'v': '\v', '\\': '\\', '"': '"'}
    while i < len(value) - 1:
        ch = value[i]
        i += 1
        if ch != '\\':
            out.append(ch)
            continue
        ch = value[i]
        i += 1
        if ch in escapes:
            out.append(escapes[ch])
        elif ch in 'xuU':
            count = {'x': 2, 'u': 4, 'U': 8}[ch]
            out.append(chr(int(value[i:i + count], 16)))
            i += count
        elif ch in '01234567':
            out.append(chr(int(ch + value[i:i + 2], 8)))
            i += 2
        else:
            raise ValueError('unsupported Go quoted escape: ' + ch)
    return ''.join(out)


def fields(message):
    matches = list(KV.finditer(message))
    result = {}
    for i, match in enumerate(matches):
        if match[1] in result:
            raise ValueError('duplicate scalar key ' + match[1])
        end = matches[i + 1].start() if i + 1 < len(matches) else len(message)
        result[match[1]] = message[match.end():end].strip()
    return result


def pressure_fields(message):
    row = fields(message)
    expected = {'phase', 'basis', *INT_FIELDS, *CAUSES}
    if set(row) != expected:
        raise ValueError('pressure-state schema changed: ' + str(sorted(set(row) ^ expected)))
    for name in INT_FIELDS:
        row[name] = int(row[name])
        if row[name] < 0:
            raise ValueError('negative unsigned operand ' + name)
    for name in CAUSES:
        if row[name] not in ('true', 'false'):
            raise ValueError('invalid Boolean ' + name)
        row[name] = row[name] == 'true'
    p = row['construction'] != 0
    computed = (row['reserved'] >= row['cow_limit'] - row['cow_limit'] // 4,
                row['cow_sources'] >= row['cow_max_sources'],
                row['cow_generations'] >= row['cow_max_generations'],
                p and row['construction'] >= row['construction_in_flight'] - row['construction_in_flight'] // 4,
                p and row['construction'] >= row['construction_total'] - row['construction_total'] // 4,
                p and row['typed_members'] >= row['typed_max_members'])
    if any(row[name] != actual for name, actual in zip(CAUSES, computed)):
        raise ValueError('logged pressure causes disagree with original exact formula')
    row['under_pressure'] = any(computed)
    row['basis_raw'] = row.pop('basis')
    return row


def merge(intervals):
    out = []
    for start, end in sorted(intervals):
        if end < start:
            raise ValueError('negative interval')
        if end == start:
            continue
        if out and start <= out[-1][1]:
            out[-1][1] = max(end, out[-1][1])
        else:
            out.append([start, end])
    return out


def intersect(left, right):
    out, i, j = [], 0, 0
    while i < len(left) and j < len(right):
        start, end = max(left[i][0], right[j][0]), min(left[i][1], right[j][1])
        if start < end:
            out.append([start, end])
        if left[i][1] <= right[j][1]:
            i += 1
        else:
            j += 1
    return out


def duration(intervals):
    return sum(end - start for start, end in intervals)


def partition_masks(regions, start, end):
    """Disjoint global wall masks, counts retain concurrent workers, never sum waits."""
    changes = collections.defaultdict(list)
    changes[start]
    changes[end]
    for r in regions:
        a, b = max(start, r['start_ns']), min(end, r['end_ns'])
        if a < b:
            changes[a].append((r['name'], 1))
            changes[b].append((r['name'], -1))
    active, segments = collections.Counter(), []
    times = sorted(changes)
    for index, time in enumerate(times[:-1]):
        for name, delta in changes[time]:
            active[name] += delta
            if active[name] < 0:
                raise ValueError('negative mask population')
            if not active[name]:
                del active[name]
        segments.append({'start_ns': time, 'end_ns': times[index + 1],
                         'duration_ns': times[index + 1] - time, 'active': dict(sorted(active.items()))})
    assert sum(x['duration_ns'] for x in segments) == end - start
    return segments


def parse(path, arm, expected_requests=32):
    tasks, regions, stacks, logs = {}, [], collections.defaultdict(list), []
    events = collections.Counter()
    issues = []
    digest = hashlib.sha256()
    previous = -1
    with path.open('rb') as stream:
        for line_number, raw in enumerate(stream, 1):
            digest.update(raw)
            if not raw.startswith(b'M='):
                continue
            line = raw.decode('utf-8').rstrip('\n')
            h = HEADER.match(line)
            if not h:
                raise ValueError('unrecognized official event header at line ' + str(line_number))
            gid, kind, time = int(h[3]), h[4], int(h[5])
            events[kind] += 1
            if kind not in ('TaskBegin', 'TaskEnd', 'RegionBegin', 'RegionEnd', 'Log'):
                continue
            if time < previous:
                raise ValueError('annotation events not time-ordered')
            previous = time
            attr = {m[1]: go_quote(m[2]) if m[2].startswith('"') else int(m[2])
                    for m in ATTR.finditer(h[6])}
            if kind.startswith('Task'):
                if attr.get('Type') != 'public-upsert':
                    continue
                task = attr['ID']
                if kind == 'TaskBegin':
                    if task in tasks:
                        raise ValueError('duplicate request task')
                    tasks[task] = {'task_id': task, 'parent_task': attr['Parent'],
                                   'goroutine': gid, 'start_ns': time, 'end_ns': None,
                                   'member': None, 'result': None, 'call_region_id': None}
                else:
                    if task not in tasks:
                        raise ValueError('request task end missing begin')
                    tasks[task]['end_ns'] = time
                continue
            if kind.startswith('Region'):
                name = attr.get('Type')
                if name not in REGIONS:
                    continue
                if kind == 'RegionBegin':
                    request = next((r['request_task_id'] for r in reversed(stacks[gid])
                                    if r['request_task_id'] is not None), None)
                    if name == 'public-upsert-call':
                        request = attr['Task']
                        if request not in tasks:
                            raise ValueError('call region has no request task')
                    r = {'region_id': len(regions), 'name': name, 'goroutine': gid,
                         'event_task_id': attr['Task'], 'request_task_id': request,
                         'parent_region_id': stacks[gid][-1]['region_id'] if stacks[gid] else None,
                         'start_ns': time, 'end_ns': None, 'duration_ns': None,
                         'begin_line': line_number, 'logs': []}
                    regions.append(r)
                    stacks[gid].append(r)
                    if name == 'public-upsert-call':
                        if tasks[request]['call_region_id'] is not None:
                            raise ValueError('more than one call region per task')
                        tasks[request]['call_region_id'] = r['region_id']
                else:
                    if not stacks[gid] or stacks[gid][-1]['name'] != name or stacks[gid][-1]['event_task_id'] != attr['Task']:
                        raise ValueError('tracked region nesting mismatch at line ' + str(line_number))
                    r = stacks[gid].pop()
                    r['end_ns'], r['duration_ns'], r['end_line'] = time, time - r['start_ns'], line_number
                continue
            category = attr.get('Category')
            if category not in CATEGORIES:
                continue
            message = attr['Message']
            item = {'log_id': len(logs), 'time_ns': time, 'line': line_number,
                    'goroutine': gid, 'task_id': attr['Task'], 'category': category, 'message': message}
            if category == 'pressure-state':
                item['fields'] = pressure_fields(message)
            elif category == 'request-member':
                item['fields'] = {k: int(v) for k, v in fields(message).items()}
                if set(item['fields']) != {'worker', 'batch', 'first', 'rows'}:
                    raise ValueError('request-member schema changed')
            elif category == 'request-result':
                m = re.fullmatch(r'batch=(\d+) inserted=(\d+) updated=(\d+) error=(.*)', message)
                if not m:
                    raise ValueError('request-result schema changed')
                item['fields'] = dict(zip(('batch', 'inserted', 'updated'), map(int, m.groups()[:3])))
                item['fields']['error_raw'] = m[4]
            logs.append(item)
            if category.startswith('request-'):
                if attr['Task'] not in tasks:
                    raise ValueError('request log missing actual task')
                field = 'member' if category == 'request-member' else 'result'
                if tasks[attr['Task']][field] is not None:
                    raise ValueError('duplicate request ' + field)
                tasks[attr['Task']][field] = item['fields']
            else:
                prepare = next((r for r in reversed(stacks[gid]) if r['name'] == 'producer-prepare'), None)
                if prepare is None:
                    raise ValueError('pressure log outside producer-prepare')
                prepare['logs'].append(item['log_id'])
                item['prepare_region_id'] = prepare['region_id']
                item['request_task_id'] = prepare['request_task_id']
    for r in regions:
        if r['end_ns'] is None:
            issues.append('unclosed region ' + str(r['region_id']))
    if issues:
        return {'input': str(path), 'input_sha256': digest.hexdigest(), 'schema_valid': False,
                'issues': issues, 'regions': regions, 'logs': logs, 'tasks': list(tasks.values())}
    loads = [r for r in regions if r['name'] == 'original-request-load']
    if len(loads) != 1:
        issues.append('expected one original-request-load, observed ' + str(len(loads)))
    complete_loads = []
    for load in loads:
        bounds = [[load['start_ns'], load['end_ns']]]
        selected = [r for r in regions if r['name'] != 'original-request-load']
        masks = {name: intersect(merge((r['start_ns'], r['end_ns']) for r in selected if r['name'] == name), bounds)
                 for name in REGIONS if name != 'original-request-load'}
        pairs = [{'left': a, 'right': b, 'intersection_ns': duration(intersect(masks[a], masks[b]))}
                 for a, b in itertools.combinations(masks, 2)]
        complete_loads.append({'region_id': load['region_id'], 'start_ns': load['start_ns'],
                              'end_ns': load['end_ns'], 'wall_ns': load['duration_ns'],
                              'region_union_ns': {k: duration(v) for k, v in masks.items()},
                              'region_intersections': pairs,
                              'disjoint_masks': partition_masks(selected, load['start_ns'], load['end_ns'])})
    global_masks = {name: merge((r['start_ns'], r['end_ns']) for r in regions if r['name'] == name)
                    for name in REGIONS}
    for task in tasks.values():
        call = regions[task['call_region_id']] if task['call_region_id'] is not None else None
        if task['end_ns'] is None or call is None or task['member'] is None or task['result'] is None:
            issues.append('incomplete request task ' + str(task['task_id']))
            continue
        task['task_duration_ns'] = task['end_ns'] - task['start_ns']
        task['call_duration_ns'] = call['duration_ns']
        if not (task['start_ns'] <= call['start_ns'] <= call['end_ns'] <= task['end_ns']):
            issues.append('request/task boundary mismatch ' + str(task['task_id']))
        if task['result']['batch'] != task['member']['batch']:
            issues.append('request batch mismatch ' + str(task['task_id']))
        task['overlap_with_any_goroutine_region_union_ns'] = {
            name: duration(intersect(mask, [[call['start_ns'], call['end_ns']]]))
            for name, mask in global_masks.items() if name not in ('public-upsert-call', 'original-request-load')}
        task['own_goroutine_region_union_ns'] = {
            name: duration(merge((r['start_ns'], r['end_ns']) for r in regions
                                 if r['request_task_id'] == task['task_id'] and r['name'] == name))
            for name in REGIONS if name not in ('public-upsert-call', 'original-request-load')}
        task['load_region_id'] = next((r['region_id'] for r in loads
                                       if r['start_ns'] <= call['start_ns'] and call['end_ns'] <= r['end_ns']), None)
        if task['load_region_id'] is None:
            issues.append('request outside original load ' + str(task['task_id']))
    if len(tasks) != expected_requests:
        issues.append('expected request task count ' + str(expected_requests) + ', observed ' + str(len(tasks)))
    preparations = []
    for r in regions:
        if r['name'] != 'producer-prepare':
            continue
        items = [logs[n] for n in r['logs']]
        phases = [x['fields'] for x in items if x['category'] == 'pressure-state']
        phase_names = [x['phase'] for x in phases]
        if len(set(phase_names)) != len(phase_names) or any(p not in ('initial', 'locked-before', 'after-cleanup') for p in phase_names):
            issues.append('duplicate/unknown pressure phase in region ' + str(r['region_id']))
        state = {x['phase']: x for x in phases}
        child = [x for x in regions if x['name'] in ('actual-pressure-drain', 'pressure-mutex-wait',
                 'pressure-mutex-held', 'pressure-cleanup-join') and x['goroutine'] == r['goroutine']
                 and r['start_ns'] <= x['start_ns'] and x['end_ns'] <= r['end_ns']]
        drains = [x for x in child if x['name'] == 'actual-pressure-drain']
        modes = [x['message'] for x in items if x['category'] == 'pressure-drain-mode']
        results = [x['message'] for x in items if x['category'] == 'pressure-drain-result']
        outcomes = [x['message'] for x in items if x['category'] == 'pressure-outcome']
        if len(drains) > 1 or len(modes) != len(drains) or len(results) != len(drains):
            issues.append('drain annotations incomplete in region ' + str(r['region_id']))
        if any(x not in ('captured-prefix', 'checkpoint') for x in modes):
            issues.append('unknown original drain branch')
        if any(x not in ('skip-under-watermark', 'skip-unchanged-remembered') for x in outcomes):
            issues.append('unknown original skip branch')
        in_load = next((x['region_id'] for x in loads if x['start_ns'] <= r['start_ns'] and r['end_ns'] <= x['end_ns']), None)
        before, after = state.get('locked-before'), state.get('after-cleanup')
        changes = {name: after[name] - before[name] for name in ('reserved', 'cow_sources', 'cow_generations',
                   'construction', 'typed_members', 'logical_seq')} if before is not None and after is not None else None
        preparations.append({'region_id': r['region_id'], 'goroutine': r['goroutine'],
                             'request_task_id': r['request_task_id'], 'load_region_id': in_load,
                             'duration_ns': r['duration_ns'], 'states': state,
                             'subregion_ids': [x['region_id'] for x in child],
                             'drain_modes': modes, 'drain_results_raw': results, 'outcomes': outcomes,
                             'after_minus_before_observed_counters': changes,
                             'actual_drain_rows': None, 'actual_drain_members': None,
                             'source_resource_identity': None})
    in_load = [p for p in preparations if p['load_region_id'] is not None]
    causes = {phase: dict(collections.Counter(name for p in in_load if phase in p['states']
                                             for name in CAUSES if p['states'][phase][name]))
              for phase in ('initial', 'locked-before', 'after-cleanup')}
    if tasks:
        members = [t['member'] for t in tasks.values() if t['member'] is not None]
        if len({m['batch'] for m in members}) != len(members):
            issues.append('duplicate request batch')
    return {'input': str(path), 'input_sha256': digest.hexdigest(), 'arm': arm,
            'schema_valid': not issues, 'issues': issues, 'qualification': None, 'timing_credit': False,
            'header_event_counts': dict(events), 'loads': complete_loads, 'tasks': list(tasks.values()),
            'preparations': preparations, 'regions': regions, 'logs': logs,
            'load_summary': {'request_tasks': len(tasks),
                             'observed_requested_rows': sum(t['member']['rows'] for t in tasks.values() if t['member'] is not None),
                             'observed_nil_error_results': sum(t['result'] is not None and t['result']['error_raw'] == '<nil>' for t in tasks.values()),
                             'preparations': len(in_load),
                             'drain_branches': dict(collections.Counter(m for p in in_load for m in p['drain_modes'])),
                             'observed_skip_branches': dict(collections.Counter(m for p in in_load for m in p['outcomes'])),
                             'pressure_cause_counts_by_phase_nonexclusive': causes,
                             'actual_drain_rows': None, 'actual_drain_members': None,
                             'source_resource_identity': None}}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--log', type=Path, required=True)
    cli.add_argument('--out', type=Path, required=True)
    cli.add_argument('--arm', choices=('native', 'legacy'), required=True)
    cli.add_argument('--expected-requests', type=int, default=32)
    args = cli.parse_args()
    if args.out.exists():
        cli.error('retain prior output; --out already exists')
    result = parse(args.log, args.arm, args.expected_requests)
    with args.out.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'output': str(args.out), 'schema_valid': result['schema_valid'],
                      'issues': result['issues'], 'input_sha256': result['input_sha256'],
                      'load_summary': result.get('load_summary'), 'qualification': None, 'timing_credit': False}))
    raise SystemExit(0 if result['schema_valid'] else 2)


if __name__ == '__main__':
    main()
