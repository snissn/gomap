"""One original load per arm with diagnostic trace annotations; no timing credit."""
from pathlib import Path
import importlib.util
import json
import signal
import sys

sys.dont_write_bytecode = True
R = Path('/mnt/fast4tb/gomap-mongo-execution-20261024')
P = Path(__file__).parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


H = module('owned', R / 'evidence/native-query-work-witness1/run.py')
V = module('observation', R / 'evidence/command-projection-v2/original-command-eligible1/run.py')
signal.signal(signal.SIGTERM, H.interrupted)
signal.signal(signal.SIGINT, H.interrupted)
plan = json.loads((P / 'plan.json').read_text())
W = Path(plan['source_dir'])
G = Path(plan['toolchain'])
E = P / 'documentservice.test'


def unchanged():
    return all(Path(f).is_file() and H.digest(f) == digest for f, digest in plan['inputs'].items())


assert plan['fixed_order'] == ['native', 'legacy']
assert plan['shape'] == {'rows': 4096, 'batch': 128, 'writers': 4, 'loads': 1, 'profile': 'command_wal_durable'}
assert unchanged(), 'frozen inputs changed before build'
assert not V.competing_go(), 'active Go before diagnostic build'
env = H.safe_env({'GOROOT': str(G), 'GOTOOLCHAIN': 'local', 'GOMAXPROCS': '4',
                  'GOCACHE': str(R / 'gocache'), 'TMPDIR': str(R / 'tmp'), 'CGO_ENABLED': '1'})
build = H.run_process([str(G / 'bin/go'), 'test', '-c', '-overlay=' + plan['overlay'],
                      '-o', str(E), './TreeDB/documentservice'], str(W), env, P / 'build.log', 600)
build['inputs_unchanged'] = unchanged()
build['plan_sha256'] = H.digest(P / 'plan.json')
if E.is_file():
    build['elf_sha256'] = H.digest(E)
H.write_json(P / 'build-receipt.json', build)
print(json.dumps({'build': build}), flush=True)
if not (build['process_ok'] and build['inputs_unchanged']):
    sys.exit(1)
elf = H.digest(E)
results = []
for number, arm in enumerate(plan['fixed_order'], 1):
    stem = f'{number:02}-{arm}'
    trace = P / (stem + '.trace')
    assert not trace.exists(), 'retain all prior attempts, never overwrite'
    assert unchanged() and H.digest(E) == elf, 'source/ELF drift before cell'
    assert not V.competing_go(), 'defer rather than execute alongside known Go'
    argv = [str(E), '-test.v', '-test.run=^$',
            '-test.bench=^BenchmarkServiceSharedCOWWriteLoad$/^writers4$',
            '-test.benchtime=1x', '-test.benchmem', '-test.count=1',
            '-test.timeout=3m', '-test.trace=' + str(trace)]
    receipt = V.measured_process(H, argv, str(W),
                                dict(env, GOMAP_SERVICE_BENCH_BACKEND=arm,
                                     GOMAP_SERVICE_BENCH_PROFILE='command_wal_durable'),
                                P / (stem + '.log'), 240)
    text = (P / (stem + '.log')).read_text()
    receipt.update(inputs_unchanged=unchanged(), elf_unchanged=H.digest(E) == elf,
                   elf_sha256=elf,
                   requests_verified=f'backend={arm} profile=command_wal_durable writers=4 loads=1 attempted=32 completed=32 request_retries=0' in text,
                   trace_sha256=H.digest(trace) if trace.is_file() else None,
                   qualification=None, timing_credit=False)
    H.write_json(P / (stem + '-receipt.json'), receipt)
    print(json.dumps(receipt), flush=True)
    results.append(receipt)
    if not (receipt['process_ok'] and receipt['inputs_unchanged'] and receipt['elf_unchanged']
            and receipt['requests_verified'] and receipt['trace_sha256']
            and not receipt['competing_go_observations']):
        H.write_json(P / 'result.json', {'valid_diagnostic': False, 'qualification': None,
                                        'timing_credit': False, 'cells': results,
                                        'unattempted_tail': plan['fixed_order'][number:]})
        sys.exit(1)
    decoded = H.run_process([str(G / 'bin/go'), 'tool', 'trace', '-d=parsed', str(trace)],
                            str(W), env, P / (stem + '-parsed.log'), 60)
    decoded['inputs_unchanged'] = unchanged()
    H.write_json(P / (stem + '-parsed-receipt.json'), decoded)
    assert decoded['process_ok'] and decoded['inputs_unchanged'], 'official trace decode failed'
H.write_json(P / 'result.json', {'valid_diagnostic': True, 'qualification': None,
                                'timing_credit': False, 'retries': 0, 'cells': results,
                                'unattempted_tail': [], 'elf_sha256': elf,
                                'inputs_unchanged': unchanged()})
