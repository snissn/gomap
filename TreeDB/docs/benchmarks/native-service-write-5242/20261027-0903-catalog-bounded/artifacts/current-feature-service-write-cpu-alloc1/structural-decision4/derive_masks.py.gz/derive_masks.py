import hashlib,json
from pathlib import Path
O=Path(__file__).resolve().parent
n=json.loads((O/'01-native-summary.json').read_text()); l=json.loads((O/'02-legacy-summary.json').read_text())
predicates={
'pressure_materializer_wait_or_syscall':lambda m:any(k in m for k in ['Waiting:pressure_materialize','Syscall:pressure_materialize']),
'pressure_wait_AND_pressure_materializer':lambda m:'Waiting:pressure_mutex' in m and any(k in m for k in ['Waiting:pressure_materialize','Syscall:pressure_materialize']),
'pressure_wait_WITHOUT_observed_materializer':lambda m:'Waiting:pressure_mutex' in m and not any(k in m for k in ['Waiting:pressure_materialize','Syscall:pressure_materialize']),
'collection_wait_WITHOUT_observed_materializer':lambda m:'Waiting:collection_gate' in m and not any(k in m for k in ['Waiting:pressure_materialize','Syscall:pressure_materialize']),
'pressure_materializer_wait_AND_syscall_overlap':lambda m:'Waiting:pressure_materialize' in m and 'Syscall:pressure_materialize' in m,
'pressure_materializer_WITH_any_worker_running':lambda m:'Running:unattributed' in m and any(k in m for k in ['Waiting:pressure_materialize','Syscall:pressure_materialize'])}
a={key:sum(row['ns'] for row in n['masks_ns'] if pred(row['mask'])) for key,pred in predicates.items()}
a.update(native_span_ns=n['observed_release_to_exit_wall_ns'],legacy_span_ns=l['observed_release_to_exit_wall_ns'],native_instrumented_benchmark_ns=727767476,benchmark_minus_observed_ns=727767476-n['observed_release_to_exit_wall_ns'],observed_pressure_materializer_share=a['pressure_materializer_wait_or_syscall']/n['observed_release_to_exit_wall_ns'],max_concurrent_pressure_materializer_workers=max(sum(v for k,v in row['mask'].items() if k in ['Waiting:pressure_materialize','Syscall:pressure_materialize']) for row in n['masks_ns']),worker74_partition_sum_ns=sum(n['per_worker_disjoint_ns']['74'].values()),worker74_span_ns=n['bounds']['74']['span_ns'],drain_count=None,selected_rows_per_drain=None,removable_share=None)
assert a['worker74_partition_sum_ns']==a['worker74_span_ns']
assert a['pressure_materializer_wait_AND_syscall_overlap']==0 and a['max_concurrent_pressure_materializer_workers']==1
(O/'derived-mask-comparison.json').write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps(a,indent=2))
