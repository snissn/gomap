## TreeDB MVCC raw-path gate

- verdict: **PASS**
- measured threshold observation: **PASS**
- baseline: `f429275bbf0c0bda2cedfc9d5862200cee067ff5`
- candidate: `040a7444e6bd3dbd727ec2d81b7c6315abe7e379`
- samples: 8 per revision, benchmark-group-paired alternating AB/BA order
- timing acceptance: median paired candidate/base relative delta <= 5% (base/head medians remain reported for context)
- allocs/op threshold: candidate median must not increase
- B/op jitter threshold: candidate median may increase by at most the smaller of 1% or 64 B; zero-B baselines remain strict

| Package | Baseline SHA-256 | Candidate SHA-256 | Relation |
| --- | --- | --- | --- |
| db | `57a0ea8f792a1d2a78e2008e184134c79dc1c03bfcfb0b1a00eb42a8501609d3` | `b1370d6d3566df40bad36d9c864400965ee9101a7eeb4e7480c60534363e87d2` | DIFFERENT |
| caching | `1ec961614552a11a17b71fb82e5c5f79dd0843fe80dc152ef2b530176e7895ca` | `6e892a1fa235d050b5876d77b02d3c0641526619ce14572f0738a54ab2a10232` | DIFFERENT |
| treedb | `9ddb387c87884c44642659286f11807fcb7bb53cf331d394f69b0d8623c5e78e` | `d050c3d5dd0bb120afcf68658263de0109f0d7fab1b710a48ac771c2ca9dd164` | DIFFERENT |

| Benchmark | Binary | Base ns/op | Head ns/op | Median delta | Paired delta | Base B/op | Head B/op | B tolerance | Base allocs/op | Head allocs/op | Measured | Attribution | Acceptance |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- | --- |
| BenchmarkGetVersioned | db DIFFERENT | 393.350 | 406.150 | +3.25% | +1.86% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkConditionalTxnBaselineBatchWrite | db DIFFERENT | 32587.500 | 34476.500 | +5.80% | +2.23% | 31463.500 | 31463.000 | 64.000 | 101.000 | 101.000 | PASS | CANDIDATE | PASS |
| BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek | treedb DIFFERENT | 210.600 | 210.000 | -0.28% | -0.34% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkRepeatedIterator | caching DIFFERENT | 179.600 | 179.000 | -0.33% | -0.15% | 112.000 | 112.000 | 1.120 | 1.000 | 1.000 | PASS | CANDIDATE | PASS |
| BenchmarkPublicCommandWALDurableTinyBatchWriteSync/placement=inline/shape=dirty_batch/ops=1 | treedb DIFFERENT | 96433.500 | 95887.000 | -0.57% | +0.08% | 4575.500 | 4579.500 | 45.755 | 16.000 | 16.000 | PASS | CANDIDATE | PASS |
