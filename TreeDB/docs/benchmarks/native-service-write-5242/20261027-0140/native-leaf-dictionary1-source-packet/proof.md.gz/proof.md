# Native packed dictionary leaf source packet

Source-only, unvalidated; root exclusively owns Go, formatting, build, tests, runtime, commits and integration. Base 550a813d8421e149e50480c8801f08fe8b9e77c8. The selected patch includes the coordinator-provided contextual error wrapping in cow_read_workspace.go and preserves its errors.Is behavior.

## Producer contract

caching/leaf_page_log.go ordinary and prepared appends pass dictionary zero. This does not constrain all legitimate persisted leaves. db/leaf_generation_pack.go selects prepareCurrentRewriteLeafDict and configures rewriteWriter.SetLeafDictMode; db/vlog_rewrite.go prepareRewriteLeafDict may select the current outer_leaf dictionary, discover a preferred prior dictionary, or train/persist one from live leaf references. The rewrite writer emits that dictionary in grouped leaf frames. The lane is rewriteLeafLogLaneID 255, matching the observed value-l255 file. db/leaf_generation_pack_authority.go captureDictionary captures the stable dictionary closure through captureStableDictionaryResourcesForDB. Native readers must accept this maintained producer when the original scope carries independent-definition capability.

## Selected change and ownership

NativeSemanticCapture passes its existing dictionary capability to nativeEntryAtRoot and nativeLeafPage. Conditional transactions pass their original DB's supported capability, matching the maintained NativeValueAtPointer contract. Neither helper refreshes a file resolver, creates a capture, retries a body, falls back to another logical path, or changes a budget. Unsupported independent providers stay unsupported. Dictionary-free ZSTD leaf decoding stays refused by native helpers. Existing raw-ZSTD control passes nil explicitly after the private helper signature change.

The descriptor is per-call metadata. basis.readMu retains original traversal ownership; pinned file identity and InspectCOWLeafRecord still precede any verified page lookup. Cold dictionary decoding takes the same cache.physicalMu and calls the existing readInspected/codecWithDictionary path. That path admits independently owned dictionary bytes, dictionary capture/snapshot metadata and the generic decoder/input/raw envelope before allocation, releases partial owners on error, and retains no caller/provider/basis in shared workspace. Leaf copy-out finishes under original locks into caller dst; native entry copy-out retains its prior ownership. Verified page admission still follows complete-record CRC verification and page validation. Existing allocation, output, capacity, retention, snapshot and close policy remains unchanged.

## Deterministic causal fixture

TestCOWNativePackedDictionaryLeaf uses a real dictdb Store and trained persisted dictionary, ordinary caching leaf writes, real rotation and partly-live generations, then the real owner-bound LeafGenerationPackRunOnceForPrivateCOW plus normal basis adoption. It installs no leaf-log wrapper or read/decode hooks. The fixture asserts a real compressed nonzero dictionary / codec None record on its exact captured file before native reads. The test-only patch uses original signatures only and can be overlaid on the base source for causal RED. The original guard should return ErrCOWReadUnsupported at the first capable dictionary read; selected source should reach the injected real-provider preparation refusal and then pass normal native reads after real original-budget capacity refunds.

Both leaf and entry subcases cover exact original capture/transaction basis, missing provider refusal, real partial-definition admission failure/refund, original finite capacity refusal/retry, caller mutation isolation, independently owned shared dictionary storage and later checkpoint/basis turnover. The leaf subcase also reads the warmed held pointer after producer DB.Close. Existing native lifetime tests retain concurrent scope/close coverage; existing dictionary cache tests retain cold/warm CRC and inspection policies.

## Root validation selectors

New deterministic first: ^TestCOWNativePackedDictionaryLeaf$

Existing focused controls: ^TestCOW(Native(BasisWorkspaceLifetime|LeafWorkspaceAdmissionAndLifetime|ValueWorkspaceAdmissionAndLifetime|ValueDictionaryColdAfterClose)|RawBasisWorkspaceLifetime|DictionaryLeaf(PointCompletesFirstTraversal|ColdCacheAdmissionAndPolicy|CapableAdmissionRefundsFreshBasis)|OrderedIteratorDictionaryLeafFallback|PhysicalLeafCache(ActivationAndCapturedCuts|RequiresVerifiedRecordAndInspection)|OwnedDictionarySuccessor(TwoCutsDefaultBudget|AlternatingValues)|OwnedDictionaryBusySharedPreservesBorrowedRefusal|SuccessorFreshDictionaryLaneRefundsBeforeLocalTraversal|PublicPointFreshDictionaryRefundsBeforeLocalAdmission|SuccessorDictionaryHandoffKeepsWarmTraversal)$

Run new test against original with only test-only-original-red.patch; retain its failure as causal evidence. Format and validate selected patch under root ownership, then run original public 4096/32x128 four-writer durable/default-cap NewManager regression unchanged. Focused passes are diagnostics; they do not replace that public gate.
