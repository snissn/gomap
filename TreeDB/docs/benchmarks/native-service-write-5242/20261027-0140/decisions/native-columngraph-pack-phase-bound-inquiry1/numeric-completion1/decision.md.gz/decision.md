# Numeric completion: HARD DEFER

The fixed opener array/control subtotal is **215,744 bytes** on the observed linux/amd64 host, using Go 1.26 source layout and the repository's exact AllocationCharge policy. It is **not a complete M**. No construction is selected: path-cache lifetime and standard-library formatting/file controls remain unbound by a demonstrated existing owner contract. Do not substitute an arbitrary larger constant or silently treat existing controls as free. No source edit or Go/runtime execution was performed.

## Numeric identity and complete known subtotal

Host observations: pointer width 8 (`ctypes.sizeof(void*)`, not a Go program), x86_64, page size 4096. Go source ABI derivation: string/interface=16, slice=24, int/pointer=8; align scalars/struct fields naturally. Frozen Go1.26 sync.Once is 12 bytes (atomic.Bool4 + Mutex8), Mutex8 and atomic.Bool4. Source-inferred types: section40, section range56, layer48, chunk descriptor56, header200, prepared view1152; mappedresource Key192, Scope104, Pin376, Handle400, Stats160, Manager184, globalPinKey16. ConservativeHandleMetadataBytes=400+2*((8+376)+(16+376))=1952.

Q is TreeDB/internal/retainedalloc/owner.go:25-44: zero->0; on this host add16 for 512<n<32768, then round <=32768 to a power of two (minimum16), otherwise round to8192. Each actual allocation is charged separately. These are arithmetic source deductions, not measured Go sizeof values. The candidate would need sizeof-based guards rather than copying host constants into portable production code.

| Family | Payload bound | Count | Q charge total |
|---|---:|---:|---:|
| Original decoded directory | 138*40 | 1 | 8,192 |
| Cloned directory (twofold capacity bound) | 276*40 | 1 | 16,384 |
| Directory sort ranges | 138*56 | 1 | 8,192 |
| Seen-map existing 1KiB/entry reserve | 138*1024 | 1 | 147,456 |
| Additional map header | 48 | 1 | 64 |
| Adjacency layers | 64*48 | 1 | 4,096 |
| Adjacency chunk descriptor arrays | 64*56 | 2 | 8,192 |
| Fixed/per-layer one-element slice headers | 24 | 136 | 4,352 |
| Two-element starts backings | 16 | 136 | 2,176 |
| Prepared view | 1152 | 1 | 2,048 |
| Manager | 184 | 1 | 256 |
| Existing conservative handle/registration bound | 1952 | 1 | 2,048 |
| Local/global deny/fallback/validation maps (one reserved entry each) | 1024 | 6 | 12,288 |
| **Known subtotal** | | | **215,744** |

The reserve applies the existing preparedSemanticStreamMapEntryReserveBytes contract (column_retained_semantic_stream.go:120-123), and adds rather than subtracts map-header/control coverage. Existing current retainedCharge and 16*state/graph charges remain untouched. This may double-cover controls already in those charges; no speculative overlap credit is taken. A global pin-table arbitrary growth cohort is not newly proven by this table: it relies exactly on the maintained ConservativeHandleMetadataBytes accounting contract, not a new global-map census or policy.

Source Go runtime/slice.go:326-331 returns newLen for append from nil; runtime allocator rounding for S<=138 and 40-byte elements remains below twofold capacity (frozen sizeclasses source, max requested5520). Thus the clone row covers its actual capacity, not just len. Section/range slices use make with exact requested capacity. The sum intentionally retains both original and cloned arrays plus range/map scratch even across disjoint phases; no early refund is assumed.

## Raw backing and public L

For positive L and valid offset, R=max(Q(L),Q(pageRound4096((Offset mod4096)+L))). Check the modulo operands, addition, host-int length and page-round overflow before admission or mapping. This covers the successful mapped extent including prefix/page rounding, or the single successful heap fallback. mmap failure unwinds before fallback; manager.go:311-332 and :337-376 keep the existing file/mmap/refusal behavior. Source-supported Windows heap fallback remains mandatory; host constants must not be applied to Windows file controls without a proof for that platform.

Public log native-selected-public-race-fixed8.log:4 records combined retained request14,795,872 and setup3,143,360 at total55,473,712. cleanup-barrier-primitive-and-public1.log:20 records the same request after total falls only4,144. Neither log exposes L, and the source fixture's HNSW levels/adjacency depend on the real graph builder, so L is not statically recoverable exactly without storage inspection (not done). Because the request contains 16Q(L) PLUS nonnegative control/state charges, Q(L)<=917,504, the largest8192 multiple<=14,795,872/16; hence L<=917,504 and R<=925,696 on this host. The known raw+metadata subtotal is at most1,141,440B; this is NOT an upper bound for the complete opener. It does not establish actual savings or a passing public control.

## Unclosed allocation/lifetime obligations

1. **Namespace/path cache:** column_asset_manager.go:254-288 cache miss constructs namespace root, asset, segment, index, prepared, quarantine and temp path strings; :315-326 also validates/splits namespace. Sizes depend on actual root/namespace lengths. Cached strings/root/namespace aliases remain in the process-global fixed-stripe cache after the pack fails or closes. Native control charge currently explicitly includes only one Q(rootDir) and Q(collectionName), plus definition/state/graph multipliers and fixed8KiB controls (search.go:86-100,:265-290). No source owner/receipt was found tying these cache-owned path backings to that pack's lifetime. The original 16Q(L) is not proof that its replacement may omit them, nor does a bigger temporary receipt prove the cache's later lifetime. This is a proof gap in the proposed replacement, not a demonstrated newly introduced production bug.
2. **Formatting and error controls:** the successful flat opener formats two labels per layer (reader.go:1176,:1194), scope ID and numeric generation. Go1.26 fmt/print.go:161-177 can lend an existing printer buffer with capacity up to65,536 plus wrapped-error slots; printed-label length alone does not bound that capacity. Namespace/ref errors can format variable metadata; raw malformed magic contributes at most8 bytes. No exact allocation/ownership sum was completed for formatter object/buffer/argument boxing/error joins and the source-parameterized string copies. Merely adding65,536 is insufficient to prove all cases or multiple calls/cohorts.
3. **File/runtime controls:** os.Open/Stat, File/poll.FD, close closure, PathError, and mappedresource registration/error stats require an explicit account or a documented existing control-bound contract. ConservativeHandleMetadataBytes explicitly covers handle/manager/global pin registrations, not all os/file/error objects or namespace paths. The existing arbitrary8KiB cache/control addition is not self-documenting proof for these different controls. No new universal runtime/governor audit or allowance is proposed.

Consequently complete M=215,744+U_paths+U_format+U_file_controls remains **null**, not zero. An implementation cannot responsibly freeze the smaller full envelope from this packet. Acknowledging this is the requested hard defer; this inquiry does not authorize expanding into a new owner/accounting mechanism or silently waiving an existing one.

## Preserved parser/phase contract if an existing ownership proof closes the gaps

Before any map/file open reserve raw R plus the COMPLETED M in the existing retained lease, together with unchanged controls/state/graph charges. Use the SAME handle/envelope/parser. Existing header checks reject unsupported version/SourceV2 binding, short header, invalid rows/dims/stride/layers/metric/encoding/M/ef and invalid base/membership before directory allocation (reader.go:773-909). Exact section count=8+2*layers (+2 forV3, -1 externalV4), max layers64, directory offset/length/data geometry and CRC are checked before make(section_count) (:908-954), so S<=138 holds even for malformed input reaching allocation. After directory entry parse, known kind/alignment/range/duplicates/overlap and every payload CRC remain mandatory (:954-987,:1053-1104). The typed section shape/finite/row-ref/ID/neighbor checks and direct-view checks remain mandatory. No guessed graph metadata is substituted for wire validation.

Only AFTER that existing envelope returns and BEFORE prepareSectionViews, a private optional callback could retain max(R+M,old16Q(L)) for V3/V6. Preserve their OLD complete 16Q envelope rather than deriving a new auxiliary/BFS model; unknown versions and V7 in this SourceV2=false route remain refused, not routed elsewhere. V1/V2/V4/V5 need no row-sized construction scratch. This is not a source census, second parser/read, source import, capraise or coefficient reduction. No operation/setup refund: total peak would be unchanged external owners+setup+retained controls/state+selected complete pack envelope. Cache/refusal cleanup must release handles before receipt refund; no partial publication. Keeping the envelope until cache Close avoids claiming temporary garbage was collected early.

## Simpler retained-bound alternatives

- Keep current16Q(L): complete existing accepted envelope, public gate remains failed; no performance/default acceptance.
- Reuse retainedChunkMetadataBytes()+mappedBytes/heapCopyBytes after open: maintained helper inventories retained aliases and handle metadata, but omits envelope sort/map scratch, V3/V6 construction and path/file/error controls. A post-open shrink cannot repair the failing pre-open Resize. Do not select it as a complete-peak replacement.
- Private phase callback as above: materially removes payload-copy-based overreservation on ordinary V1 *if* complete M and lifetime proof exists; currently deferred. Do not select a lower flat multiplier or a blanket setup credit instead.

If selected later under a completed proof, freeze test-first original public4096/fixed128 warm failure, candidate same fixture/results/authority, mapped+heap paths; refusal before map and after V3/V6 envelope; bad header/count/CRC/source/unsupported versions; no partial cache entry, actual handle closure, original receipts and Close-zero. Original setup and V3/V6 envelope stay unchanged. No further inquiry/implementation is self-authorized here.
