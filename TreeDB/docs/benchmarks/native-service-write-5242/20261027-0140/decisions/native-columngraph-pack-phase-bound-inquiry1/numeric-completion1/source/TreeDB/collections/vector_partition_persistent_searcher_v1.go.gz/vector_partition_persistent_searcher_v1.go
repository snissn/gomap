package collections

import (
	"bytes"
	"container/heap"
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"math"
	"slices"
	"sort"
	"strconv"
	"strings"
	"time"

	backenddb "github.com/snissn/gomap/TreeDB/db"
	"github.com/snissn/gomap/TreeDB/internal/mappedresource"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
)

const vectorPartitionSearchAssetMagicV1 = "VPS1"
const vectorPartitionSearchAssetVersionV1 uint32 = 1
const vectorPartitionSearchAssetMaxBytesV1 int64 = 256 << 20

type vectorPartitionMembershipSourceV1 struct {
	ordinal int
	kind    VectorPartitionMembershipKindV1
}

// VectorPartitionConstructionEvidenceV1 is offline-only, versioned HNSW
// construction provenance. It is never serialized into the search pack.
type VectorPartitionConstructionEvidenceV1 struct {
	Schema                string                                           `json:"schema"`
	Variant               string                                           `json:"variant"`
	ManifestChecksum      string                                           `json:"manifest_checksum"`
	IndexDefinitionDigest string                                           `json:"index_definition_digest"`
	Partitions            []VectorPartitionConstructionPartitionEvidenceV1 `json:"partitions"`
}
type VectorPartitionConstructionPartitionEvidenceV1 struct {
	PartitionID             uint32                                        `json:"partition_id"`
	AssetChecksum           string                                        `json:"asset_checksum"`
	MembershipDigest        string                                        `json:"membership_digest"`
	AssetBytes              uint64                                        `json:"asset_bytes"`
	Selections              []VectorPartitionConstructionSelectionV1      `json:"selections"`
	Events                  []VectorPartitionConstructionEdgeEventV1      `json:"events"`
	PostfillEdges           uint64                                        `json:"postfill_edges"`
	NativeInsertionOrdinals []int                                         `json:"native_insertion_ordinals"`
	TraceMode               string                                        `json:"trace_mode,omitempty"`
	PruneKeeps              uint64                                        `json:"prune_keeps_compact"`
	CompactLifecycle        VectorPartitionConstructionCompactLifecycleV1 `json:"compact_lifecycle,omitempty"`
	FinalOrigins            []VectorPartitionConstructionFinalOriginV1    `json:"final_origins,omitempty"`
}
type VectorPartitionConstructionFinalOriginV1 struct {
	From   int    `json:"from"`
	To     int    `json:"to"`
	Layer  int    `json:"layer"`
	Origin string `json:"origin"`
}

// VectorPartitionConstructionCompactLifecycleV1 is the count-only history
// for non-selected M18 partitions. Origin order is the evidence origin_order.
type VectorPartitionConstructionCompactLifecycleV1 struct {
	InitialAdd    [8]uint64 `json:"initial_add"`
	ReciprocalAdd [8]uint64 `json:"reciprocal_add"`
	PruneKeep     [8]uint64 `json:"reciprocal_prune_keep"`
	PruneDrop     [8]uint64 `json:"reciprocal_prune_drop"`
	VariantAdd    [8]uint64 `json:"variant_add"`
	VariantDrop   [8]uint64 `json:"variant_drop"`
	// QualityPostfillAdd is a final-stage, offline-only fill of unused L0
	// capacity from rejected diverse candidates. It is distinct from ordinary
	// construction-time nearest backfill even though both retain its origin.
	QualityPostfillAdd [8]uint64 `json:"quality_postfill_add"`
}

// VectorPartitionConstructionEvidenceSchemaV1 identifies the current
// construction-evidence wire shape. The v3 value adds distinct robust-prune
// and residual-fill origins; evidence is offline-only and fails closed on an
// older shape.
const VectorPartitionConstructionEvidenceSchemaV1 = "treedb_vector_partition_construction_evidence_v3"

func vectorPartitionConstructionDetailedTraceV1(variant VectorPartitionLocalGraphVariantV1, partition uint32) bool {
	switch variant {
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOffV1,
		VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOnV1,
		VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOffV1,
		VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOnV1,
		VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1,
		VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MRobustPruneV1:
		// #4172 policy-coordinate screening retains only compact, exact final
		// origins. Full per-edge history is unnecessary for every treatment
		// pack and must not make exploratory materialization unbounded.
		return false
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256V1:
	default:
		return true
	}
	switch partition {
	case 0, 1, 3, 16, 36:
		return true
	}
	return false
}

type VectorPartitionConstructionSelectionV1 struct {
	Node              int    `json:"node"`
	Layer             int    `json:"layer"`
	Candidates        int    `json:"candidates"`
	Selected          int    `json:"selected"`
	DiversitySelected int    `json:"diversity_selected"`
	BackfillSelected  int    `json:"backfill_selected"`
	CandidateOrdinals []int  `json:"candidate_ordinals,omitempty"`
	CandidateDigest   string `json:"candidate_digest,omitempty"`
	CandidateSampled  bool   `json:"candidate_sampled"`
}
type VectorPartitionConstructionEdgeEventV1 struct {
	From             int    `json:"from"`
	To               int    `json:"to"`
	Layer            int    `json:"layer"`
	InsertionOrdinal int    `json:"insertion_ordinal"`
	Origin           string `json:"origin"`
	Action           string `json:"action"`
}

func vectorPartitionConstructionOriginValidV1(origin string) bool {
	switch origin {
	case "diversity_selected", "nearest_backfill", "reciprocal_add", "reciprocity_repair", "overlay_rewrite", "quality_postfill", "robust_prune_refinement", "robust_prune_residual_fill":
		return true
	default:
		return false
	}
}

func vectorPartitionConstructionActionValidV1(action string) bool {
	switch action {
	case "initial_add", "reciprocal_add", "reciprocal_prune_keep", "reciprocal_prune_drop", "reciprocity_repair_add", "reciprocity_repair_drop", "overlay_rewrite_add", "overlay_rewrite_drop", "quality_postfill_add", "robust_prune_add", "robust_prune_residual_fill_add", "robust_prune_drop", "final_survivor":
		return true
	default:
		return false
	}
}

func vectorPartitionConstructionVariantMutationAllowedV1(variant VectorPartitionLocalGraphVariantV1, action string) bool {
	if action == "quality_postfill_add" {
		return variant == VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1
	}
	if action == "robust_prune_add" || action == "robust_prune_residual_fill_add" || action == "robust_prune_drop" {
		return variant == VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MRobustPruneV1
	}
	if !strings.Contains(action, "_rewrite_") && !strings.Contains(action, "_repair_") {
		return true
	}
	if strings.HasPrefix(action, "overlay_rewrite_") {
		return variant == VectorPartitionLocalGraphVariantOverlayCurrentV1
	}
	if strings.HasPrefix(action, "reciprocity_repair_") {
		switch variant {
		case VectorPartitionLocalGraphVariantAuxiliaryNavigationV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction512V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOffV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOnV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOffV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOnV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MRobustPruneV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM20EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM22EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM24EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM32EfConstruction256V1:
			return true
		}
	}
	return false
}

func vectorPartitionConstructionCandidateDigestV1(ordinals []int) string {
	h := sha256.New()
	h.Write([]byte("treedb-4170-candidate-ordinals-v1/"))
	var raw [8]byte
	for _, ordinal := range ordinals {
		binary.LittleEndian.PutUint64(raw[:], uint64(ordinal))
		h.Write(raw[:])
	}
	return hex.EncodeToString(h.Sum(nil))
}

func compactPartitionAdjacencyV1(in []uint32) []uint32 {
	if len(in) < 2 {
		return in
	}
	n := 1
	for _, x := range in[1:] {
		if x != in[n-1] {
			in[n] = x
			n++
		}
	}
	return in[:n]
}

const vectorPartitionLocalNavigationBranchV1 = 8

// vectorPartitionLocalAuxiliaryNavigationV1 is a separately encoded layer-0
// component bridge. Its CSR never shares the native HNSW degree budget.
type vectorPartitionLocalAuxiliaryNavigationV1 struct {
	Offsets   []uint64
	Neighbors []uint32
}

type vectorPartitionReachabilityBoundaryV1 struct {
	source int
	target int
	score  float32
}

type vectorPartitionReachabilityBoundaryHeapV1 []vectorPartitionReachabilityBoundaryV1

func (h vectorPartitionReachabilityBoundaryHeapV1) Len() int { return len(h) }
func (h vectorPartitionReachabilityBoundaryHeapV1) Less(i, j int) bool {
	if h[i].score != h[j].score {
		return h[i].score > h[j].score
	}
	if h[i].source != h[j].source {
		return h[i].source < h[j].source
	}
	return h[i].target < h[j].target
}
func (h vectorPartitionReachabilityBoundaryHeapV1) Swap(i, j int) { h[i], h[j] = h[j], h[i] }
func (h *vectorPartitionReachabilityBoundaryHeapV1) Push(value any) {
	*h = append(*h, value.(vectorPartitionReachabilityBoundaryV1))
}
func (h *vectorPartitionReachabilityBoundaryHeapV1) Pop() any {
	old := *h
	last := old[len(old)-1]
	*h = old[:len(old)-1]
	return last
}

// buildVectorPartitionLocalAuxiliaryNavigationV1 connects the deterministic
// directed-reachability roots of the native layer-0 graph. The entry component
// is root zero; each later root is the least unseen ordinal. A bidirectional
// branching-factor-eight tree gives every root a path from the entry. Every
// non-root upper-layer row also points to its native reachability root, so a
// normal HNSW upper-layer descent can still reach the component bridge. The
// resulting auxiliary degree is bounded by nine.
func buildVectorPartitionLocalAuxiliaryNavigationV1(rows []columnVectorGraphAssetRow, entryOrdinal int) (vectorPartitionLocalAuxiliaryNavigationV1, error) {
	nativeOffsets := make([]uint64, len(rows)+1)
	levels := make([]uint16, len(rows))
	var nativeNeighbors []uint32
	for ordinal := range rows {
		neighbors, _, err := vectorPartitionLayer0AdjacencySplitV1(rows[ordinal].Adjacency)
		if err != nil {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, err
		}
		if uint64(len(neighbors)) > math.MaxUint64-nativeOffsets[ordinal] {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, errors.New("partition-local auxiliary native edge count")
		}
		nativeOffsets[ordinal+1] = nativeOffsets[ordinal] + uint64(len(neighbors))
		nativeNeighbors = append(nativeNeighbors, neighbors...)
		level, err := columnVectorGraphAdjacencyMaxLayer(rows[ordinal].Adjacency)
		if err != nil || level < 0 || level > math.MaxUint16 {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, errors.New("partition-local auxiliary level")
		}
		levels[ordinal] = uint16(level)
	}
	return buildVectorPartitionLocalAuxiliaryNavigationFromNativeLayer0V1(len(rows), entryOrdinal, levels, nativeOffsets, nativeNeighbors)
}

// repairVectorPartitionLocalLayer0ReachabilityV1 restores entry reachability
// without growing the graph. It prefers missing reverse boundary edges, then
// tries the least unseen root from every reachable source. Only non-tree edges
// in the maintained entry-rooted spanning tree may be displaced; that keeps
// every previously reachable row reachable without trial BFS scans. Every
// accepted edge then extends the same tree through its newly reachable rows.
func repairVectorPartitionLocalLayer0ReachabilityV1(rows []columnVectorGraphAssetRow, entryOrdinal int) (int, error) {
	if len(rows) == 0 {
		if entryOrdinal != -1 {
			return 0, errors.New("partition-local reachability repair entry")
		}
		return 0, nil
	}
	if entryOrdinal < 0 || entryOrdinal >= len(rows) {
		return 0, errors.New("partition-local reachability repair entry")
	}
	adjacency := make([][]uint32, len(rows))
	suffixes := make([][]uint32, len(rows))
	incoming := make([][]int, len(rows))
	for ordinal := range rows {
		var err error
		adjacency[ordinal], suffixes[ordinal], err = vectorPartitionLayer0AdjacencySplitV1(rows[ordinal].Adjacency)
		if err != nil {
			return 0, err
		}
		for _, neighbor := range adjacency[ordinal] {
			if int(neighbor) >= len(rows) || neighbor == uint32(ordinal) {
				return 0, errors.New("partition-local reachability repair neighbor")
			}
			incoming[neighbor] = append(incoming[neighbor], ordinal)
		}
	}
	seen := make([]bool, len(rows))
	parent := make([]int, len(rows))
	for ordinal := range parent {
		parent[ordinal] = -1
	}
	visit := func(root, rootParent int) []int {
		queue := []int{root}
		seen[root] = true
		parent[root] = rootParent
		for head := 0; head < len(queue); head++ {
			ordinal := queue[head]
			for _, neighbor := range adjacency[ordinal] {
				if !seen[neighbor] {
					seen[neighbor] = true
					parent[neighbor] = ordinal
					queue = append(queue, int(neighbor))
				}
			}
		}
		return queue
	}
	similarity := func(left, right int) (float32, error) {
		if len(rows[left].Vector) == 0 || len(rows[left].Vector) != len(rows[right].Vector) {
			return 0, errors.New("partition-local reachability repair vector dimensions")
		}
		leftInvNorm, rightInvNorm := rows[left].InvNorm, rows[right].InvNorm
		var err error
		if leftInvNorm == 0 {
			leftInvNorm, err = columnVectorGraphInvNorm(rows[left].Vector)
			if err != nil {
				return 0, err
			}
		}
		if rightInvNorm == 0 {
			rightInvNorm, err = columnVectorGraphInvNorm(rows[right].Vector)
			if err != nil {
				return 0, err
			}
		}
		var dot float64
		for dimension := range rows[left].Vector {
			dot = canonicalVectorPartitionAccumulateV1(dot, rows[left].Vector[dimension]*leftInvNorm, rows[right].Vector[dimension]*rightInvNorm)
		}
		return float32(dot), nil
	}
	blocked := make([]bool, len(rows))
	selectDrop := func(source int) (int, error) {
		if blocked[source] {
			return -1, nil
		}
		position := -1
		var weakest float32
		for candidate, neighbor := range adjacency[source] {
			if parent[neighbor] == source {
				continue
			}
			score, err := similarity(source, int(neighbor))
			if err != nil {
				return -1, err
			}
			if position < 0 || score < weakest || score == weakest && neighbor > adjacency[source][position] {
				position, weakest = candidate, score
			}
		}
		if position < 0 {
			blocked[source] = true
		}
		return position, nil
	}
	newlySeen := visit(entryOrdinal, -1)
	seenCount := len(newlySeen)
	boundaries := vectorPartitionReachabilityBoundaryHeapV1{}
	pushBoundaries := func(sources []int) error {
		for _, source := range sources {
			for _, target := range incoming[source] {
				if seen[target] {
					continue
				}
				score, err := similarity(source, target)
				if err != nil {
					return err
				}
				heap.Push(&boundaries, vectorPartitionReachabilityBoundaryV1{source: source, target: target, score: score})
			}
		}
		return nil
	}
	if err := pushBoundaries(newlySeen); err != nil {
		return 0, err
	}
	repairs := 0
	for seenCount < len(rows) {
		selected := vectorPartitionReachabilityBoundaryV1{source: -1, target: -1}
		drop := -1
		for boundaries.Len() != 0 {
			candidate := heap.Pop(&boundaries).(vectorPartitionReachabilityBoundaryV1)
			if seen[candidate.target] {
				continue
			}
			position, err := selectDrop(candidate.source)
			if err != nil {
				return 0, err
			}
			if position >= 0 {
				selected, drop = candidate, position
				break
			}
		}
		if drop < 0 {
			root := -1
			for ordinal := range seen {
				if !seen[ordinal] {
					root = ordinal
					break
				}
			}
			if root < 0 {
				return 0, errors.New("partition-local reachability repair invariant")
			}
			for source := range seen {
				if !seen[source] || len(adjacency[source]) == 0 {
					continue
				}
				position, err := selectDrop(source)
				if err != nil {
					return 0, err
				}
				if position < 0 {
					continue
				}
				score, err := similarity(source, root)
				if err != nil {
					return 0, err
				}
				if drop < 0 || score > selected.score || score == selected.score && source < selected.source {
					selected = vectorPartitionReachabilityBoundaryV1{source: source, target: root, score: score}
					drop = position
				}
			}
		}
		if drop < 0 {
			return 0, errors.New("partition-local reachability repair cannot preserve reachable rows")
		}
		prior := adjacency[selected.source][drop]
		if parent[prior] == selected.source {
			return 0, errors.New("partition-local reachability repair tree edge")
		}
		adjacency[selected.source][drop] = uint32(selected.target)
		newlySeen = visit(selected.target, selected.source)
		if len(newlySeen) == 0 {
			return 0, errors.New("partition-local reachability repair did not extend reachability")
		}
		seenCount += len(newlySeen)
		repairs++
		if err := pushBoundaries(newlySeen); err != nil {
			return 0, err
		}
	}
	for ordinal := range rows {
		rows[ordinal].Adjacency = vectorPartitionLayer0AdjacencyJoinV1(adjacency[ordinal], suffixes[ordinal])
	}
	return repairs, nil
}

func buildVectorPartitionLocalAuxiliaryNavigationFromNativeLayer0V1(rows, entryOrdinal int, levels []uint16, nativeOffsets []uint64, nativeNeighbors []uint32) (vectorPartitionLocalAuxiliaryNavigationV1, error) {
	return buildVectorPartitionLocalAuxiliaryNavigationFromNativeLayer0WithContextV1(context.Background(), rows, entryOrdinal, levels, nativeOffsets, nativeNeighbors)
}

func buildVectorPartitionLocalAuxiliaryNavigationFromNativeLayer0WithContextV1(ctx context.Context, rows, entryOrdinal int, levels []uint16, nativeOffsets []uint64, nativeNeighbors []uint32) (vectorPartitionLocalAuxiliaryNavigationV1, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		return vectorPartitionLocalAuxiliaryNavigationV1{}, err
	}
	if rows == 0 {
		if entryOrdinal != -1 {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, errors.New("partition-local auxiliary entry")
		}
		return vectorPartitionLocalAuxiliaryNavigationV1{Offsets: []uint64{0}}, nil
	}
	if entryOrdinal < 0 || entryOrdinal >= rows {
		return vectorPartitionLocalAuxiliaryNavigationV1{}, errors.New("partition-local auxiliary entry")
	}
	if len(levels) != rows || len(nativeOffsets) != rows+1 || nativeOffsets[0] != 0 || nativeOffsets[rows] != uint64(len(nativeNeighbors)) {
		return vectorPartitionLocalAuxiliaryNavigationV1{}, errors.New("partition-local auxiliary native offsets")
	}
	seen := make([]bool, rows)
	componentRoots := make([]uint32, rows)
	roots := make([]uint32, 0, 1)
	visit := func(root int) error {
		queue := []int{root}
		seen[root] = true
		componentRoots[root] = uint32(root)
		for head := 0; head < len(queue); head++ {
			if head&255 == 0 {
				if err := ctx.Err(); err != nil {
					return err
				}
			}
			ordinal := queue[head]
			start, end := nativeOffsets[ordinal], nativeOffsets[ordinal+1]
			if end < start || end > uint64(len(nativeNeighbors)) {
				return errors.New("partition-local auxiliary native offsets")
			}
			neighbors := nativeNeighbors[start:end]
			rowSeen := make(map[uint32]struct{}, len(neighbors))
			for _, neighbor := range neighbors {
				if int(neighbor) >= rows || neighbor == uint32(ordinal) {
					return errors.New("partition-local auxiliary native neighbor")
				}
				if _, duplicate := rowSeen[neighbor]; duplicate {
					return errors.New("partition-local auxiliary duplicate native neighbor")
				}
				rowSeen[neighbor] = struct{}{}
				if !seen[neighbor] {
					seen[neighbor] = true
					componentRoots[neighbor] = uint32(root)
					queue = append(queue, int(neighbor))
				}
			}
		}
		return nil
	}
	for ordinal := entryOrdinal; ; {
		roots = append(roots, uint32(ordinal))
		if err := visit(ordinal); err != nil {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, err
		}
		next := -1
		for candidate := range seen {
			if candidate&1023 == 0 {
				if err := ctx.Err(); err != nil {
					return vectorPartitionLocalAuxiliaryNavigationV1{}, err
				}
			}
			if !seen[candidate] {
				next = candidate
				break
			}
		}
		if next < 0 {
			break
		}
		ordinal = next
	}
	if len(roots) > 1 && len(roots)-1 > (math.MaxInt/2) {
		return vectorPartitionLocalAuxiliaryNavigationV1{}, errors.New("partition-local auxiliary edge count")
	}
	degrees := make([]uint8, rows)
	for child := 1; child < len(roots); child++ {
		parent := (child - 1) / vectorPartitionLocalNavigationBranchV1
		degrees[roots[parent]]++
		degrees[roots[child]]++
	}
	for ordinal, level := range levels {
		if level > 0 && componentRoots[ordinal] != uint32(ordinal) {
			degrees[ordinal]++
		}
	}
	offsets := make([]uint64, rows+1)
	for ordinal, degree := range degrees {
		if ordinal&1023 == 0 {
			if err := ctx.Err(); err != nil {
				return vectorPartitionLocalAuxiliaryNavigationV1{}, err
			}
		}
		if degree > vectorPartitionLocalNavigationBranchV1+1 {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, errors.New("partition-local auxiliary degree")
		}
		offsets[ordinal+1] = offsets[ordinal] + uint64(degree)
	}
	anchorEdges := 0
	for ordinal, level := range levels {
		if level > 0 && componentRoots[ordinal] != uint32(ordinal) {
			anchorEdges++
		}
	}
	if offsets[rows] != uint64(2*(len(roots)-1)+anchorEdges) {
		return vectorPartitionLocalAuxiliaryNavigationV1{}, errors.New("partition-local auxiliary edge count")
	}
	neighbors := make([]uint32, offsets[rows])
	next := append([]uint64(nil), offsets[:rows]...)
	for child := 1; child < len(roots); child++ {
		parent := (child - 1) / vectorPartitionLocalNavigationBranchV1
		left, right := roots[parent], roots[child]
		neighbors[next[left]] = right
		next[left]++
		neighbors[next[right]] = left
		next[right]++
	}
	for ordinal, level := range levels {
		root := componentRoots[ordinal]
		if level > 0 && root != uint32(ordinal) {
			neighbors[next[ordinal]] = root
			next[ordinal]++
		}
	}
	return vectorPartitionLocalAuxiliaryNavigationV1{Offsets: offsets, Neighbors: neighbors}, nil
}

func validateVectorPartitionLocalAuxiliaryNavigationV1(rows []columnVectorGraphAssetRow, entryOrdinal int, auxiliary vectorPartitionLocalAuxiliaryNavigationV1) error {
	expected, err := buildVectorPartitionLocalAuxiliaryNavigationV1(rows, entryOrdinal)
	if err != nil {
		return err
	}
	if !slices.Equal(auxiliary.Offsets, expected.Offsets) || !slices.Equal(auxiliary.Neighbors, expected.Neighbors) {
		return errors.New("partition-local auxiliary navigation mismatch")
	}
	return nil
}

func validateVectorPartitionLocalAuxiliaryNavigationFromNativeLayer0V1(rows, entryOrdinal int, levels []uint16, nativeOffsets []uint64, nativeNeighbors []uint32, auxiliary vectorPartitionLocalAuxiliaryNavigationV1) error {
	return validateVectorPartitionLocalAuxiliaryNavigationFromNativeLayer0WithContextV1(context.Background(), rows, entryOrdinal, levels, nativeOffsets, nativeNeighbors, auxiliary)
}

func validateVectorPartitionLocalAuxiliaryNavigationFromNativeLayer0WithContextV1(ctx context.Context, rows, entryOrdinal int, levels []uint16, nativeOffsets []uint64, nativeNeighbors []uint32, auxiliary vectorPartitionLocalAuxiliaryNavigationV1) error {
	expected, err := buildVectorPartitionLocalAuxiliaryNavigationFromNativeLayer0WithContextV1(ctx, rows, entryOrdinal, levels, nativeOffsets, nativeNeighbors)
	if err != nil {
		return err
	}
	if !slices.Equal(auxiliary.Offsets, expected.Offsets) || !slices.Equal(auxiliary.Neighbors, expected.Neighbors) {
		return errors.New("partition-local auxiliary navigation mismatch")
	}
	return nil
}

// VectorPartitionLocalGraphVariantV1 selects the partition-local graph build
// used for offline causal attribution. Callers must bind the selected variant
// into their pack identity before comparing results.
type VectorPartitionLocalGraphVariantV1 string

const (
	// VectorPartitionLocalGraphVariantConnectivityPreservingVamanaR64L256Alpha1_2V1
	// is the production partition profile: two-pass Vamana with R=64,
	// construction list L=256, final alpha=1.2, and a deterministic
	// degree-preserving entry-reachability pass.
	VectorPartitionLocalGraphVariantConnectivityPreservingVamanaR64L256Alpha1_2V1 VectorPartitionLocalGraphVariantV1 = "connectivity_preserving_vamana_r64_l256_alpha_1_2"
	// VectorPartitionLocalGraphVariantCanonicalHNSWM18EfConstruction256V1 is
	// the retained pre-Vamana production HNSW profile.
	VectorPartitionLocalGraphVariantCanonicalHNSWM18EfConstruction256V1 VectorPartitionLocalGraphVariantV1 = "canonical_hnsw_m18_ef_construction_256"
	VectorPartitionLocalGraphVariantNativeV1                            VectorPartitionLocalGraphVariantV1 = "native"
	VectorPartitionLocalGraphVariantOverlayCurrentV1                    VectorPartitionLocalGraphVariantV1 = "overlay_current"
	// VectorPartitionLocalGraphVariantAuxiliaryNavigationV1 is the explicit M16
	// v3 repair: native HNSW is unchanged and component bridges live in the
	// separately encoded auxiliary channel.
	VectorPartitionLocalGraphVariantAuxiliaryNavigationV1 VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation"
	// VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction256V1 is
	// an offline-only auxiliary-navigation construction candidate.
	VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction256V1 VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_ef_construction_256"
	// VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction512V1 is
	// an offline-only auxiliary-navigation construction candidate.
	VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction512V1 VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_ef_construction_512"
	// VectorPartitionLocalGraphVariantAuxiliaryNavigationM24EfConstruction256V1
	// is an offline-only auxiliary-navigation construction candidate.
	VectorPartitionLocalGraphVariantAuxiliaryNavigationM24EfConstruction256V1 VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_m24_ef_construction_256"
	// VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256V1
	// is an offline auxiliary-navigation construction control.
	VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256V1 VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_m18_ef_construction_256"
	// The following six variants are offline-only layer-0 construction-policy
	// coordinates. All retain M18/eFC256 and the canonical reciprocal 2M cap.
	VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOffV1  VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_m18_ef_construction_256_l0_initial_m_backfill_off"
	VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOnV1   VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_m18_ef_construction_256_l0_initial_m_backfill_on"
	VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOffV1 VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_m18_ef_construction_256_l0_initial_2m_backfill_off"
	VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOnV1  VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_m18_ef_construction_256_l0_initial_2m_backfill_on"
	// VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1
	// keeps the 2M/backfill-off diversity selection and fills only unused L0
	// capacity with a deterministic least-redundant discarded-candidate pass.
	// It is offline-only and is not a production materialization default.
	VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1 VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_m18_ef_construction_256_l0_initial_2m_quality_postfill"
	// VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MRobustPruneV1
	// starts with 2M/backfill-off HNSW and applies one final, offline-only
	// DiskANN RobustPrune alpha=1.2 L0 refinement plus explicit residual fill.
	VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MRobustPruneV1 VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_m18_ef_construction_256_l0_initial_2m_robust_prune_alpha_1_2"
	// VectorPartitionLocalGraphVariantAuxiliaryNavigationM20EfConstruction256V1
	// is an offline high-recall auxiliary-navigation profile.
	VectorPartitionLocalGraphVariantAuxiliaryNavigationM20EfConstruction256V1 VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_m20_ef_construction_256"
	// VectorPartitionLocalGraphVariantAuxiliaryNavigationM22EfConstruction256V1
	// is an offline-only auxiliary-navigation construction candidate.
	VectorPartitionLocalGraphVariantAuxiliaryNavigationM22EfConstruction256V1 VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_m22_ef_construction_256"
	// VectorPartitionLocalGraphVariantAuxiliaryNavigationM32EfConstruction256V1
	// is an offline-only auxiliary-navigation construction candidate.
	VectorPartitionLocalGraphVariantAuxiliaryNavigationM32EfConstruction256V1 VectorPartitionLocalGraphVariantV1 = "auxiliary_navigation_m32_ef_construction_256"
	vectorPartitionLocalDefaultGraphVariantV1                                                                    = VectorPartitionLocalGraphVariantConnectivityPreservingVamanaR64L256Alpha1_2V1
)

func VectorPartitionLocalGraphVariantIdentityV1(variant VectorPartitionLocalGraphVariantV1) (string, error) {
	switch variant {
	case VectorPartitionLocalGraphVariantConnectivityPreservingVamanaR64L256Alpha1_2V1, VectorPartitionLocalGraphVariantCanonicalHNSWM18EfConstruction256V1, VectorPartitionLocalGraphVariantNativeV1, VectorPartitionLocalGraphVariantOverlayCurrentV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction512V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOffV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOnV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOffV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOnV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MRobustPruneV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM20EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM22EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM24EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM32EfConstruction256V1:
		return "partition_local_graph_delta_v1:" + string(variant), nil
	default:
		return "", fmt.Errorf("partition-local graph variant=%q", variant)
	}
}

func vectorPartitionLocalGraphVariantMembershipDigestV1(membership [sha256.Size]byte, variant VectorPartitionLocalGraphVariantV1) [sha256.Size]byte {
	if variant == VectorPartitionLocalGraphVariantOverlayCurrentV1 || variant == VectorPartitionLocalGraphVariantAuxiliaryNavigationV1 {
		return membership
	}
	h := sha256.New()
	h.Write([]byte("treedb_vector_partition_local_graph_variant_v1/"))
	h.Write([]byte(variant))
	h.Write(membership[:])
	var out [sha256.Size]byte
	copy(out[:], h.Sum(nil))
	return out
}

// vectorPartitionLocalGraphVariantDefinitionV1 keeps the authoritative source
// definition unchanged while selecting the identified local builder parameters.
func vectorPartitionLocalGraphVariantDefinitionV1(def VectorIndexDefinition, variant VectorPartitionLocalGraphVariantV1) (VectorIndexDefinition, bool, error) {
	switch variant {
	case VectorPartitionLocalGraphVariantConnectivityPreservingVamanaR64L256Alpha1_2V1:
		// The pack's compatibility fields encode flat degree 2M=64 and L=256.
		def.M, def.EfConstruction = 32, vectorPartitionVamanaSearchListV1
		return def, false, nil
	case VectorPartitionLocalGraphVariantCanonicalHNSWM18EfConstruction256V1:
		def.M, def.EfConstruction = 18, 256
		return def, false, nil
	case VectorPartitionLocalGraphVariantNativeV1, VectorPartitionLocalGraphVariantOverlayCurrentV1:
		return def, false, nil
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationV1:
		return def, true, nil
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction256V1:
		def.EfConstruction = 256
		return def, true, nil
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction512V1:
		def.EfConstruction = 512
		return def, true, nil
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256V1,
		VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOffV1,
		VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOnV1,
		VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOffV1,
		VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOnV1,
		VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1,
		VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MRobustPruneV1:
		def.M, def.EfConstruction = 18, 256
		return def, true, nil
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM20EfConstruction256V1:
		def.M, def.EfConstruction = 20, 256
		return def, true, nil
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM22EfConstruction256V1:
		def.M, def.EfConstruction = 22, 256
		return def, true, nil
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM24EfConstruction256V1:
		def.M, def.EfConstruction = 24, 256
		return def, true, nil
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM32EfConstruction256V1:
		def.M, def.EfConstruction = 32, 256
		return def, true, nil
	default:
		return VectorIndexDefinition{}, false, fmt.Errorf("partition-local graph variant=%q", variant)
	}
}

// VectorPartitionLocalGraphVariantParametersV1 returns the effective build
// parameters for an explicitly identified production or offline graph.
func VectorPartitionLocalGraphVariantParametersV1(def VectorIndexDefinition, variant VectorPartitionLocalGraphVariantV1) (int, int, error) {
	selected, _, err := vectorPartitionLocalGraphVariantDefinitionV1(def, variant)
	return selected.M, selected.EfConstruction, err
}

func vectorPartitionLocalGraphVariantLayer0ConstructionPolicyV1(variant VectorPartitionLocalGraphVariantV1) (vectorIndexLayer0ConstructionPolicyV1, bool) {
	switch variant {
	case VectorPartitionLocalGraphVariantCanonicalHNSWM18EfConstruction256V1:
		return vectorIndexLayer0ConstructionPolicyV1{initialSelectionFactor: 1, backfill: true, preserveSearchSet: true}, true
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOffV1:
		return vectorIndexLayer0ConstructionPolicyV1{initialSelectionFactor: 1, backfill: false}, true
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOnV1:
		return vectorIndexLayer0ConstructionPolicyV1{initialSelectionFactor: 1, backfill: true}, true
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOffV1:
		return vectorIndexLayer0ConstructionPolicyV1{initialSelectionFactor: 2, backfill: false}, true
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOnV1:
		return vectorIndexLayer0ConstructionPolicyV1{initialSelectionFactor: 2, backfill: true}, true
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1:
		return vectorIndexLayer0ConstructionPolicyV1{initialSelectionFactor: 2, qualityPostfill: true}, true
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MRobustPruneV1:
		return vectorIndexLayer0ConstructionPolicyV1{initialSelectionFactor: 2, robustPruneRefinement: true}, true
	default:
		return vectorIndexLayer0ConstructionPolicyV1{}, false
	}
}

// vectorPartitionLocalGraphDeltaRowV1 is the deterministic, construction-time
// accounting needed to compare the native local graph with the current
// partition-only navigation overlay. It intentionally describes the existing
// mutation; it does not select a repair.
type vectorPartitionLocalGraphDeltaRowV1 struct {
	NativeDegree         uint32
	FinalDegree          uint32
	OverlayEdges         uint32
	OverlayDuplicates    uint32
	DisplacedNativeEdges uint32
}

func vectorPartitionLocalGraphDeltaV1(nativeRows, finalRows []columnVectorGraphAssetRow, degreeLimit int) ([]vectorPartitionLocalGraphDeltaRowV1, error) {
	if len(nativeRows) != len(finalRows) || degreeLimit < 2 {
		return nil, errors.New("partition-local graph delta input")
	}
	deltas := make([]vectorPartitionLocalGraphDeltaRowV1, len(nativeRows))
	for row := range nativeRows {
		native, nativeSuffix, err := vectorPartitionLayer0AdjacencySplitV1(nativeRows[row].Adjacency)
		if err != nil {
			return nil, err
		}
		final, finalSuffix, err := vectorPartitionLayer0AdjacencySplitV1(finalRows[row].Adjacency)
		if err != nil || !vectorPartitionUint32SlicesEqualV1(nativeSuffix, finalSuffix) || len(final) > degreeLimit {
			return nil, errors.New("partition-local graph delta adjacency")
		}
		finalSet := make(map[uint32]struct{}, len(final))
		for _, neighbor := range final {
			if int(neighbor) >= len(finalRows) || neighbor == uint32(row) {
				return nil, errors.New("partition-local graph delta neighbor")
			}
			finalSet[neighbor] = struct{}{}
		}
		overlay, err := vectorPartitionLocalNavigationEdgesV1(row, len(nativeRows), degreeLimit)
		if err != nil {
			return nil, err
		}
		nativeSet := make(map[uint32]struct{}, len(native))
		for _, neighbor := range native {
			nativeSet[neighbor] = struct{}{}
		}
		d := vectorPartitionLocalGraphDeltaRowV1{NativeDegree: uint32(len(native)), FinalDegree: uint32(len(final)), OverlayEdges: uint32(len(overlay))}
		for _, neighbor := range overlay {
			if _, ok := nativeSet[neighbor]; ok {
				d.OverlayDuplicates++
			}
		}
		for _, neighbor := range native {
			if _, ok := finalSet[neighbor]; !ok {
				d.DisplacedNativeEdges++
			}
		}
		deltas[row] = d
	}
	return deltas, nil
}

func vectorPartitionLocalNavigationEdgesV1(row, rows, degreeLimit int) ([]uint32, error) {
	if rows < 1 || row < 0 || row >= rows || degreeLimit < 2 {
		return nil, errors.New("partition-local navigation delta input")
	}
	if rows == 1 {
		return nil, nil
	}
	if degreeLimit == 2 {
		return []uint32{uint32((row + 1) % rows)}, nil
	}
	branch := min(vectorPartitionLocalNavigationBranchV1, degreeLimit-2)
	edges := make([]uint32, 0, branch+1)
	if row != 0 {
		edges = append(edges, uint32((row-1)/branch))
	}
	for child := row*branch + 1; child < min(rows, row*branch+branch+1); child++ {
		edges = append(edges, uint32(child))
	}
	return edges, nil
}

func vectorPartitionUint32SlicesEqualV1(left, right []uint32) bool {
	if len(left) != len(right) {
		return false
	}
	for i := range left {
		if left[i] != right[i] {
			return false
		}
	}
	return true
}

// buildVectorPartitionLocalGraphAdjacencyV1 retains the shared native graph
// and computes its separate partition-only reachability channel. The channel
// is encoded by the pack materializer; native adjacency is never rewritten.
func buildVectorPartitionLocalGraphAdjacencyV1(rows []columnVectorGraphAssetRow, def VectorIndexDefinition) error {
	_, err := buildVectorPartitionLocalGraphAdjacencyVariantWithAuxiliaryV1(rows, def, VectorPartitionLocalGraphVariantAuxiliaryNavigationV1)
	return err
}

func buildVectorPartitionLocalGraphAdjacencyVariantV1(rows []columnVectorGraphAssetRow, def VectorIndexDefinition, variant VectorPartitionLocalGraphVariantV1) error {
	_, err := buildVectorPartitionLocalGraphAdjacencyVariantWithAuxiliaryV1(rows, def, variant)
	return err
}

func buildVectorPartitionLocalGraphAdjacencyVariantWithAuxiliaryV1(rows []columnVectorGraphAssetRow, def VectorIndexDefinition, variant VectorPartitionLocalGraphVariantV1) (vectorPartitionLocalAuxiliaryNavigationV1, error) {
	return buildVectorPartitionLocalGraphAdjacencyVariantWithConstructionTraceV1(rows, def, variant, nil)
}

func buildVectorPartitionLocalGraphAdjacencyVariantWithConstructionTraceV1(rows []columnVectorGraphAssetRow, def VectorIndexDefinition, variant VectorPartitionLocalGraphVariantV1, trace *vectorIndexConstructionTraceV1) (vectorPartitionLocalAuxiliaryNavigationV1, error) {
	if _, err := VectorPartitionLocalGraphVariantIdentityV1(variant); err != nil {
		return vectorPartitionLocalAuxiliaryNavigationV1{}, err
	}
	if variant == VectorPartitionLocalGraphVariantConnectivityPreservingVamanaR64L256Alpha1_2V1 {
		if trace != nil {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, errors.New("partition-local Vamana does not emit HNSW construction evidence")
		}
		return vectorPartitionLocalAuxiliaryNavigationV1{}, buildVectorPartitionVamanaV1(context.Background(), rows, def.Dimensions)
	}
	var policy *vectorIndexLayer0ConstructionPolicyV1
	if configured, ok := vectorPartitionLocalGraphVariantLayer0ConstructionPolicyV1(variant); ok {
		policy = &configured
	}
	if err := buildColumnVectorGraphAdjacencyWithConstructionPolicyV1(rows, def, trace, false, policy); err != nil {
		return vectorPartitionLocalAuxiliaryNavigationV1{}, err
	}
	switch variant {
	case VectorPartitionLocalGraphVariantCanonicalHNSWM18EfConstruction256V1, VectorPartitionLocalGraphVariantNativeV1:
		if err := trace.recordFinalSurvivors(rows); err != nil {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, err
		}
		return vectorPartitionLocalAuxiliaryNavigationV1{}, nil
	case VectorPartitionLocalGraphVariantOverlayCurrentV1:
		if err := addVectorPartitionLocalNavigationOverlayV1(rows, def.M*2); err != nil {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, err
		}
		if err := trace.reconcileVariantMutation(rows, "overlay_rewrite"); err != nil {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, err
		}
		if err := trace.recordFinalSurvivors(rows); err != nil {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, err
		}
		return vectorPartitionLocalAuxiliaryNavigationV1{}, nil
	case VectorPartitionLocalGraphVariantAuxiliaryNavigationV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationEfConstruction512V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOffV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0InitialMBackfillOnV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOffV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MBackfillOnV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MRobustPruneV1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM20EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM22EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM24EfConstruction256V1, VectorPartitionLocalGraphVariantAuxiliaryNavigationM32EfConstruction256V1:
		if _, err := repairVectorPartitionLocalLayer0ReachabilityV1(rows, 0); err != nil {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, err
		}
		if err := trace.reconcileVariantMutation(rows, "reciprocity_repair"); err != nil {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, err
		}
		if err := trace.recordFinalSurvivors(rows); err != nil {
			return vectorPartitionLocalAuxiliaryNavigationV1{}, err
		}
		return buildVectorPartitionLocalAuxiliaryNavigationV1(rows, 0)
	default:
		return vectorPartitionLocalAuxiliaryNavigationV1{}, fmt.Errorf("partition-local graph variant=%q", variant)
	}
}

// reconcileVariantMutation accounts every layer-0 rewrite made after the
// native HNSW builder. The origin of a removed edge remains its causal native
// origin; a replacement is explicitly attributed to the variant rewrite.
func (t *vectorIndexConstructionTraceV1) reconcileVariantMutation(rows []columnVectorGraphAssetRow, mutation string) error {
	if t == nil {
		return nil
	}
	if mutation != "reciprocity_repair" && mutation != "overlay_rewrite" {
		return fmt.Errorf("collections: construction trace mutation=%q", mutation)
	}
	final := make(map[vectorIndexConstructionEdgeKeyV1]struct{})
	for from := range rows {
		layers, err := vectorPartitionConstructionAdjacencyLayersV1(rows[from].Adjacency)
		if err != nil {
			return err
		}
		for layer, neighbors := range layers {
			for _, to := range neighbors {
				final[vectorIndexConstructionEdgeKeyV1{From: from, To: int(to), Layer: layer}] = struct{}{}
			}
		}
	}
	dropAction, addAction := mutation+"_drop", mutation+"_add"
	less := func(left, right vectorIndexConstructionEdgeKeyV1) bool {
		if left.Layer != right.Layer {
			return left.Layer < right.Layer
		}
		if left.From != right.From {
			return left.From < right.From
		}
		return left.To < right.To
	}
	drops := make([]vectorIndexConstructionEdgeKeyV1, 0)
	for key := range t.origins {
		if _, survives := final[key]; survives {
			continue
		}
		if key.Layer != 0 {
			return fmt.Errorf("collections: construction trace unexpected variant removal layer=%d", key.Layer)
		}
		drops = append(drops, key)
	}
	sort.Slice(drops, func(i, j int) bool { return less(drops[i], drops[j]) })
	for _, key := range drops {
		origin := t.origins[key]
		t.record(key.From, key.To, key.Layer, origin, dropAction)
		delete(t.origins, key)
	}
	adds := make([]vectorIndexConstructionEdgeKeyV1, 0)
	for key := range final {
		if _, existed := t.origins[key]; existed {
			continue
		}
		if key.Layer != 0 {
			return fmt.Errorf("collections: construction trace unexpected variant layer=%d", key.Layer)
		}
		adds = append(adds, key)
	}
	sort.Slice(adds, func(i, j int) bool { return less(adds[i], adds[j]) })
	for _, key := range adds {
		t.origins[key] = mutation
		t.record(key.From, key.To, key.Layer, mutation, addAction)
	}
	return nil
}

func addVectorPartitionLocalNavigationOverlayV1(rows []columnVectorGraphAssetRow, degreeLimit int) error {
	if len(rows) < 2 {
		return nil
	}
	if degreeLimit < 2 {
		return fmt.Errorf("partition-local navigation degree limit=%d", degreeLimit)
	}
	if degreeLimit == 2 {
		// M=1 has room for exactly a navigation successor plus one native edge.
		// The directed ring reaches every row without widening the declared cap.
		for row := range rows {
			native, suffix, err := vectorPartitionLayer0AdjacencySplitV1(rows[row].Adjacency)
			if err != nil {
				return err
			}
			out := []uint32{uint32((row + 1) % len(rows))}
			for _, neighbor := range native {
				if uint64(neighbor) >= uint64(len(rows)) || neighbor == uint32(row) {
					return fmt.Errorf("partition-local native neighbor row=%d neighbor=%d", row, neighbor)
				}
			}
			for _, neighbor := range native {
				if neighbor != out[0] {
					out = append(out, neighbor)
					break
				}
			}
			rows[row].Adjacency = vectorPartitionLayer0AdjacencyJoinV1(out, suffix)
		}
		return nil
	}
	// Reserve one layer-0 native edge for every row. M=16 keeps the existing
	// branch=8 layout byte-for-byte; lower M reduces the overlay fanout.
	branch := min(vectorPartitionLocalNavigationBranchV1, degreeLimit-2)
	children := make([][]uint32, len(rows))
	for child := 1; child < len(rows); child++ {
		parent := (child - 1) / branch
		children[parent] = append(children[parent], uint32(child))
	}
	for row := range rows {
		native, suffix, err := vectorPartitionLayer0AdjacencySplitV1(rows[row].Adjacency)
		if err != nil {
			return err
		}
		overlay := make([]uint32, 0, len(children[row])+1)
		if row != 0 {
			overlay = append(overlay, uint32((row-1)/branch))
		}
		overlay = append(overlay, children[row]...)
		if len(overlay) > degreeLimit {
			return fmt.Errorf("partition-local navigation row=%d degree=%d exceeds limit=%d", row, len(overlay), degreeLimit)
		}
		out := append([]uint32(nil), overlay...)
		for _, neighbor := range native {
			if uint64(neighbor) >= uint64(len(rows)) || neighbor == uint32(row) {
				return fmt.Errorf("partition-local native neighbor row=%d neighbor=%d", row, neighbor)
			}
			duplicate := false
			for _, existing := range out {
				if existing == neighbor {
					duplicate = true
					break
				}
			}
			if !duplicate && len(out) < degreeLimit {
				out = append(out, neighbor)
			}
		}
		rows[row].Adjacency = vectorPartitionLayer0AdjacencyJoinV1(out, suffix)
	}
	return nil
}

// split returns the layer-0 neighbors plus the exact encoded higher-layer
// suffix. A nil suffix denotes the legacy layer-0-only representation.
func vectorPartitionLayer0AdjacencySplitV1(adjacency []uint32) ([]uint32, []uint32, error) {
	if len(adjacency) == 0 {
		return nil, nil, nil
	}
	if adjacency[0] != columnVectorGraphLayeredAdjacencyMagic {
		return append([]uint32(nil), adjacency...), nil, nil
	}
	if len(adjacency) < 3 {
		return nil, nil, errors.New("partition-local layered adjacency header")
	}
	count := int(adjacency[2])
	if count < 0 || count > len(adjacency)-3 {
		return nil, nil, errors.New("partition-local layered adjacency layer-0 count")
	}
	suffix := make([]uint32, 1, 1+len(adjacency)-(3+count))
	suffix[0] = adjacency[1]
	suffix = append(suffix, adjacency[3+count:]...)
	return append([]uint32(nil), adjacency[3:3+count]...), suffix, nil
}

func vectorPartitionLayer0AdjacencyJoinV1(layer0, suffix []uint32) []uint32 {
	if suffix == nil {
		return layer0
	}
	out := make([]uint32, 0, 3+len(layer0)+len(suffix))
	out = append(out, columnVectorGraphLayeredAdjacencyMagic, suffix[0], uint32(len(layer0)))
	out = append(out, layer0...)
	out = append(out, suffix[1:]...)
	return out
}

func vectorPartitionLocalAssetIDV1(partition uint32) string {
	return fmt.Sprintf("hnsw_search_pack_v1/partition/%d", partition)
}

func vectorPartitionLocalSectionChunkAssetIDV1(partition uint32, key columnHNSWSearchPackSectionKey, chunk uint32) string {
	return fmt.Sprintf("%s/section/%02d/%05d/chunk/%08d", vectorPartitionLocalAssetIDV1(partition), key.kind, key.index, chunk)
}

func parseVectorPartitionLocalSectionChunkAssetIDV1(partition uint32, id string) (columnHNSWSearchPackSectionKey, uint32, error) {
	prefix := vectorPartitionLocalAssetIDV1(partition) + "/section/"
	parts := strings.Split(strings.TrimPrefix(id, prefix), "/")
	if !strings.HasPrefix(id, prefix) || len(parts) != 4 || parts[2] != "chunk" {
		return columnHNSWSearchPackSectionKey{}, 0, errors.New("domain section chunk asset id")
	}
	kind, kindErr := strconv.ParseUint(parts[0], 10, 16)
	index, indexErr := strconv.ParseUint(parts[1], 10, 16)
	chunk, chunkErr := strconv.ParseUint(parts[3], 10, 32)
	key := columnHNSWSearchPackSectionKey{kind: columnHNSWSearchPackSectionKind(kind), index: uint16(index)}
	if kindErr != nil || indexErr != nil || chunkErr != nil || vectorPartitionLocalSectionChunkAssetIDV1(partition, key, uint32(chunk)) != id {
		return columnHNSWSearchPackSectionKey{}, 0, errors.New("domain section chunk asset id")
	}
	return key, uint32(chunk), nil
}

func vectorPartitionDomainLayoutV1(manifest VectorPartitionManifestV1) ([]uint32, []uint32, error) {
	if err := manifest.requireInlineRuntimeV1(); err != nil {
		return nil, nil, err
	}
	if manifest.DomainCount == 0 || manifest.DomainCount > manifest.PartitionCount || len(manifest.DomainPacks) != int(manifest.PartitionCount) {
		return nil, nil, fmt.Errorf("%w: domain layout", ErrVectorPartitionSearchUnavailable)
	}
	anchors := make([]uint32, manifest.DomainCount)
	anchorForPack := make([]uint32, manifest.PartitionCount)
	seen := make([]bool, manifest.PartitionCount)
	groups := make([]string, manifest.PartitionCount)
	for _, placement := range manifest.Placements {
		if placement.PartitionID >= manifest.PartitionCount || groups[placement.PartitionID] != "" {
			return nil, nil, fmt.Errorf("%w: domain placement", ErrVectorPartitionSearchUnavailable)
		}
		groups[placement.PartitionID] = placement.GroupID
	}
	var lastDomain uint32
	for i, mapping := range manifest.DomainPacks {
		if mapping.DomainID >= manifest.DomainCount || mapping.PackID >= manifest.PartitionCount || seen[mapping.PackID] ||
			(i == 0 && mapping.DomainID != 0) || (i > 0 && (mapping.DomainID < lastDomain || mapping.DomainID > lastDomain+1)) {
			return nil, nil, fmt.Errorf("%w: domain layout", ErrVectorPartitionSearchUnavailable)
		}
		if i == 0 || mapping.DomainID != lastDomain {
			anchors[mapping.DomainID] = mapping.PackID
			lastDomain = mapping.DomainID
		}
		anchor := anchors[mapping.DomainID]
		if len(manifest.Placements) != 0 && (groups[anchor] == "" || groups[mapping.PackID] != groups[anchor]) {
			return nil, nil, fmt.Errorf("%w: split domain ownership", ErrVectorPartitionSearchUnavailable)
		}
		anchorForPack[mapping.PackID] = anchor
		seen[mapping.PackID] = true
	}
	if lastDomain+1 != manifest.DomainCount {
		return nil, nil, fmt.Errorf("%w: missing domain", ErrVectorPartitionSearchUnavailable)
	}
	for pack, ok := range seen {
		if !ok {
			return nil, nil, fmt.Errorf("%w: missing domain pack %d", ErrVectorPartitionSearchUnavailable, pack)
		}
	}
	return anchors, anchorForPack, nil
}

type vectorPartitionServingMembershipKeyV1 struct {
	ordinal uint64
	anchor  uint32
}

func vectorPartitionServingMembershipKindsV1(ctx context.Context, manifest VectorPartitionManifestV1, anchorForPack []uint32) (map[vectorPartitionServingMembershipKeyV1]VectorPartitionMembershipKindV1, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	kinds := make(map[vectorPartitionServingMembershipKeyV1]VectorPartitionMembershipKindV1, len(manifest.Memberships)+len(manifest.OverlapMemberships))
	add := func(memberships []VectorPartitionMembershipV1, kind VectorPartitionMembershipKindV1) error {
		for i, membership := range memberships {
			if i&1023 == 0 {
				if err := ctx.Err(); err != nil {
					return err
				}
			}
			if membership.PartitionID >= uint32(len(anchorForPack)) {
				return fmt.Errorf("%w: membership partition", ErrVectorPartitionSearchUnavailable)
			}
			k := vectorPartitionServingMembershipKeyV1{ordinal: membership.VectorOrdinal, anchor: anchorForPack[membership.PartitionID]}
			if prior, ok := kinds[k]; !ok || kind == VectorPartitionMembershipHomeV1 || prior != VectorPartitionMembershipHomeV1 {
				kinds[k] = kind
			}
		}
		return nil
	}
	if err := add(manifest.Memberships, VectorPartitionMembershipHomeV1); err != nil {
		return nil, err
	}
	if err := add(manifest.OverlapMemberships, VectorPartitionMembershipOverlapV1); err != nil {
		return nil, err
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return kinds, nil
}

func vectorPartitionServingMembershipListsV1(manifest VectorPartitionManifestV1, anchorForPack []uint32) ([]VectorPartitionMembershipV1, []VectorPartitionMembershipV1, error) {
	kinds, err := vectorPartitionServingMembershipKindsV1(context.Background(), manifest, anchorForPack)
	if err != nil {
		return nil, nil, err
	}
	home := make([]VectorPartitionMembershipV1, 0, len(manifest.Memberships))
	overlap := make([]VectorPartitionMembershipV1, 0, len(manifest.OverlapMemberships))
	for k, kind := range kinds {
		membership := VectorPartitionMembershipV1{VectorOrdinal: k.ordinal, PartitionID: k.anchor}
		if kind == VectorPartitionMembershipHomeV1 {
			home = append(home, membership)
		} else {
			overlap = append(overlap, membership)
		}
	}
	sort.Slice(home, func(i, j int) bool { return vectorPartitionMembershipLessV1(home[i], home[j]) })
	sort.Slice(overlap, func(i, j int) bool { return vectorPartitionMembershipLessV1(overlap[i], overlap[j]) })
	return home, overlap, nil
}

// VectorPartitionDomainGraphRowCountsV1 returns the exact serving-row counts
// produced by domain-graph membership normalization, keyed by domain anchor.
func VectorPartitionDomainGraphRowCountsV1(ctx context.Context, manifest VectorPartitionManifestV1) ([]uint64, error) {
	_, anchorForPack, err := vectorPartitionDomainLayoutV1(manifest)
	if err != nil {
		return nil, err
	}
	kinds, err := vectorPartitionServingMembershipKindsV1(ctx, manifest, anchorForPack)
	if err != nil {
		return nil, err
	}
	rows := make([]uint64, manifest.PartitionCount)
	for key := range kinds {
		if rows[key.anchor] == math.MaxUint64 {
			return nil, fmt.Errorf("%w: membership rows", ErrVectorPartitionSearchUnavailable)
		}
		rows[key.anchor]++
	}
	return rows, nil
}

type vectorPartitionDomainAssetPayloadV1 struct {
	id                 string
	payload            []byte
	membershipDigest   string
	graphVariant       string
	partition          uint32
	constructionSource int
}

func splitVectorPartitionDomainSearchPackV1(raw []byte, partition uint32, maxAssetBytes int64) ([]vectorPartitionDomainAssetPayloadV1, error) {
	return splitVectorPartitionDomainSearchPackBinding(raw, partition, maxAssetBytes, columnHNSWSearchPackDecodeOptions{})
}

func splitVectorPartitionDomainSearchPackBinding(raw []byte, partition uint32, maxAssetBytes int64, opts columnHNSWSearchPackDecodeOptions) ([]vectorPartitionDomainAssetPayloadV1, error) {
	if maxAssetBytes <= 0 {
		return nil, fmt.Errorf("%w: domain asset byte cap", ErrVectorPartitionSearchUnavailable)
	}
	pack, _, err := decodeColumnHNSWSearchPackEnvelopeWithContext(context.Background(), raw, opts)
	wantVersion := columnHNSWSearchPackVersionV6
	if opts.SourceV2 {
		wantVersion = columnHNSWSearchPackVersionV7
	}
	if err != nil || pack.Header.Version != wantVersion {
		return nil, fmt.Errorf("%w: domain Vamana pack", ErrVectorPartitionSearchUnavailable)
	}
	rootBytes := columnHNSWSearchPackHeaderSizeV2 + len(pack.Sections)*columnHNSWSearchPackSectionEntrySize
	if rootBytes > len(raw) || int64(rootBytes) > maxAssetBytes {
		return nil, fmt.Errorf("%w: domain root byte cap", ErrVectorPartitionSearchUnavailable)
	}
	digest := hex.EncodeToString(raw[columnHNSWSearchPackHeaderMembershipDigestOffset:columnHNSWSearchPackHeaderSizeV2])
	out := []vectorPartitionDomainAssetPayloadV1{{
		id: vectorPartitionLocalAssetIDV1(partition), payload: raw[:rootBytes], membershipDigest: digest,
		graphVariant: string(vectorPartitionLocalDefaultGraphVariantV1), partition: partition,
	}}
	for _, section := range pack.Sections {
		if section.Offset > uint64(len(raw)) || section.Length > uint64(len(raw))-section.Offset {
			return nil, fmt.Errorf("%w: domain section bounds", ErrVectorPartitionSearchUnavailable)
		}
		ranges, err := vectorPartitionDomainSectionChunkRangesV1(raw, pack, section, uint64(maxAssetBytes))
		if err != nil {
			return nil, err
		}
		key := columnHNSWSearchPackSectionKey{kind: section.Kind, index: section.Index}
		for chunk, bounds := range ranges {
			start, end := section.Offset+bounds[0], section.Offset+bounds[1]
			out = append(out, vectorPartitionDomainAssetPayloadV1{
				id:      vectorPartitionLocalSectionChunkAssetIDV1(partition, key, uint32(chunk)),
				payload: raw[start:end], partition: partition,
			})
		}
	}
	return out, nil
}

func vectorPartitionDomainSectionChunkRangesV1(raw []byte, pack columnHNSWSearchPack, section columnHNSWSearchPackSection, capBytes uint64) ([][2]uint64, error) {
	if section.Length == 0 {
		return nil, nil
	}
	unit := uint64(0)
	var boundaries []uint64
	switch section.Kind {
	case columnHNSWSearchPackSectionNormalizedVectors:
		unit = uint64(pack.Header.VectorStride) * 4
	case columnHNSWSearchPackSectionLevels:
		unit = 2
	case columnHNSWSearchPackSectionAdjacencyOffsets,
		columnHNSWSearchPackSectionRowRefGeneration,
		columnHNSWSearchPackSectionRowRefPartID,
		columnHNSWSearchPackSectionRowRefRowIndex,
		columnHNSWSearchPackSectionRowRefAppliedLSN,
		columnHNSWSearchPackSectionDocumentIDOffsets:
		unit = 8
	case columnHNSWSearchPackSectionAdjacencyNeighbors:
		offsetsSection, err := columnHNSWSearchPackFindSection(pack.Sections, columnHNSWSearchPackSectionAdjacencyOffsets, section.Index)
		if err != nil {
			return nil, fmt.Errorf("%w: adjacency section index", ErrVectorPartitionSearchUnavailable)
		}
		offsets := decodeUint64SliceLE(raw[offsetsSection.Offset : offsetsSection.Offset+offsetsSection.Length])
		boundaries = make([]uint64, len(offsets))
		for i, offset := range offsets {
			boundaries[i] = offset * 4
		}
	case columnHNSWSearchPackSectionDocumentIDBytes:
		offsetsSection, err := columnHNSWSearchPackFindSection(pack.Sections, columnHNSWSearchPackSectionDocumentIDOffsets, 0)
		if err != nil {
			return nil, fmt.Errorf("%w: document id offsets", ErrVectorPartitionSearchUnavailable)
		}
		boundaries = decodeUint64SliceLE(raw[offsetsSection.Offset : offsetsSection.Offset+offsetsSection.Length])
	default:
		return nil, fmt.Errorf("%w: unsupported domain section %s", ErrVectorPartitionSearchUnavailable, section.Kind)
	}
	if unit != 0 {
		if unit > capBytes || section.Length%unit != 0 {
			return nil, fmt.Errorf("%w: indivisible domain section %s", ErrVectorPartitionSearchUnavailable, section.Kind)
		}
		chunkBytes := capBytes / unit * unit
		out := make([][2]uint64, 0, (section.Length+chunkBytes-1)/chunkBytes)
		for start := uint64(0); start < section.Length; start += chunkBytes {
			end := min(start+chunkBytes, section.Length)
			out = append(out, [2]uint64{start, end})
		}
		return out, nil
	}
	if len(boundaries) == 0 || boundaries[0] != 0 || boundaries[len(boundaries)-1] != section.Length {
		return nil, fmt.Errorf("%w: domain section boundaries %s", ErrVectorPartitionSearchUnavailable, section.Kind)
	}
	out := make([][2]uint64, 0, (section.Length+capBytes-1)/capBytes)
	for startIndex := 0; startIndex < len(boundaries)-1; {
		start := boundaries[startIndex]
		limit := min(start+capBytes, section.Length)
		endIndex := sort.Search(len(boundaries), func(i int) bool { return boundaries[i] > limit }) - 1
		for endIndex > startIndex && boundaries[endIndex] == start {
			endIndex--
		}
		if endIndex <= startIndex {
			return nil, fmt.Errorf("%w: indivisible domain section %s record=%d", ErrVectorPartitionSearchUnavailable, section.Kind, startIndex)
		}
		out = append(out, [2]uint64{start, boundaries[endIndex]})
		startIndex = endIndex
	}
	return out, nil
}

func vectorPartitionMembershipsForPartitionV1(manifest VectorPartitionManifestV1, partition uint32) []vectorPartitionMembershipSourceV1 {
	members, _ := vectorPartitionMembershipsForPartitionWithContextV1(context.Background(), manifest, partition)
	return members
}

func vectorPartitionMembershipsForPartitionWithContextV1(ctx context.Context, manifest VectorPartitionManifestV1, partition uint32) ([]vectorPartitionMembershipSourceV1, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	count := 0
	for i, membership := range manifest.Memberships {
		if i&1023 == 0 {
			if err := ctx.Err(); err != nil {
				return nil, err
			}
		}
		if membership.PartitionID == partition {
			count++
		}
	}
	for i, membership := range manifest.OverlapMemberships {
		if i&1023 == 0 {
			if err := ctx.Err(); err != nil {
				return nil, err
			}
		}
		if membership.PartitionID == partition {
			count++
		}
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	members := make([]vectorPartitionMembershipSourceV1, 0, count)
	for i, membership := range manifest.Memberships {
		if i&1023 == 0 {
			if err := ctx.Err(); err != nil {
				return nil, err
			}
		}
		if membership.PartitionID == partition {
			members = append(members, vectorPartitionMembershipSourceV1{ordinal: int(membership.VectorOrdinal), kind: VectorPartitionMembershipHomeV1})
		}
	}
	for i, membership := range manifest.OverlapMemberships {
		if i&1023 == 0 {
			if err := ctx.Err(); err != nil {
				return nil, err
			}
		}
		if membership.PartitionID == partition {
			members = append(members, vectorPartitionMembershipSourceV1{ordinal: int(membership.VectorOrdinal), kind: VectorPartitionMembershipOverlapV1})
		}
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	sort.Slice(members, func(i, j int) bool {
		return members[i].ordinal < members[j].ordinal || members[i].ordinal == members[j].ordinal && members[i].kind < members[j].kind
	})
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return members, nil
}

// VectorPartitionGenerationSearchOpenPlanV1 is an immutable, generation-wide
// cold-open plan. Routed serving builds it once from the manifest already
// validated by the active-generation authority, then reuses its partition
// asset lookup and membership index for every cold partition open.
type VectorPartitionGenerationSearchOpenPlanV1 struct {
	collection            string
	indexName             string
	indexDefinitionDigest string
	sourceGeneration      uint64
	sourceChecksum        uint64
	sourceSchemaHash      uint64
	sourceRowCount        uint64
	generation            uint64
	partitionCount        uint32
	assets                []VectorPartitionAssetV1
	assetGroups           [][]VectorPartitionAssetV1
	assetPresent          []bool
	members               []vectorPartitionMembershipSourceV1
	memberOffsets         []int
	homeCounts            []int
	overlapCounts         []int
	liveRecovery          bool
}

// NewVectorPartitionGenerationSearchOpenPlanWithContextV1 indexes a validated
// generation manifest once for bounded per-partition lookup. The returned plan
// does not retain or expose the caller's manifest slices.
func NewVectorPartitionGenerationSearchOpenPlanWithContextV1(ctx context.Context, manifest VectorPartitionManifestV1) (*VectorPartitionGenerationSearchOpenPlanV1, error) {
	if err := manifest.requireInlineRuntimeV1(); err != nil {
		return nil, err
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if manifest.Collection == "" || manifest.IndexName == "" || manifest.IndexDefinitionDigest == "" || manifest.Generation == 0 || manifest.PartitionCount == 0 {
		return nil, fmt.Errorf("%w: incomplete generation search-open plan", ErrVectorPartitionSearchUnavailable)
	}
	limits := DefaultVectorPartitionManifestLimits()
	if uint64(manifest.PartitionCount) > uint64(limits.MaxPartitions) ||
		len(manifest.Memberships) > limits.totalMembershipLimit() ||
		len(manifest.OverlapMemberships) > limits.totalMembershipLimit()-min(len(manifest.Memberships), limits.totalMembershipLimit()) {
		return nil, fmt.Errorf("%w: generation search-open plan exceeds manifest limits", ErrVectorPartitionSearchUnavailable)
	}
	partitionCount := int(manifest.PartitionCount)
	plan := &VectorPartitionGenerationSearchOpenPlanV1{
		collection:            manifest.Collection,
		indexName:             manifest.IndexName,
		indexDefinitionDigest: manifest.IndexDefinitionDigest,
		sourceGeneration:      manifest.SourceGeneration,
		sourceChecksum:        manifest.SourceChecksum,
		sourceSchemaHash:      manifest.SourceSchemaHash,
		sourceRowCount:        manifest.SourceRowCount,
		generation:            manifest.Generation,
		partitionCount:        manifest.PartitionCount,
		assets:                make([]VectorPartitionAssetV1, partitionCount),
		assetGroups:           make([][]VectorPartitionAssetV1, partitionCount),
		assetPresent:          make([]bool, partitionCount),
		memberOffsets:         make([]int, partitionCount+1),
		homeCounts:            make([]int, partitionCount),
		overlapCounts:         make([]int, partitionCount),
	}
	domainMode := false
	for _, asset := range manifest.Assets {
		if strings.HasPrefix(asset.ID, vectorPartitionLocalAssetIDV1(asset.PartitionID)+"/section/") {
			domainMode = true
			break
		}
	}
	homeMemberships, overlapMemberships := manifest.Memberships, manifest.OverlapMemberships
	if domainMode {
		_, anchorForPack, err := vectorPartitionDomainLayoutV1(manifest)
		if err != nil {
			return nil, err
		}
		homeMemberships, overlapMemberships, err = vectorPartitionServingMembershipListsV1(manifest, anchorForPack)
		if err != nil {
			return nil, err
		}
	}
	for i, asset := range manifest.Assets {
		if i&1023 == 0 {
			if err := ctx.Err(); err != nil {
				return nil, err
			}
		}
		if asset.PartitionID >= manifest.PartitionCount {
			continue
		}
		partition := int(asset.PartitionID)
		if asset.ID == vectorPartitionLocalAssetIDV1(asset.PartitionID) || strings.HasPrefix(asset.ID, vectorPartitionLocalAssetIDV1(asset.PartitionID)+"/section/") {
			plan.assetGroups[partition] = append(plan.assetGroups[partition], asset)
		}
		if asset.ID != vectorPartitionLocalAssetIDV1(asset.PartitionID) {
			continue
		}
		if plan.assetPresent[partition] {
			return nil, fmt.Errorf("%w: duplicate partition search asset %d", ErrVectorPartitionSearchUnavailable, asset.PartitionID)
		}
		plan.assets[partition] = asset
		plan.assetPresent[partition] = true
	}
	countMembership := func(memberships []VectorPartitionMembershipV1, counts []int) error {
		for i, membership := range memberships {
			if i&1023 == 0 {
				if err := ctx.Err(); err != nil {
					return err
				}
			}
			if membership.PartitionID >= manifest.PartitionCount {
				return fmt.Errorf("%w: membership partition %d out of range", ErrVectorPartitionSearchUnavailable, membership.PartitionID)
			}
			counts[membership.PartitionID]++
		}
		return nil
	}
	if err := countMembership(homeMemberships, plan.homeCounts); err != nil {
		return nil, err
	}
	if err := countMembership(overlapMemberships, plan.overlapCounts); err != nil {
		return nil, err
	}
	for partition := 0; partition < partitionCount; partition++ {
		count := plan.homeCounts[partition] + plan.overlapCounts[partition]
		if count < plan.homeCounts[partition] {
			return nil, fmt.Errorf("%w: membership count overflow", ErrVectorPartitionSearchUnavailable)
		}
		plan.memberOffsets[partition+1] = plan.memberOffsets[partition] + count
		if plan.memberOffsets[partition+1] < plan.memberOffsets[partition] {
			return nil, fmt.Errorf("%w: membership offset overflow", ErrVectorPartitionSearchUnavailable)
		}
	}
	plan.members = make([]vectorPartitionMembershipSourceV1, plan.memberOffsets[partitionCount])
	next := append([]int(nil), plan.memberOffsets[:partitionCount]...)
	if err := appendVectorPartitionMembershipsToPlanV1(ctx, plan, homeMemberships, VectorPartitionMembershipHomeV1, next); err != nil {
		return nil, err
	}
	if err := appendVectorPartitionMembershipsToPlanV1(ctx, plan, overlapMemberships, VectorPartitionMembershipOverlapV1, next); err != nil {
		return nil, err
	}
	// The digest verifier makes and canonically sorts its own bounded copy.
	// Keeping the grouped home/overlap runs here avoids another generation-wide
	// sort during plan preparation.
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return plan, nil
}

// NewVectorPartitionGenerationLiveSearchOpenPlanWithContextV1 constructs the
// standalone serving plan that may reopen manifest-bound immutable packs after
// the mutable ColumnGraph source has advanced. Admission requires the exact
// durable live carrier to cover the current collection document generation;
// replicated and ordinary prepared opens never receive this authority.
func (c *Collection) NewVectorPartitionGenerationLiveSearchOpenPlanWithContextV1(ctx context.Context, manifest VectorPartitionManifestV1) (*VectorPartitionGenerationSearchOpenPlanV1, error) {
	if c == nil || manifest.Collection != c.name {
		return nil, ErrVectorPartitionSearchUnavailable
	}
	if err := manifest.validateWithContextV1(ctx, DefaultVectorPartitionManifestLimits()); err != nil {
		return nil, fmt.Errorf("%w: live recovery manifest: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	authoritative, token, err := c.ActiveVectorPartitionManifestAndAuthorityTokenWithContextV1(ctx, manifest.IndexName, manifest.Generation)
	if err != nil {
		return nil, fmt.Errorf("%w: live recovery manifest authority: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	token.Release()
	if authoritative.IntegrityDigest != manifest.IntegrityDigest {
		return nil, fmt.Errorf("%w: live recovery manifest identity", ErrVectorPartitionSearchUnavailable)
	}
	if err := c.validateCurrentVectorPartitionLiveBindingV1(ctx, manifest); err != nil {
		return nil, fmt.Errorf("%w: live recovery authority: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	plan, err := NewVectorPartitionGenerationSearchOpenPlanWithContextV1(ctx, authoritative)
	if err != nil {
		return nil, err
	}
	plan.liveRecovery = true
	return plan, nil
}

// NewPreparedVectorPartitionGenerationReplicatedLiveSearchOpenPlanWithContextV1
// constructs a live search plan for an exact locally prepared generation.
// Unlike the standalone recovery entrypoint above it deliberately does not
// consult ActiveGeneration: its caller must first validate replicated
// lifecycle authority and establish the manifest-bound durable live binding.
// Re-reading the prepared manifest and the current binding here makes a stale
// or mismatched caller fail closed before any partition asset is opened.
func (c *Collection) NewPreparedVectorPartitionGenerationReplicatedLiveSearchOpenPlanWithContextV1(ctx context.Context, manifest VectorPartitionManifestV1) (*VectorPartitionGenerationSearchOpenPlanV1, error) {
	return c.newPreparedVectorPartitionGenerationReplicatedLiveSearchOpenPlanV1(ctx, manifest, false)
}

// NewPreparedVectorPartitionGenerationReplicatedLiveStartupSearchOpenPlanWithContextV1
// validates startup after complete document/carrier mutation finalization. It must
// be called BEFORE ANY local vector or coordinator serving starts on this DB.
// The caller must not hold native admission or the root storage barrier. This is
// not a concurrent-serving API; serving callers use the ordinary method above.
func (c *Collection) NewPreparedVectorPartitionGenerationReplicatedLiveStartupSearchOpenPlanWithContextV1(ctx context.Context, manifest VectorPartitionManifestV1) (*VectorPartitionGenerationSearchOpenPlanV1, error) {
	return c.newPreparedVectorPartitionGenerationReplicatedLiveSearchOpenPlanV1(ctx, manifest, true)
}

func (c *Collection) newPreparedVectorPartitionGenerationReplicatedLiveSearchOpenPlanV1(ctx context.Context, manifest VectorPartitionManifestV1, startup bool) (*VectorPartitionGenerationSearchOpenPlanV1, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if c == nil || c.db == nil || manifest.Collection != c.name {
		return nil, ErrVectorPartitionSearchUnavailable
	}
	if err := manifest.validateWithContextV1(ctx, DefaultVectorPartitionManifestLimits()); err != nil {
		return nil, fmt.Errorf("%w: replicated live manifest: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	load := func() error {
		def, err := c.declaredVectorIndexDefinitionPrepared(manifest.IndexName)
		if err != nil || VectorIndexDefinitionDigestV1(def) != manifest.IndexDefinitionDigest {
			return fmt.Errorf("%w: replicated live index definition: %v", ErrVectorPartitionSearchUnavailable, err)
		}
		// Restore only the already-persisted carrier; never rebuild or publish
		// a replacement binding. Warm loads also inspect document authority.
		unlockLoad := c.lockNativeVectorIndexLoad()
		carrier, loadStatus, loadErr := c.loadVectorPartitionLiveIndexForServingV1(def)
		unlockLoad()
		if loadErr != nil || carrier == nil || !loadStatus.Loaded || !carrier.isPartitionLiveCarrier() {
			return fmt.Errorf("%w: replicated durable live carrier: status=%+v err=%v", ErrVectorPartitionSearchUnavailable, loadStatus, loadErr)
		}
		return nil
	}
	var plan *VectorPartitionGenerationSearchOpenPlanV1
	prove := func() error {
		prepared, err := c.preparedVectorPartitionManifestUnderStorageBarrierV1(ctx, manifest.IndexName, manifest.Generation, true)
		if err != nil {
			return fmt.Errorf("%w: replicated prepared manifest: %v", ErrVectorPartitionSearchUnavailable, err)
		}
		if prepared.IntegrityDigest != manifest.IntegrityDigest {
			return fmt.Errorf("%w: replicated prepared manifest identity", ErrVectorPartitionSearchUnavailable)
		}
		if err := c.validateCurrentVectorPartitionLiveBindingV1(ctx, manifest); err != nil {
			return fmt.Errorf("%w: replicated live authority: %v", ErrVectorPartitionSearchUnavailable, err)
		}
		plan, err = NewVectorPartitionGenerationSearchOpenPlanWithContextV1(ctx, prepared)
		return err
	}
	var err error
	if startup {
		err = WithVectorPartitionStorageBarrierV1(c.db.Dir(), func() error {
			// Native admission spans accepted roots, carrier publication and the
			// notification/finalization tail. Acquire it before even a warm load.
			unlock := c.lockNativeVectorAdmissionWrite()
			defer unlock()
			if err := load(); err != nil {
				return err
			}
			return prove()
		})
	} else {
		if err := load(); err != nil {
			return nil, err
		}
		err = WithVectorPartitionStorageBarrierV1(c.db.Dir(), prove)
	}
	if err != nil {
		return nil, err
	}
	plan.liveRecovery = true
	return plan, nil
}

func appendVectorPartitionMembershipsToPlanV1(
	ctx context.Context,
	plan *VectorPartitionGenerationSearchOpenPlanV1,
	memberships []VectorPartitionMembershipV1,
	kind VectorPartitionMembershipKindV1,
	next []int,
) error {
	partitionCount := int(plan.partitionCount)
	for i, membership := range memberships {
		if i&1023 == 0 {
			if err := ctx.Err(); err != nil {
				return err
			}
		}
		partition := int(membership.PartitionID)
		if partition < 0 || partition >= partitionCount || partition+1 >= len(plan.memberOffsets) || partition >= len(next) {
			return fmt.Errorf("%w: membership partition %d out of range", ErrVectorPartitionSearchUnavailable, membership.PartitionID)
		}
		offset := next[partition]
		if offset < plan.memberOffsets[partition] || offset >= plan.memberOffsets[partition+1] || offset >= len(plan.members) {
			return fmt.Errorf("%w: membership index changed during plan preparation", ErrVectorPartitionSearchUnavailable)
		}
		plan.members[offset] = vectorPartitionMembershipSourceV1{ordinal: int(membership.VectorOrdinal), kind: kind}
		next[partition]++
	}
	return nil
}

func (p *VectorPartitionGenerationSearchOpenPlanV1) partition(partition uint32) (*VectorPartitionAssetV1, []vectorPartitionMembershipSourceV1, int, int, error) {
	if p == nil || partition >= p.partitionCount || int(partition)+1 >= len(p.memberOffsets) || int(partition) >= len(p.assets) || !p.assetPresent[partition] {
		return nil, nil, 0, 0, fmt.Errorf("%w: missing or stale partition asset", ErrVectorPartitionSearchUnavailable)
	}
	i := int(partition)
	return &p.assets[i], p.members[p.memberOffsets[i]:p.memberOffsets[i+1]], p.homeCounts[i], p.overlapCounts[i], nil
}

func (p *VectorPartitionGenerationSearchOpenPlanV1) partitionAssets(partition uint32) []VectorPartitionAssetV1 {
	if p == nil || partition >= p.partitionCount || int(partition) >= len(p.assetGroups) {
		return nil
	}
	return p.assetGroups[partition]
}

func vectorPartitionMembershipDigestV1(reader *columnVectorGraphPhysicalRowReader, generation uint64, partition uint32, members []vectorPartitionMembershipSourceV1) ([sha256.Size]byte, error) {
	return vectorPartitionMembershipDigestWithContextV1(context.Background(), reader, generation, partition, members)
}

func vectorPartitionMembershipDigestWithContextV1(ctx context.Context, reader *columnVectorGraphPhysicalRowReader, generation uint64, partition uint32, members []vectorPartitionMembershipSourceV1) ([sha256.Size]byte, error) {
	var zero [sha256.Size]byte
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		return zero, err
	}
	if reader == nil || generation == 0 || len(members) == 0 {
		return zero, fmt.Errorf("%w: membership digest input", ErrVectorPartitionSearchUnavailable)
	}
	if err := ctx.Err(); err != nil {
		return zero, err
	}
	canonical := make([]vectorPartitionMembershipSourceV1, len(members))
	for offset := 0; offset < len(members); offset += 1024 {
		if err := ctx.Err(); err != nil {
			return zero, err
		}
		end := min(offset+1024, len(members))
		copy(canonical[offset:end], members[offset:end])
	}
	if err := ctx.Err(); err != nil {
		return zero, err
	}
	sort.Slice(canonical, func(i, j int) bool {
		return canonical[i].ordinal < canonical[j].ordinal || canonical[i].ordinal == canonical[j].ordinal && canonical[i].kind < canonical[j].kind
	})
	if err := ctx.Err(); err != nil {
		return zero, err
	}
	h := sha256.New()
	h.Write([]byte("treedb/vector-partition-membership/v1"))
	var encoded [8]byte
	binary.BigEndian.PutUint64(encoded[:], generation)
	h.Write(encoded[:])
	binary.BigEndian.PutUint32(encoded[:4], partition)
	h.Write(encoded[:4])
	binary.BigEndian.PutUint64(encoded[:], uint64(len(canonical)))
	h.Write(encoded[:])
	lastOrdinal := -1
	for i, member := range canonical {
		if i&1023 == 0 {
			if err := ctx.Err(); err != nil {
				return zero, err
			}
		}
		if member.ordinal < 0 || member.ordinal == lastOrdinal {
			return zero, fmt.Errorf("%w: duplicate membership ordinal", ErrVectorPartitionSearchUnavailable)
		}
		if member.kind != VectorPartitionMembershipHomeV1 && member.kind != VectorPartitionMembershipOverlapV1 {
			return zero, fmt.Errorf("%w: membership kind", ErrVectorPartitionSearchUnavailable)
		}
		id, ok := reader.documentIDForOrdinal(member.ordinal)
		if !ok || len(id) == 0 {
			return zero, fmt.Errorf("%w: authoritative stable ID", ErrVectorPartitionSearchUnavailable)
		}
		binary.BigEndian.PutUint64(encoded[:], uint64(member.ordinal))
		h.Write(encoded[:])
		binary.BigEndian.PutUint32(encoded[:4], uint32(len(id)))
		h.Write(encoded[:4])
		h.Write(id)
		kindByte := byte(1)
		if member.kind == VectorPartitionMembershipOverlapV1 {
			kindByte = 2
		}
		h.Write([]byte{kindByte})
		lastOrdinal = member.ordinal
	}
	if err := ctx.Err(); err != nil {
		return zero, err
	}
	var digest [sha256.Size]byte
	copy(digest[:], h.Sum(nil))
	return digest, nil
}

func decodeVectorPartitionMembershipDigestV1(raw string) ([sha256.Size]byte, error) {
	var digest [sha256.Size]byte
	decoded, err := hex.DecodeString(raw)
	if err != nil || len(decoded) != sha256.Size || raw != strings.ToLower(raw) {
		return digest, fmt.Errorf("%w: membership digest", ErrVectorPartitionSearchUnavailable)
	}
	copy(digest[:], decoded)
	return digest, nil
}

func (c *Collection) validateVectorPartitionAssetMembershipBindingsV1(manifest VectorPartitionManifestV1) error {
	return c.validateVectorPartitionAssetMembershipBindingsForGraphVariantV1(manifest, vectorPartitionLocalDefaultGraphVariantV1)
}

func (c *Collection) validateVectorPartitionAssetMembershipBindingsForGraphVariantV1(manifest VectorPartitionManifestV1, expectedGraphVariant VectorPartitionLocalGraphVariantV1) error {
	if err := manifest.requireInlineRuntimeV1(); err != nil {
		return err
	}
	hasNative := false
	chunkedDomains := false
	for _, asset := range manifest.Assets {
		if asset.ID == vectorPartitionLocalAssetIDV1(asset.PartitionID) {
			hasNative = true
		}
		if strings.HasPrefix(asset.ID, vectorPartitionLocalAssetIDV1(asset.PartitionID)+"/section/") {
			chunkedDomains = true
		}
	}
	if !hasNative {
		return nil
	}
	def, ok := findVectorIndex(c.meta.VectorIndexes, manifest.IndexName)
	if !ok {
		return ErrVectorPartitionSearchUnavailable
	}
	reader, err := c.openColumnVectorGraphPhysicalRowReader(manifest.IndexName, columnVectorGraphPhysicalRowReaderOptions{})
	if err != nil {
		return fmt.Errorf("%w: membership source reader: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	defer reader.Close()
	var plan *VectorPartitionGenerationSearchOpenPlanV1
	if chunkedDomains {
		plan, err = NewVectorPartitionGenerationSearchOpenPlanWithContextV1(context.Background(), manifest)
		if err != nil {
			return err
		}
	}
	for _, asset := range manifest.Assets {
		if asset.ID != vectorPartitionLocalAssetIDV1(asset.PartitionID) {
			continue
		}
		got, err := decodeVectorPartitionMembershipDigestV1(asset.MembershipDigest)
		if err != nil {
			return err
		}
		members := vectorPartitionMembershipsForPartitionV1(manifest, asset.PartitionID)
		if plan != nil {
			_, members, _, _, err = plan.partition(asset.PartitionID)
			if err != nil {
				return err
			}
		}
		want, err := vectorPartitionMembershipDigestV1(reader, manifest.Generation, asset.PartitionID, members)
		if err != nil {
			return err
		}
		variant := VectorPartitionLocalGraphVariantV1(asset.GraphVariant)
		if _, identityErr := VectorPartitionLocalGraphVariantIdentityV1(variant); identityErr != nil || vectorPartitionLocalGraphVariantMembershipDigestV1(want, variant) != got {
			return fmt.Errorf("%w: descriptor membership digest mismatch partition=%d", ErrVectorPartitionSearchUnavailable, asset.PartitionID)
		}
		if variant != expectedGraphVariant {
			return fmt.Errorf("%w: graph variant=%s want=%s", ErrVectorPartitionSearchUnavailable, variant, expectedGraphVariant)
		}
		if asset.Ref.Kind != ColumnAssetKindTCS1HNSWSearchPack || asset.Ref.Length <= 0 || asset.Ref.Length > vectorPartitionSearchAssetMaxBytesV1 {
			return fmt.Errorf("%w: native membership asset ref partition=%d", ErrVectorPartitionSearchUnavailable, asset.PartitionID)
		}
		if plan != nil {
			home, overlap := 0, 0
			for _, member := range members {
				if member.kind == VectorPartitionMembershipHomeV1 {
					home++
				} else {
					overlap++
				}
			}
			searcher, openErr := c.openVectorPartitionLocalSearcherForPreparedAssetsWithContextV1(context.Background(), manifest.IndexName, manifest.Generation, asset.PartitionID, manifest.IndexDefinitionDigest, manifest.SourceGeneration, manifest.SourceChecksum, manifest.SourceSchemaHash, manifest.SourceRowCount, &asset, plan.partitionAssets(asset.PartitionID), members, home, overlap, true, variant, false, false)
			if openErr != nil {
				return openErr
			}
			if closeErr := searcher.Close(); closeErr != nil {
				return closeErr
			}
			continue
		}
		raw, err := readColumnPhysicalAssetFromManager(c.db.ColumnAssetRootDir(), asset.Ref)
		if err != nil {
			return fmt.Errorf("%w: native membership asset partition=%d: %v", ErrVectorPartitionSearchUnavailable, asset.PartitionID, err)
		}
		pack, _, err := decodeColumnHNSWSearchPackEnvelope(raw, columnHNSWSearchPackDecodeOptions{
			ExpectedBaseIdentity: columnHNSWSearchPackBaseIdentity{
				ManifestGeneration: manifest.SourceGeneration,
				ManifestChecksum:   manifest.SourceChecksum,
				SchemaHash:         manifest.SourceSchemaHash,
			},
			ExpectedMembershipDigest: got,
		})
		packDef, expectAuxiliary, definitionErr := vectorPartitionLocalGraphVariantDefinitionV1(def, variant)
		packVersion := columnHNSWSearchPackVersionV2
		if expectAuxiliary {
			packVersion = columnHNSWSearchPackVersionV3
		} else if variant == VectorPartitionLocalGraphVariantConnectivityPreservingVamanaR64L256Alpha1_2V1 {
			packVersion = columnHNSWSearchPackVersionV6
		} else if variant == VectorPartitionLocalGraphVariantCanonicalHNSWM18EfConstruction256V1 {
			packVersion = columnHNSWSearchPackVersionV5
		}
		if err != nil || definitionErr != nil || pack.Header.Version != packVersion || pack.Header.MembershipDigest != got || pack.Header.HasAuxiliaryNavigation != expectAuxiliary || pack.Header.M != packDef.M || pack.Header.EfConstruction != packDef.EfConstruction || pack.Header.EfSearch != packDef.EfSearch {
			return fmt.Errorf("%w: native membership header partition=%d: %v", ErrVectorPartitionSearchUnavailable, asset.PartitionID, err)
		}
	}
	return nil
}

// MaterializeVectorPartitionLocalSearchAssetsV1 uses the canonical native HNSW
// production profile with the authoritative M1 column-asset definition.
// Callers install the returned descriptors in the generation M1 manifest;
// publication then validates the exact ref, size, CRC and SHA-256.
func (c *Collection) MaterializeVectorPartitionLocalSearchAssetsV1(index string, manifest VectorPartitionManifestV1, fileID uint32, inputs []VectorPartitionSearchAssetV1) ([]VectorPartitionAssetV1, *rootpublication.StableResourceSet, error) {
	return c.materializeVectorPartitionLocalSearchAssetsVariantV1(index, manifest, fileID, inputs, vectorPartitionSearchAssetMaxBytesV1, vectorPartitionLocalDefaultGraphVariantV1, nil, false, nil)
}

// MaterializeVectorPartitionOwnerSeparatedLocalSearchAssetsV1 builds against
// the complete authoritative source but puts each owner's whole domains in
// that owner's reserved segment. It does not publish an owner-local manifest;
// callers still validate and publish the one global generation identity.
func (c *Collection) MaterializeVectorPartitionOwnerSeparatedLocalSearchAssetsV1(index string, manifest VectorPartitionManifestV1, ownerFileIDs map[string]uint32, inputs []VectorPartitionSearchAssetV1) ([]VectorPartitionAssetV1, *rootpublication.StableResourceSet, error) {
	return c.materializeVectorPartitionLocalSearchAssetsVariantV1(index, manifest, 0, inputs, vectorPartitionSearchAssetMaxBytesV1, vectorPartitionLocalDefaultGraphVariantV1, nil, false, ownerFileIDs)
}

// MaterializeVectorPartitionLocalSearchAssetsVariantV1 constructs explicit
// graph variants. Every noncanonical variant remains offline-only.
func (c *Collection) MaterializeVectorPartitionLocalSearchAssetsVariantV1(index string, manifest VectorPartitionManifestV1, fileID uint32, inputs []VectorPartitionSearchAssetV1, variant VectorPartitionLocalGraphVariantV1) ([]VectorPartitionAssetV1, *rootpublication.StableResourceSet, error) {
	return c.materializeVectorPartitionLocalSearchAssetsVariantV1(index, manifest, fileID, inputs, vectorPartitionSearchAssetMaxBytesV1, variant, nil, false, nil)
}

// MaterializeVectorPartitionLocalSearchAssetsWithConstructionEvidenceV1 is an
// offline diagnostic sibling of the normal materializer. Pack bytes are
// identical; only the temporary builder receives the nullable trace sink.
func (c *Collection) MaterializeVectorPartitionLocalSearchAssetsWithConstructionEvidenceV1(index string, manifest VectorPartitionManifestV1, fileID uint32, inputs []VectorPartitionSearchAssetV1, variant VectorPartitionLocalGraphVariantV1) ([]VectorPartitionAssetV1, *rootpublication.StableResourceSet, VectorPartitionConstructionEvidenceV1, error) {
	evidence := VectorPartitionConstructionEvidenceV1{Schema: VectorPartitionConstructionEvidenceSchemaV1, Variant: string(variant), ManifestChecksum: manifest.IntegrityDigest, IndexDefinitionDigest: manifest.IndexDefinitionDigest}
	assets, resources, err := c.materializeVectorPartitionLocalSearchAssetsVariantV1(index, manifest, fileID, inputs, vectorPartitionSearchAssetMaxBytesV1, variant, &evidence, false, nil)
	return assets, resources, evidence, err
}

// MaterializeVectorPartitionLocalSearchAssetsWithBoundedConstructionEvidenceV1
// is the #4171 offline campaign entrypoint. Only its predeclared M18 packs
// retain detailed lifecycle events; all other packs retain count-only history
// and a live final-origin map. Search-pack bytes are unchanged.
func (c *Collection) MaterializeVectorPartitionLocalSearchAssetsWithBoundedConstructionEvidenceV1(index string, manifest VectorPartitionManifestV1, fileID uint32, inputs []VectorPartitionSearchAssetV1, variant VectorPartitionLocalGraphVariantV1) ([]VectorPartitionAssetV1, *rootpublication.StableResourceSet, VectorPartitionConstructionEvidenceV1, error) {
	evidence := VectorPartitionConstructionEvidenceV1{Schema: VectorPartitionConstructionEvidenceSchemaV1, Variant: string(variant), ManifestChecksum: manifest.IntegrityDigest, IndexDefinitionDigest: manifest.IndexDefinitionDigest}
	assets, resources, err := c.materializeVectorPartitionLocalSearchAssetsVariantV1(index, manifest, fileID, inputs, vectorPartitionSearchAssetMaxBytesV1, variant, &evidence, true, nil)
	return assets, resources, evidence, err
}

// ValidateVectorPartitionLocalConstructionEvidenceV1 fail-closes unless the
// trace binds the supplied immutable assets and its final survivors are their
// exact native packed adjacency.
func (c *Collection) ValidateVectorPartitionLocalConstructionEvidenceV1(ctx context.Context, index string, manifest VectorPartitionManifestV1, assets []VectorPartitionAssetV1, evidence VectorPartitionConstructionEvidenceV1) error {
	if c == nil || evidence.Schema != VectorPartitionConstructionEvidenceSchemaV1 || evidence.ManifestChecksum != manifest.IntegrityDigest || evidence.IndexDefinitionDigest != manifest.IndexDefinitionDigest || len(assets) == 0 || len(assets) != len(evidence.Partitions) {
		return fmt.Errorf("%w: construction evidence envelope assets=%d partitions=%d schema=%q", ErrVectorPartitionSearchUnavailable, len(assets), len(evidence.Partitions), evidence.Schema)
	}
	variant := VectorPartitionLocalGraphVariantV1(evidence.Variant)
	if _, err := VectorPartitionLocalGraphVariantIdentityV1(variant); err != nil {
		return fmt.Errorf("%w: construction evidence variant %q", ErrVectorPartitionSearchUnavailable, variant)
	}
	def, ok := findVectorIndex(c.meta.VectorIndexes, index)
	if !ok || manifest.IndexDefinitionDigest != VectorIndexDefinitionDigestV1(def) {
		return fmt.Errorf("%w: construction evidence index definition", ErrVectorPartitionSearchUnavailable)
	}
	buildDef, _, err := vectorPartitionLocalGraphVariantDefinitionV1(def, variant)
	if err != nil {
		return fmt.Errorf("%w: construction evidence variant definition: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	_, sourceGraph, _, err := c.columnVectorGraphPhysicalRowReaderSnapshotView(index)
	if err != nil || sourceGraph.BaseManifestGeneration != manifest.SourceGeneration || sourceGraph.BaseManifestChecksum != manifest.SourceChecksum || sourceGraph.BaseSchemaHash != manifest.SourceSchemaHash || uint64(sourceGraph.RowCount) != manifest.SourceRowCount {
		return fmt.Errorf("%w: construction evidence authoritative source", ErrVectorPartitionSearchUnavailable)
	}
	reader, err := c.openColumnVectorGraphPhysicalRowReader(index, columnVectorGraphPhysicalRowReaderOptions{})
	if err != nil {
		return fmt.Errorf("%w: construction evidence source reader: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	defer reader.Close()
	members := make(map[uint32][]vectorPartitionMembershipSourceV1)
	for _, membership := range manifest.Memberships {
		members[membership.PartitionID] = append(members[membership.PartitionID], vectorPartitionMembershipSourceV1{ordinal: int(membership.VectorOrdinal), kind: VectorPartitionMembershipHomeV1})
	}
	for _, membership := range manifest.OverlapMemberships {
		members[membership.PartitionID] = append(members[membership.PartitionID], vectorPartitionMembershipSourceV1{ordinal: int(membership.VectorOrdinal), kind: VectorPartitionMembershipOverlapV1})
	}
	seenPartitions := make(map[uint32]struct{}, len(assets))
	for i, asset := range assets {
		part := evidence.Partitions[i]
		if _, duplicate := seenPartitions[part.PartitionID]; duplicate || (i > 0 && evidence.Partitions[i-1].PartitionID >= part.PartitionID) {
			return fmt.Errorf("%w: construction evidence partition order index=%d partition=%d", ErrVectorPartitionSearchUnavailable, i, part.PartitionID)
		}
		seenPartitions[part.PartitionID] = struct{}{}
		if asset.PartitionID != part.PartitionID || asset.Checksum != part.AssetChecksum || asset.MembershipDigest != part.MembershipDigest || asset.Bytes != part.AssetBytes {
			return fmt.Errorf("%w: construction evidence asset binding index=%d partition=%d", ErrVectorPartitionSearchUnavailable, i, part.PartitionID)
		}
		searcher, err := c.OpenVectorPartitionLocalSearcherForOfflineAssetVariantWithContextV1(ctx, index, manifest, asset, variant)
		if err != nil {
			return fmt.Errorf("%w: construction evidence open partition=%d: %v", ErrVectorPartitionSearchUnavailable, part.PartitionID, err)
		}
		searcher.mu.Lock()
		pack := searcher.prepared
		searcher.mu.Unlock()
		if pack == nil {
			searcher.Close()
			return fmt.Errorf("%w: construction evidence missing pack partition=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID)
		}
		if part.PostfillEdges != 0 && variant != VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1 {
			searcher.Close()
			return fmt.Errorf("%w: construction evidence unexpected postfill partition=%d edges=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID, part.PostfillEdges)
		}
		if len(part.NativeInsertionOrdinals) != pack.Header.Rows {
			searcher.Close()
			return fmt.Errorf("%w: construction evidence insertion count partition=%d got=%d rows=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID, len(part.NativeInsertionOrdinals), pack.Header.Rows)
		}
		seenInsertion := make([]bool, pack.Header.Rows)
		for _, native := range part.NativeInsertionOrdinals {
			if native < 0 || native >= pack.Header.Rows || seenInsertion[native] {
				searcher.Close()
				return fmt.Errorf("%w: construction evidence insertion permutation partition=%d ordinal=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID, native)
			}
			seenInsertion[native] = true
		}
		live := make(map[vectorIndexConstructionEdgeKeyV1]string)
		selectionCounts := make(map[vectorIndexConstructionEdgeKeyV1][2]int)
		for _, selection := range part.Selections {
			if selection.Node < 0 || selection.Node >= pack.Header.Rows || selection.Layer < 0 || selection.Layer >= len(pack.AdjacencyLayers) || selection.Candidates < 0 || selection.Selected < 0 || selection.DiversitySelected < 0 || selection.BackfillSelected < 0 || selection.Selected != selection.DiversitySelected+selection.BackfillSelected || selection.Selected > selection.Candidates {
				searcher.Close()
				return fmt.Errorf("%w: construction selection invalid %+v", ErrVectorPartitionSearchUnavailable, selection)
			}
			if err := vectorPartitionConstructionValidateSelectionPolicyV1(selection, pack.Header.M, variant); err != nil {
				searcher.Close()
				return err
			}
			if selection.CandidateSampled {
				if selection.Layer != 0 || len(selection.CandidateOrdinals) != selection.Candidates || selection.CandidateDigest != vectorPartitionConstructionCandidateDigestV1(selection.CandidateOrdinals) {
					searcher.Close()
					return fmt.Errorf("%w: construction candidate sample node=%d candidates=%d ordinals=%d", ErrVectorPartitionSearchUnavailable, selection.Node, selection.Candidates, len(selection.CandidateOrdinals))
				}
				seenCandidates := make(map[int]struct{}, len(selection.CandidateOrdinals))
				for candidateIndex, candidate := range selection.CandidateOrdinals {
					if candidate < 0 || candidate >= pack.Header.Rows || candidate == selection.Node || candidateIndex > 0 && selection.CandidateOrdinals[candidateIndex-1] >= candidate {
						searcher.Close()
						return fmt.Errorf("%w: construction candidate ordinal node=%d candidate=%d index=%d", ErrVectorPartitionSearchUnavailable, selection.Node, candidate, candidateIndex)
					}
					if _, duplicate := seenCandidates[candidate]; duplicate {
						searcher.Close()
						return fmt.Errorf("%w: construction candidate duplicate partition=%d node=%d candidate=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID, selection.Node, candidate)
					}
					seenCandidates[candidate] = struct{}{}
					if part.NativeInsertionOrdinals[candidate] >= part.NativeInsertionOrdinals[selection.Node] {
						searcher.Close()
						return fmt.Errorf("%w: construction candidate insertion order node=%d candidate=%d", ErrVectorPartitionSearchUnavailable, selection.Node, candidate)
					}
				}
			} else if len(selection.CandidateOrdinals) != 0 || selection.CandidateDigest != "" {
				searcher.Close()
				return fmt.Errorf("%w: construction unsampled candidate payload partition=%d node=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID, selection.Node)
			}
			key := vectorIndexConstructionEdgeKeyV1{From: selection.Node, Layer: selection.Layer}
			if _, duplicate := selectionCounts[key]; duplicate {
				searcher.Close()
				return fmt.Errorf("%w: construction selection duplicate partition=%d node=%d layer=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID, selection.Node, selection.Layer)
			}
			selectionCounts[key] = [2]int{selection.DiversitySelected, selection.BackfillSelected}
		}
		// The sampled subset is independently derived from every eligible L0
		// selection and the persisted document IDs; evidence cannot nominate it.
		type sampleNode struct {
			node int
			hash [32]byte
			id   []byte
		}
		eligible := make([]sampleNode, 0)
		actualSampled := make(map[int]bool)
		for _, selection := range part.Selections {
			if selection.Layer != 0 {
				continue
			}
			start, end := pack.DocumentIDOffsets[selection.Node], pack.DocumentIDOffsets[selection.Node+1]
			if end < start || end > uint64(len(pack.DocumentIDBytes)) {
				searcher.Close()
				return fmt.Errorf("%w: construction document ID offsets partition=%d node=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID, selection.Node)
			}
			id := append([]byte(nil), pack.DocumentIDBytes[start:end]...)
			eligible = append(eligible, sampleNode{node: selection.Node, id: id, hash: vectorPartitionConstructionSampleHashV1(id)})
			if selection.CandidateSampled {
				actualSampled[selection.Node] = true
			}
		}
		sort.Slice(eligible, func(i, j int) bool {
			return vectorPartitionConstructionSampleLessV1(eligible[i].hash, eligible[i].id, eligible[j].hash, eligible[j].id)
		})
		// HNSW's entry point is the only row without a layer-zero insertion
		// selection. This makes the eligible sample population derivable from
		// the packed asset rather than from a self-declared trace subset.
		if len(eligible) != pack.Header.Rows-1 {
			searcher.Close()
			return fmt.Errorf("%w: construction eligible selections partition=%d got=%d want=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID, len(eligible), pack.Header.Rows-1)
		}
		limit := min(vectorPartitionConstructionCandidateSampleLimitV1, len(eligible))
		if len(actualSampled) != limit {
			searcher.Close()
			return fmt.Errorf("%w: construction sampled count partition=%d got=%d want=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID, len(actualSampled), limit)
		}
		for _, node := range eligible[:limit] {
			if !actualSampled[node.node] {
				searcher.Close()
				return fmt.Errorf("%w: construction canonical sample missing partition=%d node=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID, node.node)
			}
		}
		// Compact M18 evidence intentionally has no historical edge events. It
		// is validated directly against the encoded pack and count-only
		// lifecycle summary. Fixed-budget variants are the exception: their
		// causal final-origin map cannot be derived from packed adjacency alone,
		// so replay that construction path before accepting its attribution.
		if part.TraceMode == "compact" {
			err := vectorPartitionConstructionValidateCompactPartitionV1(part, pack, selectionCounts, variant)
			if err == nil && vectorPartitionConstructionVariantRequiresFixedBudgetReplayV1(variant) {
				replayed, replayErr := vectorPartitionConstructionReplayEvidenceV1(reader, members[part.PartitionID], buildDef, variant)
				if replayErr != nil {
					err = fmt.Errorf("construction replay: %w", replayErr)
				} else if !slices.Equal(part.NativeInsertionOrdinals, replayed.NativeInsertionOrdinals) || !vectorPartitionConstructionSelectionsEqualV1(part.Selections, replayed.Selections) || part.PostfillEdges != replayed.PostfillEdges || part.PruneKeeps != replayed.PruneKeeps || part.CompactLifecycle != replayed.CompactLifecycle || !slices.Equal(part.FinalOrigins, replayed.FinalOrigins) {
					err = fmt.Errorf("construction replay mismatch variant=%q insertion_ordinals_equal=%t selections_equal=%t edges=%d replay_edges=%d prune_keeps=%d replay_prune_keeps=%d lifecycle_equal=%t final_origins=%d replay_final_origins=%d", variant, slices.Equal(part.NativeInsertionOrdinals, replayed.NativeInsertionOrdinals), vectorPartitionConstructionSelectionsEqualV1(part.Selections, replayed.Selections), part.PostfillEdges, replayed.PostfillEdges, part.PruneKeeps, replayed.PruneKeeps, part.CompactLifecycle == replayed.CompactLifecycle, len(part.FinalOrigins), len(replayed.FinalOrigins))
				}
			}
			closeErr := searcher.Close()
			if err != nil || closeErr != nil {
				if err != nil {
					return fmt.Errorf("%w: compact construction partition=%d: %v", ErrVectorPartitionSearchUnavailable, part.PartitionID, err)
				}
				return fmt.Errorf("%w: compact construction close partition=%d: %v", ErrVectorPartitionSearchUnavailable, part.PartitionID, closeErr)
			}
			continue
		}
		if part.TraceMode != "detailed" || len(part.FinalOrigins) != 0 {
			searcher.Close()
			return ErrVectorPartitionSearchUnavailable
		}
		replayed, replayErr := vectorPartitionConstructionReplayEvidenceV1(reader, members[part.PartitionID], buildDef, variant)
		if replayErr != nil {
			searcher.Close()
			return fmt.Errorf("%w: construction replay partition=%d: %v", ErrVectorPartitionSearchUnavailable, part.PartitionID, replayErr)
		}
		if part.PostfillEdges != replayed.PostfillEdges {
			searcher.Close()
			return fmt.Errorf("%w: construction replay postfill mismatch partition=%d evidence=%d replay=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID, part.PostfillEdges, replayed.PostfillEdges)
		}
		if !slices.Equal(part.NativeInsertionOrdinals, replayed.NativeInsertionOrdinals) {
			searcher.Close()
			return fmt.Errorf("%w: construction replay insertion ordinals mismatch partition=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID)
		}
		if !vectorPartitionConstructionSelectionsEqualV1(part.Selections, replayed.Selections) {
			searcher.Close()
			return fmt.Errorf("%w: construction replay selections mismatch partition=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID)
		}
		if part.PruneKeeps != replayed.PruneKeeps || part.CompactLifecycle != replayed.CompactLifecycle {
			searcher.Close()
			return fmt.Errorf("%w: construction lifecycle summary mismatch partition=%d prune_keeps evidence=%d replay=%d lifecycle evidence=%+v replay=%+v", ErrVectorPartitionSearchUnavailable, part.PartitionID, part.PruneKeeps, replayed.PruneKeeps, part.CompactLifecycle, replayed.CompactLifecycle)
		}
		if !slices.Equal(part.Events, replayed.Events) {
			searcher.Close()
			return fmt.Errorf("%w: construction replay events mismatch partition=%d", ErrVectorPartitionSearchUnavailable, part.PartitionID)
		}
		initialCounts := make(map[vectorIndexConstructionEdgeKeyV1][2]int)
		finals := make(map[vectorIndexConstructionEdgeKeyV1]string)
		seenFinal := false
		for _, event := range part.Events {
			if event.From < 0 || event.To < 0 || event.From == event.To || event.From >= pack.Header.Rows || event.To >= pack.Header.Rows || event.Layer < 0 || event.Layer >= len(pack.AdjacencyLayers) || event.InsertionOrdinal < 0 || event.InsertionOrdinal >= pack.Header.Rows || event.InsertionOrdinal != max(part.NativeInsertionOrdinals[event.From], part.NativeInsertionOrdinals[event.To]) || !vectorPartitionConstructionOriginValidV1(event.Origin) || !vectorPartitionConstructionActionValidV1(event.Action) || !vectorPartitionConstructionVariantMutationAllowedV1(variant, event.Action) {
				searcher.Close()
				return fmt.Errorf("%w: construction event invalid %+v", ErrVectorPartitionSearchUnavailable, event)
			}
			key := vectorIndexConstructionEdgeKeyV1{From: event.From, To: event.To, Layer: event.Layer}
			switch event.Action {
			case "initial_add":
				if event.Origin != "diversity_selected" && event.Origin != "nearest_backfill" {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				if _, ok := live[key]; ok {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				live[key] = event.Origin
				counts := initialCounts[vectorIndexConstructionEdgeKeyV1{From: event.From, Layer: event.Layer}]
				if event.Origin == "diversity_selected" {
					counts[0]++
				} else {
					counts[1]++
				}
				initialCounts[vectorIndexConstructionEdgeKeyV1{From: event.From, Layer: event.Layer}] = counts
			case "reciprocal_add":
				if event.Origin != "reciprocal_add" {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				if _, ok := live[key]; ok {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				live[key] = event.Origin
			case "reciprocal_prune_keep":
				if live[key] != event.Origin {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
			case "reciprocal_prune_drop":
				if live[key] != event.Origin {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				delete(live, key)
			case "reciprocity_repair_add", "overlay_rewrite_add":
				wantOrigin := strings.TrimSuffix(event.Action, "_add")
				if event.Origin != wantOrigin {
					searcher.Close()
					return fmt.Errorf("%w: construction rewrite add origin %+v", ErrVectorPartitionSearchUnavailable, event)
				}
				if _, ok := live[key]; ok {
					searcher.Close()
					return fmt.Errorf("%w: construction rewrite add live %+v", ErrVectorPartitionSearchUnavailable, event)
				}
				live[key] = event.Origin
			case "quality_postfill_add":
				if event.Origin != "quality_postfill" {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				if _, ok := live[key]; ok {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				live[key] = event.Origin
			case "robust_prune_add":
				if event.Origin != "robust_prune_refinement" {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				if _, ok := live[key]; ok {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				live[key] = event.Origin
			case "robust_prune_residual_fill_add":
				if event.Origin != "robust_prune_residual_fill" {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				if _, ok := live[key]; ok {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				live[key] = event.Origin
			case "reciprocity_repair_drop", "overlay_rewrite_drop", "robust_prune_drop":
				if live[key] != event.Origin {
					searcher.Close()
					return fmt.Errorf("%w: construction rewrite drop live=%q event=%+v", ErrVectorPartitionSearchUnavailable, live[key], event)
				}
				delete(live, key)
			case "final_survivor":
				seenFinal = true
				if origin, ok := finals[key]; ok || live[key] != event.Origin || origin != "" {
					searcher.Close()
					return ErrVectorPartitionSearchUnavailable
				}
				finals[key] = event.Origin
			default:
				searcher.Close()
				return ErrVectorPartitionSearchUnavailable
			}
			if event.Action != "final_survivor" && seenFinal {
				searcher.Close()
				return ErrVectorPartitionSearchUnavailable
			}
		}
		for key, counts := range initialCounts {
			if selectionCounts[key] != counts {
				searcher.Close()
				return ErrVectorPartitionSearchUnavailable
			}
		}
		for key, counts := range selectionCounts {
			if initialCounts[key] != counts {
				searcher.Close()
				return ErrVectorPartitionSearchUnavailable
			}
		}
		want := make(map[vectorIndexConstructionEdgeKeyV1]struct{})
		for layer, adjacency := range pack.AdjacencyLayers {
			for from := 0; from < pack.Header.Rows; from++ {
				for _, to := range adjacency.Neighbors[adjacency.Offsets[from]:adjacency.Offsets[from+1]] {
					want[vectorIndexConstructionEdgeKeyV1{From: from, To: int(to), Layer: layer}] = struct{}{}
				}
			}
		}
		searcher.Close()
		if (len(want) != 0 && !seenFinal) || len(finals) != len(want) || len(live) != len(finals) {
			return fmt.Errorf("%w: construction final reconciliation want=%d finals=%d live=%d seen_final=%t", ErrVectorPartitionSearchUnavailable, len(want), len(finals), len(live), seenFinal)
		}
		for key := range want {
			if _, ok := finals[key]; !ok || live[key] != finals[key] {
				return fmt.Errorf("%w: construction final edge from=%d to=%d layer=%d", ErrVectorPartitionSearchUnavailable, key.From, key.To, key.Layer)
			}
		}
	}
	return nil
}

// vectorPartitionConstructionValidateSelectionPolicyV1 binds persisted L0
// selections to the variant's predeclared construction policy. This prevents
// self-consistent compact lifecycle accounting from being relabelled as a
// different initial-factor/backfill experiment.
func vectorPartitionConstructionValidateSelectionPolicyV1(selection VectorPartitionConstructionSelectionV1, m int, variant VectorPartitionLocalGraphVariantV1) error {
	if selection.Layer != 0 {
		return nil
	}
	policy, experimental := vectorPartitionLocalGraphVariantLayer0ConstructionPolicyV1(variant)
	if !experimental {
		return nil
	}
	if policy.initialSelectionFactor < 1 || m <= 0 || selection.Selected > m*policy.initialSelectionFactor || !policy.backfill && selection.BackfillSelected != 0 {
		return fmt.Errorf("%w: construction selection policy variant=%q node=%d selected=%d diversity=%d backfill=%d cap=%d", ErrVectorPartitionSearchUnavailable, variant, selection.Node, selection.Selected, selection.DiversitySelected, selection.BackfillSelected, m*policy.initialSelectionFactor)
	}
	return nil
}

// vectorPartitionConstructionValidateCompactPartitionV1 validates the bounded
// M18 trace without reconstructing its discarded per-edge history. The final
// origin map spans all HNSW layers because upper-layer traversal needs the
// same origin attribution; it must exactly cover the encoded adjacency.
func vectorPartitionConstructionValidateCompactPartitionV1(part VectorPartitionConstructionPartitionEvidenceV1, pack *columnHNSWSearchPackPreparedView, selections map[vectorIndexConstructionEdgeKeyV1][2]int, variant VectorPartitionLocalGraphVariantV1) error {
	if len(part.Events) != 0 || len(part.FinalOrigins) == 0 || part.TraceMode != "compact" || pack == nil {
		return fmt.Errorf("%w: compact trace shape events=%d finals=%d mode=%q pack=%t", ErrVectorPartitionSearchUnavailable, len(part.Events), len(part.FinalOrigins), part.TraceMode, pack != nil)
	}
	var initial [8]uint64
	for _, counts := range selections {
		initial[0] += uint64(counts[0])
		initial[1] += uint64(counts[1])
	}
	pruneKeeps, ok := vectorPartitionConstructionOriginCountsSumV1(part.CompactLifecycle.PruneKeep)
	if !ok || part.CompactLifecycle.InitialAdd != initial || part.CompactLifecycle.InitialAdd[2] != 0 || part.CompactLifecycle.InitialAdd[3] != 0 || part.CompactLifecycle.InitialAdd[4] != 0 || part.CompactLifecycle.InitialAdd[5] != 0 || part.CompactLifecycle.InitialAdd[6] != 0 || part.CompactLifecycle.InitialAdd[7] != 0 || part.CompactLifecycle.ReciprocalAdd[0] != 0 || part.CompactLifecycle.ReciprocalAdd[1] != 0 || part.CompactLifecycle.ReciprocalAdd[3] != 0 || part.CompactLifecycle.ReciprocalAdd[4] != 0 || part.CompactLifecycle.ReciprocalAdd[5] != 0 || part.CompactLifecycle.ReciprocalAdd[6] != 0 || part.CompactLifecycle.ReciprocalAdd[7] != 0 || part.PruneKeeps != pruneKeeps {
		return fmt.Errorf("%w: compact lifecycle initial=%v expected=%v reciprocal=%v prune_keeps=%d expected=%d", ErrVectorPartitionSearchUnavailable, part.CompactLifecycle.InitialAdd, initial, part.CompactLifecycle.ReciprocalAdd, part.PruneKeeps, pruneKeeps)
	}
	postfill, postfillOK := vectorPartitionConstructionOriginCountsSumV1(part.CompactLifecycle.QualityPostfillAdd)
	if !postfillOK || (variant != VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1 && (part.PostfillEdges != 0 || postfill != 0)) || (variant == VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1 && (part.CompactLifecycle.QualityPostfillAdd[0] != 0 || part.CompactLifecycle.QualityPostfillAdd[1] != 0 || part.CompactLifecycle.QualityPostfillAdd[2] != 0 || part.CompactLifecycle.QualityPostfillAdd[3] != 0 || part.CompactLifecycle.QualityPostfillAdd[4] != 0 || part.CompactLifecycle.QualityPostfillAdd[5] != part.PostfillEdges || part.CompactLifecycle.QualityPostfillAdd[6] != 0 || part.CompactLifecycle.QualityPostfillAdd[7] != 0)) {
		return fmt.Errorf("%w: compact quality postfill variant=%q edges=%d lifecycle=%v", ErrVectorPartitionSearchUnavailable, variant, part.PostfillEdges, part.CompactLifecycle.QualityPostfillAdd)
	}
	if part.CompactLifecycle.VariantAdd[0] != 0 || part.CompactLifecycle.VariantAdd[1] != 0 || part.CompactLifecycle.VariantAdd[2] != 0 {
		return fmt.Errorf("%w: compact variant adds have native origins %v", ErrVectorPartitionSearchUnavailable, part.CompactLifecycle.VariantAdd)
	}
	if part.CompactLifecycle.PruneKeep[3] != 0 || part.CompactLifecycle.PruneKeep[4] != 0 || part.CompactLifecycle.PruneKeep[5] != 0 || part.CompactLifecycle.PruneKeep[6] != 0 || part.CompactLifecycle.PruneKeep[7] != 0 || part.CompactLifecycle.PruneDrop[3] != 0 || part.CompactLifecycle.PruneDrop[4] != 0 || part.CompactLifecycle.PruneDrop[5] != 0 || part.CompactLifecycle.PruneDrop[6] != 0 || part.CompactLifecycle.PruneDrop[7] != 0 || part.CompactLifecycle.VariantAdd[5] != 0 {
		return fmt.Errorf("%w: compact lifecycle invalid quality origin prune_keep=%v prune_drop=%v variant_add=%v variant_drop=%v", ErrVectorPartitionSearchUnavailable, part.CompactLifecycle.PruneKeep, part.CompactLifecycle.PruneDrop, part.CompactLifecycle.VariantAdd, part.CompactLifecycle.VariantDrop)
	}
	// Connectivity repair can remove a final-stage quality-postfill edge. The
	// removed edge retains its causal origin, so this is the only non-robust
	// variant allowed to record VariantDrop[quality_postfill].
	if variant != VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MQualityPostfillV1 && part.CompactLifecycle.VariantDrop[5] != 0 {
		return fmt.Errorf("%w: compact non-quality lifecycle add=%v drop=%v", ErrVectorPartitionSearchUnavailable, part.CompactLifecycle.VariantAdd, part.CompactLifecycle.VariantDrop)
	}
	if variant != VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MRobustPruneV1 && (part.CompactLifecycle.VariantAdd[6] != 0 || part.CompactLifecycle.VariantAdd[7] != 0 || part.CompactLifecycle.VariantDrop[6] != 0 || part.CompactLifecycle.VariantDrop[7] != 0) {
		return fmt.Errorf("%w: compact non-robust lifecycle add=%v drop=%v", ErrVectorPartitionSearchUnavailable, part.CompactLifecycle.VariantAdd, part.CompactLifecycle.VariantDrop)
	}
	if variant == VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256Layer0Initial2MRobustPruneV1 {
		if part.CompactLifecycle.VariantAdd[4] != 0 || part.CompactLifecycle.VariantAdd[5] != 0 || part.CompactLifecycle.VariantDrop[3] != 0 || part.CompactLifecycle.VariantDrop[4] != 0 || part.CompactLifecycle.VariantDrop[5] != 0 {
			return fmt.Errorf("%w: compact robust-prune lifecycle add=%v drop=%v", ErrVectorPartitionSearchUnavailable, part.CompactLifecycle.VariantAdd, part.CompactLifecycle.VariantDrop)
		}
	} else if variant == VectorPartitionLocalGraphVariantOverlayCurrentV1 {
		if part.CompactLifecycle.VariantAdd[3] != 0 || part.CompactLifecycle.VariantDrop[3] != 0 || part.CompactLifecycle.VariantDrop[4] != 0 {
			return fmt.Errorf("%w: compact overlay variant lifecycle add=%v drop=%v", ErrVectorPartitionSearchUnavailable, part.CompactLifecycle.VariantAdd, part.CompactLifecycle.VariantDrop)
		}
	} else if part.CompactLifecycle.VariantAdd[4] != 0 || part.CompactLifecycle.VariantDrop[4] != 0 || (variant == VectorPartitionLocalGraphVariantNativeV1 && (part.CompactLifecycle.VariantAdd[3] != 0 || part.CompactLifecycle.VariantDrop[3] != 0 || part.CompactLifecycle.VariantDrop[0] != 0 || part.CompactLifecycle.VariantDrop[1] != 0 || part.CompactLifecycle.VariantDrop[2] != 0)) {
		return fmt.Errorf("%w: compact variant lifecycle variant=%q add=%v drop=%v", ErrVectorPartitionSearchUnavailable, variant, part.CompactLifecycle.VariantAdd, part.CompactLifecycle.VariantDrop)
	}
	if variant == VectorPartitionLocalGraphVariantAuxiliaryNavigationM18EfConstruction256V1 && (part.CompactLifecycle.PruneKeep[3] != 0 || part.CompactLifecycle.PruneKeep[4] != 0 || part.CompactLifecycle.PruneDrop[3] != 0 || part.CompactLifecycle.PruneDrop[4] != 0 || part.CompactLifecycle.VariantAdd[4] != 0 || part.CompactLifecycle.VariantDrop[3] != 0 || part.CompactLifecycle.VariantDrop[4] != 0) {
		return fmt.Errorf("%w: compact M18 lifecycle prune_keep=%v prune_drop=%v variant_add=%v variant_drop=%v", ErrVectorPartitionSearchUnavailable, part.CompactLifecycle.PruneKeep, part.CompactLifecycle.PruneDrop, part.CompactLifecycle.VariantAdd, part.CompactLifecycle.VariantDrop)
	}
	want := make(map[vectorIndexConstructionEdgeKeyV1]struct{})
	for layer, adjacency := range pack.AdjacencyLayers {
		for from := 0; from < pack.Header.Rows; from++ {
			for _, to := range adjacency.Neighbors[adjacency.Offsets[from]:adjacency.Offsets[from+1]] {
				want[vectorIndexConstructionEdgeKeyV1{From: from, To: int(to), Layer: layer}] = struct{}{}
			}
		}
	}
	finalCounts := [8]uint64{}
	seen := make(map[vectorIndexConstructionEdgeKeyV1]struct{}, len(part.FinalOrigins))
	var previous vectorIndexConstructionEdgeKeyV1
	for i, final := range part.FinalOrigins {
		key := vectorIndexConstructionEdgeKeyV1{From: final.From, To: final.To, Layer: final.Layer}
		if final.From < 0 || final.To < 0 || final.From == final.To || final.From >= pack.Header.Rows || final.To >= pack.Header.Rows || final.Layer < 0 || final.Layer >= len(pack.AdjacencyLayers) || !vectorPartitionConstructionOriginValidV1(final.Origin) || (i > 0 && (key.Layer < previous.Layer || key.Layer == previous.Layer && (key.From < previous.From || key.From == previous.From && key.To <= previous.To))) {
			return fmt.Errorf("%w: compact final invalid ordinal/order final=%+v", ErrVectorPartitionSearchUnavailable, final)
		}
		if _, ok := want[key]; !ok {
			return fmt.Errorf("%w: compact final missing packed edge final=%+v", ErrVectorPartitionSearchUnavailable, final)
		}
		if _, duplicate := seen[key]; duplicate {
			return fmt.Errorf("%w: compact final duplicate final=%+v", ErrVectorPartitionSearchUnavailable, final)
		}
		origin, ok := vectorIndexConstructionOriginIndexV1(final.Origin)
		if !ok {
			return fmt.Errorf("%w: compact final origin=%q", ErrVectorPartitionSearchUnavailable, final.Origin)
		}
		if finalCounts[origin] == ^uint64(0) {
			return fmt.Errorf("%w: compact final count overflow origin=%q", ErrVectorPartitionSearchUnavailable, final.Origin)
		}
		finalCounts[origin]++
		seen[key] = struct{}{}
		previous = key
	}
	if len(seen) != len(want) {
		return fmt.Errorf("%w: compact finals=%d packed_edges=%d", ErrVectorPartitionSearchUnavailable, len(seen), len(want))
	}
	for origin := range finalCounts {
		adds, ok := vectorPartitionConstructionAddV1(part.CompactLifecycle.InitialAdd[origin], part.CompactLifecycle.ReciprocalAdd[origin])
		if ok {
			adds, ok = vectorPartitionConstructionAddV1(adds, part.CompactLifecycle.VariantAdd[origin])
		}
		if ok {
			adds, ok = vectorPartitionConstructionAddV1(adds, part.CompactLifecycle.QualityPostfillAdd[origin])
		}
		drops, dropsOK := vectorPartitionConstructionAddV1(part.CompactLifecycle.PruneDrop[origin], part.CompactLifecycle.VariantDrop[origin])
		if !ok || !dropsOK || drops > adds || finalCounts[origin] != adds-drops {
			return fmt.Errorf("%w: compact lifecycle final origin=%d adds=%d drops=%d finals=%d", ErrVectorPartitionSearchUnavailable, origin, adds, drops, finalCounts[origin])
		}
	}
	return nil
}

func vectorPartitionConstructionOriginCountsSumV1(counts [8]uint64) (uint64, bool) {
	var total uint64
	for _, count := range counts {
		var ok bool
		total, ok = vectorPartitionConstructionAddV1(total, count)
		if !ok {
			return 0, false
		}
	}
	return total, true
}

func vectorPartitionConstructionAddV1(left, right uint64) (uint64, bool) {
	if ^uint64(0)-left < right {
		return 0, false
	}
	return left + right, true
}

func (c *Collection) materializeVectorPartitionLocalSearchAssetsV1(index string, manifest VectorPartitionManifestV1, fileID uint32, inputs []VectorPartitionSearchAssetV1, maxAssetBytes int64) ([]VectorPartitionAssetV1, *rootpublication.StableResourceSet, error) {
	return c.materializeVectorPartitionLocalSearchAssetsVariantV1(index, manifest, fileID, inputs, maxAssetBytes, vectorPartitionLocalDefaultGraphVariantV1, nil, false, nil)
}

// vectorPartitionConstructionReplayEvidenceV1 deterministically reconstructs
// the complete trace from manifest-bound source vectors. Candidate pools depend
// on the evolving HNSW graph, so a self-hash of evidence is not independent.
func vectorPartitionConstructionReplayEvidenceV1(reader *columnVectorGraphPhysicalRowReader, selected []vectorPartitionMembershipSourceV1, def VectorIndexDefinition, variant VectorPartitionLocalGraphVariantV1) (VectorPartitionConstructionPartitionEvidenceV1, error) {
	if reader == nil || len(selected) == 0 {
		return VectorPartitionConstructionPartitionEvidenceV1{}, ErrVectorPartitionSearchUnavailable
	}
	type selectedRow struct {
		ordinal int
		id      []byte
	}
	sourceRows := make([]selectedRow, len(selected))
	for i, source := range selected {
		id, ok := reader.documentIDForOrdinal(source.ordinal)
		if !ok || len(id) == 0 {
			return VectorPartitionConstructionPartitionEvidenceV1{}, ErrVectorPartitionSearchUnavailable
		}
		sourceRows[i] = selectedRow{ordinal: source.ordinal, id: id}
	}
	sort.Slice(sourceRows, func(i, j int) bool { return sourceRows[i].ordinal < sourceRows[j].ordinal })
	rows := make([]columnVectorGraphAssetRow, len(sourceRows))
	scratch := &columnPhysicalRowReaderScratch{}
	for i, source := range sourceRows {
		if i > 0 && source.ordinal == sourceRows[i-1].ordinal {
			return VectorPartitionConstructionPartitionEvidenceV1{}, ErrVectorPartitionSearchUnavailable
		}
		row, fetchErr := reader.FetchRow(source.ordinal, scratch)
		if fetchErr != nil && !errors.Is(fetchErr, errNilColumnVectorGraphPhysicalRowReader) {
			return VectorPartitionConstructionPartitionEvidenceV1{}, fmt.Errorf("construction replay fetch ordinal=%d: %w", source.ordinal, fetchErr)
		}
		if fetchErr != nil {
			row = columnVectorGraphPhysicalRow{}
		}
		if len(row.Vector) != def.Dimensions {
			row.Vector, _, _, _ = reader.typedVectorForOrdinal(source.ordinal)
		}
		if len(row.Vector) != def.Dimensions {
			return VectorPartitionConstructionPartitionEvidenceV1{}, ErrVectorPartitionSearchUnavailable
		}
		if invNorm, _, _, ok := reader.invNormForOrdinal(source.ordinal); ok {
			row.InvNorm = invNorm
		}
		rows[i] = columnVectorGraphAssetRow{ID: append([]byte(nil), source.id...), Vector: append([]float32(nil), row.Vector...), InvNorm: row.InvNorm}
	}
	// Replay is intentionally full-detail regardless of the persisted compact
	// campaign mode, so it remains an independent oracle for lifecycle counts
	// and final origins.
	trace := &vectorIndexConstructionTraceV1{detailed: true}
	if _, err := buildVectorPartitionLocalGraphAdjacencyVariantWithConstructionTraceV1(rows, def, variant, trace); err != nil {
		return VectorPartitionConstructionPartitionEvidenceV1{}, err
	}
	// Detailed evidence omits individual prune-keep events, so the replay must
	// preserve the count-only lifecycle summary for exact validation.
	out := VectorPartitionConstructionPartitionEvidenceV1{
		NativeInsertionOrdinals: append([]int(nil), trace.nativeInsertionOrdinals...),
		PruneKeeps:              trace.pruneKeeps,
		CompactLifecycle:        trace.compactLifecycle,
		PostfillEdges:           trace.postfillEdges,
	}
	for _, selection := range trace.selections {
		item := VectorPartitionConstructionSelectionV1{Node: selection.Node, Layer: selection.Layer, Candidates: selection.Candidates, Selected: selection.Selected, DiversitySelected: selection.DiversitySelected, BackfillSelected: selection.BackfillSelected}
		if selection.Sampled {
			item.CandidateSampled = true
			item.CandidateOrdinals = append([]int(nil), selection.CandidateNodes...)
			sort.Ints(item.CandidateOrdinals)
			item.CandidateDigest = vectorPartitionConstructionCandidateDigestV1(item.CandidateOrdinals)
		}
		out.Selections = append(out.Selections, item)
	}
	for _, event := range trace.events {
		out.Events = append(out.Events, VectorPartitionConstructionEdgeEventV1{From: event.From, To: event.To, Layer: event.Layer, InsertionOrdinal: event.InsertionOrdinal, Origin: event.Origin, Action: event.Action})
	}
	out.FinalOrigins = vectorPartitionConstructionFinalOriginsV1(trace.origins)
	return out, nil
}

// vectorPartitionConstructionVariantRequiresFixedBudgetReplayV1 identifies
// every offline #4172 construction arm. Their compact FinalOrigins are causal
// evidence, so count conservation alone cannot prevent an origin-label swap.
func vectorPartitionConstructionVariantRequiresFixedBudgetReplayV1(variant VectorPartitionLocalGraphVariantV1) bool {
	_, fixedBudget := vectorPartitionLocalGraphVariantLayer0ConstructionPolicyV1(variant)
	return fixedBudget
}

func vectorPartitionConstructionFinalOriginsV1(origins map[vectorIndexConstructionEdgeKeyV1]string) []VectorPartitionConstructionFinalOriginV1 {
	keys := make([]vectorIndexConstructionEdgeKeyV1, 0, len(origins))
	for key := range origins {
		keys = append(keys, key)
	}
	sort.Slice(keys, func(a, b int) bool {
		if keys[a].Layer != keys[b].Layer {
			return keys[a].Layer < keys[b].Layer
		}
		if keys[a].From != keys[b].From {
			return keys[a].From < keys[b].From
		}
		return keys[a].To < keys[b].To
	})
	finals := make([]VectorPartitionConstructionFinalOriginV1, 0, len(keys))
	for _, key := range keys {
		finals = append(finals, VectorPartitionConstructionFinalOriginV1{From: key.From, To: key.To, Layer: key.Layer, Origin: origins[key]})
	}
	return finals
}

func vectorPartitionConstructionSelectionsEqualV1(actual, replayed []VectorPartitionConstructionSelectionV1) bool {
	return slices.EqualFunc(actual, replayed, func(a, b VectorPartitionConstructionSelectionV1) bool {
		return a.Node == b.Node && a.Layer == b.Layer && a.Candidates == b.Candidates && a.Selected == b.Selected && a.DiversitySelected == b.DiversitySelected && a.BackfillSelected == b.BackfillSelected && a.CandidateSampled == b.CandidateSampled && a.CandidateDigest == b.CandidateDigest && slices.Equal(a.CandidateOrdinals, b.CandidateOrdinals)
	})
}

func (c *Collection) materializeVectorPartitionLocalSearchAssetsVariantV1(index string, manifest VectorPartitionManifestV1, fileID uint32, inputs []VectorPartitionSearchAssetV1, maxAssetBytes int64, variant VectorPartitionLocalGraphVariantV1, evidence *VectorPartitionConstructionEvidenceV1, boundedEvidence bool, ownerFileIDs map[string]uint32, owned ...vectorPartitionMaterializeOwnerV1) ([]VectorPartitionAssetV1, *rootpublication.StableResourceSet, error) {
	if err := manifest.requireInlineRuntimeV1(); err != nil {
		return nil, nil, err
	}
	generation := manifest.Generation
	if c == nil || c.db == nil || generation == 0 || len(inputs) == 0 || maxAssetBytes <= 0 || maxAssetBytes > vectorPartitionSearchAssetMaxBytesV1 {
		return nil, nil, ErrVectorPartitionSearchUnavailable
	}
	if _, err := VectorPartitionLocalGraphVariantIdentityV1(variant); err != nil {
		return nil, nil, fmt.Errorf("%w: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	if evidence != nil && variant == VectorPartitionLocalGraphVariantConnectivityPreservingVamanaR64L256Alpha1_2V1 {
		return nil, nil, fmt.Errorf("%w: Vamana uses pack validation rather than HNSW construction evidence", ErrVectorPartitionSearchUnavailable)
	}
	// The public materializer accepts a set of partition assets. Canonicalize it
	// before publishing so its companion evidence is likewise canonical.
	inputs = append([]VectorPartitionSearchAssetV1(nil), inputs...)
	sort.Slice(inputs, func(i, j int) bool { return inputs[i].PartitionID < inputs[j].PartitionID })
	limits := DefaultVectorPartitionManifestLimits()
	if manifest.SourceRowCount == 0 || manifest.SourceRowCount > uint64(limits.sourceRowLimit()) || len(manifest.Memberships) != int(manifest.SourceRowCount) || len(manifest.OverlapMemberships) > limits.MaxMemberships || len(inputs) > int(manifest.PartitionCount) {
		return nil, nil, fmt.Errorf("%w: manifest count cap", ErrVectorPartitionSearchUnavailable)
	}
	if index == "" || index != manifest.IndexName {
		return nil, nil, fmt.Errorf("%w: index/manifest mismatch", ErrVectorPartitionSearchUnavailable)
	}
	cfg := c.meta.Options.ColumnStore
	if cfg == nil || cfg.AssetManager == nil {
		return nil, nil, fmt.Errorf("%w: column asset manager", ErrVectorPartitionSearchUnavailable)
	}
	def, ok := findVectorIndex(c.meta.VectorIndexes, index)
	if !ok || def.Metric != VectorMetricCosine || def.Encoding != VectorIndexEncodingFloat32 {
		return nil, nil, fmt.Errorf("%w: native FP32 cosine index", ErrVectorPartitionSearchUnavailable)
	}
	if manifest.IndexDefinitionDigest != VectorIndexDefinitionDigestV1(def) {
		return nil, nil, fmt.Errorf("%w: index definition digest", ErrVectorPartitionSearchUnavailable)
	}
	buildDef, hasAuxiliaryNavigation, err := vectorPartitionLocalGraphVariantDefinitionV1(def, variant)
	if err != nil {
		return nil, nil, fmt.Errorf("%w: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	_, sourceGraph, _, err := c.columnVectorGraphPhysicalRowReaderSnapshotView(index)
	if err != nil || sourceGraph.BaseManifestGeneration != manifest.SourceGeneration || sourceGraph.BaseManifestChecksum != manifest.SourceChecksum || sourceGraph.BaseSchemaHash != manifest.SourceSchemaHash || uint64(sourceGraph.RowCount) != manifest.SourceRowCount {
		return nil, nil, fmt.Errorf("%w: stale authoritative source", ErrVectorPartitionSearchUnavailable)
	}
	reader, err := c.openColumnVectorGraphPhysicalRowReader(index, columnVectorGraphPhysicalRowReaderOptions{})
	if err != nil {
		return nil, nil, fmt.Errorf("%w: source reader: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	defer reader.Close()
	seenParts := make(map[uint32]struct{}, len(inputs))
	inputsByPartition := make(map[uint32]VectorPartitionSearchAssetV1, len(inputs))
	for _, in := range inputs {
		if in.Generation != generation || in.PartitionID >= manifest.PartitionCount || in.Dimensions != def.Dimensions || in.Source.Generation != manifest.SourceGeneration || in.Source.Checksum != manifest.SourceChecksum || in.Source.SchemaHash != manifest.SourceSchemaHash || in.Source.RowCount != manifest.SourceRowCount {
			return nil, nil, fmt.Errorf("%w: generation mismatch", ErrVectorPartitionSearchUnavailable)
		}
		if _, duplicate := seenParts[in.PartitionID]; duplicate {
			return nil, nil, fmt.Errorf("%w: duplicate partition", ErrVectorPartitionSearchUnavailable)
		}
		seenParts[in.PartitionID] = struct{}{}
		inputsByPartition[in.PartitionID] = in
	}
	domainMode := variant == vectorPartitionLocalDefaultGraphVariantV1 && manifest.DomainCount > 0 && manifest.DomainCount < manifest.PartitionCount
	buildInputs := inputs
	var fileIDByAnchor map[uint32]uint32
	homeMemberships, overlapMemberships := manifest.Memberships, manifest.OverlapMemberships
	if ownerFileIDs != nil && !domainMode {
		return nil, nil, fmt.Errorf("%w: owner-separated segments require domain mode", ErrVectorPartitionSearchUnavailable)
	}
	if domainMode {
		anchors, anchorForPack, err := vectorPartitionDomainLayoutV1(manifest)
		if err != nil || len(inputs) != int(manifest.PartitionCount) {
			return nil, nil, fmt.Errorf("%w: complete domain input", ErrVectorPartitionSearchUnavailable)
		}
		buildInputs = make([]VectorPartitionSearchAssetV1, len(anchors))
		for i, anchor := range anchors {
			in, ok := inputsByPartition[anchor]
			if !ok {
				return nil, nil, fmt.Errorf("%w: missing domain anchor %d", ErrVectorPartitionSearchUnavailable, anchor)
			}
			buildInputs[i] = in
		}
		for partition := uint32(0); partition < manifest.PartitionCount; partition++ {
			if _, ok := inputsByPartition[partition]; !ok {
				return nil, nil, fmt.Errorf("%w: missing physical pack %d", ErrVectorPartitionSearchUnavailable, partition)
			}
		}
		if ownerFileIDs != nil {
			fileIDByAnchor = make(map[uint32]uint32, len(anchors))
			placements := make(map[uint32]string, len(manifest.Placements))
			for _, placement := range manifest.Placements {
				placements[placement.PartitionID] = placement.GroupID
			}
			used := make(map[uint32]string, len(ownerFileIDs))
			seenOwners := make(map[string]bool, len(ownerFileIDs))
			for _, anchor := range anchors {
				owner := placements[anchor]
				segment := ownerFileIDs[owner]
				if owner == "" || segment == 0 || used[segment] != "" && used[segment] != owner {
					return nil, nil, fmt.Errorf("%w: missing or shared owner segment", ErrVectorPartitionSearchUnavailable)
				}
				used[segment], seenOwners[owner], fileIDByAnchor[anchor] = owner, true, segment
			}
			if len(seenOwners) != len(ownerFileIDs) {
				return nil, nil, fmt.Errorf("%w: unused owner segment", ErrVectorPartitionSearchUnavailable)
			}
			// Keep each owner's domains adjacent so one stable append session
			// closes each owner segment once, even for interleaved placements.
			sort.Slice(buildInputs, func(i, j int) bool {
				left, right := placements[buildInputs[i].PartitionID], placements[buildInputs[j].PartitionID]
				if left != right {
					return left < right
				}
				return buildInputs[i].PartitionID < buildInputs[j].PartitionID
			})
		}
		homeMemberships, overlapMemberships, err = vectorPartitionServingMembershipListsV1(manifest, anchorForPack)
		if err != nil {
			return nil, nil, err
		}
	}
	members := make(map[uint32][]vectorPartitionMembershipSourceV1)
	for _, x := range homeMemberships {
		if x.VectorOrdinal >= manifest.SourceRowCount {
			return nil, nil, fmt.Errorf("%w: source ordinal", ErrVectorPartitionSearchUnavailable)
		}
		members[x.PartitionID] = append(members[x.PartitionID], vectorPartitionMembershipSourceV1{int(x.VectorOrdinal), VectorPartitionMembershipHomeV1})
	}
	for _, x := range overlapMemberships {
		if x.VectorOrdinal >= manifest.SourceRowCount {
			return nil, nil, fmt.Errorf("%w: source ordinal", ErrVectorPartitionSearchUnavailable)
		}
		members[x.PartitionID] = append(members[x.PartitionID], vectorPartitionMembershipSourceV1{int(x.VectorOrdinal), VectorPartitionMembershipOverlapV1})
	}
	items := make([]StableColumnPhysicalAssetAppend, 0, len(buildInputs))
	pending := make([]vectorPartitionDomainAssetPayloadV1, 0, len(buildInputs))
	partitions := make([]VectorPartitionConstructionPartitionEvidenceV1, len(buildInputs))
	for i, in := range buildInputs {
		selected := members[in.PartitionID]
		if len(selected) == 0 {
			return nil, nil, fmt.Errorf("%w: partition has no canonical memberships", ErrVectorPartitionSearchUnavailable)
		}
		membershipDigest, err := vectorPartitionMembershipDigestV1(reader, generation, in.PartitionID, selected)
		if err != nil {
			return nil, nil, fmt.Errorf("retained variant partition %d membership digest: %w", in.PartitionID, err)
		}
		packPreflight := preflightVectorPartitionNativePackV1
		if domainMode {
			packPreflight = preflightVectorPartitionChunkedNativePackV1
		}
		if err := packPreflight(len(selected), buildDef.Dimensions, buildDef.M); err != nil {
			return nil, nil, fmt.Errorf("retained variant partition %d pack preflight: %w", in.PartitionID, err)
		}
		type selectedRow struct {
			ordinal int
			id      []byte
		}
		sourceRows := make([]selectedRow, len(selected))
		var documentIDBytes uint64
		for j, x := range selected {
			id, ok := reader.documentIDForOrdinal(x.ordinal)
			if !ok || len(id) == 0 {
				return nil, nil, fmt.Errorf("%w: authoritative stable ID", ErrVectorPartitionSearchUnavailable)
			}
			if uint64(len(id)) > ^uint64(0)-documentIDBytes {
				return nil, nil, fmt.Errorf("%w: stable ID byte overflow", ErrVectorPartitionSearchUnavailable)
			}
			documentIDBytes += uint64(len(id))
			sourceRows[j] = selectedRow{ordinal: x.ordinal, id: id}
		}
		// The caller's cap can be narrower than the public maximum used by the
		// shape-only preflight. Reject the known fixed-width and stable-ID lower
		// bound before copying vectors or constructing the partition-local graph.
		packCap := maxAssetBytes
		if domainMode {
			packCap = math.MaxInt64
		}
		if err := preflightVectorPartitionNativePackKnownBytesV1(len(sourceRows), buildDef.Dimensions, documentIDBytes, packCap); err != nil {
			return nil, nil, fmt.Errorf("retained variant partition %d byte preflight: %w", in.PartitionID, err)
		}
		// The partition owns a fresh local graph. Source ordinals provide a stable
		// construction order; the selected builder then applies its deterministic
		// entry-first locality order before the pack is encoded.
		sort.Slice(sourceRows, func(a, b int) bool {
			return sourceRows[a].ordinal < sourceRows[b].ordinal
		})
		for j, source := range sourceRows {
			if j > 0 && sourceRows[j-1].ordinal == source.ordinal {
				return nil, nil, fmt.Errorf("%w: duplicate membership ordinal", ErrVectorPartitionSearchUnavailable)
			}
		}
		rows := make([]columnVectorGraphAssetRow, len(sourceRows))
		scratch := &columnPhysicalRowReaderScratch{}
		for j, source := range sourceRows {
			r, fetchErr := reader.FetchRow(source.ordinal, scratch)
			if fetchErr != nil {
				r = columnVectorGraphPhysicalRow{}
			}
			if len(r.Vector) != def.Dimensions {
				r.Vector, _, _, _ = reader.typedVectorForOrdinal(source.ordinal)
			}
			if len(r.Vector) != def.Dimensions {
				return nil, nil, fmt.Errorf("%w: authoritative typed row", ErrVectorPartitionSearchUnavailable)
			}
			ref, refOK := reader.rowRefForOrdinal(source.ordinal)
			if !refOK {
				if fetchErr != nil || r.RowIndex < 0 {
					return nil, nil, fmt.Errorf("%w: authoritative source row ref", ErrVectorPartitionSearchUnavailable)
				}
				ref = DocumentRowRef{Generation: manifest.SourceGeneration, PartID: 1, RowIndex: r.RowIndex, AppliedCommandLSN: 1}
			}
			ref.DocumentID = append([]byte(nil), source.id...)
			if invNorm, _, _, ok := reader.invNormForOrdinal(source.ordinal); ok {
				r.InvNorm = invNorm
			}
			rows[j] = columnVectorGraphAssetRow{ID: append([]byte(nil), source.id...), Vector: append([]float32(nil), r.Vector...), InvNorm: r.InvNorm, BaseRowRef: ref}
		}
		var trace *vectorIndexConstructionTraceV1
		if evidence != nil {
			trace = &vectorIndexConstructionTraceV1{detailed: !boundedEvidence || vectorPartitionConstructionDetailedTraceV1(variant, in.PartitionID)}
		}
		auxiliary, err := buildVectorPartitionLocalGraphAdjacencyVariantWithConstructionTraceV1(rows, buildDef, variant, trace)
		if err != nil {
			return nil, nil, fmt.Errorf("%w: build partition-local graph: %v", ErrVectorPartitionSearchUnavailable, err)
		}
		maxLayer := 0
		rowMaxLayers := make([]int, len(rows))
		for j := range rows {
			rowMaxLayer, layerErr := columnVectorGraphAdjacencyMaxLayer(rows[j].Adjacency)
			if layerErr != nil {
				return nil, nil, fmt.Errorf("%w: partition-local adjacency: %v", ErrVectorPartitionSearchUnavailable, layerErr)
			}
			rowMaxLayers[j] = rowMaxLayer
			if rowMaxLayer > maxLayer {
				maxLayer = rowMaxLayer
			}
		}
		neighborCounts := make([]uint64, maxLayer+1)
		for j := range rows {
			for layer := 0; layer <= rowMaxLayers[j]; layer++ {
				neighbors, layerErr := columnVectorGraphAdjacencyLayer(rows[j].Adjacency, layer)
				if layerErr != nil {
					return nil, nil, fmt.Errorf("%w: partition-local adjacency: %v", ErrVectorPartitionSearchUnavailable, layerErr)
				}
				if uint64(len(neighbors)) > ^uint64(0)-neighborCounts[layer] {
					return nil, nil, fmt.Errorf("%w: neighbor count overflow", ErrVectorPartitionSearchUnavailable)
				}
				neighborCounts[layer] += uint64(len(neighbors))
			}
		}
		auxiliaryNeighbors := uint64(0)
		if hasAuxiliaryNavigation {
			auxiliaryNeighbors = uint64(len(auxiliary.Neighbors))
		}
		exactPackBytes, err := exactVectorPartitionLocalGraphPackBytesV1(len(rows), buildDef.Dimensions, neighborCounts, documentIDBytes, auxiliaryNeighbors, hasAuxiliaryNavigation, packCap)
		if err != nil {
			return nil, nil, fmt.Errorf("retained variant partition %d exact pack bytes: %w", in.PartitionID, err)
		}
		graph := columnVectorGraphManifestSnapshot{IndexName: buildDef.Name, Field: buildDef.Field, Metric: buildDef.Metric, Encoding: buildDef.Encoding, Dimensions: buildDef.Dimensions, M: buildDef.M, EfConstruction: buildDef.EfConstruction, EfSearch: buildDef.EfSearch, BaseManifestGeneration: manifest.SourceGeneration, BaseManifestChecksum: manifest.SourceChecksum, BaseSchemaHash: manifest.SourceSchemaHash, GraphSchemaHash: cfg.SchemaHash, RowCount: len(rows)}
		pack, err := buildColumnHNSWSearchPackInputWithoutVectors(buildDef, graph, rows)
		if err != nil {
			return nil, nil, fmt.Errorf("retained variant partition %d pack input: %w", in.PartitionID, err)
		}
		// Native A/B packs domain-bind their variant into the existing membership
		// identity. Production publication and serving recompute the canonical
		// membership digest and therefore fail closed on a native offline pack.
		pack.MembershipDigest = vectorPartitionLocalGraphVariantMembershipDigestV1(membershipDigest, variant)
		pack.CanonicalPartitionHNSW = variant == VectorPartitionLocalGraphVariantCanonicalHNSWM18EfConstruction256V1
		pack.ConnectivityPreservingPartitionVamana = variant == VectorPartitionLocalGraphVariantConnectivityPreservingVamanaR64L256Alpha1_2V1
		if hasAuxiliaryNavigation {
			pack.HasAuxiliaryNavigation = true
			pack.AuxiliaryNavigation = columnHNSWSearchPackLayerInput{Offsets: auxiliary.Offsets, Neighbors: auxiliary.Neighbors}
		}
		raw, err := encodeColumnHNSWSearchPackRows(pack, rows)
		if err != nil {
			return nil, nil, fmt.Errorf("retained variant partition %d encode pack: %w", in.PartitionID, err)
		}
		if int64(len(raw)) != exactPackBytes || (!domainMode && int64(len(raw)) > maxAssetBytes) {
			return nil, nil, fmt.Errorf("%w: encoded native pack bytes=%d exact=%d cap=%d", ErrVectorPartitionSearchUnavailable, len(raw), exactPackBytes, packCap)
		}
		// Column assets reserve physical part ID zero; logical partitions are
		// zero-based, so persist their unambiguous +1 representation.
		payloads := []vectorPartitionDomainAssetPayloadV1{{id: vectorPartitionLocalAssetIDV1(in.PartitionID), payload: raw, membershipDigest: hex.EncodeToString(pack.MembershipDigest[:]), graphVariant: string(variant), partition: in.PartitionID}}
		if domainMode {
			payloads, err = splitVectorPartitionDomainSearchPackV1(raw, in.PartitionID, maxAssetBytes)
			if err != nil {
				return nil, nil, err
			}
		}
		for j := range payloads {
			payloads[j].constructionSource = i
			pending = append(pending, payloads[j])
			items = append(items, StableColumnPhysicalAssetAppend{Payload: payloads[j].payload, Kind: ColumnAssetKindTCS1HNSWSearchPack, Generation: generation, PartID: uint64(in.PartitionID) + 1, FileID: fileIDByAnchor[in.PartitionID]})
		}
		if trace != nil {
			partition := VectorPartitionConstructionPartitionEvidenceV1{PartitionID: in.PartitionID, NativeInsertionOrdinals: append([]int(nil), trace.nativeInsertionOrdinals...), PruneKeeps: trace.pruneKeeps, CompactLifecycle: trace.compactLifecycle, PostfillEdges: trace.postfillEdges, TraceMode: "compact"}
			if trace.detailed {
				partition.TraceMode = "detailed"
			}
			for _, selection := range trace.selections {
				selectionEvidence := VectorPartitionConstructionSelectionV1{Node: selection.Node, Layer: selection.Layer, Candidates: selection.Candidates, Selected: selection.Selected, DiversitySelected: selection.DiversitySelected, BackfillSelected: selection.BackfillSelected}
				if selection.Sampled {
					selectionEvidence.CandidateSampled = true
					selectionEvidence.CandidateOrdinals = append([]int(nil), selection.CandidateNodes...)
					sort.Ints(selectionEvidence.CandidateOrdinals)
					selectionEvidence.CandidateDigest = vectorPartitionConstructionCandidateDigestV1(selectionEvidence.CandidateOrdinals)
				}
				partition.Selections = append(partition.Selections, selectionEvidence)
			}
			for _, event := range trace.events {
				partition.Events = append(partition.Events, VectorPartitionConstructionEdgeEventV1{From: event.From, To: event.To, Layer: event.Layer, InsertionOrdinal: event.InsertionOrdinal, Origin: event.Origin, Action: event.Action})
			}
			if !trace.detailed {
				partition.FinalOrigins = vectorPartitionConstructionFinalOriginsV1(trace.origins)
			}
			partitions[i] = partition
		}
	}
	var lease *backenddb.StableResourceCaptureLease
	var releaseCapture func()
	if len(owned) != 0 && owned[0].owner != nil {
		lease, releaseCapture, err = owned[0].owner.vectorPrepareCaptureLeaseV1()
	} else {
		lease, err = c.db.AcquireStableResourceCaptureLease()
		if lease != nil {
			releaseCapture = lease.Release
		}
	}
	if err != nil {
		return nil, nil, fmt.Errorf("retained variant capture lease: %w", err)
	}
	defer releaseCapture()
	var refs []ColumnAssetRef
	var resources *rootpublication.StableResourceSet
	if len(owned) != 0 && owned[0].fresh {
		refs, resources, err = appendFreshColumnPhysicalAssetsWithStableResources(c.db.ColumnAssetRootDir(), *cfg, items, c.db.StableResourceIdentityPinRegistry(), lease)
	} else {
		refs, resources, err = AppendColumnPhysicalAssetsWithStableResources(c.db.ColumnAssetRootDir(), *cfg, fileID, items, c.db.StableResourceIdentityPinRegistry(), lease)
	}
	if err != nil {
		return nil, nil, fmt.Errorf("retained variant append packs: %w", err)
	}
	out := make([]VectorPartitionAssetV1, len(pending))
	for i := range pending {
		sum := sha256.Sum256(items[i].Payload)
		payload := pending[i]
		out[i] = VectorPartitionAssetV1{ID: payload.id, PartitionID: payload.partition, Checksum: hex.EncodeToString(sum[:]), MembershipDigest: payload.membershipDigest, GraphVariant: payload.graphVariant, Bytes: uint64(len(items[i].Payload)), Ref: refs[i]}
		if out[i].Ref.PartID != uint64(payload.partition)+1 {
			return nil, nil, fmt.Errorf("%w: partition ref", ErrVectorPartitionSearchUnavailable)
		}
		if evidence != nil {
			partition := partitions[payload.constructionSource]
			if partition.PartitionID != out[i].PartitionID || len(partition.NativeInsertionOrdinals) == 0 {
				return nil, nil, fmt.Errorf("%w: construction trace", ErrVectorPartitionSearchUnavailable)
			}
			partition.AssetChecksum, partition.MembershipDigest, partition.AssetBytes = out[i].Checksum, out[i].MembershipDigest, out[i].Bytes
			evidence.Partitions = append(evidence.Partitions, partition)
		}
	}
	return out, resources, nil
}

func encodeVectorPartitionSearchAssetV1(a VectorPartitionSearchAssetV1) ([]byte, error) {
	if len(a.Adjacency) == 0 {
		a.Adjacency = make([][]uint32, len(a.IDs))
	}
	if err := validateVectorPartitionSearchAssetV1(a); err != nil {
		return nil, err
	}
	// Bounded preflight covers all count-derived writes before allocating.
	bytesNeeded := int64(4 + 4 + 8 + 4 + 4 + 4 + 4 + sha256.Size + len(a.ManifestChecksum))
	for i, id := range a.IDs {
		bytesNeeded += int64(4 + len(id) + 1 + 4*len(a.Vectors[i]) + 4 + 4*len(a.Adjacency[i]))
		if bytesNeeded > vectorPartitionSearchAssetMaxBytesV1 {
			return nil, errors.New("partition search asset byte cap")
		}
	}
	var b bytes.Buffer
	b.Grow(int(bytesNeeded))
	b.WriteString(vectorPartitionSearchAssetMagicV1)
	var x [8]byte
	binary.BigEndian.PutUint32(x[:4], vectorPartitionSearchAssetVersionV1)
	b.Write(x[:4])
	binary.BigEndian.PutUint64(x[:], a.Generation)
	b.Write(x[:])
	binary.BigEndian.PutUint32(x[:4], a.PartitionID)
	b.Write(x[:4])
	binary.BigEndian.PutUint32(x[:4], uint32(a.Dimensions))
	b.Write(x[:4])
	binary.BigEndian.PutUint32(x[:4], uint32(len(a.IDs)))
	b.Write(x[:4])
	binary.BigEndian.PutUint32(x[:4], uint32(len(a.ManifestChecksum)))
	b.Write(x[:4])
	b.WriteString(a.ManifestChecksum)
	for i, id := range a.IDs {
		binary.BigEndian.PutUint32(x[:4], uint32(len(id)))
		b.Write(x[:4])
		b.WriteString(id)
		if a.Kinds[i] == VectorPartitionMembershipHomeV1 {
			b.WriteByte(1)
		} else {
			b.WriteByte(2)
		}
		for _, v := range a.Vectors[i] {
			binary.BigEndian.PutUint32(x[:4], math.Float32bits(v))
			b.Write(x[:4])
		}
		binary.BigEndian.PutUint32(x[:4], uint32(len(a.Adjacency[i])))
		b.Write(x[:4])
		for _, n := range a.Adjacency[i] {
			binary.BigEndian.PutUint32(x[:4], n)
			b.Write(x[:4])
		}
	}
	sum := sha256.Sum256(b.Bytes())
	b.Write(sum[:])
	return b.Bytes(), nil
}

func decodeVectorPartitionSearchAssetV1(raw []byte) (VectorPartitionSearchAssetV1, error) {
	if len(raw) < 4+4+8+4+4+4+4+sha256.Size || string(raw[:4]) != vectorPartitionSearchAssetMagicV1 || binary.BigEndian.Uint32(raw[4:8]) != vectorPartitionSearchAssetVersionV1 {
		return VectorPartitionSearchAssetV1{}, errors.New("partition search asset header")
	}
	sum := sha256.Sum256(raw[:len(raw)-sha256.Size])
	if !bytes.Equal(sum[:], raw[len(raw)-sha256.Size:]) {
		return VectorPartitionSearchAssetV1{}, errors.New("partition search asset checksum")
	}
	off := 8
	take := func(n int) ([]byte, bool) {
		if n < 0 || off > len(raw)-sha256.Size-n {
			return nil, false
		}
		v := raw[off : off+n]
		off += n
		return v, true
	}
	u32 := func() (uint32, bool) {
		v, ok := take(4)
		if !ok {
			return 0, false
		}
		return binary.BigEndian.Uint32(v), true
	}
	u64 := func() (uint64, bool) {
		v, ok := take(8)
		if !ok {
			return 0, false
		}
		return binary.BigEndian.Uint64(v), true
	}
	g, ok := u64()
	if !ok {
		return VectorPartitionSearchAssetV1{}, errors.New("partition search asset truncated")
	}
	p, ok := u32()
	if !ok {
		return VectorPartitionSearchAssetV1{}, errors.New("partition search asset truncated")
	}
	dims, ok := u32()
	if !ok || dims == 0 || dims > 4096 {
		return VectorPartitionSearchAssetV1{}, errors.New("partition search asset dimensions")
	}
	rows, ok := u32()
	if !ok || rows == 0 || rows > 1_000_000 {
		return VectorPartitionSearchAssetV1{}, errors.New("partition search asset rows")
	}
	n, ok := u32()
	if !ok || n != 64 {
		return VectorPartitionSearchAssetV1{}, errors.New("partition search asset manifest checksum")
	}
	mb, ok := take(int(n))
	if !ok {
		return VectorPartitionSearchAssetV1{}, errors.New("partition search asset truncated")
	}
	a := VectorPartitionSearchAssetV1{ManifestChecksum: string(mb), Generation: g, PartitionID: p, Dimensions: int(dims), IDs: make([]string, rows), Vectors: make([][]float32, rows), Kinds: make([]VectorPartitionMembershipKindV1, rows), Adjacency: make([][]uint32, rows)}
	for i := range a.IDs {
		ln, ok := u32()
		if !ok || ln == 0 || ln > 1<<20 {
			return VectorPartitionSearchAssetV1{}, errors.New("partition search asset ID")
		}
		id, ok := take(int(ln))
		if !ok {
			return VectorPartitionSearchAssetV1{}, errors.New("partition search asset truncated")
		}
		a.IDs[i] = string(id)
		k, ok := take(1)
		if !ok {
			return VectorPartitionSearchAssetV1{}, errors.New("partition search asset kind")
		}
		switch k[0] {
		case 1:
			a.Kinds[i] = VectorPartitionMembershipHomeV1
		case 2:
			a.Kinds[i] = VectorPartitionMembershipOverlapV1
		default:
			return VectorPartitionSearchAssetV1{}, errors.New("partition search asset kind")
		}
		a.Vectors[i] = make([]float32, dims)
		for j := range a.Vectors[i] {
			v, ok := u32()
			if !ok {
				return VectorPartitionSearchAssetV1{}, errors.New("partition search asset truncated")
			}
			a.Vectors[i][j] = math.Float32frombits(v)
		}
		count, ok := u32()
		if !ok || count > rows {
			return VectorPartitionSearchAssetV1{}, errors.New("partition search asset adjacency")
		}
		a.Adjacency[i] = make([]uint32, count)
		for j := range a.Adjacency[i] {
			v, ok := u32()
			if !ok {
				return VectorPartitionSearchAssetV1{}, errors.New("partition search asset truncated")
			}
			a.Adjacency[i][j] = v
		}
	}
	if off != len(raw)-sha256.Size {
		return VectorPartitionSearchAssetV1{}, errors.New("partition search asset trailing bytes")
	}
	if err := validateVectorPartitionSearchAssetV1(a); err != nil {
		return VectorPartitionSearchAssetV1{}, err
	}
	return a, nil
}

func (c *Collection) OpenVectorPartitionLocalSearcherForGenerationV1(index string, generation uint64, partition uint32) (*VectorPartitionLocalSearcherV1, error) {
	return c.OpenVectorPartitionLocalSearcherForGenerationWithContextV1(context.Background(), index, generation, partition)
}

// OpenVectorPartitionLocalSearcherForOfflineAssetWithContextV1 opens one
// freshly materialized local pack without publishing its manifest or acquiring
// a production generation pin. It is for bounded offline attribution only.
// The caller keeps the materializer's StableResourceSet alive until Close.
func (c *Collection) OpenVectorPartitionLocalSearcherForOfflineAssetWithContextV1(ctx context.Context, index string, manifest VectorPartitionManifestV1, asset VectorPartitionAssetV1) (*VectorPartitionLocalSearcherV1, error) {
	return c.openVectorPartitionLocalSearcherForOfflineAssetWithContextV1(ctx, index, manifest, asset, "")
}

// OpenVectorPartitionLocalSearcherForOfflineAssetVariantWithContextV1 opens
// one offline pack only when its domain-separated membership identity and pack
// header bind it to expectedVariant. Use this boundary when benchmark metadata
// attributes retained assets to a particular construction variant.
func (c *Collection) OpenVectorPartitionLocalSearcherForOfflineAssetVariantWithContextV1(ctx context.Context, index string, manifest VectorPartitionManifestV1, asset VectorPartitionAssetV1, expectedVariant VectorPartitionLocalGraphVariantV1) (*VectorPartitionLocalSearcherV1, error) {
	if _, err := VectorPartitionLocalGraphVariantIdentityV1(expectedVariant); err != nil {
		return nil, fmt.Errorf("%w: offline graph variant", ErrVectorPartitionSearchUnavailable)
	}
	return c.openVectorPartitionLocalSearcherForOfflineAssetWithContextV1(ctx, index, manifest, asset, expectedVariant)
}

func (c *Collection) openVectorPartitionLocalSearcherForOfflineAssetWithContextV1(ctx context.Context, index string, manifest VectorPartitionManifestV1, asset VectorPartitionAssetV1, expectedVariant VectorPartitionLocalGraphVariantV1) (*VectorPartitionLocalSearcherV1, error) {
	if err := manifest.requireInlineRuntimeV1(); err != nil {
		return nil, err
	}
	if c == nil || c.db == nil || ctx == nil {
		return nil, ErrVectorPartitionSearchUnavailable
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if manifest.Collection != c.name || manifest.IndexName != index || manifest.Generation == 0 || asset.PartitionID >= manifest.PartitionCount || asset.ID != vectorPartitionLocalAssetIDV1(asset.PartitionID) {
		return nil, fmt.Errorf("%w: offline pack identity", ErrVectorPartitionSearchUnavailable)
	}
	def, ok := findVectorIndex(c.meta.VectorIndexes, index)
	if !ok || manifest.IndexDefinitionDigest != VectorIndexDefinitionDigestV1(def) {
		return nil, fmt.Errorf("%w: offline index identity", ErrVectorPartitionSearchUnavailable)
	}
	source, err := c.VectorPartitionSourceIdentityV1(index)
	if err != nil || source.Generation != manifest.SourceGeneration || source.Checksum != manifest.SourceChecksum || source.SchemaHash != manifest.SourceSchemaHash || source.RowCount != manifest.SourceRowCount {
		return nil, fmt.Errorf("%w: offline source identity", ErrVectorPartitionSearchUnavailable)
	}
	members, err := vectorPartitionMembershipsForPartitionWithContextV1(ctx, manifest, asset.PartitionID)
	if err != nil {
		return nil, err
	}
	home, overlap := 0, 0
	for _, member := range members {
		if member.kind == VectorPartitionMembershipHomeV1 {
			home++
		} else if member.kind == VectorPartitionMembershipOverlapV1 {
			overlap++
		} else {
			return nil, ErrVectorPartitionSearchUnavailable
		}
	}
	return c.openVectorPartitionLocalSearcherForPreparedPartitionWithContextV1(ctx, index, manifest.Generation, asset.PartitionID, manifest.IndexDefinitionDigest, manifest.SourceGeneration, manifest.SourceChecksum, manifest.SourceSchemaHash, manifest.SourceRowCount, &asset, members, home, overlap, true, expectedVariant, false, false)
}

// OpenVectorPartitionLocalSearcherForGenerationWithContextV1 is the
// cancellation-aware cold-open boundary used by routed serving. Checks are
// placed around lifecycle reads, membership scans, checksum streaming, and
// mapped-resource preparation; any acquired pin or handle is released on a
// canceled return.
func (c *Collection) OpenVectorPartitionLocalSearcherForGenerationWithContextV1(ctx context.Context, index string, generation uint64, partition uint32) (*VectorPartitionLocalSearcherV1, error) {
	if c == nil || c.db == nil {
		return nil, ErrVectorPartitionSearchUnavailable
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	pin, err := c.AcquireVectorPartitionReaderPinWithContextV1(ctx, index, generation)
	if err != nil {
		if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
			return nil, err
		}
		return nil, fmt.Errorf("%w: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	release := true
	defer func() {
		if release {
			pin.Release()
		}
	}()
	store, err := OpenExistingVectorPartitionStoreV1(c.db.Dir())
	if err != nil {
		return nil, err
	}
	m, err := store.OpenWithContext(ctx, c.name, index, generation)
	if err != nil {
		return nil, err
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	def, ok := findVectorIndex(c.meta.VectorIndexes, index)
	if !ok || m.IndexName != index || m.IndexDefinitionDigest != VectorIndexDefinitionDigestV1(def) || def.Metric != VectorMetricCosine || def.Encoding != VectorIndexEncodingFloat32 {
		return nil, fmt.Errorf("%w: stale index definition", ErrVectorPartitionSearchUnavailable)
	}
	plan, err := NewVectorPartitionGenerationSearchOpenPlanWithContextV1(ctx, m)
	if err != nil {
		return nil, err
	}
	asset, members, home, overlap, err := plan.partition(partition)
	if err != nil {
		return nil, err
	}
	searcher, err := c.openVectorPartitionLocalSearcherForPreparedAssetsWithContextV1(
		ctx, index, generation, partition,
		m.IndexDefinitionDigest, m.SourceGeneration, m.SourceChecksum, m.SourceSchemaHash, m.SourceRowCount,
		asset, plan.partitionAssets(partition), members, home, overlap, false, "", false, false,
	)
	if err != nil {
		return nil, err
	}
	searcher.partitionPin = pin
	release = false
	return searcher, nil
}

// OpenVectorPartitionLocalSearcherForGenerationSearchPlanWithContextV1 opens a
// persistent local searcher from a generation-wide plan prepared during the
// active-generation load. It clones the supplied validated generation pin for
// the searcher without lifecycle I/O, while avoiding another manifest decode
// and membership scan for every partition in one cold routed request.
func (c *Collection) OpenVectorPartitionLocalSearcherForGenerationSearchPlanWithContextV1(ctx context.Context, index string, generation uint64, partition uint32, plan *VectorPartitionGenerationSearchOpenPlanV1, generationPin *VectorPartitionReaderPinV1) (*VectorPartitionLocalSearcherV1, error) {
	return c.openVectorPartitionLocalSearcherForGenerationSearchPlanWithContextV1(ctx, index, generation, partition, plan, generationPin, false, false, "")
}

// OpenVectorPartitionLocalSearcherForGenerationOfflineVariantSearchPlanWithContextV1
// is the planned-open equivalent of the bounded offline attribution opener.
// It never admits the variant through the ordinary production boundary.
func (c *Collection) OpenVectorPartitionLocalSearcherForGenerationOfflineVariantSearchPlanWithContextV1(ctx context.Context, index string, generation uint64, partition uint32, plan *VectorPartitionGenerationSearchOpenPlanV1, generationPin *VectorPartitionReaderPinV1, expectedVariant VectorPartitionLocalGraphVariantV1) (*VectorPartitionLocalSearcherV1, error) {
	if _, err := VectorPartitionLocalGraphVariantIdentityV1(expectedVariant); err != nil {
		return nil, fmt.Errorf("%w: offline graph variant", ErrVectorPartitionSearchUnavailable)
	}
	return c.openVectorPartitionLocalSearcherForGenerationSearchPlanWithContextV1(ctx, index, generation, partition, plan, generationPin, false, true, expectedVariant)
}

// OpenVectorPartitionLocalSearcherForGenerationLiveSearchPlanWithContextV1
// prepares the stable-ID eligibility table needed by standalone live-delta
// serving. Immutable and replicated generation opens deliberately omit it.
func (c *Collection) OpenVectorPartitionLocalSearcherForGenerationLiveSearchPlanWithContextV1(ctx context.Context, index string, generation uint64, partition uint32, plan *VectorPartitionGenerationSearchOpenPlanV1, generationPin *VectorPartitionReaderPinV1) (*VectorPartitionLocalSearcherV1, error) {
	if plan == nil || !plan.liveRecovery {
		return nil, fmt.Errorf("%w: live recovery plan", ErrVectorPartitionSearchUnavailable)
	}
	return c.openVectorPartitionLocalSearcherForGenerationSearchPlanWithContextV1(ctx, index, generation, partition, plan, generationPin, true, false, "")
}

func (c *Collection) openVectorPartitionLocalSearcherForGenerationSearchPlanWithContextV1(ctx context.Context, index string, generation uint64, partition uint32, plan *VectorPartitionGenerationSearchOpenPlanV1, generationPin *VectorPartitionReaderPinV1, prepareStableIDOrdinals, allowOfflineNative bool, expectedGraphVariant VectorPartitionLocalGraphVariantV1) (*VectorPartitionLocalSearcherV1, error) {
	if c == nil || c.db == nil {
		return nil, ErrVectorPartitionSearchUnavailable
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if plan == nil || plan.collection != c.name || plan.indexName != index || plan.generation != generation {
		return nil, fmt.Errorf("%w: stale generation search-open plan", ErrVectorPartitionSearchUnavailable)
	}
	if prepareStableIDOrdinals {
		manifest := VectorPartitionManifestV1{
			Collection: plan.collection, IndexName: plan.indexName, IndexDefinitionDigest: plan.indexDefinitionDigest,
			SourceGeneration: plan.sourceGeneration, SourceChecksum: plan.sourceChecksum, SourceSchemaHash: plan.sourceSchemaHash,
			SourceRowCount: plan.sourceRowCount, Generation: plan.generation,
		}
		if !plan.liveRecovery {
			return nil, fmt.Errorf("%w: live recovery authority", ErrVectorPartitionSearchUnavailable)
		}
		if err := c.validateCurrentVectorPartitionLiveBindingV1(ctx, manifest); err != nil {
			return nil, fmt.Errorf("%w: live recovery authority: %v", ErrVectorPartitionSearchUnavailable, err)
		}
	}
	pinKey := vectorPartitionReaderPinKeyV1(c.db.Dir(), c.name, index, generation)
	pin, err := generationPin.cloneForKey(pinKey)
	if err != nil {
		return nil, fmt.Errorf("%w: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	release := true
	defer func() {
		if release {
			pin.Release()
		}
	}()
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	asset, members, home, overlap, err := plan.partition(partition)
	if err != nil {
		return nil, err
	}
	searcher, err := c.openVectorPartitionLocalSearcherForPreparedAssetsWithContextV1(
		ctx, index, generation, partition,
		plan.indexDefinitionDigest, plan.sourceGeneration, plan.sourceChecksum, plan.sourceSchemaHash, plan.sourceRowCount,
		asset, plan.partitionAssets(partition), members, home, overlap, allowOfflineNative, expectedGraphVariant, prepareStableIDOrdinals, plan.liveRecovery,
	)
	if err != nil {
		return nil, err
	}
	searcher.partitionPin = pin
	release = false
	return searcher, nil
}

func (c *Collection) openVectorPartitionLocalSearcherForPreparedPartitionWithContextV1(
	ctx context.Context,
	index string,
	generation uint64,
	partition uint32,
	indexDefinitionDigest string,
	sourceGeneration uint64,
	sourceChecksum uint64,
	sourceSchemaHash uint64,
	sourceRowCount uint64,
	asset *VectorPartitionAssetV1,
	members []vectorPartitionMembershipSourceV1,
	home int,
	overlap int,
	allowOfflineNative bool,
	expectedGraphVariant VectorPartitionLocalGraphVariantV1,
	prepareStableIDOrdinals bool,
	allowLiveRecovery bool,
) (*VectorPartitionLocalSearcherV1, error) {
	return c.openVectorPartitionLocalSearcherForPreparedAssetsWithContextV1(ctx, index, generation, partition, indexDefinitionDigest, sourceGeneration, sourceChecksum, sourceSchemaHash, sourceRowCount, asset, nil, members, home, overlap, allowOfflineNative, expectedGraphVariant, prepareStableIDOrdinals, allowLiveRecovery)
}

func (c *Collection) openVectorPartitionLocalSearcherForPreparedAssetsWithContextV1(
	ctx context.Context,
	index string,
	generation uint64,
	partition uint32,
	indexDefinitionDigest string,
	sourceGeneration uint64,
	sourceChecksum uint64,
	sourceSchemaHash uint64,
	sourceRowCount uint64,
	asset *VectorPartitionAssetV1,
	assetGroup []VectorPartitionAssetV1,
	members []vectorPartitionMembershipSourceV1,
	home int,
	overlap int,
	allowOfflineNative bool,
	expectedGraphVariant VectorPartitionLocalGraphVariantV1,
	prepareStableIDOrdinals bool,
	allowLiveRecovery bool,
) (*VectorPartitionLocalSearcherV1, error) {
	return c.openVectorPartitionLocalSearcherForPreparedAssetsWithSourceModeV1(
		ctx, index, generation, partition, indexDefinitionDigest, sourceGeneration,
		sourceChecksum, sourceSchemaHash, sourceRowCount, asset, assetGroup, members,
		home, overlap, allowOfflineNative, expectedGraphVariant,
		prepareStableIDOrdinals, allowLiveRecovery, false,
	)
}

// skipLocalSource is available only through the scoped immutable owner opener.
// The ordinary prepared/live/offline openers always verify the local source.
func (c *Collection) openVectorPartitionLocalSearcherForPreparedAssetsWithSourceModeV1(
	ctx context.Context,
	index string,
	generation uint64,
	partition uint32,
	indexDefinitionDigest string,
	sourceGeneration uint64,
	sourceChecksum uint64,
	sourceSchemaHash uint64,
	sourceRowCount uint64,
	asset *VectorPartitionAssetV1,
	assetGroup []VectorPartitionAssetV1,
	members []vectorPartitionMembershipSourceV1,
	home int,
	overlap int,
	allowOfflineNative bool,
	expectedGraphVariant VectorPartitionLocalGraphVariantV1,
	prepareStableIDOrdinals bool,
	allowLiveRecovery bool,
	skipLocalSource bool,
) (*VectorPartitionLocalSearcherV1, error) {
	if skipLocalSource && (allowLiveRecovery || allowOfflineNative || prepareStableIDOrdinals) {
		return nil, fmt.Errorf("%w: scoped source mode cannot use recovery or offline options", ErrVectorPartitionSearchUnavailable)
	}
	def, ok := findVectorIndex(c.meta.VectorIndexes, index)
	if !ok || indexDefinitionDigest != VectorIndexDefinitionDigestV1(def) || def.Metric != VectorMetricCosine || def.Encoding != VectorIndexEncodingFloat32 {
		return nil, fmt.Errorf("%w: stale index definition", ErrVectorPartitionSearchUnavailable)
	}
	if asset == nil || asset.Ref.Kind != ColumnAssetKindTCS1HNSWSearchPack || asset.Ref.Generation != generation || asset.Ref.PartID != uint64(partition)+1 || asset.Ref.Length > vectorPartitionSearchAssetMaxBytesV1 || asset.Ref.Length <= 0 {
		return nil, fmt.Errorf("%w: missing or stale partition asset", ErrVectorPartitionSearchUnavailable)
	}
	expectedMembershipDigest, err := decodeVectorPartitionMembershipDigestV1(asset.MembershipDigest)
	if err != nil {
		return nil, err
	}
	var sourceReader *columnVectorGraphPhysicalRowReader
	var sourceErr error
	if !skipLocalSource {
		sourceReader, sourceErr = c.openColumnVectorGraphPhysicalRowReader(index, columnVectorGraphPhysicalRowReaderOptions{})
		if sourceErr == nil && (sourceReader.graph.BaseManifestGeneration != sourceGeneration ||
			sourceReader.graph.BaseManifestChecksum != sourceChecksum || sourceReader.graph.BaseSchemaHash != sourceSchemaHash ||
			uint64(sourceReader.graph.RowCount) != sourceRowCount) {
			_ = sourceReader.Close()
			sourceReader = nil
			sourceErr = ErrVectorIndexSnapshotMismatch
		}
	}
	liveRecovery := sourceErr != nil && allowLiveRecovery
	if sourceErr != nil && !liveRecovery {
		return nil, fmt.Errorf("%w: membership source reader: %v", ErrVectorPartitionSearchUnavailable, sourceErr)
	}
	var recomputedMembershipDigest [sha256.Size]byte
	if !liveRecovery && !skipLocalSource {
		digestErr := error(nil)
		recomputedMembershipDigest, digestErr = vectorPartitionMembershipDigestWithContextV1(ctx, sourceReader, generation, partition, members)
		closeErr := sourceReader.Close()
		if digestErr != nil || closeErr != nil {
			if errors.Is(digestErr, context.Canceled) || errors.Is(digestErr, context.DeadlineExceeded) {
				return nil, digestErr
			}
			return nil, fmt.Errorf("%w: membership identity: %v", ErrVectorPartitionSearchUnavailable, errors.Join(digestErr, closeErr))
		}
	}
	graphVariant := VectorPartitionLocalGraphVariantV1(asset.GraphVariant)
	if _, err := VectorPartitionLocalGraphVariantIdentityV1(graphVariant); err != nil {
		return nil, fmt.Errorf("%w: asset graph variant=%q", ErrVectorPartitionSearchUnavailable, asset.GraphVariant)
	}
	if expectedGraphVariant != "" && graphVariant != expectedGraphVariant {
		return nil, fmt.Errorf("%w: offline graph variant=%s want=%s", ErrVectorPartitionSearchUnavailable, graphVariant, expectedGraphVariant)
	}
	if !allowOfflineNative && graphVariant != vectorPartitionLocalDefaultGraphVariantV1 {
		return nil, fmt.Errorf("%w: noncanonical production graph variant=%s", ErrVectorPartitionSearchUnavailable, graphVariant)
	}
	packDef, expectAuxiliaryNavigation, err := vectorPartitionLocalGraphVariantDefinitionV1(def, graphVariant)
	if err != nil {
		return nil, fmt.Errorf("%w: graph variant definition: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	if !liveRecovery && !skipLocalSource && vectorPartitionLocalGraphVariantMembershipDigestV1(recomputedMembershipDigest, graphVariant) != expectedMembershipDigest {
		return nil, fmt.Errorf("%w: descriptor membership digest mismatch", ErrVectorPartitionSearchUnavailable)
	}
	namespace := c.meta.Options.ColumnStore.AssetManager.Namespace
	if len(assetGroup) == 0 {
		assetGroup = []VectorPartitionAssetV1{*asset}
	}
	if err := verifyVectorPartitionAssetsWithContextV1(ctx, c.db.ColumnAssetRootDir(), namespace, assetGroup); err != nil {
		if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
			return nil, err
		}
		return nil, fmt.Errorf("%w: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	var packBytes uint64
	for _, part := range assetGroup {
		if part.PartitionID != partition || part.Ref.Kind != ColumnAssetKindTCS1HNSWSearchPack || part.Ref.Generation != generation || part.Ref.PartID != uint64(partition)+1 || part.Ref.Length <= 0 || part.Ref.Length > vectorPartitionSearchAssetMaxBytesV1 || uint64(part.Ref.Length) > ^uint64(0)-packBytes {
			return nil, fmt.Errorf("%w: chunk asset identity", ErrVectorPartitionSearchUnavailable)
		}
		packBytes += uint64(part.Ref.Length)
	}
	manager := mappedresource.NewManager()
	packVersion := columnHNSWSearchPackVersionV2
	if expectAuxiliaryNavigation {
		packVersion = columnHNSWSearchPackVersionV3
	} else if graphVariant == VectorPartitionLocalGraphVariantConnectivityPreservingVamanaR64L256Alpha1_2V1 {
		packVersion = columnHNSWSearchPackVersionV6
	} else if graphVariant == VectorPartitionLocalGraphVariantCanonicalHNSWM18EfConstruction256V1 {
		packVersion = columnHNSWSearchPackVersionV5
	}
	acquire := func(part VectorPartitionAssetV1) (*mappedresource.Handle, error) {
		path, err := columnAssetSegmentPath(c.db.ColumnAssetRootDir(), part.Ref)
		if err != nil {
			return nil, err
		}
		key := mappedresource.Key{Class: mappedresource.ClassTypedColumnAsset, Namespace: part.Ref.Namespace, Kind: string(part.Ref.Kind), Generation: part.Ref.Generation, PartID: part.Ref.PartID, FileID: part.Ref.FileID, Offset: part.Ref.Offset, Length: part.Ref.Length, Checksum: uint64(part.Ref.Checksum), Version: packVersion, Encoding: columnVectorIndexStateEncodingHNSWSearchPackV1, Section: mappedresource.Section{Kind: string(columnVectorIndexStateAssetRoleHNSWSearchPack), Category: string(ColumnAssetKindTCS1HNSWSearchPack), Name: part.ID}}
		return manager.AcquireFileRange(key, mappedresource.Scope{Kind: mappedresource.ScopePreparedSearch, ID: "vector_partition/" + strconv.FormatUint(generation, 10), Collection: c.name, Namespace: part.Ref.Namespace, Generation: generation, Reason: "vector partition native HNSW"}, path, mappedresource.AcquireOptions{Reason: "vector partition native HNSW", ValidationMode: mappedresource.ValidationVerify, PreferMapped: true, AllowHeapCopy: true, ResourceRoot: c.db.ColumnAssetRootDir(), ResourcePath: path})
	}
	openStarted := time.Now()
	h, err := acquire(*asset)
	if err != nil {
		return nil, err
	}
	if err := ctx.Err(); err != nil {
		_ = h.Release()
		return nil, err
	}
	decodeOpts := columnHNSWSearchPackDecodeOptions{ExpectedBaseIdentity: columnHNSWSearchPackBaseIdentity{ManifestGeneration: sourceGeneration, ManifestChecksum: sourceChecksum, SchemaHash: sourceSchemaHash}, ExpectedMembershipDigest: expectedMembershipDigest}
	var view *columnHNSWSearchPackPreparedView
	if len(assetGroup) == 1 {
		view, err = newColumnHNSWSearchPackPreparedViewFromHandle(manager, h, decodeOpts)
	} else {
		rootRaw := h.Bytes()
		if len(rootRaw) < columnHNSWSearchPackHeaderSizeV2 {
			err = errors.New("chunked root header")
		} else {
			metadata, _, decodeErr := decodeColumnHNSWSearchPackEnvelopeMetadataWithContext(ctx, rootRaw, hnswPackU64(rootRaw, columnHNSWSearchPackHeaderTotalLengthOffset), decodeOpts, false)
			if decodeErr != nil {
				err = decodeErr
			} else {
				type chunkAsset struct {
					ordinal uint32
					asset   VectorPartitionAssetV1
				}
				bySection := make(map[columnHNSWSearchPackSectionKey][]chunkAsset, len(metadata.Sections))
				for _, part := range assetGroup {
					if part.ID == asset.ID {
						continue
					}
					key, ordinal, parseErr := parseVectorPartitionLocalSectionChunkAssetIDV1(partition, part.ID)
					if parseErr != nil {
						err = parseErr
						break
					}
					bySection[key] = append(bySection[key], chunkAsset{ordinal: ordinal, asset: part})
				}
				sectionHandles := make(map[columnHNSWSearchPackSectionKey][]*mappedresource.Handle, len(metadata.Sections))
				expected := make(map[columnHNSWSearchPackSectionKey]struct{}, len(metadata.Sections))
				for _, section := range metadata.Sections {
					if err != nil {
						break
					}
					key := columnHNSWSearchPackSectionKey{kind: section.Kind, index: section.Index}
					expected[key] = struct{}{}
					parts := bySection[key]
					if section.Length == 0 {
						if len(parts) != 0 {
							err = fmt.Errorf("unexpected empty-section chunk %s[%d]", section.Kind, section.Index)
						}
						continue
					}
					if len(parts) == 0 {
						err = fmt.Errorf("missing chunk %s[%d]", section.Kind, section.Index)
						break
					}
					sort.Slice(parts, func(i, j int) bool { return parts[i].ordinal < parts[j].ordinal })
					for i, part := range parts {
						if part.ordinal != uint32(i) {
							err = fmt.Errorf("noncanonical chunk sequence %s[%d]", section.Kind, section.Index)
							break
						}
						sectionHandle, acquireErr := acquire(part.asset)
						if acquireErr != nil {
							err = acquireErr
							break
						}
						sectionHandles[key] = append(sectionHandles[key], sectionHandle)
					}
				}
				if err == nil {
					for key := range bySection {
						if _, ok := expected[key]; !ok {
							err = fmt.Errorf("unexpected chunk section %s[%d]", key.kind, key.index)
							break
						}
					}
				}
				if err == nil {
					view, err = newColumnHNSWSearchPackPreparedViewFromSectionHandlesWithContext(ctx, manager, h, sectionHandles, decodeOpts)
				}
				if err != nil {
					for _, handles := range sectionHandles {
						for _, sectionHandle := range handles {
							_ = sectionHandle.Release()
						}
					}
				}
			}
		}
	}
	if err != nil {
		_ = h.Release()
		return nil, fmt.Errorf("%w: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	if view.Header.Version != packVersion || view.Header.Rows != len(members) || home < 0 || overlap < 0 || home+overlap != len(members) || view.Header.Dimensions != packDef.Dimensions || view.Header.M != packDef.M || view.Header.EfConstruction != packDef.EfConstruction || view.Header.EfSearch != packDef.EfSearch || view.Header.HasAuxiliaryNavigation != expectAuxiliaryNavigation {
		_ = view.Close()
		return nil, ErrVectorPartitionSearchUnavailable
	}
	if err := ctx.Err(); err != nil {
		_ = view.Close()
		return nil, err
	}
	openNanos := time.Since(openStarted).Nanoseconds()
	if openNanos < 1 {
		openNanos = 1
	}
	view.openNanos = uint64(openNanos)
	maxStableIDBytes, err := vectorPartitionPreparedMaxStableIDBytesV1(view)
	if err != nil {
		_ = view.Close()
		return nil, fmt.Errorf("%w: stable ID bounds", ErrVectorPartitionSearchUnavailable)
	}
	var stableIDOrdinals map[string]int
	var stableIDOrdinalBytes uint64
	if prepareStableIDOrdinals {
		stableIDOrdinals, err = vectorPartitionPreparedStableIDOrdinalsV1(view)
		if err != nil {
			_ = view.Close()
			return nil, fmt.Errorf("%w: stable ID ordinals", ErrVectorPartitionSearchUnavailable)
		}
		// Charge two conservative 64-byte map buckets per entry in addition to
		// the key backing bytes. This bounds bucket, overflow, and load-factor
		// overhead without depending on runtime internals.
		stableIDOrdinalBytes = uint64(len(stableIDOrdinals)) * 128
		for id := range stableIDOrdinals {
			stableIDOrdinalBytes += uint64(len(id))
		}
	}
	// Every section chunk has already been acquired, checksum-verified and
	// semantically validated by the successful prepared-view open.
	sectionChunks := uint64(len(assetGroup) - 1)
	s := &VectorPartitionLocalSearcherV1{asset: VectorPartitionSearchAssetV1{Generation: generation, PartitionID: partition, Dimensions: view.Header.Dimensions}, prepared: view, opened: 1, homeMemberships: home, overlapMemberships: overlap, packBytes: packBytes, mappedBytes: view.mappedBytes, heapBytes: view.heapCopyBytes + view.chunkMetaBytes, sectionChunks: sectionChunks, openNanos: view.openNanos, searchRoute: VectorPartitionSearchRouteHNSWSearchPackV1, maxStableIDBytes: maxStableIDBytes, stableIDOrdinals: stableIDOrdinals, stableIDOrdinalBytes: stableIDOrdinalBytes}
	return s, nil
}

func vectorPartitionNativePackShapeV1(rows, dimensions, degree int) (int, error) {
	if rows < 1 || rows > 1_000_000 || dimensions < 1 || dimensions > 4096 || degree < 1 {
		return 0, fmt.Errorf("%w: native pack shape cap", ErrVectorPartitionSearchUnavailable)
	}
	stride, err := columnHNSWSearchPackVectorStrideForDimensions(dimensions)
	if err != nil {
		return 0, fmt.Errorf("%w: native pack stride: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	return stride, nil
}

func preflightVectorPartitionNativePackV1(rows, dimensions, degree int) error {
	stride, err := vectorPartitionNativePackShapeV1(rows, dimensions, degree)
	if err != nil {
		return err
	}
	// Reject impossible unsplit packs before allocating rows, normalized vectors,
	// or adjacency. Encoding performs the exact check after IDs/topology are known.
	perRow := int64(stride)*4 + 2 + 8*6
	if degree <= math.MaxInt/2 {
		perRow += int64(degree*2) * 4
	}
	if int64(rows) > vectorPartitionSearchAssetMaxBytesV1/perRow {
		return fmt.Errorf("%w: native pack byte cap", ErrVectorPartitionSearchUnavailable)
	}
	return nil
}

func preflightVectorPartitionChunkedNativePackV1(rows, dimensions, degree int) error {
	stride, err := vectorPartitionNativePackShapeV1(rows, dimensions, degree)
	if err != nil {
		return err
	}
	// Domain packs split fixed-width planes at row boundaries. Only one row is
	// indivisible here; the splitter owns each emitted asset's size limit.
	if int64(stride)*4 > vectorPartitionSearchAssetMaxBytesV1 {
		return fmt.Errorf("%w: native pack byte cap", ErrVectorPartitionSearchUnavailable)
	}
	return nil
}

func preflightVectorPartitionNativePackKnownBytesV1(rows, dimensions int, documentIDBytes uint64, capBytes int64) error {
	// A single layer with no encoded neighbors is the smallest valid topology.
	// The exact pass after graph construction still owns the final layer and
	// adjacency counts; this pass only proves the already-known native lower bound.
	_, err := exactVectorPartitionLocalGraphPackBytesV1(rows, dimensions, []uint64{0}, documentIDBytes, 0, false, capBytes)
	return err
}

func exactVectorPartitionNativePackBytesV1(rows, dimensions int, neighborCounts []uint64, documentIDBytes uint64, capBytes int64) (int64, error) {
	return exactVectorPartitionLocalGraphPackBytesV1(rows, dimensions, neighborCounts, documentIDBytes, 0, false, capBytes)
}

func exactVectorPartitionLocalGraphPackBytesV1(rows, dimensions int, neighborCounts []uint64, documentIDBytes, auxiliaryNeighbors uint64, hasAuxiliaryNavigation bool, capBytes int64) (int64, error) {
	if _, err := vectorPartitionNativePackShapeV1(rows, dimensions, 1); err != nil {
		return 0, err
	}
	if len(neighborCounts) < 1 || len(neighborCounts) > int(columnHNSWSearchPackMaxLayersDefault) || capBytes <= 0 {
		return 0, fmt.Errorf("%w: native pack topology cap", ErrVectorPartitionSearchUnavailable)
	}
	stride, err := columnHNSWSearchPackVectorStrideForDimensions(dimensions)
	if err != nil {
		return 0, fmt.Errorf("%w: native pack stride: %v", ErrVectorPartitionSearchUnavailable, err)
	}
	mul := func(a, b uint64) (uint64, error) {
		if a != 0 && b > ^uint64(0)/a {
			return 0, fmt.Errorf("%w: native pack size overflow", ErrVectorPartitionSearchUnavailable)
		}
		return a * b, nil
	}
	add := func(a, b uint64) (uint64, error) {
		if b > ^uint64(0)-a {
			return 0, fmt.Errorf("%w: native pack size overflow", ErrVectorPartitionSearchUnavailable)
		}
		return a + b, nil
	}
	sectionCount := uint64(8 + 2*len(neighborCounts))
	if hasAuxiliaryNavigation {
		sectionCount += 2
	}
	directoryBytes, err := mul(sectionCount, uint64(columnHNSWSearchPackSectionEntrySize))
	if err != nil {
		return 0, err
	}
	offset, err := add(uint64(columnHNSWSearchPackHeaderSizeV2), directoryBytes)
	if err != nil {
		return 0, err
	}
	offset, ok := alignColumnHNSWSearchPackUint64(offset, uint64(columnHNSWSearchPackAlignment))
	if !ok {
		return 0, fmt.Errorf("%w: native pack size overflow", ErrVectorPartitionSearchUnavailable)
	}
	appendSection := func(length uint64, alignment uint32) error {
		aligned, ok := alignColumnHNSWSearchPackUint64(offset, uint64(alignment))
		if !ok {
			return fmt.Errorf("%w: native pack size overflow", ErrVectorPartitionSearchUnavailable)
		}
		offset, err = add(aligned, length)
		return err
	}
	rowCount := uint64(rows)
	vectorValues, err := mul(rowCount, uint64(stride))
	if err != nil {
		return 0, err
	}
	vectorBytes, err := mul(vectorValues, 4)
	if err != nil {
		return 0, err
	}
	if err := appendSection(vectorBytes, columnHNSWSearchPackVectorSectionAlignment); err != nil {
		return 0, err
	}
	levelBytes, err := mul(rowCount, 2)
	if err != nil {
		return 0, err
	}
	if err := appendSection(levelBytes, columnHNSWSearchPackAlignment); err != nil {
		return 0, err
	}
	offsetRows, err := add(rowCount, 1)
	if err != nil {
		return 0, err
	}
	adjacencyOffsetBytes, err := mul(offsetRows, 8)
	if err != nil {
		return 0, err
	}
	for _, neighbors := range neighborCounts {
		if err := appendSection(adjacencyOffsetBytes, columnHNSWSearchPackAlignment); err != nil {
			return 0, err
		}
		neighborBytes, err := mul(neighbors, 4)
		if err != nil {
			return 0, err
		}
		if err := appendSection(neighborBytes, columnHNSWSearchPackAlignment); err != nil {
			return 0, err
		}
	}
	if hasAuxiliaryNavigation {
		if err := appendSection(adjacencyOffsetBytes, columnHNSWSearchPackAlignment); err != nil {
			return 0, err
		}
		auxiliaryNeighborBytes, err := mul(auxiliaryNeighbors, 4)
		if err != nil {
			return 0, err
		}
		if err := appendSection(auxiliaryNeighborBytes, columnHNSWSearchPackAlignment); err != nil {
			return 0, err
		}
	}
	rowRefBytes, err := mul(rowCount, 8)
	if err != nil {
		return 0, err
	}
	for section := 0; section < 4; section++ {
		if err := appendSection(rowRefBytes, columnHNSWSearchPackAlignment); err != nil {
			return 0, err
		}
	}
	if err := appendSection(adjacencyOffsetBytes, columnHNSWSearchPackAlignment); err != nil {
		return 0, err
	}
	if err := appendSection(documentIDBytes, columnHNSWSearchPackAlignment); err != nil {
		return 0, err
	}
	if offset > uint64(capBytes) || offset > uint64(math.MaxInt64) {
		return 0, fmt.Errorf("%w: native pack byte cap exact=%d cap=%d", ErrVectorPartitionSearchUnavailable, offset, capBytes)
	}
	return int64(offset), nil
}

func vectorPartitionRemappedNeighborCountV1(neighbors []uint32, ordToLocal map[int]int, self int) int {
	seen := make(map[int]struct{}, len(neighbors))
	for _, neighbor := range neighbors {
		if local, ok := ordToLocal[int(neighbor)]; ok && local != self {
			seen[local] = struct{}{}
		}
	}
	return len(seen)
}

func vectorPartitionSourceMaxLayerV1(reader *columnVectorGraphPhysicalRowReader, ordinal int) (int, error) {
	if reader != nil && reader.preparedSearch != nil {
		maxLayer, _, err := reader.preparedSearch.maxAdjacencyLayerForOrdinal(ordinal)
		return maxLayer, err
	}
	if reader != nil {
		if maxLayer, _, _, _, ok := reader.maxDirectAdjacencyLayerForOrdinal(ordinal); ok {
			return maxLayer, nil
		}
		row, err := reader.FetchRow(ordinal, &columnPhysicalRowReaderScratch{})
		if err == nil {
			return columnVectorGraphAdjacencyMaxLayer(row.Adjacency)
		}
	}
	return 0, errors.New("authoritative source adjacency unavailable")
}

func vectorPartitionSourceAdjacencyLayerV1(reader *columnVectorGraphPhysicalRowReader, ordinal, layer int) ([]uint32, error) {
	if reader != nil && reader.preparedSearch != nil {
		neighbors, _, err := reader.preparedSearch.adjacencyLayerForOrdinal(ordinal, layer)
		return neighbors, err
	}
	if reader != nil {
		if neighbors, _, reason, ok := reader.directAdjacencyLayerForOrdinal(ordinal, layer); ok {
			return neighbors, nil
		} else if reason != "" {
			// Fall through to the legacy row only when the direct source does
			// not own this topology shape.
		}
		row, err := reader.FetchRow(ordinal, &columnPhysicalRowReaderScratch{})
		if err == nil {
			return columnVectorGraphAdjacencyLayer(row.Adjacency, layer)
		}
	}
	return nil, errors.New("authoritative source adjacency unavailable")
}

func remapVectorPartitionAdjacencyV1(source []uint32, ordToLocal map[int]int, self int) ([]uint32, error) {
	remapLayer := func(neighbors []uint32) []uint32 {
		out := make([]uint32, 0, len(neighbors))
		for _, neighbor := range neighbors {
			if local, ok := ordToLocal[int(neighbor)]; ok && local != self {
				out = append(out, uint32(local))
			}
		}
		sort.Slice(out, func(a, b int) bool { return out[a] < out[b] })
		return compactPartitionAdjacencyV1(out)
	}
	if !columnVectorGraphAdjacencyIsLayered(source) {
		return remapLayer(source), nil
	}
	maxLayer, err := columnVectorGraphAdjacencyMaxLayer(source)
	if err != nil {
		return nil, err
	}
	out := []uint32{columnVectorGraphLayeredAdjacencyMagic, uint32(maxLayer)}
	for layer := 0; layer <= maxLayer; layer++ {
		neighbors, err := columnVectorGraphAdjacencyLayer(source, layer)
		if err != nil {
			return nil, err
		}
		remapped := remapLayer(neighbors)
		out = append(out, uint32(len(remapped)))
		out = append(out, remapped...)
	}
	return out, nil
}

func vectorPartitionSourceAdjacencyV1(reader *columnVectorGraphPhysicalRowReader, ordinal int, legacy []uint32, legacyAvailable bool) ([]uint32, error) {
	encodeLayers := func(maxLayer int, layer func(int) ([]uint32, error)) ([]uint32, error) {
		if maxLayer < 0 {
			return nil, errors.New("negative source adjacency layer")
		}
		out := []uint32{columnVectorGraphLayeredAdjacencyMagic, uint32(maxLayer)}
		for current := 0; current <= maxLayer; current++ {
			neighbors, err := layer(current)
			if err != nil {
				return nil, err
			}
			out = append(out, uint32(len(neighbors)))
			out = append(out, neighbors...)
		}
		return out, nil
	}
	if reader != nil && reader.preparedSearch != nil {
		maxLayer, _, err := reader.preparedSearch.maxAdjacencyLayerForOrdinal(ordinal)
		if err != nil {
			return nil, err
		}
		return encodeLayers(maxLayer, func(layer int) ([]uint32, error) {
			neighbors, _, err := reader.preparedSearch.adjacencyLayerForOrdinal(ordinal, layer)
			return neighbors, err
		})
	}
	if reader != nil {
		if maxLayer, _, _, _, ok := reader.maxDirectAdjacencyLayerForOrdinal(ordinal); ok {
			return encodeLayers(maxLayer, func(layer int) ([]uint32, error) {
				neighbors, _, reason, ok := reader.directAdjacencyLayerForOrdinal(ordinal, layer)
				if !ok {
					return nil, fmt.Errorf("direct source adjacency layer %d unavailable reason=%s", layer, reason)
				}
				return neighbors, nil
			})
		}
	}
	if legacyAvailable {
		return append([]uint32(nil), legacy...), nil
	}
	return nil, errors.New("authoritative source adjacency unavailable")
}

// Private prepare-only option; ordinary public builders retain admission.
type vectorPartitionMaterializeOwnerV1 struct {
	fresh bool
	owner *CommandWALAdmittedCollection
}
