# Native service write architecture reassessment

Read-only source/artifact decision, 2026-10-26. No Go, tests, profiles, workload, source change, or GitHub action. Source HEAD `550a813d8421e149e50480c8801f08fe8b9e77c8`; the source hashes below bind the actual files, independently of selected dirty packets or later root changes. Historical graph files are local issue snapshots, not a claim of current hosted state.

## Decision

**Pause native document-service default promotion and choose the parent adoption boundary before another implementation or benchmark.** Keep the maintained service owner as a truthful compatibility/default candidate while native semantic/typed-column service publication remains explicitly performance-blocked. This is a graph simplification proposal, not a passed native gate, a statement that legacy already uses COW, or permission to label ordinary service users specialized without saying so.

The core request and the chosen native typed implementation are distinguishable. The stored parent outcome requires shared COW collections for Mongo and named general consumers; it expressly permits reconsidering publication/integration decisions and explicit reviewed dispositions. It does not require this native typed ColumnGraph representation. Its named document-service adoption obligation nonetheless remains: assigning the maintained backend owner is a deliberate disposition/change of that obligation, not universal COW adoption. Root should affirmatively record which default is delivered, which native service capability is opt-in/unselected, and which real COW adoption obligation remains. Mongo/plain delivered evidence cannot be relabeled as service evidence.

**Current source does not offer 'ordinary COW memtable plus unchanged backend collection publication' as a switch.** OpenBackendWithCachedLeafLog calls the backend-only cache role; public.go:1165–1170 changes requested cow_btree/cow_ordered to btree because backend-root writers already own logical publication. The non-backend role instead binds the private COW owner, native semantic bridge and original command-WAL completion. Removing that guard alone risks two publication authorities and does not route backend collection mutations through the COW memtable. A genuinely shared below-planner COW collection adapter could be a new integration direction, but requires a specified sole commit/read/ACK owner; it is not already proved by the legacy timings.

## What the retained results explain

Diagnostic3 has eight valid rows, no retries: native/legacy median request-load time is 9.6626 at one writer and 11.0154 at four; bytes 2.5406/3.2292; objects 3.7687/3.7489. Both arms actually resolve omitted cosine to **column_graph**, with 4096 rows, 32 calls of 128, deferred rebuild. Its source still deliberately defaults cosine/TypedInput to ColumnGraph (service.go:229–231). This is the actual ordinary caller, not an explicitly requested advanced physical mode. Scalar-state reuse reduces allocations but scarcely changes this wall gap.

The earlier source-bound trace reports 588.84 ms of 630.28 ms Upsert syscall delay below PrepareNativeProducerObservation, with overlapping flush/rotation/cleanup descendants; direct command completion is 41.08 ms. These are trace populations, not additive wall components and not a new exact attribution for diagnostic3. Existing sampled profiles include setup/Optimize/Close; synchronous Upsert ancestry also omits asynchronous worker work.

The source supplies a consequential cause: every native ordinary ColumnGraph batch attaches typed physical construction. Pending construction is independently finite and crosses the original maintenance pressure threshold; PrepareNativeProducerObservation then executes full Checkpoint and joins original cleanup. That includes physical materialization, canonical journal rotation/fences and resource closure, stronger than the individual durable request ACK. Materialization selects winners but builds each surviving member's intermediate manifest/locator/primary roots in original member order and closes/syncs/certifies its asset session. Unique insert batches cannot disappear through last-writer selection. Legacy durable ACK uses maintained buffered backend publication; its deferred graph work stays outside the request timer and is separately required by Optimize/reopen. Equal durable ACK correctness therefore does not imply equal physical work at the timer boundary.

A new service combiner or relaxed ACK is not selected: the original journal already owns durable completion/grouping, direct command completion is the smaller traced family, and combining requests must preserve independent request assignment, errors, dependencies and callbacks. It would not by itself remove finite typed construction debt. More scalar/parser/credit tweaks do not address this mechanism.

## Alternatives and one next proof

1. **Selected next action is a root-owned scope/authority decision, not another timed sample:** explicitly decide whether service default promotion is still required to use native semantic publication in this parent. If not, retain actual maintained service behavior and disclose its btree backend owner, preserve all native failures and keep native publication opt-in/independently gated. Reuse existing same-owner service/command continuity and durable tests to substantiate capability retention; do not claim those demonstrate COW for that service. Parent closure requires an affirmative disposition of this named consumer, not simply moving its unmet goal elsewhere.
2. If service COW adoption remains mandatory now, select a **below-planner single-owner integration design proof** before source construction: show one public 128-row service command can use the maintained scalar/text/vector planner with a COW prepared batch while exactly one authority owns assignment, journal replay, snapshot identity and durable ACK. The decisive public proof remains unchanged 4096/128, one/four writers, all responses once, same caps/durability, Optimize and exact fresh reopen. The existing backend-only mode guard is the causal activation witness: a prototype must actually remove that btree substitution by routing the writes, not by bypassing the guard. Current source does not establish that design, so no implementation or speed prediction is authorized by this inquiry.
3. Merely changing the service default to native_runtime is not a demonstrated shortcut. Collection native InsertBatch runs finishNativeHNSWMutation after canonical publication; service DeferVectorIndexRebuild does not suppress that reconciliation. The current service shared-deferred path is ColumnGraph-only; native_runtime re-enters exclusive service locking. Both facts must be addressed or explicitly measured in a separately declared algorithm choice. Existing persisted/explicit ColumnGraph, typed, normalized and quantized contracts must remain intact. Replacing CG in the old failed fixture would change the comparator rather than pass it.
4. If preserving native ColumnGraph itself is selected, the materially different next algorithm is one final physical primary/locator/manifest construction per captured graph-free span, retaining each member's original LSN/generation/row-locator authority and graph barriers. This removes repeated intermediate publication work rather than changing an appender Close. It is a larger shared typed-publication project with unproved peak/custody bounds; it should have an explicit owner/decision and cannot be represented as another small repair. Do not resume retired appender candidates 1/2: their combined metadata/root admission inequality was not established, and no public win was accepted.

No further profiling is required to establish that current native default performance is blocked. The existing trace justifies the architecture decision but cannot predict the improvement of a new integration. A source-authority proof is the next discriminator if the parent still requires that integration; otherwise the honest next proof is continuity of the deliberately retained default plus explicit unresolved native disposition.

## Retired worktree

This inquiry consumed only the immutable candidate1/2 evidence and current canonical source. It has **no current or future dependency on the retired native-cut-materialization1 worktree**. Root may verify inventory/unique data/refs and remove that checkout while preserving all unique evidence, patches, manifests and recoverable source refs. This is not authorization for this adviser to remove anything.

## Source and evidence binding

- `TreeDB/public.go`: `4835d9655694fbb5c87889af70ac6f67a883f10a62cf9e259bed84db32a14f89`
- `TreeDB/open_backend.go`: `c3154bc45586718e8c2ff448c0d49e2ee1aa2840ab1224beccacdf1eeb4354e3`
- `TreeDB/documentservice/service.go`: `260effeacc28075df89cc57be6811dbfd24ac67417c2128ce8e359944e1b3ee4`
- `TreeDB/documentservice/shared_cow_write_bench_test.go`: `dd6d7ebcb5638badbb938ba9891c557e51fe3e9c583fc1d679d4e8f02ec29263`
- `TreeDB/collections/native_existing.go`: `c3e9af37041e24c0647c37588b89a6eb20b7bb866c05c11533e85431d32b7a51`
- `TreeDB/collections/native_hnsw.go`: `0a550b29ac90946d4d1182dbc5cba9363c390794da403d8e6965f217f5764d95`
- `TreeDB/collections/native_typed_engine.go`: `84195e1eabde88232fd662ee3d3ac1ba304690fe85c446ab85e193351517deb8`
- `TreeDB/collections/native_typed_materialize.go`: `7673510c8d33ca80bfd9627220f2ec4da13e140a9326f65e0d7972f247f5e722`
- `TreeDB/caching/cow_native_txn.go`: `c93489418d3cd108394943955e04efea0cbc1a2c87734681963b1bb4e08079bb`
- `TreeDB/caching/cow_checkpoint.go`: `eb87c30b3469f1518c75a31a3887fb845c79736b1a408cf32fea6322b498ba6d`
- `evidence/current-feature-service-write-diagnostic3/result.json`: `1fa7614464c54188992c206150fa3c9eea09dccdedd0fadfddab6704c2bb01d3`
- `evidence/current-feature-service-write-failure-inquiry1/pressure-materialization.md`: `7b741523eae16cef97760f0bca5d469bcaebdd8357b9c54485255a3345ffe83e`
- `evidence/native-cut-materialization1/candidate2/proof.md`: `f9a602a79cdd55c1730a38eb61502bfd0ade8749deb223421fb6fa1cf3e571c8`
- `evidence/native-cut-materialization1/fixloop1/ledger-and-decision.md`: `66350972127ee047c7350c724d75c372f9de7678fff60ce36dc86af969e69d91`
- `graph/5225.md`: `de700424f1ea5f0c8af26570f902921d60392f12638ab663940958bd1fc13729`
- `graph/issue-5238-current.md`: `0795b98c182af859265ddf218d3b43d63ffbab35d4265ad12c5fe4028f27fd39`
