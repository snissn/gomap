package collections

import (
	"bytes"
	"os"
	"sync/atomic"
	"testing"

	treedb "github.com/snissn/gomap/TreeDB"
)

// This whole file uses only original public producers and existing observation
// seams. It is runnable on the original source: exact data/LSN/reopen remains
// correct there, while four surviving members require four content syncs.
func TestNativeTypedMaterializeCutPublicReopen(t *testing.T) {
	if !ordinaryColumnStableAuthorityEnabled() {
		t.Skip("stable relative namespace unavailable")
	}
	opts := nativeTypedGroupOptions(t.TempDir())
	owner, err := treedb.Open(opts)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if owner != nil {
			_ = owner.Close()
		}
	}()
	backend, err := owner.NativeSemanticBackend()
	if err != nil {
		t.Fatal(err)
	}
	manager := NewCollectionManager(backend)
	defer func() {
		if manager != nil {
			_ = manager.Close()
		}
	}()
	_, err = manager.CreateCollection(&CollectionMeta{Name: "docs", Options: CollectionOptions{DocumentFormat: DocumentFormatJSON, ColumnStore: &ColumnStoreConfig{
		Enabled: true, RetainedPayload: ColumnRetainedPayloadFull, RetainedPayloadEncoding: ColumnRetainedPayloadEncodingJSON,
		Columns: []ColumnStoreColumn{{Name: "embedding", Path: "embedding", ValueType: ColumnStoreValueFloat32Vector, VectorDims: 2, Owner: TypedStorageOwnerColumnPart}},
	}}, VectorIndexes: []VectorIndexDefinition{{Name: "vec", Field: "embedding", Dimensions: 2, Metric: VectorMetricCosine, Strategy: VectorIndexStrategyColumnGraph}}})
	if err != nil {
		t.Fatal(err)
	}
	col, err := manager.OpenCollection("docs")
	if err != nil {
		t.Fatal(err)
	}
	if err = owner.Checkpoint(); err != nil {
		t.Fatal(err)
	}
	insert := func(ids []string, docs []string) {
		t.Helper()
		keys, documents := make([][]byte, len(ids)), make([][]byte, len(docs))
		for i := range ids {
			keys[i], documents[i] = []byte(ids[i]), []byte(docs[i])
		}
		if _, _, e := col.InsertBatchWithStatsValidatedFloat32Projection(keys, documents, "embedding", VectorMetricCosine, func() [][]float32 {
			vectors := make([][]float32, len(ids))
			for i := range vectors {
				vectors[i] = []float32{1, 0}
			}
			return vectors
		}()); e != nil {
			t.Fatal(e)
		}
	}
	original := `{"embedding":[1,0],"content":"original"}`
	replacement := `{"embedding":[0,1],"content":"replacement"}`
	insert([]string{"a", "anchor"}, []string{original, original})
	insert([]string{"b"}, []string{original})
	if found, changed, e := col.Update([]byte("a"), func([]byte) ([]byte, bool, error) { return []byte(replacement), true, nil }); e != nil || !found || !changed {
		t.Fatalf("update: %t %t %v", found, changed, e)
	}
	if found, e := col.DeleteDocument([]byte("b")); e != nil || !found {
		t.Fatalf("delete: %t %v", found, e)
	}
	insert([]string{"c"}, []string{original})
	held, err := col.OpenCollectionReadView()
	if err != nil {
		t.Fatal(err)
	}
	defer held.Close()
	lastNext := backend.CommandWALNextLSN()
	var syncs atomic.Int64
	originalSync := syncColumnAssetSegmentFileForPublish
	syncColumnAssetSegmentFileForPublish = func(file *os.File) error { syncs.Add(1); return originalSync(file) }
	defer func() { syncColumnAssetSegmentFileForPublish = originalSync }()
	if err = owner.Checkpoint(); err != nil {
		t.Fatal(err)
	}
	if got := syncs.Load(); got != 1 {
		t.Fatalf("graph-free cut content syncs=%d want 1 for four surviving original members", got)
	}
	// No replacement command frame or reassigned member identity is allowed.
	if backend.CommandWALNextLSN() != lastNext {
		t.Fatal("physical cut changed command WAL identities")
	}
	assertRows := func() {
		t.Helper()
		for id, want := range map[string]string{"a": replacement, "anchor": original, "c": original} {
			got, e := col.Get([]byte(id))
			if e != nil || !bytes.Equal(got, []byte(want)) {
				t.Fatalf("%s: %s %v", id, got, e)
			}
		}
		if got, e := col.Get([]byte("b")); e == nil || len(got) != 0 {
			t.Fatalf("deleted b: %s %v", got, e)
		}
	}
	assertRows()
	old, err := held.FetchDocumentsByID([][]byte{[]byte("a"), []byte("anchor"), []byte("b"), []byte("c")}, DocumentFetchOptions{})
	if err != nil || len(old.Results) != 4 || !old.Results[0].Found || !bytes.Equal(old.Results[0].Document, []byte(replacement)) || !old.Results[1].Found || old.Results[2].Found || !old.Results[3].Found {
		t.Fatalf("held cut changed: %+v %v", old.Results, err)
	}
	if err = held.Close(); err != nil {
		t.Fatal(err)
	}
	syncColumnAssetSegmentFileForPublish = originalSync
	if err = manager.Close(); err != nil {
		t.Fatal(err)
	}
	manager = nil
	if err = owner.Close(); err != nil {
		t.Fatal(err)
	}
	owner = nil
	owner, err = treedb.Open(opts)
	if err != nil {
		t.Fatal(err)
	}
	backend, err = owner.NativeSemanticBackend()
	if err != nil {
		t.Fatal(err)
	}
	manager = NewCollectionManager(backend)
	col, err = manager.OpenCollection("docs")
	if err != nil {
		t.Fatal(err)
	}
	assertRows()
	if err = manager.Close(); err != nil {
		t.Fatal(err)
	}
	manager = nil
	if err = owner.Close(); err != nil {
		t.Fatal(err)
	}
	owner = nil
}
