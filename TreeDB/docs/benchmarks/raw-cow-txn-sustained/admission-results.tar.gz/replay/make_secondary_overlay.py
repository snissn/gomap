from pathlib import Path
import sys,json,subprocess
root=Path(sys.argv[1]).resolve()
stage=Path(sys.argv[2]).resolve()
subprocess.run([sys.executable,str(root/'TreeDB/docs/benchmarks/raw-cow-txn-sustained/make_capacity_overlay.py'),str(root),str(stage)],check=True)
manifest=stage/'overlay.json'
o=json.loads(manifest.read_text())['Replace']
def edit(rel, apply):
  src=str(root/rel)
  p=Path(o.get(src, str(stage/('extra-'+(root/rel).name))))
  p.write_text(apply(Path(o.get(src,src)).read_text()))
  o[src]=str(p)
def single(s,a,b):
  assert s.count(a)==1,(a,s.count(a))
  return s.replace(a,b,1)
def direct(s):
  start=s.index('func (db *DB) beginDirectWrite()')
  end=s.index('func (db *DB) beginDirectWriteWithFlushMuHeld()', start)
  t=s[start:end]
  pat='return memtable.ErrCOWCapacity'
  assert t.count(pat)==2
  t=t.replace(pat,'return diagnoseCOWRefusal("beginDirectWrite/refreshRequired", memtable.ErrCOWCapacity)')
  return s[:start]+t+s[end:]
def init(s):
  start=s.index('func (db *DB) initOwnedCOWTxn(')
  end=s.index('func (tx *ConditionalTxn) COWTransaction()',start)
  t=s[start:end]
  needle='return err'
  steps=['provider-preflight','begin-direct','journal','budget-lease','capture']
  assert t.count(needle)==6 # five plain returns and errors.Join
  for stageName in steps:
   before,index,t=t.partition(needle)
   assert index
   if stageName==steps[0]:
    parts=[]
   parts.append(before+'return diagnoseSecondary("InitOwned/'+stageName+'",err)')
  return s[:start]+''.join(parts)+t+s[end:]+'''
func diagnoseSecondary(site string, err error) error {
 if errors.Is(err, memtable.ErrCOWCapacity) {
  return diagnoseCOWRefusal(site, err)
 }
 return err
}
'''
def batch(s):
 start=s.index('func (b *Batch) admitCOWAccepted()')
 t=s[start:]
 t=single(t,'return err','return diagnoseSecondary("admitCOWAccepted/checkpoint",err)')
 t=single(t,'return acceptedAdmissionError(err)','return diagnoseSecondary("admitCOWAccepted/re-reserve",acceptedAdmissionError(err))')
 return s[:start]+t
def vacuum(s):
 s=single(s,'db.cow.refreshRequired.Store(true)','traceVacuum("before-set", automatic, nil)\n\tdb.cow.refreshRequired.Store(true)')
 s=single(s,'db.cow.refreshRequired.Store(false)','db.cow.refreshRequired.Store(false)\n\t\ttraceVacuum("cleared", automatic, nil)')
 # Deliberately limit ordinary repeated checkpoint output. The refusal logger emits all failed calls.
 return s+'''
func traceVacuum(stage string, automatic bool, err error) {
 if cowSecondaryVacuumTraces.Add(1) <= 6 {
  traceSecondaryVacuum(stage, automatic, err)
 }
}
'''
def helper(s):
 s=s.replace('traceFmt "fmt"','traceFmt "fmt"\n traceAtomic "sync/atomic"',1)
 return s+'''
var cowSecondaryVacuumTraces traceAtomic.Int64
func traceSecondaryVacuum(stage string, automatic bool, err error) {
 traceFmt.Fprintf(traceOS.Stderr, "CHECKPOINT_VACUUM %s automatic=%t err=%v\\n", stage, automatic, err)
}
'''
edit('TreeDB/caching/db.go',direct)
edit('TreeDB/caching/cow_txn.go',init)
edit('TreeDB/caching/cow_batch.go',batch)
edit('TreeDB/caching/cow_checkpoint.go',vacuum)
edit('TreeDB/caching/cow_accepted_prefix.go',helper)
manifest.write_text(json.dumps({'Replace':o},indent=2)+'\n')
