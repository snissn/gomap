from pathlib import Path
import json,sys
root,dest=map(lambda s:Path(s).resolve(),sys.argv[1:])
dest.mkdir()
repl={}
def edit(rel, transform):
    original=root/rel
    new=dest/Path(rel).name
    new.write_text(transform(original.read_text()))
    repl[str(original)]=str(new)

def here(s, old, new):
    assert s.count(old)==1, old
    return s.replace(old,new,1)

def writer(s):
    s=here(s,'\n\t"sync/atomic"','\n\t"sync"\n\t"sync/atomic"')
    old='''		w.fileSyncCalls.Add(1)
		if ns := time.Since(start).Nanoseconds(); ns > 0 {
			w.fileSyncNs.Add(uint64(ns))
		}'''
    new='''		w.fileSyncCalls.Add(1)
		if ns := time.Since(start).Nanoseconds(); ns > 0 {
			w.fileSyncNs.Add(uint64(ns))
			recordRawTxnDiagnosticSync(start, ns)
		}'''
    return here(s,old,new)+'''
// Overlay-only observation buffer. Timing is the original writer's actual sync
// duration, captured before we take this diagnostic mutex. No per-event I/O.
type RawTxnDiagnosticSync struct { Start time.Time; Ns int64 }

var rawTxnDiagnosticSyncMu sync.Mutex
var rawTxnDiagnosticSyncs []RawTxnDiagnosticSync
var rawTxnDiagnosticOverflow int

func StartRawTxnDiagnostic(max int) {
 rawTxnDiagnosticSyncMu.Lock()
 defer rawTxnDiagnosticSyncMu.Unlock()
 rawTxnDiagnosticOverflow = 0
 rawTxnDiagnosticSyncs = make([]RawTxnDiagnosticSync, 0, max)
}

func StopRawTxnDiagnostic() ([]RawTxnDiagnosticSync, int) {
 rawTxnDiagnosticSyncMu.Lock()
 defer rawTxnDiagnosticSyncMu.Unlock()
 spans := rawTxnDiagnosticSyncs
 rawTxnDiagnosticSyncs = nil
 return spans,rawTxnDiagnosticOverflow
}

func recordRawTxnDiagnosticSync(start time.Time, ns int64) {
 rawTxnDiagnosticSyncMu.Lock()
 defer rawTxnDiagnosticSyncMu.Unlock()
 if rawTxnDiagnosticSyncs == nil { return }
 if len(rawTxnDiagnosticSyncs) == cap(rawTxnDiagnosticSyncs) { rawTxnDiagnosticOverflow++; return }
 rawTxnDiagnosticSyncs = append(rawTxnDiagnosticSyncs,RawTxnDiagnosticSync{start,ns})
}
'''
def public(s):
    assert '"github.com/snissn/gomap/TreeDB/internal/commitlog"' in s
    return s+'''
// Overlay-only diagnostic adapters; never part of the candidate source.
type RawTxnDiagnosticSync = commitlog.RawTxnDiagnosticSync
func StartRawTxnDiagnostic(max int) { commitlog.StartRawTxnDiagnostic(max) }
func StopRawTxnDiagnostic() ([]RawTxnDiagnosticSync,int) { return commitlog.StopRawTxnDiagnostic() }
'''

def driver(s):
    s=here(s,'CommitNS int64 `json:"commit_ns"`','CommitNS int64 `json:"commit_ns"`\n diagCommitStart,diagCommitEnd time.Time')
    s=here(s,'p.CommitNS += time.Since(start).Nanoseconds()', """p.diagCommitStart = start
        p.diagCommitEnd = time.Now()
        p.CommitNS += p.diagCommitEnd.Sub(start).Nanoseconds()""")
    s=here(s,'\tout.Clients = make([]clientReceipt, c.Clients)', '''	if c.Clients != 1 { return out, errors.New("attribution overlay requires one foreground client") }
	diagnosticRows := make([]diagTxn,0,c.OpsPerClient)
	out.Clients = make([]clientReceipt, c.Clients)''')
    s=here(s,'\t\t\t\tstarted := time.Now()\n','\t\t\t\tstarted := time.Now()\n\t\t\t\tvar diagnosticPhase phaseTotals\n')
    s=here(s,'e := attemptTransfer(db, pair.a, pair.z, cr.Phases)','e := attemptTransfer(db, pair.a, pair.z, &diagnosticPhase)')
    s=here(s,'cr.latencies = append(cr.latencies, time.Since(started).Nanoseconds())','''ended := time.Now()
						cr.latencies = append(cr.latencies, ended.Sub(started).Nanoseconds())
						diagnosticRows = append(diagnosticRows,diagTxn{start:started,end:ended,p:diagnosticPhase})''')
    s=here(s,'\tbegin := time.Now()\n\tout.ForegroundStart', '\ttreedb.StartRawTxnDiagnostic(c.OpsPerClient+4096)\n\tbegin := time.Now()\n\tout.ForegroundStart')
    s=here(s,'\tend := time.Now()\n\tout.ForegroundEnd', '\tend := time.Now()\n\tfsyncs,overflow:=treedb.StopRawTxnDiagnostic()\n\tout.ForegroundEnd')
    s=here(s,'\tout.AutoInWindow = observedAuto(out)\n','''	out.AutoInWindow = observedAuto(out)
	if err := writeDiagnosticSyncSummary(diagnosticRows, fsyncs, overflow); err != nil { return out,err }
''')
    return s+'''
type diagTxn struct {
 start,end time.Time
 p phaseTotals
}

func writeDiagnosticSyncSummary(rows []diagTxn, spans []treedb.RawTxnDiagnosticSync, overflow int) error {
 if overflow != 0 { return fmt.Errorf("diagnostic overflow: %d",overflow) }
 slices.SortFunc(spans,func(a,b treedb.RawTxnDiagnosticSync) int {
  return a.Start.Compare(b.Start)
 })
 nums := make(map[string][]int64)
 topSync, topTotal, topResidual := []int64{},[]int64{},[]int64{}
 allSeq := make([][3]int64,0,len(rows))
 dropped,idx:=0,0
 drops:=map[string]int{}
 tailCounts := map[string]int{}
 full:=make([]int64,0,len(rows))
 for _,row:=range rows { full=append(full,row.end.Sub(row.start).Nanoseconds()) }
 slices.Sort(full)
 p99,p999:=percentile(full,990),percentile(full,999)
 for _,row:=range rows {
  elapsed:=row.end.Sub(row.start).Nanoseconds()
  for idx<len(spans) && !spans[idx].Start.Add(time.Duration(spans[idx].Ns)).After(row.start) { idx++ }
  n,ns,cross,inCommit:=0,int64(0),false,false
  for j:=idx; j<len(spans)&&spans[j].Start.Before(row.end);j++{
   end:=spans[j].Start.Add(time.Duration(spans[j].Ns))
   if spans[j].Start.Before(row.start)||end.After(row.end){cross=true;continue}
   n++;ns+=spans[j].Ns
   inCommit=!spans[j].Start.Before(row.p.diagCommitStart)&&!end.After(row.p.diagCommitEnd)
  }
  why:=""
  if cross { why="crosses_logical_window" } else if n==0 { why="zero_inside_logical_window" } else if n>1 { why="multiple_inside_logical_window" } else if !inCommit { why="outside_commit_window" }
  if elapsed >= p99 { tailCounts["p99_all"]++; if why=="" { tailCounts["p99_matched"]++ } }
  if elapsed >= p999 { tailCounts["p99_9_all"]++; if why=="" { tailCounts["p99_9_matched"]++ } }
  if why!="" { dropped++; drops[why]++; continue }
  absorbed:=elapsed-ns
  allSeq=append(allSeq,[3]int64{elapsed,ns,absorbed})
  for k,v:=range map[string]int64{"total":elapsed,"true_sync":ns,"outside_sync":absorbed,
    "begin":row.p.BeginNS,"read":row.p.ReadNS,"stage":row.p.StageNS,
    "commit":row.p.CommitNS,"commit_outside_sync":row.p.CommitNS-ns} {
   nums[k]=append(nums[k],v)
  }
 }
 slices.SortFunc(allSeq,func(a,b [3]int64)int{if a[0]<b[0]{return -1};if a[0]>b[0]{return 1};return 0})
 for _,r:=range allSeq[len(allSeq)*99/100:]{
  topTotal=append(topTotal,r[0]);topSync=append(topSync,r[1]);topResidual=append(topResidual,r[2])
 }
 nums["op_tail_total"],nums["op_tail_sync"],nums["op_tail_outside_sync"]=topTotal,topSync,topResidual
 sums:=make(map[string][]int64)
 for k,v:=range nums{
  slices.Sort(v);sums[k]=[]int64{percentile(v,500),percentile(v,950),percentile(v,990),percentile(v,999)}
 }
 out:=map[string]any{"matched":len(allSeq),"dropped":dropped,"reason_counts":drops,"full_untapered_tail_coverage":tailCounts,"scoped_file_sync_events":len(spans),
  "percentiles":[]string{"p50","p95","p99","p99.9"},"nanoseconds":sums}
 data,err:=json.MarshalIndent(out,"","  ")
 if err!=nil{return err}
 return os.WriteFile("fsync-attribution.json",append(data,byte(10)),0600)
}
'''.replace("append(data,byte(10))", "append(data,'\\n')")
edit('TreeDB/internal/commitlog/writer.go',writer)
edit('TreeDB/public.go',public)
edit('scripts/raw_cow_txn_sustained/main.go',driver)
(dest/'overlay.json').write_text(json.dumps({'Replace':repl},indent=2)+'\n')
