# CI discovery and contract checks

All five requested commands completed with exit 0. The four Python test suites passed 62 tests in total; the inventory check validated the staged source snapshot without enabling authority. No Go/compiler commands were run, and no source files were edited or staged by this worker.

| Command | Exit | Tests / result |
| --- | --- | --- |
| `PYTHONDONTWRITEBYTECODE=1 python3 .github/scripts/test_refresh_ci_impact_inventory.py` | 0 | 15 |
| `PYTHONDONTWRITEBYTECODE=1 python3 .github/scripts/test_ci_impact.py` | 0 | 21 |
| `PYTHONDONTWRITEBYTECODE=1 python3 .github/scripts/test_treedb_ci_contract.py` | 0 | 10 |
| `PYTHONDONTWRITEBYTECODE=1 python3 .github/scripts/test_treedb_windows_core_headroom.py` | 0 | 16 |
| `PYTHONDONTWRITEBYTECODE=1 python3 .github/scripts/refresh_ci_impact_inventory.py --check` | 0 | Inventory validated |

Each command has separate `.stdout.log`, `.stderr.log`, `.exit`, and `.result.json` files in this directory. The JSON files record the command, working directory, UTC timestamps, elapsed time, driver SHA-256 and HEAD at start. `context.json` records Python/PyYAML versions and the inventory worktree hash and staged blob. All commands were available.
