#!/usr/bin/env python3
"""Compile one frozen #5338 lifecycle arm and retain its build receipt.

Run baseline and candidate separately, after all tests/builds have stopped.
This prepares a normal test binary; it never executes the benchmark.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze", type=Path, required=True)
    parser.add_argument("--arm", choices=("baseline", "candidate"), required=True)
    parser.add_argument("--go", type=Path, required=True)
    parser.add_argument("--gocache", type=Path)
    parser.add_argument("--gomodcache", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    freeze = json.loads(args.freeze.read_text())
    runner_path = Path(freeze["runner_path"])
    spec = importlib.util.spec_from_file_location("lifecycle_measurement", runner_path)
    if spec is None or spec.loader is None:
        raise ValueError("cannot load the frozen measurement helpers")
    helpers = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helpers)
    if helpers.sha256(runner_path) != freeze["runner_sha256"]:
        raise ValueError("measurement runner changed after source freeze")
    arm = freeze["arms"][args.arm]
    root = Path(arm["root"])
    before = helpers.source_snapshot(root)
    if before["source_files"] != arm["source_files"]:
        raise ValueError("source changed before compilation")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    binary = output / "lifecycle.test"
    go = args.go.resolve(strict=True)
    environment = os.environ.copy()
    for key, value in freeze["runtime_environment"].items():
        if value is None:
            environment.pop(key, None)
        else:
            environment[key] = value
    environment["GOTOOLCHAIN"] = "local"
    if args.gocache is not None:
        environment["GOCACHE"] = str(args.gocache.resolve())
    if args.gomodcache is not None:
        environment["GOMODCACHE"] = str(args.gomodcache.resolve())
    Path(environment["TMPDIR"]).mkdir(parents=True, exist_ok=True)
    version = subprocess.run([str(go), "version"], cwd=root, env=environment, text=True, capture_output=True, check=False)
    (output / "go-version.stdout").write_text(version.stdout)
    (output / "go-version.stderr").write_text(version.stderr)
    if version.returncode != 0:
        raise ValueError(f"Go version query failed: {version.returncode}")
    env_command = [str(go), "env", "-json", "GOOS", "GOARCH", "CGO_ENABLED", "GOFLAGS", "GOTOOLCHAIN", "GOCACHE", "GOMODCACHE", "GOVERSION"]
    observed_env = subprocess.run(env_command, cwd=root, env=environment, text=True, capture_output=True, check=False)
    (output / "go-env.stdout").write_text(observed_env.stdout)
    (output / "go-env.stderr").write_text(observed_env.stderr)
    if observed_env.returncode != 0:
        raise ValueError(f"Go environment query failed: {observed_env.returncode}")
    build_environment = json.loads(observed_env.stdout)
    if "-race" in build_environment.get("GOFLAGS", "").split():
        raise ValueError("normal benchmark compilation cannot inherit -race")
    command = [str(go), "test", "-c", "-p", "1", "-o", str(binary), "./TreeDB/documentservice"]
    started_at = helpers.now()
    start = time.monotonic_ns()
    with (output / "build.stdout").open("xb") as stdout, (output / "build.stderr").open("xb") as stderr:
        compiled = subprocess.run(command, cwd=root, env=environment, stdout=stdout, stderr=stderr, check=False)
    elapsed_ns = time.monotonic_ns() - start
    after = helpers.source_snapshot(root)
    source_unchanged = after["source_files"] == arm["source_files"]
    status = compiled.returncode if compiled.returncode != 0 else 0 if source_unchanged and binary.is_file() else 2
    binary_sha = helpers.sha256(binary) if binary.is_file() else None
    receipt = {
        "arm": args.arm,
        "command": command,
        "cwd": str(root),
        "exit_status": status,
        "compiler_exit_status": compiled.returncode,
        "source_unchanged": source_unchanged,
        "started_at_utc": started_at,
        "completed_at_utc": helpers.now(),
        "elapsed_ns": elapsed_ns,
        "go_version": version.stdout.strip(),
        "go_executable": str(go),
        "go_executable_sha256": helpers.sha256(go),
        "go_environment": build_environment,
        "explicit_runtime_environment": freeze["runtime_environment"],
        "source_freeze_path": str(args.freeze.resolve()),
        "source_freeze_sha256": helpers.sha256(args.freeze),
        "source_commit": arm["authenticated_commit"],
        "source_tree": arm["authenticated_tree"],
        "all_source_sha256": arm["all_source_sha256"],
        "all_source_sha256_after_build": after["all_source_sha256"],
        "production_source_sha256": arm["production_source_sha256"],
        "benchmark_sha256": arm["benchmark_sha256"],
        "shared_helper_sha256": arm["shared_helper_sha256"],
        "binary_path": str(binary),
        "binary_sha256": binary_sha,
        "stdout": {"path": str(output / "build.stdout"), "sha256": helpers.sha256(output / "build.stdout")},
        "stderr": {"path": str(output / "build.stderr"), "sha256": helpers.sha256(output / "build.stderr")},
        "build_helper_sha256": helpers.sha256(Path(__file__)),
    }
    if status == 0:
        info_command = [str(go), "version", "-m", str(binary)]
        info = subprocess.run(info_command, cwd=root, env=environment, text=True, capture_output=True, check=False)
        (output / "go-build-info.stdout").write_text(info.stdout)
        (output / "go-build-info.stderr").write_text(info.stderr)
        receipt["go_build_info"] = {"command": info_command, "exit_status": info.returncode, "stdout_sha256": helpers.sha256(output / "go-build-info.stdout"), "stderr_sha256": helpers.sha256(output / "go-build-info.stderr")}
    helpers.write_json(output / "build-receipt.json", receipt)
    print(json.dumps({"arm": args.arm, "receipt": str(output / "build-receipt.json"), "binary": str(binary), "binary_sha256": binary_sha, "exit_status": status, "compiler_exit_status": compiled.returncode, "source_unchanged": source_unchanged}), flush=True)
    return status


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"INVALID_BUILD: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(2)
