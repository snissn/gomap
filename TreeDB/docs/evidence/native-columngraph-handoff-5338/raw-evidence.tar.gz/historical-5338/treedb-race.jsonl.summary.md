## Go Test Timing Summary

| elapsed_s | result | package | test |
| ---: | --- | --- | --- |
| 42.93 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestOrdinaryColumnGraphNativeService4096` |
| 23.69 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestOrdinaryColumnGraphNativeService4096/native` |
| 19.24 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestOrdinaryColumnGraphNativeService4096/legacy` |
| 10.28 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceSharedCOWWriteLoadedFilteredVectorRefusal` |
| 5.20 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceSharedCOWWriteLoadedFilteredVectorRefusal/writers4` |
| 5.09 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceSharedCOWWriteLoadedFilteredVectorRefusal/writers1` |
| 4.74 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestOrdinaryColumnGraphNativeConcurrentWrite4096` |
| 4.18 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestSharedCOWFrozenFixturePreflight` |
| 4.14 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceConcurrentFilterDeleteAndUpsertPreservesReplacement` |
| 2.53 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceCosineNormalizedF32V1HNSWExactReceipt` |
| 2.42 | fail | `github.com/snissn/gomap/TreeDB/documentservice` | `TestOrdinaryColumnGraphNativeColdHybrid4096` |
| 1.29 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestOrdinaryColumnGraphNativeOptimizeCrashReopen` |
| 1.28 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceDeferredVectorBuildOptimizeCheckpointCrashReopen` |
| 1.23 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceRawBackendReadsAdvanceCachedForegroundActivity` |
| 1.16 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceStandardOptimizeCheckpointCrashReopen` |
| 1.14 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestHTTPScalarTruncationFailsClosedNeverPartial` |
| 1.13 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceColumnGraphBufferedInsertCrashRecovery` |
| 1.11 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceTypedFreshUpsertConcurrentDenseAfterColumnGraphBuildAndVacuum` |
| 1.08 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceDeferredVectorBuildMaintenanceLifecycle` |
| 1.06 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestDiagnosticsSnapshotConcurrentWithWrites` |
| 0.85 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceLegacyColumnGraphMutationDefaultRouteAndReopen` |
| 0.77 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceConcurrentSameIDUpsertsSucceed` |
| 0.73 | pass | `github.com/snissn/gomap/TreeDB/documentservice` | `TestServiceColumnGraphCrossCollectionClosure` |
| 0.51 | pass | `github.com/snissn/gomap/TreeDB/internal/raftharness` | `TestReadIndexProviderFailsClosed` |
| 0.49 | pass | `github.com/snissn/gomap/TreeDB/internal/vectorops` | `TestDotFloat32IndexedAMD64ExactBits4137` |

## Package Results

| elapsed_s | result | package |
| ---: | --- | --- |
| 95.47 | fail | `github.com/snissn/gomap/TreeDB/documentservice` |
| 5.32 | pass | `github.com/snissn/gomap/TreeDB/internal/raftharness` |
| 1.90 | pass | `github.com/snissn/gomap/TreeDB/internal/templatedb` |
| 1.89 | pass | `github.com/snissn/gomap/TreeDB/internal/powerlossreopen` |
| 1.86 | pass | `github.com/snissn/gomap/TreeDB/internal/compression` |
| 1.72 | pass | `github.com/snissn/gomap/TreeDB/internal/vectorops` |
| 1.09 | pass | `github.com/snissn/gomap/TreeDB/internal/bulk` |
| 1.03 | pass | `github.com/snissn/gomap/TreeDB/internal/merging` |
| 1.03 | pass | `github.com/snissn/gomap/TreeDB/mongo_gateway/compatdiff` |
| 1.02 | pass | `github.com/snissn/gomap/TreeDB/page` |
| 1.02 | pass | `github.com/snissn/gomap/TreeDB/internal/keyupdate` |
| 0.00 | skip | `github.com/snissn/gomap/TreeDB/cmd/template_corpus_extract` |
| 0.00 | skip | `github.com/snissn/gomap/TreeDB/cmd/unified_bench` |

## Tests Still Running At Log End

- none
