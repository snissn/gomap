#!/usr/bin/env python3
"""Run the remaining independent gates serially, retaining every original exit."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from native_graph_lifecycle_benchmark import source_snapshot

TASK = Path('/workspace/scratch/0d9ab3f5d72e')
ROOT = TASK / 'gomap-5338'
EVIDENCE = TASK / 'evidence'
GO = TASK / 'toolchain/go/bin/go'
FREEZE = EVIDENCE / 'lifecycle-source-freeze.json'
ENV = dict(os.environ)
ENV.update(PATH=str(GO.parent) + os.pathsep + ENV.get('PATH', ''),
           GOCACHE=str(TASK / 'go-cache'), GOPATH=str(TASK / 'go-path'),
           GOWORK='off', GOTOOLCHAIN='local', GOMEMLIMIT='4GiB',
           GOMAXPROCS='2', TMPDIR=str(TASK / 'tmp'))
PATTERN = '^(TestTypedStorageLegacy.*|TestNativeOrdinaryGraphAcceptedAcrossCapturedManifestBuild|TestNativeOrdinaryColumnGraphRecipeAcrossCapturedHandoff|TestNativeOrdinaryGraphHandoff.*|TestNativeOrdinaryGraphPreassignmentSourceChangesHaveNoEffect|TestNativeGraphPreparation.*|TestNative.*Diagnostic.*)$'
COMMANDS = [
    ('candidate-final-focused', ['test', '-json', '-p', '1', '-timeout', '12m', './TreeDB/collections', '-run', PATTERN, '-count=1']),
    ('candidate-vet', ['vet', '-p', '1', './TreeDB/documentservice', './TreeDB/collections', './TreeDB/caching', './TreeDB/db', './TreeDB/nativewire', './TreeDB', './TreeDB/docs']),
    ('candidate-nativewire', ['test', '-json', '-p', '1', '-timeout', '30m', './TreeDB/nativewire', '-count=1']),
    ('candidate-race', ['test', '-json', '-race', '-p', '1', '-timeout', '20m', './TreeDB/documentservice', './TreeDB/collections', '-count=1']),
]

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_sources():
    freeze = json.loads(FREEZE.read_text())
    candidate = freeze['arms']['candidate']
    actual = source_snapshot(ROOT)
    if actual['all_source_sha256'] != candidate['all_source_sha256']:
        raise RuntimeError('source set or bytes changed after freeze')
    return candidate['all_source_sha256']

def main():
    source_hash = verify_sources()
    failed = False
    for name, args in COMMANDS:
        paths = {key: EVIDENCE / (name + suffix) for key, suffix in
                 [('stdout', '.jsonl'), ('stderr', '.stderr'), ('exit', '.exit'), ('receipt', '.receipt.json')]}
        if any(p.exists() for p in paths.values()):
            raise RuntimeError('refusing to overwrite an earlier run: ' + name)
        command = [str(GO), *args]
        receipt = dict(name=name, command=command, cwd=str(ROOT), started_utc=utc(),
                       source_freeze_sha256=digest(FREEZE), source_sha256=source_hash,
                       environment={k: ENV.get(k) for k in ['GOCACHE', 'GOPATH', 'GOWORK', 'GOTOOLCHAIN', 'GOMEMLIMIT', 'GOMAXPROCS', 'TMPDIR', 'GODEBUG', 'GOGC', 'TZ', 'LANG', 'LC_ALL']})
        print('START', name, receipt['started_utc'], flush=True)
        started = time.monotonic()
        with paths['stdout'].open('xb') as out, paths['stderr'].open('xb') as err:
            process = subprocess.run(command, cwd=ROOT, env=ENV, stdout=out, stderr=err)
        receipt.update(exit_status=process.returncode, finished_utc=utc(),
                       elapsed_seconds=time.monotonic()-started,
                       stdout_sha256=digest(paths['stdout']), stderr_sha256=digest(paths['stderr']))
        paths['exit'].write_text(str(process.returncode) + '\n')
        paths['receipt'].write_text(json.dumps(receipt, indent=2) + '\n')
        print('END', name, process.returncode, round(receipt['elapsed_seconds'], 3), flush=True)
        if verify_sources() != source_hash:
            raise RuntimeError('source closure changed')
        failed |= process.returncode != 0
    return int(failed)

if __name__ == '__main__':
    sys.exit(main())
