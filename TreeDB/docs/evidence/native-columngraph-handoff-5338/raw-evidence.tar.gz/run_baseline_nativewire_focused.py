#!/usr/bin/env python3
"""One retained baseline control; never retry or replace an existing run."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

from native_graph_lifecycle_benchmark import source_snapshot

TASK = Path('/workspace/scratch/0d9ab3f5d72e')
ROOT = TASK / 'gomap-5338-baseline'
EVIDENCE = TASK / 'evidence'
FREEZE = EVIDENCE / 'lifecycle-source-freeze.json'
GO = TASK / 'toolchain/go/bin/go'
NAME = 'baseline-nativewire-focused'
TEST = 'TestMultiOwnerTCPAcceptedModelScaledCorrectnessV1'
COMMAND = [str(GO), 'test', '-json', '-p', '1', '-timeout', '30m',
           './TreeDB/nativewire', '-run', '^' + TEST + '$', '-count=1']


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as src:
        for chunk in iter(lambda: src.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def snapshot_summary(snapshot):
    return {k: v for k, v in snapshot.items() if k != 'source_files'}


def verify_baseline(expected):
    actual = source_snapshot(ROOT)
    if actual['all_source_sha256'] != expected['all_source_sha256']:
        raise RuntimeError('baseline source bytes differ from the frozen inventory')
    for key in ('local_head', 'local_head_tree', 'tracked_working_changes',
                'tracked_staged_changes', 'untracked_source_files'):
        if actual[key] != expected[key]:
            raise RuntimeError('baseline source identity differs: ' + key)
    return snapshot_summary(actual)


def active_go_processes():
    active = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit() or int(path.name) == os.getpid():
            continue
        try:
            fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            if fields[0] == 'Z':
                continue
            argv = [v.decode(errors='replace') for v in
                    (path / 'cmdline').read_bytes().split(b'\0') if v]
            if not argv:
                continue
            executable = Path(argv[0]).name
            pipeline = (executable.startswith('python') and len(argv) > 1
                        and argv[1].endswith('/evidence/run_final_validation.py'))
            task_tool = str(TASK) in ' '.join(argv) and (
                executable in ('go', 'compile', 'link', 'asm', 'cgo',
                               'gcc', 'cc1', 'collect2', 'ld')
                or executable.endswith('.test'))
            if pipeline or task_tool:
                active.append({'pid': int(path.name), 'argv': argv})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return active


def parse_output(path):
    events, parse_errors = [], []
    for number, line in enumerate(path.read_text(errors='replace').splitlines(), 1):
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError as exc:
            parse_errors.append({'line': number, 'error': str(exc)})
    selected = [e for e in events if e.get('Test') == TEST]
    counts = {action: sum(e.get('Action') == action and bool(e.get('Test'))
                          for e in events)
              for action in ('run', 'pass', 'skip', 'fail')}
    failed = [e for e in events if e.get('Action') == 'fail']
    error_pattern = re.compile(r'public indexed query|panic:|fatal error:|'
                               r'DATA RACE|hashicorp raft unavailable|'
                               r'(?:\bfailed\b|\berror\b|\bunexpected\b)', re.I)
    causes = [e for e in selected if e.get('Action') == 'output'
              and error_pattern.search(e.get('Output', ''))
              and not e.get('Output', '').lstrip().startswith('--- FAIL:')]
    return {
        'parse_errors': parse_errors, 'test_event_counts': counts,
        'selected_run_count': sum(e.get('Action') == 'run' for e in selected),
        'selected_pass_count': sum(e.get('Action') == 'pass' for e in selected),
        'failure_events': failed,
        'first_observed_error_event': causes[0] if failed and causes else None,
        'first_cause_interpretation': ('Original error text only; no hidden Raft '
                                     'state or historical attribution inferred.'),
        'failed_selected_test_output': ''.join(e.get('Output', '') for e in selected)
                                      if failed else None,
        'package_result_events': [e for e in events if not e.get('Test')
                                  and e.get('Action') in ('pass', 'fail', 'skip')],
    }


def main():
    paths = {key: EVIDENCE / (NAME + suffix) for key, suffix in
             [('stdout', '.jsonl'), ('stderr', '.stderr'),
              ('exit', '.exit'), ('receipt', '.receipt.json')]}
    if any(p.exists() for p in paths.values()):
        raise RuntimeError('refusing to overwrite any earlier baseline control')
    if not (EVIDENCE / 'candidate-race.exit').is_file():
        raise RuntimeError('candidate race has not recorded its exit')
    active = active_go_processes()
    if active:
        raise RuntimeError('Go validation/compiler/test processes remain: ' + json.dumps(active))
    freeze = json.loads(FREEZE.read_text())
    before = verify_baseline(freeze['arms']['baseline'])
    build_path = EVIDENCE / 'lifecycle-build-baseline/build-receipt.json'
    build = json.loads(build_path.read_text())
    go_sha = digest(GO)
    if go_sha != build['go_executable_sha256']:
        raise RuntimeError('Go executable differs from the retained Go 1.26.10 build receipt')
    reference_path = EVIDENCE / 'candidate-nativewire.receipt.json'
    reference = json.loads(reference_path.read_text())
    env = dict(os.environ)
    env['PATH'] = str(GO.parent) + os.pathsep + env.get('PATH', '')
    for key, value in reference['environment'].items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    receipt = {
        'name': NAME, 'scope': 'FOCUSED baseline control; not a recreation of full-package history.',
        'interpretation_limit': 'A pass does not explain or supersede the original candidate full-package failure; a failure does not transfer issue ownership.',
        'command': COMMAND, 'cwd': str(ROOT), 'started_utc': utc(),
        'source_freeze_sha256': digest(FREEZE), 'source_before': before,
        'environment': {key: env.get(key) for key in ['PATH', *reference['environment']]},
        'environment_reference_receipt_sha256': digest(reference_path),
        'go_executable_sha256': go_sha, 'go_version': build['go_version'],
        'go_version_provenance': str(build_path),
        'candidate_race_exit': int((EVIDENCE / 'candidate-race.exit').read_text()),
        'prelaunch_process_guard': {'checked_utc': utc(), 'active_go_processes': active},
        'runner_sha256': digest(Path(__file__)),
        'attempt_count': 1, 'retry_policy': 'No retry; all original outputs retained.',
    }
    print('START', NAME, receipt['started_utc'], flush=True)
    started = time.monotonic()
    with paths['stdout'].open('xb') as out, paths['stderr'].open('xb') as err:
        process = subprocess.run(COMMAND, cwd=ROOT, env=env, stdout=out, stderr=err)
    receipt.update(exit_status=process.returncode, finished_utc=utc(),
                   elapsed_seconds=time.monotonic() - started,
                   stdout_sha256=digest(paths['stdout']),
                   stderr_sha256=digest(paths['stderr']))
    with paths['exit'].open('x') as out:
        out.write(str(process.returncode) + '\n')
    receipt['exit_file_sha256'] = digest(paths['exit'])
    try:
        receipt['source_after'] = verify_baseline(freeze['arms']['baseline'])
        receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after']
    except Exception as exc:
        receipt['source_unchanged'] = False
        receipt['source_verification_error'] = str(exc)
    receipt['test_result'] = parse_output(paths['stdout'])
    result = receipt['test_result']
    receipt['control_passed'] = (process.returncode == 0 and receipt['source_unchanged']
                                 and not result['parse_errors']
                                 and result['selected_run_count'] == 1
                                 and result['selected_pass_count'] == 1
                                 and not result['failure_events'])
    with paths['receipt'].open('x') as out:
        json.dump(receipt, out, indent=2)
        out.write('\n')
    print('END', NAME, process.returncode, round(receipt['elapsed_seconds'], 3),
          'control_passed=' + str(receipt['control_passed']), flush=True)
    return 0 if receipt['control_passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
