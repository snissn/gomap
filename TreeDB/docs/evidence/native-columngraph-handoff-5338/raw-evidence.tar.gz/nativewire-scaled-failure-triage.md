# Native-wire scaled correctness failure: source triage

## Finding

The original candidate run failed `TestMultiOwnerTCPAcceptedModelScaledCorrectnessV1` on **public query 23** (zero based), at `2026-10-30T19:36:05.033Z`; the final fail event records 55.31 seconds. Its complete reported cause is:

```text
vectorpartition: generation_mismatch: vectorpartition: generation_mismatch:
nativewire: fixed-peer vector mutation proof stale
raftcluster: hashicorp raft unavailable
```

This is an immutable multi-owner search's **catalog/Raft availability refusal**. It is not evidence that a graph recipe's physical root changed or that a data generation actually mismatched. The current log does not identify the failing node, exact fence call, missing-leader state or shutdown state. Do not label it a flake, assign it to #5333, or mark the native-wire suite qualified.

## What completed before failure

The fixture uses 1,024 rows, 768 dimensions, three packs, two domains and two serving owners. Source construction, the two canonical domain graphs, all 32 same-generation local reference queries, original seed close, source-verified BUILD/Stage/ACTIVE, and runtime readiness completed before entering the public query loop. Queries 0–22 returned and passed their parity assertions; query 23 returned the error before result validation. The intentional later owner-loss/invalidation controls were not reached. Each of the four child runtimes reports PASS on cleanup; those child harness shutdown outcomes do not negate the parent failure or prove uninterrupted Raft availability.

## Source path and boundary

1. `vector_partition_fixed_peer_multi_owner_v1_test.go:739–741` fails immediately on the public client's returned search error.
2. `fixed_peer_vector_runtime_v1.go:1204–1243` selects the immutable backend and fences ACTIVE state on entry/exit. Scoped router/owner authorization also performs catalog fences.
3. `fixed_peer_vector_immutable_runtime_v1.go:441–443` joins a failed `catalogFence` with `ErrFixedPeerVectorProofStaleV1`; the scoped owner authority has an equivalent join at `vector_partition_scoped_owner_authority_v1.go:154`.
4. `fixed_peer_tcp_runtime_v1.go:830–848` discovers a leader, performs `catalog-read`, and checks local catalog progress. `/v1/catalog-read` calls `localCatalogFence` at line 1170, which invokes `LinearizableCatalogMetaAppliedIndexV1` at line 893.
5. `catalog_meta_raft.go:367` returns the **bare** unavailable sentinel when admission sees Shutdown or no current leader ID. Line 493 also returns it for explicit Shutdown during leader verification. Line 427 can return it for unavailable applied state, but the actual nonnil `CatalogMetaAuthorityV1` returns `ok=true` (`catalog_meta.go:113–119`).
6. The control RPC preserves `err.Error()` verbatim (`fixed_peer_tcp_runtime_v1.go:1011`, `1455`). Joined HashiCorp future errors normally retain additional text. Proof lease expiration/term/applied-index failures normally carry the distinct read-barrier sentinel and explanatory text. Thus the exact bare cause points more strongly to a fresh catalog admission/leadership availability state, while the precise branch remains unobserved.

`publicBackendErrorV1` classifies a joined proof-stale sentinel as generation mismatch, which explains the outer label. The public wire encode/decode produces the repeated generation-mismatch wording; it is not two independently observed generation failures.

## Relevance to the #5338 patch

The seed opens `backenddb.Open` directly (`vector_partition_live_production_v1_test.go:716`), and this fixture's groups leave `NativeCollections=false` (`vector_partition_fixed_peer_multi_owner_v1_test.go:1483–1488`). `openDataGroupV1` consequently uses direct backend open (`replica_replacement_runtime_v1.go:34–48`). The manager selects `nativeJSON` only after native semantic activation rejects legacy producer admission (`collections/api.go:1754–1763`; `db/native_semantic_activation.go:42–54`). That activation is absent here.

Accordingly, this fixture does not traverse the new native graph effective-root/header handoff or preassignment refresh. The shared generic typed-image builder can execute during successful seed construction, but the new provenance scalar neither changes the encoded image nor feeds catalog/Raft authority. All implicated fixture, search, catalog and Raft files are unchanged from baseline. This is strong source separation from the selected handoff seam, not proof that every timing/resource effect of a different binary is impossible.

The exact source/hashes are retained in `nativewire-scaled-failure.source.json`; all 16 inspected files match frozen candidate `9cd7557fb705b07261b801a2f42aa90dee4ce171`, tree `dff272aeed265395770cb6eba7b17eeb6463618b`. The generic typed-image builder is the only changed file in that set.

## Existing issue comparison

The GitHub adapter returned [#4927](https://github.com/snissn/gomap/issues/4927), completed by [#4928](https://github.com/snissn/gomap/pull/4928), as prior ownership for this test's setup-budget failures. Current source already starts its 90-second operation context after seed construction (lines 94–97). This run reached public query 23, and child runtime durations were approximately 3.8 seconds. It does not reproduce that older setup-deadline signature, so the historical resolution cannot dispose of this failure.

[#5333](https://github.com/snissn/gomap/issues/5333) concerns public COW native-wire JSON mutation/checkpoint failures at the span-native zipper replacement-root invariant. The present read-fence failure supplies neither that invariant nor that storage-owner path. It should not be transferred to #5333 based on the package name.

## Next discriminator

Preserve this failed execution. A single source-bound baseline control of this exact test, with the same toolchain and environment, can establish whether the same search refusal also exists before this patch; it cannot by itself explain the candidate event or qualify a retry. For causal capture, use a separately labeled diagnostic overlay to retain **the first failed fence's** node, operation, query/request identity, Raft state, leader ID, term, applied/commit indices, raw error and time. Existing `Status` and `DiagnosticsV1` immediately before cleanup can supplement it; they are later observations and must not be substituted for the failing state. The runtime currently sets Raft `LogOutput=io.Discard`, so original node logs contain no leadership-transition history.

The fixture config uses 300 ms heartbeat/election/leader-lease durations and a 12-second request timeout. Those are facts to bind in a discriminator, not a reason to extend them or weaken the strict search assertion. A missing-leader transition versus an actual shutdown/authority fault is the first causal distinction to resolve. No source edit, Go execution, rerun, retry or timing relaxation was performed during this triage.

## Preserved original evidence

- `nativewire-scaled-failure.events.jsonl`: all 68 original JSON events for this completed test; SHA-256 `7f68d68feb712abd17434ee0a574f997955629d8472c058fc41051b57e0db9b1`.
- `nativewire-scaled-failure.stdout`: exact concatenated original test output; SHA-256 `97b9bd818e914a03c739ab35295a80fd8875f7a33ade4cbdb86b279d4d3685bb`.
- `nativewire-scaled-failure.source.json`: source hashes, baseline equality and original final event.

The full package log was still being appended during extraction; no final package outcome is inferred here.
