#!/usr/bin/env python3
"""Package completed, original validation records without compiler scratch."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile
import datetime

TASK = Path('/workspace/scratch/0d9ab3f5d72e')
EVIDENCE = TASK / 'evidence'
DEST = TASK / 'gomap-5338/TreeDB/docs/evidence/native-columngraph-handoff-5338'
RUNS = ['baseline-witness', 'candidate-focused', 'candidate-documentservice',
        'candidate-affected', 'candidate-final-focused', 'candidate-vet',
        'candidate-nativewire', 'candidate-race', 'baseline-nativewire-focused']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_interruption():
    path = EVIDENCE / 'local-race-interruption.json'
    receipt = json.loads(path.read_text())
    expected = {'schema': 'gomap.validation.incomplete-run.v1',
                'name': 'candidate-race', 'status': 'incomplete',
                'exit_status': None, 'exit_status_known': False}
    if any(receipt.get(key) != value for key, value in expected.items()):
        raise RuntimeError('invalid interruption disposition')
    if any((EVIDENCE / ('candidate-race' + suffix)).exists()
           for suffix in ['.exit', '.receipt.json']):
        raise RuntimeError('interruption record conflicts with a completion receipt')
    artifacts = {row['path']: row for row in receipt['artifacts']}
    for name in ['candidate-race.jsonl', 'candidate-race.stderr']:
        output = EVIDENCE / name
        if artifacts[name]['bytes'] != output.stat().st_size or artifacts[name]['sha256'] != sha(output):
            raise RuntimeError('interrupted output changed: ' + name)

def verify_completed_receipt(name):
    path = EVIDENCE / (name + '.receipt.json')
    if not path.exists():
        return
    receipt = json.loads(path.read_text())
    for field, suffix in [('stdout_sha256', '.jsonl'), ('stderr_sha256', '.stderr')]:
        if receipt[field] != sha(EVIDENCE / (name + suffix)):
            raise RuntimeError('completed output changed: ' + name + suffix)
    exit_path = EVIDENCE / (name + '.exit')
    if receipt['exit_status'] != int(exit_path.read_text().strip()):
        raise RuntimeError('completed exit differs from receipt: ' + name)
    if 'exit_file_sha256' in receipt and receipt['exit_file_sha256'] != sha(exit_path):
        raise RuntimeError('completed exit bytes changed: ' + name)

def run_summary(name):
    out, err, exit_path = [EVIDENCE / (name + suffix) for suffix in ['.jsonl', '.stderr', '.exit']]
    interruption = EVIDENCE / 'local-race-interruption.json'
    incomplete = name == 'candidate-race' and not exit_path.exists() and interruption.is_file()
    status = None if incomplete else int(exit_path.read_text().strip())
    rows = []
    for line in out.read_text().splitlines():
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise RuntimeError('invalid retained JSON in ' + name) from exc
    counts = {a: sum(r.get('Action') == a and bool(r.get('Test')) for r in rows) for a in ['pass', 'fail', 'skip']}
    receipt = EVIDENCE / (name + '.receipt.json')
    value = {'name': name, 'exit_status': status,
             'execution_status': 'incomplete; original exit unknown' if incomplete else 'complete',
             'test_event_counts': counts,
             'package_results': [{k: r[k] for k in ['Package', 'Action', 'Elapsed', 'FailedBuild'] if k in r}
                                 for r in rows if r.get('Action') in ['pass', 'fail', 'skip'] and not r.get('Test')],
             'failed_tests': [r['Test'] for r in rows if r.get('Action') == 'fail' and r.get('Test')],
             'artifacts': [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p)}
                           for p in [out, err, exit_path] if p.exists()]}
    if incomplete:
        value['interruption_receipt'] = json.loads(interruption.read_text())
    elif receipt.exists():
        value['receipt'] = json.loads(receipt.read_text())
    else:
        value['command_record'] = 'See early-run-commands.json in the raw archive; early command flag spelling is normalized from same-session execution notes.'
    return value

def main():
    # Interrupted output remains incomplete evidence, with no invented exit.
    for name in RUNS:
        for suffix in ['.jsonl', '.stderr', '.exit']:
            if name == 'candidate-race' and suffix == '.exit' and (EVIDENCE / 'local-race-interruption.json').is_file():
                continue
            if not (EVIDENCE / (name + suffix)).is_file():
                raise RuntimeError('incomplete run: ' + name + suffix)
    if not (EVIDENCE / 'baseline-nativewire-focused.receipt.json').is_file():
        raise RuntimeError('baseline command receipt not complete')
    verify_interruption()
    for name in RUNS:
        if name != 'candidate-race':
            verify_completed_receipt(name)
    readme = (EVIDENCE / 'pr-evidence-readme.md').read_text()
    if 'PENDING_' in readme.replace('PENDING_RAW_ARCHIVE_SHA256', '').replace('PENDING_RAW_ARCHIVE', ''):
        raise RuntimeError('finish README validation dispositions before packaging')
    if not (EVIDENCE / 'early-run-commands.json').is_file():
        raise RuntimeError('early command reconstruction is absent')
    if DEST.exists():
        raise RuntimeError('refusing to replace an existing evidence packet')
    DEST.mkdir(parents=True)
    freeze = json.loads((EVIDENCE / 'lifecycle-source-freeze.json').read_text())
    validation = {
        'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'candidate_source_commit': freeze['arms']['candidate']['authenticated_commit'],
        'candidate_source_tree': freeze['arms']['candidate']['authenticated_tree'],
        'candidate_all_source_sha256': freeze['arms']['candidate']['all_source_sha256'],
        'source_freeze_sha256': sha(EVIDENCE / 'lifecycle-source-freeze.json'),
        'count_scope': 'Go JSON test/subtest completion events, not independent workloads. Original nonzero runs remain nonzero.',
        'runs': [run_summary(name) for name in RUNS],
        'python_contract_results': [json.loads(p.read_text()) for p in sorted((EVIDENCE / 'ci-contracts').glob('*.result.json'))],
        'measurement_summary_sha256': sha(EVIDENCE / 'lifecycle-measurements/summary.json'),
        'all_six_measurements_complete': json.loads((EVIDENCE / 'lifecycle-measurements/summary.json').read_text())['all_six_complete'],
        'historical_incident': 'The original #5332 Optimize cause remains unattributed; the controlled handoff failure is separate evidence.',
    }
    (EVIDENCE / 'validation-results.json').write_text(json.dumps(validation, indent=2) + '\n')

    selected = set()
    for name in RUNS:
        selected.update(EVIDENCE.glob(name + '.*'))
    for pattern in ['nativewire-scaled-failure*', 'early-run-commands.json',
                    'lifecycle-source-freeze.json', 'baseline-lifecycle-binding.json',
                    'lifecycle-build-equivalence.json', 'source-commit-binding.json',
                    'candidate-source-binding.json', 'github-source-receipt.json',
                    'production-review.md', 'shared-caller-review*', 'measured-results.md',
                    'lifecycle-validation-matrix.md', 'validation-results.json',
                    'native_graph_lifecycle_benchmark.py', 'native_graph_lifecycle_benchmark_protocol.md',
                    'build_native_graph_lifecycle_benchmark.py', 'run_final_validation.py',
                    'run_baseline_nativewire_focused.py', 'run_baseline_nativewire_after_interruption.py',
                    'package_pr_evidence.py',
                    'local-race-interruption.json', 'local-race-interruption.md',
                    'issue5338-legacy-name-review.txt',
                    'hosted-source-status.json']:
        selected.update(EVIDENCE.glob(pattern))
    for directory in ['diagnostic-fd1', 'historical-5338', 'ci-contracts', 'lifecycle-measurements',
                      'lifecycle-build-baseline', 'lifecycle-build-candidate']:
        selected.update(p for p in (EVIDENCE / directory).rglob('*')
                        if p.is_file() and p.name != 'lifecycle.test' and '__pycache__' not in p.parts)
    windows = EVIDENCE / 'hosted-windows-core-3-124262874273'
    for name in ['job.raw.log', 'triage.json', 'failing-test.jsonl', 'raw-log-receipt.json', 'related-owner-issues.json']:
        path = windows / name
        if path.is_file():
            selected.add(path)
    selected = sorted(p for p in selected if p.is_file())
    manifest = {'scope': 'Original retained outputs, receipts, source inventories and scripts. Executables, compiler scratch, caches and temporary download URLs excluded.',
                'files': [{'path': p.relative_to(EVIDENCE).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in selected]}
    manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
    (DEST / 'artifact-manifest.json').write_bytes(manifest_bytes)
    archive = DEST / 'raw-evidence.tar.gz'
    with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
            for path, data in [('artifact-manifest.json', manifest_bytes)] + [(p.relative_to(EVIDENCE).as_posix(), p.read_bytes()) for p in selected]:
                info = tarfile.TarInfo(path)
                info.size, info.mtime, info.mode = len(data), 0, 0o644
                tar.addfile(info, io.BytesIO(data))
    for src, dst in [('production-review.md', 'production-review.md'),
                     ('shared-caller-review.md', 'shared-caller-review.md'),
                     ('shared-caller-review.source.json', 'shared-caller-review.source.json'),
                     ('measured-results.md', 'measured-results.md'),
                     ('native_graph_lifecycle_benchmark_protocol.md', 'benchmark-protocol.md'),
                     ('lifecycle-measurements/summary.json', 'measurement-summary.json'),
                     ('lifecycle-build-equivalence.json', 'lifecycle-build-equivalence.json'),
                     ('validation-results.json', 'validation-results.json')]:
        shutil.copyfile(EVIDENCE / src, DEST / dst)
    readme = (EVIDENCE / 'pr-evidence-readme.md').read_text()
    readme = readme.replace('**PENDING_RAW_ARCHIVE**', 'complete (' + str(archive.stat().st_size) + ' bytes)')
    readme = readme.replace('PENDING_RAW_ARCHIVE_SHA256', sha(archive))
    readme = readme.replace('The archive and validation manifest must be finalized before treating these links as complete.',
                            'The archive manifest records each original member\'s size and SHA-256; executables are identified by their build receipts and excluded.')
    if 'PENDING_' in readme:
        raise RuntimeError('finish README validation dispositions before publication')
    (DEST / 'README.md').write_text(readme)
    print(json.dumps({'directory': str(DEST), 'archive_bytes': archive.stat().st_size,
                      'archive_sha256': sha(archive), 'raw_members': len(selected),
                      'files': [p.name for p in sorted(DEST.iterdir())]}))

if __name__ == '__main__':
    main()
