# Local race evidence: incomplete command, unknown exit

The local `candidate-race` command has no recovered exit status. Its retained JSON stream contains a completed **documentservice package PASS (164.435 s)** and passing handoff/preassignment regressions, but ends while the collections package is running. The full local two-package command must be reported as **incomplete**, not passed or failed.

At audit time, `candidate-race.exit` and `candidate-race.receipt.json` were absent. The original execution session could not be resumed, and no Go/test/validation process was visible in the independent process inventory. These observations do not identify the interruption mechanism or recover an operating-system wait status. No timeout, signal, test failure, or clean exit is inferred.

The original stdout is 4,151,241 bytes, SHA-256 `fd8caa2da75eea25575ac608d56a289344cc6b38a83277d07ba1c36973de46a7`; stderr is empty. All 16,905 retained lines parse as JSON. Test/subtest completion events are 4,133 pass, 33 skip and zero failure, from 4,167 test starts. The last event is the start-output for `TestR1TypedRowOrderedPartLookupHistory5065`, at `2026-10-30T20:05:35.077007022Z`. There is no terminal event for that test or the collections package. Zero retained failure events is a statement about the partial log, not a complete-suite absence-of-failure claim.

The deterministic accepted-handoff witness passes all four arms under `-race`: sequential, changed manifest, unchanged manifest and changed-manifest crash recovery. The real preassignment physical-handoff and logical-row controls also pass. The 4096-document cold-Hybrid service fixture, Optimize/crash/reopen, and original-Close fault control have recorded race passes. Exact events and package-separated counts are in `local-race-interruption.json`.

The independent hosted workflow `41113857081` completed all eight Linux race jobs successfully on source commit `9cd7557fb705b07261b801a2f42aa90dee4ce171`, with synthetic merge `a2d2e8cf0de82852a61f916c91a6048d3f22b864` and the frozen candidate tree. The adapter was rechecked at approximately 20:09 UTC: all 38 jobs completed, with 36 successes and two failures (Windows core-3 and the aggregate required gate). The hosted race passes do not retroactively complete the local command or waive either unresolved validation failure.

## Suggested report wording

README race row:

> Local command incomplete; exit unknown. Retained documentservice package PASS (164.435 s), four captured-handoff arms and both preassignment arms PASS. Partial stream: 4,133 pass / 33 skip / zero failure events. Independent hosted qualification: all eight Linux race jobs PASS on the frozen source.

Validation matrix race row:

> INCOMPLETE locally; original stdout/stderr retained without fabricated exit or after-command receipt. `local-race-interruption.json` records the last event, completion gap and unknown termination cause. Hosted run 41113857081 independently passes all eight Linux race jobs on the same frozen source; that result is separate from this local command.

The package manifest should explicitly allow an incomplete run with `exit_status: null` and its interruption record. It must not require or create a numeric `.exit` file for this command. A subsequent diagnostic runner may check that no competing process remains and record this incomplete state; it must not interpret it as an original exit value.
