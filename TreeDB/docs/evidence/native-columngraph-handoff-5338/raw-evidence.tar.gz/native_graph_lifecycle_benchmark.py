#!/usr/bin/env python3
"""Freeze #5338 sources, then run six isolated public lifecycle samples.

This script never builds Go binaries. Each measured binary is the only child of
a fresh Python worker, so RUSAGE_CHILDREN.ru_maxrss describes that benchmark
process rather than the cumulative maximum of earlier benchmark samples.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import resource
import signal
import statistics
import subprocess
import sys
import time


BASE_COMMIT = "d7db5409e20412f4dac4e1a3f902484b05e014e1"
BASE_TREE = "39a87e47f3740e4056f25196da54a9f4e35eb159"
BENCHMARK = "BenchmarkOrdinaryColumnGraphNativeLifecycle4096"
BENCH_SOURCE = "TreeDB/documentservice/ordinary_columngraph_native_lifecycle_bench_test.go"
HELPER_SOURCE = "TreeDB/documentservice/shared_cow_write_bench_test.go"
HELPER_SHA256 = "45d2186bbc6ece189f56ee4fd44226250ed2a9e458d739d3dd4eb34ecaec6826"
ORDER = ["baseline", "candidate"] * 3
FLAGS = [
    "-test.run=^$", f"-test.bench=^{BENCHMARK}$", "-test.benchtime=1x",
    "-test.count=1", "-test.benchmem", "-test.v",
]
RUNTIME_KEYS = ("GODEBUG", "GOGC", "GOTRACEBACK", "LANG", "LC_ALL", "TZ")
SOURCE_SUFFIXES = (".go", ".c", ".h", ".s", ".S", ".syso")
RUSAGE_FIELDS = (
    "ru_utime", "ru_stime", "ru_maxrss", "ru_minflt", "ru_majflt",
    "ru_inblock", "ru_oublock", "ru_nvcsw", "ru_nivcsw",
)


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as src:
        for block in iter(lambda: src.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def canonical_sha(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def write_json(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as out:
        json.dump(value, out, sort_keys=True, indent=2)
        out.write("\n")


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


def source_file(path: str) -> bool:
    return Path(path).name in ("go.mod", "go.sum") or path.endswith(SOURCE_SUFFIXES)


def source_snapshot(root: Path) -> dict:
    tracked = set(filter(None, git(root, "ls-files", "-z").split("\0")))
    untracked = set(filter(None, git(root, "ls-files", "--others", "--exclude-standard", "-z").split("\0")))
    records = []
    for name in sorted(p for p in tracked | untracked if source_file(p)):
        path = root / name
        if not path.is_file():
            raise ValueError(f"missing source input: {path}")
        records.append({"path": name, "bytes": path.stat().st_size, "sha256": sha256(path)})
    production = [r for r in records if not r["path"].endswith("_test.go")]
    tests = [r for r in records if r["path"].endswith("_test.go")]
    return {
        "root": str(root),
        "local_head": git(root, "rev-parse", "HEAD"),
        "local_head_tree": git(root, "rev-parse", "HEAD^{tree}"),
        "status_porcelain": git(root, "status", "--short").splitlines(),
        "tracked_working_changes": git(root, "diff", "--name-only").splitlines(),
        "tracked_staged_changes": git(root, "diff", "--cached", "--name-only").splitlines(),
        "untracked_source_files": sorted(p for p in untracked if source_file(p)),
        "source_files": records,
        "all_source_sha256": canonical_sha(records),
        "production_source_sha256": canonical_sha(production),
        "test_source_sha256": canonical_sha(tests),
        "benchmark_sha256": sha256(root / BENCH_SOURCE),
        "shared_helper_sha256": sha256(root / HELPER_SOURCE),
    }


def freeze(args: argparse.Namespace) -> int:
    if args.timeout_seconds <= 0:
        raise ValueError("sample deadline must be positive")
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise ValueError(f"refusing to replace existing freeze: {output}")
    baseline = source_snapshot(args.baseline_root.resolve())
    candidate = source_snapshot(args.candidate_root.resolve())
    if (baseline["local_head"], baseline["local_head_tree"]) != (BASE_COMMIT, BASE_TREE):
        raise ValueError("baseline is not the declared exact original main commit/tree")
    if baseline["tracked_working_changes"] or baseline["tracked_staged_changes"]:
        raise ValueError("baseline has tracked changes beyond the intentional benchmark overlay")
    if baseline["untracked_source_files"] != [BENCH_SOURCE]:
        raise ValueError("baseline must have only the benchmark overlay as untracked source")
    if candidate["tracked_working_changes"] or candidate["untracked_source_files"]:
        raise ValueError("candidate must match its staged, authenticated source tree")
    for value in (args.candidate_commit, args.candidate_tree):
        if not re.fullmatch(r"[0-9a-f]{40}", value):
            raise ValueError("candidate commit/tree must be full lowercase Git object IDs")
    index_tree = git(args.candidate_root.resolve(), "write-tree")
    if index_tree != args.candidate_tree:
        raise ValueError(f"candidate index tree {index_tree} differs from authenticated tree {args.candidate_tree}")
    if baseline["benchmark_sha256"] != candidate["benchmark_sha256"]:
        raise ValueError("baseline and candidate benchmark overlays differ")
    if baseline["shared_helper_sha256"] != HELPER_SHA256 or candidate["shared_helper_sha256"] != HELPER_SHA256:
        raise ValueError("the common helper is not the unchanged baseline helper")
    baseline.update({"authenticated_commit": BASE_COMMIT, "authenticated_tree": BASE_TREE})
    candidate.update({
        "authenticated_commit": args.candidate_commit,
        "authenticated_tree": args.candidate_tree,
        "local_index_tree": index_tree,
        "identity_provenance": "commit/tree supplied from the authenticated GitHub adapter; local staged tree checked for equality",
    })
    runtime_environment = {key: os.environ.get(key) for key in RUNTIME_KEYS}
    runtime_environment.update({
        "GOWORK": "off", "GOMEMLIMIT": "4GiB", "GOMAXPROCS": "2",
        "TMPDIR": str(args.tmpdir.resolve()),
    })
    manifest = {
        "version": 1, "frozen_at_utc": now(),
        "benchmark": BENCHMARK, "rows": 4096, "rows_per_request": 128,
        "writer_count": 1, "profile": "command_wal_durable", "memtable_mode": "cow_btree",
        "sample_order": ORDER, "binary_arguments": FLAGS,
        "timeout_seconds_per_sample": args.timeout_seconds,
        "runtime_environment": runtime_environment,
        "runner_path": str(Path(__file__).resolve()), "runner_sha256": sha256(Path(__file__)),
        "python_executable": str(Path(sys.executable).resolve()), "python_version": sys.version,
        "host": platform.uname()._asdict(),
        "arms": {"baseline": baseline, "candidate": candidate},
        "scope": "Successful public sequential lifecycle cost control; no forced overlap and no speedup acceptance claim. Source files include repository Go/build inputs; authenticated Git trees bind remaining tracked assets, and go.mod/go.sum bind module dependencies.",
    }
    write_json(output, manifest)
    print(json.dumps({"freeze": str(output), "sha256": sha256(output), "candidate_commit": args.candidate_commit, "candidate_tree": args.candidate_tree}))
    return 0


def usage() -> dict:
    observed = resource.getrusage(resource.RUSAGE_CHILDREN)
    return {name: getattr(observed, name) for name in RUSAGE_FIELDS}


def parse_benchmark(stdout: str, stderr: str) -> dict:
    errors = []
    phases = []
    for line in stdout.splitlines():
        match = re.search(r"LIFECYCLE_PHASE (\{.*\})\s*$", line)
        if match:
            try:
                phases.append(json.loads(match.group(1)))
            except json.JSONDecodeError as exc:
                errors.append(f"invalid phase JSON: {exc}")
    if len(phases) != 3 or sorted((p.get("load"), p.get("phase")) for p in phases) != [(0, "checkpoint"), (0, "optimize"), (0, "seed")]:
        errors.append("expected exactly one seed, Optimize and Checkpoint record for load 0")
    for phase in phases:
        if not all(isinstance(phase.get(key), int) and phase[key] >= 0 for key in ("nanos", "allocated_bytes", "allocations", "heap_alloc_at_start", "heap_alloc_at_end")):
            errors.append(f"missing numeric phase measurement: {phase.get('phase')}")
        for boundary in ("cow_before", "cow_after"):
            if not isinstance(phase.get(boundary), dict) or len(phase[boundary]) != 9:
                errors.append(f"missing original phase counters: {phase.get('phase')}/{boundary}")
    rows = re.findall(rf"^{BENCHMARK}(?:-\d+)?\s+(\d+)\s+(.+)$", stdout, re.MULTILINE)
    metrics = {}
    if len(rows) != 1 or rows[0][0] != "1":
        errors.append("expected exactly one completed 1x benchmark result")
    else:
        fields = rows[0][1].split()
        if len(fields) % 2:
            errors.append("malformed benchmark metric pairs")
        else:
            try:
                metrics = {fields[i + 1]: float(fields[i]) for i in range(0, len(fields), 2)}
            except ValueError as exc:
                errors.append(f"invalid benchmark metric: {exc}")
        required = {"ns/op", "B/op", "allocs/op", "records/op", "cow_peak_B"}
        required.update(f"{phase}_{unit}/load" for phase in ("seed", "optimize", "checkpoint") for unit in ("ns", "B", "allocs"))
        if not required.issubset(metrics) or metrics.get("records/op") != 4096:
            errors.append("missing complete fixed-geometry benchmark metrics")
        if not all(math.isfinite(value) and value >= 0 for value in metrics.values()):
            errors.append("nonfinite or negative benchmark metric")
    closed = re.findall(r"LIFECYCLE_CLOSED load=(\d+) heap_alloc_after_gc=(\d+) heap_sys=(\d+) sys=(\d+)", stdout)
    retained = None
    if len(closed) != 1 or closed[0][0] != "0":
        errors.append("missing one post-Close retention record for load 0")
    else:
        retained = dict(zip(("load", "heap_alloc_after_gc", "heap_sys", "sys"), map(int, closed[0])))
    if stdout.count("completed_graph_rows=4096 optimize_calls=1") != 1:
        errors.append("missing exact completed graph observation")
    if not re.search(r"^PASS\s*$", stdout, re.MULTILINE):
        errors.append("missing original Go PASS trailer")
    if "DATA RACE" in stdout or "DATA RACE" in stderr:
        errors.append("data-race diagnostic in original output")
    return {"errors": errors, "metrics": metrics, "phases": phases, "post_close": retained}


def worker(args: argparse.Namespace) -> int:
    # Do not invoke Git, Go, uname, or any other subprocess in this worker.
    # The one benchmark binary below must be its sole child.
    manifest = json.loads(args.manifest.read_text())
    arm = manifest["arms"][args.arm]
    sample = args.sample.resolve()
    sample.mkdir(parents=True, exist_ok=False)
    binary = Path(arm["binary_path"])
    if sha256(binary) != arm["binary_sha256"]:
        raise ValueError("binary changed after binding")
    environment = os.environ.copy()
    for key, value in manifest["runtime_environment"].items():
        if value is None:
            environment.pop(key, None)
        else:
            environment[key] = value
    before = usage()
    if any(before[key] != 0 for key in RUSAGE_FIELDS):
        raise ValueError("worker already has child resource usage; measurement is invalid")
    command = [str(binary), *manifest["binary_arguments"]]
    began = now()
    start = time.monotonic_ns()
    timed_out = False
    with (sample / "benchmark.stdout").open("xb") as stdout, (sample / "benchmark.stderr").open("xb") as stderr:
        process = subprocess.Popen(command, cwd=arm["root"], env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            returncode = process.wait(timeout=manifest["timeout_seconds_per_sample"])
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            returncode = process.wait()
    elapsed_ns = time.monotonic_ns() - start
    after = usage()
    try:
        parsed = parse_benchmark((sample / "benchmark.stdout").read_text(errors="replace"), (sample / "benchmark.stderr").read_text(errors="replace"))
    except Exception as exc:
        parsed = {"errors": [f"output parser failed: {type(exc).__name__}: {exc}"], "metrics": {}, "phases": [], "post_close": None}
    classification = "timeout" if timed_out else "fail" if returncode != 0 else "invalid" if parsed["errors"] else "pass"
    rss_scale = 1024 if sys.platform.startswith("linux") else 1 if sys.platform == "darwin" else None
    if rss_scale is None:
        raise ValueError(f"unsupported ru_maxrss units for platform {sys.platform}")
    receipt = {
        "arm": args.arm, "sample_number": args.number, "classification": classification,
        "started_at_utc": began, "completed_at_utc": now(), "elapsed_ns": elapsed_ns,
        "command": command, "cwd": arm["root"], "runtime_environment": manifest["runtime_environment"],
        "exit_status": returncode, "timed_out": timed_out,
        "rusage_children_before": before, "rusage_children_after": after,
        "user_cpu_seconds": after["ru_utime"] - before["ru_utime"],
        "system_cpu_seconds": after["ru_stime"] - before["ru_stime"],
        "peak_rss_bytes": after["ru_maxrss"] * rss_scale,
        "ru_maxrss_native_unit": "KiB" if rss_scale == 1024 else "bytes",
        "source_commit": arm["authenticated_commit"], "source_tree": arm["authenticated_tree"],
        "all_source_sha256": arm["all_source_sha256"], "production_source_sha256": arm["production_source_sha256"],
        "benchmark_sha256": arm["benchmark_sha256"], "shared_helper_sha256": arm["shared_helper_sha256"],
        "binary_sha256": arm["binary_sha256"], "bound_manifest_sha256": sha256(args.manifest),
        "stdout_sha256": sha256(sample / "benchmark.stdout"), "stderr_sha256": sha256(sample / "benchmark.stderr"),
        "parsed": parsed,
        "rss_scope": "Peak RSS of the single benchmark child, including untimed setup/validation/Close/reopen. It is not graph-only memory or a phase allocation metric.",
    }
    write_json(sample / "receipt.json", receipt)
    print(json.dumps({"sample": str(sample), "classification": classification, "exit_status": returncode, "peak_rss_bytes": receipt["peak_rss_bytes"]}))
    return 0 if classification == "pass" else 1


def summarize(samples: list[dict]) -> dict:
    arms = {}
    for name in ("baseline", "candidate"):
        selected = [s for s in samples if s["arm"] == name]
        passed = [s for s in selected if s.get("classification") == "pass"]
        arm = {"samples": len(selected), "successful_samples": len(passed), "all_three_complete": len(passed) == 3, "statistics": None}
        if len(passed) == 3:
            measurements = {}
            for sample in passed:
                values = dict(sample["parsed"]["metrics"])
                values.update({key: sample[key] for key in ("peak_rss_bytes", "elapsed_ns", "user_cpu_seconds", "system_cpu_seconds")})
                values["post_close_heap_alloc_after_gc"] = sample["parsed"]["post_close"]["heap_alloc_after_gc"]
                for key, value in values.items():
                    measurements.setdefault(key, []).append(value)
            arm["statistics"] = {key: {"n": len(values), "median": statistics.median(values), "min": min(values), "max": max(values)} for key, values in measurements.items()}
        arms[name] = arm
    return {"all_six_complete": all(a["all_three_complete"] for a in arms.values()), "arms": arms, "interpretation": "No retry, exclusion of failed samples, or speedup acceptance claim. Aggregate statistics require all three planned samples for that arm to complete."}


def run(args: argparse.Namespace) -> int:
    frozen = json.loads(args.freeze.read_text())
    if frozen["runner_sha256"] != sha256(Path(__file__)):
        raise ValueError("runner changed after source freeze")
    if frozen["sample_order"] != ORDER or frozen["binary_arguments"] != FLAGS:
        raise ValueError("frozen protocol does not match fixed six-sample lifecycle protocol")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    for name, path, receipt_path in (
        ("baseline", args.baseline_binary, args.baseline_build_receipt),
        ("candidate", args.candidate_binary, args.candidate_build_receipt),
    ):
        arm = frozen["arms"][name]
        current = source_snapshot(Path(arm["root"]))
        if current["source_files"] != arm["source_files"]:
            raise ValueError(f"{name} source bytes changed after freeze")
        binary = path.resolve(strict=True)
        if not binary.is_file() or not os.access(binary, os.X_OK):
            raise ValueError(f"{name} binary is not executable: {binary}")
        arm["binary_path"], arm["binary_sha256"] = str(binary), sha256(binary)
        build_receipt = receipt_path.resolve(strict=True)
        build = json.loads(build_receipt.read_text())
        if build.get("exit_status") != 0 or build.get("binary_sha256") != arm["binary_sha256"] or build.get("source_freeze_sha256") != sha256(args.freeze):
            raise ValueError(f"{name} build receipt does not bind a successful build of this frozen source and binary")
        if Path(build.get("cwd", "")).resolve() != Path(arm["root"]) or not isinstance(build.get("command"), list) or not build["command"] or not build.get("go_version"):
            raise ValueError(f"{name} build receipt lacks exact command, cwd or Go version")
        if "-race" in build["command"]:
            raise ValueError("this protocol measures normal binaries, not race-instrumented binaries")
        arm["build_receipt"] = {"path": str(build_receipt), "sha256": sha256(build_receipt)}
        arm["go_version"] = build["go_version"]
    if frozen["arms"]["baseline"]["go_version"] != frozen["arms"]["candidate"]["go_version"]:
        raise ValueError("the two builds used different Go toolchain versions")
    for key in RUNTIME_KEYS:
        if os.environ.get(key) != frozen["runtime_environment"][key]:
            raise ValueError(f"inherited runtime environment changed after freeze: {key}")
    Path(frozen["runtime_environment"]["TMPDIR"]).mkdir(parents=True, exist_ok=True)
    frozen["source_freeze_path"] = str(args.freeze.resolve())
    frozen["source_freeze_sha256"] = sha256(args.freeze)
    frozen["binaries_bound_at_utc"] = now()
    bound = output / "bound-manifest.json"
    write_json(bound, frozen)
    samples = []
    for number, arm in enumerate(ORDER, 1):
        sample = output / f"sample-{number:02d}-{arm}"
        command = [sys.executable, str(Path(__file__).resolve()), "_worker", "--manifest", str(bound), "--arm", arm, "--number", str(number), "--sample", str(sample)]
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        (output / f"worker-{number:02d}.stdout").write_text(result.stdout)
        (output / f"worker-{number:02d}.stderr").write_text(result.stderr)
        write_json(output / f"worker-{number:02d}.json", {"command": command, "exit_status": result.returncode})
        receipt = sample / "receipt.json"
        if receipt.exists():
            observed = json.loads(receipt.read_text())
            observed["worker_exit_status"] = result.returncode
            if observed["classification"] == "pass" and result.returncode != 0:
                observed["classification"] = "invalid"
                observed["reason"] = "worker failed after producing a successful child receipt"
            samples.append(observed)
        else:
            samples.append({"arm": arm, "sample_number": number, "classification": "invalid", "worker_exit_status": result.returncode, "reason": "worker produced no receipt; retain worker stdout/stderr"})
        print(json.dumps({"sample_number": number, "arm": arm, "classification": samples[-1]["classification"]}), flush=True)
    summary = summarize(samples)
    write_json(output / "samples.json", samples)
    write_json(output / "summary.json", summary)
    print(json.dumps({"output": str(output), "all_six_complete": summary["all_six_complete"]}), flush=True)
    return 0 if summary["all_six_complete"] else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    prepare = commands.add_parser("freeze", help="freeze source bytes and authenticated candidate identity before compilation/measurement")
    prepare.add_argument("--baseline-root", type=Path, required=True)
    prepare.add_argument("--candidate-root", type=Path, required=True)
    prepare.add_argument("--candidate-commit", required=True)
    prepare.add_argument("--candidate-tree", required=True)
    prepare.add_argument("--tmpdir", type=Path, required=True)
    prepare.add_argument("--output", type=Path, required=True)
    prepare.add_argument("--timeout-seconds", type=int, default=180)
    prepare.set_defaults(action=freeze)
    execute = commands.add_parser("run", help="bind prebuilt binaries and run six sequential fresh-process samples")
    execute.add_argument("--freeze", type=Path, required=True)
    execute.add_argument("--baseline-binary", type=Path, required=True)
    execute.add_argument("--candidate-binary", type=Path, required=True)
    execute.add_argument("--baseline-build-receipt", type=Path, required=True)
    execute.add_argument("--candidate-build-receipt", type=Path, required=True)
    execute.add_argument("--output", type=Path, required=True)
    execute.set_defaults(action=run)
    child = commands.add_parser("_worker", help=argparse.SUPPRESS)
    child.add_argument("--manifest", type=Path, required=True)
    child.add_argument("--arm", choices=("baseline", "candidate"), required=True)
    child.add_argument("--number", type=int, required=True)
    child.add_argument("--sample", type=Path, required=True)
    child.set_defaults(action=worker)
    args = parser.parse_args()
    try:
        return args.action(args)
    except Exception as exc:
        print(f"INVALID_PROTOCOL: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
