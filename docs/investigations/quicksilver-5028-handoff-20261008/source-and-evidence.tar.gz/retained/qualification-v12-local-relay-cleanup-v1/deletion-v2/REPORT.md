# Completed exact released local relay cleanup

**COMPLETE: all three released directories were deleted locally and their actual paths are absent.** The relay parent and all provisioning receipts were preserved. No move, archive, new preservation copy or path recreation occurred.

Deleted exact paths:
- `quiet-runner-provisioning-v1/relay/modules`
- `quiet-runner-provisioning-v1/relay/native`
- `quiet-runner-provisioning-v1/relay/toolchain`

Sole deletion owner: `/root/r5037_current_composition_review`. Authority: root's exact three-directory release SHA `0b41affc3efd749470a8ae09546bedc884df5aaff9e4f9343b0bd462d6816fda`, supplemented by root's explicit routine cleanup message retained here. The immutable V1 receipt retains the first permission failure and conservative toolchain retention. The failed modules attempt changed/deleted zero entries.

Immediately before each actual deletion, the corresponding complete original snapshot matched all regular-file bytes/SHA, types, dev/inode, modes, uid/gid, link counts, sizes/blocks, ns mtime/ctime, literal symlink identities and the complete path set. Snapshots cover 30,948 modules entries, 130 native entries and 16,737 toolchain entries. Canonical roots, absence of mount/device boundaries and protected registered worktrees, and current ps/lsof consumers were checked. Complete metadata/path reenumeration closed each full content check; no active consumer was found. `shutil.rmtree.avoids_symlink_attacks` was true and fd-based removal followed no symlinks.

Root specifically admitted the original copied Go repository within toolchain. Read-only Git inspections used `GIT_OPTIONAL_LOCKS=0`. Origin: `/home/mikers/.gvm/archive/go`; detached HEAD: `2dc996f71b0ebafb77e64433e58333e049488a3c`. The sole status row was `?? manifest`; its exact bytes and the complete `.git` tree/refs matched the original snapshot. No `.git/worktrees` administration directory existed. Raw config/HEAD/refs/status evidence is retained. Complete original relay/native install checksum evidence and current source-lock native path bindings are retained in the original inventory; no native reread was performed.

After a new full modules snapshot and live consumer check passed, root's expressly authorized permission repair added owner write/execute through `O_NOFOLLOW` directory fds to precisely 3,697 originally snapshotted, same-owner module-cache directory nodes. The receipt records each device/inode, old/new mode and ctime. No file/symlink/other-node permission changed. The complete path/metadata set then matched the expected original set with only these controlled mode/ctime changes. Removal succeeded; no automatic unreviewed retry or scope expansion occurred.

All original inventory artifacts, provisioning receipts, source lock and explicitly bound protected inputs passed SHA/byte checks before and after both operations. All 38 protected gomap worktree registrations remained present; complete raw registration output was byte-identical. The protected relay/provisioning/BASE ancestor device/inode/type/mode identities were preserved. Primary checkout, worktrees, raw failures/profiles/results, current frozen source closure, P9/root_native_io and native installations were preserved.

Local available bytes at the first attempt: 3387396096; after the final deletion: 4993048576 (overall observed difference +1605652480 bytes). V2's before/after observation was 3345010688 -> 4993048576 (+1648037888 bytes). These observations include concurrent filesystem activity; they do not establish uniquely attributable APFS physical reclamation. Original allocated-byte snapshot total: 1,663,463,424 bytes.

Actual receipts: immutable V1 attempt plus `deletion-receipt-v2.json` for the resolved removals, controlled permission changes, command timestamps/return codes, stream hashes, protected checks and final actual absence. `final-path-absence-v1.json` performs another final absence check. The relay parent is retained. No native I/O, source/Git/state/GH mutation, build, benchmark, DB activity or unrelated deletion occurred. No qualification, performance or merge acceptance is asserted. Held #5004/PR5006 remain excluded.
