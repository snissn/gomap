Inventory only: the three local relay directories are eligible candidates for root release. Nothing was deleted, moved, archived, copied for preservation, or changed in Git/state. Native timed work was untouched: no SSH/native reads, no scans of installed native trees or benchmark DBs, and no runtime/build/test actions.

Exact proposed targets (all device16777231):

| Relative to quiet-runner-provisioning-v1/relay | Inode | Entries | Apparent bytes including directory metadata | st_blocks allocated bytes |
|---|---:|---:|---:|---:|
| modules | 486010285 | 30948 | 775666186 | 843796480 |
| native | 486007928 | 130 | 33847699 | 34078720 |
| toolchain | 485981787 | 16737 | 743605643 | 785588224 |

Total47,815 entries,1,553,119,528 apparent bytes and1,663,463,424 allocated bytes (about1.55GiB allocated). Reclaimed free space is not guaranteed by allocated-size estimates because APFS sharing/snapshots and concurrent writes may differ. Available local bytes at completed snapshot:1,704,275,968.

Complete snapshots retain every path/type, device/inode, uid/gid/mode/nlink, size/blocks, mtime_ns/ctime_ns; all42,084 regular files have full SHA256 hashes, six native symlinks retain literal targets. Each tree was then re-enumerated and every metadata/path identity compared; no additions/replacements/changes, special files or device boundaries were found. Native symlinks used for retained input comparison resolve inside native target; deletion must never follow links. No regular-file multi-link cases found. Compressed JSONL files are metadata inventories, not preservation copies of payloads. Exact root nanosecond mtimes and ctimes are in inventory.json, not rounded shell timestamps.

Provisioning provenance: all13 complete receipt rows exactly equal their individual *-run.json; all recorded stdout/stderr SHA hashes verified. Each toolchain/native/modules relay/install returned rc0, and both origin and installed-copy checksum dry runs used rsync -acn --itemize-changes, rc0 with empty stdout/stderr. Completed producers are the receipt-recorded13 PIDs; none was live at inspection. Preserve these receipts and provision-quiet-runner.py outside the three targets.

Installed copies remain on192.168.0.111 under /home/mikers/quicksilver-maintenance-5028-20261006: toolchain/go1.26.3, native, cache/go-mod. Current retained actual-fresh-source-lock-v12.json SHA bda4d248... selects those exact native GOROOT/GOMODCACHE/native library paths, never local relay. All3,425 selected toolchain/module/native inputs in original_actual_files/required_current_files/go_tool match freshly hashed local bytes, including go executable d68b7abb... and selected libraries. This verifies retained current native identity through accepted source-lock bindings and genuine complete provisioning receipts; no claim of a new native readback is made during measurement. The full current native source closure and installed module cache must remain protected.

Local consumer inspection: ps axo pid/ppid/lstart/command succeeded; no command references an exact relay target and no provisioning PID remained. lsof -nP -Fpcn succeeded rc0 with empty stderr and found no relay file/cwd/mapped/open handles. git ls-files found no tracked paths under relay. Registered worktrees are captured read-only in protected-worktree-registration.txt; none is nested in a target. Current accepted pre-C1/post-small anchor, continuation finite config and current P9/root_native_io.py have no local relay pathname reference. Consumer checks are time-specific observations, not deletion authorization.

Protect all primary tracked/dirty/unrelated content, every registered or unregistered active/provisional worktree, all raw failures/profiles/results, all frozen source/receipt closure, current P9/root_native_io and all native installations. Only the three exact local paths may be considered; relay parent, provisioning receipts, source controls, shared real caches and installed native copies are excluded.

Root must issue its exact three-directory release allowlist before deletion. Immediately before each deletion, recheck exact root identity and complete snapshot contents/metadata, nested worktree/mount/link boundaries and current processes/handles; any mismatch/activity/uncertainty means retain. The snapshots are an inventory handoff, not a future accepted release. No native timed I/O conflict was introduced; all inventory hashing occurred locally at nice19.
