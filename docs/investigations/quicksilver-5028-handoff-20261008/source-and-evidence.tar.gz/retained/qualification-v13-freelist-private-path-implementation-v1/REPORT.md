# Freelist allocation private-path refinement

Implemented and committed locally as `01ad34afed6d64f58d8504a57a247170289e4772`, parent `e70deeff0085c51278e57a272d4de1e622e63fe2`, in the clean sole-writer `/private/tmp/gomap-qs-5015`. Root selection SHA: `b52019dfce7574dda0688a98049a63e54628e72ea80b9d11c3cd330a27d9c16e`. No push, merge, native launch, SSH, GH, primary/B edits, root-state write, gate change, held #5004/5006 or adjacent c9f85 work. This is an implementation handoff for root review; original qualification/performance/CI gates remain required.

## Change and ownership proof

`generation_v1_txn.go:185–200` adds exactly two private fields: the current root pointer and one chunk number. Successful **persistent** `mutateMany` (`:283–288`) clones all 15 radix nodes and its state chunk, then records only that complete path as private. Dirty siblings never qualify. `Allocate` (`:300–318`) runs the unchanged reservation-aware selector first. It clears one selected free bit in place only when both recorded fields match the current root/chunk and the complete path validates. Otherwise it uses the original persistent mutation. Logical mutation counters and changed-chunk bookkeeping use one shared accounting helper; private paths have no durable page IDs to replace.

`generation_v1_tree.go:228–258` validates the complete path and free bit before mutation, retains identical empty-chunk behavior, then recomputes every ancestor summary. All other mutations, contiguous metadata/auxiliary clearing, retirement and pruning retain their persistent COW paths. No changed selector, hint, allocation ordering, format, API, durable accounting or metadata placement algorithm.

Actual sharing seams audited:

- `BeginCandidateV1` (`generation_v1_txn.go:228–246`) shares immutable base state with **no** private proof, including unmaterialized model bases with page ID zero. Other simultaneously opened transactions cannot inherit authority.
- `cloneForAllocatorPrepare` (`:205–225`) revokes proof before copying, so both original rollback and staged branch must copy their next selected path. Nested forks have the same rule. Existing mutable collection copies remain intact.
- `allocator_cow.go:388–451` stages under the allocator mutex, preserves pre-clone profile/limit checks, and restores the original transaction, counters and ledger on failed preparation. Abort (`:455–488`) restores the proof-revoked original. Activation begins a fresh candidate from the immutable materialized generation. Waiting, reservation horizons and prepared immutability are unchanged.
- `MaterializeCandidate` (`generation_v1_txn.go:729–764`) revokes proof before metadata selection and again when consuming the transaction, before detach/emission assigns page identities. Both reused-metadata selected-path/sibling isolation and full detach remain intact. Success and partial sink failure consume the transaction as before.
- `generation_v1_metadata_reuse.go:215` shallow-copies a read-only sizing plan. It does not mutate or publish that plan's root. Its actual bit-clear remains pure COW. `detachMetadataSiblings` still receives the just-copied selected path. No other production transaction value copies/root-sharing assignments were found in the finite freelist caller set.
- Model tests directly construct a generation from a transaction root and stop using the previous transaction; metadata tests hold roots across materialization. Neither supplies mutable private authority to a successor. Arbitrary external value-copy use of the exported mutable transaction has no newly established isolation contract.

Allocator entry points retain their existing mutex. There is no new same-transaction concurrent-use guarantee. The private clear takes no callback/context and validates before the first write; no new cancellable step or user panic boundary appears. Ordinary sink errors, retry and abort retain existing behavior. Existing generic mutation callbacks still use COW; panic recovery/continued use of an interrupted allocator preparation is not newly promised. Process-fatal allocation failure has no new recovery contract.

## Caller coverage and memory bound

The refinement serves real single-page `Allocator.Alloc` calls as well as its existing sequential `AllocMany` loop (`allocator.go:248–264`). `db/alloc_tracker.go:32`, optimistic `db/batch.go:400`, serialized `:737`, and grouped `root_publication_build_group.go:281` all reach that same allocation seam. The only two production optional `AllocMany` sites remain zipper leaf/internal rebalance (`zipper.go:3843,4281`), including their existing partial-ID retirement/fallback. The outer-value-log leaf path bypasses the leaf AllocMany site; an AllocMany-only improvement would miss the ordinary group tracker.

For N successive successful allocations within one private chunk, full state-path clone objects decrease from 16N to 16; selector traversal, summary recomputation, ID recording and ledger checks remain. A chunk contains at most 256 free bits. Switching chunks or sharing/forking invalidates reuse, and append allocation gains nothing. Authority adds a pointer and uint64 to each transaction (16 bytes of field payload on this 64-bit target), no history collection or separate retained tree. The proof always references the current root, and clears before consumption. Production locality, whole-process allocation improvement, retained heap and RSS benefit are **UNKNOWN** until root's matched profiling/qualification.

## Test-first and bounded validation

Before implementation, the allocation discriminator failed: 64 actual Allocate calls used **1,038** heap allocations versus the test's <=96 bound. All other initial differential/fork/materialization/overflow tests passed. After implementation the discriminator records **30** allocations. This is a real allocator invocation measurement, not an assertion on the new proof fields.

New tests in `generation_v1_private_path_test.go` cover 420-step same/chunk-switch/reserved-preferred/reserved-all ID, root, allocation-record and stats equivalence against the original persistent mutation, then exact materialized page bytes, generation reference and reservation record; immutable base; both staging branches and nested concurrent clones; warm real AllocMany followed by failed prepare or abort and further allocation; retained prepared roots; materialization success/failure; append overflow and real AllocMany partial success IDs/counters before overflow. Existing model, metadata shared-dirty-branch, losing-claim, partial sink, reservation, generation byte/digest, prepare limit and rollback tests remain unchanged and pass.

Full freelist normal and race suites pass on final source. Actual DB focused normal/race checks pass, including group final staging/abort, full-scan fallback/overflow, optimistic concurrent-root conflict/rebase/cold build, failed prepare rollback, root mismatch retry, and WriteSync reopen. Commands, environments, raw results and durations are in paired `*.json`/`*.txt` artifacts. All tests/benchmarks use owned Go 1.26.0, GOWORK=off, GOTOOLCHAIN=local, GOMAXPROCS=4. No broad Go test suite was launched. Repository initial commit hook ran `go fmt ./...` with inherited environment, made no changes, and its precise toolchain is UNKNOWN; explicit owned gofmt had already formatted all changed Go inputs. Final amend used the explicit leased environment (hook skipped with no new staged files). Final Git bytes equal the tested working files.

Focused benchmark, 128 actual Allocate calls per operation, three 100x runs on local Darwin/arm64 Apple M3:

| Shape | Before | After |
| --- | --- | --- |
| Same chunk | 668,321–668,323 B/op; 2,063 allocs/op; 145,260–152,155 ns/op | 9,952 B/op; 31 allocs/op; 72,672–74,505 ns/op |
| Alternating chunks | 668,322–668,323 B/op; 2,063 allocs/op; 145,805–153,652 ns/op | 668,321–668,323 B/op; 2,063 allocs/op; 151,224–152,876 ns/op |

These microbench numbers establish the intended local allocation discriminator and unchanged fallback cost, not whole-service speed or performance acceptance. The benchmark function is unchanged between before/after; the initially failing test file was subsequently expanded with safety coverage and its complete earlier file bytes were not separately retained. Before runtime implementation source is bound to exact parent Git objects; final harness/source is bound to final commit objects.

Updated the existing Freelist Generation V1 storage spec with runtime ownership rules and unchanged encoding. After staging intended source/test/docs, refreshed canonical CI inventory: only `discovery_source_sha256` changed, 14 workflows/56 existing members and reviewed ownership retained. Refresh/check, 15 generator tests, 21 impact tests, 6 TreeDB CI-contract tests and 16 Windows headroom tests all pass. Clean final working tree. Root owns review, native comparison, CI qualification, integration and merge.
