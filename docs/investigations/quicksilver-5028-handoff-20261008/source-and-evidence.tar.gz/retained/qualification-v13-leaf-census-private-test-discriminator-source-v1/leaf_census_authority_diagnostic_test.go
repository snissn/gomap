// Diagnostic overlay only. No production export, repair or scheduling change.
package db

import (
 "context"
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "errors"
 "fmt"
 "io"
 "math"
 "os"
 "testing"
 "time"

 "github.com/snissn/gomap/TreeDB/internal/rootpublication"
 "github.com/snissn/gomap/TreeDB/page"
)

const qsv13TargetRawID uint32 = 2139095277

// Root must separately admit the exact frozen source and closed DB path.
// No default DB selection and no invocation from a normal test run.
func TestQSV13ReadOnlyLeafCensusAuthority(t *testing.T) {
 dir := os.Getenv("QSV13_LEAF_CENSUS_DB")
 if dir == "" { t.Skip("explicit closed diagnostic DB path required") }
 out := map[string]any{
  "scope":"post-close read-only leaf GC census with private authority discrimination",
  "read_only":true,"dry_run":true,"qualified":false,"qualification":false,
  "numerical_accepted":false,"performance_accepted":false,"product_accepted":false,"change_accepted":false,"merge_accepted":false,
  "held_excluded":[]int{5004,5006},"target_raw_id":qsv13TargetRawID,
  "target_marked_id":page.ValueLogFileID(qsv13TargetRawID),
 }
 started := time.Now()
 err := qsv13ReadOnlyLeafCensus(dir,out)
 out["wall_ns"] = time.Since(started).Nanoseconds()
 if err != nil { out["error"] = err.Error() }
 encoded, encodeErr := json.Marshal(out)
 if encodeErr != nil { t.Fatalf("encode retained diagnostic: %v",encodeErr) }
 fmt.Println("QSV13_LEAF_CENSUS_JSON",string(encoded))
 if err != nil { t.Fail() }
}

func qsv13ReadOnlyLeafCensus(dir string,out map[string]any) (err error) {
 cfg, exists, err := LoadFormatConfig(dir)
 if err != nil { return err }
 if !exists || cfg.DurabilityProfile != ProfileCommandWALDurable || !cfg.IndexOuterLeavesInValueLog {
  return fmt.Errorf("expected persisted command_wal_durable and outer-leaf format")
 }
 opts := Options{Dir:dir,ReadOnly:true,ResolvedProfile:cfg.DurabilityProfile,
  CommandWAL:true,Durability:DurabilityDurable,VerifyOnRead:true}
 cfg.ApplyToOptions(&opts)
 opts.ValueLog.ReadIntegrity = IntegrityVerify
 out["format"] = cfg
 opened := time.Now()
 database, err := Open(opts)
 out["open_wall_ns"] = time.Since(opened).Nanoseconds()
 if err != nil { return err }
 defer func() {
  if closeErr := database.Close(); closeErr != nil {
   out["close_error"] = closeErr.Error()
   if err == nil { err = closeErr }
  }
 }()
 inspectionErr := qsv13InspectAuthority(database,out)
 if inspectionErr != nil { out["inspection_error"] = inspectionErr.Error() }
 // The original scan gets its original two-minute context after diagnostics.
 ctx, cancel := context.WithTimeout(context.Background(),2*time.Minute)
 defer cancel()
 scanStarted := time.Now()
 stats, censusErr := database.LeafGenerationGC(ctx,LeafGenerationGCOptions{DryRun:true})
 out["scan_wall_ns"] = time.Since(scanStarted).Nanoseconds()
 out["stats"] = stats
 if censusErr != nil { out["census_error"] = censusErr.Error(); return censusErr }
 return inspectionErr
}

func qsv13InspectAuthority(database *DB,out map[string]any) error {
 d := map[string]any{"eligibility_claim":false,"target_raw_id":qsv13TargetRawID}
 out["authority_discriminator"] = d
 var failures []error
 roots, err := database.CaptureRecoverableRootSetForInspection(context.Background())
 if err != nil { d["inspection_capture_error"] = err.Error(); failures = append(failures,err) } else {
  d["recoverable_roots"] = roots.Roots()
  if err := roots.Revalidate(); err != nil { d["inspection_revalidate_error"] = err.Error(); failures = append(failures,err) } else { d["inspection_revalidated"] = true }
  roots.Release()
  d["inspection_capability_released"] = true
 }
 // The handle is exclusively read-only; locks retain the original field seams.
 // Borrowed slot tokens are never released or transferred by this diagnostic.
 database.teardownMu.RLock()
 database.durablePublishMu.Lock()
 d["selected_slot"] = database.durableRoot.slot
 d["selected_record"] = database.durableRoot.record
 d["slot_commit_seq"] = database.durableRoot.slotCommit
 slots := make([]map[string]any,0,2)
 for slot := 0; slot < 2; slot++ {
  record := database.durableRoot.slotRecord[slot]
  row := map[string]any{"slot":slot,"record":record,"meta":database.durableRoot.slotMeta[slot],"viable_record_present":record.CommitSeq != 0}
  manifests := []map[string]any{}
  targetResources := []map[string]any{}
  resources := database.durableRoot.slotResources[slot]
  row["resources_present"] = resources != nil
  if resources != nil {
   for _, token := range resources.Tokens() {
    if token == nil { continue }
    if token.Kind() == rootpublication.ResourceOuterLeafManifest {
     observed, tokenErr := qsv13InspectManifestToken(token)
     manifests = append(manifests,observed)
     if tokenErr != nil { failures = append(failures,tokenErr) }
    }
    if (token.Kind() == rootpublication.ResourceOuterLeafLog || token.Kind() == rootpublication.ResourceOuterLeafPack) && token.ResourceID() == fmt.Sprint(page.ValueLogFileID(qsv13TargetRawID)) {
     targetResources = append(targetResources,qsv13TokenScalars(token))
    }
   }
  }
  row["outer_leaf_manifest_tokens"] = manifests
  row["target_outer_leaf_tokens"] = targetResources
  row["manifest_token_count"] = len(manifests)
  if len(manifests)>1 { failures = append(failures,fmt.Errorf("slot %d has multiple outer-leaf manifest tokens",slot)) }
  slots = append(slots,row)
 }
 d["slots"] = slots
 database.durablePublishMu.Unlock()
 database.teardownMu.RUnlock()
 database.mu.RLock()
 d["loaded_leaf_manifest"] = qsv13ManifestTarget(database.leafGenerationManifest)
 database.mu.RUnlock()
 // This snapshot owns the set while its exact registered file is inspected.
 // Neither index-builder below stores to the index cache or writes a sidecar.
 snapshot := database.AcquireSnapshot()
 if snapshot == nil { failures = append(failures,ErrClosed); return errors.Join(failures...) }
 target := map[string]any{"registered":false,"builder_called":false}
 d["target_snapshot_backing"] = target
 if snapshot.state == nil || snapshot.state.ValueLogSet == nil {
  failures = append(failures,fmt.Errorf("target snapshot has no ValueLogSet"))
 } else {
  target["snapshot_commit_seq"] = snapshot.state.CommitSeq
  if snapshot.state.LeafGenerations != nil {
   target["active_view_present"] = true
   generationID, present := snapshot.state.LeafGenerations.FileToGeneration[qsv13TargetRawID]
   target["active_view_mapping_present"] = present
   target["active_view_generation_id"] = generationID
  } else { target["active_view_present"] = false }
  markedID := page.ValueLogFileID(qsv13TargetRawID)
  segment := snapshot.state.ValueLogSet.Files[markedID]
  route := "canonical_fallback_log"
  if segment != nil {
   target["registered"] = true
   target["registered_id"] = segment.ID
   target["registered_path"] = segment.Path
   target["open_file_present"] = segment.File != nil
   target["zombie"] = segment.IsZombie.Load()
   target["ref_count"] = segment.RefCount.Load()
   if segment.File != nil {
    route = "registered_snapshot_segment"
    if info, statErr := segment.File.Stat(); statErr != nil { target["registered_stat_error"] = statErr.Error(); failures = append(failures,statErr) } else { target["registered_bytes"] = info.Size(); target["registered_os_identity"] = info.Sys() }
   }
  }
  target["builder_route"] = route
  target["fallback_path"] = leafGenerationFallbackPath(database.dir,qsv13TargetRawID)
  // Inspect the sidecar independently; absence/error/empty are distinct.
  diskIndex, diskPresent, diskErr := database.loadLeafGenerationRecordLengthIndexFromDisk(qsv13TargetRawID)
  target["sidecar_index_present"] = diskPresent
  if diskErr != nil { target["sidecar_index_error"] = diskErr.Error(); target["sidecar_index_not_exist"] = errors.Is(diskErr,os.ErrNotExist); failures = append(failures,diskErr) }
  if diskIndex != nil { target["sidecar_index_record_count"] = diskIndex.len() }
  built, buildErr := database.buildLeafGenerationRecordLengthIndex(qsv13TargetRawID,snapshot.state.ValueLogSet)
  target["builder_called"] = true
  target["builder_success"] = buildErr == nil
  if buildErr != nil { target["builder_error"] = buildErr.Error(); target["builder_not_exist"] = errors.Is(buildErr,os.ErrNotExist); failures = append(failures,buildErr) }
  if built != nil { target["builder_record_count"] = built.len() }
 }
 if closeErr := snapshot.Close(); closeErr != nil { target["snapshot_close_error"] = closeErr.Error(); failures = append(failures,closeErr) }
 d["diagnostic_snapshot_closed_before_census"] = true
 return errors.Join(failures...)
}

func qsv13TokenScalars(token *rootpublication.StableResourceToken) map[string]any {
 digest := token.Digest()
 return map[string]any{"kind":token.Kind(),"resource_id":token.ResourceID(),"generation":token.Generation(),
  "logical_lane":token.LogicalLane(),"diagnostic_path":token.DiagnosticPath(),"frontier":token.Frontier(),
  "identity":token.Identity(),"digest_sha256":hex.EncodeToString(digest[:])}
}

func qsv13InspectManifestToken(token *rootpublication.StableResourceToken) (map[string]any,error) {
 row := qsv13TokenScalars(token)
 frontier := token.Frontier()
 if frontier.Bytes == 0 || frontier.Bytes > math.MaxInt64 {
  err := fmt.Errorf("invalid exact manifest frontier for %s",token.ResourceID()); row["read_error"] = err.Error(); return row,err
 }
 var data []byte
 err := token.WithPinnedFile(func(file *os.File) error {
  var readErr error
  data, readErr = io.ReadAll(io.NewSectionReader(file,0,int64(frontier.Bytes)))
  return readErr
 })
 row["actual_read_bytes"] = len(data)
 if err != nil { row["read_error"] = err.Error(); return row,err }
 if uint64(len(data)) != frontier.Bytes { err = fmt.Errorf("short exact manifest frontier for %s",token.ResourceID()); row["read_error"] = err.Error(); return row,err }
 digest := sha256.Sum256(data)
 row["actual_read_sha256"] = hex.EncodeToString(digest[:])
 row["digest_matches_token"] = digest == token.Digest()
 if digest != token.Digest() { err = fmt.Errorf("exact manifest digest mismatch for %s",token.ResourceID()); row["read_error"] = err.Error(); return row,err }
 manifest, err := decodeLeafGenerationManifest(data,token.ResourceID())
 if err != nil { row["decode_error"] = err.Error(); return row,err }
 row["manifest_target"] = qsv13ManifestTarget(manifest)
 row["revision_matches_token"] = manifest.ManifestRevision == token.Generation()
 if manifest.ManifestRevision != token.Generation() { err = fmt.Errorf("exact manifest revision mismatch for %s",token.ResourceID()); row["decode_error"] = err.Error(); return row,err }
 return row,nil
}

func qsv13ManifestTarget(manifest *leafGenerationManifest) map[string]any {
 if manifest == nil { return map[string]any{"present":false} }
 records := []leafGenerationRecord{}
 for _, generation := range manifest.Generations {
  for _, id := range generation.FileIDs { if id == qsv13TargetRawID { records = append(records,generation); break } }
 }
 return map[string]any{"present":true,"version":manifest.Version,"manifest_revision":manifest.ManifestRevision,
  "current_generation_id":manifest.CurrentGenerationID,"next_generation_id":manifest.NextGenerationID,
  "target_mapping_present":len(records)>0,"target_generation_records":records}
}
