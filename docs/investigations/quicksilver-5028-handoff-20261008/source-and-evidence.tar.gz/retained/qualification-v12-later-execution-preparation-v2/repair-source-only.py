"""Exclusive v2 source-only repair and static evidence; no campaign imports/mains."""
from pathlib import Path
import ast,difflib,hashlib,json,re
BASE=Path('/Users/michaelseiler/dev/snissn/gomap/tmp/quicksilver-maintenance-5028-20261005')
OLD=BASE/'qualification-v12-later-execution-preparation-v1'
OUT=Path(__file__).resolve().parent
NATIVE='/home/mikers/quicksilver-maintenance-5028-20261006'
old_manifest=json.loads((OLD/'exact-source-manifest.json').read_text())
flags=dict(schema=1,source_only=True,accepted_by_root=False,qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
old_snapshot={p.name:sha(p) for p in OLD.iterdir() if p.is_file()}
changes={};outputs={};sources={}
def adapt(name,additional=()):
    path=OLD/name;assert sha(path)==old_manifest['outputs'][name]
    original=path.read_text();s=original;substitutions=[]
    pairs=[('qualification-v12-later-execution-preparation-v1','qualification-v12-later-execution-preparation-v2'),*additional]
    for before,after in pairs:
        hits=s.count(before)
        if not hits:
            assert before.startswith('qualification-v12-later-execution-preparation-'),(name,before)
            continue
        positions=[];offset=0
        for _ in range(hits):
            pos=s.index(before,offset);positions.append(pos);offset=pos+len(before)
        s=s.replace(before,after);substitutions.append(dict(before=before,after=after,count=hits,positions=positions))
    compile(s,str(OUT/name),'exec');ast.parse(s)
    restored=s
    for row in reversed(substitutions):
        before,after=row['before'],row['after']
        for index in reversed(range(row['count'])):
            pos=row['positions'][index]+index*(len(after)-len(before))
            assert restored[pos:pos+len(after)]==after
            restored=restored[:pos]+before+restored[pos+len(after):]
    assert restored==original
    funcs=lambda text:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
    assert funcs(restored)==funcs(original)
    p=OUT/name
    if p.exists():assert p.read_text()==s # first concrete diff was already exclusively published
    else:
        with p.open('x') as f:f.write(s)
    diff=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile=str(path),tofile=str(p)))
    dp=OUT/(name+'.diff')
    if dp.exists():assert dp.read_text()==diff
    else:
        with dp.open('x') as f:f.write(diff)
    a,b=funcs(original),funcs(s)
    changes[name]=dict(original_path=str(path),original_sha256=sha(path),new_sha256=sha(p),declared_substitutions=substitutions,whole_original_source_bytes_exact_after_declared_reversal=True,all_function_ASTs_identical_after_declared_reversal=True,unchanged_function_ASTs=[k for k in a if a[k]==b.get(k)],functions_with_declared_freshness_change=[k for k in a if a[k]!=b.get(k)])
    outputs[name]=sha(p);sources[name]=s
    return outputs[name]
transition_name='root-global-calibration-transition-v12-v1.py'
oldline="        assert activation['deployment']==dict(path=str(PROS/'deployment.accepted.json'),sha256='35a583de6c91c5bb7f00a8df2b82e9a8b43f0da2694c4ee069375ecd6fe4affe')"
newline="        assert activation['deployment']==operational['deployment_binding']\n        assert activation['deployment']['path']==str(PROS/'deployment.accepted.json')"
transition=adapt(transition_name,[(oldline,newline)])
transition_old=old_manifest['outputs'][transition_name]
closure_name='root-full-R-canonical-B-closure-v12-v1.py'
closure=adapt(closure_name,[(transition_old,transition)])
adapt('root-run-original-global-analyses-v12-v1.py',[(transition_old,transition)])
adapt('root-run-full-R-and-global54-v12-v1.py',[(transition_old,transition),(old_manifest['outputs'][closure_name],closure)])
for name in ('root-accept-physical34-v12-v1.py','root-run-physical34-preservation-v12-v1.py','root-run-original-pairs-v12-v1.py','pair-launch-prerequisite-readback-v12-v1.py'):adapt(name)
# Complete source-only interface: loop-read keys and stage-specific transition arguments.
authority_keys=['qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized']
interfaces={}
for name,s in sources.items():
    tree=ast.parse(s)
    keys={n.slice.value for n in ast.walk(tree) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id in ('q','request','req','actual_request') and isinstance(n.slice,ast.Constant) and isinstance(n.slice.value,str)}
    keys.update(authority_keys)
    stage_conditional={}
    if name=='pair-launch-prerequisite-readback-v12-v1.py':keys.update(('driver','guard','selection'))
    if name==transition_name:
        keys.difference_update(('prepared_draft','original_analysis_execution','prospective_binding'))
        stage_conditional={'B-pre':['prepared_draft','prospective_binding'],'R-pre':['prepared_draft','prospective_binding'],'B-accept':['original_analysis_execution'],'R-accept':['original_analysis_execution']}
    interfaces[name]=dict(helper=dict(path=NATIVE+'/'+OUT.name+'/'+name,sha256=outputs[name]),CLI=['python3','-B',name,'ACTUAL_ROOT_REQUEST_PATH','ACTUAL_ROOT_REQUEST_SHA256'],required_top_level_request_keys=sorted(keys),stage_conditional_required_request_keys=stage_conditional,false_authority_fields=authority_keys,unknown_actual_values=None,invocation_accepted_by_root=False,invocation_authorized=False)
write('actual-request-interface.source-only.json',dict(flags,status='SOURCE_ONLY_REQUEST_INTERFACE_REQUIRES_ACTUAL_ROOT_DECISION',campaign_root=NATIVE+'/qualification-v12-refresh/qualification-v10',foundation=NATIVE+'/qualification-v12-source-inventory',held_excluded=[5004,5006],interfaces=interfaces,actual_initial_source_anchor=None,actual_initial_source_file_count=None,actual_post_small_source_anchor=None,actual_post_small_source_file_count=None,actual_controls=None,actual_full_R_and_GLOBAL54_acceptance=None,actual_physical34_acceptance=None))
# Each runtime helper's hardcoded digest is an unchanged original authority or a new helper dependency.
immutable={'4005f6369837ecb7000d3a89b86aeac361b3c9d07ccc323450b60bfa4fbd6219':'original B definition','78b660b14f7eeab54a7fb18a5d298c0b74cce7386af2f50b0080419fbf1bee2b':'original namespace seam','9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd':'original evaluator','e5744ead53031c489e3345c16a48c0b2e7b91c577177d50d25d94adfbe7b79fd':'original B controller','433c5df7016136afc8920b6663c5c0ed5d167cea993b35554a0b54a663764dc6':'original R controller','0f2590a04e3959110e5e5d6f5e2e350a7476a162cbe925939de52191a7efc810':'original R support','2fccfac7a950aad6f397e15d94d5cc7b45d4b45ec5943d567c1a19e26cc4d406':'original-folder complete24 pin manifest','ccc5b23ed271b2bd814fc2678a7e4d99e72f0f381b4a39d37132ae570cdee97d':'original strict consumer v5','fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1':'reviewed original root native IO'}
allowed=dict(immutable);allowed[transition]='current v2 transition helper';allowed[closure]='current v2 closure helper'
audit={}
for name,s in sources.items():
    literals=sorted({n.value for n in ast.walk(ast.parse(s)) if isinstance(n,ast.Constant) and isinstance(n.value,str) and re.fullmatch('[0-9a-f]{64}',n.value)})
    assert all(d in allowed for d in literals),(name,literals)
    assert 'qualification-v11' not in s and '35a583de6c91c5bb7f00a8df2b82e9a8b43f0da2694c4ee069375ecd6fe4affe' not in s
    assert 'qualification-v12-later-execution-preparation-v1' not in s
    audit[name]={d:allowed[d] for d in literals}
write('generated-identity-default-audit.json',dict(flags,files=audit,additional_generated_v11_identity_defaults_found=[],runtime_authority_predicates_changed=False,artifact_and_mathematical_version_names_changed=False))
write('declared-source-deltas-and-AST-verification.json',dict(flags,files=changes,no_modules_imported=True,no_helpers_executed=True))
abi_paths=[BASE/'qualification-v11-fresh-controls-v1/prepare-root-source-context-v1.py',BASE/'qualification-v11-fresh-controls-v1/bind-prospective-v10-v1.py',BASE/'qualification-v12-root-preparation-v1/construct-fresh-controls-v12.py']
write('exact-source-manifest.json',dict(flags,inputs={str(OLD/name):old_manifest['outputs'][name] for name in outputs},ABI_source_inputs={str(p):sha(p) for p in abi_paths},outputs=outputs,immutable_v1_packet_snapshot=old_snapshot,future_actual_requests=None,future_generated_control_hashes=None,future_actual_acceptance_refs=None))
assert {p.name:sha(p) for p in OLD.iterdir() if p.is_file()}==old_snapshot
assert not (OUT/'__pycache__').exists()
print(json.dumps(dict(outputs=outputs,syntax_AST_declared_reversal_and_constant_audit_passed=True,v1_untouched=True),indent=2))
