# Empty-sibling snapshot rotation candidate

The candidate retains truly empty HashSorted sibling tables at snapshot/iterator cuts; populated and tombstone-bearing shards follow the original replacement path. It leaves memtable construction/insertion and generic rotation policies unchanged. Root owns source review, integration and native qualification; all acceptance flags remain false.

## Ownership and mechanism

Base is `01ad34afed6d64f58d8504a57a247170289e4772`. Only leased `TreeDB/caching/db.go`, `snapshot.go` and new `snapshot_empty_rotation_test.go` are changed. `hash_sorted.go` is verified byte-identical to HEAD. No staging/commit/push/GH/state/CI inventory/native/SSH/spawning, held #5004/#5006 or root-owned script edits. Scope is an architectural controller experiment after the retired demand-growth/deferred-reservation candidates, not another insertion repair.

`db.go:28445` returns the actual replacement count from the iterator-specific policy. The existing generic `rotateMutableShardsLocked` wrapper (`28485`) passes false to the single shared rotation loop. Iterator/snapshot callers pass true. The loop (`28494`) admits retention only for unchanged HashSorted mode and no active byte warmup; actual per-shard type must also be HashSorted. Adaptive mode is selected through the original function and a transition disables retention for the whole cut.

The check at `28550` runs with db.mu and that shard.mu held and requires Len==0, shard.bytes==0 and Size()==0. Empty-key tombstones and zero-length values remain semantic entries (Len>0) and rotate. An inconsistent nonzero byte contribution rotates. A retained sibling skips Freeze, byte subtraction, arena draining, queue/retirement, new-table allocation and root promotion; its live pointer/range/arena remain intact. All shard locks, including retained siblings, stay held through the existing final publication; no writer can slip into a sibling after its emptiness check and before the cut is published.

The original queue IDs/shard/lane/ranges/WAL/value-log paths, capacity/hints, flush notifications, adaptive observations, pressure thresholds and byte accounting remain unchanged for replaced tables. Generic checkpoint/capacity/WAL rotations retain original replace-all behavior. The preexisting WAL-rotating implementation is untouched; no second selective loop is introduced. Snapshot accounting (`snapshot.go:278–288`) increments the actual replacement count, with original rotation/enqueued-record/byte counters and original success/error behavior.

Frozen isolation is anchored in `root_domain.go:241–273`: snapshot, system and iterator roots explicitly clear mutable pointers. Live point roots still use retained mutables. Snapshot Get/Has/GetManyView and iterator fallback consume frozen/published roots and backend snapshots, not view.mutables. Nonempty old tables are still sealed/promoted and pinned. Older views never classify a retained active empty sibling as retired; release/recycle/owner Close remain through existing code. No Manager pins, content sync, root/fence coverage or durability/ACK contract is removed.

Errors still return through the original caller NotifyError/iterator error path. Required replacements retain original partial-error order; there is no new rollback or recovery. All originally acquired locks remain covered by the existing deferred reverse unlock on return/panic. No cancellation API or new panic swallowing is introduced. Simultaneous snapshots serialize their cuts through db.mu; live writers retain shard-lock admission.

## Test-first and validation

The unchanged HEAD baseline fails the new snapshot/forward/reverse identity assertions: it replaces all seven empty siblings of the sole populated shard. Sparse accounting fails 4 replacements versus 1. All raw failures are retained. A first compile attempt used the wrong missing-key constant and is also retained; it was corrected to the existing tree.ErrKeyNotFound contract.

Meaningful new tests cover later writes into every retained sibling excluded from old Get/Has/GetManyView/prefix/forward/reverse/exact-range results; live and a newer snapshot include them. The old table stores a verified persistent ValuePtr. Held snapshots/iterators and views survive writes and Checkpoint/flush, including old pointer values and overwrite visibility. Separate tests cover zero-length inline values, existing-backend tombstones and an empty-key tombstone, all-empty acquisition, generic and WAL replace-all, real adaptive HashSorted-to-AppendOnly transition, byte-warmup fallback, inconsistent-byte fallback, truthful counters, concurrent writer/snapshot cuts, older-view release and owner Close with a held snapshot.

Affected ownership normal/race results and exact commands are in raw receipts and source bindings. The earlier full affected regex runs both passed. Final tests added direct generic-wrapper/prefix/Close coverage. A final normal run initially panicked only because the new Close test invoked Close and its shared test cleanup invoked Close again; its fixture was corrected to close once. The next build hit Data-volume exhaustion, retained as an environment failure. Root authorized a fresh task-owned FlashDrive GOTMPDIR/GOCACHE for final validation; no existing directories were deleted and no checks/gates were waived. Final outcomes are recorded below when complete.

The focused regex retains snapshot acquisition/error/debug/fast-path, ordinary/snapshot iterator lifetime/Close, root group/domain/published paths, RCU queue/view retirement, adaptive decisions, GetManyView and arena-view lease tests. It excludes the previously diagnosed direct sync.Pool-budget fixture, rather than concealing its old failures; exact old failure receipts remain bound from the retired packet.

## Immutable generic benchmark and observed opportunity

Six real caching cases: dirty shards1/4/16 of16, variable generic keys1/64 per dirty shard, copied values forced into persistent vlog, Set+AcquireSnapshot+Has+Close timed, Checkpoint outside timing/MemStats to keep queue work bounded. Three samples of30 iterations each; same toolchain/env/options/input and benchmark/fixture bodies before/after. `before-benchmark-test-source.go` reconstructs and exactly matches the actual before-run test-source SHA; immutable helper/fixture/benchmark bodies match final source. Later edits only extend nonbenchmark tests. Whole-process background activity may overlap, and this is local opportunity evidence rather than native service qualification.

| Dirty shards / keys each | Median B/op before → after | Median allocations/op before → after | Median time change |
| --- | --- | --- | --- |
| 1 / 1 | 1,882,944 → 194,196 | 216 → 49 | −36.93% |
| 1 / 64 | 1,884,144 → 195,323 | 216 → 49 | −47.49% |
| 4 / 1 | 2,095,074 → 744,149 | 243 → 110 | −53.20% |
| 4 / 64 | 2,100,094 → 749,046 | 248 → 114 | −21.86% |
| 16 / 1 | 2,944,488 → 2,944,694 | 348 → 349 | −16.13% |
| 16 / 64 | 2,963,256 → 2,963,763 | 362 → 364 | +0.87% |

All raw samples, including slower samples and slight all-dirty allocation/timing increases, are retained in benchmark-comparison.json. No material timing blocker is established in this bounded sample; no statistical/native performance acceptance is claimed. The workload's actual fraction of truly empty siblings is UNKNOWN until root census, and all-dirty cuts offer no constructor reduction.

The source bound is E avoided table constructions and freezes per eligible cut, for E truly empty siblings. At the existing 64KiB iterator hint, each avoided entry reservation is 1024×56=57,344B on this64-bit target, plus the original map/finalization backing; E=15 avoids860,160B of entry arrays alone. This does not change populated growth/reservation or configured limits.

Retaining a table can retain larger initial/reset backing longer. At the existing8MiB HashSorted prealloc maximum, an empty table can retain131,072×56=7,340,032B of entry backing versus57,344B for a64KiB successor; fifteen such tables could retain 109,240,320B (104.18MiB) more entry backing alone, plus maps, until they are populated and eventually rotated or closed. This is a source-derived upper comparison, not measured RSS. The benchmark uses the existing small hint for its fixture and cannot adjudicate net residency in the real service workload. No new trimming cap/pool or capacity policy is added to hide this caveat.

No external docs/format/API change is needed for this internal allocation lifetime candidate; relevant isolation comments are updated. Root owns any integration docs/CI discovery refresh. Source handback includes exact diff, base/current Git/SHA custody, commands, failures, benchmark samples and created local Go scratch roots. Original gates stay intact.
