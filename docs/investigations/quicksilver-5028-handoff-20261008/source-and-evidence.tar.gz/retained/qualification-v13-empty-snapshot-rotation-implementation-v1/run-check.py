import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
out=Path(__file__).resolve().parent
repo=Path('/private/tmp/gomap-qs-5015')
label=sys.argv[1];args=sys.argv[2:]
env=os.environ.copy();explicit={'GOWORK':'off','GOTOOLCHAIN':'local','GOROOT':'/Users/michaelseiler/.gvm/gos/go1.26.0','GOMAXPROCS':'4','GOTMPDIR':'/Volumes/FlashDrive/gomap-5015-empty-rotation-local-go-j4l9blji/tmp'};env.update(explicit)
cmd=[explicit['GOROOT']+'/bin/go']+args
sources={}
for s in ['TreeDB/caching/db.go','TreeDB/caching/snapshot.go','TreeDB/caching/snapshot_empty_rotation_test.go','TreeDB/internal/memtable/hash_sorted.go']:
 b=(repo/s).read_bytes();sources[s]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
t=time.time();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(cmd,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for suffix,data in [('.stdout.txt',r.stdout),('.stderr.txt',r.stderr)]:
 with (out/(label+suffix)).open('xb') as f:f.write(data)
receipt={'command':cmd,'cwd':str(repo),'environment':explicit,'started_utc':start,'elapsed_seconds':time.time()-t,'exit_code':r.returncode,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_bindings':sources,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
with (out/(label+'.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'label':label,'exit_code':r.returncode,'elapsed_seconds':receipt['elapsed_seconds'],'stdout_tail':r.stdout.decode(errors='replace')[-2500:],'stderr_tail':r.stderr.decode(errors='replace')[-1500:]}))
