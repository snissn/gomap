# Empty-rotation R native adapter source review

Disposition: **NO REMAINING SOURCE BLOCKER FOUND in the repaired adapter and final request**. This is source-only build-preparation review, not runtime approval, product acceptance, collection authority, performance qualification, or merge authorization. Those flags remain false.

## Exact input and copy contract

Final request SHA256 f2cec7fd1b643283a15561cdb52d8aae64c15bfa8e3a52f6830d0f5c89bb85cc selects R head4b2ac03223517e0c5a393f2dd645177d07437b4a / tree6bc106d9a9e5e1f3d1ae42fc4daf830af229d430. Every one of the 9,941 manifest blob/mode entries independently matches git ls-tree of that exact head; no symlinks occur in this manifest. The three caching source blobs hash to the previously reviewed b9eb... / 1d0... / 686b... bytes, so the source review remains applicable after commit. The old/new manifests differ only in those three caching files, scripts/mvcc_raw_path_gate.sh, and the CI discovery hash.

The full shipping archive lives on Flash, avoiding another Data copy. Its independently computed length/SHA match the final request and retained local archive receipt: 158,692,577 bytes / 51f7ea71abf4fabb9576f645bbcec4ba290feac5ccfb67e66f3fd2470cfdd225. The receipt records git_rc=0, gzip_rc=0, and genuine_children_joined; this is retained record readback, not a new process inspection or rerun. Pending pre-archive request was reviewed only as provisional; final request uses the fresh control archive.

build-empty-rotation-R.py:44-60 binds frozen environment/tool/native scope, new manifest head/tree and archive hash before requiring absent source/build/binary outputs and extracting into an isolated new source directory. Retained extract_archive checks member path/type/set, creates ordinary copies rather than source aliases, verifies all Git blobs and executable modes, and rejects extra/missing leaves. Actual remote absence, canonical paths, tool/library bytes and full extraction will be enforced at root execution; this review did not visit native paths.

## Retained compiler and affected-test chain

The final request helpers and original_build_context are identical to the retained freelist request. Both helper source hashes and root_native_io hash match their declared values. The new adapter preserves go1.26.3, full-archive verification, lmdb/rocksdb tags, go-list closure, build -p1/-buildvcs=false/-work/-x, export archives, module/test classifications, generated work/import archives, native-input verification and final source-leaf checks. It replaces the six prior freelist/zipper/db native checks with the exact existing affected caching normal/race regex and timeout. Prior unchanged coverage is explicitly separate; equality of the old/new embedded receipt is checked against the retained root acceptance. It is not claimed as fresh coverage of caching behavior.

pipeline_common.py's run waits for each child, then performs owned PGID cleanup and direct-child join, proves quiescence before final raw hashes, and propagates failure. Builder successful rejects command failure or controller timeout. No test success or compiler closure is claimed before actual receipts are produced and reviewed by root.

## Resolved cancellation finding

Initial adapter source omitted SIGTERM handling. Importing build-native-v12.py does not invoke its main(), so its signal installation was absent; default SIGTERM could bypass pc.run cleanup while children ran in separate sessions. Root repaired this narrowly: signal import at build-empty-rotation-R.py:5 and SIGINT/SIGTERM -> builder.interrupt at 41-42, before the first pc.run. Independently inspected repaired bytes resolve that blocker without changing retained helpers.

## Authority and joins

launch-build.py:23-41 preserves the existing exclusive root/native_active guard and compare-before-replace state update. Transfers use fresh control names, exclusive remote files and length/hash verification. The Flash archive path is supplied directly. Successful native return must match the exact status/head/tree and false qualification/collection flags before setting joined and clearing active (61-68). Exception handling retains the failure and active lease for verification; it does not retry or declare quiescence. An SSH/controller failure still requires root to verify remote owned-process quiescence; local SSH join alone is not proof.

The successful branch ends at build/affected correctness receipts. Neither adapter nor launcher invokes benchmark measurement or authorizes collection. No campaign thresholds, checker, consumer policy, or primary source were changed by this review. The source commit's script addition retains the original MVCC gate verdict/threshold/exit and adds separate post-failure diagnostics; CI metadata changes only its discovery-source hash.

All reviewer commands joined. Root retains runtime/preflight, final raw receipt acceptance, native lease, measurement and integration/merge authority. No native/Go/tests/GitHub/SSH/source/index/state operations were performed. Only this fresh REPORT and bindings packet were written. All numerical/performance/qualification/adoption/merge claims are false.
