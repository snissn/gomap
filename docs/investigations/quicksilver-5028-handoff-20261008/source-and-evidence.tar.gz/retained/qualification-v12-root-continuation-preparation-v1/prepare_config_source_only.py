import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;RP=BASE/'qualification-v12-root-preparation-v1';REMOTE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
adopt=RP/'root-current-exact-stage-source-adoption-v12-v1.json'
assert hashlib.sha256(adopt.read_bytes()).hexdigest()=='a127920b5d57e014c4020e8828e8edc04ece7d2df4192f0d112a04f6381cc300'
a=json.loads(adopt.read_bytes());refs={}
def add(ref):
 p=BASE/Path(ref['path']).relative_to(REMOTE);assert p.is_file() and not p.is_symlink() and p.resolve()==p
 assert hashlib.sha256(p.read_bytes()).hexdigest()==ref['sha256'];refs[ref['path']]=ref
for field in ('selected','source_adoptions','drafts'):
 for ref in a[field].values():add(ref)
def walk(v):
 if isinstance(v,dict):
  if set(v)=={'path','sha256'} and isinstance(v['path'],str) and v['path'].startswith(str(REMOTE)+'/'):add(v)
  else:
   for item in v.values():walk(item)
 elif isinstance(v,list):
  for item in v:walk(item)
for ref in a['drafts'].values():walk(json.loads((BASE/Path(ref['path']).relative_to(REMOTE)).read_bytes()))
final=BASE/'qualification-v12-final-artifact-preparation-v1'
for name in ['root-final-raw-closure-v12-v1.py','root-final-metadata-io-v12-v1.py','root-final-content-acceptance-v12-v1.py','root-run-final-evaluation-v12-v1.py','raw-request.draft.json','metadata-request.draft.json','original-evaluation-request.draft.json','strict-evaluation-request.draft.json']:
 p=final/name;add(dict(path=str(REMOTE/p.relative_to(BASE)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
walk(json.loads((final/'raw-request.draft.json').read_bytes())['strict_context'])
for name in ['root-full-R-canonical-B-closure-v12-v1.py','root-full-R-closure-source-acceptance-v12-v1.json','root-global-calibration-transition-v12-v1.py','root-accept-physical34-v12-v1.py','pair-launch-prerequisite-readback-v12-v1.py']:
 p=BASE/'qualification-v12-later-execution-preparation-v3'/name
 if not p.exists():raise FileNotFoundError('explicit dependency missing: '+str(p))
 add(dict(path=str(REMOTE/p.relative_to(BASE)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
config=dict(source_only=True,accepted=False,adoption=dict(path=str(REMOTE/adopt.relative_to(BASE)),sha256=hashlib.sha256(adopt.read_bytes()).hexdigest()),selected=a['selected'],adoptions=a['source_adoptions'],drafts=a['drafts'],staging_sources=sorted(refs.values(),key=lambda r:r['path']),original_helper=dict(path=str(REMOTE/'qualification-v12-later-execution-preparation-v3/root-run-original-global-analyses-v12-v1.py'),sha256='bf391958e4d1f08f16f5b0f3e784eb635cec839208198fdf61f042efdd5b84e0'),io=dict(path=str(REMOTE/'qualification-v9-selected-source-preparation-v1/root_native_io.py'),sha256='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'))
with (HERE/'finite-config.json').open('x') as out:json.dump(config,out,indent=2);out.write('\n')
print(len(refs))
