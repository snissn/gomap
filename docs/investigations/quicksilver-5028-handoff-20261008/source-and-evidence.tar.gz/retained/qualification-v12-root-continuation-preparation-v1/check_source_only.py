"""Finite AST and receipt checks; no launcher main/import or native execution."""
import ast,hashlib,json,tempfile,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
source=BASE/'qualification-v12-root-preparation-v1/continue-reviewed-v12-qualification-v1.py'
tree=ast.parse(source.read_bytes());compile(source.read_bytes(),str(source),'exec')
config=json.loads((HERE/'finite-config.json').read_bytes())
assert len(config['staging_sources'])==58
for start in range(0,58,32):
 batch=config['staging_sources'][start:start+32];assert len(batch)<=32
 expected={str(Path(x['path']).relative_to('/home/mikers/quicksilver-maintenance-5028-20261006')):dict(bytes=(BASE/Path(x['path']).relative_to('/home/mikers/quicksilver-maintenance-5028-20261006')).stat().st_size,sha256=x['sha256']) for x in batch}
 assert len(json.dumps(dict(root='/home/mikers/quicksilver-maintenance-5028-20261006',expected=expected,overwrite_allowed=False,created_ns=1),indent=2).encode())+1<=16384
for ref in config['staging_sources']+[config['adoption'],config['io'],config['original_helper']]:
 p=BASE/Path(ref['path']).relative_to('/home/mikers/quicksilver-maintenance-5028-20261006');assert hashlib.sha256(p.read_bytes()).hexdigest()==ref['sha256']
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
invokes=sorted([n for n in ast.walk(main) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='invoke'],key=lambda n:n.lineno)
assert [n.args[1].value for n in invokes]==['full-R-global54','physical34','original-pairs','raw-metadata','content-evaluations']
waits=sorted([n for n in ast.walk(main) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='wait_file'],key=lambda n:n.lineno)
assert waits[0].lineno<invokes[0].lineno and invokes[1].lineno<waits[1].lineno<invokes[2].lineno
assert 'root-prepair-current-transport-checkpoint-accepted-v12-v1.json' in source.read_text()
# Execute only canonical/sha/read/receipt definitions against isolated synthetic receipt files.
names={'canonical','sha','read','receipt'}
defs=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[])
env=dict(Path=Path,hashlib=hashlib,json=json,time=time);exec(compile(defs,'isolated_receipt_definitions','exec'),env)
passed=[]
with tempfile.TemporaryDirectory(prefix='source_only_continuation_') as raw:
 p=Path(raw).resolve();out=p/'synthetic-stdout';err=p/'synthetic-stderr';run=p/'synthetic-receipt'
 out.write_bytes(b'{"source_only":true}\n');err.write_bytes(b'')
 def row():
  return dict(owner='/root',argv=['synthetic-only'],rc=0,local_pid=123,started_ns=1,finished_ns=2,stdout=dict(path=str(out),bytes=out.stat().st_size,sha256=env['sha'](out)),stderr=dict(path=str(err),bytes=0,sha256=env['sha'](err)))
 good=row();run.write_text(json.dumps(good));assert env['receipt'](run,['synthetic-only'])==good;passed.append('valid-bound-dict-streams')
 for name,mutate in [('rc-failure',lambda r:r.update(rc=1)),('argv-drift',lambda r:r.update(argv=['different'])),('owner-drift',lambda r:r.update(owner='other')),('missing-pid',lambda r:r.update(local_pid=0)),('timestamp-order',lambda r:r.update(started_ns=3)),('hash-drift',lambda r:r['stdout'].update(sha256='0'*64)),('byte-drift',lambda r:r['stdout'].update(bytes=0)),('malformed-stream',lambda r:r.update(stdout=str(out)))]:
  bad=row();mutate(bad);run.write_text(json.dumps(bad))
  try:env['receipt'](run,['synthetic-only'])
  except (AssertionError,TypeError):passed.append(name)
  else:raise AssertionError(name)
 err.write_bytes(b'failure');bad=row();bad['stderr']['bytes']=err.stat().st_size;run.write_text(json.dumps(bad))
 try:env['receipt'](run,['synthetic-only'])
 except AssertionError:passed.append('nonempty-stderr')
 else:raise AssertionError('nonempty-stderr')
result=dict(source_only=True,accepted=False,runtime_authority=False,qualification_acceptance=False,merge_authority=False,status='FINITE_SOURCE_ONLY_CHECKS_PASS',receipt_checks=passed,exact58_dependency_hashes_verified=True,two_bounded_staging_batches=True,source_compiles=True,sequential_order_and_prepaired_wait_verified=True,no_launcher_module_or_main_executed=True,no_native_or_network=True)
with (HERE/'static-check-results.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
