"""Finite JSON template adaptation only; no campaign imports, native calls or authority."""
from pathlib import Path
import json,hashlib,difflib
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;NROOT=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
Q12=NROOT/'qualification-v12-refresh/qualification-v10'
inputs={};checks=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def input(name,expected=None):
 p=BASE/name;d=sha(p)
 if expected:assert d==expected,(name,d,expected)
 inputs[name]=dict(path=str(p),sha256=d,bytes=p.stat().st_size);return p

def load(name,expected=None):return json.loads(input(name,expected).read_bytes())
def ref(p):return dict(path=str(NROOT/p.relative_to(BASE)),sha256=sha(p))
def save(name,value):
 with (HERE/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
P='qualification-v12-refresh/qualification-v10-prospective-root-v1/'
calp=input(P+'calibration-rest-activation.accepted-v1.json','07e61cd3acc351f4cefe355817a70b54c8a73377584c9345c837a7f73517a1d6');cal=json.loads(calp.read_bytes())
rulep=input(P+'prospective-rule-freeze.accepted-v1.json','9786f95c9b82385e0b950af22f4b92b5c7b079b4012ed809a0db458380be65d4');rule=json.loads(rulep.read_bytes())
depp=input(P+'deployment.accepted.json','3f256e6a7313ebadde42f36a5edf1ba94832fc629b25d3d493381818153797d3');dep=json.loads(depp.read_bytes())
bindp=input('qualification-v12-refresh/qualification-v10/prospective-v10-root-v1/pre-c1-binding.json','7b25e5278bc9ca6d7e27075ef2e036470593846d22214315ed89b7171ec703c8')
lock=load('qualification-v12-root-preparation-v1/actual-fresh-source-lock-v12.json','bda4d2486d2e66ee33533d601d216092ce1cd8f5211cfb02aac0d9d2bf823c75')
manifestp=input('qualification-v12-refresh/qualification-v10/manifest.json','fe243316b55e429a276a8a060607c8920973275c3e089125dbf66f13370a5092')
compositionp=input('qualification-v12-root-preparation-v1/actual-root-approved-source-inputs-v1/source-composition-v12.json','b9342c5a67c83d26046eaede93c223dd91e1427af51a3e4ba4c8e98cada2bfc9')
assert lock['manifest_sha256']==sha(manifestp) and lock['composition']['sha256']==sha(compositionp)
NC='qualification-v12-fresh-controls-v1/'
driverp=input(NC+'collection-native-driver-v12-v2.py','aa98083ab9ab2b19cb1bc90ecd562ec2c9e49314fafb28f2f3d8035bbb06bbe8')
selectorp=input(NC+'deployment-helpers-selection.json','eaf90e128e43bbfee259f65a5e8866028899abb25e28877bd42c52afa6e8b7fd')
guardp=input(NC+'global54-artifact-guard-v12-operational-v1.py','3afb3b02c11d7138cc9846489d34b39aa346333a8660dfb0f5e2ddf5daa359b6')
verifierp=input(NC+'verify-qualification-v10-deployment-v2.py','11246d9d5f2e50711ae178b3b2acb2938f7400060e7f77efc1ff9293c76d52fc')
context=load('qualification-v12-root-preparation-v1/actual-source-context-and-binding-readback-v12-v1.json')
adoption=load('qualification-v12-root-preparation-v1/root-orchestration-v12-source-acceptance-v3.json')
load('qualification-v12-root-preparation-v1/root-controls-v12-source-acceptance-v1.json','f41a2c593f775ab844f40bb753a3941989b1049b56fc92e2bfa658c402cccd5b')
anchor=load(P+'pre-c1-anchor.accepted-v2.json','888b36ee11f99c77af68341651cef36e1fe4cb817652091e17edb90eec8497b4')
for p in (driverp,selectorp,guardp,verifierp):assert anchor['files'][ref(p)['path']]==sha(p)
assert dep['campaign_root']==rule['campaign_root']==cal['campaign_root']==str(Q12)
assert cal['deployment_binding']==ref(depp) and cal['prospective_binding']==ref(bindp) and cal['prospective_rule_freeze']==ref(rulep)
assert cal['deployment_verifier']==ref(verifierp)
for p in (depp,bindp):assert context['actual_files'][ref(p)['path']]['sha256']==sha(p)
assert adoption['accepted_by_root'] is adoption['source_only'] is True and adoption['campaign_root']==str(Q12)
checks.append('actual-current-source-lock-context-calibration-rule-driver-selector-guard-bindings')
sub=[('qualification-v11-refresh/qualification-v10','qualification-v12-refresh/qualification-v10'),('qualification-v11-fresh-controls-v1','qualification-v12-fresh-controls-v1'),('collection-native-driver-v11-v1.py','collection-native-driver-v12-v2.py'),('global54-artifact-guard-v11-operational-v1.py','global54-artifact-guard-v12-operational-v1.py'),('62fc3e0348d3022765a3fa7c026f4c957bf128a83720775685553e9104b61748',sha(manifestp)),('9a58d370032bda9765926ff3df5a68d7836f95f7ed0aa8a8a0710c9b2e59ccf3',sha(compositionp)),('2df6cc8824df6edbace58939f9f99144e92585390ac540f15a4b15176c18013a',sha(guardp)),('c257cf40511062d3a5882861a3bb79142f5d85d7d42af34eda26c20353d78ab0',sha(calp)),('ab32d6b6531f818b59dba398f91959eed89361f4d72d84986b30e6ee54523131',sha(bindp)),('35a583de6c91c5bb7f00a8df2b82e9a8b43f0da2694c4ee069375ecd6fe4affe',sha(depp)),('fb852636b95f8c4b7484a9d54653195da1be95e18990e03cde3818dc654473cd',sha(driverp)),('f19c9398f75c1c6f988e0ec21056634cf50b2d84e662b9649a13b0f48cf59bb9',sha(selectorp)),('b34dc2398c500b0378bb2f1a157664ff7a2da96ca72098cd86aa16d4f306513d',sha(rulep))]
known={ref(p)['path']:p for p in (calp,rulep,depp,bindp,manifestp,compositionp,driverp,selectorp,guardp,verifierp)}
names=['global54-input.draft.json','R-collection-activation.draft.json','pair-driver-activation.draft.json','preservation-request.draft.json']
deltas=[]
for name in names:
 oldp=input('qualification-v11-pair-prerequisite-preparation-v1/'+name);old=oldp.read_text();new=old;used=[]
 for a,z in sub:
  if a in new:used.append(dict(old=a,new=z,occurrences=new.count(a)));new=new.replace(a,z)
 value=json.loads(new);original=json.loads(old)
 assert set(value)==set(original) and value['source_only'] is True and value['accepted_by_root'] is False
 assert value['status']=='SOURCE_ONLY_NOT_EXECUTABLE' and value['campaign_root']==str(Q12) and value['held_excluded']==[5004,5006]
 def walk(v,oldv,path=''):
  assert type(v)==type(oldv)
  if isinstance(v,dict):
   assert set(v)==set(oldv)
   if set(v)=={'path','sha256'} and v['sha256'] is not None:
    p=known.get(v['path'])
    if p is None:p=input(str(Path(v['path']).relative_to(NROOT)),v['sha256']);known[v['path']]=p
    assert sha(p)==v['sha256']
   for k,x in v.items():
    if k=='accepted_by_root' or k in ('qualification','performance_accepted') or k.endswith('_authorized'):assert x is False
    if k.endswith('_ns'):assert x is None
    if oldv[k] is None:assert x is None
    walk(x,oldv[k],path+'/'+k)
  elif isinstance(v,list):
   assert len(v)==len(oldv)
   for x,y in zip(v,oldv):walk(x,y,path)
  elif not isinstance(v,str):assert v==oldv
 walk(value,original)
 (HERE/name).write_text(new)
 (HERE/(name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(oldp),tofile=name)))
 reverse=new
 for x in reversed(used):reverse=reverse.replace(x['new'],x['old'])
 assert reverse==old
 deltas.append(dict(file=name,substitutions=used,exact_byte_reversal=True,JSON_keys_schema_and_nulls_unchanged=True))
 checks.extend([name+': strict JSON shape preserved',name+': known references rehashed',name+': all future nulls and authority false',name+': exact byte reversal'])
# Cross-template equality, source identities and unchanged scopes.
global54=json.loads((HERE/names[0]).read_text());r=json.loads((HERE/names[1]).read_text());pair=json.loads((HERE/names[2]).read_text());physical=json.loads((HERE/names[3]).read_text())
assert pair['driver']==ref(driverp) and pair['global54_guard']==global54['guard']==ref(guardp)
assert pair['helper_selection_sha256']==sha(selectorp)
assert pair['deployment']==global54['deployment']==ref(depp) and pair['calibration_activation']==global54['calibration_activation']==ref(calp)
assert physical['prospective_rule_freeze']==ref(rulep)
assert physical['consumer']['sha256']=='ccc5b23ed271b2bd814fc2678a7e4d99e72f0f381b4a39d37132ae570cdee97d'
assert physical['evaluator']['sha256']=='9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd'
assert pair['root_launch_scope_now']==['R-offline-pairs:all-original-six','B-offline-pairs:all-original-ten','B-online-pairs:all-original-three']
assert r['root_launch_scope_now']==['R-offline-pairs:all-original-six']
checks.append('cross-template-current-bindings-and-exact-original-launch-scopes')
save('declared-adaptation-and-static-checks.json',dict(status='SOURCE_ONLY_STATIC_CHECKS_PASS',accepted_by_root=False,qualification=False,check_count=len(checks),checks=[dict(name=x,status='PASS') for x in checks],deltas=deltas,campaign_imports=0,native_commands=0,database_opens=0,authority_issued=False))
save('exact-input-output-manifest.json',dict(status='SOURCE_ONLY_UNACCEPTED',accepted_by_root=False,qualification=False,inputs=inputs,outputs={p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in HERE.iterdir() if p.is_file()}))
print(json.dumps(dict(status='FOUR_SOURCE_ONLY_TEMPLATES_READY',checks=len(checks),inputs=len(inputs),templates={name:sha(HERE/name) for name in names})))
