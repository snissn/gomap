#!/usr/bin/env python3
"""Fresh v10-shaped four-receipt inventory; actual root content review follows."""
import hashlib
import json
import os
import pathlib
import re
import shutil
import stat
import subprocess
import sys
import time
pc=None

def load_common(request_path, request_sha):
    import types
    p=Path(request_path) if 'Path' in globals() else pathlib.Path(request_path)
    raw=p.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=request_sha:raise ValueError('request SHA mismatch')
    request=json.loads(raw);ref=request['dependencies']['pipeline_common']
    selected=(Path(__file__) if 'Path' in globals() else pathlib.Path(__file__)).resolve().parent/'pipeline_common.py'
    if ref['path']!=str(selected) or selected.is_symlink() or hashlib.sha256(selected.read_bytes()).hexdigest()!=ref['sha256']:raise ValueError('exact shared dependency selection drift')
    module=types.ModuleType('qualification_v12_pipeline_common');module.__file__=str(selected)
    exec(compile(selected.read_bytes(),str(selected),'exec'),module.__dict__)
    return module

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def verify_export(source, listing):
    assert source.is_dir() and not source.is_symlink()
    seen = set()
    for parent, directories, files in os.walk(source, followlinks=False):
        for name in list(directories):
            path = pathlib.Path(parent) / name
            assert name != '.git'
            if path.is_symlink():
                seen.add(path.relative_to(source).as_posix()); directories.remove(name)
        for name in files:
            assert name != '.git'
            seen.add((pathlib.Path(parent) / name).relative_to(source).as_posix())
    assert seen == set(listing['files']), 'full source export includes exactly all tracked leaves'
    for name, item in listing['files'].items():
        relative = pathlib.PurePosixPath(name)
        assert not relative.is_absolute() and name == relative.as_posix()
        assert all(p not in ('', '.', '..', '.git') for p in relative.parts)
        path = source / name
        parent = path.parent
        while parent != source:
            assert parent.is_dir() and not parent.is_symlink()
            parent = parent.parent
        mode = path.lstat().st_mode
        if item['mode'] == '120000':
            assert stat.S_ISLNK(mode); data = os.fsencode(os.readlink(path))
        else:
            assert item['mode'] in ('100644','100755') and stat.S_ISREG(mode)
            assert bool(mode & 0o111) == (item['mode']=='100755')
            data = path.read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == item['blob']
PROBE=None
PROBE_COUNT=0

def command(argv,env,cwd=None):
    global PROBE_COUNT
    PROBE_COUNT+=1
    rec,error=pc.run(argv,cwd or ROOT,env,PROBE,'probe-'+str(PROBE_COUNT),45)
    save(PROBE/('probe-'+str(PROBE_COUNT)+'.json'),rec)
    if error is not None:raise error
    assert not rec.get('controller_timeout') and rec['raw_hashes_final']
    return dict(argv=argv,rc=rec['rc'],stdout=pathlib.Path(rec['stdout_path']).read_text(),stderr=pathlib.Path(rec['stderr_path']).read_text(),raw_receipt=str(PROBE/('probe-'+str(PROBE_COUNT)+'.json')),raw_receipt_sha256=sha(PROBE/('probe-'+str(PROBE_COUNT)+'.json')))


def main():
    global pc
    if len(sys.argv)!=3:raise ValueError('REQUEST SHA256 required')
    pc=load_common(sys.argv[1],sys.argv[2])
    global ROOT,CAMPAIGN,PROBE
    assert __debug__ and len(sys.argv)==3
    r,ref=pc.request(sys.argv[1],sys.argv[2],'inventory');meta,frozen,pins=pc.basis(r)
    assert r['controller_path']==str(pathlib.Path(__file__).resolve())
    meta_path=pathlib.Path(r['composition']['path'])
    ROOT=pc.canonical(r['native_root']);CAMPAIGN=pc.canonical(r['foundation']);env,go=pc.environment(r,frozen)
    assert not (CAMPAIGN/'manifest.json').exists() and not (CAMPAIGN/'inventory-prepared.json').exists()
    for name in ('bin','receipts','plans','fixture-receipts'):
        (CAMPAIGN/name).mkdir(exist_ok=True)
    PROBE=CAMPAIGN/'receipts'/'inventory-probes';PROBE.mkdir()
    stop=pc.bound(r['build_complete']);build_stop=pathlib.Path(r['build_complete']['path'])
    assert stop['status']=='BUILD_COMPLETE_STOP_BEFORE_MEASUREMENT' and stop['accepted_by_root'] is False and stop['qualification'] is False and stop['collection_authorized'] is False and stop['performance_runs']==0
    assert stop['composition_sha256']==r['composition']['sha256'] and stop['source_freeze_sha256']==r['source_freeze']['sha256']
    assert set(stop['source_receipts'])==set(pins) and set(stop['build_receipts'])==set(pc.SLOTS) and set(stop['compiler_input_receipts'])==set(pc.SLOTS)
    for slot,ci_ref in stop['compiler_input_receipts'].items():
        ci=pc.bound(ci_ref);assert ci['slot']==slot and {k:ci[k] for k in ('head','tree')}==pins[pc.SLOTS[slot]]
        pc.bound(ci['go_list_receipt']);pc.bound(ci['build_receipt']);pc.bound(ci['export_listing_receipt']);assert sha(pathlib.Path(ci['export_listing_raw']['path']))==ci['export_listing_raw']['sha256']
        assert sha(pathlib.Path(ci['go_list_raw']['path']))==ci['go_list_raw']['sha256']
        for key in ('selected_files','module_files','uncompiled_repository_test_inputs','native_input_files','generated_and_work_files','actual_import_archives','actual_package_export_archives'):pc.verify_bindings(ci[key])
    pc.native_scope(r,frozen)
    assert r['environment']['sha256'] == frozen['environment_sha256']
    env = pc.bound(r['environment'])
    env = {k: v for k, v in env.items() if not k.startswith('TREEDB_')}
    env.update(GOMEMLIMIT='off', GOGC='100', GOMAXPROCS='12', GODEBUG='')
    keep_env = {'GOROOT', 'GOWORK', 'GOFLAGS', 'GOENV', 'GOTOOLCHAIN',
                'GOCACHE', 'GOMODCACHE', 'CGO_ENABLED', 'CGO_CFLAGS',
                'CGO_CPPFLAGS', 'CGO_CXXFLAGS', 'CGO_LDFLAGS', 'PATH', 'LD_LIBRARY_PATH', 'GOMEMLIMIT',
                'GOGC', 'GOMAXPROCS', 'GODEBUG'}
    build_env = {k: env[k] for k in keep_env if k in env}
    assert build_env['GOWORK'] == 'off' and build_env['CGO_ENABLED'] == '1'
    source_receipt = dict(schema=1, accepted_by_root=False,
                          baseline_product=meta['baseline_product'],
                          landed_harness_head=pins['A']['head'],
                          harness_tree=pins['A']['tree'], variants={},
                          received_composition=meta,
                          composition_sha256=sha(meta_path))
    for role, variant in meta['variants'].items():
        source = pathlib.Path(variant['source'])
        listing = pc.bound(variant['tracked_manifest'])
        assert listing['tree'] == variant['tree'] and listing['head'] == variant['accepted_head']
        assert variant['source'] == frozen['source_paths'][role]
        verify_export(source, listing)
        source_record = stop['source_receipts'][role]
        sr=pc.bound(source_record)
        assert sr['rc']==0 and sr['source']==str(source) and {k:sr[k] for k in ('head','tree')}==pins[role] and sr['verified_all_tracked_blobs_and_modes'] is True
        for name, expected in listing['files'].items():
            path = source / name
            mode = path.lstat().st_mode
            if expected['mode'] == '120000':
                assert stat.S_ISLNK(mode), (role, name, 'symlink')
                data = os.readlink(path).encode()
            else:
                assert stat.S_ISREG(mode), (role, name, 'regular file')
                assert bool(mode & 0o111) == (expected['mode'] == '100755'), (role, name, 'executable bit')
                data = path.read_bytes()
            assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == expected['blob'], (role, name, 'blob')
        source_receipt['variants'][role] = dict(variant, tracked_files=len(listing['files']),
                            verified_git_blobs_and_modes=True, verified_ns=time.time_ns())
    # Actual fresh receipt content and compiler inputs need separate root review.
    sources = {}
    build_receipt = dict(schema=1, env=build_env, source_binding='complete actual fresh tracked Git blobs and modes', compiler_input_receipts=stop['compiler_input_receipts'], source_basis=r['source_basis'], binaries={})
    libraries = {}
    native_receipt = dict(schema=1, loader_environment={k: v for k, v in env.items() if k.startswith('LD_')}, binaries={})
    for role, slot in meta['binaries'].items():
        origin = pathlib.Path(slot['origin'])
        binary = CAMPAIGN / 'bin' / slot['name']
        pc.canonical(str(binary),exists=False);assert origin!=binary and not binary.exists() and slot['name']==pathlib.Path(slot['name']).name
        shutil.copy2(origin, binary)
        assert sha(origin) == sha(binary)
        with binary.open('rb') as stream:
            assert stream.read(4) == b'\x7fELF'
        run_path = pathlib.Path(slot['build_receipt'])
        build = json.loads(run_path.read_bytes())
        assert build['rc'] == 0 and not build.get('controller_timeout')
        assert build['source'] == meta['variants'][slot['variant']]['source']
        assert sha(run_path) == stop['build_receipts'][role]['sha256']
        assert sha(binary) == build['binary_sha256'] == stop['build_receipts'][role]['binary_sha256']
        assert build['head'] == meta['variants'][slot['variant']]['accepted_head']
        assert build['tree'] == meta['variants'][slot['variant']]['tree']
        assert build['accepted_input']['build_env'] == build_env
        assert build['command'][1:7] == ['build', '-p', '1', '-buildvcs=false', '-work', '-x']
        ldd = command(['/usr/bin/ldd', str(binary)], env)
        output, errors = ldd['stdout'].strip(), ldd['stderr'].strip()
        if ldd['rc'] in (0, 1) and (output, errors) in (
                ('statically linked', ''), ('', 'statically linked'),
                ('not a dynamic executable', ''), ('', 'not a dynamic executable')):
            linkage = 'static'
        else:
            assert ldd['rc'] == 0 and not errors, ldd
            linkage = 'dynamic'
            for line in output.splitlines():
                fields = line.split()
                if fields[0] in ('linux-vdso.so.1', 'linux-gate.so.1'):
                    continue
                dep = fields[2] if '=>' in fields else fields[0]
                assert pathlib.Path(dep).is_absolute() and pathlib.Path(dep).is_file(), dep
                libraries[dep] = dict(sha256=sha(pathlib.Path(dep)), resolved=str(pathlib.Path(dep).resolve()), bytes=pathlib.Path(dep).stat().st_size)
        variant = meta['variants'][slot['variant']]
        sources[role] = dict(head=variant['accepted_head'], tree=variant['tree'],
                             built_against_head=variant['accepted_head'],
                             binary=slot['name'], binary_sha256=sha(binary), linkage=linkage)
        build_receipt['binaries'][role] = dict(origin=str(origin), binary=str(binary),
                            source=sources[role], original_build=build,
                            original_build_path=str(run_path), original_build_sha256=sha(run_path),
                            go_version=command([go, 'version', '-m', str(binary)], env))
        native_receipt['binaries'][role] = ldd
    build_receipt['toolchain'] = dict(version=command([go, 'version'], env),
                        env=command([go, 'env', 'GOROOT', 'GOOS', 'GOARCH', 'CGO_ENABLED', 'GOVERSION', 'GOCACHE', 'GOMODCACHE'], env))
    assert 'go1.26.3' in build_receipt['toolchain']['version']['stdout']
    assert len(libraries) == 16, 'expected actual sixteen-library quiet-host resolution'
    assert libraries == frozen['expected_native_libraries'], 'actual native library identities must match frozen inputs'
    native_receipt['libraries'] = libraries
    runner_receipt = dict(schema=1, recorded_ns=time.time_ns(),
                         owner='/root', serial_collection=True,
                         infrastructure_exception=meta['infrastructure_exception'],
                         host=command(['hostname'], env), uname=command(['uname', '-a'], env),
                         cpu=command(['lscpu'], env), storage=command(['df', '-B1', str(CAMPAIGN)], env),
                         mount=command(['findmnt', '-T', str(CAMPAIGN), '-o', 'TARGET,SOURCE,FSTYPE,OPTIONS'], env),
                         processes=command(['ps', '-eo', 'pid,ppid,etimes,pcpu,pmem,comm,args'], env),
                         ntp=command(['timedatectl', 'show', '-p', 'NTPSynchronized', '-p', 'NTP', '-p', 'Timezone'], env),
                         load=os.getloadavg(), meminfo=pathlib.Path('/proc/meminfo').read_text(),
                         clock_resolution={k: time.get_clock_info(k).__dict__ for k in ('time', 'monotonic', 'perf_counter')},
                         clock_contract=dict(pause_wall_monotonic_tolerance_ns=1000000,
                             actual_per_pause_bounds_checked=True,
                             sustained_window_seconds=10, trim_boundary_ns=200000000,
                             minimum_complete_samples=40, maximum_gap_ns=400000000),
                         cache_state='fresh processes; physical fixture fingerprint/copy/rebind verification warms file cache identically before compact; no cache drop',
                         external_tools={name: dict(path=str(pathlib.Path(name).resolve()), sha256=sha(pathlib.Path(name)))
                             for name in ('/usr/bin/time', '/usr/bin/python3', '/usr/bin/ldd')})
    assert 'NTPSynchronized=yes' in runner_receipt['ntp']['stdout']
    receipts = {}
    for role, value in [('source', source_receipt), ('build', build_receipt),
                        ('native', native_receipt), ('runner', runner_receipt)]:
        path = CAMPAIGN / 'receipts' / (role + '-inventory.json')
        save(path, value)
        receipts[role] = dict(path=str(path.relative_to(CAMPAIGN)), sha256=sha(path))
    pc.request(sys.argv[1],sys.argv[2],'inventory');pc.basis(r);pc.environment(r,frozen);pc.native_scope(r,frozen);assert sha(pathlib.Path(__file__))==r['controller_sha256']
    manifest = dict(build_env=build_env, sources=sources, snapshot_restore='restore',
                    libraries=libraries, receipts=receipts)
    save(CAMPAIGN / 'manifest.json', manifest)
    save(CAMPAIGN / 'inventory-prepared.json', dict(schema=1, created_ns=time.time_ns(),
                manifest_sha256=sha(CAMPAIGN / 'manifest.json'), receipts=receipts, sources=sources, libraries=libraries, source_basis=r['source_basis'],
                landing=pins['A']['head'], accepted_by_root=False,
                status='INVENTORY_COMPLETE_STOP_ROOT_ACTUAL_CONTENT_ACCEPTANCE_REQUIRED',
                qualification=False, collection_authorized=False, performance_runs=0, compiler_input_receipts=stop['compiler_input_receipts'], build_complete_sha256=sha(build_stop),
                scope='common source/build/native/runner inventory before any performance characterization',
                collector_source=meta['variants']['A']['source']))
    print(json.dumps(dict(status='INVENTORY_COMPLETE_STOP_ROOT_ACTUAL_CONTENT_ACCEPTANCE_REQUIRED', qualification=False, campaign=str(CAMPAIGN), manifest_sha256=sha(CAMPAIGN / 'manifest.json'),
                         binaries={k: v['binary_sha256'] for k, v in sources.items()},
                         libraries=len(libraries), receipts=receipts)), flush=True)


if __name__=='__main__':main()
