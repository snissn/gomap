"""Hash-bound fresh-source helpers. Importing performs no native action."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import time

SLOTS = {'A':'A','A_unified':'A','R':'R','R_unified':'R','B':'B','B_unified':'B','restore':'A','benchprof':'A'}
BUILD_FIELDS = ('GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SwigFiles','SwigCXXFiles','SysoFiles','EmbedFiles')
ENV_KEYS = {'GOROOT','GOWORK','GOFLAGS','GOENV','GOTOOLCHAIN','GOCACHE','GOMODCACHE','CGO_ENABLED','CGO_CFLAGS','CGO_CPPFLAGS','CGO_CXXFLAGS','CGO_LDFLAGS','PATH','LD_LIBRARY_PATH','GOMEMLIMIT','GOGC','GOMAXPROCS','GODEBUG'}


def require(ok, why):
    if not ok:
        raise ValueError(why)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1<<20), b''):
            h.update(block)
    return h.hexdigest()


def verify_ref(ref):
    require(set(ref)=={'path','sha256'}, 'exact canonical path/SHA reference required')
    p=Path(ref['path'])
    require(p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p, 'canonical bound regular file')
    require(isinstance(ref['sha256'],str) and re.fullmatch('[0-9a-f]{64}',ref['sha256']) and sha(p)==ref['sha256'], 'bound input drift: '+str(p))
    return p


def bound(ref):
    return json.loads(verify_ref(ref).read_bytes())


def save(path,value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def canonical(path, exists=True):
    p=Path(path);require(p.is_absolute() and '..' not in p.parts and not p.is_symlink(), 'absolute nonalias path required')
    require(p.resolve(strict=exists)==p, 'canonical path required')
    return p


def request(path,digest,stage):
    require(__debug__, 'unoptimized Python required')
    ref={'path':str(path),'sha256':digest};r=bound(ref)
    require(r['schema']==1 and r['receipt_kind']=='qualification-v12-'+stage+'-request', 'stage request schema')
    require(r['accepted_by_root'] is True and r[stage+'_execution_authorized'] is True, 'actual root stage authority required')
    require(r['collection_authorized'] is False and r['qualification'] is False and r['held_excluded']==[5004,5006], 'stage grants no measurement authority')
    require(r['controller_sha256']==sha(r['controller_path']), 'controller selection drift')
    require({'pipeline_common','request_schema'}.issubset(r['dependencies']),'exact shared dependencies required')
    require(r['dependencies']['request_schema']['path']==str(Path(__file__).parent/'request.schema.json'),'exact request schema selection')
    for dependency in r['dependencies'].values():verify_ref(dependency)
    return r,ref


def basis(r):
    proof=bound(r['source_basis']);accept=bound(r['source_basis_acceptance']);meta=bound(r['composition']);frozen=bound(r['source_freeze'])
    require(proof['accepted_by_root'] is False and proof['receipt_kind']=='qualification-v12-observed-source-basis', 'observed fresh basis required')
    require(accept['accepted_by_root'] is True and accept['receipt_kind']=='qualification-v12-root-source-basis-acceptance', 'separate actual root acceptance required')
    require(accept['source_basis']==r['source_basis'] and accept['variants']==proof['exact_variants'] and accept['reviewed_bindings']==proof['review_bindings'], 'complete basis review identity drift')
    require(accept['source_export_authorized'] is True and accept['build_authorized'] is True and accept['collection_authorized'] is False and accept['qualification'] is False and accept['held_excluded']==[5004,5006], 'source/build-only basis authority')
    require(meta['accepted_by_root'] is True and meta['landed_harness_attested'] is True and meta['held_excluded']==[5004,5006], 'fresh composition authority')
    pins={role:{'head':v['accepted_head'],'tree':v['tree']} for role,v in meta['variants'].items()}
    require(set(pins)=={'A','R','B'} and pins==proof['exact_variants'], 'composition source pins differ')
    require(frozen['accepted_by_root'] is True and frozen['collection_authorized'] is False and frozen['qualification'] is False and frozen['held_excluded']==[5004,5006], 'fresh source freeze authority')
    require(frozen['variants']==pins and frozen['source_basis']==r['source_basis'] and frozen['source_basis_acceptance']==r['source_basis_acceptance'], 'freeze identity drift')
    for ref in proof['review_bindings'].values():bound(ref)
    for role,v in meta['variants'].items():
        listing=bound(v['tracked_manifest']);require({k:listing[k] for k in ('head','tree')}==pins[role], 'full tracked source identity')
        require(proof['tracked_manifests'][role]==v['tracked_manifest'], 'basis/composition full export binding')
    require(set(meta['binaries'])==set(SLOTS), 'all eight binary slots required')
    for slot,role in SLOTS.items():require(meta['binaries'][slot]['variant']==role, 'binary source role')
    return meta,frozen,pins


def environment(r,frozen):
    env=bound(r['environment']);require(r['environment']['sha256']==frozen['environment_sha256'], 'frozen environment drift')
    require(all(isinstance(k,str) and isinstance(v,str) for k,v in env.items()), 'environment string map')
    required={'GOWORK':'off','GOTOOLCHAIN':'local','GOMAXPROCS':'12','GOGC':'100','GOMEMLIMIT':'off','CGO_ENABLED':'1','GOENV':'off','GODEBUG':'','GOEXPERIMENT':''}
    require(all(env.get(k)==v for k,v in required.items()), 'original environment gates')
    require(not any(k.startswith('TREEDB_') for k in env) and not env.get('LD_PRELOAD') and not env.get('LD_AUDIT') and not env.get('GOFLAGS'), 'unexpected override')
    go=canonical(r['go_tool']['path']);require(sha(go)==r['go_tool']['sha256'] and shutil.which('go',path=env['PATH'])==str(go), 'bound actual Go executable required')
    return env,str(go)


def file_binding(path):
    p=Path(path);require(p.is_absolute() and p.is_file(), 'selected compiler input missing: '+str(p))
    return {'path':str(p),'resolved':str(p.resolve(strict=True)),'sha256':sha(p),'bytes':p.stat().st_size}


def native_scope(r,frozen):
    """Complete reviewed native/tool/include superset; no Go-list-only claim."""
    scope=bound(r['native_input_scope'])
    require(scope['accepted_by_root'] is True and scope['complete_build_input_scope_reviewed'] is True and scope['qualification'] is False and scope['collection_authorized'] is False, 'independent complete native-input scope review required')
    require(frozen['native_input_scope']==r['native_input_scope'], 'native input scope freeze drift')
    require(set(scope['categories'])=={'toolchain','compiler_linker_tools','native_headers_sysroots','native_libraries'}, 'full native/tool/include categories required')
    files={}
    for category,roots in scope['categories'].items():
        require(roots, 'empty native input category: '+category)
        for root in roots:
            p=canonical(root)
            paths=[p] if p.is_file() else sorted(p.rglob('*'))
            for leaf in paths:
                if leaf.is_file():files[str(leaf)]=dict(file_binding(leaf),category=category)
    require(files and files==scope['expected_files'], 'actual native/tool/include supersets differ reviewed frozen bytes')
    return files


def json_stream(raw):
    decoder=json.JSONDecoder();pos=0;result=[]
    while pos<len(raw):
        while pos<len(raw) and raw[pos].isspace():pos+=1
        if pos==len(raw):break
        value,end=decoder.raw_decode(raw,pos);result.append(value);pos=end
    require(result,'empty package listing');return result


def compiler_inputs(packages,source,listing):
    inputs={};modules={};tests={};uncompiled={};harness={}
    source=Path(source)
    for package in packages:
        require(not package.get('Error') and not package.get('DepsErrors') and not package.get('Incomplete'), 'incomplete compiler closure')
        directory=canonical(package['Dir'])
        for field in BUILD_FIELDS:
            for name in package.get(field,[]):
                p=directory/name;binding=file_binding(p)
                if p.is_relative_to(source):
                    relative=p.relative_to(source).as_posix();item=listing['files'].get(relative)
                    require(item is not None and item['mode'] in ('100644','100755'), 'compiled in-repo input absent from full Git manifest')
                    data=p.read_bytes();oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
                    require(oid==item['blob'],'compiled Git input drift');binding['git']=item
                binding['field']=field;binding['package']=package['ImportPath'];inputs[str(p)]=binding
                if p.is_relative_to(source) and p.relative_to(source).as_posix().startswith(('cmd/unified_bench/','cmd/benchprof/')):harness[p.relative_to(source).as_posix()]=binding
        tests[package['ImportPath']]={'TestGoFiles':package.get('TestGoFiles',[]),'XTestGoFiles':package.get('XTestGoFiles',[]),'IgnoredGoFiles':package.get('IgnoredGoFiles',[])}
        for field in ('TestGoFiles','XTestGoFiles'):
            for name in package.get(field,[]):
                p=directory/name
                if p.is_relative_to(source):uncompiled[str(p)]=dict(file_binding(p),field=field,package=package['ImportPath'],compiled_in_this_non_test_build=False)
        module=package.get('Module')
        while module:
            if module.get('GoMod'):modules[module['GoMod']]=file_binding(module['GoMod'])
            if module.get('Dir'):
                for name in ('go.mod','go.sum'):
                    p=Path(module['Dir'])/name
                    if p.is_file():modules[str(p)]=file_binding(p)
            module=module.get('Replace')
    require(inputs,'no selected compiler inputs');return {'selected_files':inputs,'module_files':modules,'test_classification':tests,'repository_harness_inputs':harness,'uncompiled_repository_test_inputs':uncompiled}


def verify_bindings(bindings):
    for item in bindings.values():require(file_binding(item['path'])=={k:item[k] for k in ('path','resolved','sha256','bytes')}, 'selected input drift')


def live_group_members(pgid):
    """Owned PGID only; non-Linux waits for group disappearance (fail closed)."""
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return False, []
    except PermissionError:
        # Some kernels report EPERM while dead members are being reaped.
        # This is uncertainty, never permission to finalize raw hashes.
        return True, []
    if not Path('/proc').is_dir():
        return True, []
    members=[]
    for entry in Path('/proc').iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            fields=entry.joinpath('stat').read_text().rsplit(')',1)[1].split()
        except (FileNotFoundError, ProcessLookupError):
            continue
        # Permission/parse failures deliberately reject quiescence.
        if int(fields[2])==pgid:
            members.append(dict(pid=int(entry.name),state=fields[0]))
    # A present but unobserved group is an enumeration race, never proof.
    return not members or any(m['state'] not in ('Z','X') for m in members), members

def stop_group(proc):
    """TERM grace10s; unconditional KILL; direct-child join; bounded quiescence."""
    require(proc.pid != os.getpgrp(), 'refuse adapter own process group')
    result=dict(pgid=proc.pid,term_sent=False,kill_sent=False,leader_grace_timeout=False,
        direct_child_joined=False,quiescent=False,dead_members=[],signal_errors=[],detached_descendants_covered=False)
    try:
        os.killpg(proc.pid, signal.SIGTERM);result['term_sent']=True
    except ProcessLookupError:
        pass
    except PermissionError as error:
        result['signal_errors'].append(repr(error))
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        result['leader_grace_timeout']=True
    finally:
        # Leader exit is not group exit. Escalate in both cases.
        try:
            os.killpg(proc.pid, signal.SIGKILL);result['kill_sent']=True
        except ProcessLookupError:
            pass
        except PermissionError as error:
            result['signal_errors'].append(repr(error))
    proc.wait(timeout=10);result['direct_child_joined']=True
    deadline=time.monotonic()+10
    while True:
        live,members=live_group_members(proc.pid)
        if not live:
            result['quiescent']=True;result['dead_members']=members
            return result
        if time.monotonic()>=deadline:
            raise RuntimeError('owned process group still live/unproven after SIGKILL: '+repr(members))
        # Cover members appearing during a /proc enumeration race.
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        except PermissionError as error:
            result['signal_errors'].append(repr(error))
        time.sleep(0.05)


def run(argv,source,env,directory,prefix,timeout):
    directory=Path(directory);stdout_path=directory/(prefix+'-stdout.txt');stderr_path=directory/(prefix+'-stderr.txt')
    record=dict(command=argv,cwd=str(source),source=str(source),started_ns=time.time_ns(),timeout_seconds=timeout,load_before=os.getloadavg(),rc=None)
    proc=None;failure=None;quiescent=False
    try:
        with stdout_path.open('xb') as stdout,stderr_path.open('xb') as stderr:
            proc=subprocess.Popen(argv,cwd=source,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
            record['pid']=proc.pid
            try:record['rc']=proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:record['controller_timeout']=True;record['rc']=124
    except BaseException as error:failure=error;record['error']=repr(error)
    finally:
        handlers={s:signal.signal(s,signal.SIG_IGN) for s in (signal.SIGINT,signal.SIGTERM)}
        try:
            quiescent=proc is None
            if proc is not None:
                try:record['process_group_cleanup']=stop_group(proc);quiescent=True
                except BaseException as error:failure=error;record['cleanup_error']=repr(error)
                if record['rc'] is None:record['rc']=proc.returncode
            record.update(finished_ns=time.time_ns(),load_after=os.getloadavg(),raw_hashes_final=quiescent,stdout_path=str(stdout_path),stderr_path=str(stderr_path),stdout_sha256=sha(stdout_path) if quiescent and stdout_path.exists() else None,stderr_sha256=sha(stderr_path) if quiescent and stderr_path.exists() else None)
        finally:
            for signum,handler in handlers.items():signal.signal(signum,handler)
    return record,failure


def work_inputs(stderr_path):
    raw=Path(stderr_path).read_text();lines=[x[5:] for x in raw.splitlines() if x.startswith('WORK=')]
    require(len(lines)==1, 'exact retained Go build WORK directory required')
    work=canonical(lines[0]);require(work.is_dir(),'retained compiler work directory missing')
    files={};cache={}
    for p in sorted(work.rglob('*')):
        if p.is_file():
            files[str(p)]=file_binding(p)
            if p.name.startswith('importcfg'):
                for line in p.read_text().splitlines():
                    if line.startswith('packagefile ') and '=' in line:
                        target=line.split('=',1)[1]
                        if Path(target).is_absolute():cache[target]=file_binding(target)
    # Retained generated sources, native objects, importcfg, assembly and cache
    # export archives bind actual build work; no claim Go list sees all headers.
    return {'work_directory':str(work),'generated_and_work_files':files,'actual_import_archives':cache}


def package_exports(packages):
    result={}
    for package in packages:
        require(not package.get('Error') and not package.get('DepsErrors') and not package.get('Incomplete'),'incomplete actual package export closure')
        if package['ImportPath']=='unsafe':continue
        require(package.get('Export'),'selected actual package export missing: '+package['ImportPath'])
        p=package['Export'];result[p]=dict(file_binding(p),package=package['ImportPath'])
    require(result,'empty actual package export archive closure');return result
