#!/usr/bin/env python3
"""Import-safe joined-process correctness runner; no measurement/acceptance."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import stat
import subprocess
import sys
import time
pc=None

def load_common(request_path, request_sha):
    import types
    p=Path(request_path) if 'Path' in globals() else pathlib.Path(request_path)
    raw=p.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=request_sha:raise ValueError('request SHA mismatch')
    request=json.loads(raw);ref=request['dependencies']['pipeline_common']
    selected=(Path(__file__) if 'Path' in globals() else pathlib.Path(__file__)).resolve().parent/'pipeline_common.py'
    if ref['path']!=str(selected) or selected.is_symlink() or hashlib.sha256(selected.read_bytes()).hexdigest()!=ref['sha256']:raise ValueError('exact shared dependency selection drift')
    module=types.ModuleType('qualification_v12_pipeline_common');module.__file__=str(selected)
    exec(compile(selected.read_bytes(),str(selected),'exec'),module.__dict__)
    return module

ROOT=CAMPAIGN=OUTPUT=None
HERE=Path(__file__).parent
ENV_SHA=CHECKS_SHA=None
PINS={}
SLOTS={}
ENV_KEYS={'GOFLAGS', 'GOROOT', 'GOENV', 'GOGC', 'CGO_LDFLAGS', 'GOMAXPROCS', 'GOWORK', 'CGO_CXXFLAGS', 'LD_LIBRARY_PATH', 'GOMODCACHE', 'CGO_ENABLED', 'GODEBUG', 'GOCACHE', 'CGO_CFLAGS', 'GOTOOLCHAIN', 'CGO_CPPFLAGS', 'PATH', 'GOMEMLIMIT'}

def require(ok, why):
    if not ok:
        raise ValueError(why)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def bound(ref):
    p = Path(ref['path'])
    require(p.is_absolute() and p.is_file() and not p.is_symlink() and p==p.resolve(), 'absolute canonical regular bound file')
    require(isinstance(ref['sha256'], str) and re.fullmatch('[0-9a-f]{64}', ref['sha256']) and sha(p)==ref['sha256'], 'bound file SHA mismatch: '+str(p))
    return read(p)

def root_ref(name, digest):
    p = Path(name)
    if not p.is_absolute():
        p = ROOT/p
    require(p.is_relative_to(ROOT) and '..' not in p.parts, 'source binding outside native root')
    return bound(dict(path=str(p),sha256=digest))

def checked_source(source, listing):
    # Same symlink-aware full tracked leaf contract as the formal inventory.
    require(source.is_dir() and not source.is_symlink(), 'real exported source directory')
    seen = set()
    for parent, directories, files in os.walk(source, followlinks=False):
        for name in list(directories):
            path = Path(parent)/name
            require(name != '.git', 'Git administration directory')
            if path.is_symlink():
                seen.add(path.relative_to(source).as_posix()); directories.remove(name)
        for name in files:
            require(name != '.git', 'Git administration file')
            seen.add((Path(parent)/name).relative_to(source).as_posix())
    require(seen == set(listing['files']) and seen, 'full source file-set mismatch')
    for name,item in listing['files'].items():
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and name==relative.as_posix() and all(x not in ('','.','..','.git') for x in relative.parts), 'unsafe tracked leaf')
        path=source/name; parent=path.parent
        while parent != source:
            require(parent.is_dir() and not parent.is_symlink(), 'unsafe source parent'); parent=parent.parent
        mode=path.lstat().st_mode
        if item['mode']=='120000':
            require(stat.S_ISLNK(mode), 'source symlink mode'); data=os.fsencode(os.readlink(path))
        else:
            require(item['mode'] in ('100644','100755') and stat.S_ISREG(mode), 'source regular mode')
            require(bool(mode & 0o111)==(item['mode']=='100755'), 'source executable mode'); data=path.read_bytes()
        require(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['blob'], 'source blob drift: '+name)

def idle(root):
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal() or int(path.name)==os.getpid():
            continue
        try:
            argv=path.joinpath('cmdline').read_bytes().split(b'\0')
            state=path.joinpath('stat').read_text().rsplit(')',1)[1].split()[0]
        except OSError:
            continue
        prefix=bytes(str(root),'utf8')
        active=argv and ((argv[0].startswith(prefix) and b'/bin/' in argv[0]) or any(a.startswith(prefix) and a.endswith((b'/quicksilver_maintenance.py',b'/unified_bench_quicksilver_capture.py')) for a in argv))
        require(state=='Z' or not active, 'another runner-owned measurement is active: '+path.name)

def interrupt(signum, frame):
    raise InterruptedError('correctness adapter signal '+str(signum))

def live_group_members(pgid):
    """Owned PGID only; non-Linux waits for group disappearance (fail closed)."""
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return False, []
    except PermissionError:
        # Some kernels report EPERM while dead members are being reaped.
        # This is uncertainty, never permission to finalize raw hashes.
        return True, []
    if not Path('/proc').is_dir():
        return True, []
    members=[]
    for entry in Path('/proc').iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            fields=entry.joinpath('stat').read_text().rsplit(')',1)[1].split()
        except (FileNotFoundError, ProcessLookupError):
            continue
        # Permission/parse failures deliberately reject quiescence.
        if int(fields[2])==pgid:
            members.append(dict(pid=int(entry.name),state=fields[0]))
    # A present but unobserved group is an enumeration race, never proof.
    return not members or any(m['state'] not in ('Z','X') for m in members), members

def stop_group(proc):
    """TERM grace10s; unconditional KILL; direct-child join; bounded quiescence."""
    require(proc.pid != os.getpgrp(), 'refuse adapter own process group')
    result=dict(pgid=proc.pid,term_sent=False,kill_sent=False,leader_grace_timeout=False,
        direct_child_joined=False,quiescent=False,dead_members=[],signal_errors=[],detached_descendants_covered=False)
    try:
        os.killpg(proc.pid, signal.SIGTERM);result['term_sent']=True
    except ProcessLookupError:
        pass
    except PermissionError as error:
        result['signal_errors'].append(repr(error))
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        result['leader_grace_timeout']=True
    finally:
        # Leader exit is not group exit. Escalate in both cases.
        try:
            os.killpg(proc.pid, signal.SIGKILL);result['kill_sent']=True
        except ProcessLookupError:
            pass
        except PermissionError as error:
            result['signal_errors'].append(repr(error))
    proc.wait(timeout=10);result['direct_child_joined']=True
    deadline=time.monotonic()+10
    while True:
        live,members=live_group_members(proc.pid)
        if not live:
            result['quiescent']=True;result['dead_members']=members
            return result
        if time.monotonic()>=deadline:
            raise RuntimeError('owned process group still live/unproven after SIGKILL: '+repr(members))
        # Cover members appearing during a /proc enumeration race.
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        except PermissionError as error:
            result['signal_errors'].append(repr(error))
        time.sleep(0.05)

def command(row, cwd, env, input_sha):
    directory=OUTPUT/'receipts'/row['label'];directory.mkdir(exist_ok=False)
    record=dict(command=row['argv'],cwd=str(cwd),env=env,started_ns=time.time_ns(),load_before=os.getloadavg(),
        input_sha256=input_sha,root_owner='/root',correctness_only=True,qualification=False,
        timeout_seconds=row['outer_timeout_seconds'],helper_sha256=sha(__file__),checks_sha256=CHECKS_SHA)
    proc=None; failure=None
    try:
        with (directory/'stdout.txt').open('x') as stdout,(directory/'stderr.txt').open('x') as stderr:
            proc=subprocess.Popen(row['argv'],cwd=cwd,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
            record['pid']=proc.pid
            try:
                record['rc']=proc.wait(timeout=row['outer_timeout_seconds'])
            except subprocess.TimeoutExpired:
                record['timeout']=True;record['rc']=124
    except BaseException as error:
        failure=error;record['error']=repr(error)
    finally:
        # Normal exit, timeout and interruption all close the owned group first.
        handlers={s:signal.signal(s,signal.SIG_IGN) for s in (signal.SIGINT,signal.SIGTERM)}
        try:
            quiescent=proc is None
            if proc is not None:
                try:
                    record['process_group_cleanup']=stop_group(proc);quiescent=True
                except BaseException as cleanup_error:
                    record['cleanup_error']=repr(cleanup_error)
                    failure=cleanup_error
                if 'rc' not in record:
                    record['rc']=proc.returncode
            record.update(finished_ns=time.time_ns(),load_after=os.getloadavg(),
                raw_hashes_final=quiescent,
                stdout_sha256=sha(directory/'stdout.txt') if quiescent and (directory/'stdout.txt').exists() else None,
                stderr_sha256=sha(directory/'stderr.txt') if quiescent and (directory/'stderr.txt').exists() else None)
            save(directory/'run.json',record)
            print(json.dumps(dict(label=row['label'],rc=record.get('rc'),receipt=str(directory))),flush=True)
        finally:
            for signum,handler in handlers.items():
                signal.signal(signum,handler)
    if failure is not None:
        raise failure
    require(record['rc']==0 and not record.get('timeout'), 'retained failed step; no retry: '+row['label'])
    events=[json.loads(line) for line in (directory/'stdout.txt').read_text().splitlines()]
    matches=validate_events(row,events)
    save(directory/'matches.json',matches)
    return dict(label=row['label'],path=str(directory/'run.json'),sha256=sha(directory/'run.json'),
        matches=str(directory/'matches.json'),matches_sha256=sha(directory/'matches.json'),
        skips=[dict(package=e.get('Package'),test=e.get('Test')) for e in events if e.get('Action')=='skip'])

def validate_events(row,events):
    if row.get('additive_group'):require(not any(e.get('Action')=='skip' for e in events),'additive native test/subtest skipped')
    require(not any(e.get('Action')=='fail' for e in events), 'failed JSON event')
    packages=['github.com/snissn/gomap/'+arg[2:] for arg in row['argv'] if arg.startswith('./')]
    require(set(packages)==set(row['required_matches']), 'bound package-set mismatch')
    matches={}
    for package in packages:
        names=sorted({e['Test'] for e in events if e.get('Package')==package and e.get('Action')=='pass' and e.get('Test') and '/' not in e['Test']})
        require(names and any(e.get('Package')==package and e.get('Action')=='pass' and not e.get('Test') for e in events), 'no successful matched top-level tests/package pass')
        required = set(row['required_matches'][package])
        if row.get('variant','B') in ('A','R','B'):
            passed = {e['Test'] for e in events if e.get('Package')==package and e.get('Action')=='pass' and e.get('Test')}
            skipped = {e['Test'] for e in events if e.get('Package')==package and e.get('Action')=='skip' and e.get('Test')}
            require(not required.intersection(skipped), 'required native test/subtest skipped')
            require(required.issubset(passed), 'required native test/subtest pass event absent')
        else:
            require(required.issubset(names), 'required matched name absent')
        if row['exact_match_set']:
            require(names==row['required_matches'][package], 'exact risk match-set mismatch')
        matches[package]=names
    return matches

def validate_additive(rows,inputs,meta):
    require(inputs['inspected_test_catalog']==inputs['dependencies']['inspected_test_catalog'] and inputs['inspected_test_catalog']['path']==str(HERE/'inspected-test-catalog.json'),'exact inspected catalog selection')
    catalog=bound(inputs['inspected_test_catalog'])
    require(catalog['receipt_kind']=='qualification-v12-inspected-test-names' and catalog['accepted_by_root'] is False,'inspected finite catalog required')
    expected=read(HERE/'checks-fresh.template.json')['checks'][30:]
    require(sha(HERE/'checks-fresh.template.json')==inputs['dependencies']['checks_fresh_template']['sha256'] and inputs['dependencies']['checks_fresh_template']['path']==str(HERE/'checks-fresh.template.json'),'exact additive template binding')
    require(rows==expected and len(rows)==16,'all16 additive normal/race contracts required')
    for role in ('A','R','B'):
        source=Path(meta['variants'][role]['source'])
        for item in catalog['tests']:
            path=source/item['path']
            require(path.is_file() and not path.is_symlink() and re.search(r'^func '+re.escape(item['name'])+r'\(t \*testing\.T\)',path.read_text(),re.M),'inspected additive test absent from actual fresh source: '+role+':'+item['name'])


def compiler_review(inputs,stop):
    accepted=bound(inputs['actual_content_acceptance'])
    require(accepted['actual_compiler_input_contents_accepted']=={slot:True for slot in SLOTS},'actual per-slot compiler-input root content acceptance required')
    require(set(stop['compiler_input_receipts'])==set(SLOTS) and accepted['compiler_input_receipts']==stop['compiler_input_receipts'],'compiler input receipt root identity')
    for slot,ref in stop['compiler_input_receipts'].items():
        ci=bound(ref);require(ci['slot']==slot and {k:ci[k] for k in ('head','tree')}==PINS[SLOTS[slot]],'compiler source identity')
        pc.bound(ci['go_list_receipt']);pc.bound(ci['build_receipt']);pc.bound(ci['export_listing_receipt']);require(sha(ci['go_list_raw']['path'])==ci['go_list_raw']['sha256'] and sha(ci['export_listing_raw']['path'])==ci['export_listing_raw']['sha256'],'actual compiler raw listing drift')
        for key in ('selected_files','module_files','uncompiled_repository_test_inputs','native_input_files','generated_and_work_files','actual_import_archives','actual_package_export_archives'):pc.verify_bindings(ci[key])

def main():
    global pc
    if len(sys.argv)!=3:raise ValueError('REQUEST SHA256 required')
    pc=load_common(sys.argv[1],sys.argv[2])
    global ROOT,CAMPAIGN,OUTPUT,HERE,ENV_SHA,CHECKS_SHA,PINS,SLOTS
    require(__debug__ and len(sys.argv)==3,'unoptimized REQUEST SHA256 required')
    inputs,input_ref=pc.request(sys.argv[1],sys.argv[2],'correctness');input_path=Path(sys.argv[1])
    require(inputs['controller_path']==str(Path(__file__).resolve()),'actual correctness helper selection')
    ROOT=pc.canonical(inputs['native_root']);CAMPAIGN=pc.canonical(inputs['foundation']);OUTPUT=pc.canonical(inputs['output'],exists=False);HERE=Path(__file__).resolve().parent
    ENV_SHA=inputs['environment']['sha256'];CHECKS_SHA=inputs['checks']['sha256'];SLOTS=pc.SLOTS
    require(not OUTPUT.exists(),'exclusive fresh correctness output')
    checks=bound(inputs['checks']);original=read(HERE/'checks.json')
    require(inputs['dependencies']['checks_original']==dict(path=str(HERE/'checks.json'),sha256=inputs['original_checks_sha256']),'exact original checklist dependency')
    require(sha(HERE/'checks.json')==inputs['original_checks_sha256'],'original30 checklist drift')
    require(checks['checks'][:30]==original['checks'] and len(original['checks'])==30,'every original30 row preserved exactly')
    require(len(checks['checks'])==checks['check_count'] and len({r['label'] for r in checks['checks']})==checks['check_count'],'exact complete unique checklist count')
    meta,frozen,PINS=pc.basis(inputs);manifest=bound(inputs['manifest']);inventory=bound(inputs['inventory_complete']);accepted=bound(inputs['actual_content_acceptance']);stop=bound(inputs['build_complete'])
    validate_additive(checks['checks'][30:],inputs,meta)
    compiler_review(inputs,stop);pc.native_scope(inputs,frozen)
    require(Path(inputs['manifest']['path'])==CAMPAIGN/'manifest.json' and Path(inputs['inventory_complete']['path'])==CAMPAIGN/'inventory-complete.json', 'formal fresh foundation layout required')
    require(meta['accepted_by_root'] is True and meta['landed_harness_attested'] is True and meta['held_excluded']==[5004,5006], 'formal composition acceptance required')
    require({r:dict(head=v['accepted_head'],tree=v['tree']) for r,v in meta['variants'].items()}==PINS, 'exact A/R/B composition')
    require({r:dict(head=v['accepted_head'],tree=v['tree']) for r,v in meta['variants'].items()}==PINS,'fresh composition pins')
    require(inventory['accepted_by_root'] is True and inventory['status']=='ROOT_ACCEPTED_ACTUAL_INVENTORY_CONTENTS' and inventory['performance_runs']==0 and inventory['qualification'] is False, 'accepted formal inventory required')
    require(inventory['manifest_sha256']==inputs['manifest']['sha256'] and inventory['actual_content_acceptance_path']==inputs['actual_content_acceptance']['path'] and inventory['actual_content_acceptance_sha256']==inputs['actual_content_acceptance']['sha256'], 'inventory/root content binding')
    require(accepted['accepted_by_root'] is True and accepted['qualification'] is False and accepted['collection_authorized'] is False and accepted['actual_receipt_contents_accepted']=={r:True for r in ('source','build','native','runner')}, 'actual formal raw-content review required')
    require(accepted['landed_harness_attested'] is True and accepted['host_clock_and_serialization_accepted'] is True, 'harness/serialization content acceptance')
    require(accepted['manifest_sha256']==inputs['manifest']['sha256'] and accepted['sources']==manifest['sources'] and accepted['libraries']==manifest['libraries'], 'root manifest contents mismatch')
    require(accepted['receipt_sha256']=={r:v['sha256'] for r,v in manifest['receipts'].items()}, 'root receipt identities mismatch')
    prepared=bound(dict(path=str(CAMPAIGN/'inventory-prepared.json'),sha256=accepted['inventory_prepared_sha256']))
    require(prepared['accepted_by_root'] is False and prepared['manifest_sha256']==inputs['manifest']['sha256'], 'original inventory STOP required')
    require(stop['schema']==1 and stop['status']=='BUILD_COMPLETE_STOP_BEFORE_MEASUREMENT' and stop['accepted_by_root'] is False and stop['actual_receipt_content_acceptance_required'] is True and stop['performance_runs']==0 and stop['qualification'] is False, 'formal8 build STOP required')
    require(stop['composition_sha256']==inputs['composition']['sha256'] and stop['source_freeze_sha256']==inputs['source_freeze']['sha256'], 'build composition/freeze mismatch')
    require(accepted['build_complete_sha256']==inventory['build_complete_sha256']==prepared['build_complete_sha256']==inputs['build_complete']['sha256'], 'root formal build binding')
    require(set(stop['source_receipts'])==set(PINS) and set(stop['build_receipts'])==set(SLOTS) and set(manifest['sources'])==set(SLOTS), 'three sources/eight binaries required')
    require(set(manifest['receipts'])=={'source','build','native','runner'}, 'full formal receipt scope')
    receipts={r:bound(dict(path=str(CAMPAIGN/v['path']),sha256=v['sha256'])) for r,v in manifest['receipts'].items()}
    require(receipts['source']['received_composition']==meta and receipts['source']['composition_sha256']==inputs['composition']['sha256'], 'actual source receipt composition')
    environment=bound(inputs['environment']);require(inputs['environment']['sha256']==ENV_SHA==frozen['environment_sha256'], 'fresh frozen environment required')
    require(all(isinstance(k,str) and isinstance(v,str) for k,v in environment.items()), 'environment string map')
    require(all(environment.get(k)==v for k,v in {'GOWORK':'off','GOTOOLCHAIN':'local','GOMAXPROCS':'12','GOGC':'100','GOMEMLIMIT':'off','CGO_ENABLED':'1','GOENV':'off','GODEBUG':'','GOEXPERIMENT':''}.items()), 'original runner controls')
    require(not any(k.startswith('TREEDB_') for k in environment) and not environment.get('LD_PRELOAD') and not environment.get('LD_AUDIT') and not environment.get('GOFLAGS'), 'unexpected environment override')
    require(manifest['build_env']=={k:environment[k] for k in ENV_KEYS if k in environment}, 'formal build environment differs original environment')
    go=Path(inputs['go_tool']['path']);require(inputs['go_tool']['path']==str(go) and sha(go)==inputs['go_tool']['sha256'] and shutil.which('go',path=environment['PATH'])==str(go), 'actual bound Go1.26.3 executable required')
    libraries=manifest['libraries'];require(len(libraries)==16 and libraries==frozen['expected_native_libraries']==receipts['native']['libraries'], 'actual frozen16 library inventory required')
    for name,item in libraries.items():
        path=Path(name);require(path.is_absolute() and path.is_file() and sha(path)==item['sha256'] and str(path.resolve())==item['resolved'], 'native library drift')
    listings={}
    for role,v in meta['variants'].items():
        source=Path(meta['variants'][role]['source']);require(v['source']==str(source), 'formal source path')
        listing=pc.bound(v['tracked_manifest']);require({k:listing[k] for k in ('head','tree')}==PINS[role], 'tracked source identity')
        checked_source(source,listing);listings[role]=listing
        sr=bound(stop['source_receipts'][role]);require(sr['rc']==0 and sr['source']==str(source) and {k:sr[k] for k in ('head','tree')}==PINS[role] and sr['verified_all_tracked_blobs_and_modes'] is True, 'formal build source receipt')
    for slot,role in SLOTS.items():
        v=manifest['sources'][slot];require({k:v[k] for k in ('head','tree')}==PINS[role] and v['built_against_head']==PINS[role]['head'], 'exact built source pins')
        name=v['binary'];require(name==Path(name).name and sha(CAMPAIGN/'bin'/name)==v['binary_sha256'], 'formal binary drift')
        br=bound(dict(path=stop['build_receipts'][slot]['path'],sha256=stop['build_receipts'][slot]['sha256']))
        require(br['rc']==0 and not br.get('controller_timeout') and br['binary_sha256']==v['binary_sha256'] and {k:br[k] for k in ('head','tree')}==PINS[role], 'formal build receipt')
        require(br['accepted_input']['go_version'].startswith('go version go1.26.3 ') and br['accepted_input']['go_binary']==str(go) and br['accepted_input']['environment_sha256']==ENV_SHA and br['accepted_input']['build_env']==manifest['build_env'], 'actual Go1.26.3 build/environment binding')
    idle(ROOT)
    signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
    OUTPUT.mkdir();(OUTPUT/'receipts').mkdir();(OUTPUT/'input.json').write_bytes(input_path.read_bytes())
    save(OUTPUT/'bindings.json',dict(input_sha256=sys.argv[2],composition=inputs['composition'],manifest=inputs['manifest'],inventory_complete=inputs['inventory_complete'],actual_content_acceptance=inputs['actual_content_acceptance'],source_pins=PINS,environment=inputs['environment'],go_tool=inputs['go_tool'],checks_sha256=CHECKS_SHA))
    completed=[]
    for row in checks['checks']:
        role=row.get('variant','B');require(role in PINS, 'check source role')
        source=Path(meta['variants'][role]['source'])
        completed.append(command(row,source,environment,sys.argv[2]))
    for role,listing in listings.items():
        checked_source(Path(meta['variants'][role]['source']),listing)
    for key in ('composition','manifest','inventory_complete','actual_content_acceptance','build_complete','environment'):
        bound(inputs[key])
    require(sha(input_path)==sys.argv[2] and sha(__file__)==inputs['controller_sha256'] and sha(inputs['checks']['path'])==CHECKS_SHA and sha(go)==inputs['go_tool']['sha256'], 'input/helper/tool drift after tests')
    for name,item in libraries.items():
        require(sha(name)==item['sha256'] and str(Path(name).resolve())==item['resolved'], 'library drift after tests')
    for source in manifest['sources'].values():
        require(sha(CAMPAIGN/'bin'/source['binary'])==source['binary_sha256'], 'binary drift after tests')
    pc.request(sys.argv[1],sys.argv[2],'correctness');compiler_review(inputs,stop);pc.native_scope(inputs,frozen);pc.basis(inputs)
    save(OUTPUT/'correctness-complete.json',dict(schema=1,status='CORRECTNESS_COMPLETE_STOP_ROOT_CONTENT_REVIEW_REQUIRED',rc=0,accepted_by_root=False,collection_authorized=False,qualification=False,performance_accepted=False,variants=PINS,candidate_role='per-check exact fresh A/R/B',original30_rows_preserved=True,additive_check_count=len(checks['checks'])-30,commands=len(checks['checks']),input_sha256=sys.argv[2],manifest_sha256=inputs['manifest']['sha256'],composition_sha256=inputs['composition']['sha256'],root_content_acceptance_sha256=inputs['actual_content_acceptance']['sha256'],checks_sha256=CHECKS_SHA,checks=completed,finished_ns=time.time_ns()))
    print('CORRECTNESS_COMPLETE_STOP_ROOT_CONTENT_REVIEW_REQUIRED',flush=True)

if __name__=='__main__':main()
