"""Pure AST merge/add_file/sha only, with synthetic local files; no main/import."""
import ast,copy,hashlib,json,tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
old=HERE.parent/'qualification-v12-analysis-receipt-compatibility-preparation-v1/root-final-raw-closure-v12-v2.py'
new=HERE/'root-final-raw-closure-v12-v3.py'
class CountPath(type(Path())):
 resolutions=0
 def resolve(self,*args,**kwargs):
  type(self).resolutions+=1
  return super().resolve(*args,**kwargs)
def seam(source):
 tree=ast.parse(source.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('require','sha','canonical','map_target','add_map','merge')]
 g={'Path':CountPath,'hashlib':hashlib}
 exec(compile(ast.Module(body=copy.deepcopy(nodes),type_ignores=[]),'<AST synthetic merge>','exec'),g)
 actual_sha=g['sha'];g['hash_calls']=[]
 def counted_sha(p):g['hash_calls'].append(str(p));return actual_sha(p)
 g['sha']=counted_sha
 return g
original=seam(old);linear=seam(new);checks=[];counts=[]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check(label,files,incoming,valid,expected=None):
 for version,g in [('rawV2',original),('rawV3',linear)]:
  m=dict(files);before=list(m.items());g['hash_calls'].clear()
  try:g['merge'](m,incoming)
  except (AssertionError,OSError,ValueError):assert not valid,(label,version)
  else:
   assert valid,(label,version)
   if expected is not None:assert list(m.items())==list(expected.items()),(label,version)
   assert all(m[k]==v for k,v in before),(label,version,'retained map drift')
   assert len(g['hash_calls'])==2*len(incoming),(label,version,'incoming reads skipped')
  checks.append({'name':label,'version':version,'passed':True})
with tempfile.TemporaryDirectory(prefix='synthetic-merge-',dir=HERE) as raw:
 root=Path(raw).resolve();a=root/'a';b=root/'b';c=root/'c'
 for p in (a,b,c):p.write_bytes(p.name.encode())
 da,db,dc=map(digest,(a,b,c));alias=root/'alias-a';alias.symlink_to(a)
 parent=root/'alias-parent';parent.symlink_to(root,target_is_directory=True)
 check('same-path reuse unchanged order',{str(a):da},{str(a):da},True,{str(a):da})
 check('incoming symlink canonical-equivalent reuse retains original key',{str(a):da},{str(alias):da},True,{str(a):da})
 check('inherited alias retains exact original spelling',{str(alias):da},{str(a):da},True,{str(alias):da})
 check('inherited parent alias retains spelling',{str(parent/'a'):da},{str(a):da},True,{str(parent/'a'):da})
 check('new canonical file appended',{str(a):da},{str(b):db},True,{str(a):da,str(b):db})
 check('incoming alternate equivalent key retains first admitted key',{},dict([(str(a),da),(str(alias),da)]),True,{str(a):da})
 check('conflicting inherited digest',{str(a):'0'*64},{str(a):da},False)
 check('wrong incoming digest',{str(a):da},{str(b):'0'*64},False)
 check('duplicate inherited canonical aliases',{str(a):da,str(alias):da},{str(a):da},False)
 check('new symlink rejected',{}, {str(alias):da},False)
 check('new symlink-parent alias rejected',{}, {str(parent/'a'):da},False)
 (root/'sub').mkdir()
 check('new dotdot spelling rejected',{}, {str(root/'sub'/ '..'/'a'):da},False)
 relative=Path(a).relative_to(Path.cwd()) if a.is_relative_to(Path.cwd()) else None
 assert relative is not None
 check('new relative spelling rejected',{}, {str(relative):da},False)
 check('relative incoming rejected even if equivalent',{str(a):da},{str(relative):da},False)
 check('missing incoming file',{str(a):da},{str(root/'missing'):da},False)
 check('missing inherited file',{str(root/'missing'):da},{str(a):da},False)
 a.write_bytes(b'drift');check('drifting incoming file',{str(a):da},{str(a):da},False)
 a.write_bytes(b'a')
 # Failure retains the same already-verified prefix as the original merge.
 for version,g in [('rawV2',original),('rawV3',linear)]:
  m={str(a):da}
  try:g['merge'](m,{str(b):db,str(c):'0'*64})
  except (AssertionError,ValueError):pass
  else:raise AssertionError('partial-prefix hostile fixture passed')
  assert list(m.items())==[(str(a),da),(str(b),db)]
  checks.append({'name':'same partial verified prefix on failure','version':version,'passed':True})
 # Verify that the second incoming read still catches a change between reads.
 for version,g in [('rawV2',original),('rawV3',linear)]:
  actual_sha=g['sha'];calls=[0]
  def two_read_drift(p):
   calls[0]+=1
   return da if calls[0]==1 else '0'*64
  g['sha']=two_read_drift
  try:g['merge']({str(a):da},{str(a):da})
  except (AssertionError,ValueError):pass
  else:raise AssertionError('second-read drift not rejected')
  finally:g['sha']=actual_sha
  assert calls[0]==2
  checks.append({'name':'reject second-read drift','version':version,'passed':True})
 # A fresh index is built per call: changed local path state cannot be cached.
 mapping={str(a):da};linear['merge'](mapping,{str(a):da});a.unlink()
 try:linear['merge'](mapping,{str(b):db})
 except FileNotFoundError:pass
 else:raise AssertionError('cross-call stale path accepted')
 checks.append({'name':'no cross-call canonical cache','version':'rawV3','passed':True})
 for n in (16,64,128):
  entries={}
  for i in range(n):
   p=root/('scale-'+str(n)+'-'+str(i));p.write_bytes(str(i).encode());entries[str(p)]=digest(p)
  for version,g in [('rawV2',original),('rawV3',linear)]:
   CountPath.resolutions=0;g['hash_calls'].clear();m=dict(entries);g['merge'](m,entries)
   expected=n*(n+1) if version=='rawV2' else 2*n
   assert CountPath.resolutions==expected,(version,n,CountPath.resolutions,expected)
   assert len(g['hash_calls'])==2*n and list(m.items())==list(entries.items())
   counts.append({'version':version,'retained_count':n,'incoming_count':n,'observed_resolve_calls':CountPath.resolutions,'incoming_hash_reads':len(g['hash_calls']),'expected_resolve_calls':expected})
 # Fake canonical filesystem supplies N=12555 for exact bounded operation counting.
 class FakePath:
  resolutions=0
  def __init__(self,p):self.name=p.name if isinstance(p,FakePath) else str(p)
  def resolve(self,strict=True):type(self).resolutions+=1;return self
  def is_file(self):return True
  def is_absolute(self):return self.name.startswith('/')
  def is_symlink(self):return False
  def __hash__(self):return hash(self.name)
  def __eq__(self,other):return isinstance(other,FakePath) and self.name==other.name
  def __str__(self):return self.name
 g=seam(new);g['Path']=FakePath;fake_hash_calls=[0]
 def fake_sha(p):fake_hash_calls[0]+=1;return 'd'*64
 g['sha']=fake_sha
 n=12555;entries={'/synthetic/file-'+str(i):'d'*64 for i in range(n)};m=dict(entries);g['merge'](m,entries)
 assert FakePath.resolutions==2*n and fake_hash_calls[0]==2*n and m==entries
 counts.append({'version':'rawV3','filesystem':'pure fake canonical fixture','retained_count':n,'incoming_count':n,'observed_resolve_calls':FakePath.resolutions,'original_resolve_calls_from_measured_formula':n*(n+1),'observed_incoming_hash_reads':fake_hash_calls[0]})
result={'source_only':True,'checks_count':len(checks),'checks':checks,'resolution_counts':counts,'scope':'AST-extracted require/sha/canonical/map_target/add_map/merge only; synthetic local and fake filesystems; no campaign/main/native/IO/controller/evaluator execution','qualification':False,'performance_accepted':False,'collection_authorized':False,'candidate_pairs_authorized':False,'merge_authorized':False}
with (HERE/'raw-isolated-check-results-final.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('PASSED',len(checks));print(json.dumps(counts,separators=(',',':')))
