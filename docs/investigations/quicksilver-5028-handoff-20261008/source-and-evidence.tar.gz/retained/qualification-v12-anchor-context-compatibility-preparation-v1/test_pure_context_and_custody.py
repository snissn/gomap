"""Isolated AST seams only. Never loads a controller, IO module or main."""
import ast,copy,hashlib,json,types
from pathlib import Path
PACKET=Path(__file__).resolve().parent
BASE=PACKET.parent
NATIVE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=NATIVE/'qualification-v12-refresh/qualification-v10'
HERE=NATIVE/'qualification-v12-later-execution-preparation-v3'
OP=ROOT.parent/'qualification-v10-prospective-root-v1/pre-c1-anchor.accepted-v2.json'
OP_SHA='888b36ee11f99c77af68341651cef36e1fe4cb817652091e17edb90eec8497b4'
source=(PACKET/'root-global-calibration-transition-v12-v4.py').read_text()
tree=ast.parse(source);functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
local_op=BASE/'qualification-v12-refresh/qualification-v10-prospective-root-v1/pre-c1-anchor.accepted-v2.json'
assert hashlib.sha256(local_op.read_bytes()).hexdigest()==OP_SHA
actual=json.loads(local_op.read_bytes())
checks=[]
def record(name,fn,valid):
 try:fn()
 except (AssertionError,KeyError,ValueError):
  assert not valid,name
 else:assert valid,name
 checks.append(dict(name=name,passed=True))
def isolated(name,globals_dict):
 node=copy.deepcopy(functions[name]);exec(compile(ast.Module(body=[node],type_ignores=[]),'<isolated AST seam>','exec'),globals_dict)
 return globals_dict[name]
ref={'path':str(OP),'sha256':OP_SHA}
g={'OP':OP,'OP_SHA':OP_SHA,'INITIAL_OP_SHA':OP_SHA,'ROOT':ROOT,'OP_FILE_COUNT':12555,
 'OUT':HERE/'qualification-v12-global-analysis-transitions-v1','bound':lambda r:copy.deepcopy(actual),
 'reference':lambda p:ref.copy()}
pre=isolated('predecessor',g)
record('genuine exact OP B-pre unchanged',lambda:pre('B-pre',ref,copy.deepcopy(actual)),True)
fixed=ast.literal_eval(next(n.value for n in ast.walk(functions['predecessor']) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='fixed' for x in n.targets)))
missing=('complete_unchanged_deployment_import_set','retained_failed_direct_preflight','predecessor_source_anchor')
for key in fixed:
 if key in actual:
  bad=copy.deepcopy(actual);bad[key]={'synthetic_drift':True}
  record('reject changed '+key,lambda b=bad:pre('B-pre',ref,b),False)
  bad=copy.deepcopy(actual);del bad[key]
  record('reject removed '+key,lambda b=bad:pre('B-pre',ref,b),False)
 else:
  bad=copy.deepcopy(actual);bad[key]=None
  record('reject fabricated absent '+key,lambda b=bad:pre('B-pre',ref,b),False)
for key in missing:
 bad=copy.deepcopy(actual);bad[key]=None;g['bound']=lambda r,b=bad:b
 record('reject arbitrary operational historical-field presence '+key,lambda:pre('B-pre',ref,bad),False)
g['bound']=lambda r:copy.deepcopy(actual)
g['OP_SHA']='0'*64
record('reject different OP binding',lambda:pre('B-pre',ref,actual),False);g['OP_SHA']=OP_SHA
bad=copy.deepcopy(actual);bad['files'].pop(next(iter(bad['files'])))
record('reject dropped source map binding',lambda:pre('B-pre',ref,bad),False)
flags=('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized')
adapter={'path':str(NATIVE/'qualification-v12-analysis-receipt-compatibility-preparation-v1/prepare-original-analysis-receipt-view-v12-v2.py'),'sha256':'830f832be33ffd6c6c757f3c86ca0a5d3089357f8d2fc2d6705ae17c42ef8466'}
own={'path':str(PACKET/'root-global-calibration-transition-v12-v4.py'),'sha256':hashlib.sha256(source.encode()).hexdigest()}
prior={'path':str(HERE/'root-global-transition-source-acceptance-v12-v3.json'),'sha256':'f1150ead3c594f767126783d99f9650b007fca368884a47e1e2cd464e64c5cb9'}
prior_helper={'path':str(HERE/'root-global-calibration-transition-v12-v3.py'),'sha256':'1f5fe209749617ebe65f1bccf4fd579c557a145047cbc8c1093ce1fbdd793b97'}
# Synthetic source acceptance is a pure fixture, never an emitted acceptance.
review={'path':'/synthetic/review','sha256':'1'*64};manifest={'path':'/synthetic/manifest','sha256':'2'*64}
adoption=dict(schema=1,owner='/root',accepted_by_root=True,source_only=True,campaign_root=str(ROOT),held_excluded=[5004,5006],helper=own,prepare_adapter=adapter,independent_source_review=review,independent_source_manifest=manifest,**{k:False for k in flags})
def reference(p):
 return {own['path']:own,review['path']:review,manifest['path']:manifest}[str(p)]
cg={'Path':Path,'__file__':own['path'],'ROOT':ROOT,'ADAPTER_PATH':adapter['path'],'ADAPTER_SHA':adapter['sha256'],'bound':lambda r:copy.deepcopy(adoption),'reference':reference}
current=isolated('current_source_acceptance',cg)
request={'source_compatibility_acceptance':{'path':'/synthetic/new-source-adoption','sha256':'3'*64}}
record('current V4 separate source acceptance admitted',lambda:current(request),True)
for key,value in [('helper',prior_helper),('prepare_adapter',dict(adapter,sha256='0'*64)),('owner','/other'),('schema',2),('source_only',False),('accepted_by_root',False),('held_excluded',[]),('campaign_root','/other')]+[(k,True) for k in flags]:
 bad=copy.deepcopy(adoption);bad[key]=value;cg['bound']=lambda r,b=bad:b
 record('reject current source adoption '+key,lambda:current(request),False)
# Extract actual prepare admission prefix through helper custody assertion.
prep=copy.deepcopy(functions['preparation_transport']);end=next(i for i,n in enumerate(prep.body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='add_file');prep.body=prep.body[:end]
pg={'Path':Path,'ROOT':ROOT,'BD':NATIVE/'qualification-analysis-controller.py','RD':NATIVE/'r-material-gate-preparation-v2/r-analysis-controller.py','RDEF':ROOT/'prospective-v10-root-v1/r-definition.accepted.json','RDEF_SHA':'cf1d1d0455e8cd2b1e50cb117b1af439a6d413287615e0b58ff1909fb29e00d7','ADAPTER_PATH':adapter['path'],'ADAPTER_SHA':adapter['sha256'],'PRIOR_PREPARE_SOURCE_ACCEPTANCE':prior,'PRIOR_PREPARE_HELPER':prior_helper,'source':lambda *args:types.SimpleNamespace(FLAGS=flags)}
exec(compile(ast.Module(body=[prep],type_ignores=[]),'<isolated prepare admission AST>','exec'),pg)
actualq=json.loads((BASE/'qualification-v12-later-execution-preparation-v3/root-B-prepare-receipt-view-actual-request-v12-v1.json').read_bytes())
prior_adoption=json.loads((BASE/'qualification-v12-later-execution-preparation-v3/root-global-transition-source-acceptance-v12-v3.json').read_bytes())
for role in ('B','R'):
 q=copy.deepcopy(actualq);q['role']=role;out=ROOT/('analysis-global-original-v1' if role=='B' else 'ar-analysis-global-original-v1');q['original_argv']=['python3','-B',str(pg['BD'] if role=='B' else pg['RD']),'full-calibration','--campaign',str(ROOT),'--out',str(out)]
 req={'preparation_transport':{'adapter':adapter,'request':{'path':'/synthetic/prepare-request','sha256':'4'*64},'provenance':{'path':'/synthetic/provenance','sha256':'5'*64},'execution':{}},'base_anchor':{'path':'/synthetic/R-predecessor','sha256':'6'*64}}
 if role=='R':q['original_argv']+=['--original-B-anchor',req['base_anchor']['path'],'--original-B-anchor-sha256',req['base_anchor']['sha256'],'--definition',str(pg['RDEF']),'--definition-sha256',pg['RDEF_SHA']]
 q['original_argv']+=['--prepare']
 def bound(r):
  if r==req['preparation_transport']['request']:return q
  if r==req['preparation_transport']['provenance']:return {}
  assert r==prior;return prior_adoption
 pg['bound']=bound
 record('prior immutable V3 adapter custody '+role,lambda:pg['preparation_transport'](req,role,out,{}),True)
 q['source_compatibility_acceptance']=dict(prior,sha256='0'*64)
 record('reject altered prior adoption '+role,lambda:pg['preparation_transport'](req,role,out,{}),False)
 q['source_compatibility_acceptance']=prior.copy();saved=prior_adoption['helper'];prior_adoption['helper']=own
 record('reject rewritten prior helper '+role,lambda:pg['preparation_transport'](req,role,out,{}),False);prior_adoption['helper']=saved
result={'source_only':True,'execution_scope':'AST-extracted pure seams; no native, IO, controller, evaluator or main execution','checks_count':len(checks),'checks':checks,'qualification':False,'performance_accepted':False,'collection_authorized':False,'candidate_pairs_authorized':False,'merge_authorized':False}
with (PACKET/'pure-check-results.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('PASSED',len(checks))
