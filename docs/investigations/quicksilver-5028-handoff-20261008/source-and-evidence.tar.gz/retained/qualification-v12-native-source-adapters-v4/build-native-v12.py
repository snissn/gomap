#!/usr/bin/env python3
"""Fresh exact full exports and eight serial native builds; no measurement."""
import hashlib
import json
import os
import pathlib
import re
import shutil
import signal
import stat
import subprocess
import sys
import tarfile
import time
pc=None

def load_common(request_path, request_sha):
    import types
    p=Path(request_path) if 'Path' in globals() else pathlib.Path(request_path)
    raw=p.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=request_sha:raise ValueError('request SHA mismatch')
    request=json.loads(raw);ref=request['dependencies']['pipeline_common']
    selected=(Path(__file__) if 'Path' in globals() else pathlib.Path(__file__)).resolve().parent/'pipeline_common.py'
    if ref['path']!=str(selected) or selected.is_symlink() or hashlib.sha256(selected.read_bytes()).hexdigest()!=ref['sha256']:raise ValueError('exact shared dependency selection drift')
    module=types.ModuleType('qualification_v12_pipeline_common');module.__file__=str(selected)
    exec(compile(selected.read_bytes(),str(selected),'exec'),module.__dict__)
    return module


def require(condition, detail):
    if not condition:
        raise RuntimeError(detail)

def sha(path):
    digest = hashlib.sha256()
    with pathlib.Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return digest.hexdigest()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def absent(path):
    require(not os.path.lexists(path), 'immutable output already exists: ' + str(path))

def oid(value):
    require(isinstance(value, str) and re.fullmatch('[0-9a-f]{40}', value),
            'expected full Git object ID')
    return value

def load_bound(path, digest):
    require(isinstance(digest, str) and re.fullmatch('[0-9a-f]{64}', digest),
            'expected SHA256: ' + str(path))
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == digest, 'SHA256 mismatch: ' + str(path))
    return json.loads(data)

def manifest(path, digest):
    listing = load_bound(path, digest)
    oid(listing['head'])
    oid(listing['tree'])
    require(isinstance(listing['files'], dict) and listing['files'], 'empty tracked manifest')
    for name, item in listing['files'].items():
        relative = pathlib.PurePosixPath(name)
        require(name == relative.as_posix() and not relative.is_absolute()
                and all(p not in ('', '.', '..', '.git') for p in relative.parts),
                'unsafe tracked path: ' + name)
        require(item['mode'] in ('100644', '100755', '120000'), 'unsupported Git mode')
        oid(item['blob'])
    return listing

def verify(source, listing):
    require(source.is_dir() and not source.is_symlink(), 'source must be a real directory')
    for name, item in listing['files'].items():
        path = source / name
        parent = path.parent
        while parent != source:
            require(parent.is_dir() and not parent.is_symlink(), 'unsafe parent: ' + str(parent))
            parent = parent.parent
        mode = path.lstat().st_mode
        if item['mode'] == '120000':
            require(stat.S_ISLNK(mode), 'expected symlink: ' + name)
            data = os.fsencode(os.readlink(path))
        else:
            require(stat.S_ISREG(mode), 'expected regular file: ' + name)
            require(bool(mode & 0o111) == (item['mode'] == '100755'), 'Git mode mismatch: ' + name)
            data = path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        require(blob == item['blob'], 'Git blob mismatch: ' + name)

def leaves(source):
    result = set()
    for parent, directories, files in os.walk(source, followlinks=False):
        for name in list(directories):
            require(name != '.git', 'source export contains Git administration directory')
            path = pathlib.Path(parent) / name
            if path.is_symlink():
                result.add(path.relative_to(source).as_posix())
                directories.remove(name)
        for name in files:
            result.add((pathlib.Path(parent) / name).relative_to(source).as_posix())
    require(not any('.git' in pathlib.PurePosixPath(name).parts for name in result),
            'source export contains Git administration files')
    return result

def interrupt(signum, frame):
    raise InterruptedError('controller signal ' + str(signum))

def successful(record, failure):
    if failure is not None:
        raise failure
    require(record['rc'] == 0 and not record.get('controller_timeout'),
            'failed command retained; no retry: ' + str(record['command']))

def extract_archive(archive, source, listing):
    # Do not delegate tar path handling or follow archive-supplied symlink parents.
    with tarfile.open(archive, 'r:*') as stream:
        members = stream.getmembers()
        names = set()
        files = []
        for member in members:
            name = member.name.rstrip('/')
            relative = pathlib.PurePosixPath(name)
            require(name == relative.as_posix() and not relative.is_absolute() and
                all(p not in ('', '.', '..', '.git') for p in relative.parts), 'unsafe archive member')
            require(name not in names, 'duplicate archive path')
            names.add(name)
            if member.isdir():
                require(name not in listing['files'], 'archive directory/file collision')
                continue
            require(name in listing['files'], 'archive unexpected leaf')
            expected = listing['files'][name]
            require((member.issym() and expected['mode']=='120000') or
                    (member.isfile() and expected['mode'] in ('100644','100755')), 'archive type/mode mismatch')
            files.append(member)
        require({m.name for m in files} == set(listing['files']), 'archive omitted tracked Git paths')
        source.mkdir()
        for member in files:
            path = source / member.name
            path.parent.mkdir(parents=True, exist_ok=True)
        for member in files:
            path = source / member.name
            if member.issym():
                os.symlink(member.linkname, path)
            else:
                with stream.extractfile(member) as incoming, path.open('xb') as outgoing:
                    shutil.copyfileobj(incoming, outgoing)
                path.chmod(0o755 if listing['files'][member.name]['mode']=='100755' else 0o644)
    verify(source, listing)
    require(leaves(source) == set(listing['files']), 'full export leaves mismatch')


def main():
    global pc
    if len(sys.argv)!=3:raise ValueError('REQUEST SHA256 required')
    pc=load_common(sys.argv[1],sys.argv[2])
    require(len(sys.argv)==3,'REQUEST SHA256 required')
    r,request_ref=pc.request(sys.argv[1],sys.argv[2],'build');meta,frozen,pins=pc.basis(r)
    require(r['controller_path']==str(pathlib.Path(__file__).resolve()),'actual builder selection')
    root=pc.canonical(r['native_root']);foundation=pc.canonical(r['foundation']);env,go=pc.environment(r,frozen)
    native_inputs=pc.native_scope(r,frozen)
    complete=pc.canonical(r['build_complete'],exists=False);absent(complete)
    require(complete.is_relative_to(foundation),'build STOP belongs to foundation')
    plans={};builds=[]
    for role in ('A','R','B'):
        item=meta['variants'][role];require(item['source']==frozen['source_paths'][role],'frozen complete source path');source=pc.canonical(item['source'],exists=False);require(source.is_relative_to(root) and not source.is_relative_to(foundation),'source export must have its own native-root path');absent(source)
        listing=pc.bound(item['tracked_manifest']);archive_ref=item['archive'];archive=pc.canonical(archive_ref['path'])
        require(sha(archive)==archive_ref['sha256'],'archive SHA')
        ar=pc.bound(item['archive_receipt']);require(ar['rc']==0 and ar['head']==pins[role]['head'] and ar['tree']==pins[role]['tree'] and ar['archive_sha256']==sha(archive),'actual full archive receipt')
        directory=foundation/'receipts'/(role+'-source');absent(directory);plans[role]=(source,listing,archive,directory)
        builds.extend([(role,role,'./TreeDB/cmd/treemap',[],role+'-treemap'),(role+'_unified',role,'./cmd/unified_bench',['-tags','lmdb rocksdb'],role+'-unified')])
    builds.extend([('restore','A','./cmd/quicksilver_snapshot_restore',[],'fixed-restore'),('benchprof','A','./cmd/benchprof',[],'benchprof')])
    require(set(meta['binaries'])=={x[0] for x in builds},'exact eight binary slots')
    for slot,role,package,tags,label in builds:
        item=meta['binaries'][slot];pc.canonical(item['origin'],exists=False);pc.canonical(item['build_receipt'],exists=False);require(item['name']==pathlib.Path(item['name']).name and pathlib.Path(item['origin'])!=foundation/'bin'/item['name'],'distinct fresh build and staged binary paths');absent(pathlib.Path(item['origin']));absent(pathlib.Path(item['build_receipt']))
        require(pathlib.Path(item['origin']).is_relative_to(foundation/'bin') and pathlib.Path(item['build_receipt']).is_relative_to(foundation/'receipts'),'fresh build paths')
    require((foundation/'bin').is_dir() and (foundation/'receipts').is_dir(),'fresh artifact roots required')
    signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
    version,failure=pc.run([go,'version'],root,env,foundation/'receipts','go-version-v4',30);save(foundation/'receipts/go-version-v4.json',version);successful(version,failure)
    require(pathlib.Path(version['stdout_path']).read_text().startswith('go version go1.26.3 '),'Go1.26.3 required')
    binding=dict(request=request_ref,composition=r['composition'],source_freeze=r['source_freeze'],source_basis=r['source_basis'],source_basis_acceptance=r['source_basis_acceptance'],environment_sha256=r['environment']['sha256'],build_env={k:env[k] for k in sorted(pc.ENV_KEYS) if k in env},go_binary=go,go_binary_sha256=sha(go),go_version=pathlib.Path(version['stdout_path']).read_text().strip())
    source_receipts={};build_receipts={};compiler_receipts={}
    for role,(source,listing,archive,directory) in plans.items():
        directory.mkdir();record=dict(schema=1,role=role,source=str(source),head=listing['head'],tree=listing['tree'],started_ns=time.time_ns(),accepted_input=binding,archive_sha256=sha(archive),rc=None)
        try:extract_archive(archive,source,listing);record.update(rc=0,verified_all_tracked_blobs_and_modes=True,tracked_files=len(listing['files']))
        except BaseException as error:record.update(rc=1,error=repr(error));record['finished_ns']=time.time_ns();save(directory/'run.json',record);raise
        record['finished_ns']=time.time_ns();save(directory/'run.json',record);source_receipts[role]=dict(path=str(directory/'run.json'),sha256=sha(directory/'run.json'))
    for slot,role,package,tags,label in builds:
        source,listing,_,_=plans[role];verify(source,listing);require(leaves(source)==set(listing['files']),'exact export before build')
        directory=pathlib.Path(meta['binaries'][slot]['build_receipt']).parent;directory.mkdir()
        cr,cf=pc.run([go,'list','-deps','-json']+tags+[package],source,env,directory,'go-list',300);save(directory/'go-list-run.json',cr);successful(cr,cf)
        inputs=pc.compiler_inputs(pc.json_stream(pathlib.Path(cr['stdout_path']).read_text()),source,listing)
        binary=pathlib.Path(meta['binaries'][slot]['origin'])
        # -work/-x add diagnostics, preserve the original compilation controls.
        argv=[go,'build','-p','1','-buildvcs=false','-work','-x']+tags+['-o',str(binary),package]
        record,failure=pc.run(argv,source,env,directory,'build',300)
        record.update(schema=1,classification='fresh complete actual Git export; no tests or measurement',accepted_input=binding,slot=slot,role=role,head=listing['head'],tree=listing['tree'],tracked_manifest_sha256=meta['variants'][role]['tracked_manifest']['sha256'],binary=str(binary),binary_sha256=sha(binary) if binary.is_file() else None)
        if record['rc']==0 and not binary.is_file():record.update(rc=1,error='missing binary')
        save(pathlib.Path(meta['binaries'][slot]['build_receipt']),record);successful(record,failure)
        er,ef=pc.run([go,'list','-p','1','-deps','-export','-json']+tags+[package],source,env,directory,'go-list-exports',300);save(directory/'go-list-exports-run.json',er);successful(er,ef)
        export_packages=pc.json_stream(pathlib.Path(er['stdout_path']).read_text());exports=pc.package_exports(export_packages)
        generated=pc.work_inputs(record['stderr_path']);pc.verify_bindings(exports);pc.verify_bindings(inputs['selected_files']);pc.verify_bindings(inputs['module_files']);pc.verify_bindings(inputs['uncompiled_repository_test_inputs']);pc.verify_bindings(native_inputs);pc.verify_bindings(generated['generated_and_work_files']);pc.verify_bindings(generated['actual_import_archives']);verify(source,listing);require(leaves(source)==set(listing['files']),'exact export after build')
        ci=dict(schema=1,slot=slot,role=role,head=listing['head'],tree=listing['tree'],package=package,tags=tags,request=request_ref,go_list_receipt=dict(path=str(directory/'go-list-run.json'),sha256=sha(directory/'go-list-run.json')),go_list_raw=dict(path=cr['stdout_path'],sha256=cr['stdout_sha256']),build_receipt=dict(path=meta['binaries'][slot]['build_receipt'],sha256=sha(meta['binaries'][slot]['build_receipt'])),export_listing_receipt=dict(path=str(directory/'go-list-exports-run.json'),sha256=sha(directory/'go-list-exports-run.json')),export_listing_raw=dict(path=er['stdout_path'],sha256=er['stdout_sha256']),actual_package_export_archives=exports,native_input_scope=r['native_input_scope'],native_input_files=native_inputs,**inputs,**generated,accepted_by_root=False,complete_scope_requires_root_actual_content_review=True,qualification=False)
        save(directory/'compiler-inputs.json',ci);compiler_receipts[slot]=dict(path=str(directory/'compiler-inputs.json'),sha256=sha(directory/'compiler-inputs.json'))
        build_receipts[slot]=dict(path=meta['binaries'][slot]['build_receipt'],sha256=sha(meta['binaries'][slot]['build_receipt']),binary_sha256=sha(binary))
    pc.request(sys.argv[1],sys.argv[2],'build');pc.basis(r);pc.environment(r,frozen);pc.native_scope(r,frozen);pc.require(sha(pathlib.Path(__file__))==r['controller_sha256'],'builder drift')
    save(complete,dict(schema=1,status='BUILD_COMPLETE_STOP_BEFORE_MEASUREMENT',accepted_by_root=False,collection_authorized=False,qualification=False,performance_runs=0,completed_ns=time.time_ns(),composition_sha256=r['composition']['sha256'],source_freeze_sha256=r['source_freeze']['sha256'],source_receipts=source_receipts,build_receipts=build_receipts,compiler_input_receipts=compiler_receipts,actual_receipt_content_acceptance_required=True))
    print(json.dumps(dict(status='BUILD_COMPLETE_STOP_BEFORE_MEASUREMENT',receipt=str(complete),sha256=sha(complete),qualification=False)))


if __name__=='__main__':main()
