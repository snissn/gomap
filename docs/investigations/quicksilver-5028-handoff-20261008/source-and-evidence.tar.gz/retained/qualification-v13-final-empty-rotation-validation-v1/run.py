import subprocess,json,hashlib,os,time,sys,signal
from pathlib import Path
OUT=Path(__file__).resolve().parent
config=json.loads((OUT/"request.json").read_bytes());repo=Path(config["repo"])
env=os.environ.copy();env.update(config["environment"]);label=sys.argv[1]
sources={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in config["sources"]}
cmd=config["normal_command"] if label=="normal" else config["race_command"]
start=time.time_ns()
with (OUT/(label+".stdout")).open("xb") as o,(OUT/(label+".stderr")).open("xb") as e:
 process=subprocess.Popen(cmd,cwd=repo,env=env,stdout=o,stderr=e,start_new_session=True)
 (OUT/(label+"-owner.json")).write_text(json.dumps({"pid":process.pid,"pgid":process.pid,"started_ns":start,"command":cmd})+"\n")
 try:rc=process.wait(timeout=240)
 except subprocess.TimeoutExpired:
  os.killpg(process.pid,signal.SIGTERM)
  try:rc=process.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);rc=process.wait()
assert sources=={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in config["sources"]}
record={"rc":rc,"command":cmd,"environment":config["environment"],"source_bindings":sources,"started_ns":start,"finished_ns":time.time_ns(),"genuine_child_join":True,"stdout_sha256":hashlib.sha256((OUT/(label+".stdout")).read_bytes()).hexdigest(),"stderr_sha256":hashlib.sha256((OUT/(label+".stderr")).read_bytes()).hexdigest()}
(OUT/(label+"-result.json")).write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record),flush=True)
sys.exit(0 if rc==0 else 1)
