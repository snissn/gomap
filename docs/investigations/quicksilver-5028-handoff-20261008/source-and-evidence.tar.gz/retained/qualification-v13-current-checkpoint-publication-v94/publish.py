from pathlib import Path
import json,subprocess,hashlib,time
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
block=(HERE/'current-block.md').read_text();old=(BASE/'qualification-v13-current-checkpoint-publication-v93/current-block.md').read_text()
def api(endpoint,label,method='GET',payload=None):
 argv=['gh','api','repos/snissn/gomap/'+endpoint]
 if method!='GET':
  f=HERE/(label+'-request.json');f.write_text(json.dumps(payload)+'\n');argv+=['--method',method,'--input',str(f)]
 r=subprocess.run(argv,capture_output=True);(HERE/(label+'.json')).write_bytes(r.stdout);(HERE/(label+'.stderr')).write_bytes(r.stderr);assert r.returncode==0,(label,r.returncode)
 return json.loads(r.stdout)
results=[]
for n in [5028,5015,5016,5030,5116]:
 label='issue-'+str(n);ep='issues/'+str(n);before=api(ep,label+'-before');assert before['state']=='open'
 if n==5116:
  assert '<!-- codex-issue-graph-executor:writer-repair-selected-v94 -->' not in before['body']
  body=(HERE/'writer-current-block.md').read_text()+before['body']
 else:
  assert before['body'].startswith(old)
  body=block+before['body'][len(old):]
 api(ep,label+'-patch','PATCH',{'body':body});after=api(ep,label+'-readback');assert after['state']=='open' and after['body']==body
 results.append(dict(target=after['html_url'],path=str(HERE/(label+'-readback.json')),sha256=hashlib.sha256((HERE/(label+'-readback.json')).read_bytes()).hexdigest(),verified=True))
ep='issues/comments/6023447234';api(ep,'parent-comment-before');api(ep,'parent-comment-patch','PATCH',{'body':block});after=api(ep,'parent-comment-readback');assert after['body']==block
results.append(dict(target=after['html_url'],verified=True))
receipt=dict(checkpoint_version=94,verified_live_outputs=results,held_excluded=[5004,5006],qualification=False,performance_accepted=False,finished_ns=time.time_ns());rp=HERE/'root-publication-receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'checkpoint_version':94,'verified_live_outputs':len(results),'receipt_sha256':hashlib.sha256(rp.read_bytes()).hexdigest()}),flush=True)
