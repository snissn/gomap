"""Local synthetic identity checks only; uses the real 16-entry alias geometry."""
from pathlib import Path
import ast
import copy
import hashlib
import json
import re
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
CONTROLS=BASE/'qualification-v12-fresh-controls-v2'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())

class FiniteIdentity(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(prefix='synthetic-identity-',dir=HERE)
  self.root=Path(self.temp.name)
  self.real=read(CONTROLS/'v10-source-lock.json')['manifest']['libraries']
  self.assertEqual(len(self.real),16)
  self.names={};libraries={};files={}
  for loader,identity in self.real.items():
   target=identity['resolved']
   if target not in self.names:
    p=self.root/('target-'+str(len(self.names)));p.write_bytes(('synthetic-source-identity '+target).encode());self.names[target]=p
   p=self.names[target]
   if loader==target:alias=p
   else:
    alias=self.root/('loader-'+str(len(libraries)));alias.symlink_to(p);self.names[loader]=alias
   libraries[str(alias)]={'resolved':str(p),'sha256':sha(p)}
   files[str(p)]=sha(p)
  self.manifest={'libraries':libraries};mp=self.root/'manifest.json';mp.write_text(json.dumps(self.manifest))
  files[str(mp)]=sha(mp)
  self.files=files
  self.anchor={'runtime_loader_bindings':copy.deepcopy(libraries)}
  self.deployment={'manifest_sha256':sha(mp),'libraries':libraries}
  source=(HERE/'verify-qualification-v10-deployment-v2.py').read_text()
  canonical=source[source.index('    canonical = set()'):source.index('    def anchored(')]
  library=source[source.index("    libraries = manifest['libraries']"):source.index("    assert deployment['controls']")]
  self.block='\n'.join(line[4:] if line.startswith('    ') else line for line in (canonical+library).splitlines())
 def tearDown(self):self.temp.cleanup()
 def check(self):
  def bound(p,h):self.assertEqual(sha(p),h);return read(p)
  env={'Path':Path,'ROOT':self.root,'deployment':self.deployment,'bound':bound,'anchor_files':self.files,'sha':sha,'manifest':self.manifest,'anchor':self.anchor,'re':re}
  exec(compile(self.block,'exact-v2-identity-block','exec'),env)
  return env
 def alias(self):
  return next((Path(p),Path(i['resolved'])) for p,i in self.manifest['libraries'].items() if p!=i['resolved'])
 def test_real16_geometry_accepts_exact10_alias_pairs(self):
  result=self.check();self.assertEqual(len(self.anchor['runtime_loader_bindings']),16)
  self.assertEqual(len(result['canonical']),len(self.files))
 def test_unknown_alias_rejected(self):
  _,target=self.alias();alias=self.root/'unapproved-alias';alias.symlink_to(target);self.files[str(alias)]=sha(target)
  with self.assertRaises(AssertionError):self.check()
 def test_rebound_target_rejected(self):
  alias,_=self.alias();other=self.root/'other';other.write_bytes(b'synthetic-other');alias.unlink();alias.symlink_to(other)
  with self.assertRaises(AssertionError):self.check()
 def test_digest_mismatch_rejected(self):
  _,target=self.alias();self.files[str(target)]='0'*64
  with self.assertRaises(AssertionError):self.check()
 def test_canonical_alias_collision_rejected(self):
  _,target=self.alias();alias=self.root/'third-entry';alias.symlink_to(target);self.files[str(alias)]=sha(target)
  with self.assertRaises(AssertionError):self.check()
 def test_canonical_target_required(self):
  _,target=self.alias();del self.files[str(target)]
  with self.assertRaises((AssertionError,KeyError)):self.check()
 def test_all16_loader_metadata_required(self):
  alias,_=self.alias();del self.anchor['runtime_loader_bindings'][str(alias)]
  with self.assertRaises(AssertionError):self.check()
 def test_loader_metadata_digest_mismatch(self):
  alias,_=self.alias();self.anchor['runtime_loader_bindings'][str(alias)]['sha256']='0'*64
  with self.assertRaises(AssertionError):self.check()
 def test_target_bytes_drift_rejected(self):
  _,target=self.alias();target.write_bytes(b'synthetic-drift')
  with self.assertRaises(AssertionError):self.check()

class SourceInvariance(unittest.TestCase):
 def test_driver_only_two_verifier_names_change(self):
  old=(CONTROLS/'collection-native-driver-v12-v1.py').read_text();new=(HERE/'collection-native-driver-v12-v2.py').read_text()
  self.assertEqual(old.count('verify-qualification-v10-deployment-v1.py'),2)
  expected=old.replace('verify-qualification-v10-deployment-v1.py','verify-qualification-v10-deployment-v2.py')
  self.assertEqual(new,expected)
  self.assertEqual(ast.dump(ast.parse(new)),ast.dump(ast.parse(expected)))
 def test_verifier_only_two_identity_statements_change(self):
  old=(CONTROLS/'verify-qualification-v10-deployment-v1.py').read_text();new=(HERE/'verify-qualification-v10-deployment-v2.py').read_text()
  expected=old.replace("assert deployment['libraries'] == libraries, 'root-reviewed complete native library map required'", "assert deployment['libraries'] == libraries, 'root-reviewed complete native library map required'\n    assert anchor['runtime_loader_bindings'] == libraries, 'exact frozen loader path/resolved/hash map required'")
  expected=expected.replace("assert anchor_files[path] == digest, 'unbound actual loader key'", "assert anchor_files[identity['resolved']] == digest, 'unbound actual loader canonical target'")
  self.assertEqual(new,expected)
  def canonical(source):return source[source.index('    canonical = set()'):source.index('    def anchored(')]
  self.assertEqual(canonical(old),canonical(new))
 def test_actual_full_maps_projection_preserves_every_original_source(self):
  lock=read(CONTROLS/'v10-source-lock.json');full=dict(lock['original_actual_files'])
  for name,digest in lock['required_current_files'].items():
   self.assertTrue(name not in full or full[name]==digest);full[name]=digest
  aliases={p:i for p,i in lock['manifest']['libraries'].items() if p!=i['resolved']}
  projected={p:h for p,h in full.items() if p not in aliases}
  for p,h in lock['original_actual_files'].items():self.assertEqual(projected[p],h)
  for p,i in aliases.items():self.assertEqual(full[p],projected[i['resolved']]);self.assertEqual(full[p],i['sha256'])
  self.assertEqual(len(full)-len(projected),10)
 def test_embedded_post_small_json_writers_and_all_sources_parse(self):
  for p in HERE.glob('*.py'):ast.parse(p.read_bytes(),filename=str(p))
  self.assertIn("phase=B/'qualification-v12-fresh-controls-v1/collection-driver-small-v12'",(HERE/'root-replay-small-actual-v12-v1.py').read_text())
  tree=ast.parse((HERE/'root-authorize-remaining-calibration-v12-v1.py').read_bytes())
  closure=next(n.value.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Constant) and any(isinstance(t,ast.Name) and t.id=='closure' for t in n.targets))
  inner=ast.parse(closure)
  writers=[n.args[0].value for n in ast.walk(inner) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='write']
  self.assertEqual(writers,['\n','\n'])
 def test_controller_and_original_math_sources_remain_exact(self):
  accepted=read(BASE/'qualification-v12-root-preparation-v1/root-controls-v12-source-acceptance-v1.json')
  for path,digest in accepted['selected_operational_sources'].items():
   p=CONTROLS/Path(path).name
   self.assertEqual(sha(p),digest,path)
  old=ast.parse((BASE/'qualification-v11-source-orchestration-preparation-v2/root-freeze-qualification-v11-v1.py').read_bytes())
  new=ast.parse((HERE/'root-freeze-qualification-v12-v1.py').read_bytes())
  def literal(tree):
   return next(n.value.value for n in ast.walk(tree) if isinstance(n,ast.keyword) and n.arg=='numerical_policy')
  self.assertEqual(literal(old),literal(new))

if __name__=='__main__':unittest.main(verbosity=2)
