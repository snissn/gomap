"""Execute only the actual root-authorized original serial small stage."""
from pathlib import Path
import hashlib
import json
import os
import time
import types
SOURCE_HERE=Path(__file__).resolve().parent;BASE=SOURCE_HERE.parent;HERE=BASE/'qualification-v12-root-preparation-v1';STATE=BASE/'state.json'
REMOTE='/home/mikers/quicksilver-maintenance-5028-20261006'
ROOT=REMOTE+'/qualification-v12-refresh/qualification-v10'
OUT=BASE/'qualification-v12-refresh/qualification-v10-prospective-root-v1'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return dict(path=REMOTE+'/'+p.relative_to(BASE).as_posix(),sha256=sha(p))
def store(s):
    p=HERE/('state-small-runtime-'+str(time.time_ns())+'.json')
    with p.open('x') as f:json.dump(s,f,indent=2,allow_nan=False);f.write('\n')
    p.replace(STATE)
sp=OUT/'small-calibration-driver-activation.accepted-v2.json';activation=read(sp)
proof=read(OUT/'root-direct-preflight-actual-acceptance-v2.json')
assert proof['accepted_by_root'] and proof['campaign_root']==ROOT
assert activation['phase']=='small' and activation['accepted_by_root'] and activation['collection_authorized'] and not activation['candidate_pair_collection_authorized']
assert activation['driver']==dict(path=REMOTE+'/qualification-v12-fresh-controls-v1/collection-native-driver-v12-v1.py',sha256=sha(BASE/'qualification-v12-fresh-controls-v2/collection-native-driver-v12-v1.py'))
assert activation['root_actual_direct_preflight']==ref(OUT/'root-direct-preflight-actual-acceptance-v2.json')
state=read(STATE);assert isinstance(state['checkpoint_version'],int) and state['native_active'] is None
state['native_active']=dict(phase='fresh-v12-small',owner='/root',local_owner_pid=os.getpid(),started_ns=time.time_ns(),
    label='v12-actual-original-small-calibration-v1',campaign_root=ROOT,
    driver=activation['driver'],activation=ref(sp),qualification=False,candidate_pair_collection_authorized=False)
state['current_execution_status']='Original serial fresh v12 small calibration running; no pair/performance/qualification acceptance'
state['next_action']='Join root-owned small stage, inspect/replay actual raw contents; then authorize remaining original calibration'
store(state)
ip=BASE/'qualification-v9-selected-source-preparation-v1/root_native_io.py'
io=types.ModuleType('root_io');io.__file__=str(ip);exec(compile(ip.read_bytes(),str(ip),'exec'),io.__dict__)
argv=['python3','-B',activation['driver']['path'],'small',ref(sp)['path'],sha(sp)]
try:
    raw=io.native(argv,'v12-actual-original-small-calibration-v1',24000)
    state=read(STATE);state['native_active']=None
    state['current_execution_status']='Fresh original small calibration joined rc0; actual raw replay/content acceptance next'
    state['next_action']='Read complete original small C/guard artifacts and retain actual root raw replay acceptance before remaining calibration'
    store(state);print(raw.decode(),end='')
except BaseException as error:
    state=read(STATE);state['native_active']=None
    state['current_execution_status']='Fresh small stage failed; retained actual native record requires diagnosis before retry'
    state['next_action']='Read retained v12-actual-original-small-calibration-v1 raw error/outcome and diagnose actual affected gate'
    state['last_native_failure']=dict(label='v12-actual-original-small-calibration-v1',error=repr(error),finished_ns=time.time_ns())
    store(state);raise
