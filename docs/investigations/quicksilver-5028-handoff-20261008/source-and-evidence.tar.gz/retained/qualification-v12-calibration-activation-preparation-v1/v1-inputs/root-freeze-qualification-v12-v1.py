"""Root's prospective rule/source freeze, with actual native byte readback.

Does not collect any calibration or paired measurement, or open a database.
Every output is exclusive; acceptance follows the native closure readback.
"""
import hashlib
import json
from pathlib import Path
import time
import types

SOURCE_HERE = Path(__file__).resolve().parent
BASE = SOURCE_HERE.parent
HERE = BASE/'qualification-v12-root-preparation-v1'
CONTROLS = BASE/'qualification-v12-fresh-controls-v2'
REMOTE = '/home/mikers/quicksilver-maintenance-5028-20261006'
ROOT = REMOTE + '/qualification-v12-refresh/qualification-v10'
OUT = BASE / 'qualification-v12-refresh/qualification-v10-prospective-root-v1'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def ref(path):
    path = Path(path)
    name=path.relative_to(BASE).as_posix()
    if path.is_relative_to(CONTROLS):name='qualification-v12-fresh-controls-v1/'+path.relative_to(CONTROLS).as_posix()
    return dict(path=REMOTE+'/'+name, sha256=sha(path))


def save(path, data):
    with Path(path).open('x') as f:
        json.dump(data, f, indent=2, allow_nan=False)
        f.write('\n')


def local(refpath):
    p=Path(refpath)
    nc=Path(REMOTE)/'qualification-v12-fresh-controls-v1'
    if p.is_relative_to(nc) and p.suffix=='.py':p=CONTROLS/p.relative_to(nc)
    elif p.is_relative_to(nc) and p.name in ('v10-source-lock.json','deployment-helpers-selection.json','construction-observation.json'):p=CONTROLS/p.relative_to(nc)
    elif p.is_relative_to(REMOTE):p=BASE/p.relative_to(REMOTE)
    assert p.is_relative_to(BASE), 'source reference outside selected local/provenance root'
    return p

def bound_source(ref):
    assert set(ref)=={'path','sha256'}
    p=local(ref['path'])
    assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and sha(p)==ref['sha256']
    return p

def manifest_paths(ref):
    manifest=bound_source(ref);m=read(manifest);paths=[]
    for group in ('inputs','outputs'):
        rows=m[group]
        if isinstance(rows,dict):
            normalized=[]
            for key,value in rows.items():
                path=Path(value.get('path',key) if isinstance(value,dict) else key)
                if not path.is_absolute():path=manifest.parent/path
                row=dict(path=str(path),sha256=value['sha256'] if isinstance(value,dict) else value)
                normalized.append(row)
            rows=normalized
        for row in rows:paths.append(bound_source(dict(path=row['path'],sha256=row['sha256'])))
    return paths

def acceptance(p):
    a=read(p)
    assert a['accepted_by_root'] is True and a['source_only'] is True
    assert a['qualification'] is False and a['collection_authorized'] is False and a['performance_accepted'] is False
    assert a['blocking_findings']==[]
    return a

def main():
    assert __debug__ and __import__('sys').pycache_prefix is None
    io_path = BASE/'qualification-v9-selected-source-preparation-v1/root_native_io.py'
    io = types.ModuleType('root_native_io'); io.__file__ = str(io_path)
    exec(compile(io_path.read_bytes(), str(io_path), 'exec'), io.__dict__)
    inp_path = BASE/'qualification-v12-refresh/qualification-v10-source-freeze-root-input-v1.json'
    inp = read(inp_path)
    binding_path = BASE/'qualification-v12-refresh/qualification-v10/prospective-v10-root-v1/pre-c1-binding.json'
    binding = read(binding_path)
    dep_path = OUT/'deployment.accepted.json'
    dep = read(dep_path)
    lock_path = CONTROLS/'v10-source-lock.json'
    assert sha(lock_path) == inp['v10_source_lock']['sha256']
    manifest = read(lock_path)['manifest']
    selection = inp['prospective_source_selection']
    assert inp['source_frozen_ns'] <= time.time_ns()
    assert binding['root_input_sha256'] == sha(inp_path)
    assert dep['campaign_root'] == binding['campaign_root'] == ROOT
    assert inp['campaign_id']=='quicksilver-maintenance-5028-qv12-192e501-6fa638b-73100c5' and inp['campaign_root']==ROOT
    consumer_acceptance=acceptance(BASE/'qualification-v11-root-preparation-v1/root-consumer-v5-source-acceptance-v1.json')
    controls_acceptance=read(HERE/'root-controls-v12-source-acceptance-v1.json')
    assert controls_acceptance['accepted_by_root'] and controls_acceptance['source_only']
    assert not any(controls_acceptance[k] for k in ('qualification','collection_authorized','performance_accepted'))
    frontier_path=HERE/'pre-c1-closure-frontier.accepted-v1.json'
    frontier=read(frontier_path)
    assert frontier['schema']==1 and frontier['accepted_by_root'] is True and frontier['source_only'] is True
    assert frontier['qualification'] is False and frontier['collection_authorized'] is False and frontier['performance_accepted'] is False
    assert frontier['campaign_root']==ROOT and frontier['held_excluded']==[5004,5006]
    for path in list(frontier['actual_native_files'])+[entry['path'] for entry in frontier['refs']]:
        p=Path(path)
        if p.is_relative_to(BASE):p=Path(REMOTE)/p.relative_to(BASE)
        assert p.is_absolute() and not p.is_relative_to(Path(REMOTE)/'qualification-v10'), 'old v10 campaign evidence excluded from fresh frontier'
    assert selection['consumer']['sha256']=='ccc5b23ed271b2bd814fc2678a7e4d99e72f0f381b4a39d37132ae570cdee97d'
    rule = dict(schema=1, accepted_by_root=True, qualification=False,
                collection_authorized=False, performance_accepted=False,
                campaign_id=inp['campaign_id'], campaign_root=ROOT, held_excluded=[5004,5006],
                no_historical_v8_v9_observations=True,
                consumer_sha256=selection['consumer']['sha256'],
                preservation_mechanism_sha256=selection['consumer']['sha256'],
                policy_sha256=selection['policy']['sha256'],
                witness_sha256=selection['witness']['sha256'],
                evaluator_sha256='9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd',
                original_definition_sha256='4005f6369837ecb7000d3a89b86aeac361b3c9d07ccc323450b60bfa4fbd6219',
                R_definition_sha256=sha(BASE/'qualification-v12-refresh/qualification-v10/prospective-v10-root-v1/r-definition.accepted.json'),
                common_inventory=inp['common_inventory'],
                pre_c1_bindings=dict(source_freeze=ref(inp_path), deployment=ref(dep_path),
                                     applicability=inp['reuse_applicability']),
                global_replay_helper=selection['global_replay_helper'],
                source_selection=selection, frozen_ns=time.time_ns(),
                numerical_policy='Original E=(maxC-minC)/medianC, material all3 and median>2E, regression >=2adverse<-2E; UNKNOWN nonpassing. Supplemental strict latency proof applies only its prospectively frozen equality/theorem scope; no noise floor, equality waiver, alternate target or changed original evaluator.',
                preservation_before_any_pair_required=True,
                note='Genuine root source/mechanism/rule decision before fresh C1. No future GLOBAL/final pair hashes or qualification/performance acceptance. Original unchanged full evaluation must run first; every final/full Inventory, original math, correctness and CI gate remains mandatory.')
    rule_path = OUT/'prospective-rule-freeze.accepted-v1.json'
    save(rule_path, rule)
    rule_stage_sources = {rule_path.relative_to(BASE).as_posix():rule_path,
                          Path(__file__).relative_to(BASE).as_posix():Path(__file__)}
    rule_stage_expected = {name:sha(path) for name,path in rule_stage_sources.items()}
    rule_stage_name = rule_path.relative_to(BASE).as_posix()
    rule_stage_probe = "from pathlib import Path\nimport hashlib,json,os\nroot=Path("+repr(REMOTE)+")\nexpected="+repr(rule_stage_expected)+"\nrule_name="+repr(rule_stage_name)+"\nmissing=[]\nfor name,h in expected.items():\n p=root/name\n if name==rule_name:assert not os.path.lexists(p), 'prospective rule already exists'\n if not os.path.lexists(p):missing.append(name);continue\n assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and hashlib.sha256(p.read_bytes()).hexdigest()==h, 'conflicting freezer source'\n assert not (p.parent/'__pycache__').exists()\nprint(json.dumps(missing))"
    rule_stage_missing = json.loads(io.native(['python3','-B','-c',rule_stage_probe], 'v12-prospective-rule-source-prestage-readback-v2',120))
    io.put({name:path for name,path in rule_stage_sources.items() if name in rule_stage_missing}, 'v12-prospective-rule-source-freeze-stage-v1')
    files = dict(binding['files'])
    def add(path, digest):
        assert path not in files or files[path] == digest, 'conflicting anchor digest '+path
        files[path] = digest
    fixtures = BASE/'qualification-v9-prospective-root-v1/root-fresh-fixtures-acceptance-v1.json'
    for path,digest in read(fixtures)['actual_file_hashes'].items(): add(path,digest)
    for path,identity in manifest['libraries'].items(): add(path,identity['sha256'])
    for source in manifest['sources'].values(): add(ROOT+'/bin/'+source['binary'],source['binary_sha256'])
    for path,digest in frontier['actual_native_files'].items():
        assert Path(path).is_absolute();add(path,digest)
    pins_path=BASE/'qualification-v10-global-deployment-preparation-v2/immutable-pins.json'
    assert sha(pins_path)=='2fccfac7a950aad6f397e15d94d5cc7b45d4b45ec5943d567c1a19e26cc4d406'
    pins=read(pins_path);assert len(pins)==24
    for name,digest in pins.items():assert sha(BASE/name)==digest;add(REMOTE+'/'+name,digest)
    for entry in dep['helpers'].values(): add(entry['path'],entry['sha256'])
    for entry in selection.values(): add(entry['path'],entry['sha256'])
    local_extra = [binding_path,dep_path,rule_path,fixtures,Path(__file__),SOURCE_HERE/'root-assemble-pre-c1-frontier-v12-v1.py',
                   pins_path,HERE/'source-context-request.accepted-v12-v1.json',HERE/'actual-root-source-context-preparation-result-v12-v1.json',
                   HERE/'actual-source-context-and-binding-readback-v12-v1.json',
                   BASE/'qualification-v11-root-preparation-v1/root-consumer-v5-source-acceptance-v1.json',
                   HERE/'root-controls-v12-source-acceptance-v1.json',HERE/'current-host-readback.accepted-v12-v1.json',frontier_path,
                   HERE/'common-H-actual-landed-acceptance-v12-v1.json',lock_path,
                   CONTROLS/'construction-observation.json',CONTROLS/'deployment-helpers-selection.json']
    context=read(HERE/'actual-root-source-context-preparation-result-v12-v1.json')
    for k in ('result','deployment','reuse_applicability','inventory','root_input'):local_extra.append(bound_source(context[k]))
    host=read(HERE/'current-host-readback.accepted-v12-v1.json');local_extra.append(bound_source(host['runner_receipt']))
    for k in ('author_manifest','independent_review','independent_review_manifest'):local_extra.append(bound_source(consumer_acceptance[k]))
    local_extra += manifest_paths(consumer_acceptance['author_manifest'])+manifest_paths(consumer_acceptance['independent_review_manifest'])
    local_extra.append(bound_source(consumer_acceptance['actual_native_finite_diagnostics']))
    for k in ('constructor','construction_observation','independent_finite_fix_review'):local_extra.append(bound_source(controls_acceptance[k]))
    local_extra += [bound_source(dict(path=p,sha256=h)) for p,h in controls_acceptance['selected_operational_sources'].items()]
    local_extra += [bound_source(entry) for entry in frontier['refs']]
    local_extra.append(bound_source(dep['original_19_manifest']))
    support_manifest=BASE/'r-material-gate-preparation-v2/immutable-inputs.json'
    assert sha(support_manifest)==dep['preserved_support_manifest_sha256'];local_extra.append(support_manifest)
    local_extra=list(dict.fromkeys(local_extra))
    for path in local_extra:
        entry=ref(path);add(entry['path'],entry['sha256'])
    expected={ref(p)['path']:sha(p) for p in local_extra}
    prestage="from pathlib import Path\nimport hashlib,json,os\nexpected="+repr(expected)+"\nmissing=[]\nfor path,h in expected.items():\n p=Path(path)\n if not os.path.lexists(p):missing.append(path);continue\n assert p.is_file() and not p.is_symlink() and p.resolve()==p and hashlib.sha256(p.read_bytes()).hexdigest()==h\nprint(json.dumps(missing))"
    missing=json.loads(io.native(['python3','-B','-c',prestage], 'v12-additional-source-evidence-prestage-readback-v1',120))
    if missing:
        io.put({Path(ref(p)['path']).relative_to(REMOTE).as_posix():p for p in local_extra if ref(p)['path'] in missing}, 'v12-additional-source-evidence-stage-v1')
    h=read(HERE/'common-H-actual-landed-acceptance-v12-v1.json')
    anchor = dict(schema=1, accepted_by_root=False, qualification=False,
                  collection_authorized=False, candidate_pair_collection_authorized=False,
                  root=ROOT,campaign_id=inp['campaign_id'], definition=REMOTE+'/qualification-prep/revised-draft/protocol-definition-root-frozen.json',
                  evaluator=REMOTE+'/qualification-prep/evaluator.py', driver=REMOTE+'/qualification-analysis-controller.py',
                  accounting_policy=binding['accounting_policy'],accounting_freeze=binding['accounting_freeze'],
                  accounting_checker=binding['accounting_checker'],controls=manifest['build_env'],
                  harness_files=h['harness_files'], executed_controllers=dep['executed_controllers'],
                  deployment_binding=ref(dep_path), v10_root_input=binding['root_input'],
                  v10_root_input_sha256=binding['root_input_sha256'],
                  landed_harness_attested=True,receipt_contents_accepted=True,
                  host_clock_and_serialization_accepted=True,common_prerequisite_landed=True,
                  native_correctness_receipt=inp['native_correctness_receipt'],
                  global_calibration_gate=ROOT+'/global-calibration-freeze.json',
                  pre_pair_global54_root_guard_required=True,held_excluded=[5004,5006],
                  accepted_fixtures=ref(fixtures), fixture_source_applicability=inp['reuse_applicability'],
                  historical_calibration_or_pair_results_reused=False,
                  prospective_rule_freeze=ref(rule_path),source_frozen_ns=inp['source_frozen_ns'],
                  created_ns=time.time_ns(), files=files)
    draft = OUT/'pre-c1-anchor.draft-v1.json'; save(draft,anchor)
    # Verify every actual native file, canonical uniqueness and Python cache absence.
    probe="from pathlib import Path\nimport hashlib,json,time\nfiles="+repr(files)+"\nactual={}\ncanonical=set()\nfor path,h in files.items():\n p=Path(path);r=p.resolve(strict=True)\n assert p.is_file() and r not in canonical, 'anchor missing/alias '+path\n canonical.add(r)\n data=p.read_bytes();actual[path]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),resolved=str(r))\n assert actual[path]['sha256']==h, 'actual drift '+path\n if path.endswith('.py'):assert not (r.parent/'__pycache__').exists(), 'unbound source cache '+path\nroot=Path("+repr(ROOT)+")\nnamespace={}\nfor d in [root,root/'plans',root/'receipts']:\n assert d.is_dir() and not d.is_symlink() and d.resolve()==d\n namespace[str(d)]=sorted(p.name for p in d.iterdir())\n for p in d.iterdir():\n  n=p.name\n  if d.name=='receipts':\n   for prefix in ['ar-orchestration-','orchestration-']:\n    if n.startswith(prefix):n=n[len(prefix):];break\n  assert not n.startswith(('cal-','guard-','pairs-','ar-','online-')), 'pre-C1 producer '+str(p)\nprint(json.dumps(dict(schema=1,actual_files=actual,namespace=namespace,read_ns=time.time_ns(),qualification=False,collection_authorized=False)))"
    actual=json.loads(io.native(['python3','-B','-c',probe], 'v12-actual-full-pre-C1-source-anchor-readback-v1', 240))
    proof = OUT/'actual-full-pre-c1-source-anchor-readback-v2.json';save(proof,actual)
    assert set(actual['actual_files']) == set(files)
    anchor.update(accepted_by_root=True, actual_contents_accepted_ns=time.time_ns(),
                  actual_file_count=len(files), actual_native_readback=ref(proof),
                  note='Root accepted exact complete actual native byte closure after readback, including original controls/native correctness/closed fixtures and newly reviewed common H/source lifecycle. Fresh calibration and later GLOBAL54/physical preservation/pair contents still require separate actual decisions.')
    accepted=OUT/'pre-c1-anchor.accepted-v2.json';save(accepted,anchor)
    io.put({p.relative_to(BASE).as_posix():p for p in [proof,accepted]}, 'v12-actual-full-pre-C1-source-anchor-acceptance-stage-v1')
    print(json.dumps(dict(status='ACTUAL_PRE_C1_SOURCE_AND_RULE_FROZEN',anchor=ref(accepted),
                         rule=ref(rule_path),actual_files=len(files),qualification=False,
                         collection_authorized=False)),flush=True)


if __name__=='__main__':main()
