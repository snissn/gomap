"""Join actual V12 source evidence and exact immutable verifier imports before C1.

Source only. No collector, DB, correctness, build, or native command is run.
"""
from pathlib import Path
import ast,hashlib,json,time
SOURCE_HERE=Path(__file__).resolve().parent
BASE=SOURCE_HERE.parent
HERE=BASE/'qualification-v12-root-preparation-v1'
CONTROLS=BASE/'qualification-v12-fresh-controls-v2'
NROOT=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
NC=NROOT/'qualification-v12-fresh-controls-v1'
ROOT=NROOT/'qualification-v12-refresh/qualification-v10'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def local(p):
 p=Path(p)
 if p.is_relative_to(NC) and p.suffix=='.py':p=CONTROLS/p.relative_to(NC)
 elif p.is_relative_to(NROOT):p=BASE/p.relative_to(NROOT)
 return p
refs={}
def include(p,digest=None):
 p=local(p);assert p.is_relative_to(BASE) and p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p
 h=sha(p);assert digest is None or h==digest
 n=str(NC/p.relative_to(CONTROLS)) if p.is_relative_to(CONTROLS) else str(NROOT/p.relative_to(BASE))
 assert n not in refs or refs[n]==h;refs[n]=h
adoption=read(HERE/'root-orchestration-v12-source-acceptance-v1.json')
assert adoption['accepted_by_root'] and adoption['source_only'] and adoption['blocking_findings']==[]
assert not any(adoption[k] for k in ('qualification','collection_authorized','performance_accepted'))
for row in adoption['actual_local_bindings']:include(row['path'],row['sha256'])
for name in ['root-orchestration-v12-source-acceptance-v1.json','root-controls-v12-source-acceptance-v1.json',
 'current-host-readback.accepted-v12-v1.json','actual-native-source-reuse-readback-v12-v1.json',
 'actual-root-source-context-preparation-result-v12-v1.json','actual-pre-C1-binding-result-v12-v1.json',
 'actual-source-context-and-binding-readback-v12-v1.json','source-context-request.accepted-v12-v1.json',
 'common-H-actual-landed-acceptance-v12-v1.json','root-actual-correctness-content-acceptance-v12-v1.json',
 'root-actual-inventory-content-acceptance-v12-v1.json','root-prepare-actual-source-context-v12-v1.py']:
 include(HERE/name)
include(Path(__file__))
lock=read(HERE/'actual-fresh-source-lock-v12.json');include(HERE/'actual-fresh-source-lock-v12.json')
packet=read(HERE/'actual-native-source-reuse-readback-v12-v1.json')
assert packet['campaign_root']==str(ROOT) and packet['original_actual_files']==lock['original_actual_files']
assert packet['actual_files']==lock['required_current_files'] and packet['database_opens']==0
assert not lock['historical_runtime_results_reused']
files={}
def add(p,h):
 assert Path(p).is_absolute()
 assert p not in files or files[p]==h;files[p]=h
for table in (lock['original_actual_files'],lock['required_current_files']):
 for p,h in table.items():add(p,h)
for p,row in packet['copies'].items():add(p,row['sha256'])
for row in lock['tracked_manifests'].values():add(row['path'],row['sha256'])
h=read(HERE/'common-H-actual-landed-acceptance-v12-v1.json')
for role,p in h['harness_files'].items():add(p,h['runtime_harness'][role]['sha256'])
controls=read(HERE/'root-controls-v12-source-acceptance-v1.json')
for p,h in controls['selected_operational_sources'].items():include(p,h)
for k in ('constructor','construction_observation','independent_finite_fix_review'):
 r=controls[k];include(r['path'],r['sha256'])
for p in (CONTROLS/'v10-source-lock.json',CONTROLS/'deployment-helpers-selection.json'):include(p)
context=read(HERE/'actual-root-source-context-preparation-result-v12-v1.json')
for k in ('result','deployment','reuse_applicability','inventory','root_input'):
 r=context[k];include(r['path'],r['sha256'])
# Closure required by exact selected verifier; no hard-coded historical import count.
verifier=CONTROLS/'verify-qualification-v10-deployment-v1.py';include(verifier)
needed={}
for node in ast.parse(verifier.read_bytes()).body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('ORIGINALS','R_SUPPORT_ORIGINALS') for t in node.targets):
  for p,h in ast.literal_eval(node.value).items():
   n=str(NROOT/p);assert n not in needed or needed[n]==h;needed[n]=h
assert needed
for p,h in needed.items():add(p,h)
binding=read(BASE/'qualification-v12-refresh/qualification-v10/prospective-v10-root-v1/pre-c1-binding.json')
assert binding['campaign_root']==str(ROOT) and binding['accepted_by_root'] and not binding['collection_authorized']
for p,h in binding['files'].items():add(p,h)
for p,h in refs.items():add(p,h)
value=dict(schema=1,accepted_by_root=True,source_only=True,qualification=False,collection_authorized=False,
 performance_accepted=False,campaign_root=str(ROOT),held_excluded=[5004,5006],created_ns=time.time_ns(),
 refs=[dict(path=p,sha256=h) for p,h in sorted(refs.items())],actual_native_files=files,
 factual_provenance=dict(original_evidence_files=len(lock['original_actual_files']),current_files=len(lock['required_current_files']),
 fresh_runtime_receipt_copies=len(packet['copies']),tracked_export_manifests=len(lock['tracked_manifests']),
 complete_unchanged_deployment_import_set=needed),
 note='Source-only join of actual current bindings. Historical fixture provenance remains separate and is not scientific calibration. Full native byte/cache/producer-empty readback and direct verifier remain mandatory before C1.')
p=HERE/'pre-c1-closure-frontier.accepted-v1.json'
with p.open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps(dict(status='ACTUAL_EVIDENCE_FRONTIER_JOINED_SOURCE_ONLY',frontier=dict(path=str(NROOT/p.relative_to(BASE)),sha256=sha(p)),refs=len(refs),native_files=len(files),qualification=False,collection_authorized=False)))
