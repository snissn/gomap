"""Root-owned read-only raw replay; no collector/DB/Go work."""
from pathlib import Path
import hashlib,json,os,sys,time,types
sys.dont_write_bytecode=True
B=Path('/home/mikers/quicksilver-maintenance-5028-20261006');Q=B/'qualification-v12-refresh/qualification-v10'
P=B/'qualification-v12-root-preparation-v1/small-actual-content-replay-v12-v1'
def sh(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def save(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
oldp=B/'qualification-v12-refresh/qualification-v10-prospective-root-v1/pre-c1-anchor.accepted-v2.json'
activation=read(B/'qualification-v12-refresh/qualification-v10-prospective-root-v1/calibration-activation.accepted-v2.json')
assert activation['anchor']==str(oldp) and activation['anchor_sha256']==sh(oldp)
a=read(oldp);assert a['root']==str(Q) and a['accepted_by_root'];files=dict(a['files']);canonical={}
for name,h in files.items():
 p=Path(name);r=p.resolve(strict=True);assert r not in canonical and sh(p)==h,name;canonical[r]=name
 if name.endswith('.py'):assert not (p.parent/'__pycache__').exists()
phase=B/'qualification-v12-fresh-controls-v2/collection-driver-small-v12'
assert read(phase/'complete.json')['rc']==0
for folder in phase.iterdir():
 if folder.is_dir():
  row=read(folder/'complete.json');assert row['rc']==0 and row['raw_hashes_final'] is True and not row.get('timeout')
  for n in ('stdout','stderr'):assert sh(folder/(n+'.txt'))==row[n+'_sha256']
  try:os.kill(row['pid'],0);raise AssertionError('live child')
  except ProcessLookupError:pass
expected=[]
for mode in ('full','exhaustive'):
 for i in (1,2,3):
  expected.append(('offline',Q/f'cal-primary-s24-n30000-{mode}-b8192'/f'C{i}'/'run.json'))
  expected.append(('guard',Q/f'guard-primary-s24-n30000-{mode}-b8192-C{i}'/f'1-C{i}'/'run.json'))
for kind,p in expected:assert p.is_file(),str(p)
def add(p):
 p=Path(p);r=p.resolve(strict=True);h=sh(p)
 if r in canonical:assert files[canonical[r]]==h;return
 assert p.is_file() and not p.is_symlink() and r==p
 canonical[r]=str(p);files[str(p)]=h
for kind,p in expected:
 for folder in (p.parent,p.parent.parent):
  for raw in folder.iterdir():
   if raw.is_file():add(raw)
for folder in phase.iterdir():
 for raw in (folder.iterdir() if folder.is_dir() else [folder]):
  if raw.is_file():add(raw)
add(oldp);add(Path(__file__))
a.update(files=files,qualification=False,collection_authorized=False,candidate_pair_collection_authorized=False,
 diagnostic_raw_inventory=True,raw_validation_pending=True,
 note='Preserved original_source_bindings source bindings plus actual small raw transitive closure. Root read-only diagnostic replay, not calibration/noise/global/performance acceptance.')
P.mkdir(exist_ok=False);ap=P/'small-actual-inventory.json';save(ap,a)
evpath=Path(a['evaluator']);assert sh(evpath)=='9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd'
ev=types.ModuleType('small_original_evaluator');ev.__file__=str(evpath);exec(compile(evpath.read_bytes(),str(evpath),'exec'),ev.__dict__)
inv=ev.Inventory(ap,sh(ap));collector,maintenance=ev.load_collectors(inv)
rows=[];common=None;intervals=[]
for kind,p in expected:
 if kind=='offline':
  value=ev.load_original(inv,collector,maintenance,str(p),'offline');run=value['run'];report=value['report']
  row={'kind':kind,'path':str(p),'validated':run['validated'],'started_ns':value['started_ns'],'finished_ns':value['finished_ns'],
   'elapsed_seconds':run['elapsed_seconds'],'peak_rss_bytes':run['memory']['peak_rss_bytes'],'policy_complete':maintenance.policy_complete(report),'endpoint':report['endpoint']}
 else:
  value=ev.load_run(inv,collector,str(p));run=value['run'];report=value['report']
  row={'kind':kind,'path':str(p),'validated':run['validated'],'started_ns':int(run['started']*1e9),'finished_ns':int(run['finished']*1e9),
   'phase_names':[x['name'] for x in report['phases']],'miss_ratio_validation':run.get('miss_ratio_validation')}
 ci=ev.common_inventory(inv,str(p),run);assert common is None or ci==common;common=ci
 rows.append(row);intervals.append((row['started_ns'],row['finished_ns']))
intervals.sort();assert all(x[1]<=y[0] for x,y in zip(intervals,intervals[1:]))
freeze=read(B/'qualification-v12-refresh/qualification-v10-prospective-root-v1/prospective-rule-freeze.accepted-v1.json')
assert freeze['frozen_ns']<intervals[0][0]
result={'schema':1,'status':'SMALL_ALL12_ORIGINAL_RAW_REPLAY_PASS','original_source_bindings_retained':all(files[k]==v for k,v in read(oldp)['files'].items()),
 'actual_inventory_files':len(files),'inventory':{'path':str(ap),'sha256':sh(ap)},'rows':rows,'common_inventory':common,
 'all12_serial_nonoverlap':True,'source_and_rule_precede_first_C':True,'first_C_ns':intervals[0][0],'rule_frozen_ns':freeze['frozen_ns'],
 'all6_maintenance_all6_service_guards':True,'qualification':False,'performance_accepted':False,'collection_authorized':False,
 'held_excluded':[5004,5006],'read_ns':time.time_ns()}
save(P/'result.json',result);print(json.dumps(result,allow_nan=False))
