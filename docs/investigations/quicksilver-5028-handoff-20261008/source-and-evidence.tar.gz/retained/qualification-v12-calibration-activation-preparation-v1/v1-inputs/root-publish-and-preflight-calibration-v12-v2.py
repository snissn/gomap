"""Publish the actual fresh source freeze, then original direct preflight."""
from pathlib import Path
import hashlib
import json
import subprocess
import time
import types

SOURCE_HERE=Path(__file__).resolve().parent
BASE=SOURCE_HERE.parent
HERE=BASE/'qualification-v12-root-preparation-v1'
REMOTE='/home/mikers/quicksilver-maintenance-5028-20261006'
ROOT=REMOTE+'/qualification-v12-refresh/qualification-v10'
OUT=BASE/'qualification-v12-refresh/qualification-v10-prospective-root-v1'
CONTROLS=BASE/'qualification-v12-fresh-controls-v2'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_bytes())
def ref(p):
    p=Path(p);name=p.relative_to(BASE).as_posix()
    if p.is_relative_to(CONTROLS):name='qualification-v12-fresh-controls-v1/'+p.relative_to(CONTROLS).as_posix()
    return dict(path=REMOTE+'/'+name,sha256=sha(p))
def save(p,data):
    with p.open('x') as f: json.dump(data,f,indent=2,allow_nan=False);f.write('\n')
def api(args,label):
    r=subprocess.run(['gh','api']+args,capture_output=True,timeout=40)
    with (OUT/(label+'-raw.json')).open('xb') as f:f.write(r.stdout)
    with (OUT/(label+'-stderr.txt')).open('xb') as f:f.write(r.stderr)
    assert r.returncode==0,(label,r.stderr.decode(errors='replace'))
    return json.loads(r.stdout)

ap=OUT/'pre-c1-anchor.accepted-v2.json';rp=OUT/'prospective-rule-freeze.accepted-v1.json'
dp=OUT/'deployment.accepted.json'
bp=BASE/'qualification-v12-refresh/qualification-v10/prospective-v10-root-v1/pre-c1-binding.json'
a,r,d,b=map(read,(ap,rp,dp,bp))
assert a['accepted_by_root'] and a['root']==ROOT and a['actual_file_count']==len(a['files'])
assert a['prospective_rule_freeze']==ref(rp) and a['deployment_binding']==ref(dp)
assert b['campaign_root']==d['campaign_root']==r['campaign_root']==ROOT
assert not any(a[k] for k in ('qualification','collection_authorized','candidate_pair_collection_authorized'))
actual=read(OUT/'actual-full-pre-c1-source-anchor-readback-v2.json')
assert {p:x['sha256'] for p,x in actual['actual_files'].items()}==a['files']
assert a['source_frozen_ns']<=r['frozen_ns']<=actual['read_ns']<=a['actual_contents_accepted_ns']
assert r['consumer_sha256']=='ccc5b23ed271b2bd814fc2678a7e4d99e72f0f381b4a39d37132ae570cdee97d'
for p in (CONTROLS/'collection-native-driver-v12-v1.py',CONTROLS/'deployment-helpers-selection.json',CONTROLS/'verify-qualification-v10-deployment-v1.py'):
    assert a['files'][ref(p)['path']]==sha(p)
body=(
    '### Exact fresh V12 source freeze before C1\n\n'
    'Campaign `'+ROOT+'`. Actual canonical native source readback binds '+str(len(a['files']))+' files. '
    'Anchor SHA `'+sha(ap)+'`, rule SHA `'+sha(rp)+'`, root input SHA `'+b['root_input_sha256']+'`, '
    'binding SHA `'+sha(bp)+'`, deployment SHA `'+sha(dp)+'`. '
    'Source frozen_ns='+str(a['source_frozen_ns'])+', rule frozen_ns='+str(r['frozen_ns'])+', read_ns='+str(actual['read_ns'])+'. '
    'Source-only orchestration acceptance SHA `'+sha(HERE/'root-orchestration-v12-source-acceptance-v1.json')+'`. '
    'A192e5019e579af3b98ae4fbf4ea497bb9ccd672f / R6fa638b8bffa71750e1aefa0bb746bb747aa06c1 / B73100c5b8cc2337d9cff36c60a8e4182f1820fe9. '
    'Original Go1.26.3/GOMAXPROCS12/GOGC100/GOMEMLIMIT off, workers4, sealed1GiB mapping, ordinary durable Commit ACK, default compression/CRC remain exact. '
    'No historical measurement is reused. Compatibility restored-copy checks are source compatibility only. '
    'All original39C/39guards, B36/R18/GLOBAL54,114 ordered pairs/guards, full R support closure, full-value/miss/reopen/physical preservation, '
    'material3M speed AND actual process memory, default useful progress/conditional4M, service/storage/allocation and original-final-FIRST are mandatory. '
    'Original E=(maxC-minC)/medianC, all3 and median>2E, >=2adverse<-2E, UNKNOWN nonpassing remain unchanged; '
    'strict supplemental witness applies only its frozen equality/theorem scope, without noise floors/equality waiver. '
    'Only original30k small calibration may launch after exact direct binder and verifier pass. '
    'No pair/performance/qualification/merge acceptance. Current-head review/CI, ordered merges and actual landed-source #5030 matched qualification remain required. Held #5004/PR5006 excluded.')
req=OUT/'external-pre-c1-freeze-v2-request.json';save(req,dict(body=body))
response=api(['repos/snissn/gomap/issues/5030/comments','--method','POST','--input',str(req)],'external-pre-c1-freeze-v2-response')
external=api(['repos/snissn/gomap/issues/comments/'+str(response['id'])],'external-pre-c1-freeze-v2-readback')
assert external['body']==body and external['html_url']==response['html_url']
cal=dict(schema=1,accepted_by_root=True,collection_authorized=True,qualification=False,performance_accepted=False,
         campaign_id=b['campaign_id'],campaign_root=ROOT,held_excluded=[5004,5006],
         allowed_stages=['fixtures','offline-calibration','online-calibration'],candidate_pair_collection_authorized=False,
         github_external_anchor_url=external['html_url'],anchor=ref(ap)['path'],anchor_sha256=sha(ap),
         prospective_binding=ref(bp),prospective_binding_sha256=sha(bp),deployment_binding=ref(dp),
         deployment_verifier=ref(CONTROLS/'verify-qualification-v10-deployment-v1.py'),
         prospective_rule_freeze=ref(rp),authorized_ns=time.time_ns(),
         root_launch_scope_now=['offline-calibration:primary-s24-n30000'],
         note='Genuine fresh external before-C1 freeze. Direct preflight must pass before small driver activation. Only original calibration is authorized; all outcome/qualification/merge gates unchanged and pair authority false.')
cp=OUT/'calibration-activation.accepted-v2.json';save(cp,cal)
ip=BASE/'qualification-v9-selected-source-preparation-v1/root_native_io.py'
io=types.ModuleType('root_io');io.__file__=str(ip);exec(compile(ip.read_bytes(),str(ip),'exec'),io.__dict__)
io.put({cp.relative_to(BASE).as_posix():cp},'v12-calibration-only-activation-exclusive-stage-v2')
binder=d['helpers']['binder']
br=json.loads(io.native(['python3','-B',binder['path'],'check',ref(bp)['path'],sha(bp),ref(cp)['path'],sha(cp)],'v12-direct-original-binder-preflight-v2',360))
assert br['status']=='PRE_C1_BINDINGS_PRESENT_ROOT_AUTHORIZED_CALIBRATION_ONLY' and br['qualification'] is False and br['native_commands_launched']==0
v=cal['deployment_verifier']
vr=json.loads(io.native(['python3','-B',v['path'],ref(dp)['path'],sha(dp),ref(bp)['path'],sha(bp),ref(cp)['path'],sha(cp)],'v12-direct-supplemental-deployment-preflight-v2',360))
assert vr['status']=='SUPPLEMENTAL_DEPLOYMENT_IDENTITIES_VERIFIED_NO_LAUNCH' and vr['qualification'] is False and vr['collection_launched'] is False
proof=dict(schema=1,accepted_by_root=True,source_only=True,qualification=False,collection_authorized=False,
           performance_accepted=False,campaign_root=ROOT,actual_binder_result=br,actual_deployment_result=vr,
           actual_native_records=[ref(io.HERE/(n+'-run.json')) for n in ('v12-direct-original-binder-preflight-v2','v12-direct-supplemental-deployment-preflight-v2')],
           accepted_ns=time.time_ns(),held_excluded=[5004,5006])
pp=OUT/'root-direct-preflight-actual-acceptance-v2.json';save(pp,proof)
driver=dict(schema=1,accepted_by_root=True,collection_authorized=True,qualification=False,performance_accepted=False,
            phase='small',campaign_id=b['campaign_id'],campaign_root=ROOT,held_excluded=[5004,5006],
            driver=ref(CONTROLS/'collection-native-driver-v12-v1.py'),helper_selection_sha256=sha(CONTROLS/'deployment-helpers-selection.json'),
            deployment=ref(dp),calibration_activation=ref(cp),root_launch_scope_now=cal['root_launch_scope_now'],
            candidate_pair_collection_authorized=False,authorized_ns=time.time_ns(),root_actual_direct_preflight=ref(pp))
sp=OUT/'small-calibration-driver-activation.accepted-v2.json';save(sp,driver)
io.put({p.relative_to(BASE).as_posix():p for p in (pp,sp)},'v12-direct-preflight-and-small-activation-exclusive-stage-v2')
print(json.dumps(dict(status='FRESH_CALIBRATION_DIRECT_PREFLIGHT_PASSED_SMALL_AUTHORIZED',external_anchor=external['html_url'],calibration_activation=ref(cp),driver_activation=ref(sp),driver=driver['driver'],qualification=False,candidate_pairs_authorized=False)))
