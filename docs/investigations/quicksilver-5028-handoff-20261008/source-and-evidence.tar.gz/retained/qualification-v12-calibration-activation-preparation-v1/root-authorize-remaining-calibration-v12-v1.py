"""Accept actual original small raw contents; authorize original calibration only."""
from pathlib import Path
import hashlib
import json
import subprocess
import time
import types

SOURCE_HERE=Path(__file__).resolve().parent;BASE=SOURCE_HERE.parent;HERE=BASE/'qualification-v12-root-preparation-v1'
REMOTE='/home/mikers/quicksilver-maintenance-5028-20261006'
ROOT=REMOTE+'/qualification-v12-refresh/qualification-v10'
OUT=BASE/'qualification-v12-refresh/qualification-v10-prospective-root-v1'
OLD=BASE/'qualification-v9-selected-source-preparation-v1'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return dict(path=REMOTE+'/'+Path(p).relative_to(BASE).as_posix(),sha256=sha(p))
def save(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def api(endpoint,label,body=None):
    argv=['gh','api',endpoint]
    if body is not None:
        p=OUT/(label+'-request.json');save(p,dict(body=body));argv+=['--method','POST','--input',str(p)]
    result=subprocess.run(argv,capture_output=True,timeout=40)
    with (OUT/(label+'-raw.json')).open('xb') as f:f.write(result.stdout)
    with (OUT/(label+'-stderr.txt')).open('xb') as f:f.write(result.stderr)
    assert result.returncode==0,(label,result.stderr.decode(errors='replace'))
    return json.loads(result.stdout)

state=read(BASE/'state.json');assert isinstance(state['checkpoint_version'],int) and state['native_active'] is None
small=read(HERE/'actual-small-original-raw-replay-v12-v1.json')
assert small['status']=='SMALL_ALL12_ORIGINAL_RAW_REPLAY_PASS'
assert small['original_source_bindings_retained'] and small['actual_inventory_files']>=len(read(OUT/'pre-c1-anchor.accepted-v2.json')['files'])
assert small['all12_serial_nonoverlap'] and small['all6_maintenance_all6_service_guards'] and small['source_and_rule_precede_first_C']
assert len(small['rows'])==12 and not small['qualification'] and not small['performance_accepted']
run=OLD/'v12-actual-original-small-calibration-v1-run.json'
replay=OLD/'v12-actual-original-small-raw-replay-v1-run.json'
for p in (run,replay):
    r=read(p);assert r['rc']==0 and r['finished_ns']>=r['started_ns']
    for k in ('stdout','stderr'):assert sha(r[k]['path'])==r[k]['sha256']
anchor0=OUT/'pre-c1-anchor.accepted-v2.json';rule=OUT/'prospective-rule-freeze.accepted-v1.json'
assert read(OUT/'calibration-activation.accepted-v2.json')['anchor_sha256']==sha(anchor0)
assert read(rule)['frozen_ns']==small['rule_frozen_ns']<small['first_C_ns']
accepted=HERE/'root-actual-small-content-acceptance-v12-v1.json'
save(accepted,dict(schema=1,accepted_by_root=True,actual_small_contents_accepted=True,qualification=False,
    performance_accepted=False,collection_authorized=False,campaign_root=ROOT,held_excluded=[5004,5006],accepted_ns=time.time_ns(),
    native_result=ref(OLD/'v12-actual-original-small-raw-replay-v1-stdout.txt'),native_invocation=ref(replay),
    actual_inventory=small['inventory'],original_source_bindings_retained=True,all6_policy_complete_all6_guards_original_replay=True,
    all12_serial_nonoverlap=True,original_genuine_rule=ref(rule),native_first_C_ns=small['first_C_ns'],
    note='Actual original all12 raw replay and source chronology passed. Baseline content acceptance only; no noise/global/material/performance/qualification/pair/merge acceptance.'))
ip=OLD/'root_native_io.py';io=types.ModuleType('root_io');io.__file__=str(ip);exec(compile(ip.read_bytes(),str(ip),'exec'),io.__dict__)
sources=[accepted,HERE/'actual-small-original-raw-replay-v12-v1.json',Path(__file__)]
for p in (run,replay):
    sources.append(p);r=read(p);sources.extend(Path(r[k]['path']) for k in ('stdout','stderr'))
targets={p.relative_to(BASE).as_posix():p for p in sources}
prestage='''from pathlib import Path
import hashlib,json,os
B=Path(BASE_LITERAL);wanted=EXPECTED_LITERAL;missing=[]
for name,h in wanted.items():
 p=B/name
 if os.path.lexists(p):
  assert p.is_file() and not p.is_symlink() and p.resolve()==p and hashlib.sha256(p.read_bytes()).hexdigest()==h,name
 else:missing.append(name)
print(json.dumps({'missing':missing}))
'''.replace('BASE_LITERAL',repr(REMOTE)).replace('EXPECTED_LITERAL',repr({n:sha(p) for n,p in targets.items()}))
missing=json.loads(io.native(['python3','-B','-c',prestage],'v12-small-facts-prestage-readback-v1',180))['missing']
if missing:io.put({n:targets[n] for n in missing},'v12-small-facts-exclusive-stage-v1')
ap=OUT/'post-small-source-anchor.accepted-v1.json'
remote_anchor=ref(ap)['path'] if ap.exists() else REMOTE+'/'+ap.relative_to(BASE).as_posix()
closure='''from pathlib import Path
import hashlib,json,sys,time
sys.dont_write_bytecode=True
B=Path(BASE_LITERAL);inventory=INVENTORY_LITERAL;wanted=EXPECTED_LITERAL;old=OLD_LITERAL;accepted=ACCEPTED_LITERAL;out=OUT_LITERAL
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(inventory['path'])==inventory['sha256'];a=json.loads(Path(inventory['path']).read_bytes())
assert sha(old['path'])==old['sha256'];original=json.loads(Path(old['path']).read_bytes())
assert a['root']==ROOT_LITERAL and a['accepted_by_root'] is True and all(a['files'].get(p)==h for p,h in original['files'].items())
for name,h in wanted.items():
 p=B/name;assert sha(p)==h
 if str(p) in a['files']:assert a['files'][str(p)]==h
 else:a['files'][str(p)]=h
for p,h in ((inventory['path'],inventory['sha256']),(old['path'],old['sha256'])):
 if p in a['files']:assert a['files'][p]==h
 else:a['files'][p]=h
canonical={}
for p,h in a['files'].items():
 p=Path(p);r=p.resolve(strict=True)
 assert p.is_absolute() and p.is_file() and r not in canonical and sha(p)==h,str(p)
 canonical[r]=str(p)
 if str(p).endswith('.py'):assert not (p.parent/'__pycache__').exists()
for folder in (Path(ROOT_LITERAL),Path(ROOT_LITERAL)/'plans',Path(ROOT_LITERAL)/'receipts'):
 if folder.exists():assert not any(p.name.startswith(('pairs','ar-pairs','ar-guard','ar-orchestration-pairs','orchestration-pairs')) for p in folder.iterdir())
assert sys.pycache_prefix is None
a.update(actual_file_count=len(a['files']),actual_small_contents=accepted,actual_small_contents_accepted=True,
 original_pre_c1_anchor=old,diagnostic_raw_inventory=False,raw_validation_pending=False,qualification=False,
 collection_authorized=False,candidate_pair_collection_authorized=False,performance_accepted=False,
 note='Actual additive post-small raw/source closure. All original_source_bindings mechanism/source/rule/context bindings and genuine before-C1 times retained; source mechanism unchanged. Original small raw replay accepted; no performance/pair authority.')
with Path(out).open('x') as f:json.dump(a,f,indent=2,allow_nan=False);f.write('\\n')
proof=dict(schema=1,status='ACTUAL_POST_SMALL_SOURCE_RAW_CLOSURE_PASS',actual_files=len(a['files']),original_source_bindings_retained=True,
 no_pair_namespace=True,canonical_hashes_verified=True,python_cache_absent=True,checked_ns=time.time_ns(),qualification=False,
 anchor={'path':out,'sha256':sha(out)})
with Path(out).with_name('post-small-source-anchor.actual-readback-v1.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\\n')
print(json.dumps(dict(anchor=a,proof=proof)))
'''
for x,y in {'BASE_LITERAL':repr(REMOTE),'INVENTORY_LITERAL':repr(small['inventory']),
    'EXPECTED_LITERAL':repr({n:sha(p) for n,p in targets.items()}),'OLD_LITERAL':repr(ref(anchor0)),
    'ACCEPTED_LITERAL':repr(ref(accepted)),'OUT_LITERAL':repr(remote_anchor),'ROOT_LITERAL':repr(ROOT)}.items():closure=closure.replace(x,y)
closed=json.loads(io.native(['python3','-B','-c',closure],'v12-actual-post-small-source-closure-v1',1800))
save(ap,closed['anchor']);save(OUT/'post-small-source-anchor.actual-readback-v1.json',closed['proof'])
assert sha(ap)==closed['proof']['anchor']['sha256'] and closed['proof']['original_source_bindings_retained']
body=('Fresh v12 small baseline accepted: all six original30k maintenance captures and all six service guards passed original raw validation, full-value/reopen/miss oracles, policy completion, ordinary durable ACK, default compression/CRC and serial timing checks. '
      'The actual small raw inventory has actual counted files and retains all original pre-C1 genuine before-C1 source/context bindings. Additive post-small closure has'+str(closed['proof']['actual_files'])+' files, actual native canonical hashes/cache/no-pair checks passed. '
      'Source mechanism and frozen rule/math/settings are unchanged. Root small acceptance SHA '+sha(accepted)+', actual additive anchor SHA '+sha(ap)+'. '
      'Next: only the original remaining39C/39guards calibration across all five offline and three online fixtures; the original controller may reuse the six exact-plan/validated/policy-complete small captures. '
      'No candidate pairs, noise, performance, qualification or merge acceptance. B36/R18, full GLOBAL54, preservation and114 ordered pair+guard, material3M speed AND actual process-memory, default/conditional4M, source/current-head review/CI, ordered merges and actual landed #5030 qualification remain required. R5037/B5054 remain draft/unmerged/unqualified. Held #5004/PR5006 excluded.')
posted=api('repos/snissn/gomap/issues/5030/comments','external-small-content-and-calibration-rest-v12-v1',body)
actual=api('repos/snissn/gomap/issues/comments/'+str(posted['id']),'external-small-content-and-calibration-rest-v12-v1-readback')
assert actual['body']==body and actual['html_url']==posted['html_url']
cp=OUT/'calibration-rest-activation.accepted-v1.json';previous=OUT/'calibration-activation.accepted-v2.json'
cal=read(previous);scope=['offline-calibration:all-original-five','online-calibration:all-original-three']
cal.update(anchor=ref(ap)['path'],anchor_sha256=sha(ap),github_external_anchor_url=actual['html_url'],authorized_ns=time.time_ns(),
    root_launch_scope_now=scope,supersedes=ref(previous),actual_small_contents=ref(accepted),
    note='Genuine post-small calibration-only activation with complete inherited source/raw closure. Original valid-small reuse only; no changed source/rule/math/settings and no candidate pair authority.')
assert cal['prospective_rule_freeze']==ref(rule) and cal['candidate_pair_collection_authorized'] is False
save(cp,cal)
dp=OUT/'remaining-calibration-driver-activation.accepted-v1.json';sp=OUT/'small-calibration-driver-activation.accepted-v2.json'
driver=read(sp);driver.update(phase='calibration-rest',calibration_activation=ref(cp),root_launch_scope_now=scope,
    authorized_ns=time.time_ns(),supersedes=ref(sp),actual_small_contents=ref(accepted))
assert driver['driver']==dict(path=REMOTE+'/qualification-v12-fresh-controls-v1/collection-native-driver-v12-v2.py',sha256=sha(SOURCE_HERE/'collection-native-driver-v12-v2.py'))
assert driver['candidate_pair_collection_authorized'] is False
save(dp,driver);io.put({p.relative_to(BASE).as_posix():p for p in (cp,dp)},'v12-remaining-calibration-activations-exclusive-stage-v1')
result=dict(status='ACTUAL_SMALL_CONTENT_ACCEPTED_REMAINING_CALIBRATION_ONLY_AUTHORIZED',external_anchor=actual['html_url'],
    small=ref(accepted),source_anchor=ref(ap),calibration_activation=ref(cp),driver_activation=ref(dp),
    calibration_captures=6,calibration_guards=6,candidate_pairs=0,qualification=False,performance_accepted=False)
save(HERE/'remaining-calibration-actual-authorization-v12-v1.json',result);print(json.dumps(result))
