"""Execute root-authorized original remaining calibration serially."""
from pathlib import Path
import hashlib,json,os,time,types
SOURCE_HERE=Path(__file__).resolve().parent;BASE=SOURCE_HERE.parent;HERE=BASE/'qualification-v12-root-preparation-v1';STATE=BASE/'state.json'
REMOTE='/home/mikers/quicksilver-maintenance-5028-20261006'
ROOT=REMOTE+'/qualification-v12-refresh/qualification-v10'
OUT=BASE/'qualification-v12-refresh/qualification-v10-prospective-root-v1'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return dict(path=REMOTE+'/'+p.relative_to(BASE).as_posix(),sha256=sha(p))
def store(s):
    p=HERE/('state-rest-runtime-'+str(time.time_ns())+'.json')
    with p.open('x') as f:json.dump(s,f,indent=2,allow_nan=False);f.write('\n')
    p.replace(STATE)
dp=OUT/'remaining-calibration-driver-activation.accepted-v1.json';activation=read(dp)
authorization=read(HERE/'remaining-calibration-actual-authorization-v12-v1.json')
small=read(HERE/'root-actual-small-content-acceptance-v12-v1.json')
assert authorization['driver_activation']==ref(dp) and authorization['calibration_captures']==authorization['calibration_guards']==6
assert authorization['candidate_pairs']==0 and not authorization['qualification']
assert small['accepted_by_root'] and small['actual_small_contents_accepted'] and small['all6_policy_complete_all6_guards_original_replay']
assert activation['phase']=='calibration-rest' and activation['accepted_by_root'] and activation['collection_authorized'] and not activation['candidate_pair_collection_authorized']
assert activation['driver']==dict(path=REMOTE+'/qualification-v12-fresh-controls-v1/collection-native-driver-v12-v2.py',sha256=sha(SOURCE_HERE/'collection-native-driver-v12-v2.py'))
state=read(STATE);assert isinstance(state['checkpoint_version'],int) and state['native_active'] is None
state['native_active']=dict(phase='fresh-v12-calibration-rest',owner='/root',local_owner_pid=os.getpid(),started_ns=time.time_ns(),
    label='v12-actual-original-remaining-calibration-v1',campaign_root=ROOT,driver=activation['driver'],activation=ref(dp),
    qualification=False,candidate_pair_collection_authorized=False)
state.setdefault('qualification_v12_current',{}).update(stage='Original remaining calibration running serially; actual6C/6guard small content accepted',
    calibration_captures=6,calibration_guards=6,actual_small_contents=authorization['small'],
    post_small_source_anchor=authorization['source_anchor'],remaining_calibration_driver=ref(dp))
state['current_execution_status']='Fresh original remaining39C/39guard calibration RUNNING serially; actual6C/6guard accepted; no pair/performance/qualification acceptance'
state['next_action']='Join actual original remaining phase, validate/replay all39C/39guards then original B36/R18/GLOBAL54 before any pair'
store(state)
ip=BASE/'qualification-v9-selected-source-preparation-v1/root_native_io.py';io=types.ModuleType('root_io');io.__file__=str(ip);exec(compile(ip.read_bytes(),str(ip),'exec'),io.__dict__)
try:
    raw=io.native(['python3','-B',activation['driver']['path'],'calibration-rest',ref(dp)['path'],sha(dp)],'v12-actual-original-remaining-calibration-v1',48000)
    state=read(STATE);state['native_active']=None
    state['current_execution_status']='Fresh original remaining calibration joined rc0; original all39C/39guard content replay and B36/R18 analysis next'
    state['next_action']='Root replay actual all39C/39guard original sources and phase receipts, then original B36/R18 freezes and GLOBAL54/preservation/pair gates'
    store(state);print(raw.decode(),end='')
except BaseException as error:
    state=read(STATE);state['native_active']=None
    state['current_execution_status']='Fresh remaining calibration failed; retained actual native failure requires diagnosis before any retry'
    state['next_action']='Read retained v12-actual-original-remaining-calibration-v1 raw run/stdout/stderr and diagnose actual failed gate'
    state['last_native_failure']=dict(label='v12-actual-original-remaining-calibration-v1',error=repr(error),finished_ns=time.time_ns())
    store(state);raise
