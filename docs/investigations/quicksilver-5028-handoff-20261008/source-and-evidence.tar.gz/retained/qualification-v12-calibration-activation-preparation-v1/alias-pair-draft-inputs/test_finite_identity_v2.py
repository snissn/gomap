"""Local synthetic identity checks only; uses the real 16-entry alias geometry."""
from pathlib import Path
import ast
import copy
import hashlib
import json
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
CONTROLS=BASE/'qualification-v12-fresh-controls-v2'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())

class FiniteIdentity(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(prefix='synthetic-identity-',dir=HERE)
  self.root=Path(self.temp.name)
  self.real=read(CONTROLS/'v10-source-lock.json')['manifest']['libraries']
  self.assertEqual(len(self.real),16)
  self.names={};libraries={};files={}
  for loader,identity in self.real.items():
   target=identity['resolved']
   if target not in self.names:
    p=self.root/('target-'+str(len(self.names)));p.write_bytes(('synthetic-source-identity '+target).encode());self.names[target]=p
   p=self.names[target]
   if loader==target:alias=p
   else:
    alias=self.root/('loader-'+str(len(libraries)));alias.symlink_to(p);self.names[loader]=alias
   libraries[str(alias)]={'resolved':str(p),'sha256':sha(p)}
   files[str(alias)]=sha(p);files[str(p)]=sha(p)
  self.manifest={'libraries':libraries};mp=self.root/'manifest.json';mp.write_text(json.dumps(self.manifest))
  files[str(mp)]=sha(mp)
  self.files=files
  self.deployment={'manifest_sha256':sha(mp),'libraries':libraries}
  source=(HERE/'verify-qualification-v10-deployment-v2.py').read_text()
  self.block=source[source.index('    # Identity-only exception:'):source.index('    def anchored(')]
  self.block='\n'.join(line[4:] if line.startswith('    ') else line for line in self.block.splitlines())
 def tearDown(self):self.temp.cleanup()
 def check(self):
  def bound(p,h):self.assertEqual(sha(p),h);return read(p)
  env={'Path':Path,'ROOT':self.root,'deployment':self.deployment,'bound':bound,'anchor_files':self.files,'sha':sha}
  exec(compile(self.block,'exact-v2-identity-block','exec'),env)
  return env
 def alias(self):
  return next((Path(p),Path(i['resolved'])) for p,i in self.manifest['libraries'].items() if p!=i['resolved'])
 def test_real16_geometry_accepts_exact10_alias_pairs(self):
  result=self.check();self.assertEqual(len(result['approved_library_aliases']),10)
  self.assertEqual(sum(len(v)-1 for v in result['canonical'].values()),10)
 def test_unknown_alias_rejected(self):
  _,target=self.alias();alias=self.root/'unapproved-alias';alias.symlink_to(target);self.files[str(alias)]=sha(target)
  with self.assertRaises(AssertionError):self.check()
 def test_rebound_target_rejected(self):
  alias,_=self.alias();other=self.root/'other';other.write_bytes(b'synthetic-other');alias.unlink();alias.symlink_to(other)
  with self.assertRaises(AssertionError):self.check()
 def test_digest_mismatch_rejected(self):
  alias,_=self.alias();self.files[str(alias)]='0'*64
  with self.assertRaises(AssertionError):self.check()
 def test_canonical_alias_collision_rejected(self):
  _,target=self.alias();alias=self.root/'third-entry';alias.symlink_to(target);self.files[str(alias)]=sha(target)
  with self.assertRaises(AssertionError):self.check()
 def test_canonical_target_required(self):
  _,target=self.alias();del self.files[str(target)]
  with self.assertRaises(AssertionError):self.check()
 def test_target_bytes_drift_rejected(self):
  _,target=self.alias();target.write_bytes(b'synthetic-drift')
  with self.assertRaises(AssertionError):self.check()

class SourceInvariance(unittest.TestCase):
 def test_driver_only_two_verifier_names_change(self):
  old=(CONTROLS/'collection-native-driver-v12-v1.py').read_text();new=(HERE/'collection-native-driver-v12-v2.py').read_text()
  self.assertEqual(old.count('verify-qualification-v10-deployment-v1.py'),2)
  expected=old.replace('verify-qualification-v10-deployment-v1.py','verify-qualification-v10-deployment-v2.py')
  self.assertEqual(new,expected)
  self.assertEqual(ast.dump(ast.parse(new)),ast.dump(ast.parse(expected)))
 def test_verifier_only_identity_block_changes(self):
  old=(CONTROLS/'verify-qualification-v10-deployment-v1.py').read_text();new=(HERE/'verify-qualification-v10-deployment-v2.py').read_text()
  o1=old.index('    canonical = set()');o2=old.index('    def anchored(')
  n1=new.index('    # Identity-only exception:');n2=new.index('    def anchored(')
  restored=new[:n1]+old[o1:o2]+new[n2:]
  self.assertEqual(restored,old)
 def test_controller_and_original_math_sources_remain_exact(self):
  accepted=read(BASE/'qualification-v12-root-preparation-v1/root-controls-v12-source-acceptance-v1.json')
  for path,digest in accepted['selected_operational_sources'].items():
   p=CONTROLS/Path(path).name
   self.assertEqual(sha(p),digest,path)
  old=ast.parse((BASE/'qualification-v11-source-orchestration-preparation-v2/root-freeze-qualification-v11-v1.py').read_bytes())
  new=ast.parse((HERE/'root-freeze-qualification-v12-v1.py').read_bytes())
  def literal(tree):
   return next(n.value.value for n in ast.walk(tree) if isinstance(n,ast.keyword) and n.arg=='numerical_policy')
  self.assertEqual(literal(old),literal(new))

if __name__=='__main__':unittest.main(verbosity=2)
