"""Root-owned serial driver. CLI: PHASE ACTIVATION ACTIVATION_SHA256.

PHASE is small, calibration-rest, or pairs. Exact original controllers and owned
process cleanup are reused. Every failure is retained and stops the stage.
"""
if not __debug__:
    raise RuntimeError('collection driver requires unoptimized Python')
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import types
sys.dont_write_bytecode = True
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
ROOT=Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')
SELECTED=HERE
IMMUTABLE_SELECTED=BASE/'qualification-v10-source-preparation-v2'
GRID=[f'primary-s24-n{n}' for n in (30000,300000,3000000)]+[f'holdout-s73-n{n}' for n in (300000,3000000)]
HELPERS=json.loads((HERE/'deployment-helpers-selection.json').read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound(ref):
    assert set(ref)=={'path','sha256'}
    p=Path(ref['path'])
    assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve()==p
    assert re.fullmatch('[0-9a-f]{64}',ref['sha256']) and sha(p)==ref['sha256']
    return json.loads(p.read_bytes())


def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')


def source_module(path,name):
    value=types.ModuleType(name);value.__file__=str(path)
    exec(compile(Path(path).read_bytes(),str(path),'exec'),value.__dict__)
    return value


def source_only_imports(files):
    assert sys.pycache_prefix is None, 'external Python cache prefix is not admissible'
    for path in files:
        if str(path).endswith('.py'):
            assert not (Path(path).parent/'__pycache__').exists(), 'unbound Python cache in selected source directory'


def commands(phase,controllers,r_activation):
    if phase=='small':
        return [('small-baseline',['python3','-B',controllers['B']['path'],'offline-calibration',GRID[0]],24000)]
    if phase=='calibration-rest':
        return [(f'offline-calibration-{slug}',['python3','-B',controllers['B']['path'],'offline-calibration',slug],24000) for slug in GRID]+[
            (f'online-calibration-{slug}',['python3','-B',controllers['B']['path'],'online-calibration',slug],24000) for slug in GRID[:3]]
    assert phase=='pairs' and r_activation is not None
    return [('R-offline-pairs',['python3','-B',controllers['R']['path'],'offline-pairs',r_activation['path'],r_activation['sha256']],86400),
            ('B-offline-pairs',['python3','-B',controllers['B']['path'],'offline-pairs'],86400),
            ('B-online-pairs',['python3','-B',controllers['B']['path'],'online-pairs'],86400)]


def main():
    assert len(sys.argv)==4
    phase,activation_path,activation_sha=sys.argv[1:]
    assert phase in ('small','calibration-rest','pairs')
    activation=bound(dict(path=activation_path,sha256=activation_sha))
    assert activation['accepted_by_root'] is True and activation['collection_authorized'] is True and activation['qualification'] is False
    assert activation['phase']==phase and activation['campaign_root']==str(ROOT) and activation['held_excluded']==[5004,5006]
    assert activation['driver']==dict(path=str(Path(__file__).resolve()),sha256=sha(__file__))
    assert activation['helper_selection_sha256']==sha(HERE/'deployment-helpers-selection.json')
    deployment=bound(activation['deployment'])
    assert deployment['accepted_by_root'] is True and deployment['collection_authorized'] is False and deployment['qualification'] is False
    assert deployment['campaign_root']==str(ROOT) and set(deployment['helpers'])==set(HELPERS)
    for role,(name,digest) in HELPERS.items():
        selected=deployment['helpers'][role]
        assert Path(selected['path']).name==name and selected['sha256']==digest==sha(selected['path'])
        assert selected['path']=={'source_export': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-native-source-adapters-v4/build-native-v12.py', 'inventory': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-native-source-adapters-v4/inventory-native-v12.py', 'builder': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-native-source-adapters-v4/build-native-v12.py', 'inventory_acceptor': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-source-inventory/inputs/accept-fresh-inventory-v12.py', 'correctness_checker': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-native-source-adapters-v4/correctness-only-v12.py', 'correctness_checks': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-native-source-adapters-v4/checks-fresh.template.json', 'binder': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-fresh-controls-v1/bind-prospective-v10-v1.py', 'R_controller': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-fresh-controls-v1/r-collection-controller.py', 'B_controller': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-fresh-controls-v1/qualification-v10-collection-controller.py', 'reuse_applicability': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-fresh-controls-v1/v10_applicability.py', 'reuse_lock': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-fresh-controls-v1/v10-source-lock.json', 'post_calibration_seam': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v10-source-preparation-v2/post-calibration-identity-seam-v1.py'}[role], 'wrong exact fresh helper path'
    controllers=deployment['executed_controllers']
    assert controllers=={role:deployment['helpers'][role+'_controller'] for role in ('R','B')}
    calibration=bound(activation['calibration_activation'])
    assert calibration['accepted_by_root'] is True and calibration['collection_authorized'] is True and calibration['qualification'] is False
    assert calibration['allowed_stages']==['fixtures','offline-calibration','online-calibration']
    assert calibration['campaign_root']==str(ROOT) and calibration['held_excluded']==[5004,5006]
    assert calibration['candidate_pair_collection_authorized'] is False
    assert calibration['deployment_binding']==activation['deployment']
    assert re.fullmatch(r'https://github\.com/snissn/gomap/issues/[0-9]+#issuecomment-[0-9]+',calibration['github_external_anchor_url'])
    anchor=bound(dict(path=calibration['anchor'],sha256=calibration['anchor_sha256']))
    assert anchor['accepted_by_root'] is True and anchor['root']==str(ROOT)
    assert anchor['files'][str(Path(__file__).resolve())]==sha(__file__)
    assert anchor['files'][str(HERE/'deployment-helpers-selection.json')]==sha(HERE/'deployment-helpers-selection.json')
    source_only_imports(anchor['files'])
    if phase=='pairs':
        current_pair_anchor=bound(activation['current_pair_source_anchor'])
        assert current_pair_anchor['schema']==1 and current_pair_anchor['accepted_by_root'] is True and current_pair_anchor['root']==str(ROOT)
        predecessor_ref=activation['current_pair_source_predecessor']
        predecessor=bound(predecessor_ref)
        assert predecessor['schema']==1 and predecessor['accepted_by_root'] is True and predecessor['root']==str(ROOT)
        assert current_pair_anchor['files'][predecessor_ref['path']]==predecessor_ref['sha256']
        assert all(current_pair_anchor['files'].get(path)==digest for path,digest in predecessor['files'].items())
        assert current_pair_anchor['files'][calibration['anchor']]==calibration['anchor_sha256']
        assert all(current_pair_anchor['files'].get(path)==digest for path,digest in anchor['files'].items())
        assert current_pair_anchor['files'][str(Path(__file__).resolve())]==sha(__file__)
        source_only_imports(current_pair_anchor['files'])
    checker=deployment['helpers']['correctness_checker']
    cleanup=source_module(checker['path'],'root_correctness_cleanup')
    signal.signal(signal.SIGINT,cleanup.interrupt);signal.signal(signal.SIGTERM,cleanup.interrupt)
    cleanup.idle(BASE)
    # Child controllers use exactly the preserved R support import directory.
    child_env=dict(os.environ)
    child_env.pop('PYTHONPYCACHEPREFIX', None)
    child_env['PYTHONPATH']=deployment['preserved_support_import_directory']
    receipt=HERE/('collection-driver-'+phase+'-v12');receipt.mkdir(exist_ok=False)
    def command(label,argv,timeout):
        source_only_imports(anchor['files'])
        if phase=='pairs':source_only_imports(current_pair_anchor['files'])
        folder=receipt/label;folder.mkdir(exist_ok=False)
        record=dict(schema=1,argv=argv,started_ns=time.time_ns(),owner='/root',driver_pid=os.getpid(),
                    activation_sha256=activation_sha,load_before=os.getloadavg(),qualification=False,phase=phase)
        save(folder/'started.json',record)
        proc=None;failure=None
        try:
            with (folder/'stdout.txt').open('x') as out,(folder/'stderr.txt').open('x') as err:
                proc=subprocess.Popen(argv,cwd=ROOT,env=child_env,stdout=out,stderr=err,start_new_session=True)
                record['pid']=proc.pid
                try:record['rc']=proc.wait(timeout=timeout)
                except subprocess.TimeoutExpired:record.update(rc=124,timeout=True)
        except BaseException as error:
            failure=error;record['error']=repr(error)
        finally:
            handlers={s:signal.signal(s,signal.SIG_IGN) for s in (signal.SIGINT,signal.SIGTERM)}
            try:
                quiescent=proc is None
                if proc is not None:
                    try:record['process_group_cleanup']=cleanup.stop_group(proc);quiescent=True
                    except BaseException as error:failure=error;record['cleanup_error']=repr(error)
                    if 'rc' not in record:record['rc']=proc.returncode
                record.update(finished_ns=time.time_ns(),load_after=os.getloadavg(),raw_hashes_final=quiescent)
                for name in ('stdout','stderr'):
                    path=folder/(name+'.txt')
                    record[name+'_sha256']=sha(path) if quiescent and path.exists() else None
                save(folder/'complete.json',record)
            finally:
                for signum,handler in handlers.items():signal.signal(signum,handler)
        print(json.dumps(dict(label=label,rc=record.get('rc'),receipt=str(folder))),flush=True)
        if failure is not None:raise failure
        assert record['rc']==0 and not record.get('timeout'), 'Retained failure; no automatic retry.'
        cleanup.idle(BASE)  # Also detect any live collector's detached session.
    binding=calibration['prospective_binding']
    assert calibration['prospective_binding_sha256']==binding['sha256']
    binder=deployment['helpers']['binder']
    if phase=='small':
        assert activation['root_launch_scope_now']==['offline-calibration:'+GRID[0]]
        assert activation['candidate_pair_collection_authorized'] is False
        command('binder-check',['python3','-B',binder['path'],'check',binding['path'],binding['sha256'],activation['calibration_activation']['path'],activation['calibration_activation']['sha256']],180)
    elif phase=='calibration-rest':
        assert activation['root_launch_scope_now']==['offline-calibration:all-original-five','online-calibration:all-original-three']
        assert activation['candidate_pair_collection_authorized'] is False
        app=source_module(deployment['helpers']['reuse_applicability']['path'],'v10_applicability')
        sys.modules['v10_applicability']=app
        b=source_module(binder['path'],'root_v10_binder')
        seam=source_module(deployment['helpers']['post_calibration_seam']['path'],'root_v10_post_calibration_identity')
        seam.check(b,[binding['path'],binding['sha256'],activation['calibration_activation']['path'],activation['calibration_activation']['sha256']],'post-calibration-pre-first-pair')
    else:
        assert activation['root_launch_scope_now']==['R-offline-pairs:all-original-six','B-offline-pairs:all-original-ten','B-online-pairs:all-original-three']
        assert activation['candidate_pair_collection_authorized'] is True
        guard=activation['global54_guard'];guard_input=activation['global54_input']
        assert guard==dict(path=str(HERE/'global54-artifact-guard-v12-operational-v1.py'),sha256=sha(HERE/'global54-artifact-guard-v12-operational-v1.py'))
        assert current_pair_anchor['files'][guard['path']]==guard['sha256']
        actual_guard_input=bound(guard_input)
        assert actual_guard_input['guard']==guard and actual_guard_input['R_anchor']==activation['current_pair_source_anchor']
        assert actual_guard_input['calibration_activation']==activation['calibration_activation']
        command('global54-before-first-pair',['python3','-B',guard['path'],guard_input['path'],guard_input['sha256']],3600)
        result=json.loads((receipt/'global54-before-first-pair/stdout.txt').read_bytes())
        assert result['status']=='GLOBAL54_ARTIFACT_REPLAY_COMPLETE_ROOT_LAUNCH_STILL_REQUIRED'
        assert (result['baseline_captures'],result['guard_captures'],result['B_slots'],result['R_slots'])==(39,39,36,18)
        assert result['qualification'] is False and result['candidate_pairs_authorized'] is False
        r=bound(activation['R_activation'])
        assert r['accepted_by_root'] is True and r['collection_authorized'] is True and r['qualification'] is False
        assert r['campaign_root']==str(ROOT) and r['held_excluded']==[5004,5006]
    if phase!='pairs':
        verifier=calibration['deployment_verifier']
        assert verifier==dict(path=str(HERE/'verify-qualification-v10-deployment-v2.py'),sha256=sha(HERE/'verify-qualification-v10-deployment-v2.py'))
        command('deployment-check',['python3','-B',verifier['path'],activation['deployment']['path'],activation['deployment']['sha256'],binding['path'],binding['sha256'],activation['calibration_activation']['path'],activation['calibration_activation']['sha256']],180)
    for label,argv,timeout in commands(phase,controllers,activation.get('R_activation')):
        command(label,argv,timeout)
    save(receipt/'complete.json',dict(schema=1,status='STAGE_JOINED_ROOT_CONTENT_REVIEW_REQUIRED',phase=phase,rc=0,finished_ns=time.time_ns(),activation_sha256=activation_sha,qualification=False))


if __name__=='__main__':main()
