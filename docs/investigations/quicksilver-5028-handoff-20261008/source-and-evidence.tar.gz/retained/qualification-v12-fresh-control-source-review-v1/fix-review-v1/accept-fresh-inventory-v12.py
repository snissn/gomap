"""Accept fresh inventory bytes after independent root content review; no collection.

CLI: ACTUAL_CONTENT_ACCEPTANCE SHA256. Every output is exclusive.
"""
if not __debug__:
    raise RuntimeError('inventory acceptance requires assertions')
import hashlib
import json
from pathlib import Path
import re
import sys
import time

ROOT = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
FOUNDATION = ROOT / 'qualification-v12-source-inventory'
SLOTS = {'A': 'A', 'A_unified': 'A', 'R': 'R', 'R_unified': 'R',
         'B': 'B', 'B_unified': 'B', 'restore': 'A', 'benchprof': 'A'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound(ref):
    assert set(ref) == {'path', 'sha256'}
    path = Path(ref['path'])
    assert path.is_absolute() and path.is_file() and not path.is_symlink()
    assert path.resolve(strict=True) == path
    assert re.fullmatch('[0-9a-f]{64}', ref['sha256']) and sha(path) == ref['sha256']
    return json.loads(path.read_bytes())


def main():
    assert len(sys.argv) == 3 and sys.pycache_prefix is None
    acceptance_ref = dict(path=sys.argv[1], sha256=sys.argv[2])
    acceptance = bound(acceptance_ref)
    assert acceptance['accepted_by_root'] is True
    assert acceptance['qualification'] is False and acceptance['collection_authorized'] is False
    assert acceptance['campaign_root'] == str(FOUNDATION)
    assert acceptance['actual_receipt_contents_accepted'] == {r: True for r in ('source', 'build', 'native', 'runner')}
    for field in ('landed_harness_attested', 'host_clock_and_serialization_accepted', 'complete_compiler_input_contents_accepted'):
        assert acceptance[field] is True
    prepared = FOUNDATION / 'inventory-prepared.json'
    meta = bound(dict(path=str(prepared), sha256=acceptance['inventory_prepared_sha256']))
    assert meta['accepted_by_root'] is False and meta['performance_runs'] == 0 and meta['qualification'] is False
    manifest = bound(dict(path=str(FOUNDATION / 'manifest.json'), sha256=acceptance['manifest_sha256']))
    assert meta['manifest_sha256'] == acceptance['manifest_sha256']
    assert set(manifest['receipts']) == {'source', 'build', 'native', 'runner'}
    assert acceptance['receipt_sha256'] == {r: v['sha256'] for r, v in manifest['receipts'].items()}
    for ref in manifest['receipts'].values():
        bound(dict(path=str(FOUNDATION / ref['path']), sha256=ref['sha256']))
    assert acceptance['sources'] == manifest['sources'] and acceptance['libraries'] == manifest['libraries']
    assert set(manifest['sources']) == set(SLOTS) and len(manifest['libraries']) == 16
    for field in ('sources', 'libraries', 'receipts'):
        assert meta[field] == manifest[field]
    build = bound(acceptance['build_complete'])
    assert acceptance['build_complete_sha256'] == acceptance['build_complete']['sha256'] == meta['build_complete_sha256']
    assert build['qualification'] is False and build['collection_authorized'] is False
    assert build['status'] == 'BUILD_COMPLETE_STOP_BEFORE_MEASUREMENT' and build['accepted_by_root'] is False
    assert set(build['build_receipts']) == set(build['compiler_input_receipts']) == set(SLOTS)
    assert acceptance['actual_compiler_input_contents_accepted'] == {slot: True for slot in SLOTS}
    assert acceptance['compiler_input_receipts'] == meta['compiler_input_receipts'] == build['compiler_input_receipts']
    basis = bound(acceptance['source_basis'])
    assert basis['receipt_kind'] == 'qualification-v12-observed-source-basis' and basis['accepted_by_root'] is False
    assert set(basis['exact_variants']) == {'A', 'R', 'B'}
    assert meta['source_basis'] == acceptance['source_basis']
    source = json.loads((FOUNDATION / manifest['receipts']['source']['path']).read_bytes())
    assert source['landed_harness_head'] == meta['landing'] == basis['exact_variants']['A']['head']
    assert acceptance['variants'] == basis['exact_variants']
    assert acceptance['held_excluded'] == basis['held_excluded'] == [5004, 5006]
    for slot, role in SLOTS.items():
        variant = basis['exact_variants'][role]
        actual = manifest['sources'][slot]
        assert (actual['head'], actual['tree'], actual['built_against_head']) == (variant['head'], variant['tree'], variant['head'])
        assert actual['binary'] == Path(actual['binary']).name
        binary = FOUNDATION / 'bin' / actual['binary']
        assert binary.is_file() and not binary.is_symlink() and binary.stat().st_mode & 0o111
        assert sha(binary) == actual['binary_sha256'] == build['build_receipts'][slot]['binary_sha256']
        compiler = bound(build['compiler_input_receipts'][slot])
        assert compiler['slot'] == slot and compiler['role'] == role
        assert (compiler['head'], compiler['tree']) == (variant['head'], variant['tree'])
    for path, identity in manifest['libraries'].items():
        assert str(Path(path).resolve(strict=True)) == identity['resolved'] and sha(path) == identity['sha256']
    for path, digest in acceptance['files'].items():
        assert sha(path) == digest
    assert all(type(value) is int for value in (build['completed_ns'], meta['created_ns'], acceptance['accepted_ns']))
    assert build['completed_ns'] <= meta['created_ns'] <= acceptance['accepted_ns'] <= time.time_ns()
    result = dict(meta, accepted_by_root=True, status='ROOT_ACCEPTED_ACTUAL_INVENTORY_CONTENTS',
                  actual_content_acceptance_path=acceptance_ref['path'],
                  actual_content_acceptance_sha256=acceptance_ref['sha256'], content_accepted_ns=time.time_ns())
    target = FOUNDATION / 'inventory-complete.json'
    with target.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(status='ROOT_ACCEPTED_ACTUAL_INVENTORY_CONTENTS_STOP_NO_MEASUREMENT',
                          inventory_sha256=sha(target), qualification=False)))


if __name__ == '__main__':
    main()
