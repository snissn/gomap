"""Finite source-binding adaptation of reviewed v11 controls; no native commands.

CLI: REQUEST SHA256. Fresh actual foundation evidence is required before writes.
The output is source preparation only; separate review and collection authority
remain required. Original controllers, matrices and numerical rules are retained.
"""
if not __debug__:
    raise RuntimeError('source construction requires assertions')
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys

BASE = Path('/Users/michaelseiler/dev/snissn/gomap/tmp/quicksilver-maintenance-5028-20261005')
OLD = BASE / 'qualification-v11-fresh-controls-v1'
NATIVE_BASE = '/home/mikers/quicksilver-maintenance-5028-20261006'
OLD_ROOT = NATIVE_BASE + '/qualification-v11-refresh/qualification-v10'
NEW_ROOT = NATIVE_BASE + '/qualification-v12-refresh/qualification-v10'
OLD_LOCK_SHA = 'fa4b316bcf5eca0f8141be9c99fbf57777e386196a83b9599966d802af10677e'
ORIGINAL_CHECKS_SHA = '42142c3ff8fecf98ff14eed6c394093d906001d09d5bfb2ab6a895d065aa866c'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound(ref):
    assert set(ref) == {'path', 'sha256'}
    p = Path(ref['path'])
    assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve(strict=True) == p
    assert re.fullmatch('[0-9a-f]{64}', ref['sha256']) and sha(p) == ref['sha256']
    return json.loads(p.read_bytes())


def one(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


def assignment(text, name, value):
    lines = text.splitlines(True)
    hits = [i for i, line in enumerate(lines) if line.startswith(name + '=') or line.startswith(name + ' = ')]
    assert len(hits) == 1, (name, hits)
    lines[hits[0]] = name + ' = ' + repr(value) + '\n'
    return ''.join(lines)


def functions(text):
    return {node.name: ast.dump(node, include_attributes=False)
            for node in ast.parse(text).body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}


def main():
    assert len(sys.argv) == 3 and sys.pycache_prefix is None
    request_ref = dict(path=sys.argv[1], sha256=sys.argv[2])
    request = bound(request_ref)
    assert request['receipt_kind'] == 'qualification-v12-fresh-control-construction-request'
    assert request['accepted_by_root'] is True and request['construction_authorized'] is True
    assert request['qualification'] is False and request['collection_authorized'] is False
    assert request['held_excluded'] == [5004, 5006]
    lock = bound(request['actual_source_lock_copy'])
    assert request['native_source_lock']['sha256'] == request['actual_source_lock_copy']['sha256']
    assert lock['origin_campaign'] == NATIVE_BASE + '/qualification-v12-source-inventory'
    assert lock['held_excluded'] == [5004, 5006]
    correctness = bound(request['actual_correctness_copy'])
    checks = bound(request['actual_checks_copy'])
    original_ref = dict(path=str(BASE / 'qualification-v9-selected-source-preparation-v1/checks.json'), sha256=ORIGINAL_CHECKS_SHA)
    original = bound(original_ref)
    assert checks['checks'][:30] == original['checks'] and checks['check_count'] == len(checks['checks']) == 46
    assert request['actual_checks_copy']['sha256'] == '4aa3a4c2ac28204ed1807292bee64a0a01b9b434ee32fd16940b8e7349c506b7'
    assert correctness['accepted_by_root'] is True and correctness['native_correctness_accepted'] is True
    assert correctness['original30_rows_preserved'] is True and correctness['commands'] == checks['check_count']
    assert correctness['additive_check_count'] == checks['check_count'] - 30 == 16
    assert correctness['checks_sha256'] == request['actual_checks_copy']['sha256']
    assert correctness['composition_sha256'] == request['fresh_composition_sha256']
    assert correctness['manifest_sha256'] == lock['manifest_sha256']
    assert lock['origin_correctness']['sha256'] == request['actual_correctness_copy']['sha256']
    assert correctness['variants'] == lock['pins']
    assert correctness['qualification'] is False and correctness['collection_authorized'] is False
    assert set(lock['source_paths']) == set(lock['pins']) == {'A', 'R', 'B'}
    out = Path(request['output'])
    assert out.parent == BASE and not out.exists() and not out.is_symlink()
    native_out = NATIVE_BASE + '/' + out.name
    assert request['native_source_lock']['path'] == native_out + '/v10-source-lock.json'
    assert set(request['native_helpers']) == {'source_export', 'builder', 'inventory', 'inventory_acceptor', 'correctness_checker', 'correctness_checks'}
    for ref in request['native_helpers'].values():
        assert set(ref) == {'path', 'sha256'} and ref['path'].startswith(NATIVE_BASE + '/')
        assert re.fullmatch('[0-9a-f]{64}', ref['sha256'])
    assert request['native_helpers']['correctness_checks']['sha256'] == request['actual_checks_copy']['sha256']
    assert sha(OLD / 'deployment-helpers-selection.json') == request['reviewed_original_sources']['deployment-helpers-selection.json']
    out.mkdir()
    original_sources = {}
    output_sources = {}

    def source(name):
        p = OLD / name
        assert sha(p) == request['reviewed_original_sources'][name]
        original_sources[str(p)] = sha(p)
        return p.read_text()

    def put(name, text, original_name):
        compile(text, str(out / name), 'exec')
        with (out / name).open('x') as stream:
            stream.write(text)
        with (out / (name + '.diff')).open('x') as stream:
            stream.writelines(difflib.unified_diff((OLD / original_name).read_text().splitlines(True), text.splitlines(True), fromfile=str(OLD / original_name), tofile=str(out / name)))
        output_sources[name] = sha(out / name)
        return output_sources[name]

    pins = {r: (v['head'], v['tree']) for r, v in lock['pins'].items()}
    lock_sha = request['native_source_lock']['sha256']
    app = source('v10_applicability.py')
    app = one(app, OLD_ROOT, NEW_ROOT)
    app = one(app, "tracked_export(PROVENANCE_BASE/('source-qualification-v9-'+role), tree)", "tracked_export(Path(lock['source_paths'][role]), tree)")
    app = one(app, OLD_LOCK_SHA, lock_sha)
    app_sha = put('v10_applicability.py', app, 'v10_applicability.py')
    binder = source('bind-prospective-v10-v1.py')
    binder = one(binder, OLD_ROOT, NEW_ROOT)
    binder = assignment(binder, 'PINS', pins)
    binder = assignment(binder, 'PARENTS', request['normal_B_merge_parents'])
    binder = one(binder, "correctness['commands']==30", "correctness['commands']==" + str(checks['check_count']))
    binder = one(binder, "assert correctness['original26_rows_preserved'] is True and correctness['additive_affected_current_main_checks']==4", "assert correctness['original30_rows_preserved'] is True and correctness['additive_check_count']==" + str(checks['check_count'] - 30))
    binder = one(binder, '9a58d370032bda9765926ff3df5a68d7836f95f7ed0aa8a8a0710c9b2e59ccf3', request['fresh_composition_sha256'])
    binder = one(binder, ORIGINAL_CHECKS_SHA, request['actual_checks_copy']['sha256'])
    assert functions(binder)['original_calibration_selection'] == functions((OLD / 'bind-prospective-v10-v1.py').read_text())['original_calibration_selection']
    binder_sha = put('bind-prospective-v10-v1.py', binder, 'bind-prospective-v10-v1.py')
    helpers = json.loads((OLD / 'deployment-helpers-selection.json').read_bytes())
    for role, ref in request['native_helpers'].items():
        helpers[role] = [Path(ref['path']).name, ref['sha256']]
    helpers['reuse_lock'] = ['v10-source-lock.json', lock_sha]
    helpers['reuse_applicability'][1] = app_sha
    helpers['binder'][1] = binder_sha
    for role, name in (('R_controller', 'r-collection-controller.py'), ('B_controller', 'qualification-v10-collection-controller.py')):
        original_text = source(name)
        text = one(original_text, OLD_ROOT, NEW_ROOT)
        assert functions(text) == functions(original_text), 'original controller implementation changed'
        helpers[role][1] = put(name, text, name)
    with (out / 'v10-source-lock.json').open('xb') as stream:
        stream.write(Path(request['actual_source_lock_copy']['path']).read_bytes())
    with (out / 'deployment-helpers-selection.json').open('x') as stream:
        json.dump(helpers, stream, indent=2)
        stream.write('\n')
    expected_paths = {r: request['native_helpers'][r]['path'] if r in request['native_helpers'] else
                      NATIVE_BASE + '/qualification-v10-source-preparation-v2/' + v[0] if r == 'post_calibration_seam' else
                      native_out + '/' + v[0] for r, v in helpers.items()}
    context = source('prepare-root-source-context-v1.py')
    context = one(context, OLD_ROOT, NEW_ROOT)
    context = one(context, OLD_LOCK_SHA, lock_sha)
    context = one(context, 'ca4b9223e0869c0408cfb78aaf419e6cbe6d0b95fc58f900ee570711c13c2550', app_sha)
    put('prepare-root-source-context-v1.py', context, 'prepare-root-source-context-v1.py')
    stage = source('stage-reused-runtime-readback-v1.py')
    stage = one(stage, "OLD=BASE/'qualification-v9'", "OLD=BASE/'qualification-v12-source-inventory'")
    stage = one(stage, OLD_ROOT, NEW_ROOT)
    stage = one(stage, "LOCK=PACK/'v10-source-lock.json'", "LOCK=SOURCE_HERE/'v10-source-lock.json'")
    stage = one(stage, OLD_LOCK_SHA, lock_sha)
    stage = one(stage, 'ca4b9223e0869c0408cfb78aaf419e6cbe6d0b95fc58f900ee570711c13c2550', app_sha)
    stage = one(stage, "app.tracked_export(BASE/('source-qualification-v9-'+role),tree)", "app.tracked_export(Path(lock['source_paths'][role]),tree)")
    put('stage-reused-runtime-readback-v1.py', stage, 'stage-reused-runtime-readback-v1.py')
    verifier = source('verify-qualification-v10-deployment-v1.py')
    verifier = one(verifier, OLD_ROOT, NEW_ROOT)
    verifier = assignment(verifier, 'PINS', pins)
    verifier = assignment(verifier, 'HELPERS', {k: tuple(v) for k, v in helpers.items()})
    old_paths = "        if role in ('binder','R_controller','B_controller','reuse_applicability'):\n            assert path == SOURCE_HERE/name, 'wrong selected fresh helper directory'\n        elif role in ('reuse_lock','post_calibration_seam'):\n            assert path == base/'qualification-v10-source-preparation-v2'/name, 'wrong immutable v10 helper directory'"
    verifier = one(verifier, old_paths, "        assert str(path) == " + repr(expected_paths) + "[role], 'wrong exact selected fresh helper path'")
    put('verify-qualification-v10-deployment-v1.py', verifier, 'verify-qualification-v10-deployment-v1.py')
    guard_name = 'global54-artifact-guard-v12-operational-v1.py'
    guard = source('global54-artifact-guard-v11-operational-v1.py')
    guard = one(guard, OLD_ROOT, NEW_ROOT)
    guard = assignment(guard, 'MANIFEST', lock['manifest_sha256'])
    guard = assignment(guard, 'COMPOSITION', request['fresh_composition_sha256'])
    line = next(line for line in guard.splitlines() if line.startswith('    current_sources = '))
    current_names = ['v10_applicability.py', 'bind-prospective-v10-v1.py', 'qualification-v10-collection-controller.py', 'r-collection-controller.py', 'verify-qualification-v10-deployment-v1.py', 'deployment-helpers-selection.json']
    guard = one(guard, line, '    current_sources = ' + repr({name: sha(out / name) for name in current_names}))
    put(guard_name, guard, 'global54-artifact-guard-v11-operational-v1.py')
    driver = source('collection-native-driver-v11-v1.py')
    driver = one(driver, OLD_ROOT, NEW_ROOT)
    old_paths = "        assert selected['path']==str(SELECTED/name) if role in ('binder','R_controller','B_controller','reuse_applicability') else True\n        assert selected['path']==str(IMMUTABLE_SELECTED/name) if role in ('reuse_lock','post_calibration_seam') else True"
    driver = one(driver, old_paths, "        assert selected['path']==" + repr(expected_paths) + "[role], 'wrong exact fresh helper path'")
    driver = one(driver, "collection-driver-'+phase+'-v11", "collection-driver-'+phase+'-v12")
    driver = one(driver, 'global54-artifact-guard-v11-operational-v1.py', guard_name)
    assert functions(driver)['commands'] == functions((OLD / 'collection-native-driver-v11-v1.py').read_text())['commands']
    put('collection-native-driver-v12-v1.py', driver, 'collection-native-driver-v11-v1.py')
    result = dict(schema=1, receipt_kind='qualification-v12-fresh-control-construction-observation',
                  source_only=True, accepted_by_root=False, qualification=False, collection_authorized=False,
                  native_commands=0, request=request_ref, original_sources=original_sources,
                  output_sources={str(out / name): digest for name, digest in output_sources.items()},
                  unchanged_controller_function_ASTs=True, unchanged_native_matrix_AST=True,
                  unchanged_original_calibration_selection_AST=True, expected_native_helper_paths=expected_paths,
                  held_excluded=[5004, 5006])
    result['output_sources'][str(out / 'v10-source-lock.json')] = sha(out / 'v10-source-lock.json')
    result['output_sources'][str(out / 'deployment-helpers-selection.json')] = sha(out / 'deployment-helpers-selection.json')
    with (out / 'construction-observation.json').open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(observation=str(out / 'construction-observation.json'), sha256=sha(out / 'construction-observation.json'), qualification=False)))


if __name__ == '__main__':
    main()
