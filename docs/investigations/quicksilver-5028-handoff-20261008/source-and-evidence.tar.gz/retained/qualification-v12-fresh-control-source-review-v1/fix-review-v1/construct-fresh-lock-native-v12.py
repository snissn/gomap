"""Bind accepted fresh foundation evidence and unchanged closed fixture provenance.

CLI: REQUEST SHA256. Reads files only; never opens a DB or grants collection.
The lock output is an unaccepted source observation, exclusively written.
"""
if not __debug__:
    raise RuntimeError('source construction requires assertions')
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time

ROOT = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
FOUNDATION = ROOT / 'qualification-v12-source-inventory'
CAMPAIGN = ROOT / 'qualification-v12-refresh/qualification-v10'
HISTORICAL_LOCK = ROOT / 'qualification-v10-source-preparation-v2/v10-source-lock.json'
HISTORICAL_LOCK_SHA = 'fa4b316bcf5eca0f8141be9c99fbf57777e386196a83b9599966d802af10677e'
ORIGINAL_CHECKS_SHA = '42142c3ff8fecf98ff14eed6c394093d906001d09d5bfb2ab6a895d065aa866c'
FRESH_CHECKS_SHA = '4aa3a4c2ac28204ed1807292bee64a0a01b9b434ee32fd16940b8e7349c506b7'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for raw in iter(lambda: stream.read(1 << 20), b''):
            h.update(raw)
    return h.hexdigest()


def bound(ref):
    assert set(ref) == {'path', 'sha256'}
    p = Path(ref['path'])
    assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve(strict=True) == p
    assert re.fullmatch('[0-9a-f]{64}', ref['sha256']) and sha(p) == ref['sha256']
    return json.loads(p.read_bytes())


def main():
    assert len(sys.argv) == 3 and sys.pycache_prefix is None
    request_ref = dict(path=sys.argv[1], sha256=sys.argv[2])
    request = bound(request_ref)
    assert request['receipt_kind'] == 'qualification-v12-fresh-lock-construction-request'
    assert request['accepted_by_root'] is True and request['construction_authorized'] is True
    assert request['qualification'] is False and request['collection_authorized'] is False
    assert request['held_excluded'] == [5004, 5006]
    inventory_ref = request['inventory']
    assert inventory_ref['path'] == str(FOUNDATION / 'inventory-complete.json')
    inventory = bound(inventory_ref)
    assert inventory['accepted_by_root'] is True and inventory['qualification'] is False and inventory['performance_runs'] == 0
    content_ref = dict(path=inventory['actual_content_acceptance_path'], sha256=inventory['actual_content_acceptance_sha256'])
    content = bound(content_ref)
    assert content['accepted_by_root'] is True and content['collection_authorized'] is False and content['qualification'] is False
    assert content['complete_compiler_input_contents_accepted'] is True
    assert content['actual_receipt_contents_accepted'] == {r: True for r in ('source', 'build', 'native', 'runner')}
    basis = bound(request['source_basis'])
    basis_acceptance = bound(request['source_basis_acceptance'])
    assert basis['accepted_by_root'] is False and basis_acceptance['accepted_by_root'] is True
    assert basis_acceptance['source_basis'] == request['source_basis']
    assert basis_acceptance['variants'] == basis['exact_variants'] == content['variants']
    assert basis_acceptance['reviewed_bindings'] == basis['review_bindings']
    assert basis_acceptance['held_excluded'] == basis['held_excluded'] == [5004, 5006]
    assert basis_acceptance['qualification'] is False and basis_acceptance['collection_authorized'] is False
    freeze = bound(request['source_freeze'])
    correctness = bound(request['correctness'])
    composition = bound(request['composition'])
    checks = bound(request['checks'])
    original_checks = bound(request['original_checks'])
    assert request['checks']['sha256'] == FRESH_CHECKS_SHA
    assert request['original_checks']['sha256'] == ORIGINAL_CHECKS_SHA
    assert checks['checks'][:30] == original_checks['checks'] and len(original_checks['checks']) == 30
    assert checks['check_count'] == len(checks['checks']) == 46
    assert freeze['accepted_by_root'] is True and freeze['qualification'] is False and freeze['collection_authorized'] is False
    assert freeze['variants'] == basis['exact_variants'] and freeze['held_excluded'] == [5004, 5006]
    assert freeze['b_normal_merge_parents'] == basis['normal_merge_parents']['B']
    assert inventory['source_basis'] == content['source_basis'] == freeze['source_basis'] == request['source_basis']
    assert content['source_basis_acceptance'] == freeze['source_basis_acceptance'] == request['source_basis_acceptance']
    assert correctness['accepted_by_root'] is True and correctness['native_correctness_accepted'] is True
    assert correctness['qualification'] is False and correctness['collection_authorized'] is False and correctness['performance_accepted'] is False
    assert correctness['variants'] == basis['exact_variants'] and correctness['held_excluded'] == [5004, 5006]
    assert correctness['original30_rows_preserved'] is True
    assert correctness['inventory_actual_content_acceptance_sha256'] == content_ref['sha256']
    assert correctness['commands'] == 46 and correctness['additive_check_count'] == 16
    assert correctness['checks_sha256'] == request['checks']['sha256']
    observed_correctness = bound(request['correctness_observation'])
    assert observed_correctness['accepted_by_root'] is False and observed_correctness['rc'] == 0
    assert observed_correctness['qualification'] is False and observed_correctness['collection_authorized'] is False
    assert observed_correctness['root_content_acceptance_sha256'] == content_ref['sha256']
    assert correctness['files'][request['correctness_observation']['path']] == request['correctness_observation']['sha256']
    for field in ('variants', 'commands', 'additive_check_count', 'checks_sha256', 'composition_sha256', 'manifest_sha256'):
        assert observed_correctness[field] == correctness[field]
    manifest_path = FOUNDATION / 'manifest.json'
    manifest_sha = sha(manifest_path)
    manifest = json.loads(manifest_path.read_bytes())
    assert inventory['manifest_sha256'] == content['manifest_sha256'] == correctness['manifest_sha256'] == manifest_sha
    assert len(manifest['sources']) == 8 and len(manifest['libraries']) == 16
    assert manifest['sources'] == content['sources'] and manifest['libraries'] == content['libraries']
    assert set(manifest['receipts']) == {'source', 'build', 'native', 'runner'}
    source = bound(dict(path=str(FOUNDATION / manifest['receipts']['source']['path']), sha256=manifest['receipts']['source']['sha256']))
    build = bound(content['build_complete'])
    assert build['status'] == 'BUILD_COMPLETE_STOP_BEFORE_MEASUREMENT' and build['accepted_by_root'] is False
    assert build['qualification'] is False and build['collection_authorized'] is False and build['performance_runs'] == 0
    assert content['build_complete']['sha256'] == content['build_complete_sha256'] == inventory['build_complete_sha256']
    assert source['received_composition'] == composition
    assert source['composition_sha256'] == build['composition_sha256'] == correctness['composition_sha256'] == request['composition']['sha256']
    assert build['source_freeze_sha256'] == request['source_freeze']['sha256']
    assert composition['accepted_by_root'] is True and composition['landed_harness_attested'] is True
    assert {r: dict(head=v['accepted_head'], tree=v['tree']) for r, v in composition['variants'].items()} == basis['exact_variants']
    pins = basis['exact_variants']
    for role, pin in pins.items():
        for slot in (role, role + '_unified'):
            source = manifest['sources'][slot]
            assert (source['head'], source['tree'], source['built_against_head']) == (pin['head'], pin['tree'], pin['head'])
    old = bound(dict(path=str(HISTORICAL_LOCK), sha256=HISTORICAL_LOCK_SHA))
    # Historical fixtures and their complete producer provenance are retained.
    # Current product/runtime inventories, correctness, timing, RSS and
    # acceptance times are fresh and never supplied by that provenance.
    harness = old['runtime_harness']
    harness_basis = bound(basis['review_bindings']['selected_harness'])
    assert set(harness_basis['python_files']) == {v['path'] for v in harness.values()}
    for binding in harness.values():
        observed = harness_basis['python_files'][binding['path']]
        assert (binding['mode'], binding['blob'], binding['sha256']) == (observed['mode'], observed['blob'], observed['sha256'])
        p = ROOT / 'source-qualification-v10-common-H' / binding['path']
        assert p.is_file() and not p.is_symlink() and sha(p) == binding['sha256']
        assert ('100755' if p.stat().st_mode & 0o111 else '100644') == binding['mode']
    assert len(old['fixtures']) == 5
    for fixture in old['fixtures']:
        receipt = bound(fixture['receipt'])
        assert receipt == fixture['original_receipt'] and receipt['closed'] is True and receipt['verified'] is True
    assert old['go_tool'] == request['go_tool']
    assert sha(old['go_tool']['path']) == old['go_tool']['sha256']
    original_files = {}

    def record(path, expected):
        p = Path(path)
        assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve(strict=True) == p
        assert sha(p) == expected and (path not in original_files or original_files[path] == expected)
        original_files[path] = expected

    historical_provenance = old['original_actual_files']
    assert historical_provenance
    for fixture in old['fixtures']:
        receipt = fixture['original_receipt']
        for field in ('oracle_run', 'oracle_stdout'):
            assert historical_provenance[receipt[field]] == receipt[field + '_sha256']
    # Preserve the reviewed full producer/raw/source closure rather than
    # guessing which transitive fixture provenance can be discarded. The
    # ordinary app/stage rehash original_actual_files, so these bytes remain
    # checked even though they grant no fresh runtime acceptance.
    for path, digest in historical_provenance.items():
        record(path, digest)
    record(str(HISTORICAL_LOCK), HISTORICAL_LOCK_SHA)
    refs = [request_ref, inventory_ref, content_ref, content['build_complete'], request['source_basis'], request['source_basis_acceptance'], request['source_freeze'], request['correctness'], request['correctness_observation'], request['composition'], request['checks'], request['original_checks']]
    refs += list(basis['tracked_manifests'].values()) + list(basis['review_bindings'].values())
    for ref in refs:
        record(ref['path'], ref['sha256'])
    for owner in (content, correctness, freeze):
        for path, digest in owner['files'].items():
            record(path, digest)
    record(str(manifest_path), manifest_sha)
    for role, ref in manifest['receipts'].items():
        p = FOUNDATION / ref['path']
        record(str(p), ref['sha256'])
        assert content['receipt_sha256'][role] == ref['sha256']
    required = {}
    for source in manifest['sources'].values():
        original = FOUNDATION / 'bin' / source['binary']
        assert original.is_file() and not original.is_symlink() and original.stat().st_mode & 0o111
        assert sha(original) == source['binary_sha256']
        for campaign in (FOUNDATION, CAMPAIGN):
            required[str(campaign / 'bin' / source['binary'])] = source['binary_sha256']
    required[old['go_tool']['path']] = old['go_tool']['sha256']
    for path, library in manifest['libraries'].items():
        assert str(Path(path).resolve(strict=True)) == library['resolved'] and sha(path) == library['sha256']
        required[path] = library['sha256']
    for binding in harness.values():
        required[str(ROOT / 'source-qualification-v10-common-H' / binding['path'])] = binding['sha256']
    assert len(required) == 36, 'original eight-binary/two-location, tool, sixteen-library and three-collector closure'
    assert set(request['source_paths']) == {'A', 'R', 'B'}
    for role, path in request['source_paths'].items():
        p = Path(path)
        assert p == ROOT / ('source-qualification-v12-' + role) and p.is_dir() and not p.is_symlink()
        tree = bound(basis['tracked_manifests'][role])
        assert (tree['head'], tree['tree']) == (pins[role]['head'], pins[role]['tree'])
    chronology = [basis_acceptance['accepted_ns'], freeze['accepted_ns'], build['completed_ns'], inventory['created_ns'], content['accepted_ns'], inventory['content_accepted_ns'], observed_correctness['finished_ns'], correctness['accepted_ns']]
    assert all(type(value) is int and value > 0 for value in chronology)
    assert chronology == sorted(chronology) and chronology[-1] <= time.time_ns()
    latest = chronology[-1]
    lock = dict(schema=1, source_only=True, qualification=False, collection_authorized=False,
                candidate_h_head=pins['A']['head'], candidate_h_tree=pins['A']['tree'], pins=pins,
                h_changed_paths=[], runtime_harness=harness, manifest=manifest, manifest_sha256=manifest_sha,
                origin_campaign=str(FOUNDATION), origin_inventory=inventory_ref,
                origin_source_freeze=request['source_freeze'], origin_correctness=request['correctness'],
                source_basis=request['source_basis'], source_basis_acceptance=request['source_basis_acceptance'],
                original_actual_files=original_files, tracked_manifests=basis['tracked_manifests'],
                source_paths=request['source_paths'], go_tool=old['go_tool'], required_current_files=required,
                fixtures=old['fixtures'], latest_origin_accepted_ns=latest, held_excluded=[5004, 5006],
                construction_request=request_ref, compiler_input_contents_accepted=True,
                composition=request['composition'], checks=request['checks'], correctness_observation=request['correctness_observation'],
                historical_runtime_results_reused=False, closed_fixture_compatibility_accepted=False,
                historical_fixture_provenance_files=historical_provenance,
                historical_provenance_is_not_current_source_or_qualification=True)
    output = Path(request['output'])
    assert output.parent == ROOT / 'qualification-v12-source-preparation-v1' and not os.path.lexists(output)
    output.parent.mkdir(exist_ok=False)
    with output.open('x') as stream:
        json.dump(lock, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(receipt_kind='qualification-v12-fresh-lock-construction-observation',
                          lock=dict(path=str(output), sha256=sha(output)), accepted_by_root=False,
                          qualification=False, collection_authorized=False, database_opens=0)))


if __name__ == '__main__':
    main()
