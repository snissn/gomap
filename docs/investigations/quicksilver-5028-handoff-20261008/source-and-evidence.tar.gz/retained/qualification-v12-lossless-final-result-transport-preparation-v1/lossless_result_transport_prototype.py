"""SOURCE-ONLY PROTOTYPE. No CLI, native launcher, acceptance, or state writes.

Root must separately adopt transport/capture callbacks and new exclusive labels.
Complete original byte streams are retained; small indexes are never substitutes.
"""
import gzip
import hashlib
import json
from pathlib import Path
import time

CHUNK = 1 << 20
NROOT = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = NROOT/'qualification-v12-refresh/qualification-v10'
CHECKER_SHA = 'aee4bc7d1784c1ee4e6adb3d4e899a6fdaa86d3a21ba7a08c4c6d838ff99e8ee'
IDS = {'service.'+p+'.'+f
       for p in ('quicksilver_hits','quicksilver_misses','quicksilver_mixed','quicksilver_concurrent')
       for f in ('process_bytes_per_op','process_allocs_per_op')}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def authority_false():
    return dict(accepted_by_root=False, raw_contents_accepted=False,
                qualification=False, performance_accepted=False,
                collection_authorized=False, candidate_pairs_authorized=False,
                merge_authorized=False, analysis_authorized=False)


def canonical_file(path):
    p = Path(path)
    require(p.is_absolute() and p.is_file() and not p.is_symlink()
            and p.resolve(strict=True) == p, 'canonical nonsymlink regular file required')
    return p


def exact_ref(ref):
    require(set(ref) == {'path','sha256'} and isinstance(ref['path'],str)
            and isinstance(ref['sha256'],str) and len(ref['sha256']) == 64
            and all(c in '0123456789abcdef' for c in ref['sha256']), 'exact reference required')


def stream_identity(stream):
    digest = hashlib.sha256()
    size = 0
    for block in iter(lambda: stream.read(CHUNK), b''):
        digest.update(block)
        size += len(block)
    return dict(bytes=size, sha256=digest.hexdigest())


def compress_stream(incoming, outgoing):
    """Lossless arbitrary bytes; no JSON projection, whitespace or key rewrite."""
    digest = hashlib.sha256()
    size = 0
    with gzip.GzipFile(fileobj=outgoing, mode='wb', filename='', mtime=0, compresslevel=1) as zipped:
        for block in iter(lambda: incoming.read(CHUNK), b''):
            digest.update(block)
            size += len(block)
            zipped.write(block)
    return dict(bytes=size, sha256=digest.hexdigest())


def verify_stream(incoming, record):
    """Verify BOTH compressed identity and complete decompressed canonical bytes."""
    incoming.seek(0)
    require(stream_identity(incoming) == record['compressed_identity'], 'compressed byte drift')
    incoming.seek(0)
    with gzip.GzipFile(fileobj=incoming, mode='rb') as unzipped:
        require(stream_identity(unzipped) == record['raw_identity'], 'complete original byte drift')


def pack_one(reference, destination):
    """Future sender primitive; caller owns authorization and exclusive destination."""
    exact_ref(reference)
    source = canonical_file(reference['path'])
    target = Path(destination)
    require(target.is_absolute() and target.resolve() == target and not target.exists()
            and not target.is_symlink(), 'new canonical exclusive archive required')
    parent = target.parent
    require(parent.is_dir() and not parent.is_symlink() and parent.resolve(strict=True) == parent,
            'canonical existing archive parent required')
    started = time.time_ns()
    with source.open('rb') as incoming, target.open('xb') as outgoing:
        raw = compress_stream(incoming, outgoing)
    require(raw['sha256'] == reference['sha256'], 'sender original SHA drift')
    require(canonical_file(reference['path']) == source, 'sender path relation drift')
    with source.open('rb') as incoming:
        require(stream_identity(incoming) == raw, 'sender bytes changed during compression')
    with target.open('rb') as incoming:
        compressed = stream_identity(incoming)
    record = dict(source_reference=reference, archive_path=str(target),
                  raw_identity=raw, compressed_identity=compressed,
                  packing_started_ns=started, packing_finished_ns=time.time_ns())
    verify_archive(record, reference)
    return record


def verify_archive(record, expected_reference):
    exact_ref(expected_reference)
    require(record['source_reference'] == expected_reference
            and record['raw_identity']['sha256'] == expected_reference['sha256'], 'external reference drift')
    path = canonical_file(record['archive_path'])
    with path.open('rb') as incoming:
        verify_stream(incoming, record)
    return path


def complete_json(record, expected_reference):
    """At most one file parsed here. json semantics intentionally match frozen script."""
    path = verify_archive(record, expected_reference)
    with gzip.open(path, 'rb') as incoming:
        value = json.load(incoming)
    # A further archive/byte check retains drift detection around the parse.
    verify_archive(record, expected_reference)
    return value


def result_refs(actual):
    """Same exact role/key joins as frozen stage4, without a result-body aggregate."""
    for key in ('qualification','performance_accepted','collection_authorized',
                'candidate_pairs_authorized','merge_authorized'):
        require(actual[key] is False, 'forbidden authority')
    require(actual['status'] == 'ACTUAL_ORIGINAL_FULL54_THEN_SEPARATE_STRICT19_JOINED_PRODUCT_DECISION_PENDING',
            'original54/strict19 genuine joined predecessor required')
    require(actual['original_pair_count'] == actual['state_specific_guard_count'] == 114, 'original raw scope drift')
    require(set(actual['original_evaluations']) == {'B','R'}
            and len(actual['original_evaluations']['B']) == 36
            and len(actual['original_evaluations']['R']) == 18
            and len(actual['separate_strict_proofs']) == 19, 'complete73 scope drift')
    refs = {'original-'+role+'-'+name:ref for role,rows in actual['original_evaluations'].items()
            for name,ref in rows.items()}
    for item in actual['separate_strict_proofs']:
        key = 'strict-'+item['role']+'-'+Path(item['bundle']['path']).name
        require(key not in refs, 'duplicate strict proof identity')
        refs[key] = item['proof']
    require(len(refs) == 73, 'complete73 identity drift')
    for ref in refs.values():
        exact_ref(ref)
    return refs


def read_complete73(actual, export):
    """export must supply a joined, root-bound sender/transfer receipt and local archive.

    Root callback contract: exclusive canonical sender/receiver files, no retry,
    exact source bytes, rc0/empty stderr, binding inner/outer argv/start/finish,
    complete transfer size/hash, and frozen predecessor/source acceptance.
    Receipt validation and actual execution are intentionally NOT invented here.
    """
    refs = result_refs(actual)
    rows = {}
    for key,reference in refs.items():
        record, receipt_reference = export(key, reference)
        exact_ref(receipt_reference)
        value = complete_json(record, reference)  # Complete parse, never a header/summary read.
        require(isinstance(value,dict) and value['qualification'] is False, 'result shape/authority drift')
        del value
        rows[key] = dict(reference=reference, archive=record, transport_receipt=receipt_reference)
    return dict(schema=1,status='COMPLETE73_TRANSPORT_CONTENT_REVIEW_PENDING',records=rows,
                complete_body_count=73,held_excluded=[5004,5006],**authority_false())


def allocation_names(actual):
    B = actual['original_evaluations']['B']
    names = sorted(name for name in B if name.endswith('-service-final'))
    online = ['online-primary-n'+str(n) for n in (30000,300000,3000000)]
    require(len(names) == 13 and all(name in B for name in online), 'B13 service + fresh online3 required')
    names += online
    require(len(names) == len(set(names)) == 16, 'B16 identities')
    return names


def allocation_argv(name, original_ref, anchor):
    ep = Path(original_ref['path'])
    require(ep.parent == ROOT/'analysis-global-original-v1'
            and ep.name == name+'.evaluation.json', 'exact original B result path')
    bundle = ep.with_name(name+'.bundle.json')
    return ['python3','-B',str(NROOT/'qualification-v3-policy-preparation/allocation_accounting.py'),
            str(bundle),'--anchor',anchor['path'],'--anchor-sha256',anchor['sha256']]


def complete_numeric_equal(original, replay_numerical, now):
    require(0 < original['created_ns'] < replay_numerical['created_ns'] < now, 'original/replay chronology')
    left = {k:v for k,v in original.items() if k not in ('root_acceptance_required','created_ns')}
    right = {k:v for k,v in replay_numerical.items() if k != 'created_ns'}
    require(left == right, 'complete original numeric/provenance drift')


def checked_ledger(entries):
    require(len(entries) == 8 and {entry['id'] for entry in entries} == IDS, 'eight exact allocation entries required')
    return entries


def ledger_view(entries):
    """Bounded dispositions/cross-products only; NEVER complete ledger entries."""
    checked_ledger(entries)
    views = []
    for entry in entries:
        require(entry['status'] in ('checked','unmet')
                and type(entry['allocation_guard_met']) is bool, 'entry disposition shape')
        original = entry['original_numerical']
        require(original['status'] in ('evaluated','unknown'), 'original numerical disposition')
        view = dict(id=entry['id'],status=entry['status'],
                    allocation_guard_met=entry['allocation_guard_met'],
                    original_numerical_status=original['status'])
        if entry['status'] == 'checked':
            for key in ('exact_nonincrease_observed','zero_spread_supplement_eligible'):
                require(type(entry[key]) is bool, 'checked scalar shape')
                view[key] = entry[key]
            require(len(entry['pairs']) == 3, 'three bounded pair views')
            pairs = []
            for i,pair in enumerate(entry['pairs'],1):
                require(type(pair['pair']) is int and pair['pair'] == i, 'pair order')
                counters = {}
                for side in ('A','B'):
                    n,ops = pair[side]['numerator'],pair[side]['ops']
                    require(type(n) is int and 0 <= n <= 2**64-1
                            and type(ops) is int and 0 < ops <= 2**63-1, 'frozen Go counter bounds')
                    counters[side] = dict(numerator=n,ops=ops)
                left = counters['B']['numerator']*counters['A']['ops']
                right = counters['A']['numerator']*counters['B']['ops']
                require(type(pair['B_num_times_A_ops']) is int
                        and type(pair['A_num_times_B_ops']) is int
                        and pair['B_num_times_A_ops'] == left
                        and pair['A_num_times_B_ops'] == right
                        and type(pair['observed_nonincrease']) is bool
                        and pair['observed_nonincrease'] == (left <= right), 'full-entry cross-product drift')
                pairs.append(dict(pair=i,**counters,B_num_times_A_ops=left,
                                  A_num_times_B_ops=right,observed_nonincrease=pair['observed_nonincrease']))
            view['pair_views'] = pairs
        views.append(view)
    require(len(json.dumps(views,separators=(',',':')).encode()) <= 16384,
            'bounded ledger view exceeded')
    return views


def ledger_reference(record, pointer, entries):
    require(pointer in ('/accounting_ledger','/allocation_ledger'), 'exact full ledger pointer')
    return dict(complete_archive=record,json_pointer=pointer,
                disposition_views=ledger_view(entries),
                complete_entries_embedded=False)


def verify_ledger_reference(reference):
    """Re-open verified complete content and cross-check every extracted view."""
    record = reference['complete_archive']
    value = complete_json(record,record['source_reference'])
    pointer = reference['json_pointer']
    require(pointer in ('/accounting_ledger','/allocation_ledger'), 'exact full ledger pointer')
    entries = checked_ledger(value[pointer[1:]])
    require(reference['complete_entries_embedded'] is False
            and ledger_view(entries) == reference['disposition_views'], 'view/full entry drift')
    return reference['disposition_views']


def replay_B16_and_read_R6(actual, anchors, index, run_exact):
    """run_exact(argv,name,CHECKER_SHA) is a ROOT-OWNED future adapter, never invoked here.

    It must execute each exact argv once, unchanged frozen checker/raw/math; retain
    complete canonical stdout/stderr and joined inner/outer receipts; return
    (complete-gzip-stdout-record, producer receipt, producer receipt reference,
    compressed transport receipt, compressed transport receipt reference).
    It must verify checker SHA, all native predecessor gates and source identity.
    Small rows intentionally reference complete stdout instead of copying numerical.
    """
    require(set(index['records']) == set(result_refs(actual)), 'complete73 index substitution')
    B = actual['original_evaluations']['B']
    rows = {}
    for name in allocation_names(actual):
        original_ref = B[name]
        argv = allocation_argv(name, original_ref, anchors['B'])
        record,receipt,receipt_ref,transport,transport_ref = run_exact(argv,name,CHECKER_SHA)
        exact_ref(receipt_ref)
        exact_ref(transport_ref)
        require(receipt['native_argv'] == argv and receipt['rc'] == 0
                and receipt['stderr']['bytes'] == 0
                and receipt['stderr']['sha256'] == hashlib.sha256(b'').hexdigest()
                and 0 < receipt['started_ns'] < receipt['finished_ns'] <= time.time_ns(),
                'actual allocation argv/join/chronology/stderr drift')
        require(transport['rc'] == 0 and transport['stderr']['bytes'] == 0
                and transport['stderr']['sha256'] == hashlib.sha256(b'').hexdigest()
                and 0 < transport['started_ns'] < transport['finished_ns'] <= time.time_ns()
                and record['compressed_identity'] == {k:transport['stdout'][k] for k in ('bytes','sha256')}
                and record['archive_path'] == transport['stdout']['path'], 'compressed transfer receipt drift')
        require(record['raw_identity'] == {k:receipt['stdout'][k] for k in ('bytes','sha256')}
                and record['source_reference']['path'] == receipt['stdout']['path'], 'complete stdout receipt drift')
        result = complete_json(record, record['source_reference'])
        require(result['status'] == 'prospective_accounting_artifact_only'
                and result['qualification'] is False, 'allocation result status')
        entries = checked_ledger(result['accounting_ledger'])
        require(type(result['all_allocation_guards_met']) is bool
                and result['all_allocation_guards_met'] == all(e['allocation_guard_met'] is True for e in entries),
                'allocation aggregate/content drift')
        original = complete_json(index['records']['original-B-'+name]['archive'], original_ref)
        complete_numeric_equal(original, result['numerical'], time.time_ns())
        rows[name] = dict(original_reference=original_ref,complete_result=record,native_execution=receipt_ref,
                          compressed_transport=transport_ref,producer_raw_stdout=receipt['stdout'],
                          producer_native_argv=argv,producer_started_ns=receipt['started_ns'],
                          producer_finished_ns=receipt['finished_ns'],producer_rc=receipt['rc'],
                          final_anchor=anchors['B'],
                          accounting_ledger_reference=ledger_reference(record,'/accounting_ledger',entries))
        del original,result,entries
    R = actual['original_evaluations']['R']
    rnames = sorted(name for name in R if name.endswith('-service-final'))
    require(len(rnames) == 6, 'R6 inherited ledgers required; no standalone R replay')
    rrows = {}
    for name in rnames:
        original = complete_json(index['records']['original-R-'+name]['archive'],R[name])
        rrows[name] = dict(original_reference=R[name],
                           allocation_ledger_reference=ledger_reference(
                               index['records']['original-R-'+name]['archive'],
                               '/allocation_ledger',original['allocation_ledger']))
        del original
    entries = [e for row in rows.values()
               for e in row['accounting_ledger_reference']['disposition_views']]
    entries += [e for row in rrows.values()
                for e in row['allocation_ledger_reference']['disposition_views']]
    require(len(entries) == 176, 'all176 exact content')
    return dict(schema=1,status='ALL176_CONTENT_REVIEW_PENDING',B=rows,R=rrows,
                B_bundle_count=16,R_bundle_count=6,entry_count=176,
                met_entry_count=sum(e['allocation_guard_met'] is True for e in entries),
                all_allocation_guards_met=all(e['allocation_guard_met'] is True for e in entries),
                complete_ledger_entries_embedded=False,
                original_numerical_UNKNOWN_unmodified=True,held_excluded=[5004,5006],**authority_false())
