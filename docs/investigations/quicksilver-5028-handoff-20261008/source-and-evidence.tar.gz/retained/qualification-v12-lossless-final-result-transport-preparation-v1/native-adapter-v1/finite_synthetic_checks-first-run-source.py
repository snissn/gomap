"""Finite local synthetic-only checks; retained fixtures, no native/product inputs."""
from pathlib import Path
import copy
import hashlib
import json
import types

HERE = Path(__file__).resolve().parent


def load(path, name):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__)
    return module


def main():
    a = load(HERE/'native_lossless_stage4_adapter.py','synthetic_adapter')
    p = load(HERE.parent/'lossless_result_transport_prototype.py','synthetic_prototype')
    a.P = p
    fixture = HERE/'synthetic-fixtures-v1'
    fixture.mkdir()  # Exclusive one-shot finite fixture; preserve, never delete/reuse.
    out = fixture/'output'
    out.mkdir()
    checks = []
    def check(name, condition):
        assert condition,name
        checks.append(dict(name=name,passed=True))
    def rejects(name, function):
        try:
            function()
        except (ValueError,KeyError,TypeError,FileExistsError):
            check(name,True)
        else:
            raise AssertionError(name)
    source = fixture/'synthetic-original.json'
    value = dict(qualification=False,root_acceptance_required=True,created_ns=100,
        original_evidence=[dict(common_inventory='x'*10000)],
        ledger=[dict(id='synthetic',status='unknown',reason='EXACT UNKNOWN',
                     pairs=[dict(A=1,B=2)],support=dict(common_inventory='y'*10000))],
        allocation_ledger=[dict(id='synthetic',original_numerical=dict(status='unknown',
            reason='EXACT INNER UNKNOWN',support=dict(common_inventory='z'*10000)),pairs=[1,2,3])])
    source.write_bytes(json.dumps(value).encode())
    ref = a.reference(source)
    check('canonical exact source identity',a.bound(ref) == value)
    rejects('wrong source SHA rejected',lambda:a.bound(dict(path=ref['path'],sha256='0'*64)))
    rejects('extra reference keys rejected',lambda:a.verify_ref(dict(**ref,bytes=1)))
    rejects('relative source rejected',lambda:a.canonical('relative.json'))
    wrong_flags = {k:False for k in a.FLAGS};wrong_flags['merge_authorized']=True
    rejects('product authority rejected',lambda:a.flags(wrong_flags))
    adapter = a.Adapter(out,ref,{}, {'original-B-synthetic':ref},{})
    archive,operation_ref = adapter.export('original-B-synthetic',ref)
    operation = a.bound(operation_ref)
    check('archive receipt records actual function success',operation['rc']==0 and operation['process'] is False
          and operation['kind']=='native_archive_function_call' and operation['child_pid'] is None)
    check('archive receipt compressed identity matches actual file',
          operation['stdout']==a.identity(archive['archive_path']))
    check('archive function chronology',0 < operation['started_ns'] < operation['finished_ns'])
    parsed = adapter.observe_complete_json(archive,ref)
    check('complete bytes parsed without projection mutation',parsed == value)
    view = a.bound(adapter.observations['original-B-synthetic'])
    check('view explicitly projection',view['complete_result'] is False)
    projected = view['value_projection']
    check('exact UNKNOWN reason retained',projected['ledger'][0]['reason']=='EXACT UNKNOWN')
    check('pairs retained unchanged',projected['ledger'][0]['pairs']==value['ledger'][0]['pairs'])
    check('top provenance archive pointer',projected['original_evidence']['json_pointer']=='/original_evidence')
    check('individual support archive pointer',projected['ledger'][0]['support']['json_pointer']=='/ledger/0/support')
    check('nested original ledger support archive pointer',projected['allocation_ledger'][0]['original_numerical']['support']['json_pointer']=='/allocation_ledger/0/original_numerical/support')
    check('nested exact UNKNOWN reason retained',projected['allocation_ledger'][0]['original_numerical']['reason']=='EXACT INNER UNKNOWN')
    check('complete support recoverable',p.complete_json(archive,ref)['ledger'][0]['support']==value['ledger'][0]['support'])
    before = dict(adapter.observations)
    adapter.observe_complete_json(archive,ref)
    check('repeat full parse does not duplicate projections',adapter.observations==before)
    strict = dict(status='SEPARATE_PRODUCT_GUARD_PROOF_ONLY',qualification=False,
                  proofs=[dict(source_support=[dict(ops=7,samples=3)])],
                  not_applicable=[dict(id='synthetic',reason='EXACT UNKNOWN',guard_route='NOT_APPLICABLE')])
    check('bounded strict proof/not_applicable retained completely',
          a.numerical_projection(strict,archive)['value_projection']==strict)
    rejects('unexpected giant remaining view fails',lambda:a.write_json(out/'giant-rejected.json',
            a.numerical_projection(dict(other='q'*(a.VIEW_LIMIT+1)),archive),a.VIEW_LIMIT))
    rejects('existing output packet cannot be reused',lambda:a.write_json(out/'giant-rejected.json',{}))
    original = copy.deepcopy(value); replay = copy.deepcopy(value)
    original['created_ns']=1;replay['created_ns']=2;del replay['root_acceptance_required']
    p.complete_numeric_equal(original,replay,3)
    check('full numerical comparison preserves frozen exclusions',True)
    replay['original_evidence'][0]['common_inventory']='CHANGED'
    rejects('complete provenance drift still rejected',lambda:p.complete_numeric_equal(original,replay,3))
    ledger = [dict(id=k,status='unmet',allocation_guard_met=False,
                   original_numerical=dict(status='unknown',reason='UNCHANGED',support=value['original_evidence']))
              for k in sorted(p.IDS)]
    ledger_source = fixture/'synthetic-ledger.json'
    ledger_source.write_bytes(json.dumps(dict(accounting_ledger=ledger,allocation_ledger=ledger)).encode())
    ledger_ref = a.reference(ledger_source)
    ledger_archive = p.pack_one(ledger_ref,out/'synthetic-ledger.gz')
    for pointer in ('/accounting_ledger','/allocation_ledger'):
        lr = p.ledger_reference(ledger_archive,pointer,ledger)
        check('complete full pointer verification '+pointer,len(p.verify_ledger_reference(lr))==8)
        lr['disposition_views'][0]['allocation_guard_met']=True
        rejects('bounded disposition/full entry mismatch '+pointer,lambda lr=lr:p.verify_ledger_reference(lr))
    # Fake child only: no subprocess is executed, and no real checker bytes are imported.
    checker = fixture/'synthetic-checker-source.py'
    checker.write_bytes(b'# SYNTHETIC ONLY\n')
    a.CHECKER_SHA = a.reference(checker)['sha256']
    fake_argv = ['python3','-B',str(checker),'synthetic.bundle.json','--anchor','synthetic','--anchor-sha256','0'*64]
    p.allocation_argv = lambda *args:fake_argv
    child_calls = []
    class FakeChild:
        pid = 123456  # Explicit synthetic fixture; never a runtime PID claim.
        def __init__(self,argv,stdout,stderr):
            child_calls.append(argv)
            stdout.write(b'{"synthetic_complete_stdout":true}\n')
        def wait(self):
            return 0
    a.subprocess.Popen = FakeChild
    adapter.actual = dict(original_evaluations=dict(B=dict(synthetic=ref)))
    adapter.anchors = dict(B=ref)
    record,receipt,receipt_ref,archive_op,archive_op_ref = adapter.run_exact(fake_argv,'synthetic',a.CHECKER_SHA)
    check('synthetic producer exactly one argv call',child_calls==[fake_argv])
    check('synthetic producer join fields journalled',receipt['rc']==0 and receipt['child_pid']==123456
          and receipt['native_argv']==fake_argv and receipt['started_ns']<=receipt['spawned_ns']<=receipt['finished_ns'])
    check('producer raw identity distinct from compressed operation',receipt['stdout']==a.identity(receipt['stdout']['path'])
          and archive_op['stdout']==a.identity(record['archive_path'])
          and receipt_ref != archive_op_ref)
    rejects('repeat producer rejected before fake child launch',lambda:adapter.run_exact(fake_argv,'synthetic',a.CHECKER_SHA))
    check('failed duplicate does not launch another child',len(child_calls)==1)
    result = dict(schema=1,synthetic_only=True,actual_input_execution=False,
                  checks=checks,count=len(checks),fixture=str(fixture),**p.authority_false())
    a.write_json(HERE/'synthetic-check-results.json',result)
    print(json.dumps(dict(synthetic_checks=len(checks),actual_input_execution=False)))


if __name__ == '__main__':
    main()
