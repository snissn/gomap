"""Finite mocked-byte-store regression through actual predecessors(), no native inputs."""
from pathlib import Path
import copy
import hashlib
import json
import types

HERE = Path(__file__).resolve().parent


def main():
    def module(path,name):
        m=types.ModuleType(name);m.__file__=str(path)
        exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__)
        return m
    a=module(HERE/'native_lossless_stage4_adapter.py','synthetic_strict_adapter')
    p=module(HERE.parent/'lossless_result_transport_prototype.py','synthetic_strict_prototype')
    a.P=p
    store={};streams={};checks=[]
    def ref(path,value):
        digest=hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()
        r=dict(path=str(path),sha256=digest);store[r['path']]=(r,copy.deepcopy(value));return r
    def bound(r,*args):
        assert store[r['path']][0]==r,'synthetic exact byte-store reference mismatch'
        return copy.deepcopy(store[r['path']][1])
    def verify(r):
        assert store[r['path']][0]==r,'synthetic exact byte-store reference mismatch'
        return Path(r['path'])
    def limited_bound(r,limit=a.SMALL_LIMIT):
        value=bound(r)
        a.require(len(json.dumps(value).encode()) <= limit,'synthetic small-file limit')
        return value
    a.bound=limited_bound;a.complete_bound=bound;a.verify_ref=verify
    a.reference=lambda path:copy.deepcopy(store[str(path)][0])
    a.identity=lambda path:copy.deepcopy(streams[str(path)])
    ff={k:False for k in a.FLAGS}
    base=a.NROOT/'synthetic-only'
    evaluator=ref(base/'evaluator.py',{})
    evaluator['sha256']=a.EVALUATOR_SHA;store[evaluator['path']]=(evaluator,{})
    consumer=ref(base/'consumer.py',{})
    consumer['sha256']=a.STRICT_CONSUMER_SHA;store[consumer['path']]=(consumer,{})
    definition=ref(base/'definition.json',{})
    anchors={}
    for role in ('B','R'):
        value=dict(root=str(a.ROOT),definition=definition['path'],files={
            evaluator['path']:evaluator['sha256'],consumer['path']:consumer['sha256'],
            definition['path']:definition['sha256']})
        if role=='R':value.update(original_B_anchor=anchors['B']['path'],original_B_anchor_sha256=anchors['B']['sha256'])
        anchors[role]=ref(base/(role+'.anchor.json'),value)
    evaluations={};cores={};bundles={}
    for role,total,services in (('B',36,13),('R',18,6)):
        names=['synthetic-'+str(i)+'-service-final' for i in range(services)]
        names+=['synthetic-other-'+str(i) for i in range(total-services)]
        parent=a.ROOT/('analysis-global-original-v1' if role=='B' else 'ar-analysis-global-original-v1')
        evaluations[role]={}
        for name in names:
            core=dict(schema=1,status='artifact_diagnostic_only',qualification=False,created_ns=105,
                anchor_sha256=anchors[role]['sha256'],definition_sha256=definition['sha256'],
                calibration=['C1','C2','C3'],ledger=[dict(id='metric',status='unknown',reason='EXACT UNKNOWN')],
                original_evidence=[dict(guard=str(i),common_inventory='COMPLETE PROVENANCE') for i in range(9)])
            original=dict(core,root_acceptance_required=True)
            if role=='R':
                original.update(candidate_variant='R',allocation_ledger=[dict(id=k,status='unmet',allocation_guard_met=False,
                    original_numerical=dict(status='unknown',reason='EXACT ALLOCATION UNKNOWN')) for k in sorted(p.IDS)])
            evaluations[role][name]=ref(parent/(name+'.evaluation.json'),original)
            cores[role,name]=core
            bundle=ref(parent/(name+'.bundle.json'),dict(variant=role,metric_set='service_final_inplace',calibration=core['calibration'],metrics=['metric']))
            bundles[role,name]=bundle
            # Update same anchor fixture and digest references consistently before finalizing below.
            store[anchors[role]['path']][1]['files'][bundle['path']]=bundle['sha256']
    # Synthetic store pins denote identities; its fixtures deliberately avoid disk/native bytes.
    def execution(path,argv,start,end,stdout_value):
        so=ref(Path(str(path)+'.stdout'),stdout_value);se=ref(Path(str(path)+'.stderr'),{})
        streams[so['path']]=dict(**so,bytes=10)
        streams[se['path']]=dict(path=se['path'],sha256=a.EMPTY_SHA,bytes=0)
        return ref(path,dict(native_argv=argv,rc=0,started_ns=start,finished_ns=end,
            stdout=streams[so['path']],stderr=streams[se['path']]))
    content=ref(base/'content.json',dict(status='ACTUAL_FINAL_CONTENT_ONLY_ROOT_ACCEPTED',accepted_by_root=True,
        actual_final_contents_accepted=True,campaign_root=str(a.ROOT),held_excluded=[5004,5006],
        original_pair_count=114,state_specific_guard_count=114,metadata_files=34,
        original_evaluation_required=True,strict_supplement_separate=True,final_anchors=anchors,
        metadata_io_completed_ns=50,actual_final_contents_accepted_ns=60,reviewed_ns=70,**ff))
    origreq=ref(base/'original-request.json',dict(actual_final_content_acceptance=content,mode='original',
        accepted_by_root=True,artifact_evaluation_authorized=True,original_full_evaluation_authorized=True,
        strict_supplement_authorized=False,**ff))
    executions={role:execution(base/(role+'.execution.json'),a.original_argv(role,anchors,definition),start,end,
        dict(status='analysis_complete_root_review_required',stage='final-evaluate',slots=sorted(evaluations[role]),qualification=False))
        for role,start,end in (('B',80,110),('R',111,120))}
    original=ref(base/'original-completion.json',dict(status='ORIGINAL_FULL_B_R_JOINED_ROOT_REVIEW_REQUIRED',
        accepted_by_root=False,campaign_root=str(a.ROOT),held_excluded=[5004,5006],final_anchors=anchors,
        actual_final_content_acceptance=content,evaluations=evaluations,executions=executions,request=origreq,
        original_numerical_UNKNOWN_must_remain=True,strict_supplement_separate=True,completed_ns=130,**ff))
    proofs=[];targets={}
    for i,(role,name) in enumerate((r,n) for r in ('B','R') for n in evaluations[r] if n.endswith('-service-final')):
        start=140+10*i;end=start+8
        proofdir=base/(role+'-'+name+'.strict-proof')
        replay=dict(cores[role,name],created_ns=start+2)
        replayref=ref(proofdir/'original-evaluate.json',replay)
        pr=ref(base/(role+'-'+name+'.request.json'),dict(bundle=bundles[role,name],anchor=anchors[role],
            R_anchor=anchors['R'],consumer=consumer,evaluator=evaluator,definition=definition))
        proof=ref(proofdir/'strict-latency-guard-proof.json',dict(schema=1,status='SEPARATE_PRODUCT_GUARD_PROOF_ONLY',metadata_preservation_acceptance=content,physical_pre_pair_anchors=anchors,original_pre_pair_anchors=anchors,E_estimate=None,material=False,held_excluded=[5004,5006],
            original_completed_evaluate=replayref,variant=role,original_numerical_result_unmodified=True,
            numerical_UNKNOWN_can_pass=False,request_sha256=pr['sha256'],
            proofs=[dict(id='metric',source_support=[dict(name='quicksilver_hits',ops=7,samples=3,
                raw_stats=[0]*1100000 if i==0 else [0])],reported_effects=[0.0,0.0,0.0],
                extracted_calibration=[1.0,1.0,1.0],guard_run_paths=['C1','C2','C3','A1','B1','A2','B2','A3','B3'],
                separate_guard_disposition='UNRESOLVED')],
            not_applicable=[dict(id='other-metric',original_status='unknown',reason='EXACT UNKNOWN',guard_route='NOT_APPLICABLE')],**{k:v for k,v in ff.items() if k!='candidate_pairs_authorized'}))
        argv=['python3','-B',consumer['path'],pr['path'],pr['sha256'],str(proofdir)]
        er=execution(base/(role+'-'+name+'.execution.json'),argv,start,end,proof)
        proofs.append(dict(role=role,bundle=bundles[role,name],request=pr,proof=proof))
        targets[role,name]=(replayref,pr,proof,er)
    sr=ref(base/'strict-request.json',dict(original_full_completion=original,actual_final_content_acceptance=content,
        mode='strict',accepted_by_root=True,artifact_evaluation_authorized=True,strict_supplement_authorized=True,
        original_full_evaluation_authorized=False,**ff))
    strict=ref(base/'strict-completion.json',dict(status='SEPARATE_STRICT19_REPLAY_JOINED_ROOT_REVIEW_REQUIRED',
        accepted_by_root=False,original_full_completion=original,request=sr,proofs=proofs,
        original_numerical_UNKNOWN_must_remain=True,completed_ns=340,**ff))
    actual=dict(status='ACTUAL_ORIGINAL_FULL54_THEN_SEPARATE_STRICT19_JOINED_PRODUCT_DECISION_PENDING',
        accepted_by_root=False,campaign_root=str(a.ROOT),held_excluded=[5004,5006],original_numerical_UNKNOWN_must_remain=True,
        original_evaluations=evaluations,separate_strict_proofs=proofs,actual_final_content_acceptance=content,
        original_full_completion=original,separate_strict19_completion=strict,original_pair_count=114,
        state_specific_guard_count=114,completed_ns=350,**ff)
    req=dict(final_anchors=anchors,authorized_ns=360)
    refs,returned=a.predecessors(req,actual)
    assert len(refs)==73 and returned==anchors
    checks.append(dict(name='actual predecessors seam accepts all19 distinct replay refs including legitimate proof above2MiB',passed=True))
    firstproof=proofs[0]['proof']
    assert len(json.dumps(bound(firstproof)).encode()) > a.SMALL_LIMIT
    try:limited_bound(firstproof)
    except ValueError:checks.append(dict(name='same legitimate proof demonstrably fails old small-bound limit',passed=True))
    else:raise AssertionError('fixture not large enough')
    def reject(name,ref,key,value):
        old=copy.deepcopy(store[ref['path']][1]);store[ref['path']][1][key]=value
        try:
            a.predecessors(req,actual)
        except (ValueError,AssertionError):checks.append(dict(name=name,passed=True))
        else:raise AssertionError(name)
        finally:store[ref['path']]=(ref,old)
    replay,pr,proof,er=next(iter(targets.values()))
    reject('stale in-process evaluator result rejected by enclosing child interval',replay,'created_ns',100)
    reject('wrong final anchor rejected',replay,'anchor_sha256','0'*64)
    reject('wrong role proof rejected',proof,'variant','R')
    reject('altered exact child argv rejected',er,'native_argv',['python3','wrong'])
    reject('original54 path cannot substitute distinct strict result',proof,'original_completed_evaluate',evaluations['B']['synthetic-0-service-final'])
    reject('UNKNOWN/provenance content drift rejected',replay,'original_evidence',[dict(guard=str(i),common_inventory='ALTERED') for i in range(9)])
    fixture=HERE/'strict-support-synthetic-fixtures-v3'
    fixture.mkdir()
    full=bound(firstproof)
    source=fixture/'complete-strict-proof.synthetic.json'
    source.write_bytes(json.dumps(full).encode())
    real_ref=dict(path=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    record=p.pack_one(real_ref,fixture/'complete-strict-proof.synthetic.json.gz')
    projection=a.numerical_projection(full,record)
    view=projection['value_projection']
    omitted=view['proofs'][0]['source_support']
    assert omitted['projection_omitted_full_content'] is True and omitted['json_pointer']=='/proofs/0/source_support'
    recovered=p.complete_json(record,real_ref)['proofs'][0]['source_support']
    assert recovered==full['proofs'][0]['source_support']
    checks.append(dict(name='large strict source_support exact full archive pointer projection and recovery',passed=True))
    for key in full:
        if key!='proofs':assert view[key]==full[key]
    assert {k:v for k,v in view['proofs'][0].items() if k!='source_support'}=={k:v for k,v in full['proofs'][0].items() if k!='source_support'}
    assert len(json.dumps(projection).encode())<a.VIEW_LIMIT
    checks.append(dict(name='all witness/effects/calibrations/guardpaths/UNKNOWN/not_applicable fields preserved',passed=True))
    giant=copy.deepcopy(full);giant['unexpected_giant_remaining']='x'*(a.VIEW_LIMIT+1)
    try:a.write_json(fixture/'unexpected-giant-rejected.synthetic.json',a.numerical_projection(giant,record),a.VIEW_LIMIT)
    except ValueError:checks.append(dict(name='unexpected remaining giant field fails without projection omission',passed=True))
    else:raise AssertionError('unexpected giant accepted')
    result=dict(schema=1,synthetic_only=True,actual_input_execution=False,checks=checks,
        tested_adapter=dict(path=str(HERE/'native_lossless_stage4_adapter.py'),sha256=hashlib.sha256((HERE/'native_lossless_stage4_adapter.py').read_bytes()).hexdigest()),
        byte_store_mocked=True,no_subprocesses=True,**p.authority_false())
    with (HERE/'strict-predecessor-seam-synthetic-results-v3.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(dict(synthetic_seam_checks=len(checks),actual_input_execution=False)))


if __name__=='__main__':main()
