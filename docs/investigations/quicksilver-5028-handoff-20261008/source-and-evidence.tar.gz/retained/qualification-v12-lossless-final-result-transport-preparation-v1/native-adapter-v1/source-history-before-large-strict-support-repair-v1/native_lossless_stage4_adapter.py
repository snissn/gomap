"""Root-deployed native artifact adapter. CLI: REQUEST_PATH REQUEST_SHA NEW_OUTPUT.

Source preparation does not authorize execution. No SSH, product/state/GH writes,
retry, qualification decision, or cross-host transfer occurs in this adapter.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
import types

NROOT = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = NROOT/'qualification-v12-refresh/qualification-v10'
OUTPUT = NROOT/'qualification-v12-lossless-final-result-transport-actual-v1'
PROTOTYPE_SHA = 'b7bef94abde1a84552c2e2a2aae1e503b9b108e260a58abbba80eb2344cf0282'
CHECKER_SHA = 'aee4bc7d1784c1ee4e6adb3d4e899a6fdaa86d3a21ba7a08c4c6d838ff99e8ee'
EVALUATOR_SHA = '9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd'
STRICT_CONSUMER_SHA = 'ccc5b23ed271b2bd814fc2678a7e4d99e72f0f381b4a39d37132ae570cdee97d'
FLAGS = ('qualification','performance_accepted','collection_authorized',
         'candidate_pairs_authorized','merge_authorized')
EMPTY_SHA = hashlib.sha256(b'').hexdigest()
SMALL_LIMIT = 2 << 20
VIEW_LIMIT = 512 << 10
P = None


def require(ok, why):
    if not ok:
        raise ValueError(why)


def flags(value):
    require(all(value[k] is False for k in FLAGS), 'product authority forbidden')


def canonical(path):
    p = Path(path)
    require(p.is_absolute() and p.is_file() and not p.is_symlink()
            and p.resolve(strict=True) == p, 'canonical nonsymlink regular file')
    return p


def identity(path):
    p = canonical(path)
    h = hashlib.sha256()
    size = 0
    with p.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
            size += len(block)
    require(canonical(path) == p, 'identity path drift')
    return dict(path=str(p),sha256=h.hexdigest(),bytes=size)


def reference(path):
    row = identity(path)
    return {k:row[k] for k in ('path','sha256')}


def exact_reference(ref):
    require(set(ref) == {'path','sha256'} and isinstance(ref['path'],str)
            and isinstance(ref['sha256'],str) and len(ref['sha256']) == 64
            and all(c in '0123456789abcdef' for c in ref['sha256']), 'exact reference')


def verify_ref(ref):
    exact_reference(ref)
    require(reference(ref['path']) == ref, 'bound file SHA drift')
    return canonical(ref['path'])


def bound(ref, limit=SMALL_LIMIT):
    p = verify_ref(ref)
    require(p.stat().st_size <= limit, 'unexpected giant predecessor/source packet')
    with p.open('rb') as stream:
        value = json.load(stream)
    verify_ref(ref)
    return value


def write_json(path, value, limit=SMALL_LIMIT):
    """Exclusive, bounded streaming encoding; failed partial evidence is retained."""
    p = Path(path)
    require(p.is_absolute() and p.resolve() == p and not p.exists()
            and not p.is_symlink() and p.parent.resolve(strict=True) == p.parent,
            'new canonical packet')
    size = 0
    with p.open('xb') as stream:
        for piece in json.JSONEncoder(allow_nan=False,separators=(',',':')).iterencode(value):
            data = piece.encode('utf-8')
            size += len(data)
            require(size <= limit, 'unexpected giant remaining projection/packet; never truncate')
            stream.write(data)
        stream.write(b'\n')
    return reference(p)


def execution(ref, expected_argv=None):
    row = bound(ref)
    require(row['rc'] == 0 and not row.get('error')
            and 0 < row['started_ns'] < row['finished_ns'] < time.time_ns(), 'genuine joined receipt')
    if expected_argv is not None:
        require(row['native_argv'] == expected_argv, 'predecessor exact argv')
    for channel in ('stdout','stderr'):
        require(identity(row[channel]['path']) == row[channel], 'complete predecessor stream identity')
    require(row['stderr']['bytes'] == 0 and row['stderr']['sha256'] == EMPTY_SHA,
            'predecessor stderr')
    return row


def original_argv(role, anchors, definition):
    driver = NROOT/('qualification-analysis-controller.py' if role == 'B'
                    else 'r-material-gate-preparation-v2/r-analysis-controller.py')
    out = ROOT/('analysis-global-original-v1' if role == 'B' else 'ar-analysis-global-original-v1')
    args = ['python3','-B',str(driver),'final-evaluate','--campaign',str(ROOT),'--out',str(out)]
    if role == 'R':
        args += ['--original-B-anchor',anchors['B']['path'],'--original-B-anchor-sha256',
                 anchors['B']['sha256'],'--definition',definition['path'],
                 '--definition-sha256',definition['sha256']]
    return args+['--anchor',anchors[role]['path'],'--anchor-sha256',anchors[role]['sha256']]


def complete_bound(ref):
    """Sequential complete native JSON, including giant provenance; never project."""
    path = verify_ref(ref)
    with path.open('rb') as stream:
        value = json.load(stream)
    verify_ref(ref)
    return value


def strict_replay_binding(item, proof_request, proof, child, original_ref, anchor_value, anchors, role):
    """evaluate_first runs IN PROCESS; the genuine enclosing consumer child is its receipt."""
    evaluator = proof_request['evaluator']
    consumer = proof_request['consumer']
    require(evaluator['sha256'] == EVALUATOR_SHA and consumer['sha256'] == STRICT_CONSUMER_SHA,
            'frozen strict evaluator/consumer identity')
    for ref in (evaluator,consumer,proof_request['definition'],item['bundle']):
        verify_ref(ref)
        selected = Path(ref['path'])
        files = anchor_value['files']
        anchored = files.get(str(selected))
        if anchored is None and selected.is_relative_to(Path(anchor_value['root'])):
            anchored = files.get(str(selected.relative_to(Path(anchor_value['root']))))
        require(anchored == ref['sha256'], 'strict replay selected input absent from same final anchor')
    require(proof_request['definition']['path'] == anchor_value['definition']
            and proof_request['anchor'] == anchors[role]
            and proof_request['R_anchor'] == anchors['R']
            and proof['variant'] == role, 'strict replay final role/anchor/definition')
    bundle = bound(item['bundle'])
    require(bundle.get('variant','B') == role and bundle['metric_set'] == 'service_final_inplace',
            'strict replay exact state-specific bundle role')
    replay_ref = proof['original_completed_evaluate']
    require(replay_ref != original_ref
            and replay_ref['path'] == str(Path(item['proof']['path']).parent/'original-evaluate.json'),
            'distinct exact strict in-process result path')
    replay = complete_bound(replay_ref)
    original = complete_bound(original_ref)
    evaluator_argv = [evaluator['path'],'evaluate',item['bundle']['path'],
                      '--anchor',anchors[role]['path'],'--anchor-sha256',anchors[role]['sha256'],
                      '--definition-sha256',proof_request['definition']['sha256']]
    # This argv is pinned by the exact consumer source evaluate_first; it is not a separate child launch.
    require(replay['schema'] == 1 and replay['status'] == 'artifact_diagnostic_only'
            and replay['qualification'] is False and type(replay['created_ns']) is int
            and child['started_ns'] <= replay['created_ns'] <= child['finished_ns']
            and replay['anchor_sha256'] == anchors[role]['sha256']
            and replay['definition_sha256'] == proof_request['definition']['sha256']
            and replay['calibration'] == bundle['calibration']
            and len(replay['original_evidence']) == 9
            and len(replay['ledger']) == len(bundle['metrics'])
            and {e['id'] for e in replay['ledger']} == set(bundle['metrics']), 'strict replay complete result identity')
    require(original['created_ns'] < child['started_ns'] and original['root_acceptance_required'] is True,
            'original54 distinct result before strict child')
    exclude = {'created_ns','root_acceptance_required'}
    if role == 'R':
        require(original['candidate_variant'] == 'R', 'original R controller identity')
        P.ledger_view(original['allocation_ledger'])  # Complete controller-added ledger remains independently checked.
        exclude |= {'candidate_variant','allocation_ledger'}
    left = {k:v for k,v in original.items() if k not in exclude}
    right = {k:v for k,v in replay.items() if k != 'created_ns'}
    require(left == right, 'strict replay full original evaluator numeric/provenance drift')
    return dict(kind='IN_PROCESS_FROZEN_EVALUATOR_BOUND_TO_STRICT_CONSUMER_CHILD',
                original54_reference=original_ref,strict_evaluator_result=replay_ref,
                evaluator=evaluator,evaluator_argv=evaluator_argv,
                enclosing_consumer_argv=child['native_argv'],created_ns=replay['created_ns'])


def predecessors(req, actual):
    flags(actual)
    require(actual['accepted_by_root'] is False and actual['campaign_root'] == str(ROOT)
            and actual['held_excluded'] == [5004,5006]
            and actual['original_numerical_UNKNOWN_must_remain'] is True, 'actual outcome identity')
    refs = P.result_refs(actual)
    content = bound(actual['actual_final_content_acceptance'])
    original = bound(actual['original_full_completion'])
    strict = bound(actual['separate_strict19_completion'])
    for value in (content,original,strict):
        flags(value)
    require(content['status'] == 'ACTUAL_FINAL_CONTENT_ONLY_ROOT_ACCEPTED'
            and content['accepted_by_root'] is content['actual_final_contents_accepted'] is True
            and content['campaign_root'] == str(ROOT) and content['held_excluded'] == [5004,5006]
            and content['original_pair_count'] == content['state_specific_guard_count'] == 114
            and content['metadata_files'] == 34
            and content['original_evaluation_required'] is content['strict_supplement_separate'] is True,
            'content predecessor scope')
    anchors = req['final_anchors']
    require(set(anchors) == {'B','R'} and content['final_anchors'] == anchors
            and original['final_anchors'] == anchors, 'exact final anchors')
    anchor_values = {role:bound(ref,64 << 20) for role,ref in anchors.items()}
    require(anchor_values['R']['original_B_anchor'] == anchors['B']['path']
            and anchor_values['R']['original_B_anchor_sha256'] == anchors['B']['sha256'], 'R/B anchor binding')
    definition = reference(anchor_values['R']['definition'])
    require(original['status'] == 'ORIGINAL_FULL_B_R_JOINED_ROOT_REVIEW_REQUIRED'
            and original['accepted_by_root'] is False and original['campaign_root'] == str(ROOT)
            and original['held_excluded'] == [5004,5006]
            and original['actual_final_content_acceptance'] == actual['actual_final_content_acceptance']
            and original['evaluations'] == actual['original_evaluations']
            and set(original['executions']) == {'B','R'}
            and original['original_numerical_UNKNOWN_must_remain'] is True
            and original['strict_supplement_separate'] is True, 'original54 predecessor')
    original_request = bound(original['request'])
    flags(original_request)
    require(original_request['accepted_by_root'] is True
            and original_request['artifact_evaluation_authorized'] is True, 'original request authorization')
    require(original_request['actual_final_content_acceptance'] == actual['actual_final_content_acceptance']
            and original_request['mode'] == 'original'
            and original_request['original_full_evaluation_authorized'] is True
            and original_request['strict_supplement_authorized'] is False, 'original request binding')
    previous = content['actual_final_contents_accepted_ns']
    for role in ('B','R'):
        row = execution(original['executions'][role],original_argv(role,anchors,definition))
        require(previous <= row['started_ns'] < row['finished_ns'] <= original['completed_ns'],
                'original B then R chronology')
        previous = row['finished_ns']
        summary = bound({k:row['stdout'][k] for k in ('path','sha256')})
        require(summary == dict(status='analysis_complete_root_review_required',stage='final-evaluate',
                               slots=sorted(original['evaluations'][role]),qualification=False), 'original summary scope')
        parent = ROOT/('analysis-global-original-v1' if role == 'B' else 'ar-analysis-global-original-v1')
        for name,ref in original['evaluations'][role].items():
            require(ref['path'] == str(parent/(name+'.evaluation.json')), 'exact original result membership')
    require(strict['status'] == 'SEPARATE_STRICT19_REPLAY_JOINED_ROOT_REVIEW_REQUIRED'
            and strict['accepted_by_root'] is False
            and strict['original_full_completion'] == actual['original_full_completion']
            and strict['proofs'] == actual['separate_strict_proofs']
            and strict['original_numerical_UNKNOWN_must_remain'] is True, 'strict19 predecessor')
    strict_request = bound(strict['request'])
    flags(strict_request)
    require(strict_request['accepted_by_root'] is True
            and strict_request['artifact_evaluation_authorized'] is True, 'strict request authorization')
    require(strict_request['original_full_completion'] == actual['original_full_completion']
            and strict_request['actual_final_content_acceptance'] == actual['actual_final_content_acceptance']
            and strict_request['mode'] == 'strict'
            and strict_request['strict_supplement_authorized'] is True
            and strict_request['original_full_evaluation_authorized'] is False, 'strict request binding')
    previous = original['completed_ns']
    seen = set()
    for item in strict['proofs']:
        role = item['role']
        require(role in ('B','R'), 'strict role')
        name = Path(item['bundle']['path']).name.removesuffix('.bundle.json')
        require(name.endswith('-service-final') and name in original['evaluations'][role]
                and (role,name) not in seen, 'strict original membership')
        seen.add((role,name))
        require(item['bundle']['path'] == str(Path(original['evaluations'][role][name]['path']).with_suffix('').with_suffix('.bundle.json')),
                'strict bundle path')
        verify_ref(item['bundle'])
        proof_request = bound(item['request'])
        require(proof_request['bundle'] == item['bundle'] and proof_request['anchor'] == anchors[role]
                and proof_request['R_anchor'] == anchors['R'], 'strict proof request membership')
        verify_ref(proof_request['consumer'])
        proof = bound(item['proof'])
        require(proof['status'] == 'SEPARATE_PRODUCT_GUARD_PROOF_ONLY'
                and proof['original_numerical_result_unmodified'] is True
                and proof['numerical_UNKNOWN_can_pass'] is False
                and proof['request_sha256'] == item['request']['sha256'], 'strict proof identity')
        # Strict proof format predates candidate_pairs_authorized; require all its declared flags.
        require(all(proof[k] is False for k in FLAGS if k != 'candidate_pairs_authorized'), 'strict proof authority')
        receipt_path = Path(actual['separate_strict19_completion']['path']).parent/(role+'-'+name+'.execution.json')
        argv = ['python3','-B',proof_request['consumer']['path'],item['request']['path'],
                item['request']['sha256'],str(Path(item['proof']['path']).parent)]
        row = execution(reference(receipt_path),argv)
        require(previous <= row['started_ns'] < row['finished_ns'] <= strict['completed_ns'], 'strict serial chronology')
        require(bound({k:row['stdout'][k] for k in ('path','sha256')}) == item['proof'], 'strict producer result ref')
        strict_replay_binding(item,proof_request,proof,row,original['evaluations'][role][name],
                              anchor_values[role],anchors,role)
        previous = row['finished_ns']
    require(len(seen) == 19 and sum(role == 'B' for role,name in seen) == 13
            and sum(role == 'R' for role,name in seen) == 6, 'strict19 identities')
    require(0 < content['metadata_io_completed_ns'] < content['actual_final_contents_accepted_ns']
            <= content['reviewed_ns'] < original['completed_ns'] < strict['completed_ns']
            <= actual['completed_ns'] < req['authorized_ns'] < time.time_ns(), '54 before19 before new request chronology')
    return refs,anchors


def omitted(record, pointer):
    return dict(projection_omitted_full_content=True,complete_archive=record,json_pointer=pointer)


def numerical_projection(value, record):
    """Only original_evidence and individual numerical ledger support are omitted."""
    view = dict(value)
    if 'original_evidence' in value:
        view['original_evidence'] = omitted(record,'/original_evidence')
    for ledger_key in ('ledger','allocation_ledger'):
        if ledger_key not in value:
            continue
        require(isinstance(value[ledger_key],list), 'ledger array')
        rows = []
        for i,entry in enumerate(value[ledger_key]):
            row = dict(entry)
            if 'support' in entry:
                row['support'] = omitted(record,'/'+ledger_key+'/'+str(i)+'/support')
            if ledger_key == 'allocation_ledger' and 'original_numerical' in entry:
                nested = dict(entry['original_numerical'])
                if 'support' in nested:
                    nested['support'] = omitted(record,'/'+ledger_key+'/'+str(i)+'/original_numerical/support')
                row['original_numerical'] = nested
            rows.append(row)
        view[ledger_key] = rows
    return dict(schema=1,kind='OBSERVATION_ONLY_NUMERICAL_PROJECTION',complete_result=False,
                complete_archive=record,value_projection=view,**P.authority_false())


class Adapter:
    def __init__(self, out, req_ref, actual, refs, anchors):
        self.out,self.req_ref,self.actual,self.refs,self.anchors = out,req_ref,actual,refs,anchors
        self.operation_receipts,self.producer_receipts,self.observations = [],[],{}
        self.archives = {}
        self.original_complete_json = P.complete_json

    def archive(self, key, ref):
        started = time.time_ns()
        receipt_path = self.out/(key+'.archive-operation.json')
        row = dict(schema=1,kind='native_archive_function_call',process=False,child_pid=None,
                   function='lossless_result_transport_prototype.pack_one',request=self.req_ref,
                   source_reference=ref,started_ns=started,rc=None,**P.authority_false())
        try:
            record = P.pack_one(ref,self.out/(key+'.complete.json.gz'))
            row.update(rc=0,stdout=dict(path=record['archive_path'],**record['compressed_identity']),
                       stdout_semantics='complete_archive_artifact_identity_not_process_stdout',
                       stderr=dict(kind='not_applicable_to_function',bytes=0,sha256=EMPTY_SHA),
                       complete_archive=record)
        except BaseException as error:
            row['error'] = repr(error)
            raise
        finally:
            row['finished_ns'] = time.time_ns()
            receipt_ref = write_json(receipt_path,row)
            self.operation_receipts.append(receipt_ref)
        return record,row,receipt_ref

    def export(self, key, ref):
        require(self.refs[key] == ref, 'export exact73 source membership')
        record,receipt,receipt_ref = self.archive(key,ref)
        self.archives[ref['path']] = (key,record)
        return record,receipt_ref

    def observe_complete_json(self, record, ref):
        value = self.original_complete_json(record,ref)
        if ref['path'] in self.archives:
            key,expected = self.archives[ref['path']]
            require(record == expected and self.refs[key] == ref, 'observation archive membership')
            if key not in self.observations:
                if key.startswith('original-'):
                    require(value['qualification'] is False and value['root_acceptance_required'] is True,
                            'complete original result authority')
                else:
                    require(value['status'] == 'SEPARATE_PRODUCT_GUARD_PROOF_ONLY', 'complete strict result')
                projection = numerical_projection(value,record)
                self.observations[key] = write_json(self.out/(key+'.observation-projection.json'),projection,VIEW_LIMIT)
        return value

    def run_exact(self, argv, name, checker_sha):
        require(checker_sha == CHECKER_SHA and argv == P.allocation_argv(
            name,self.actual['original_evaluations']['B'][name],self.anchors['B']), 'exact allocation argv/source')
        checker_ref = dict(path=argv[2],sha256=CHECKER_SHA)
        verify_ref(checker_ref)  # Current frozen native checker checked immediately before EVERY call.
        stdout = self.out/(name+'.producer.stdout.json')
        stderr = self.out/(name+'.producer.stderr.txt')
        row = dict(schema=1,kind='native_child_process',request=self.req_ref,native_argv=argv,
                   checker=checker_ref,owner_pid=os.getpid(),child_pid=None,started_ns=time.time_ns(),
                   rc=None,**P.authority_false())
        try:
            with stdout.open('xb') as so,stderr.open('xb') as se:
                child = subprocess.Popen(argv,stdout=so,stderr=se)
                row['child_pid'] = child.pid
                row['spawned_ns'] = time.time_ns()
                write_json(self.out/(name+'.producer.activation.json'),row)
                row['rc'] = child.wait()
            verify_ref(checker_ref)
        except BaseException as error:
            row['error'] = repr(error)
            raise
        finally:
            row['finished_ns'] = time.time_ns()
            for channel,path in (('stdout',stdout),('stderr',stderr)):
                if path.is_file():
                    row[channel] = identity(path)
            receipt_ref = write_json(self.out/(name+'.producer.execution.json'),row)
            self.producer_receipts.append(receipt_ref)
        require(row['rc'] == 0 and not row.get('error') and row['stderr']['bytes'] == 0,
                'allocation child failed; complete evidence retained; no retry')
        raw_ref = {k:row['stdout'][k] for k in ('path','sha256')}
        record,operation,operation_ref = self.archive(name+'-replay',raw_ref)
        return record,row,receipt_ref,operation,operation_ref


def main(argv):
    global P
    require(__debug__ and sys.pycache_prefix is None and not os.environ.get('PYTHONPYCACHEPREFIX'),
            'unoptimized Python without alternate bytecode writes required')
    sys.dont_write_bytecode = True
    require(len(argv) == 4, 'CLI REQUEST_PATH REQUEST_SHA NEW_OUTPUT')
    request_ref = dict(path=argv[1],sha256=argv[2])
    req = bound(request_ref)
    flags(req)
    require(req['schema'] == 1 and req['status'] == 'ROOT_AUTHORIZED_LOSSLESS_FINAL_RESULT_AND_B16_REPLAY_ONLY'
            and req['artifact_content_review_authorized'] is True and req['campaign_root'] == str(ROOT)
            and req['held_excluded'] == [5004,5006], 'root request scope')
    out = Path(argv[3])
    require(req['output_directory'] == str(out) and out == OUTPUT and out.is_absolute()
            and out.resolve() == out and not out.exists() and not out.is_symlink()
            and out.parent.resolve(strict=True) == out.parent, 'exact new exclusive canonical output')
    adoption = bound(req['source_adoption'])
    flags(adoption)
    require(adoption['accepted_by_root'] is adoption['source_only'] is True
            and adoption['helper'] == reference(canonical(__file__))
            and adoption['prototype']['sha256'] == PROTOTYPE_SHA, 'adopted exact helper/prototype')
    verify_ref(adoption['independent_review'])
    verify_ref(adoption['launcher'])
    prototype_path = verify_ref(adoption['prototype'])
    require(prototype_path.stat().st_size == 17310, 'frozen prototype byte count')
    prototype_bytes = prototype_path.read_bytes()
    require(hashlib.sha256(prototype_bytes).hexdigest() == PROTOTYPE_SHA
            and len(prototype_bytes) == 17310, 'exact imported prototype bytes')
    P = types.ModuleType('lossless_result_transport_prototype')
    P.__file__ = str(prototype_path)
    exec(compile(prototype_bytes,str(prototype_path),'exec'),P.__dict__)
    actual = bound(req['actual_final_outcome'])
    refs,anchors = predecessors(req,actual)
    out.mkdir()  # No writes to old evidence/source/state; partial new output is never reused.
    adapter = Adapter(out,request_ref,actual,refs,anchors)
    started = time.time_ns()
    try:
        P.complete_json = adapter.observe_complete_json
        index = P.read_complete73(actual,adapter.export)
        require(set(adapter.observations) == set(refs), 'all73 complete observation membership')
        index_ref = write_json(out/'complete73-index.json',index)
        observations_ref = write_json(out/'observation-projection-index.json',dict(
            schema=1,complete_results=False,kind='OBSERVATION_ONLY_PROJECTION_INDEX',
            projections=adapter.observations,complete73_index=index_ref,**P.authority_false()))
        ledger = P.replay_B16_and_read_R6(actual,anchors,index,adapter.run_exact)
        require(ledger['entry_count'] == 176 and len(adapter.producer_receipts) == 16,
                'all176 genuine actual call count')
        verified_entries = verified_met = 0
        for role,key in (('B','accounting_ledger_reference'),('R','allocation_ledger_reference')):
            for row in ledger[role].values():
                views = P.verify_ledger_reference(row[key])
                verified_entries += len(views)
                verified_met += sum(e['allocation_guard_met'] is True for e in views)
                del views
        require(verified_entries == 176 and verified_met == ledger['met_entry_count'],
                'all176 reopened complete archive pointers/disposition drift')
        ledger['complete_archive_pointer_entries_reverified'] = verified_entries
        ledger_ref = write_json(out/'all176-archive-ledger.json',ledger)
        status = 'NATIVE_LOSSLESS_ALL73_ALL176_JOINED_PRODUCT_DECISION_PENDING'
        completion = dict(schema=1,status=status,request=request_ref,source_adoption=req['source_adoption'],
            actual_final_outcome=req['actual_final_outcome'],final_anchors=anchors,index=index_ref,
            observations=observations_ref,all176=ledger_ref,operation_receipts=adapter.operation_receipts,
            producer_receipts=adapter.producer_receipts,complete73_count=73,entry_count=176,
            B_replay_count=16,R_inherited_ledger_count=6,started_ns=started,completed_ns=time.time_ns(),
            complete_results_retained_in_archives=True,complete_ledgers_embedded=False,
            campaign_root=str(ROOT),held_excluded=[5004,5006],**P.authority_false())
        completion_ref = write_json(out/'completion.pending-product-review.json',completion)
        print(json.dumps(dict(status=status,completion=completion_ref,index=index_ref,
            observations=observations_ref,all176=ledger_ref,operation_receipts=adapter.operation_receipts,
            producer_receipts=adapter.producer_receipts,qualification=False),allow_nan=False),flush=True)
    except BaseException as error:
        write_json(out/'failure.no-retry.json',dict(schema=1,status='FAILED_NEW_OUTPUT_RETAINED_NO_RETRY',
            request=request_ref,error=repr(error),started_ns=started,finished_ns=time.time_ns(),
            operation_receipts=adapter.operation_receipts,producer_receipts=adapter.producer_receipts,
            **P.authority_false()))
        raise
    finally:
        P.complete_json = adapter.original_complete_json


if __name__ == '__main__':
    main(sys.argv)
