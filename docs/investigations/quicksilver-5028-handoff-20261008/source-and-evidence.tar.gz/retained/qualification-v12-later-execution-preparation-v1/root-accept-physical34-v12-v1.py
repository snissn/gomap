"""Root finite artifact acceptance after the original physical preservation IO.

No benchmark, database access, metadata replacement, math or pair authority.
Only the exact consumer physical_anchor transform is published in new files.
"""
if not __debug__:
    raise RuntimeError('root acceptance assertions required')
from pathlib import Path
import copy
import hashlib
import json
import sys
import time
import types
sys.dont_write_bytecode = True

BASE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = BASE/'qualification-v12-refresh/qualification-v10'
OUT = ROOT/'pre-pair-root-physical34-acceptance-v12-v1'
CONSUMER_SHA = 'ccc5b23ed271b2bd814fc2678a7e4d99e72f0f381b4a39d37132ae570cdee97d'
EVALUATOR_SHA = '9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ref(path):
    return dict(path=str(path),sha256=sha(path))


def bound(item):
    assert set(item) == {'path','sha256'}
    p = Path(item['path'])
    assert p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink()
    assert sha(p) == item['sha256']
    return json.loads(p.read_bytes())


def source(item, name, digest):
    assert item['sha256'] == digest and sha(item['path']) == digest
    assert not (Path(item['path']).parent/'__pycache__').exists()
    module = types.ModuleType(name);module.__file__ = item['path']
    exec(compile(Path(item['path']).read_bytes(),item['path'],'exec'),module.__dict__)
    return module


def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
    return ref(path)


assert len(sys.argv)==3 and sys.pycache_prefix is None
request_ref = dict(path=sys.argv[1],sha256=sys.argv[2]);request = bound(request_ref)
assert request['schema']==1 and request['accepted_by_root'] is True and request['owner']=='/root'
assert request['physical34_acceptance_io_authorized'] is True
assert request['campaign_root']==str(ROOT) and request['held_excluded']==[5004,5006]
assert request['helper']==ref(Path(__file__).resolve())
assert all(request[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
receipt = bound(request['preservation_receipt'])
assert receipt['status']=='PRESERVED_BYTES_ROOT_ACCEPTANCE_PENDING' and receipt['accepted_by_root'] is False
assert receipt['qualification'] is receipt['performance_accepted'] is receipt['collection_authorized'] is False
assert receipt['schema']==1 and receipt['campaign_root']==str(ROOT) and receipt['held_excluded']==[5004,5006]
assert receipt['no_pair_namespace_at_completion'] is True
copy_request = bound(receipt['request'])
assert receipt['request_sha256']==receipt['request']['sha256']
assert copy_request['accepted_by_root'] is True and copy_request['artifact_io_authorized'] is True
assert copy_request['qualification'] is copy_request['collection_authorized'] is False
assert copy_request['global54_actual_content_acceptance']==receipt['global54_actual_content_acceptance']
assert receipt['consumer']==copy_request['consumer']==request['consumer']
assert receipt['prospective_rule_freeze']==copy_request['prospective_rule_freeze']
global_accept = bound(receipt['global54_actual_content_acceptance'])
assert global_accept['accepted_by_root'] is global_accept['global54_actual_contents_accepted'] is True
assert global_accept['qualification'] is global_accept['performance_accepted'] is False
assert global_accept['campaign_root']==str(ROOT) and global_accept['held_excluded']==[5004,5006]
originals = {role:bound(item) for role,item in receipt['original_anchors'].items()}
assert set(originals)=={'B','R'} and receipt['original_anchors']['R']==global_accept['R_anchor']
assert originals['R']['files']==global_accept['files']
assert receipt['original_anchors']['B']==dict(path=originals['R']['original_B_anchor'],sha256=originals['R']['original_B_anchor_sha256'])
for role,anchor in originals.items():
    assert anchor['root']==str(ROOT) and anchor['accepted_by_root'] is True
    assert bound(receipt['retained_anchors'][role])==anchor
    assert receipt['retained_anchors'][role]['sha256']==receipt['original_anchors'][role]['sha256']
    for path,digest in anchor['files'].items():
        assert sha(path)==digest
        if path.endswith('.py'):
            assert not (Path(path).parent/'__pycache__').exists(), 'reject unbound Python cache before imports'
assert bound(receipt['retained_global54_acceptance'])==global_accept
assert receipt['retained_global54_acceptance']['sha256']==receipt['global54_actual_content_acceptance']['sha256']
assert all(originals['R']['files'].get(path)==digest for path,digest in originals['B']['files'].items())
strict = source(request['consumer'],'root_preservation_frozen_consumer',CONSUMER_SHA)
ev = source(copy_request['evaluator'],'root_preservation_original_evaluator',EVALUATOR_SHA)
invs = {role:ev.Inventory(item['path'],item['sha256']) for role,item in receipt['original_anchors'].items()}
drivers = strict.original_drivers(invs['R'],copy_request,'root_physical_')
plans,mutable = strict.layout_metadata(ROOT,copy_request,originals,drivers)
strict.no_pair_attempt(ROOT,plans)
assert len(mutable)==34 and set(receipt['mapping'])==set(mutable)
preserved = Path(request['preservation_receipt']['path']).parent
assert preserved.parent==ROOT and preserved.resolve()==preserved
for number,path in enumerate(sorted(mutable)):
    record = receipt['mapping'][path];item = mutable[path]
    assert set(record)=={'role','kind','original_sha256','copy'}
    assert record['role']==item['role'] and record['kind']==item['kind']
    assert record['original_sha256']==record['copy']['sha256']==originals['R']['files'][path]==sha(path)
    assert Path(record['copy']['path'])==preserved/(str(number).zfill(2)+'-'+Path(path).name)
    saved = bound(record['copy'])
    if item['kind']=='offline':
        assert saved==item['expected']
    else:
        assert saved['runs']==item['expected']
        assert all(saved[k] is True for k in ('accepted_by_root','inplace_no_reload_restore','before_after_census_retained'))
assert bound(receipt['drafts']['B'])==dict(strict.physical_anchor(originals['B'],receipt['mapping'],'B'),accepted_by_root=False)
assert bound(receipt['drafts']['R'])==dict(strict.physical_anchor(originals['R'],receipt['mapping'],'R',receipt['drafts']['B']),accepted_by_root=False)
assert not OUT.exists() and not OUT.is_symlink()
OUT.mkdir()
B = strict.physical_anchor(originals['B'],receipt['mapping'],'B')
B_ref = save(OUT/'physical-B-anchor.accepted.json',B)
R = strict.physical_anchor(originals['R'],receipt['mapping'],'R',B_ref)
R_ref = save(OUT/'physical-R-anchor.accepted.json',R)
for item in (B_ref,R_ref):
    inv = ev.Inventory(item['path'],item['sha256'])
    for path in inv.files:inv.file(path)
assert all(R['files'].get(path)==digest for path,digest in B['files'].items())
strict.no_pair_attempt(ROOT,plans)
now = time.time_ns()
assert 0<global_accept['accepted_ns']<=receipt['started_ns']<=receipt['completed_ns']<now
acceptance = dict(schema=1,status='ACTUAL_EXACT34_BYTES_AND_PHYSICAL_ANCHORS_ROOT_ACCEPTED',
    accepted_by_root=True,metadata_preservation_actual_contents_accepted=True,owner='/root',
    accepted_ns=now,campaign_root=str(ROOT),held_excluded=[5004,5006],consumer=request['consumer'],
    receipt=request['preservation_receipt'],request=receipt['request'],
    global54_actual_content_acceptance=receipt['global54_actual_content_acceptance'],
    original_anchors=receipt['original_anchors'],physical_anchors=dict(B=B_ref,R=R_ref),mapping=receipt['mapping'],
    preserved_completed_ns=receipt['completed_ns'],no_pair_namespace_at_acceptance=True,
    physical34_content_request=request_ref,qualification=False,performance_accepted=False,
    collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False)
accepted_ref = save(OUT/'metadata-preservation-actual-content-acceptance.json',acceptance)
result = dict(schema=1,status='ACTUAL_PHYSICAL34_ROOT_CONTENT_ACCEPTANCE_PASS',
    acceptance=accepted_ref,original_anchors=receipt['original_anchors'],physical_anchors=acceptance['physical_anchors'],
    preserved_count=34,no_pair_namespace=True,accepted_ns=now,qualification=False,performance_accepted=False,
    collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False)
save(OUT/'actual-readback.json',result)
print(json.dumps(result,allow_nan=False))
