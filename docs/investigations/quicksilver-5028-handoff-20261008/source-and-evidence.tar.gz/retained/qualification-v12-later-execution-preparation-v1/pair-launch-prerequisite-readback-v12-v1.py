"""Future native read-only prerequisite readback. No campaign imports or launch."""
if not __debug__: raise RuntimeError('unoptimized Python required')
from pathlib import Path
import hashlib,json,math,sys,time
BASE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=BASE/'qualification-v12-refresh/qualification-v10'
PROS=ROOT.parent/'qualification-v10-prospective-root-v1'
CONTROLS=BASE/'qualification-v12-fresh-controls-v1'
def require(ok,why):
    if not ok:raise ValueError(why)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def parse(raw):
    def unique(items):
        d={}
        for k,v in items:require(k not in d,'duplicate JSON key');d[k]=v
        return d
    def invalid(v):raise ValueError('nonfinite JSON')
    def finite(v):
        f=float(v);require(math.isfinite(f),'nonfinite JSON');return f
    return json.loads(raw,object_pairs_hook=unique,parse_constant=invalid,parse_float=finite)
def canonical(p):
    p=Path(p);require(p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p,'canonical regular file');return p
def bound(r):
    require(set(r)=={'path','sha256'},'exact ref');p=canonical(r['path']);require(sha(p)==r['sha256'],'bound digest drift');return parse(p.read_bytes())
def check_map(files):
    seen=set();require(isinstance(files,dict) and files,'nonempty map')
    for name,digest in files.items():
        p=Path(name);require(p.is_absolute() and p.is_file(),'absolute regular inherited map');target=p.resolve(strict=True)
        require(target not in seen and sha(p)==digest,'map digest/alias drift');seen.add(target)
        if target.suffix=='.py':require(p==target and not (target.parent/'__pycache__').exists(),'canonical source without cache')
def flags(v):
    require(all(v[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized')),'forbidden pre-launch authority')
def inherited(a,b):require(all(a.get(k)==v for k,v in b.items()),'full unchanged map inheritance')
def no_pairs():
    require(ROOT.resolve()==ROOT and ROOT.is_dir() and not ROOT.is_symlink(),'canonical campaign')
    for directory in (ROOT,ROOT/'plans',ROOT/'receipts'):
        if not directory.exists():continue
        require(directory.is_dir() and not directory.is_symlink(),'canonical namespace')
        for p in directory.iterdir():
            name=p.name
            if directory.name=='receipts':
                for prefix in ('ar-orchestration-','orchestration-'):
                    if name.startswith(prefix):name=name[len(prefix):];break
            require(not name.startswith(('pairs','ar-pairs','ar-guard')),'retained pair/partial namespace')
    require(not (CONTROLS/'collection-driver-pairs-v12').exists(),'pair driver receipt already exists')
def physical(original,mapping,role,bref=None):
    a=dict(original);a['files']={mapping.get(k,{'copy':{'path':k}})['copy']['path']:v for k,v in original['files'].items()}
    if role=='R':a.update(original_B_anchor=bref['path'],original_B_anchor_sha256=bref['sha256']);a['files'][bref['path']]=bref['sha256']
    return a

def main():
    require(len(sys.argv)==3 and sys.flags.dont_write_bytecode and sys.pycache_prefix is None,'python3 -B request SHA')
    q=bound(dict(path=sys.argv[1],sha256=sys.argv[2]));flags(q)
    require(q['accepted_by_root'] is True and q['read_only_prerequisite_check_authorized'] is True and q['campaign_root']==str(ROOT),'actual root readback request')
    no_pairs();full=bound(q['full_R']);old=bound(q['full_R_predecessor'])
    for a in (full,old):require(a['schema']==1 and a['accepted_by_root'] is True and a['root']==str(ROOT),'accepted full R');check_map(a['files'])
    inherited(full['files'],old['files']);require(full['files'][q['full_R_predecessor']['path']]==q['full_R_predecessor']['sha256'] and full['current_pair_source_predecessor']==q['full_R_predecessor'],'R predecessor selector')
    dep=bound(q['deployment']);cal=bound(q['calibration_activation'])
    require(dep['campaign_root']==cal['campaign_root']==str(ROOT) and cal['held_excluded']==[5004,5006],'current deployment/calibration root')
    require(dep['accepted_by_root'] is True and cal['accepted_by_root'] is True and cal['collection_authorized'] is True and cal['qualification'] is False,'actual deployment/calibration')
    require(cal['deployment_binding']==q['deployment'] and cal['candidate_pair_collection_authorized'] is False,'original calibration binding')
    calref=dict(path=cal['anchor'],sha256=cal['anchor_sha256']);calanchor=bound(calref);check_map(calanchor['files'])
    require(calref==q['post_small_anchor'] and calref['path']==str(PROS/'post-small-source-anchor.accepted-v1.json'),'unchanged current calibrated source selector')
    require(full['files'][calref['path']]==calref['sha256'],'calibration anchor ref');inherited(full['files'],calanchor['files'])
    initialref=q['initial_source_anchor'];require(initialref['path']==str(PROS/'pre-c1-anchor.accepted-v2.json'),'current initial source selector');initial=bound(initialref)
    require(len(initial['files'])==q['initial_source_file_count'] and len(calanchor['files'])==q['post_small_source_file_count'] and type(q['initial_source_file_count']) is type(q['post_small_source_file_count']) is int and 0<q['initial_source_file_count']<=q['post_small_source_file_count'],'complete actual initial/calibrated closure');inherited(calanchor['files'],initial['files'])
    for key in ('driver','guard','selection'):
        r=q[key];canonical(r['path']);require(sha(r['path'])==r['sha256']==full['files'][r['path']],'current source selection')
    pinsref=dict(path=str(BASE/'qualification-v10-global-deployment-preparation-v2/immutable-pins.json'),sha256='2fccfac7a950aad6f397e15d94d5cc7b45d4b45ec5943d567c1a19e26cc4d406');pins=bound(pinsref)
    require(len(pins)==24 and full['files'][pinsref['path']]==pinsref['sha256'],'all24 original pins manifest')
    for name,digest in pins.items():require(full['files'][str(BASE/name)]==digest==sha(BASE/name),'original pin closure')
    gate=q['canonical_B_gate'];canonical(gate['path']);require(gate['path']==str(ROOT/'global-calibration-freeze.json') and full['files'][gate['path']]==gate['sha256']==sha(gate['path']),'canonical B gate')
    require(Path(gate['path']).read_bytes()==Path(full['original_B_global_gate']).read_bytes(),'canonical B gate exact same bytes')
    ga=bound(q['global54_content_acceptance']);gi=bound(q['global54_input']);flags(ga)
    require(ga['campaign_root']==str(ROOT) and ga['held_excluded']==[5004,5006] and gi['campaign_root']==str(ROOT) and gi['qualification'] is gi['collection_authorized'] is gi['candidate_pairs_authorized'] is False,'current GLOBAL scope')
    require(ga['accepted_by_root'] is True and ga['global54_actual_contents_accepted'] is True and ga['R_anchor']==q['full_R'] and ga['files']==full['files'],'GLOBAL full R selector/map')
    require(gi['accepted_by_root'] is True and gi['artifact_replay_authorized'] is True and gi['R_anchor']==q['full_R'] and gi['actual_global_content_acceptance']==q['global54_content_acceptance'] and gi['guard']==q['guard'] and gi['calibration_activation']==q['calibration_activation'],'actual GLOBAL input')
    ac=bound(q['physical34_actual_acceptance']);flags(ac)
    require(ac['schema']==1 and ac['accepted_by_root'] is True and ac['metadata_preservation_actual_contents_accepted'] is True and ac['no_pair_namespace_at_acceptance'] is True and ac['campaign_root']==str(ROOT) and ac['held_excluded']==[5004,5006],'actual physical34 acceptance')
    receipt=bound(ac['receipt']);require(receipt['accepted_by_root'] is False and receipt['status']=='PRESERVED_BYTES_ROOT_ACCEPTANCE_PENDING' and receipt['no_pair_namespace_at_completion'] is True,'original preservation receipt')
    require(ac['original_anchors']==receipt['original_anchors'] and ac['original_anchors']['R']==q['full_R'] and ac['global54_actual_content_acceptance']==receipt['global54_actual_content_acceptance']==q['global54_content_acceptance'],'physical original full R/GLOBAL binding')
    require(ac['mapping']==receipt['mapping'] and ac['consumer']==receipt['consumer'] and ac['request']==receipt['request'] and ac['preserved_completed_ns']==receipt['completed_ns'],'physical receipt binding')
    require(ac['consumer']['sha256']=='ccc5b23ed271b2bd814fc2678a7e4d99e72f0f381b4a39d37132ae570cdee97d' and receipt['prospective_rule_freeze']==q['prospective_rule_freeze'],'original consumer/rule');bound(receipt['prospective_rule_freeze']);require(sha(canonical(ac['consumer']['path']))==ac['consumer']['sha256'],'consumer hash')
    originals={k:bound(v) for k,v in ac['original_anchors'].items()};require(set(originals)=={'B','R'} and originals['R']==full,'both original anchors');inherited(full['files'],originals['B']['files'])
    require(ac['original_anchors']['B']==dict(path=full['original_B_anchor'],sha256=full['original_B_anchor_sha256']),'full original B selector')
    require(len(ac['mapping'])==34,'exact34 mapping');counts={('B','offline'):0,('R','offline'):0,('B','origins'):0,('R','origins'):0};copies=set()
    folder=Path(ac['receipt']['path']).parent;require(folder.resolve()==folder and folder.parent==ROOT,'canonical preservation directory')
    for n,path in enumerate(sorted(ac['mapping'])):
        item=ac['mapping'][path];require(set(item)=={'role','kind','original_sha256','copy'},'exact copy record');counts[(item['role'],item['kind'])]+=1
        require(item['copy']['path']==str(folder/(str(n).zfill(2)+'-'+Path(path).name)) and item['copy']['path'] not in copies,'exact exclusive copy path');copies.add(item['copy']['path'])
        require(item['original_sha256']==item['copy']['sha256']==full['files'][path]==sha(canonical(path)),'original34 bytes unchanged');bound(item['copy'])
    require(counts=={('B','offline'):20,('R','offline'):12,('B','origins'):1,('R','origins'):1},'exact20B12R2origin')
    require(set(ac['physical_anchors'])=={'B','R'},'both physical authorities')
    for role in ('B','R'):
        ph=bound(ac['physical_anchors'][role]);require(ph==physical(originals[role],ac['mapping'],role,ac['physical_anchors']['B'] if role=='R' else None),'physical exact map transformation');check_map(ph['files'])
        require(bound(receipt['retained_anchors'][role])==originals[role] and receipt['retained_anchors'][role]['sha256']==ac['original_anchors'][role]['sha256'],'retained original byte identity')
    now=time.time_ns();require(0<ga['accepted_ns']<=receipt['started_ns']<=receipt['completed_ns']<=ac['accepted_ns']<now,'pre-first-pair chronology')
    for key in ('original_B_global_gate','global_calibration_gate'):
        g=bound(dict(path=full[key],sha256=full['files'][full[key]]));require(g['accepted_by_root'] is True and g['qualification'] is False and 0<g['frozen_ns']<now,'original B/R global freeze')
    check_map(full['files']);no_pairs()
    print(json.dumps(dict(status='PAIR_LAUNCH_PREREQUISITE_READBACK_PASS',full_R=q['full_R'],full_R_predecessor=q['full_R_predecessor'],physical34_actual_acceptance=q['physical34_actual_acceptance'],preserved_count=34,pins_count=24,no_pair_namespace=True,checked_ns=now,qualification=False,collection_authorized=False,candidate_pairs_authorized=False),allow_nan=False))
if __name__=='__main__':main()
