"""Root additive artifact IO: retain R/calibration and bind canonical B gate.

No capture, database, numerical calculation, performance or pair authority.
The accepted original R anchor stays immutable. All24 dependencies are bound,
the canonical B gate is an exact exclusive copy, and original Inventory and R
prerequisite validators run before and after the new closure is published.
"""
if not __debug__:
    raise RuntimeError('unoptimized root assertions required')
from pathlib import Path
import copy
import hashlib
import json
import sys
import time
import types
sys.dont_write_bytecode = True

BASE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = BASE/'qualification-v12-refresh/qualification-v10'
OUT = ROOT/'full-R-canonical-B-closure-v12-v1'
TP = BASE/'qualification-v12-later-execution-preparation-v1/root-global-calibration-transition-v12-v1.py'
TP_SHA = 'cf8423134ae10c95ce56da97e4ae9e5d260416c84bfa43e39f0acf4ef46194ef'
PINS = BASE/'qualification-v10-global-deployment-preparation-v2/immutable-pins.json'
PINS_SHA = '2fccfac7a950aad6f397e15d94d5cc7b45d4b45ec5943d567c1a19e26cc4d406'
POST_SMALL = ROOT.parent/'qualification-v10-prospective-root-v1/post-small-source-anchor.accepted-v1.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ref(path):
    return dict(path=str(path), sha256=sha(path))


def read(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


assert len(sys.argv) == 3 and sys.pycache_prefix is None
request_path = Path(sys.argv[1])
assert sha(request_path) == sys.argv[2]
request = read(request_path)
assert request['schema'] == 1 and request['accepted_by_root'] is True
assert request['additive_full_R_canonical_B_io_authorized'] is True
assert request['campaign_root'] == str(ROOT) and request['held_excluded'] == [5004, 5006]
assert all(request[k] is False for k in ('qualification', 'performance_accepted',
    'collection_authorized', 'candidate_pairs_authorized', 'merge_authorized'))
assert request['helper'] == ref(Path(__file__).resolve())
assert request['transition_helper'] == dict(path=str(TP), sha256=TP_SHA)
assert sha(TP) == TP_SHA
for path in (TP, Path(__file__).resolve(), request_path):
    assert not (path.parent/'__pycache__').exists(), 'cached root/campaign import rejected'
t = types.ModuleType('root_original_transition')
t.__file__ = str(TP)
exec(compile(TP.read_bytes(), str(TP), 'exec'), t.__dict__)
expected_predecessor = t.OUT/'R-accept/external-anchor.accepted.json'
assert request['original_R_anchor'] == ref(expected_predecessor)
old = t.bound(request['original_R_anchor'])
assert old['root'] == str(ROOT) and old['accepted_by_root'] is True
review = t.bound(old['actual_artifact_content_review'])
assert review['status'] == 'R_ORIGINAL_DIAGNOSTIC_FREEZE_CONTENTS_ACCEPTED'
assert review['slots'] == 18 and review['groups'] == 6
assert all(review[k] is False for k in ('qualification', 'performance_accepted',
    'collection_authorized', 'candidate_pairs_authorized'))
for name in old['files']:
    if name.endswith('.py'):
        assert not (Path(name).parent/'__pycache__').exists(), 'cached inherited import rejected: '+name
ev = t.source(t.EV, 'full_closure_original_evaluator')
inv = ev.Inventory(request['original_R_anchor']['path'], request['original_R_anchor']['sha256'])
support = t.source(t.SUP, 'full_closure_original_R_support')
support.verify_prerequisites(inv, ev, read(t.RDEF), pairs=False)
seam = t.source(t.SEAM, 'full_closure_original_namespace')
seam.post_calibration_pre_pair(ROOT)
assert request['frozen_pins'] == dict(path=str(PINS), sha256=PINS_SHA)
assert old['files'][str(PINS)] == PINS_SHA and sha(PINS) == PINS_SHA
pins = read(PINS)
assert len(pins) == 24
assert request['post_small_anchor']['path'] == str(POST_SMALL)
POST_SMALL_SHA=request['post_small_anchor']['sha256']
post_small = t.bound(request['post_small_anchor'])
assert len(post_small['files']) == request['post_small_source_file_count'] and type(request['post_small_source_file_count']) is int and request['post_small_source_file_count'] > 0 and post_small['accepted_by_root'] is True
assert all(old['files'].get(path) == digest for path, digest in post_small['files'].items())
source_gate = Path(old['original_B_global_gate'])
canonical_gate = ROOT/'global-calibration-freeze.json'
assert source_gate == ROOT/'analysis-global-original-v1/global-calibration-freeze.json'
assert request['canonical_B_gate'] == dict(path=str(canonical_gate), sha256=old['original_B_global_gate_sha256'])
assert old['files'][str(source_gate)] == old['original_B_global_gate_sha256'] == sha(source_gate)
assert read(source_gate)['accepted_by_root'] is True
assert not canonical_gate.exists() and not canonical_gate.is_symlink(), 'retain conflicting canonical path; no overwrite'
assert not OUT.exists() and not OUT.is_symlink(), 'exclusive new additive closure only'
for rel, digest in pins.items():
    path = BASE/rel
    assert path.is_file() and path.resolve() == path and not path.is_symlink() and sha(path) == digest
    if str(path) in old['files']:
        assert old['files'][str(path)] == digest
OUT.mkdir(exist_ok=False)
with canonical_gate.open('xb') as stream:
    stream.write(source_gate.read_bytes())
assert canonical_gate.read_bytes() == source_gate.read_bytes()
anchor = copy.deepcopy(old)
files = anchor['files']
for path in (expected_predecessor, Path(__file__).resolve(), request_path, canonical_gate, POST_SMALL):
    t.add_file(files, path)
for rel in pins:
    t.add_file(files, BASE/rel)
assert all(files[path] == digest for path, digest in old['files'].items())
anchor.update(actual_file_count=len(files),
    current_pair_source_predecessor=request['original_R_anchor'],
    canonical_B_gate_binding=request['canonical_B_gate'],
    full_R_additive_closure_request=ref(request_path))
probe = OUT/'original-prerequisites-probe.json'
save(probe, anchor)
checked = ev.Inventory(probe, sha(probe))
support.verify_prerequisites(checked, ev, read(t.RDEF), pairs=False)
seam.post_calibration_pre_pair(ROOT)
assert all(anchor[k] == value for k, value in old.items()
    if k not in ('files', 'actual_file_count', 'actual_contents_accepted_ns'))
anchor['actual_contents_accepted_ns'] = time.time_ns()
final = OUT/'full-R-anchor.accepted.json'
save(final, anchor)
checked = ev.Inventory(final, sha(final))
support.verify_prerequisites(checked, ev, read(t.RDEF), pairs=False)
assert all(files[path] == digest for path, digest in old['files'].items())
assert files[str(canonical_gate)] == files[str(source_gate)] == request['canonical_B_gate']['sha256']
seam.post_calibration_pre_pair(ROOT)
result = dict(schema=1, status='ACTUAL_FULL_R_CANONICAL_B_COMPLETE24_CLOSURE_PASS',
    R_anchor=ref(final), original_R_anchor=request['original_R_anchor'],
    canonical_B_gate=request['canonical_B_gate'], canonical_B_gate_bytes_equal=True,
    full_predecessor_and_post_small_calibration_inherited=True,
    file_count=len(files), pins_count=len(pins), no_pair_namespace=True,
    checked_ns=time.time_ns(), qualification=False, performance_accepted=False,
    collection_authorized=False, candidate_pairs_authorized=False)
save(OUT/'actual-readback.json', result)
print(json.dumps(result, allow_nan=False))
