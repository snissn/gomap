"""Finite source-only adaptation; never imports or invokes execution helpers."""
from pathlib import Path
import ast,difflib,hashlib,json
BASE=Path('/Users/michaelseiler/dev/snissn/gomap/tmp/quicksilver-maintenance-5028-20261005')
OUT=BASE/'qualification-v12-later-execution-preparation-v1'
NATIVE='/home/mikers/quicksilver-maintenance-5028-20261006'
changes={};inputs={};outputs={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,value):
    with p.open('w' if p.exists() else 'x') as f:f.write(json.dumps(value,indent=2,allow_nan=False)+'\n')
def load(rel,name):
    p=BASE/rel;inputs[str(p)]=sha(p);s=p.read_text();return [p,name,s,s,[]]
def sub(item,old,new,count=None):
    assert old in item[3],(item[1],old)
    hits=item[3].count(old)
    if count is not None:assert hits==count,(item[1],old,hits)
    positions=[];offset=0
    for _ in range(hits):
        pos=item[3].index(old,offset);positions.append(pos);offset=pos+len(old)
    item[3]=item[3].replace(old,new);item[4].append([old,new,hits,positions])
def paths(item):
    sub(item,'qualification-v11','qualification-v12')
    sub(item,'v11','v12')
def emit(item):
    p,name,original,s,replacements=item
    compile(s,str(OUT/name),'exec');ast.parse(s)
    reversed_s=s
    for before,after,hits,positions in reversed(replacements):
        for index in reversed(range(hits)):
            pos=positions[index]+index*(len(after)-len(before))
            assert reversed_s[pos:pos+len(after)]==after,(name,pos)
            reversed_s=reversed_s[:pos]+before+reversed_s[pos+len(after):]
    assert reversed_s==original
    functions=lambda text:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    assert functions(reversed_s)==functions(original)
    if (OUT/name).exists():
        prior=json.loads((OUT/'exact-source-manifest.json').read_text())['outputs'][name]
        assert sha(OUT/name)==prior,'source preparation preimage drift'
    with (OUT/name).open('w' if (OUT/name).exists() else 'x') as f:f.write(s)
    with (OUT/(name+'.diff')).open('w' if (OUT/(name+'.diff')).exists() else 'x') as f:f.writelines(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile=str(p),tofile=str(OUT/name)))
    changes[name]=dict(original_path=str(p),original_sha256=sha(p),new_sha256=sha(OUT/name),replacements=replacements,all_function_ASTs_identical_after_declared_reversal=True,whole_original_source_bytes_exact_after_declared_reversal=True)
    outputs[name]=sha(OUT/name);return sha(OUT/name)
# Same request model as reviewed helpers; bind unknown fresh facts before use.
bootstrap='''\ndef actual_invocation_request():
    import sys
    assert len(sys.argv)==3 and sys.pycache_prefix is None
    p=Path(sys.argv[1]);assert p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink()
    assert sha(p)==sys.argv[2]
    q=read(p)
    assert q['schema']==1 and q['accepted_by_root'] is True and q['owner']=='/root'
    assert q['later_artifact_execution_authorized'] is True
    assert q['campaign_root']==str(ROOT) and q['held_excluded']==[5004,5006]
    assert q['helper']==remote_ref(Path(__file__).resolve())
    assert all(q[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
    return q
\n'''
rootrel='qualification-v11-root-preparation-v1/'
# Native scientific transition: all original functions remain except invocation binding.
i=load('qualification-v11-global-analysis-transition-preparation-v1/root-global-calibration-transition-v11-v1.py','root-global-calibration-transition-v12-v1.py');paths(i)
sub(i,"RDEF_SHA = '8717a8854760e9fe3997eff5db1456a3e9d11c9de5c4ea2f40f0ea01324d4863'\n",'',1)
sub(i,"OP_SHA = '2fafd3ea9214d951170c82d69a893e984dab0c984b47662f871d8547646c7f2a'\nOP_FILE_COUNT = 535\n",'',1)
sub(i,"        CALDRIVER:'fb852636b95f8c4b7484a9d54653195da1be95e18990e03cde3818dc654473cd',\n        SELECTED:'f19c9398f75c1c6f988e0ec21056634cf50b2d84e662b9649a13b0f48cf59bb9',\n",'',1)
sub(i,"        BDEF:BDEF_SHA, RDEF:RDEF_SHA}","        BDEF:BDEF_SHA}",1)
sub(i,'def main():\n','def main():\n    global OP, OP_SHA, OP_FILE_COUNT, RDEF, RDEF_SHA\n',1)
marker="    assert req['helper']==reference(Path(__file__).resolve())\n"
bind="""    OP=Path(req['initial_source_anchor']['path']);OP_SHA=req['initial_source_anchor']['sha256']
    assert OP==PROS/'pre-c1-anchor.accepted-v2.json'
    initial=bound(req['initial_source_anchor']);OP_FILE_COUNT=req['initial_source_file_count']
    assert type(OP_FILE_COUNT) is int and OP_FILE_COUNT==initial['actual_file_count']==len(initial['files']) and OP_FILE_COUNT>0
    RDEF=Path(req['R_definition']['path']);RDEF_SHA=req['R_definition']['sha256']
    assert RDEF==ROOT/'prospective-v10-root-v1/r-definition.accepted.json';bound(req['R_definition'])
    assert set(req['selected_controls'])=={'driver','selection'}
    for path,key in ((CALDRIVER,'driver'),(SELECTED,'selection')):
        selected=req['selected_controls'][key];assert selected['path']==str(path) and sha(path)==selected['sha256']
        assert isinstance(selected['sha256'],str) and len(selected['sha256'])==64
        PINS[path]=selected['sha256']
    PINS[RDEF]=RDEF_SHA
"""
sub(i,marker,marker+bind,1);transition_sha=emit(i)
# Native full-R closure: unchanged closure/gate/validator mechanics.
i=load(rootrel+'root-full-R-canonical-B-closure-v11-v1.py','root-full-R-canonical-B-closure-v12-v1.py');paths(i)
sub(i,"qualification-v12-global-analysis-transition-preparation-v1/root-global-calibration-transition-v12-v1.py","qualification-v12-later-execution-preparation-v1/root-global-calibration-transition-v12-v1.py",1)
sub(i,"'f9a3b897cb6194eabd0402bcad638f394577bd9b803561a4e03e7d703458cbf5'",repr(transition_sha),1)
sub(i,"POST_SMALL_SHA = 'b8117ff96f9d14d5a32d1b5810ebf1856f02ca6c9309974417ba77400c3e3824'\n",'',1)
sub(i,"assert request['post_small_anchor'] == dict(path=str(POST_SMALL), sha256=POST_SMALL_SHA)","assert request['post_small_anchor']['path'] == str(POST_SMALL)\nPOST_SMALL_SHA=request['post_small_anchor']['sha256']",1)
sub(i,"len(post_small['files']) == 722", "len(post_small['files']) == request['post_small_source_file_count'] and type(request['post_small_source_file_count']) is int and request['post_small_source_file_count'] > 0",1)
closure_sha=emit(i)
i=load(rootrel+'root-accept-physical34-v11-v1.py','root-accept-physical34-v12-v1.py');paths(i);physical_sha=emit(i)
# Original global analysis launcher; unchanged B prepare/pre/analysis/accept then R order.
i=load(rootrel+'root-run-original-global-analyses-v11-v1.py','root-run-original-global-analyses-v12-v1.py');paths(i)
sub(i,"RDEF_SHA = '8717a8854760e9fe3997eff5db1456a3e9d11c9de5c4ea2f40f0ea01324d4863'\n",'',1)
sub(i,"qualification-v12-global-analysis-transition-preparation-v1/root-global-calibration-transition-v12-v1.py","qualification-v12-later-execution-preparation-v1/root-global-calibration-transition-v12-v1.py",1)
sub(i,"'f9a3b897cb6194eabd0402bcad638f394577bd9b803561a4e03e7d703458cbf5'",repr(transition_sha),1)
sub(i,"sha256='ab32d6b6531f818b59dba398f91959eed89361f4d72d84986b30e6ee54523131'","sha256=actual_request['prospective_binding']['sha256']",1)
sub(i,'actual_calibration_activations=phase_refs, **extra)',"actual_calibration_activations=phase_refs, initial_source_anchor=actual_request['initial_source_anchor'], initial_source_file_count=actual_request['initial_source_file_count'], R_definition=actual_request['R_definition'], selected_controls=actual_request['selected_controls'], **extra)",1)
sub(i,"if __name__ == '__main__':",bootstrap+"if __name__ == '__main__':",1)
sub(i,'    assert __debug__\n    state = read(STATE)',"    assert __debug__\n    actual_request=actual_invocation_request()\n    RDEF_SHA=actual_request['R_definition']['sha256']\n    assert actual_request['R_definition']['path']==str(RDEF)\n    state = read(STATE)",1)
sub(i,"    assert phases['small']['sha256'] == 'f25ef420a84ea3a4c9f13cf4d6211f92404e4e0653a439ae55a6b3158291ec1b'\n    assert phases['calibration-rest']['sha256'] == '4c26e6ff056c80607517a59bf83bd017bf7870a67db3ef01b7cb68977b12bef6'", "    assert phases==actual_request['actual_phase_activations']",1)
sub(i,"        initial = dict(path=str(PROS/'pre-c1-anchor.accepted-v2.json'),\n            sha256='2fafd3ea9214d951170c82d69a893e984dab0c984b47662f871d8547646c7f2a')", "        initial=actual_request['initial_source_anchor']\n        assert initial['path']==str(PROS/'pre-c1-anchor.accepted-v2.json')",1)
emit(i)
# Full-R/GLOBAL launcher; request owns fresh manifest/composition/post-small/guard facts.
i=load(rootrel+'root-run-full-R-and-global54-v11-v1.py','root-run-full-R-and-global54-v12-v1.py');paths(i)
for variable in ('GUARD_SHA','POST_SMALL_SHA','MANIFEST','COMPOSITION'):
    line=next(line for line in i[3].splitlines(True) if line.startswith(variable+' ='));sub(i,line,'',1)
sub(i,"'ee0102c6d5281b5469f9b8d4d677935a13bdca0fb0cdf9ffc0e5585c2c800ad1'",repr(closure_sha),1)
sub(i,"'f9a3b897cb6194eabd0402bcad638f394577bd9b803561a4e03e7d703458cbf5'",repr(transition_sha),1)
sub(i,"qualification-v12-global-analysis-transition-preparation-v1/root-global-calibration-transition-v12-v1.py","qualification-v12-later-execution-preparation-v1/root-global-calibration-transition-v12-v1.py",1)
sub(i,"if __name__ == '__main__':",bootstrap+"if __name__ == '__main__':",1)
sub(i,'    assert __debug__\n    state = read(STATE)',"    assert __debug__\n    actual_request=actual_invocation_request()\n    GUARD_SHA=actual_request['guard']['sha256'];assert actual_request['guard']['path']==str(GUARD)\n    POST_SMALL_SHA=actual_request['post_small_anchor']['sha256'];assert actual_request['post_small_anchor']['path']==str(POST_SMALL)\n    MANIFEST=actual_request['manifest_sha256'];COMPOSITION=actual_request['composition_sha256']\n    state = read(STATE)",1)
sub(i,'post_small_anchor=dict(path=str(POST_SMALL),sha256=POST_SMALL_SHA),','post_small_anchor=dict(path=str(POST_SMALL),sha256=POST_SMALL_SHA),post_small_source_file_count=actual_request["post_small_source_file_count"],',1)
sub(i,"inp = read(BASE/'qualification-v12-pair-prerequisite-preparation-v1/global54-input.draft.json')", "template=actual_request['global54_input_template'];template_path=BASE/Path(template['path']).relative_to(REMOTE)\n        assert sha(template_path)==template['sha256']\n        inp=read(template_path)",1)
emit(i)
# Physical34 IO launcher; unchanged frozen consumer, exact acceptance helper transform.
i=load(rootrel+'root-run-physical34-preservation-v11-v1.py','root-run-physical34-preservation-v12-v1.py');paths(i)
sub(i,"if __name__=='__main__':",bootstrap+"if __name__=='__main__':",1)
sub(i,'    assert __debug__\n    state=read(STATE)',"    assert __debug__\n    actual_request=actual_invocation_request()\n    state=read(STATE)",1)
sub(i,"request=read(BASE/'qualification-v12-pair-prerequisite-preparation-v1/preservation-request.draft.json')", "template=actual_request['preservation_request_template'];template_path=BASE/Path(template['path']).relative_to(REMOTE)\n        assert sha(template_path)==template['sha256']\n        request=read(template_path)",1)
emit(i)
# Pair launcher and readback retain all gates; only current binding refs become input-derived.
pairrel='qualification-v11-pair-launch-runtime-preparation-v1/'
i=load(pairrel+'root-run-original-pairs-v11-v1.py','root-run-original-pairs-v12-v1.py');paths(i)
for variable in ('DRIVER_SHA','SELECTION_SHA','GUARD_SHA'):
    line=next(line for line in i[3].splitlines(True) if line.startswith(variable+'='));sub(i,line,'',1)
sub(i,"    adoption=local_bound(q['helper_source_acceptance']);", "    selected=q['selected_controls'];require(set(selected)=={'driver','selection','guard'},'exact current controls')\n    DRIVER_SHA=selected['driver']['sha256'];SELECTION_SHA=selected['selection']['sha256'];GUARD_SHA=selected['guard']['sha256']\n    adoption=local_bound(q['helper_source_acceptance']);",1)
start="    templates=BASE/'qualification-v12-pair-prerequisite-preparation-v1'\n"
a=i[3].index(start);z=i[3].index('    for t in (r,d):',a);old=i[3][a:z]
new="""    template_refs=q['activation_templates'];require(set(template_refs)=={'R','driver'},'exact current activation templates')
    r=local_bound(template_refs['R']);d=local_bound(template_refs['driver'])
    require(d['driver']==selected['driver'] and d['global54_guard']==selected['guard'] and selected['selection']['path']==str(REMOTE/'qualification-v12-fresh-controls-v1/deployment-helpers-selection.json'),'actual selected control refs')
"""
sub(i,old,new,1)
sub(i,"selection=dict(path=str(REMOTE/'qualification-v12-fresh-controls-v1/deployment-helpers-selection.json'),sha256=SELECTION_SHA),qualification=False", "selection=dict(path=str(REMOTE/'qualification-v12-fresh-controls-v1/deployment-helpers-selection.json'),sha256=SELECTION_SHA),initial_source_anchor=q['initial_source_anchor'],initial_source_file_count=q['initial_source_file_count'],post_small_anchor=q['post_small_anchor'],post_small_source_file_count=q['post_small_source_file_count'],prospective_rule_freeze=q['prospective_rule_freeze'],qualification=False",1)
emit(i)
i=load(pairrel+'pair-launch-prerequisite-readback-v11-v1.py','pair-launch-prerequisite-readback-v12-v1.py');paths(i)
sub(i,"require(calref==dict(path=str(PROS/'post-small-source-anchor.accepted-v1.json'),sha256='b8117ff96f9d14d5a32d1b5810ebf1856f02ca6c9309974417ba77400c3e3824'),'unchanged calibrated source selector')", "require(calref==q['post_small_anchor'] and calref['path']==str(PROS/'post-small-source-anchor.accepted-v1.json'),'unchanged current calibrated source selector')",1)
sub(i,"initialref=dict(path=str(PROS/'pre-c1-anchor.accepted-v2.json'),sha256='2fafd3ea9214d951170c82d69a893e984dab0c984b47662f871d8547646c7f2a');initial=bound(initialref)","initialref=q['initial_source_anchor'];require(initialref['path']==str(PROS/'pre-c1-anchor.accepted-v2.json'),'current initial source selector');initial=bound(initialref)",1)
sub(i,"len(initial['files'])==535 and len(calanchor['files'])==722,'original535/722 closure'", "len(initial['files'])==q['initial_source_file_count'] and len(calanchor['files'])==q['post_small_source_file_count'] and type(q['initial_source_file_count']) is type(q['post_small_source_file_count']) is int and 0<q['initial_source_file_count']<=q['post_small_source_file_count'],'complete actual initial/calibrated closure'",1)
sub(i,"receipt['prospective_rule_freeze']['sha256']=='b34dc2398c500b0378bb2f1a157664ff7a2da96ca72098cd86aa16d4f306513d'", "receipt['prospective_rule_freeze']==q['prospective_rule_freeze']",1)
emit(i)
# Frozen field validation and source evidence only; no invocation of adapted modules.
flags=dict(schema=1,source_only=True,accepted_by_root=False,qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False)
write(OUT/'declared-source-deltas-and-AST-verification.json',dict(flags,files=changes,no_modules_imported=True,no_helpers_executed=True))
write(OUT/'exact-source-manifest.json',dict(flags,inputs=inputs,outputs=outputs,constructor=dict(path=str(BASE/'qualification-v12-root-preparation-v1/construct-fresh-controls-v12.py'),sha256=sha(BASE/'qualification-v12-root-preparation-v1/construct-fresh-controls-v12.py')),future_actual_requests=None,future_generated_control_hashes=None,future_actual_acceptance_refs=None))
print(json.dumps(dict(sources=len(outputs),outputs=outputs,all_syntax_and_declared_reversal_checks_passed=True),indent=2))
