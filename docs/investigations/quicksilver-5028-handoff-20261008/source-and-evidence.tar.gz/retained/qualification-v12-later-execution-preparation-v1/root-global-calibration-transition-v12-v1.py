"""Root artifact transitions only. No capture, DB access, test, or launch.

The original analysis CLIs run separately. This helper replays their actual
raw evidence and changes only the specified draft acceptance flags. Every old
accepted source/raw binding and all original numeric/time fields survive.
CLI: REQUEST REQUEST_SHA256, stages B-pre/B-accept/R-pre/R-accept.
"""
if not __debug__:
    raise RuntimeError('root artifact review requires assertions')
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types
sys.dont_write_bytecode = True

BASE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = BASE/'qualification-v12-refresh/qualification-v10'
HERE = Path(__file__).resolve().parent
OUT = HERE/'qualification-v12-global-analysis-transitions-v1'
BOUT = ROOT/'analysis-global-original-v1'
ROUT = ROOT/'ar-analysis-global-original-v1'
PROS = ROOT.parent/'qualification-v10-prospective-root-v1'
EV = BASE/'qualification-prep/evaluator.py'
BD = BASE/'qualification-analysis-controller.py'
RD = BASE/'r-material-gate-preparation-v2/r-analysis-controller.py'
SUP = BASE/'r-material-gate-preparation-v2/r_protocol_support.py'
BDEF = BASE/'qualification-prep/revised-draft/protocol-definition-root-frozen.json'
RDEF = ROOT/'prospective-v10-root-v1/r-definition.accepted.json'
BDEF_SHA = '4005f6369837ecb7000d3a89b86aeac361b3c9d07ccc323450b60bfa4fbd6219'
OP = PROS/'pre-c1-anchor.accepted-v2.json'
GLOBAL = BASE/'qualification-v12-fresh-controls-v1'
SEAM = BASE/'qualification-v10-source-preparation-v2/post-calibration-identity-seam-v1.py'
CALDRIVER = GLOBAL/'collection-native-driver-v12-v1.py'
SELECTED = GLOBAL/'deployment-helpers-selection.json'
PINS = {SEAM:'78b660b14f7eeab54a7fb18a5d298c0b74cce7386af2f50b0080419fbf1bee2b',
        EV:'9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd',
        BD:'e5744ead53031c489e3345c16a48c0b2e7b91c577177d50d25d94adfbe7b79fd',
        RD:'433c5df7016136afc8920b6663c5c0ed5d167cea993b35554a0b54a663764dc6',
        SUP:'0f2590a04e3959110e5e5d6f5e2e350a7476a162cbe925939de52191a7efc810',
        BDEF:BDEF_SHA}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1<<20), b''):
            h.update(block)
    return h.hexdigest()

def read(path): return json.loads(Path(path).read_bytes())

def save(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n')

def reference(path): return dict(path=str(path), sha256=sha(path))

def bound(ref):
    assert set(ref)=={'path','sha256'}
    p=Path(ref['path'])
    assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve()==p
    assert sha(p)==ref['sha256'], str(p)
    return read(p)

def source(path, name):
    assert sha(path)==PINS[path]
    assert sys.pycache_prefix is None and not (path.parent/'__pycache__').exists()
    m=types.ModuleType(name); m.__file__=str(path)
    exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__)
    return m

def add_file(files, path):
    p=Path(path); canonical=p.resolve(strict=True); actual=sha(p)
    assert canonical.is_file()
    existing=[name for name in files if Path(name).resolve(strict=True)==canonical]
    assert len(existing)<=1, 'duplicate canonical aliases'
    if existing:
        assert files[existing[0]]==actual, str(p)
        return
    assert p.is_absolute() and p==canonical and not p.is_symlink()
    files[str(p)]=actual

def merge(files, incoming):
    for name, expected in incoming.items():
        assert sha(name)==expected, name
        add_file(files, name)

def no_pairs(groups):
    # Reuse the accepted closed namespace rule; do not invent a weaker prefix.
    source(SEAM,'root_original_post_calibration_seam').post_calibration_pre_pair(ROOT)
    assert all(not Path(name).parent.exists() for g in groups for name in g['runs'])


def accepted_flags(path, fields, retained=None):
    before_bytes=path.read_bytes(); before=json.loads(before_bytes)
    assert all(before[k] is False for k in fields), 'already/partly accepted draft'
    if retained is None:
        retained=path.with_name(path.stem+'.root-unaccepted-retained.json')
        with retained.open('xb') as f: f.write(before_bytes)
    else:
        assert retained.resolve(strict=True)==retained and not retained.is_symlink()
        assert retained.read_bytes()==before_bytes, 'immutable pending metadata copy drift'
    after=copy.deepcopy(before)
    for k in fields: after[k]=True
    assert {k:v for k,v in before.items() if k not in fields}=={k:v for k,v in after.items() if k not in fields}
    pending=path.with_name(path.name+'.root-accepting')
    save(pending,after); os.replace(pending,path)
    assert read(path)==after
    return retained


def predecessor(stage, ref, base):
    operational=bound(dict(path=str(OP),sha256=OP_SHA))
    assert operational['accepted_by_root'] is True and operational['root']==str(ROOT)
    assert operational['actual_file_count']==len(operational['files'])==OP_FILE_COUNT
    assert all(base['files'].get(k)==v for k,v in operational['files'].items()), 'exact fresh pre-C1 source inheritance'
    fixed=('campaign_id','evaluator','harness_files','controls','accounting_policy','accounting_freeze',
           'accounting_checker','executed_controllers','deployment_binding','v10_root_input',
           'v10_root_input_sha256','native_correctness_receipt','held_excluded','accepted_fixtures',
           'fixture_source_applicability','prospective_rule_freeze','source_frozen_ns',
           'historical_calibration_or_pair_results_reused','pre_pair_global54_root_guard_required',
           'complete_unchanged_deployment_import_set','retained_failed_direct_preflight',
           'predecessor_source_anchor','actual_native_readback')
    assert all(base[k]==operational[k] for k in fixed), 'accepted fresh pre-C1 context drift'
    paths={'B-pre':OP,'B-accept':OUT/'B-pre/external-anchor.accepted.json',
           'R-pre':OUT/'B-accept/external-anchor.accepted.json',
           'R-accept':OUT/'R-pre/external-anchor.accepted.json'}
    assert ref['path']==str(paths[stage]) and ref==reference(paths[stage]), 'exact stage predecessor'
    if stage=='B-pre':
        assert ref['sha256']==OP_SHA
    else:
        prior={'B-accept':'B','R-pre':'B','R-accept':'R'}[stage]
        reviewed=bound(base['actual_artifact_content_review'])
        expected=(prior+'_ORIGINAL_DIAGNOSTIC_FREEZE_CONTENTS_ACCEPTED' if stage=='R-pre' else
                  prior+'_ORIGINAL_RAW_AND_ORIGINS_REVIEW_PASS')
        assert reviewed['status']==expected
        assert reviewed['qualification'] is reviewed['performance_accepted'] is reviewed['collection_authorized'] is reviewed['candidate_pairs_authorized'] is False
        assert base['files'][base['actual_artifact_content_review']['path']]==base['actual_artifact_content_review']['sha256']
    return operational


def calibration_receipts(files, request):
    driver=source(CALDRIVER,'root_original_calibration_driver')
    intervals=[]; rows=[]
    assert set(request['actual_calibration_activations'])=={'small','calibration-rest'}
    assert len({ref['path'] for ref in request['actual_calibration_activations'].values()})==2
    operational=bound(dict(path=str(OP),sha256=OP_SHA))
    for phase in ('small','calibration-rest'):
        ref=request['actual_calibration_activations'][phase]
        activation_path=Path(ref['path']);digest=ref['sha256']
        assert activation_path.parent==PROS, 'exact fresh phase activation namespace'
        activation=bound(ref); add_file(files,activation_path)
        assert activation['accepted_by_root'] is True and activation['collection_authorized'] is True
        assert activation['qualification'] is False and activation['candidate_pair_collection_authorized'] is False
        assert activation['driver']==reference(CALDRIVER) and activation['phase']==phase
        assert activation['helper_selection_sha256']==PINS[SELECTED]
        deployment=bound(activation['deployment']);calibration=bound(activation['calibration_activation'])
        for p in (activation['deployment']['path'],activation['calibration_activation']['path']): add_file(files,p)
        assert activation['deployment']==dict(path=str(PROS/'deployment.accepted.json'),sha256='35a583de6c91c5bb7f00a8df2b82e9a8b43f0da2694c4ee069375ecd6fe4affe')
        assert deployment['campaign_root']==calibration['campaign_root']==activation['campaign_root']==str(ROOT)
        assert calibration['qualification'] is False and calibration['candidate_pair_collection_authorized'] is False
        calibration_anchor_ref=dict(path=calibration['anchor'],sha256=calibration['anchor_sha256'])
        calibration_anchor=bound(calibration_anchor_ref);add_file(files,calibration_anchor_ref['path'])
        assert calibration_anchor['accepted_by_root'] is True and calibration_anchor['root']==str(ROOT)
        assert all(calibration_anchor['files'].get(k)==v for k,v in operational['files'].items()), 'exact fresh pre-C1 calibration source inheritance'
        assert calibration_anchor['deployment_binding']==operational['deployment_binding'] and calibration_anchor['prospective_rule_freeze']==operational['prospective_rule_freeze']
        assert calibration_anchor['v10_root_input']==operational['v10_root_input'] and calibration_anchor['v10_root_input_sha256']==operational['v10_root_input_sha256']
        assert calibration_anchor['source_frozen_ns']==operational['source_frozen_ns']
        merge(files,calibration_anchor['files'])
        binding=calibration['prospective_binding'];bound(binding);add_file(files,binding['path'])
        assert binding==dict(path=str(ROOT/'prospective-v10-root-v1/pre-c1-binding.json'),sha256=operational['files'][str(ROOT/'prospective-v10-root-v1/pre-c1-binding.json')])
        controllers=deployment['executed_controllers']
        expected={label:argv for label,argv,_ in driver.commands(phase,controllers,None)}
        if phase=='small':
            expected['binder-check']=['python3','-B',deployment['helpers']['binder']['path'],'check',binding['path'],binding['sha256'],activation['calibration_activation']['path'],activation['calibration_activation']['sha256']]
        verifier=calibration['deployment_verifier']
        expected['deployment-check']=['python3','-B',verifier['path'],activation['deployment']['path'],activation['deployment']['sha256'],binding['path'],binding['sha256'],activation['calibration_activation']['path'],activation['calibration_activation']['sha256']]
        folder=GLOBAL/('collection-driver-'+phase+'-v12')
        complete=read(folder/'complete.json')
        assert set(complete)=={'schema','status','phase','rc','finished_ns','activation_sha256','qualification'}
        assert complete['schema']==1 and complete['status']=='STAGE_JOINED_ROOT_CONTENT_REVIEW_REQUIRED'
        assert complete['phase']==phase and complete['rc']==0 and complete['qualification'] is False and complete['activation_sha256']==digest
        assert {p.name for p in folder.iterdir()}==set(expected)|{'complete.json'}, 'closed exact command coverage'
        phase_intervals=[]
        for label,argv in expected.items():
            p=folder/label;assert p.is_dir() and not p.is_symlink() and p.resolve()==p
            assert {raw.name for raw in p.iterdir()}=={'started.json','complete.json','stdout.txt','stderr.txt'}
            started=read(p/'started.json'); row=read(p/'complete.json')
            assert all(row[k]==v for k,v in started.items()), 'actual started/complete identity drift'
            assert row['schema']==1 and row['owner']=='/root' and row['phase']==phase and row['argv']==argv
            assert row['qualification'] is False and row['activation_sha256']==digest
            assert row['rc']==0 and not any(row.get(k) for k in ('timeout','error','cleanup_error')) and row['raw_hashes_final'] is True
            assert row['process_group_cleanup']['quiescent'] is True and row['process_group_cleanup']['direct_child_joined'] is True
            assert type(row['started_ns']) is type(row['finished_ns']) is int and activation['authorized_ns']<=row['started_ns']<row['finished_ns']<=complete['finished_ns']
            for stream in ('stdout','stderr'):
                assert sha(p/(stream+'.txt'))==row[stream+'_sha256']
            for raw in p.iterdir(): assert raw.is_file() and not raw.is_symlink(); add_file(files,raw)
            phase_intervals.append((row['started_ns'],row['finished_ns']))
            rows.append(dict(phase=phase,label=label,argv=argv,complete=reference(p/'complete.json')))
        phase_intervals.sort();assert all(a[1]<=b[0] for a,b in zip(phase_intervals,phase_intervals[1:]))
        intervals.extend(phase_intervals);add_file(files,folder/'complete.json')
    intervals.sort();assert all(a[1]<=b[0] for a,b in zip(intervals,intervals[1:]))
    assert len(rows)==12
    return rows


def original_analysis_execution(request, role, out, slots, base_ref, files):
    refs=request['original_analysis_execution'];assert set(refs)=={'run','stdout','stderr'}
    execution=bound(refs['run'])
    for k in ('stdout','stderr'):
        p=Path(refs[k]['path']);assert reference(p)==refs[k] and p.resolve(strict=True)==p and not p.is_symlink()
        assert execution[k]['sha256']==sha(p) and execution[k]['bytes']==p.stat().st_size
        add_file(files,p)
    add_file(files,refs['run']['path'])
    expected=['python3','-B',str(BD if role=='B' else RD),'full-calibration','--campaign',str(ROOT),'--out',str(out)]
    if role=='R':
        pre=bound(base_ref)
        expected+=['--original-B-anchor',pre['original_B_anchor'],'--original-B-anchor-sha256',pre['original_B_anchor_sha256'],
                   '--definition',str(RDEF),'--definition-sha256',RDEF_SHA]
    expected+=['--anchor',base_ref['path'],'--anchor-sha256',base_ref['sha256']]
    assert execution['native_argv']==expected and execution['rc']==0 and not execution.get('error')
    assert type(execution['started_ns']) is type(execution['finished_ns']) is int and 0<execution['started_ns']<execution['finished_ns']
    assert not Path(refs['stderr']['path']).read_bytes()
    result=read(refs['stdout']['path'])
    assert result==dict(status='analysis_complete_root_review_required',stage='full-calibration',slots=sorted(slots),qualification=False)
    return execution


def main():
    global OP, OP_SHA, OP_FILE_COUNT, RDEF, RDEF_SHA
    assert len(sys.argv)==3
    reqpath=Path(sys.argv[1]); reqref=dict(path=str(reqpath),sha256=sys.argv[2]); req=bound(reqref)
    assert req['schema']==1 and req['accepted_by_root'] is True and req['artifact_transition_authorized'] is True
    assert req['qualification'] is req['performance_accepted'] is req['collection_authorized'] is req['candidate_pairs_authorized'] is False
    assert req['campaign_root']==str(ROOT) and req['held_excluded']==[5004,5006]
    assert req['helper']==reference(Path(__file__).resolve())
    OP=Path(req['initial_source_anchor']['path']);OP_SHA=req['initial_source_anchor']['sha256']
    assert OP==PROS/'pre-c1-anchor.accepted-v2.json'
    initial=bound(req['initial_source_anchor']);OP_FILE_COUNT=req['initial_source_file_count']
    assert type(OP_FILE_COUNT) is int and OP_FILE_COUNT==initial['actual_file_count']==len(initial['files']) and OP_FILE_COUNT>0
    RDEF=Path(req['R_definition']['path']);RDEF_SHA=req['R_definition']['sha256']
    assert RDEF==ROOT/'prospective-v10-root-v1/r-definition.accepted.json';bound(req['R_definition'])
    assert set(req['selected_controls'])=={'driver','selection'}
    for path,key in ((CALDRIVER,'driver'),(SELECTED,'selection')):
        selected=req['selected_controls'][key];assert selected['path']==str(path) and sha(path)==selected['sha256']
        assert isinstance(selected['sha256'],str) and len(selected['sha256'])==64
        PINS[path]=selected['sha256']
    PINS[RDEF]=RDEF_SHA
    stage=req['stage']; assert stage in ('B-pre','B-accept','R-pre','R-accept')
    role=stage[0]; pre=stage.endswith('-pre'); out=BOUT if role=='B' else ROUT
    expected_driver=BD if role=='B' else RD; definition=BDEF if role=='B' else RDEF
    for p,h in PINS.items(): assert sha(p)==h
    base=bound(req['base_anchor']); assert base['accepted_by_root'] is True and base['root']==str(ROOT)
    operational=predecessor(stage,req['base_anchor'],base)
    ev=source(EV,'root_original_evaluator')
    oldinv=ev.Inventory(req['base_anchor']['path'],req['base_anchor']['sha256'])
    for name in oldinv.files:
        if name.endswith('.py'): assert not (Path(name).parent/'__pycache__').exists()
    support=source(SUP,'r_protocol_support'); sys.modules['r_protocol_support']=support
    driver=source(expected_driver,'root_original_'+role+'_analysis')
    driver.DEFINITION=definition; driver.DEFINITION_SHA=sha(definition)
    groups,slots,origins=driver.layout(ROOT,out,read(definition)); no_pairs(groups)
    assert len(groups)==(13 if role=='B' else 6) and len(slots)==(36 if role=='B' else 18)
    files=dict(base['files']); add_file(files,Path(req['base_anchor']['path']))
    add_file(files,Path(__file__).resolve()); add_file(files,reqpath)
    for p in PINS: add_file(files,p)
    # Preserve genuine request-selected phase activations and their actual freezes.
    for entry in req['actual_calibration_activations'].values():
        phase_activation=bound(entry);add_file(files,entry['path'])
        add_file(files,phase_activation['calibration_activation']['path'])
    command_rows=calibration_receipts(files,req)
    work=OUT/stage; work.mkdir(parents=True,exist_ok=False)
    a=copy.deepcopy(base)
    # New raw contents are not accepted at the predecessor's old timestamp.
    # Its exact JSON remains inherited and the operational provenance survives.
    a.pop('actual_contents_accepted_ns',None)
    a['operational_source_actual_contents_accepted_ns']=operational['actual_contents_accepted_ns']
    a.update(driver=str(expected_driver),definition=str(definition),global_calibration_gate=str(out/'global-calibration-freeze.json'),
             files=files,qualification=False,collection_authorized=False,candidate_pair_collection_authorized=False,
             created_ns=time.time_ns(),supersedes=req['base_anchor'],artifact_transition_request=reqref)
    if role=='R' and pre:
        assert base['driver']==str(BD) and base['definition']==str(BDEF)
        b_gate=base['global_calibration_gate']; assert sha(b_gate)==base['files'][b_gate]
        binding=bound(req['prospective_binding'])
        a.update(original_B_anchor=req['base_anchor']['path'],original_B_anchor_sha256=req['base_anchor']['sha256'],
                 original_B_global_gate=b_gate,original_B_global_gate_sha256=sha(b_gate),original_B_definition=str(BDEF),
                 calibration_applicability=base['calibration_applicability'],r_prospective_policy_extension=binding['r_prospective_policy_extension'])
    if pre:
        draft=out/'external-anchor.draft.json'; assert reference(draft)==req['prepared_draft']
        d=read(draft); assert d['accepted_by_root'] is False and d['root']==str(ROOT)
        assert d['driver']==str(expected_driver) and d['definition']==str(definition) and d['harness_files']==base['harness_files']
        merge(files,d['files']); add_file(files,draft)
        op=out/'guard-origins.json'; origin=read(op)
        assert origin['runs']==origins and len(origins)==(39 if role=='B' else 18)
        assert all(origin[k] is False for k in ('accepted_by_root','inplace_no_reload_restore','before_after_census_retained'))
        assert str(op) not in base['files'], 'only new pending origin metadata may be remapped'
        retained=work/'guard-origins.pre-review-retained.json'
        with retained.open('xb') as f:f.write(op.read_bytes())
        assert sha(retained)==files[str(op)]
        diagnostic_value=copy.deepcopy(a)
        diagnostic_value['files'].pop(str(op))
        diagnostic_value['files'][str(retained)]=sha(retained)
        diagnostic_value['actual_file_count']=len(diagnostic_value['files'])
        diagnostic_value.update(diagnostic_raw_replay_only=True,analysis_authorized=False,
            pending_origin_metadata_remap=dict(original=reference(op),retained=reference(retained),
                note='Only new draft origin metadata is retained at an immutable physical path. Every fresh pre-C1 source and every current raw/source binding is exact. No analysis authority.'))
        diagnostic=work/'diagnostic-raw-anchor.json'; save(diagnostic,diagnostic_value)
        inv=ev.Inventory(diagnostic,sha(diagnostic)); collector,maintenance=ev.load_collectors(inv)
        rows=[]; intervals=[]; common=None
        for g in groups:
            originals=[ev.load_original(inv,collector,maintenance,p,g['kind']) for p in g['calibration']]
            guards=[ev.load_run(inv,collector,p) for p in slots[g['cell']+'-service-final']['calibration']]
            assert [x['run']['cell']['label'] for x in originals]==['C1','C2','C3']
            assert all(x['run']['cell']['source']==('A_unified' if g['kind']=='online' else 'A') for x in originals)
            assert all(x['original_contract']==originals[0]['original_contract'] and x['run']['source']==originals[0]['run']['source'] for x in originals)
            for original,guard in zip(originals,guards):
                ci=original['common_inventory']; assert common is None or common==ci; common=ci
                assert ev.common_inventory(inv,guard['name'],guard['run'])==ci
                provenance=origin['runs'][guard['name']]
                assert provenance['original_run']==original['name'] and provenance['kind']==g['kind']
                assert Path(original['directory']).resolve()==Path(provenance['directory']).resolve()==Path(guard['run']['cell']['measure_dir']).resolve()
                assert original['run']['cell']['label']==guard['run']['cell']['label'] and original['run']['source']['head']==guard['run']['source']['head']
                assert original['finished_ns']<int(guard['run']['started']*1e9)
                assert guard['report']['measurement_state']=='retained final fixture; pre/post full oracle; no population reload or restore'
                intervals.extend([(original['started_ns'],original['finished_ns']),(int(guard['run']['started']*1e9),int(guard['run']['finished']*1e9))])
                rows.append(dict(cell=g['cell'],kind=g['kind'],label=original['run']['cell']['label'],original=original['name'],guard=guard['name'],
                    original_started_ns=original['started_ns'],original_finished_ns=original['finished_ns'],
                    guard_started_ns=int(guard['run']['started']*1e9),guard_finished_ns=int(guard['run']['finished']*1e9),
                    policy_complete=True if g['kind']=='offline' else None,full_original_and_guard_replay=True,
                    inplace_directory=provenance['directory'],before_after_census_retained=True))
        intervals.sort(); assert all(x[1]<=y[0] for x,y in zip(intervals,intervals[1:]))
        rule=bound(base['prospective_rule_freeze']); assert rule['frozen_ns']<intervals[0][0]
        prebinding=bound(req['prospective_binding']); assert prebinding['common_inventory']==common
        retained=accepted_flags(op,('accepted_by_root','inplace_no_reload_restore','before_after_census_retained'),retained=retained)
        # The retained diagnostic remains physically hash-valid after acceptance.
        ev.Inventory(diagnostic,sha(diagnostic))
        files[str(op)]=sha(op); add_file(files,retained)
        a.update(current_calibration_common_inventory=common,calibration_raw_contents_accepted=True,
                 calibration_original_count=len(rows),calibration_state_specific_guard_count=len(rows),
                 all_current_calibration_and_guard_intervals_serial=True)
        report=dict(schema=1,status=role+'_ORIGINAL_RAW_AND_ORIGINS_REVIEW_PASS',rows=rows,common_inventory=common,
                    baseline_count=len(rows),guard_count=len(rows),first_C_ns=intervals[0][0],rule_frozen_ns=rule['frozen_ns'],
                    qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,reviewed_ns=time.time_ns())
    else:
        assert base['driver']==str(expected_driver) and base['definition']==str(definition)
        gatepath=out/'global-calibration-freeze.json'; gate=read(gatepath)
        assert gate['accepted_by_root'] is False and gate['candidate_collection_accepted_by_root'] is False and gate['qualification'] is False
        assert gate['original_pair_groups']==groups and gate['definition_sha256']==sha(definition)
        assert gate['input_anchor_sha256']==req['base_anchor']['sha256']
        assert gate['offline_cells_complete']==10 and gate['offline_noise_metrics']==['elapsed_seconds','peak_rss_bytes'] and gate['all_selected_service_online_noises_frozen'] is True
        assert gate['noise_freeze_receipts']==[str(out/(name+'.freeze.json')) for name in sorted(slots)], 'exact original sorted freeze references'
        execution=original_analysis_execution(req,role,out,slots,req['base_anchor'],files)
        assert execution['started_ns']<=gate['frozen_ns']<=execution['finished_ns']
        unknown=[]; freezes=[]; numerical=[]
        for name in sorted(slots):
            bundle=out/(name+'.bundle.json'); assert read(bundle)==slots[name]
            fp=out/(name+'.freeze.json'); np=out/(name+'.noise.json'); f=read(fp); n=read(np)
            assert f['accepted_by_root'] is False and f['qualification'] is False and f['noise_cell']==name and f['noise']==str(np)
            assert f['definition_sha256']==sha(definition) and f['noise_sha256']==sha(np) and f['input_anchor_sha256']==req['base_anchor']['sha256']
            assert type(n['created_ns']) is int and type(f['frozen_ns']) is int and execution['started_ns']<=n['created_ns']<=f['frozen_ns']<=gate['frozen_ns']<=execution['finished_ns']<time.time_ns()
            u=driver.unresolved_metrics(name,n); assert u==f['unresolved_noise_metrics']; unknown.extend(u)
            paths=slots[name]['calibration_runs' if 'metric' in slots[name] else 'calibration']
            finish=[read(p)['finished_ns'] if 'metric' in slots[name] else int(read(p)['finished']*1e9) for p in paths]
            assert max(finish)<n['created_ns']
            freezes.append(fp); numerical.append(dict(noise_cell=name,noise=reference(np),freeze_before_acceptance=reference(fp),
                                                     values=n.get('values'),E=n.get('E'),ledger=n.get('ledger'),unresolved_noise_metrics=u))
        order=lambda rows:sorted(rows,key=lambda x:(x['noise_cell'],x['id']))
        assert order(unknown)==order(gate['unresolved_noise_metrics'])
        for fp in freezes:
            add_file(files,accepted_flags(fp,('accepted_by_root',)))
            add_file(files,fp); add_file(files,fp.with_name(fp.name.replace('.freeze.json','.noise.json')))
        add_file(files,accepted_flags(gatepath,('accepted_by_root','candidate_collection_accepted_by_root'))); add_file(files,gatepath)
        if role=='B':
            app=work/'calibration-applicability.accepted.json'
            save(app,dict(schema=1,accepted_by_root=True,qualification=False,common_inventory=base['current_calibration_common_inventory'],
                original_B_global_gate_sha256=sha(gatepath),frozen_ns=time.time_ns(),
                A_source_binary_equal=True,fixture_restore_equal=True,native_env_host_equal=True,harness_observer_equal=True,
                finite_work_and_state_specific_guards_equal=True,no_diagnostic_or_historical_inputs=True,
                note='Actual full current39C/39guards replay retained in B-pre report. Post-B applicability; original pre-C1 reuse applicability and allocation extension remain immutable.'))
            add_file(files,app); a['calibration_applicability']=str(app)
        a.update(actual_calibration_observations_accepted=True,original_analysis_execution=req['original_analysis_execution'],unresolved_noise_metrics=unknown)
        report=dict(schema=1,status=role+'_ORIGINAL_DIAGNOSTIC_FREEZE_CONTENTS_ACCEPTED',slots=len(slots),groups=len(groups),
                    global_gate=reference(gatepath),original_frozen_ns=gate['frozen_ns'],numerical=numerical,
                    original_analysis_execution=req['original_analysis_execution'],original_math_replay_still_required_by_GLOBAL54=True,
                    unresolved_noise_metrics=unknown,numerical_UNKNOWN_can_pass=False,
                    legacy_candidate_collection_flag_is_not_external_pair_authority=True,
                    qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,reviewed_ns=time.time_ns())
    no_pairs(groups)
    # Validate complete actual closure and inherited R gates before publishing
    # the final accepted report/anchor. Retain an explicitly interim probe.
    prerequisite=work/'prepublication-prerequisite-probe.json'
    probe=copy.deepcopy(a);probe.update(interim_prerequisite_probe_only=True,analysis_authorized=False,actual_file_count=len(files))
    save(prerequisite,probe)
    checked=ev.Inventory(prerequisite,sha(prerequisite))
    if role=='R':support.verify_prerequisites(checked,ev,read(RDEF),pairs=False)
    add_file(files,prerequisite)
    report['reviewed_ns']=time.time_ns()
    a['actual_contents_accepted_ns']=report['reviewed_ns']
    a['note']='Root current artifact transition '+stage+' accepted at actual review time; original/source/raw/C/rule/noise bindings and timestamps retained. No performance, qualification, collection or pair authority.'
    report.update(exact_original_command_rows=command_rows,exact_pre_c1_source_anchor=dict(path=str(OP),sha256=OP_SHA),
                  namespace_checked_with_original_accepted_seam=True,prepublication_prerequisites_passed=True)
    reportpath=work/'actual-content-review.json'; save(reportpath,report); add_file(files,reportpath)
    a['actual_artifact_content_review']=reference(reportpath)
    a['actual_file_count']=len(files)
    assert all(files[k]==v for k,v in base['files'].items()), 'previous exact accepted file map must survive'
    ap=work/'external-anchor.accepted.json'; save(ap,a)
    finalinv=ev.Inventory(ap,sha(ap))
    assert all(finalinv.files[k]==v for k,v in base['files'].items())
    no_pairs(groups)
    print(json.dumps(dict(status=report['status'],anchor=reference(ap),report=reference(reportpath),files=len(files),
                         baseline_count=report.get('baseline_count'),guard_count=report.get('guard_count'),
                         slots=report.get('slots'),unresolved_noise_metrics=report.get('unresolved_noise_metrics'),
                         qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False),allow_nan=False))

if __name__=='__main__': main()
