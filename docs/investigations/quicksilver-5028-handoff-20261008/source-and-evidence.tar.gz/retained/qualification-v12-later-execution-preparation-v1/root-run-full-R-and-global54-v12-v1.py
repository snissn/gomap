"""Root artifact handoff after actual original39/B36/R18 acceptance.

Prepared only until invoked. No capture, database access or pair authority.
Original Inventory, R prerequisites and GLOBAL54 replay own their checks.
"""
from pathlib import Path
import hashlib
import json
import os
import time
import types

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
REMOTE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = REMOTE/'qualification-v12-refresh/qualification-v10'
PROS = ROOT.parent/'qualification-v10-prospective-root-v1'
STATE = BASE/'state.json'
RECEIPTS = BASE/'qualification-v9-selected-source-preparation-v1'
HELPER = HERE/'root-full-R-canonical-B-closure-v12-v1.py'
HELPER_SHA = '2f7ff00a0275cb506001dd50efbcbfbdab910252c25e366f7501608fbdbd7092'
GUARD = REMOTE/'qualification-v12-fresh-controls-v1/global54-artifact-guard-v12-operational-v1.py'
PINS = REMOTE/'qualification-v10-global-deployment-preparation-v2/immutable-pins.json'
PINS_SHA = '2fccfac7a950aad6f397e15d94d5cc7b45d4b45ec5943d567c1a19e26cc4d406'
POST_SMALL = PROS/'post-small-source-anchor.accepted-v1.json'


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def remote_ref(path):
    return dict(path=str(REMOTE/path.relative_to(BASE)), sha256=sha(path))


def runtime(**fields):
    state = read(STATE)
    state.update(fields)
    pending = HERE/('state-full-R-global54-'+str(time.time_ns())+'.json')
    save(pending, state)
    pending.replace(STATE)


def actual(label):
    row = read(RECEIPTS/(label+'-run.json'))
    assert row['rc'] == 0 and not row.get('error')
    assert 0 < row['started_ns'] < row['finished_ns']
    for channel in ('stdout', 'stderr'):
        path = RECEIPTS/(label+'-'+channel+'.txt')
        assert row[channel] == dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))
    assert not (RECEIPTS/(label+'-stderr.txt')).read_bytes()
    return row


def bound_read(ref, label, gates=False):
    code = '''from pathlib import Path
import hashlib,json,sys,time
p=Path(sys.argv[1]);expected=sys.argv[2]
assert p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink()
assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
a=json.loads(p.read_bytes());assert a['accepted_by_root'] is True
v=dict(ref=dict(path=str(p),sha256=expected),anchor=a,read_ns=time.time_ns())
if sys.argv[3]=='gates':
 v['gates']={}
 for role,key in [('B','original_B_global_gate'),('R','global_calibration_gate')]:
  g=Path(a[key]);d=hashlib.sha256(g.read_bytes()).hexdigest()
  assert g.is_absolute() and g.resolve()==g and not g.is_symlink()
  assert a['files'][str(g)]==d
  value=json.loads(g.read_bytes());assert value['accepted_by_root'] is True and value['qualification'] is False
  v['gates'][role]=dict(ref=dict(path=str(g),sha256=d),value=value)
print(json.dumps(v,allow_nan=False))
'''
    value = json.loads(io.native(['python3', '-B', '-c', code, ref['path'], ref['sha256'],
        'gates' if gates else 'anchor'], label, 180))
    actual(label)
    assert value['ref'] == ref
    return value



def actual_invocation_request():
    import sys
    assert len(sys.argv)==3 and sys.pycache_prefix is None
    p=Path(sys.argv[1]);assert p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink()
    assert sha(p)==sys.argv[2]
    q=read(p)
    assert q['schema']==1 and q['accepted_by_root'] is True and q['owner']=='/root'
    assert q['later_artifact_execution_authorized'] is True
    assert q['campaign_root']==str(ROOT) and q['held_excluded']==[5004,5006]
    assert q['helper']==remote_ref(Path(__file__).resolve())
    assert all(q[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
    return q

if __name__ == '__main__':
    assert __debug__
    actual_request=actual_invocation_request()
    GUARD_SHA=actual_request['guard']['sha256'];assert actual_request['guard']['path']==str(GUARD)
    POST_SMALL_SHA=actual_request['post_small_anchor']['sha256'];assert actual_request['post_small_anchor']['path']==str(POST_SMALL)
    MANIFEST=actual_request['manifest_sha256'];COMPOSITION=actual_request['composition_sha256']
    state = read(STATE)
    assert state['native_active'] is None, 'join existing native owner first'
    accepted = read(HERE/'root-global-calibration-content-acceptance-v12-v1.json')
    assert accepted['accepted_by_root'] is True
    assert accepted['status'] == 'ACTUAL_ORIGINAL_39C_39GUARDS_B36_R18_CONTENTS_ACCEPTED'
    assert (accepted['calibration_captures'], accepted['calibration_guards'], accepted['B_slots'], accepted['R_slots']) == (39,39,36,18)
    assert all(accepted[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
    assert accepted['campaign_root'] == str(ROOT) and accepted['held_excluded'] == [5004,5006]
    adoption = read(HERE/'root-full-R-closure-source-acceptance-v12-v1.json')
    assert adoption['accepted_by_root'] is True and adoption['source_only'] is True
    assert sha(HELPER) == HELPER_SHA
    ip = RECEIPTS/'root_native_io.py'
    assert sha(ip) == 'fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
    io = types.ModuleType('root_io'); io.__file__ = str(ip)
    exec(compile(ip.read_bytes(), str(ip), 'exec'), io.__dict__)
    runtime(native_active=dict(phase='fresh-v12-full-R-GLOBAL54-artifact-checks', owner='/root',
        local_owner_pid=os.getpid(), started_ns=time.time_ns(), campaign_root=str(ROOT),
        qualification=False, candidate_pair_collection_authorized=False))
    try:
        old_ref = accepted['R']['anchor']
        old = bound_read(old_ref, 'v12-root-actual-R-accept-selector-readback-v1', gates=True)
        assert old['anchor']['root'] == str(ROOT)
        request = dict(schema=1, accepted_by_root=True, owner='/root', authorized_ns=time.time_ns(),
            status='ROOT_AUTHORIZED_ADDITIVE_CANONICAL_B_AND_COMPLETE24_ARTIFACT_IO_ONLY',
            additive_full_R_canonical_B_io_authorized=True, campaign_root=str(ROOT), held_excluded=[5004,5006],
            qualification=False, performance_accepted=False, collection_authorized=False,
            candidate_pairs_authorized=False, merge_authorized=False, helper=remote_ref(HELPER),
            transition_helper=dict(path=str(REMOTE/'qualification-v12-later-execution-preparation-v1/root-global-calibration-transition-v12-v1.py'),
                sha256='cf8423134ae10c95ce56da97e4ae9e5d260416c84bfa43e39f0acf4ef46194ef'),
            original_R_anchor=old_ref, frozen_pins=dict(path=str(PINS),sha256=PINS_SHA),
            post_small_anchor=dict(path=str(POST_SMALL),sha256=POST_SMALL_SHA),post_small_source_file_count=actual_request["post_small_source_file_count"],
            canonical_B_gate=dict(path=str(ROOT/'global-calibration-freeze.json'),sha256=old['gates']['B']['ref']['sha256']),
            helper_source_acceptance=remote_ref(HERE/'root-full-R-closure-source-acceptance-v12-v1.json'))
        rp = HERE/'root-full-R-canonical-B-closure-actual-request-v12-v1.json'
        save(rp, request)
        io.put({p.relative_to(BASE).as_posix():p for p in (HELPER,rp,HERE/'root-full-R-closure-source-acceptance-v12-v1.json')},
            'v12-root-full-R-canonical-B-exclusive-transfer-v1')
        label = 'v12-root-full-R-canonical-B-actual-closure-v1'
        result = json.loads(io.native(['python3','-B',request['helper']['path'],remote_ref(rp)['path'],sha(rp)], label,7200))
        actual(label)
        assert result['status'] == 'ACTUAL_FULL_R_CANONICAL_B_COMPLETE24_CLOSURE_PASS'
        assert result['canonical_B_gate_bytes_equal'] is result['full_predecessor_and_post_small_calibration_inherited'] is result['no_pair_namespace'] is True
        assert result['pins_count'] == 24 and result['original_R_anchor'] == old_ref
        assert all(result[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized'))
        save(HERE/'actual-full-R-canonical-B-result-v12-v1.json', result)
        current = bound_read(result['R_anchor'],'v12-root-full-R-before-GLOBAL54-readback-v1',gates=True)
        anchor = current['anchor']
        assert anchor['root'] == str(ROOT) and anchor['current_pair_source_predecessor'] == old_ref
        assert all(anchor['files'].get(p)==d for p,d in old['anchor']['files'].items())
        assert anchor['files'][old_ref['path']] == old_ref['sha256']
        assert current['gates'] == old['gates']
        now = time.time_ns()
        assert all(0 < item['value']['frozen_ns'] < now for item in current['gates'].values())
        decision = dict(schema=1, status='ACTUAL_GLOBAL54_RAW_ORIGINS_AND_FREEZES_ROOT_ACCEPTED_REPLAY_REQUIRED',
            accepted_by_root=True, global54_actual_contents_accepted=True, owner='/root',accepted_ns=now,
            campaign_root=str(ROOT),held_excluded=[5004,5006],qualification=False,performance_accepted=False,
            collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False,
            manifest_sha256=MANIFEST,composition_sha256=COMPOSITION, R_anchor=result['R_anchor'],
            files=anchor['files'],B_global_gate_sha256=current['gates']['B']['ref']['sha256'],
            R_global_gate_sha256=current['gates']['R']['ref']['sha256'],
            original_R_accept_predecessor=old_ref,canonical_B_gate=result['canonical_B_gate'],
            canonical_B_gate_byte_identical_verified=True, original_calibration_content_acceptance=remote_ref(HERE/'root-global-calibration-content-acceptance-v12-v1.json'),
            native_full_R_readback=remote_ref(RECEIPTS/'v12-root-full-R-before-GLOBAL54-readback-v1-stdout.txt'))
        dp = HERE/'root-global54-actual-content-acceptance-v12-v1.json';save(dp,decision)
        template=actual_request['global54_input_template'];template_path=BASE/Path(template['path']).relative_to(REMOTE)
        assert sha(template_path)==template['sha256']
        inp=read(template_path)
        inp.pop('source_only');inp.update(status='ROOT_AUTHORIZED_ORIGINAL_GLOBAL54_ARTIFACT_REPLAY_ONLY',
            accepted_by_root=True,artifact_replay_authorized=True,R_anchor=result['R_anchor'],
            actual_global_content_acceptance=remote_ref(dp))
        assert inp['guard'] == dict(path=str(GUARD),sha256=GUARD_SHA)
        gp = HERE/'root-global54-actual-input-v12-v1.json';save(gp,inp)
        io.put({p.relative_to(BASE).as_posix():p for p in (dp,gp)},'v12-root-global54-actual-input-exclusive-transfer-v1')
        label = 'v12-actual-original-global54-complete-replay-v1'
        replay = json.loads(io.native(['python3','-B',str(GUARD),remote_ref(gp)['path'],sha(gp)],label,7200))
        execution = actual(label)
        assert replay['status'] == 'GLOBAL54_ARTIFACT_REPLAY_COMPLETE_ROOT_LAUNCH_STILL_REQUIRED'
        assert (replay['baseline_captures'],replay['guard_captures'],replay['B_slots'],replay['R_slots']) == (39,39,36,18)
        assert replay['qualification'] is replay['candidate_pairs_authorized'] is False
        save(HERE/'actual-original-global54-replay-result-v12-v1.json',replay)
        outcome = dict(schema=1,status='ACTUAL_FULL_R_COMPLETE24_CANONICAL_B_AND_GLOBAL54_REPLAY_PASS',
            accepted_by_root=True,accepted_ns=time.time_ns(),campaign_root=str(ROOT),held_excluded=[5004,5006],
            full_R=result['R_anchor'],full_R_predecessor=old_ref, canonical_B_gate=result['canonical_B_gate'],
            global54_content_acceptance=remote_ref(dp),global54_input=remote_ref(gp),
            replay_execution=remote_ref(RECEIPTS/(label+'-run.json')),replay_result=replay,
            qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False)
        save(HERE/'root-full-R-and-global54-actual-acceptance-v12-v1.json',outcome)
        state = read(STATE);state['qualification_v12_current']['full_R_and_GLOBAL54_actual']=remote_ref(HERE/'root-full-R-and-global54-actual-acceptance-v12-v1.json')
        runtime(native_active=None,qualification_v12_current=state['qualification_v12_current'],
            current_execution_status='Actual full-R/canonical B/all24/original GLOBAL54 passed; no candidate pairs yet',
            next_action='Exact physical34 preservation, root content acceptance, then separate R/driver pair authority')
        print(json.dumps(outcome,allow_nan=False),flush=True)
    except BaseException as error:
        runtime(native_active=None,current_execution_status='Full-R/GLOBAL54 artifact gate failed; all exact raw retained',
            next_action='Inspect exact failing artifact receipt; no candidate pair collection or automatic retry',
            last_native_failure=dict(phase='fresh-v12-full-R-GLOBAL54',error=repr(error),finished_ns=time.time_ns()))
        raise
