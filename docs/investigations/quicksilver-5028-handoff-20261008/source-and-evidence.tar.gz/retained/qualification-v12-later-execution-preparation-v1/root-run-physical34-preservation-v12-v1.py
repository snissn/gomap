"""Root-only physical calibration metadata preservation after actual GLOBAL54.

Prepared until invoked. Serial artifact IO only; no pair or merge authority.
"""
from pathlib import Path
import hashlib
import json
import os
import time
import types

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
REMOTE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = REMOTE/'qualification-v12-refresh/qualification-v10'
STATE = BASE/'state.json'
RECEIPTS = BASE/'qualification-v9-selected-source-preparation-v1'
HELPER = HERE/'root-accept-physical34-v12-v1.py'
CONSUMER = REMOTE/'prospective-strict-latency-guard-consumer-v5/strict_latency_guard_consumer.py'
CONSUMER_SHA = 'ccc5b23ed271b2bd814fc2678a7e4d99e72f0f381b4a39d37132ae570cdee97d'


def read(path):return json.loads(Path(path).read_bytes())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def remote_ref(path):return dict(path=str(REMOTE/path.relative_to(BASE)),sha256=sha(path))
def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
def runtime(**fields):
    state=read(STATE);state.update(fields)
    pending=HERE/('state-physical34-runtime-'+str(time.time_ns())+'.json')
    save(pending,state);pending.replace(STATE)
def actual(label):
    row=read(RECEIPTS/(label+'-run.json'))
    assert row['rc']==0 and not row.get('error') and 0<row['started_ns']<row['finished_ns']
    for channel in ('stdout','stderr'):
        p=RECEIPTS/(label+'-'+channel+'.txt')
        assert row[channel]==dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
    assert not (RECEIPTS/(label+'-stderr.txt')).read_bytes()
    return row



def actual_invocation_request():
    import sys
    assert len(sys.argv)==3 and sys.pycache_prefix is None
    p=Path(sys.argv[1]);assert p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink()
    assert sha(p)==sys.argv[2]
    q=read(p)
    assert q['schema']==1 and q['accepted_by_root'] is True and q['owner']=='/root'
    assert q['later_artifact_execution_authorized'] is True
    assert q['campaign_root']==str(ROOT) and q['held_excluded']==[5004,5006]
    assert q['helper']==remote_ref(Path(__file__).resolve())
    assert all(q[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
    return q

if __name__=='__main__':
    assert __debug__
    actual_request=actual_invocation_request()
    state=read(STATE);assert state['native_active'] is None
    predecessor=read(HERE/'root-full-R-and-global54-actual-acceptance-v12-v1.json')
    assert predecessor['accepted_by_root'] is True
    assert predecessor['status']=='ACTUAL_FULL_R_COMPLETE24_CANONICAL_B_AND_GLOBAL54_REPLAY_PASS'
    assert predecessor['campaign_root']==str(ROOT) and predecessor['held_excluded']==[5004,5006]
    assert all(predecessor[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
    replay=predecessor['replay_result']
    assert (replay['baseline_captures'],replay['guard_captures'],replay['B_slots'],replay['R_slots'])==(39,39,36,18)
    assert sha(BASE/'prospective-strict-latency-guard-consumer-v5/strict_latency_guard_consumer.py')==CONSUMER_SHA
    ip=RECEIPTS/'root_native_io.py'
    assert sha(ip)=='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
    io=types.ModuleType('root_io');io.__file__=str(ip)
    exec(compile(ip.read_bytes(),str(ip),'exec'),io.__dict__)
    runtime(native_active=dict(phase='fresh-v12-physical34-preservation-and-root-content-check',owner='/root',
        local_owner_pid=os.getpid(),started_ns=time.time_ns(),campaign_root=str(ROOT),
        qualification=False,candidate_pair_collection_authorized=False))
    try:
        template=actual_request['preservation_request_template'];template_path=BASE/Path(template['path']).relative_to(REMOTE)
        assert sha(template_path)==template['sha256']
        request=read(template_path)
        request.pop('source_only')
        request.update(status='ROOT_AUTHORIZED_EXACT_PHYSICAL34_COPY_ONLY',accepted_by_root=True,artifact_io_authorized=True,
            owner='/root',authorized_ns=time.time_ns(),global54_actual_content_acceptance=predecessor['global54_content_acceptance'])
        assert request['consumer']==dict(path=str(CONSUMER),sha256=CONSUMER_SHA)
        rp=HERE/'root-physical34-preservation-actual-request-v12-v1.json';save(rp,request)
        io.put({rp.relative_to(BASE).as_posix():rp},'v12-root-physical34-preservation-request-exclusive-stage-v1')
        label='v12-actual-physical34-preservation-v1'
        preserved=ROOT/'pre-pair-physical34-preserved-v12-v1'
        receipt=json.loads(io.native(['python3','-B',str(CONSUMER),'preserve',remote_ref(rp)['path'],sha(rp),str(preserved)],label,7200))
        actual(label)
        assert set(receipt)=={'path','sha256'} and receipt['path']==str(preserved/'preservation-receipt.json')
        save(HERE/'actual-physical34-preservation-receipt-ref-v12-v1.json',receipt)
        check_request=dict(schema=1,status='ROOT_AUTHORIZED_EXACT34_CONTENT_CHECK_AND_PHYSICAL_ANCHOR_IO_ONLY',
            accepted_by_root=True,owner='/root',authorized_ns=time.time_ns(),physical34_acceptance_io_authorized=True,
            helper=remote_ref(HELPER),campaign_root=str(ROOT),held_excluded=[5004,5006],consumer=request['consumer'],
            preservation_receipt=receipt,qualification=False,performance_accepted=False,collection_authorized=False,
            candidate_pairs_authorized=False,merge_authorized=False)
        cp=HERE/'root-physical34-content-actual-request-v12-v1.json';save(cp,check_request)
        io.put({p.relative_to(BASE).as_posix():p for p in (HELPER,cp)},'v12-root-physical34-content-helper-and-request-exclusive-stage-v1')
        label='v12-actual-physical34-root-content-acceptance-v1'
        accepted=json.loads(io.native(['python3','-B',remote_ref(HELPER)['path'],remote_ref(cp)['path'],sha(cp)],label,7200))
        actual(label)
        assert accepted['status']=='ACTUAL_PHYSICAL34_ROOT_CONTENT_ACCEPTANCE_PASS'
        assert accepted['preserved_count']==34 and accepted['no_pair_namespace'] is True
        assert accepted['original_anchors']['R']==predecessor['full_R']
        assert all(accepted[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
        save(HERE/'actual-physical34-root-content-result-v12-v1.json',accepted)
        state=read(STATE)
        state['qualification_v12_current']['physical34_actual']=remote_ref(HERE/'actual-physical34-root-content-result-v12-v1.json')
        runtime(native_active=None,qualification_v12_current=state['qualification_v12_current'],
            current_execution_status='Actual GLOBAL54 and exact physical34 content passed; no candidate pairs collected',
            next_action='Separate actual root R and pair-driver authority selecting immutable original full-R, then original114/114')
        print(json.dumps(accepted,allow_nan=False),flush=True)
    except BaseException as error:
        runtime(native_active=None,current_execution_status='Physical34 gate failed; immutable original and failed raw retained',
            next_action='Inspect exact physical34 failure; no retry or pair collection',
            last_native_failure=dict(phase='fresh-v12-physical34',error=repr(error),finished_ns=time.time_ns()))
        raise
