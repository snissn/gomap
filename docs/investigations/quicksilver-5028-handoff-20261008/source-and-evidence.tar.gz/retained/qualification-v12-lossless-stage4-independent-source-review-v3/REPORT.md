# Independent source review v3: large strict-proof transport repair

Verdict: **NO_CONCRETE_SOURCE_BLOCKER** in the bounded changed-source review. Current adapter/report/manifest and v2 launcher exactly match all requested SHA-256 identities; the prototype remains unchanged. Source only: no helper/native/SSH/Go/GH execution, new synthetic run, adoption, state or product change. All five authority flags remain false; #5004/#5006 remain excluded.

## Failure seam and repair

Retained v1 execution receipt reports rc1 after8.032826s. Its stderr identifies `predecessors():274`, `proof=bound(item['proof'])`, failing the small predecessor-file limit. The bound root reassessment records zero B16 calls/no archives, and retained readonly shape observation records absent old output. That read-only observation has rc0, matching full stdout identity/empty stderr,19 stat rows totalling176,755,727 bytes and maximum31,595,254 bytes. Only the first5,004-byte proof was fully hash-checked and parsed for shape; it contains0 metric proofs/16 not_applicable. This does not validate all19 complete contents or their dispositions.

The new `predecessors():274` uses unchanged `complete_bound()` to verify the canonical source identity, parse the entire strict proof without the small-packet cap, and rehash it afterwards. It retains all previous source, member, role, anchor, definition, exact child argv/join/streams/chronology, distinct strict replay, full numerical/provenance equality and UNKNOWN gates. Full complete proof parsing remains before new output creation. No frozen evaluator/consumer/checker policy or original result source is edited.

## Projection and full content

`numerical_projection():323-331` adds only `/proofs/i/source_support` omission for the exact strict status. It creates new per-proof dictionaries, replacing each present support array with explicit `projection_omitted_full_content=true`, the verified complete archive record and exact JSON pointer. Source objects are not modified. All remaining top-level and metric proof fields, witness numbers/effects/calibrations/guard paths, UNKNOWN policy, not_applicable and dispositions remain intact. Frozen consumer `metric_proof():368-390` confirms this field contains complete extracted phase/raw statistical support; the authoritative gzip archive retains it and is fully verified/parsed.

Unexpected large fields outside that permitted omission still fail the unchanged512KiB remaining-view limit without truncation. Small source/request/adoption/summary packets remain limited to2MiB. Full archive pointers remain distinct from bounded observation views; no projection is relabelled complete content.

## Exact delta and launcher consistency

Preserved00c1/current AST comparison identifies only changed `predecessors` and `numerical_projection`, plus the actual-v1→actual-v2 output constant. The other16 functions/classes, including `complete_bound`, `strict_replay_binding`, `Adapter` and `main`, are AST-identical and reuse the prior full review. The prototype is byte-identical. Full all73 archive/parse ordering, unchanged B16/R6/all176 checker/pointer gates, frozen arithmetic/provenance, authority flags, receipts, exclusive output/failure/no-retry behavior and product/default-progress gates remain unchanged.

The launcher changes eight string sites representing seven distinct literal replacements. Reversing those literals restores the entire prior launcher AST exactly. HERE/NINPUT use root-preparation-v2; NOUT matches the adapter's exact native actual-v2 constant; request.output_directory, operation/readback labels and local output names agree. Historical original54/strict19 v1 references and receipt labels intentionally remain unchanged. Source adoption still binds the exact helper, prototype, review and launcher; root must select the refreshed identities.

## Retained synthetic scope and limits

The eleven retained final-source checks are bound to adapter SHA3c943f585b5f7c1c6edca37dac0d00cb7a0e0b5aaeae8cce7447d347fe4f9acc. They exercise real predecessor/projection control flow through an explicitly mocked byte/parser/reference/stream store: large-proof acceptance and old2MiB rejection; existing stale/anchor/role/argv/reference/provenance rejection; plus finite real gzip archive verification/full source_support pointer recovery, other-field preservation and unexpected remaining giant-field rejection. The test fixture has the strict producer's four authority flags and explicit remaining fields. Earlier32/7 and exploratory-v2 results retain their historical source bindings. No tests were rerun or relabelled.

No additional concrete changed-source blocker was found. Native peak RSS, full pair parsing cost, strict support parse/compression cost, retained disk use and successful stage4 completion remain unverified. Root owns the new request/adoption/namespace/execution and final numerical/performance/correctness/product decisions. Exact input bytes/spans, AST/literal delta, failure/layout observation scope and synthetic limits are recorded in `independent-review.json`.
