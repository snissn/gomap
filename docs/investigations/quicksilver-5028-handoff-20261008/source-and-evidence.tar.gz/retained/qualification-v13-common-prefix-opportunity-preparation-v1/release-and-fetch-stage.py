import base64,hashlib,json,os,time,sys
from pathlib import Path
H=Path(__file__).resolve().parent;B=H.parent;stage=sys.argv[1];assert stage in ('build','prepare','collect')
p=B/'qualification-v9-selected-source-preparation-v1/root_native_io.py';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io={'__file__':str(p),'__name__':'rootio'};exec(compile(raw,str(p),'exec'),io);io['HERE']=H
q=json.loads((H/'request.json').read_bytes());N=q['work']
program=r"""import base64,hashlib,json,os,time
from pathlib import Path
p=Path(ROOT_LITERAL);stage=STAGE_LITERAL;outcome=json.loads((p/(stage+'-outcome.json')).read_bytes());assert outcome['qualification'] is False
records=outcome['commands']
for r in records:
 assert r['raw_hashes_final'] and r['process_group_cleanup']['direct_child_joined'] and r['process_group_cleanup']['quiescent']
active=[]
for entry in Path('/proc').iterdir():
 if not entry.name.isdecimal() or int(entry.name)==os.getpid():continue
 try:argv=(entry/'cmdline').read_bytes().split(b'\0');name=Path(os.fsdecode(argv[0])).name if argv and argv[0] else ''
 except OSError:continue
 try:actual=Path(os.readlink(entry/'exe')).name.removesuffix(' (deleted)')
 except OSError:actual=name
 if name in ('go','compile','link','snapshot-restore','treemap','treedb') or name.endswith('.test') or actual.endswith('.test') or name.startswith(('unified-bench','treedb-compact','treemap')):active.append({'pid':int(entry.name),'executable':name})
assert not active,active
release={'status':'ACTUAL_OPPORTUNITY_STAGE_JOINED_AND_RELEASED','stage':stage,'active_conflicts':active,'all_owned_runs_joined':True,'whole_stage_deadline_satisfied':outcome['whole_stage_deadline_satisfied'],'stage_status':outcome['status'],'checked_ns':time.time_ns(),'qualification':False,'performance_accepted':False}
(p/('root-'+stage+'-fresh-release.json')).write_text(json.dumps(release,indent=2)+'\n')
files={}
if stage=='build':
 paths=list(p.iterdir())+[a for a in (p/'overlay').rglob('*') if a.is_file()]
else:
 # Prior accepted compiler/source files remain in the original build packet.
 # Fetch this actual stage's new owner/outcome/join/raw files without copies.
 names={stage+'-owner.json',stage+'-outcome.json','root-'+stage+'-fresh-release.json'}
 for r in records:
  for key in ('stdout_path','stderr_path'):
   f=Path(r[key]);assert f.parent==p;names.add(f.name)
  stdout=Path(r['stdout_path']);assert stdout.name.endswith('-stdout.txt');names.add(stdout.name.removesuffix('-stdout.txt')+'-run.json')
 if stage=='collect':names.add('opportunity-census.json')
 paths=[p/name for name in sorted(names)]
for f in paths:
 if f.is_file():
  assert not f.is_symlink();data=f.read_bytes();files[str(f.relative_to(p))]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'base64':base64.b64encode(data).decode()}
assert len(files)<100 and sum(x['bytes'] for x in files.values())<100*1024**2
print(json.dumps({'release':release,'files':files,'qualification':False}),flush=True)
""".replace('ROOT_LITERAL',repr(N)).replace('STAGE_LITERAL',repr(stage))
data=json.loads(io['native'](['python3','-B','-c',program],'actual-'+stage+'-join-release-and-readback-v1',120))
outdir=H/('native-actual-'+stage);outdir.mkdir()
for n,item in data['files'].items():
 path=Path(n);assert not path.is_absolute() and '..' not in path.parts
 raw=base64.b64decode(item['base64'],validate=True);assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'];f=outdir/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw)
receipt=dict(**data['release'],transport={'path':str(H/('actual-'+stage+'-join-release-and-readback-v1-stdout.txt')),'sha256':hashlib.sha256((H/('actual-'+stage+'-join-release-and-readback-v1-stdout.txt')).read_bytes()).hexdigest()},fetched_files=len(data['files']),actual_bytes=sum(x['bytes'] for x in data['files'].values()))
p=H/('root-'+stage+'-runtime-release.json');p.write_text(json.dumps(receipt,indent=2)+'\n')
S=B/'state.json';old=S.read_bytes();s=json.loads(old);assert s['native_active']['phase']=='R-common-prefix-opportunity-overlay-'+stage
s['native_active']=None;s['native_heavy_slot']=None;s['qualification_v13_current']['native_active']=None
s['qualification_v13_current'].setdefault('common_prefix_opportunity_actual_stage_releases',{})[stage]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
s['state_updated_ns']=time.time_ns();pending=H/('state.'+stage+'.release.pending');pending.write_text(json.dumps(s,indent=2)+'\n');assert S.read_bytes()==old;os.replace(pending,S)
print(json.dumps(receipt),flush=True)
