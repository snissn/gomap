"""Diagnostic-only collector ownership shim; entire census inherits outer PGID."""
import hashlib, json, pathlib, signal, sys, types
P=pathlib.Path
if not __debug__: raise RuntimeError('Python -O forbidden')
request=P(sys.argv[1]);assert hashlib.sha256(request.read_bytes()).hexdigest()==sys.argv[2]
q=json.loads(request.read_bytes())
def interrupt(signum, frame): raise InterruptedError('collector ownership signal '+str(signum))
for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,interrupt)
# Load exact retained helper; change only process ownership/launcher cleanup.
ref=q['rss_helper'];path=P(ref['path']);raw=path.read_bytes();assert not path.is_symlink() and hashlib.sha256(raw).hexdigest()==ref['sha256']
s=raw.decode()
for old,new in [('kwargs["start_new_session"] = True','kwargs["start_new_session"] = False'),('os.killpg(process.pid, 15)','process.terminate()'),('os.killpg(process.pid, 9)','process.kill()')]:
 assert s.count(old)==1,old;s=s.replace(old,new,1)
rss=types.ModuleType('owned_process_rss');rss.__file__=str(path);sys.modules['owned_process_rss']=rss;exec(compile(s,str(path)+'[diagnostic-shared-pgid]', 'exec'),rss.__dict__)
ref=q['capture'];path=P(ref['path']);raw=path.read_bytes();assert not path.is_symlink() and hashlib.sha256(raw).hexdigest()==ref['sha256']
collector=types.ModuleType('diagnostic_owned_collector');collector.__file__=str(path);exec(compile(raw,str(path),'exec'),collector.__dict__)
sys.argv=[str(path),q['manifest'],q['plan']]
collector.main()
