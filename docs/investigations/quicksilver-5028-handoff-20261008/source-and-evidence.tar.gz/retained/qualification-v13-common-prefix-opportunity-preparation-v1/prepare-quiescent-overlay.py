"""Artifact-only extension of the reviewed counters; no product file changes."""
import argparse, hashlib, json, pathlib, subprocess, sys
p=argparse.ArgumentParser();p.add_argument('--source-root',required=True);p.add_argument('--output',required=True);a=p.parse_args()
r=pathlib.Path(a.source_root).resolve();d=pathlib.Path(a.output).resolve();here=pathlib.Path(__file__).resolve().parent
subprocess.run([sys.executable,'-B',str(here/'prepare-diagnostic-overlay.py'),'--source-root',str(r),'--output',str(d)],check=True)
t=d/'generation_v1_tree.go';s=t.read_text()
assert s.count('func prefixDiagnosticDump() {')==1
s=s.replace('func prefixDiagnosticDump() {','func prefixDiagnosticDump() { prefixDiagnosticDumpAt("materialize-unqualified") }\nfunc DiagnosticPrivateCommonPrefixQuiescent() { prefixDiagnosticDumpAt("engine-return-db-closed") }\nfunc prefixDiagnosticDumpAt(endpoint string) {',1)
s=s.replace('"diagnostic":"freelist-private-common-prefix","cumulative":true,','"diagnostic":"freelist-private-common-prefix","cumulative":true,"endpoint":endpoint,',1)
t.write_text(s)
f=r/'cmd/unified_bench/suite_quicksilver.go';s=f.read_text()
assert s.count('treedb "github.com/snissn/gomap/TreeDB"')==1
s=s.replace('treedb "github.com/snissn/gomap/TreeDB"','diagnosticfreelist "github.com/snissn/gomap/TreeDB/freelist"\n treedb "github.com/snissn/gomap/TreeDB"',1)
needle='func runQuicksilverEngine(cfg BenchConfig, c quicksilverConfig, engine string, open DBFactory, dir string) (res quicksilverResult, err error) {\n'
assert s.count(needle)==1
# Registered before the existing DB-close defer: it runs after Close on return.
s=s.replace(needle,needle+' defer func() { if err == nil { diagnosticfreelist.DiagnosticPrivateCommonPrefixQuiescent() } }()\n',1)
target=d/f.name;target.write_text(s)
overlay=json.loads((d/'overlay.json').read_text());overlay['Replace'][str(f)]=str(target)
(d/'overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
bindings=json.loads((d/'bindings.json').read_text());bindings['source_inputs'][str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
bindings.update(final_endpoint='engine-return-db-closed',final_valid_only_with_exit_zero_and_all_original_oracles=True,overlay_outputs={str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in (t,d/'generation_v1_txn.go',target)})
(d/'bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
