import pathlib,json,hashlib,argparse
out=pathlib.Path(__file__).parent
parser=argparse.ArgumentParser()
parser.add_argument('--source-root',default='/private/tmp/gomap-qs-5015')
parser.add_argument('--output')
args=parser.parse_args()
repo=pathlib.Path(args.source_root).resolve()
dest=pathlib.Path(args.output).resolve() if args.output else out/'diagnostic-overlay'
dest.mkdir(exist_ok=False)
tree=repo/'TreeDB/freelist/generation_v1_tree.go'
txn=repo/'TreeDB/freelist/generation_v1_txn.go'
s=tree.read_text().replace('import (','import (\n "encoding/json"\n "os"\n "sync/atomic"',1)
s+=r"""

// Diagnostic overlay only: excluded from the production postimages.
var prefixDiagnostic struct {
 selected, transitions, noAuthority, same, switches, eligible, invalidProof atomic.Uint64
 forkRevocations, selectionRevocations, emissionRevocations atomic.Uint64
 maxSelectedChunk, reusableAncestors atomic.Uint64
 commonEdges [chunkTrieDepth]atomic.Uint64
}
func prefixDiagnosticAllocation(t *FreelistTxn, chunk uint64) {
 d:=&prefixDiagnostic
 d.selected.Add(1)
 if len(t.allocated)>0 && t.allocated[len(t.allocated)-1].id>>freelistChunkShift!=chunk { d.transitions.Add(1) }
 for old:=d.maxSelectedChunk.Load();chunk>old;old=d.maxSelectedChunk.Load() { if d.maxSelectedChunk.CompareAndSwap(old,chunk) { break } }
 if t.privateRoot!=t.root { d.noAuthority.Add(1);return }
 if t.privateChunk==chunk { d.same.Add(1);return }
 d.switches.Add(1)
 n:=t.root
 for depth:=0;depth<=chunkTrieDepth;depth++ {
  if n==nil||n.pageID!=0 { d.invalidProof.Add(1);return }
  if depth<chunkTrieDepth { n=n.child[chunkNibble(t.privateChunk,depth)] }
 }
 if n.chunk!=nil&&n.chunk.pageID!=0 { d.invalidProof.Add(1);return }
 depth:=0
 for depth<chunkTrieDepth&&chunkNibble(t.privateChunk,depth)==chunkNibble(chunk,depth) { depth++ }
 if depth==chunkTrieDepth { d.invalidProof.Add(1);return }
 d.eligible.Add(1);d.commonEdges[depth].Add(1);d.reusableAncestors.Add(uint64(depth+1))
}
func prefixDiagnosticRevoke(t *FreelistTxn,kind int) {
 if t.privateRoot==nil||t.privateRoot!=t.root { return }
 switch kind { case 0:prefixDiagnostic.forkRevocations.Add(1);case 1:prefixDiagnostic.selectionRevocations.Add(1);case 2:prefixDiagnostic.emissionRevocations.Add(1) }
}
func prefixDiagnosticDump() {
 d:=&prefixDiagnostic
 var edges [chunkTrieDepth]uint64
 for i:=range edges { edges[i]=d.commonEdges[i].Load() }
 data,_:=json.Marshal(map[string]any{
 "diagnostic":"freelist-private-common-prefix","cumulative":true,
 "selected_reused":d.selected.Load(),"selected_transitions_from_previous_allocation":d.transitions.Load(),
 "no_private_authority":d.noAuthority.Load(),"same_private_chunk":d.same.Load(),"certified_chunk_switches":d.switches.Load(),
 "eligible_complete_proof_switches":d.eligible.Load(),"invalid_complete_proof_switches":d.invalidProof.Load(),
 "common_nibble_edges_histogram":edges,"reusable_ancestor_node_count":d.reusableAncestors.Load(),"max_selected_chunk":d.maxSelectedChunk.Load(),
 "prepare_fork_revocations":d.forkRevocations.Load(),"materialize_selection_revocations":d.selectionRevocations.Load(),"materialize_emission_revocations":d.emissionRevocations.Load(),
 })
 _,_=os.Stderr.Write(append(data,'\n'))
}
"""
a=txn.read_text()
needle='if id, ok := chooseUnreservedFreePage(t.root, regionHint, t.ledger, &t.stats.PageVisits); ok {'
assert a.count(needle)==1
a=a.replace(needle,needle+'\n prefixDiagnosticAllocation(t,id>>freelistChunkShift)',1)
start=a.index('func (t *FreelistTxn) cloneForAllocatorPrepare()')
i=a.index('\tt.privateRoot = nil',start);a=a[:i]+'\tprefixDiagnosticRevoke(t,0)\n'+a[i:]
start=a.index('func (t *FreelistTxn) MaterializeCandidate(')
i=a.index('\n',start);a=a[:i]+'\n defer prefixDiagnosticDump()'+a[i:]
i=a.index('\tt.privateRoot = nil',start);a=a[:i]+'\tprefixDiagnosticRevoke(t,1)\n'+a[i:]
i=a.index('\tt.privateRoot = nil',i+len('\tprefixDiagnosticRevoke(t,1)\n\tt.privateRoot = nil'));a=a[:i]+'\tprefixDiagnosticRevoke(t,2)\n'+a[i:]
files={tree:s,txn:a}
replace={}
for src,contents in files.items():
 dst=dest/src.name;dst.write_text(contents);replace[str(src)]=str(dst)
(dest/'overlay.json').write_text(json.dumps({'Replace':replace},indent=2)+'\n')
(dest/'bindings.json').write_text(json.dumps({'source_inputs':{str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in files},'production_api_or_overhead':False,'requires_original_performance_run_without_overlay':True},indent=2)+'\n')
print(dest/'overlay.json')
