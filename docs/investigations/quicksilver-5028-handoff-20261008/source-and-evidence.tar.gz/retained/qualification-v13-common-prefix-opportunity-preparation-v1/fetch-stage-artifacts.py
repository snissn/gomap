"""Finite read-only actual diagnostic artifact readback; no runtime grant."""
import base64, hashlib, json, sys
from pathlib import Path
H = Path(__file__).resolve().parent
B = H.parent
stage = sys.argv[1]
assert stage in ('prepare', 'collect')
q = json.loads((H / 'request.json').read_bytes())
p = B / 'qualification-v9-selected-source-preparation-v1/root_native_io.py'
raw = p.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io = dict(__file__=str(p), __name__='root_io')
exec(compile(raw, str(p), 'exec'), io)
io['HERE'] = H
program = r'''import base64,hashlib,json
from pathlib import Path
q=json.loads(Path(REQUEST_LITERAL).read_bytes());stage=STAGE_LITERAL
work=Path(q['work']);outcome=json.loads((work/(stage+'-outcome.json')).read_bytes())
assert outcome['status']==('FRESH_COPY_REBOUND_SOURCE_UNCHANGED' if stage=='prepare' else 'QUIESCENT_CENSUS_JOINED_DIAGNOSTIC_ONLY')
assert outcome['whole_stage_deadline_satisfied'] and outcome['qualification'] is False
paths={}
def add(label,p):
 assert label not in paths and not p.is_symlink() and p.is_file()
 data=p.read_bytes();paths[label]={'native_path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'base64':base64.b64encode(data).decode()}
if stage=='prepare':
 fixture=Path(q['fixture'])
 for n in ('copy-before-rebind.json','prepared-receipt.json'):add('fixture/'+n,fixture/n)
 add('manifest.json',Path(q['manifest']));add('capture-plan.json',Path(q['plan']))
else:
 output=Path(q['root'])/q['capture_plan']['output']/('1-'+q['capture_plan']['cells'][0]['label'])
 assert output.is_dir() and not output.is_symlink()
 for p in sorted(output.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():add('capture/'+str(p.relative_to(output)),p)
 add('opportunity-census.json',work/'opportunity-census.json')
assert paths and len(paths)<150 and sum(x['bytes'] for x in paths.values())<128*1024**2
print(json.dumps({'stage':stage,'files':paths,'qualification':False}),flush=True)
'''.replace('REQUEST_LITERAL', repr(q['root'].split('/qualification-v12-refresh')[0]
    + '/qualification-v13-common-prefix-opportunity-control-v1/request.json')).replace('STAGE_LITERAL', repr(stage))
data = json.loads(io['native'](['python3', '-B', '-c', program],
    'actual-' + stage + '-artifacts-readback-v1', 120))
target = H / ('native-artifacts-' + stage)
target.mkdir()
bindings = {}
for name, item in data['files'].items():
    rel = Path(name)
    assert not rel.is_absolute() and '..' not in rel.parts
    raw = base64.b64decode(item.pop('base64'), validate=True)
    assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
    p = target / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(raw)
    bindings[name] = dict(item, local_path=str(p))
with (H / ('root-' + stage + '-artifact-bindings.json')).open('x') as f:
    json.dump(dict(stage=stage, bindings=bindings, qualification=False), f, indent=2)
    f.write('\n')
print(json.dumps(dict(status='FINITE_ACTUAL_ARTIFACT_READBACK_COMPLETE', stage=stage,
    files=len(bindings), bytes=sum(x['bytes'] for x in bindings.values()), qualification=False)))
