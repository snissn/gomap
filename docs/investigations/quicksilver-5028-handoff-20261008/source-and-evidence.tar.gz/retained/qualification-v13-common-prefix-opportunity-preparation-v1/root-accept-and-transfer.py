"""Root source review acceptance and small artifact-only exclusive transfer."""
import ast,hashlib,json,pathlib,subprocess,time,types
P=pathlib.Path; HERE=P(__file__).resolve().parent; BASE=HERE.parent
def sha(p): return hashlib.sha256(P(p).read_bytes()).hexdigest()
def ref(p): return dict(path=str(P(p)),sha256=sha(p))
d=json.loads((HERE/'source-bindings.json').read_bytes());source=P(d['source_root'])
assert d['head']=='4ba7bfad3c29d176fe7686f14cfe49276a9b3d3a'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==d['head']
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=source,text=True)
for r in d['source_bindings']:
    p=source/r['path']; assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
    assert subprocess.check_output(['git','rev-parse',d['head']+':'+r['path']],cwd=source,text=True).strip()==r['git_blob']
for r in d['artifact_inputs']+d['packet_bindings']:
    p=P(r['path']); assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
for p in HERE.glob('*.py'): ast.parse(p.read_text(),filename=str(p))
assert sha(HERE/'request.json')=='5121ea060f934c952d8d9343a6372e924167a68356ca1a25c33f028a2e9657f9'
request=json.loads((HERE/'request.json').read_bytes())
assert request['collection_authorized'] is False and request['qualification'] is False
receipt=dict(status='ROOT_SOURCE_REVIEW_ACCEPTED_PREPARATION_ONLY',created_ns=time.time_ns(),head=d['head'],tree=d['tree'],bindings=ref(HERE/'source-bindings.json'),request=ref(HERE/'request.json'),source_count=len(d['source_bindings']),artifact_count=len(d['artifact_inputs']),packet_count=len(d['packet_bindings']),reviewed=['bounded whole-stage commands and synchronous controller deadlines','original collector remains hash-bound and unchanged','diagnostic ownership shim keeps time and benchmark in outer PGID','only actual joined exit-zero oracle-validated final DB-closed counter row can be interpreted','default workload, immutable source inputs and original outcome gates preserved','separate explicit root runtime lease per stage; adjacent R1 reservation respected'],runtime_cancellation_tested=False,native_executed=False,qualification=False,performance_accepted=False,process_memory_accepted=False)
with (HERE/'root-source-readiness-acceptance.json').open('x') as f: json.dump(receipt,f,indent=2,allow_nan=False);f.write('\n')
io_path=BASE/'qualification-v9-selected-source-preparation-v1/root_native_io.py'
assert sha(io_path)=='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io=types.ModuleType('root_opportunity_io');io.__file__=str(io_path);exec(compile(io_path.read_bytes(),str(io_path),'exec'),io.__dict__);io.HERE=HERE
names=['request.json','root-ready.py','prepare-diagnostic-overlay.py','prepare-quiescent-overlay.py','run-owned-collector.py','capture-plan.json','source-bindings.json','REPORT.md','root-source-readiness-acceptance.json']
directory='qualification-v13-common-prefix-opportunity-control-v1'
actual=io.put({directory+'/'+name:HERE/name for name in names},'root-exclusive-artifact-transfer-v2')
print(json.dumps(dict(status=actual['status'],files=len(actual['received']),bytes=sum(r['bytes'] for r in actual['received'].values()),Go_executed=False,runtime_lease_granted=False)),flush=True)
