"""Root-only launcher; preparation never creates a runtime grant."""
import hashlib, json, os, sys, time
from pathlib import Path
H = Path(__file__).resolve().parent
B = H.parent
stage = sys.argv[1]
assert stage in ('prepare', 'collect')
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
q = json.loads((H / 'request.json').read_bytes())
assert sha(H / 'request.json') == '5121ea060f934c952d8d9343a6372e924167a68356ca1a25c33f028a2e9657f9'
assert sha(H / 'root-ready.py') == '771e779d4ca61896d09bd26f0fa4868e939f47ebe59e95fc4b60566bd461f226'
lease_path = H / ('root-native111-' + stage + '-lease.json')
lease = json.loads(lease_path.read_bytes())
assert lease['status'] == 'EXPLICIT_ADJACENT_ROOT_RELEASE_AND_CURRENT_GRANT'
assert lease['host'] == '192.168.0.111' and lease['owner'] == 'root-5028'
assert lease['actual_root_join_and_quiescence_confirmed'] is True
assert lease['phase'] == 'R-common-prefix-opportunity-overlay-' + stage
assert lease['whole_stage_budget_seconds'] == q['stage_deadlines_seconds'][stage]
assert time.time_ns() < lease['expires_ns']
accepted = json.loads((H / 'root-actual-build-acceptance.json').read_bytes())
assert accepted['status'] == 'ROOT_ACCEPTED_DIAGNOSTIC_OVERLAY_BUILD_AND_AFFECTED_NORMAL_TESTS_ONLY'
if stage == 'collect':
    accepted_prepare = json.loads((H / 'root-actual-prepare-acceptance.json').read_bytes())
    assert accepted_prepare['status'] == 'ROOT_ACCEPTED_FRESH_PRIVATE_COPY_AND_REBIND_ONLY'
S = B / 'state.json'
old = S.read_bytes()
s = json.loads(old)
assert s['native_active'] is None and s['native_heavy_slot'] is None
assert s['qualification_v13_current']['native_active'] is None
active = dict(owner='root', phase=lease['phase'], head=q['head'], qualification=False,
    started_ns=time.time_ns(), runtime_lease=dict(path=str(lease_path), sha256=sha(lease_path)))
s['native_active'] = active
s['native_heavy_slot'] = active
s['qualification_v13_current']['native_active'] = active
pending = H / ('state.' + stage + '.launch.pending')
pending.write_text(json.dumps(s, indent=2) + '\n')
assert S.read_bytes() == old
os.replace(pending, S)
p = B / 'qualification-v9-selected-source-preparation-v1/root_native_io.py'
raw = p.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io = dict(__file__=str(p), __name__='root_io')
exec(compile(raw, str(p), 'exec'), io)
io['HERE'] = H
io['native'](['python3', '-B', q['root'].split('/qualification-v12-refresh')[0]
    + '/qualification-v13-common-prefix-opportunity-control-v1/root-ready.py',
    q['root'].split('/qualification-v12-refresh')[0]
    + '/qualification-v13-common-prefix-opportunity-control-v1/request.json',
    sha(H / 'request.json'), '--stage', stage, '--root-runtime-lease', sha(lease_path)],
    'actual-' + stage + '-opportunity-v1', q['stage_deadlines_seconds'][stage] + 30)
print(json.dumps(dict(status='ACTUAL_STAGE_OUTER_SSH_JOINED_RELEASE_AUDIT_PENDING',
    stage=stage, qualification=False)), flush=True)
