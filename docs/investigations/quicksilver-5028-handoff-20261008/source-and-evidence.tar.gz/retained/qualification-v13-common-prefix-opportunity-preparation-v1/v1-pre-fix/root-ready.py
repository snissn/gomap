"""PREPARED ONLY. Root explicitly leases each stage; never updates graph state."""
import argparse, hashlib, json, os, pathlib, shutil, signal, sys, time, types
P=pathlib.Path
p=argparse.ArgumentParser();p.add_argument('request');p.add_argument('request_sha256');p.add_argument('--stage',choices=['build','prepare','collect'],required=True);p.add_argument('--root-runtime-lease',required=True);a=p.parse_args()
def sha(path): return hashlib.sha256(P(path).read_bytes()).hexdigest()
def save(path,obj):
 with P(path).open('x') as f: json.dump(obj,f,indent=2,allow_nan=False);f.write('\n')
def bound(ref):
 assert not P(ref['path']).is_symlink() and sha(ref['path'])==ref['sha256'];return json.loads(P(ref['path']).read_bytes())
def load(ref,name):
 path=P(ref['path']);assert not path.is_symlink() and sha(path)==ref['sha256']
 m=types.ModuleType(name);m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
assert a.root_runtime_lease and sha(a.request)==a.request_sha256
q=json.loads(P(a.request).read_bytes());assert q['head']=='4ba7bfad3c29d176fe7686f14cfe49276a9b3d3a'
assert q['qualification'] is False and q['performance_accepted'] is False and q['collection_authorized'] is False
assert q['held_excluded']==[5004,5006]
here=P(a.request).resolve().parent;source=P(q['source']);root=P(q['root']);work=P(q['work']);binary=P(q['binary'])
assert sha(q['rss_helper']['path'])==q['rss_helper']['sha256']
sys.path.insert(0,str(P(q['capture']['path']).parent))
pc=load(q['helpers']['pipeline_common.py'],'opportunity_compiler_common');builder=load(q['helpers']['build-native-v12.py'],'opportunity_builder')
for sig in (signal.SIGINT,signal.SIGTERM): signal.signal(sig,builder.interrupt)
frozen=pc.bound(q['context']['source_freeze']);env,go=pc.environment(q['context'],frozen)
listing=bound(q['tracked_manifest']);assert listing['head']==q['head'] and listing['tree']==q['tree']
builder.verify(source,listing);assert builder.leaves(source)==set(listing['files'])
assert sha(q['accepted_binary'])==q['accepted_binary_sha256']
# This root lease must have no pre-existing benchmark/Go/maintenance consumers.
for entry in P('/proc').iterdir():
 if not entry.name.isdecimal() or int(entry.name)==os.getpid(): continue
 try: raw=(entry/'cmdline').read_bytes().split(b'\0');name=P(os.fsdecode(raw[0])).name if raw and raw[0] else ''
 except OSError: continue
 assert name not in ('go','compile','link','snapshot-restore') and not name.startswith(('unified-bench','treedb-compact','allocation-accounting')), (entry.name,name)
assert __debug__, 'Python -O forbidden'
for name,expected in q['packet_sha256'].items(): assert sha(here/name)==expected
if a.stage=='build': work.mkdir(exist_ok=False)
else: assert work.is_dir()
started=time.time_ns();receipt={'stage':a.stage,'started_ns':started,'root_runtime_lease':a.root_runtime_lease,'qualification':False,'performance_accepted':False,'process_memory_accepted':False,'commands':[]}
save(work/(a.stage+'-owner.json'),dict(receipt,pid=os.getpid(),argv=sys.argv))
def run(prefix,argv,timeout):
 record,failure=pc.run(argv,source,env,work,prefix,timeout);save(work/(prefix+'-run.json'),record);receipt['commands'].append(record);builder.successful(record,failure);assert record['raw_hashes_final'];return record
try:
 if a.stage=='build':
  overlay=work/'overlay';run('generate-overlay',[sys.executable,'-B',str(here/'prepare-quiescent-overlay.py'),'--source-root',str(source),'--output',str(overlay)],30)
  replacement=json.loads((overlay/'overlay.json').read_bytes())['Replace']
  assert len(replacement)==3
  for src,dst in replacement.items():
   assert sha(src)==q['overlay_source_sha256'][str(P(src).relative_to(source))]
  version=run('go-version',[go,'version'],30)
  assert P(version['stdout_path']).read_text().startswith('go version go1.26.3 ')
  tags=['-tags','lmdb rocksdb'];package='./cmd/unified_bench';ov=['-overlay',str(overlay/'overlay.json')]
  original=run('go-list-base',[go,'list','-deps','-json',*tags,package],180)
  inputs=pc.compiler_inputs(pc.json_stream(P(original['stdout_path']).read_text()),source,listing)
  effective=dict(inputs['selected_files'])
  for src,dst in replacement.items():
   assert src in effective
   effective[src]=dict(pc.file_binding(P(dst)),virtual_source=src,base_git=listing['files'][str(P(src).relative_to(source))],base_source_sha256=sha(src),diagnostic_overlay=True)
  assert not binary.exists()
  built=run('build-overlay',[go,'build','-p','1','-buildvcs=false','-work','-x',*ov,*tags,'-o',str(binary),package],360)
  # Actual compile argv, not merely Go-list classification, must show all replacements.
  compile_lines=[s for s in P(built['stderr_path']).read_text().splitlines() if '/compile ' in s]
  for dst in replacement.values(): assert any(dst in line for line in compile_lines), 'missing actual overlay compile input: '+dst
  exports_run=run('go-list-overlay-exports',[go,'list','-p','1','-deps','-export','-json',*ov,*tags,package],180)
  exports=pc.package_exports(pc.json_stream(P(exports_run['stdout_path']).read_text()));generated=pc.work_inputs(built['stderr_path'])
  native=pc.native_scope(q['context'],frozen)
  for values in (inputs['selected_files'],effective,inputs['module_files'],inputs['uncompiled_repository_test_inputs'],exports,native,generated['generated_and_work_files'],generated['actual_import_archives']): pc.verify_bindings(values)
  compiler=dict(head=q['head'],tree=q['tree'],env=env,go_tool=q['context']['go_tool'],tags=tags,**inputs,effective_overlay_selected_files=effective,overlay_replace=replacement,actual_overlay_compile_argv=compile_lines,actual_package_export_archives=exports,native_input_files=native,**generated,qualification=False)
  save(work/'compiler-inputs.json',compiler)
  run('freelist-normal',[go,'test',*ov,'-v','-count=1','-timeout','2m','./TreeDB/freelist'],180)
  focused='^Test(COWBuildGroupRejectsChangedUserBasisBeforeApply|CompactIndexPrepareFailureRollsBackOldTreeRetirements|FlushApplyPreparedPublishMismatchRetriesWithoutPublishingPreparedRoot|FlushApplyPreparedPublishWriteSyncReopens|RootPublicationBuildGroupStagesOnlyFinalCandidate|RootPublicationBuildGroupAbortDiscardsStagedRoot)$'
  run('db-focused-normal',[go,'test',*ov,'-v','-count=1','-run',focused,'-timeout','2m','./TreeDB/db'],180)
  harness='^TestQuicksilver(RetainedReaderFailureJoins|RetainedIncompleteWriterReleasesOwner|StatsAfterWriterDrain|ReaderTimerExcludesWriterDrain|RetainedConcurrentGeneration|ErrorJoins|RealisticWorkflow)$'
  run('harness-quiescence-normal',[go,'test',*ov,*tags,'-v','-count=1','-run',harness,'-timeout','2m','./cmd/unified_bench'],180)
  for prefix,names in [('db-focused-normal',focused[6:-2].split('|')),('harness-quiescence-normal',['Quicksilver'+s for s in harness[17:-2].split('|')])]:
   raw=(work/(prefix+'-stdout.txt')).read_text()
   # Root additionally reads full raw bodies; named coverage is not inferred from exit alone.
   for name in names: assert '--- PASS: Test'+name+' ' in raw, 'missing named pass '+name
  builder.verify(source,listing);assert builder.leaves(source)==set(listing['files'])
  save(work/'source-receipt.json',dict(head=q['head'],tree=q['tree'],tracked_manifest=q['tracked_manifest'],base_source_verified_unchanged=True,diagnostic_overlay=replacement,overlay_bindings=pc.file_binding(overlay/'bindings.json'),qualification=False))
  receipt.update(status='OVERLAY_BUILD_AND_NORMAL_TESTS_JOINED',binary_sha256=sha(binary),compiler_inputs_sha256=sha(work/'compiler-inputs.json'))
 elif a.stage=='prepare':
  prior=json.loads((work/'build-outcome.json').read_bytes());assert prior['status']=='OVERLAY_BUILD_AND_NORMAL_TESTS_JOINED' and sha(binary)==prior['binary_sha256']
  capture=load(q['capture'],'unified_bench_quicksilver_capture');maintenance=load(q['maintenance'],'quicksilver_maintenance')
  manifest=bound(q['original_manifest'])
  for role in ('source','build','native','runner'):
   ref=manifest['receipts'][role];path=P(ref['path']);path=path if path.is_absolute() else root/path;assert sha(path)==ref['sha256']
  retained=P(q['retained_source']);before=maintenance.fingerprint(retained);assert before==q['retained_source_fingerprint']
  assert shutil.disk_usage(root).free>20*1024**3
  fixture=P(q['fixture']);fixture.mkdir(exist_ok=False);db=fixture/'db';shutil.copytree(retained,db)
  assert maintenance.fingerprint(db)==before and maintenance.fingerprint(retained)==before
  metadata=dict(source=str(retained),copy=str(db),before=before,qualification=False)
  save(fixture/'copy-before-rebind.json',metadata)
  runtime_env=capture.capture_environment(manifest['build_env'],root/'working-dbs')
  restore=manifest['sources'][manifest['snapshot_restore']];restore_binary=root/'bin'/restore['binary'];assert sha(restore_binary)==restore['binary_sha256']
  capture.validate_native(restore_binary,restore,manifest['libraries'],runtime_env,root,fixture,{})
  original_env=env;env=runtime_env
  try: run('restore-private-copy',[str(restore_binary),str(db)],1800)
  finally: env=original_env
  restored=json.loads((work/'restore-private-copy-stdout.txt').read_bytes());assert restored['rebound'] is True and restored['operation']=='RebindDurableRootSnapshotLayoutWithContextV1'
  assert restored['stores'] in (['maindb'],['dictdb','maindb'],['templatedb','maindb'],['dictdb','templatedb','maindb'],['backend'])
  assert maintenance.fingerprint(retained)==before
  metadata.update(copy_after_rebind=maintenance.fingerprint(db),retained_after=maintenance.fingerprint(retained));save(fixture/'prepared-receipt.json',metadata)
  manifest['sources']['PREFIX_DIAGNOSTIC']=dict(head=q['head'],tree=q['tree'],built_against_head=q['head'],binary=binary.name,binary_sha256=sha(binary),linkage='dynamic')
  manifest['receipts']['source']=dict(path=str(work/'source-receipt.json'),sha256=sha(work/'source-receipt.json'));manifest['receipts']['build']=dict(path=str(work/'compiler-inputs.json'),sha256=sha(work/'compiler-inputs.json'))
  save(q['manifest'],manifest);save(q['plan'],q['capture_plan'])
  receipt.update(status='FRESH_COPY_REBOUND_SOURCE_UNCHANGED',source_fingerprint=before,copy_after_rebind=metadata['copy_after_rebind'])
 else:
  assert json.loads((work/'prepare-outcome.json').read_bytes())['status']=='FRESH_COPY_REBOUND_SOURCE_UNCHANGED'
  prior=json.loads((work/'build-outcome.json').read_bytes());assert sha(binary)==prior['binary_sha256']
  capture=load(q['capture'],'unified_bench_quicksilver_capture');maintenance=load(q['maintenance'],'quicksilver_maintenance')
  before=maintenance.fingerprint(P(q['retained_source']));assert before==q['retained_source_fingerprint']
  run('collector',[sys.executable,'-B',q['capture']['path'],q['manifest'],q['plan']],2400)
  output=root/q['capture_plan']['output']/('1-'+q['capture_plan']['cells'][0]['label'])
  actual=json.loads((output/'run.json').read_bytes());assert actual['rc']==0 and actual['validated'] is True
  assert actual['source']['head']==q['head'] and actual['source']['binary_sha256']==sha(binary)
  assert maintenance.fingerprint(P(q['retained_source']))==before
  rows=[]
  for line in (output/'stderr.log').read_text().splitlines():
   if line.startswith('{'):
    try: row=json.loads(line)
    except json.JSONDecodeError: continue
    if row.get('diagnostic')=='freelist-private-common-prefix': rows.append(row)
  final=[r for r in rows if r.get('endpoint')=='engine-return-db-closed'];assert len(final)==1 and rows[-1]==final[0]
  d=final[0];hist=d['common_nibble_edges_histogram'];assert len(hist)==14
  assert d['selected_reused']==d['no_private_authority']+d['same_private_chunk']+d['certified_chunk_switches']
  assert d['certified_chunk_switches']==d['eligible_complete_proof_switches']+d['invalid_complete_proof_switches']
  assert sum(hist)==d['eligible_complete_proof_switches'] and sum((i+1)*v for i,v in enumerate(hist))==d['reusable_ancestor_node_count']
  save(work/'opportunity-census.json',dict(counter=d,intermediate_dumps=len(rows)-1,run=pc.file_binding(output/'run.json'),stderr=pc.file_binding(output/'stderr.log'),source_fingerprint_unchanged=before,timings_instrumented_unqualified=True,qualification=False,performance_accepted=False))
  receipt.update(status='QUIESCENT_CENSUS_JOINED_DIAGNOSTIC_ONLY',census_sha256=sha(work/'opportunity-census.json'))
except BaseException as error:
 receipt.update(status='FAILED_RETAINED_NO_AUTOMATIC_RETRY',error=repr(error));raise
finally:
 receipt['finished_ns']=time.time_ns();save(work/(a.stage+'-outcome.json'),receipt)
