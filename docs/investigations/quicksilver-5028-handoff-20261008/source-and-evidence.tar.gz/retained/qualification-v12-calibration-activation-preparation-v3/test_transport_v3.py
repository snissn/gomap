"""Local extracted-source transport contracts; fake I/O performs no SSH/native."""
import ast,hashlib,json,os,tempfile,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
PARENT=BASE/'qualification-v12-calibration-activation-preparation-v1'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def block(name,start,end):
 text=(HERE/name).read_text();text=text[text.index(start):text.index(end,text.index(start))]
 if text.startswith('    '):text='\n'.join(x[4:] if x.startswith('    ') else x for x in text.splitlines())+'\n'
 return compile(text,name,'exec')
FREEZE=block('root-freeze-qualification-v12-v1.py','    probe_path=HERE/', '\n    proof = ')
REST=block('root-authorize-remaining-calibration-v12-v1.py',"probe_path=HERE/",'\nsave(ap,')
FMARK="print(json.dumps(dict(schema=1,actual_files=actual,namespace=namespace,read_ns=time.time_ns(),qualification=False,collection_authorized=False)))"
class FakeIO:
 def __init__(self,kind):self.kind=kind;self.calls=[];self.tamper=False
 def put(self,sources,label):
  self.calls.append(('put',label));self.p=next(iter(sources.values()));self.before=self.p.read_bytes();self.h=digest(self.p)
  assert len(sources)==1
 def native(self,argv,label,timeout):
  assert self.calls and self.calls[-1][0]=='put';assert argv==['python3','-B',str(self.p)]
  assert self.p.read_bytes()==self.before
  assert len(' '.join(argv).encode())<1024
  self.calls.append(('native',label,timeout))
  h='0'*64 if self.tamper else self.h
  if self.kind=='freeze':return json.dumps({'actual_files':{str(self.p):{'sha256':h}}})
  return json.dumps({'anchor':{'generated_native_probe':{'path':str(self.p),'sha256':h},'files':{str(self.p):h}}})
def environment(tmp,io):
 p=Path(tmp);files={};canonical={}
 def add(path,h):assert path not in files or files[path]==h;files[path]=h
 return dict(HERE=p,BASE=p.parent,Path=Path,json=json,io=io,files=files,canonical_files=canonical,add=add,
             ref=lambda p:dict(path=str(p),sha256=digest(p)))
class Contracts(unittest.TestCase):
 def test_real_map_oversize_byte_exact_short_argv(self):
  frontier=json.loads((BASE/'qualification-v12-root-preparation-v1/pre-c1-closure-frontier.accepted-v1.json').read_bytes())
  full=repr(frontier['actual_native_files']);self.assertEqual(len(frontier['actual_native_files']),12445)
  self.assertEqual(len(full.encode()),2355888);self.assertGreater(len(full.encode()),os.sysconf('SC_ARG_MAX'))
  with tempfile.TemporaryDirectory(dir=HERE) as tmp:
   io=FakeIO('freeze');env=environment(tmp,io);original='files='+full+'\n'+FMARK+'\n';env['probe']=original
   exec(FREEZE,env);generated=env['probe'];self.assertEqual(generated.replace(env['self_readback'],''),original)
   self.assertEqual(io.before,generated.encode());self.assertNotIn(io.h,generated)
   self.assertEqual(env['files'],env['canonical_files']);self.assertEqual(io.calls[-1],('native','v12-actual-full-pre-C1-source-anchor-readback-v1',240))
   with self.assertRaises(FileExistsError):exec(FREEZE,env)
 def test_freezer_digest_mismatch_fails(self):
  with tempfile.TemporaryDirectory(dir=HERE) as tmp:
   io=FakeIO('freeze');io.tamper=True;env=environment(tmp,io);env['probe']=FMARK+'\n'
   with self.assertRaises(AssertionError):exec(FREEZE,env)
   self.assertFalse(env['files'])
 def test_remaining_byte_exact_short_argv_and_exclusive(self):
  with tempfile.TemporaryDirectory(dir=HERE) as tmp:
   io=FakeIO('rest');env=environment(tmp,io);original="a={'files':{}}\ncanonical={}\n# exact frozen facts\n";env['closure']=original
   exec(REST,env);self.assertEqual(env['closure'].replace(env['self_binding'],''),original)
   self.assertNotIn(io.h,env['closure']);self.assertEqual(io.before,env['closure'].encode())
   self.assertEqual(io.calls[-1],('native','v12-actual-post-small-source-closure-v1',1800))
   with self.assertRaises(FileExistsError):exec(REST,env)
 def test_remaining_digest_mismatch_fails(self):
  with tempfile.TemporaryDirectory(dir=HERE) as tmp:
   io=FakeIO('rest');io.tamper=True;env=environment(tmp,io);env['closure']='canonical={}\n'
   with self.assertRaises(AssertionError):exec(REST,env)
 def test_generated_self_binding_checks_real_local_bytes(self):
  with tempfile.TemporaryDirectory(dir=HERE) as tmp:
   io=FakeIO('rest');env=environment(tmp,io);env['closure']='canonical={}\n';exec(REST,env)
   p=env['probe_path'];g=dict(Path=Path,__file__=str(p),a={'files':{}},sha=digest)
   exec(env['self_binding'],g);self.assertEqual(g['a']['files'][str(p)],digest(p))
   with self.assertRaises(AssertionError):exec(env['self_binding'],g)
   alias=Path(tmp)/'alias.py';alias.symlink_to(p);g.update(__file__=str(alias),a={'files':{}})
   with self.assertRaises(AssertionError):exec(env['self_binding'],g)
 def test_all_original_probe_templates_and_driver_verifier_unchanged(self):
  for name in ('collection-native-driver-v12-v2.py','verify-qualification-v10-deployment-v2.py'):
   self.assertEqual((HERE/name).read_bytes(),(PARENT/name).read_bytes())
  for name,var in [('root-freeze-qualification-v12-v1.py','probe'),('root-authorize-remaining-calibration-v12-v1.py','closure')]:
   def literal(folder):
    for n in ast.walk(ast.parse((folder/name).read_bytes())):
     if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==var for t in n.targets) and isinstance(n.value,ast.Constant):return n.value.value
    raise AssertionError('template missing')
   self.assertEqual(literal(HERE),literal(PARENT))
  for p in HERE.glob('*.py'):ast.parse(p.read_bytes())
if __name__=='__main__':unittest.main(verbosity=2)
