#!/usr/bin/env python3
"""Artifact-only proposal. Reads anchored packets, emits JSON; launches nothing.

An externally supplied anchor digest is the trust boundary, not run.json's own
hash fields. Root must accept the definition and receipt contents before use.
Original kept DB paths must remain available for original collector replay;
this reads no DB values and cannot replace the collector's captured oracles.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
import pathlib
import re
import statistics
import sys
import time
sys.dont_write_bytecode = True


class Invalid(ValueError):
    pass


def require(ok, why):
    if not ok:
        raise Invalid(why)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def number(value, label, positive=False):
    require(type(value) in (int, float) and math.isfinite(value), label + ': finite number required')
    require(value > 0 if positive else value >= 0, label + ': invalid sign/resolution')
    return value


class Inventory:
    def __init__(self, path, expected):
        self.path = pathlib.Path(path).resolve(strict=True)
        require(digest(self.path) == expected, 'external anchor digest mismatch')
        self.anchor = json.loads(self.path.read_bytes())
        require(self.anchor['schema'] == 1 and self.anchor['accepted_by_root'] is True, 'unaccepted anchor')
        self.root = pathlib.Path(self.anchor['root']).resolve(strict=True)
        self.files = self.anchor['files']
        require(self.files and all(re.fullmatch('[0-9a-f]{64}', v) for v in self.files.values()), 'missing raw anchors')
        # Hash each inventory file once and reject canonical aliases up front.
        self.by_path = {}
        for name in self.files:
            path = self.resolve(name)
            require(path not in self.by_path, 'aliased raw anchor: '+name)
            require(path.is_file() and digest(path) == self.files[name], 'raw inventory drift: '+name)
            self.by_path[path] = name

    def resolve(self, name):
        require(isinstance(name, str), 'anchor path must be text')
        path = pathlib.Path(name)
        if not path.is_absolute():
            path = self.root / path
        return path.resolve(strict=True)

    def file(self, name):
        path = self.resolve(name)
        require(self.by_path.get(path) == name and digest(path) == self.files.get(name), 'unanchored/drifting file: '+name)
        return path

    def json(self, name):
        return json.loads(self.file(name).read_bytes())

    def local(self, path):
        path = pathlib.Path(path).resolve(strict=True)
        name = self.by_path.get(path)
        require(name is not None, 'missing raw anchor: '+str(path))
        return self.file(name)


def load_collectors(inv):
    paths = inv.anchor['harness_files']
    require(inv.anchor['landed_harness_attested'] is True, 'harness landing not attested')
    modules = {}
    # Exact anchored imports only; maintenance must reuse this same unified module.
    for key, name in [('observer', 'owned_process_rss'), ('collector', 'unified_bench_quicksilver_capture'),
                      ('maintenance', 'quicksilver_maintenance')]:
        path = inv.file(paths[key])
        require(path.name == name+'.py', 'wrong original harness module')
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        modules[key] = module
    # Original maintenance load_run hashes all raw/plan/restore/fixture receipts.
    # Make every such dependency require the external anchor as well as its own
    # captured digest. This hook does not execute a capture or change raw bytes.
    modules['collector'].sha256 = lambda path: digest(inv.local(path))
    return modules['collector'], modules['maintenance']


def expected_command(binary, cell, collector):
    case = cell.get('case', 'realistic')
    command = [str(binary), '-suite', 'quicksilver', '-dbs', cell['engine'], '-profile', cell.get('profile', 'durable'),
        '-quicksilver-case', case, '-keys', str(cell.get('keys', 3000000)), '-read-workers', str(cell.get('workers', 4)),
        '-quicksilver-reads', str(cell.get('reads', 6000000)), '-quicksilver-updates', str(cell.get('updates', 40000)),
        '-quicksilver-duration', cell.get('duration', '8s'), '-quicksilver-read-batch', '64',
        '-quicksilver-commit', cell.get('commit', 'auto'), '-max-wall', collector.capture_wall_limit(cell)]
    if case == 'realistic':
        command += ['-seed', str(cell.get('seed', 24)), '-quicksilver-mixture', cell.get('mixture', 'primary'),
            '-quicksilver-working-set', cell.get('working_set', 'uniform'), '-quicksilver-miss-percent', str(cell.get('miss_percent', 90))]
    if cell.get('churn_rounds', 0):
        command += ['-quicksilver-churn-rounds', str(cell['churn_rounds']), '-quicksilver-churn-pause', cell.get('churn_pause', '6s'),
                    '-quicksilver-churn-shape', cell.get('churn_shape', 'full-refresh')]
    if cell.get('measure_dir'):
        command += ['-quicksilver-measure-dir', str(pathlib.Path(cell['measure_dir']).resolve(strict=True))]
    command += cell.get('flags', [])
    if cell.get('keep', False):
        command += ['-keep']
    return command


def load_run(inv, collector, name):
    path = inv.file(name)
    run = json.loads(path.read_bytes())
    require(run.get('validated') is True and type(run.get('rc')) is int and run['rc'] == 0 and 'error' not in run, 'failed/unvalidated run')
    require(run.get('repeat') == 1 and run['cell'].get('profiled', False) is False, 'profiled/repeated run')
    start, finish = run['started'], run['finished']
    number(start, 'start', True); number(finish, 'finish', True)
    require(finish > start, 'run clock order')
    manifest_path = inv.local(path.parent.parent/'manifest.json')
    plan_path = inv.local(path.parent.parent/'plan.json')
    manifest = json.loads(manifest_path.read_bytes()); plan = json.loads(plan_path.read_bytes())
    require(digest(manifest_path) == run['manifest_sha256'] and digest(plan_path) == run['plan_sha256'], 'plan/manifest binding')
    require(plan.get('repeats', 1) == 1 and run['cell'] in plan['cells'], 'cell/plan binding')
    require(run['source'] == manifest['sources'][run['cell']['source']], 'source binding')
    require(run['collector_sha256'] == digest(inv.file(inv.anchor['harness_files']['collector'])) and
            run['rss_observer_sha256'] == digest(inv.file(inv.anchor['harness_files']['observer'])), 'harness source drift')
    require(set(manifest['receipts']) == {'source', 'build', 'native', 'runner'}, 'receipt roles')
    for role, identity in manifest['receipts'].items():
        require(digest(inv.local(path.parent.parent/(role+'-receipt.json'))) == identity['sha256'], 'receipt binding: '+role)
    require(inv.anchor['receipt_contents_accepted'] is True, 'receipt hashes alone are not content attestation')
    native = run['native_resolution']
    require(native['rc'] in ((0, 1) if run['source'].get('linkage') == 'static' else (0,)), 'native resolution failed')
    require(native['linkage'] == run['source'].get('linkage', 'dynamic'), 'linkage drift')
    require(not any(v for k, v in native['loader_env'].items() if k.startswith('LD_') and k != 'LD_LIBRARY_PATH'), 'loader injection')
    for library, sha in native['libraries'].items():
        require(sha == manifest['libraries'][library]['sha256'], 'native identity drift')
        require(digest(inv.local(library)) == sha, 'native library raw binding')
    binary = inv.local(run['command'][0])
    require(binary.name == run['source']['binary'] and digest(binary) == run['source']['binary_sha256'], 'binary identity drift')
    require(run['command'] == expected_command(binary, run['cell'], collector), 'original capture argv drift')
    with binary.open('rb') as stream:
        require(stream.read(4) == b'\x7fELF', 'non-native executable')
    inv.local(path.parent/'ldd.stdout.txt'); inv.local(path.parent/'ldd.stderr.txt')
    for key, value in inv.anchor['controls'].items():
        require(run['env'].get(key) == value, 'runtime control drift: '+key)
    report_path = inv.local(path.parent/'stdout.json')
    inv.local(path.parent/'stderr.log')
    reports = json.loads(report_path.read_bytes())
    replay = copy.deepcopy(run)
    replay.pop('miss_ratio_validation', None)  # Recompute, do not append to captured checks.
    # Existing original validator checks generation/counts/full-byte/miss/census,
    # ACK/CRC/default flags, quantile/rate/allocation numerators and round work.
    collector.validate(reports, run['cell'], path.parent, {}, replay)
    require(replay.get('miss_ratio_validation') == run.get('miss_ratio_validation'), 'miss-screen receipt drift')
    summary = json.loads(inv.local(path.parent/'rss_samples.jsonl.summary.json').read_bytes())
    require(summary == run['rss_sampling'] and pathlib.Path(summary['expected_executable']).resolve() == binary, 'RSS summary/executable binding')
    require(summary['complete'] is True and not summary['cancelled'] and not summary['errors'] and summary['interval_ms'] == 200, 'incomplete RSS')
    rows = [json.loads(v) for v in inv.local(path.parent/'rss_samples.jsonl').read_text().splitlines()]
    require(len(rows) == summary['samples'] and rows, 'RSS count')
    identities = {(v['pid'], v['process_start_ticks']) for v in rows}
    require(len(identities) == 1 and next(iter(identities))[0] == summary['observed_pid'], 'RSS identity changed')
    previous = summary['started_unix_nano']
    for row in rows:
        lo, hi = row['started_unix_nano'], row['finished_unix_nano']
        require(type(lo) is int and type(hi) is int and previous <= lo < hi <= summary['finished_unix_nano'], 'sample clock/order')
        require(type(row['pid']) is int and row['pid'] > 0 and type(row['process_start_ticks']) is int and row['process_start_ticks'] > 0, 'sample process identity type')
        for field in ('rss_bytes', 'anonymous_bytes', 'file_bytes', 'shared_memory_bytes'):
            require(type(row[field]) is int and row[field] >= 0, 'sample bytes')
        previous = hi
    require(summary['first_sample_unix_nano'] == rows[0]['started_unix_nano'] and summary['last_sample_unix_nano'] == rows[-1]['finished_unix_nano'], 'sample endpoint drift')
    require(int(start*1e9) <= summary['started_unix_nano'] <= summary['finished_unix_nano'] <= int(finish*1e9)+1024, 'sampler/run clock containment')
    return dict(name=name, run=run, report=reports[0], rows=rows)


def contract(packet):
    run = packet['run']
    cell = {k: v for k, v in run['cell'].items() if k not in ('label', 'source', 'measure_dir')}
    return dict(cell=cell, state='retained-final-inplace' if run['cell'].get('measure_dir') else 'fresh',
                config=packet['report']['config'], env=run['env'],
                collector=run['collector_sha256'], observer=run['rss_observer_sha256'],
                manifest=run['manifest_sha256'], libraries=run['native_resolution']['libraries'],
                loader=run['native_resolution']['loader_env'])


def common_inventory(inv, name, run):
    path = inv.file(name)
    manifest = json.loads(inv.local(path.parent.parent/'manifest.json').read_bytes())
    require(digest(inv.local(path.parent.parent/'manifest.json')) == run['manifest_sha256'], 'original common manifest drift')
    require(set(manifest['receipts']) == {'source', 'build', 'native', 'runner'}, 'original receipt roles')
    for role, identity in manifest['receipts'].items():
        require(digest(inv.local(path.parent.parent/(role+'-receipt.json'))) == identity['sha256'], 'original common receipt drift')
    return dict(manifest=run['manifest_sha256'], receipts={k:v['sha256'] for k,v in manifest['receipts'].items()})


def load_original(inv, collector, maintenance, name, kind):
    if kind == 'online':
        packet = load_run(inv, collector, name)
        require(packet['run']['cell'].get('churn_rounds') == 3 and not packet['run']['cell'].get('measure_dir'), 'original online work missing')
        packet.update(kind=kind, started_ns=int(packet['run']['started']*1e9), finished_ns=int(packet['run']['finished']*1e9),
                      original_contract=contract(packet), directory=packet['report']['data_dir'])
    else:
        require(kind == 'offline', 'unknown original producer')
        path = inv.file(name)
        # Includes stdout/stderr/time-v/RSS, restore stdout/stderr/ldd, fixture
        # receipt, copied manifest/plan and all four common inventory receipts.
        # The anchored sha256 hook covers every dependency load_run hashes.
        run, report = maintenance.load_run(path)
        require(maintenance.validate_measurement(json.loads(inv.local(path.parent/'stdout.json').read_bytes()), run['cell']) == report,
                'original measurement replay drift')
        require(maintenance.policy_complete(report), 'incomplete original maintenance policy')
        require(run['harness'] == dict(collector=digest(inv.file(inv.anchor['harness_files']['maintenance'])),
                    unified_collector=digest(inv.file(inv.anchor['harness_files']['collector'])),
                    rss_observer=digest(inv.file(inv.anchor['harness_files']['observer']))), 'original harness binding')
        manifest = json.loads(inv.local(path.parent.parent/'manifest.json').read_bytes())
        for source, native, binary in [(run['source'], run['native_resolution'], run['command'][0]),
                (run['snapshot_restore']['source'], run['snapshot_restore']['native']['native_resolution'], run['snapshot_restore']['command'][0])]:
            require(digest(inv.local(binary)) == source['binary_sha256'], 'original/restore binary binding')
            require(native['linkage'] == source.get('linkage', 'dynamic') and native['rc'] in ((0,1) if native['linkage']=='static' else (0,)), 'original/restore native failure')
            require(not any(v for k,v in native['loader_env'].items() if k.startswith('LD_') and k!='LD_LIBRARY_PATH'), 'original/restore loader injection')
            for library, sha in native['libraries'].items():
                require(sha == manifest['libraries'][library]['sha256'] and digest(inv.local(library)) == sha, 'original/restore native dependency')
        require(all(run['env'].get(k)==v for k,v in inv.anchor['controls'].items()), 'original runtime drift')
        summary = run['rss_sampling']
        require(summary['observed_pid'] > 0 and pathlib.Path(summary['expected_executable']).resolve() == pathlib.Path(run['command'][0]).resolve(), 'original sample owner')
        packet = dict(name=name, kind=kind, run=run, report=report, started_ns=run['started_ns'], finished_ns=run['finished_ns'],
                      original_contract=maintenance.contract(run), directory=str(path.parent/'db'))
    packet['common_inventory'] = common_inventory(inv, name, packet['run'])
    return packet


def original_pairs(inv, collector, maintenance, group, expected_inventory):
    variant = group['variant']
    require(variant in ('B','R') and len(group['runs']) == 6, 'original pair group')
    packets = [load_original(inv, collector, maintenance, name, group['kind']) for name in group['runs']]
    for packet in packets:
        cell = packet['run']['cell']
        if group['kind'] == 'online':
            require(group['cell'] == 'online-primary-n'+str(cell['keys']) and cell['seed'] == 24 and cell['mixture'] == 'primary', 'original online matrix identity')
        else:
            require(group['cell'].endswith('-'+cell['mode']+'-b'+str(cell['batch_size'])), 'original offline mode/batch identity')
    labels = ['A1',variant+'1',variant+'2','A2','A3',variant+'3']
    require([v['run']['cell']['label'] for v in packets] == labels, 'original pair labels/order')
    require(all(a['finished_ns'] <= b['started_ns'] for a,b in zip(packets,packets[1:])), 'original pair overlap/order')
    require(all(v['original_contract'] == packets[0]['original_contract'] and v['common_inventory'] == expected_inventory for v in packets), 'original matched contract/common inventory')
    calibration = [load_original(inv, collector, maintenance, p, group['kind']) for p in group['calibration']]
    require(len(calibration)==3 and [v['run']['cell']['label'] for v in calibration]==['C1','C2','C3'] and all(v['run']['cell']['source']==('A_unified' if group['kind']=='online' else 'A') for v in calibration), 'original group baseline characterizations')
    require(all(v['original_contract']==packets[0]['original_contract'] and v['common_inventory']==expected_inventory and v['run']['source']==packets[0]['run']['source'] for v in calibration), 'original baseline work/source/common inventory drift')
    require(all(a['finished_ns']<=b['started_ns'] for a,b in zip(calibration,calibration[1:])) and calibration[-1]['finished_ns']<packets[0]['started_ns'], 'original baseline/pair order')
    for packet, label in zip(packets, labels):
        role = label[0]+('_unified' if group['kind']=='online' else '')
        require(packet['run']['cell']['source'] == role, 'original source role')
    require(all(v['run']['source'] == packets[0]['run']['source'] for v in (packets[3],packets[4])), 'original baseline source drift')
    require(packets[1]['run']['source'] != packets[0]['run']['source'] and all(v['run']['source'] == packets[1]['run']['source'] for v in (packets[2],packets[5])), 'original candidate source drift')
    return packets


def attach_origins(inv, collector, maintenance, packets, bundle):
    origins = inv.json(bundle['guard_origins'])
    require(origins['accepted_by_root'] is True and origins['inplace_no_reload_restore'] is True and origins['before_after_census_retained'] is True, 'retained guard provenance missing')
    originals = []
    for packet in packets:
        origin = origins['runs'][packet['name']]
        original = load_original(inv, collector, maintenance, origin['original_run'], origin['kind'])
        require(original['run']['cell']['label'] == packet['run']['cell']['label'], 'guard/original replicate label')
        require(pathlib.Path(original['directory']).resolve() == pathlib.Path(origin['directory']).resolve() == pathlib.Path(packet['run']['cell']['measure_dir']).resolve(), 'guard original final-directory mismatch')
        require(original['run']['source']['head'] == packet['run']['source']['head'] and original['common_inventory'] == common_inventory(inv, packet['name'], packet['run']), 'guard original product/common inventory mismatch')
        require(original['finished_ns'] < int(packet['run']['started']*1e9), 'guard preceded original completion')
        packet['original'] = original
        originals.append(original)
    require(len({v['name'] for v in originals}) == len(originals), 'reused original state')
    require(all(v['original_contract'] == originals[0]['original_contract'] for v in originals), 'original state work/controls drift')
    return originals


def quiet(packet, definition, metric):
    cfg = definition['quiet']
    require(cfg['pause_start_field'] and cfg['pause_end_field'], 'actual pause stamp schema not frozen')
    require(cfg['clock_evidence_required'] and cfg['wall_monotonic_tolerance_ns'] is not None, 'clock sanity threshold not frozen')
    r = packet['report']['maintenance_churn']['rounds'][metric['round']-1]
    lo, hi = r[cfg['pause_start_field']], r[cfg['pause_end_field']]
    require(type(lo) is int and type(hi) is int and lo < hi, 'pause stamp ordering')
    requested = packet['report']['config']['churn_pause_ns']
    actual = number(r['pause_seconds'], 'pause duration', True)*1e9
    tolerance = cfg['wall_monotonic_tolerance_ns']
    require(hi-lo >= requested-tolerance and abs((hi-lo)-actual) <= tolerance, 'pause clock/duration mismatch')
    require(r['before']['captured_at_unix_nano'] <= lo < hi <= r['after']['captured_at_unix_nano'], 'pause outside round snapshots')
    # Round wall includes snapshot reads/stats outside timestamp boundaries.
    # Check containment, not equality with those unmeasured ordered costs.
    require(0 <= r['after']['captured_at_unix_nano']-r['before']['captured_at_unix_nano'] <= r['wall_seconds']*1e9+tolerance, 'round clock/monotonic containment')
    upper = hi-cfg['trim_ns']; lower = upper-cfg['window_ns']
    require(lower >= lo+cfg['trim_ns'], 'insufficient actual pause interior')
    rows = [v for v in packet['rows'] if lower <= v['started_unix_nano'] <= v['finished_unix_nano'] <= upper]
    require(len(rows) >= cfg['min_rows'], 'quiet row coverage')
    gaps = [rows[0]['started_unix_nano']-lower, upper-rows[-1]['finished_unix_nano']]
    gaps += [b['started_unix_nano']-a['started_unix_nano'] for a, b in zip(rows, rows[1:])]
    require(max(gaps) <= cfg['max_gap_ns'], 'quiet gap/uncovered endpoint')
    return statistics.median(v[metric['field']] for v in rows), dict(lower_ns=lower, upper_ns=upper, rows=len(rows), max_gap_ns=max(gaps),
        before=r['before'], after=r['after'], completion_location='not established by boundary snapshots')


def extract(packet, definition, metric):
    report = packet['report']; selector = metric['selector']; support = {}
    if selector == 'phase':
        phase = [v for v in report['phases'] if v['name'] == metric['phase']]
        require(len(phase) == 1, 'phase missing/duplicate')
        value = phase[0][metric['field']]; support = phase[0]
        if metric['field'] in ('p50_us', 'p95_us', 'p99_us', 'p999_us', 'max_us'):
            require(type(phase[0]['samples']) is int and 0 < phase[0]['samples'] <= phase[0]['ops'], 'missing latency sample support')
    elif selector == 'quiet':
        value, support = quiet(packet, definition, metric)
    elif selector == 'array':
        values = report[metric['field']]
        require(values and all(number(v, 'duration') >= 0 for v in values), 'empty duration array')
        value = sum(values) if metric['aggregation'] == 'sum' else max(values)
        support = dict(values=values, updated_keys=report['updated_keys'], mutations=report['mutations'], batches=report['mutation_commit_batches'])
    elif selector == 'report':
        value = report[metric['field']]
    elif selector == 'round':
        r = report['maintenance_churn']['rounds'][metric['round']-1]
        value = r[metric['field']]; support = r
    elif selector == 'time-v':
        # Packet stderr is separately anchored; cannot infer HWM from RSS rows.
        value = packet['hwm_bytes']
    else:
        raise Invalid('unsupported exact selector')
    return number(value, metric['id'], True), support


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('calibrate', 'evaluate'))
    parser.add_argument('bundle'); parser.add_argument('--anchor', required=True)
    parser.add_argument('--anchor-sha256', required=True); parser.add_argument('--definition-sha256', required=True)
    args = parser.parse_args()
    require(__debug__, 'original collector validator requires assertions')
    inv = Inventory(args.anchor, args.anchor_sha256)
    definition = inv.json(inv.anchor['definition'])
    require(digest(inv.file(inv.anchor['definition'])) == args.definition_sha256 and definition['accepted_by_root'] is True, 'definition not externally accepted')
    require(inv.anchor['host_clock_and_serialization_accepted'] is True, 'host clock/overlap evidence missing')
    bundle = inv.json(args.bundle); collector, maintenance = load_collectors(inv)
    require(bundle['metric_set'] in definition['metric_sets'] and set(bundle['metrics']) == set(definition['metric_sets'][bundle['metric_set']]), 'incomplete metric ledger')
    c = [load_run(inv, collector, p) for p in bundle['calibration']]
    require(len(c) == 3 and [v['run']['cell']['label'] for v in c] == ['C1', 'C2', 'C3'], 'three baseline characterizations')
    require(all(contract(v) == contract(c[0]) and v['run']['source'] == c[0]['run']['source'] for v in c), 'calibration contract/source drift')
    require(all(a['run']['finished'] <= b['run']['started'] for a, b in zip(c, c[1:])), 'calibration overlap/order')
    require(c[0]['run']['cell']['source'] == 'A_unified', 'baseline role required')
    retained = bool(c[0]['run']['cell'].get('measure_dir'))
    if retained:
        attach_origins(inv, collector, maintenance, c, bundle)
    packets = list(c)
    pairs = []
    if args.command == 'evaluate':
        gate = inv.json(inv.anchor['global_calibration_gate'])
        require(gate['accepted_by_root'] is True and gate['offline_cells_complete'] == 10 and gate['offline_noise_metrics'] == ['elapsed_seconds', 'peak_rss_bytes'] and gate['all_selected_service_online_noises_frozen'] is True, 'global baseline/noise gate incomplete')
        noise = inv.json(bundle['noise']); freeze = inv.json(bundle['noise_freeze_receipt'])
        require(freeze['noise_sha256'] == digest(inv.file(bundle['noise'])) and freeze['accepted_by_root'] is True, 'external noise freeze binding')
        pairs = [[load_run(inv, collector, p[role]) for role in ('A', 'B')] for p in bundle['pairs']]
        require(len(pairs) == 3, 'three pairs required')
        ordered = [pairs[0][0], pairs[0][1], pairs[1][1], pairs[1][0], pairs[2][0], pairs[2][1]]
        variant = bundle.get('variant', 'B')
        require(variant in ('B', 'R'), 'candidate variant')
        require([v['run']['cell']['label'] for v in ordered] == ['A1', variant+'1', variant+'2', 'A2', 'A3', variant+'3'], 'pair order labels')
        if retained:
            attach_origins(inv, collector, maintenance, ordered, bundle)
        boundaries = [v['original'] if retained else dict(name=v['name'],run=v['run'],started_ns=int(v['run']['started']*1e9),finished_ns=int(v['run']['finished']*1e9)) for v in ordered]
        require([v['run']['cell']['label'] for v in boundaries] == ['A1',variant+'1',variant+'2','A2','A3',variant+'3'] and all(a['finished_ns'] <= b['started_ns'] for a,b in zip(boundaries,boundaries[1:])), 'actual original pair order')
        require(c[-1]['run']['finished']*1e9 < noise['created_ns'] <= freeze['frozen_ns'] < min(v['started_ns'] for v in boundaries), 'noise not frozen before original pairs')
        require(all(a['run']['finished'] <= b['run']['started'] for a, b in zip(ordered, ordered[1:])), 'pair overlap/order')
        require(all(v[0]['run']['source'] == c[0]['run']['source'] for v in pairs), 'baseline source drift')
        require(all(v[1]['run']['source'] == pairs[0][1]['run']['source'] and v[1]['run']['source'] != c[0]['run']['source'] for v in pairs), 'candidate source drift')
        inventory = common_inventory(inv, c[0]['name'], c[0]['run'])
        expected_groups = {(cell, variant) for cell in definition['required_original_cells'] for variant in definition['selected_candidate_variants']}
        groups = gate['original_pair_groups']
        require(len(groups) == len(expected_groups) and {(v['cell'],v['variant']) for v in groups} == expected_groups, 'all selected original pair cells/variants not covered')
        global_originals = [v for group in groups for v in original_pairs(inv, collector, maintenance, group, inventory)]
        for group in groups:
            for name in group['calibration']:
                original_cal = inv.json(name)
                finish = original_cal['finished_ns'] if group['kind']=='offline' else int(original_cal['finished']*1e9)
                require(finish < gate['frozen_ns'], 'global original calibration incomplete at freeze')
        require(global_originals and len({v['name'] for v in global_originals}) == len(global_originals), 'missing/reused global original pairs')
        require({v['name'] for v in boundaries} <= {v['name'] for v in global_originals}, 'selected originals absent from global gate')
        earliest_candidate = min(v['started_ns'] for v in global_originals if v['run']['cell']['source'] in ('B','R','B_unified','R_unified'))
        require(gate['frozen_ns'] < min(v['started_ns'] for v in global_originals), 'global calibration freeze after original pair timing')
        freeze_receipts = [inv.json(p) for p in gate['noise_freeze_receipts']]
        require(len(freeze_receipts) == len(definition['required_noise_cells']) and {v['noise_cell'] for v in freeze_receipts} == set(definition['required_noise_cells']), 'all selected noise cells not covered')
        require(bundle['noise_freeze_receipt'] in gate['noise_freeze_receipts'], 'selected noise absent from global freeze')
        for receipt in freeze_receipts:
            raw_noise = inv.json(receipt['noise'])
            require(receipt['accepted_by_root'] is True and digest(inv.file(receipt['noise'])) == receipt['noise_sha256'] and raw_noise['created_ns'] <= receipt['frozen_ns'] <= gate['frozen_ns'] < earliest_candidate, 'selected noise freeze after original candidate/drift')
        require(all(v[1]['run']['cell']['source'] == variant+'_unified' for v in pairs), 'candidate role drift')
        packets += ordered
        require(all(contract(v) == contract(c[0]) for v in packets), 'matched contract drift')
    require(len({v['name'] for v in packets}) == len(packets), 'reused run')
    for packet in packets:
        stderr = inv.local(inv.file(packet['name']).parent/'stderr.log').read_text()
        peaks = re.findall(r'Maximum resident set size \(kbytes\):\s*(\d+)', stderr)
        require(len(peaks) == 1, 'time-v HWM missing/duplicate')
        packet['hwm_bytes'] = int(peaks[0])*1024
    ledger = []
    for metric in definition['metrics']:
        if metric['id'] not in bundle['metrics']:
            continue
        try:
            extracted = [extract(v, definition, metric) for v in packets]
            values = [v[0] for v in extracted[:3]]; median = statistics.median(values)
            E = (max(values)-min(values))/median
            require(E > 0, 'zero spread requires independently frozen resolution evidence; unresolved')
            entry = dict(id=metric['id'], status='calibrated', values=values, E=E, support=[v[1] for v in extracted])
            if pairs:
                old = [v for v in noise['ledger'] if v['id'] == metric['id']]
                require(len(old) == 1 and old[0]['values'] == values and old[0]['E'] == E, 'noise values/selector drift')
                require(noise['definition_sha256'] == args.definition_sha256 and noise['calibration'] == bundle['calibration'] and noise['contract'] == contract(c[0]), 'noise cell/definition drift')
                effects = []
                for a, b in pairs:
                    av = extract(a, definition, metric)[0]; bv = extract(b, definition, metric)[0]
                    effects.append((av-bv)/av if metric['direction'] == 'lower' else (bv-av)/av)
                entry.update(status='evaluated', effects=effects, threshold=2*E,
                             material=all(v > 0 for v in effects) and statistics.median(effects) > 2*E,
                             repeated_regression=sum(v < -2*E for v in effects) >= 2)
            ledger.append(entry)
        except (Invalid, KeyError, TypeError, IndexError) as error:
            ledger.append(dict(id=metric['id'], status='unknown', reason=str(error)))
    require(set(bundle['metrics']) == {v['id'] for v in ledger} and ledger, 'unknown/missing metric definitions')
    print(json.dumps(dict(schema=1, status='artifact_diagnostic_only', created_ns=time.time_ns(),
        definition_sha256=args.definition_sha256, anchor_sha256=args.anchor_sha256,
        calibration=bundle['calibration'], contract=contract(c[0]), ledger=ledger,
        original_evidence=[dict(guard=v['name'], original=v['original']['name'], kind=v['original']['kind'], started_ns=v['original']['started_ns'], finished_ns=v['original']['finished_ns'], source=v['original']['run']['source'], common_inventory=v['original']['common_inventory']) for v in packets if 'original' in v],
        qualification=False, remaining_gates=definition['remaining_gates'],
        scope='Metric evidence only; scheduled eligible work/root horizons/storage/CRC-decode/landed product equality remain explicit independent gates.'), indent=2, allow_nan=False))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError, AssertionError) as error:
        print(json.dumps(dict(status='rejected', qualification=False, reason=str(error))), file=sys.stderr)
        sys.exit(1)
