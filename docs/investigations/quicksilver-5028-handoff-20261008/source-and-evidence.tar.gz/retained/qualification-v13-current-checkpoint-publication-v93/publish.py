from pathlib import Path
import json,subprocess,hashlib,time,os
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
block=(HERE/'current-block.md').read_text();oldblock=(BASE/'qualification-v13-current-checkpoint-publication-v91/current-block.md').read_text()
def api(path,label,method='GET',payload=None):
 argv=['gh','api','repos/snissn/gomap/'+path]
 if method!='GET':
  f=HERE/(label+'-request.json');f.write_text(json.dumps(payload)+'\n');argv+=['--method',method,'--input',str(f)]
 r=subprocess.run(argv,capture_output=True);(HERE/(label+'.json')).write_bytes(r.stdout);(HERE/(label+'.stderr')).write_bytes(r.stderr);assert r.returncode==0,(label,r.returncode)
 return json.loads(r.stdout)
results=[]
for n in [5028,5015,5016,5030]:
 label='issue-'+str(n);endpoint='issues/'+str(n);before=api(endpoint,label+'-before');body=before['body'];assert before['state']=='open' and body.startswith(oldblock)
 replacement=block+body[len(oldblock):];api(endpoint,label+'-patch','PATCH',{'body':replacement});after=api(endpoint,label+'-readback');assert after['state']=='open' and after['body']==replacement
 results.append(dict(target=after['html_url'],path=str(HERE/(label+'-readback.json')),sha256=hashlib.sha256((HERE/(label+'-readback.json')).read_bytes()).hexdigest(),verified=True))
for n,head in [(5037,'4ba7bfad3c29d176fe7686f14cfe49276a9b3d3a'),(5054,'a6b778ffeb9a401848d5eaf6d177547a5f21aef8')]:
 label='pr-'+str(n);endpoint='pulls/'+str(n);before=api(endpoint,label+'-before');assert before['state']=='open' and before['draft'] and before['head']['sha']==head
 body=before['body']
 if n==5037:
  body=body.replace('Current head `02c0242113931641480216cfd591a01660687549` includes canonical resolution of the main CI-inventory conflict; measured TreeDB and benchmark/capture/module identities equal R4b2a.', 'Current head `4ba7bfad3c29d176fe7686f14cfe49276a9b3d3a` additionally reuses only the proven-private common allocator prefix and copies the changed suffix; fork/rollback/materialization revoke ownership.')
  body=body.replace('All51 visible current-head CI checks pass, including required aggregates.', 'Exact Linux build, full freelist normal/race and six focused database normal/race tests pass. Hosted current-head CI is running.')
  body=body.replace('a conditional common-prefix freelist experiment is active, with test-first chunk-switch and retained-root controls; no performance acceptance is granted.', 'the source-reviewed/test-first common-prefix refinement reduces nearby-switch component bytes47–51%, objects80–86% and time30–33%. Representative frequency/performance and process-memory benefit remain unproven. Necessary #5116 owns the separately evidenced pre-existing external-manifest authority gap before affected matched qualification; no performance acceptance is granted.')
 api(endpoint,label+'-patch','PATCH',{'body':body});after=api(endpoint,label+'-readback');assert after['head']['sha']==head and after['draft'] and after['body']==body
 results.append(dict(target=after['html_url'],path=str(HERE/(label+'-readback.json')),sha256=hashlib.sha256((HERE/(label+'-readback.json')).read_bytes()).hexdigest(),verified=True))
label='parent-comment';endpoint='issues/comments/6023447234';api(endpoint,label+'-before');api(endpoint,label+'-patch','PATCH',{'body':block});after=api(endpoint,label+'-readback');assert after['body']==block
results.append(dict(target=after['html_url'],path=str(HERE/(label+'-readback.json')),sha256=hashlib.sha256((HERE/(label+'-readback.json')).read_bytes()).hexdigest(),verified=True))
receipt=dict(checkpoint_version=93,verified_live_outputs=results,held_excluded=[5004,5006],qualification=False,performance_accepted=False,finished_ns=time.time_ns());rp=HERE/'root-publication-receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'checkpoint_version':93,'verified_live_outputs':len(results),'receipt_sha256':hashlib.sha256(rp.read_bytes()).hexdigest()}),flush=True)
