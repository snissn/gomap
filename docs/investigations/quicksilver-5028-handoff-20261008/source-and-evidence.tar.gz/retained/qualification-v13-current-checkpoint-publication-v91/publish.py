from pathlib import Path
import json,subprocess,hashlib,time,os
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
block=(HERE/'current-block.md').read_text();oldblock=(BASE/'qualification-v13-current-checkpoint-publication-v90/current-block.md').read_text()
def api(path,label,method='GET',payload=None):
 argv=['gh','api','repos/snissn/gomap/'+path]
 if method!='GET':
  f=HERE/(label+'-request.json');f.write_text(json.dumps(payload)+'\n');argv+=['--method',method,'--input',str(f)]
 r=subprocess.run(argv,capture_output=True);(HERE/(label+'.json')).write_bytes(r.stdout);(HERE/(label+'.stderr')).write_bytes(r.stderr);assert r.returncode==0,(label,r.returncode)
 return json.loads(r.stdout)
results=[]
for n in [5028,5015,5016,5030]:
 label='issue-'+str(n);endpoint='issues/'+str(n);before=api(endpoint,label+'-before');body=before['body'];assert before['state']=='open' and body.startswith(oldblock)
 replacement=block+body[len(oldblock):];api(endpoint,label+'-patch','PATCH',{'body':replacement});after=api(endpoint,label+'-readback');assert after['state']=='open' and after['body']==replacement
 results.append(dict(target=after['html_url'],path=str(HERE/(label+'-readback.json')),sha256=hashlib.sha256((HERE/(label+'-readback.json')).read_bytes()).hexdigest(),verified=True))
for n,head in [(5037,'02c0242113931641480216cfd591a01660687549'),(5054,'a6b778ffeb9a401848d5eaf6d177547a5f21aef8')]:
 label='pr-'+str(n);endpoint='pulls/'+str(n);before=api(endpoint,label+'-before');assert before['state']=='open' and before['draft'] and before['head']['sha']==head
 body=before['body']
 if n==5037:
  old='Current-head MVCC raw-path, snapshot iterator, index-vacuum M0, read-snapshot and performance smoke gates have passed; required aggregates/review remain open.'
  assert old in body;body=body.replace(old,'All51 visible current-head CI checks pass, including required aggregates. Mature review, original product performance and final qualification remain open.')
  old='another evidence-led lifecycle inquiry is active.';assert old in body;body=body.replace(old,'a conditional common-prefix freelist experiment is active, with test-first chunk-switch and retained-root controls; no performance acceptance is granted.')
 api(endpoint,label+'-patch','PATCH',{'body':body});after=api(endpoint,label+'-readback');assert after['head']['sha']==head and after['draft'] and after['body']==body
 results.append(dict(target=after['html_url'],path=str(HERE/(label+'-readback.json')),sha256=hashlib.sha256((HERE/(label+'-readback.json')).read_bytes()).hexdigest(),verified=True))
label='parent-comment';endpoint='issues/comments/6023447234';api(endpoint,label+'-before');api(endpoint,label+'-patch','PATCH',{'body':block});after=api(endpoint,label+'-readback');assert after['body']==block
results.append(dict(target=after['html_url'],path=str(HERE/(label+'-readback.json')),sha256=hashlib.sha256((HERE/(label+'-readback.json')).read_bytes()).hexdigest(),verified=True))
receipt=dict(checkpoint_version=91,verified_live_outputs=results,held_excluded=[5004,5006],qualification=False,performance_accepted=False,finished_ns=time.time_ns());rp=HERE/'root-publication-receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n')
sp=BASE/'state.json';raw=sp.read_bytes();state=json.loads(raw);assert state['checkpoint_version']==90 and state['native_active'] is None
state['checkpoint_version']=91;state['qualification_v13_current']['stage']='current-R-51-CI-success-common-prefix-test-first-experiment-B-authority-adapter-preparation-no-product-qualification'
state['qualification_v13_current']['publication_v91']={'path':str(rp),'sha256':hashlib.sha256(rp.read_bytes()).hexdigest()}
f=BASE/'qualification-v13-current-head-CI-followup-v91/pr-5037-CI-1791472875576972000.json';d=json.loads(f.read_bytes());assert d['headRefOid']=='02c0242113931641480216cfd591a01660687549' and len(d['statusCheckRollup'])==51
state['nodes']['5015']['latest_current_head_ci']={'head':d['headRefOid'],'all51_success':True,'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'CI_only_no_merge_or_performance_acceptance':True}
state['nodes']['5015']['next_action']='Test-first existing-private-proof common-prefix experiment; accept exact source/affected checks/diagnostic opportunity before new qualified comparison. Original product gates remain open.'
state['qualification_v13_current']['local_shipping_cleanup_v91']=[]
for folder in ['qualification-v13-released-local-source-shipping-cleanup-v1','qualification-v13-released-v9-local-source-shipping-cleanup-v1']:
 f=BASE/folder/'cleanup-result.json';x=json.loads(f.read_bytes());state['qualification_v13_current']['local_shipping_cleanup_v91'].append({'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'logical_deleted_bytes':x['logical_deleted_bytes'],'all_raw_evidence_retained':True})
state['local_disjoint_active_roles_v91']=[{'agent':'/root/r5015_producer_history_source_inquiry','role':'R common-prefix bounded implementation','base':'02c0242113931641480216cfd591a01660687549'},{'agent':'/root/v12_final_artifact_source_preparation','role':'B private read-only diagnostic artifact preparation only'}]
tmp=HERE/'state.pending'
with tmp.open('x') as f:json.dump(state,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
assert sp.read_bytes()==raw;os.replace(tmp,sp)
print(json.dumps({'checkpoint_version':91,'verified_live_outputs':len(results),'receipt_sha256':hashlib.sha256(rp.read_bytes()).hexdigest()}),flush=True)
