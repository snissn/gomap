"""Exact reuse or exclusive transfer; original IO owns every native receipt."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import time

MAX_FILES = 32
MAX_PLAN_BYTES = 16384

PROBE = '''import hashlib,json,os,pathlib,stat,sys
root=pathlib.Path(sys.argv[1]);request=pathlib.Path(sys.argv[2])
assert root.is_absolute() and root.resolve(strict=True)==root and root.is_dir() and not root.is_symlink()
assert request.is_absolute() and request.resolve(strict=True)==request and request.is_file() and not request.is_symlink()
assert request.is_relative_to(root)
data=request.read_bytes();assert len(data)<=16384 and hashlib.sha256(data).hexdigest()==sys.argv[3]
plan=json.loads(data);assert plan['root']==str(root) and plan['overwrite_allowed'] is False
expected=plan['expected'];assert 0<len(expected)<=32
observed={}
for name,identity in expected.items():
 rel=pathlib.PurePosixPath(name)
 assert str(rel)==name and not rel.is_absolute() and rel.parts and all(x not in ('.','..','.git') for x in rel.parts)
 path=root/name;parent=path.parent
 while parent!=root:
  if os.path.lexists(parent):assert parent.resolve(strict=True)==parent and parent.is_dir() and not parent.is_symlink()
  parent=parent.parent
 if os.path.lexists(path):
  assert path.resolve(strict=True)==path and stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink(),name
  assert path.stat().st_size==identity['bytes'],name
  digest=hashlib.sha256()
  with path.open('rb') as stream:
   for chunk in iter(lambda:stream.read(1048576),b''):digest.update(chunk)
  actual=dict(bytes=path.stat().st_size,sha256=digest.hexdigest());assert actual==identity,name
  observed[name]=dict(state='EXACT_EXISTING',identity=actual)
 else:observed[name]=dict(state='MISSING',identity=identity)
print(json.dumps(dict(status='EXACT_STAGE_PROBE_COMPLETE',observed=observed)),flush=True)
'''


def _probe(io, request_name, request_sha, expected, label):
    argv=['python3','-B','-c',PROBE,str(io.ROOT),str(Path(io.ROOT)/request_name),request_sha]
    result=json.loads(io.native(argv,label,timeout=180))
    assert set(result)=={'status','observed'} and result['status']=='EXACT_STAGE_PROBE_COMPLETE'
    observed=result['observed'];assert isinstance(observed,dict) and set(observed)==set(expected)
    for name,row in observed.items():
        assert set(row)=={'state','identity'} and row['state'] in ('EXACT_EXISTING','MISSING')
        assert row['identity']==expected[name]
    return observed


def exact_stage(io, sources, label):
    """Verify all requested paths, reuse exact bytes, put only missing paths."""
    assert isinstance(sources,dict) and 0<len(sources)<=MAX_FILES
    assert isinstance(label,str) and label and len(label)<=160 and all(c.isalnum() or c in '-_' for c in label)
    expected={}
    for name,path in sources.items():
        assert isinstance(name,str) and len(name)<=512
        rel=PurePosixPath(name)
        assert str(rel)==name and not rel.is_absolute() and rel.parts and all(x not in ('.','..','.git') for x in rel.parts)
        local=Path(path);assert local.is_absolute() and local.resolve(strict=True)==local and local.is_file() and not local.is_symlink()
        expected[name]=io.identity(local)
    plan=dict(root=str(io.ROOT),expected=expected,overwrite_allowed=False,created_ns=time.time_ns())
    assert len(json.dumps(plan,indent=2).encode())+1<=MAX_PLAN_BYTES
    plan_name=label+'-exact-stage-plan.json'
    io.save(plan_name,plan)
    request=Path(io.HERE)/plan_name
    base=Path(io.HERE).parent
    assert base.is_absolute() and base.resolve(strict=True)==base
    assert request.resolve(strict=True)==request and request.is_file() and not request.is_symlink()
    request_name=request.relative_to(base).as_posix();request_identity=io.identity(request)
    assert request_name not in expected and request_identity['bytes']<=MAX_PLAN_BYTES
    plan_transfer=io.put({request_name:request},label+'-exact-stage-plan-transfer')
    assert plan_transfer['status']=='EXCLUSIVE_TRANSFER_COMPLETE' and plan_transfer['received']=={request_name:request_identity}
    before=_probe(io,request_name,request_identity['sha256'],expected,label+'-exact-stage-preflight')
    missing={name:sources[name] for name,row in before.items() if row['state']=='MISSING'}
    reused={name:expected[name] for name,row in before.items() if row['state']=='EXACT_EXISTING'}
    transfer=None
    if missing:
        transfer=io.put(missing,label+'-exact-stage-missing-transfer')
        assert transfer['status']=='EXCLUSIVE_TRANSFER_COMPLETE' and transfer['received']=={name:expected[name] for name in missing}
    after=_probe(io,request_name,request_identity['sha256'],expected,label+'-exact-stage-readback')
    assert all(row['state']=='EXACT_EXISTING' for row in after.values())
    assert io.identity(request)==request_identity
    assert all(io.identity(path)==expected[name] for name,path in sources.items())
    result=dict(status='EXACT_STAGE_COMPLETE',expected=expected,reused=reused,transferred={name:expected[name] for name in missing},source_plan=dict(path=str(request),native_path=str(Path(io.ROOT)/request_name),**request_identity),plan_transfer=plan_transfer,missing_transfer=transfer,finished_ns=time.time_ns())
    io.save(label+'-exact-stage-result.json',result)
    return result
