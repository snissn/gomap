"""Finite exclusive copies and reversible staging-boundary adaptation only."""
import ast,difflib,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
UTILITY=HERE/'exact_stage_v12_v1.py'
IO=BASE/'qualification-v9-selected-source-preparation-v1/root_native_io.py'
PIN='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
assert hashlib.sha256(IO.read_bytes()).hexdigest()==PIN
names={
'qualification-v12-later-execution-preparation-v3':['root-run-full-R-and-global54-v12-v1.py','root-run-physical34-preservation-v12-v1.py','root-run-original-pairs-v12-v1.py'],
'qualification-v12-final-artifact-preparation-v1':['root-run-final-raw-and-metadata-v12-v1.py','root-run-final-content-and-evaluations-v12-v1.py']}
def ident(p):
 d=p.read_bytes();return dict(path=str(p),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
loader='''def load_exact_stage():
    path=BASE/'qualification-v12-exact-stage-preparation-v1/exact_stage_v12_v1.py'
    assert path.resolve(strict=True)==path and path.is_file() and not path.is_symlink()
    data=path.read_bytes()
    assert hashlib.sha256(data).hexdigest()=='UTILITY_SHA'
    module=types.ModuleType('root_exact_stage_v12');module.__file__=str(path)
    exec(compile(data,str(path),'exec'),module.__dict__)
    return module


'''.replace('UTILITY_SHA',ident(UTILITY)['sha256'])
rows=[]
for folder,files in names.items():
 for name in files:
  old=BASE/folder/name;new=old.with_name(name.replace('-v12-v1.py','-v12-v2.py'))
  text=old.read_text();assert 'load_exact_stage' not in text
  index=text.index('def main(') if 'def main(' in text else text.index('if __name__')
  changed=text[:index]+loader+text[index:]
  lines=changed.splitlines(keepends=True)
  matches=[i for i,line in enumerate(lines) if "exec(compile(ip.read_bytes()" in line and 'io.__dict__' in line]
  assert len(matches)==1
  lines.insert(matches[0]+1,'    stage=load_exact_stage()\n')
  changed=''.join(lines).replace('io.put(','stage.exact_stage(io,')
  assert changed.count('stage.exact_stage(io,')==text.count('io.put(')>0
  reverse=changed.replace(loader,'',1).replace('    stage=load_exact_stage()\n','',1).replace('stage.exact_stage(io,','io.put(')
  assert reverse==text
  assert ast.dump(ast.parse(reverse),include_attributes=False)==ast.dump(ast.parse(text),include_attributes=False)
  compile(changed,str(new),'exec')
  with new.open('x') as out:out.write(changed)
  diff=''.join(difflib.unified_diff(text.splitlines(True),changed.splitlines(True),fromfile=str(old),tofile=str(new)))
  diffpath=HERE/(new.name+'.diff')
  with diffpath.open('x') as out:out.write(diff)
  rows.append(dict(input=ident(old),output=ident(new),diff=ident(diffpath),put_boundaries=text.count('io.put('),exact_text_and_AST_reversal=True))
manifest=dict(source_only=True,accepted=False,collection_authority=False,runtime_authority=False,qualification_acceptance=False,merge_authority=False,original_io=ident(IO),utility=ident(UTILITY),launchers=rows)
with (HERE/'source-manifest.json').open('x') as out:json.dump(manifest,out,indent=2);out.write('\n')
print(json.dumps(dict(utility=ident(UTILITY),copies=len(rows),put_boundaries=sum(r['put_boundaries'] for r in rows))))
