# V12 exact staging source preparation

Source only. Accepted false; collection, runtime, performance, qualification, candidate-pair and merge authority false. Independent root review/adoption is required. No campaign module, frozen IO module, launcher main, native/SSH/network command, database, build, benchmark, GitHub edit, state mutation, or cleanup of existing artifacts was executed.

## Concrete change

`exact_stage_v12_v1.py` accepts `(io, sources, label)`. It verifies canonical local source bytes, creates an exclusive source plan for every requested file, and transfers that bounded plan via unchanged original `io.put`. The read-only native probe receives only root, plan path and SHA references; the probe argv contains no requested source map or payload. The original `io.put` streams plan and missing payloads via its existing stdin tar transport.

The probe requires a canonical root and plan, no symlink parents or targets, regular existing files, exact byte counts and SHA256. Every requested path must appear once in a complete probe response. Exact existing files are recorded as reused; only missing source paths are passed to original `io.put`. Mismatched existing files fail before any requested source transfer. Original exclusive put prevents overwrite if a missing file appears before transfer. A second read-only probe verifies every path after transfer, and incomplete transfer or probe receipts fail before any exact-stage completion result.

The source plan is an exclusive JSON file under the original IO `HERE`, with its root-relative path staged once. Maximum 32 requested files, 512 characters per relative name, and 16,384 plan bytes; maps beyond those bounds fail. The fixed probe is below 8KiB. Unchanged original `io.put` embeds only its finite transfer identity map in its receiver code, while payloads use stdin tar; the same 32-file/16KiB bounds limit that original receiver map. No inventory traversal is performed. This covers the affected launchers' finite source sets (maximum ten requested files).

Each original staging label is supplied unchanged to the utility. New transport-only receipt labels add `-exact-stage-plan-transfer`, `-exact-stage-preflight`, `-exact-stage-missing-transfer`, and `-exact-stage-readback`. Original IO saves and transfers remain unchanged; original native helper command labels/argv/receipts remain unchanged. Reused source files generate no duplicate payload transfer; a small plan transfer still occurs to retain complete byte-bound source admission. Existing files or existing receipt names are never overwritten. No retry is introduced.

## Minimal launcher copies and admission requirements

Five `-v12-v2.py` copies live beside their original `-v12-v1.py` launchers, preserving `HERE`. Each adds one pinned utility loader, one module binding after the existing frozen IO load, and substitutes 11 total `io.put` calls with explicit `stage.exact_stage(io, ...)`. No native helper, science argv, counts, matrix, source inheritance, ordering or evaluator changed. Full original B then R final evaluation remains ahead of separate strict supplemental evaluation.

Actual invocation requests must reference the actual v2 launcher path and SHA. Existing request/adoption artifacts are not revised here. Pair and both final launchers already require `helper_source_acceptance` matching the actual current helper; root must create/review the new accepted source admission for the v2 helper before those launchers can run. Full-R/physical requests also bind their current launcher bytes. The pinned utility needs independent source review/adoption and must remain at its exact local packet path; it is loaded locally only, and is not imported as a native campaign module. All existing native helper and native helper adoption pins remain unchanged. Unknown future results, timestamps and runtime receipts are not supplied.

## Verification

Twenty isolated local fake-IO cases passed: all missing, mixed reuse/transfer, full reuse, same-size SHA mismatch, target/parent/local-source/root symlink, unsafe relative path, target directory, file-count bound, partial plan/transfer/probe responses, wrong status/identity, extra probe path, missing transferred file, and corrupt final readback. Tests execute only the new transport utility and its read-only probe against disposable local test paths; no campaign modules or original frozen IO code execute.

All five copies compile as source. Removing only the loader/binding and reversing explicit staging substitutions reproduces every original file byte-for-byte and the entire original module AST. Original v1 launchers and frozen IO SHA256 remain unchanged. Exact diffs, full byte/SHA identities and source-only check results are retained. `prepare_source_only.py` is an exclusive preparation record, not a runtime harness; rerunning it fails on existing output paths. No future accepted source or runtime authority is fabricated.

## Exact source identities

| Source | SHA256 |
|---|---|
| qualification-v9-selected-source-preparation-v1/root_native_io.py | fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1 |
| qualification-v12-exact-stage-preparation-v1/exact_stage_v12_v1.py | 27515da907ab4bf3bdcb5fc56773364189b70159317521c2e22e5e4ce068dd03 |
| qualification-v12-later-execution-preparation-v3/root-run-full-R-and-global54-v12-v1.py | b9378812db24157d00d3acf98717e0de2071d0fa4f89bff42636fd1647935e65 |
| qualification-v12-later-execution-preparation-v3/root-run-physical34-preservation-v12-v1.py | 5d9481de26ce2843e5ff53ca73f0417db56c7096f7637baf9410607d4068080d |
| qualification-v12-later-execution-preparation-v3/root-run-original-pairs-v12-v1.py | 47c4358a662854b60ca2931cd63f4569636a25eaf0649533c3d3b5952f1cd6ed |
| qualification-v12-final-artifact-preparation-v1/root-run-final-raw-and-metadata-v12-v1.py | 54a4b3a33d828d39a48895ac649e973d9a3e58286e97757d9486bb5621c56ae5 |
| qualification-v12-final-artifact-preparation-v1/root-run-final-content-and-evaluations-v12-v1.py | 29dadb26b237e427233066d650704f4f9fcbfb25115ec7e419e89fd6480f8f09 |
| qualification-v12-later-execution-preparation-v3/root-run-full-R-and-global54-v12-v2.py | f2650a2985e8a15b9efdb4f016c5630ef70fb25a33050c44636fb8ceee25132e |
| qualification-v12-later-execution-preparation-v3/root-run-physical34-preservation-v12-v2.py | 08f3609dfd94177aa80c555f42b90d9bb2033246467d9c4ab2c65ff8fd6efeea |
| qualification-v12-later-execution-preparation-v3/root-run-original-pairs-v12-v2.py | be7fd6aadd59655a8138d176a3a3227c0ecb8f43107c95d8eccbf0cf9b6039db |
| qualification-v12-final-artifact-preparation-v1/root-run-final-raw-and-metadata-v12-v2.py | 1c9d04ee4f7a770f360ef401c7c00529279277861c913bee1a516cc0483cc8f0 |
| qualification-v12-final-artifact-preparation-v1/root-run-final-content-and-evaluations-v12-v2.py | c6980abcaad2b393fd5e139a37384b2f5eafc865cb7588afa3267a937da7aba7 |
