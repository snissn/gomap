"""Isolated local fakes only: no frozen IO/campaign/native/SSH execution."""
import ast,contextlib,hashlib,io,json,os,sys,tempfile,types
from pathlib import Path
HERE=Path(__file__).resolve().parent
source=(HERE/'exact_stage_v12_v1.py').read_bytes()
ast.parse(source)
m=types.ModuleType('isolated_exact_stage');exec(compile(source,'isolated_exact_stage','exec'),m.__dict__)
class FakeIO:
 def __init__(self,base,mode=None):
  self.HERE=base/'local'/'frozen-io';self.HERE.mkdir(parents=True)
  self.ROOT=str(base/'remote');Path(self.ROOT).mkdir()
  self.mode=mode;self.put_calls=[];self.native_calls=[];self.saved={}
 def identity(self,path):
  data=Path(path).read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 def save(self,name,value):
  with (self.HERE/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
  self.saved[name]=value
 def put(self,sources,label):
  self.put_calls.append(dict(sources=sources,label=label));received={}
  for name,path in sources.items():
   target=Path(self.ROOT)/name
   assert not os.path.lexists(target)
   target.parent.mkdir(parents=True,exist_ok=True)
   with target.open('xb') as out:out.write(Path(path).read_bytes())
   received[name]=self.identity(target)
  result=dict(status='EXCLUSIVE_TRANSFER_COMPLETE',received=received,finished_ns=1)
  if self.mode=='partial-plan' and label.endswith('plan-transfer'):result['received']={}
  if self.mode=='partial-transfer' and label.endswith('missing-transfer'):result['received']={}
  if self.mode=='wrong-transfer-status' and label.endswith('missing-transfer'):result['status']='FAILED'
  if self.mode=='missing-after-transfer' and label.endswith('missing-transfer'):
   for name in sources:(Path(self.ROOT)/name).unlink()
  return result
 def native(self,argv,label,timeout):
  assert argv[:3]==['python3','-B','-c'] and argv[3]==m.PROBE and len(argv)==7 and timeout==180
  assert len(argv[3])<8192 and len(argv[5])<1024 and len(argv[6])==64
  self.native_calls.append(label)
  saved_argv=sys.argv
  stream=io.StringIO()
  try:
   sys.argv=['-c',*argv[4:]]
   with contextlib.redirect_stdout(stream):exec(compile(argv[3],'isolated_readonly_probe','exec'),{})
  finally:sys.argv=saved_argv
  result=json.loads(stream.getvalue())
  if self.mode=='partial-probe':result['observed']={}
  if self.mode=='forged-identity':next(iter(result['observed'].values()))['identity']['sha256']='0'*64
  if self.mode=='wrong-probe-status':result['status']='FAILED'
  if self.mode=='extra-probe-path':result['observed']['unexpected']={}
  if self.mode=='corrupt-readback' and label.endswith('readback'):result['observed']={}
  return json.dumps(result).encode()

def case(name,setup=None,mode=None,deny=False):
 with tempfile.TemporaryDirectory(prefix='source_only_exact_stage_') as raw:
  base=Path(raw).resolve();fake=FakeIO(base,mode)
  a=base/'source-a';b=base/'source-b';a.write_bytes(b'alpha');b.write_bytes(b'beta')
  sources={'packet/a.py':a,'packet/b.json':b}
  if setup:setup(fake,base,sources)
  try:result=m.exact_stage(fake,sources,'finite-case')
  except (AssertionError,ValueError,FileNotFoundError,NotADirectoryError):
   assert deny,name
   assert not any(k.endswith('-exact-stage-result.json') for k in fake.saved),name
   return dict(name=name,status='PASS_DENIED',puts=len(fake.put_calls),probes=len(fake.native_calls))
  assert not deny,name
  assert result['status']=='EXACT_STAGE_COMPLETE' and set(result['reused'])|set(result['transferred'])==set(sources)
  assert not set(result['reused'])&set(result['transferred'])
  assert fake.put_calls[0]['label'].endswith('plan-transfer') and len(fake.put_calls[0]['sources'])==1
  missing_calls=[row for row in fake.put_calls if row['label'].endswith('missing-transfer')]
  assert len(missing_calls)==bool(result['transferred'])
  if missing_calls:assert set(missing_calls[0]['sources'])==set(result['transferred'])
  assert len(fake.native_calls)==2
  return dict(name=name,status='PASS',reused=len(result['reused']),transferred=len(result['transferred']))
def existing(fake,base,sources,which=('packet/a.py',)):
 for name in which:
  target=Path(fake.ROOT)/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(sources[name].read_bytes())
def mismatch(fake,base,sources):
 existing(fake,base,sources);(Path(fake.ROOT)/'packet/a.py').write_bytes(b'omega')
def symlink_target(fake,base,sources):
 target=Path(fake.ROOT)/'packet/a.py';target.parent.mkdir();target.symlink_to(sources['packet/a.py'])
def symlink_parent(fake,base,sources):
 other=base/'other';other.mkdir();(Path(fake.ROOT)/'packet').symlink_to(other,target_is_directory=True)
def local_symlink(fake,base,sources):
 p=base/'link';p.symlink_to(sources['packet/a.py']);sources['packet/a.py']=p
def traversal(fake,base,sources):sources['../escape']=sources.pop('packet/a.py')
def directory_target(fake,base,sources):(Path(fake.ROOT)/'packet/a.py').mkdir(parents=True)
def too_many(fake,base,sources):
 p=sources['packet/a.py'];sources.clear();sources.update({f'packet/{i}':p for i in range(33)})
def root_symlink(fake,base,sources):
 link=base/'remote-link';link.symlink_to(fake.ROOT,target_is_directory=True);fake.ROOT=str(link)
rows=[case('all-missing'),case('mixed-existing-missing',existing),case('all-exact-reused',lambda f,b,s:existing(f,b,s,tuple(s))),case('same-size-hash-mismatch',mismatch,deny=True),case('target-symlink',symlink_target,deny=True),case('parent-symlink',symlink_parent,deny=True),case('local-source-symlink',local_symlink,deny=True),case('unsafe-relative-path',traversal,deny=True),case('target-directory',directory_target,deny=True),case('bound-33-files',too_many,deny=True),case('root-symlink',root_symlink,deny=True)]
for mode in ('partial-plan','partial-transfer','wrong-transfer-status','missing-after-transfer','partial-probe','forged-identity','wrong-probe-status','extra-probe-path','corrupt-readback'):
 rows.append(case(mode,mode=mode,deny=True))
manifest=json.loads((HERE/'source-manifest.json').read_bytes())
for row in [manifest['original_io'],*[r['input'] for r in manifest['launchers']]]:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
for row in manifest['launchers']:
 text=Path(row['output']['path']).read_text();compile(text,row['output']['path'],'exec')
 tree=ast.parse(text);loader=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='load_exact_stage')
 start=loader.lineno-1;end=loader.end_lineno
 lines=text.splitlines(keepends=True);del lines[start:end+2]
 reverse=''.join(lines).replace('    stage=load_exact_stage()\n','',1).replace('stage.exact_stage(io,','io.put(')
 original=Path(row['input']['path']).read_text()
 assert reverse==original and ast.dump(ast.parse(reverse))==ast.dump(ast.parse(original))
result=dict(source_only=True,accepted=False,runtime_authority=False,qualification_acceptance=False,merge_authority=False,status='SOURCE_ONLY_ISOLATED_CHECKS_PASS',cases=rows,case_count=len(rows),originals_unchanged=True,five_exact_source_and_AST_reversals=True,no_campaign_modules_executed=True,no_native_or_network=True)
with (HERE/'static-check-results.json').open('x') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps(dict(status=result['status'],case_count=len(rows),originals_unchanged=True,exact_reversals=5)))
