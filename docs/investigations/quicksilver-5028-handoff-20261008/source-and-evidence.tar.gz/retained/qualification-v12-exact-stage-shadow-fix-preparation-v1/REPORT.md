# V12 final content staging shadow fix

Source only. Accepted false; collection, runtime, performance, qualification, candidate-pair and merge authority false. Independent root/reviewer adoption remains required.

The v2 launcher used `stage` for both the exact-staging module and the inherited ten-file source tuple, causing `AttributeError` before content staging. The new adjacent `root-run-final-content-and-evaluations-v12-v3.py` uses `exact_stage_module` for the module binding and all three staging calls. The inherited `stage` tuple and its comprehension remain byte-identical. These four name changes are the complete source diff; all helper pins, requests, source tuple ordering, labels, native commands, science, gates, original B/R evaluation order, separate strict supplemental evaluation, and other failure checks are unchanged.

The isolated regression check executes only AST-extracted local assignments and the first transport call with synthetic paths and a fake module. It reproduces the old tuple `AttributeError`, then verifies that the v3 module survives the original tuple assignment and receives the exact ten source paths and original label. Static checks verify all three calls use the distinct module, the module has exactly one assignment, the copy compiles, and reversing the four identifier substitutions restores the complete original text and AST. No campaign module, utility module, frozen IO module, launcher main, native/network command, database, state, build or GitHub action executes. The earlier twenty transport checks need no repetition because utility/transport behavior is unchanged.

V1/V2 launchers, old packet files, utility, frozen IO and the other four v2 copies remain immutable; every file in the old exact-stage packet manifest was rechecked against its original byte count and SHA256. The utility remains `27515da907ab4bf3bdcb5fc56773364189b70159317521c2e22e5e4ce068dd03`. Root's actual content/evaluation invocation request must bind the v3 helper path and SHA, and `helper_source_acceptance` must admit that same new v3 helper. No accepted admission or future runtime receipt is created here.

Input v2: `c6980abcaad2b393fd5e139a37384b2f5eafc865cb7588afa3267a937da7aba7`.

Output v3: `46b7f235b2af8bc0240fc064263cbf7337e2be21187c99c1d84975825fe49e09` (13,721 bytes).

Exact input/output identities, diff and source-only checks are recorded in `source-manifest.json` and `static-check-results.json`. Preparation script output paths are exclusive; it is a source-only preparation record, not a runtime launcher.
