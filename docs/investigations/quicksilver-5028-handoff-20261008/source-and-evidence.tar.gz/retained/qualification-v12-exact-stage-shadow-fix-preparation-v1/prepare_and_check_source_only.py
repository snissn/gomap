"""Bounded source copy, reversible diff, and isolated binding regression check."""
import ast,difflib,hashlib,json,types
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
OLD=BASE/'qualification-v12-final-artifact-preparation-v1/root-run-final-content-and-evaluations-v12-v2.py'
NEW=OLD.with_name('root-run-final-content-and-evaluations-v12-v3.py')
UTILITY=BASE/'qualification-v12-exact-stage-preparation-v1/exact_stage_v12_v1.py'
IO=BASE/'qualification-v9-selected-source-preparation-v1/root_native_io.py'
def identity(p):
 data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
assert identity(OLD)['sha256']=='c6980abcaad2b393fd5e139a37384b2f5eafc865cb7588afa3267a937da7aba7'
assert identity(UTILITY)['sha256']=='27515da907ab4bf3bdcb5fc56773364189b70159317521c2e22e5e4ce068dd03'
assert identity(IO)['sha256']=='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
old=OLD.read_text()
assert old.count('    stage=load_exact_stage()\n')==1 and old.count('stage.exact_stage(io,')==3
new=old.replace('    stage=load_exact_stage()\n','    exact_stage_module=load_exact_stage()\n',1).replace('stage.exact_stage(io,','exact_stage_module.exact_stage(io,')
assert new.replace('    exact_stage_module=load_exact_stage()\n','    stage=load_exact_stage()\n',1).replace('exact_stage_module.exact_stage(io,','stage.exact_stage(io,')==old
compile(new,str(NEW),'exec')
oldtree=ast.parse(old);newtree=ast.parse(new)
# Reverse only the loader assignment target and exact_stage attribute receiver.
class ReverseBoundary(ast.NodeTransformer):
 def visit_Name(self,node):
  if node.id=='exact_stage_module':node.id='stage'
  return node
assert ast.dump(ReverseBoundary().visit(ast.parse(new)),include_attributes=False)==ast.dump(oldtree,include_attributes=False)
# Extract only the two local assignments and first staging call; execute no campaign code.
def boundary(tree,module_name):
 assigns=[node for node in ast.walk(tree) if isinstance(node,ast.Assign)]
 load=[node for node in assigns if any(isinstance(t,ast.Name) and t.id==module_name for t in node.targets) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='load_exact_stage']
 assert len(load)==1 and isinstance(load[0].value,ast.Call) and isinstance(load[0].value.func,ast.Name) and load[0].value.func.id=='load_exact_stage'
 tuples=[node for node in assigns if any(isinstance(t,ast.Name) and t.id=='stage' for t in node.targets) and isinstance(node.value,ast.Tuple)]
 assert len(tuples)==1
 calls=[node for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='exact_stage']
 assert len(calls)==3 and all(isinstance(n.func.value,ast.Name) and n.func.value.id==module_name for n in calls)
 calls.sort(key=lambda n:n.lineno)
 assert load[0].lineno<tuples[0].lineno<calls[0].lineno
 return ast.fix_missing_locations(ast.Module(body=[load[0],tuples[0],ast.Expr(value=calls[0])],type_ignores=[]))
record=[]
module=types.ModuleType('isolated_exact_stage_module')
def fake_stage(io,sources,label):record.append(dict(io=io,sources=sources,label=label))
module.exact_stage=fake_stage
local_base=Path('/isolated/source-only')
def environment():
 env=dict(BASE=local_base,load_exact_stage=lambda:module,io=object(),metadata_label='isolated-metadata',RECEIPTS=local_base/'receipts',streams={channel:local_base/'receipts'/('isolated-'+channel+'.txt') for channel in ('stdout','stderr')})
 for name in ('CONTENT','EVALUATION','content_adoption','evaluation_adoption','outcome_path','result_path','content_request_path'):env[name]=local_base/(name+'.source')
 return env
oldenv=environment()
try:exec(compile(boundary(oldtree,'stage'),'isolated-v2-binding-only','exec'),oldenv)
except AttributeError as error:assert "'tuple' object has no attribute 'exact_stage'" in str(error)
else:raise AssertionError('old regression was not reproduced')
assert not record
newenv=environment()
exec(compile(boundary(newtree,'exact_stage_module'),'isolated-v3-binding-only','exec'),newenv)
assert newenv['exact_stage_module'] is module and isinstance(newenv['exact_stage_module'],types.ModuleType)
assert isinstance(newenv['stage'],tuple) and len(newenv['stage'])==10
assert len(record)==1 and len(record[0]['sources'])==10
assert tuple(record[0]['sources'].values())==newenv['stage']
assert record[0]['label']=='v12-root-final-content-inputs-and-reviewed-evaluators-exclusive-stage-v1'
with NEW.open('x') as out:out.write(new)
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(OLD),tofile=str(NEW)))
with (HERE/'content-evaluations-v2-to-v3.diff').open('x') as out:out.write(diff)
checks=dict(source_only=True,accepted=False,runtime_authority=False,qualification_acceptance=False,merge_authority=False,old_tuple_shadow_AttributeError_reproduced=True,new_module_binding_survives_original_tuple_assignment=True,original_ten_source_tuple_preserved=True,all_three_calls_use_distinct_module_binding=True,exact_text_and_AST_reversal=True,source_compiles=True,no_campaign_module_or_main_executed=True,no_native_or_network=True)
with (HERE/'static-check-results.json').open('x') as out:json.dump(checks,out,indent=2);out.write('\n')
manifest=dict(source_only=True,accepted=False,collection_authority=False,runtime_authority=False,qualification_acceptance=False,performance_acceptance=False,candidate_pair_authority=False,merge_authority=False,inputs=[identity(OLD),identity(UTILITY),identity(IO)],output=identity(NEW),diff=identity(HERE/'content-evaluations-v2-to-v3.diff'),checks=identity(HERE/'static-check-results.json'))
assert identity(OLD)['sha256']=='c6980abcaad2b393fd5e139a37384b2f5eafc865cb7588afa3267a937da7aba7'
with (HERE/'source-manifest.json').open('x') as out:json.dump(manifest,out,indent=2);out.write('\n')
print(json.dumps(dict(output=manifest['output'],checks=checks),indent=2))
