# B root/leaf manifest divergence: read-only source inquiry

Ordinary publication permits a newly registered raw leaf dependency to be published with inherited, older manifest authority: resource capture precedes pending manifest staging and post-publication persistence. This ordering predates B certified prune. Actual ReadOnly selected its pinned manifest correctly. The exact first offending ACK/producer and root/page/offset remain unobserved; the observed target cannot yet be assigned conclusively to ordering versus registration filtering.

All numerical/performance/qualification/product/change/merge acceptance flags false; held #5004/PR #5006 excluded. No native/runtime/tests/build/network/Git mutations/source/state edits. Exact frozen/current and comparison bindings are in source-bindings.json.

## Genuine evidence

Raw stdout SHA a30ceba84dd2cf8a2e01436fc72a920a9cb8730a8cf6cb6edb1b8b57eaaed43d (16530B). Let D = JSON-pointer prefix `/interpretation/raw_diagnostic/authority_discriminator`.

- `/test/rc=1`; `/interpretation/named_runs=1`, named_passes0, named_skippedfalse, json_record_count1, stats_validfalse. Census error `leaf generation plan: missing generation for leaf file 2139095277`; interpreted numerical census fields null/UNKNOWN.
- D`/selected_slot=0`, `/slot_commit_seq=[128,127]`. Both viable roots UserRootPageID9624/SystemRootPageID5060, AppliedCommandLSN/MaxEntryRevision12880; only commit128 visible.
- D`/loaded_leaf_manifest`: version2, manifest_revision21, current_generation_id150, next_generation_id151, target_mapping_presentfalse, target_generation_records[]. For both i=0,1 D`/slots/i/outer_leaf_manifest_tokens/0` binds `manifest.durable.0000000000000015.json`, generation21, frontier.Bytes31591, actual_read_sha256=digest_sha256 `248ca31a17674c103e66c8fdd3bcf34c3a0e97ffe505e4453bf39a61624dfce2`. Digest/revision checks pass; manifest_target lacks target mapping.
- Both D`/slots/i/target_outer_leaf_tokens/0` bind `leaf_vlog/value-l255-000237.log`, generation/resource_id4286578925, frontier.Bytes33554945, dev66306/inode6838642. Packed manager ID differs from raw LeafLogPtr.FileID2139095277; zero digest is not a content hash.
- D`/target_snapshot_backing`: snapshot_commit_seq128, active_view_mapping_presentfalse, registeredtrue, registered_id4286578925, registered_bytes33554945, open_file_presenttrue, zombiefalse, ref_count1. registered_snapshot_segment builder succeeds with17579 records; sidecar_index_presenttrue, sidecar_index_record_count0. This demonstrates parseability/registration, not the failing pointer's root/page/offset.
- Capability inspection revalidated/released and diagnostic snapshot closed before census. `/database_metadata_unchanged=true`, `/content_hash_claim=false` is metadata equality, not content/page proof.

Metadata raw SHA42799c7f… binds complete-file f9502539… and lists selected hex15/rev21 manifest31591B versus newer hex28/rev40 and compatibility69079B. Hex28 is decimal40. No latest manifest contents or replacement authority is established.

## Source causal boundaries (frozen761 exact lines)

`leaf_page_log.go:1097-1121,1140-1211` registers/promotes created/current files and queues raw IDs. Cached `caching/db.go:29052-29095` reader registration calls backend separately. File registration/pinning does not grant generation membership/deletion permission.

`leaf_generation_manifest.go:401-466,614-700` stages pending IDs in cloned manifest; `noteLeafGenerationWritableFileIDs:704-746` replaces stable manifest/view; replacement805-825 releases producer token rather than automatically transferring it into an already captured root candidate.

Queued `root_publication_activation.go:774` captures resources before pending staging at390 (called801). Staging supplies visible-view/post-work persistence; captured immutable resource set remains unchanged. Inline `db.go:3659` also captures before staging3736. Post-work3853-3901 persists/installs/clears pending after publication and cannot update sealed slots retroactively.

`durable_root_runtime.go:958-984` removes inherited manifest only if additional resources already contain a replacement manifest. New raw resources do not create replacement authority. Existing `prepareDurableRootManifestResourcesV1:98-132` supplies a stable replacement seam to vacuum callers; ordinary publication does not thereby inherit that transfer.

`leaf_generation_manifest_stable_prepare.go:17-63`, `open_readonly.go:158-179` deliberately load exact selected token before compatibility fallback. Actual token bytes/digest confirm this route. `leaf_generation_plan.go:950-975` builds scan state only from selected mappings;979-988 fails on encountered missing LeafLogPtr.FileID. Empty valid sidecar cannot repair that earlier membership failure. Census establishes encountered target pointer, not which root/page/offset.

Second discriminator: `leaf_generation_manifest.go:983-1032` skips physically present unmapped pending raw IDs whose sequence <= maxNonDeletedRecoveredSeq. Test1080 covers a stale missing older file, not present referenced out-of-order lane files. Actual target involvement UNKNOWN until pending IDs/lane/sequence and staged candidate at first offending ACK are observed.

## Attribution and later local fix

Queued activation blob ddba6e48… and manifest03fa34e3… are identical in A192, R6fa, measuredB731, frozen761 and currenta6. A inline capture3645 also precedes pending staging3719. The identified ordering/filter behavior was not introduced by B certified prune. No unobserved A workload outcome is inferred. Current comparison per file is recorded explicitly; only unchanged causal seams are relied on.

Local adjacent R1 afb0db443fbc39bd5de59735d70f77b2d0fdacf0 (`reuse owned manifests at the exact publication boundary`) orders owned-format dependency flush/registration before staging/publication (`db.go:3583-3600`). `leaf_manifest_owned.go:424-538` fences basis and installs intrinsic system-root manifest; pending IDs consumed at visibility including reused revision. Tests cover reuse/root edits, rollover and failed-stage retention. It is gated by db.ownedLeafManifests and not proof of repair to frozen external numbered-manifest DBs. Adjacent-owner branch, landed-main status unverified; local main is stale September28. No integration/adoption authorized.

## Best next action and conditional seam

Use a small writer ACK/reopen invariant reproducer before another census/stress run. Extend `TestOuterLeafOrdinaryAdditiveProducerInventory` (`root_publication_activation_test.go:950`): retain real registered leaf producer and predecessor prime; inspect each acknowledged root's own pinned manifest versus its actual referenced raw IDs, visible view/pending/created/current lanes/token ownership; Close/ReadOnly reopen and unchanged census. Exercise serialized and queued/build-group paths with command-WAL-durable mode matching this DB (existing inventory test is relaxed). Do not inject mappings or call noteLeafGenerationWritableFileIDs in setup. Small test-only rotation is causal discrimination, not natural admission/qualification evidence.

Narrowest retained-DB witness: first failing recoverable-root descriptor/commit, visited page ID, LeafLogPtr.FileID/offset/length, selected manifest revision/membership and matching raw token identity/frontier. Piggyback existing failed walk, preserve error, no new scan/absence permission. Metadata alone cannot locate writer cut.

If ordering reproduces: stage pending manifest after real dependency flush/registration and before capture; retain exact stable replacement token into same ACK candidate closure; consume pending producer ownership only at successful visibility. Reuse stable-manifest preparation; post-work-only persistence is insufficient. Keep older slots' own complete manifests; abort/error retains retryable pending IDs/releases abandoned tokens. Preserve both slots/replay/dictionary/pager/reader pins/revisions/late Manager fences. If present out-of-order raw IDs are instead proved filtered, isolate that predicate with cross-lane test before changing it.

Reject compatibility substitution, fabricated mappings, directory-based absence authority, deletion/repair, pressure/cap/budget changes or large rerun as first discriminator. Eligibility/reclaimable bytes/product/performance remain UNKNOWN. Missing first-ACK producer history and first failing root/page/offset are explicit next evidence needs.
