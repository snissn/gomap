# #5030 final qualification worksheet

SOURCE ONLY. All values, outcomes and verdicts below are **PENDING ACTUAL JOIN AND ROOT ADJUDICATION**. Root accepted the preceding metric map as source review only; that acceptance explicitly leaves raw, numerical, runtime, qualification, correctness, performance and merge acceptance false. No actual results, current host/native sources, state or GitHub were inspected. Held #5004 / PR #5006 remain excluded. This worksheet grants no execution or acceptance authority.

## Fill prerequisites and exact joins

Record externally accepted path + SHA256 + bytes for each prerequisite. Missing or malformed evidence stays **UNMET/MISSING**; UNKNOWN stays numerical **UNKNOWN**.

| Code | Required authority/content before filling dependent cells | Fill |
|---|---|---|
| Q0 | Root mapping source review: qualification-v12-root-preparation-v1/root-final-human-report-mapping-source-content-acceptance-v12-v1.json, status ROOT_LOCAL_SOURCE_METRIC_MAPPING_ACCEPTED_ONLY, source_review_accepted_by_root=true; bind accepted REPORT.md and source-bindings.json | SOURCE REVIEW ONLY; not product authority |
| Q1 | Genuine root-accepted original raw114 and distinct state-specific guards114; externally bound original sources/binaries/harness/native/runner/configuration; original validation, pre-C1 freezes, common inventory and chronological pair order | PENDING |
| Q2 | Genuine root-accepted exact34 final metadata/content and actual final B/R anchors; bind actual_final_content_acceptance and its final_anchors without fabricating future hashes | PENDING |
| Q3 | Original full54 B36 first then R18, then separate strict19; bind each complete numerical/proof file to actual reference SHA/bytes; no partial evaluation or source-review substitute | PENDING |
| Q4 | Complete all73 result bodies plus B16*8 and R6*8=176 allocation entries; complete genuine execution/readback identity; immutable original numeric content; inspect every entry and exact UNKNOWN reason | PENDING |
| Q5 | Bound actual default/ordinary configuration, eligibility/debt/root/pin evidence, useful scheduled progress/abort attribution, storage/physical checks, full correctness and eventual landed implementation equality | PENDING |

Root's required sequence remains raw114+114 -> exact34 -> original full54 -> separate strict19 -> complete all73 -> all176. Counts and rc0 are never passes. [C:33-60; F:84-124; P:22-92]

Use these aliases for **future genuinely validated** content, not source-created values:

- `O` = BASE/qualification-v12-final-artifact-preparation-v1/root-final-evaluations-actual-outcome-v12-v1.json. `O.original_evaluations[role][slot]` is the original {path,sha256}; `O.separate_strict_proofs[]` supplies {role,bundle,proof}. `O.actual_final_content_acceptance` binds final metadata authority.
- `J` = BASE/qualification-v12-root-preparation-v1/actual-final-all73-result-complete-content-v12-v1.json. `J["original-"+role+"-"+slot].value` is original result body `N`; sibling `.reference`/`.bytes` bind it. Strict body `T` is `J["strict-"+role+"-"+bundle_basename].value`, joined by exact proof ref in O. Do not guess strict keys from slot text alone.
- `L` = BASE/qualification-v12-root-preparation-v1/actual-final-all176-allocation-joined-v12-v1.json. B entry array is `L.B[slot].result.accounting_ledger`; R entry array is `L.R[slot].ledger`. `entry_count`, `met_entry_count`, `all_allocation_guards_met` are summary checks; inspect all176 content.
- `bundle` is the exact bound original `<slot>.bundle.json` from final plans/anchor. Native metrics below come from already-bound `bundle.pairs[i].A` and `.B` run paths and their original stdout/RSS/stderr closure. In R, dictionary key `.B` points to candidate R; `variant=R` and R labels are mandatory. No native read is authorized by this template.

All actual paths must follow final plans; R output path must not be inferred from B's analysis-global-original-v1 directory. [B:88-101; R:92-113; P:28-47,59-84]

## R/A: primary seed24 offline, batch8192

Every row needs Q1-Q4. Fill elapsed seconds and command HWM MiB with **all3 A/candidate observations and each median**; paired columns contain all3 matched directional changes and their median. Do not use ratios of independent medians as paired effects. Retained service gates must use this cohort's retained final DB state. No R online or holdout claim is provided.

| Cell `primary-s24-n<keys>-<mode>-b8192` | A -> R elapsed s, triples; medians | Elapsed paired %, E%,2E%,status/material | A -> R HWM MiB, triples; medians | HWM paired %, E%,2E%,status/material | Completion/service/debt |
|---|---|---|---|---|---|
| n30000-full | PENDING | PENDING | PENDING | PENDING | PENDING |
| n30000-exhaustive | PENDING | PENDING | PENDING | PENDING | PENDING |
| n300000-full | PENDING | PENDING | PENDING | PENDING | PENDING |
| n300000-exhaustive | PENDING | PENDING | PENDING | PENDING | PENDING |
| n3000000-full | PENDING | PENDING | PENDING | PENDING | PENDING |
| n3000000-exhaustive | PENDING | PENDING | PENDING | PENDING | PENDING |

## Independent combined B/A: offline primary/holdout and online

Every row needs Q1-Q4. B/A and R/A are independent matched cohorts; **no B/R causal delta**. Offline rows use the same elapsed/HWM fields as above. Online rows use the declared quiet.round3.rss_bytes primary and separate guard evidence.

| Exact cell prefix, suffix `-b8192` offline | A -> B elapsed s / HWM MiB, triples; medians (online: quiet RSS MiB) | Paired % triples; median | E%,2E%, original status/material | Other memory/service/progress/storage/correctness |
|---|---|---|---|---|
| primary-s24-n30000-full | PENDING | PENDING | PENDING | PENDING |
| primary-s24-n30000-exhaustive | PENDING | PENDING | PENDING | PENDING |
| primary-s24-n300000-full | PENDING | PENDING | PENDING | PENDING |
| primary-s24-n300000-exhaustive | PENDING | PENDING | PENDING | PENDING |
| primary-s24-n3000000-full | PENDING | PENDING | PENDING | PENDING |
| primary-s24-n3000000-exhaustive | PENDING | PENDING | PENDING | PENDING |
| holdout-s73-n300000-full | PENDING | PENDING | PENDING | PENDING |
| holdout-s73-n300000-exhaustive | PENDING | PENDING | PENDING | PENDING |
| holdout-s73-n3000000-full | PENDING | PENDING | PENDING | PENDING |
| holdout-s73-n3000000-exhaustive | PENDING | PENDING | PENDING | PENDING |
| online-primary-n30000 (no suffix) | PENDING | PENDING | PENDING | PENDING |
| online-primary-n300000 (no suffix) | PENDING | PENDING | PENDING | PENDING |
| online-primary-n3000000 (no suffix) | PENDING | PENDING | PENDING | PENDING |

## Cell selectors and original arithmetic

| Quantity | Exact selector to fill after Q1-Q4 |
|---|---|
| Offline elapsed | slot=`cell+"-elapsed_seconds"`; bound paired `run.json.elapsed_seconds`; `N.pair_effects`, `.median_effect`, `.E`, `.threshold`, `.material`, `.all_favourable`; `.status` may be absent for known original offline results |
| Offline HWM | slot=`cell+"-peak_rss_bytes"`; bound paired `run.json.memory.peak_rss_bytes`, derived from bound stderr.log time-v kbytes*1024; same N fields. `memory.sampled_peak` is separately co-timed sampled components, not HWM |
| Completion | `N.completion` three [A,candidate] dictionaries, `.equal_completion`, `.complete_runs`, `.complete_phase_dispositions`; raw applied/audit phase dispositions and debt remain explicit |
| Online quiet primary | slot=online cell; `N.ledger[id="quiet.round3.rss_bytes"]`: `.values` is C1/C2/C3, **not Ai**; `.effects`, `.E`, `.threshold`, `.material`, `.repeated_regression`; absolute pair values are medians of bound RSS rows inside exact round3 pause interior; support lower_ns/upper_ns/rows/max_gap_ns/before/after must match |
| Service metrics | slot=`cell+"-service-final"` for13 B/6 R retained guards, plus fresh B online original slots; `N.ledger[id="service.<phase>.<field>"]`; absolute values at bound stdout.json[0].phases[name=<phase>].<field>. Four phases=quicksilver_hits/misses/mixed/concurrent |
| Writer/barriers | `N.ledger[id="writer.update_batch_ms.sum/max" or "writer.checkpoint_ms.sum/max"]` from corresponding stdout arrays; `barrier.<field>` from report fields; `service.concurrent.composition_seconds` from concurrent phase |

Lower directional effect=(A-candidate)/A; higher=(candidate-A)/A; percent=100*effect. E=(max(C)-min(C))/median(C), known E>0. Material requires all3 effects>0 and median>2E, plus offline equal completion and complete runs. Known service repeated_regression means >=2 effects strictly<-2E. Guard material=false alone is not failure. Offline has no emitted repeated_regression field. UNKNOWN retains exact reason; offline unresolved override makes status=unknown/material=false/E=null/threshold=null and diagnostic pair effects cannot restore a pass. MiB=bytes/1048576; preserve original bytes and unrounded arithmetic. [M:410-476; E:291-342,421-446; B:218-248,379-389]

## Full gate ledger: required disposition and remaining evidence

Fill `PENDING` with **MET / UNMET / UNKNOWN / MISSING**, authority refs, exact original reason, and any separately supported guard disposition. No numerical UNKNOWN becomes a numerical pass.

| Gate, complete scope | Exact selector / authority needed | Disposition + evidence/missing reason |
|---|---|---|
| Faster useful maintenance/scaling | Both offline tables; representative3M elapsed material and smaller-scale work attribution; equal completion, policy/phases and remaining debt. Avoid requiring invented every-cell material targets | PENDING |
| Credible peak OR sustained owned-process memory | Offline whole-command HWM and/or B online quiet.round3 RSS, paired material/noise plus useful work/lifetime context. Round1/2 RSS, components and command HWM in online are guards; allocator rates and boundary snapshots cannot substitute | PENDING |
| Ordinary default2s schedule/configuration | Q5 actual bound command/config/env/source and genuine opportunity timeline; source2s scan budgets are **not scheduler cadence**; Full/Exhaustive commands are explicit maintenance | PENDING |
| Eligibility/protected retention | Q5 root/pin/protected/recovery horizons and safe reclaimable debt; before/after `engine_stats`, raw command-WAL `refresh.roots_before/roots_after`, `leaf_gc.stats.ManifestRevisionsProtected/Eligible/Deleted` where applicable; endpoint-specific metadata is not universal pin proof | PENDING |
| Useful automatic progress versus repeated proof abort | Online `stdout.json[0].maintenance_churn.rounds[r-1].before/after.engine_stats`, timestamp captured_at_unix_nano; `treedb.cache.vlog_generation.maintenance.passes.{with_rewrite,with_gc,with_leaf_pack,noop}.source.<source>`; leaf_pack copied/attributed_reclaim/gc.deleted counters versus errors,canceled,deadline,last_skip_reason; retained_prune completed/removed/closed versus foreground/budget/close abort. Show differences, eligibility, scheduling source and safe debt. Noop/expected reclaim alone is insufficient | PENDING |
| Service/no regression, full originals | Every40-ID retained service ledger for B13/R6 and64-ID fresh B online ledger; known E>0 + no repeated_regression under original policy or explicitly accepted measured cause/tradeoff; throughput/tails/max, concurrent/writer/barriers/memory guards | PENDING |
| Separate strict19 | `T.proofs[]` original exact16 p50/p95/p99/p999 positive-zero-spread UNKNOWN IDs; reported_pairs/effects all3, strict_favorable_positions,sufficient_witness,separate_guard_disposition. >=2 strict favorable gives SUFFICIENT_WITNESS; `T.not_applicable[]` retains original rule. Needs genuine prospective freeze/provenance and original full54 first; packet rc0 is insufficient | PENDING |
| Allocation full176 | `L.B[slot].result.accounting_ledger[]` and `L.R[slot].ledger[]`: original_numerical/original_baseline,baseline,pairs,zero_spread_supplement_eligible,allocation_guard_met. Require each8 entries per22 bundles met; B16 includes3 fresh online plus13 retained, R6 inherited original ledgers. Known-E follows original no repeated_regression; narrow recognized UNKNOWN exact-rate supplement requires all3 cross-product nonincrease. Preserve every growth observation; no new known-E exact-growth veto | PENDING |
| Shared-memory exact-zero guard | Original calibration/pair owned RSS identity/raw rows, complete quiet windows, every required shared_memory_bytes integer0 and accepted unchanged zero-guard policy. Numerical UNKNOWN stays; sampled accounting proves neither continuous absence nor total RSS saving; strict19 does not check it | PENDING |
| Storage/debt/handles | Raw offline stdout report.before/after[] name=index/wal/value_vlog/leaf_vlog/total,bytes/files/zero_byte_files; remaining_debt; online initial_files/final_files/maintenance_churn.final_files_after_close; actual retained-prune/GC counters plus safe-root authority. Separate final A/candidate census from within-run before/after. Legit protected debt need not vanish | PENDING |
| Apparent/allocated/temporary storage and physical-work limits | Bind actual producer semantics/measurements. Offline `N.unavailable` explicitly lists peak temporary disk and per-phase CRC/decode bytes. Missing allocation/apparent/temporary/frame/decode evidence is MISSING, never MET | PENDING |
| Correctness/service/storage preservation | Q5 full key/value/miss verification, checkpoint/reopen, physical CRC/decode/frame, affected correctness/race/recovery and final landed product equality. Bound collector profile/integrity and structural validation alone cannot close the full gate | PENDING |
| All remaining graph obligations | Frozen remaining_gates plus live root-owned parent authority; outside-matrix larger/conditional obligations are not waived by54/19/176 bookkeeping | PENDING |

[M:100-223,475-476; U:279-372; G:33255-33320,33400-33472; D:193-202; K:88-146; L:368-390,545-557; Z:3-13; A:29-31]

## Concise user-facing result, root fills last

**R/A:** [3M and scaling elapsed absolutes/paired changes; relevant HWM result; original noise/UNKNOWN; retained guards and limitations].

**Independent B/A:** [primary/holdout maintenance and online quiet RSS absolutes/paired changes; original noise/UNKNOWN and guard results]. No B/R causal claim.

**Ordinary operation:** [actual default cadence/config, eligibility/protected debt, useful scheduled progress versus abort, service/allocation/storage/correctness disposition].

**Decision and remaining work:** [explicit finding for each of the4 product goals; exact unmet/missing/UNKNOWN evidence; accepted tradeoffs if any; larger/conditional graph obligations]. Do not state qualification, performance acceptance, graph completion or merge readiness from joined counts or rc0.

Exact source SHA/bytes/line spans and root source-review acceptance are bound in source-bindings.json. E/B/R/D/RD/A/C/P/S/L/W/Z/ZA/M/U/K/F/G IDs inherit the accepted mapping's source index; source acceptance remains separate from runtime/results/product acceptance. Only this worksheet and its bindings are written. No modules/imports/tests/capture/helper/native/GitHub/state/source changes or children.
