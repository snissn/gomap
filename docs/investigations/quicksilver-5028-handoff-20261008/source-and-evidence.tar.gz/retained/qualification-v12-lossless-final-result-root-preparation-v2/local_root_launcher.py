"""Root-only finite stage4 launcher. Source review precedes any native use.

Complete result parsing/equality runs sequentially on the native runner. This
launcher retrieves bounded exact receipts, indexes and explicitly named views;
complete canonical originals and lossless archives stay authoritative there.
"""
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types

BASE = Path('/Users/michaelseiler/dev/snissn/gomap/tmp/quicksilver-maintenance-5028-20261005')
HERE = BASE/'qualification-v12-lossless-final-result-root-preparation-v2'
P9 = BASE/'qualification-v9-selected-source-preparation-v1'
FINAL = BASE/'qualification-v12-final-artifact-preparation-v1'
NROOT = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
NINPUT = NROOT/HERE.name
NOUT = NROOT/'qualification-v12-lossless-final-result-transport-actual-v2'
FLAGS = ('qualification','performance_accepted','collection_authorized',
         'candidate_pairs_authorized','merge_authorized')


def identity(path):
    p = Path(path)
    assert p.is_absolute() and p.resolve(strict=True) == p and not p.is_symlink()
    digest = hashlib.sha256()
    size = 0
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            digest.update(block)
            size += len(block)
    return dict(bytes=size,sha256=digest.hexdigest())


def ref(path):
    return dict(path=str(path),sha256=identity(path)['sha256'])


def read(path):
    return json.loads(Path(path).read_bytes())


def save(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False)
        f.write('\n')


def flags(value):
    assert all(value[k] is False for k in FLAGS)


def state_update(**fields):
    p = BASE/'state.json'
    before = p.read_bytes()
    s = json.loads(before)
    s.update(fields)
    s['updated_at_ns'] = time.time_ns()
    pending = HERE/('state-stage4-runtime-'+str(time.time_ns())+'.json')
    with pending.open('x') as f:
        json.dump(s,f,indent=2,allow_nan=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    assert p.read_bytes() == before, 'state changed concurrently'
    os.replace(pending,p)


def actual(label,stdout_suffix='txt'):
    receipt_path = P9/(label+'-run.json')
    r = read(receipt_path)
    assert r['rc'] == 0 and not r.get('error')
    assert 0 < r['started_ns'] < r['finished_ns'] <= time.time_ns()
    for kind in ('stdout','stderr'):
        suffix = stdout_suffix if kind == 'stdout' else 'txt'
        path = P9/(label+'-'+kind+'.'+suffix)
        expected = identity(path)
        if 'path' in r[kind]:
            expected['path'] = str(path)
        assert r[kind] == expected
    assert r['stderr']['bytes'] == 0
    return ref(receipt_path)


def native_bound(io,reference,label,local_name):
    assert set(reference) == {'path','sha256'}
    assert Path(reference['path']).is_relative_to(NOUT)
    assert len(reference['sha256']) == 64 and all(c in '0123456789abcdef' for c in reference['sha256'])
    code = '''from pathlib import Path
import hashlib,sys
p=Path(sys.argv[1]);assert p.is_absolute() and p.resolve(strict=True)==p and p.is_file() and not p.is_symlink()
assert p.stat().st_size <= 4*1024*1024, 'bounded packet too large; full archives remain separate'
raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==sys.argv[2]
sys.stdout.buffer.write(raw)
'''
    raw = io.native(['python3','-B','-c',code,reference['path'],reference['sha256']],label,120)
    execution = actual(label)
    assert hashlib.sha256(raw).hexdigest() == reference['sha256']
    target = HERE/local_name
    with target.open('xb') as f:
        f.write(raw)
    return json.loads(raw),dict(native_reference=reference,local_reference=ref(target),execution=execution)


def main(adoption_path,adoption_sha):
    assert __debug__ and os.environ.get('PYTHONPYCACHEPREFIX') is None
    adoption_path = Path(adoption_path)
    assert adoption_path.parent == HERE and identity(adoption_path)['sha256'] == adoption_sha
    adoption = read(adoption_path)
    flags(adoption)
    assert adoption['accepted_by_root'] is adoption['source_only'] is True
    assert adoption['status'] == 'ROOT_LOSSLESS_STAGE4_ADAPTER_SOURCE_ACCEPTED_ONLY'
    assert adoption['held_excluded'] == [5004,5006]
    launcher_path = Path(__file__).resolve()
    assert adoption['local_launcher'] == ref(launcher_path)
    assert adoption['launcher'] == dict(path=str(NINPUT/launcher_path.name),sha256=identity(launcher_path)['sha256'])
    review_path = Path(adoption['local_independent_review']['path'])
    assert ref(review_path) == adoption['local_independent_review']
    assert adoption['independent_review'] == dict(path=str(NINPUT/'independent-review.json'),sha256=identity(review_path)['sha256'])
    state = read(BASE/'state.json')
    assert state['native_active'] is None
    outcome_path = FINAL/'root-final-evaluations-actual-outcome-v12-v1.json'
    outcome = read(outcome_path)
    flags(outcome)
    assert outcome['status'] == 'ACTUAL_ORIGINAL_FULL54_THEN_SEPARATE_STRICT19_JOINED_PRODUCT_DECISION_PENDING'
    assert outcome['held_excluded'] == [5004,5006]
    assert outcome['original_pair_count'] == outcome['state_specific_guard_count'] == 114
    assert len(outcome['original_evaluations']['B']) == 36
    assert len(outcome['original_evaluations']['R']) == 18
    assert len(outcome['separate_strict_proofs']) == 19
    actual('v12-actual-original-full-B36-R18-final-evaluation-v1')
    actual('v12-actual-separate-strict19-supplement-v1')
    content = read(FINAL/'actual-final-content-decision-readback-v12-v1.json')
    assert content['reference'] == outcome['actual_final_content_acceptance']
    flags(content['decision'])
    assert content['decision']['actual_final_contents_accepted'] is True
    proto_path = Path(adoption['local_prototype']['path'])
    helper_path = Path(adoption['local_helper']['path'])
    assert ref(proto_path) == adoption['local_prototype']
    assert ref(helper_path) == adoption['local_helper']
    for p,k in ((proto_path,'prototype'),(helper_path,'helper')):
        assert adoption[k] == dict(path=str(NINPUT/p.name),sha256=identity(p)['sha256'])
    ip = P9/'root_native_io.py'
    assert identity(ip)['sha256'] == 'fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
    io = types.ModuleType('root_io')
    io.__file__ = str(ip)
    exec(compile(ip.read_bytes(),str(ip),'exec'),io.__dict__)
    request_path = HERE/'actual-stage4-request.json'
    request = dict(schema=1,status='ROOT_AUTHORIZED_LOSSLESS_FINAL_RESULT_AND_B16_REPLAY_ONLY',
        actual_final_outcome=dict(path=str(NINPUT/'actual-final-outcome.json'),sha256=identity(outcome_path)['sha256']),
        source_adoption=dict(path=str(NINPUT/'source-adoption.json'),sha256=adoption_sha),
        final_anchors=content['decision']['final_anchors'],campaign_root=outcome['campaign_root'],
        output_directory=str(NOUT),
        authorized_ns=time.time_ns(),
        held_excluded=[5004,5006],artifact_content_review_authorized=True,
        **{key:False for key in FLAGS})
    save(request_path,request)
    sources={str((NINPUT/name).relative_to(NROOT)):p for name,p in (
        (proto_path.name,proto_path),(helper_path.name,helper_path),
        (launcher_path.name,launcher_path),('independent-review.json',review_path),
        ('source-adoption.json',adoption_path),('actual-stage4-request.json',request_path),
        ('actual-final-outcome.json',outcome_path))}
    state_update(native_active=dict(phase='fresh-v12-lossless-complete73-and-exact-B16-allocation',
        owner='/root',local_owner_pid=os.getpid(),started_ns=time.time_ns(),
        campaign_root=outcome['campaign_root'],qualification=False,candidate_pairs_authorized=False))
    try:
        io.put(sources,'v12-root-lossless-stage4-reviewed-inputs-exclusive-stage-v2')
        stage_receipt=actual('v12-root-lossless-stage4-reviewed-inputs-exclusive-stage-v2','json')
        label='v12-actual-lossless-native-complete73-and-exact-B16-allocation-v2'
        result=json.loads(io.native(['python3','-B',str(NINPUT/helper_path.name),
            str(NINPUT/request_path.name),identity(request_path)['sha256'],str(NOUT)],label,14400))
        execution=actual(label)
        # The native adapter's returned artifact refs are checked individually.
        readbacks={}
        for key in ('completion','complete73','observations','all176'):
            source_key = 'index' if key == 'complete73' else key
            value,receipt=native_bound(io,result[source_key],'v12-root-lossless-stage4-'+key+'-readback-v2',
                'actual-lossless-stage4-'+key+'-v12-v2.json')
            flags(value)
            readbacks[key]=dict(value=value,receipt=receipt)
        expected={'original-'+role+'-'+name:reference
            for role,rows in outcome['original_evaluations'].items() for name,reference in rows.items()}
        for item in outcome['separate_strict_proofs']:
            key='strict-'+item['role']+'-'+Path(item['bundle']['path']).name
            assert key not in expected
            expected[key]=item['proof']
        index=readbacks['complete73']['value']
        assert index['complete_body_count'] == len(expected) == 73
        assert set(index['records']) == set(expected)
        assert all(index['records'][key]['reference'] == reference for key,reference in expected.items())
        ledger=readbacks['all176']['value']
        assert ledger['B_bundle_count'] == 16 and ledger['R_bundle_count'] == 6
        assert ledger['entry_count'] == 176
        entries=[entry for row in ledger['B'].values() for entry in row['accounting_ledger_reference']['disposition_views']]
        entries += [entry for row in ledger['R'].values() for entry in row['allocation_ledger_reference']['disposition_views']]
        assert len(entries) == 176 and all(type(entry['allocation_guard_met']) is bool for entry in entries)
        assert ledger['met_entry_count'] == sum(entry['allocation_guard_met'] is True for entry in entries)
        assert ledger['all_allocation_guards_met'] == all(entry['allocation_guard_met'] is True for entry in entries)
        assert ledger['original_numerical_UNKNOWN_unmodified'] is True
        packet=dict(schema=1,status='ACTUAL_LOSSLESS_STAGE4_JOINED_PRODUCT_DECISION_PENDING',
            accepted_by_root=False,source_adoption=ref(adoption_path),
            original_final_outcome=ref(outcome_path),exclusive_stage_execution=stage_receipt,
            native_execution=execution,native_result=result,readbacks=readbacks,
            held_excluded=[5004,5006],completed_ns=time.time_ns(),**{key:False for key in FLAGS})
        final=HERE/'actual-lossless-stage4-root-outcome-v12-v2.json'
        save(final,packet)
        s=read(BASE/'state.json')
        q=s['qualification_v12_current']
        q['actual_lossless_stage4_joined']=ref(final)
        state_update(native_active=None,qualification_v12_current=q,
            current_execution_status='Lossless complete73 and exact B16/all176 joined; product disposition pending',
            next_action='Inspect all numerical/strict/allocation dispositions and full referenced contents; adjudicate unchanged memory, default progress, service, storage and correctness gates')
        print(json.dumps(dict(status=packet['status'],outcome=ref(final),qualification=False)),flush=True)
    except BaseException as error:
        state_update(native_active=None,last_native_failure=dict(
            phase='fresh-v12-lossless-complete73-and-B16',error=repr(error),finished_ns=time.time_ns()),
            current_execution_status='Lossless stage4 failed; originals and joined calls retained; no automatic retry',
            next_action='Inspect exact failure and completed exclusive receipts; do not repeat completed allocation calls or alter frozen arithmetic')
        raise


if __name__ == '__main__':
    assert len(sys.argv) == 3
    main(sys.argv[1],sys.argv[2])
