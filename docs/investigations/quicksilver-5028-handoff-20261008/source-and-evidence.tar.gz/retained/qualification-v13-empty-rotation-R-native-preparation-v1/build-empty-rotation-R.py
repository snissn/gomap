"""Root diagnostic build using the retained, verified compiler-input helpers."""
import hashlib
import json
import os
import signal
from pathlib import Path
import sys
import time
import types


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound(ref):
    p = Path(ref['path'])
    assert p.is_absolute() and not p.is_symlink()
    assert sha(p) == ref['sha256']
    return json.loads(p.read_bytes())


def load(ref, name):
    p = Path(ref['path'])
    assert not p.is_symlink() and sha(p) == ref['sha256']
    m = types.ModuleType(name)
    m.__file__ = str(p)
    sys.modules[name] = m
    exec(compile(p.read_bytes(), str(p), 'exec'), m.__dict__)
    return m


request_path = Path(sys.argv[1])
assert sha(request_path) == sys.argv[2]
request = json.loads(request_path.read_bytes())
assert request['scope'] == 'Exact empty-rotation R diagnostic build only; stop before measurement'
assert not request['collection_authorized'] and not request['qualification']
assert request['held_excluded'] == [5004, 5006]
pc = load(request['helpers']['pipeline_common.py'], 'refined_compiler_common')
builder = load(request['helpers']['build-native-v12.py'], 'retained_archive_builder')
for signum in (signal.SIGINT, signal.SIGTERM):
    signal.signal(signum, builder.interrupt)
context = request['original_build_context']
frozen = pc.bound(context['source_freeze'])
env, go = pc.environment(context, frozen)
native_inputs = pc.native_scope(context, frozen)
listing = bound(request['tracked_manifest'])
assert listing['head'] == request['candidate_head'] and listing['tree'] == request['candidate_tree']
archive = Path(request['archive']['path'])
assert sha(archive) == request['archive']['sha256']
source = Path(request['source'])
directory = Path(request['build_root'])
binary = Path(request['binary'])
assert not os.path.lexists(source) and not os.path.lexists(directory) and not os.path.lexists(binary)
directory.mkdir()
started = time.time_ns()
owner = dict(pid=os.getpid(), started_ns=started, argv=sys.argv, scope=request['scope'],
             qualification=False, collection_authorized=False)
builder.save(directory / 'native-owner.json', owner)
builder.extract_archive(archive, source, listing)
source_receipt = dict(head=listing['head'], tree=listing['tree'], source=str(source),
    tracked_manifest=request['tracked_manifest'], archive=request['archive'],
    verified_all_tracked_blobs_and_modes=True, tracked_files=len(listing['files']),
    runtime_source_review=request['source_review'], qualification=False)
builder.save(directory / 'source-receipt.json', source_receipt)


def run(prefix, argv, timeout=300):
    record, failure = pc.run(argv, source, env, directory, prefix, timeout)
    builder.save(directory / (prefix + '-run.json'), record)
    builder.successful(record, failure)
    return record


version = run('go-version', [go, 'version'], 30)
assert Path(version['stdout_path']).read_text().startswith('go version go1.26.3 ')
tags = ['-tags', 'lmdb rocksdb']
package = './cmd/unified_bench'
listed = run('go-list', [go, 'list', '-deps', '-json', *tags, package])
inputs = pc.compiler_inputs(pc.json_stream(Path(listed['stdout_path']).read_text()), source, listing)
built = run('build', [go, 'build', '-p', '1', '-buildvcs=false', '-work', '-x', *tags,
                      '-o', str(binary), package])
exports_run = run('go-list-exports', [go, 'list', '-p', '1', '-deps', '-export', '-json', *tags, package])
exports = pc.package_exports(pc.json_stream(Path(exports_run['stdout_path']).read_text()))
generated = pc.work_inputs(built['stderr_path'])
for values in (exports, inputs['selected_files'], inputs['module_files'],
               inputs['uncompiled_repository_test_inputs'], native_inputs,
               generated['generated_and_work_files'], generated['actual_import_archives']):
    pc.verify_bindings(values)
builder.verify(source, listing)
assert builder.leaves(source) == set(listing['files'])
compiler_receipt = dict(schema=1, head=listing['head'], tree=listing['tree'],
    package=package, tags=tags, env=env, go_tool=context['go_tool'],
    native_input_scope=context['native_input_scope'], native_input_files=native_inputs,
    actual_package_export_archives=exports, **inputs, **generated,
    qualification=False, accepted_by_root=False)
builder.save(directory / 'compiler-inputs.json', compiler_receipt)
run('caching-focused-normal', [go, 'test', '-count=1', '-run', '^(TestEmptySnapshotRotation|TestAcquireSnapshot|TestAcquireBackendSnapshot|TestIteratorSnapshotIsolation|TestSnapshot|TestCachedSnapshot|TestRootDomain|TestRawPointRootDomain|TestRawIteratorRootDomain|TestDB_MemtableSnapshot|TestDB_BatchWriteBypassRetainsMemtableViewLease|TestRetainMemtableView|TestPublishMemtablesDefers|TestRetiredMemtableRecycle|TestReleaseClosingEmptyMemtables|TestAdaptiveMemtableMode|TestGetManyView|TestBatchArenaLeases_|TestBatchStableViewValueLease_|TestBatchResetDoesNotCorrupt)', '-timeout', '3m', './TreeDB/caching'], 240)
run('caching-focused-race', [go, 'test', '-race', '-count=1', '-run', '^(TestEmptySnapshotRotation|TestAcquireSnapshot|TestAcquireBackendSnapshot|TestIteratorSnapshotIsolation|TestSnapshot|TestCachedSnapshot|TestRootDomain|TestRawPointRootDomain|TestRawIteratorRootDomain|TestDB_MemtableSnapshot|TestDB_BatchWriteBypassRetainsMemtableViewLease|TestRetainMemtableView|TestPublishMemtablesDefers|TestRetiredMemtableRecycle|TestReleaseClosingEmptyMemtables|TestAdaptiveMemtableMode|TestGetManyView|TestBatchArenaLeases_|TestBatchStableViewValueLease_|TestBatchResetDoesNotCorrupt)', '-timeout', '3m', './TreeDB/caching'], 240)
builder.verify(source, listing)
assert builder.leaves(source) == set(listing['files'])
assert sha(binary) and sha(request_path) == sys.argv[2]
result = dict(status='EXACT_EMPTY_ROTATION_R_BUILD_AND_AFFECTED_NATIVE_TESTS_JOINED',
    head=listing['head'], tree=listing['tree'], binary=str(binary), binary_sha256=sha(binary),
    tracked_files=len(listing['files']), source_receipt=str(directory/'source-receipt.json'),
    source_receipt_sha256=sha(directory/'source-receipt.json'),
    compiler_receipt=str(directory/'compiler-inputs.json'),
    compiler_receipt_sha256=sha(directory/'compiler-inputs.json'),
    directory=str(directory), started_ns=started, finished_ns=time.time_ns(),
    collection_authorized=False, qualification=False, performance_accepted=False)
builder.save(directory/'build-complete.json', result)
print(json.dumps(result), flush=True)
