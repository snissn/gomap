"""Root build-only launch. Collection remains unauthorized after a genuine join."""
import hashlib
import json
import os
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
STATE = BASE / 'state.json'
NROOT = '/home/mikers/quicksilver-maintenance-5028-20261006'
CONTROL = NROOT + '/qualification-v13-empty-rotation-R-native-control-v1'
io_path = BASE / 'qualification-v9-selected-source-preparation-v1/root_native_io.py'
raw = io_path.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io = {'__file__': str(io_path), '__name__': 'root_io'}
exec(compile(raw, str(io_path), 'exec'), io)
request_raw = (HERE / 'request.json').read_bytes()
request_sha = hashlib.sha256(request_raw).hexdigest()
request = json.loads(request_raw)
assert not request['collection_authorized'] and not request['qualification']


def change(active, outcome=None):
    old = STATE.read_bytes()
    state = json.loads(old)
    previous = state.get('native_active')
    assert previous is None or previous.get('owner_launcher_pid') == os.getpid()
    state['native_active'] = active
    current = state['qualification_v13_current']
    current['native_active'] = active
    current['empty_rotation_R_build_request'] = str(HERE / 'request.json')
    if outcome is not None:
        current['empty_rotation_R_build_outcome'] = outcome
    pending = BASE / ('state-v13-empty-rotation-R-build-' + str(time.time_ns()) + '.pending')
    with pending.open('x') as stream:
        json.dump(state, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    assert STATE.read_bytes() == old
    os.replace(pending, STATE)


result = dict(started_ns=time.time_ns(), request_sha256=request_sha,
              collection_authorized=False, qualification=False, performance_accepted=False)
with (HERE / 'launch-owner.json').open('x') as stream:
    json.dump(dict(pid=os.getpid(), started_ns=result['started_ns'], held_excluded=[5004, 5006]), stream)
active = dict(owner='root', owner_launcher_pid=os.getpid(), started_ns=result['started_ns'],
              phase='exact-empty-rotation-R-build-only', scope=request['scope'], head=request['candidate_head'])
change(active)
joined = False
try:
    io['put']({'qualification-v13-empty-rotation-R-native-control-v1/' + name: (Path(request['local_shipping_archive']) if name == 'R-full-source.tar.gz' else HERE / name)
               for name in ('build-empty-rotation-R.py', 'request.json', 'R-full-source.tar.gz', 'R-tracked-manifest.json')},
              'v13-empty-rotation-R-build-exclusive-control-transfer-v1')
    print('ROOT_BUILD_ONLY_ACTUAL_LAUNCH', flush=True)
    argv = ['python3', '-B', CONTROL + '/build-empty-rotation-R.py', CONTROL + '/request.json', request_sha]
    result['native_argv'] = argv
    outcome = json.loads(io['native'](argv, 'v13-empty-rotation-R-build-and-native-caching-tests-v1', 1000))
    assert outcome['status'] == 'EXACT_EMPTY_ROTATION_R_BUILD_AND_AFFECTED_NATIVE_TESTS_JOINED'
    assert outcome['head'] == request['candidate_head'] and outcome['tree'] == request['candidate_tree']
    assert not outcome['collection_authorized'] and not outcome['qualification']
    result['native_outcome'] = outcome
    result['status'] = 'GENUINE_BUILD_JOINED_STOP_BEFORE_MEASUREMENT'
    joined = True
except BaseException as error:
    result['status'] = 'FAILED_RETAINED_JOIN_REQUIRES_VERIFICATION_NO_RETRY'
    result['error'] = repr(error)
    raise
finally:
    result['finished_ns'] = time.time_ns()
    with (HERE / 'actual-build-root-outcome.json').open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    pointer = dict(path=str(HERE / 'actual-build-root-outcome.json'), status=result['status'])
    change(None if joined else active, pointer)
    print(json.dumps(dict(status=result['status'], elapsed_seconds=(result['finished_ns'] - result['started_ns']) / 1e9,
                          outcome=pointer['path'])), flush=True)
