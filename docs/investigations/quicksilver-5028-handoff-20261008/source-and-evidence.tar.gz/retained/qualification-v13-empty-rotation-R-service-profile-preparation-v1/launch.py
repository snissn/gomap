"""Root-owned once-only diagnostic launch and genuine join bookkeeping."""
import hashlib
import json
import os
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
STATE = BASE / 'state.json'
io_path = BASE / 'qualification-v9-selected-source-preparation-v1/root_native_io.py'
io_raw = io_path.read_bytes()
assert hashlib.sha256(io_raw).hexdigest() == 'fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io = {'__file__': str(io_path), '__name__': 'root_io'}
exec(compile(io_raw, str(io_path), 'exec'), io)
NROOT = '/home/mikers/quicksilver-maintenance-5028-20261006'
ROOT = NROOT + '/qualification-v12-refresh/qualification-v10'
CONTROL = NROOT + '/qualification-v13-empty-rotation-R-service-profile-control-v1'


def state_change(phase, argv=None, outcome=None):
    old = STATE.read_bytes()
    state = json.loads(old)
    active = state.get('native_active')
    assert active is None or active.get('owner_launcher_pid') == os.getpid()
    row = None if phase == 'joined' else dict(owner='root', owner_launcher_pid=os.getpid(),
        phase=phase, native_argv=argv, started_ns=time.time_ns(), scope='v13 empty-rotation R diagnostic only')
    state['native_active'] = row
    current = state['qualification_v13_current']
    current['native_active'] = row
    current['empty_rotation_profile_request'] = str(HERE / 'request.json')
    if outcome is not None:
        current['empty_rotation_profile_outcome'] = outcome
    pending = BASE / ('state-v13-empty-rotation-R-profile-' + phase + '-' + str(time.time_ns()) + '.pending')
    with pending.open('x') as stream:
        json.dump(state, stream, indent=2, allow_nan=False); stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    assert STATE.read_bytes() == old
    os.replace(pending, STATE)


with (HERE / 'launch-owner.json').open('x') as stream:
    json.dump(dict(pid=os.getpid(), started_ns=time.time_ns(), root=str(ROOT), held_excluded=[5004, 5006]), stream)
result = dict(started_ns=time.time_ns(), qualification=False, performance_accepted=False)
try:
    io['put']({'qualification-v13-empty-rotation-R-service-profile-control-v1/' + name: HERE / name
               for name in ('prepare.py', 'plan.json', 'request.json', 'source-acceptance.json', 'build-acceptance.json')}, 'v13-empty-rotation-R-profile-exclusive-control-transfer-v1')
    io['put']({'qualification-v12-refresh/qualification-v10/manifest-v13-empty-rotation-R-diagnostic.json': HERE/'manifest-v13-empty-rotation-R-diagnostic.json'}, 'v13-empty-rotation-R-profile-exclusive-manifest-transfer-v1')
    argv = ['python3', '-B', CONTROL + '/prepare.py']
    state_change('fresh-copy-preparation', argv)
    raw = io['native'](argv, 'v13-empty-rotation-R-profile-fresh-copy-preparation-v1', 1800)
    result['preparation'] = json.loads(raw)
    print(json.dumps(result['preparation']), flush=True)
    argv = ['python3', '-B', NROOT + '/source-qualification-v12-R/scripts/unified_bench_quicksilver_capture.py',
            ROOT + '/manifest-v13-empty-rotation-R-diagnostic.json', CONTROL + '/plan.json']
    state_change('frozen-R-3M-service-profile', argv)
    print('ROOT_PROFILE_ACTUAL_LAUNCH', flush=True)
    raw = io['native'](argv, 'v13-empty-rotation-R-profile-frozen-R3M-service-v1', 2400)
    result['collector_stdout'] = raw.decode()
    code = """import pathlib,json,sys,hashlib,time
root=pathlib.Path(ROOT_LITERAL)
scripts=pathlib.Path(SCRIPTS_LITERAL)
assert hashlib.sha256((scripts/'quicksilver_maintenance.py').read_bytes()).hexdigest()=='41d565138ae6d3762e74bce21dd2dd8c88830ce0ef7a24a34b1d6da7bfc25796'
sys.path.insert(0,str(scripts));import quicksilver_maintenance as maintenance
prep=json.loads((root/'v13-empty-rotation-R-post-exhaustive-3M-profile-fixture-v1/prepared-receipt.json').read_bytes())
actual=maintenance.fingerprint(pathlib.Path(prep['source']));assert actual==prep['source_before']
out=root/'v13-empty-rotation-R-post-exhaustive-3M-service-profile-v1/1-ER13-post-exhaustive'
run=json.loads((out/'run.json').read_bytes());assert run['rc']==0 and run['validated'] is True
assert run['source']['head']=='4b2ac03223517e0c5a393f2dd645177d07437b4a'
assert run['source']['binary_sha256']=='843196665d75473f1f30068bf45b871c1817d06bdaa53f3a984785cc1829b78f'
print(json.dumps({'status':'GENUINE_DIAGNOSTIC_PROFILE_JOINED_SOURCE_UNCHANGED','clock_ns':time.time_ns(),'source_fingerprint':actual,'output':str(out),'source_head':run['source']['head'],'collector_sha256':run['collector_sha256'],'rc':run['rc'],'validated':run['validated'],'started':run['started'],'finished':run['finished'],'rss_sampling':run['rss_sampling'],'profile_files':[{ 'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.glob('*.pprof'))],'qualification':False,'performance_accepted':False}))
""".replace('ROOT_LITERAL', repr(ROOT)).replace('SCRIPTS_LITERAL', repr(NROOT + '/source-qualification-v12-R/scripts'))
    raw = io['native'](['python3', '-B', '-c', code], 'v13-empty-rotation-R-profile-source-preservation-and-genuine-join-v1', 120)
    result['join'] = json.loads(raw)
    result['status'] = 'JOINED_DIAGNOSTIC_ONLY'
except BaseException as error:
    result['status'] = 'FAILED_RETAINED_NO_RETRY'
    result['error'] = repr(error)
    raise
finally:
    result['finished_ns'] = time.time_ns()
    with (HERE / 'actual-root-outcome.json').open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    if result['status']=='JOINED_DIAGNOSTIC_ONLY':
        state_change('joined', outcome=dict(path=str(HERE / 'actual-root-outcome.json'), status=result['status']))
    print(json.dumps(dict(status=result['status'], outcome=str(HERE / 'actual-root-outcome.json'),
                          elapsed_seconds=(result['finished_ns'] - result['started_ns']) / 1e9)), flush=True)
