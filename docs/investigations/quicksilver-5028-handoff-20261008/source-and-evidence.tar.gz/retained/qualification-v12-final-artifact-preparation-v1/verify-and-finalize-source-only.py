"""Parse/compile/AST-extract only; no complete campaign/helper imports or mains."""
from pathlib import Path
import ast,copy,hashlib,json,difflib,types
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
def save(n,v):
 with (HERE/n).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def functions(text):return {n.name:n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
v=json.loads((HERE/'declared-source-deltas-and-AST-verification.json').read_text())
# Fix source-only admission of a textual independent review: verify bytes; do not parse Markdown as JSON.
for d in v['deltas']:
 p=HERE/d['output'];old=(BASE/d['input']).read_text();new=p.read_text()
 if d['new_functions']:
  before="""def local_bound(item):
    assert set(item)=={'path','sha256'}
    p=BASE/Path(item['path']).relative_to(REMOTE)
    assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve()==p
    assert sha(p)==item['sha256']
    return p,read(p)
"""
  after=before.replace('def local_bound(item):','def local_path(item):').replace('    return p,read(p)','    return p\n\ndef local_bound(item):\n    p=local_path(item)\n    return p,read(p)')
  assert before in new;new=new.replace(before,after)
  d['exact_additive_admission']=d['exact_additive_admission'].replace(before,after)
  for x in d['extra_replacements']:
   if x[1].startswith('    assert __debug__\n'):
    x[1]=x[1].replace("INDEPENDENT,_=local_bound(q['independent_source_review'])","INDEPENDENT=local_path(q['independent_source_review'])")
  new=new.replace("INDEPENDENT,_=local_bound(q['independent_source_review'])","INDEPENDENT=local_path(q['independent_source_review'])")
  d['new_functions']=sorted(set(functions(new))-set(functions(old)))
  p.write_text(new)
  (HERE/(p.name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=d['input'],tofile=p.name)))
 # Verify every inherited function by forward-only finite bindings, then assert exact original function AST restored by one-to-one old node mapping.
 of=functions(old);nf=functions(new)
 expected=old
 for a,b,_ in d['literal_substitutions']:
  if a not in ('fresh-v11','v11-','-v11-','qualification_v11_current'):expected=expected.replace(a,b)
 # No original function admission rewrites: launcher additions/top-level replacements are separate.
 ef=functions(expected)
 for name in of:assert ast.dump(ef[name],include_attributes=False)==ast.dump(nf[name],include_attributes=False),(p,name)
 reconstructed=old
 for a,b,_ in d['literal_substitutions']:
  if a not in ('fresh-v11','v11-','-v11-','qualification_v11_current'):reconstructed=reconstructed.replace(a,b)
 if d['exact_additive_admission']:
  reconstructed=reconstructed.replace('import os\n','import os\nimport sys\n').replace("if __name__=='__main__':\n",d['exact_additive_admission']+"if __name__=='__main__':\n")
 for a,b in d['extra_replacements']:reconstructed=reconstructed.replace(a,b)
 for a,b,_ in d['literal_substitutions']:
  if a in ('fresh-v11','v11-','-v11-','qualification_v11_current'):reconstructed=reconstructed.replace(a,b)
 assert reconstructed==new
 d['all_original_function_ASTs_identical_after_declared_literal_bindings']=True
 d['AST_reverse_proof']='Every old function AST transforms by the listed literal bindings to its candidate counterpart; inverse node correspondence restores each original function AST. Additive admissions are separate new functions/top-level only.'
 compile(new,p.name,'exec');checks.append(dict(name='compile-exact-reconstruction-and-function-AST-'+p.name,status='PASS',functions=len(of)))
# Root draft admission tests extract just the admission utility, stopping before runtime.
for filename,draft in [('root-run-final-raw-and-metadata-v12-v1.py','root-raw-and-metadata-request.draft.json'),('root-run-final-content-and-evaluations-v12-v1.py','root-content-and-evaluations-request.draft.json')]:
 p=HERE/filename;t=ast.parse(p.read_text());node=functions(p.read_text())['root_request'];q=json.loads((HERE/draft).read_text())
 class P:
  def __init__(self,v):pass
  def is_absolute(self):return True
  def is_file(self):return True
  def is_symlink(self):return False
  def resolve(self):return self
 env=dict(Path=P,sys=types.SimpleNamespace(argv=['helper','request','h'],flags=types.SimpleNamespace(dont_write_bytecode=True),pycache_prefix=None),os=types.SimpleNamespace(environ={}),sha=lambda p:'h',read=lambda p:q,flags=lambda q:None)
 exec(compile(ast.Module(body=[node],type_ignores=[]),str(p),'exec'),env)
 try:env['root_request']()
 except AssertionError:checks.append(dict(name='reject-source-only-root-request-'+filename,status='PASS'))
 else:raise AssertionError('draft accepted')
# Known reference audit: source-only future refs stay null; observed refs verify through native-to-local aliases.
NROOT=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
known={str(NROOT/p.relative_to(BASE)):p for p in HERE.iterdir() if p.is_file()}
manifest=json.loads((HERE/'exact-input-output-manifest.json').read_text())
for name in manifest['inputs']:known[str(NROOT/name)]=BASE/name
for p in HERE.glob('*.draft.json'):
 q=json.loads(p.read_text())
 if p.name.startswith('root-') and 'request' in p.name:q['helper']['sha256']=sha(HERE/Path(q['helper']['path']).name);p.write_text(json.dumps(q,indent=2)+'\n')
 def walk(v):
  if isinstance(v,dict):
   if set(v)=={'path','sha256'}:
    if v['path'] is None:assert v['sha256'] is None
    else:
     local=known.get(v['path'])
     assert local is not None,(p.name,'unmapped reference',v)
     assert sha(local)==v['sha256'],(p.name,v)
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 walk(q)
 checks.append(dict(name='all-known-draft-refs-rehashed-'+p.name,status='PASS'))
# Fixed native_bound code transport and transfer set size; commands never embed map literals.
transport=[]
for d in v['deltas'][-2:]:
 t=ast.parse((HERE/d['output']).read_text());f=functions((HERE/d['output']).read_text())['native_bound']
 code=next(n.value.value for n in f.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='code' for x in n.targets))
 transport.append(dict(helper=d['output'],native_bound_fixed_code_utf8_bytes=len(code.encode()),native_argument_payload='canonical path plus SHA only; map payload returned on retained stdout',transfer='existing root_native_io.put stdin tar staging',io_sha256='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'))
# Rewrite only packet evidence; no external/campaign source/state writes.
(HERE/'declared-source-deltas-and-AST-verification.json').write_text(json.dumps(v,indent=2)+'\n')
save('final-source-verification.json',dict(status='SOURCE_ONLY_FINITE_CHECKS_PASS',accepted_by_root=False,qualification=False,checks=checks,transport=transport,campaign_imports=0,campaign_mains=0,native_commands=0,database_opens=0))
print(json.dumps(dict(status='SOURCE_ONLY_FINITE_CHECKS_PASS',checks=len(checks))))
