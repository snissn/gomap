"""SOURCE_ONLY_PREPARATION: finite read-only new raw closure and public-loader replay.
Future CLI: REQUEST REQUEST_SHA256 NEW_EXCLUSIVE_Q10_OUTPUT.
Only labelled diagnostic Inventory probes inherit predecessor accepted_by_root.
Inherited file keys remain exact; captured library aliases resolve without duplicate map identities.
No capture, prepare(), metadata enrichment, final analysis or raw acceptance.
"""
if not __debug__:
    raise RuntimeError("unoptimized Python required")
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
import types
sys.dont_write_bytecode = True
BASE = Path("/home/mikers/quicksilver-maintenance-5028-20261006")
ROOT = BASE/"qualification-v12-refresh/qualification-v10"
PINS = {
    "evaluator": "9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd",
    "consumer": "ccc5b23ed271b2bd814fc2678a7e4d99e72f0f381b4a39d37132ae570cdee97d",
    "support": "0f2590a04e3959110e5e5d6f5e2e350a7476a162cbe925939de52191a7efc810",
}


def require(ok, why):
    if not ok: raise ValueError(why)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""): h.update(block)
    return h.hexdigest()

def canonical(path):
    p = Path(path)
    require(p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p,
            "canonical regular file required: "+str(p))
    return p

def parse(raw):
    def unique(items):
        value = {}
        for key, item in items:
            require(key not in value, "duplicate JSON key")
            value[key] = item
        return value
    def invalid(value): raise ValueError("nonfinite JSON token: "+value)
    def finite(value):
        number = float(value)
        require(math.isfinite(number), "nonfinite JSON number")
        return number
    return json.loads(raw, object_pairs_hook=unique, parse_constant=invalid, parse_float=finite)

def bound(ref):
    require(set(ref)=={"path","sha256"}, "exact ref required")
    p = canonical(ref["path"])
    require(sha(p)==ref["sha256"], "bound SHA drift")
    return parse(p.read_bytes())

def reference(path): return dict(path=str(path), sha256=sha(path))

def flags(value):
    for name in ("qualification","performance_accepted","collection_authorized","merge_authorized"):
        require(value[name] is False, "forbidden authority: "+name)

def source(ref, name, expected):
    canonical(ref["path"])
    require(ref["sha256"]==expected and sha(ref["path"])==expected, "selected source identity")
    require(sys.pycache_prefix is None and not (Path(ref["path"]).parent/"__pycache__").exists(),
            "source cache forbidden")
    module = types.ModuleType(name); module.__file__ = ref["path"]
    exec(compile(Path(ref["path"]).read_bytes(), ref["path"], "exec"), module.__dict__)
    return module

def map_target(name):
    # Original Inventory resolves inherited spellings but rejects duplicate identities.
    require(isinstance(name,str), "inventory key must be text")
    captured=Path(name)
    require(captured.is_absolute(), "absolute inherited inventory key required")
    target=captured.resolve(strict=True)
    require(target.is_file() and not target.is_symlink(), "regular resolved inventory target required")
    return target

def check_map(files):
    resolved = set()
    require(isinstance(files,dict) and files, "complete actual raw map required")
    for name,digest in files.items():
        p = map_target(name)
        require(p not in resolved and isinstance(digest,str) and len(digest)==64 and
                all(c in "0123456789abcdef" for c in digest) and sha(name)==sha(p)==digest,
                "raw digest/duplicate canonical alias drift: "+name)
        resolved.add(p)
        if p.suffix==".py":
            canonical(name)
            require(not (p.parent/"__pycache__").exists(), "unbound source cache")
    return files

def add_map(files, name, digest):
    # Keep the established exact key, as original transition-v3 add_file does.
    target=map_target(name)
    require(sha(name)==sha(target)==digest, "dependency SHA drift")
    existing=[key for key in files if map_target(key)==target]
    require(len(existing)<=1, "duplicate canonical inventory aliases")
    if existing:
        key=existing[0]
        require(files[key]==digest, "canonical-equivalent dependency conflict")
        return key
    require(canonical(name)==target, "new map keys must be canonical")
    files[name]=digest
    return name

def add(files, ref):
    # Helper/request/source/control refs retain strict canonical spelling.
    canonical(ref["path"])
    return add_map(files,ref["path"],ref["sha256"])

def alias_record(captured, key, digest):
    target=map_target(captured)
    require(map_target(key)==target and sha(captured)==sha(target)==digest,
            "captured/canonical library identity drift")
    return dict(captured_path=captured,canonical_path=str(target),inventory_key=key,
        captured_sha256=digest,canonical_sha256=digest,
        captured_is_symlink=Path(captured).is_symlink(),
        captured_spelling_is_canonical=Path(captured)==target,
        alias_relation="identity" if Path(captured)==target else "captured-path-resolves-to-canonical-file")

def inherited_aliases(files):
    return [alias_record(name,name,digest) for name,digest in sorted(files.items())
            if Path(name)!=map_target(name)]

def library_observed(files, path, expected, aliases):
    # Captured native library spellings may contain real leaf/parent aliases.
    require(isinstance(path,str), "captured library path must be text")
    target=map_target(path)
    require(sha(path)==sha(target)==expected, "captured native library SHA drift")
    key=add_map(files,str(target),expected)
    record=alias_record(path,key,expected)
    require(path not in aliases or aliases[path]==record, "captured library alias relation conflict")
    aliases[path]=record
    return target

def rehash_aliases(files, records):
    for record in records:
        require(files.get(record["inventory_key"])==record["captured_sha256"] and
                alias_record(record["captured_path"],record["inventory_key"],record["captured_sha256"])==record,
                "captured/inherited alias relation changed during replay")

def save(path, value):
    with Path(path).open("xb") as stream:
        stream.write((json.dumps(value,indent=2,allow_nan=False)+"\n").encode())
    return reference(path)

PAIR_DRIVER_SHA="aa98083ab9ab2b19cb1bc90ecd562ec2c9e49314fafb28f2f3d8035bbb06bbe8"
HELPER_SELECTION_SHA="eaf90e128e43bbfee259f65a5e8866028899abb25e28877bd42c52afa6e8b7fd"
IMMUTABLE_PINS_SHA="2fccfac7a950aad6f397e15d94d5cc7b45d4b45ec5943d567c1a19e26cc4d406"
OPERATIONAL_GUARD_SHA="3afb3b02c11d7138cc9846489d34b39aa346333a8660dfb0f5e2ddf5daa359b6"
B_DEFINITION_SHA="4005f6369837ecb7000d3a89b86aeac361b3c9d07ccc323450b60bfa4fbd6219"
R_DEFINITION_SHA="cf1d1d0455e8cd2b1e50cb117b1af439a6d413287615e0b58ff1909fb29e00d7"
MANIFEST_SHA="fe243316b55e429a276a8a060607c8920973275c3e089125dbf66f13370a5092"
COMPOSITION_SHA="b9342c5a67c83d26046eaede93c223dd91e1427af51a3e4ba4c8e98cada2bfc9"
COLLECTION_SHAS={"R":"6835c2e5acc9120b9d555c88e7b06a78fe950fa59355d77b3a02ff3b4c56cbe9",
                 "B":"f05ac1dd8ace960cf0dc9914a0996f9b4d4e3ee43a6019d80e685c17d20f2043"}
SOURCE_HEADS={"A":"192e5019e579af3b98ae4fbf4ea497bb9ccd672f",
              "A_unified":"192e5019e579af3b98ae4fbf4ea497bb9ccd672f",
              "R":"6fa638b8bffa71750e1aefa0bb746bb747aa06c1",
              "R_unified":"6fa638b8bffa71750e1aefa0bb746bb747aa06c1",
              "B":"73100c5b8cc2337d9cff36c60a8e4182f1820fe9",
              "B_unified":"73100c5b8cc2337d9cff36c60a8e4182f1820fe9"}

def file_ref(path):
    return reference(canonical(path))

def read_file(path):
    return parse(canonical(path).read_bytes())

def observed(files,path,expected=None):
    ref=file_ref(path)
    if expected is not None:require(ref["sha256"]==expected,"captured dependency SHA drift")
    add(files,ref)
    return Path(ref["path"])

def merge(files,other):
    for path,digest in other.items():add_map(files,path,digest)

def regular_directory(path):
    p=Path(path)
    require(p.is_absolute() and p.is_dir() and not p.is_symlink() and p.resolve(strict=True)==p,
            "canonical directory required")
    return p

def immediate(files,folder):
    for path in sorted(regular_directory(folder).iterdir()):
        require(not path.is_symlink(),"symlink in raw immediate closure")
        if path.is_file():observed(files,path)

def no_overlap(out,directory):
    p=regular_directory(directory)
    require(not out.is_relative_to(p) and not p.is_relative_to(out),"output overlaps retained data/source")

def manifest_closure(files,path,aliases):
    manifest=read_file(observed(files,path))
    require(set(manifest["receipts"])=={"source","build","native","runner"},"exact common receipt roles")
    for role,ref in manifest["receipts"].items():
        receipt_path=ROOT/ref["path"] if Path(path)==ROOT/"manifest.json" else Path(path).parent/(role+"-receipt.json")
        data=read_file(observed(files,receipt_path,ref["sha256"]))
        if role=="build":
            for binary in data["binaries"].values():observed(files,binary["original_build_path"])
        if role=="source":
            for variant in data["variants"].values():observed(files,BASE/variant["tracked_manifest"])
    for source in manifest["sources"].values():observed(files,ROOT/"bin"/source["binary"],source["binary_sha256"])
    for library,value in manifest["libraries"].items():library_observed(files,library,value["sha256"],aliases)
    return manifest

def gather(files,plan,out,aliases):
    inventory=read_file(observed(files,ROOT/"inventory-complete.json"))
    root_manifest=manifest_closure(files,ROOT/"manifest.json",aliases)
    require(inventory["accepted_by_root"] is True and
            inventory["manifest_sha256"]==sha(ROOT/"manifest.json"),"common inventory/manifest drift")
    for role,head in SOURCE_HEADS.items():
        require(root_manifest["sources"][role]["head"]==head,"selected source head drift")
    collector=regular_directory(inventory["collector_source"])/"scripts"
    for name in ("owned_process_rss.py","unified_bench_quicksilver_capture.py","quicksilver_maintenance.py"):
        observed(files,collector/name)
    names=set()
    for group in plan["groups"]:
        names.update(group["calibration"]);names.update(group["runs"])
        slot=plan["slots"][group["cell"]+"-service-final"]
        names.update(slot["calibration"])
        names.update(pair[k] for pair in slot["pairs"] for k in ("A","B"))
    for name in sorted(names):
        path=observed(files,name);run=read_file(path)
        immediate(files,path.parent);immediate(files,path.parent.parent)
        manifest_closure(files,path.parent.parent/"manifest.json",aliases)
        directories=[path.parent/"db"]
        if run["cell"].get("measure_dir"):directories.append(Path(run["cell"]["measure_dir"]))
        if run["cell"].get("fixture"):directories.append(Path(run["cell"]["fixture"]))
        if "snapshot_restore" not in run:
            directories.append(Path(read_file(path.parent/"stdout.json")[0]["data_dir"]))
        for directory in directories:
            # Offline guard run dirs need not have a db subdir.
            if directory==path.parent/"db" and not directory.exists():
                require("snapshot_restore" not in run,"original offline DB absent")
                continue
            no_overlap(out,directory)
        artifacts=run.get("artifacts",{})
        require(isinstance(artifacts,dict),"run artifacts map required when present")
        for filename,digest in artifacts.items():
            require(isinstance(filename,str) and Path(filename).name==filename and filename not in (".",".."),
                    "artifact basename required")
            observed(files,path.parent/filename,digest)
        observed(files,run["command"][0],run["source"]["binary_sha256"])
        for library,digest in run["native_resolution"]["libraries"].items():library_observed(files,library,digest,aliases)
        if "snapshot_restore" in run:
            restore=run["snapshot_restore"]
            observed(files,restore["command"][0],restore["source"]["binary_sha256"])
            for library,digest in restore["native"]["native_resolution"]["libraries"].items():library_observed(files,library,digest,aliases)
        # Original controllers retain root plan/orchestration provenance.
        label=path.parent.parent.name
        root_plan=ROOT/"plans"/(label+".json")
        observed(files,root_plan,run["plan_sha256"])
        prefix="ar-orchestration-" if label.startswith(("ar-pairs-","ar-guard-")) else "orchestration-"
        folder=ROOT/"receipts"/(prefix+label)
        immediate(files,folder)
        command=read_file(folder/"run.json")
        require(command["rc"]==0 and command["root_owner"]=="/root" and
                command["plan_sha256"]==run["plan_sha256"] and command["manifest_sha256"]==run["manifest_sha256"],
                "original capture orchestration provenance drift")
        for channel in ("stdout","stderr"):observed(files,folder/(channel+".txt"),command[channel+"_sha256"])
    return root_manifest

def paired_receipts(req,ctx,files):
    activation=bound(req["paired_driver_activation"])
    joined=bound(req["paired_driver_completion"])
    driver=ctx["paired_driver"]
    require(driver["sha256"]==PAIR_DRIVER_SHA and
            driver["path"]==str(BASE/"qualification-v12-fresh-controls-v1/collection-native-driver-v12-v2.py"),
            "selected joined driver identity")
    observed(files,driver["path"],PAIR_DRIVER_SHA)
    require(set(joined)=={"schema","status","phase","rc","finished_ns","activation_sha256","qualification"},
            "complete original driver join schema required")
    expected_parent=Path(driver["path"]).parent/"collection-driver-pairs-v12"
    require(Path(req["paired_driver_completion"]["path"])==expected_parent/"complete.json" and
            joined["schema"]==1 and joined["status"]=="STAGE_JOINED_ROOT_CONTENT_REVIEW_REQUIRED" and
            joined["phase"]=="pairs" and type(joined["rc"]) is int and joined["rc"]==0 and joined["qualification"] is False and
            joined["activation_sha256"]==req["paired_driver_activation"]["sha256"],
            "actual joined paired completion required")
    require(activation["accepted_by_root"] is True and activation["collection_authorized"] is True and
            activation["qualification"] is False and activation["phase"]=="pairs" and
            activation["campaign_root"]==str(ROOT) and activation["held_excluded"]==[5004,5006] and
            activation["candidate_pair_collection_authorized"] is True and activation["driver"]==driver and
            activation["deployment"]==ctx["current_bindings"]["deployment"] and
            activation["global54_actual_content_acceptance"]==ctx["current_bindings"]["global54_actual_content_acceptance"] and
            activation["metadata_preservation_acceptance"]==req["metadata_preservation_acceptance"] and
            activation["root_launch_scope_now"]==["R-offline-pairs:all-original-six","B-offline-pairs:all-original-ten","B-online-pairs:all-original-three"],
            "actual pair activation binding drift")
    deployment=bound(activation["deployment"])
    selection_path=Path(driver["path"]).parent/"deployment-helpers-selection.json"
    selection=read_file(observed(files,selection_path,activation["helper_selection_sha256"]))
    require(activation["helper_selection_sha256"]==HELPER_SELECTION_SHA and
            deployment["accepted_by_root"] is True and deployment["qualification"] is False and
            deployment["collection_authorized"] is False and deployment["campaign_root"]==str(ROOT) and
            set(deployment["helpers"])==set(selection),"actual deployment helpers drift")
    for role,(name,digest) in selection.items():
        ref=deployment["helpers"][role]
        require(Path(ref["path"]).name==name and ref["sha256"]==digest,"deployment selected helper drift")
        add(files,ref)
    controllers=deployment["executed_controllers"]
    require(controllers=={role:deployment["helpers"][role+"_controller"] for role in ("R","B")} and
            {role:ref["sha256"] for role,ref in controllers.items()}==COLLECTION_SHAS,"exact original pair controllers")
    guard=activation["global54_guard"];guard_input=bound(activation["global54_input"])
    require(guard["sha256"]==OPERATIONAL_GUARD_SHA and
            guard["path"]==str(Path(driver["path"]).parent/"global54-artifact-guard-v12-operational-v1.py") and
            guard_input["guard"]==guard and guard_input["actual_global_content_acceptance"]==
                ctx["current_bindings"]["global54_actual_content_acceptance"],
            "original pre-first-pair guard binding drift")
    require(guard_input["accepted_by_root"] is True and guard_input["artifact_replay_authorized"] is True and
            guard_input["qualification"] is False and guard_input["collection_authorized"] is False and
            guard_input["candidate_pairs_authorized"] is False and guard_input["campaign_root"]==str(ROOT) and
            guard_input["held_excluded"]==[5004,5006] and guard_input["manifest_sha256"]==MANIFEST_SHA and
            guard_input["composition_sha256"]==COMPOSITION_SHA==ctx["composition_sha256"] and
            guard_input["deployment"]==activation["deployment"] and
            guard_input["calibration_activation"]==activation["calibration_activation"],"GLOBAL54 actual input scope drift")
    pin_path=BASE/"qualification-v10-global-deployment-preparation-v2/immutable-pins.json"
    pin_map=read_file(observed(files,pin_path,IMMUTABLE_PINS_SHA))
    for name,digest in pin_map.items():observed(files,BASE/name,digest)
    r_activation=bound(activation["R_activation"])
    require(r_activation["accepted_by_root"] is True and r_activation["collection_authorized"] is True and
            r_activation["qualification"] is False and r_activation["campaign_root"]==str(ROOT) and
            r_activation["held_excluded"]==[5004,5006],"actual R activation drift")
    require(r_activation["metadata_preservation_acceptance"]==req["metadata_preservation_acceptance"] and
            r_activation["global54_actual_content_acceptance"]==ctx["current_bindings"]["global54_actual_content_acceptance"],
            "R actual preservation/GLOBAL54 binding drift")
    for ref in (req["paired_driver_activation"],req["paired_driver_completion"],activation["deployment"],
                activation["calibration_activation"],guard,activation["global54_input"],activation["R_activation"]):
        add(files,ref)
    calibration=bound(activation["calibration_activation"])
    require(calibration["accepted_by_root"] is True and calibration["collection_authorized"] is True and
            calibration["qualification"] is False and calibration["candidate_pair_collection_authorized"] is False and
            calibration["deployment_binding"]==activation["deployment"],"calibration predecessor drift")
    for key in ("prospective_binding","deployment_verifier"):
        add(files,calibration[key])
    calibration_ref=dict(path=calibration["anchor"],sha256=calibration["anchor_sha256"])
    calibration_anchor=bound(calibration_ref)
    require(calibration_anchor["accepted_by_root"] is True and calibration_anchor["root"]==str(ROOT),
            "accepted calibration source predecessor required")
    # Mirror the v11 driver current-source predecessor/calibration closure gates.
    current_ref=activation["current_pair_source_anchor"]
    predecessor_ref=activation["current_pair_source_predecessor"]
    current=bound(current_ref);predecessor=bound(predecessor_ref)
    require(current["schema"]==predecessor["schema"]==1 and
            current["accepted_by_root"] is True and predecessor["accepted_by_root"] is True and
            current["root"]==predecessor["root"]==str(ROOT),"current pair source ancestry required")
    check_map(current["files"]);check_map(predecessor["files"])
    require(current["files"].get(predecessor_ref["path"])==predecessor_ref["sha256"] and
            all(current["files"].get(path)==digest for path,digest in predecessor["files"].items()) and
            current["files"].get(calibration_ref["path"])==calibration_ref["sha256"] and
            all(current["files"].get(path)==digest for path,digest in calibration_anchor["files"].items()),
            "complete exact predecessor/calibration source closure required")
    require(calibration_anchor["files"].get(driver["path"])==PAIR_DRIVER_SHA and
            calibration_anchor["files"].get(str(selection_path))==HELPER_SELECTION_SHA and
            current["files"].get(driver["path"])==PAIR_DRIVER_SHA and
            current["files"].get(str(selection_path))==HELPER_SELECTION_SHA and
            current["files"].get(guard["path"])==OPERATIONAL_GUARD_SHA,
            "current selected driver/selector/guard source closure drift")
    require(guard_input["R_anchor"]==current_ref and
            dict(path=r_activation["anchor"],sha256=r_activation["anchor_sha256"])==current_ref,
            "current full R source/GLOBAL54/R activation selector drift")
    merge(files,current["files"])
    add(files,current_ref);add(files,predecessor_ref)
    merge(files,calibration_anchor["files"])
    add(files,calibration_ref)
    add(files,dict(path=r_activation["anchor"],sha256=r_activation["anchor_sha256"]))
    expected={
        "global54-before-first-pair":["python3","-B",guard["path"],activation["global54_input"]["path"],activation["global54_input"]["sha256"]],
        "R-offline-pairs":["python3","-B",controllers["R"]["path"],"offline-pairs",activation["R_activation"]["path"],activation["R_activation"]["sha256"]],
        "B-offline-pairs":["python3","-B",controllers["B"]["path"],"offline-pairs"],
        "B-online-pairs":["python3","-B",controllers["B"]["path"],"online-pairs"]}
    records={};previous=None
    for label,argv in expected.items():
        folder=expected_parent/label;immediate(files,folder)
        start=read_file(folder/"started.json");complete=read_file(folder/"complete.json")
        require(set(start)=={"schema","argv","started_ns","owner","driver_pid","activation_sha256","load_before","qualification","phase"} and
                all(complete.get(k)==v for k,v in start.items()) and complete["schema"]==1 and
                type(complete["driver_pid"]) is int and complete["driver_pid"]>0 and
                type(complete["pid"]) is int and complete["pid"]>0 and
                complete["argv"]==argv and complete["phase"]=="pairs" and complete["qualification"] is False and
                complete["owner"]=="/root" and complete["activation_sha256"]==req["paired_driver_activation"]["sha256"] and
                type(complete["rc"]) is int and complete["rc"]==0 and complete["raw_hashes_final"] is True and
                not any(complete.get(k) for k in ("error","timeout","cleanup_error")),"complete joined command required")
        cleanup=complete["process_group_cleanup"]
        require(cleanup["quiescent"] is True and cleanup["direct_child_joined"] is True and
                cleanup["pgid"]==complete["pid"] and not cleanup["signal_errors"],"joined process cleanup required")
        lo,hi=complete["started_ns"],complete["finished_ns"]
        require(type(lo) is int and type(hi) is int and 0<lo<hi and
                (previous is None or previous<=lo),"serial command intervals required")
        previous=hi
        for channel in ("stdout","stderr"):observed(files,folder/(channel+".txt"),complete[channel+"_sha256"])
        records[label]=complete
    require(type(joined["finished_ns"]) is int and previous<=joined["finished_ns"]<=req["joined_ns"]<time.time_ns(),
            "actual joined chronology drift")
    global_result=read_file(expected_parent/"global54-before-first-pair/stdout.txt")
    require(global_result["status"]=="GLOBAL54_ARTIFACT_REPLAY_COMPLETE_ROOT_LAUNCH_STILL_REQUIRED" and
            (global_result["baseline_captures"],global_result["guard_captures"],global_result["B_slots"],global_result["R_slots"])==(39,39,36,18) and
            global_result["qualification"] is False and global_result["candidate_pairs_authorized"] is False,
            "actual original GLOBAL54 replay result required")
    return joined,records

def diagnostic(original,files,predecessor,reqref):
    result=copy.deepcopy(original);result["files"]=dict(files)
    result.update(inherited_inventory_reader_compatibility_only=True,diagnostic_raw_replay_only=True,
        raw_contents_accepted=False,analysis_authorized=False,qualification=False,performance_accepted=False,
        collection_authorized=False,candidate_pairs_authorized=False,candidate_pair_collection_authorized=False,merge_authorized=False,
        diagnostic_request=reqref,diagnostic_predecessor_anchor=predecessor,
        inherited_acceptance_provenance="All inherited acceptance fields and times describe the pre-pair predecessor only; no new raw-content acceptance.")
    require(result["accepted_by_root"] is True,"accepted predecessor reader flag required")
    return result

def main():
    require(len(sys.argv)==4 and sys.flags.dont_write_bytecode and sys.pycache_prefix is None and
            "PYTHONPYCACHEPREFIX" not in os.environ,"python3 -B without source cache prefix required")
    reqref=dict(path=sys.argv[1],sha256=sys.argv[2]);req=bound(reqref);flags(req)
    require(req["schema"]==1 and req["accepted_by_root"] is True and
            req["read_only_raw_closure_authorized"] is True and req["diagnostic_inventory_creation"] is True and
            req["serial_and_quiescent"] is True and req["candidate_pairs_authorized"] is False and
            req["campaign_root"]==str(ROOT) and req["held_excluded"]==[5004,5006] and
            type(req["joined_ns"]) is int and req["joined_ns"]>0,"actual finite diagnostic request required")
    require(req["helper"]==reference(canonical(__file__)),"helper selection drift")
    selected=bound(req["helper_source_acceptance"]);flags(selected)
    require(selected["accepted_by_root"] is True and selected["helper"]==req["helper"] and
            selected["campaign_root"]==str(ROOT) and selected["diagnostic_inventory_creation"] is True and
            selected["independent_source_review"]==req["independent_source_review"],
            "actual root source review and diagnostic scope required")
    review=canonical(req["independent_source_review"]["path"])
    require(sha(review)==req["independent_source_review"]["sha256"],"independent source review drift")
    ctx=req["strict_context"]
    out=Path(sys.argv[3])
    require(ROOT.is_dir() and ROOT.resolve()==ROOT and not ROOT.is_symlink() and
            out.is_absolute() and out.resolve()==out and out.parent==ROOT and
            out.name.startswith("raw-closure-") and not out.exists() and not out.is_symlink(),
            "new exclusive canonical Q10 diagnostic output required")
    require(ROOT.is_dir() and ROOT.resolve()==ROOT and not ROOT.is_symlink(), "canonical campaign root")
    require(set(ctx["current_bindings"])=={"source_freeze","deployment","applicability","global54_actual_content_acceptance"},
            "exact current binding roles")
    require(ctx["analysis_directories"]==dict(B=str(ROOT/"analysis-global-original-v1"),
            R=str(ROOT/"ar-analysis-global-original-v1")), "original analysis directories required")
    acceptance = bound(req["metadata_preservation_acceptance"])
    receipt = bound(acceptance["receipt"])
    global_ref = ctx["current_bindings"]["global54_actual_content_acceptance"]
    global_accept = bound(global_ref)
    require(acceptance["accepted_by_root"] is True and acceptance["metadata_preservation_actual_contents_accepted"] is True and
            acceptance["qualification"] is False and acceptance["collection_authorized"] is False and
            acceptance["performance_accepted"] is False and acceptance["no_pair_namespace_at_acceptance"] is True and
            acceptance["campaign_root"]==str(ROOT) and acceptance["held_excluded"]==[5004,5006],
            "actual physical preservation acceptance required")
    require(receipt["accepted_by_root"] is False and receipt["status"]=="PRESERVED_BYTES_ROOT_ACCEPTANCE_PENDING" and
            receipt["schema"]==1 and receipt["qualification"] is False and receipt["collection_authorized"] is False and
            receipt["campaign_root"]==str(ROOT) and receipt["held_excluded"]==[5004,5006] and
            receipt["no_pair_namespace_at_completion"] is True and receipt["consumer"]==ctx["consumer"] and
            receipt["global54_actual_content_acceptance"]==global_ref and
            acceptance["original_anchors"]==receipt["original_anchors"] and
            acceptance["mapping"]==receipt["mapping"] and acceptance["consumer"]==receipt["consumer"] and
            acceptance["request"]==receipt["request"] and
            acceptance["preserved_completed_ns"]==receipt["completed_ns"], "preservation provenance drift")
    originals = {role:bound(ref) for role,ref in receipt["retained_anchors"].items()}
    require(set(originals)=={"B","R"} and receipt["original_anchors"]["R"]==global_accept["R_anchor"] and
            global_accept["files"]==originals["R"]["files"] and global_accept["accepted_by_root"] is True and
            global_accept["global54_actual_contents_accepted"] is True and global_accept["qualification"] is False and
            global_accept["performance_accepted"] is False and
            receipt["original_anchors"]["B"]==dict(path=originals["R"]["original_B_anchor"],
            sha256=originals["R"]["original_B_anchor_sha256"]), "original full selectors drift")
    for role in ("B","R"):
        require(receipt["retained_anchors"][role]["sha256"]==receipt["original_anchors"][role]["sha256"] and
                originals[role]==bound(receipt["original_anchors"][role]), "original anchor byte drift")
        require(originals[role]["root"]==str(ROOT), "original campaign root drift")
        check_map(originals[role]["files"])
    require(all(originals["R"]["files"].get(p)==d for p,d in originals["B"]["files"].items()),
            "full original B closure not inherited by canonical R")
    # Cache and complete source identity checks precede any imported source execution.
    for key in ("evaluator","consumer","support"):
        require(originals["R"]["files"].get(ctx[key]["path"])==PINS[key], "original source closure")
    ev = source(ctx["evaluator"],"raw_closure_original_evaluator",PINS["evaluator"])
    strict = source(ctx["consumer"],"raw_closure_frozen_consumer",PINS["consumer"])
    original_invs = {role:ev.Inventory(ref["path"],ref["sha256"]) for role,ref in receipt["original_anchors"].items()}
    drivers = strict.original_drivers(original_invs["R"],ctx,"raw_closure_original_")
    plans,mutable = strict.layout_metadata(ROOT,ctx,originals,drivers)
    require(len(mutable)==34 and set(receipt["mapping"])==set(mutable), "exact32+2 mapping required")
    copies = set()
    physical = {role:ev.Inventory(ref["path"],ref["sha256"]) for role,ref in acceptance["physical_anchors"].items()}
    require(set(physical)=={"B","R"}, "both physical anchors required")
    for role in ("B","R"):
        expected = strict.physical_anchor(originals[role],receipt["mapping"],role,
                                         acceptance["physical_anchors"]["B"] if role=="R" else None)
        require(physical[role].anchor==expected, "physical full-map transformation drift")
        require(Path(acceptance["receipt"]["path"]).parent.parent==ROOT and
                Path(receipt["drafts"][role]["path"])==Path(acceptance["receipt"]["path"]).parent/
                    ("physical-"+role+"-anchor.draft.json") and
                Path(receipt["retained_anchors"][role]["path"])==Path(acceptance["receipt"]["path"]).parent/
                    ("original-"+role+"-anchor.json"), "physical provenance path drift")
        draft_expected = copy.deepcopy(expected);draft_expected["accepted_by_root"]=False
        if role=="R":
            draft_expected["files"].pop(acceptance["physical_anchors"]["B"]["path"])
            draft_expected["files"][receipt["drafts"]["B"]["path"]]=receipt["drafts"]["B"]["sha256"]
            draft_expected["original_B_anchor"]=receipt["drafts"]["B"]["path"]
            draft_expected["original_B_anchor_sha256"]=receipt["drafts"]["B"]["sha256"]
        require(bound(receipt["drafts"][role])==draft_expected, "physical draft acceptance transformation drift")
    require(bound(receipt["retained_global54_acceptance"])==global_accept and
            receipt["retained_global54_acceptance"]["sha256"]==global_ref["sha256"] and
            acceptance["global54_actual_content_acceptance"]==global_ref and
            receipt["prospective_rule_freeze"]==ctx["prospective_rule_freeze"] and
            receipt["request_sha256"]==receipt["request"]["sha256"], "retained GLOBAL54/request/rule drift")
    copy_request = bound(receipt["request"])
    require(copy_request["schema"]==1 and copy_request["accepted_by_root"] is True and
            copy_request["artifact_io_authorized"] is True and copy_request["qualification"] is False and
            copy_request["collection_authorized"] is False and
            copy_request["global54_actual_content_acceptance"]==global_ref,
            "actual preservation copy request required")
    for key in ("consumer","evaluator","drivers","support","analysis_directories","prospective_rule_freeze"):
        require(copy_request[key]==ctx[key], "preservation source/request substitution")
    source_refs = [ctx[k] for k in ("evaluator","definition","consumer","witness","policy","prospective_rule_freeze",
            "support","global_replay_helper")]+list(ctx["drivers"].values())+[
            ctx["current_bindings"][k] for k in ("source_freeze","deployment","applicability")]
    for ref in source_refs:
        require(sha(physical["R"].local(Path(ref["path"])))==ref["sha256"],
                "source/control absent from accepted physical pre-pair closure")
    for number,path in enumerate(sorted(mutable)):
        item = mutable[path]; record = receipt["mapping"][path]; saved = bound(record["copy"])
        require(set(record)=={"role","kind","original_sha256","copy"} and record["role"]==item["role"] and record["kind"]==item["kind"] and
                record["original_sha256"]==record["copy"]["sha256"]==originals["R"]["files"][path] and
                Path(record["copy"]["path"])==Path(acceptance["receipt"]["path"]).parent/
                    (str(number).zfill(2)+"-"+Path(path).name) and record["copy"]["path"] not in copies and
                record["copy"]["path"] not in originals["R"]["files"] and
                sha(canonical(path))==record["original_sha256"], "immutable exact copy/current metadata drift")
        copies.add(record["copy"]["path"])
        if item["kind"]=="offline":
            require(saved==item["expected"], "unresolved offline layout drift")
        else:
            C = {k:v for k,v in item["expected"].items() if Path(v["original_run"]).parent.name.split("-")[-1].startswith("C")}
            require(saved["runs"]==C and all(saved[k] is True for k in
                    ("accepted_by_root","inplace_no_reload_restore","before_after_census_retained")),
                    "original complete C origins required")

    require(len(plans["B"]["groups"])==13 and len(plans["B"]["slots"])==36 and
            len(plans["R"]["groups"])==6 and len(plans["R"]["slots"])==18 and
            len(plans["B"]["origins"])==117 and len(plans["R"]["origins"])==54,"complete original layouts required")
    require(originals["B"]["files"][originals["B"]["definition"]]==B_DEFINITION_SHA and
            originals["R"]["files"][originals["R"]["definition"]]==R_DEFINITION_SHA and
            ctx["R_definition_sha256"]==R_DEFINITION_SHA,"selected original definitions")
    maps={role:dict(originals[role]["files"]) for role in ("B","R")}
    inherited={role:inherited_aliases(originals[role]["files"]) for role in ("B","R")}
    library_aliases={role:{} for role in ("B","R")}
    for role in ("B","R"):
        gather(maps[role],plans[role],out,library_aliases[role])
    merge(maps["R"],maps["B"])
    for path,record in library_aliases["B"].items():
        require(path not in library_aliases["R"] or library_aliases["R"][path]==record,
                "B/R captured library relation conflict")
        library_aliases["R"][path]=dict(record)
    dependencies=[reqref,req["helper"],req["helper_source_acceptance"],req["independent_source_review"],
        req["metadata_preservation_acceptance"],acceptance["receipt"],receipt["request"],
        *acceptance["physical_anchors"].values(),*receipt["drafts"].values(),
        *receipt["retained_anchors"].values(),receipt["retained_global54_acceptance"],
        *receipt["original_anchors"].values(),global_ref,*ctx["current_bindings"].values(),
        *source_refs,*[record["copy"] for record in receipt["mapping"].values()]]
    for ref in dependencies:add(maps["R"],ref)
    joined,commands=paired_receipts(req,ctx,maps["R"])
    r_activation=bound(bound(req["paired_driver_activation"])["R_activation"])
    require(dict(path=r_activation["anchor"],sha256=r_activation["anchor_sha256"])==receipt["original_anchors"]["R"],
            "R pair activation did not select full original canonical R")
    require(bound(bound(req["paired_driver_activation"])["global54_input"])["R_anchor"]==receipt["original_anchors"]["R"],
            "pre-first-pair guard selected another R closure")
    for role in ("B","R"):
        for p,d in originals[role]["files"].items():require(maps[role].get(p)==d,"prior closure drift")
        check_map(maps[role])
    require(all(maps["R"].get(p)==d for p,d in maps["B"].items()),"R must inherit full B")
    # Cache/identity closure checks occur before original collector imports.
    for role in ("B","R"):
        for path in maps[role]:
            if path.endswith(".py"):no_overlap(out,Path(path).parent)
    for name in originals["R"]["harness_files"].values():
        require(originals["R"]["files"].get(name)==maps["R"].get(name),"original harness source drift")
    out.mkdir();started=time.time_ns()
    Bprobe=diagnostic(originals["B"],maps["B"],receipt["original_anchors"]["B"],reqref)
    Bref=save(out/"diagnostic-B-inventory.json",Bprobe)
    Rprobe=diagnostic(originals["R"],maps["R"],receipt["original_anchors"]["R"],reqref)
    add(Rprobe["files"],Bref)
    Rprobe["original_B_anchor"]=Bref["path"];Rprobe["original_B_anchor_sha256"]=Bref["sha256"]
    Rref=save(out/"diagnostic-R-inventory.json",Rprobe)
    ev.Inventory(Bref["path"],Bref["sha256"])
    inv=ev.Inventory(Rref["path"],Rref["sha256"])
    support=source(ctx["support"],"raw_closure_original_support",PINS["support"])
    support.verify_prerequisites(inv,ev,inv.json(inv.anchor["definition"]),pairs=True)
    collector,maintenance=ev.load_collectors(inv)
    common=ev.load_original(inv,collector,maintenance,plans["B"]["groups"][0]["calibration"][0],
                            plans["B"]["groups"][0]["kind"])["common_inventory"]
    intervals=[];seen_runs=set();seen_guards=set();counts={}
    for role,plan in plans.items():
        original_count=guard_count=0
        for group in plan["groups"]:
            pairs=ev.original_pairs(inv,collector,maintenance,group,common)
            slot=plan["slots"][group["cell"]+"-service-final"]
            guard_contract=ev.contract(ev.load_run(inv,collector,slot["calibration"][0]))
            guards=[ev.load_run(inv,collector,pair[k]) for pair in slot["pairs"] for k in ("A","B")]
            originals_by_name={packet["name"]:packet for packet in pairs}
            require(len(originals_by_name)==6 and len(guards)==6,"exact six originals and six guards per group")
            command_label="R-offline-pairs" if role=="R" else ("B-online-pairs" if group["kind"]=="online" else "B-offline-pairs")
            command=commands[command_label]
            for packet in pairs:
                require(packet["name"] not in seen_runs,"pair reuse");seen_runs.add(packet["name"]);original_count+=1
                require(command["started_ns"]<=packet["started_ns"]<packet["finished_ns"]<=command["finished_ns"],
                        "pair outside own joined driver interval")
                intervals.append(dict(role=role,kind="original",name=packet["name"],started_ns=packet["started_ns"],
                                      finished_ns=packet["finished_ns"],driver_command=command_label))
            for guard in guards:
                require(guard["name"] not in seen_guards,"guard reuse");seen_guards.add(guard["name"]);guard_count+=1
                origin=plan["origins"][guard["name"]];original=originals_by_name[origin["original_run"]]
                directory=regular_directory(original["directory"])
                require(directory==regular_directory(origin["directory"])==
                        regular_directory(guard["run"]["cell"]["measure_dir"]) and
                        original["run"]["cell"]["label"]==guard["run"]["cell"]["label"] and
                        original["run"]["source"]["head"]==guard["run"]["source"]["head"] and
                        original["common_inventory"]==ev.common_inventory(inv,guard["name"],guard["run"]) and
                        ev.contract(guard)==guard_contract,"paired guard origin/source/common/contract drift")
                lo,hi=int(guard["run"]["started"]*1e9),int(guard["run"]["finished"]*1e9)
                require(original["finished_ns"]<lo and command["started_ns"]<=lo<hi<=command["finished_ns"],
                        "guard original/driver chronology drift")
                intervals.append(dict(role=role,kind="guard",name=guard["name"],original=origin["original_run"],
                                      directory=str(directory),started_ns=lo,finished_ns=hi,driver_command=command_label))
        counts[role]=dict(originals=original_count,guards=guard_count)
    require(counts==dict(B=dict(originals=78,guards=78),R=dict(originals=36,guards=36)) and
            len(seen_runs)==len(seen_guards)==114 and not seen_runs&seen_guards,"114+114 complete raw identity bound")
    intervals.sort(key=lambda row:(row["started_ns"],row["finished_ns"],row["name"]))
    require(all(a["finished_ns"]<=b["started_ns"] for a,b in zip(intervals,intervals[1:])),
            "globally serial original/guard intervals required")
    require(0<global_accept["accepted_ns"]<=receipt["started_ns"]<=receipt["completed_ns"]<=
            acceptance["accepted_ns"]<intervals[0]["started_ns"] and
            intervals[-1]["finished_ns"]<=joined["finished_ns"]<=req["joined_ns"],
            "genuine pre-pair preservation/join chronology required")
    for role,plan in plans.items():
        gate=inv.json(originals[role]["global_calibration_gate"])
        require(type(gate["frozen_ns"]) is int and gate["frozen_ns"]<intervals[0]["started_ns"],
                "original global freeze must precede every pair")
    require(acceptance["accepted_ns"]<commands["global54-before-first-pair"]["started_ns"],
            "preservation acceptance must precede actual pre-first-pair guard")
    # No original metadata/source/receipt/raw byte changed across diagnostic replay.
    for role,files in maps.items():
        check_map(files)
        rehash_aliases(files,inherited[role])
        rehash_aliases(files,library_aliases[role].values())
    for path,record in receipt["mapping"].items():
        require(sha(canonical(path))==record["original_sha256"]==sha(canonical(record["copy"]["path"])),
                "original34/preserved copy drift")
    require(file_ref(Bref["path"])==Bref and file_ref(Rref["path"])==Rref,"diagnostic probe drift")
    completed=time.time_ns()
    packet=dict(schema=1,status="ROOT_CONTENT_REVIEW_PENDING",accepted_by_root=False,raw_contents_accepted=False,
        qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,
        merge_authorized=False,analysis_authorized=False,campaign_root=str(ROOT),held_excluded=[5004,5006],
        files=maps,original_pair_count=114,state_specific_guard_count=114,counts=counts,
        request=reqref,helper=req["helper"],helper_source_acceptance=req["helper_source_acceptance"],
        independent_source_review=req["independent_source_review"],metadata_preservation_acceptance=req["metadata_preservation_acceptance"],
        paired_driver_completion=req["paired_driver_completion"],paired_driver_activation=req["paired_driver_activation"],
        diagnostic_inventories=dict(B=Bref,R=Rref),intervals=intervals,
        inherited_inventory_aliases=inherited,
        captured_library_identities={role:[rows[path] for path in sorted(rows)]
                                     for role,rows in library_aliases.items()},
        joined_ns=req["joined_ns"],started_ns=started,diagnostic_completed_ns=completed,
        reviewed_ns=None,raw_contents_accepted_ns=None,root_review_required=True,
        serial_and_quiescent=req["serial_and_quiescent"],serial_quiescence_basis="Actual root request plus exact joined command cleanup receipts; no live process inspection.",
        original34_unchanged=True,final_metadata_io_separate=True,original_analysis_separate=True)
    packet_ref=save(out/"raw-closure.pending-root-review.json",packet)
    print(json.dumps(dict(status="ROOT_CONTENT_REVIEW_PENDING",accepted_by_root=False,packet=packet_ref,
        qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,
        merge_authorized=False),allow_nan=False))

if __name__=="__main__":
    main()
