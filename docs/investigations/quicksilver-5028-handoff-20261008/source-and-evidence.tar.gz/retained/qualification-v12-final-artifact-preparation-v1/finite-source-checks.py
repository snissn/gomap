"""Finite AST-extracted checks only; never imports campaign modules or invokes mains."""
from pathlib import Path
import ast,copy,hashlib,json,types
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
checks=[]
def check(name,fn):
    fn();checks.append(dict(name=name,status='PASS'))
def reject(name,fn):
    try:fn()
    except (AssertionError,ValueError,KeyError):checks.append(dict(name=name,status='PASS'));return
    raise AssertionError('unexpected acceptance: '+name)
def extract(path,names,env):
    tree=ast.parse(path.read_bytes());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    assert {n.name for n in nodes}==set(names)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),env);return env
content=HERE/'root-final-content-acceptance-v12-v1.py';wrapper=HERE/'root-run-final-evaluation-v12-v1.py'
for path in (content,wrapper):check('compile-'+path.name,lambda path=path:compile(path.read_bytes(),str(path),'exec'))
env=extract(content,('no_authority','top_level_unchanged'),{})
flags={k:False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized')}
check('all-authority-false',lambda:env['no_authority'](flags))
for key in flags:reject('reject-authority-'+key,lambda key=key:env['no_authority'](dict(flags,**{key:True})))
old=dict(files={'old':'hash'},created_ns=1,pairs=0,original_B_anchor='oldB',original_B_anchor_sha256='oldhash')
for role in ('B','R'):
    final=copy.deepcopy(old);final['files']={'new':'newhash'}
    if role=='R':final.update(original_B_anchor='newB',original_B_anchor_sha256='newBhash')
    check('exact-files-selector-change-'+role,lambda role=role,final=final:env['top_level_unchanged'](old,final,role))
    for key in ('created_ns','pairs'):
        drift=copy.deepcopy(final);drift[key]+=1
        reject('reject-top-'+role+'-'+key,lambda role=role,drift=drift:env['top_level_unchanged'](old,drift,role))
    drift=dict(final,new_field=1);reject('reject-new-field-'+role,lambda role=role,drift=drift:env['top_level_unchanged'](old,drift,role))
drift=dict(old,original_B_anchor='other');reject('reject-B-selector',lambda:env['top_level_unchanged'](old,drift,'B'))
N=Path('/home/mikers/quicksilver-maintenance-5028-20261006');ROOT=N/'qualification-v12-refresh/qualification-v10'
wenv=extract(wrapper,('original_argv','verify_original_completion','copy_context'),dict(Path=Path,json=json,ROOT=ROOT,BD=N/'qualification-analysis-controller.py',RD=N/'r-material-gate-preparation-v2/r-analysis-controller.py'))
anchors={role:dict(path=str(ROOT/('final-'+role+'.json')),sha256=role*64) for role in ('B','R')};definition=dict(path=str(N/'R-definition.json'),sha256='d'*64)
for role in ('B','R'):
    argv=wenv['original_argv'](role,anchors,definition)
    check('full-original-cli-'+role,lambda argv=argv:None if 'final-evaluate' in argv and '--cell' not in argv and '--prepare' not in argv else (_ for _ in ()).throw(AssertionError()))
    assert argv[-4:]==['--anchor',anchors[role]['path'],'--anchor-sha256',anchors[role]['sha256']]
    if role=='R':assert argv[argv.index('--original-B-anchor')+1]==anchors['B']['path'] and argv[argv.index('--definition')+1]==definition['path']
fixture=HERE/'finite-fixtures';fixture.mkdir(exist_ok=True)
data={};plans={};runs={};evals={}
def ref(path):return dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
for index,role in enumerate(('B','R')):
    slots={f'{role}-{i:02}':{} for i in range(36 if role=='B' else 18)};plans[role]=dict(slots=slots,out=fixture/role);evals[role]={}
    for name in slots:
        rr=dict(path=str(fixture/role/(name+'.evaluation.json')),sha256='e'*64);evals[role][name]=rr;data[rr['path']]=dict(qualification=False,root_acceptance_required=True,ledger=[dict(status='unknown',E=None)])
    stream=fixture/(role+'.stdout.json');stream.write_text(json.dumps(dict(status='analysis_complete_root_review_required',stage='final-evaluate',slots=sorted(slots),qualification=False))+'\n')
    stderr=fixture/(role+'.stderr.txt');stderr.write_bytes(b'')
    row=dict(native_argv=wenv['original_argv'](role,anchors,definition),rc=0,started_ns=1+index*3,finished_ns=2+index*3,stdout=dict(ref(stream),bytes=stream.stat().st_size),stderr=dict(ref(stderr),bytes=0))
    rr=dict(path=str(fixture/(role+'.execution.json')),sha256='f'*64);runs[role]=rr;data[rr['path']]=row
m=types.SimpleNamespace(bound=lambda rr:data[rr['path']],canonical=lambda path:Path(path),sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest(),parse=lambda raw:json.loads(raw))
value=dict(flags,status='ORIGINAL_FULL_B_R_JOINED_ROOT_REVIEW_REQUIRED',accepted_by_root=False,campaign_root=str(ROOT),held_excluded=[5004,5006],final_anchors=anchors,executions=runs,evaluations=evals,completed_ns=7)
verify=lambda value=value:wenv['verify_original_completion'](m,value,anchors,plans,definition)
check('complete-B36-R18-original-before-strict',verify)
for role in ('B','R'):
    rr=runs[role];row=data[rr['path']];prior=copy.deepcopy(row)
    for label,mutator in [('prepare',lambda r:r['native_argv'].append('--prepare')),('bad-rc',lambda r:r.update(rc=1)),('stream-digest',lambda r:r['stdout'].update(sha256='0'*64)),('stream-size',lambda r:r['stdout'].update(bytes=0))]:
        mutator(row);reject('reject-'+role+'-'+label,verify);row.clear();row.update(copy.deepcopy(prior))
    name=next(iter(evals[role]));saved=evals[role].pop(name);reject('reject-missing-slot-'+role,verify);evals[role][name]=saved
row=data[runs['R']['path']];oldstart=row['started_ns'];row['started_ns']=1;reject('reject-B-R-overlap',verify);row['started_ns']=oldstart
for name in ('final-content-request.draft.json','original-evaluation-request.draft.json','strict-evaluation-request.draft.json','strict-replay-request.draft.json'):
    v=json.loads((HERE/name).read_text());check('draft-unaccepted-'+name,lambda v=v:None if v['accepted_by_root'] is False and v.get('authorized_ns') is None else (_ for _ in ()).throw(AssertionError()))
    for k in flags:
        if k in v:assert v[k] is False
    assert v['status']=='SOURCE_ONLY_NOT_EXECUTABLE'
assert all(v is None for c in json.loads((HERE/'launch-argv.draft.json').read_text())['commands'] for v in c['argv'][3:]);checks.append(dict(name='all-future-launch-operands-null',status='PASS'))
wt=ast.parse(wrapper.read_bytes());constants={n.targets[0].id:ast.literal_eval(n.value) for n in wt.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and isinstance(n.value,ast.Constant)}
assert constants['CONTENT_SHA']==hashlib.sha256(content.read_bytes()).hexdigest();checks.append(dict(name='wrapper-exact-content-source-pin',status='PASS'))
root_tree=ast.parse((HERE/'root-run-final-raw-and-metadata-v12-v1.py').read_bytes())
root_outcomes=[n.value for n in ast.walk(root_tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='outcome' for t in n.targets)]
assert len(root_outcomes)==1
expected={k.arg for k in root_outcomes[0].keywords}
sets=[n.value for n in ast.walk(ast.parse(content.read_bytes())) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='outcome_keys' for t in n.targets)]
assert len(sets)==1 and ast.literal_eval(sets[0])==expected;checks.append(dict(name='exact-current-root-outcome-schema',status='PASS'))
value=dict(a=[{'x':1}]);copied=wenv['copy_context'](value);copied['a'][0]['x']=2;assert value['a'][0]['x']==1;checks.append(dict(name='strict-context-copy-isolated',status='PASS'))
metadata_tree=ast.parse((HERE/'root-final-metadata-io-v12-v1.py').read_bytes())
md={n.name:n for n in metadata_tree.body if isinstance(n,ast.FunctionDef)}
required={'canonical':1,'parse':1,'bound':1,'flags':1,'source':3,'check_map':1,'save':2,'reference':1,'sha':1}
assert all(name in md and len(md[name].args.args)==argc for name,argc in required.items());checks.append(dict(name='reviewed-metadata-API-exact-signatures',status='PASS'))
strict_tree=ast.parse((BASE/'prospective-strict-latency-guard-consumer-v5/strict_latency_guard_consumer.py').read_bytes());sd={n.name:n for n in strict_tree.body if isinstance(n,ast.FunctionDef)}
assert all(len(sd[name].args.args)==argc for name,argc in {'pre_pair_inventory':3,'original_drivers':3,'layout_metadata':4}.items());checks.append(dict(name='CCC5-selected-reuse-API-signatures',status='PASS'))
ret=next(n.value for n in ast.walk(sd['pre_pair_inventory']) if isinstance(n,ast.Return))
assert isinstance(ret,ast.Call) and {'physical','originals','acceptance','receipt','expected_offline','B_final'}=={k.arg for k in ret.keywords};checks.append(dict(name='CCC5-transition-return-shape',status='PASS'))
assert len(next(n for n in ast.walk(sd['layout_metadata']) if isinstance(n,ast.Return)).value.elts)==2;checks.append(dict(name='CCC5-layout-plans-mutable-return-shape',status='PASS'))
review_env=extract(content,('no_authority','top_level_unchanged','review'),dict(Path=Path,ROOT=ROOT))
request=json.loads((HERE/'final-content-request.draft.json').read_text());reject('draft-content-request-rejected-before-input-use',lambda:review_env['review'](None,request))
result=dict(status='SOURCE_ONLY_FINITE_CHECKS_PASS',checks=checks,check_count=len(checks),campaign_imports=0,mains_invoked=0,native_commands=0,actual_execution=False,accepted_by_root=False,qualification=False,performance_accepted=False,collection_authorized=False,merge_authorized=False)
(HERE/'finite-source-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],checks=len(checks))))
