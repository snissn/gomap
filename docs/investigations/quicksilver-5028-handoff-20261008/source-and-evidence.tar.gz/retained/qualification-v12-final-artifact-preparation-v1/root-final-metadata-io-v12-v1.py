"""SOURCE_ONLY_PREPARATION: finite root-authorized final metadata IO.
CLI: REQUEST REQUEST_SHA256 NEW_EXCLUSIVE_Q10_OUTPUT.
No capture, prepare(), controller/evaluator main, benchmark or gate acceptance.
Actual raw content acceptance is an external immutable root record.
"""
if not __debug__:
    raise RuntimeError("unoptimized Python required")
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
import types
sys.dont_write_bytecode = True
BASE = Path("/home/mikers/quicksilver-maintenance-5028-20261006")
ROOT = BASE/"qualification-v12-refresh/qualification-v10"
PINS = {
    "evaluator": "9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd",
    "consumer": "ccc5b23ed271b2bd814fc2678a7e4d99e72f0f381b4a39d37132ae570cdee97d",
    "support": "0f2590a04e3959110e5e5d6f5e2e350a7476a162cbe925939de52191a7efc810",
}
DECISION_SHA = "046ddda274e16247d63bd4673fd23a69f2a551711317d5db2f80f8d7748de1b3"

def require(ok, why):
    if not ok: raise ValueError(why)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""): h.update(block)
    return h.hexdigest()

def canonical(path):
    p = Path(path)
    require(p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p,
            "canonical regular file required: "+str(p))
    return p

def parse(raw):
    def unique(items):
        value = {}
        for key, item in items:
            require(key not in value, "duplicate JSON key")
            value[key] = item
        return value
    def invalid(value): raise ValueError("nonfinite JSON token: "+value)
    def finite(value):
        number = float(value)
        require(math.isfinite(number), "nonfinite JSON number")
        return number
    return json.loads(raw, object_pairs_hook=unique, parse_constant=invalid, parse_float=finite)

def bound(ref):
    require(set(ref)=={"path","sha256"}, "exact ref required")
    p = canonical(ref["path"])
    require(sha(p)==ref["sha256"], "bound SHA drift")
    return parse(p.read_bytes())

def reference(path): return dict(path=str(path), sha256=sha(path))

def flags(value):
    for name in ("qualification","performance_accepted","collection_authorized","merge_authorized"):
        require(value[name] is False, "forbidden authority: "+name)

def source(ref, name, expected):
    canonical(ref["path"])
    require(ref["sha256"]==expected and sha(ref["path"])==expected, "selected source identity")
    require(sys.pycache_prefix is None and not (Path(ref["path"]).parent/"__pycache__").exists(),
            "source cache forbidden")
    module = types.ModuleType(name); module.__file__ = ref["path"]
    exec(compile(Path(ref["path"]).read_bytes(), ref["path"], "exec"), module.__dict__)
    return module

def resolve_map_name(name):
    # Match original Inventory.resolve: retain the exact stored spelling.
    require(isinstance(name,str), "anchor path must be text")
    p = Path(name)
    if not p.is_absolute(): p = ROOT/p
    p = p.resolve(strict=True)
    require(p.is_file(), "raw regular file required: "+name)
    return p

def check_map(files):
    resolved = set()
    require(isinstance(files,dict) and files, "complete actual raw map required")
    for name,digest in files.items():
        p = resolve_map_name(name)
        require(p not in resolved and isinstance(digest,str) and len(digest)==64 and
                all(c in "0123456789abcdef" for c in digest) and sha(p)==digest,
                "raw digest/alias drift: "+name)
        resolved.add(p)
        if p.suffix==".py":
            require(not (p.parent/"__pycache__").exists(), "unbound source cache")
    return files

def add(files, ref):
    # Newly added controls/probes must still have strictly canonical paths.
    p = canonical(ref["path"])
    require(sha(p)==ref["sha256"], "dependency SHA drift")
    existing = [name for name in files if resolve_map_name(name)==p]
    require(len(existing)<=1, "duplicate canonical aliases")
    if existing:
        require(files[existing[0]]==ref["sha256"], "dependency conflict")
        return
    files[ref["path"]] = ref["sha256"]

def merge(files, incoming):
    # Inherited maps may contain genuine aliases; do not rewrite their keys.
    check_map(files); check_map(incoming)
    resolved = {resolve_map_name(name):name for name in files}
    for name,digest in incoming.items():
        p = resolve_map_name(name)
        existing = resolved.get(p)
        if existing is not None:
            require(files[existing]==digest, "inherited dependency conflict")
        else:
            files[name] = digest
            resolved[p] = name

def save(path, value):
    with Path(path).open("xb") as stream:
        stream.write((json.dumps(value,indent=2,allow_nan=False)+"\n").encode())
    return reference(path)

def main():
    require(len(sys.argv)==4 and sys.pycache_prefix is None, "request SHA new output required")
    reqref = dict(path=sys.argv[1],sha256=sys.argv[2]); req = bound(reqref); flags(req)
    require(req["schema"]==1 and req["accepted_by_root"] is True and
            req["metadata_io_authorized"] is True and req["final_anchor_binding_authorized"] is True and
            req["exclusive_root_metadata_writer"] is True and req["candidate_pairs_authorized"] is False and
            req["campaign_root"]==str(ROOT) and req["held_excluded"]==[5004,5006],
            "explicit finite root metadata authority required")
    require(req["helper"]==reference(canonical(__file__)), "helper selection drift")
    decision = bound(req["binding_source_preparation_acceptance"])
    require(req["binding_source_preparation_acceptance"]["sha256"]==DECISION_SHA and
            decision["accepted_by_root"] is True and decision["qualification"] is False and
            decision["status"]=="BOUNDED_FINAL_ANALYSIS_SOURCE_PREPARATION_ACCEPTED_ONLY",
            "binding source preparation decision required")
    selected = bound(req["helper_source_acceptance"]); flags(selected)
    require(selected["accepted_by_root"] is True and selected["helper"]==req["helper"] and
            selected["campaign_root"]==str(ROOT), "actual helper source review required")
    raw = bound(req["raw_contents_acceptance"]); flags(raw)
    require(raw["schema"]==1 and raw["accepted_by_root"] is True and
            raw["raw_contents_accepted"] is True and raw["serial_and_quiescent"] is True and
            raw["campaign_root"]==str(ROOT) and raw["held_excluded"]==[5004,5006] and
            raw["original_pair_count"]==raw["state_specific_guard_count"]==114 and
            type(raw["joined_ns"]) is int and type(raw["reviewed_ns"]) is int and
            0<raw["joined_ns"]<=raw["reviewed_ns"]<time.time_ns(),
            "actual joined raw CONTENT acceptance required")
    joined = bound(raw["paired_driver_completion"])
    require(joined["phase"]=="pairs" and joined["rc"]==0 and joined["qualification"] is False and
            joined["finished_ns"]<=raw["joined_ns"], "joined paired driver receipt required")
    ctx = req["strict_context"]
    require(ROOT.is_dir() and ROOT.resolve()==ROOT and not ROOT.is_symlink(), "canonical campaign root")
    require(set(ctx["current_bindings"])=={"source_freeze","deployment","applicability","global54_actual_content_acceptance"},
            "exact current binding roles")
    require(ctx["analysis_directories"]==dict(B=str(ROOT/"analysis-global-original-v1"),
            R=str(ROOT/"ar-analysis-global-original-v1")), "original analysis directories required")
    acceptance = bound(req["metadata_preservation_acceptance"])
    receipt = bound(acceptance["receipt"])
    global_ref = ctx["current_bindings"]["global54_actual_content_acceptance"]
    global_accept = bound(global_ref)
    require(acceptance["accepted_by_root"] is True and acceptance["metadata_preservation_actual_contents_accepted"] is True and
            acceptance["qualification"] is False and acceptance["collection_authorized"] is False and
            acceptance["performance_accepted"] is False and acceptance["no_pair_namespace_at_acceptance"] is True and
            acceptance["campaign_root"]==str(ROOT) and acceptance["held_excluded"]==[5004,5006],
            "actual physical preservation acceptance required")
    require(receipt["accepted_by_root"] is False and receipt["status"]=="PRESERVED_BYTES_ROOT_ACCEPTANCE_PENDING" and
            receipt["schema"]==1 and receipt["qualification"] is False and receipt["collection_authorized"] is False and
            receipt["campaign_root"]==str(ROOT) and receipt["held_excluded"]==[5004,5006] and
            receipt["no_pair_namespace_at_completion"] is True and receipt["consumer"]==ctx["consumer"] and
            receipt["global54_actual_content_acceptance"]==global_ref and
            acceptance["original_anchors"]==receipt["original_anchors"] and
            acceptance["mapping"]==receipt["mapping"] and acceptance["consumer"]==receipt["consumer"] and
            acceptance["request"]==receipt["request"] and
            acceptance["preserved_completed_ns"]==receipt["completed_ns"], "preservation provenance drift")
    originals = {role:bound(ref) for role,ref in receipt["retained_anchors"].items()}
    require(set(originals)=={"B","R"} and receipt["original_anchors"]["R"]==global_accept["R_anchor"] and
            global_accept["files"]==originals["R"]["files"] and global_accept["accepted_by_root"] is True and
            global_accept["global54_actual_contents_accepted"] is True and global_accept["qualification"] is False and
            global_accept["performance_accepted"] is False and
            receipt["original_anchors"]["B"]==dict(path=originals["R"]["original_B_anchor"],
            sha256=originals["R"]["original_B_anchor_sha256"]), "original full selectors drift")
    for role in ("B","R"):
        require(receipt["retained_anchors"][role]["sha256"]==receipt["original_anchors"][role]["sha256"] and
                originals[role]==bound(receipt["original_anchors"][role]), "original anchor byte drift")
        require(originals[role]["root"]==str(ROOT), "original campaign root drift")
        check_map(originals[role]["files"])
    # Cache and complete source identity checks precede any imported source execution.
    for key in ("evaluator","consumer","support"):
        require(originals["R"]["files"].get(ctx[key]["path"])==PINS[key], "original source closure")
    ev = source(ctx["evaluator"],"final_metadata_original_evaluator",PINS["evaluator"])
    strict = source(ctx["consumer"],"final_metadata_frozen_consumer",PINS["consumer"])
    original_invs = {role:ev.Inventory(ref["path"],ref["sha256"]) for role,ref in receipt["original_anchors"].items()}
    drivers = strict.original_drivers(original_invs["R"],ctx,"metadata_original_")
    plans,mutable = strict.layout_metadata(ROOT,ctx,originals,drivers)
    require(len(mutable)==34 and set(receipt["mapping"])==set(mutable), "exact32+2 mapping required")
    copies = set(); new_values = {}
    physical = {role:ev.Inventory(ref["path"],ref["sha256"]) for role,ref in acceptance["physical_anchors"].items()}
    require(set(physical)=={"B","R"}, "both physical anchors required")
    for role in ("B","R"):
        expected = strict.physical_anchor(originals[role],receipt["mapping"],role,
                                         acceptance["physical_anchors"]["B"] if role=="R" else None)
        require(physical[role].anchor==expected, "physical full-map transformation drift")
        require(Path(acceptance["receipt"]["path"]).parent.parent==ROOT and
                Path(receipt["drafts"][role]["path"])==Path(acceptance["receipt"]["path"]).parent/
                    ("physical-"+role+"-anchor.draft.json") and
                Path(receipt["retained_anchors"][role]["path"])==Path(acceptance["receipt"]["path"]).parent/
                    ("original-"+role+"-anchor.json"), "physical provenance path drift")
        draft_expected = copy.deepcopy(expected);draft_expected["accepted_by_root"]=False
        if role=="R":
            draft_expected["files"].pop(acceptance["physical_anchors"]["B"]["path"])
            draft_expected["files"][receipt["drafts"]["B"]["path"]]=receipt["drafts"]["B"]["sha256"]
            draft_expected["original_B_anchor"]=receipt["drafts"]["B"]["path"]
            draft_expected["original_B_anchor_sha256"]=receipt["drafts"]["B"]["sha256"]
        require(bound(receipt["drafts"][role])==draft_expected, "physical draft acceptance transformation drift")
    require(bound(receipt["retained_global54_acceptance"])==global_accept and
            receipt["retained_global54_acceptance"]["sha256"]==global_ref["sha256"] and
            acceptance["global54_actual_content_acceptance"]==global_ref and
            receipt["prospective_rule_freeze"]==ctx["prospective_rule_freeze"] and
            receipt["request_sha256"]==receipt["request"]["sha256"], "retained GLOBAL54/request/rule drift")
    copy_request = bound(receipt["request"])
    require(copy_request["schema"]==1 and copy_request["accepted_by_root"] is True and
            copy_request["artifact_io_authorized"] is True and copy_request["qualification"] is False and
            copy_request["collection_authorized"] is False and
            copy_request["global54_actual_content_acceptance"]==global_ref,
            "actual preservation copy request required")
    for key in ("consumer","evaluator","drivers","support","analysis_directories","prospective_rule_freeze"):
        require(copy_request[key]==ctx[key], "preservation source/request substitution")
    source_refs = [ctx[k] for k in ("evaluator","definition","consumer","witness","policy","prospective_rule_freeze",
            "support","global_replay_helper")]+list(ctx["drivers"].values())+[
            ctx["current_bindings"][k] for k in ("source_freeze","deployment","applicability")]
    for ref in source_refs:
        require(sha(physical["R"].local(Path(ref["path"])))==ref["sha256"],
                "source/control absent from accepted physical pre-pair closure")
    for number,path in enumerate(sorted(mutable)):
        item = mutable[path]; record = receipt["mapping"][path]; saved = bound(record["copy"])
        require(set(record)=={"role","kind","original_sha256","copy"} and record["role"]==item["role"] and record["kind"]==item["kind"] and
                record["original_sha256"]==record["copy"]["sha256"]==originals["R"]["files"][path] and
                Path(record["copy"]["path"])==Path(acceptance["receipt"]["path"]).parent/
                    (str(number).zfill(2)+"-"+Path(path).name) and record["copy"]["path"] not in copies and
                record["copy"]["path"] not in originals["R"]["files"] and
                sha(canonical(path))==record["original_sha256"], "immutable exact copy/current metadata drift")
        copies.add(record["copy"]["path"])
        if item["kind"]=="offline":
            require(saved==item["expected"], "unresolved offline layout drift")
        else:
            C = {k:v for k,v in item["expected"].items() if Path(v["original_run"]).parent.name.split("-")[-1].startswith("C")}
            require(saved["runs"]==C and all(saved[k] is True for k in
                    ("accepted_by_root","inplace_no_reload_restore","before_after_census_retained")),
                    "original complete C origins required")
            new_values[path] = dict(saved,runs=item["expected"])
    require(len(plans["B"]["origins"])==117 and len(plans["R"]["origins"])==54, "complete final origin matrix")
    require(set(raw["files"])=={"B","R"}, "both exact root raw maps required")
    maps = {role:dict(check_map(raw["files"][role])) for role in ("B","R")}
    for role in ("B","R"):
        require(all(maps[role].get(p)==d for p,d in originals[role]["files"].items()), "earlier full closure changed")
    require(all(maps["R"].get(p)==d for p,d in maps["B"].items()), "full B raw closure not inherited")
    dependencies = [reqref,req["helper"],req["binding_source_preparation_acceptance"],
        req["helper_source_acceptance"],req["raw_contents_acceptance"],raw["paired_driver_completion"],
        req["metadata_preservation_acceptance"],acceptance["receipt"],receipt["request"],
        *acceptance["physical_anchors"].values(),*receipt["drafts"].values(),
        *receipt["retained_anchors"].values(),receipt["retained_global54_acceptance"],
        *receipt["original_anchors"].values(),global_ref,*ctx["current_bindings"].values()]
    dependencies += [record["copy"] for record in receipt["mapping"].values()]
    for ref in dependencies: add(maps["R"],ref)
    for role in ("B","R"):
        for p,d in originals["B"]["files"].items():
            require(originals["R"]["files"].get(p)==d, "original B closure not inherited")
    out = Path(sys.argv[3])
    require(out.is_absolute() and out.resolve()==out and out.parent==ROOT and
            out.name.startswith("final-metadata-") and not out.exists() and not out.is_symlink(),
            "new exclusive canonical Q10 output required")
    # New probe evidence only; no existing metadata mutation has occurred.
    out.mkdir(); started = time.time_ns()
    Bprobe = copy.deepcopy(originals["B"]); Bprobe["files"] = maps["B"]
    Bprobe_ref = save(out/"raw-B-probe.json",Bprobe)
    Rprobe = copy.deepcopy(originals["R"]); Rprobe["files"] = dict(maps["R"])
    add(Rprobe["files"],Bprobe_ref)
    Rprobe["original_B_anchor"] = Bprobe_ref["path"]; Rprobe["original_B_anchor_sha256"] = Bprobe_ref["sha256"]
    Rprobe_ref = save(out/"raw-R-probe.json",Rprobe)
    inv = ev.Inventory(Rprobe_ref["path"],Rprobe_ref["sha256"])
    support = source(ctx["support"],"r_protocol_support",PINS["support"])
    support.verify_prerequisites(inv,ev,inv.json(inv.anchor["definition"]),pairs=True)
    collector,maintenance = ev.load_collectors(inv)
    common = ev.load_original(inv,collector,maintenance,plans["B"]["groups"][0]["calibration"][0],
                              plans["B"]["groups"][0]["kind"])["common_inventory"]
    intervals=[]; seen_runs=set(); seen_guards=set()
    for role,plan in plans.items():
        for group in plan["groups"]:
            pairs = ev.original_pairs(inv,collector,maintenance,group,common)
            slot = plan["slots"][group["cell"]+"-service-final"]
            guards = [ev.load_run(inv,collector,pair[k]) for pair in slot["pairs"] for k in ("A","B")]
            for packet in pairs:
                require(packet["name"] not in seen_runs, "pair reuse")
                seen_runs.add(packet["name"]);intervals.append((packet["started_ns"],packet["finished_ns"]))
            guard_contract = ev.contract(ev.load_run(inv,collector,slot["calibration"][0]))
            for guard in guards:
                require(guard["name"] not in seen_guards, "guard reuse");seen_guards.add(guard["name"])
                provenance = plan["origins"][guard["name"]]
                original = next(p for p in pairs if p["name"]==provenance["original_run"])
                require(Path(original["directory"]).resolve()==Path(provenance["directory"]).resolve()==
                        Path(guard["run"]["cell"]["measure_dir"]).resolve() and
                        original["run"]["cell"]["label"]==guard["run"]["cell"]["label"] and
                        original["run"]["source"]["head"]==guard["run"]["source"]["head"] and
                        original["common_inventory"]==ev.common_inventory(inv,guard["name"],guard["run"]) and
                        original["finished_ns"]<int(guard["run"]["started"]*1e9), "paired guard origin drift")
                current = ev.contract(guard);guard_contract = guard_contract or current
                require(current==guard_contract, "matched guard contract drift")
                intervals.append((int(guard["run"]["started"]*1e9),int(guard["run"]["finished"]*1e9)))
    intervals.sort()
    require(len(seen_runs)==len(seen_guards)==114 and all(a[1]<=b[0] for a,b in zip(intervals,intervals[1:])),
            "114+114 complete serialized raw matrix required")
    require(0<global_accept["accepted_ns"]<=receipt["started_ns"]<=receipt["completed_ns"]<=
            acceptance["accepted_ns"]<intervals[0][0] and intervals[-1][1]<=raw["joined_ns"],
            "actual pre-pair preservation/join chronology drift")
    for path,item in mutable.items():
        if item["kind"]=="offline":new_values[path]=strict.final_offline_bundle(item["expected"],inv)
    require(set(new_values)==set(mutable), "exact34 staged metadata required")
    staged={}
    for number,path in enumerate(sorted(new_values)):
        staged[path]=save(out/(str(number).zfill(2)+"-final-"+Path(path).name),new_values[path])
    # Recheck every root accepted byte and every old metadata byte before replacing any.
    for files in maps.values():check_map(files)
    for path,record in receipt["mapping"].items():
        require(sha(canonical(path))==record["original_sha256"], "metadata changed during preflight")
    for path in sorted(staged):
        require(sha(canonical(path))==receipt["mapping"][path]["original_sha256"], "concurrent metadata writer")
        os.replace(staged[path]["path"],path)
        for role in ("B","R"):
            if path in maps[role]:maps[role][path]=sha(path)
    Bfinal = copy.deepcopy(originals["B"]);Bfinal["files"]=maps["B"]
    add(Bfinal["files"],Bprobe_ref)
    Bref = save(out/"final-B-anchor.accepted.json",Bfinal)
    ev.Inventory(Bref["path"],Bref["sha256"])
    Rfinal = copy.deepcopy(originals["R"]);Rfinal["files"]=maps["R"]
    merge(Rfinal["files"],Bfinal["files"])
    require(all(Rfinal["files"].get(p)==d for p,d in Bfinal["files"].items()),
            "full final B exact key/SHA closure not inherited")
    for ref in (Bref,Bprobe_ref,Rprobe_ref):add(Rfinal["files"],ref)
    Rfinal["original_B_anchor"]=Bref["path"];Rfinal["original_B_anchor_sha256"]=Bref["sha256"]
    Rref = save(out/"final-R-anchor.accepted.json",Rfinal)
    final = ev.Inventory(Rref["path"],Rref["sha256"])
    final_ctx = dict(ctx,metadata_preservation_acceptance=req["metadata_preservation_acceptance"],R_anchor=Rref)
    strict.pre_pair_inventory(ev,final_ctx,final)
    completed = time.time_ns()
    result = save(out/"metadata-io-completion.pending-root-review.json",dict(schema=1,
        status="FINITE_FINAL_METADATA_BOUND_PENDING_ROOT_FINAL_CONTENT_REVIEW",accepted_by_root=False,
        qualification=False,performance_accepted=False,collection_authorized=False,merge_authorized=False,
        campaign_root=str(ROOT),held_excluded=[5004,5006],request=reqref,
        raw_contents_acceptance=req["raw_contents_acceptance"],metadata_preservation_acceptance=req["metadata_preservation_acceptance"],
        final_anchors=dict(B=Bref,R=Rref),actual_final_file_counts=dict(B=len(Bfinal["files"]),R=len(Rfinal["files"])),
        started_ns=started,metadata_io_completed_ns=completed,actual_final_contents_accepted_ns=None,
        original_evaluation_required=True,strict_supplement_separate=True))
    print(json.dumps(dict(status="METADATA_IO_COMPLETE_ROOT_REVIEW_REQUIRED",completion=result,
                         final_anchors=dict(B=Bref,R=Rref),qualification=False),allow_nan=False))

if __name__=="__main__":
    main()
