"""Root-authorized final content decision only; never rewrites an anchor.
CLI REQUEST REQUEST_SHA256 NEW_EXCLUSIVE_Q11_OUTPUT.
"""
if not __debug__: raise RuntimeError('unoptimized Python required')
from pathlib import Path
import copy,hashlib,json,sys,time,types
sys.dont_write_bytecode=True
BASE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=BASE/'qualification-v12-refresh/qualification-v10'
METADATA=BASE/'qualification-v12-final-artifact-preparation-v1/root-final-metadata-io-v12-v1.py'
METADATA_SHA='3f82c0a3f323a2e9b47ff3739febf35c813daaae69264b51c4f3131419775f4c'

def reviewed_metadata():
    assert sys.pycache_prefix is None and METADATA.is_file() and not METADATA.is_symlink() and METADATA.resolve()==METADATA
    assert hashlib.sha256(METADATA.read_bytes()).hexdigest()==METADATA_SHA
    assert not (METADATA.parent/'__pycache__').exists()
    m=types.ModuleType('reviewed_final_metadata');m.__file__=str(METADATA)
    exec(compile(METADATA.read_bytes(),str(METADATA),'exec'),m.__dict__)
    return m

def no_authority(value):
    assert all(value[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))

def top_level_unchanged(original,final,role):
    allowed={'files'} if role=='B' else {'files','original_B_anchor','original_B_anchor_sha256'}
    assert set(original)==set(final)
    assert {k:v for k,v in original.items() if k not in allowed}=={k:v for k,v in final.items() if k not in allowed}

def review(m,request):
    no_authority(request)
    assert request['schema']==1 and request['accepted_by_root'] is True and request['artifact_content_review_authorized'] is True
    assert request['campaign_root']==str(ROOT) and request['held_excluded']==[5004,5006]
    outcome=m.bound(request['actual_raw_and_metadata_outcome'])
    outcome_keys={'schema','status','accepted_by_root','campaign_root','held_excluded','actual_raw_content_acceptance','actual_metadata_request','actual_metadata_completion','final_anchors','original_pair_count','state_specific_guard_count','qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized','original_evaluation_required','strict_supplement_separate'}
    assert set(outcome)==outcome_keys
    no_authority(outcome)
    assert outcome['status']=='ACTUAL_RAW114_ACCEPTED_EXACT34_IO_PENDING_FINAL_CONTENT_ACCEPTANCE' and outcome['accepted_by_root'] is False
    assert outcome['campaign_root']==str(ROOT) and outcome['held_excluded']==[5004,5006]
    assert outcome['original_pair_count']==outcome['state_specific_guard_count']==114
    assert outcome['original_evaluation_required'] is outcome['strict_supplement_separate'] is True
    pending=m.bound(outcome['actual_metadata_completion']);m.flags(pending)
    assert pending['schema']==1 and pending['status']=='FINITE_FINAL_METADATA_BOUND_PENDING_ROOT_FINAL_CONTENT_REVIEW'
    assert pending['accepted_by_root'] is False and pending['actual_final_contents_accepted_ns'] is None
    assert pending['campaign_root']==str(ROOT) and pending['held_excluded']==[5004,5006]
    assert pending['request']==outcome['actual_metadata_request'] and pending['raw_contents_acceptance']==outcome['actual_raw_content_acceptance']
    assert pending['final_anchors']==outcome['final_anchors'] and set(pending['final_anchors'])=={'B','R'}
    assert pending['original_evaluation_required'] is pending['strict_supplement_separate'] is True
    meta=m.bound(outcome['actual_metadata_request']);m.flags(meta)
    assert meta['accepted_by_root'] is meta['metadata_io_authorized'] is meta['final_anchor_binding_authorized'] is meta['exclusive_root_metadata_writer'] is True
    assert meta['helper']==dict(path=str(METADATA),sha256=METADATA_SHA) and meta['candidate_pairs_authorized'] is False
    assert meta['campaign_root']==str(ROOT) and meta['held_excluded']==[5004,5006]
    assert meta['raw_contents_acceptance']==outcome['actual_raw_content_acceptance'] and meta['metadata_preservation_acceptance']==pending['metadata_preservation_acceptance']
    metadata_adoption=m.bound(meta['helper_source_acceptance']);no_authority(metadata_adoption)
    assert metadata_adoption['accepted_by_root'] is metadata_adoption['source_only'] is True and metadata_adoption['helper']==meta['helper'] and metadata_adoption['campaign_root']==str(ROOT)
    raw=m.bound(outcome['actual_raw_content_acceptance']);no_authority(raw)
    assert raw['accepted_by_root'] is raw['raw_contents_accepted'] is raw['serial_and_quiescent'] is True
    assert raw['campaign_root']==str(ROOT) and raw['held_excluded']==[5004,5006]
    assert raw['original_pair_count']==raw['state_specific_guard_count']==114
    assert raw['counts']==dict(B=dict(originals=78,guards=78),R=dict(originals=36,guards=36)) and len(raw['intervals'])==228
    assert raw['metadata_preservation_acceptance']==pending['metadata_preservation_acceptance']
    assert raw['status']=='ACTUAL_JOINED114_RAW_CONTENT_ROOT_ACCEPTED' and raw['reviewed_ns']==raw['raw_contents_accepted_ns']
    raw_pending=m.bound(raw['actual_pending_packet']);no_authority(raw_pending)
    assert raw_pending['status']=='ROOT_CONTENT_REVIEW_PENDING' and raw_pending['accepted_by_root'] is raw_pending['raw_contents_accepted'] is False
    for key in ('files','counts','intervals','request','helper','helper_source_acceptance','paired_driver_completion','paired_driver_activation','metadata_preservation_acceptance','joined_ns','diagnostic_completed_ns'):
        assert raw[key]==raw_pending[key]
    assert raw_pending['diagnostic_completed_ns']<raw['reviewed_ns']
    assert raw['joined_ns']<=raw['reviewed_ns']<pending['started_ns']<pending['metadata_io_completed_ns']<time.time_ns()
    execution=m.bound(request['actual_metadata_execution'])
    expected=['python3','-B',str(METADATA),outcome['actual_metadata_request']['path'],outcome['actual_metadata_request']['sha256'],str(Path(pending['final_anchors']['B']['path']).parent)]
    assert execution['native_argv']==expected and execution['rc']==0 and not execution.get('error')
    assert execution['started_ns']<=pending['started_ns']<pending['metadata_io_completed_ns']<=execution['finished_ns']<time.time_ns()
    for channel in ('stdout','stderr'):
        ref=request['actual_metadata_execution_streams'][channel];p=m.canonical(ref['path'])
        assert m.sha(p)==ref['sha256']==execution[channel]['sha256'] and p.stat().st_size==execution[channel]['bytes']
    assert not Path(request['actual_metadata_execution_streams']['stderr']['path']).read_bytes()
    result=m.bound(request['actual_metadata_result'])
    assert result==m.parse(Path(request['actual_metadata_execution_streams']['stdout']['path']).read_bytes())
    assert result==dict(status='METADATA_IO_COMPLETE_ROOT_REVIEW_REQUIRED',completion=outcome['actual_metadata_completion'],final_anchors=outcome['final_anchors'],qualification=False)
    ctx=meta['strict_context'];finals={role:m.bound(ref) for role,ref in pending['final_anchors'].items()}
    for value in finals.values():m.check_map(value['files'])
    ev=m.source(ctx['evaluator'],'final_content_original_evaluator',m.PINS['evaluator'])
    strict=m.source(ctx['consumer'],'final_content_frozen_consumer',m.PINS['consumer'])
    invs={role:ev.Inventory(ref['path'],ref['sha256']) for role,ref in pending['final_anchors'].items()}
    assert all(inv.root==ROOT for inv in invs.values())
    assert finals['R']['original_B_anchor']==pending['final_anchors']['B']['path'] and finals['R']['original_B_anchor_sha256']==pending['final_anchors']['B']['sha256']
    strict_context=dict(ctx,R_anchor=pending['final_anchors']['R'],metadata_preservation_acceptance=pending['metadata_preservation_acceptance'])
    transition=strict.pre_pair_inventory(ev,strict_context,invs['R'])
    drivers=strict.original_drivers(invs['R'],strict_context,'final_content_')
    plans,mutable=strict.layout_metadata(ROOT,strict_context,transition['originals'],drivers)
    assert len(mutable)==34 and len(plans['B']['groups'])==13 and len(plans['R']['groups'])==6
    for role in ('B','R'):
        top_level_unchanged(transition['originals'][role],finals[role],role)
        assert pending['actual_final_file_counts'][role]==len(finals[role]['files'])
        for p,h in raw['files'][role].items():
            assert p in finals[role]['files']
            assert p in mutable or finals[role]['files'][p]==h
        for p,h in finals['B']['files'].items():assert finals['R']['files'].get(p)==h
    support=m.source(ctx['support'],'r_protocol_support',m.PINS['support'])
    support.verify_prerequisites(invs['R'],ev,invs['R'].json(invs['R'].anchor['definition']),pairs=True)
    return dict(outcome=outcome,pending=pending,raw=raw,context=ctx,finals=finals,plans=plans)

def main():
    assert len(sys.argv)==4
    m=reviewed_metadata();ref=dict(path=sys.argv[1],sha256=sys.argv[2]);request=m.bound(ref)
    assert request['helper']==m.reference(m.canonical(__file__))
    adoption=m.bound(request['helper_source_acceptance']);no_authority(adoption)
    assert adoption['accepted_by_root'] is adoption['source_only'] is True and adoption['helper']==request['helper'] and adoption['campaign_root']==str(ROOT)
    checked=review(m,request)
    out=Path(sys.argv[3]);assert out.is_absolute() and out.parent==ROOT and out.resolve()==out and not out.exists() and not out.is_symlink()
    now=time.time_ns();out.mkdir()
    decision=dict(schema=1,status='ACTUAL_FINAL_CONTENT_ONLY_ROOT_ACCEPTED',accepted_by_root=True,actual_final_contents_accepted=True,
        qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False,
        campaign_root=str(ROOT),held_excluded=[5004,5006],request=ref,helper=request['helper'],helper_source_acceptance=request['helper_source_acceptance'],
        actual_raw_and_metadata_outcome=request['actual_raw_and_metadata_outcome'],actual_metadata_execution=request['actual_metadata_execution'],
        actual_metadata_execution_streams=request['actual_metadata_execution_streams'],actual_metadata_result=request['actual_metadata_result'],
        actual_metadata_completion=checked['outcome']['actual_metadata_completion'],actual_raw_content_acceptance=checked['outcome']['actual_raw_content_acceptance'],
        final_anchors=checked['outcome']['final_anchors'],metadata_preservation_acceptance=checked['pending']['metadata_preservation_acceptance'],
        actual_final_file_counts=checked['pending']['actual_final_file_counts'],original_pair_count=114,state_specific_guard_count=114,metadata_files=34,
        reviewed_ns=now,actual_final_contents_accepted_ns=now,metadata_io_completed_ns=checked['pending']['metadata_io_completed_ns'],
        original_evaluation_required=True,strict_supplement_separate=True,original_numerical_UNKNOWN_must_remain=True)
    print(json.dumps(m.save(out/'actual-final-content-acceptance.json',decision),allow_nan=False))

if __name__=='__main__':main()
