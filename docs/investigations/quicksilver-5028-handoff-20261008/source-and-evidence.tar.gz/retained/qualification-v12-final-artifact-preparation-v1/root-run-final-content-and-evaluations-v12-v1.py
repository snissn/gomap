"""Root handoff after real raw114 and exact34 IO; artifact evaluation only.

Requests and times are created only in main. The unchanged full original
evaluations precede the separately reviewed strict supplement. No performance
or merge decision is made here; failures retain their exact first-attempt bytes.
"""
from pathlib import Path
import hashlib
import json
import os
import sys
import time
import types

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
REMOTE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = REMOTE/'qualification-v12-refresh/qualification-v10'
RECEIPTS = BASE/'qualification-v9-selected-source-preparation-v1'
PREP = BASE/'qualification-v12-final-artifact-preparation-v1'
CONTENT = PREP/'root-final-content-acceptance-v12-v1.py'
EVALUATION = PREP/'root-run-final-evaluation-v12-v1.py'
CONTENT_SHA = 'c43ae30bb0f9bd4ede35704931185253a7b440cb9ed6a2892a8a6939bef76475'
EVALUATION_SHA = '3d0374a34f4aeb2df948a4ce72e4165d81e8886e6038c9f7a027eacb0300d8fd'


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ref(path):
    return dict(path=str(REMOTE/path.relative_to(BASE)),sha256=sha(path))


def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def flags(value):
    assert all(value[key] is False for key in ('qualification','performance_accepted',
        'collection_authorized','candidate_pairs_authorized','merge_authorized'))


def runtime(**fields):
    state=read(BASE/'state.json');state.update(fields)
    pending=HERE/('state-final-evaluation-runtime-'+str(time.time_ns())+'.json')
    save(pending,state);pending.replace(BASE/'state.json')


def actual(label):
    row=read(RECEIPTS/(label+'-run.json'))
    assert row['rc']==0 and not row.get('error') and 0<row['started_ns']<row['finished_ns']
    for channel in ('stdout','stderr'):
        path=RECEIPTS/(label+'-'+channel+'.txt')
        assert row[channel]==dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size)
    assert not (RECEIPTS/(label+'-stderr.txt')).read_bytes()
    return row


def native_bound(item,label):
    code='''from pathlib import Path
import hashlib,json,sys
p=Path(sys.argv[1]);assert p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink()
assert hashlib.sha256(p.read_bytes()).hexdigest()==sys.argv[2]
print(json.dumps(json.loads(p.read_bytes()),allow_nan=False))
'''
    value=json.loads(io.native(['python3','-B','-c',code,item['path'],item['sha256']],label,180))
    actual(label)
    return value


def request(name,adoption,status,**actual_fields):
    value=read(PREP/(name+'-request.draft.json'))
    assert value.pop('source_only') is True and value['accepted_by_root'] is False
    value.update(accepted_by_root=True,status=status,authorized_ns=time.time_ns(),
        owner='/root',helper_source_acceptance=ref(adoption),**actual_fields)
    flags(value)
    return value


def local_path(item):
    assert set(item)=={'path','sha256'}
    p=BASE/Path(item['path']).relative_to(REMOTE)
    assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve()==p
    assert sha(p)==item['sha256']
    return p

def local_bound(item):
    p=local_path(item)
    return p,read(p)


def root_request():
    assert len(sys.argv)==3 and sys.flags.dont_write_bytecode and sys.pycache_prefix is None and not os.environ.get('PYTHONPYCACHEPREFIX')
    p=Path(sys.argv[1])
    assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve()==p and sha(p)==sys.argv[2]
    q=read(p);flags(q)
    assert q['schema']==1 and q['accepted_by_root'] is True and q['owner']=='/root'
    assert q['campaign_root']==str(ROOT) and q['held_excluded']==[5004,5006]
    assert q['helper']==ref(Path(__file__).resolve())
    assert q['serial_and_quiescent'] is q['exclusive_native_owner'] is True
    assert q['root_final_handoff_authorized'] is True
    _,adoption=local_bound(q['helper_source_acceptance']);flags(adoption)
    assert adoption['accepted_by_root'] is adoption['source_only'] is True
    assert adoption['helper']==q['helper'] and adoption['campaign_root']==str(ROOT)
    return q


if __name__=='__main__':
    assert __debug__
    q=root_request()
    state=read(BASE/'state.json');assert state['native_active'] is None
    outcome_path,_=local_bound(q['actual_raw_and_metadata_outcome'])
    outcome=read(outcome_path);flags(outcome)
    assert outcome['status']=='ACTUAL_RAW114_ACCEPTED_EXACT34_IO_PENDING_FINAL_CONTENT_ACCEPTANCE'
    assert outcome['campaign_root']==str(ROOT) and outcome['held_excluded']==[5004,5006]
    assert outcome['original_pair_count']==outcome['state_specific_guard_count']==114
    assert sha(CONTENT)==CONTENT_SHA and sha(EVALUATION)==EVALUATION_SHA
    content_adoption,_=local_bound(q['content_helper_source_acceptance'])
    evaluation_adoption,_=local_bound(q['evaluation_helper_source_acceptance'])
    for path,helper in ((content_adoption,CONTENT),(evaluation_adoption,EVALUATION)):
        adoption=read(path);flags(adoption)
        assert adoption['accepted_by_root'] is adoption['source_only'] is True
        assert adoption['helper']==ref(helper) and adoption['campaign_root']==str(ROOT)
    metadata_label=q['metadata_execution_label']
    metadata_execution=actual(metadata_label)
    streams={channel:RECEIPTS/(metadata_label+'-'+channel+'.txt') for channel in ('stdout','stderr')}
    result_path,_=local_bound(q['actual_metadata_result'])
    assert read(result_path)==json.loads(streams['stdout'].read_bytes())
    assert read(result_path)['completion']==outcome['actual_metadata_completion']
    ip=RECEIPTS/'root_native_io.py'
    assert sha(ip)=='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
    assert not (ip.parent/'__pycache__').exists()
    io=types.ModuleType('root_io');io.__file__=str(ip)
    exec(compile(ip.read_bytes(),str(ip),'exec'),io.__dict__)
    runtime(native_active=dict(phase='fresh-v12-final-content-original54-then-separate-strict19',
        owner='/root',local_owner_pid=os.getpid(),started_ns=time.time_ns(),campaign_root=str(ROOT),
        qualification=False,candidate_pair_collection_authorized=False))
    try:
        content_request=request('final-content',content_adoption,'ROOT_AUTHORIZED_ACTUAL_FINAL_CONTENT_REVIEW_ONLY',
            artifact_content_review_authorized=True,actual_raw_and_metadata_outcome=ref(outcome_path),
            actual_metadata_execution=ref(RECEIPTS/(metadata_label+'-run.json')),
            actual_metadata_execution_streams={key:ref(path) for key,path in streams.items()},
            actual_metadata_result=ref(result_path))
        content_request_path=HERE/'root-final-content-actual-request-v12-v1.json'
        save(content_request_path,content_request)
        stage=(CONTENT,EVALUATION,content_adoption,evaluation_adoption,outcome_path,
            result_path,RECEIPTS/(metadata_label+'-run.json'),*streams.values(),content_request_path)
        io.put({path.relative_to(BASE).as_posix():path for path in stage},
            'v12-root-final-content-inputs-and-reviewed-evaluators-exclusive-stage-v1')
        label='v12-actual-final-content-review-v1'
        content_ref=json.loads(io.native(['python3','-B',ref(CONTENT)['path'],ref(content_request_path)['path'],
            sha(content_request_path),str(ROOT/'final-content-actual114-v12-v1')],label,14400))
        actual(label)
        content=native_bound(content_ref,'v12-root-final-content-decision-readback-v1');flags(content)
        assert content['status']=='ACTUAL_FINAL_CONTENT_ONLY_ROOT_ACCEPTED'
        assert content['accepted_by_root'] is content['actual_final_contents_accepted'] is True
        assert content['final_anchors']==outcome['final_anchors']
        assert content['original_pair_count']==content['state_specific_guard_count']==114 and content['metadata_files']==34
        assert content['request']==ref(content_request_path) and content['actual_raw_and_metadata_outcome']==ref(outcome_path)
        save(HERE/'actual-final-content-decision-readback-v12-v1.json',dict(reference=content_ref,decision=content))
        original_request=request('original-evaluation',evaluation_adoption,'ROOT_AUTHORIZED_ORIGINAL_FULL_FINAL_EVALUATION_ONLY',
            artifact_evaluation_authorized=True,original_full_evaluation_authorized=True,
            actual_final_content_acceptance=content_ref)
        original_request_path=HERE/'root-original-full-final-evaluation-actual-request-v12-v1.json'
        save(original_request_path,original_request)
        io.put({original_request_path.relative_to(BASE).as_posix():original_request_path},
            'v12-root-original-full-final-evaluation-request-exclusive-stage-v1')
        label='v12-actual-original-full-B36-R18-final-evaluation-v1'
        original_ref=json.loads(io.native(['python3','-B',ref(EVALUATION)['path'],ref(original_request_path)['path'],
            sha(original_request_path),str(ROOT/'original-full-final-evaluation-actual114-v12-v1')],label,14400))
        actual(label)
        original=native_bound(original_ref,'v12-root-original-full-final-completion-readback-v1');flags(original)
        assert original['status']=='ORIGINAL_FULL_B_R_JOINED_ROOT_REVIEW_REQUIRED' and original['accepted_by_root'] is False
        assert original['actual_final_content_acceptance']==content_ref and original['request']==ref(original_request_path)
        assert original['final_anchors']==content['final_anchors']
        assert len(original['evaluations']['B'])==36 and len(original['evaluations']['R'])==18
        assert original['original_numerical_UNKNOWN_must_remain'] is original['strict_supplement_separate'] is True
        save(HERE/'actual-original-full-final-completion-readback-v12-v1.json',dict(reference=original_ref,completion=original))
        strict_request=request('strict-evaluation',evaluation_adoption,'ROOT_AUTHORIZED_SEPARATE_STRICT19_SUPPLEMENT_ONLY',
            artifact_evaluation_authorized=True,strict_supplement_authorized=True,
            actual_final_content_acceptance=content_ref,original_full_completion=original_ref)
        strict_request_path=HERE/'root-strict19-supplement-actual-request-v12-v1.json'
        save(strict_request_path,strict_request)
        io.put({strict_request_path.relative_to(BASE).as_posix():strict_request_path},
            'v12-root-separate-strict19-request-exclusive-stage-v1')
        label='v12-actual-separate-strict19-supplement-v1'
        strict_ref=json.loads(io.native(['python3','-B',ref(EVALUATION)['path'],ref(strict_request_path)['path'],
            sha(strict_request_path),str(ROOT/'separate-strict19-actual114-v12-v1')],label,14400))
        actual(label)
        strict=native_bound(strict_ref,'v12-root-separate-strict19-completion-readback-v1');flags(strict)
        assert strict['status']=='SEPARATE_STRICT19_REPLAY_JOINED_ROOT_REVIEW_REQUIRED'
        assert strict['accepted_by_root'] is False and strict['original_full_completion']==original_ref
        assert strict['request']==ref(strict_request_path) and len(strict['proofs'])==19
        assert strict['original_numerical_UNKNOWN_must_remain'] is True
        result=dict(schema=1,status='ACTUAL_ORIGINAL_FULL54_THEN_SEPARATE_STRICT19_JOINED_PRODUCT_DECISION_PENDING',
            accepted_by_root=False,campaign_root=str(ROOT),held_excluded=[5004,5006],
            actual_final_content_acceptance=content_ref,original_full_completion=original_ref,
            original_evaluations=original['evaluations'],separate_strict19_completion=strict_ref,
            separate_strict_proofs=strict['proofs'],original_pair_count=114,state_specific_guard_count=114,
            qualification=False,performance_accepted=False,collection_authorized=False,
            candidate_pairs_authorized=False,merge_authorized=False,
            original_numerical_UNKNOWN_must_remain=True,completed_ns=time.time_ns())
        result_path=HERE/'root-final-evaluations-actual-outcome-v12-v1.json';save(result_path,result)
        state=read(BASE/'state.json');state['qualification_v12_current']['original_full_and_strict19_actual']=ref(result_path)
        runtime(native_active=None,qualification_v12_current=state['qualification_v12_current'],
            current_execution_status='Actual full B36/R18 final analyses and separate strict19 joined; product decision pending',
            next_action='Read every actual original result and distinct strict proof; decide unchanged speed, process-memory, progress, correctness and regression gates')
        print(json.dumps(result,allow_nan=False),flush=True)
    except BaseException as error:
        runtime(native_active=None,current_execution_status='Actual final content/evaluation failed; original bytes retained; no retry',
            next_action='Inspect exact failed artifact seam before further evaluation or merge',
            last_native_failure=dict(phase='fresh-v12-final-content-and-evaluations',error=repr(error),finished_ns=time.time_ns()))
        raise
