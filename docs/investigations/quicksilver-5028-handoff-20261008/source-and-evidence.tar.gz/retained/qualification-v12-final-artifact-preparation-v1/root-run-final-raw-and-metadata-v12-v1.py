"""Prepared root-only final artifact handoff; no main executes at preparation.

Requires the real joined114/114 phase. The independently reviewed frozen raw
helper checks all actual contents; root records that narrow acceptance before
the separate reviewed exact34 metadata helper. No performance/merge authority.
"""
from pathlib import Path
import hashlib
import json
import os
import sys
import time
import types

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
REMOTE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = REMOTE/'qualification-v12-refresh/qualification-v10'
STATE = BASE/'state.json'
RECEIPTS = BASE/'qualification-v9-selected-source-preparation-v1'
PREP = BASE/'qualification-v12-final-artifact-preparation-v1'
INDEPENDENT = None
RAW = PREP/'root-final-raw-closure-v12-v1.py'
METADATA = PREP/'root-final-metadata-io-v12-v1.py'
RAW_SHA = '34cd215d65da201bf50f468042959988c13c004bd89674cf6b7a8ee626b6a5b2'
METADATA_SHA = '3f82c0a3f323a2e9b47ff3739febf35c813daaae69264b51c4f3131419775f4c'
REVIEW_SHA = None


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def remote_ref(path):
    return dict(path=str(REMOTE/path.relative_to(BASE)),sha256=sha(path))


def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def runtime(**fields):
    state=read(STATE);state.update(fields)
    pending=HERE/('state-final-artifact-runtime-'+str(time.time_ns())+'.json')
    save(pending,state);pending.replace(STATE)


def flags(value):
    assert all(value[k] is False for k in ('qualification','performance_accepted',
        'collection_authorized','candidate_pairs_authorized','merge_authorized'))


def actual(label):
    row=read(RECEIPTS/(label+'-run.json'))
    assert row['rc']==0 and not row.get('error') and 0<row['started_ns']<row['finished_ns']
    for channel in ('stdout','stderr'):
        path=RECEIPTS/(label+'-'+channel+'.txt')
        assert row[channel]==dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size)
    assert not (RECEIPTS/(label+'-stderr.txt')).read_bytes()
    return row


def native_bound(item,label):
    code='''from pathlib import Path
import hashlib,json,sys
p=Path(sys.argv[1]);assert p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink()
assert hashlib.sha256(p.read_bytes()).hexdigest()==sys.argv[2]
print(json.dumps(json.loads(p.read_bytes()),allow_nan=False))
'''
    result=json.loads(io.native(['python3','-B','-c',code,item['path'],item['sha256']],label,180))
    actual(label)
    return result


def local_path(item):
    assert set(item)=={'path','sha256'}
    p=BASE/Path(item['path']).relative_to(REMOTE)
    assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve()==p
    assert sha(p)==item['sha256']
    return p

def local_bound(item):
    p=local_path(item)
    return p,read(p)


def root_request():
    assert len(sys.argv)==3 and sys.flags.dont_write_bytecode and sys.pycache_prefix is None and not os.environ.get('PYTHONPYCACHEPREFIX')
    p=Path(sys.argv[1])
    assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve()==p and sha(p)==sys.argv[2]
    q=read(p);flags(q)
    assert q['schema']==1 and q['accepted_by_root'] is True and q['owner']=='/root'
    assert q['campaign_root']==str(ROOT) and q['held_excluded']==[5004,5006]
    assert q['helper']==remote_ref(Path(__file__).resolve())
    assert q['serial_and_quiescent'] is q['exclusive_native_owner'] is True
    assert q['root_final_handoff_authorized'] is True
    _,adoption=local_bound(q['helper_source_acceptance']);flags(adoption)
    assert adoption['accepted_by_root'] is adoption['source_only'] is True
    assert adoption['helper']==q['helper'] and adoption['campaign_root']==str(ROOT)
    return q


if __name__=='__main__':
    assert __debug__
    q=root_request()
    INDEPENDENT=local_path(q['independent_source_review']);REVIEW_SHA=q['independent_source_review']['sha256']
    state=read(STATE);assert state['native_active'] is None
    _,joined=local_bound(q['joined_pair_phase'])
    assert joined['campaign_root']==str(ROOT) and joined['held_excluded']==[5004,5006]
    assert joined['original_pair_count']==joined['state_specific_guard_count']==114
    assert joined['raw_content_acceptance'] is False
    assert type(joined['joined_ns']) is int and 0<joined['joined_ns']<time.time_ns()
    assert sha(RAW)==RAW_SHA and sha(METADATA)==METADATA_SHA and sha(INDEPENDENT)==REVIEW_SHA
    raw_adopt,_=local_bound(q['raw_helper_source_acceptance'])
    metadata_adopt,_=local_bound(q['metadata_helper_source_acceptance'])
    for path,helper in ((raw_adopt,RAW),(metadata_adopt,METADATA)):
        selection=read(path);flags(selection)
        assert selection['accepted_by_root'] is True and selection['source_only'] is True
        assert selection['helper']==remote_ref(helper) and selection['independent_source_review']==remote_ref(INDEPENDENT)
        assert selection['campaign_root']==str(ROOT)
    ip=RECEIPTS/'root_native_io.py'
    assert sha(ip)=='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
    io=types.ModuleType('root_io');io.__file__=str(ip)
    exec(compile(ip.read_bytes(),str(ip),'exec'),io.__dict__)
    runtime(native_active=dict(phase='fresh-v12-joined-raw114-content-and-exact34-metadata',
        owner='/root',local_owner_pid=os.getpid(),started_ns=time.time_ns(),campaign_root=str(ROOT),
        qualification=False,candidate_pair_collection_authorized=False))
    try:
        completion=native_bound(joined['paired_driver_completion'],'v12-root-joined114-before-raw-readback-v1')
        assert completion['phase']=='pairs' and completion['rc']==0 and completion['qualification'] is False
        assert completion['finished_ns']<=joined['joined_ns']
        request=read(PREP/'raw-request.draft.json');request.pop('source_only')
        request.update(status='ROOT_AUTHORIZED_JOINED114_RAW_CONTENT_REPLAY_ONLY',accepted_by_root=True,
            read_only_raw_closure_authorized=True,diagnostic_inventory_creation=True,serial_and_quiescent=True,
            helper_source_acceptance=remote_ref(raw_adopt),independent_source_review=remote_ref(INDEPENDENT),
            metadata_preservation_acceptance=joined['metadata_preservation_acceptance'],
            paired_driver_completion=joined['paired_driver_completion'],
            paired_driver_activation=joined['paired_driver_activation'],joined_ns=joined['joined_ns'],
            output_directory=str(ROOT/'raw-closure-final114-v12-v1'),owner='/root',authorized_ns=time.time_ns())
        request['strict_context']['current_bindings']['global54_actual_content_acceptance']=joined['global54_content_acceptance']
        flags(request)
        rp=HERE/'root-final-raw-actual-request-v12-v1.json';save(rp,request)
        sources=(RAW,METADATA,raw_adopt,metadata_adopt,INDEPENDENT,rp)
        io.put({p.relative_to(BASE).as_posix():p for p in sources},'v12-root-final-artifact-sources-and-raw-request-exclusive-stage-v1')
        label='v12-actual-final-raw114-content-replay-v1'
        result=json.loads(io.native(['python3','-B',request['helper']['path'],remote_ref(rp)['path'],sha(rp),
            request['output_directory']],label,14400));actual(label)
        assert result['status']=='ROOT_CONTENT_REVIEW_PENDING' and result['accepted_by_root'] is False
        flags(result)
        pending=native_bound(result['packet'],'v12-root-actual-final-raw114-packet-readback-v1')
        flags(pending)
        assert pending['status']=='ROOT_CONTENT_REVIEW_PENDING' and pending['accepted_by_root'] is pending['raw_contents_accepted'] is False
        assert pending['campaign_root']==str(ROOT) and pending['held_excluded']==[5004,5006]
        assert pending['request']==remote_ref(rp) and pending['helper']==remote_ref(RAW)
        assert pending['helper_source_acceptance']==remote_ref(raw_adopt) and pending['independent_source_review']==remote_ref(INDEPENDENT)
        assert pending['paired_driver_completion']==joined['paired_driver_completion']
        assert pending['paired_driver_activation']==joined['paired_driver_activation']
        assert pending['metadata_preservation_acceptance']==joined['metadata_preservation_acceptance']
        assert pending['original_pair_count']==pending['state_specific_guard_count']==114
        assert pending['counts']==dict(B=dict(originals=78,guards=78),R=dict(originals=36,guards=36))
        assert pending['serial_and_quiescent'] is pending['original34_unchanged'] is True
        assert pending['joined_ns']==joined['joined_ns'] and pending['joined_ns']<=pending['started_ns']<pending['diagnostic_completed_ns']<time.time_ns()
        assert len(pending['intervals'])==228 and set(pending['files'])=={'B','R'}
        assert all(pending['files']['R'].get(p)==d for p,d in pending['files']['B'].items())
        now=time.time_ns()
        accepted=dict(pending,status='ACTUAL_JOINED114_RAW_CONTENT_ROOT_ACCEPTED',accepted_by_root=True,
            raw_contents_accepted=True,reviewed_ns=now,raw_contents_accepted_ns=now,
            actual_pending_packet=result['packet'],actual_raw_execution=remote_ref(RECEIPTS/(label+'-run.json')),
            root_review_required=False,owner='/root')
        flags(accepted)
        ap=HERE/'root-final-raw-content-actual-acceptance-v12-v1.json';save(ap,accepted)
        metadata_request=read(PREP/'metadata-request.draft.json');metadata_request.pop('source_only')
        metadata_request.update(status='ROOT_AUTHORIZED_EXACT34_FINAL_METADATA_AND_ANCHOR_IO_ONLY',
            accepted_by_root=True,metadata_io_authorized=True,final_anchor_binding_authorized=True,
            exclusive_root_metadata_writer=True,helper_source_acceptance=remote_ref(metadata_adopt),
            raw_contents_acceptance=remote_ref(ap),metadata_preservation_acceptance=joined['metadata_preservation_acceptance'],
            owner='/root',authorized_ns=time.time_ns())
        metadata_request['strict_context']['current_bindings']['global54_actual_content_acceptance']=joined['global54_content_acceptance']
        flags(metadata_request)
        mp=HERE/'root-final-metadata-actual-request-v12-v1.json';save(mp,metadata_request)
        io.put({p.relative_to(BASE).as_posix():p for p in (ap,mp)},'v12-root-final-raw-acceptance-and-exact34-request-exclusive-stage-v1')
        label='v12-actual-final-exact34-metadata-io-v1'
        output=ROOT/'final-metadata-actual114-v12-v1'
        metadata=json.loads(io.native(['python3','-B',metadata_request['helper']['path'],remote_ref(mp)['path'],sha(mp),str(output)],
            label,14400));actual(label)
        assert metadata['status']=='METADATA_IO_COMPLETE_ROOT_REVIEW_REQUIRED' and metadata['qualification'] is False
        save(HERE/'actual-final-exact34-metadata-result-v12-v1.json',metadata)
        content=native_bound(metadata['completion'],'v12-root-final-exact34-completion-readback-v1')
        assert content['accepted_by_root'] is False and content['qualification'] is content['performance_accepted'] is False
        assert content['request']==remote_ref(mp) and content['raw_contents_acceptance']==remote_ref(ap)
        assert content['metadata_preservation_acceptance']==joined['metadata_preservation_acceptance']
        assert content['final_anchors']==metadata['final_anchors']
        assert now<content['started_ns']<content['metadata_io_completed_ns']<time.time_ns()
        assert content['original_evaluation_required'] is content['strict_supplement_separate'] is True
        outcome=dict(schema=1,status='ACTUAL_RAW114_ACCEPTED_EXACT34_IO_PENDING_FINAL_CONTENT_ACCEPTANCE',
            accepted_by_root=False,campaign_root=str(ROOT),held_excluded=[5004,5006],
            actual_raw_content_acceptance=remote_ref(ap),actual_metadata_request=remote_ref(mp),
            actual_metadata_completion=metadata['completion'],final_anchors=metadata['final_anchors'],
            original_pair_count=114,state_specific_guard_count=114,qualification=False,performance_accepted=False,
            collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False,
            original_evaluation_required=True,strict_supplement_separate=True)
        op=HERE/'root-final-raw-and-metadata-actual-outcome-v12-v1.json';save(op,outcome)
        state=read(STATE)
        state['qualification_v12_current']['raw114_and_exact34_io_actual']=remote_ref(op)
        runtime(native_active=None,qualification_v12_current=state['qualification_v12_current'],
            current_execution_status='Actual114/114 raw content accepted; exact34 metadata IO joined; final content and performance gates pending',
            next_action='Separate actual final content acceptance; original full B and R final evaluation FIRST, then separate strict supplement')
        print(json.dumps(outcome,allow_nan=False),flush=True)
    except BaseException as error:
        runtime(native_active=None,current_execution_status='Final raw/metadata gate failed; exact evidence and physical34 originals retained',
            next_action='Inspect exact failure and any partial34 replacements; no benchmark, rewrite or automatic retry',
            last_native_failure=dict(phase='fresh-v12-final-raw-and-metadata',error=repr(error),finished_ns=time.time_ns()))
        raise
