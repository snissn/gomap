"""Separate original/strict artifact evaluations. CLI REQUEST SHA NEW_OUTPUT.
Original mode runs full B then full R. Strict mode requires their actual completion.
No capture, --prepare, numerical reinterpretation, qualification or merge decision.
"""
if not __debug__:raise RuntimeError('unoptimized Python required')
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,types
sys.dont_write_bytecode=True
BASE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=BASE/'qualification-v12-refresh/qualification-v10'
CONTENT=BASE/'qualification-v12-final-artifact-preparation-v1/root-final-content-acceptance-v12-v1.py'
CONTENT_SHA='c43ae30bb0f9bd4ede35704931185253a7b440cb9ed6a2892a8a6939bef76475'
BD=BASE/'qualification-analysis-controller.py'
RD=BASE/'r-material-gate-preparation-v2/r-analysis-controller.py'
BD_SHA='e5744ead53031c489e3345c16a48c0b2e7b91c577177d50d25d94adfbe7b79fd'
RD_SHA='433c5df7016136afc8920b6663c5c0ed5d167cea993b35554a0b54a663764dc6'

def content_module():
    assert CONTENT.is_file() and not CONTENT.is_symlink() and CONTENT.resolve()==CONTENT and sys.pycache_prefix is None
    assert hashlib.sha256(CONTENT.read_bytes()).hexdigest()==CONTENT_SHA and not (CONTENT.parent/'__pycache__').exists()
    c=types.ModuleType('reviewed_final_content');c.__file__=str(CONTENT)
    exec(compile(CONTENT.read_bytes(),str(CONTENT),'exec'),c.__dict__);return c

def original_argv(role,anchors,definition):
    args=['python3','-B',str(BD if role=='B' else RD),'final-evaluate','--campaign',str(ROOT),'--out',str(ROOT/('analysis-global-original-v1' if role=='B' else 'ar-analysis-global-original-v1'))]
    if role=='R':args+=['--original-B-anchor',anchors['B']['path'],'--original-B-anchor-sha256',anchors['B']['sha256'],'--definition',definition['path'],'--definition-sha256',definition['sha256']]
    return args+['--anchor',anchors[role]['path'],'--anchor-sha256',anchors[role]['sha256']]

def execute(m,argv,out,label):
    stdout=out/(label+'.stdout.json');stderr=out/(label+'.stderr.txt');row=dict(schema=1,native_argv=argv,started_ns=time.time_ns(),finished_ns=None,rc=None,qualification=False,performance_accepted=False,collection_authorized=False)
    try:
        with stdout.open('xb') as so,stderr.open('xb') as se:row['rc']=subprocess.run(argv,stdout=so,stderr=se,check=False).returncode
    except BaseException as error:
        row['error']=repr(error);raise
    finally:
        row['finished_ns']=time.time_ns()
        for name,path in (('stdout',stdout),('stderr',stderr)):
            if path.is_file():row[name]=dict(m.reference(path),bytes=path.stat().st_size)
        m.save(out/(label+'.execution.json'),row)
    assert row['rc']==0 and not row.get('error'),'failed artifact evaluation retained; no retry'
    assert not stderr.read_bytes(),'unexpected stderr retained; root diagnosis required'
    return m.reference(out/(label+'.execution.json')),m.parse(stdout.read_bytes())

def verify_original_completion(m,value,anchors,plans,definition):
    assert value['status']=='ORIGINAL_FULL_B_R_JOINED_ROOT_REVIEW_REQUIRED' and value['accepted_by_root'] is False
    assert value['qualification'] is value['performance_accepted'] is value['collection_authorized'] is value['candidate_pairs_authorized'] is value['merge_authorized'] is False
    assert value['campaign_root']==str(ROOT) and value['held_excluded']==[5004,5006] and value['final_anchors']==anchors
    assert set(value['executions'])==set(value['evaluations'])=={'B','R'}
    previous=0
    for role in ('B','R'):
        execution=m.bound(value['executions'][role]);assert execution['native_argv']==original_argv(role,anchors,definition)
        assert execution['rc']==0 and not execution.get('error') and previous<=execution['started_ns']<execution['finished_ns']<=value['completed_ns'];previous=execution['finished_ns']
        for channel in ('stdout','stderr'):
            ref=execution[channel];path=m.canonical(ref['path'])
            assert m.sha(path)==ref['sha256'] and path.stat().st_size==ref['bytes']
        assert not Path(execution['stderr']['path']).read_bytes()
        summary=m.parse(Path(execution['stdout']['path']).read_bytes())
        assert summary==dict(status='analysis_complete_root_review_required',stage='final-evaluate',slots=sorted(plans[role]['slots']),qualification=False)
        assert set(value['evaluations'][role])==set(plans[role]['slots']) and len(value['evaluations'][role])==(36 if role=='B' else 18)
        for name,ref in value['evaluations'][role].items():
            assert ref['path']==str(Path(plans[role]['out'])/(name+'.evaluation.json'))
            result=m.bound(ref);assert result['qualification'] is False and result['root_acceptance_required'] is True

def main():
    assert len(sys.argv)==4 and sys.pycache_prefix is None and not os.environ.get('PYTHONPYCACHEPREFIX')
    c=content_module();m=c.reviewed_metadata();ref=dict(path=sys.argv[1],sha256=sys.argv[2]);req=m.bound(ref);c.no_authority(req)
    assert req['schema']==1 and req['accepted_by_root'] is True and req['artifact_evaluation_authorized'] is True
    assert req['campaign_root']==str(ROOT) and req['held_excluded']==[5004,5006] and req['helper']==m.reference(m.canonical(__file__))
    adoption=m.bound(req['helper_source_acceptance']);c.no_authority(adoption)
    assert adoption['accepted_by_root'] is adoption['source_only'] is True and adoption['helper']==req['helper'] and adoption['campaign_root']==str(ROOT)
    decision=m.bound(req['actual_final_content_acceptance']);c.no_authority(decision)
    assert decision['status']=='ACTUAL_FINAL_CONTENT_ONLY_ROOT_ACCEPTED' and decision['accepted_by_root'] is decision['actual_final_contents_accepted'] is True
    assert decision['campaign_root']==str(ROOT) and decision['held_excluded']==[5004,5006]
    assert decision['helper']==m.reference(CONTENT) and decision['original_evaluation_required'] is decision['strict_supplement_separate'] is True
    checked=c.review(m,m.bound(decision['request']));assert checked['outcome']['final_anchors']==decision['final_anchors']
    assert checked['pending']['metadata_io_completed_ns']<decision['actual_final_contents_accepted_ns']<=decision['reviewed_ns']<time.time_ns()
    anchors=decision['final_anchors'];ctx=checked['context'];plans=checked['plans']
    # layout_metadata plans intentionally expose original out/groups/slots.
    Rdefinition=m.reference(m.canonical(checked['finals']['R']['definition']))
    assert Rdefinition['sha256']==ctx['R_definition_sha256']
    assert m.sha(BD)==BD_SHA and m.sha(RD)==RD_SHA
    out=Path(sys.argv[3]);assert out.is_absolute() and out.parent==ROOT and out.resolve()==out and not out.exists() and not out.is_symlink()
    mode=req['mode'];assert mode in ('original','strict')
    if mode=='original':
        assert req['original_full_evaluation_authorized'] is True and req['strict_supplement_authorized'] is False and req['original_full_completion'] is None
        for plan in plans.values():
            for name in plan['slots']:
                assert not (Path(plan['out'])/(name+'.evaluation.json')).exists() and not (Path(plan['out'])/(name+'.analysis-failure.json')).exists(),'existing evaluation/failure; no automatic retry'
        out.mkdir();executions={};evaluations={}
        for role in ('B','R'):
            run,result=execute(m,original_argv(role,anchors,Rdefinition),out,'original-'+role)
            assert result==dict(status='analysis_complete_root_review_required',stage='final-evaluate',slots=sorted(plans[role]['slots']),qualification=False)
            executions[role]=run;evaluations[role]={name:m.reference(Path(plans[role]['out'])/(name+'.evaluation.json')) for name in sorted(plans[role]['slots'])}
        completion=dict(schema=1,status='ORIGINAL_FULL_B_R_JOINED_ROOT_REVIEW_REQUIRED',accepted_by_root=False,campaign_root=str(ROOT),held_excluded=[5004,5006],
            request=ref,final_anchors=anchors,actual_final_content_acceptance=req['actual_final_content_acceptance'],executions=executions,evaluations=evaluations,
            completed_ns=time.time_ns(),qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False,
            original_numerical_UNKNOWN_must_remain=True,strict_supplement_separate=True)
        verify_original_completion(m,completion,anchors,plans,Rdefinition)
        print(json.dumps(m.save(out/'original-full-completion.pending-root-review.json',completion),allow_nan=False));return
    assert req['strict_supplement_authorized'] is True and req['original_full_evaluation_authorized'] is False
    original=m.bound(req['original_full_completion']);verify_original_completion(m,original,anchors,plans,Rdefinition)
    assert original['actual_final_content_acceptance']==req['actual_final_content_acceptance'] and original['completed_ns']<time.time_ns()
    out.mkdir();proofs=[]
    for role in ('B','R'):
        service=sorted(name for name in plans[role]['slots'] if name.endswith('-service-final'))
        assert len(service)==(13 if role=='B' else 6)
        for name in service:
            bundle=m.reference(Path(plans[role]['out'])/(name+'.bundle.json'))
            request=copy_context(ctx)
            request.update(schema=1,accepted_by_root=True,artifact_replay_authorized=True,qualification=False,performance_accepted=False,collection_authorized=False,merge_authorized=False,
                held_excluded=[5004,5006],anchor=anchors[role],R_anchor=anchors['R'],bundle=bundle,
                definition=m.reference(Path(checked['finals'][role]['definition'])),metadata_preservation_acceptance=decision['metadata_preservation_acceptance'])
            request_path=out/(role+'-'+name+'.request.json');request_ref=m.save(request_path,request)
            proofout=out/(role+'-'+name+'.strict-proof')
            _,proof_ref=execute(m,['python3','-B',ctx['consumer']['path'],request_ref['path'],request_ref['sha256'],str(proofout)],out,role+'-'+name)
            proof=m.bound(proof_ref)
            assert proof['status']=='SEPARATE_PRODUCT_GUARD_PROOF_ONLY' and proof['original_numerical_result_unmodified'] is True and proof['numerical_UNKNOWN_can_pass'] is False
            assert proof['qualification'] is proof['performance_accepted'] is proof['collection_authorized'] is proof['merge_authorized'] is False
            proofs.append(dict(role=role,bundle=bundle,request=request_ref,proof=proof_ref))
    assert len(proofs)==19
    value=dict(schema=1,status='SEPARATE_STRICT19_REPLAY_JOINED_ROOT_REVIEW_REQUIRED',accepted_by_root=False,request=ref,original_full_completion=req['original_full_completion'],proofs=proofs,
        qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False,
        original_numerical_UNKNOWN_must_remain=True,completed_ns=time.time_ns())
    print(json.dumps(m.save(out/'strict19-completion.pending-root-review.json',value),allow_nan=False))

def copy_context(value):
    # JSON context contains only actual immutable source refs/settings.
    return json.loads(json.dumps(value,allow_nan=False))

if __name__=='__main__':main()
