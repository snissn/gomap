"""Finite source-only preparation; no imports or execution of campaign helpers."""
import ast,hashlib,json,difflib
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
NROOT=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
inputs={};deltas=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inp(name,expected=None):
 p=BASE/name;d=sha(p)
 if expected:assert d==expected,(name,d,expected)
 inputs[name]=dict(sha256=d,bytes=p.stat().st_size,scope='direct byte hashing and bounded source/JSON inspection');return p

def load(name,expected=None):return json.loads(inp(name,expected).read_bytes())
def save(name,v):
 with (HERE/name).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def nref(p):return dict(path=str(NROOT/p.relative_to(BASE)),sha256=sha(p))
anchor=load('qualification-v12-refresh/qualification-v10-prospective-root-v1/pre-c1-anchor.accepted-v2.json','888b36ee11f99c77af68341651cef36e1fe4cb817652091e17edb90eec8497b4')
post=load('qualification-v12-refresh/qualification-v10-prospective-root-v1/post-small-source-anchor.accepted-v1.json','b3c1a781ca144888931eb882f9b306de06062aa00908af66e13cbd8a2e177f17')
rule=load('qualification-v12-refresh/qualification-v10-prospective-root-v1/prospective-rule-freeze.accepted-v1.json','9786f95c9b82385e0b950af22f4b92b5c7b079b4012ed809a0db458380be65d4')
lock=load('qualification-v12-root-preparation-v1/actual-fresh-source-lock-v12.json','bda4d2486d2e66ee33533d601d216092ce1cd8f5211cfb02aac0d9d2bf823c75')
assert len(anchor['files'])==12555 and len(post['files'])==12741
assert all(post['files'].get(k)==v for k,v in anchor['files'].items())
manifest=load('qualification-v12-refresh/qualification-v10/manifest.json',lock['manifest_sha256'])
composition=inp('qualification-v12-root-preparation-v1/actual-root-approved-source-inputs-v1/source-composition-v12.json',lock['composition']['sha256'])
rdef=inp('qualification-v12-refresh/qualification-v10/prospective-v10-root-v1/r-definition.accepted.json',rule['R_definition_sha256'])
selection=inp('qualification-v12-fresh-controls-v1/deployment-helpers-selection.json','eaf90e128e43bbfee259f65a5e8866028899abb25e28877bd42c52afa6e8b7fd')
driver=inp('qualification-v12-fresh-controls-v1/collection-native-driver-v12-v2.py','aa98083ab9ab2b19cb1bc90ecd562ec2c9e49314fafb28f2f3d8035bbb06bbe8')
verifier=inp('qualification-v12-fresh-controls-v1/verify-qualification-v10-deployment-v2.py','11246d9d5f2e50711ae178b3b2acb2938f7400060e7f77efc1ff9293c76d52fc')
guard=inp('qualification-v12-fresh-controls-v1/global54-artifact-guard-v12-operational-v1.py','3afb3b02c11d7138cc9846489d34b39aa346333a8660dfb0f5e2ddf5daa359b6')
for p in (driver,verifier,selection,guard):assert anchor['files'][str(NROOT/p.relative_to(BASE))]==sha(p)
for role,ref in anchor['executed_controllers'].items():inp(str(Path(ref['path']).relative_to(NROOT)),ref['sha256'])
for k,ref in rule['pre_c1_bindings'].items():inp(str(Path(ref['path']).relative_to(NROOT)),ref['sha256'])
for k in ('consumer','witness','policy','global_replay_helper'):
 ref=rule['source_selection'][k];inp(str(Path(ref['path']).relative_to(NROOT)),ref['sha256'])
for name,digest in load('qualification-v10-global-deployment-preparation-v2/immutable-pins.json','2fccfac7a950aad6f397e15d94d5cc7b45d4b45ec5943d567c1a19e26cc4d406').items():inp(name,digest)
inp('qualification-v9-selected-source-preparation-v1/root_native_io.py','fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1')
inp('qualification-v10-root-runtime-preparation-v1/root-final-analysis-binding-source-preparation-acceptance-v1.json','046ddda274e16247d63bd4673fd23a69f2a551711317d5db2f80f8d7748de1b3')
sub=[('qualification-v11-refresh/qualification-v10','qualification-v12-refresh/qualification-v10'),('qualification-v11-final-content-and-evaluation-preparation-v1','qualification-v12-final-artifact-preparation-v1'),('qualification-v11-final-artifact-preparation-v1','qualification-v12-final-artifact-preparation-v1'),('qualification-v11-fresh-controls-v1','qualification-v12-fresh-controls-v1'),('collection-native-driver-v11-v1.py','collection-native-driver-v12-v2.py'),('global54-artifact-guard-v11-operational-v1.py','global54-artifact-guard-v12-operational-v1.py'),('collection-driver-pairs-v11','collection-driver-pairs-v12'),('fb852636b95f8c4b7484a9d54653195da1be95e18990e03cde3818dc654473cd',sha(driver)),('f19c9398f75c1c6f988e0ec21056634cf50b2d84e662b9649a13b0f48cf59bb9',sha(selection)),('2df6cc8824df6edbace58939f9f99144e92585390ac540f15a4b15176c18013a',sha(guard)),('d4e02b3a625a5cd10abf6b92cbc21a921ca82cc1a67931a86d251075e4c64827',anchor['executed_controllers']['R']['sha256']),('d5bc4cbc09450ae521aec023a6f973f289f4ba6af552b49131c882880e8a97fc',anchor['executed_controllers']['B']['sha256']),('3325dfe77940fec8587d8b61b1ac4e0b2f72caca',manifest['sources']['A']['head']),('7f7dd3b126df465ed971a410651d44b2ecc62383',manifest['sources']['R']['head']),('3b72833df173d1277df88be5453a58d6d311bd81',manifest['sources']['B']['head']),('62fc3e0348d3022765a3fa7c026f4c957bf128a83720775685553e9104b61748',lock['manifest_sha256']),('9a58d370032bda9765926ff3df5a68d7836f95f7ed0aa8a8a0710c9b2e59ccf3',sha(composition)),('8717a8854760e9fe3997eff5db1456a3e9d11c9de5c4ea2f40f0ea01324d4863',sha(rdef))]
olds=[('qualification-v11-final-artifact-preparation-v1','root-final-raw-closure-v11-v1.py','f9f35084902da6c6d52121cd274ecd192d6cbf9698fe3d8133cdfc43d00fc124'),('qualification-v11-final-artifact-preparation-v1','root-final-metadata-io-v11-v1.py','d7dbe845e2461a9de7935586e6adacc5696ba25559f3b60d1fcc5b803be602ea'),('qualification-v11-final-content-and-evaluation-preparation-v1','root-final-content-acceptance-v11-v1.py','f44cf1308bd3a6a0252569ca17e949cce702e2855c726f1023de216bbad58ec3'),('qualification-v11-final-content-and-evaluation-preparation-v1','root-run-final-evaluation-v11-v1.py','09472329183362835cf64a5f485e7e13ad792dd0bea8db2e6f0f9dc2f71b2194'),('qualification-v11-root-preparation-v1','root-run-final-raw-and-metadata-v11-v1.py',None),('qualification-v11-root-preparation-v1','root-run-final-content-and-evaluations-v11-v1.py',None)]
for _,name,_ in olds:sub.append((name,name.replace('v11','v12')))
checks=[]
# Strict local bound actual request admission, applied only to the two root launchers.
admission='''def local_bound(item):
    assert set(item)=={'path','sha256'}
    p=BASE/Path(item['path']).relative_to(REMOTE)
    assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve()==p
    assert sha(p)==item['sha256']
    return p,read(p)


def root_request():
    assert len(sys.argv)==3 and sys.flags.dont_write_bytecode and sys.pycache_prefix is None and not os.environ.get('PYTHONPYCACHEPREFIX')
    p=Path(sys.argv[1])
    assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve()==p and sha(p)==sys.argv[2]
    q=read(p);flags(q)
    assert q['schema']==1 and q['accepted_by_root'] is True and q['owner']=='/root'
    assert q['campaign_root']==str(ROOT) and q['held_excluded']==[5004,5006]
    assert q['helper']==remote_ref(Path(__file__).resolve())
    assert q['serial_and_quiescent'] is q['exclusive_native_owner'] is True
    assert q['root_final_handoff_authorized'] is True
    _,adoption=local_bound(q['helper_source_acceptance']);flags(adoption)
    assert adoption['accepted_by_root'] is adoption['source_only'] is True
    assert adoption['helper']==q['helper'] and adoption['campaign_root']==str(ROOT)
    return q


'''
for folder,name,pin in olds:
 oldp=inp(folder+'/'+name,pin);old=oldp.read_text();new=old;used=[]
 for a,b in sub:
  if a in new:used.append([a,b,new.count(a)]);new=new.replace(a,b)
 newname=name.replace('v11','v12')
 extras=[]
 if 'root-run-final-raw-and-metadata' in name:
  for a,b in [("INDEPENDENT = BASE/'qualification-v11-final-artifact-independent-review-v1/REPORT.md'","INDEPENDENT = None"),("REVIEW_SHA = 'b85f4fdced1f287fe6ca346d5641f9d4c1ba652363019fd9d24069fbb1488c87'","REVIEW_SHA = None")]:
   assert a in new;new=new.replace(a,b);extras.append([a,b])
  new=new.replace('import os\n','import os\nimport sys\n')
  insert=admission
  new=new.replace("if __name__=='__main__':\n",insert+"if __name__=='__main__':\n")
  swaps=[("    assert __debug__\n","    assert __debug__\n    q=root_request()\n    INDEPENDENT,_=local_bound(q['independent_source_review']);REVIEW_SHA=q['independent_source_review']['sha256']\n"),("    joined=read(HERE/'root-original114-pair-phase-joined-v11-v1.json')","    _,joined=local_bound(q['joined_pair_phase'])"),("    raw_adopt=HERE/'root-final-raw-helper-source-acceptance-v11-v1.json'","    raw_adopt,_=local_bound(q['raw_helper_source_acceptance'])"),("    metadata_adopt=HERE/'root-final-metadata-helper-source-acceptance-v11-v1.json'","    metadata_adopt,_=local_bound(q['metadata_helper_source_acceptance'])")]
 elif 'root-run-final-content-and-evaluations' in name:
  new=new.replace('import os\n','import os\nimport sys\n')
  insert=admission.replace("remote_ref(Path(__file__).resolve())","ref(Path(__file__).resolve())")
  new=new.replace("if __name__=='__main__':\n",insert+"if __name__=='__main__':\n")
  swaps=[("    assert __debug__\n","    assert __debug__\n    q=root_request()\n"),("    outcome_path=HERE/'root-final-raw-and-metadata-actual-outcome-v11-v1.json'","    outcome_path,_=local_bound(q['actual_raw_and_metadata_outcome'])"),("    content_adoption=HERE/'root-final-content-source-acceptance-v11-v1.json'","    content_adoption,_=local_bound(q['content_helper_source_acceptance'])"),("    evaluation_adoption=HERE/'root-original-first-and-strict-evaluation-source-acceptance-v11-v1.json'","    evaluation_adoption,_=local_bound(q['evaluation_helper_source_acceptance'])"),("    metadata_label='v11-actual-final-exact34-metadata-io-v1'","    metadata_label=q['metadata_execution_label']"),("    result_path=HERE/'actual-final-exact34-metadata-result-v11-v1.json'","    result_path,_=local_bound(q['actual_metadata_result'])")]
 else:insert='';swaps=[]
 for a,b in swaps:assert a in new,(name,a);new=new.replace(a,b);extras.append([a,b])
 # Literal phase/output labels and state field are identity-only adaptations.
 if name.startswith('root-run-final-') and ('metadata' in name or 'evaluations' in name):
  for a,b in [('fresh-v11','fresh-v12'),('v11-','v12-'),('-v11-','-v12-'),('qualification_v11_current','qualification_v12_current')]:
   if a in new:used.append([a,b,new.count(a)]);new=new.replace(a,b)
 if 'metadata-io' in name:sub.append(('d7dbe845e2461a9de7935586e6adacc5696ba25559f3b60d1fcc5b803be602ea',hashlib.sha256(new.encode()).hexdigest()))
 if 'raw-closure' in name:sub.append(('f9f35084902da6c6d52121cd274ecd192d6cbf9698fe3d8133cdfc43d00fc124',hashlib.sha256(new.encode()).hexdigest()))
 if 'content-acceptance' in name:sub.append(('f44cf1308bd3a6a0252569ca17e949cce702e2855c726f1023de216bbad58ec3',hashlib.sha256(new.encode()).hexdigest()))
 if 'root-run-final-evaluation-v11' in name:sub.append(('09472329183362835cf64a5f485e7e13ad792dd0bea8db2e6f0f9dc2f71b2194',hashlib.sha256(new.encode()).hexdigest()))
 (HERE/newname).write_text(new)
 (HERE/(newname+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(oldp),tofile=newname)))
 compile(new,newname,'exec');ast.parse(new)
 # Reconstruction uses exact declared delta sequence, which includes additive admission and all bindings.
 reconstructed=old
 for a,b,_ in used:
  # Launcher used contains late broad label changes: they must run after extra edits.
  if a in ('fresh-v11','v11-','-v11-','qualification_v11_current'):continue
  reconstructed=reconstructed.replace(a,b)
 if insert:reconstructed=reconstructed.replace('import os\n','import os\nimport sys\n').replace("if __name__=='__main__':\n",insert+"if __name__=='__main__':\n")
 for a,b in extras:reconstructed=reconstructed.replace(a,b)
 for a,b,_ in used:
  if a in ('fresh-v11','v11-','-v11-','qualification_v11_current'):reconstructed=reconstructed.replace(a,b)
 assert reconstructed==new,newname
 oldfunc={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(old).body if isinstance(n,ast.FunctionDef)}
 newfunc={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(new).body if isinstance(n,ast.FunctionDef)}
 changed=[k for k in oldfunc if newfunc.get(k)!=oldfunc[k]]
 deltas.append(dict(input=folder+'/'+name,output=newname,literal_substitutions=used,extra_replacements=extras,exact_additive_admission=insert or None,original_function_count=len(oldfunc),direct_changed_original_functions=changed,new_functions=sorted(set(newfunc)-set(oldfunc)),reconstructs_candidate_bytes=True))
 checks.append(dict(name='compile-and-exact-declared-reconstruction-'+newname,status='PASS'))
# Draft interfaces inherit exact fields; bind only observed V12 sources/current records.
for folder in ('qualification-v11-final-artifact-preparation-v1','qualification-v11-final-content-and-evaluation-preparation-v1'):
 for p in sorted((BASE/folder).glob('*.draft.json')):
  data=json.loads(inp(str(p.relative_to(BASE))).read_bytes());text=json.dumps(data)
  for a,b in sub:text=text.replace(a,b)
  data=json.loads(text)
  if 'strict_context' in data:
   ctx=data['strict_context'];ctx['current_bindings'].update(rule['pre_c1_bindings']);ctx['prospective_rule_freeze']=nref(BASE/'qualification-v12-refresh/qualification-v10-prospective-root-v1/prospective-rule-freeze.accepted-v1.json')
  if p.name=='strict-replay-request.draft.json':
   data['current_bindings'].update(rule['pre_c1_bindings']);data['prospective_rule_freeze']=nref(BASE/'qualification-v12-refresh/qualification-v10-prospective-root-v1/prospective-rule-freeze.accepted-v1.json')
  save(p.name,data)
flags=dict(accepted_by_root=False,source_only=True,qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False)
null=dict(path=None,sha256=None)
for kind,name in [('raw-and-metadata','root-run-final-raw-and-metadata-v12-v1.py'),('content-and-evaluations','root-run-final-content-and-evaluations-v12-v1.py')]:
 q=dict(flags,schema=1,status='SOURCE_ONLY_NOT_EXECUTABLE',owner=None,authorized_ns=None,campaign_root=anchor['root'],held_excluded=[5004,5006],helper=nref(HERE/name),helper_source_acceptance=null,serial_and_quiescent=False,exclusive_native_owner=False,root_final_handoff_authorized=False)
 if kind=='raw-and-metadata':q.update(independent_source_review=null,joined_pair_phase=null,raw_helper_source_acceptance=null,metadata_helper_source_acceptance=null)
 else:q.update(actual_raw_and_metadata_outcome=null,content_helper_source_acceptance=null,evaluation_helper_source_acceptance=null,metadata_execution_label=None,actual_metadata_result=null)
 save('root-'+kind+'-request.draft.json',q)
save('declared-source-deltas-and-AST-verification.json',dict(status='SOURCE_ONLY_DECLARED_DELTAS',accepted_by_root=False,deltas=deltas,checks=checks))
save('exact-input-output-manifest.json',dict(status='SOURCE_ONLY_UNACCEPTED',accepted_by_root=False,inputs=inputs,outputs={p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in HERE.iterdir() if p.is_file()}))
print(json.dumps(dict(status='SOURCE_ONLY_PREPARATION_WRITTEN',sources=6,inputs=len(inputs),checks=len(checks))))
