"""Root continuation: wait for the actual calibration join, then artifact replay.
No measurement, altered calculations, retry, performance or merge authority.
"""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
BASE=Path('/Users/michaelseiler/dev/snissn/gomap/tmp/quicksilver-maintenance-5028-20261005')
HERE=BASE/'qualification-v12-root-preparation-v1'
RECEIPTS=BASE/'qualification-v9-selected-source-preparation-v1'
HELPER=BASE/'qualification-v12-later-execution-preparation-v3/root-run-original-global-analyses-v12-v1.py'
HELPER_SHA='bf391958e4d1f08f16f5b0f3e784eb635cec839208198fdf61f042efdd5b84e0'
CAL=HERE/'remaining-calibration-controller-actual-v12-v1-run.json'
REQUEST=HERE/'original-global-analysis-actual-request-v12-v1.json'
LABEL='original-global-analysis-controller-actual-v12-v1'
FLAGS=('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def actual(p):
 r=read(p);assert r['rc']==0 and not r.get('error') and 0<r['started_ns']<r['finished_ns']
 for c in ('stdout','stderr'):
  d=r[c];f=Path(d['path']);assert f.is_file() and not f.is_symlink() and f.resolve()==f
  assert d['sha256']==sha(f) and d['bytes']==f.stat().st_size
 return r
assert __debug__ and sys.flags.dont_write_bytecode and sha(HELPER)==HELPER_SHA
assert not REQUEST.exists() and not (HERE/(LABEL+'-run.json')).exists()
print(json.dumps(dict(status='WAITING_REAL_EXISTING_CALIBRATION_JOIN',pid=os.getpid(),started_ns=time.time_ns())),flush=True)
while True:
 if CAL.exists():
  cal=read(CAL)
  if cal.get('returncode') is not None:
   assert cal['returncode']==0 and cal['child_joined'] is True
   assert 0<cal['started_ns']<cal['finished_ns']<=time.time_ns()
   assert sha(Path(cal['script']))==cal['sha256']
   for c in ('stdout','stderr'):
    f=Path(cal[c]);assert f.is_file() and not f.is_symlink() and f.resolve()==f
   assert not Path(cal['stderr']).read_bytes()
   active=read(BASE/'state.json')['native_active']
   if active is None:break
 time.sleep(5)
rest=actual(RECEIPTS/'v12-actual-original-remaining-calibration-v1-run.json')
small=actual(RECEIPTS/'v12-actual-original-small-calibration-v1-run.json')
assert small['finished_ns']<rest['started_ns']<rest['finished_ns']<=time.time_ns()
q=read(HERE/'original-global-analysis-actual-inputs-draft-v12-v1.json')
assert q['source_only'] is True and q['accepted_by_root'] is False and q['later_artifact_execution_authorized'] is False
assert all(q[k] is False for k in FLAGS)
assert q['helper']['sha256']==HELPER_SHA
q.pop('source_only');q.pop('note')
q.update(accepted_by_root=True,later_artifact_execution_authorized=True,authorized_ns=time.time_ns(),
 status='ROOT_AUTHORIZED_ORIGINAL_GLOBAL_ARTIFACT_REPLAY_ONLY',
 actual_remaining_phase_join=dict(path=str(CAL),sha256=sha(CAL)))
save(REQUEST,q)
argv=[sys.executable,'-B',str(HELPER),str(REQUEST),sha(REQUEST)]
row=dict(argv=argv,owner='/root',started_ns=time.time_ns(),rc=None,qualification=False,performance_accepted=False)
out=HERE/(LABEL+'-stdout.txt');err=HERE/(LABEL+'-stderr.txt')
with out.open('xb') as stdout,err.open('xb') as stderr:
 child=subprocess.Popen(argv,stdout=stdout,stderr=stderr);row['local_pid']=child.pid
 print(json.dumps(dict(status='ACTUAL_JOIN_ACCEPTED_ORIGINAL_ARTIFACT_REPLAY_STARTED',pid=child.pid,request=str(REQUEST),started_ns=row['started_ns'])),flush=True)
 try:row['rc']=child.wait()
 finally:
  row.update(finished_ns=time.time_ns(),stdout=dict(path=str(out),bytes=out.stat().st_size,sha256=sha(out)),stderr=dict(path=str(err),bytes=err.stat().st_size,sha256=sha(err)))
  save(HERE/(LABEL+'-run.json'),row)
assert row['rc']==0,'actual artifact replay failed; retained once; no retry'
print(json.dumps(dict(status='ORIGINAL_ARTIFACT_REPLAY_JOINED',rc=row['rc'],finished_ns=row['finished_ns'])),flush=True)
