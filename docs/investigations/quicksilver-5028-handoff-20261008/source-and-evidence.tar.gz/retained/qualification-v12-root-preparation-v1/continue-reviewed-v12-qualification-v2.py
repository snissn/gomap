"""Root sequential continuation; requires genuine joins and separate prepair admission."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,types
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
REMOTE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=REMOTE/'qualification-v12-refresh/qualification-v10'
PACKET=BASE/'qualification-v12-root-continuation-output-fix-preparation-v1'
CONFIG_SHA='72d7a53db8f8af8e2c30ce2c59195599370b2ecc2bf90cea0d779790066d1b61'
FLAGS=('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized')
LATER=BASE/'qualification-v12-later-execution-preparation-v3'
FINAL=BASE/'qualification-v12-final-artifact-preparation-v1'
def canonical(p):
 p=Path(p);assert p.is_absolute() and p.resolve(strict=True)==p and p.is_file() and not p.is_symlink();return p

def sha(p):return hashlib.sha256(canonical(p).read_bytes()).hexdigest()
def read(p):return json.loads(canonical(p).read_bytes())
def ref(p):return dict(path=str(REMOTE/canonical(p).relative_to(BASE)),sha256=sha(p))
def local(r):
 assert set(r)=={'path','sha256'};p=canonical(BASE/Path(r['path']).relative_to(REMOTE));assert sha(p)==r['sha256'];return p

def bound(r):return read(local(r))
def flags(v):assert all(v[k] is False for k in FLAGS)
def scope(v):
 assert v['campaign_root']==str(ROOT) and v['held_excluded']==[5004,5006];flags(v)

OUTPUT_CONTRACTS = {'full-R-global54': {'status': 'ACTUAL_FULL_R_COMPLETE24_CANONICAL_B_AND_GLOBAL54_REPLAY_PASS', 'keys': ['schema', 'status', 'accepted_by_root', 'accepted_ns', 'campaign_root', 'held_excluded', 'full_R', 'full_R_predecessor', 'canonical_B_gate', 'global54_content_acceptance', 'global54_input', 'replay_execution', 'replay_result', 'qualification', 'performance_accepted', 'collection_authorized', 'candidate_pairs_authorized', 'merge_authorized']}, 'physical34': {'status': 'ACTUAL_PHYSICAL34_ROOT_CONTENT_ACCEPTANCE_PASS', 'keys': ['schema', 'status', 'acceptance', 'original_anchors', 'physical_anchors', 'preserved_count', 'no_pair_namespace', 'accepted_ns', 'qualification', 'performance_accepted', 'collection_authorized', 'candidate_pairs_authorized', 'merge_authorized']}, 'original-pairs': {'status': 'ORIGINAL_PAIR_DRIVER_JOINED_ACTUAL_RAW_CONTENT_REVIEW_REQUIRED', 'keys': ['schema', 'campaign_root', 'held_excluded', 'status', 'accepted_by_root', 'raw_contents_accepted', 'paired_driver_completion', 'paired_driver_activation', 'R_activation', 'full_R', 'full_R_predecessor', 'physical34_actual_acceptance', 'native_execution', 'global54_content_acceptance', 'metadata_preservation_acceptance', 'original_pair_count', 'state_specific_guard_count', 'counts_are_expected_until_raw_replay', 'raw_content_acceptance', 'expected_original_pairs', 'expected_state_specific_guards', 'joined_ns', 'qualification', 'performance_accepted', 'collection_authorized', 'candidate_pairs_authorized', 'merge_authorized']}, 'raw-metadata': {'status': 'ACTUAL_RAW114_ACCEPTED_EXACT34_IO_PENDING_FINAL_CONTENT_ACCEPTANCE', 'keys': ['schema', 'status', 'accepted_by_root', 'campaign_root', 'held_excluded', 'actual_raw_content_acceptance', 'actual_metadata_request', 'actual_metadata_completion', 'final_anchors', 'original_pair_count', 'state_specific_guard_count', 'qualification', 'performance_accepted', 'collection_authorized', 'candidate_pairs_authorized', 'merge_authorized', 'original_evaluation_required', 'strict_supplement_separate']}, 'content-evaluations': {'status': 'ACTUAL_ORIGINAL_FULL54_THEN_SEPARATE_STRICT19_JOINED_PRODUCT_DECISION_PENDING', 'keys': ['schema', 'status', 'accepted_by_root', 'campaign_root', 'held_excluded', 'actual_final_content_acceptance', 'original_full_completion', 'original_evaluations', 'separate_strict19_completion', 'separate_strict_proofs', 'original_pair_count', 'state_specific_guard_count', 'qualification', 'performance_accepted', 'collection_authorized', 'candidate_pairs_authorized', 'merge_authorized', 'original_numerical_UNKNOWN_must_remain', 'completed_ns']}}
PHYSICAL_ACCEPTANCE_KEYS = {'original_anchors', 'global54_actual_content_acceptance', 'consumer', 'candidate_pairs_authorized', 'accepted_ns', 'qualification', 'mapping', 'merge_authorized', 'status', 'owner', 'held_excluded', 'physical_anchors', 'receipt', 'accepted_by_root', 'schema', 'metadata_preservation_actual_contents_accepted', 'performance_accepted', 'preserved_completed_ns', 'request', 'campaign_root', 'collection_authorized', 'no_pair_namespace_at_acceptance', 'physical34_content_request'}
PHYSICAL_READBACK = HERE/'physical34-continuation-native-acceptance-readback-v12-v2.json'

def admit_output(phase,value,physical_acceptance=None):
    contract=OUTPUT_CONTRACTS[phase]
    assert isinstance(value,dict) and set(value)==set(contract['keys'])
    assert value['schema']==1 and value['status']==contract['status'];flags(value)
    if phase=='physical34':
        assert value['preserved_count']==34 and value['no_pair_namespace'] is True
        assert type(value['accepted_ns']) is int and 0<value['accepted_ns']<time.time_ns()
        for key in ('acceptance',):
            r=value[key];assert set(r)=={'path','sha256'} and isinstance(r['sha256'],str) and len(r['sha256'])==64
        assert set(value['original_anchors'])==set(value['physical_anchors'])=={'B','R'}
        a=physical_acceptance;assert isinstance(a,dict) and set(a)==PHYSICAL_ACCEPTANCE_KEYS;scope(a)
        assert a['schema']==1 and a['status']=='ACTUAL_EXACT34_BYTES_AND_PHYSICAL_ANCHORS_ROOT_ACCEPTED'
        assert a['accepted_by_root'] is a['metadata_preservation_actual_contents_accepted'] is True and a['owner']=='/root'
        assert a['accepted_ns']==value['accepted_ns'] and a['no_pair_namespace_at_acceptance'] is True
        assert a['original_anchors']==value['original_anchors'] and a['physical_anchors']==value['physical_anchors']
        assert type(a['preserved_completed_ns']) is int and 0<a['preserved_completed_ns']<a['accepted_ns']
    else:
        scope(value)
        if phase=='full-R-global54':
            assert value['accepted_by_root'] is True and type(value['accepted_ns']) is int and 0<value['accepted_ns']<time.time_ns()
            replay=value['replay_result']
            assert (replay['baseline_captures'],replay['guard_captures'],replay['B_slots'],replay['R_slots'])==(39,39,36,18)
        else:
            assert value['accepted_by_root'] is False and value['original_pair_count']==value['state_specific_guard_count']==114
            if phase=='original-pairs':
                assert value['raw_contents_accepted'] is value['raw_content_acceptance'] is False
                assert value['counts_are_expected_until_raw_replay'] is True
                assert value['expected_original_pairs']==value['expected_state_specific_guards']==114
                assert type(value['joined_ns']) is int and 0<value['joined_ns']<time.time_ns()
            elif phase=='raw-metadata':
                assert value['original_evaluation_required'] is value['strict_supplement_separate'] is True
                assert set(value['final_anchors'])=={'B','R'}
            elif phase=='content-evaluations':
                assert value['original_numerical_UNKNOWN_must_remain'] is True and len(value['separate_strict_proofs'])==19
                assert type(value['completed_ns']) is int and 0<value['completed_ns']<time.time_ns()
    return value

def read_physical_acceptance(io,value):
    r=value['acceptance'];assert set(r)=={'path','sha256'}
    assert Path(r['path']).parent==ROOT/'pre-pair-root-physical34-acceptance-v12-v1'
    assert Path(r['path']).name=='metadata-preservation-actual-content-acceptance.json'
    code="from pathlib import Path;import hashlib,sys;p=Path(sys.argv[1]);assert p.is_absolute() and p.resolve(strict=True)==p and p.is_file() and not p.is_symlink();data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==sys.argv[2];sys.stdout.buffer.write(data)"
    label='v12-continuation-physical34-native-acceptance-readback-v2'
    raw=io.native(['python3','-B','-c',code,r['path'],r['sha256']],label,180)
    assert hashlib.sha256(raw).hexdigest()==r['sha256']
    actual=json.loads(raw);admit_output('physical34',value,actual)
    # Preserve exact original native bytes; no authority or scope fields synthesized.
    with PHYSICAL_READBACK.open('xb') as out:out.write(raw)
    return actual

def save(p,v):
 with p.open('x') as out:json.dump(v,out,indent=2,allow_nan=False);out.write('\n')

def idle():assert read(BASE/'state.json')['native_active'] is None

def receipt(p,expected_argv):
 r=read(p);assert r['owner']=='/root' and r['argv']==expected_argv and r['rc']==0 and not r.get('error')
 assert type(r['local_pid']) is int and r['local_pid']>0 and 0<r['started_ns']<r['finished_ns']<=time.time_ns()
 for channel in ('stdout','stderr'):
  d=r[channel];assert set(d)=={'path','bytes','sha256'};s=canonical(d['path'])
  assert s.stat().st_size==d['bytes'] and sha(s)==d['sha256']
 assert not canonical(r['stderr']['path']).read_bytes()
 return r

def wait_file(p,label):
 ticks=0
 while not p.exists():
  if ticks%6==0:print(json.dumps(dict(status=label,owner='/root',pid=os.getpid())),flush=True)
  time.sleep(5);ticks+=1
 return canonical(p)

def load_source(r,name):
 p=local(r);assert sys.pycache_prefix is None and not (p.parent/'__pycache__').exists()
 m=types.ModuleType(name);m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__);return m

def source_admission(config,phase):
 aggregate=bound(config['adoption']);scope(aggregate)
 assert aggregate['source_only'] is aggregate['accepted_by_root'] is True and aggregate['owner']=='/root'
 assert aggregate['selected'][phase]==config['selected'][phase]
 assert aggregate['source_adoptions'][phase]==config['adoptions'][phase]
 a=bound(config['adoptions'][phase]);scope(a)
 assert a['source_only'] is a['accepted_by_root'] is True and a['helper']==config['selected'][phase]
 local(config['selected'][phase]);return a

def invoke(config,phase,actual_fields,authorization,io=None):
 idle();source_admission(config,phase)
 q=bound(config['drafts'][phase]);scope(q)
 assert q['source_only'] is True and q['accepted_by_root'] is False and q['authorized_ns'] is None
 assert q['helper']==config['selected'][phase] and q['helper_source_acceptance']==config['adoptions'][phase]
 q.pop('source_only');q.update(actual_fields)
 q.update(accepted_by_root=True,owner='/root',authorized_ns=time.time_ns(),status='ROOT_AUTHORIZED_SEQUENTIAL_REVIEWED_HANDOFF_ONLY')
 q[authorization]=True
 for k in ('serial_and_quiescent','exclusive_native_owner'):
  if k in q:q[k]=True
 flags(q)
 request=HERE/(phase+'-continuation-actual-request-v12-v1.json');save(request,q)
 helper=local(q['helper']);argv=[sys.executable,'-B',str(helper),str(request),sha(request)]
 label=phase+'-continuation-actual-v12-v1';run=HERE/(label+'-run.json')
 out=HERE/(label+'-stdout.txt');err=HERE/(label+'-stderr.txt')
 assert not run.exists()
 row=dict(argv=argv,owner='/root',script=str(helper),script_sha256=sha(helper),request=ref(request),started_ns=time.time_ns(),rc=None,child_joined=False,local_owner_pid=os.getpid(),qualification=False,performance_accepted=False,merge_authorized=False)
 with out.open('xb') as stdout,err.open('xb') as stderr:
  child=subprocess.Popen(argv,stdout=stdout,stderr=stderr);row['local_pid']=child.pid
  print(json.dumps(dict(status='REVIEWED_CHILD_STARTED',phase=phase,pid=child.pid,argv=argv)),flush=True)
  try:row['rc']=child.wait();row['child_joined']=True
  except BaseException as error:
   row['error']=repr(error)
   if child.poll() is None:child.terminate()
   row['rc']=child.wait();row['child_joined']=True
   raise
  finally:
   row.update(finished_ns=time.time_ns(),stdout=dict(path=str(out),bytes=out.stat().st_size,sha256=sha(out)),stderr=dict(path=str(err),bytes=err.stat().st_size,sha256=sha(err)))
   save(run,row)
 receipt(run,argv);assert row['child_joined'] is True;idle()
 rows=[json.loads(line) for line in out.read_bytes().splitlines() if line.strip()]
 assert rows and all(isinstance(row,dict) for row in rows)
 value=rows[-1]
 acceptance=read_physical_acceptance(io,value) if phase=='physical34' else None
 return admit_output(phase,value,acceptance)

def genuine_outcome(path,value,status,phase):
 actual=read(path);assert actual==value and actual['status']==status
 acceptance=read(PHYSICAL_READBACK) if phase=='physical34' else None
 if acceptance is not None:assert sha(PHYSICAL_READBACK)==actual['acceptance']['sha256']
 admit_output(phase,actual,acceptance);return ref(path)

def main():
 assert __debug__ and sys.flags.dont_write_bytecode and sys.pycache_prefix is None
 assert sha(PACKET/'finite-config.json')==CONFIG_SHA
 config=read(PACKET/'finite-config.json')
 # Explicit root invocation authorizes this continuation; all source admissions remain source-only.
 assert len(sys.argv)==3
 admission=read(canonical(sys.argv[1]));assert sha(Path(sys.argv[1]))==sys.argv[2]
 scope(admission);assert admission['owner']=='/root' and admission['accepted_by_root'] is True and admission['continuation_authorized'] is True
 assert admission['helper']==ref(Path(__file__).resolve()) and admission['current_source_adoption']==config['adoption']
 assert type(admission['authorized_ns']) is int and 0<admission['authorized_ns']<time.time_ns()
 previous=HERE/'original-global-analysis-controller-actual-v12-v1-run.json'
 wait_file(previous,'WAITING_GENUINE_ORIGINAL_GLOBAL_JOIN')
 original_request=HERE/'original-global-analysis-actual-request-v12-v1.json'
 original_helper=local(config['original_helper'])
 r=receipt(previous,[sys.executable,'-B',str(original_helper),str(original_request),sha(original_request)])
 accepted_path=LATER/'root-global-calibration-content-acceptance-v12-v1.json'
 accepted=read(accepted_path);scope(accepted)
 assert accepted['accepted_by_root'] is True and accepted['status']=='ACTUAL_ORIGINAL_39C_39GUARDS_B36_R18_CONTENTS_ACCEPTED'
 assert (accepted['calibration_captures'],accepted['calibration_guards'],accepted['B_slots'],accepted['R_slots'])==(39,39,36,18)
 stream_rows=[json.loads(line) for line in canonical(r['stdout']['path']).read_bytes().splitlines() if line.strip()]
 assert stream_rows and all(isinstance(row,dict) for row in stream_rows) and stream_rows[-1]==accepted
 assert r['started_ns']<=accepted['accepted_ns']<=r['finished_ns']
 idle()
 io=load_source(config['io'],'unchanged_root_io');utility=load_source(config['selected']['utility'],'reviewed_exact_stage')
 source_admission(config,'utility')
 staged=[]
 sources=config['staging_sources']
 for start in range(0,len(sources),32):
  batch=sources[start:start+32]
  staged.append(utility.exact_stage(io,{Path(x['path']).relative_to(REMOTE).as_posix():local(x) for x in batch},'v12-continuation-reviewed-source-batch-'+str(start//32+1)))
 binding_path=HERE/'root-continuation-actual-staged-source-binding-v12-v1.json'
 binding=dict(schema=1,status='ACTUAL_REVIEWED_SOURCE_BYTES_STAGED_ROOT_INSPECTION_REQUIRED',accepted_by_root=False,owner='/root',campaign_root=str(ROOT),held_excluded=[5004,5006],source_adoption=config['adoption'],sources=sources,actual_stages=staged,staged_ns=time.time_ns(),qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False)
 save(binding_path,binding)
 full=invoke(config,'full-R-global54',dict(actual_global_analysis_content_acceptance=ref(accepted_path)),'later_artifact_execution_authorized')
 full_ref=genuine_outcome(LATER/'root-full-R-and-global54-actual-acceptance-v12-v1.json',full,'ACTUAL_FULL_R_COMPLETE24_CANONICAL_B_AND_GLOBAL54_REPLAY_PASS','full-R-global54')
 assert full['accepted_by_root'] is True and (full['replay_result']['baseline_captures'],full['replay_result']['guard_captures'],full['replay_result']['B_slots'],full['replay_result']['R_slots'])==(39,39,36,18)
 physical=invoke(config,'physical34',dict(actual_full_R_GLOBAL54_content_acceptance=full_ref),'later_artifact_execution_authorized',io=io)
 physical_ref=genuine_outcome(LATER/'actual-physical34-root-content-result-v12-v1.json',physical,'ACTUAL_PHYSICAL34_ROOT_CONTENT_ACCEPTANCE_PASS','physical34')
 assert physical['original_anchors']['R']==full['full_R']
 assert physical['preserved_count']==34 and physical['no_pair_namespace'] is True
 checkpoint=HERE/'root-prepair-current-transport-checkpoint-accepted-v12-v1.json'
 wait_file(checkpoint,'WAITING_SEPARATE_ROOT_PREPAIR_SOURCE_CHECKPOINT')
 check=read(checkpoint);scope(check);idle()
 assert check['owner']=='/root' and check['accepted_by_root'] is check['pair_launch_authorized'] is True
 assert type(check['accepted_ns']) is int and physical['accepted_ns']<=check['accepted_ns']<time.time_ns()
 assert check['current_source_adoption']==config['adoption'] and check['staged_source_binding']==ref(binding_path)
 assert check['full_R_and_global54_actual_acceptance']==full_ref and check['physical34_actual_acceptance']==physical_ref
 evidence=bound(check['actual_external_source_checkpoint']);assert evidence['owner']=='/root' and evidence['issue']==5030 and evidence['source_checkpoint_pass'] is True
 pairs=invoke(config,'original-pairs',dict(full_R_and_global54_actual_acceptance=full_ref,physical34_actual_acceptance=physical_ref,root_prepaired_checkpoint=ref(checkpoint)),'pair_launch_authorized')
 joined_ref=genuine_outcome(HERE/'root-original114-pair-phase-joined-v12-v1.json',pairs,'ORIGINAL_PAIR_DRIVER_JOINED_ACTUAL_RAW_CONTENT_REVIEW_REQUIRED','original-pairs')
 assert pairs['original_pair_count']==pairs['state_specific_guard_count']==114 and pairs['raw_content_acceptance'] is False
 raw=invoke(config,'raw-metadata',dict(joined_pair_phase=joined_ref),'root_final_handoff_authorized')
 raw_ref=genuine_outcome(FINAL/'root-final-raw-and-metadata-actual-outcome-v12-v1.json',raw,'ACTUAL_RAW114_ACCEPTED_EXACT34_IO_PENDING_FINAL_CONTENT_ACCEPTANCE','raw-metadata')
 assert raw['original_pair_count']==raw['state_specific_guard_count']==114
 content=invoke(config,'content-evaluations',dict(actual_raw_and_metadata_outcome=raw_ref,actual_metadata_result=ref(FINAL/'actual-final-exact34-metadata-result-v12-v1.json')),'root_final_handoff_authorized')
 genuine_outcome(FINAL/'root-final-evaluations-actual-outcome-v12-v1.json',content,'ACTUAL_ORIGINAL_FULL54_THEN_SEPARATE_STRICT19_JOINED_PRODUCT_DECISION_PENDING','content-evaluations')
 print(json.dumps(dict(status='REVIEWED_SEQUENTIAL_CHILDREN_JOINED_ROOT_PRODUCT_DECISION_REQUIRED',qualification=False,performance_accepted=False,merge_authorized=False)),flush=True)

if __name__=='__main__':main()
