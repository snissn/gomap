import json,time,types
from pathlib import Path
base=Path('tmp/quicksilver-maintenance-5028-20261005').resolve()
p=base/'qualification-v9-selected-source-preparation-v1/root_native_io.py'
m=types.ModuleType('root_live_progress_io');m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__)
code=r'''from pathlib import Path
import os,time,json
root='/home/mikers/quicksilver-maintenance-5028-20261006'
driver=Path(root)/'qualification-v12-fresh-controls-v1/collection-driver-pairs-v12'
processes=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 try:
  args=[x.decode(errors='replace') for x in (p/'cmdline').read_bytes().split(bytes([0])) if x]
  if not args:continue
  exe=Path(args[0]).name
  # Actual ELF binary paths; exclude shell/Python/SSH observer controllers.
  if not args[0].startswith(root+'/') or exe in ('python','python3'):continue
  stat=(p/'stat').read_text().rsplit(') ',1)[1].split()
  processes.append(dict(pid=int(p.name),argv=args[:8],state=stat[0],cpu_ticks=int(stat[11])+int(stat[12]),
   start_ticks=int(stat[19]),status=[x for x in (p/'status').read_text().splitlines() if x.startswith(('VmRSS:','VmHWM:','Threads:'))]))
 except OSError:continue
steps=[]
for f in driver.iterdir():
 if not f.is_dir():continue
 s=f/'stdout.txt';e=f/'stderr.txt'
 steps.append(dict(name=f.name,complete=(f/'complete.json').exists(),last_stdout=s.read_text(errors='replace')[-1800:] if s.exists() else '',
  stderr_bytes=e.stat().st_size if e.exists() else None))
print(json.dumps(dict(read_ns=time.time_ns(),clock_ticks_per_second=os.sysconf('SC_CLK_TCK'),processes=processes,steps=steps)))
'''
r=json.loads(m.native(['python3','-B','-c',code],'v12-pair-live-process-and-step-read-'+str(time.time_ns()),60))
print(json.dumps(r,indent=2))
