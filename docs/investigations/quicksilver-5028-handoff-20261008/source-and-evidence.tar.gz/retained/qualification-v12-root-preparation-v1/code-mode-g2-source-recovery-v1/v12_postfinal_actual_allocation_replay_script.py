
from pathlib import Path
import json,hashlib,types,time,os
BASE=Path('/Users/michaelseiler/dev/snissn/gomap/tmp/quicksilver-maintenance-5028-20261005')
P9=BASE/'qualification-v9-selected-source-preparation-v1'
FINAL=BASE/'qualification-v12-final-artifact-preparation-v1'
PREP=BASE/'qualification-v12-root-preparation-v1'
NROOT=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=NROOT/'qualification-v12-refresh/qualification-v10'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def save(p,x):
 with Path(p).open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def flags(x):
 for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'):assert x[k] is False
def state_update(**x):
 p=BASE/'state.json';old=p.read_bytes();s=json.loads(old);s.update(x);s['updated_at_ns']=time.time_ns()
 tmp=PREP/('state-allocation-runtime-'+str(time.time_ns())+'.json');save(tmp,s);assert p.read_bytes()==old;os.replace(tmp,p)
state=read(BASE/'state.json');assert state['native_active'] is None
actual=read(FINAL/'root-final-evaluations-actual-outcome-v12-v1.json');flags(actual)
assert actual['status']=='ACTUAL_ORIGINAL_FULL54_THEN_SEPARATE_STRICT19_JOINED_PRODUCT_DECISION_PENDING'
assert actual['original_pair_count']==actual['state_specific_guard_count']==114
assert len(actual['original_evaluations']['B'])==36 and len(actual['original_evaluations']['R'])==18 and len(actual['separate_strict_proofs'])==19
content=read(FINAL/'actual-final-content-decision-readback-v12-v1.json')
assert content['reference']==actual['actual_final_content_acceptance']
anchors=content['decision']['final_anchors'];flags(content['decision'])
assert content['decision']['actual_final_contents_accepted'] is True
source=P9/'root_native_io.py';assert sha(source)=='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io=types.ModuleType('root_io');io.__file__=str(source);exec(compile(source.read_bytes(),str(source),'exec'),io.__dict__)
refs={'original-'+role+'-'+name:ref for role,rows in actual['original_evaluations'].items() for name,ref in rows.items()}
for item in actual['separate_strict_proofs']:
 key='strict-'+item['role']+'-'+Path(item['bundle']['path']).name
 assert key not in refs
 refs[key]=item['proof']
assert len(refs)==73
code="""from pathlib import Path
import json,hashlib,sys
refs=json.loads(sys.argv[1]);out={}
for name,ref in refs.items():
 assert set(ref)=={'path','sha256'}
 p=Path(ref['path']);assert p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink()
 raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==ref['sha256'],name
 out[name]={'reference':ref,'bytes':len(raw),'value':json.loads(raw)}
print(json.dumps(out,allow_nan=False))
"""
state_update(native_active={'phase':'fresh-v12-final-original54-strict19-content-and-B16-allocation-replay','owner':'/root','local_owner_pid':os.getpid(),'started_ns':time.time_ns(),'qualification':False,'campaign_root':str(ROOT)})
try:
 raw=io.native(['python3','-B','-c',code,json.dumps(refs,separators=(',',':'))],'v12-actual-final-all73-result-complete-content-readback-v1',600)
 outp=PREP/'actual-final-all73-result-complete-content-v12-v1.json'
 with outp.open('xb') as f:f.write(raw)
 allcontent=json.loads(raw);assert set(allcontent)==set(refs)
 ids={'service.'+p+'.'+f for p in ('quicksilver_hits','quicksilver_misses','quicksilver_mixed','quicksilver_concurrent') for f in ('process_bytes_per_op','process_allocs_per_op')}
 B=actual['original_evaluations']['B'];R=actual['original_evaluations']['R']
 services=sorted(n for n in B if n.endswith('-service-final'))
 online=['online-primary-n'+str(n) for n in (30000,300000,3000000)]
 assert len(services)==13 and all(n in B for n in online)
 bnames=services+online;assert len(bnames)==len(set(bnames))==16
 bresults={}
 for name in bnames:
  ep=Path(B[name]['path']);assert ep.parent==ROOT/'analysis-global-original-v1' and ep.name==name+'.evaluation.json'
  bundle=ep.with_name(name+'.bundle.json')
  label='v12-actual-final-B-allocation-'+name+'-v1'
  argv=['python3','-B',str(NROOT/'qualification-v3-policy-preparation/allocation_accounting.py'),str(bundle),'--anchor',anchors['B']['path'],'--anchor-sha256',anchors['B']['sha256']]
  result=json.loads(io.native(argv,label,14400))
  assert result['status']=='prospective_accounting_artifact_only' and result['qualification'] is False
  entries=result['accounting_ledger'];assert len(entries)==8 and {e['id'] for e in entries}==ids
  assert type(result['all_allocation_guards_met']) is bool
  assert result['all_allocation_guards_met']==all(e['allocation_guard_met'] is True for e in entries)
  old=allcontent['original-B-'+name]['value'];numeric={k:v for k,v in old.items() if k not in ('root_acceptance_required','created_ns')}
  replay_numeric={k:v for k,v in result['numerical'].items() if k!='created_ns'}
  assert 0<old['created_ns']<result['numerical']['created_ns']<time.time_ns()
  assert numeric==replay_numeric,'original numeric result drift: '+name
  receipt=read(P9/(label+'-run.json'));assert receipt['rc']==0
  assert (P9/(label+'-stderr.txt')).read_bytes()==b''
  row={'native_execution':{'path':str(P9/(label+'-run.json')),'sha256':sha(P9/(label+'-run.json'))},'bundle_path':str(bundle),'final_anchor':anchors['B'],'result':result}
  save(PREP/('actual-final-B-allocation-'+name+'-v12-v1.json'),row)
  bresults[name]=row
  print(json.dumps({'bundle':name,'entries':8,'met':sum(e['allocation_guard_met'] is True for e in entries),'numeric_original_preserved':True}),flush=True)
 rnames=sorted(n for n in R if n.endswith('-service-final'));assert len(rnames)==6
 rledgers={}
 for name in rnames:
  row=allcontent['original-R-'+name]
  ledger=row['value']['allocation_ledger'];assert len(ledger)==8 and {e['id'] for e in ledger}==ids
  rledgers[name]={'original_reference':row['reference'],'ledger':ledger}
 allentries=[e for row in bresults.values() for e in row['result']['accounting_ledger']]+[e for row in rledgers.values() for e in row['ledger']]
 assert len(allentries)==176
 packet={'schema':1,'status':'ACTUAL_ALL176_ALLOCATION_CONTENT_REPLAY_JOINED_PRODUCT_DECISION_PENDING','accepted_by_root':False,'campaign_root':str(ROOT),'held_excluded':[5004,5006],
 'qualification':False,'performance_accepted':False,'collection_authorized':False,'candidate_pairs_authorized':False,'merge_authorized':False,
 'original_final_outcome':{'path':str(FINAL/'root-final-evaluations-actual-outcome-v12-v1.json'),'sha256':sha(FINAL/'root-final-evaluations-actual-outcome-v12-v1.json')},
 'actual_all73_complete_content':{'path':str(outp),'sha256':sha(outp)},'B':bresults,'R':rledgers,'B_bundle_count':16,'R_bundle_count':6,'entry_count':176,
 'met_entry_count':sum(e['allocation_guard_met'] is True for e in allentries),'all_allocation_guards_met':all(e['allocation_guard_met'] is True for e in allentries),'completed_ns':time.time_ns(),'original_numerical_UNKNOWN_unmodified':True}
 final=PREP/'actual-final-all176-allocation-joined-v12-v1.json';save(final,packet)
 s=read(BASE/'state.json');q=s['qualification_v12_current'];q['actual_all176_allocation_ledger_content']={'path':str(final),'sha256':sha(final)}
 state_update(native_active=None,qualification_v12_current=q,current_execution_status='Original114/114, original54, strict19 and actual176 allocation replay joined; numerical/product disposition pending',next_action='Read all original/strict/allocation entries, adjudicate speed/RSS/default progress/storage/correctness, refine selected implementation when a product gate remains unmet')
 print(json.dumps({'status':packet['status'],'entries':176,'met':packet['met_entry_count'],'all_met':packet['all_allocation_guards_met'],'qualification':False}),flush=True)
except BaseException as error:
 state_update(native_active=None,last_native_failure={'phase':'fresh-v12-final-allocation-replay','error':repr(error),'finished_ns':time.time_ns()},current_execution_status='Actual final allocation replay failed; original bytes retained; no automatic retry',next_action='Inspect exact failure; do not duplicate completed allocation calls or change frozen arithmetic')
 raise
