import copy,hashlib,json,os,time,types
from pathlib import Path
BASE=Path('tmp/quicksilver-maintenance-5028-20261005').resolve()
REMOTE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=REMOTE/'qualification-v12-refresh/qualification-v10'
PREP=BASE/'qualification-v12-root-preparation-v1'
P9=BASE/'qualification-v9-selected-source-preparation-v1'
ADOPT=BASE/'qualification-v12-root-global-reader-adoption-v1'
PACK=BASE/'qualification-v12-global-loader-reader-compatibility-preparation-v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def ref(p):return dict(path=str(REMOTE/Path(p).relative_to(BASE)),sha256=sha(p))
def bound(r):
 p=BASE/Path(r['path']).relative_to(REMOTE)
 assert p.is_file() and p.resolve()==p and not p.is_symlink() and sha(p)==r['sha256']
 return read(p)
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
 return ref(p)
def flags(v):assert all(v[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
def load(p,digest,name):
 assert p.is_file() and p.resolve()==p and not p.is_symlink() and sha(p)==digest and not (p.parent/'__pycache__').exists()
 m=types.ModuleType(name);m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__);return m
def state_update(**fields):
 s=read(BASE/'state.json');s.update(fields)
 p=PREP/('state-raw-actual-runtime-'+str(time.time_ns())+'.json');save(p,s);p.replace(BASE/'state.json')
def actual(label):
 r=read(P9/(label+'-run.json'));assert r['rc']==0 and not r.get('error') and 0<r['started_ns']<r['finished_ns']
 for k in ('stdout','stderr'):
  p=P9/(label+'-'+k+'.txt');assert r[k]==dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
 assert not (P9/(label+'-stderr.txt')).read_bytes()
 return r
assert __debug__ and os.environ.get('PYTHONPYCACHEPREFIX') is None
s=read(BASE/'state.json');assert s['native_active'] is None
ar=s['qualification_v12_current']['actual_original114_raw_content_acceptance'];raw=bound(ar);flags(raw)
assert raw['status']=='ACTUAL_JOINED114_RAW_CONTENT_ROOT_ACCEPTED' and raw['accepted_by_root'] is raw['raw_contents_accepted'] is True
assert raw['original_pair_count']==raw['state_specific_guard_count']==114 and len(raw['intervals'])==228
assert 0<raw['joined_ns']<raw['reviewed_ns']<=raw['raw_contents_accepted_ns']<time.time_ns()
FINAL=BASE/'qualification-v12-final-artifact-preparation-v1'
helper=FINAL/'root-final-metadata-io-v12-v1.py';assert sha(helper)=='3f82c0a3f323a2e9b47ff3739febf35c813daaae69264b51c4f3131419775f4c'
adop=FINAL/'root-metadata-source-acceptance-v12-v1.json';assert sha(adop)=='ba0fb3772a1b64bc08f4cad8993e1751c5ec19aafd03185ac45f1e7896751a0e'
a=read(adop);flags(a);assert a['accepted_by_root'] is True and a['helper']==ref(helper)
io=load(P9/'root_native_io.py','fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1','root_metadata_io')
stage=load(BASE/'qualification-v12-exact-stage-preparation-v1/exact_stage_v12_v1.py','27515da907ab4bf3bdcb5fc56773364189b70159317521c2e22e5e4ce068dd03','root_metadata_stage')
q=read(FINAL/'metadata-request.draft.json');assert q.pop('source_only') is True and q['accepted_by_root'] is False and q['helper']==ref(helper)
q.update(status='ROOT_AUTHORIZED_ACTUAL_JOINED114_EXACT34_FINAL_METADATA_IO_ONLY',accepted_by_root=True,
 metadata_io_authorized=True,final_anchor_binding_authorized=True,exclusive_root_metadata_writer=True,
 raw_contents_acceptance=ar,helper_source_acceptance=ref(adop),metadata_preservation_acceptance=raw['metadata_preservation_acceptance'])
rawq=bound(raw['request']);q['strict_context']['current_bindings']['global54_actual_content_acceptance']=rawq['strict_context']['current_bindings']['global54_actual_content_acceptance']
flags(q)
qp=PREP/'root-actual-final-exact34-metadata-request-v12-v1.json';qr=save(qp,q)
stage.exact_stage(io,{qp.relative_to(BASE).as_posix():qp},'v12-actual-final-exact34-metadata-request-exclusive-stage-v1')
state_update(native_active=dict(phase='fresh-v12-actual-final-exact34-metadata-io',owner='/root',local_owner_pid=os.getpid(),started_ns=time.time_ns(),request=qr,qualification=False),
 current_execution_status='Actual114/114 raw accepted; binding exact34 final metadata through unchanged reviewed helper',
 next_action='Verify actual metadata receipt then unchanged full final content gate; original54 before separate strict19')
try:
 label='v12-actual-final-exact34-metadata-io-v1'
 result=json.loads(io.native(['python3','-B',ref(helper)['path'],qr['path'],qr['sha256'],str(ROOT/'final-metadata-actual114-v12-v1')],label,14400));execution=actual(label)
 assert result['status']=='METADATA_IO_COMPLETE_ROOT_REVIEW_REQUIRED' and result['qualification'] is False and set(result['final_anchors'])=={'B','R'}
 rp=FINAL/'actual-final-exact34-metadata-result-v12-v1.json';rr=save(rp,result)
 code="from pathlib import Path;import hashlib,sys;p=Path(sys.argv[1]);raw=p.read_bytes();assert p.resolve()==p and not p.is_symlink() and hashlib.sha256(raw).hexdigest()==sys.argv[2];sys.stdout.buffer.write(raw)"
 b=io.native(['python3','-B','-c',code,result['completion']['path'],result['completion']['sha256']],'v12-actual-final-exact34-metadata-completion-content-readback-v1',180)
 actual('v12-actual-final-exact34-metadata-completion-content-readback-v1')
 assert hashlib.sha256(b).hexdigest()==result['completion']['sha256']
 cp=PREP/'actual-final-exact34-metadata-completion-content-v12-v1.json'
 with cp.open('xb') as f:f.write(b)
 c=read(cp)
 assert c['status']=='FINITE_FINAL_METADATA_BOUND_PENDING_ROOT_FINAL_CONTENT_REVIEW' and c['accepted_by_root'] is False
 assert all(c[k] is False for k in ('qualification','performance_accepted','collection_authorized','merge_authorized'))
 assert c['raw_contents_acceptance']==ar and c['metadata_preservation_acceptance']==raw['metadata_preservation_acceptance'] and c['final_anchors']==result['final_anchors']
 assert c['request']==qr and 0<c['started_ns']<c['metadata_io_completed_ns']<=execution['finished_ns']
 assert c['actual_final_contents_accepted_ns'] is None and c['original_evaluation_required'] is c['strict_supplement_separate'] is True
 outcome=dict(schema=1,status='ACTUAL_RAW114_ACCEPTED_EXACT34_IO_PENDING_FINAL_CONTENT_ACCEPTANCE',accepted_by_root=False,
 campaign_root=str(ROOT),held_excluded=[5004,5006],actual_raw_content_acceptance=ar,actual_metadata_request=qr,
 actual_metadata_completion=result['completion'],final_anchors=result['final_anchors'],original_pair_count=114,state_specific_guard_count=114,
 qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False,
 original_evaluation_required=True,strict_supplement_separate=True)
 flags(outcome)
 op=FINAL/'root-final-raw-and-metadata-actual-outcome-v12-v1.json';orr=save(op,outcome)
 s=read(BASE/'state.json');s['qualification_v12_current'].update(actual_raw_and_metadata_outcome=orr,
 actual_metadata_result=rr,metadata_execution_label=label,final_metadata_anchors_pending_content_acceptance=result['final_anchors'])
 state_update(native_active=None,qualification_v12_current=s['qualification_v12_current'],
 current_execution_status='Actual raw114 accepted and exact34 metadata IO joined; final content/numerical/product acceptance pending',
 next_action='Invoke unchanged final content and full54 original evaluations before separate strict19; actual allocation and product gates follow')
 print(json.dumps(dict(status=outcome['status'],outcome=orr,actual_metadata_result=rr,metadata_execution_label=label,final_anchors=result['final_anchors'],qualification=False),indent=2))
except BaseException as e:
 state_update(native_active=None,current_execution_status='Actual metadata IO failed; retain complete original/preserved/staged bytes; no evaluation authority',
 next_action='Inspect failed exact metadata gate; no automatic retry or original evidence overwrite',last_native_failure=dict(phase='fresh-v12-actual-final-exact34-metadata-io',error=repr(e),finished_ns=time.time_ns()))
 raise
