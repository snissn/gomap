import copy,hashlib,json,os,time,types
from pathlib import Path
BASE=Path('tmp/quicksilver-maintenance-5028-20261005').resolve()
REMOTE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=REMOTE/'qualification-v12-refresh/qualification-v10'
PREP=BASE/'qualification-v12-root-preparation-v1'
P9=BASE/'qualification-v9-selected-source-preparation-v1'
ADOPT=BASE/'qualification-v12-root-global-reader-adoption-v1'
PACK=BASE/'qualification-v12-global-loader-reader-compatibility-preparation-v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def ref(p):return dict(path=str(REMOTE/Path(p).relative_to(BASE)),sha256=sha(p))
def bound(r):
 p=BASE/Path(r['path']).relative_to(REMOTE)
 assert p.is_file() and p.resolve()==p and not p.is_symlink() and sha(p)==r['sha256']
 return read(p)
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
 return ref(p)
def flags(v):assert all(v[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
def load(p,digest,name):
 assert p.is_file() and p.resolve()==p and not p.is_symlink() and sha(p)==digest and not (p.parent/'__pycache__').exists()
 m=types.ModuleType(name);m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__);return m
def state_update(**fields):
 s=read(BASE/'state.json');s.update(fields)
 p=PREP/('state-raw-actual-runtime-'+str(time.time_ns())+'.json');save(p,s);p.replace(BASE/'state.json')
def actual(label):
 r=read(P9/(label+'-run.json'));assert r['rc']==0 and not r.get('error') and 0<r['started_ns']<r['finished_ns']
 for k in ('stdout','stderr'):
  p=P9/(label+'-'+k+'.txt');assert r[k]==dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
 assert not (P9/(label+'-stderr.txt')).read_bytes()
 return r
assert __debug__ and os.environ.get('PYTHONPYCACHEPREFIX') is None
s=read(BASE/'state.json');assert s['native_active'] is None
joined_path=PREP/'root-original114-pair-phase-joined-v12-v1.json'
j=read(joined_path);flags(j)
assert j['status']=='ORIGINAL_PAIR_DRIVER_JOINED_ACTUAL_RAW_CONTENT_REVIEW_REQUIRED' and j['raw_contents_accepted'] is False
assert j['campaign_root']==str(ROOT) and j['held_excluded']==[5004,5006] and j['original_pair_count']==j['state_specific_guard_count']==114
assert j['metadata_preservation_acceptance']==s['qualification_v12_current']['physical34_native_actual_acceptance']
actual('v12-actual-original-114-pairs-114-guards-v1')
io=load(P9/'root_native_io.py','fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1','root_raw_io')
stage=load(BASE/'qualification-v12-exact-stage-preparation-v1/exact_stage_v12_v1.py','27515da907ab4bf3bdcb5fc56773364189b70159317521c2e22e5e4ce068dd03','root_raw_stage')
helper=PACK/'root-final-raw-closure-v12-v4.py';assert sha(helper)=='dfa291f5d4faae45c5beff4648a8332944f1df4489aa20f1b4487a4d9aec0de6'
adoption=ADOPT/'root-raw-source-acceptance-v12-v4.json';a=read(adoption);flags(a);assert a['accepted_by_root'] is True and a['helper']==ref(helper)
q=read(BASE/'qualification-v12-analysis-compatibility-coordination-v1/raw-request.draft-v12-v2.json')
assert q.pop('source_only') is True and q['accepted_by_root'] is False
q.update(status='ROOT_AUTHORIZED_GENUINELY_JOINED114_RAW_CONTENT_REPLAY_ONLY',accepted_by_root=True,
 read_only_raw_closure_authorized=True,diagnostic_inventory_creation=True,serial_and_quiescent=True,
 joined_ns=j['joined_ns'],helper=ref(helper),helper_source_acceptance=ref(adoption),
 independent_source_review=a['independent_source_review'],
 metadata_preservation_acceptance=j['metadata_preservation_acceptance'],
 paired_driver_completion=j['paired_driver_completion'],paired_driver_activation=j['paired_driver_activation'],
 output_directory=str(ROOT/'raw-closure-actual114-v12-v4'))
q['strict_context']['paired_driver']=s['qualification_v12_current']['current_pair_driver']
q['strict_context']['current_bindings']['global54_actual_content_acceptance']=j['global54_content_acceptance']
flags(q);assert q['analysis_authorized'] is False
qp=PREP/'root-actual-joined114-raw-content-request-v12-v4.json';save(qp,q)
stage.exact_stage(io,{qp.relative_to(BASE).as_posix():qp},'v12-actual-joined114-raw-request-exclusive-stage-v4')
state_update(native_active=dict(phase='fresh-v12-actual-joined114-raw-content-replay',owner='/root',local_owner_pid=os.getpid(),started_ns=time.time_ns(),request=ref(qp),qualification=False),
 current_execution_status='Original driver genuinely joined; reviewing actual114 runs/114 guards with unchanged content and serial gates',
 next_action='Admit raw contents only after actual reviewed helper completes; final metadata and numerical gates remain separate')
try:
 label='v12-actual-joined114-raw-content-closure-v4'
 result=json.loads(io.native(['python3','-B',ref(helper)['path'],ref(qp)['path'],sha(qp),q['output_directory']],label,14400));execution=actual(label)
 flags(result);assert result['status']=='ROOT_CONTENT_REVIEW_PENDING' and result['accepted_by_root'] is False
 save(PREP/'actual-raw-content-closure-result-v12-v4.json',result)
 code="from pathlib import Path;import hashlib,sys;p=Path(sys.argv[1]);raw=p.read_bytes();assert p.resolve()==p and not p.is_symlink() and hashlib.sha256(raw).hexdigest()==sys.argv[2];sys.stdout.buffer.write(raw)"
 raw=io.native(['python3','-B','-c',code,result['packet']['path'],result['packet']['sha256']],'v12-actual-joined114-raw-packet-complete-content-readback-v4',180)
 actual('v12-actual-joined114-raw-packet-complete-content-readback-v4')
 assert hashlib.sha256(raw).hexdigest()==result['packet']['sha256']
 pp=PREP/'actual-joined114-raw-packet-complete-content-v12-v4.json'
 with pp.open('xb') as f:f.write(raw)
 p=read(pp);flags(p)
 assert p['status']=='ROOT_CONTENT_REVIEW_PENDING' and p['accepted_by_root'] is p['raw_contents_accepted'] is False
 assert p['request']==ref(qp) and p['helper']==ref(helper) and p['helper_source_acceptance']==ref(adoption)
 assert p['independent_source_review']==q['independent_source_review'] and p['paired_driver_activation']==j['paired_driver_activation'] and p['paired_driver_completion']==j['paired_driver_completion']
 assert p['metadata_preservation_acceptance']==j['metadata_preservation_acceptance']
 assert p['original_pair_count']==p['state_specific_guard_count']==114 and p['counts']==dict(B=dict(originals=78,guards=78),R=dict(originals=36,guards=36))
 assert p['campaign_root']==str(ROOT) and p['held_excluded']==[5004,5006] and p['serial_and_quiescent'] is p['original34_unchanged'] is True
 assert p['final_metadata_io_separate'] is p['original_analysis_separate'] is p['root_review_required'] is True
 assert 0<j['joined_ns']==p['joined_ns']<=p['started_ns']<p['diagnostic_completed_ns']<time.time_ns()
 rows=p['intervals'];assert len(rows)==228 and len({r['name'] for r in rows})==228
 assert sum(r['kind']=='original' for r in rows)==sum(r['kind']=='guard' for r in rows)==114
 assert all(type(r['started_ns']) is int and type(r['finished_ns']) is int and 0<r['started_ns']<r['finished_ns']<=j['joined_ns'] for r in rows)
 assert all(a['finished_ns']<=b['started_ns'] for a,b in zip(rows,rows[1:]))
 assert set(p['files'])=={'B','R'} and all(p['files']['R'].get(k)==v for k,v in p['files']['B'].items())
 reviewed=time.time_ns()
 accepted=copy.deepcopy(p);accepted.update(status='ACTUAL_JOINED114_RAW_CONTENT_ROOT_ACCEPTED',accepted_by_root=True,raw_contents_accepted=True,
 reviewed_ns=reviewed,raw_contents_accepted_ns=reviewed,root_review_required=False,
 actual_pending_packet=result['packet'],actual_raw_execution=ref(P9/(label+'-run.json')))
 flags(accepted)
 ap=PREP/'root-actual-joined114-raw-content-acceptance-v12-v4.json';ar=save(ap,accepted)
 stage.exact_stage(io,{ap.relative_to(BASE).as_posix():ap},'v12-actual-joined114-raw-content-acceptance-exclusive-stage-v4')
 s=read(BASE/'state.json');s['qualification_v12_current']['actual_original114_raw_content_acceptance']=ar
 state_update(native_active=None,qualification_v12_current=s['qualification_v12_current'],
 current_execution_status='Actual original114 runs/114 guards and228 serial intervals root content accepted; numerical/product gates pending',
 next_action='Bind exact34 final metadata through reviewed unchanged helper; original full54 before separate strict19')
 print(json.dumps(dict(status=accepted['status'],acceptance=ar,counts=p['counts'],serial_intervals=228,file_counts={r:len(f) for r,f in p['files'].items()},qualification=False),indent=2))
except BaseException as e:
 state_update(native_active=None,current_execution_status='Actual raw closure failed; retained first-attempt bytes; no final metadata acceptance',
 next_action='Inspect failed exact raw gate; no automatic retry or original evidence overwrite',last_native_failure=dict(phase='fresh-v12-actual-joined114-raw-content-replay',error=repr(e),finished_ns=time.time_ns()))
 raise
