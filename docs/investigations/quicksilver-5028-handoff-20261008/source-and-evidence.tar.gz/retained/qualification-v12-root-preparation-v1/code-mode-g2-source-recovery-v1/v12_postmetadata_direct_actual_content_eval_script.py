import copy,hashlib,json,os,time,types
from pathlib import Path
BASE=Path('tmp/quicksilver-maintenance-5028-20261005').resolve()
REMOTE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=REMOTE/'qualification-v12-refresh/qualification-v10'
PREP=BASE/'qualification-v12-root-preparation-v1'
P9=BASE/'qualification-v9-selected-source-preparation-v1'
ADOPT=BASE/'qualification-v12-root-global-reader-adoption-v1'
PACK=BASE/'qualification-v12-global-loader-reader-compatibility-preparation-v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def ref(p):return dict(path=str(REMOTE/Path(p).relative_to(BASE)),sha256=sha(p))
def bound(r):
 p=BASE/Path(r['path']).relative_to(REMOTE)
 assert p.is_file() and p.resolve()==p and not p.is_symlink() and sha(p)==r['sha256']
 return read(p)
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
 return ref(p)
def flags(v):assert all(v[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
def load(p,digest,name):
 assert p.is_file() and p.resolve()==p and not p.is_symlink() and sha(p)==digest and not (p.parent/'__pycache__').exists()
 m=types.ModuleType(name);m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__);return m
def state_update(**fields):
 s=read(BASE/'state.json');s.update(fields)
 p=PREP/('state-raw-actual-runtime-'+str(time.time_ns())+'.json');save(p,s);p.replace(BASE/'state.json')
def actual(label):
 r=read(P9/(label+'-run.json'));assert r['rc']==0 and not r.get('error') and 0<r['started_ns']<r['finished_ns']
 for k in ('stdout','stderr'):
  p=P9/(label+'-'+k+'.txt');assert r[k]==dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
 assert not (P9/(label+'-stderr.txt')).read_bytes()
 return r
assert __debug__ and os.environ.get('PYTHONPYCACHEPREFIX') is None
s=read(BASE/'state.json');assert s['native_active'] is None
q=s['qualification_v12_current'];outcome=bound(q['actual_raw_and_metadata_outcome']);flags(outcome)
assert outcome['status']=='ACTUAL_RAW114_ACCEPTED_EXACT34_IO_PENDING_FINAL_CONTENT_ACCEPTANCE'
assert outcome['accepted_by_root'] is False and outcome['original_pair_count']==outcome['state_specific_guard_count']==114
assert outcome['original_evaluation_required'] is outcome['strict_supplement_separate'] is True
actual(q['metadata_execution_label'])
cont=load(PREP/'continue-reviewed-v12-qualification-v2.py','02292c22c7777c707d0c34f7933643cc65bb9386a9856dc5c87a14878be65248','root_final_content_continuation')
cfg=BASE/'qualification-v12-root-continuation-output-fix-preparation-v1/finite-config.json'
assert sha(cfg)=='72d7a53db8f8af8e2c30ce2c59195599370b2ecc2bf90cea0d779790066d1b61'
config=read(cfg)
result=cont.invoke(config,'content-evaluations',dict(
 actual_raw_and_metadata_outcome=q['actual_raw_and_metadata_outcome'],
 actual_metadata_result=q['actual_metadata_result'],metadata_execution_label=q['metadata_execution_label']),
 'root_final_handoff_authorized')
flags(result)
assert result['status']=='ACTUAL_ORIGINAL_FULL54_THEN_SEPARATE_STRICT19_JOINED_PRODUCT_DECISION_PENDING'
assert result['accepted_by_root'] is False and result['original_pair_count']==result['state_specific_guard_count']==114
assert len(result['original_evaluations']['B'])==36 and len(result['original_evaluations']['R'])==18 and len(result['separate_strict_proofs'])==19
assert result['original_numerical_UNKNOWN_must_remain'] is True
p=BASE/'qualification-v12-final-artifact-preparation-v1/root-final-evaluations-actual-outcome-v12-v1.json'
assert read(p)==result
s=read(BASE/'state.json');assert s['native_active'] is None
s['qualification_v12_current']['actual_final_original54_and_separate_strict19']=ref(p)
state_update(qualification_v12_current=s['qualification_v12_current'],
 current_execution_status='Actual raw114/114, exact34 content, original final54 and separate strict19 genuinely joined; product adjudication pending',
 next_action='Inspect actual full numerical/guard/176 allocation ledgers and default progress; decide causal refinements before current-head merges')
print(json.dumps(dict(status=result['status'],actual_outcome=ref(p),original_slots=dict(B=36,R=18),strict_proofs=19,qualification=False),indent=2))
