## Current landed prerequisite and fresh qualification source (checkpoint v49)

The external owner has merged **PR #5084** (`192e5019e579af3b98ae4fbf4ea497bb9ccd672f`, 2026-10-07 14:28:11 UTC); #5083 is closed. The coordinator consumed that landed output without taking over the external branch or authority. Owned R/PR #5037 normally integrated main as `6fa638b8bffa71750e1aefa0bb746bb747aa06c1`; B/PR #5054 normally integrated that R as `73100c5b8cc2337d9cff36c60a8e4182f1820fe9`. All94 shared control/harness mode/blob bindings now match actual A/R/B; the stale profile assertion was restored to landed common source. Canonical CI discovery refresh/check passed with policy and original members retained. Complete common1715 / R-owned69 / B-owned18 path deltas are explicitly bound.

These are fresh source candidates, **not qualified or merged R/B changes**. Actual combined source review, eight fresh native builds, full compiler/input and four-receipt content review, original30 plus16 additive correctness commands, compatible restored-copy oracles, the previously failed online guard, unchanged39C/39guard and B36/R18 calibration, original114run/114guard qualification, original allocation/memory/default-progress/regression/UNKNOWN gates, current-head CI/review and final landed-source #5030 remain required. Previous v11 failure/DB/raw/offline rc0 observations remain historical and nonqualifying; no old runtime sample is promoted. Held **#5004 / PR #5006** remain outside the sprint. Earlier source/prerequisite sections below are retained history and superseded for current identity by this checkpoint.

Coordinator reassessment SHA256 `1c8d15ec94639503263cffc5db12b62ee76a3d2accd5d6ea4a83e93159d1f4e9`.

## Current prerequisite after the actual online baseline failure

The fresh v11 A baseline failed in the primary30k C2 post-churn guard with a closed tracked value-log handle during refresh. Failed DB and raw receipts are retained. Independent exact-source Sol audit and coordinator inspection show the reachable retirement/refresh race; the exact failing interleaving remains inferred. The benchmark correctly joins readers and writer before close. The same manager source exists in A, R and B; avoiding one B refresh route is not a lifetime fix.

Required common prerequisite: **#5083 / PR #5084**, actively owned under #5044. Consume its accepted landed output; do not take over its branch, merge authority or current-head correctness/performance/review/CI gates. The initial zombie-skip alone would bypass physical rebound checks and is not selected. After it lands, integrate current main normally into #5015/PR5037 and that R head into #5016/PR5054; freeze the actual common corrected source and run fresh affected matched qualification with the unchanged39C/39guard, B36/R18 and114run/114guard contract. Historical small content acceptance and offline rc0 observations keep original identities; they do not qualify the repaired runtime. This necessary prerequisite preserves the selected maintenance mechanisms and all parent speed, memory, default progress, storage, service and correctness gates. Current failure checkpoint: https://github.com/snissn/gomap/issues/5028#issuecomment-6023447234 . Held **#5004 / PR #5006** remain outside this sprint. Coordinator reassessment SHA256 `2f71235b32ec4b7134c73a32c795f6a03a719c354f6de3f2346cb516b4a25782`.

## Current graph prerequisite: strict maintenance receipt schema

The fresh v9 baseline stopped after the first native compact returned rc0: the strict collector rejected seven newly serialized manifest-GC fields. The original failed run and receipts remain retained and nonqualifying. Accepted exact-source causal inquiry selects **#5086** as a narrow, necessary reviewed/landed harness PR before fresh matched collection. It owns strict typed current-field validation, separate manifest units and unsupported/partial nonpassing semantics; it changes no native command, product storage behavior or measurement/qualification math.

Current ordering: accepted #5029 and landed #5031/#5035/#5075 -> **#5086 reviewed/landed schema repair** -> fresh source-bound B36/R18 calibration and original paired qualification for selected #5015 / PR #5037 and #5016 / PR #5054 -> gated implementation merges -> #5030 landed-source equality and parent outcome acceptance. Current R/B runtime heads remain `7f7dd3b126df465ed971a410651d44b2ecc62383` / `3b72833df173d1277df88be5453a58d6d311bd81`, unmerged. Exact-byte applicability may preserve unchanged runtime correctness and closed fixtures, but failed calibration may not be promoted or overwritten. All original correctness/performance/memory/regression/UNKNOWN gates and held **#5004 / PR #5006** exclusion remain intact. Coordinator owns acceptance, native collection and merge authority.

## Current selected graph: ordinary publication extension

The A-only causal inquiry recorded in https://github.com/snissn/gomap/issues/5028#issuecomment-6010734795 completed successfully. Its whole-process CPU profile confirms ordinary candidate reachability as the principal bottleneck (153.45/214.22 sampled CPU seconds); all value, miss and reopen checks passed. This does not qualify a performance ratio.

#5015 / PR #5037 now owns the necessary ordinary destructive Apply/cached-group continuation in the same exact-closure packet. Reuse its exact raw collector and stable append authority, introduce explicit complete-chain proof, preserve full fallback and original rewrite gates. #5016 / PR #5054 remains dependent on that stable contract. Executable edges remain acyclic: accepted #5029 decision and landed #5031/#5035 -> revised #5015 -> #5016 -> #5030 matched qualification -> parent outcome acceptance. No new code PR is required merely to represent this accepted inquiry.

The partial v2 campaign and frozen numerical results remain preserved, including two positive zero-spread allocation UNKNOWNs. The coordinator will freeze the revised candidate sources and any prospectively reviewed accounting policy before fresh affected calibrations/pairs. Existing primary speed, automatic eligible progress, relevant lower process memory and correctness/regression gates remain open. Held #5004 / PR #5006 remain excluded.

## Intended outcome

Make TreeDB maintenance materially faster and improve its scaling on Quicksilver-shaped KV workloads. Seek lower peak and sustained process memory by avoiding repeated work and shortening transient or retired-resource lifetimes. Faster maintenance is valuable independently; a memory benefit must be measured rather than assumed.

This is an exploratory implementation graph. Its first node delivers **verified ticket revisions**, with evidence and a decision, rather than requiring a PR. It can reject the initial mechanisms and replace the remaining plan. Accepted research or a new follow-up ticket does not satisfy the product goal.

Workstream: **Q1 Quicksilver-shaped KV** in [the authoritative project](https://github.com/users/snissn/projects/1). Planning only: no implementation or benchmark campaign was started by creating this graph. Current inspected product base: `9905d553658c3c80924c2def2479d2c6a77c47f9`; refresh affected paths before execution. Workflow contract: [planner](https://github.com/snissn/skills/blob/e8e04004a49d2bf5491ddffd5ec2e0fa8ae4f2cc/gh-issue-planner/SKILL.md) and [executor](https://github.com/snissn/skills/blob/e8e04004a49d2bf5491ddffd5ec2e0fa8ae4f2cc/codex-issue-graph-executor/SKILL.md).

## Evidence and open questions

The [published 3M packet](https://github.com/snissn/gomap/blob/9905d553658c3c80924c2def2479d2c6a77c47f9/docs/benchmarks/treedb_quicksilver_space_memory_20261005/REPORT.md) and [final publication qualification](https://github.com/snissn/gomap/pull/5013#issuecomment-5994044765) supply history, not measurements of a new optimization:

- A terminated 60-second rewrite diagnostic attributed 95.41% cumulative CPU to candidate resource closure and 73.46% to nested Zstd decoding. These overlap and are not full-run scaling evidence. The current outer-leaf rewrite path declines logical reference-delta tracking; #5015 owns the proposed remedy if selected.
- In the six-full-refresh default stress, ten retained-log scans exhausted the background budget, with no completed full scan or removed segment. This does not prove every retained byte was garbage. #5016 owns progress on this path if selected.
- RSS includes file-backed mappings, anonymous memory, stacks and runtime state. The earlier mapping-budget diagnostic and held cache-offset candidate do not establish a qualified process-memory improvement. Faster cleanup might reduce residency or lifetime; it could also add persistent metadata and raise memory.
- Successful repaired Full/Exhaustive calls still reported `fully_compacted=false`, `policy_fully_compacted=false`, and `byte_minimized=false`. Recovery-selectable slots and pins remain legitimate retention roots. Sequential restored-copy timings, after partial earlier maintenance, are not matched speedup ratios.

## Current graph and deliverable contracts

| Node | Role / primary deliverable | Dependencies | Acceptance owner / owned gate | Initial state |
| --- | --- | --- | --- | --- |
| #5029 | Causal investigation and plan revision / `issue-update` to this tracker and #5015/#5016 | none | Coordinator accepts the measurement contract, findings and verified scope/edge changes | pending; first frontier |
| #5015 | Selected closure optimization / `pr` | **accepted output** of #5029 selecting this mechanism | Coordinator accepts its exact-root correctness, scaling, allocations and representative speed gate under current PR policy | pending; conditional |
| #5016 | Selected retained-log progress optimization / `pr` | **accepted output** of #5029 selecting this mechanism | Coordinator accepts safe progress, foreground/cancellation behavior, allocations and representative reclamation gate under current PR policy | pending; conditional |
| #5030 | Matched final qualification / `artifact`, with a tracker decision/update | accepted #5029 contract; **merged PRs** for every selected implementation | Coordinator accepts the source-bound full comparison and maps any failed product gate back into the graph | pending |
| This tracker | Product acceptance / `decision` recorded here | accepted final qualification and all required outcome gates | Coordinator owns the final outcome; only explicit user acceptance can narrow it | open |

```mermaid
flowchart LR
  A[Investigate and revise tickets] -->|accepted decision selects| B[5015 closure work]
  A -->|accepted decision selects| C[5016 prune progress]
  A -->|accepted measurement contract| Z[Final qualification]
  B -->|merged PR if selected| Z
  C -->|merged PR if selected| Z
  Z --> P[Parent outcome decision]
```

Only selected branches become implementation obligations. The coordinator records the accepted decision, issue revision timestamps/links, evidence identity, ownership and updated acyclic edges before dispatch. A disproven branch can be retired with its obligations mapped to a justified alternative; a started candidate failing its speed or correctness gate remains `fix-needed` until its scope is explicitly resolved. Non-PR nodes finish `completed`, never `merged`. Each gate has one owner; final qualification supplies evidence to this tracker's product gates.

## Outcome gates and measurement contract

#5029 freezes exact commands, starting-state identity, phase boundaries, repetitions/order/noise policy, and material-improvement/regression criteria before candidate comparisons. Use existing evidence first; expand collection only to answer a named uncertainty. Do not invent a percentage from an unpaired historical timeout or an arbitrary RAM ceiling.

| Metric | Class | Required result / evidence |
| --- | --- | --- |
| Maintenance wall/CPU cost and scaling | Primary outcome | Repeatable material improvement on the selected representative production maintenance path, with work/path counters explaining the change across dataset sizes. Fixed swap batch and matched physical input separate algorithmic improvement from larger-batch tuning. |
| Automatic maintenance progress and storage debt | Primary product facet | Under an eligible finite-write/quiet interval, proven reclaimable debt makes progress rather than repeatedly restarting incomplete proof. Retention justified by recovery/pins is reported separately. No requirement to delete every retained byte or force all compaction flags true. |
| Peak and sustained process memory | Secondary outcome | Seek an attributable reduction in a relevant phase/lifetime, with a repeated process-level comparison and scaling model. Heap reduction alone does not prove RSS reduction. If no credible memory benefit emerges, revise the remaining graph; do not silently declare this objective achieved or replace it with a cap. |
| Foreground owned reads/writes and p99; load/checkpoint/close; temporary/final disk | Guardrails | No unaccepted material regression under the frozen comparison policy. Include reads after maintenance because rewrite can enlarge compressed frames and CRC/decode amplification. |
| Persistence, exact reachability, corruption detection and lifetime safety | Hard invariants | Preserve the existing mode/ACK contract, complete recoverable-root authority, checksums and fallback. Full values/misses and affected root/snapshot/reopen/crash/race tests pass. |
| Final flags, pin age/count, live/stale/protected bytes, mapped bytes and retained heap | Observational / causal | Report by phase and root horizon. These are attribution, not invented hard bounds or evidence that all physical space must shrink immediately. |

Use the unified Quicksilver `generic-v1` primary mixture and holdout, with variable key families/lengths and mixed realistic value sizes/compressibility. This is a synthetic workload, not a measured Cloudflare production distribution. Preserve the existing 3M anchor; use smaller sizes for causal/scaling tests and expand only when needed. Full-population refresh is a stress control, separately labeled from sparse update/delete and quiet-drain behavior. Keep ordinary compressed outer leaves/value pointers and read verification enabled; inline/paged or compression-off controls distinguish mechanisms, not promotion defaults. Record negative-lookup coverage, durability/ordinary versus sync ACK, concurrency, cache state and both mapping domains identically across each A/B pair.

Report setup/load, update/churn, maintenance, foreground overlap, post-maintenance reads, checkpoint/close and reopen separately. Compare maintenance from equivalent verified physical starting states; a writable oracle can change representation, so record its placement and before/after census. Retain unprofiled repeated qualification separately from CPU/allocation/block/mutex profiles and phase-marked memory samples. Respect the existing benchprof artifact contract.

## Reassessment and execution boundaries

- Reassess after the first causal evidence, after each selected candidate's small matched comparison, and after joint churn/memory/post-maintenance qualification. Positive local results also trigger a check that the parent outcome improves.
- Reuse existing publication deltas, dependency projections, reachability collectors, retained-source proof paths and stable-resource lifetimes before adding a new cache, cursor or scheduler. Reject changes that merely increase a timeout/batch size or hide work outside the measurement window without qualifying their full tradeoffs.
- Each implementation is one coherent packet: production callers/fallback, test-first invariant, change, allocation/lifetime audit, docs, representative evidence, mature independent review and current-head required CI. No separate PR per start/implement/close phase.
- Future delegated work uses exact `gpt-6.1-sol` in runtime routing, normally one worker and at most two safe independent lanes. One writer per shared closure/publication contract; serialize overlapping changes. One owner runs native benchmark collection on a quiet local or Linux host. Provisional PR successors may start only after accepted decisions and stable contracts; merge dependencies still require landed predecessors.
- Inventory current policy and active owners again before execution. Preserve dirty primary checkouts, isolate experiments, register large generated paths and release only owned disposable outputs after their consumers finish. Retain failed raw evidence and source/command receipts. No blanket `/tmp` deletion.

## Scope, reuse and documentation

#5015 and #5016 are adopted, conditional implementation owners; their historical completion packets remain intact pending the first accepted revision. #5001 stays the previous investigation/history tracker, with held #5004 / draft #5006 outside this graph. Do not reactivate that rejected representation merely because memory is an objective.

#1185 (broad automatic maintenance), #943 (runtime rewrite), #1140 (out-of-core validation), and #948 (debt reporting) remain adjacent owners; findings can link back without absorbing their whole scope. Active MVCC #4871/#4878/#4879 and tooling #5019/PR #5020 retain their separate logical-version pruning and Dgraph/Badger gates. MVCC pruning is not persistent-segment GC. Their benchmark README edits may overlap; coordinate before touching those files.

Preflight read root/TreeDB `AGENTS.md`, `CONTRIBUTING.md`, the spec index, contracts, storage/recovery/write-durability, value-log lifecycle, recoverable-root maintenance, existing benchmark code and report at the pinned base. Reusable seams: `canTrackRewriteValueLogRefDelta`, candidate dependency capture/projection, `maintenanceReachabilityScan`, `collectValueLogLiveIDsUntilWithContextAndTimeout`, and the retained-prune scheduled/inline/observed-source paths. The pointer-only rewrite microbenchmark uses paged leaves, so it cannot certify compressed outer-leaf closure work unchanged. WAL-on scheduling eligibility must be verified at the actual public caller; old #943 scheduler statements are historical.

Behavior owners update affected lifecycle, recoverable-root, write/durability and recovery specs with their PRs. Profiling/harness changes also own producer/consumer parsers, artifact tests and both benchmark READMEs when their contract changes. This tracker's ticket-only investigation changes no product behavior or format.

## Completion ledger

- [x] Accept #5029 findings and verify revised live ticket bodies, ownership, gates and selected dependencies.
- [ ] Land each selected implementation packet or explicitly replace a disproven mechanism while preserving product obligations.
- [ ] Accept #5030 source-bound comparison, including representative scale, post-maintenance reads and process memory.
- [ ] Primary maintenance outcomes pass; the secondary memory outcome has measured support. Unmet objectives remain open unless the user explicitly accepts a narrower endpoint.
- [ ] No unaccepted hard-invariant or guardrail failure; docs are current, failed evidence retained and owned disposable outputs accounted for.
- [ ] Record the final product decision here. Research completion, green CI, accepted artifacts and linked follow-ups alone do not complete this tracker.


## Accepted investigation checkpoint: qualification seam

Source audit at 9905 confirms existing churn restores the full population and retained mode only verifies. Selected an instrumentation-only prerequisite #5031 for sparse churn and retained-final-fixture performance guards. It owns the reviewed/landed harness before expensive collection; #5030 now requires its merged PR. The rest of #5029 remains running, and #5015/#5016 remain conditional until their mechanism decisions are accepted. Preserve the original parent gates and held #5004/PR#5006 exclusion.


## Accepted #5029 decision and current frontier

https://github.com/snissn/gomap/issues/5029#issuecomment-6001679661 selects #5015 exact logical deltas + exact raw leaf collector and #5016 certified manifest membership + batch GC with a coverage gate. #5031 is the instrumentation-only prerequisite. #5029 completed its accepted issue-update output; baseline numerical noise calibration, product speed/progress/memory and final #5030 remain open. #5016 construction may use the recorded #5015 contract provisionally, with shared helper ownership and synchronization before merge. Original parent invariants and outcome gates are preserved.


Instrumentation prerequisite selected during execution: #5035 lands the minimal matched compact capture/analyzer, reusing #5031 native provenance and owned-process RSS. The collector must be reviewed and landed before expensive maintenance qualification; #5030 and selected product performance evidence depend on it. This repairs the missing reusable capture/analysis seam without changing the accepted #5029 gates or held #5004/PR#5006 exclusion.


### Accepted reassessment: v7 baseline physical-byte accounting failure

The original v7 baseline controller stopped honestly at primary seed24 / 3M / exhaustive: all three compact commands returned rc0, but all three failed the unchanged policy-completion gate. The exact original validator confirms five sealed segments and 23,380 stale bytes in each result. A read-only physical header walk finds 5,845 actual frames; each file's discrepancy equals its four-byte-per-frame CRC prefix. The pointer-relative resolver intentionally excludes that prefix, while physical maintenance compares its sum with full file sizes. Original failed source, raw receipts, databases and policy remain retained; there is no candidate-pair authority and no qualification acceptance. See [the failure checkpoint](https://github.com/snissn/gomap/issues/5030#issuecomment-6023297602).

Root accepted the independently checked causal inquiry and selected **#5075** as a narrow, necessary **PR** prerequisite: include CRC prefixes exactly once in physical segment/chunk live-byte consumers, preserving pointer encoding, generic resolver semantics, grouped-frame dedupe, root/pin/resource authority, checksums, durability, counters and completion/admission thresholds. Test first against actual physical bytes, force output rollover, retain genuine stale/GC behavior and verify checksum-enabled reopen. The graph coordinator owns native execution, review/CI integration and merge; the implementation worker is exact GPT-6.1 Sol in an isolated worktree.

Remaining ordering: accepted #5029 -> #5075 common-source correctness repair -> refreshed matched A/R/B correctness/build/source/environment inputs -> complete B36 and R18 calibration/noise freezes -> original paired qualification for selected R (#5015 / PR #5037) and B (#5016 / PR #5054) -> policy-compliant implementation merges -> #5030 landed-source equality and final matched acceptance. R/B construction may proceed provisionally, but their performance/merge gates remain outstanding. The failed v7 observations cannot be resumed or relabeled as fixed-source samples. New common A/R/B must contain the same accepted repair and identical measurement controls/harness, with original identity records and failed evidence preserved.

No original speed, memory, service-allocation, UNKNOWN, fixed-window, matrix/order, noise-derived 2E, material-3M, default-scheduler/conditional-4M, read/reopen/oracle or durability gate is waived. Held **#5004 / PR #5006** stay excluded. This repair fixes a correctness prerequisite; neither this accepted inquiry nor its eventual PR can close unmet parent product objectives. Root owns the next action: finish #5075, verify the actual landed repair and refresh only affected gates prospectively.
