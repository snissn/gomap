"""Join actual v12 source/host evidence and run the unchanged binding controls.

No database opens or measurement commands. Source decisions are root-owned;
historical runtime observations remain historical. Every output is exclusive.
"""
from pathlib import Path
import hashlib
import json
import time
import types

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
REMOTE = '/home/mikers/quicksilver-maintenance-5028-20261006'
ROOT = REMOTE + '/qualification-v12-refresh/qualification-v10'
CONTROLS = BASE / 'qualification-v12-fresh-controls-v2'
NCONTROLS = REMOTE + '/qualification-v12-fresh-controls-v1'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def read(p):
    return json.loads(Path(p).read_bytes())


def save(p, v):
    with Path(p).open('x') as f:
        json.dump(v, f, indent=2, allow_nan=False)
        f.write('\n')


def ref(p):
    return dict(path=REMOTE + '/' + Path(p).relative_to(BASE).as_posix(), sha256=sha(p))


assert __debug__
ip = BASE / 'qualification-v9-selected-source-preparation-v1/root_native_io.py'
assert sha(ip) == 'fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io = types.ModuleType('root_io')
io.__file__ = str(ip)
exec(compile(ip.read_bytes(), str(ip), 'exec'), io.__dict__)
lock = read(HERE / 'actual-fresh-source-lock-v12.json')
assert sha(HERE / 'actual-fresh-source-lock-v12.json') == 'bda4d2486d2e66ee33533d601d216092ce1cd8f5211cfb02aac0d9d2bf823c75'
packet = read(HERE / 'actual-native-source-reuse-readback-v12-v1.json')
assert packet['campaign_root'] == ROOT and packet['database_opens'] == 0
assert packet['original_actual_files'] == lock['original_actual_files']
assert packet['actual_files'] == lock['required_current_files']
assert len(packet['copies']) == 18 and len(packet['fixtures']) == 5
for observed, original in zip(packet['fixtures'], lock['fixtures']):
    assert observed['receipt'] == original['receipt']
    assert observed['fingerprint'] == original['original_receipt']['fingerprint']
    assert observed['physical_census'] == original['original_receipt']['physical_census']
manifest = lock['manifest']
native_input = read(BASE / 'qualification-v9-selected-source-preparation-v1/v12-actual-four-inventory-receipt-and-manifest-readback-v1-stdout.txt')['files']
old_runner_path = lock['origin_campaign'] + '/' + manifest['receipts']['runner']['path']
original_runner = native_input[old_runner_path]['value']
assert native_input[old_runner_path]['sha256'] == manifest['receipts']['runner']['sha256']
runner = packet['runner_raw']
assert runner['recorded_ns'] > lock['latest_origin_accepted_ns']
for name in ('host', 'uname', 'mount', 'ntp', 'cpu', 'processes', 'storage'):
    current, previous = runner[name], original_runner[name]
    assert current['argv'] == [ROOT if arg == lock['origin_campaign'] else arg for arg in previous['argv']]
    assert current['rc'] == 0 and current['stderr'] == ''
    if name in ('host', 'uname', 'mount', 'ntp'):
        assert current['stdout'] == previous['stdout']
stable_cpu = lambda text: [line for line in text.splitlines() if not line.startswith('CPU(s) scaling MHz:')]
assert stable_cpu(runner['cpu']['stdout']) == stable_cpu(original_runner['cpu']['stdout'])
for name in ('external_tools', 'clock_resolution', 'clock_contract', 'cache_state'):
    assert runner[name] == original_runner[name]
assert max(runner['load']) < 1, 'unexpected host load requires review before source acceptance'
# Actual idle scan reads /proc; it does not open a DB or run a correctness test.
code = """import pathlib,json,hashlib,types,time
p=pathlib.Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-native-source-adapters-v4/correctness-only-v12.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='4327a100e96d113f707edf7970901a432e77e4561e77548143268122e81e72bb'
m=types.ModuleType('idle');m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__)
m.idle(pathlib.Path('/home/mikers/quicksilver-maintenance-5028-20261006'))
print(json.dumps(dict(no_owned_measurements=True,read_ns=time.time_ns())))
"""
idle = json.loads(io.native(['python3', '-B', '-c', code], 'v12-actual-source-context-idle-readback-v1', 120))
assert idle['no_owned_measurements'] is True
current = dict(schema=1, accepted_by_root=True, campaign_root=ROOT,
    qualification=False, collection_authorized=False, performance_accepted=False,
    build_env=manifest['build_env'], original_runner_inventory_sha256=manifest['receipts']['runner']['sha256'],
    same_host_kernel_cpu_filesystem_as_original=True, clock_and_serialization_accepted=True,
    no_heavy_campaign_processes=True, actual_files=packet['actual_files'], read_ns=idle['read_ns'],
    runner_receipt=packet['runner_receipt'], actual_native_source_reuse_packet=ref(HERE/'actual-native-source-reuse-readback-v12-v1.json'),
    note='Actual fresh input/host identity only. No historical measurement or qualification is reused.')
cp = HERE/'current-host-readback.accepted-v12-v1.json'
save(cp, current)
harness = dict(schema=1, accepted_by_root=True, accepted_ns=time.time_ns(),
    qualification=False, collection_authorized=False, landed_on_main=True,
    landed_head=lock['candidate_h_head'], landed_tree=lock['candidate_h_tree'],
    product_base_head=lock['pins']['A']['head'], changed_paths_from_product_A=lock['h_changed_paths'],
    engines=['A','R','B'], held_excluded=[5004,5006], runtime_harness=lock['runtime_harness'],
    harness_files={role:REMOTE+'/source-qualification-v10-common-H/'+r['path'] for role,r in lock['runtime_harness'].items()},
    actual_source_basis_acceptance=lock['source_basis_acceptance'],
    note='Exact current A landed-source/common-harness identity verified in the accepted source basis and actual complete tracked exports. Earlier common-H collector bytes remain exact; its old source identity is not relabeled.')
hp=HERE/'common-H-actual-landed-acceptance-v12-v1.json'
save(hp,harness)
old_request=read(BASE/'qualification-v11-root-preparation-v1/source-context-request.accepted-v1.json')
request=dict(old_request)
campaign_id='quicksilver-maintenance-5028-qv12-192e501-6fa638b-73100c5'
request.update(campaign_id=campaign_id,campaign_root=ROOT,source_lock=dict(path=NCONTROLS+'/v10-source-lock.json',sha256=sha(CONTROLS/'v10-source-lock.json')),
    common_harness=ref(hp),current_host_readback=ref(cp),created_ns=time.time_ns())
adoption=HERE/'root-controls-v12-source-acceptance-v1.json'
selected={k:v for k,v in old_request['prospective_source_selection'].items() if not k.startswith('operational_') and k!='global_source_acceptance'}
selected['global_source_acceptance']=ref(adoption)
for f in CONTROLS.glob('*.py'):
    selected['operational_'+f.name]=dict(path=NCONTROLS+'/'+f.name,sha256=sha(f))
request['prospective_source_selection']=selected
origin=dict(old_request['original_root_input'])
origin.update(campaign_id=campaign_id,campaign_root=ROOT,created_ns=time.time_ns(),accepted_ns=time.time_ns(),
    inventory_sha256=lock['origin_inventory']['sha256'],manifest_sha256=lock['manifest_sha256'],
    receipt_sha256={k:v['sha256'] for k,v in manifest['receipts'].items()},libraries=manifest['libraries'],sources=manifest['sources'],
    actual_inventory_content_acceptance=dict(path=REMOTE+'/qualification-v12-source-inventory/inputs/root-actual-inventory-content-acceptance-v12-v1.json',sha256='44a7c6063934dd7fa1c190171e8e15b4d903664dcfa422bc1858b1a671556628'),
    actual_native_correctness_input=dict(path=REMOTE+'/qualification-v12-source-inventory/correctness/input.json',sha256=read(HERE/'root-actual-correctness-content-acceptance-v12-v1.json')['files'][REMOTE+'/qualification-v12-source-inventory/correctness/input.json']),
    native_correctness_receipt=lock['origin_correctness'],source_freeze=lock['origin_source_freeze'],independent_adapter_review=ref(adoption),
    note='Actual v12 source/correctness input. Prior root input is preserved separately as format/protocol provenance only; none of its historical runtime acceptance is promoted.')
request['original_root_input']=origin
deployment=dict(old_request['deployment'])
selection=read(CONTROLS/'deployment-helpers-selection.json')
constructed=read(CONTROLS/'construction-observation.json')
deployment.update(campaign_id=campaign_id,campaign_root=ROOT,created_ns=time.time_ns(),accepted_ns=time.time_ns(),
    controls=manifest['build_env'],libraries=manifest['libraries'],manifest_sha256=lock['manifest_sha256'],variants=lock['pins'],
    correctness_content_acceptance=lock['origin_correctness'],independent_adapter_review=ref(adoption),
    global_source_acceptance=ref(adoption),
    source_equality=dict(measurement_blob_modes_equal=True,whole_reference_94_equal=True,source_basis_acceptance=lock['source_basis_acceptance']),
    helpers={role:dict(path=constructed['expected_native_helper_paths'][role],sha256=value[1]) for role,value in selection.items()},
    executed_controllers={role:dict(path=NCONTROLS+'/'+name,sha256=sha(CONTROLS/name)) for role,name in [('R','r-collection-controller.py'),('B','qualification-v10-collection-controller.py')]},
    note='Actual v12 control selection and source binding only; no collection/qualification/merge acceptance.')
request['deployment']=deployment
qp=HERE/'source-context-request.accepted-v12-v1.json'
save(qp,request)
io.put({f.relative_to(BASE).as_posix():f for f in (cp,hp,qp,Path(__file__))},'v12-actual-source-context-inputs-exclusive-staging-v1')
raw=io.native(['python3','-B',NCONTROLS+'/prepare-root-source-context-v1.py',ref(qp)['path'],sha(qp)],'v12-actual-source-context-construction-v1',1800)
result=json.loads(raw)
save(HERE/'actual-root-source-context-preparation-result-v12-v1.json',result)
assert result['original_full_applicability_verified'] is True and result['database_opens']==0
binding=ROOT+'/prospective-v10-root-v1'
binder=deployment['helpers']['binder']
bound=json.loads(io.native(['python3','-B',binder['path'],'bind',result['root_input']['path'],result['root_input']['sha256'],binding], 'v12-actual-prospective-source-binding-v1',1800))
save(HERE/'actual-pre-C1-binding-result-v12-v1.json',bound)
print(json.dumps(dict(status='ACTUAL_V12_SOURCE_CONTEXT_AND_PROSPECTIVE_BINDING_CONSTRUCTED',context=result,binding=bound,qualification=False)),flush=True)
