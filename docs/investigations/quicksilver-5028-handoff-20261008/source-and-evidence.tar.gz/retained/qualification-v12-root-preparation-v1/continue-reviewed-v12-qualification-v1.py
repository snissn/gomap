"""Root sequential continuation; requires genuine joins and separate prepair admission."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,types
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
REMOTE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=REMOTE/'qualification-v12-refresh/qualification-v10'
PACKET=BASE/'qualification-v12-root-continuation-preparation-v1'
CONFIG_SHA='72d7a53db8f8af8e2c30ce2c59195599370b2ecc2bf90cea0d779790066d1b61'
FLAGS=('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized')
LATER=BASE/'qualification-v12-later-execution-preparation-v3'
FINAL=BASE/'qualification-v12-final-artifact-preparation-v1'
def canonical(p):
 p=Path(p);assert p.is_absolute() and p.resolve(strict=True)==p and p.is_file() and not p.is_symlink();return p

def sha(p):return hashlib.sha256(canonical(p).read_bytes()).hexdigest()
def read(p):return json.loads(canonical(p).read_bytes())
def ref(p):return dict(path=str(REMOTE/canonical(p).relative_to(BASE)),sha256=sha(p))
def local(r):
 assert set(r)=={'path','sha256'};p=canonical(BASE/Path(r['path']).relative_to(REMOTE));assert sha(p)==r['sha256'];return p

def bound(r):return read(local(r))
def flags(v):assert all(v[k] is False for k in FLAGS)
def scope(v):
 assert v['campaign_root']==str(ROOT) and v['held_excluded']==[5004,5006];flags(v)

def save(p,v):
 with p.open('x') as out:json.dump(v,out,indent=2,allow_nan=False);out.write('\n')

def idle():assert read(BASE/'state.json')['native_active'] is None

def receipt(p,expected_argv):
 r=read(p);assert r['owner']=='/root' and r['argv']==expected_argv and r['rc']==0 and not r.get('error')
 assert type(r['local_pid']) is int and r['local_pid']>0 and 0<r['started_ns']<r['finished_ns']<=time.time_ns()
 for channel in ('stdout','stderr'):
  d=r[channel];assert set(d)=={'path','bytes','sha256'};s=canonical(d['path'])
  assert s.stat().st_size==d['bytes'] and sha(s)==d['sha256']
 assert not canonical(r['stderr']['path']).read_bytes()
 return r

def wait_file(p,label):
 ticks=0
 while not p.exists():
  if ticks%6==0:print(json.dumps(dict(status=label,owner='/root',pid=os.getpid())),flush=True)
  time.sleep(5);ticks+=1
 return canonical(p)

def load_source(r,name):
 p=local(r);assert sys.pycache_prefix is None and not (p.parent/'__pycache__').exists()
 m=types.ModuleType(name);m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__);return m

def source_admission(config,phase):
 aggregate=bound(config['adoption']);scope(aggregate)
 assert aggregate['source_only'] is aggregate['accepted_by_root'] is True and aggregate['owner']=='/root'
 assert aggregate['selected'][phase]==config['selected'][phase]
 assert aggregate['source_adoptions'][phase]==config['adoptions'][phase]
 a=bound(config['adoptions'][phase]);scope(a)
 assert a['source_only'] is a['accepted_by_root'] is True and a['helper']==config['selected'][phase]
 local(config['selected'][phase]);return a

def invoke(config,phase,actual_fields,authorization):
 idle();source_admission(config,phase)
 q=bound(config['drafts'][phase]);scope(q)
 assert q['source_only'] is True and q['accepted_by_root'] is False and q['authorized_ns'] is None
 assert q['helper']==config['selected'][phase] and q['helper_source_acceptance']==config['adoptions'][phase]
 q.pop('source_only');q.update(actual_fields)
 q.update(accepted_by_root=True,owner='/root',authorized_ns=time.time_ns(),status='ROOT_AUTHORIZED_SEQUENTIAL_REVIEWED_HANDOFF_ONLY')
 q[authorization]=True
 for k in ('serial_and_quiescent','exclusive_native_owner'):
  if k in q:q[k]=True
 flags(q)
 request=HERE/(phase+'-continuation-actual-request-v12-v1.json');save(request,q)
 helper=local(q['helper']);argv=[sys.executable,'-B',str(helper),str(request),sha(request)]
 label=phase+'-continuation-actual-v12-v1';run=HERE/(label+'-run.json')
 out=HERE/(label+'-stdout.txt');err=HERE/(label+'-stderr.txt')
 assert not run.exists()
 row=dict(argv=argv,owner='/root',script=str(helper),script_sha256=sha(helper),request=ref(request),started_ns=time.time_ns(),rc=None,child_joined=False,local_owner_pid=os.getpid(),qualification=False,performance_accepted=False,merge_authorized=False)
 with out.open('xb') as stdout,err.open('xb') as stderr:
  child=subprocess.Popen(argv,stdout=stdout,stderr=stderr);row['local_pid']=child.pid
  print(json.dumps(dict(status='REVIEWED_CHILD_STARTED',phase=phase,pid=child.pid,argv=argv)),flush=True)
  try:row['rc']=child.wait();row['child_joined']=True
  except BaseException as error:
   row['error']=repr(error)
   if child.poll() is None:child.terminate()
   row['rc']=child.wait();row['child_joined']=True
   raise
  finally:
   row.update(finished_ns=time.time_ns(),stdout=dict(path=str(out),bytes=out.stat().st_size,sha256=sha(out)),stderr=dict(path=str(err),bytes=err.stat().st_size,sha256=sha(err)))
   save(run,row)
 receipt(run,argv);assert row['child_joined'] is True;idle()
 value=json.loads(out.read_bytes());scope(value)
 return value

def genuine_outcome(path,value,status):
 actual=read(path);assert actual==value and actual['status']==status;scope(actual);return ref(path)

def main():
 assert __debug__ and sys.flags.dont_write_bytecode and sys.pycache_prefix is None
 assert sha(PACKET/'finite-config.json')==CONFIG_SHA
 config=read(PACKET/'finite-config.json')
 # Explicit root invocation authorizes this continuation; all source admissions remain source-only.
 assert len(sys.argv)==3
 admission=read(canonical(sys.argv[1]));assert sha(Path(sys.argv[1]))==sys.argv[2]
 scope(admission);assert admission['owner']=='/root' and admission['accepted_by_root'] is True and admission['continuation_authorized'] is True
 assert admission['helper']==ref(Path(__file__).resolve()) and admission['current_source_adoption']==config['adoption']
 assert type(admission['authorized_ns']) is int and 0<admission['authorized_ns']<time.time_ns()
 previous=HERE/'original-global-analysis-controller-actual-v12-v1-run.json'
 wait_file(previous,'WAITING_GENUINE_ORIGINAL_GLOBAL_JOIN')
 original_request=HERE/'original-global-analysis-actual-request-v12-v1.json'
 original_helper=local(config['original_helper'])
 r=receipt(previous,[sys.executable,'-B',str(original_helper),str(original_request),sha(original_request)])
 accepted_path=LATER/'root-global-calibration-content-acceptance-v12-v1.json'
 accepted=read(accepted_path);scope(accepted)
 assert accepted['accepted_by_root'] is True and accepted['status']=='ACTUAL_ORIGINAL_39C_39GUARDS_B36_R18_CONTENTS_ACCEPTED'
 assert (accepted['calibration_captures'],accepted['calibration_guards'],accepted['B_slots'],accepted['R_slots'])==(39,39,36,18)
 stream_rows=[json.loads(line) for line in canonical(r['stdout']['path']).read_bytes().splitlines() if line.strip()]
 assert stream_rows and all(isinstance(row,dict) for row in stream_rows) and stream_rows[-1]==accepted
 assert r['started_ns']<=accepted['accepted_ns']<=r['finished_ns']
 idle()
 io=load_source(config['io'],'unchanged_root_io');utility=load_source(config['selected']['utility'],'reviewed_exact_stage')
 source_admission(config,'utility')
 staged=[]
 sources=config['staging_sources']
 for start in range(0,len(sources),32):
  batch=sources[start:start+32]
  staged.append(utility.exact_stage(io,{Path(x['path']).relative_to(REMOTE).as_posix():local(x) for x in batch},'v12-continuation-reviewed-source-batch-'+str(start//32+1)))
 binding_path=HERE/'root-continuation-actual-staged-source-binding-v12-v1.json'
 binding=dict(schema=1,status='ACTUAL_REVIEWED_SOURCE_BYTES_STAGED_ROOT_INSPECTION_REQUIRED',accepted_by_root=False,owner='/root',campaign_root=str(ROOT),held_excluded=[5004,5006],source_adoption=config['adoption'],sources=sources,actual_stages=staged,staged_ns=time.time_ns(),qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False)
 save(binding_path,binding)
 full=invoke(config,'full-R-global54',dict(actual_global_analysis_content_acceptance=ref(accepted_path)),'later_artifact_execution_authorized')
 full_ref=genuine_outcome(LATER/'root-full-R-and-global54-actual-acceptance-v12-v1.json',full,'ACTUAL_FULL_R_COMPLETE24_CANONICAL_B_AND_GLOBAL54_REPLAY_PASS')
 assert full['accepted_by_root'] is True and (full['replay_result']['baseline_captures'],full['replay_result']['guard_captures'],full['replay_result']['B_slots'],full['replay_result']['R_slots'])==(39,39,36,18)
 physical=invoke(config,'physical34',dict(actual_full_R_GLOBAL54_content_acceptance=full_ref),'later_artifact_execution_authorized')
 physical_ref=genuine_outcome(LATER/'actual-physical34-root-content-result-v12-v1.json',physical,'ACTUAL_PHYSICAL34_ROOT_CONTENT_ACCEPTANCE_PASS')
 assert physical['preserved_count']==34 and physical['no_pair_namespace'] is True
 checkpoint=HERE/'root-prepair-current-transport-checkpoint-accepted-v12-v1.json'
 wait_file(checkpoint,'WAITING_SEPARATE_ROOT_PREPAIR_SOURCE_CHECKPOINT')
 check=read(checkpoint);scope(check);idle()
 assert check['owner']=='/root' and check['accepted_by_root'] is check['pair_launch_authorized'] is True
 assert type(check['accepted_ns']) is int and physical['accepted_ns']<=check['accepted_ns']<time.time_ns()
 assert check['current_source_adoption']==config['adoption'] and check['staged_source_binding']==ref(binding_path)
 assert check['full_R_and_global54_actual_acceptance']==full_ref and check['physical34_actual_acceptance']==physical_ref
 evidence=bound(check['actual_external_source_checkpoint']);assert evidence['owner']=='/root' and evidence['issue']==5030 and evidence['source_checkpoint_pass'] is True
 pairs=invoke(config,'original-pairs',dict(full_R_and_global54_actual_acceptance=full_ref,physical34_actual_acceptance=physical_ref,root_prepaired_checkpoint=ref(checkpoint)),'pair_launch_authorized')
 joined_ref=genuine_outcome(HERE/'root-original114-pair-phase-joined-v12-v1.json',pairs,'ORIGINAL_PAIR_DRIVER_JOINED_ACTUAL_RAW_CONTENT_REVIEW_REQUIRED')
 assert pairs['original_pair_count']==pairs['state_specific_guard_count']==114 and pairs['raw_content_acceptance'] is False
 raw=invoke(config,'raw-metadata',dict(joined_pair_phase=joined_ref),'root_final_handoff_authorized')
 raw_ref=genuine_outcome(FINAL/'root-final-raw-and-metadata-actual-outcome-v12-v1.json',raw,'ACTUAL_RAW114_ACCEPTED_EXACT34_IO_PENDING_FINAL_CONTENT_ACCEPTANCE')
 assert raw['original_pair_count']==raw['state_specific_guard_count']==114
 content=invoke(config,'content-evaluations',dict(actual_raw_and_metadata_outcome=raw_ref,actual_metadata_result=ref(FINAL/'actual-final-exact34-metadata-result-v12-v1.json')),'root_final_handoff_authorized')
 assert read(FINAL/'root-final-evaluations-actual-outcome-v12-v1.json')==content
 print(json.dumps(dict(status='REVIEWED_SEQUENTIAL_CHILDREN_JOINED_ROOT_PRODUCT_DECISION_REQUIRED',qualification=False,performance_accepted=False,merge_authorized=False)),flush=True)

if __name__=='__main__':main()
