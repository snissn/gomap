"""Root reads complete retained actual receipts and emits inventory-only acceptance."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

BASE = Path('/Users/michaelseiler/dev/snissn/gomap/tmp/quicksilver-maintenance-5028-20261005')
PREP = BASE / 'qualification-v12-root-preparation-v1'
INPUTS = PREP / 'actual-root-approved-source-inputs-v1'
RAW = BASE / 'qualification-v9-selected-source-preparation-v1'
ADAPTER = BASE / 'qualification-v12-native-source-adapters-v4'
NROOT = '/home/mikers/quicksilver-maintenance-5028-20261006'
FOUND = NROOT + '/qualification-v12-source-inventory'
SLOTS = {'A': 'A', 'A_unified': 'A', 'R': 'R', 'R_unified': 'R',
         'B': 'B', 'B_unified': 'B', 'restore': 'A', 'benchprof': 'A'}

def read(path):
    return json.loads(Path(path).read_bytes())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    packet_path = RAW / 'v12-actual-four-inventory-receipt-and-manifest-readback-v1-stdout.txt'
    compiler_path = RAW / 'v12-actual-eight-complete-compiler-input-receipt-readback-v1-stdout.txt'
    packet = read(packet_path)['files']
    compiler_packet = read(compiler_path)
    manifest = packet[FOUND + '/manifest.json']['value']
    prepared = packet[FOUND + '/inventory-prepared.json']['value']
    stop = packet[FOUND + '/build-complete.json']['value']
    assert stop == compiler_packet['build_complete']
    request = read(ADAPTER / 'actual-build-request-v12-v4.json')
    scope = read(INPUTS / 'root-native-input-scope-v12.json')
    freeze = read(INPUTS / 'source-freeze-v12-v2.json')
    basis = read(INPUTS / 'native-observed-source-basis-v12.json')
    composition = read(INPUTS / 'source-composition-v12.json')
    environment = read(INPUTS / 'native-environment-v12.json')
    assert sha(INPUTS / 'source-freeze-v12-v2.json') == request['source_freeze']['sha256'] == stop['source_freeze_sha256']
    assert sha(INPUTS / 'source-composition-v12.json') == request['composition']['sha256'] == stop['composition_sha256']
    assert prepared['accepted_by_root'] is False and stop['accepted_by_root'] is False
    assert prepared['performance_runs'] == stop['performance_runs'] == 0
    assert stop['completed_ns'] <= prepared['created_ns'] <= time.time_ns()
    variants = basis['exact_variants']
    receipts = {name: packet[FOUND + '/' + ref['path']]['value'] for name, ref in manifest['receipts'].items()}
    assert receipts['source']['received_composition'] == composition
    assert receipts['source']['baseline_product'] == receipts['source']['landed_harness_head'] == variants['A']['head']
    assert receipts['source']['harness_tree'] == variants['A']['tree']
    assert receipts['build']['env'] == manifest['build_env']
    assert receipts['build']['source_basis'] == request['source_basis']
    assert receipts['build']['compiler_input_receipts'] == stop['compiler_input_receipts']
    assert receipts['native']['libraries'] == manifest['libraries'] == scope['expected_native_libraries'] == freeze['expected_native_libraries']
    assert len(manifest['libraries']) == 16
    assert set(manifest['sources']) == set(compiler_packet['compiler_inputs']) == set(SLOTS)
    assert receipts['build']['toolchain']['version']['stdout'] == 'go version go1.26.3 linux/amd64\n'
    assert environment['GOMAXPROCS'] == '12' and environment['GOMEMLIMIT'] == 'off' and environment['GOGC'] == '100'
    assert environment['GOWORK'] == 'off' and environment['GOEXPERIMENT'] == ''
    files = {path: item['sha256'] for path, item in packet.items()}
    files.update(freeze['files'])
    files[request['source_freeze']['path']] = request['source_freeze']['sha256']
    files[str(Path(NROOT) / ADAPTER.name / 'actual-build-request-v12-v4.json')] = sha(ADAPTER / 'actual-build-request-v12-v4.json')
    summary = {}
    normalized = {}
    for slot, role in SLOTS.items():
        comp = compiler_packet['compiler_inputs'][slot]
        source = manifest['sources'][slot]
        build = receipts['build']['binaries'][slot]['original_build']
        assert comp['slot'] == slot and comp['role'] == role
        assert {k: comp[k] for k in ('head', 'tree')} == variants[role]
        assert {k: source[k] for k in ('head', 'tree')} == variants[role]
        assert comp['request'] == build['accepted_input']['request']
        assert comp['request']['sha256'] == sha(ADAPTER / 'actual-build-request-v12-v4.json')
        assert comp['native_input_scope'] == request['native_input_scope']
        assert comp['native_input_files'] == scope['expected_files'] and len(comp['native_input_files']) == 27378
        assert build['rc'] == 0 and build['raw_hashes_final'] is True and build['process_group_cleanup']['quiescent'] is True
        assert build['binary_sha256'] == source['binary_sha256'] == stop['build_receipts'][slot]['binary_sha256']
        assert build['accepted_input']['environment_sha256'] == request['environment']['sha256']
        assert build['accepted_input']['go_version'] == 'go version go1.26.3 linux/amd64'
        assert '-work' in build['command'] and '-x' in build['command'] and '-buildvcs=false' in build['command']
        assert comp['tags'] == (['-tags', 'lmdb rocksdb'] if slot.endswith('_unified') else [])
        assert receipts['build']['binaries'][slot]['go_version']['rc'] == 0
        assert ': go1.26.3\n' in receipts['build']['binaries'][slot]['go_version']['stdout']
        dynamic = receipts['native']['binaries'][slot]
        assert dynamic['rc'] == (1 if slot in ('restore', 'benchprof') else 0)
        assert 'not found' not in dynamic['stdout'] + dynamic['stderr']
        if slot in ('restore', 'benchprof'):
            assert 'not a dynamic executable' in dynamic['stderr']
        files[stop['compiler_input_receipts'][slot]['path']] = stop['compiler_input_receipts'][slot]['sha256']
        files[build['stdout_path']] = build['stdout_sha256']
        files[build['stderr_path']] = build['stderr_sha256']
        for key in ('go_list_receipt', 'go_list_raw', 'build_receipt', 'export_listing_receipt', 'export_listing_raw'):
            files[comp[key]['path']] = comp[key]['sha256']
        for key in ('selected_files', 'module_files', 'generated_and_work_files', 'actual_import_archives', 'actual_package_export_archives', 'repository_harness_inputs', 'uncompiled_repository_test_inputs'):
            for path, item in comp[key].items():
                if key == 'repository_harness_inputs':
                    assert item['path'] == composition['variants'][role]['source'] + '/' + path
                    path = item['path']
                assert path == item['path'] and re.fullmatch('[0-9a-f]{64}', item['sha256'])
                assert type(item['bytes']) is int and item['bytes'] >= 0
                if key == 'uncompiled_repository_test_inputs':
                    assert item['compiled_in_this_non_test_build'] is False and item['field'] in ('TestGoFiles', 'XTestGoFiles')
                else:
                    assert not path.endswith('_test.go')
                if key == 'generated_and_work_files':
                    assert path.startswith(comp['work_directory'] + '/')
                files[path] = item['sha256']
        source_prefix = composition['variants'][role]['source'] + '/'
        def normalize(mapping):
            return {(path.removeprefix(source_prefix) if path.startswith(source_prefix) else path): item['sha256'] for path, item in mapping.items()}
        normalized[slot] = {key: normalize(comp[key]) for key in ('selected_files', 'module_files', 'repository_harness_inputs')}
        summary[slot] = {key: len(comp[key]) for key in ('selected_files', 'module_files', 'generated_and_work_files', 'actual_import_archives', 'actual_package_export_archives', 'repository_harness_inputs', 'uncompiled_repository_test_inputs')}
    for role in ('R', 'B'):
        allowed = set(subprocess.check_output(['git', 'diff', '--name-only', variants['A']['head'], variants[role]['head']], text=True).splitlines())
        for suffix in ('', '_unified'):
            original = normalized['A' + suffix]
            candidate = normalized[role + suffix]
            assert candidate['module_files'] == original['module_files']
            assert candidate['repository_harness_inputs'] == original['repository_harness_inputs']
            changed = sorted(name for name in set(original['selected_files']) | set(candidate['selected_files']) if original['selected_files'].get(name) != candidate['selected_files'].get(name))
            assert set(changed).issubset(allowed)
            assert all(name.startswith('TreeDB/') and not name.startswith('TreeDB/cmd/') for name in changed)
            summary[role + suffix]['active_selected_source_deltas'] = changed
    runner = receipts['runner']
    assert runner['owner'] == '/root' and runner['serial_collection'] is True
    assert 'NTP=yes\n' in runner['ntp']['stdout'] and 'NTPSynchronized=yes\n' in runner['ntp']['stdout']
    assert runner['clock_contract'] == {'pause_wall_monotonic_tolerance_ns': 1000000, 'actual_per_pause_bounds_checked': True, 'sustained_window_seconds': 10, 'trim_boundary_ns': 200000000, 'minimum_complete_samples': 40, 'maximum_gap_ns': 400000000}
    assert runner['clock_resolution']['monotonic']['monotonic'] is True
    assert max(runner['load']) < 2
    assert 'AMD Ryzen 7 9700X' in runner['cpu']['stdout'] and 'ext4' in runner['mount']['stdout']
    for row in runner['processes']['stdout'].splitlines():
        assert not ('/bin/unified-bench' in row or '/bin/treemap' in row or '/quicksilver_maintenance.py' in row)
    for ref in runner['external_tools'].values():
        files[ref['path']] = ref['sha256']
    for receipt in receipts.values():
        def collect(value):
            if isinstance(value, dict):
                if isinstance(value.get('raw_receipt'), str):
                    files[value['raw_receipt']] = value['raw_receipt_sha256']
                for child in value.values():
                    collect(child)
            elif isinstance(value, list):
                for child in value:
                    collect(child)
        collect(receipt)
    for path, item in manifest['libraries'].items():
        files[item['resolved']] = item['sha256']
    for slot, ref in stop['source_receipts'].items():
        files[ref['path']] = ref['sha256']
    acceptance = dict(schema=1, receipt_kind='qualification-v12-root-actual-inventory-content-acceptance',
        accepted_by_root=True, accepted_ns=time.time_ns(), qualification=False, collection_authorized=False,
        held_excluded=[5004,5006], campaign_root=FOUND,
        actual_receipt_contents_accepted={r: True for r in ('source','build','native','runner')},
        landed_harness_attested=True, host_clock_and_serialization_accepted=True,
        complete_compiler_input_contents_accepted=True, actual_compiler_input_contents_accepted={slot: True for slot in SLOTS},
        inventory_prepared_sha256=packet[FOUND + '/inventory-prepared.json']['sha256'],
        manifest_sha256=packet[FOUND + '/manifest.json']['sha256'],
        receipt_sha256={r:v['sha256'] for r,v in manifest['receipts'].items()},
        sources=manifest['sources'], libraries=manifest['libraries'],
        build_complete={'path':FOUND + '/build-complete.json','sha256':packet[FOUND + '/build-complete.json']['sha256']},
        build_complete_sha256=packet[FOUND + '/build-complete.json']['sha256'],
        compiler_input_receipts=stop['compiler_input_receipts'], source_basis=request['source_basis'],
        source_basis_acceptance=request['source_basis_acceptance'], variants=variants, files=files,
        root_review='Actual full source/build/native/runner JSON and eight complete compiler-input contents reviewed; equal frozen27378 native files, identical modules/benchmark harness inputs, actual candidate-only selected product deltas, uncompiled tests, linked libraries, retained WORK/export/cache inputs and serial quiet-clock contracts verified. No correctness or performance acceptance.',
        actual_content_review_summary=summary,
        retained_readbacks=[{'path':str(path),'sha256':sha(path)} for path in (packet_path,compiler_path)])
    target = PREP / 'root-actual-inventory-content-acceptance-v12-v1.json'
    with target.open('x') as stream:
        json.dump(acceptance,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'path':str(target),'sha256':sha(target),'native_bound_files':len(files),'actual_compiler_summary':summary},indent=2))

if __name__ == '__main__':
    main()
