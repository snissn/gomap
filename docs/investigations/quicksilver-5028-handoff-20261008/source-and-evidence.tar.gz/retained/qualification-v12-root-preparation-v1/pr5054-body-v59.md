Retained-value-log pruning repeats user/system pointer walks and per-segment maintenance calls. This change reuses complete DB-certified recovery membership and performs one fenced GC call for the retained candidate batch. Uncertified roots, detached cached roots, unresolved publication debt and foreign physical identities retain full projection or fail closed.

GC revalidates exact root/resource authority at mutation, preserves active and in-use segments, and reports actual partial marks, pending files and deletions separately. Explicit synchronous pruning can reclaim proven closed recent segments; ordinary scheduler pressure retains its existing eligibility protections. The implementation reuses existing recovery membership, projection and GC APIs with the original durability, codecs, checksums, mapping and pause/budget controls.

Candidate `73100c5b8cc2337d9cff36c60a8e4182f1820fe9` is stacked on R `6fa638b8bffa71750e1aefa0bb746bb747aa06c1` / PR #5037; both include the landed common retirement fix (PR #5084). The accepted inquiry #5029 selected this work for parent #5028. Its predecessor must land before final branch synchronization and merge.

Validation at this candidate:

- All 46 original and additive Linux normal/race correctness commands passed. Full raw-event replay found no skipped or failed test events; the actual correctness-content acceptance is SHA256 `3e5ad02d26db7cb384a35f928decfc13584179b0f7d80b79a9399ec1d5a5ebcf`.
- Five private restored-copy compatibility oracles passed full-value, miss, census and reopen checks. Actual acceptance SHA256: `d2e4a8367b41329d1435dc4f08fcc5fab431c7cb966d8959ffbe47f195479870`.
- Both exact heads have all 51 current check/status results SUCCESS. Independent current-composition source reviews are accepted.
- Original matched calibration is running under durable ordinary commit, default compression/checksum verification, realistic generic keys/values and the unchanged measurement controls. Maintenance speed, natural peak/sustained process memory, service/allocation nonregression, storage and default scheduler progress remain unqualified. Candidate pairs begin only after complete original calibration acceptance.

The complete evidence history and current source/CI checkpoint are tracked in #5030 and [parent #5028](https://github.com/snissn/gomap/issues/5028#issuecomment-6042769825). Historical failed packets retain their original identities. Later successful checks do not establish a cause for earlier failures.

This remains draft. Matched outcome gates, ordered predecessor landing where applicable, necessary final branch synchronization, mature review, current-head required CI and actual landed-source applicability must pass before merge. No storage-format, durability, production batch-size or artificial memory-limit change is selected. Held #5004 / PR #5006 remain excluded.

Closes #5016 only after its completion packet passes.
