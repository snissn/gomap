Execution checkpoint v68. The fresh V12 campaign has completed all **30 original offline calibration commands and30 corresponding retained read-only guard commands with rc0**, including primary and holdout3M Exhaustive cases within the unchanged30-minute guard limit. The sole root-owned serial native campaign is now collecting the nine original online controls and their nine guards. Exact60-receipt return-code observation SHA256: `d2327549c9c542de725928d3f3d69005611490fa062e9ed337d8ba749c8dbf9e`. This is a command-completion observation; only the earlier small6C/6guard raw-content acceptance exists so far. Complete39 raw/global acceptance, candidate measurements and product qualification are still pending.

Frozen A `192e5019e579af3b98ae4fbf4ea497bb9ccd672f`, R/PR5037 `6fa638b8bffa71750e1aefa0bb746bb747aa06c1`, and B/PR5054 `73100c5b8cc2337d9cff36c60a8e4182f1820fe9` retain the actual eight native builds, accepted46 correctness commands and five full compatibility oracles. The current campaign keeps ordinary durable ACK, default compression/checksums, generic realistic keys/values, the complete original matrices, fixed windows/order and unchanged E/sign/2E/UNKNOWN rules. R/B remain draft, unmerged and unqualified.

Root separately accepted source applicability for the observed external main a758 delta: none of its25 changed paths are selected in any of the eight actual build closures or common H. This permits the frozen campaign to continue unchanged; actual later synchronization/full maps/compiled and native applicability/current-head correctness/CI/mature review remain mandatory. All original service/allocation/storage/oracle/material3M speed AND credible actual process-memory/default scheduled eligible progress/conditional4M obligations survive. Full original54 evaluation precedes any separate strict19 proof; the additional16 B allocation ledgers and existing6 R ledgers remain required. Numerical UNKNOWN stays nonpassing.

Exactly three released local provisioning relays were actually deleted after identity/consumer/release checks; source, original evidence, failed databases and active worktrees remain protected. No unrelated or held work was taken over. **#5004 / PR5006 remain excluded.** Historical checkpoints below keep their original identities and cannot qualify current source.

```json
{
  "checkpoint_version": 68,
  "repo": "snissn/gomap",
  "parent": 5028,
  "owner": "/root",
  "delegated_model": "gpt-6.1-sol",
  "held_excluded": [
    5004,
    5006
  ],
  "campaign_id": "quicksilver-maintenance-5028-qv12-192e501-6fa638b-73100c5",
  "native_measurement_owner": "/root",
  "offline_control_rc0": 30,
  "offline_guard_rc0": 30,
  "complete39_raw_and_GLOBAL54_accepted": false,
  "candidate_runs_started": false,
  "performance_accepted": false,
  "qualification": false,
  "merge_authorized_by_evidence": false,
  "nodes": {
    "5029": {
      "state": "completed",
      "deliverable": "issue-update",
      "accepted_output": "https://github.com/snissn/gomap/issues/5029#issuecomment-6001679661"
    },
    "5015": {
      "state": "performance-pending",
      "pr": 5037,
      "head": "6fa638b8bffa71750e1aefa0bb746bb747aa06c1",
      "draft": true,
      "merged": false
    },
    "5016": {
      "state": "performance-pending",
      "pr": 5054,
      "head": "73100c5b8cc2337d9cff36c60a8e4182f1820fe9",
      "draft": true,
      "merged": false
    },
    "5030": {
      "state": "qualification-pending",
      "deliverable": "artifact",
      "requires_actual_selected_merges_and_landed_applicability": true
    }
  },
  "offline_observation_sha256": "d2327549c9c542de725928d3f3d69005611490fa062e9ed337d8ba749c8dbf9e",
  "next_action": "Join original39 calibration and guards; original B36/R18 global54 and physical34; separate source checkpoint; unchanged114 runs and114 guards; original-full54 then strict19 plus allocation and surviving product gates; reviewed ordered merges; actual landed-source5030"
}
```

Immutable prior checkpoint history follows.

