from pathlib import Path
import hashlib,json,sys,time
sys.dont_write_bytecode=True
B=Path('/home/mikers/quicksilver-maintenance-5028-20261006');inventory={'path': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-root-preparation-v1/small-actual-content-replay-v12-v1/small-actual-inventory.json', 'sha256': '63fff0f487ae0aa5bba0d548a8c30fefc6d0483b99a1dd2a09f8e22aa340fc86'};wanted={'qualification-v12-root-preparation-v1/root-actual-small-content-acceptance-v12-v1.json': 'f25701b326c0b83c2e5c07b5b8f3139b7ac109be1bc8125c74d0219ddbd17e96', 'qualification-v12-root-preparation-v1/actual-small-original-raw-replay-v12-v1.json': '6e01690fd0ba2fa516b11985a3097bbd5d4cf931b762102df768ef33b301f314', 'qualification-v12-calibration-activation-preparation-v3/root-authorize-remaining-calibration-v12-v1.py': 'f7db5eeae822f18a49d73c764511787edee449b216ccb7c6d92cde8477221f42', 'qualification-v9-selected-source-preparation-v1/v12-actual-original-small-calibration-v1-run.json': '911dc44552876a7eb197c0c1fa71742204473f28f85c0e6b8152a6f3dd59d4df', 'qualification-v9-selected-source-preparation-v1/v12-actual-original-small-calibration-v1-stdout.txt': 'ed2fd7e889f2b350b363bf5eaafd10b71dfb18489453271efca0268c7b38cf82', 'qualification-v9-selected-source-preparation-v1/v12-actual-original-small-calibration-v1-stderr.txt': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'qualification-v9-selected-source-preparation-v1/v12-actual-original-small-raw-replay-v1-run.json': 'bddc67ec0d5674a79d047327d3856e2ac10f6cef5718c451b1efc8e08a9dd516', 'qualification-v9-selected-source-preparation-v1/v12-actual-original-small-raw-replay-v1-stdout.txt': '6e01690fd0ba2fa516b11985a3097bbd5d4cf931b762102df768ef33b301f314', 'qualification-v9-selected-source-preparation-v1/v12-actual-original-small-raw-replay-v1-stderr.txt': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'};old={'path': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10-prospective-root-v1/pre-c1-anchor.accepted-v2.json', 'sha256': '888b36ee11f99c77af68341651cef36e1fe4cb817652091e17edb90eec8497b4'};accepted={'path': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-root-preparation-v1/root-actual-small-content-acceptance-v12-v1.json', 'sha256': 'f25701b326c0b83c2e5c07b5b8f3139b7ac109be1bc8125c74d0219ddbd17e96'};out='/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10-prospective-root-v1/post-small-source-anchor.accepted-v1.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(inventory['path'])==inventory['sha256'];a=json.loads(Path(inventory['path']).read_bytes())
assert sha(old['path'])==old['sha256'];original=json.loads(Path(old['path']).read_bytes())
assert a['root']=='/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10' and a['accepted_by_root'] is True and all(a['files'].get(p)==h for p,h in original['files'].items())
for name,h in wanted.items():
 p=B/name;assert sha(p)==h
 if str(p) in a['files']:assert a['files'][str(p)]==h
 else:a['files'][str(p)]=h
for p,h in ((inventory['path'],inventory['sha256']),(old['path'],old['sha256'])):
 if p in a['files']:assert a['files'][p]==h
 else:a['files'][p]=h
source=Path(__file__)
assert source.is_file() and not source.is_symlink() and source.resolve(strict=True)==source and str(source) not in a['files']
a['files'][str(source)]=sha(source)
a['generated_native_probe']={'path':str(source),'sha256':sha(source)}
canonical={}
for p,h in a['files'].items():
 p=Path(p);r=p.resolve(strict=True)
 assert p.is_absolute() and p.is_file() and r not in canonical and sha(p)==h,str(p)
 canonical[r]=str(p)
 if str(p).endswith('.py'):assert not (p.parent/'__pycache__').exists()
for folder in (Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10'),Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')/'plans',Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')/'receipts'):
 if folder.exists():assert not any(p.name.startswith(('pairs','ar-pairs','ar-guard','ar-orchestration-pairs','orchestration-pairs')) for p in folder.iterdir())
assert sys.pycache_prefix is None
a.update(actual_file_count=len(a['files']),actual_small_contents=accepted,actual_small_contents_accepted=True,
 original_pre_c1_anchor=old,diagnostic_raw_inventory=False,raw_validation_pending=False,qualification=False,
 collection_authorized=False,candidate_pair_collection_authorized=False,performance_accepted=False,
 note='Actual additive post-small raw/source closure. All original_source_bindings mechanism/source/rule/context bindings and genuine before-C1 times retained; source mechanism unchanged. Original small raw replay accepted; no performance/pair authority.')
with Path(out).open('x') as f:json.dump(a,f,indent=2,allow_nan=False);f.write('\n')
proof=dict(schema=1,status='ACTUAL_POST_SMALL_SOURCE_RAW_CLOSURE_PASS',actual_files=len(a['files']),original_source_bindings_retained=True,
 no_pair_namespace=True,canonical_hashes_verified=True,python_cache_absent=True,checked_ns=time.time_ns(),qualification=False,
 anchor={'path':out,'sha256':sha(out)})
with Path(out).with_name('post-small-source-anchor.actual-readback-v1.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n')
print(json.dumps(dict(anchor=a,proof=proof)))
