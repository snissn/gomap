Compressed outer-leaf rewrites and ordinary cached checkpoints repeatedly walk dependency closures and recapture stable resources. This change carries exact membership through supported logical ValuePtr and leaf-file deltas, keeps one physical producer family per active lane, and transfers attempt-owned resources at the existing publication boundary. Unsupported, stale or inconsistent projections retain the full scan.

Both recoverable roots, pinned readers, publication debt, dictionary/template resources and physical identity checks retain their existing authority. Rotation, conflict and abort release the correct owners. The same packet removes a redundant copy from owned inline reads and probes namespace identity without opening another physical handle, preserving validation frequency, flush/frontier checks and custom-provider fallback.

Candidate `6fa638b8bffa71750e1aefa0bb746bb747aa06c1` includes the landed common retirement fix (PR #5084). The accepted inquiry #5029 selected this work for parent #5028. PR #5054 is provisionally stacked on this branch and must wait for this PR to land.

Validation at this candidate:

- All 46 original and additive Linux normal/race correctness commands passed. Full raw-event replay found no skipped or failed test events; the actual correctness-content acceptance is SHA256 `3e5ad02d26db7cb384a35f928decfc13584179b0f7d80b79a9399ec1d5a5ebcf`.
- Five private restored-copy compatibility oracles passed full-value, miss, census and reopen checks. Actual acceptance SHA256: `d2e4a8367b41329d1435dc4f08fcc5fab431c7cb966d8959ffbe47f195479870`.
- Both exact heads have all 51 current check/status results SUCCESS. Independent current-composition source reviews are accepted.
- Original matched calibration is running under durable ordinary commit, default compression/checksum verification, realistic generic keys/values and the unchanged measurement controls. Maintenance speed, natural peak/sustained process memory, service/allocation nonregression, storage and default scheduler progress remain unqualified. Candidate pairs begin only after complete original calibration acceptance.

The complete evidence history and current source/CI checkpoint are tracked in #5030 and [parent #5028](https://github.com/snissn/gomap/issues/5028#issuecomment-6042769825). Historical failed packets retain their original identities. Later successful checks do not establish a cause for earlier failures.

This remains draft. Matched outcome gates, ordered predecessor landing where applicable, necessary final branch synchronization, mature review, current-head required CI and actual landed-source applicability must pass before merge. No storage-format, durability, production batch-size or artificial memory-limit change is selected. Held #5004 / PR #5006 remain excluded.

Closes #5015 only after its completion packet passes.
