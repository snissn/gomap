"""Root source adoption only. No native, campaign, or performance authority."""
from pathlib import Path
import hashlib
import json
import time

BASE = Path('/Users/michaelseiler/dev/snissn/gomap/tmp/quicksilver-maintenance-5028-20261005')
REMOTE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = REMOTE/'qualification-v12-refresh/qualification-v10'
HERE = BASE/'qualification-v12-root-preparation-v1'
REVIEW = BASE/'qualification-v12-exact-stage-independent-review-v1'
FLAGS = ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def ref(path):
    return dict(path=str(REMOTE/path.relative_to(BASE)),sha256=sha(path))

report = REVIEW/'REPORT.md'
manifest = REVIEW/'exact-source-manifest.json'
assert sha(report)=='76cef19a3b4ed8a5e8fce01a7867a24540281a1776c3c1e269c8ec9e6170c89c'
assert sha(manifest)=='3f7c63c8a88c76017a83dae863f250efbeca96d65a67c4bb6ba9c05791a902a4'
review = read(manifest)
assert review['status']=='SOURCE_ONLY_ACCEPT_CURRENT_SELECTION_REJECT_SHADOWED_V2'
assert review['all45_binding_records_exact'] is True
checked=[]
def verify(value):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and 'sha256' in value and 'bytes' in value:
            path=Path(value['path'])
            assert path.is_absolute() and path.resolve(strict=True)==path and path.is_file() and not path.is_symlink()
            assert path.stat().st_size==value['bytes'] and sha(path)==value['sha256'],str(path)
            checked.append(dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size))
        for item in value.values(): verify(item)
    elif isinstance(value,list):
        for item in value: verify(item)
verify(review)

selected={
    'utility': ('qualification-v12-exact-stage-preparation-v1/exact_stage_v12_v1.py','27515da907ab4bf3bdcb5fc56773364189b70159317521c2e22e5e4ce068dd03'),
    'full-R-global54': ('qualification-v12-later-execution-preparation-v3/root-run-full-R-and-global54-v12-v2.py','f2650a2985e8a15b9efdb4f016c5630ef70fb25a33050c44636fb8ceee25132e'),
    'physical34': ('qualification-v12-later-execution-preparation-v3/root-run-physical34-preservation-v12-v2.py','08f3609dfd94177aa80c555f42b90d9bb2033246467d9c4ab2c65ff8fd6efeea'),
    'original-pairs': ('qualification-v12-later-execution-preparation-v3/root-run-original-pairs-v12-v2.py','be7fd6aadd59655a8138d176a3a3227c0ecb8f43107c95d8eccbf0cf9b6039db'),
    'raw-metadata': ('qualification-v12-final-artifact-preparation-v1/root-run-final-raw-and-metadata-v12-v2.py','1c9d04ee4f7a770f360ef401c7c00529279277861c913bee1a516cc0483cc8f0'),
    'content-evaluations': ('qualification-v12-final-artifact-preparation-v1/root-run-final-content-and-evaluations-v12-v3.py','46b7f235b2af8bc0240fc064263cbf7337e2be21187c99c1d84975825fe49e09'),
}
for name,(relative,digest) in selected.items(): assert sha(BASE/relative)==digest,name
adoptions={}
for name,(relative,digest) in selected.items():
    path=HERE/('root-'+name+'-exact-stage-source-acceptance-v12-v1.json')
    value=dict(schema=1,status='ROOT_ACCEPTED_CURRENT_REVIEWED_TRANSPORT_SOURCE_ONLY',source_only=True,
        accepted_by_root=True,owner='/root',accepted_ns=time.time_ns(),campaign_root=str(ROOT),held_excluded=[5004,5006],
        helper=ref(BASE/relative),independent_source_review=ref(report),independent_source_manifest=ref(manifest),
        scope='Exact existing byte reuse and exclusive missing transfer only; original runtime/science/product gates remain mandatory',
        original_frozen_IO_sha256='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1',
        original_engine_harness_analysis_native_helper_bytes_changed=False,
        root_reverified_binding_records=len(checked),blocking_findings=[],**{flag:False for flag in FLAGS})
    if name!='utility': value['exact_stage_utility']=ref(BASE/selected['utility'][0])
    if name=='original-pairs':
        value['prerequisite_helper']=ref(BASE/'qualification-v12-later-execution-preparation-v3/pair-launch-prerequisite-readback-v12-v1.py')
    save(path,value);adoptions[name]=path

drafts={
    'full-R-global54': (HERE/'full-R-global54-actual-inputs-draft-v12-v1.json',HERE/'full-R-global54-actual-inputs-draft-v12-v2.json'),
    'physical34': (HERE/'physical34-actual-inputs-draft-v12-v1.json',HERE/'physical34-actual-inputs-draft-v12-v2.json'),
    'original-pairs': (HERE/'original-pairs-actual-inputs-draft-v12-v1.json',HERE/'original-pairs-actual-inputs-draft-v12-v2.json'),
    'raw-metadata': (BASE/'qualification-v12-final-artifact-preparation-v1/root-raw-and-metadata-request.draft.json',HERE/'raw-and-metadata-inputs-draft-v12-v2.json'),
    'content-evaluations': (BASE/'qualification-v12-final-artifact-preparation-v1/root-content-and-evaluations-request.draft.json',HERE/'content-and-evaluations-inputs-draft-v12-v3.json'),
}
for name,(old,new) in drafts.items():
    draft=read(old)
    assert draft['accepted_by_root'] is False and draft['source_only'] is True
    assert all(draft[k] is False for k in FLAGS)
    draft.update(helper=ref(BASE/selected[name][0]),helper_source_acceptance=ref(adoptions[name]))
    if name=='raw-metadata':
        final=BASE/'qualification-v12-final-artifact-preparation-v1'
        draft.update(independent_source_review=ref(BASE/'qualification-v12-final-artifact-independent-review-v1/REPORT.md'),
            raw_helper_source_acceptance=ref(final/'root-raw-source-acceptance-v12-v1.json'),
            metadata_helper_source_acceptance=ref(final/'root-metadata-source-acceptance-v12-v1.json'))
    if name=='content-evaluations':
        final=BASE/'qualification-v12-final-artifact-preparation-v1'
        draft.update(content_helper_source_acceptance=ref(final/'root-content-source-acceptance-v12-v1.json'),
            evaluation_helper_source_acceptance=ref(final/'root-evaluation-source-acceptance-v12-v1.json'),
            metadata_execution_label='v12-actual-final-exact34-metadata-io-v1')
    save(new,draft)

outcome=dict(schema=1,status='ROOT_ACCEPTED_CURRENT_EXACT_STAGE_TRANSPORT_SOURCE_ONLY',source_only=True,
    accepted_by_root=True,owner='/root',accepted_ns=time.time_ns(),campaign_root=str(ROOT),held_excluded=[5004,5006],
    review=ref(report),manifest=ref(manifest),root_reverified_binding_records=checked,
    selected={name:ref(BASE[p]) for name,(p,digest) in selected.items()},
    source_adoptions={name:ref(path) for name,path in adoptions.items()},
    drafts={name:ref(new) for name,(old,new) in drafts.items()},
    rejected_final_content_v2=ref(BASE/'qualification-v12-final-artifact-preparation-v1/root-run-final-content-and-evaluations-v12-v2.py'),
    all_native_science_and_product_acceptance_remains_pending=True,staging_completed=False,
    **{flag:False for flag in FLAGS})
receipt=HERE/'root-current-exact-stage-source-adoption-v12-v1.json'
save(receipt,outcome)
state=read(BASE/'state.json')
state['checkpoint_version']+=1
state['qualification_v12_current']['current_exact_stage_transport_source_only']=ref(receipt)
pending=HERE/('state-exact-stage-source-adoption-'+str(time.time_ns())+'.json')
save(pending,state);pending.replace(BASE/'state.json')
print(json.dumps(dict(status=outcome['status'],bindings=len(checked),selected=outcome['selected'],receipt=ref(receipt)),allow_nan=False))
