"""Root-owned receipt wrapper for the reviewed sequential continuation."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def state(entry):
    p=BASE/'state.json';s=json.loads(p.read_bytes())
    s.setdefault('root_continuations',{})['reviewed_selected_phase_sequence']=entry
    t=HERE/('state-root-continuation-'+str(time.time_ns())+'.json');save(t,s);t.replace(p)
helper=HERE/'continue-reviewed-v12-qualification-v2.py'
admission=HERE/'root-continuation-actual-admission-v12-v2.json'
assert sys.flags.dont_write_bytecode and __debug__
assert sha(helper)=='02292c22c7777c707d0c34f7933643cc65bb9386a9856dc5c87a14878be65248'
assert sha(admission)=='453a8acfae1e4a695b5ac65c34a3cc48320b270e15066f6c4867aa74b07809c2'
label='reviewed-continuation-controller-actual-v12-v2'
out=HERE/(label+'-stdout.txt');err=HERE/(label+'-stderr.txt')
run=HERE/(label+'-run.json');assert not run.exists()
argv=[sys.executable,'-B',str(helper),str(admission),sha(admission)]
row=dict(owner='/root',argv=argv,script=str(helper),script_sha256=sha(helper),
         admission=dict(path=str(admission),sha256=sha(admission)),wrapper_pid=os.getpid(),
         started_ns=time.time_ns(),rc=None,child_joined=False,
         qualification=False,performance_accepted=False,merge_authorized=False)
entry=dict(owner='/root',local_pid=os.getpid(),status='WAITING_REAL_ORIGINAL_GLOBAL_JOIN',
           source=dict(path=str(helper),sha256=sha(helper)),actual_admission=row['admission'],
           qualification=False,performance_accepted=False,merge_authorized=False)
with out.open('xb') as stdout,err.open('xb') as stderr:
    child=subprocess.Popen(argv,stdout=stdout,stderr=stderr);row['local_pid']=child.pid
    entry['child_pid']=child.pid;state(entry)
    print(json.dumps(dict(status='REVIEWED_CONTINUATION_STARTED_WAITING_GENUINE_JOIN',pid=child.pid,wrapper_pid=os.getpid())),flush=True)
    try:row['rc']=child.wait();row['child_joined']=True
    finally:
        row.update(finished_ns=time.time_ns(),stdout=dict(path=str(out),bytes=out.stat().st_size,sha256=sha(out)),stderr=dict(path=str(err),bytes=err.stat().st_size,sha256=sha(err)))
        save(run,row)
        entry.update(status='JOINED_ROOT_PRODUCT_DECISION_PENDING' if row['rc']==0 else 'FAILED_RETAINED_ROOT_INSPECTION_REQUIRED',actual_run=dict(path=str(run),sha256=sha(run)))
        state(entry)
print(json.dumps(row),flush=True)
sys.exit(row['rc'])
