"""Current-A compatibility oracle on five independently restored private copies.

This is not calibration or candidate qualification. It uses the unchanged
reviewed restore API and retained-fixture unified collector. Originals are only
fingerprinted; all ordinary database opens operate on exclusive private copies.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

REMOTE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = REMOTE/'qualification-v12-refresh/qualification-v10'
HERE = REMOTE/'qualification-v12-root-preparation-v1'
LOCK = REMOTE/'qualification-v12-fresh-controls-v1/v10-source-lock.json'
OUT = ROOT/'compatibility-closed-fixtures-v1'
COMMON = REMOTE/'source-qualification-v10-common-H/scripts'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, v):
    with Path(p).open('x') as f:
        json.dump(v, f, indent=2, allow_nan=False)
        f.write('\n')


assert __debug__ and sys.dont_write_bytecode
assert sha(LOCK) == 'bda4d2486d2e66ee33533d601d216092ce1cd8f5211cfb02aac0d9d2bf823c75'
lock = json.loads(LOCK.read_bytes())
manifest = json.loads((ROOT/'manifest.json').read_bytes())
assert sha(ROOT/'manifest.json') == lock['manifest_sha256']
assert manifest['sources']['A_unified']['head'] == '192e5019e579af3b98ae4fbf4ea497bb9ccd672f'
for role, row in lock['runtime_harness'].items():
    assert sha(COMMON.parent/row['path']) == row['sha256'], role
assert not (COMMON/'__pycache__').exists()
sys.path.insert(0, str(COMMON))
import quicksilver_maintenance as maintenance
import unified_bench_quicksilver_capture as unified

# Read process metadata only before acquiring the one native measurement lane.
for proc in Path('/proc').iterdir():
    if not proc.name.isdecimal():
        continue
    try:
        exe = (proc/'exe').resolve(strict=True)
    except (OSError, RuntimeError):
        continue
    assert not (exe.is_relative_to(REMOTE) and exe.name.startswith(('unified-bench', 'treemap', 'snapshot-restore'))), str(exe)
assert max(os.getloadavg()) < 1, 'host load requires review'
assert not os.path.lexists(OUT)
OUT.mkdir()
env = unified.capture_environment(manifest['build_env'], ROOT/'working-dbs')
(ROOT/'working-dbs').mkdir(exist_ok=True)
observations = []
for fixture in lock['fixtures']:
    started = time.time_ns()
    name = fixture['name']
    print(json.dumps(dict(stage='fixture-start', fixture=name, started_ns=started)), flush=True)
    receipt = fixture['receipt']
    rp = Path(receipt['path'])
    assert sha(rp) == receipt['sha256']
    attestation = json.loads(rp.read_bytes())
    assert attestation == fixture['original_receipt'] and attestation['closed'] is True and attestation['verified'] is True
    original = Path(attestation['directory'])
    before = maintenance.fingerprint(original)
    assert before == attestation['fingerprint'] and before['sha256'] == attestation['fixture_sha256']
    cell = OUT/name
    cell.mkdir()
    database = cell/'db'
    shutil.copytree(original, database)
    assert maintenance.fingerprint(database) == before == maintenance.fingerprint(original)
    for p in database.rglob('*'):
        if p.is_file():
            op = original/p.relative_to(database)
            assert (p.stat().st_dev, p.stat().st_ino) != (op.stat().st_dev, op.stat().st_ino), 'hardlinked copy'
    payload = maintenance.fingerprint(database, payload_only=True)
    restore = dict(fixture=receipt, original_fingerprint=before, source_compatibility_only=True)
    maintenance.restore_snapshot(ROOT, manifest, database, cell, env, restore)
    after = maintenance.fingerprint(database)
    assert (after['files'], after['bytes']) == (before['files'], before['bytes'])
    assert maintenance.fingerprint(database, payload_only=True) == payload
    assert maintenance.fingerprint(original) == before
    save(cell/'restore-readback.json', restore)
    mixture, seed_text, n_text = name.split('-')
    seed, keys = int(seed_text[1:]), int(n_text[1:])
    assert keys == fixture['keys']
    settings = dict(label='current-A-full-oracle', source='A_unified', engine='treedb',
                    case='realistic', profile='durable', keys=keys, seed=seed,
                    mixture=mixture, working_set='uniform', miss_percent=90,
                    reads=2*keys, workers=4, updates=min(40000, keys//4), duration='8s',
                    commit='ordinary', keep=True, profiled=False,
                    rss_sample_interval_ms=200, measure_dir=str(database))
    plan = dict(output='compatibility-closed-fixtures-v1/'+name+'/guard', repeats=1, cells=[settings])
    plan_path = cell/'guard-plan.json'
    save(plan_path, plan)
    command = ['python3', '-B', str(COMMON/'unified_bench_quicksilver_capture.py'), str(ROOT/'manifest.json'), str(plan_path)]
    with (cell/'collector.stdout.txt').open('x') as stdout, (cell/'collector.stderr.txt').open('x') as stderr:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, timeout=7200)
    run_path = cell/'guard/1-current-A-full-oracle/run.json'
    run = json.loads(run_path.read_bytes())
    assert result.returncode == 0 and run['rc'] == 0 and run['validated'] is True and 'error' not in run
    assert run['retained_fixture']['oracle'] == 'pre/post complete expected bytes/misses plus live-key census'
    assert maintenance.fingerprint(original) == before, 'original fixture changed'
    observation = dict(name=name, original=receipt, restored_private_directory=str(database),
        restore=dict(path=str(cell/'restore-readback.json'), sha256=sha(cell/'restore-readback.json')),
        run=dict(path=str(run_path), sha256=sha(run_path)), stdout=dict(path=str(run_path.parent/'stdout.json'), sha256=sha(run_path.parent/'stdout.json')),
        started_ns=started, finished_ns=time.time_ns(), validated=True, original_fingerprint_unchanged=True)
    save(cell/'compatibility-observation.json', observation)
    observations.append(observation)
    print(json.dumps(dict(stage='fixture-complete', fixture=name, finished_ns=observation['finished_ns'], validated=True)), flush=True)
save(OUT/'complete.json', dict(schema=1, campaign_root=str(ROOT), source=manifest['sources']['A_unified'],
    source_lock=dict(path=str(LOCK), sha256=sha(LOCK)), compatibility_only=True,
    qualification=False, performance_accepted=False, calibration_observations_reused=False,
    original_database_opens=0, fixtures=observations, finished_ns=time.time_ns()))
print(json.dumps(dict(status='FIVE_DISPOSABLE_CURRENT_A_FULL_ORACLES_PASSED', fixtures=len(observations), qualification=False)), flush=True)
