import copy
import hashlib
import json
from pathlib import Path
import time
import types

PREP = Path(__file__).resolve().parent
BASE = PREP.parent
P9 = BASE / 'qualification-v9-selected-source-preparation-v1'
OUT = PREP / 'actual-root-approved-source-inputs-v1'
NROOT = '/home/mikers/quicksilver-maintenance-5028-20261006'
FOUNDATION = NROOT + '/qualification-v12-source-inventory'
DST = FOUNDATION + '/inputs'
HELPERS = NROOT + '/qualification-v12-native-source-adapters-v3'
BDIR = BASE / 'qualification-v12-source-pipeline-preparation-v1/actual-source-basis-v1'
ADIR = BASE / 'qualification-v12-source-pipeline-preparation-v1/actual-source-archives-v1'

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def localref(p):
    return dict(path=str(p), sha256=digest(p))

def native_existing(p):
    return dict(path=DST + '/' + p.name, sha256=digest(p))

def save(name, value):
    p = OUT / name
    with p.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
    return native_existing(p)

OUT.mkdir()
original = json.loads((BDIR / 'observed-source-basis.json').read_bytes())
basis = copy.deepcopy(original)
transfer = json.loads((P9 / 'v12-complete-actual-Git-source-and-archive-exclusive-stage-v1-stdout.json').read_bytes())
assert transfer['status'] == 'EXCLUSIVE_TRANSFER_COMPLETE' and len(transfer['received']) == 14
for group in ('tracked_manifests', 'review_bindings'):
    for name, ref in basis[group].items():
        p = Path(ref['path'])
        assert digest(p) == ref['sha256']
        assert transfer['received']['qualification-v12-source-inventory/inputs/' + p.name]['sha256'] == ref['sha256']
        basis[group][name] = native_existing(p)
for p in ADIR.iterdir():
    if p.name != 'archive-index.json':
        assert transfer['received']['qualification-v12-source-inventory/inputs/' + p.name]['sha256'] == digest(p)
basis['origin_git_observation'] = native_existing(BDIR / 'observed-source-basis.json')
basis['origin_request_provenance'] = basis.pop('request')
basis['transport_kind'] = 'Exact root-observed local Git bytes transferred and independently native read back; no native Git execution claim'
basis['transport_receipt'] = save('actual-source-transport-receipt.json', transfer)
basis_ref = save('native-observed-source-basis-v12.json', basis)
review = BASE / 'qualification-v12-actual-integration-review-v1'
assert digest(review / 'REPORT.md') == '977d65f16ec60a7021b4e3d8ac66ae3878f869a56ac92be69bb2a9ff67562976'
assert digest(review / 'exact-input-manifest.json') == '745b8547e62c9e5c5cc95048d25847d7da31bff876afce8663c8f606b5f73b54'
for group in ('common', 'R_owned', 'B_owned'):
    delta = json.loads((BDIR / (group + '-delta.json')).read_bytes())
    assert all(x['root_review_classification'] for x in delta)
selected = json.loads((BDIR / 'selected-harness-bindings.json').read_bytes())
assert len(selected['go_files']) == 94 and len(selected['python_files']) == 3
for role, ref in original['tracked_manifests'].items():
    listing = json.loads(Path(ref['path']).read_bytes())
    assert all(listing['files'][p] == obj for p, obj in selected['go_files'].items())
accept_ref = save('root-source-basis-acceptance-v12.json', dict(
    schema=1, receipt_kind='qualification-v12-root-source-basis-acceptance',
    accepted_by_root=True, accepted_ns=time.time_ns(), source_basis=basis_ref,
    variants=basis['exact_variants'], reviewed_bindings=basis['review_bindings'],
    source_export_authorized=True, build_authorized=True,
    collection_authorized=False, qualification=False, held_excluded=[5004, 5006],
    root_review='Complete current common/selected deltas, normal integrations, 94 identical Go harness bindings, three selected Python blobs, exact transferred Git manifests/archives; no compiled/runtime/performance claims',
    independent_review=localref(review / 'REPORT.md'),
    independent_manifest=localref(review / 'exact-input-manifest.json'),
    held_commit_absence_verified_in_v49=localref(PREP / 'root-actual-common-integration-reassessment-v49.json')))
census = P9 / 'v12-strict-native-census-full-root-readback-v1-stdout.txt'
assert digest(census) == '99ddaedb335ff419a688e514b25c165d44dcd4095af6854a03aaac551aabb363'
scope = json.loads(census.read_bytes())
assert len(scope['expected_files']) == 27378
assert len(scope['expected_directory_aliases']) == 10
assert len(scope['expected_namespace_aliases']) == 3
assert len(scope['expected_dangling_symlinks']) == 1
assert scope['file_bindings_equal_previous_observation'] is True
search = json.loads((PREP / 'actual-native-tool-loader-search-observation-v1.json').read_bytes())
assert len(search['executables']) == 22 and len(search['tool_dynamic_libraries']) == 21
assert all(x['rc'] == 0 for x in search['probes'])
for item in list(search['executables'].values()) + list(search['tool_dynamic_libraries'].values()):
    assert any(b['resolved'] == item['resolved'] and b['sha256'] == item['sha256'] and b['bytes'] == item['bytes'] for b in scope['expected_files'].values()), item
for item in scope['expected_directory_aliases'].values():
    assert any(item['resolved'] == r or item['resolved'].startswith(r + '/') for roots in scope['categories'].values() for r in roots)
for name, item in scope['expected_native_libraries'].items():
    assert any(b['resolved'] == item['resolved'] and b['sha256'] == item['sha256'] and b['bytes'] == item['bytes'] for b in scope['expected_files'].values()), name
scope.update(
    accepted_by_root=True, complete_build_input_scope_reviewed=True,
    accepted_ns=time.time_ns(),
    root_observation=dict(path=NROOT + '/qualification-v12-native-input-observation-v3.json', sha256=digest(census)),
    actual_tool_loader_search_observation=localref(PREP / 'actual-native-tool-loader-search-observation-v1.json'),
    independent_helper_review=localref(BASE / 'qualification-v12-fresh-control-source-review-v1/fix-independent-review-v3/REPORT.md'),
    root_review='Strict complete selected canonical native/tool/include supersets; 22 tools and 21 actual loader dependencies covered; exact 10 directory aliases, 3 selected top-level aliases and one unrelated missing Qt target bound. No unreadable/stat errors suppressed. Actual post-build compiler closure still requires review.')
scope_ref = save('root-native-input-scope-v12.json', scope)
env_ref = save('native-environment-v12.json', scope['environment'])
old = json.loads((P9 / 'qualification-v9-source-composition.json').read_bytes())
meta = dict(
    schema=1, accepted_by_root=True, accepted_ns=time.time_ns(),
    landed_harness_attested=True, held_excluded=[5004, 5006],
    qualification=False, collection_authorized=False,
    baseline_product=basis['exact_variants']['A']['head'],
    historical_baseline_product=old['baseline_product'],
    infrastructure_exception=old['infrastructure_exception'],
    common_prerequisite_landed=True, environment_sha256=env_ref['sha256'],
    variants={}, binaries={})
for role, pin in basis['exact_variants'].items():
    meta['variants'][role] = dict(
        accepted_head=pin['head'], tree=pin['tree'], built_against_head=pin['head'],
        source=NROOT + '/source-qualification-v12-' + role,
        tracked_manifest=basis['tracked_manifests'][role],
        archive=native_existing(ADIR / (role + '-full-source.tar.gz')),
        archive_receipt=native_existing(ADIR / (role + '-archive-receipt.json')))
for slot, role in {'A':'A', 'A_unified':'A', 'R':'R', 'R_unified':'R', 'B':'B', 'B_unified':'B', 'restore':'A', 'benchprof':'A'}.items():
    name = old['binaries'][slot]['name']
    label = 'fixed-restore' if slot == 'restore' else 'benchprof' if slot == 'benchprof' else role + ('-unified' if slot.endswith('_unified') else '-treemap')
    meta['binaries'][slot] = dict(variant=role, name=name,
        origin=FOUNDATION + '/bin/' + name + '-qualification-v12',
        build_receipt=FOUNDATION + '/receipts/' + label + '/run.json')
meta_ref = save('source-composition-v12.json', meta)
frozen = dict(
    schema=1, accepted_by_root=True, accepted_ns=time.time_ns(),
    collection_authorized=False, qualification=False, held_excluded=[5004, 5006],
    variants=basis['exact_variants'], source_paths={k:v['source'] for k,v in meta['variants'].items()},
    source_basis=basis_ref, source_basis_acceptance=accept_ref,
    native_input_scope=scope_ref, environment_sha256=env_ref['sha256'],
    expected_native_libraries=scope['expected_native_libraries'],
    b_normal_merge_parents=basis['normal_merge_parents']['B'],
    normal_merge_parents=basis['normal_merge_parents'],
    note='Actual root-reviewed immutable Git archives/manifests and native bytes frozen before export/build; export, compiler runtime, correctness and performance not yet asserted')
frozen_ref = save('source-freeze-v12.json', frozen)
helper_local = BASE / 'qualification-v12-native-source-adapters-v3'
request = dict(
    schema=1, receipt_kind='qualification-v12-build-request',
    accepted_by_root=True, build_execution_authorized=True,
    qualification=False, collection_authorized=False, held_excluded=[5004, 5006],
    controller_path=HELPERS + '/build-native-v12.py',
    controller_sha256=digest(helper_local / 'build-native-v12.py'),
    native_root=NROOT, foundation=FOUNDATION, composition=meta_ref,
    source_freeze=frozen_ref, source_basis=basis_ref, source_basis_acceptance=accept_ref,
    environment=env_ref,
    go_tool=dict(path=NROOT + '/toolchain/go1.26.3/bin/go', sha256='d68b7abbc40d0844f673f6cf06ae3cded225c50437c6454fa37ef178d079fe65'),
    native_input_scope=scope_ref,
    dependencies={k:dict(path=HELPERS + '/' + f, sha256=digest(helper_local / f)) for k,f in [('pipeline_common','pipeline_common.py'),('request_schema','request.schema.json')]},
    build_complete=FOUNDATION + '/build-complete.json')
request_ref = save('actual-build-request-v12.json', request)
p = P9 / 'root_native_io.py'
io = types.ModuleType('nativeio')
io.__file__ = str(p)
exec(compile(p.read_bytes(), str(p), 'exec'), io.__dict__)
received = io.put({'qualification-v12-source-inventory/inputs/' + p.name:p for p in OUT.iterdir()}, 'v12-root-accepted-source-and-build-inputs-exclusive-stage-v1')
assert len(received['received']) == 8
print(json.dumps(dict(status='SOURCE_AND_NATIVE_INPUTS_ACCEPTED_BUILD_ONLY', build_request=request_ref, source_basis_acceptance=accept_ref, source_freeze=frozen_ref, composition=meta_ref, files=8, collection_authorized=False, qualification=False), indent=2))
