"""Root review of retained actual native correctness content; no DB or capture."""
from pathlib import Path
import hashlib
import json
import time

BASE = Path('/Users/michaelseiler/dev/snissn/gomap/tmp/quicksilver-maintenance-5028-20261005')
HERE = Path(__file__).resolve().parent
IO = BASE / 'qualification-v9-selected-source-preparation-v1'
ADAPTER = BASE / 'qualification-v12-native-source-adapters-v4'
NATIVE = '/home/mikers/quicksilver-maintenance-5028-20261006'
ROOT = NATIVE + '/qualification-v12-source-inventory/correctness'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def main():
    request_path = ADAPTER / 'actual-correctness-request-v12-v4.json'
    request_bytes = request_path.read_bytes()
    request_sha = sha(request_bytes)
    request = json.loads(request_bytes)
    packet_path = IO / 'v12-actual-native-46-correctness-complete-content-readback-v1-stdout.txt'
    packet = read(packet_path)
    execution = read(IO / 'v12-actual-native-original30-plus16-correctness-v1-run.json')
    readback = read(IO / 'v12-actual-native-46-correctness-complete-content-readback-v1-run.json')
    for record in (execution, readback):
        assert record['rc'] == 0 and not record.get('error')
        assert 0 < record['started_ns'] < record['finished_ns']
        for channel in ('stdout', 'stderr'):
            ref = record[channel]
            raw = Path(ref['path']).read_bytes()
            assert len(raw) == ref['bytes'] and sha(raw) == ref['sha256']
        assert not Path(record['stderr']['path']).read_bytes()
    assert execution['finished_ns'] < readback['started_ns']
    files = packet['actual_files']
    assert len(files) == 187 and packet['dbs_opened'] is False
    for path, value in files.items():
        assert path.startswith(ROOT + '/') and '/..' not in path
        raw = value['content'].encode('utf-8')
        assert len(raw) == value['bytes'] and sha(raw) == value['sha256']

    def content(path):
        return json.loads(files[path]['content'])

    observed_path = ROOT + '/correctness-complete.json'
    observed = content(observed_path)
    assert observed == packet['actual_complete']
    assert observed['status'] == 'CORRECTNESS_COMPLETE_STOP_ROOT_CONTENT_REVIEW_REQUIRED'
    assert observed['rc'] == 0 and observed['accepted_by_root'] is False
    assert all(observed[k] is False for k in ('qualification', 'performance_accepted', 'collection_authorized'))
    assert observed['commands'] == 46 and observed['additive_check_count'] == 16
    assert observed['original30_rows_preserved'] is True
    assert content(ROOT + '/input.json') == request
    assert files[ROOT + '/input.json']['sha256'] == request_sha == observed['input_sha256']
    bindings = content(ROOT + '/bindings.json')
    checks_path = ADAPTER / Path(request['checks']['path']).name
    checks = read(checks_path)
    original = read(ADAPTER / 'checks.json')
    assert sha(checks_path.read_bytes()) == request['checks']['sha256']
    assert checks['checks'][:30] == original['checks'] and len(original['checks']) == 30
    assert checks['check_count'] == len(checks['checks']) == 46
    basis = read(HERE / 'actual-root-approved-source-inputs-v1/native-observed-source-basis-v12.json')
    inventory = read(HERE / 'root-actual-inventory-content-acceptance-v12-v1.json')
    assert inventory['accepted_by_root'] is True
    assert observed['variants'] == bindings['source_pins'] == basis['exact_variants'] == inventory['variants']
    assert observed['composition_sha256'] == request['composition']['sha256']
    assert observed['manifest_sha256'] == request['manifest']['sha256'] == inventory['manifest_sha256']
    assert observed['checks_sha256'] == request['checks']['sha256']
    assert observed['root_content_acceptance_sha256'] == request['actual_content_acceptance']['sha256']
    for key in ('composition', 'manifest', 'inventory_complete', 'actual_content_acceptance', 'environment', 'go_tool'):
        assert bindings[key] == request[key]
    environment = read(HERE / 'actual-root-approved-source-inputs-v1/native-environment-v12.json')
    reports = []
    expected_files = {ROOT + '/input.json', ROOT + '/bindings.json', observed_path}
    previous_end = execution['started_ns']
    for expected, completed in zip(checks['checks'], observed['checks'], strict=True):
        label = expected['label']
        directory = ROOT + '/receipts/' + label
        assert completed['label'] == label and completed['path'] == directory + '/run.json'
        assert completed['sha256'] == files[completed['path']]['sha256']
        assert completed['matches'] == directory + '/matches.json'
        assert completed['matches_sha256'] == files[completed['matches']]['sha256']
        run = content(completed['path'])
        matches = content(completed['matches'])
        assert run['command'] == expected['argv']
        role = expected.get('variant', 'B')
        assert run['cwd'] == NATIVE + '/source-qualification-v12-' + role
        assert run['env'] == environment and run['input_sha256'] == request_sha
        assert run['checks_sha256'] == request['checks']['sha256']
        assert run['helper_sha256'] == request['controller_sha256']
        assert run['rc'] == 0 and not run.get('timeout') and not run.get('error') and not run.get('cleanup_error')
        assert run['correctness_only'] is True and run['qualification'] is False
        cleanup = run['process_group_cleanup']
        assert cleanup['direct_child_joined'] is True and cleanup['quiescent'] is True
        assert not cleanup['signal_errors'] and run['raw_hashes_final'] is True
        assert previous_end <= run['started_ns'] < run['finished_ns'] <= observed['finished_ns']
        previous_end = run['finished_ns']
        for channel in ('stdout', 'stderr'):
            name = directory + '/' + channel + '.txt'
            assert run[channel + '_sha256'] == files[name]['sha256']
        assert files[directory + '/stderr.txt']['bytes'] == 0
        events = [json.loads(line) for line in files[directory + '/stdout.txt']['content'].splitlines()]
        assert events and not any(e.get('Action') in ('fail', 'skip') for e in events)
        packages = {'github.com/snissn/gomap/' + a[2:] for a in expected['argv'] if a.startswith('./')}
        assert packages == set(expected['required_matches']) == set(matches)
        required_count = 0
        actual_top_level = 0
        for package in packages:
            passed = {e['Test'] for e in events if e.get('Package') == package and e.get('Action') == 'pass' and e.get('Test')}
            top = sorted(t for t in passed if '/' not in t)
            assert top and matches[package] == top
            required = expected['required_matches'][package]
            assert set(required).issubset(passed)
            assert any(e.get('Package') == package and e.get('Action') == 'pass' and not e.get('Test') for e in events)
            if expected['exact_match_set']:
                assert top == required
            required_count += len(required)
            actual_top_level += len(top)
        assert completed['skips'] == []
        expected_files.update(directory + '/' + name for name in ('run.json', 'matches.json', 'stdout.txt', 'stderr.txt'))
        reports.append(dict(label=label, source_role=role, argv=run['command'], required_pass_events=required_count,
                            actual_top_level_passes=actual_top_level, all_subtests_pass=True, skipped_tests=0,
                            race_enabled='-race' in run['command'], process_group_quiescent=True))
    assert set(files) == expected_files
    assert observed['finished_ns'] <= execution['finished_ns']
    native_files = {p: value['sha256'] for p, value in files.items()}
    native_files[request['controller_path']] = request['controller_sha256']
    native_files[NATIVE + '/' + request_path.relative_to(BASE).as_posix()] = request_sha
    for key in ('source_basis', 'source_basis_acceptance', 'composition', 'source_freeze', 'environment', 'manifest',
                'inventory_complete', 'actual_content_acceptance', 'build_complete', 'checks', 'inspected_test_catalog', 'go_tool'):
        ref = request[key]
        native_files[ref['path']] = ref['sha256']
    for ref in request['dependencies'].values():
        native_files[ref['path']] = ref['sha256']
    accepted = dict(schema=1, status='ROOT_ACCEPTED_ACTUAL_NATIVE_46_CORRECTNESS_CONTENTS', accepted_by_root=True,
                    native_correctness_accepted=True, accepted_ns=time.time_ns(), owner='/root',
                    variants=observed['variants'], held_excluded=[5004, 5006], original30_rows_preserved=True,
                    commands=46, additive_check_count=16, checks_sha256=observed['checks_sha256'],
                    manifest_sha256=observed['manifest_sha256'], composition_sha256=observed['composition_sha256'],
                    inventory_actual_content_acceptance_sha256=request['actual_content_acceptance']['sha256'],
                    correctness_observation=dict(path=observed_path, sha256=files[observed_path]['sha256']),
                    files=native_files, actual_command_contents=reports, original_raw_streams_complete=True,
                    all_required_tests_and_subtests_passed=True, no_test_skips=True, all_process_groups_joined_quiescent=True,
                    post_check_source_binary_native_input_drift_checks_passed=True,
                    actual_readback=dict(path=str(packet_path), sha256=sha(packet_path.read_bytes())),
                    actual_join=dict(path=str(IO / 'v12-actual-native-original30-plus16-correctness-v1-run.json'),
                                     sha256=sha((IO / 'v12-actual-native-original30-plus16-correctness-v1-run.json').read_bytes())),
                    performance_accepted=False, qualification=False, collection_authorized=False,
                    candidate_pairs_authorized=False, merge_authorized=False)
    output = HERE / 'root-actual-correctness-content-acceptance-v12-v1.json'
    with output.open('x') as stream:
        json.dump(accepted, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(path=str(output), sha256=sha(output.read_bytes()), actual_commands=len(reports),
                          native_file_bindings=len(native_files), skipped_tests=0,
                          actual_top_level_passes=sum(r['actual_top_level_passes'] for r in reports))))


if __name__ == '__main__':
    assert __debug__
    main()
