"""Join the finite, diagnostic-only profile analysis under root ownership."""
import hashlib
import json
import os
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
STATE = BASE / 'state.json'
IO = BASE / 'qualification-v9-selected-source-preparation-v1/root_native_io.py'
raw = IO.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io = dict(__file__=str(IO), __name__='root_io')
exec(compile(raw, str(IO), 'exec'), io)


def update(change):
    old = STATE.read_bytes()
    state = json.loads(old)
    change(state)
    pending = HERE / ('state-' + str(time.time_ns()) + '.pending')
    with pending.open('x') as stream:
        json.dump(state, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    assert STATE.read_bytes() == old
    os.replace(pending, STATE)


owner = dict(owner='/root', local_pid=os.getpid(), kind='finite-pprof-diagnostic-analysis',
             started_ns=time.time_ns(), source_head='01ad34afed6d64f58d8504a57a247170289e4772',
             qualification=False)


def start(state):
    assert state['native_active'] is None
    state['native_active'] = owner
    state['qualification_v13_current']['native_active'] = owner


update(start)
native_script = 'qualification-v13-freelist-R-native-control-v1/pprof-analysis-v1.py'
io['put']({native_script: HERE / 'pprof-analysis-v1.py'},
          'v13-freelist-R-profile-pprof-source-transfer-v1')
result = json.loads(io['native'](
    ['python3', '-B', '/home/mikers/quicksilver-maintenance-5028-20261006/' + native_script],
    'v13-freelist-R-profile-actual-pprof-analysis-v1', timeout=300))
assert result['status'] == 'FROZEN_PROFILE_ANALYSIS_JOINED_DIAGNOSTIC_ONLY'
assert len(result['receipts']) == 14 and all(x['rc'] == 0 for x in result['receipts'])
assert result['qualification'] is False and result['performance_accepted'] is False
path = HERE / 'actual-pprof-analysis-v1.json'
with path.open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write('\n')


def joined(state):
    assert state['native_active'] == owner
    state['native_active'] = None
    current = state['qualification_v13_current']
    current['native_active'] = None
    current['refined_freelist_profile_analysis'] = dict(
        path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        status=result['status'])
    state['state_updated_ns'] = time.time_ns()


update(joined)
print(json.dumps(dict(status=result['status'], joined_calls=len(result['receipts']),
                      path=str(path), qualification=False)))
