from pathlib import Path
import hashlib, json, os, re, subprocess, tempfile

repo=Path('/private/tmp/gomap-qs-5015')
script=(repo/'scripts/mvcc_raw_path_gate.sh').read_text()
tail=script[script.index('if python3 .github/scripts/check_mvcc_raw_path_gate.py'):]
cases=[
 ('pass_skips',0,False,False,0,0,False,'snapshot',False),
 ('equivalent_skips',1,False,True,0,0,False,'snapshot',False),
 ('timing_pass_skips',2,True,False,0,0,False,'snapshot',False),
 ('other_row_skips',1,False,False,0,0,False,'other',False),
 ('failure_retains_and_pairs',1,False,False,0,0,False,'snapshot',True),
 ('diagnostic_timeouts_preserve_fail',1,False,False,124,124,False,'snapshot',True),
 ('hash_mismatch_stops_before_tools',1,False,False,0,0,True,'snapshot',False),
]
prefix=r"""set -euo pipefail
python3() { if [[ "$1" == .github/scripts/check_mvcc_raw_path_gate.py ]]; then return "$MOCK_GATE_STATUS"; else command python3 "$@"; fi; }
timeout() {
  [[ $(wc -l < "$OUT_DIR/snapshot-seek-diagnostics/binary-verification.txt") -eq 2 ]] || return 99
  printf '%s\n' "$*" >> "$OUT_DIR/asm-calls"
  if ((MOCK_ASM_STATUS == 0)); then printf 'TEXT mock\n'; fi
  return "$MOCK_ASM_STATUS"
}
taskset() {
  [[ $(wc -l < "$OUT_DIR/snapshot-seek-diagnostics/binary-verification.txt") -eq 2 ]] || return 99
  printf '%s\n' "$*" >> "$OUT_DIR/public-calls"
  printf 'mock public diagnostic\n'
  return "$MOCK_PUBLIC_STATUS"
}
ps() { printf 'mock ps\n'; }
TMP_ROOT="$OUT_DIR"
SUMMARY_JSON="$OUT_DIR/summary.json"
SUMMARY_MD="$OUT_DIR/summary.md"
BASELINE_LOG="$OUT_DIR/baseline.txt"
CANDIDATE_LOG="$OUT_DIR/candidate.txt"
BASELINE_SHA=base
CANDIDATE_SHA=head
for revision in BASELINE CANDIDATE; do
  for package in DB CACHING TREEDB; do printf -v "${revision}_${package}_BIN" dummy; done
done
RUNS=8
BENCHTIME=2s
MAX_REGRESSION_PERCENT=5
MAX_BYTES_REGRESSION_PERCENT=1
MAX_BYTES_REGRESSION_ABSOLUTE=64
SCRIPT_GOWORK=off
CPUSET=0
CACHING_BENCH_REGEX='^BenchmarkRepeatedIterator$'
"""
for name,status,timing,equivalent,public_status,asm_status,mismatch,row_kind,expected in cases:
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp)
  bins={revision:revision.encode() for revision in ('baseline','candidate')}
  hashes={revision:hashlib.sha256(data).hexdigest() for revision,data in bins.items()}
  if mismatch: hashes['candidate']='0'*64
  for revision,data in bins.items(): (root/(revision+'-treedb.test')).write_bytes(data)
  row='BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek' if row_kind=='snapshot' else 'BenchmarkGetVersioned'
  (root/'summary.json').write_text(json.dumps({'binary_digests':{'treedb':hashes},'results':[{'benchmark':row,'timing_pass':timing,'binary_equivalent':equivalent}]}))
  (root/'baseline.txt').write_text('original baseline\n'); (root/'candidate.txt').write_text('original candidate\n')
  before={f:(root/f).read_bytes() for f in ('baseline.txt','candidate.txt','summary.json')}
  result=subprocess.run(['bash','-c',prefix+tail],env={**os.environ,'OUT_DIR':tmp,'MOCK_GATE_STATUS':str(status),'MOCK_PUBLIC_STATUS':str(public_status),'MOCK_ASM_STATUS':str(asm_status),'PYTHONDONTWRITEBYTECODE':'1'},text=True,capture_output=True)
  assert result.returncode==status,(name,result.returncode,result.stderr)
  assert all((root/f).read_bytes()==value for f,value in before.items()),name
  diag=root/'snapshot-seek-diagnostics'
  if expected:
   assert len((root/'asm-calls').read_text().splitlines())==2,name
   rows=(root/'public-calls').read_text().splitlines()
   assert len(rows)==16,name
   expect_order=[rev for sample in range(1,9) for rev in (('baseline','candidate') if sample%2 else ('candidate','baseline'))]
   assert [re.search(r'/(baseline|candidate)-treedb.test',r).group(1) for r in rows]==expect_order,name
   assert all('-c 0 timeout --kill-after=5s 30s env GOMAXPROCS=1' in r and '-test.benchtime=2s -test.count=1' in r and 'public_seek_baseline$' in r for r in rows),name
   for revision,data in bins.items():
    assert (diag/(revision+'-treedb.test')).read_bytes()==data,name
    status_text=(diag/(revision+'-objdump-status.txt')).read_text()
    assert 'exit='+str(asm_status) in status_text,name
    assert 'empty_output='+('false' if asm_status==0 else 'true') in status_text,name
    for sample in range(1,9):
     assert (diag/(revision+'-'+str(sample)+'-public-seek-status.txt')).read_text()=='exit='+str(public_status)+'\n',name
  else:
   assert not (root/'asm-calls').exists() and not (root/'public-calls').exists(),name
   if mismatch:
    assert 'retained binary mismatch: candidate' in (diag/'binary-verification.txt').read_text(),name
    assert 'original gate status preserved' in result.stderr,name
   else:
    assert not diag.exists(),name
  print('PASS',name,'gate_exit='+str(result.returncode),'public_calls='+str(16 if expected else 0))
print('7 mocked control-flow cases PASS; no Go/native binary was executed')
