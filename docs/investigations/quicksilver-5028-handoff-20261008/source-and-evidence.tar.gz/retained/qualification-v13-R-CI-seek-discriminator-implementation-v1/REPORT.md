# R snapshot Seek CI discriminator implementation

Implemented the selected script-only post-failure diagnostic in `/private/tmp/gomap-qs-5015/scripts/mvcc_raw_path_gate.sh`, sole owned production path. Root retains staging, coherent integration, CI/native execution and merge ownership. No other worker path was opened or modified; no global status, stage, commit, push, Go/native/SSH/GitHub execution or CI rerun occurred.

## Exact source and diff

Starting/current commit `01ad34afed6d64f58d8504a57a247170289e4772`; root-approved base `2d6b07f58902537cfe8d2b3e3a8c3c9ba0f3c07c`. Existing HEAD root AGENTS was read; no scripts/AGENTS.md exists. Root-AGENTS SHA-256 `320c5ed8a179e15886cd58832f76d7906f5d76c189500e756f0adb957d6ecf99`. Previously read/bound executor guidance remains effective within the explicit single-file scope.

Original script Git blob `e31fef98dffb00c237582d0f6668f328cbe2d0e9`, SHA-256 `f40abf9f22b42b7d99a0950b93521cfe361c785da4c116ef107aaee2debe1885`. Result Git blob (computed without writing objects) `945fe26591188aaa316d304d2906c6c8e44934a6`, SHA-256 **`206921a1034985b812154b2b2b1070feecdf77ad35cf904298e5bd48e729b571`**. [script.diff](script.diff) contains the exact unstaged one-file diff. The added block starts at line 238. A byte comparison proves the entire original script prefix through its existing diagnostics and final echo/exit remain unchanged; the new block is inserted between them.

On exact `BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek` timing failure with unequal owning binaries and nonzero gate status, the block copies the already-measured two TreeDB executables. It records copied hashes and verifies both against original summary digests **before any disassembly or execution**. Failure to bind exits only the diagnostic subshell. It then retains targeted hot disassembly with exit/empty-output receipts, and executes existing `public_seek_baseline` in separate configured eight AB/BA pairs at 2s/CPU0/GOMAXPROCS1, recording individual stdout/stderr/status and pre-sample process observations. Diagnostic timeouts/failures are recorded without replacing the original gate status. Samples remain in a separate subdirectory and never feed the checker.

Original five groups, original sample/log paths, checker invocation, threshold/statistic, `gate_status`, final exit and environment defaults are unchanged. No Go fixture, production API, workflow, checker, new framework, waiver or optional fixture instrumentation was added. The actual native symbol coverage/base-R diagnostic run remains for root/CI; this worker did not execute Go or benchmark binaries.

## Actual validation

| Check | Result |
|---|---|
| `bash -n scripts/mvcc_raw_path_gate.sh` | PASS, exit 0 |
| Existing raw-path checker `--self-test` | PASS, exit 0 |
| Existing benchmark pairing suite | PASS, 8 tests, exit 0 |
| Existing raw-path equivalence suite | PASS, 10 tests, exit 0 |
| Existing TreeDB CI contract suite | PASS, 6 tests, exit 0 |
| Scoped `git diff --check -- scripts/mvcc_raw_path_gate.sh` | PASS, exit 0 |
| Artifact-only mocked branch harness | PASS, 7 control-flow cases, exit 0 |
| Original/rerun packet integrity | PASS, 16 file bindings unchanged |

The mocked harness exercises gate-pass skip, equivalent-binary skip, timing-pass skip, wrong-row skip, changed-binary timing failure with 16 AB/BA diagnostic calls, diagnostic timeouts preserving FAIL, and candidate digest mismatch preventing **both** disassembly and execution. It checks original logs/summary remain byte-identical, CPU0/GOMAX1/2s arguments, retained executable bytes, copy verification before tools, per-call statuses and empty-output state. All Go/tool/benchmark calls are mocked; no native benchmark ran. The artifact-only harness source and raw outputs are retained for review; no repository test file was added.

Both prior R FAIL packets remain unchanged (+5.02185583% and +5.42800069% paired timing observations). This work does not resolve causal attribution or confer performance acceptance. Implemented=true; native_execution=false, CI_rerun=false, performance_acceptance=false, product_acceptance=false, qualification=false, linux_qualification=false, merge_authority=false, merge_ready=false, threshold_waiver=false.

## Artifact SHA-256 receipts

- `checker-self-test.log`: `2ba8a1ad86d64d79b959050d72b642b4ac453096858ee9d05f7afd78315524aa`
- `ci-contract.log`: `d5b37d688b80b57fff3614355e0f1317459204c3de96aaa00f70834e4e1346da`
- `diff-check.log`: `11394dd77fb3ac4f4516f2186abfeda54eea601ce0bcd0c09a51cb6b40a3f9d6`
- `equivalence.log`: `2653afe7db808e19d34e16d5c6a9f795a59d92e91bb21c762de09d190defa207`
- `failed-packet-integrity.log`: `b7cf195792b75c5e29598b32512926521e81807d1a967b74df281192a1578a3f`
- `mock-control-flow.log`: `259e3362e3f9589e5ceeb28deaeeeae392a2c75f54da136bd505ec0c1119fe4f`
- `mock_control_flow_check.py`: `6d40b3cefb0a36a36a4116c63298860c8611acae42b863490000a49529680667`
- `pairing.log`: `8c772f1b31b4ffc3598578acf5b97ad4de398aad98227087d564996f7a3a0888`
- `script.diff`: `dd63b248098a074adef5bd0bf68e1487ca84628867974b1bc8433b873ab1de66`
- `syntax.log`: `82bbfef90076aaf81dc693bccb8af63eecc716a012b4db7a5f71b2e02b1594c7`

Ownership returned to root for one coherent integration with the memtable candidate.
