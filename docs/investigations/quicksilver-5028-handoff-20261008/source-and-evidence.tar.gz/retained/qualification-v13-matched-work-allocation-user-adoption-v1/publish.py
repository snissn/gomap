from pathlib import Path
import subprocess,json,time,hashlib
HERE=Path(__file__).resolve().parent
block=(HERE/'live-revision.md').read_text()
def api(path,label,method='GET',payload=None):
 argv=['gh','api','repos/snissn/gomap/'+path]
 if payload is not None:
  f=HERE/(label+'-request.json');f.write_text(json.dumps(payload)+'\n');argv+=['--method',method,'--input',str(f)]
 r=subprocess.run(argv,capture_output=True,timeout=25);(HERE/(label+'.json')).write_bytes(r.stdout);(HERE/(label+'.stderr')).write_bytes(r.stderr);assert r.returncode==0
 return json.loads(r.stdout)
receipts=[]
for n in [5028,5015,5016,5030]:
 label='issue-'+str(n);path='issues/'+str(n);before=api(path,label+'-before');assert before['state']=='open' and '<!-- codex-issue-graph-executor:matched-work-adoption-v1 -->' not in before['body']
 body=before['body']+'\n\n'+block;api(path,label+'-patch','PATCH',{'body':body});after=api(path,label+'-readback');assert after['body']==body and after['state']=='open';receipts.append({'url':after['html_url'],'actual_live_body_verified':True,'readback':{'path':str(HERE/(label+'-readback.json')),'sha256':hashlib.sha256((HERE/(label+'-readback.json')).read_bytes()).hexdigest()}})
c=api('issues/5028/comments','parent-adoption-comment','POST',{'body':block});receipts.append({'url':c['html_url'],'comment_id':c['id']})
(HERE/'root-live-revision-receipt.json').write_text(json.dumps({'status':'USER_AUTHORIZED_ALLOCATION_REVISION_APPLIED_AND_ACTUAL_LIVE_VERIFIED','created_ns':time.time_ns(),'outputs':receipts,'qualification':False,'performance_accepted':False,'held_excluded':[5004,5006]},indent=2)+'\n')
print(json.dumps({'revised_issues':4,'comment_url':c['html_url'],'qualification':False}),flush=True)
