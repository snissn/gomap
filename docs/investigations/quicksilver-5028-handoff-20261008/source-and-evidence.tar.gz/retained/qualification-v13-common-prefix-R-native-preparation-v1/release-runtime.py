from pathlib import Path
import json,hashlib,time,base64,os
H=Path(__file__).resolve().parent;B=H.parent
p=B/'qualification-v9-selected-source-preparation-v1/root_native_io.py';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io={'__file__':str(p),'__name__':'rootio'};exec(compile(raw,str(p),'exec'),io);io['HERE']=H
N='/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v13-common-prefix-R-native-build-v1'
code="""import pathlib,json,hashlib,os,time,base64
p=pathlib.Path(ROOT_LITERAL);files={};receipts={}
for f in sorted(p.glob('*-run.json')):
 r=json.loads(f.read_bytes());assert r['rc']==0 and r['raw_hashes_final'] and r['process_group_cleanup']['quiescent']
 receipts[f.name]=r
 for field in ['stdout_path','stderr_path']:
  x=pathlib.Path(r[field]);data=x.read_bytes();assert hashlib.sha256(data).hexdigest()==r[field.replace('_path','_sha256')]
  files[x.name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 data=f.read_bytes();files[f.name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
active=[]
for d in pathlib.Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:
  cmd=(d/'cmdline').read_bytes().replace(b'\\0',b' ').decode(errors='replace');exe=os.path.basename(os.readlink(d/'exe'))
  if exe in ['go','compile','link','treemap','unified-bench'] or exe.endswith('.test'):active.append({'pid':int(d.name),'exe':exe,'argv':cmd})
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not active,active
print(json.dumps({'status':'NATIVE_WINDOW_ACTUAL_COMMANDS_JOINED_AND_RELEASED','receipts':receipts,'files':files,'fresh_active_go_test_build_bench':active,'released_at_ns':time.time_ns(),'qualification':False}),flush=True)
""".replace('ROOT_LITERAL',repr(N))
out=json.loads(io['native'](['python3','-B','-c',code],'actual-native-release-v1',60));(H/'root-runtime-release.json').write_text(json.dumps(out,indent=2)+'\n')
S=B/'state.json';old=S.read_bytes();st=json.loads(old);assert st['native_active']['owner']=='root' and st['native_active']['head']=='4ba7bfad3c29d176fe7686f14cfe49276a9b3d3a'
st['native_active']=None;st['native_heavy_slot']=None;st['qualification_v13_current']['native_active']=None
st['qualification_v13_current']['common_prefix_R_native_runtime_release']={'path':str(H/'root-runtime-release.json'),'sha256':hashlib.sha256((H/'root-runtime-release.json').read_bytes()).hexdigest()}
pending=H/'state-release.pending';pending.write_text(json.dumps(st,indent=2)+'\n');assert S.read_bytes()==old;os.replace(pending,S)
print(json.dumps({'status':out['status'],'native_commands':len(out['receipts']),'release_sha256':hashlib.sha256((H/'root-runtime-release.json').read_bytes()).hexdigest()}),flush=True)
