import json,hashlib,os,time
from pathlib import Path
H=Path(__file__).resolve().parent;BASE=H.parent;S=BASE/'state.json'
p=BASE/'qualification-v9-selected-source-preparation-v1/root_native_io.py';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io={'__file__':str(p),'__name__':'root_io'};exec(compile(raw,str(p),'exec'),io);io['HERE']=H
r=json.loads((H/'request.json').read_bytes());N='/home/mikers/quicksilver-maintenance-5028-20261006';C=N+'/qualification-v13-common-prefix-R-native-control-v1';rs=hashlib.sha256((H/'request.json').read_bytes()).hexdigest()
old=S.read_bytes();st=json.loads(old);assert st['native_active'] is None
active={'owner':'root','owner_launcher_pid':os.getpid(),'phase':'common-prefix-R-build-focused-DB-tests-only','head':r['candidate_head'],'started_ns':time.time_ns(),'qualification':False,'external_grant':'adjacent R1 explicit <=8min window at15:50UTC; actual release required'}
st['native_active']=active;st['native_heavy_slot']=active;st['qualification_v13_current']['native_active']=active
st['nodes']['5015']['head']=r['candidate_head'];st['qualification_v13_current']['current_heads']['R']=r['candidate_head']
tmp=H/'state.pending';tmp.write_text(json.dumps(st,indent=2)+'\n');assert S.read_bytes()==old;os.replace(tmp,S)
plan={name:Path(path) for name,path in json.loads((H/'source-transfer-map.json').read_bytes()).items()}
for name in ['build-common-prefix-R.py','request.json','R-tracked-manifest.json']:plan[C.split(N+'/')[1]+'/'+name]=H/name
print('ROOT_BUILD_AND_DB_TEST_WINDOW_LAUNCH',flush=True)
io['put'](plan,'actual-exclusive-transfer-v1')
argv=['python3','-B',C+'/build-common-prefix-R.py',C+'/request.json',rs]
try:
 result=json.loads(io['native'](argv,'actual-build-and-focused-native-tests-v1',430))
 assert result['head']==r['candidate_head'] and result['status']=='EXACT_COMMON_PREFIX_R_BUILD_AND_AFFECTED_NATIVE_TESTS_JOINED'
 (H/'actual-build-root-outcome.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result),flush=True)
except BaseException as error:
 (H/'actual-build-root-failure.json').write_text(json.dumps({'error':repr(error),'native_active_requires_actual_join_and_release':True,'qualification':False},indent=2)+'\n');raise
