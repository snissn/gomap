import pathlib,json,hashlib,base64
H=pathlib.Path(__file__).resolve().parent;B=H.parent;p=B/'qualification-v9-selected-source-preparation-v1/root_native_io.py';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
io={'__file__':str(p),'__name__':'rootio'};exec(compile(raw,str(p),'exec'),io);io['HERE']=H
N='/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v13-common-prefix-R-native-build-v1'
code="""import pathlib,json,hashlib,base64
p=pathlib.Path(ROOT_LITERAL);names={'source-receipt.json','compiler-inputs.json','build-complete.json'}
for f in p.glob('*-run.json'):
 names.add(f.name);r=json.loads(f.read_bytes());assert r['rc']==0 and r['raw_hashes_final'] and r['process_group_cleanup']['quiescent'] and r['process_group_cleanup']['direct_child_joined']
 for k in ['stdout_path','stderr_path']:
  q=pathlib.Path(r[k]);assert q.parent==p;names.add(q.name)
out={}
for n in sorted(names):
 data=(p/n).read_bytes();out[n]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'base64':base64.b64encode(data).decode()}
print(json.dumps({'files':out,'qualification':False}),flush=True)
""".replace('ROOT_LITERAL',repr(N))
data=json.loads(io['native'](['python3','-B','-c',code],'actual-compiler-and-tests-readback-v1',120));outdir=H/'native-actual';outdir.mkdir()
for name,item in data['files'].items():
 assert pathlib.Path(name).name==name;raw=base64.b64decode(item['base64'],validate=True);assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'];(outdir/name).write_bytes(raw)
print(json.dumps({'fetched_files':len(data['files']),'actual_bytes':sum(x['bytes'] for x in data['files'].values()),'transport_sha256':hashlib.sha256((H/'actual-compiler-and-tests-readback-v1-stdout.txt').read_bytes()).hexdigest()}),flush=True)
