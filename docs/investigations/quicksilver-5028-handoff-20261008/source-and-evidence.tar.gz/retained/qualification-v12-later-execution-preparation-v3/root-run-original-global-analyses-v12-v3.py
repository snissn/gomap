"""Root-only original B/R calibration analyses after the actual serial join.

No capture, benchmark, database access or candidate collection. The immutable
original analysis CLIs and reviewed transition helper own all scientific checks.
This launcher retains actual commands and accepts only their explicit outcomes.
"""
from pathlib import Path
import hashlib
import json
import os
import time
import types

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
REMOTE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT = REMOTE/'qualification-v12-refresh/qualification-v10'
PROS = REMOTE/'qualification-v12-refresh/qualification-v10-prospective-root-v1'
RECEIPTS = BASE/'qualification-v9-selected-source-preparation-v1'
HELPER_REL = 'qualification-v12-later-execution-preparation-v3/root-global-calibration-transition-v12-v3.py'
HELPER_SHA = '1f5fe209749617ebe65f1bccf4fd579c557a145047cbc8c1093ce1fbdd793b97'
HELPER = REMOTE/HELPER_REL
TRANSITIONS = HELPER.parent/'qualification-v12-global-analysis-transitions-v1'
RDEF = ROOT/'prospective-v10-root-v1/r-definition.accepted.json'
STATE = BASE/'state.json'


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def remote_ref(path):
    return dict(path=str(REMOTE/path.relative_to(BASE)), sha256=sha(path))


def update_runtime(**fields):
    state = read(STATE)
    state.update(fields)
    pending = HERE/('state-global-analysis-runtime-'+str(time.time_ns())+'.json')
    save(pending, state)
    pending.replace(STATE)


def actual_execution(label):
    row = read(RECEIPTS/(label+'-run.json'))
    assert row['rc'] == 0 and not row.get('error'), label
    assert type(row['started_ns']) is type(row['finished_ns']) is int
    assert row['started_ns'] < row['finished_ns']
    for stream in ('stdout', 'stderr'):
        path = RECEIPTS/(label+'-'+stream+'.txt')
        assert row[stream]['path'] == str(path)
        assert row[stream]['sha256'] == sha(path)
        assert row[stream]['bytes'] == path.stat().st_size
    assert not (RECEIPTS/(label+'-stderr.txt')).read_bytes(), label
    return row


def request(stage, predecessor, phase_refs, **extra):
    value = dict(schema=1, status='ROOT_AUTHORIZED_ORIGINAL_'+stage+'_CONTENT_REPLAY',
        accepted_by_root=True, owner='/root', authorized_ns=time.time_ns(),
        artifact_transition_authorized=True, stage=stage, campaign_root=str(ROOT),
        held_excluded=[5004, 5006], qualification=False, performance_accepted=False,
        collection_authorized=False, candidate_pairs_authorized=False, merge_authorized=False,
        helper=dict(path=str(HELPER), sha256=HELPER_SHA), base_anchor=predecessor,
        actual_calibration_activations=phase_refs, initial_source_anchor=actual_request['initial_source_anchor'], initial_source_file_count=actual_request['initial_source_file_count'], R_definition=actual_request['R_definition'], selected_controls=actual_request['selected_controls'], **extra)
    path = HERE/('root-global-'+stage+'-request-v12-v1.json')
    save(path, value)
    io.put({path.relative_to(BASE).as_posix(): path}, 'v12-'+stage+'-request-exclusive-stage-v1')
    label = 'v12-actual-original-'+stage+'-content-replay-v1'
    result = json.loads(io.native(['python3', '-B', str(HELPER),
        remote_ref(path)['path'], sha(path)], label, 7200))
    actual_execution(label)
    assert result['qualification'] is result['performance_accepted'] is False
    assert result['collection_authorized'] is result['candidate_pairs_authorized'] is False
    assert result['anchor']['path'] == str(TRANSITIONS/stage/'external-anchor.accepted.json')
    assert result['report']['path'] == str(TRANSITIONS/stage/'actual-content-review.json')
    if stage.endswith('-pre'):
        count = 39 if stage[0] == 'B' else 18
        assert result['status'] == stage[0]+'_ORIGINAL_RAW_AND_ORIGINS_REVIEW_PASS'
        assert result['baseline_count'] == result['guard_count'] == count
    else:
        assert result['status'] == stage[0]+'_ORIGINAL_DIAGNOSTIC_FREEZE_CONTENTS_ACCEPTED'
        assert result['slots'] == (36 if stage[0] == 'B' else 18)
    save(HERE/('actual-'+stage+'-result-v12-v1.json'), result)
    print(json.dumps(result, allow_nan=False), flush=True)
    return result


def analyze(role, predecessor, phase_refs, b_accepted=None):
    out = ROOT/('analysis-global-original-v1' if role == 'B' else 'ar-analysis-global-original-v1')
    driver = REMOTE/('qualification-analysis-controller.py' if role == 'B'
        else 'r-material-gate-preparation-v2/r-analysis-controller.py')
    command = ['python3', '-B', str(driver), 'full-calibration', '--campaign', str(ROOT), '--out', str(out)]
    extra = []
    if role == 'R':
        assert b_accepted is not None
        extra = ['--original-B-anchor', b_accepted['path'], '--original-B-anchor-sha256',
            b_accepted['sha256'], '--definition', str(RDEF), '--definition-sha256', RDEF_SHA]
    prep_label = 'v12-original-'+role+'-full-calibration-prepare-v2'
    adapter = actual_request['prepare_adapter']
    assert adapter == dict(path=str(REMOTE/'qualification-v12-analysis-receipt-compatibility-preparation-v1/prepare-original-analysis-receipt-view-v12-v2.py'),
        sha256='830f832be33ffd6c6c757f3c86ca0a5d3089357f8d2fc2d6705ae17c42ef8466')
    preparation = dict(schema=1, status='ROOT_AUTHORIZED_PREPARE_ONLY_EXACT_RECEIPT_READ_VIEW',
        owner='/root', accepted_by_root=True, authorized_ns=time.time_ns(),
        prepare_receipt_read_view_authorized=True, role=role, adapter=adapter,
        controller=dict(path=str(driver), sha256=('e5744ead53031c489e3345c16a48c0b2e7b91c577177d50d25d94adfbe7b79fd'
            if role=='B' else '433c5df7016136afc8920b6663c5c0ed5d167cea993b35554a0b54a663764dc6')),
        original_argv=command+extra+['--prepare'],
        source_lock=actual_request['source_lock'],campaign_manifest=actual_request['campaign_manifest'],
        source_receipt=actual_request['source_receipt'],
        provenance_path=str(REMOTE/HERE.relative_to(BASE)/('root-'+role+'-prepare-receipt-view-provenance-v12-v1.json')),
        qualification=False,performance_accepted=False,collection_authorized=False,
        candidate_pairs_authorized=False,merge_authorized=False,held_excluded=[5004,5006],
        source_compatibility_acceptance=actual_request['compatibility_source_acceptance'])
    pp=HERE/('root-'+role+'-prepare-receipt-view-actual-request-v12-v1.json')
    save(pp,preparation)
    io.put({pp.relative_to(BASE).as_posix():pp},
        'v12-'+role+'-prepare-receipt-view-request-exclusive-stage-v1')
    prepared = json.loads(io.native(['python3','-B',adapter['path'],
        remote_ref(pp)['path'],sha(pp)],prep_label,7200))
    actual_execution(prep_label)
    provenance_reader = "import hashlib,json,pathlib,sys; p=pathlib.Path(sys.argv[1]); assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p; data=p.read_bytes(); print(json.dumps(dict(reference=dict(path=str(p),sha256=hashlib.sha256(data).hexdigest()),bytes=len(data),value=json.loads(data))))"
    observed=json.loads(io.native(['python3','-B','-c',provenance_reader,
        preparation['provenance_path']],'v12-'+role+'-prepare-receipt-view-actual-provenance-readback-v1',120))
    assert observed['reference']['path']==preparation['provenance_path']
    pv=observed['value']
    assert pv['request']==remote_ref(pp) and pv['logical_original_argv']==preparation['original_argv']
    assert pv['outer_argv']==['python3','-B',adapter['path'],remote_ref(pp)['path'],sha(pp)]
    assert pv['returncode']==0 and pv['error'] is None
    assert all(pv[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
    paths = dict(run=RECEIPTS/(prep_label+'-run.json'),
        stdout=RECEIPTS/(prep_label+'-stdout.txt'),stderr=RECEIPTS/(prep_label+'-stderr.txt'))
    io.put({p.relative_to(BASE).as_posix():p for p in paths.values()},
        'v12-'+role+'-prepare-receipt-view-execution-exclusive-stage-v1')
    preparation_transport=dict(adapter=adapter,request=remote_ref(pp),
        provenance=observed['reference'],
        execution={name:remote_ref(path) for name,path in paths.items()})
    assert prepared['status'] == 'root_review_required' and prepared['qualification'] is False
    assert prepared['anchor'] == str(out/'external-anchor.draft.json')
    pre = request(role+'-pre', predecessor, phase_refs,
        preparation_transport=preparation_transport,
        prepared_draft=dict(path=prepared['anchor'], sha256=prepared['anchor_sha256']),
        prospective_binding=dict(path=str(ROOT/'prospective-v10-root-v1/pre-c1-binding.json'),
            sha256=actual_request['prospective_binding']['sha256']))
    label = 'v12-original-'+role+'-full-calibration-v1'
    result = json.loads(io.native(command+extra+['--anchor', pre['anchor']['path'],
        '--anchor-sha256', pre['anchor']['sha256']], label, 7200))
    execution = actual_execution(label)
    assert result['status'] == 'analysis_complete_root_review_required'
    assert result['stage'] == 'full-calibration' and result['qualification'] is False
    assert len(result['slots']) == (36 if role == 'B' else 18)
    assert result['slots'] == sorted(set(result['slots']))
    paths = dict(run=RECEIPTS/(label+'-run.json'), stdout=RECEIPTS/(label+'-stdout.txt'),
        stderr=RECEIPTS/(label+'-stderr.txt'))
    io.put({p.relative_to(BASE).as_posix(): p for p in paths.values()},
        'v12-'+role+'-original-analysis-execution-exclusive-stage-v1')
    accepted = request(role+'-accept', pre['anchor'], phase_refs,
        original_analysis_execution={name: remote_ref(path) for name, path in paths.items()})
    assert execution['native_argv'] == command+extra+['--anchor', pre['anchor']['path'],
        '--anchor-sha256', pre['anchor']['sha256']]
    return accepted



def actual_invocation_request():
    import sys
    assert len(sys.argv)==3 and sys.pycache_prefix is None
    p=Path(sys.argv[1]);assert p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink()
    assert sha(p)==sys.argv[2]
    q=read(p)
    assert q['schema']==1 and q['accepted_by_root'] is True and q['owner']=='/root'
    assert q['later_artifact_execution_authorized'] is True
    assert q['campaign_root']==str(ROOT) and q['held_excluded']==[5004,5006]
    assert q['helper']==remote_ref(Path(__file__).resolve())
    assert all(q[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
    return q

if __name__ == '__main__':
    assert __debug__
    actual_request=actual_invocation_request()
    RDEF_SHA=actual_request['R_definition']['sha256']
    assert actual_request['R_definition']['path']==str(RDEF)
    state = read(STATE)
    assert state['native_active'] is None, 'join the existing calibration before launching'
    rest = actual_execution('v12-actual-original-remaining-calibration-v1')
    small = actual_execution('v12-actual-original-small-calibration-v1')
    assert small['finished_ns'] < rest['started_ns']
    source = read(HERE/'root-global-transition-source-acceptance-v12-v3.json')
    assert actual_request['compatibility_source_acceptance']==remote_ref(HERE/'root-global-transition-source-acceptance-v12-v3.json')
    assert source['helper']==dict(path=str(HELPER),sha256=HELPER_SHA)
    assert source['prepare_adapter']==actual_request['prepare_adapter']
    assert source['accepted_by_root'] is True and source['source_only'] is True
    assert source['qualification'] is source['performance_accepted'] is False
    assert sha(BASE/HELPER_REL) == HELPER_SHA
    phase_paths = {'small': BASE/'qualification-v12-refresh/qualification-v10-prospective-root-v1/small-calibration-driver-activation.accepted-v2.json',
        'calibration-rest': BASE/'qualification-v12-refresh/qualification-v10-prospective-root-v1/remaining-calibration-driver-activation.accepted-v1.json'}
    phases = {name: remote_ref(path) for name, path in phase_paths.items()}
    assert phases==actual_request['actual_phase_activations']
    ip = RECEIPTS/'root_native_io.py'
    assert sha(ip) == 'fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
    io = types.ModuleType('root_io')
    io.__file__ = str(ip)
    exec(compile(ip.read_bytes(), str(ip), 'exec'), io.__dict__)
    update_runtime(native_active=dict(phase='fresh-v12-original-B36-R18-content-analysis',
        owner='/root', local_owner_pid=os.getpid(), started_ns=time.time_ns(),
        campaign_root=str(ROOT), qualification=False, candidate_pair_collection_authorized=False),
        current_execution_status='Actual original calibration joined; original raw/B36/R18 analyses running serially')
    try:
        initial=actual_request['initial_source_anchor']
        assert initial['path']==str(PROS/'pre-c1-anchor.accepted-v2.json')
        b = analyze('B', initial, phases)
        r = analyze('R', b['anchor'], phases, b['anchor'])
        accepted = dict(schema=1, status='ACTUAL_ORIGINAL_39C_39GUARDS_B36_R18_CONTENTS_ACCEPTED',
            accepted_by_root=True, accepted_ns=time.time_ns(), campaign_root=str(ROOT), held_excluded=[5004, 5006],
            calibration_captures=39, calibration_guards=39, B_slots=36, R_slots=18,
            actual_phase_activations=phases, B=b, R=r, numerical_UNKNOWN_can_pass=False,
            qualification=False, performance_accepted=False, collection_authorized=False,
            candidate_pairs_authorized=False, merge_authorized=False,
            next_action='Root full-R canonical B/all24 closure, actual GLOBAL54, physical34 preservation, then separate pair authority')
        save(HERE/'root-global-calibration-content-acceptance-v12-v1.json', accepted)
        state = read(STATE)
        state['qualification_v12_current'].update(calibration_captures=39, calibration_guards=39,
            B_original_noise_slots=36, R_original_noise_slots=18,
            original_global_calibration_contents=remote_ref(HERE/'root-global-calibration-content-acceptance-v12-v1.json'))
        update_runtime(native_active=None, qualification_v12_current=state['qualification_v12_current'],
            current_execution_status='Actual original39C/39guards/B36/R18 accepted; no candidate pairs or performance qualification',
            next_action=accepted['next_action'])
        print(json.dumps(accepted, allow_nan=False), flush=True)
    except BaseException as error:
        update_runtime(native_active=None,
            current_execution_status='Original global analysis gate failed; exact raw evidence retained for diagnosis',
            next_action='Read failed original analysis/transition receipt; no blind retry or candidate collection',
            last_native_failure=dict(phase='fresh-v12-original-B36-R18-content-analysis', error=repr(error),
                finished_ns=time.time_ns()))
        raise
