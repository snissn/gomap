"""Prepared root-only activation and unchanged original pair-driver runtime.
Future CLI: python3 -B HELPER ROOT_REQUEST ROOT_REQUEST_SHA256.
Nothing is accepted or launched by source preparation. Failures are retained.
"""
if not __debug__:raise RuntimeError('unoptimized Python required')
from pathlib import Path
import hashlib,json,math,os,sys,time,types
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
REMOTE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=REMOTE/'qualification-v12-refresh/qualification-v10'
STATE=BASE/'state.json';RECEIPTS=BASE/'qualification-v9-selected-source-preparation-v1'
IO_SHA='fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1'
LABEL='v12-actual-original-114-pairs-114-guards-v1'
def require(ok,why):
    if not ok:raise ValueError(why)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def parse(raw):
    def unique(items):
        d={}
        for k,v in items:require(k not in d,'duplicate JSON key');d[k]=v
        return d
    def invalid(v):raise ValueError('nonfinite JSON')
    def finite(v):
        f=float(v);require(math.isfinite(f),'nonfinite JSON');return f
    return json.loads(raw,object_pairs_hook=unique,parse_constant=invalid,parse_float=finite)
def canonical(p):
    p=Path(p);require(p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve()==p,'canonical local file');return p
def read(p):return parse(Path(p).read_bytes())
def ref(p):return dict(path=str(REMOTE/Path(p).relative_to(BASE)),sha256=sha(p))
def local_bound(r):
    require(set(r)=={'path','sha256'},'exact bound ref');rel=Path(r['path']).relative_to(REMOTE);p=canonical(BASE/rel);require(sha(p)==r['sha256'],'local reference drift');return read(p)
def save(p,value):
    with p.open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
    return ref(p)
def flags(v):require(all(v[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized')),'forbidden upstream authority')
def runtime(**fields):
    s=read(STATE);s.update(fields);p=HERE/('state-pair-runtime-'+str(time.time_ns())+'.json');save(p,s);p.replace(STATE)
def actual(label):
    row=read(RECEIPTS/(label+'-run.json'));require(row['rc']==0 and not row.get('error') and 0<row['started_ns']<row['finished_ns'],'successful retained native receipt')
    for channel in ('stdout','stderr'):
        p=RECEIPTS/(label+'-'+channel+'.txt');require(row[channel]==dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size),'retained stream identity')
    require(not (RECEIPTS/(label+'-stderr.txt')).read_bytes(),'unexpected native stderr');return row

def load_exact_stage():
    path=BASE/'qualification-v12-exact-stage-preparation-v1/exact_stage_v12_v1.py'
    assert path.resolve(strict=True)==path and path.is_file() and not path.is_symlink()
    data=path.read_bytes()
    assert hashlib.sha256(data).hexdigest()=='27515da907ab4bf3bdcb5fc56773364189b70159317521c2e22e5e4ce068dd03'
    module=types.ModuleType('root_exact_stage_v12');module.__file__=str(path)
    exec(compile(data,str(path),'exec'),module.__dict__)
    return module


def main():
    require(len(sys.argv)==3 and sys.flags.dont_write_bytecode and sys.pycache_prefix is None,'python3 -B request SHA')
    rp=canonical(sys.argv[1]);require(sha(rp)==sys.argv[2],'root request digest');q=read(rp);flags(q)
    require(q['schema']==1 and q['accepted_by_root'] is True and q['owner']=='/root' and q['pair_launch_authorized'] is True and q['serial_and_quiescent'] is True and q['exclusive_native_owner'] is True,'actual bounded root launch authority')
    require(q['campaign_root']==str(ROOT) and q['held_excluded']==[5004,5006] and q['helper']==ref(canonical(__file__)),'current root/source selection')
    require((q['expected_original_pairs'],q['expected_state_specific_guards'])==(114,114),'full original matrix only')
    selected=q['selected_controls'];require(set(selected)=={'driver','selection','guard'},'exact current controls')
    DRIVER_SHA=selected['driver']['sha256'];SELECTION_SHA=selected['selection']['sha256'];GUARD_SHA=selected['guard']['sha256']
    adoption=local_bound(q['helper_source_acceptance']);require(adoption['accepted_by_root'] is True and adoption['source_only'] is True and adoption['helper']==q['helper'],'actual independent source adoption')
    preflight=HERE/'pair-launch-prerequisite-readback-v12-v1.py';require(q['prerequisite_helper']==ref(preflight) and adoption['prerequisite_helper']==q['prerequisite_helper'],'reviewed prerequisite helper')
    s=read(STATE);require(s['native_active'] is None,'join previous native owner')
    full=local_bound(q['full_R_and_global54_actual_acceptance']);flags(full)
    require(full['accepted_by_root'] is True and full['status']=='ACTUAL_FULL_R_COMPLETE24_CANONICAL_B_AND_GLOBAL54_REPLAY_PASS' and full['campaign_root']==str(ROOT) and full['held_excluded']==[5004,5006],'actual full R/GLOBAL gate')
    replay=full['replay_result'];require(replay['status']=='GLOBAL54_ARTIFACT_REPLAY_COMPLETE_ROOT_LAUNCH_STILL_REQUIRED' and (replay['baseline_captures'],replay['guard_captures'],replay['B_slots'],replay['R_slots'])==(39,39,36,18) and replay['qualification'] is replay['candidate_pairs_authorized'] is False,'actual39/39/36/18 GLOBAL replay')
    global_decision=local_bound(full['global54_content_acceptance']);calibration_contents=local_bound(global_decision['original_calibration_content_acceptance']);flags(calibration_contents)
    require(calibration_contents['accepted_by_root'] is True and calibration_contents['status']=='ACTUAL_ORIGINAL_39C_39GUARDS_B36_R18_CONTENTS_ACCEPTED' and (calibration_contents['calibration_captures'],calibration_contents['calibration_guards'],calibration_contents['B_slots'],calibration_contents['R_slots'])==(39,39,36,18),'actual original39 calibration acceptance')
    require(calibration_contents['R']['anchor']==full['full_R_predecessor'],'actual R-accept predecessor')
    template_refs=q['activation_templates'];require(set(template_refs)=={'R','driver'},'exact current activation templates')
    r=local_bound(template_refs['R']);d=local_bound(template_refs['driver'])
    require(d['driver']==selected['driver'] and d['global54_guard']==selected['guard'] and selected['selection']['path']==str(REMOTE/'qualification-v12-fresh-controls-v1/deployment-helpers-selection.json'),'actual selected control refs')
    for t in (r,d):require(t['source_only'] is True and t['accepted_by_root'] is False and t['collection_authorized'] is False,'source-only template');require(t['campaign_root']==str(ROOT) and t['held_excluded']==[5004,5006],'original matrix campaign')
    require(d['driver']['sha256']==DRIVER_SHA and d['helper_selection_sha256']==SELECTION_SHA and d['global54_guard']['sha256']==GUARD_SHA,'unchanged driver selection')
    for native,digest in [(d['driver']['path'],DRIVER_SHA),(d['global54_guard']['path'],GUARD_SHA),(str(REMOTE/'qualification-v12-fresh-controls-v1/deployment-helpers-selection.json'),SELECTION_SHA)]:require(sha(canonical(BASE/Path(native).relative_to(REMOTE)))==digest,'selected local controls')
    for p in [HERE/'R-collection-activation.accepted-v12-v1.json',HERE/'pair-driver-activation.accepted-v12-v1.json',BASE/'qualification-v12-root-preparation-v1/root-original114-pair-phase-joined-v12-v1.json']:
        require(not os.path.lexists(p),'retained prior authority/attempt; no retry')
    ip=canonical(RECEIPTS/'root_native_io.py');require(sha(ip)==IO_SHA and not (ip.parent/'__pycache__').exists(),'exact uncached root native IO')
    io=types.ModuleType('root_pair_io');io.__file__=str(ip);exec(compile(ip.read_bytes(),str(ip),'exec'),io.__dict__)
    stage=load_exact_stage()
    runtime(native_active=dict(phase='fresh-v12-original-pair-prerequisite-and-launch',owner='/root',local_owner_pid=os.getpid(),started_ns=time.time_ns(),campaign_root=str(ROOT),qualification=False,request=ref(rp)))
    try:
        check=dict(schema=1,accepted_by_root=True,read_only_prerequisite_check_authorized=True,campaign_root=str(ROOT),held_excluded=[5004,5006],
            full_R=full['full_R'],full_R_predecessor=full['full_R_predecessor'],canonical_B_gate=full['canonical_B_gate'],global54_content_acceptance=full['global54_content_acceptance'],global54_input=full['global54_input'],physical34_actual_acceptance=q['physical34_actual_acceptance'],deployment=d['deployment'],calibration_activation=d['calibration_activation'],driver=d['driver'],guard=d['global54_guard'],selection=dict(path=str(REMOTE/'qualification-v12-fresh-controls-v1/deployment-helpers-selection.json'),sha256=SELECTION_SHA),initial_source_anchor=q['initial_source_anchor'],initial_source_file_count=q['initial_source_file_count'],post_small_anchor=q['post_small_anchor'],post_small_source_file_count=q['post_small_source_file_count'],prospective_rule_freeze=q['prospective_rule_freeze'],qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False)
        cp=HERE/'pair-launch-prerequisite-request.accepted-v12-v1.json';save(cp,check)
        stage.exact_stage(io,{p.relative_to(BASE).as_posix():p for p in (preflight,cp)},'v12-pair-prerequisite-exclusive-stage-v1')
        result=parse(io.native(['python3','-B',ref(preflight)['path'],ref(cp)['path'],sha(cp)],'v12-pair-prerequisite-actual-readback-v1',7200));actual('v12-pair-prerequisite-actual-readback-v1')
        require(result['status']=='PAIR_LAUNCH_PREREQUISITE_READBACK_PASS' and result['full_R']==full['full_R'] and result['full_R_predecessor']==full['full_R_predecessor'] and result['physical34_actual_acceptance']==q['physical34_actual_acceptance'] and result['preserved_count']==34 and result['pins_count']==24 and result['no_pair_namespace'] is True,'actual root gate readback')
        save(HERE/'pair-launch-prerequisite-actual-readback-v12-v1.json',result)
        now=time.time_ns()
        for t in (r,d):
            t.pop('source_only');t.update(accepted_by_root=True,collection_authorized=True,candidate_pair_collection_authorized=True,authorized_ns=now,status='ROOT_AUTHORIZED_ORIGINAL_PAIR_COLLECTION_ONLY',owner='/root',root_launch_request=ref(rp),global54_actual_content_acceptance=full['global54_content_acceptance'],metadata_preservation_acceptance=q['physical34_actual_acceptance'],canonical_B_gate=full['canonical_B_gate'])
        r.update(anchor=full['full_R']['path'],anchor_sha256=full['full_R']['sha256'])
        rr=save(HERE/'R-collection-activation.accepted-v12-v1.json',r)
        d.update(R_activation=rr,current_pair_source_anchor=full['full_R'],current_pair_source_predecessor=full['full_R_predecessor'],global54_input=full['global54_input'])
        dr=save(HERE/'pair-driver-activation.accepted-v12-v1.json',d)
        stage.exact_stage(io,{p.relative_to(BASE).as_posix():p for p in (HERE/'R-collection-activation.accepted-v12-v1.json',HERE/'pair-driver-activation.accepted-v12-v1.json')},'v12-original-pair-activations-exclusive-stage-v1')
        runtime(current_execution_status='Original114 pairs/114 guards running through unchanged serial driver; actual prerequisite gates passed',next_action='Join driver; review actual raw114/114 before final metadata IO or original final analysis')
        io.native(['python3','-B',d['driver']['path'],'pairs',dr['path'],dr['sha256']],LABEL,300000);execution=actual(LABEL)
        code="from pathlib import Path;import hashlib,json,sys;p=Path(sys.argv[1]);assert p.resolve()==p and not p.is_symlink();v=json.loads(p.read_bytes());assert v['status']=='STAGE_JOINED_ROOT_CONTENT_REVIEW_REQUIRED' and v['phase']=='pairs' and v['rc']==0 and v['activation_sha256']==sys.argv[2] and v['qualification'] is False;print(json.dumps(dict(receipt=v,reference=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))))"
        joined=parse(io.native(['python3','-B','-c',code,str(REMOTE/'qualification-v12-fresh-controls-v1/collection-driver-pairs-v12/complete.json'),dr['sha256']],'v12-original-pair-completion-readback-v1',180));actual('v12-original-pair-completion-readback-v1')
        outcome=dict(schema=1,campaign_root=str(ROOT),held_excluded=[5004,5006],status='ORIGINAL_PAIR_DRIVER_JOINED_ACTUAL_RAW_CONTENT_REVIEW_REQUIRED',accepted_by_root=False,raw_contents_accepted=False,paired_driver_completion=joined['reference'],paired_driver_activation=dr,R_activation=rr,full_R=full['full_R'],full_R_predecessor=full['full_R_predecessor'],physical34_actual_acceptance=q['physical34_actual_acceptance'],native_execution=ref(RECEIPTS/(LABEL+'-run.json')),global54_content_acceptance=full['global54_content_acceptance'],metadata_preservation_acceptance=q['physical34_actual_acceptance'],original_pair_count=114,state_specific_guard_count=114,counts_are_expected_until_raw_replay=True,raw_content_acceptance=False,expected_original_pairs=114,expected_state_specific_guards=114,joined_ns=time.time_ns(),qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False)
        resultref=save(BASE/'qualification-v12-root-preparation-v1/root-original114-pair-phase-joined-v12-v1.json',outcome)
        s=read(STATE);s['qualification_v12_current']['original_pair_driver_joined_pending_raw_review']=resultref
        runtime(native_active=None,qualification_v12_current=s['qualification_v12_current'],current_execution_status='Original pair driver joined rc0; raw content acceptance pending',next_action='Read exact retained pair/guard bytes through reviewed raw helper; no final metadata or final numerical decision yet')
        print(json.dumps(outcome,allow_nan=False),flush=True)
    except BaseException as error:
        runtime(native_active=None,current_execution_status='Original pair prerequisite/launch failed; exact artifacts retained',next_action='Inspect retained actual failed gate/cleanup; no automatic retry, overwrite or authority reuse',last_native_failure=dict(phase='fresh-v12-original-pairs',label=LABEL,error=repr(error),finished_ns=time.time_ns()))
        raise
if __name__=='__main__':main()
