# Bounded freelist allocation algorithm inquiry

The smallest source-supported candidate is a **transaction-private last-root/chunk proof that allows repeated single Allocate calls to update the same already-copied path**. Keep page selection, hints, ledger, pager extension and allocator accounting unchanged. An AllocMany-only change misses the actual group/tracker path. This is an implementation outline, not a patch, performance claim, runtime selection or qualification.

Inspected exact R `e70deeff0085c51278e57a272d4de1e622e63fe2` through read-only Git objects in `/private/tmp/gomap-qs-5015`. No worktree/Git/product/state changes, Go/tests/benchmarks/native/GH/SSH runs, push, merge or gate changes. Held #5004/PR5006 excluded. Exact source/input SHA custody is in `source-bindings.json`. Original allocation/performance gates stand; R-only profiles do not establish A regression.

## Actual caller coverage

| Caller / binding | Exact source | Scope |
| --- | --- | --- |
| Leaf rebalance | `zipper/zipper.go:3840–3863` | Optional AllocMany interface, count2; completely bypassed when outerLeavesInValueLog. Fallback two Alloc calls feeds first ID as second hint. Partial returned IDs retired on error. |
| Internal rebalance | `zipper/zipper.go:4278–4301` | Optional interface, count2; same hints and partial-error cleanup. |
| Ordinary serialized Apply | `db/batch.go:737–742` | Zipper uses idx.allocator directly; single allocations and optional pair rebalance can reach COW transaction. |
| Optimistic Apply | `db/batch.go:400–401` | Uses allocTracker, which exposes only Alloc (`db/alloc_tracker.go:32–40`), so optional AllocMany interface is unavailable. |
| Root-publication group Apply | `db/root_publication_build_group.go:281–290` | Uses the same tracker and only single Alloc; this is the profiled group route. |

Object-level caller search finds these two production AllocMany call sites; all other hits are allocator definitions, tests, benchmarks and retained profile text. Existing `freelist/allocator.go:248–265` COW AllocMany loops `allocCOWLocked`, preserving hint=id after each success. Optimizing that loop alone does not address tracker-mediated allocations. Adding AllocMany to tracker is an additional caller/API-path change, and count2/outer-leaf bypass further bounds potential coverage; it is unnecessary for the proposed txn seam.

## Observed algorithm and ownership seam

`generation_v1_tree.go:20–24` defines 256-page chunks and trie depth14. `mutateChunk:190–211` clones15 nodes plus one stateChunk for every mutation, then recomputes all summaries. `FreelistTxn.Allocate:289–300` first chooses the exact unreserved free page, clears its bit via this persistent mutation, records allocation and counters. `chooseUnreservedFreePage:311–338` includes region-distance/tie behavior and reserved-page fallback; preserve it verbatim. Repeated calls often can select the same chunk because highest free bits are chosen, but actual workload locality is UNKNOWN.

Allocator locking serializes all production transaction mutation (`allocator.go:792–807`; `allocator_cow.go:255–284`). The group tracker adds bookkeeping but delegates to that lock. `BeginCandidateV1:220–238` shares immutable base root; it creates no exclusive mutable authority. A successful full mutateChunk, however, creates an entirely new root-to-chunk path with no outside owner. Only other branches are shared. The new path can be changed again for the same chunk before an ownership fork, provided that fork invalidates the proof.

Existing code has no such proof: pageID0, changedChunks membership, or root pointer equality by themselves do not establish exclusivity. `cloneForAllocatorPrepare:198–217` shares even dirty roots with rollback/staged transactions; `allocator_cow.go:411–450` retains rollbackTxn and restores it on error. Abort restores rollback before waking waiters (`:455–482`); activation creates a new txn from candidate generation (`:503–515`).

## Concrete minimal implementation outline

1. Add two private runtime-only FreelistTxn fields: a last-private-root pointer and its chunk number. Nil root means no authority. BeginCandidate initializes empty. No node/chunk tags, registry, ownership map, global pool, durable format or public API.
2. After each successful ordinary persistent mutateChunk, record its newly copied root and target chunk. That authority covers only that exact path, not dirty siblings or every changed chunk.
3. In Allocate only, after the unchanged chooser returns id, test `txn.root == privateRoot && id>>8 == privateChunk`. If false, use existing full persistent mutation. If true, traverse the exact path, clear the validated bit in its private chunk, preserve empty-chunk removal semantics and recompute every ancestor bottom-up. Share existing markReplacedPath/changedChunks/StateMutationPaths/Items bookkeeping; do not duplicate counters or alter their logical meaning. Keep other mutation callbacks on the original persistent path. This narrows in-place work to a validated, non-user-callback bit clear.
4. In cloneForAllocatorPrepare, clear authority in **both original and clone** before either can mutate again; sharing a dirty root revokes both proofs. Copy existing slices/maps exactly as now. On rollback a transaction may have empty proof; its next mutation takes the full COW path. Logical state is untouched by proof invalidation.
5. Clear proof before MaterializeCandidate calls tryReusedMetadata, and again when consumed before detach/emission. This is required even for direct standalone materialization: existing tests retain txn.root without a prepare clone. Preserve selected-path full copy, detachMetadataSiblings and detachUnmaterialized verbatim, success/failure consumption, immutable retry base, reservation tail burning and all sink behavior.
6. Root mismatch/different chunk always falls back; a change to another chunk creates a fresh proof for that chunk. Do not extend reuse to longest common prefix, earlier visited branches or arbitrary changedChunks in this refinement. The sizing-only `planned := *t` (`metadata_reuse.go:215–218`) is read-only; keep it so, and clear its copied proof defensively if future mutation is possible.

The invariant is inductive: first mutation copies15 nodes/chunk; same-chunk Allocate only changes that privately copied path; different-path mutation copies a new path; every real sharing fork clears both proofs; materialization clears proof and makes its existing isolation copy. Base and sibling transactions cannot observe these in-place bit clears. Implementation must encode this invariant explicitly and test every transition.

Critical materialization evidence: `generation_v1_metadata_reuse.go:7–19` assumes selected metadata path was just copied. `tryReusedMetadata:182–235` plans before atomic claim, mutates only after success. `TestMetadataEmissionPreservesSharedDirtyBranches4627:12–49` retains selected and sibling dirty roots across successful/partial-failed emission; `generation_v1_metadata_reuse_test.go:251–254` wraps pre-materialization txn.root in a generation used by a checked sink. Skipping the materialization reset would violate these contracts, even when ordinary allocator prepare appears serialized.

## ID, hint, partial-error and safety equivalence

Choose exactly the same page from the same logically updated bitmap/summaries each time; no delayed bitmap clears, selection batching, sorting or changed tie-break. Public Alloc/AllocMany and allocCOWLocked stay unchanged, including preferAppend, per-ID hint, PageVisits, reservation checks, per-page Truncate, successful stats and lastAlloc. On Truncate error the underlying txn has already selected/recorded that ID but public allocation returns error without adding it to returned partial results; preserve this existing ordering, not a newly transactional batch.

Keep prepared generation/base digest and root immutability, rollback snapshots, no reuse before two-slot/read/history horizons, visible/ambiguous ledger ownership, allocation admission/prepare limits, all pins/durability/final coverage/fences. Other generic mutation callbacks retain pure COW behavior, including callback panic behavior. The Allocate bit clear uses an offset masked to0..255 and internal traversal whose valid path follows the unchanged chooser; any implementation-added guard must check before mutation and use safe fallback. No new user callback or recovered-panic contract is introduced.

## Quantified source bound and remaining uncertainty

For N consecutive reused Allocate calls to one 256-page chunk without a sharing fork, current source performs16*N structure clone operations; candidate performs at most16, while preserving chooser/recompute/mark/counter work. For a full chunk's256 allocations:4096 clone operations become at most16, eliminating up to4080 (99.61%) in that finite run. This is an algorithm bound, not measured whole-process allocation or speed. Chunk switches/forks retain full fallback; alternating chunks receive no claimed reduction. Append allocations already avoid these mutations. Actual run frequency, profile attribution and realized byte/object/latency improvement remain UNKNOWN.

Two proof fields add16B of field payload per transaction on64-bit targets (not measured allocator size). Pointer references only the current root already retained by txn; invalidate on consume/fork to avoid stale-root retention. No cache grows with chunk count. This does not establish heap/RSS benefit; old generations and materialization copies retain their existing lifetimes.

## Required focused tests before selecting implementation

- Differential page-ID sequences and complete materialized bytes against existing pure mutation: same chunk, chunk boundaries/alternation, hint0 and ties, reserved preferred chunk/all-reserved fallback, preferAppend and high-water overflow. Keep summaries/free and retired data identical after every step.
- Prepare fork after an already private path; then mutate original and staged separately, including same chunk and sibling chunks. Both roots must stay unchanged when the other branch writes; invalidation must affect both branches.
- Successful/failed/aborted prepare, rollback followed by another same-chunk allocation, activation/build-ahead and retry after partial sink writes. Include retained direct txn.root materialization fixtures above.
- AllocMany versus repeated Alloc, including partial results and pager-extension failure ordering; tracker group/optimistic actual paths; no extra returned/retired IDs.
- Structural clone/allocation discriminator for a finite same-chunk run, plus alternating-chunk fallback; prove exact bytes/IDs before claiming cost reduction. Appropriate race coverage of shared allocator/separate candidates remains root-owned.

Existing source tests to retain: `TestFreelistGenerationV1_OlderGenerationAndPagesRemainImmutable`, `..._MaterializeDoesNotAssignIDsIntoBase`, `..._HorizonPreventsPrematureReuse`; `TestFreelistTxn_AllocateSkipsAnotherCandidateReservation`, `..._SinkFailureConsumesTransaction`, `..._PartialSinkFailureBurnsTailUntilRetryPublishesAbandonment`; batched retirement/prune exactness; `TestMetadataEmissionPreservesSharedDirtyBranches4627`, `TestMetadataLosingClaimPreservesTransaction4627`, `TestMetadataImpossibleRunDoesNotAllocate4627`, `TestFreelistMetadataReuseStagedAllocatorRollback4627`; `TestAllocatorCOWCandidateRetirementsRollbackBeforePublish`, `TestAllocatorCOWDoesNotReuseUntilTwoSlotHorizonAdvances`, `TestAllocatorActivatedCOWGenerationsBuildAheadOfDurablePublication`; existing AllocMany sequence/partial-error tests. None run here.

Unsafe alternatives: blanket pageID0 mutation, relying only on changedChunks, preserving proof in either prepare branch, metadata emission on the retained private path, deferred/batched selection that changes reservation/error order, broad per-node owner/history mechanisms, or removing pins/fences/coverage. Root must review the eventual patch and collect matched native evidence; this source finding changes no gates.
