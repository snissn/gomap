import pathlib,json,hashlib,subprocess,time,os
root=pathlib.Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')
profile=root/'v13-causal-post-exhaustive-R3M-profile-v1/1-R-post-exhaustive'
go='/home/mikers/quicksilver-maintenance-5028-20261006/toolchain/go1.26.3/bin/go'
assert hashlib.sha256(pathlib.Path(go).read_bytes()).hexdigest()=='d68b7abbc40d0844f673f6cf06ae3cded225c50437c6454fa37ef178d079fe65'
binary=root/'bin/unified-bench-R';assert hashlib.sha256(binary.read_bytes()).hexdigest()=='07f52b8ec99a0f263f59f4dba729cebf1ef3e4e8bdc33c2370fd7929e5c43494'
run=json.loads((profile/'run.json').read_bytes());assert run['validated'] is True and run['rc']==0
out=profile.parent/'root-pprof-analysis-v2';out.mkdir(exist_ok=False)
env=dict(json.loads((root/'manifest.json').read_bytes())['build_env']);assert env['GOWORK']=='off' and env['GOTOOLCHAIN']=='local' and env['GOCACHE']
receipts=[]
for phase in ['hits','misses','mixed','concurrent']:
 for kind,index in [('allocs','alloc_space'),('allocs','alloc_objects'),('cpu','cpu')]:
  src=profile/f'{kind}_quicksilver_{phase}_treedb.pprof';name=f'{phase}-{index}-top'
  argv=[go,'tool','pprof','-sample_index='+index,'-top','-nodecount=25',str(binary),str(src)]
  start=time.time_ns();r=subprocess.run(argv,env=env,capture_output=True,timeout=120)
  (out/(name+'.txt')).write_bytes(r.stdout);(out/(name+'.stderr.txt')).write_bytes(r.stderr)
  receipts.append({'name':name,'argv':argv,'rc':r.returncode,'started_ns':start,'finished_ns':time.time_ns(),'profile_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stdout_bytes':len(r.stdout)})
  assert r.returncode==0,(name,r.returncode)
for name,src,options in [('concurrent-alloc-space-cumulative',profile/'allocs_quicksilver_concurrent_treedb.pprof',['-sample_index=alloc_space','-top','-cum','-nodecount=80']),('final-checkpoint-cpu-top',profile/'checkpoint_cpu_checkpoint_quicksilver_final_treedb.pprof',['-top','-nodecount=25'])]:
 argv=[go,'tool','pprof',*options,str(binary),str(src)];start=time.time_ns();r=subprocess.run(argv,env=env,capture_output=True,timeout=120)
 (out/(name+'.txt')).write_bytes(r.stdout);(out/(name+'.stderr.txt')).write_bytes(r.stderr)
 receipts.append({'name':name,'argv':argv,'rc':r.returncode,'started_ns':start,'finished_ns':time.time_ns(),'profile_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stdout_bytes':len(r.stdout)})
 assert r.returncode==0,(name,r.returncode)
report=json.loads((profile/'stdout.json').read_bytes())[0]
result={'status':'FROZEN_PROFILE_ANALYSIS_JOINED_DIAGNOSTIC_ONLY','output':str(out),'receipts':receipts,'phase_process_allocation_counters':[{'name':p['name'],'ops':p['ops'],'process_allocated_bytes':p['process_allocated_bytes'],'process_mallocs':p['process_mallocs']} for p in report['phases']],'initial_checkpoint_ms':report['initial_checkpoint_ms'],'checkpoint_ms':report['checkpoint_ms'],'final_checkpoint_ms':report['final_checkpoint_ms'],'tops':{n:(out/(n+'.txt')).read_text() for n in ['hits-alloc_space-top','concurrent-alloc_space-top','concurrent-alloc_objects-top','concurrent-alloc-space-cumulative','final-checkpoint-cpu-top']},'qualification':False,'performance_accepted':False}
(out/'analysis-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
