"""Prepare one independently rebound diagnostic copy; preserve accepted source."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time

ROOT = Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')
SCRIPTS = Path('/home/mikers/quicksilver-maintenance-5028-20261006/source-qualification-v12-R/scripts')
EXPECTED = {
    'unified_bench_quicksilver_capture.py': '1ae0af355186e384c909c9699c69ed18e8ec2bfa3fc59f91e13556a5f93f95f6',
    'owned_process_rss.py': 'b10721ee8d773d4cb1fa1ebbd28ca51d38bd217ba99a5960413c1c1523d179ad',
    'quicksilver_maintenance.py': '41d565138ae6d3762e74bce21dd2dd8c88830ce0ef7a24a34b1d6da7bfc25796',
}
for name, expected in EXPECTED.items():
    assert hashlib.sha256((SCRIPTS / name).read_bytes()).hexdigest() == expected
sys.path.insert(0, str(SCRIPTS))
import quicksilver_maintenance as maintenance
import unified_bench_quicksilver_capture as capture

manifest_raw = (ROOT / 'manifest.json').read_bytes()
assert hashlib.sha256(manifest_raw).hexdigest() == 'fe243316b55e429a276a8a060607c8920973275c3e089125dbf66f13370a5092'
manifest = json.loads(manifest_raw)
source = ROOT / 'ar-pairs-primary-s24-n3000000-exhaustive-b8192/R1/db'
prior = json.loads((ROOT / 'ar-guard-primary-s24-n3000000-exhaustive-b8192-R1/1-R1/run.json').read_bytes())
assert prior['validated'] is True and prior['rc'] == 0
assert prior['source']['head'] == '6fa638b8bffa71750e1aefa0bb746bb747aa06c1'
assert prior['manifest_sha256'] == hashlib.sha256(manifest_raw).hexdigest()
assert prior['cell']['measure_dir'] == str(source)
for role in ('source', 'build', 'native', 'runner'):
    receipt = manifest['receipts'][role]
    assert hashlib.sha256((ROOT / receipt['path']).read_bytes()).hexdigest() == receipt['sha256']
assert capture.sha256(ROOT / 'bin' / manifest['sources']['R_unified']['binary']) == '07f52b8ec99a0f263f59f4dba729cebf1ef3e4e8bdc33c2370fd7929e5c43494'
consumers = []
for entry in Path('/proc').iterdir():
    if not entry.name.isdecimal() or int(entry.name) == os.getpid():
        continue
    try:
        args = (entry / 'cmdline').read_bytes().split(b'\0')
    except (OSError, PermissionError):
        continue
    # Executable basename avoids matching this preparation source in argv text.
    if args and (b'unified-bench' in Path(os.fsdecode(args[0])).name.encode() or
                 Path(os.fsdecode(args[0])).name in ('treedb-compact-R', 'allocation-accounting')):
        consumers.append(int(entry.name))
assert not consumers, consumers
assert shutil.disk_usage(ROOT).free > 20 * 1024 ** 3
out = ROOT / 'v13-causal-post-exhaustive-R3M-profile-fixture-v1'
out.mkdir(exist_ok=False)
before = maintenance.fingerprint(source)
copy = out / 'db'
shutil.copytree(source, copy)
copied = maintenance.fingerprint(copy)
assert before == copied
after_copy = maintenance.fingerprint(source)
assert before == after_copy
metadata = dict(scope='Diagnostic only, independent physical copy of already verified idempotent post-exhaustive service state',
                source=str(source), copied_to=str(copy), source_before=before, copy_before_rebind=copied,
                source_after_copy=after_copy, clock_ns=time.time_ns(), load=os.getloadavg(), qualification=False,
                performance_accepted=False, held_excluded=[5004, 5006])
with (out / 'copy-before-rebind-receipt.json').open('x') as stream:
    json.dump(metadata, stream, indent=2); stream.write('\n')
env = capture.capture_environment(manifest['build_env'], ROOT / 'working-dbs')
maintenance.restore_snapshot(ROOT, manifest, copy, out, env, metadata)
metadata['source_after_rebind'] = maintenance.fingerprint(source)
assert metadata['source_after_rebind'] == before
metadata['copy_after_rebind'] = maintenance.fingerprint(copy)
metadata['prepared'] = True
with (out / 'prepared-receipt.json').open('x') as stream:
    json.dump(metadata, stream, indent=2); stream.write('\n')
print(json.dumps(dict(status='FRESH_COPY_REBOUND_SOURCE_UNCHANGED', source_fingerprint=before,
                      copy_after_rebind=metadata['copy_after_rebind'], output=str(out),
                      clock_ns=time.time_ns(), load=os.getloadavg())), flush=True)
