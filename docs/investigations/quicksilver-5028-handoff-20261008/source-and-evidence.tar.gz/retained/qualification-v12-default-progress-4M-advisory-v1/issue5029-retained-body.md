Parent: #5028. Role: **investigation and decision**. Intended output: **`issue-update`** to the parent, #5015 and #5016, supported by a source-bound evidence/decision packet. Acceptance owner: the graph coordinator. No predecessors. This is the first executable frontier; both implementation branches remain conditional until its findings are accepted.

## Question and provisional hypotheses

Which existing maintenance work should we remove or reuse to make compressed-outer-leaf maintenance faster, and which resource lifetimes actually affect process memory?

1. Outer-leaf rewrite repeatedly rebuilds whole-candidate resource closure because its existing logical reference-delta path is disabled. Exact deltas plus already available producer dependencies might remove repeated whole-tree traversal; the possible memory cost of retained closure metadata must be measured.
2. Background retained-log proof restarts from a fresh map/snapshot after its short scan budget. A safe existing proof/progress seam may avoid repeated work or starvation; a larger deadline alone may only move the cost onto foreground latency.
3. Retired mappings, decoded caches, snapshots or temporary proof/swap buffers may dominate memory at different phases. Faster maintenance may shorten a lifetime, but a retained segment on disk need not have resident mapped pages. Determine that causal link before claiming a memory benefit.

Current inspected base: `9905d553658c3c80924c2def2479d2c6a77c47f9`. Historical inputs: [3M report](https://github.com/snissn/gomap/blob/9905d553658c3c80924c2def2479d2c6a77c47f9/docs/benchmarks/treedb_quicksilver_space_memory_20261005/REPORT.md), [landed-publication qualification](https://github.com/snissn/gomap/pull/5013#issuecomment-5994044765), and the current #5015/#5016 bodies. Preserve historical sources, failures and measurement limitations.

## Smallest useful inquiry

- Refresh actual main, applicable root/TreeDB policy and adjacent active owners. Trace public `CompactStorage` Full/Exhaustive and online/background rewrite/prune admission through candidate publication, proof acquisition, retirement, manager eviction and handle release; include system/collection roots and fallback callers. The value log is persistent storage, not a disposable WAL.
- Reuse the existing closure/reference tracker, producer-resource projection, `maintenanceReachabilityScan` counters, retained-prune scan hooks/status counters, recoverable-root authority and manager/stable-resource lifetime observations. At the pinned base, `canTrackRewriteValueLogRefDelta` explicitly declines outer leaves; candidate capture falls back to reachability scanning. `collectValueLogLiveIDsUntilWithContextAndTimeout` acquires a fresh map/snapshot, discards incomplete proof on abort, and the scheduled runner supplies the private budget. Observed-source and explicit inline paths have different proof/fence contracts. Verify rather than conflate them.
- Begin with existing profiles and deterministic small fixtures. For rewrite, compare compressed outer-leaf and paged controls across dataset size at **fixed swap batch**, counting closure walks, visited pages/records, decoded bytes, publication count and physical identities. The existing `BenchmarkValueLogRewriteOnline_ValuePointers` has no outer-leaf setup and is only a control. Hold larger-batch tuning as a separate factor.
- For pruning, use the existing budget/cancellation hook with eligible garbage and pinned/live controls. Separate budget exhaustion, foreground mutation, stale root basis, legitimate pin retention and no-candidate outcomes. Compare scheduled bounded work with a finite explicit/reference completion to estimate necessary proof; do not treat its foreground pause as equivalent service latency.
- Trace allocation and retention by owner/lifetime: candidate/proof metadata, buffers and decode scratch, root/snapshot/stable-resource pins, retired file mappings and decoded caches. Relate counters to co-timed heap and RSS/file/anonymous observations. No RSS-minus-heap arithmetic, global fixed RAM cap or pooling-by-assumption.
- Define the public confirmation fixture from existing unified Quicksilver `generic-v1` primary and holdout. Keep 3M as the existing anchor and two smaller scale points for causal work; choose a larger point only for a named unresolved risk. Preserve generic key families, value-size/entropy distributions and actual ACK/compression/checksum settings. Separate full-refresh stress from representative sparse churn and quiet drain.

Useful existing commands, to be frozen at the refreshed base before collection:

```sh
GOWORK=off go test ./TreeDB/db -run '^$' \
  -bench '^BenchmarkValueLogRewriteOnline_ValuePointers$' -benchmem -benchtime=1x -count=3
GOWORK=off go test ./TreeDB/caching \
  -run 'TestRetainedValueLogPrune(BudgetAbortSkipsUnprovenReclaim|CancellationSkipsUnprovenReclaim|CloseCancelsNestedLiveIDScan)$' -count=1
```

These are controls/characterization, not sufficient outer-leaf speed or RSS evidence. Reuse `unified-bench -profile-dir` and `benchprof -profiles-dir` for compatible public profile artifacts; standalone diagnostic package profiles keep their own source/command receipts. Validate capture/analysis boundaries before expensive collection. Diagnostic overlays are retained and excluded from public performance claims. A necessary reusable harness change becomes an explicitly owned PR prerequisite; ticket-only output does not bypass its review/CI gates.

## Deliverable and acceptance

- [x] Publish a concise source/command/fixture-bound limiter and lifetime analysis: evidence for/against each hypothesis, alternatives, measured tradeoffs, unknowns and the next smallest useful test. Reuse accepted historical evidence only with an applicability rationale.
- [x] Freeze the comparison contract **before** candidate collection: equivalent physical input/census and oracle placement; ordinary ACK/durable opt-up; phase/cold/warm boundaries; size/churn shape; concurrency; exact flags; paired repetitions/order/noise/exclusion policy; material speed/memory improvement and regression criteria based on baseline variance. Memory bounds should describe work/owner lifetimes and scaling, not an invented user-facing capacity cap.
- [x] Revise the parent and #5015/#5016 live bodies to **select, narrow, defer or retire** each mechanism with evidence. Name the accepted deliverable, acceptance owner, code/conflict surfaces, test-first invariant, documentation owner, dependencies and eligible successors for selected work. Preserve exact-root/reopen/CRC/lifetime gates and map every remaining product obligation. Add a child only when a separately owned required seam is discovered.
- [x] Verify the actual live revisions and timestamps/links, parent/child edges, acyclicity, preserved historical evidence and absence of duplicated gates. Record coordinator acceptance and source/evidence identities. This issue then finishes `completed`; it needs no synthetic PR.

Classification: performance-objective investigation, with a **non-PR acceptance check**, not an implementation red-test requirement. If it produces code intended to land, that code follows the normal coherent PR packet and current repository policy. Negative or inconclusive findings can complete this inquiry only when their next decision and remaining owners are recorded; they leave the parent's speed/memory outcome open. A diagnostic time box stops that probe, not the product sprint.


## Accepted output

Coordinator accepts the source-bound investigation and verified ticket revisions at https://github.com/snissn/gomap/issues/5029#issuecomment-6001679661. #5015 and #5016 are selected/narrowed; #5031 owns the measurement seam. The frozen noise formula and commands precede candidate collection; numeric baseline envelopes and product outcomes remain downstream gates. This completes the issue-update deliverable, not the parent improvement.
