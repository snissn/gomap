# R5015 / R5037 producer-history source inquiry v1

Source: `9011f52f0c7f12346254a5dbf41461ae9b4af943`, inspected only through Git objects in `/private/tmp/gomap-qs-5015`. This is source inquiry acceptance only; no runtime selection or campaign conclusion. The supplied 13-entry public FlushAll/Checkpoint observation was not remeasured. Native111 original114/114 remains untouched; Linux111/185 and held #5004/PR5006 were excluded. Adjacent c9f85 fallback-count reuse is outside this source binding and is not a history mechanism.

## Finding

**No inspected existing owner-backed mutable cross-publication content-sync certificate qualifies.** The canonical physical identity/lifetime seam exists in `valuelog.Manager.files[fileID] -> *File`; actual appends and physical writer sync are owned by `valuelog.Writer`, serialized by the caching lane. A successful publication token sync currently sends no successful durability cut back to either owner. Safe retention at an existing owner is conceivable, but safety is **UNKNOWN** until that owner can prove the required writer, epoch, namespace and lifetime contract. This inquiry does not propose an implementation, registry, API, hooks, skip rule or fanout.

## Finite actual path and ownership

Line references below are all at the source SHA above, under TreeDB/.

- `db/durable_root_runtime.go:1172-1245`: ordinary complete capture takes `CurrentSubsetNoRefresh`, rejects missing/zombie handles, classifies the reserved leaf lane, and calls `Manager.StableResourceToken` with generation=`fileID`. Ordinary registrations supply no RID membership or prior content certificate.
- `internal/valuelog/stable_resource.go:228-255`: manager capture holds `m.mu.RLock`, fixes the registry and exact `m.files[fileID].File`, then calls `stableValueLogResourceToken(..., false)`. `1782-1807` derives the current byte frontier from the open file and privately canonicalizes supplied RIDs. Current size is a capture frontier, not successful-sync evidence.
- `internal/valuelog/manager.go:47-73,1409-1455`: `*File` retains immutable registered physical/parent identities, namespace, deletion admission and borrower state. Manager owns membership under `mu`. Neither struct contains a successful content cut, exact synced RID set or content mutation/rollback epoch.
- `internal/valuelog/writer.go:88-142,2720-2738`: Writer owns the writable descriptor, fileID, accepted size, buffers and sync primitive. Sync flushes first and propagates physical failure; it does not retain a successful cut. This is the actual producer-side content seam, distinct from Manager's identity/deletion ownership.
- `caching/stable_leaf_resource.go:209-241` captures the current outer-leaf writer; `internal/valuelog/stable_resource.go:1651-1664,1732-1734` explicitly drains bytes without fsync and starts ordinary tokens uncertified.
- `internal/rootpublication/resource_physical_union.go:3-11` borrows exact tokens while candidates retain ownership. `resource_set.go:4115-4138` syncs the greatest coalesced frontier per entry, attempts every entry and joins errors. Coalescing/borrowing is already present; it supplies no historical content success.
- `internal/rootpublication/resource_token.go:555-579,748-794`: default physical barrier is `stableio.SyncFile`. Constructor `ContentSynced` seeds a private certificate. Successful `syncThrough` updates metrics only, **not** `syncedFrontier` or producer state. Exact coverage checks bytes, LSN and RID subset membership; equal maxima/count/bounds cannot replace exact membership.

## Existing near-misses and smallest discriminators

1. **Lane materialization history, limited scope:** `caching/db.go:2623-2647` records fileID, lane sequence and writer size after successful materialization sync. `caching/value_log_appender.go:370-387` reuses it only while `l.syncing` remains reserved and file/sequence/size remain unchanged, for command-WAL external-reference ordering. This is real owner-held success history, but it is not Manager-backed, carries no exact RID membership/physical identity/namespace/content epoch, and is not consumed by ordinary public resource capture. It does not qualify across public publications.
2. **Synced rotation token:** `internal/valuelog/stable_resource.go:1925-1933` performs actual old-file sync before certifying the closed token. This certifies that captured token's exact frontier; it is not retained canonical producer content history for a later Manager recapture.
3. **Apply family:** `stable_resource.go:1667-1729` keeps one writer, descriptor, fileID and exact registration for a joined private Apply attempt; it rejects regressing frontiers. Its comment explicitly excludes capture history. `resource_token.go:685-714` excludes already-synced family tokens. Descriptor/family reuse is not sync history.
4. **Namespace history:** `rootpublication/pin_registry.go:449-518` retains checked parent/child/name durability, removes an older child at the same parent/name, and can forget an exact link. `valuelog/stable_resource.go:461-502` reuses this exact namespace proof. This qualifies as structural link history only, not content history.

The smallest existing owner-local discriminator is exact `*File` membership under Manager's mutex; for the producer family it is Writer + exact `*os.File` + fileID + exact registration. Physical `StableIdentity` with logical generation distinguishes rebound identities; registered parent identity/name distinguishes namespace. **No inspected existing scalar combines these with a content mutation/rebind/rollback epoch.** FileID, path, size, metrics and capture flags alone are insufficient. No truncate/rollback content operation or corresponding epoch was found in the inspected Writer/Manager/caching capture paths; coverage of all external writers or same-length mutation is **UNKNOWN**, not proof of absence throughout TreeDB.

## Correctness and lifecycle requirements, not implementation

A qualifying owner claim would have to record only a successful barrier on its exact retained handle, with byte/LSN coverage and privately owned exact RID membership tied to the same physical/logical generation and validated namespace. It must remain valid across appends only for covered immutable bytes/RIDs; truncate, rewrite, rollback, handle replacement, namespace rebound or uncertain ownership must invalidate or fail closed. A failure cannot advance that resource's cut. Per-resource success during a later partial failure is distinguishable from publication success and must not turn meta/root publication failure into success.

Existing borrower/Close contract is concrete: `manager.go:2302-2317,2480-2497` increments/decrements File leases; `2672-2695` eviction rejects refs or deletion admissions and detaches the exact owner before close. `1842-1889` Close blocks new deletion work, joins admitted workers outside `mu`, unobserves/closes files and clears membership. Tokens duplicate exact handles (`resource_token.go:392-393`) and own pins independently; owner teardown must not leave a mutable history callback targeting a released/rebound owner. Retirement parent borrowing (`valuelog/stable_resource.go:804-835`) survives existing borrows but rejects new borrows after release. Failed physical deletion retains the exact zombie and observation for retry (`748-771`). Stable rotation retries require the identical pending successor (`1918-1923`); old-close fail-stop and cleanup are separate from any content success.

Publication retry/ambiguity also stays separate: `db/root_publication_activation.go:1300-1354` runs resources, index and meta barriers; pre-mutation failures are retryable, post-mutation failure is ambiguous/poisoned. A content certificate alone cannot certify this publication.

**Index/custom barriers excluded from ordinary-file inference:** `db/stable_resource.go:367-371,466-477` uses `Pager.SyncIndexDataWithStableFile` and captures the index uncertified. `root_publication_activation.go:1313-1323` separately syncs index data and target meta pages. Byte-frontier history cannot prove same-length mapped-page/index modifications, and arbitrary custom SyncThrough semantics require their own producer contract.

## Existing tests and discriminating source question

Inspected test source, not executed:

- `caching/value_log_appender_test.go:17-136`: retained reservation reuse; growth, reservation release, rotation and failure fallback.
- `rootpublication/resource_contract_test.go:1246,1280,1401,1452-1558`: greatest frontier, preserved constructor certificate, unsynced child, advanced frontier and sparse RID coverage (including same bounds/different member).
- `valuelog/stable_resource_supported_test.go:398-403` and `stable_pending_successor_supported_test.go:47,161,225,528,691,754`: retained identities/observations, exact-successor retry, Close, replacement rejection and close fail-stop.

Discriminating source question for #5099: **Which existing producer-owned object receives publication's successful physical sync and remains the single serialized authority for that exact File/Writer generation through every append, rebind, rollback and owner Close, while retaining validated exact RID membership?** At this SHA the ordinary Manager capture + token path has no such receiver or complete discriminator. Existing tests establish narrower contracts; none of the inspected tests establishes a Manager-backed mutable cross-publication certificate. That missing source evidence is the boundary; no runtime experiment was selected.
