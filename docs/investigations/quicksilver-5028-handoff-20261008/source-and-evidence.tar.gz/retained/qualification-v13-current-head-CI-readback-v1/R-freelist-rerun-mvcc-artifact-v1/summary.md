## TreeDB MVCC raw-path gate

- verdict: **FAIL**
- measured threshold observation: **FAIL**
- baseline: `2d6b07f58902537cfe8d2b3e3a8c3c9ba0f3c07c`
- candidate: `01ad34afed6d64f58d8504a57a247170289e4772`
- samples: 8 per revision, benchmark-group-paired alternating AB/BA order
- timing acceptance: median paired candidate/base relative delta <= 5% (base/head medians remain reported for context)
- allocs/op threshold: candidate median must not increase
- B/op jitter threshold: candidate median may increase by at most the smaller of 1% or 64 B; zero-B baselines remain strict

| Package | Baseline SHA-256 | Candidate SHA-256 | Relation |
| --- | --- | --- | --- |
| db | `eab5524a80f571c3312546226dec720291addaeb58028c4a7b65314e03d5b5ce` | `fd6f0ac8fa0d9e40c1ebb959efab2af9f2147b330c6bbc73cacf0101e2f8b867` | DIFFERENT |
| caching | `e8e42e18ac556837c779e5395da585f44add7d123126ba0996f7a044fd7eb827` | `63c1d93bb98fae952eb360a740fda909386cc05a8e97da3528ce29db7f9515f3` | DIFFERENT |
| treedb | `5034eefe8548d3cb9cc2c34022ed41054fce4745d7dbd75321dc255218805c26` | `648bf64a3171e6f96225f9856b50c5c5e12b5f61fdfd73e20f300bd6c4a9497c` | DIFFERENT |

| Benchmark | Binary | Base ns/op | Head ns/op | Median delta | Paired delta | Base B/op | Head B/op | B tolerance | Base allocs/op | Head allocs/op | Measured | Attribution | Acceptance |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- | --- |
| BenchmarkGetVersioned | db DIFFERENT | 460.600 | 448.200 | -2.69% | -3.39% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkConditionalTxnBaselineBatchWrite | db DIFFERENT | 84834.000 | 81947.000 | -3.40% | -3.08% | 152744.000 | 130596.000 | 64.000 | 281.000 | 235.000 | PASS | CANDIDATE | PASS |
| BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek | treedb DIFFERENT | 232.200 | 242.100 | +4.26% | +5.43% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | FAIL | CANDIDATE | FAIL |
| BenchmarkRepeatedIterator | caching DIFFERENT | 300.750 | 302.100 | +0.45% | +0.36% | 112.000 | 112.000 | 1.120 | 2.000 | 2.000 | PASS | CANDIDATE | PASS |
| BenchmarkPublicCommandWALDurableTinyBatchWriteSync/placement=inline/shape=dirty_batch/ops=1 | treedb DIFFERENT | 230784.500 | 229526.500 | -0.55% | -1.58% | 4578.000 | 4578.000 | 45.780 | 17.000 | 17.000 | PASS | CANDIDATE | PASS |
