## Go Test Timing Summary

| elapsed_s | result | package | test |
| ---: | --- | --- | --- |
| 53.98 | pass | `github.com/snissn/gomap/TreeDB` | `TestDeferredVectorBuildMaintenanceFinalizeDebtAndFailureSemantics` |
| 27.45 | pass | `github.com/snissn/gomap/TreeDB` | `TestReopenVerify_AdaptiveLeafEncoding_MixedEncodingPages` |
| 22.29 | pass | `github.com/snissn/gomap/TreeDB` | `TestCrashRecovery_DeleteRangeWithoutTrailingSync_ReplaysCorrectKeys` |
| 19.67 | pass | `github.com/snissn/gomap/TreeDB` | `TestCOWPublicCompressedDictionaryAndPhysicalPinLifetime` |
| 16.72 | pass | `github.com/snissn/gomap/TreeDB/db` | `TestIndexVacuumTriggerReportContextCancelsCollectionWalk` |
| 16.39 | pass | `github.com/snissn/gomap/TreeDB` | `TestCOWPublicModeledStableImageCheckpointAndNoWALVolatileAck` |
| 15.38 | pass | `github.com/snissn/gomap/TreeDB` | `TestPowerLossCertificationGroupedDependencyFailurePublicReopen` |
| 14.29 | pass | `github.com/snissn/gomap/TreeDB` | `TestCrashRecovery_DeleteRangeWithoutTrailingSync_ReplaysCorrectKeys/wal_on_relaxed` |
| 13.12 | pass | `github.com/snissn/gomap/TreeDB/db` | `TestCompactIndex_AllocatesNewPagesByAppending` |
| 12.82 | pass | `github.com/snissn/gomap/TreeDB` | `TestReopenVerify_IndexColumnarLeaves` |
| 11.25 | pass | `github.com/snissn/gomap/TreeDB` | `TestCOWPublicCompressedDictionaryAndPhysicalPinLifetime/command_wal_relaxed` |
| 11.14 | pass | `github.com/snissn/gomap/TreeDB/internal/powerlosscert` | `TestBuildTestBinariesUsesPrivateExactSHACheckout` |
| 10.85 | pass | `github.com/snissn/gomap/TreeDB` | `TestDeferredVectorBuildMaintenanceConcurrentWorkerAndLifecycle` |
| 10.41 | pass | `github.com/snissn/gomap/TreeDB` | `TestReopenEmptyKeyNilValueValueLogPointer` |
| 9.06 | pass | `github.com/snissn/gomap/TreeDB` | `TestReopenVerify_WALOn_Checkpoint_LeafPagesInValueLog` |
| 8.98 | pass | `github.com/snissn/gomap/TreeDB` | `TestReopenVerify_WALOn_WriteSync` |
| 8.84 | pass | `github.com/snissn/gomap/TreeDB` | `TestOpenFreshCompositeCloseReopenPreservesValue` |
| 8.05 | pass | `github.com/snissn/gomap/TreeDB` | `TestCOWPublicModeledStableImageCheckpointAndNoWALVolatileAck/command_wal_durable` |
| 8.04 | pass | `github.com/snissn/gomap/TreeDB` | `TestCOWPublicCompressedDictionaryAndPhysicalPinLifetime/command_wal_durable` |
| 8.03 | pass | `github.com/snissn/gomap/TreeDB` | `TestCOWPublicModeledStableImageCheckpointAndNoWALVolatileAck/command_wal_relaxed` |
| 8.00 | pass | `github.com/snissn/gomap/TreeDB` | `TestCrashRecovery_DeleteRangeWithoutTrailingSync_ReplaysCorrectKeys/durable_default` |
| 7.84 | pass | `github.com/snissn/gomap/TreeDB` | `TestBackgroundIndexVacuumDisabledIntervalStartsNoWorker` |
| 7.82 | pass | `github.com/snissn/gomap/TreeDB` | `TestSnapshotIteratorSeekAfterReopen` |
| 7.77 | pass | `github.com/snissn/gomap/TreeDB` | `TestPublicCommandWALRawKVEmptyPointKeyAndZeroLengthValues` |
| 7.74 | pass | `github.com/snissn/gomap/TreeDB` | `TestOpen_DefaultsToCommandWALDurableResolvedProfile` |

## Package Results

| elapsed_s | result | package |
| ---: | --- | --- |
| 304.09 | pass | `github.com/snissn/gomap/TreeDB` |
| 37.37 | pass | `github.com/snissn/gomap/TreeDB/db` |
| 18.45 | pass | `github.com/snissn/gomap/TreeDB/internal/raftharness` |
| 17.44 | pass | `github.com/snissn/gomap/TreeDB/internal/powerlosscert` |
| 1.51 | pass | `github.com/snissn/gomap/TreeDB/internal/powerlossreopen` |
| 0.28 | pass | `github.com/snissn/gomap/TreeDB/mongo_gateway/fastclient` |
| 0.24 | pass | `github.com/snissn/gomap/TreeDB/tree` |
| 0.17 | pass | `github.com/snissn/gomap/TreeDB/internal/vectorops` |
| 0.10 | pass | `github.com/snissn/gomap/TreeDB/collections/embedding` |
| 0.08 | pass | `github.com/snissn/gomap/TreeDB/internal/bulk` |
| 0.03 | pass | `github.com/snissn/gomap/TreeDB/internal/lockfile` |
| 0.03 | pass | `github.com/snissn/gomap/TreeDB/cmd/treedb_v4_production_gate` |
| 0.00 | skip | `github.com/snissn/gomap/TreeDB/cmd/power_loss_certify` |
| 0.00 | skip | `github.com/snissn/gomap/TreeDB/internal/cowbench` |
| 0.00 | skip | `github.com/snissn/gomap/TreeDB/internal/stableio` |

## Tests Still Running At Log End

- none
