package db

import (
 "bytes"
 "context"
 "crypto/sha256"
 "fmt"
 "io"
 "os"
 "testing"
 "time"

 batchpkg "github.com/snissn/gomap/TreeDB/batch"
 "github.com/snissn/gomap/TreeDB/internal/leafrefscan"
 "github.com/snissn/gomap/TreeDB/internal/rootpublication"
 "github.com/snissn/gomap/TreeDB/internal/valuelog"
 "github.com/snissn/gomap/TreeDB/node"
 "github.com/snissn/gomap/TreeDB/page"
)

// This fixture changes only the producer's physical append sequence. It
// never injects manifest membership or substitutes the compatibility view.
func TestExternalManifestWriterACKCoverage(t *testing.T) {
 for _, path := range []string{"serialized", "queued", "build-group"} {
  for _, order := range []string{"ascending", "present-lower-sequence"} {
   t.Run(path+"/"+order, func(t *testing.T) {
    dir := t.TempDir()
    enableCommandWALFormat(t, dir)
    opts := Options{Dir:dir, CommandWAL:true, Durability:DurabilityDurable,
      IndexOuterLeavesInValueLog:true, DisableBackgroundPrune:true}
    database, err := Open(opts)
    if err != nil { t.Fatal(err) }
    defer func(){ if database != nil { _ = database.Close() } }()
    primeSegment,primeWriter:=openLeafPageLogTestWriter(t,LeafLogDirPath(dir),rewriteLeafLogLaneID,10)
    leafLog := &multiReportedLeafPageLog{appendSegment:primeSegment,writer:primeWriter,currentSegments:[]LeafPageLogSegment{primeSegment},createdSegments:[]LeafPageLogSegment{primeSegment}}
    defer leafLog.Close()
    database.SetLeafPageLog(leafLog)
    key := func(i int) []byte { return []byte(fmt.Sprintf("manifest-key-%04d-%0120d",i,i)) }
    value := bytes.Repeat([]byte("v"),32)
    publish := func(first, count int) {
     entries := make([]batchpkg.Entry,count)
     for i := range entries { entries[i] = batchpkg.Entry{Type:batchpkg.OpPut,Key:key(first+i),Value:value} }
     lsn, err := database.AppendRawKVCommandWALOrderedEntries(entries,true)
     if err != nil || lsn == 0 { t.Fatalf("real command frame lsn=%d err=%v",lsn,err) }
     var group *RootPublicationBuildGroup
     parts := 1
     if path == "build-group" {
      group, err = database.BeginRootPublicationBuildGroup()
      if err != nil { t.Fatal(err) }
      defer group.Close()
      parts = 2
     }
     for part:=0;part<parts;part++ {
      b := database.NewPhysicalBatch().(*Batch)
      start, end := part*count/parts,(part+1)*count/parts
      for _,e := range entries[start:end] { if err:=b.Set(e.Key,e.Value);err!=nil { _=b.Close();t.Fatal(err) } }
      final := part == parts-1
      if final { if err:=b.SetCommandWALPublish(lsn,[]CommandWALLSNRange{{First:lsn,Last:lsn}});err!=nil { _=b.Close();t.Fatal(err) } }
      if group != nil { if err:=b.SetRootPublicationBuildGroup(group,final);err!=nil { _=b.Close();t.Fatal(err) } }
      if path == "serialized" { err=b.writeSerialized(true,b.commandWALPublishIntent,database.assignBatchEntryRevisions(b.batch),nil)
      } else if final { err=b.WriteSync() } else { err=b.Write() }
      closeErr := b.Close()
      if err != nil || closeErr != nil { t.Fatalf("writer err=%v close=%v",err,closeErr) }
     }
     if group != nil { if err:=group.Close();err!=nil { t.Fatal(err) } }
     if got:=database.State().AppliedCommandLSN;got!=lsn { t.Fatalf("ACK AppliedCommandLSN=%d want %d",got,lsn) }
     if database.rootPublication != nil {
      ctx,cancel:=context.WithTimeout(context.Background(),5*time.Second)
      err=database.rootPublication.coordinator.WaitThrough(ctx,database.currentCommitSeq())
      cancel()
      if err!=nil { t.Fatalf("join existing root publication after ACK: %v",err) }
     }
    }
    // Prime real predecessor membership using actual writes and producer registration.
    publish(0,128)
    qsv13CheckExternalManifestWriterRoots(t,database,"prime-ACK")
    if err:=leafLog.writer.Close();err!=nil { t.Fatal(err) }
    lane,seq:=uint32(rewriteLeafLogLaneID),uint32(11)
    if order=="present-lower-sequence" { seq=9 }
    segment,writer:=openLeafPageLogTestWriter(t,LeafLogDirPath(dir),lane,seq)
    leafLog.appendSegment,leafLog.writer=segment,writer
    leafLog.currentSegments=[]LeafPageLogSegment{segment}
    leafLog.createdSegments=append(leafLog.createdSegments,segment)
    publish(128,128)
    qsv13CheckExternalManifestWriterRoots(t,database,"new-producer-ACK")
    // A later ACK diagnoses a one-publication lag without manufacturing mappings.
    publish(256,2)
    qsv13CheckExternalManifestWriterRoots(t,database,"same-producer-next-ACK")
    if err:=database.Close();err!=nil { t.Fatal(err) };database=nil
    if err:=leafLog.Close();err!=nil { t.Fatal(err) }
    opts.ReadOnly=true
    reopened,err:=Open(opts)
    if err!=nil { t.Fatalf("ReadOnly reopen: %v",err) }
    defer reopened.Close()
    qsv13CheckExternalManifestWriterRoots(t,reopened,"ReadOnly-reopen")
    ctx,cancel:=context.WithTimeout(context.Background(),5*time.Second)
    stats,censusErr:=reopened.LeafGenerationGC(ctx,LeafGenerationGCOptions{DryRun:true})
    cancel()
    if censusErr!=nil { t.Errorf("unchanged ReadOnly DryRun census: %v (raw stats=%+v; UNKNOWN on error)",censusErr,stats) }
    for i:=0;i<258;i++ { got,err:=reopened.Get(key(i));if err!=nil||!bytes.Equal(got,value) { t.Fatalf("reopen key%d value=%q err=%v",i,got,err) } }
   })
  }
 }
}

// Freeze writer publication while inspecting each slot's own retained authority.
// The verifier callback supplies the actual containing pager page for each ptr.
func qsv13CheckExternalManifestWriterRoots(t *testing.T, database *DB, phase string) {
 t.Helper()
 database.writeMu.Lock()
 defer database.writeMu.Unlock()
 database.durablePublishMu.Lock()
 defer database.durablePublishMu.Unlock()
 idx:=database.idx.Load()
 for slot,record:=range database.durableRoot.slotRecord {
  if record.CommitSeq==0 { continue }
  resources:=database.durableRoot.slotResources[slot]
  if resources==nil { t.Errorf("%s slot%d commit%d lacks resources",phase,slot,record.CommitSeq);continue }
  var token *rootpublication.StableResourceToken
  for _,candidate:=range resources.Tokens() {
   if candidate.Kind()!=rootpublication.ResourceOuterLeafManifest { continue }
   if token!=nil { t.Errorf("%s slot%d multiple manifest tokens",phase,slot);return };token=candidate
  }
  if token==nil { t.Errorf("%s slot%d commit%d lacks manifest token",phase,slot,record.CommitSeq);continue }
  // Only exact pinned frontier bytes; never read manifest.json or newest filename.
  var data []byte
  err:=token.WithPinnedFile(func(file *os.File) error {
   var e error;data,e=io.ReadAll(io.NewSectionReader(file,0,int64(token.Frontier().Bytes)));return e
  })
  if err!=nil||uint64(len(data))!=token.Frontier().Bytes||sha256.Sum256(data)!=token.Digest() {
   t.Errorf("%s slot%d exact manifest read/digest failed err=%v",phase,slot,err);continue
  }
  manifest,err:=decodeLeafGenerationManifest(data,token.ResourceID())
  if err!=nil||manifest.ManifestRevision!=token.Generation() { t.Errorf("%s slot%d manifest decode/revision err=%v",phase,slot,err);continue }
  t.Logf("%s slot%d commit%d manifest=%s revision%d digest=%x frontier=%d",phase,slot,record.CommitSeq,token.ResourceID(),token.Generation(),token.Digest(),token.Frontier().Bytes)
  view:=newLeafGenerationView(manifest)
  var ownerPage uint64
  seen:=0
  err=leafrefscan.WalkRoots(context.Background(),[]uint64{record.UserRootPageID,record.SystemRootPageID},idx.pager.Get,
   func(id uint64,_ node.Node) error { ownerPage=id;return nil },
   func(ptr page.LeafLogPtr) error {
    seen++
    marked:=ptr.ValueLogFileID()
    var backing *rootpublication.StableResourceToken
    for _,candidate:=range resources.Tokens() { if candidate.Kind()==rootpublication.ResourceOuterLeafLog&&candidate.Generation()==uint64(marked) { backing=candidate;break } }
    if backing==nil { t.Errorf("%s slot%d commit%d page%d ptr%+v missing raw resource",phase,slot,record.CommitSeq,ownerPage,ptr)
    } else {
     if ptr.Offset>backing.Frontier().Bytes||uint64(ptr.RecordLength())>backing.Frontier().Bytes-ptr.Offset { t.Errorf("%s slot%d ptr%+v exceeds exact resource %s frontier%d",phase,slot,ptr,backing.ResourceID(),backing.Frontier().Bytes) }
     if err:=backing.WithPinnedFile(func(f *os.File) error { info,e:=f.Stat();if e!=nil{return e};if uint64(info.Size())<backing.Frontier().Bytes{return fmt.Errorf("physical file shorter than retained frontier")};return nil });err!=nil { t.Errorf("%s slot%d exact raw backing: %v",phase,slot,err) }
    }
    if _,ok:=view.FileToGeneration[ptr.FileID];!ok {
     currentHas:=database.leafGenerationManifest.hasNonDeletedFileID(ptr.FileID)
     _,seq:=valuelog.DecodeSegmentID(ptr.FileID)
     var filtered []uint32
     var filterErr error
     if !currentHas { filtered,filterErr=database.filterLeafGenerationRegistrableRawFileIDs(database.leafGenerationManifest,[]uint32{ptr.FileID}) }
     t.Errorf("%s slot%d commit%d page%d ptr%+v manifest%d missing; currentHas=%t maxRecoveredSeq=%d ptrSeq=%d filterIfCurrentMissing=%v filterErr=%v backing=%t",phase,slot,record.CommitSeq,ownerPage,ptr,manifest.ManifestRevision,currentHas,database.leafGenerationManifest.maxNonDeletedRecoveredSeq(),seq,filtered,filterErr,backing!=nil)
    }
    return nil
   })
  if err!=nil { t.Errorf("%s slot%d root walk: %v",phase,slot,err) }
  if record.CommitSeq==database.currentCommitSeq()&&seen==0 { t.Errorf("%s fixture failed to produce outer-leaf pointers",phase) }
 }
}
