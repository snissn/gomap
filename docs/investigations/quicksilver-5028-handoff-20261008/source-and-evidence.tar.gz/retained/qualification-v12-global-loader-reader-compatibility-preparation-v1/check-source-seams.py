"""Only AST-isolated pure seams and a synthetic local library fixture; no source import/main."""
import ast, copy, hashlib, json, pathlib, re, tempfile
P=pathlib.Path(__file__).resolve().parent; B=P.parent; F=B/'qualification-v12-fresh-controls-v1'
N=pathlib.Path('/home/mikers/quicksilver-maintenance-5028-20261006'); fresh=N/F.name; packet=N/P.name
passed=[]
def ok(name,fn):
    fn();passed.append(name)
def reject(name,fn):
    try:fn()
    except (AssertionError,ValueError,KeyError,FileNotFoundError):passed.append(name);return
    raise AssertionError('unexpected admission: '+name)
def tree(p):return ast.parse(p.read_text())
def fun(t,n):return next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name==n)
def run(nodes,env):exec(compile(ast.fix_missing_locations(ast.Module(body=copy.deepcopy(nodes),type_ignores=[])),'<isolated-exact-AST>','exec'),env)
def req(v,m):
    if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
# Reversal and all retained function ASTs are checked independently here.
for row in json.loads((P/'exact-deltas-and-reversal.json').read_text())['sources']:
    inp=pathlib.Path(row['input']);out=pathlib.Path(row['output']);a=inp.read_text();z=out.read_text()
    assert sha(inp)==row['input_sha256'] and sha(out)==row['output_sha256']
    rev=z
    for e in reversed(row['edits']):
        assert rev.count(e['after'])==1;rev=rev.replace(e['after'],e['before'])
    assert rev==a
    ta,tz=tree(inp),tree(out)
    for name in row['unchanged_function_AST']:assert ast.dump(fun(ta,name))==ast.dump(fun(tz,name))
    compile(z,str(out),'exec');passed.append(out.name+' exact reversal/retained AST/compile')
# Execute only unchanged library-loop AST, with actual local symlink/regular bytes.
with tempfile.TemporaryDirectory(prefix='loader-reader-source-seam-') as td:
    root=pathlib.Path(td).resolve();target=root/'loader-target';target.write_bytes(b'isolated-loader');alias=root/'loader-alias';alias.symlink_to(target)
    digest=sha(target);libs={str(alias):dict(resolved=str(target),sha256=digest)}
    oldmain=fun(tree(F/'verify-qualification-v10-deployment-v1.py'),'main');newmain=fun(tree(F/'verify-qualification-v10-deployment-v2.py'),'main')
    loop=lambda m:next(x for x in m.body if isinstance(x,ast.For) and ast.unparse(x.iter)=='libraries.items()')
    bind=next(x for x in newmain.body if isinstance(x,ast.Assert) and "anchor['runtime_loader_bindings']" in ast.unparse(x.test))
    def case(nodes,libraries=None,files=None,binding=None):
        run(nodes,dict(Path=pathlib.Path,re=re,sha=sha,libraries=copy.deepcopy(libs if libraries is None else libraries),anchor_files={str(target):digest} if files is None else files,anchor=dict(runtime_loader_bindings=copy.deepcopy(libs if binding is None else binding))))
    reject('original V1 canonical-only anchor reproduces loader-key KeyError',lambda:case([loop(oldmain)]))
    ok('frozen V2 exact loader alias/canonical target admits',lambda:case([bind,loop(newmain)]))
    reject('frozen V2 binding map drift denied',lambda:case([bind,loop(newmain)],binding={}))
    reject('frozen V2 canonical target digest drift denied',lambda:case([bind,loop(newmain)],files={str(target):'0'*64}))
    bad=copy.deepcopy(libs);bad[str(alias)]['resolved']=str(root/'other')
    reject('frozen V2 rebound target denied',lambda:case([bind,loop(newmain)],libraries=bad,binding=bad,files={str(root/'other'):digest}))
    bad=copy.deepcopy(libs);bad[str(alias)]['sha256']='x'*64
    reject('frozen V2 malformed digest denied',lambda:case([bind,loop(newmain)],libraries=bad,binding=bad))
    target.write_bytes(b'drift')
    reject('frozen V2 actual bytes drift denied',lambda:case([bind,loop(newmain)]))
# The unchanged original commands function supplies the exact order, argv and limits.
dt=tree(P/'collection-native-driver-v12-v3.py');ot=tree(F/'collection-native-driver-v12-v2.py')
for phase in ('small','calibration-rest','pairs'):
    e=dict(GRID=['g0','g1','g2','g3','g4']);run([fun(dt,'commands')],e)
    old=dict(GRID=e['GRID']);run([fun(ot,'commands')],old)
    args=(phase,{'R':{'path':'/R'},'B':{'path':'/B'}},{'path':'/activation','sha256':'a'*64})
    assert e['commands'](*args)==old['commands'](*args);passed.append('unchanged commands '+phase)
assert [x[0] for x in e['commands'](*args)]==['R-offline-pairs','B-offline-pairs','B-online-pairs']
assert [x[2] for x in e['commands'](*args)]==[86400]*3
main=fun(dt,'main');phasegate=next(x for x in main.body if isinstance(x,ast.Assert) and ast.unparse(x.test)=="phase == 'pairs'")
ok('new driver admits pairs only',lambda:run([phasegate],dict(phase='pairs')))
for phase in ('small','calibration-rest','final-evaluate','unknown'):reject('new driver rejects '+phase,lambda phase=phase:run([phasegate],dict(phase=phase)))
oldD=fresh/'collection-native-driver-v12-v2.py';oldG=fresh/'global54-artifact-guard-v12-operational-v1.py';newD=packet/'collection-native-driver-v12-v3.py';newG=packet/'global54-artifact-guard-v12-operational-v2.py';sel=fresh/'deployment-helpers-selection.json'
D='aa98083ab9ab2b19cb1bc90ecd562ec2c9e49314fafb28f2f3d8035bbb06bbe8';G='3afb3b02c11d7138cc9846489d34b39aa346333a8660dfb0f5e2ddf5daa359b6';S=sha(F/'deployment-helpers-selection.json');ND=sha(P/newD.name);NG=sha(P/newG.name)
historical={str(oldD):D,str(oldG):G,str(sel):S};current={**historical,str(newD):ND,str(newG):NG}
oldasserts=[x for x in main.body if isinstance(x,ast.Assert) and "anchor['files']" in ast.unparse(x.test)]
def driver_history(files):run(oldasserts,dict(Path=pathlib.Path,HERE=fresh,anchor=dict(files=files),sha=lambda p:S))
ok('driver immutable calibration excludes future reader and admits historical refs',lambda:driver_history(historical))
for path in (oldD,oldG,sel):
    bad={**historical,str(path):'0'*64};reject('driver historical digest drift '+path.name,lambda bad=bad:driver_history(bad))
# Raw admission is evaluated as its exact single identity/source-closure require statement.
rt=tree(P/'root-final-raw-closure-v12-v4.py');pf=fun(rt,'paired_receipts')
closure=next(x for x in pf.body if isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and x.value.func.id=='require' and x.value.args[-1].value=='current selected driver/selector/guard source closure drift')
def rawcheck(h,c,driver=None,guard=None):run([closure],dict(require=req,BASE=N,selection_path=sel,CALIBRATION_DRIVER_SHA=D,CALIBRATION_GUARD_SHA=G,HELPER_SELECTION_SHA=S,PAIR_DRIVER_SHA=ND,OPERATIONAL_GUARD_SHA=NG,calibration_anchor=dict(files=h),current=dict(files=c),driver=dict(path=str(newD)) if driver is None else driver,guard=dict(path=str(newG)) if guard is None else guard))
ok('raw split source identities admit no future driver in historical anchor',lambda:rawcheck(historical,current))
for path in (oldD,oldG,sel):
    bad={**historical,str(path):'0'*64};reject('raw historical drift '+path.name,lambda bad=bad:rawcheck(bad,current))
for path in (newD,newG,sel):
    bad={**current,str(path):'0'*64};reject('raw current drift '+path.name,lambda bad=bad:rawcheck(historical,bad))
reject('raw old driver substituted for current reader',lambda:rawcheck(historical,current,driver=dict(path=str(oldD))))
reject('raw old guard substituted for current reader',lambda:rawcheck(historical,current,guard=dict(path=str(oldG))))
assigns={x.targets[0].id:x for x in pf.body if isinstance(x,ast.Assign) and isinstance(x.targets[0],ast.Name)}
env=dict(BASE=N);run([assigns['expected_parent'],assigns['selection_path']],env)
assert env['expected_parent']==fresh/'collection-driver-pairs-v12' and env['selection_path']==sel;passed.append('raw explicit original receipt and selection directories')
# Dynamic ownfile is still checked by original guard validate_input; no helper registry insertion.
gt=tree(P/'global54-artifact-guard-v12-operational-v2.py');check=fun(gt,'check')
text=ast.unparse(check)
assert "verify-qualification-v10-deployment-v2.py" in text and "verify-qualification-v10-deployment-v1.py" not in text
assert '11246d9d5f2e50711ae178b3b2acb2938f7400060e7f77efc1ff9293c76d52fc' in text
assert "inv.local(Path(__file__))" in text
passed.append('guard frozen verifier V2 selection and ownfile inventory retained')
# Actual source-only observation of the selected historical anchor fields, no file-map replay.
anchorpath=B/'qualification-v12-refresh/qualification-v10-prospective-root-v1/post-small-source-anchor.accepted-v1.json'
a=json.loads(anchorpath.read_bytes());assert all(a['files'].get(k)==v for k,v in historical.items())
assert a['files'].get(str(fresh/'verify-qualification-v10-deployment-v2.py'))==sha(F/'verify-qualification-v10-deployment-v2.py')
assert str(newD) not in a['files'] and str(newG) not in a['files'];passed.append('genuine frozen historical anchor contains original readers and verifier V2 only')
with (P/'isolated-checks.json').open('x') as out:json.dump(dict(source_only=True,campaign_modules_executed=False,native_execution=False,checks=passed,count=len(passed),qualification=False,performance_accepted=False,collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False),out,indent=2);out.write('\n')
print(json.dumps(dict(count=len(passed),passed=True)))
