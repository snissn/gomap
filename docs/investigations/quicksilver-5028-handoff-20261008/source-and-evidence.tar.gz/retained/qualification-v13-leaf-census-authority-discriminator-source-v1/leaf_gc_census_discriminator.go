// Diagnostic only: classify a closed DB with the existing full recovery proof.
package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"io"
	"path/filepath"
	"regexp"
	"encoding/json"
	"fmt"
	"os"
	"time"

	backend "github.com/snissn/gomap/TreeDB/db"
)

func main() {
	if len(os.Args) != 3 {
		fmt.Fprintln(os.Stderr, "usage: leaf-gc-census-discriminator <closed-maindb-dir> <exact-manifest-read-request.json>")
		os.Exit(2)
	}
	started := time.Now()
	out := map[string]any{"scope": "post-close read-only leaf GC census", "dry_run": true, "read_only": true, "qualified": false}
	out["qualification"] = false
	out["performance_accepted"] = false
	out["product_accepted"] = false
	out["change_accepted"] = false
	out["merge_accepted"] = false
	err := census(os.Args[1], os.Args[2], out)
	out["wall_ns"] = time.Since(started).Nanoseconds()
	if err != nil {
		out["error"] = err.Error()
	}
	if encodeErr := json.NewEncoder(os.Stdout).Encode(out); encodeErr != nil {
		fmt.Fprintln(os.Stderr, encodeErr)
		os.Exit(1)
	}
	if err != nil {
		os.Exit(1)
	}
}

func census(dir, requestPath string, out map[string]any) (err error) {
	request, err := readRequest(requestPath)
	if err != nil { return err }
	cfg, exists, err := backend.LoadFormatConfig(dir)
	if err != nil {
		return err
	}
	if !exists || cfg.DurabilityProfile != backend.ProfileCommandWALDurable || !cfg.IndexOuterLeavesInValueLog {
		return fmt.Errorf("expected persisted command_wal_durable and outer-leaf format")
	}
	opts := backend.Options{Dir: dir, ReadOnly: true, ResolvedProfile: cfg.DurabilityProfile,
		CommandWAL: true, Durability: backend.DurabilityDurable, VerifyOnRead: true}
	cfg.ApplyToOptions(&opts)
	opts.ValueLog.ReadIntegrity = backend.IntegrityVerify
	out["format"] = cfg
	opened := time.Now()
	database, err := backend.Open(opts)
	out["open_wall_ns"] = time.Since(opened).Nanoseconds()
	if err != nil {
		return err
	}
	defer func() {
		if closeErr := database.Close(); closeErr != nil {
			out["close_error"] = closeErr.Error()
			if err == nil {
				err = closeErr
			}
		}
	}()
	// Discriminator errors remain explicit; the original census still runs.
	// Start the unchanged census timeout only after releasing diagnostic pins.
	discriminatorErr := discriminate(context.Background(), database, dir, request, out)
	if discriminatorErr != nil { out["discriminator_error"] = discriminatorErr.Error() }
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	scanStarted := time.Now()
	stats, err := database.LeafGenerationGC(ctx, backend.LeafGenerationGCOptions{DryRun: true})
	out["scan_wall_ns"] = time.Since(scanStarted).Nanoseconds()
	out["stats"] = stats
	// Preserve the genuine original census error as the primary error.
	if err != nil { return err }
	return discriminatorErr
}


const targetRawID uint32 = 2139095277
const targetMarkedID uint32 = 4286578925

type exactFileReference struct {
	Basename string `json:"basename"`
	Bytes int64 `json:"bytes"`
	SHA256 string `json:"sha256"`
}

type readRequestSpec struct {
	Schema int `json:"schema"`
	ImmutableManifestCandidates []exactFileReference `json:"immutable_manifest_candidates"`
	CompatibilityManifest exactFileReference `json:"compatibility_manifest"`
}

// These references authorize diagnostic reads only; they are not root-resource
// tokens, root adoption, source acceptance, or deletion authority.
func readRequest(path string) (readRequestSpec, error) {
	var q readRequestSpec
	file, err := os.Open(path)
	if err != nil { return q, err }
	defer file.Close()
	decoder := json.NewDecoder(file)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&q); err != nil { return q, err }
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF { return q, fmt.Errorf("request must contain exactly one JSON object") }
	if q.Schema != 1 || len(q.ImmutableManifestCandidates) == 0 || len(q.ImmutableManifestCandidates) > 2 {
		return q, fmt.Errorf("expected one or two explicit immutable manifest candidates")
	}
	seen := map[string]bool{}
	revisionName := regexp.MustCompile(`^manifest\.durable\.[0-9a-f]{16}\.json$`)
	for _, ref := range q.ImmutableManifestCandidates {
		if !revisionName.MatchString(ref.Basename) || seen[ref.Basename] { return q, fmt.Errorf("invalid or duplicate immutable manifest candidate") }
		seen[ref.Basename] = true
		if err := validateReference(ref); err != nil { return q, err }
	}
	if q.CompatibilityManifest.Basename != "manifest.json" { return q, fmt.Errorf("expected explicit compatibility manifest.json") }
	return q, validateReference(q.CompatibilityManifest)
}

func validateReference(ref exactFileReference) error {
	decoded, err := hex.DecodeString(ref.SHA256)
	if ref.Bytes <= 0 || err != nil || len(decoded) != sha256.Size || ref.SHA256 != hex.EncodeToString(decoded) {
		return fmt.Errorf("invalid exact diagnostic manifest reference")
	}
	return nil
}

func discriminate(ctx context.Context, database *backend.DB, dir string, request readRequestSpec, out map[string]any) error {
	d := map[string]any{
		"target_raw_id": targetRawID, "target_marked_id": targetMarkedID,
		"target_basename": "value-l255-000237.log", "held_excluded": []int{5004,5006},
		"manifest_reads_are_diagnostic_candidates": true,
		"selected_manifest_token": nil, "per_root_manifest_tokens": nil,
		"candidate_slot_association": nil, "registered_value_log_set_backing": nil,
		"missing_public_witnesses": []string{
			"per-root manifest token enumeration/identity/frontier/digest",
			"candidate immutable revision association to each viable slot",
			"target registered ValueLogSet entry/open-file/zombie/index-builder route",
			"exact root/page/offset which caused the original missing-generation error",
		},
	}
	out["discriminator"] = d
	allStats := database.Stats()
	selectedStats := map[string]string{}
	for _, key := range []string{
		"treedb.durable_root.selected_slot", "treedb.durable_root.commit_seq",
		"treedb.durable_root.durable_seq", "treedb.durable_root.record_page",
		"treedb.durable_root.user_root_page", "treedb.durable_root.system_root_page",
		"treedb.durable_root.slot0.commit_seq", "treedb.durable_root.slot1.commit_seq",
	} { if value, ok := allStats[key]; ok { selectedStats[key] = value } }
	d["selected_and_slot_stats"] = selectedStats
	// Do not retain extra inspection pins through the original GC census.
	roots, err := database.CaptureRecoverableRootSetForInspection(ctx)
	if err != nil { return err }
	d["recoverable_roots"] = roots.Roots()
	revalidateErr := roots.Revalidate()
	roots.Release()
	d["inspection_capability_released_before_census"] = true
	if revalidateErr != nil { return revalidateErr }
	d["inspection_revalidated"] = true
	canonicalDir, err := filepath.Abs(dir)
	if err != nil { return err }
	resolved, err := filepath.EvalSymlinks(canonicalDir)
	if err != nil || resolved != canonicalDir { return fmt.Errorf("diagnostic DB path must be canonical without symlink components") }
	leafDir := backend.LeafLogDirPath(canonicalDir)
	if resolvedLeaf, err := filepath.EvalSymlinks(leafDir); err != nil || resolvedLeaf != leafDir { return fmt.Errorf("diagnostic leaf directory must not contain symlinks") }
	rows := make([]map[string]any,0,len(request.ImmutableManifestCandidates))
	d["immutable_manifest_candidates"] = rows
	for _, ref := range request.ImmutableManifestCandidates {
		row, err := inspectManifest(leafDir, ref, "unassociated_immutable_candidate")
		if err != nil { return err }
		rows = append(rows,row)
		d["immutable_manifest_candidates"] = rows
	}
	compatibility, err := inspectManifest(leafDir, request.CompatibilityManifest, "compatibility_only_not_selected_authority")
	if err != nil { return err }
	d["compatibility_manifest"] = compatibility
	physical := map[string]any{}
	d["target_physical_metadata"] = physical
	for _, basename := range []string{"value-l255-000237.log", "value-l255-000237.log.lenidx"} {
		info, err := os.Lstat(filepath.Join(leafDir,basename))
		if err != nil { return err }
		if !info.Mode().IsRegular() { return fmt.Errorf("target diagnostic path is not a regular nonsymlink file: %s",basename) }
		physical[basename] = map[string]any{"bytes":info.Size(),"mode":info.Mode().String(),"mtime_ns":info.ModTime().UnixNano(),"native_identity":info.Sys(),"data_hash_claim":false}
	}
	return nil
}

func inspectManifest(leafDir string, ref exactFileReference, label string) (map[string]any,error) {
	path := filepath.Join(leafDir,ref.Basename)
	before, err := os.Lstat(path)
	if err != nil { return nil,err }
	if !before.Mode().IsRegular() || before.Size() != ref.Bytes { return nil,fmt.Errorf("manifest exact regular-file/size mismatch: %s",ref.Basename) }
	file, err := os.Open(path)
	if err != nil { return nil,err }
	defer file.Close()
	opened, err := file.Stat()
	if err != nil || !os.SameFile(before,opened) { return nil,fmt.Errorf("manifest changed while opening: %s",ref.Basename) }
	data, err := io.ReadAll(io.LimitReader(file,ref.Bytes+1))
	if err != nil { return nil,err }
	digest := sha256.Sum256(data)
	if int64(len(data)) != ref.Bytes || hex.EncodeToString(digest[:]) != ref.SHA256 { return nil,fmt.Errorf("manifest exact bytes/SHA mismatch: %s",ref.Basename) }
	var manifest struct {
		Version int `json:"version"`
		ManifestRevision uint64 `json:"manifest_revision"`
		CurrentGenerationID uint64 `json:"current_generation_id"`
		NextGenerationID uint64 `json:"next_generation_id"`
		Generations []json.RawMessage `json:"generations"`
	}
	if err := json.Unmarshal(data,&manifest); err != nil { return nil,err }
	matches := []json.RawMessage{}
	for _, raw := range manifest.Generations {
		var record struct { FileIDs []uint32 `json:"file_ids"` }
		if err := json.Unmarshal(raw,&record); err != nil { return nil,err }
		for _, id := range record.FileIDs { if id == targetRawID { matches = append(matches,raw); break } }
	}
	return map[string]any{"label":label,"reference":ref,"path":path,
		"version":manifest.Version,"manifest_revision":manifest.ManifestRevision,
		"current_generation_id":manifest.CurrentGenerationID,"next_generation_id":manifest.NextGenerationID,
		"target_generation_records":matches,"native_identity":opened.Sys(),
		"is_validated_root_token":false,"eligibility_claim":false},nil
}
