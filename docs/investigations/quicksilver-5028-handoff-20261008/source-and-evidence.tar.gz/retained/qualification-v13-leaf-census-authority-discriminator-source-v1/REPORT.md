# Public-API leaf census discriminator draft

This draft preserves the original read-only format/profile/integrity/Open/Close and public LeafGenerationGC(DryRun:true) census. It adds selected-slot stats, copied public recovery roots and exact finite diagnostic manifest reads. **Exact slot manifest tokens and target registered backing are unavailable through an externally usable discovery API; those fields stay null.** It never treats a candidate JSON file as selected recovery authority, never substitutes a compatibility view, and never classifies missing coverage as eligible. Both prior failed observations remain retained.

Frozen source is B `761e08c9eff0abadaf5bf132225f9948b83d7c57`, tree `69030ef5d37e1bca7928aed6d852589e3923141f`. Only this new packet was written; no Go/parser/test/build/native/SSH/network/DB/Git/source/state action ran. Source review/freeze/build/runtime admission belongs to root. All numerical/qualification/performance/product/change/merge flags are false; #5004/PR#5006 excluded.

## Public contract and exact limitation

`DB.Stats()` (api.go) provides `treedb.durable_root.selected_slot`, selected commit/durable seq, record page/user/system root pages and slot0/slot1 commit seq (durable_root_stats.go:28-33,56-57). `CaptureRecoverableRootSetForInspection(ctx)` is specifically supported for read-only handles (recoverable_root_set.go:116-129); `Roots()` copies exact root scalars/Visible/Durable (499-505). `Revalidate()` and `Release()` retain normal source authority/lifetime contracts. The helper captures, copies, revalidates and **releases before** its original census to avoid its own additional inspection pins affecting that census. Root labels are not converted into numbered-slot associations by guessing commit order.

Per-root resource inventories are private `rootResources`; public `CloneStableResourceForRoot` (390-409) selects an already known exact internal rootpublication selector/obligation. It cannot enumerate selectors or discover an unknown selected manifest revision. The external helper neither imports that internal package nor attempts reflection/generic type tricks, private fields, unsafe, production exports or a private test bridge. `DBState.ValueLogSet` is private; no public per-file registered/open/zombie or index-builder-source witness was found. A public token API returning an index token would not establish outer-leaf manifest coverage.

The selected immutable revision still comes from the private exact selected slot resource token (manifest_stable_prepare.go:14-60). Compatibility `manifest.json` may be ahead (manifest_store.go:385-390). Therefore `discriminator.selected_manifest_token`, `per_root_manifest_tokens`, `candidate_slot_association` and `registered_value_log_set_backing` are null with explicit missing fields. This draft alone cannot resolve the whole recovery frontier ambiguity. Root needs exact authority inventory from an already approved reader capable of exposing those retained token descriptors; do not promote these candidate reads into token proof.

## CLI/read request shape

Proposed direct CLI: `leaf-gc-census-discriminator <closed-maindb-dir> <exact-manifest-read-request.json>`; root's existing frozen builder/owned wrapper must separately bind this new source hash and frozen B source/head/tree/compiler, and retain truthful argv/PID/join/rc/streams plus metadata-before/after. No launcher or builder was created or edited.

The root-authored request is one JSON object, no unknown fields/trailing values:

```json
{
  "schema": 1,
  "immutable_manifest_candidates": [
    {"basename": "manifest.durable.0000000000000028.json", "bytes": 69079, "sha256": "<genuine SHA256 of exact file bytes>"}
  ],
  "compatibility_manifest": {"basename": "manifest.json", "bytes": 69079, "sha256": "<genuine SHA256 of exact file bytes>"}
}
```

This is explanatory shape only; placeholder strings are rejected, not an actual request or authority. Accept one or two explicit distinct immutable revision basenames (the finite slot question), never directory discovery. The actual SHA of each JSON file must be obtained by root; inventory size alone does not bind content. Canonical nonsymlink DB/leaf directory paths, nonsymlink regular manifest files, exact sizes, same opened inode and SHA256 are checked. Reads use the requested file length plus one byte, not unlimited manifest/directory scans. Immutable records retain every matching generation's raw JSON, including state/commit fields, instead of collapsing reused raw IDs. Version/revision/current/next scalars are diagnostic values, not a replacement production manifest validator. Candidate revision/name semantics remain token-unproven and explicitly labeled.

Target is fixed to raw2139095277, marked4286578925, lane255/sequence237. Only target log and `.lenidx` lstat metadata are read; no value/leaf data is hashed or scanned by the discriminator. Public registered backing remains missing. The original census traversal still runs unchanged. A discriminator error is retained separately; if original census fails its exact error remains primary. A successful census plus discriminator failure still returns nonzero; zero output cannot silently hide incomplete discrimination.

## Current metadata, without further inference

The newly retained local metadata JSON SHA is bound in source-bindings.json. Its `complete_file_sha256=f950253901d7f7b69abca11d623dde4c036dbb5d1cea1ae42cc9962184e0e174` refers to root's native complete inventory file (4034B), not to this differently sized local projection. We verified that provenance field; did not re-read native bytes. The projection reports target log33554945B, index16B and latest immutable0028/compatibility both69079B. Equal sizes do not prove equal contents or selected slot identity. The16B sidecar matches the source header size; its record count/content was not read here, so no empty-index/corruption/live-coverage conclusion is made.

## Review and remaining gate

Changes are bounded to argument/request admission, false authority fields, an additive discriminator call before the original census, and additive diagnostic helper functions. Original profile validation, read-only flags, checksum/integrity, two-minute context, DryRun options, timings/stat retention and deferred Close remain. The original two-minute census context starts after diagnostics, so diagnostic reads do not consume or extend its scan timeout. No scheduling/cap/budget/pressure/manifest/source authority changed. Go compilation and runtime validation were explicitly prohibited: this is a source draft, not a compiled or executable acceptance. Root must independently source-review and freeze it before any permitted build/run after the current R1 finite window joins.

The decisive missing witness remains the root-bound manifest token and its target mapping/state, contrasted with candidate and compatibility mappings and actual registered backing. If that cannot be supplied through an existing admitted reader, keep UNKNOWN and ask for a separately reviewed narrow read-only token descriptor witness rather than relax the census or expose broad mutable internals. This packet grants no implementation or collection authority.
