import pathlib,json,subprocess,hashlib,os,re,time
HERE=pathlib.Path(__file__).resolve().parent;BASE=HERE.parent
block=(HERE/'current-block.md').read_text()
heads={'5037':'01ad34afed6d64f58d8504a57a247170289e4772','5054':'761e08c9eff0abadaf5bf132225f9948b83d7c57'}
def api(path,label,method='GET',payload=None):
 argv=['gh','api','repos/snissn/gomap/'+path]
 if method!='GET':
  f=HERE/(label+'-request.json');f.write_text(json.dumps(payload)+'\n');argv+=['--method',method,'--input',str(f)]
 r=subprocess.run(argv,capture_output=True);(HERE/(label+'.json')).write_bytes(r.stdout);(HERE/(label+'.stderr')).write_bytes(r.stderr);assert r.returncode==0,(label,r.returncode)
 return json.loads(r.stdout)
results=[]
for n in [5028,5015,5016,5030]:
 label='issue-'+str(n);endpoint='issues/'+str(n);before=api(endpoint,label+'-before');assert before['state']=='open';body=before['body'];assert body.startswith('## Current execution checkpoint v87\n')
 next_block=body.index('## Current execution checkpoint v85');replacement=block+'\n'+body[next_block:]
 api(endpoint,label+'-patch','PATCH',{'body':replacement});after=api(endpoint,label+'-readback');assert after['body']==replacement and after['state']=='open';results.append(dict(target=after['html_url'],readback=label+'-readback.json',sha256=hashlib.sha256((HERE/(label+'-readback.json')).read_bytes()).hexdigest(),verified=True))
prtext={
'5037':"""Ordinary root publication rebuilt physical value-log closure from tree contents and repeatedly copied scratch/freelist state. This change carries exact guarded resource descriptors through publication, retains conservative fallback for uncovered recovery roots, reuses attempt-private scratch and the selected transaction-owned freelist path within a chunk. Allocator staging/materialization revoke private-path ownership before branches can share it.

Recovery closure, both durable slots, pending/ambiguous roots, dictionary and cross-lane resources, optimistic conflict handling, checksums and durable ACK remain gates. Persistent value-log segments are reclaimed only after exact reachability and lifetime protection allow it.

Current head: `01ad34afed6d64f58d8504a57a247170289e4772`. Independent source review and exact Linux Go1.26.3 affected normal/race checks pass. The source-bound 3M service profile joined and identifies empty memtable replacement as avoidable allocation; two constructor changes were retired for populated-table timing regressions. A controller-level empty snapshot-rotation experiment is in progress and is not yet part of this head. The unchanged MVCC snapshot-seek CI gate failed twice (+5.02% and +5.428% paired against5%); cause is unresolved. Separate seek/code-generation diagnostics preserve its original verdict and threshold. Original allocation/performance regressions remain blockers and no acceptance changed.

Draft #5015 implementation under #5028. Required current-head review/CI, product qualification and ordered merge remain open. #5030 must qualify actual landed runtime. Held #5004 / PR #5006 are excluded.
""",
'5054':"""Retained value-log pruning repeated complete reachability work for individual candidates and could exhaust its quiet proof budget before useful work finished. This change batches protection from exact recoverable-root membership, conservatively projects uncovered and detached cache roots, and performs fresh GC recovery and late mutation fences before forgetting retention or deleting any segment.

Passive last-attempt and existing work counters distinguish where an ordinary attempt stops. Completed means successful GC-call handling and does not assert eligibility, successful fencing, deletion or useful progress. No scheduler, budget, pressure or cap is changed in this head.

Current provisional head: `761e08c9eff0abadaf5bf132225f9948b83d7c57`, based on R/PR #5037 `01ad34afed6d64f58d8504a57a247170289e4772`. Independent source review and exact native affected normal/race checks pass. The separately labeled natural 3M full-refresh diagnostic genuinely joined: actual ordinary value-log GC removed1,612,377,444bytes/10segments; leaf GC remained zero and closed leaf-log bytes were9,554,791,785. A post-close read-only full-recovery DryRun census is being prepared to classify leaf debt, whose safe eligibility remains UNKNOWN. This one diagnostic does not establish repeated product progress or memory attribution. Original performance/allocation/UNKNOWN observations remain blockers. The original Windows shard was canceled at its40-minute limit before a subsequent test-start event, with no failed-test event; cause is UNKNOWN. One affected-job rerun is in progress without changing checks.

Draft #5016 under #5028; held #5004 / PR #5006 excluded. R must land, then B must synchronize and pass applicable current-head review/CI and qualification before merge. #5030 qualifies actual landed runtime.
"""}
for n in ['5037','5054']:
 endpoint='pulls/'+n;label='pr-'+n;before=api(endpoint,label+'-before');assert before['state']=='open' and before['draft'] and before['head']['sha']==heads[n]
 api(endpoint,label+'-patch','PATCH',{'body':prtext[n]});after=api(endpoint,label+'-readback');assert after['body']==prtext[n] and after['head']['sha']==heads[n] and after['draft'];results.append(dict(target=after['html_url'],readback=label+'-readback.json',sha256=hashlib.sha256((HERE/(label+'-readback.json')).read_bytes()).hexdigest(),verified=True))
endpoint='issues/comments/6023447234';api(endpoint,'parent-comment-before');api(endpoint,'parent-comment-patch','PATCH',{'body':block});after=api(endpoint,'parent-comment-readback');assert after['body']==block;results.append(dict(target=after['html_url'],readback='parent-comment-readback.json',sha256=hashlib.sha256((HERE/'parent-comment-readback.json').read_bytes()).hexdigest(),verified=True))
receipt=dict(checkpoint_version=88,held_excluded=[5004,5006],qualification=False,performance_accepted=False,verified_live_outputs=results,finished_ns=time.time_ns())
p=HERE/'root-publication-receipt.json';p.write_text(json.dumps(receipt,indent=2)+'\n')
state_path=BASE/'state.json';old=state_path.read_bytes();state=json.loads(old);assert state['checkpoint_version']==88 and state['native_active'] is None;state['qualification_v13_current']['publication_v88']=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest());tmp=HERE/'state-publication.pending'
with tmp.open('x') as f:json.dump(state,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
assert state_path.read_bytes()==old;os.replace(tmp,state_path)
print(json.dumps({'checkpoint_version':88,'verified_live_outputs':len(results),'receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
