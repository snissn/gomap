# Conditional Allocate common-prefix experiment

Base HEAD remains `02c0242113931641480216cfd591a01660687549`; no stage, commit, push, native run, state or CI inventory mutation. Source lease is handed back to root. Exactly three worktree paths changed; base/postimages, complete binary-capable diff, selection SHA and exact unchanged caller/policy/test bindings are in this packet. Product/performance/qualification/merge acceptance are all false. Held #5004/#5006 and adjacent work remain excluded.

## Mechanism and authority

`generation_v1_tree.go:260–294` adds one free-bit-specific helper. `generation_v1_txn.go:308–324` keeps the old same-chunk fast path, records selected-path durable metadata IDs, tries prefix reuse only when the existing `privateRoot == root` certificate names another chunk, and otherwise uses the original persistent mutation. It uses no new fields, registry, capacity, format, API or selector. Logical path/item statistics still count one mutation per completed reuse allocation; selector visits, hints, IDs, reservation/append/partial-error semantics remain unchanged.

The helper validates **all 15 nodes** on the old certified path and its nonnil chunk before any mutation, including the portion below the new branch divergence. An empty old leaf is valid after its last free bit was cleared. It validates the selected target bit, identifies the common nibble prefix, calls the existing `mutateChunk` only on the divergent suffix, then recomputes the reused ancestors with the existing `recomputeStateNode`. The selected chunk is always copied, even if dirty; dirty siblings are never inferred private. Failed proof falls back to full COW. Metadata replacement recording before a failed proof is idempotently repeated by the original fallback.

The two-field authority was audited at the actual sharing seams: NewFreelistTxn starts without authority; `mutateMany` establishes a fully copied path; `cloneForAllocatorPrepare` revokes it in both original and staged branches before sharing; MaterializeCandidate revokes before metadata selection and again before assigning/emitting page IDs, detaching dirty siblings/root as before. Allocator prepare/abort/failure restores the revoked rollback transaction. The adjacent `tryReusedMetadata` shallow `planned := *t` copy (generation_v1_metadata_reuse.go:215) is a read-only sizing plan except its separately cloned replacement map; it neither mutates nor retains the shared root, and MaterializeCandidate already revoked the private certificate before entering it. None of those revocations, ownership, horizon, reservation or emit/consume behavior changed. AllocateAppend does not mutate/share the tree. Successful prefix reuse extends the same proof with an owned copied suffix and changes only privateChunk; privateRoot remains the current root.

For k common nibble edges, the old 15-node copy becomes `14-k` suffix node copies plus the unchanged chunk copy; `k+1` certified ancestors are reused. Chunks 0/1 reuse 14 ancestors, 0/16 and 0/70 reuse 13, and high-bit divergence reuses only the root. Summary recomputation is preserved throughout; this is copy elimination, not a scan/summary skip. Persistent retained tree semantics remain equivalent; there is no process RSS claim.

## Actual test-first evidence

The exact baseline allocation-bound run exits 1 as intended: 64 alternating Allocate calls use **1,038 heap allocations** for each 0/1, 0/16 and 0/70 case, versus bound256. Candidate final normal run passes with **156/219/219** allocations. The earlier Flash-storage baseline attempt was stopped and waited with exit-15 before test output; it is retained as a failed setup receipt and provides no RED evidence.

Baseline contracts pass. Final full `./TreeDB/freelist` normal and race pass. All commands use Darwin Go1.26.0, `GOTOOLCHAIN=local GOWORK=off GOMAXPROCS=12` and explicit owned cache/temp/test roots. Exact argv/environment/raw hashes/source hashes and actual subprocess wait results are in each `*.receipt.json`; `command-summary.json` indexes all11 Go attempts. Final candidate normal/race/bench receipts show source stable throughout. The first candidate-normal pass predates only the coherent duplicated-fallback simplification and is superseded by final normal/race receipts.

New tests cover actual Allocate with switching at 0/1,0/16,0/70 and high-bit divergence; complete persistent-oracle differential IDs/errors/allocated records/high-water/tree/changed chunks/replaced metadata/logical stats; durable-ID seeds and emitted bytes/GenerationRef/reservation records; reservations; exhausting the last free bit and switching away from a private empty leaf; append fallback; and rejection of incomplete proofs at root/interior/leaf/chunk even when the common prefix itself appears dirty. Existing nested simultaneous prepare branches, retained dirty materialization roots, warm abort/sink rollback now force chunk switches. Existing full-package metadata sibling retention, partial sink consumption/retry, horizon/retirement, reservation and AllocMany partial-error tests remain intact and passed.

The focused actual DB six-test normal/race commands **did not qualify**: both waited exit1 and produced only `FAIL`; a single-test `-json` diagnostic waited exit1 with no output. There are no named assertion results. Cause is UNKNOWN. Read-only Go driver inspection finds this output compatible with interruption before test execution, but root reports no owned process/space-monitor kill, and external interruption is not established. No correctness gate is waived. Root explicitly requested no more Go and will investigate these receipts. No tests/Go processes remain owned/running.

## Warm-cache local allocation/timing discriminator

Existing `BenchmarkFreelistAllocatePrivatePath` plus the new distance benchmark execute128 real Allocate calls per operation. Identical fixture/test bytes are used before/after; both phases retain five300ms samples with all raw values. These are medians, not a claim of statistical significance or actual3M eligibility. Baseline contract run briefly overlaps benchmark startup; five-sample median comparisons are retained without discarding results.

| Shape | Before ns/op | After ns/op | Before B/op | After B/op | Before allocs/op | After allocs/op |
|---|---:|---:|---:|---:|---:|---:|
| Same chunk guard |74,527|72,325|9,952|9,952|31|31|
| Existing chunk0/2 switch |153,088|102,011|668,324|326,945|2,063|285|
| Chunk0/1 switch |152,009|102,316|668,323|326,945|2,063|285|
| Chunk0/16 switch |153,289|106,060|668,324|351,329|2,063|412|
| Chunk0/70 switch |154,636|107,943|668,324|351,329|2,063|412|
| Chunk0/high-bit switch |152,602|151,366|668,324|643,941|2,063|1,936|

Same-chunk reservation/allocation counts are exactly unchanged and no local timing regression was observed. Nearby switching bytes fall47–51%, allocations80–86%, time30–33%; high-bit changes are small. Actual switch frequency, original8s process allocation/RSS/performance gates and native baseline eligibility replay are still outstanding. None are normalized, weakened or claimed passed.

## Diagnostic overlay and remaining review

`prepare-diagnostic-overlay.py` accepts `--source-root` and a fresh `--output`, reads the chosen frozen original or candidate files, binds them, and creates two diagnostic replacements plus `overlay.json`. Prepared candidate overlay is gofmt-parsed but **not compiled/executed** because root held further Go. See `diagnostic-overlay/README.md` for exact counters and consistency checks. It observes actual selected reusable chunks, allocation transitions, certified same/switch, full-path eligibility, prefix depth, saved-ancestor opportunity and fork/materialization revocations. Cumulative JSON is emitted on MaterializeCandidate return; root must retain a final quiescent dump and bindings. A missing/final-unjoined dump remains UNKNOWN. Instrumented timing/bytes/RSS cannot satisfy original gates. Production has no diagnostic overhead or API.

Root should review the entire patch, investigate DB pre-test failures, then collect the already-selected finite native eligibility histogram and uninstrumented matched workload if warranted. No second mechanism or tuning was attempted. Public docs/format/ACK/configuration remain unchanged; private ownership comments document the new proof construction. Root owns CI discovery refresh and all adoption/integration.

## Storage custody

Initial bulk Flash index seeding was stopped; exact dependency/index Flash seeding was also stopped and genuinely joined exit143. Its baseline Go was genuinely joined exit-15. Owned roots are `/Volumes/FlashDrive/gomap-5015-common-prefix-local-go-fst_eqyw` and `/private/tmp/gomap-5015-common-prefix-local-go-5kqxg24v`. The internal seed used APFS `cp -c` for only530 exact normal dependency/archive action-index files,200,022,553 logical bytes. Default/shared cache was read only and untouched. Prior empty-rotation scratch is consumed only through its41KB `tmp/go-build4258426053/b001/importcfg.link`; do not release that original until root decides. Every Go attempt has an actual wait receipt. One early read-only Flash inventory command's exec-session ID was not retained; its exact PID49840 was terminated and subsequently absent, rather than claiming an unavailable tool-join receipt for it. It ran no Go/tests and wrote no state/source.

Main volume was space constrained: ~207MiB initially; root released exact shipping archives; sampled free ~179MiB after focused DB builds, fluctuating to ~217MiB at final seal. All finite caches/importcfg/source are retained at root's explicit instruction. Scratch is handed back for root-controlled release; no cleanup performed. The failed/slow setup and negative DB attempts remain visible.
