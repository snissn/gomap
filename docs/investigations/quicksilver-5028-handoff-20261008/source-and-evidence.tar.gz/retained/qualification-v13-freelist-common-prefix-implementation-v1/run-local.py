import pathlib,os,sys,time,json,subprocess,hashlib
out=pathlib.Path(__file__).parent
root=pathlib.Path("/private/tmp/gomap-5015-common-prefix-local-go-5kqxg24v")
name=sys.argv[1]; args=sys.argv[2:]
env=os.environ.copy(); controls={"GOROOT":"/Users/michaelseiler/.gvm/gos/go1.26.0","GOTOOLCHAIN":"local","GOWORK":"off","GOMAXPROCS":"12","GOCACHE":str(root/"cache"),"GOTMPDIR":str(root/"tmp"),"TMPDIR":str(root/"testtmp")}
env.update(controls)
repo=pathlib.Path("/private/tmp/gomap-qs-5015")
inputs={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/"TreeDB/freelist").glob("generation_v1*go")}
start=time.time()
with (out/(name+".raw.txt")).open("xb") as log:
 proc=subprocess.Popen(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 code=proc.wait()
after={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/"TreeDB/freelist").glob("generation_v1*go")}
receipt={"source_stable_through_command": inputs==after,"post_source_hashes":after,"argv":args,"cwd":str(repo),"environment":controls,"pid":proc.pid,"exit_code":code,"actual_wait":True,"elapsed_seconds":time.time()-start,"source_hashes":inputs,"raw_sha256":hashlib.sha256((out/(name+".raw.txt")).read_bytes()).hexdigest()}
(out/(name+".receipt.json")).write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"name":name,"exit_code":code,"elapsed_seconds":receipt["elapsed_seconds"]}),flush=True)
sys.exit(code)
