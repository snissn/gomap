"""Prepare-only, module-local read view of exact frozen V12 source receipt.
CLI: REQUEST REQUEST_SHA256. New root source adoption/authorization is required.
Never use this adapter for an analysis or final-evaluate command.
"""
import argparse,copy,hashlib,json,os,sys,time,types
from pathlib import Path
BASE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ROOT=BASE/'qualification-v12-refresh/qualification-v10'
SOURCE_SHA='30eb9fe190c0b65cd7097333285d8b5e324532bc930a967af6423c6cb300ef81'
LOCK_SHA='bda4d2486d2e66ee33533d601d216092ce1cd8f5211cfb02aac0d9d2bf823c75'
TRACKED={'A': {'path': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-source-inventory/inputs/qualification-v12-A-tracked-tree.json', 'sha256': '320207420455ed1392400711e9dedc4983afb66ecf65c0f34fdc5a77e50761b4'}, 'B': {'path': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-source-inventory/inputs/qualification-v12-B-tracked-tree.json', 'sha256': 'c181652857444632fc5a79cc498a5e78fc272fe46ffb2fd0f3949fef4ad9501a'}, 'R': {'path': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-source-inventory/inputs/qualification-v12-R-tracked-tree.json', 'sha256': '15de5d5f280ef971649fdee97780d91e9ddcb7b28f0e97bcd138b2821f0ee79c'}}
PINS={'A': {'head': '192e5019e579af3b98ae4fbf4ea497bb9ccd672f', 'tree': '79100a06e3258caacbc127678f1a4d17bcc9f3e6'}, 'B': {'head': '73100c5b8cc2337d9cff36c60a8e4182f1820fe9', 'tree': '41331819ecb921ea477baf1997a652506700cf56'}, 'R': {'head': '6fa638b8bffa71750e1aefa0bb746bb747aa06c1', 'tree': 'b4bbd98c74c21f7f68bce288341a0925c83e18f1'}}
CONTROLLERS={
 'B':{'path':str(BASE/'qualification-analysis-controller.py'),'sha256':'e5744ead53031c489e3345c16a48c0b2e7b91c577177d50d25d94adfbe7b79fd'},
 'R':{'path':str(BASE/'r-material-gate-preparation-v2/r-analysis-controller.py'),'sha256':'433c5df7016136afc8920b6663c5c0ed5d167cea993b35554a0b54a663764dc6'}}
FLAGS=('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized')
def require(value,why):
 if not value:raise ValueError(why)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def canonical(path):
 require(isinstance(path,str),'text path required')
 p=Path(path);require(p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p,'canonical regular file required')
 return p
def parse(raw):
 def unique(items):
  result={}
  for key,value in items:
   require(key not in result,'duplicate JSON key');result[key]=value
  return result
 def invalid(value):raise ValueError('nonfinite JSON token')
 return json.loads(raw,object_pairs_hook=unique,parse_constant=invalid)
def bound(ref):
 require(isinstance(ref,dict) and set(ref)=={'path','sha256'},'exact ref required')
 p=canonical(ref['path']);require(sha(p)==ref['sha256'],'bound digest mismatch');return parse(p.read_bytes())
def validate_argv(role,argv):
 require(role in CONTROLLERS and isinstance(argv,list) and all(isinstance(v,str) for v in argv),'unknown role/argv')
 require(argv[:3]==['python3','-B',CONTROLLERS[role]['path']],'original logical argv drift')
 p=argparse.ArgumentParser(allow_abbrev=False,exit_on_error=False)
 p.add_argument('stage',choices=['full-calibration']);p.add_argument('--campaign',required=True);p.add_argument('--out',required=True);p.add_argument('--prepare',action='store_true',required=True)
 if role=='R':
  for option in ['--original-B-anchor','--original-B-anchor-sha256','--definition','--definition-sha256']:p.add_argument(option,required=True)
 a=p.parse_args(argv[3:]);require(a.campaign==str(ROOT),'campaign drift')
 options=argv[4:];require(len(options)==len(set(options)),'duplicate argv option/value')
 out=ROOT/('analysis-global-original-v1' if role=='B' else 'ar-analysis-global-original-v1')
 require(a.out==str(out),'exact original global prepare output required')
 require(not os.path.lexists(out),'original prepare output already exists')
 return a
def validate_admission(q,ownref):
 require(q['held_excluded']==[5004,5006],'held exclusions drift')
 require(type(q['authorized_ns']) is int and q['authorized_ns']>0,'positive root request authorization timestamp required')
 role=q['role'];require(role in CONTROLLERS,'unknown role')
 target=BASE/'qualification-v12-later-execution-preparation-v3'/('root-'+role+'-prepare-receipt-view-provenance-v12-v1.json')
 require(q['provenance_path']==str(target),'exact role provenance path required')
 require(target.parent.is_dir() and target.parent.resolve(strict=True)==target.parent and not os.path.lexists(target),'canonical exclusive provenance path required')
 adoption=bound(q['source_compatibility_acceptance'])
 require(adoption['schema']==1 and adoption['accepted_by_root'] is True and adoption['source_only'] is True and adoption['owner']=='/root','actual root source acceptance required')
 require(adoption['held_excluded']==[5004,5006] and all(adoption[k] is False for k in FLAGS),'source acceptance exclusions/authority drift')
 require(adoption['prepare_adapter']==ownref and q['adapter']==ownref,'current adapter source acceptance mismatch')
 return target
def normalized_view(receipt,lock):
 require(lock['pins']==PINS and lock['tracked_manifests']==TRACKED,'source lock identity drift')
 require(lock['manifest']['receipts']['source']['sha256']==SOURCE_SHA,'source receipt lock drift')
 require(set(receipt['variants'])==set(PINS),'exact A/B/R roles required')
 view=copy.deepcopy(receipt);changes=[]
 for role in sorted(PINS):
  v=receipt['variants'][role];ref=v['tracked_manifest'];require(ref==TRACKED[role] and isinstance(ref,dict) and set(ref)=={'path','sha256'},'exact tracked ref/role drift')
  require(v['accepted_head']==v['built_against_head']==PINS[role]['head'] and v['tree']==PINS[role]['tree'],'tracked head/tree drift')
  require(v['source']==lock['source_paths'][role],'source path drift')
  bound(ref)
  view['variants'][role]['tracked_manifest']=ref['path'];changes.append({'role':role,'original':copy.deepcopy(ref),'view':ref['path']})
 reversed_view=copy.deepcopy(view)
 for change in changes:reversed_view['variants'][change['role']]['tracked_manifest']=change['original']
 require(reversed_view==receipt,'read view changed other values')
 return view,changes
def provenance(outer,logical,request,controller,source,lock,view,changes,started,finished,rc,error):
 return {'schema':1,'scope':'ACTUAL_PREPARE_ONLY_RECEIPT_READ_VIEW','owner':'/root','outer_argv':outer,'logical_original_argv':logical,'pid':os.getpid(),'started_ns':started,'finished_ns':finished,'returncode':rc,'error':error,'request':request,'controller':controller,'source_receipt':source,'source_lock':lock,'normalized_view_sha256':hashlib.sha256(json.dumps(view,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest(),'read_view_changes':changes,**{k:False for k in FLAGS}}
def main():
 require(__debug__ and sys.flags.dont_write_bytecode and sys.pycache_prefix is None,'unoptimized -B required')
 require(len(sys.argv)==3,'REQUEST REQUEST_SHA256 required')
 reqref={'path':sys.argv[1],'sha256':sys.argv[2]};q=bound(reqref)
 ownref={'path':str(canonical(str(Path(__file__).absolute()))),'sha256':sha(__file__)}
 require(q['adapter']==ownref,'adapter source binding drift')
 require(q['schema']==1 and q['accepted_by_root'] is True and q['owner']=='/root' and q['prepare_receipt_read_view_authorized'] is True and q.get('source_only') is not True,'new root preparation authorization required')
 require(all(q[k] is False for k in FLAGS),'forbidden product/collection authority')
 target=validate_admission(q,ownref)
 role=q['role'];args=validate_argv(role,q['original_argv']);controller=CONTROLLERS[role];require(q['controller']==controller,'controller pin drift');bound_controller=canonical(controller['path']);require(sha(bound_controller)==controller['sha256'],'original controller bytes drift')
 require(q['source_lock']['sha256']==LOCK_SHA,'exact source lock required');lock=bound(q['source_lock'])
 manifest=bound(q['campaign_manifest']);require(q['campaign_manifest']['path']==str(ROOT/'manifest.json') and q['campaign_manifest']['sha256']==lock['manifest_sha256'],'campaign manifest path/digest drift')
 ref=manifest['receipts']['source'];source={'path':str(ROOT/ref['path']),'sha256':ref['sha256']}
 require(source==q['source_receipt'] and source['sha256']==SOURCE_SHA,'actual common source receipt mismatch')
 receipt=bound(source);view,changes=normalized_view(receipt,lock)
 require(not os.path.lexists(target) and not os.path.lexists(args.out),'prepare output/provenance became occupied')
 outer=list(sys.orig_argv);logical=list(q['original_argv']);started=time.time_ns();rc=1;error=None
 oldargv=sys.argv[:];oldpath=sys.path[:]
 try:
  sys.path.insert(0,str(bound_controller.parent))
  module=types.ModuleType('original_prepare_only');module.__file__=str(bound_controller)
  exec(compile(bound_controller.read_bytes(),str(bound_controller),'exec'),module.__dict__)
  original_read=module.read
  def read_view(path):
   if str(path)==source['path']:
    actual=bound(source);require(actual==receipt,'source changed during prepare');return copy.deepcopy(view)
   return original_read(path)
  module.read=read_view
  sys.argv=[str(bound_controller),*logical[3:]]
  module.main();rc=0
 except BaseException as exc:
  error=type(exc).__name__+': '+str(exc)
  if isinstance(exc,SystemExit):rc=exc.code if isinstance(exc.code,int) else 1
  raise
 finally:
  sys.argv=oldargv;sys.path=oldpath
  record=provenance(outer,logical,reqref,controller,source,q['source_lock'],view,changes,started,time.time_ns(),rc,error)
  with target.open('x') as stream:json.dump(record,stream,indent=2,allow_nan=False);stream.write('\n')
if __name__=='__main__':main()
