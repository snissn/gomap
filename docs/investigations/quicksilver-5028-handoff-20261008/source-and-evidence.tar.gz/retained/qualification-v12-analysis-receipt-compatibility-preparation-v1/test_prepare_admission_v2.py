"""New admission seam only, AST extracted; isolated local synthetic files."""
import argparse,ast,copy,hashlib,json,pathlib,tempfile
HERE=pathlib.Path(__file__).resolve().parent
checks=[]
def denied(name,fn):
 try:fn()
 except (ValueError,KeyError,OSError,SystemExit,argparse.ArgumentError):checks.append(name);return
 raise AssertionError('hostile admission accepted: '+name)
tree=ast.parse((HERE/'prepare-original-analysis-receipt-view-v12-v2.py').read_text());selected=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.Assign)) or isinstance(n,ast.FunctionDef) and n.name!='main']
ns={};exec(compile(ast.Module(body=selected,type_ignores=[]),'<pure-admission-v2>','exec'),ns)
with tempfile.TemporaryDirectory(prefix='synthetic-admission-',dir=HERE) as tmp:
 root=pathlib.Path(tmp);ns['BASE']=root;ns['ROOT']=root/'campaign';ns['ROOT'].mkdir();later=root/'qualification-v12-later-execution-preparation-v3';later.mkdir()
 adapter=root/'adapter.py';adapter.write_text('synthetic immutable adapter bytes');own={'path':str(adapter),'sha256':hashlib.sha256(adapter.read_bytes()).hexdigest()}
 source=root/'source-acceptance.json'
 adoption={'schema':1,'source_only':True,'accepted_by_root':True,'owner':'/root','held_excluded':[5004,5006],'prepare_adapter':own,**{k:False for k in ns['FLAGS']}}
 def adopt(value):
  source.write_text(json.dumps(value));return {'path':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
 ref=adopt(adoption)
 def argv(role):
  values=['python3','-B',ns['CONTROLLERS'][role]['path'],'full-calibration','--campaign',str(ns['ROOT']),'--out',str(ns['ROOT']/('analysis-global-original-v1' if role=='B' else 'ar-analysis-global-original-v1')),'--prepare']
  if role=='R':values+=['--original-B-anchor','/synthetic/anchor','--original-B-anchor-sha256','anchorSHA','--definition','/synthetic/definition','--definition-sha256','definitionSHA']
  return values
 def request(role):return {'role':role,'adapter':own,'held_excluded':[5004,5006],'authorized_ns':10,'provenance_path':str(later/('root-'+role+'-prepare-receipt-view-provenance-v12-v1.json')),'source_compatibility_acceptance':ref}
 for role in ['B','R']:
  a=ns['validate_argv'](role,argv(role));q=request(role);assert ns['validate_admission'](q,own)==pathlib.Path(q['provenance_path']);checks.append('exact '+role+' output/provenance/adoption admitted')
  alternate=argv(role);alternate[7]=str(ns['ROOT']/('analysis-other' if role=='B' else 'ar-analysis-other'));denied(role+' alternate output',lambda:ns['validate_argv'](role,alternate))
  alias=argv(role);alias[7]=str(ns['ROOT']/'nested'/'..'/pathlib.Path(a.out).name);denied(role+' output alias',lambda:ns['validate_argv'](role,alias))
  output=pathlib.Path(a.out);output.symlink_to(root/'nonexistent-output');denied(role+' dangling output symlink',lambda:ns['validate_argv'](role,argv(role)));output.unlink()
  output.mkdir();denied(role+' occupied output',lambda:ns['validate_argv'](role,argv(role)));output.rmdir()
  wrong=request(role);wrong['provenance_path']=str(root/'elsewhere.json');denied(role+' alternate provenance',lambda:ns['validate_admission'](wrong,own))
  wrong=request(role);wrong['provenance_path']=str(later/'nested'/'..'/pathlib.Path(q['provenance_path']).name);denied(role+' provenance alias',lambda:ns['validate_admission'](wrong,own))
  other=request(role);other['provenance_path']=request('R' if role=='B' else 'B')['provenance_path'];denied(role+' wrong role provenance',lambda:ns['validate_admission'](other,own))
  target=pathlib.Path(q['provenance_path']);target.symlink_to(root/'nonexistent-provenance');denied(role+' dangling provenance symlink',lambda:ns['validate_admission'](q,own));target.unlink()
  target.write_text('occupied');denied(role+' occupied provenance',lambda:ns['validate_admission'](q,own));target.unlink()
 for name,key,value in [('missing exclusions','held_excluded',[]),('wrong exclusions','held_excluded',[5004]),('boolean timestamp','authorized_ns',True),('zero timestamp','authorized_ns',0),('negative timestamp','authorized_ns',-1),('float timestamp','authorized_ns',1.0),('missing authorization timestamp','authorized_ns',None)]:
  q=request('B');q[key]=value;denied(name,lambda q=q:ns['validate_admission'](q,own))
 q=request('B');q['authorized_ns']=10**30;ns['validate_admission'](q,own);checks.append('positive Mac-clock timestamp without native age comparison')
 for name,key,value in [('unaccepted source','accepted_by_root',False),('runtime source acceptance','source_only',False),('wrong owner','owner','/other'),('wrong schema','schema',2),('wrong held source','held_excluded',[]),('wrong adapter source','prepare_adapter',{**own,'sha256':'0'*64})]+[(key+' authority',key,True) for key in ns['FLAGS']]:
  bad=copy.deepcopy(adoption);bad[key]=value;q=request('B');q['source_compatibility_acceptance']=adopt(bad);denied(name,lambda q=q:ns['validate_admission'](q,own))
 ref=adopt(adoption);q=request('B');q['source_compatibility_acceptance']['sha256']='0'*64;denied('actual adoption digest mismatch',lambda:ns['validate_admission'](q,own));ref=adopt(adoption)
 link=root/'source-link.json';link.symlink_to(source);q=request('B');q['source_compatibility_acceptance']={**ref,'path':str(link)};denied('source adoption symlink',lambda:ns['validate_admission'](q,own))
 q=request('B');q['adapter']={**own,'path':str(root/'wrong-adapter.py')};denied('request dynamic ownref drift',lambda:ns['validate_admission'](q,own))
 # Canonical parent gate is independently exercised using a local symlink base.
 realbase=ns['BASE'];linked=root/'linked-base';linked.symlink_to(root,target_is_directory=True);ns['BASE']=linked;q=request('B');q['provenance_path']=str(linked/'qualification-v12-later-execution-preparation-v3'/'root-B-prepare-receipt-view-provenance-v12-v1.json');denied('provenance symlink parent',lambda:ns['validate_admission'](q,own));ns['BASE']=realbase
print(json.dumps({'source_only':True,'checks_passed':len(checks),'checks':checks},indent=2))
