"""Synthetic pure-function/AST checks only; never load original controllers."""
import argparse,ast,copy,hashlib,json,pathlib,tempfile
HERE=pathlib.Path(__file__).resolve().parent
checks=[]
def record(name,fn):
 fn();checks.append(name)
def deny(name,fn):
 try:fn()
 except (ValueError,SystemExit,FileNotFoundError,AssertionError,argparse.ArgumentError):checks.append(name);return
 raise AssertionError('accepted hostile case: '+name)
tree=ast.parse((HERE/'prepare-original-analysis-receipt-view-v12-v1.py').read_text())
selected=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.Assign)) or isinstance(n,ast.FunctionDef) and n.name!='main']
ns={};exec(compile(ast.Module(body=selected,type_ignores=[]),'<isolated-pure-adapter>','exec'),ns)
argv=['python3','-B',ns['CONTROLLERS']['B']['path'],'full-calibration','--campaign',str(ns['ROOT']),'--out',str(ns['ROOT']/'analysis-isolated'),'--prepare']
record('exact prepare argv admitted',lambda:ns['validate_argv']('B',argv))
for name,change in [('evaluation',lambda a:a.__setitem__(3,'final-evaluate')),('analysis without prepare',lambda a:a.remove('--prepare')),('unknown argument',lambda a:a.extend(['--fake','x'])),('duplicate flag',lambda a:a.append('--prepare')),('alias output',lambda a:a.__setitem__(7,str(ns['ROOT']/'..'/'analysis-isolated')))]:
 a=argv[:];change(a);deny(name,lambda a=a:ns['validate_argv']('B',a))
deny('unknown controller role',lambda:ns['validate_argv']('A',argv))
with tempfile.TemporaryDirectory(prefix='synthetic-',dir=HERE) as tmp:
 root=pathlib.Path(tmp);refs={};pins=ns['PINS'];variants={};paths={}
 for role in pins:
  p=root/(role+'.json');p.write_text(json.dumps({'head':pins[role]['head'],'tree':pins[role]['tree']}));refs[role]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};paths[role]=str(root/('source-'+role));variants[role]={'accepted_head':pins[role]['head'],'built_against_head':pins[role]['head'],'tree':pins[role]['tree'],'source':paths[role],'tracked_manifest':refs[role],'sentinel':{'nested':[1,2,'keep']}}
 ns['TRACKED']=refs
 lock={'pins':pins,'tracked_manifests':refs,'source_paths':paths,'manifest':{'receipts':{'source':{'sha256':ns['SOURCE_SHA']}}}}
 original={'variants':variants,'sentinel':[False,{'unchanged':42}]};before=copy.deepcopy(original)
 view,changes=ns['normalized_view'](original,lock);assert original==before and len(changes)==3
 reverse=copy.deepcopy(view)
 for r in refs:assert view['variants'][r]['tracked_manifest']==refs[r]['path'];reverse['variants'][r]['tracked_manifest']=refs[r]
 assert reverse==original;checks.append('exact three-field view and deep preservation')
 for name,mutate in [('wrong role',lambda v:v['variants'].__setitem__('X',v['variants'].pop('A'))),('wrong digest',lambda v:v['variants']['A']['tracked_manifest'].__setitem__('sha256','0'*64)),('wrong path',lambda v:v['variants']['A']['tracked_manifest'].__setitem__('path',str(root/'other.json'))),('alias path',lambda v:v['variants']['A']['tracked_manifest'].__setitem__('path',str(root/'..'/root.name/'A.json'))),('extra ref key',lambda v:v['variants']['A']['tracked_manifest'].__setitem__('alias',True)),('wrong head',lambda v:v['variants']['A'].__setitem__('accepted_head','0'*40))]:
  bad=copy.deepcopy(original);mutate(bad);deny(name,lambda bad=bad:ns['normalized_view'](bad,lock))
 p=root/'A.json';p.write_text('tampered');deny('actual tracked bytes mismatch',lambda:ns['normalized_view'](original,lock))
 p.write_text(json.dumps({'head':pins['A']['head'],'tree':pins['A']['tree']}));link=root/'linked.json';link.symlink_to(p);deny('symlink rejected',lambda:ns['canonical'](str(link)));deny('symlink parent rejected',lambda:ns['canonical'](str(root/'..'/root.name/'A.json')))
 custody=ns['provenance'](['python3','-B','adapter.py','request','hash'],argv,{'path':'request','sha256':'hash'},ns['CONTROLLERS']['B'],{'path':'source','sha256':'sha'},{'path':'lock','sha256':'sha'},view,changes,10,20,0,None)
 assert custody['outer_argv']==['python3','-B','adapter.py','request','hash'] and custody['logical_original_argv']==argv and custody['started_ns']==10 and custody['finished_ns']==20 and custody['returncode']==0 and custody['read_view_changes']==changes
 assert custody['normalized_view_sha256']==hashlib.sha256(json.dumps(view,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest();checks.append('truthful distinct argv and exact view custody')
raw=ast.parse((HERE/'root-final-raw-closure-v12-v2.py').read_text());fn=next(n for n in raw.body if isinstance(n,ast.FunctionDef) and n.name=='tracked_manifest_path')
expected=ast.literal_eval(next(n.value for n in fn.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='expected'))
source_digest=ns['SOURCE_SHA'];rawns={'BASE':pathlib.Path('/synthetic-base'),'require':ns['require'],'Path':pathlib.Path,'isinstance':isinstance}
rawns['canonical']=lambda p:pathlib.Path(p);rawns['sha']=lambda p:expected[next(k for k,v in expected.items() if v['path']==str(p))]['sha256']
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<isolated-raw-boundary>','exec'),rawns)
for role,ref in expected.items():assert rawns['tracked_manifest_path'](role,{'tracked_manifest':ref},source_digest)==pathlib.Path(ref['path'])
checks.append('raw exact selected records admitted')
for name,role,ref,digest in [('raw wrong role','X',expected['A'],source_digest),('raw wrong digest','A',{**expected['A'],'sha256':'0'*64},source_digest),('raw alias','A',{**expected['A'],'path':expected['A']['path']+'/../alias'},source_digest),('raw unknown source','A',expected['A'],'0'*64)]:deny(name,lambda role=role,ref=ref,digest=digest:rawns['tracked_manifest_path'](role,{'tracked_manifest':ref},digest))
rawns['sha']=lambda p:'0'*64;deny('raw actual bytes digest mismatch',lambda:rawns['tracked_manifest_path']('A',{'tracked_manifest':expected['A']},source_digest))
assert rawns['tracked_manifest_path']('historical',{'tracked_manifest':'legacy.json'},'historic')==pathlib.Path('/synthetic-base/legacy.json');checks.append('legacy string semantics retained')
original=HERE.parent/'qualification-v12-final-artifact-preparation-v1/root-final-raw-closure-v12-v1.py';old=ast.parse(original.read_text());new=copy.deepcopy(raw);new.body=[n for n in new.body if not isinstance(n,ast.FunctionDef) or n.name!='tracked_manifest_path']
for i,n in enumerate(new.body):
 if isinstance(n,ast.FunctionDef) and n.name=='manifest_closure':new.body[i]=next(v for v in old.body if isinstance(v,ast.FunctionDef) and v.name=='manifest_closure')
assert ast.dump(new,include_attributes=False)==ast.dump(old,include_attributes=False);checks.append('all raw AST outside exact transport boundary identical')
print(json.dumps({'source_only':True,'checks_passed':len(checks),'checks':checks},indent=2))
