"""Future source-only Git basis construction. REQUEST SHA256; no native execution.
Outputs are unaccepted observations. Root review is a separate required step.
"""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

BASE = Path('/Users/michaelseiler/dev/snissn/gomap/tmp/quicksilver-maintenance-5028-20261005/qualification-v12-source-pipeline-preparation-v1')
ROLES = ('A', 'R', 'B')
HARNESS = ('scripts/quicksilver_maintenance.py', 'scripts/unified_bench_quicksilver_capture.py', 'scripts/owned_process_rss.py')


def require(ok, why):
    if not ok:
        raise ValueError(why)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def bound(ref):
    require(set(ref) == {'path', 'sha256'}, 'exact path/SHA reference required')
    p = Path(ref['path'])
    require(p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve(strict=True) == p, 'canonical input required')
    require(re.fullmatch('[0-9a-f]{64}', ref['sha256']) and digest(p.read_bytes()) == ref['sha256'], 'bound SHA drift')
    return json.loads(p.read_bytes())


def emit(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False, sort_keys=True)
        stream.write('\n')
    return {'path': str(path), 'sha256': digest(path.read_bytes())}


def git(repo, *args):
    # Deliberately limited to Git object/ancestry reads, never checkout or merge.
    require(args[0] in ('rev-parse', 'ls-tree', 'show', 'merge-base', 'cat-file'), 'unsupported Git action')
    p = subprocess.run(['git', '-C', str(repo), *args], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    require(p.returncode == 0, 'Git read failed: '+p.stderr.decode())
    return p.stdout


def oid(value):
    require(isinstance(value, str) and re.fullmatch('[0-9a-f]{40}', value), 'actual full commit ID required')
    return value


def tree(repo, head):
    head = oid(head)
    require(git(repo, 'cat-file', '-t', head).strip() == b'commit', 'resolved commit required; diagnostic trees forbidden')
    result = {'head': head, 'tree': git(repo, 'rev-parse', head+'^{tree}').decode().strip(), 'files': {}}
    for raw in git(repo, 'ls-tree', '-r', '-z', head).split(b'\0'):
        if not raw:
            continue
        meta, name = raw.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        name = name.decode(); relative = PurePosixPath(name)
        require(kind == 'blob' and mode in ('100644', '100755', '120000'), 'unsupported tracked object; review submodules explicitly')
        require(not relative.is_absolute() and name == relative.as_posix() and all(x not in ('', '.', '..', '.git') for x in relative.parts), 'unsafe tracked path')
        result['files'][name] = {'mode': mode, 'blob': blob}
    require(result['files'], 'empty Git source')
    return result


def delta(old, new):
    a, b = old['files'], new['files']
    return [{'path': p, 'old': a.get(p), 'new': b.get(p)} for p in sorted(a.keys() | b.keys()) if a.get(p) != b.get(p)]


def validate_accepted_basis(proof_ref, acceptance_ref):
    """Small shared seam for future builder/inventory/correctness entrypoints."""
    proof, accepted = bound(proof_ref), bound(acceptance_ref)
    require(proof['receipt_kind'] == 'qualification-v12-observed-source-basis' and proof['accepted_by_root'] is False, 'original observation required')
    require(accepted['receipt_kind'] == 'qualification-v12-root-source-basis-acceptance' and accepted['accepted_by_root'] is True, 'actual separate root source acceptance required')
    require(accepted['source_basis'] == proof_ref and accepted['variants'] == proof['exact_variants'], 'acceptance/source identity drift')
    require(accepted['reviewed_bindings'] == proof['review_bindings'], 'full common/owned/harness review binding required')
    require(accepted['source_export_authorized'] is True and accepted['build_authorized'] is True, 'source/build authority required')
    require(accepted['qualification'] is False and accepted['collection_authorized'] is False and accepted['held_excluded'] == [5004, 5006], 'no measurement authority')
    return proof, accepted


def main():
    require(__debug__ and len(sys.argv) == 3, 'unoptimized Python REQUEST SHA256 required')
    request_ref = {'path': sys.argv[1], 'sha256': sys.argv[2]}; request = bound(request_ref)
    require(request['receipt_kind'] == 'qualification-v12-source-basis-construction-request', 'request schema')
    require(request['accepted_by_root'] is True and request['construction_authorized'] is True, 'root construction authorization required')
    require(request['qualification'] is False and request['collection_authorized'] is False and request['held_excluded'] == [5004, 5006], 'source-only scope')
    repo = Path(request['repository']); require(repo.is_absolute() and repo.resolve(strict=True) == repo, 'canonical repository required')
    out = Path(request['output']); require(out.parent == BASE and not out.exists() and not out.is_symlink(), 'fresh exclusive child of authorized BASE required')
    require(set(request['variants']) == set(ROLES), 'all three source roles required')
    variants = {r: tree(repo, request['variants'][r]['head']) for r in ROLES}
    main_source = tree(repo, request['current_landed_main_head']); owner = oid(request['owner_landed_5084_commit'])
    require(variants['A']['head'] == main_source['head'], 'A must select the actual accepted current common main')
    git(repo, 'merge-base', '--is-ancestor', owner, variants['A']['head'])
    require(set(request['normal_merge_parents']) == {'R', 'B'}, 'normal integration parents required')
    for role, common in (('R', 'A'), ('B', 'R')):
        parents = git(repo, 'show', '-s', '--format=%P', variants[role]['head']).decode().split()
        expected = [oid(x) for x in request['normal_merge_parents'][role]]
        require(len(parents) == 2 and parents == expected and variants[common]['head'] in parents, 'actual normal merge parents do not match root selection')
    historical = tree(repo, request['historical_A_head'])
    changes = {'common': delta(historical, variants['A']), 'R_owned': delta(variants['A'], variants['R']), 'B_owned': delta(variants['R'], variants['B'])}
    require(set(request['delta_classification']) == set(changes), 'all complete delta classifications required')
    for name, rows in changes.items():
        classification = request['delta_classification'][name]
        require(set(classification) == {r['path'] for r in rows}, 'every changed path must have explicit root review classification: '+name)
        require(all(isinstance(v, str) and v for v in classification.values()), 'empty review classification')
        for row in rows:
            row['root_review_classification'] = classification[row['path']]
    harness_head = oid(request['selected_landed_python_harness_head']); harness_source = tree(repo, harness_head)
    harness = {}
    for path in HARNESS:
        binding = harness_source['files'][path]
        require(binding['mode'] in ('100644', '100755'), 'harness must be a regular tracked file')
        require(all(variants[r]['files'].get(path) == binding for r in ROLES), 'selected Python harness differs from actual common A/R/B')
        harness[path] = dict(binding, sha256=digest(git(repo, 'cat-file', 'blob', binding['blob'])))
    reviewed_go_harness = request['reviewed_go_harness_paths']
    require('cmd/unified_bench/profile_artifact_dir_test.go' in reviewed_go_harness and len(reviewed_go_harness) == len(set(reviewed_go_harness)), 'complete reviewed Go harness including former exception required')
    go_harness = {}
    for path in reviewed_go_harness:
        require(path in variants['A']['files'] and all(variants[r]['files'].get(path) == variants['A']['files'][path] for r in ROLES), 'Go harness binding differs; independent review required')
        go_harness[path] = variants['A']['files'][path]
    out.mkdir()
    manifests = {r: emit(out/('qualification-v12-'+r+'-tracked-tree.json'), variants[r]) for r in ROLES}
    deltas = {name: emit(out/(name+'-delta.json'), rows) for name, rows in changes.items()}
    harness_ref = emit(out/'selected-harness-bindings.json', {'python_head': harness_head, 'python_files': harness, 'go_files': go_harness})
    proof = {'schema': 1, 'receipt_kind': 'qualification-v12-observed-source-basis', 'source_only': True, 'accepted_by_root': False, 'qualification': False, 'collection_authorized': False, 'performance_accepted': False, 'request': request_ref, 'exact_variants': {r: {k: variants[r][k] for k in ('head', 'tree')} for r in ROLES}, 'normal_merge_parents': request['normal_merge_parents'], 'current_landed_main': {k: main_source[k] for k in ('head', 'tree')}, 'owner_landed_5084_commit': owner, 'tracked_manifests': manifests, 'review_bindings': dict(deltas, selected_harness=harness_ref), 'compiler_input_closure_observed': False, 'requires_separate_root_review': True, 'held_excluded': [5004, 5006]}
    proof_ref = emit(out/'observed-source-basis.json', proof)
    print(json.dumps({'source_basis': proof_ref, 'accepted_by_root': False, 'native_commands': 0}))


if __name__ == '__main__':
    main()
