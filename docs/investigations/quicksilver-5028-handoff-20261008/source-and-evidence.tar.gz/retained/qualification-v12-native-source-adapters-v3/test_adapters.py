"""Finite Python-only tests; never invoke a stage/native subprocess."""
import ast
import hashlib
import json
from pathlib import Path
import signal
import sys
import tarfile
import tempfile
import types
import unittest
from unittest.mock import patch

HERE=Path(__file__).absolute().parent

def load(name):
    p=HERE/name;module=types.ModuleType(name);module.__file__=str(p)
    exec(compile(p.read_bytes(),str(p),'exec'),module.__dict__)
    return module

PC=load('pipeline_common.py');BUILD=load('build-native-v12.py');CHECK=load('correctness-only-v12.py');INV=load('inventory-native-v12.py')

class AdapterTests(unittest.TestCase):
    def test_syntax_import_has_no_stage_io(self):
        for name in ('pipeline_common.py','build-native-v12.py','inventory-native-v12.py','correctness-only-v12.py'):
            raw=(HERE/name).read_bytes();ast.parse(raw)
            module=types.ModuleType('isolated');module.__file__=str(HERE/name)
            with patch('subprocess.Popen',side_effect=AssertionError('native invocation')),patch.object(Path,'read_bytes',side_effect=AssertionError('stage input IO')),patch.object(Path,'read_text',side_effect=AssertionError('stage input IO')),patch.object(Path,'open',side_effect=AssertionError('stage input IO')),patch.object(Path,'resolve',side_effect=AssertionError('stage path IO')):
                exec(compile(raw,str(HERE/name),'exec'),module.__dict__)
            self.assertTrue(callable(CHECK.interrupt) and callable(CHECK.idle) and callable(CHECK.stop_group))

    def test_full_original30_and_additive_exact(self):
        old=json.loads((HERE/'checks.json').read_bytes());fresh=json.loads((HERE/'checks-fresh.template.json').read_bytes())
        self.assertEqual(old['checks'],fresh['checks'][:30]);self.assertEqual(46,fresh['check_count']);self.assertEqual(46,len({r['label'] for r in fresh['checks']}))
        catalog=json.loads((HERE/'inspected-test-catalog.json').read_bytes());names={r['name'] for r in catalog['tests']}
        added=fresh['checks'][30:]
        for role in ('A','R','B'):
            for group in ('common-retirement','private-append'):
                selected=[r for r in added if r['variant']==role and r['additive_group']==group]
                self.assertEqual(2,len(selected));self.assertEqual({False,True},{'-race' in r['argv'] for r in selected})
                for row in selected:self.assertTrue(set(next(iter(row['required_matches'].values()))).issubset(names))
        self.assertEqual(4,len([r for r in added if r['additive_group']=='combined']))

    def test_bound_rejects_drift_extra_keys_and_alias(self):
        with tempfile.TemporaryDirectory(dir=HERE) as td:
            p=Path(td)/'value.json';p.write_text('{"ok":1}');ref=dict(path=str(p),sha256=PC.sha(p))
            self.assertEqual({'ok':1},PC.bound(ref))
            with self.assertRaises(ValueError):PC.bound(dict(ref,extra=True))
            p.write_text('{"ok":2}')
            with self.assertRaises(ValueError):PC.bound(ref)
            link=Path(td)/'link.json';link.symlink_to(p)
            with self.assertRaises(ValueError):PC.bound(dict(path=str(link),sha256=PC.sha(link)))

    def test_compiler_closure_tracks_embed_assembly_cgo_modules_and_drift(self):
        with tempfile.TemporaryDirectory(dir=HERE) as td:
            source=Path(td);files={}
            for name in ('main.go','native.c','native.h','fast.s','asset.txt','go.mod','go.sum','profile_artifact_dir_test.go'):
                p=source/name;p.write_text(name);data=p.read_bytes();files[name]=dict(mode='100644',blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
            package=dict(Dir=str(source),ImportPath='example/main',GoFiles=['main.go'],CFiles=['native.c'],HFiles=['native.h'],SFiles=['fast.s'],EmbedFiles=['asset.txt'],TestGoFiles=['profile_artifact_dir_test.go'],Module=dict(Dir=str(source),GoMod=str(source/'go.mod')))
            closure=PC.compiler_inputs([package],source,dict(files=files))
            self.assertEqual(5,len(closure['selected_files']));self.assertEqual(2,len(closure['module_files']))
            self.assertEqual(['profile_artifact_dir_test.go'],closure['test_classification']['example/main']['TestGoFiles'])
            PC.verify_bindings(closure['selected_files']);(source/'asset.txt').write_text('changed')
            with self.assertRaises(ValueError):PC.verify_bindings(closure['selected_files'])
            package['Incomplete']=True
            with self.assertRaises(ValueError):PC.compiler_inputs([package],source,dict(files=files))

    def test_work_inputs_retains_generated_and_actual_import_archives(self):
        with tempfile.TemporaryDirectory(dir=HERE) as td:
            root=Path(td);work=root/'work';work.mkdir();cache=root/'cached.a';cache.write_bytes(b'archive');(work/'generated.c').write_text('generated');(work/'importcfg').write_text('packagefile example='+str(cache)+'\n');err=root/'stderr';err.write_text('WORK='+str(work)+'\n')
            got=PC.work_inputs(err);self.assertEqual(2,len(got['generated_and_work_files']));self.assertEqual(str(cache),next(iter(got['actual_import_archives'])))
            err.write_text('WORK='+str(work)+'\nWORK='+str(work)+'\n')
            with self.assertRaises(ValueError):PC.work_inputs(err)

    def test_cached_package_export_archives_are_bound(self):
        with tempfile.TemporaryDirectory(dir=HERE) as td:
            archive=Path(td)/'compiled.a';archive.write_bytes(b'actual-cache-archive')
            got=PC.package_exports([dict(ImportPath='unsafe'),dict(ImportPath='example/main',Export=str(archive))]);self.assertIn(str(archive),got);PC.verify_bindings(got)
            with self.assertRaises(ValueError):PC.package_exports([dict(ImportPath='example/main')])

    def test_native_scope_requires_complete_review_and_detects_drift(self):
        with tempfile.TemporaryDirectory(dir=HERE) as td:
            root=Path(td);categories={};expected={}
            for category in ('toolchain','compiler_linker_tools','native_headers_sysroots','native_libraries'):
                p=root/category;p.write_text(category);categories[category]=[str(p)];expected[str(p)]=dict(PC.file_binding(p),category=category)
            scope=dict(accepted_by_root=True,complete_build_input_scope_reviewed=True,qualification=False,collection_authorized=False,categories=categories,expected_files=expected,expected_directory_aliases={},expected_dangling_symlinks={},expected_namespace_aliases={})
            p=root/'scope.json';p.write_text(json.dumps(scope));ref=dict(path=str(p),sha256=PC.sha(p));self.assertEqual(expected,PC.native_scope(dict(native_input_scope=ref),dict(native_input_scope=ref)))
            (root/'toolchain').write_text('drift')
            with self.assertRaises(ValueError):PC.native_scope(dict(native_input_scope=ref),dict(native_input_scope=ref))

    def test_directory_alias_binding_retarget_and_explicit_coverage(self):
        with tempfile.TemporaryDirectory(dir=HERE) as td:
            root=Path(td);headers=root/'headers';headers.mkdir();target=root/'target';target.mkdir();other=root/'other';other.mkdir()
            (target/'api.h').write_text('same bytes');(other/'api.h').write_text('same bytes');alias=headers/'external';alias.symlink_to(target,target_is_directory=True)
            categories={}
            for category in ('toolchain','compiler_linker_tools','native_libraries'):
                p=root/category;p.write_text(category);categories[category]=[str(p)]
            categories['native_headers_sysroots']=[str(headers),str(target),str(other)]
            def expected_files():
                files={}
                for category,roots in categories.items():
                    for name in roots:
                        p=Path(name)
                        for leaf in ([p] if p.is_file() else sorted(p.rglob('*'))):
                            if leaf.is_file():files[str(leaf)]=dict(PC.file_binding(leaf),category=category)
                return files
            expected_alias={str(alias):dict(path=str(alias),link_text=str(target),resolved=str(target))}
            scope=dict(accepted_by_root=True,complete_build_input_scope_reviewed=True,qualification=False,collection_authorized=False,categories=categories,expected_files=expected_files(),expected_directory_aliases=expected_alias,expected_dangling_symlinks={},expected_namespace_aliases={})
            scope_path=root/'scope.json'
            def run_scope():
                scope_path.write_text(json.dumps(scope));ref=dict(path=str(scope_path),sha256=PC.sha(scope_path));return PC.native_scope(dict(native_input_scope=ref),dict(native_input_scope=ref))
            self.assertEqual(scope['expected_files'],run_scope())
            # Same byte content at another already-covered target cannot launder retarget.
            alias.unlink();alias.symlink_to(other,target_is_directory=True)
            with self.assertRaisesRegex(ValueError,'directory aliases differ'):run_scope()
            # Same target, different link text also rejects.
            alias.unlink();alias.symlink_to('../target',target_is_directory=True)
            with self.assertRaisesRegex(ValueError,'directory aliases differ'):run_scope()
            alias.unlink();alias.symlink_to(target,target_is_directory=True)
            categories['native_headers_sysroots']=[str(headers),str(other)];scope['expected_files']=expected_files()
            with self.assertRaisesRegex(ValueError,'uncovered canonical target'):run_scope()

    def test_strict_scope_enumeration_failure_and_missing_alias_binding(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory(dir=HERE) as td:
            root=Path(td);nested=root/'nested';nested.mkdir()
            with patch.object(PC.os,'scandir',side_effect=PermissionError('denied')):
                with self.assertRaises(PermissionError):list(PC.strict_scope_entries(root))
            missing=root/'missing-link';missing.symlink_to(root/'absent')
            categories={};expected={}
            for category in ('toolchain','compiler_linker_tools','native_libraries'):
                p=root/category;p.write_text(category);categories[category]=[str(p)];expected[str(p)]=dict(PC.file_binding(p),category=category)
            categories['native_headers_sysroots']=[str(nested)]
            (nested/'alias').symlink_to(root/'absent')
            alias=nested/'alias';namespace=root/'namespace';namespace.symlink_to(nested,target_is_directory=True)
            scope=dict(accepted_by_root=True,complete_build_input_scope_reviewed=True,qualification=False,collection_authorized=False,categories=categories,expected_files=expected,expected_directory_aliases={},expected_dangling_symlinks={str(alias):dict(path=str(alias),link_text=str(root/'absent'),resolved_missing_target=str(root/'absent'))},expected_namespace_aliases={str(namespace):dict(path=str(namespace),link_text=str(nested),resolved=str(nested))})
            p=root/'scope.json'
            def run():
                p.write_text(json.dumps(scope));ref=dict(path=str(p),sha256=PC.sha(p));return PC.native_scope(dict(native_input_scope=ref),dict(native_input_scope=ref))
            self.assertEqual(expected,run())
            scope['expected_dangling_symlinks']={}
            with self.assertRaisesRegex(ValueError,'missing native namespace'):run()
            scope['expected_dangling_symlinks']={str(alias):dict(path=str(alias),link_text=str(root/'absent'),resolved_missing_target=str(root/'absent'))}
            namespace.unlink();namespace.symlink_to(root,target_is_directory=True)
            with self.assertRaisesRegex(ValueError,'top-level namespace alias drift'):run()

    def test_required_subtest_pass_no_skip_all_roles(self):
        package='github.com/snissn/gomap/TreeDB/db'
        for role in ('A','R','B',None):
            row=dict(argv=['go','test','./TreeDB/db'],required_matches={package:['TestOwned','TestOwned/sub']},exact_match_set=False)
            if role:row['variant']=role
            events=[dict(Package=package,Action='pass',Test='TestOwned'),dict(Package=package,Action='pass',Test='TestOwned/sub'),dict(Package=package,Action='pass')]
            self.assertEqual({package:['TestOwned']},CHECK.validate_events(row,events))
            with self.assertRaises(ValueError):CHECK.validate_events(row,events+[dict(Package=package,Action='skip',Test='TestOwned/sub')])
            with self.assertRaises(ValueError):CHECK.validate_events(row,[e for e in events if e.get('Test')!='TestOwned/sub'])
            with self.assertRaises(ValueError):CHECK.validate_events(row,events+[dict(Package=package,Action='fail')])

    def test_additive_unknown_subtest_skip_rejects(self):
        package='github.com/snissn/gomap/TreeDB/db';row=dict(argv=['go','test','./TreeDB/db'],variant='A',additive_group='private-append',required_matches={package:['TestAppend']},exact_match_set=True)
        events=[dict(Package=package,Action='pass',Test='TestAppend'),dict(Package=package,Action='pass'),dict(Package=package,Action='skip',Test='TestAppend/unlisted')]
        with self.assertRaises(ValueError):CHECK.validate_events(row,events)

    def test_unconditional_kill_and_join_after_leader_exit(self):
        proc=types.SimpleNamespace(pid=987654,wait=lambda timeout:0)
        for module in (PC,CHECK):
            sent=[]
            with patch.object(module.os,'killpg',side_effect=lambda pid,sig:sent.append((pid,sig))),patch.object(module,'live_group_members',return_value=(False,[])):
                result=module.stop_group(proc)
            self.assertEqual([(proc.pid,signal.SIGTERM),(proc.pid,signal.SIGKILL)],sent);self.assertTrue(result['direct_child_joined'] and result['quiescent'])

    def test_archive_missing_and_traversal_reject_before_extraction(self):
        with tempfile.TemporaryDirectory(dir=HERE) as td:
            root=Path(td);p=root/'archive.tar'
            with tarfile.open(p,'w') as tar:
                item=tarfile.TarInfo('../escape');item.size=0;tar.addfile(item)
            with self.assertRaises(RuntimeError):BUILD.extract_archive(p,root/'source',dict(files={'x':dict(mode='100644',blob='0'*40)}))
            self.assertFalse((root/'source').exists())
            with tarfile.open(p,'w'):pass
            with self.assertRaises(RuntimeError):BUILD.extract_archive(p,root/'source',dict(files={'x':dict(mode='100644',blob='0'*40)}))

    def test_original_cleanup_functions_equal(self):
        original=HERE.parent/'qualification-v9-selected-source-preparation-v1'/'correctness-only-v2.py'
        old=ast.parse(original.read_bytes());new=ast.parse((HERE/'correctness-only-v12.py').read_bytes())
        for name in ('interrupt','idle','live_group_members','stop_group'):
            left=next(x for x in old.body if isinstance(x,ast.FunctionDef) and x.name==name);right=next(x for x in new.body if isinstance(x,ast.FunctionDef) and x.name==name)
            self.assertEqual(ast.dump(left,include_attributes=False),ast.dump(right,include_attributes=False),name)

if __name__=='__main__':unittest.main(verbosity=2)
