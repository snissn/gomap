"""Root-owned source-only context preparation; no campaign commands or DB opens.

CLI: REQUEST SHA256. Inputs are coordinator-accepted, actual source decisions.
The selected applicability verifier checks the full original physical closure.
Every output is exclusive. A failed attempt is retained, never overwritten.
"""
if not __debug__:
    raise RuntimeError('assertions required')
import hashlib
import json
from pathlib import Path
import sys
import time
import types

PROVENANCE_BASE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
CAMPAIGN_ROOT = Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def bound(ref):
    p = Path(ref['path'])
    assert p.is_absolute() and p.is_file() and not p.is_symlink()
    assert p.resolve(strict=True) == p and sha(p) == ref['sha256']
    return json.loads(p.read_bytes())


def emit(p, value):
    with p.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
    return dict(path=str(p), sha256=sha(p))


def main():
    assert sys.pycache_prefix is None and len(sys.argv) == 3
    request_ref = dict(path=sys.argv[1], sha256=sys.argv[2])
    request = bound(request_ref)
    assert request['accepted_by_root'] is True
    assert request['collection_authorized'] is False and request['qualification'] is False
    root = Path(request['campaign_root'])
    assert root == CAMPAIGN_ROOT and root.name == 'qualification-v10' and root.resolve(strict=True) == root
    for directory in (root, root / 'plans', root / 'receipts'):
        assert not directory.is_symlink()
        if not directory.exists():
            continue
        assert directory.is_dir() and directory.resolve(strict=True) == directory
        for p in directory.iterdir():
            name = p.name
            if directory.name == 'receipts':
                for prefix in ('ar-orchestration-', 'orchestration-'):
                    if name.startswith(prefix):
                        name = name[len(prefix):]
                        break
            assert not name.startswith(('cal-', 'guard-', 'pairs-', 'ar-', 'online-'))
    lock = bound(request['source_lock'])
    assert request['source_lock']['sha256'] == 'bda4d2486d2e66ee33533d601d216092ce1cd8f5211cfb02aac0d9d2bf823c75'
    manifest = json.loads((root / 'manifest.json').read_bytes())
    assert manifest == lock['manifest'] and sha(root / 'manifest.json') == lock['manifest_sha256']
    h = bound(request['common_harness'])
    assert h['accepted_by_root'] is True and h['landed_on_main'] is True
    assert h['landed_tree'] == lock['candidate_h_tree']
    current = bound(request['current_host_readback'])
    assert current['accepted_by_root'] is True and current['campaign_root'] == str(root)
    for ref in request['prospective_source_selection'].values():
        p = Path(ref['path'])
        assert p.is_file() and not p.is_symlink() and p.resolve(strict=True) == p
        assert sha(p) == ref['sha256']
        if p.suffix == '.py':
            assert not (p.parent / '__pycache__').exists()
    original = bound(lock['origin_inventory'])
    origin_input = request['original_root_input']
    assert origin_input['accepted_by_root'] is True and origin_input['collection_authorized'] is False
    here = Path(__file__).resolve().parent
    out = root.parent / 'qualification-v10-prospective-root-v1'
    out.mkdir()
    if not (root / 'plans').exists():
        (root / 'plans').mkdir()
    deployment = dict(request['deployment'])
    assert deployment['accepted_by_root'] is True and deployment['collection_authorized'] is False
    assert deployment['qualification'] is False and deployment['campaign_root'] == str(root)
    for ref in deployment['helpers'].values():
        p = Path(ref['path'])
        assert p.is_file() and not p.is_symlink() and p.resolve(strict=True) == p
        assert sha(p) == ref['sha256'] and not (p.parent / '__pycache__').exists()
    deployment_ref = emit(out / 'deployment.accepted.json', deployment)
    decision = dict(schema=1, accepted_by_root=True, accepted_ns=time.time_ns(),
                    qualification=False, collection_authorized=False, performance_accepted=False,
                    campaign_root=str(root), v10_source_lock=request['source_lock'],
                    common_harness=request['common_harness'], current_host_readback=request['current_host_readback'],
                    preserves_original_receipt_heads_paths_times=True,
                    historical_calibration_or_pair_results_reused=False,
                    request=request_ref, prospective_source_selection=request['prospective_source_selection'])
    decision_ref = emit(here / 'reuse-applicability.accepted-v1.json', decision)
    inventory = dict(original)
    inventory.update(collector_source=str(PROVENANCE_BASE / 'source-qualification-v10-common-H'),
                     origin_inventory=lock['origin_inventory'], common_harness=request['common_harness'],
                     reuse_applicability=decision_ref)
    inventory_ref = emit(root / 'inventory-complete.json', inventory)
    now = time.time_ns()
    root_input = dict(origin_input)
    root_input.update(campaign_id=request['campaign_id'], campaign_root=str(root),
                      inventory_sha256=inventory_ref['sha256'], manifest_sha256=lock['manifest_sha256'],
                      common_inventory=dict(manifest=lock['manifest_sha256'],
                                            receipts={k: v['sha256'] for k, v in manifest['receipts'].items()}),
                      composition_sha256=bound(lock['origin_correctness'])['composition_sha256'],
                      source_freeze=lock['origin_source_freeze'], native_correctness_receipt=lock['origin_correctness'],
                      v10_source_lock=request['source_lock'], reuse_applicability=decision_ref,
                      deployment_binding=deployment_ref, source_frozen_ns=now, accepted_ns=time.time_ns(),
                      prospective_source_selection=request['prospective_source_selection'],
                      original_root_input_provenance=request['original_root_input_provenance'],
                      source_context_request=request_ref)
    root_input_ref = emit(root.parent / 'qualification-v10-source-freeze-root-input-v1.json', root_input)
    app_ref = deployment['helpers']['reuse_applicability']
    assert app_ref == dict(path=str(here/'v10_applicability.py'), sha256='86ac1a866ed604705c86f3403c152e16dc5078a9802b0cd22f8bf9ce0d0d1362')
    app_path = Path(app_ref['path'])
    assert not (app_path.parent / '__pycache__').exists()
    app = types.ModuleType('v10_applicability')
    app.__file__ = str(app_path)
    exec(compile(app_path.read_bytes(), str(app_path), 'exec'), app.__dict__)
    app.verify(root, inventory, root_input)
    result = dict(schema=1, source_only=True, qualification=False, collection_authorized=False,
                  native_commands_launched=0, database_opens=0, original_full_applicability_verified=True,
                  request=request_ref, deployment=deployment_ref, reuse_applicability=decision_ref,
                  inventory=inventory_ref, root_input=root_input_ref, finished_ns=time.time_ns())
    ref = emit(here / 'root-source-context-readback-v1.json', result)
    print(json.dumps(dict(result=ref, **result)))


if __name__ == '__main__':
    main()
