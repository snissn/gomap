"""Read-only reuse/common-H checks; source preparation does not grant authority.

This module reads exact original v9 evidence; it never rewrites that evidence,
executes a native command, or accepts qualification. Root supplies the landed-H
and current-host decisions after independent review. Optimized Python is refused.
"""
if not __debug__:
    raise RuntimeError('v10 applicability requires unoptimized Python')
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time

PROVENANCE_BASE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
CAMPAIGN_ROOT = Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')


def require(ok, why):
    if not ok:
        raise ValueError(why)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            h.update(data)
    return h.hexdigest()


def bound(ref):
    require(set(ref) == {'path', 'sha256'}, 'exact path/SHA reference required')
    p = Path(ref['path'])
    require(p.is_absolute() and p.is_file() and not p.is_symlink() and
            str(p.resolve(strict=True)) == str(p), 'canonical regular input required')
    require(re.fullmatch('[0-9a-f]{64}', ref['sha256']) and sha(p) == ref['sha256'], 'input digest drift: '+str(p))
    return json.loads(p.read_bytes())


def common_harness(root, inventory, lock):
    h = bound(inventory['common_harness'])
    require(h['accepted_by_root'] is True and h['landed_on_main'] is True,
            'actual root-accepted landed H proof required')
    require(h['qualification'] is False and h['collection_authorized'] is False,
            'source binding cannot grant collection/qualification')
    require(re.fullmatch('[0-9a-f]{40}', h['landed_head']) and h['landed_tree'] == lock['candidate_h_tree'],
            'landed H must have reviewed candidate tree; changed tree needs new review')
    require(h['product_base_head'] == lock['pins']['A']['head'] and
            h['changed_paths_from_product_A'] == lock['h_changed_paths'], 'H/product applicability drift')
    require(h['engines'] == ['A', 'R', 'B'] and h['held_excluded'] == [5004, 5006],
            'one common collector for all engines; held candidates excluded')
    source = Path(inventory['collector_source'])
    require(root == CAMPAIGN_ROOT and source == PROVENANCE_BASE/'source-qualification-v10-common-H' and
            source.is_dir() and not source.is_symlink(), 'wrong common-H export')
    # Normal Python import may read cached bytecode even with -B. Bind the
    # entire selected import closure before any common-H source is imported.
    expected_objects = {'scripts'} | {v['path'] for v in lock['runtime_harness'].values()}
    actual_objects = list(source.rglob('*'))
    require({p.relative_to(source).as_posix() for p in actual_objects} == expected_objects,
            'common-H export contains an unselected import object')
    require(all(not p.is_symlink() and p.resolve(strict=True) == p for p in actual_objects) and
            (source/'scripts').is_dir(), 'common-H export must be canonical without symlinks')
    expected = {}
    for role, binding in lock['runtime_harness'].items():
        p = source/binding['path']
        require(p.is_file() and not p.is_symlink() and sha(p) == binding['sha256'], 'common harness byte drift')
        require(('100755' if p.stat().st_mode & 0o111 else '100644') == binding['mode'], 'common harness mode drift')
        expected[role] = str(p)
    require(h['runtime_harness'] == lock['runtime_harness'] and h['harness_files'] == expected,
            'common H mode/blob/SHA or executable selection mismatch')
    return h


def tracked_export(export, tree):
    export = Path(export)
    require(export.is_dir() and not export.is_symlink(), 'original source export missing')
    expected = tree['files']
    actual = {str(p.relative_to(export)) for p in export.rglob('*') if p.is_file() or p.is_symlink()}
    require(actual == set(expected), 'full tracked export file set drift')
    for relative, binding in expected.items():
        p = export/relative
        if binding['mode'] == '120000':
            require(p.is_symlink(), 'tracked link mode drift')
            data = os.readlink(p).encode()
        else:
            require(binding['mode'] in ('100644', '100755') and p.is_file() and not p.is_symlink(), 'unsupported/tracked file mode drift')
            require(('100755' if p.stat().st_mode & 0o111 else '100644') == binding['mode'], 'tracked executable mode drift')
            data = p.read_bytes()
        require(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest() == binding['blob'], 'tracked Git blob drift: '+relative)


def verify(root, inventory, root_input):
    """Validate all reuse inputs; leave authorization to original binder/launcher."""
    root = Path(root)
    require(root == CAMPAIGN_ROOT and root.name == 'qualification-v10', 'fresh v11 campaign namespace required')
    require(root_input['v10_source_lock']['sha256'] == SOURCE_LOCK_SHA256, 'reviewed source lock required')
    lock = bound(root_input['v10_source_lock'])
    decision = bound(root_input['reuse_applicability'])
    require(inventory['reuse_applicability'] == root_input['reuse_applicability'], 'inventory/root reuse binding mismatch')
    require(decision['accepted_by_root'] is True and decision['qualification'] is False and
            decision['collection_authorized'] is False and decision['performance_accepted'] is False,
            'root source applicability decision required; no acceptance of performance')
    require(decision['v10_source_lock'] == root_input['v10_source_lock'] and decision['campaign_root'] == str(root), 'wrong reuse decision scope')
    require(decision['common_harness'] == inventory['common_harness'], 'root applicability must select exact common H proof')
    require(decision['preserves_original_receipt_heads_paths_times'] is True and
            decision['historical_calibration_or_pair_results_reused'] is False, 'historical evidence cannot become fresh qualification data')
    origin = bound(lock['origin_inventory'])
    require(inventory['origin_inventory'] == lock['origin_inventory'], 'original inventory provenance missing')
    # The only semantic selection change is a separate common collector. Every
    # original inventory field, including old landed_harness_head, stays intact.
    extra = {'collector_source', 'origin_inventory', 'common_harness', 'reuse_applicability'}
    require(set(inventory) == set(origin) | (extra-{'collector_source'}), 'unexpected reused inventory fields')
    require({k:v for k,v in inventory.items() if k not in extra} ==
            {k:v for k,v in origin.items() if k not in extra}, 'original inventory evidence relabelled')
    require(sha(root/'manifest.json') == lock['manifest_sha256'], 'product manifest must remain byte-identical')
    manifest = json.loads((root/'manifest.json').read_bytes())
    require(manifest == lock['manifest'], 'product manifest implementation/control drift')
    require(root_input['source_freeze'] == lock['origin_source_freeze'] and
            root_input['native_correctness_receipt'] == lock['origin_correctness'], 'original source/native receipt required')
    for path, digest in lock['original_actual_files'].items():
        p = Path(path)
        require(p.is_file() and not p.is_symlink() and sha(p) == digest, 'original actual evidence missing/drift: '+path)
    for role, ref in lock['tracked_manifests'].items():
        tree = bound(ref)
        require((tree['head'], tree['tree']) == (lock['pins'][role]['head'], lock['pins'][role]['tree']), 'tracked head/tree drift')
        tracked_export(Path(lock['source_paths'][role]), tree)
    for slot, source in manifest['sources'].items():
        for campaign in (root, Path(lock['origin_campaign'])):
            binary = campaign/'bin'/source['binary']
            require(binary.is_file() and not binary.is_symlink() and binary.stat().st_mode & 0o111, 'canonical executable binary required')
        require(sha(root/'bin'/source['binary']) == source['binary_sha256'] and
                sha(Path(lock['origin_campaign'])/'bin'/source['binary']) == source['binary_sha256'], 'reused binary drift: '+slot)
    go = Path(lock['go_tool']['path'])
    require(go.is_file() and not go.is_symlink() and go.stat().st_mode & 0o111 and
            sha(go) == lock['go_tool']['sha256'], 'Go1.26.3 executable drift')
    for path, library in manifest['libraries'].items():
        require(str(Path(path).resolve(strict=True)) == library['resolved'] and
                sha(path) == library['sha256'], 'native library target/bytes drift')
    h = common_harness(root, inventory, lock)
    readback = bound(decision['current_host_readback'])
    require(readback['accepted_by_root'] is True and readback['campaign_root'] == str(root) and
            readback['qualification'] is False and readback['collection_authorized'] is False, 'current host read-back acceptance required')
    require(readback['build_env'] == manifest['build_env'] and
            readback['original_runner_inventory_sha256'] == manifest['receipts']['runner']['sha256'] and
            readback['same_host_kernel_cpu_filesystem_as_original'] is True and
            readback['clock_and_serialization_accepted'] is True and
            readback['no_heavy_campaign_processes'] is True, 'current environment/host/clock/quiescence proof required')
    require(readback['actual_files'] == lock['required_current_files'], 'current read-back must cover all reused binaries/tool/libraries')
    for path, digest in readback['actual_files'].items():
        require(sha(path) == digest, 'current selected implementation byte drift')
    previous_runner = json.loads((Path(lock['origin_campaign'])/manifest['receipts']['runner']['path']).read_bytes())
    current_runner = bound(readback['runner_receipt'])
    require(type(current_runner['recorded_ns']) is int and
            lock['latest_origin_accepted_ns'] < current_runner['recorded_ns'] <= readback['read_ns'], 'fresh actual runner raw required')
    for name in ('host','uname','mount','ntp'):
        current, previous = current_runner[name], previous_runner[name]
        require(current['rc'] == 0 and current['stderr'] == '' and current['stdout'] == previous['stdout'], 'current host/kernel/filesystem/clock raw drift: '+name)
        expected_argv = [str(root) if arg == lock['origin_campaign'] else arg for arg in previous['argv']]
        require(current['argv'] == expected_argv, 'wrong current host probe: '+name)
    def stable_cpu(raw):
        # Scaling MHz is an instantaneous observation, not CPU identity. It is
        # retained in actual raw; every other original lscpu line is compared.
        return [line for line in raw.splitlines() if not line.startswith('CPU(s) scaling MHz:')]
    require(current_runner['cpu']['rc'] == 0 and current_runner['cpu']['stderr'] == '' and
            current_runner['cpu']['argv'] == previous_runner['cpu']['argv'] and
            stable_cpu(current_runner['cpu']['stdout']) == stable_cpu(previous_runner['cpu']['stdout']), 'current CPU identity drift')
    for name in ('external_tools','clock_resolution','clock_contract','cache_state'):
        require(current_runner[name] == previous_runner[name], 'current tools/clock/cache control drift: '+name)
    require(current_runner['serial_collection'] is True and current_runner['owner'] == '/root' and
            current_runner['processes']['argv'] == previous_runner['processes']['argv'] and
            current_runner['processes']['rc'] == 0 and current_runner['processes']['stderr'] == '' and
            isinstance(current_runner['processes']['stdout'],str) and current_runner['processes']['stdout'], 'current serialized process raw required')
    scripts = str(Path(h['harness_files']['maintenance']).parent)
    for name in ('owned_process_rss', 'unified_bench_quicksilver_capture', 'quicksilver_maintenance'):
        if name in sys.modules:
            require(str(Path(sys.modules[name].__file__).resolve()) == str(Path(scripts)/(name+'.py')), 'previous collector import selected different bytes')
    old_path = sys.path[:]
    old_bytecode = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        sys.path.insert(0, scripts)
        module = __import__('quicksilver_maintenance')
    finally:
        sys.path[:] = old_path
        sys.dont_write_bytecode = old_bytecode
    for fixture in lock['fixtures']:
        receipt = bound(fixture['receipt'])
        require(receipt == fixture['original_receipt'] and receipt['closed'] is True and receipt['verified'] is True,
                'original closed fixture receipt required')
        require(sha(root/'fixture-receipts'/Path(fixture['receipt']['path']).name) == fixture['receipt']['sha256'], 'fixture copied receipt must keep original provenance')
        # Import the exact current common maintenance implementation only after
        # hashing it; fingerprint is read-only and does not open a database.
        require(module.fingerprint(receipt['directory']) == receipt['fingerprint'], 'closed fixture content drift')
        directory = Path(receipt['directory'])
        census = [dict(path=p.relative_to(directory).as_posix(), apparent_bytes=p.stat().st_size,
                       allocated_bytes=p.stat().st_blocks*512, device=p.stat().st_dev, inode=p.stat().st_ino)
                  for p in sorted(directory.rglob('*')) if p.is_file()]
        require(census == receipt['physical_census'], 'closed fixture physical identity drift')
    now = time.time_ns()
    require(type(readback['read_ns']) is int and type(decision['accepted_ns']) is int and
            lock['latest_origin_accepted_ns'] < readback['read_ns'] <= decision['accepted_ns'] <= root_input['source_frozen_ns'] <= now,
            'fresh host/applicability/source freeze chronology required')
    require(type(h['accepted_ns']) is int and
            lock['latest_origin_accepted_ns'] < h['accepted_ns'] <= decision['accepted_ns'] <= root_input['source_frozen_ns'] <= now,
            'actual positive landed H acceptance must precede its reuse decision and source freeze')
    return lock, decision


def selected_for_controller(root, inventory):
    """Standalone controller still has no pair authority; bind source selection."""
    decision = bound(inventory['reuse_applicability'])
    require(decision['accepted_by_root'] is True and decision['qualification'] is False and
            decision['collection_authorized'] is False and decision['performance_accepted'] is False,
            'root source applicability decision required')
    require(decision['v10_source_lock']['sha256'] == SOURCE_LOCK_SHA256 and
            decision['common_harness'] == inventory['common_harness'] and decision['campaign_root'] == str(root), 'controller applicability scope drift')
    lock = bound(decision['v10_source_lock'])
    return common_harness(Path(root), inventory, lock)

SOURCE_LOCK_SHA256 = 'bda4d2486d2e66ee33533d601d216092ce1cd8f5211cfb02aac0d9d2bf823c75'
