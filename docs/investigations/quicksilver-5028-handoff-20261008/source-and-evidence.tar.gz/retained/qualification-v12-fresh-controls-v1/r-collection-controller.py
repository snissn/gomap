"""Prospective separate R controller. No authorization supplied by preparation.
Only offline-pairs is admitted after external source/definition/global/policy
acceptance. Root controls the one native owner; B campaign files are unchanged.
"""
if not __debug__:
    raise RuntimeError('qualification orchestration requires unoptimized Python')

import hashlib
import importlib.util
import json
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')
GRID = [('primary', 24, n) for n in (30000, 300000, 3000000)]
ORDER = ['A1', 'R1', 'R2', 'A2', 'A3', 'R3']


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            h.update(data)
    return h.hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def settings(label, variant, mixture, seed, n, **extra):
    return dict(label=label, source=variant+'_unified', engine='treedb',
                case='realistic', profile='durable', keys=n, seed=seed,
                mixture=mixture, working_set='uniform', miss_percent=90,
                reads=2*n, workers=4, updates=min(40000, n//4), duration='8s',
                commit='ordinary', keep=True, profiled=False,
                rss_sample_interval_ms=200, **extra)


def main():
    assert len(sys.argv) in (4, 5), 'offline-pairs ACTIVATION ACTIVATION_SHA256 [FIXTURE]'
    stage = sys.argv[1]
    assert stage=='offline-pairs', 'R supplement can collect fresh offline pairs only'
    from r_protocol_support import verify_collection_activation
    activation = verify_collection_activation(ROOT, sys.argv[2], sys.argv[3])
    # A small complete baseline cell validates the resolved analysis plumbing
    # before the 3M cells. Selection never reduces the global frozen matrix.
    selection = sys.argv[4] if len(sys.argv) == 5 else None
    grid = GRID
    if selection is not None:
        grid = [v for v in GRID if selection == f'{v[0]}-s{v[1]}-n{v[2]}']
        assert len(grid) == 1, 'selection must name an accepted fixture'
    inventory = json.loads((ROOT/'inventory-complete.json').read_bytes())
    assert inventory['accepted_by_root'] and sha(ROOT/'manifest.json') == inventory['manifest_sha256']
    from v10_applicability import selected_for_controller
    selected_for_controller(ROOT, inventory)
    source = pathlib.Path(inventory['collector_source'])
    scripts = source/'scripts'
    sys.path.insert(0, str(scripts))
    import quicksilver_maintenance as maintenance
    import unified_bench_quicksilver_capture as unified
    env = {k: v for k, v in os.environ.items() if not k.startswith('TREEDB_')}
    env.update(json.loads((ROOT/'manifest.json').read_bytes())['build_env'])

    def capture(label, kind, plan):
        path = ROOT/'plans'/(label+'.json')
        if path.exists():
            assert json.loads(path.read_bytes()) == plan, 'resolved plan drift'
        else:
            save(path, plan)
        out = ROOT/plan['output']
        if out.exists():
            # A failed or interrupted attempt is a result, never overwritten.
            for cell in plan['cells']:
                run_path = out/(cell['label'] if kind=='offline' else '1-'+cell['label'])/'run.json'
                data = json.loads(run_path.read_bytes())
                assert data.get('validated') is True and data['rc']==0 and 'error' not in data, 'retained failed run; coordinator diagnosis required'
                started_ns=data['started_ns'] if kind=='offline' else int(data['started']*1e9)
                assert started_ns>activation['supplement_gate']['frozen_ns'], 'retained timing predates R global freeze'
                if kind=='offline':
                    run, report = maintenance.load_run(run_path)
                    assert maintenance.policy_complete(report)
            print(json.dumps(dict(reused_complete_capture=str(path), kind=kind)), flush=True)
            return
        receipt = ROOT/'receipts'/('ar-orchestration-'+label)
        receipt.mkdir(exist_ok=False)
        script = scripts/('quicksilver_maintenance.py' if kind=='offline' else 'unified_bench_quicksilver_capture.py')
        argv = ['python3', '-B', str(script)] + (['capture'] if kind=='offline' else []) + [str(ROOT/'manifest.json'), str(path)]
        record = dict(schema=1, stage=stage, command=argv, started_ns=time.time_ns(),
                      root_owner='/root', load_before=os.getloadavg(), plan_sha256=sha(path),
                      manifest_sha256=inventory['manifest_sha256'])
        print(json.dumps(dict(start=label, kind=kind, started_ns=record['started_ns'])), flush=True)
        with (receipt/'stdout.txt').open('w') as stdout, (receipt/'stderr.txt').open('w') as stderr:
            proc = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
        record.update(rc=proc.returncode, finished_ns=time.time_ns(), load_after=os.getloadavg(),
                      stdout_sha256=sha(receipt/'stdout.txt'), stderr_sha256=sha(receipt/'stderr.txt'))
        save(receipt/'run.json', record)
        print(json.dumps(dict(finish=label, rc=proc.returncode, receipt=str(receipt))), flush=True)
        assert proc.returncode == 0, 'preserved failed collector result: '+str(receipt)
        for cell in plan['cells']:
            run_path = out/(cell['label'] if kind=='offline' else '1-'+cell['label'])/'run.json'
            data = json.loads(run_path.read_bytes())
            assert data.get('validated') is True and data['rc']==0 and 'error' not in data
            if kind=='offline':
                run, report = maintenance.load_run(run_path)
                assert maintenance.policy_complete(report), 'endpoint completed without policy completion'

    def fixture(mixture, seed, n):
        slug=f'{mixture}-s{seed}-n{n}'
        receipt_path=ROOT/'fixture-receipts'/(slug+'.json')
        assert receipt_path.exists(), 'R never creates or replaces common-v3 fixtures'
        value=json.loads(receipt_path.read_bytes())
        assert maintenance.fingerprint(value['directory'])['sha256']==value['fixture_sha256']
        return value['directory'], dict(path=str(receipt_path), sha256=sha(receipt_path))

    labels=ORDER
    prefix='ar-pairs'
    for mixture, seed, n in grid:
        directory, binding=fixture(mixture, seed, n)
        for mode in ('full','exhaustive'):
            slug=f'{mixture}-s{seed}-n{n}-{mode}-b8192'
            base=dict(fixture=directory, fixture_receipt=binding, mode=mode,
                      batch_size=8192, endpoint='compact-command-wal-settle-v1', timeout_seconds=1800)
            plan=dict(output=prefix+'-'+slug,
                      cells=[dict(base,label=label,source=label[0]) for label in labels])
            capture(prefix+'-'+slug, 'offline', plan)
            # Guard each actual retained compact copy with its source binary;
            # each guard can legitimately create new debt after compact census.
            for label in labels:
                measured=str(ROOT/plan['output']/label/'db')
                guard=dict(output='ar-guard-'+slug+'-'+label, repeats=1,
                           cells=[settings(label,label[0],mixture,seed,n,measure_dir=measured)])
                capture('ar-guard-'+slug+'-'+label,'online',guard)
    print('STAGE_COMPLETE '+stage, flush=True)


if __name__=='__main__':
    main()
