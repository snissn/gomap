"""UNEXECUTED preparation: root-owned artifact writes only; no native commands.
Future CLI: bind ROOT_INPUT SHA256 NEW_OUT | check BINDING SHA256 ACTIVATION SHA256
The check command is mandatory immediately before any original calibration.
"""
if not __debug__:
    raise RuntimeError('prospective binding requires assertions enabled')
import hashlib
import json
from pathlib import Path
import re
import sys
import time
SOURCE_HERE=Path(__file__).resolve().parent
HERE=SOURCE_HERE.parent/'qualification-v10-source-preparation-v2'
BASE=HERE.parent
PROVENANCE_BASE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
CAMPAIGN_ROOT=Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')
PINS = {'A': ('192e5019e579af3b98ae4fbf4ea497bb9ccd672f', '79100a06e3258caacbc127678f1a4d17bcc9f3e6'), 'B': ('73100c5b8cc2337d9cff36c60a8e4182f1820fe9', '41331819ecb921ea477baf1997a652506700cf56'), 'R': ('6fa638b8bffa71750e1aefa0bb746bb747aa06c1', 'b4bbd98c74c21f7f68bce288341a0925c83e18f1')}
from v10_applicability import verify as verify_reuse, bound as reuse_bound, common_harness, SOURCE_LOCK_SHA256
PARENTS = ['3b72833df173d1277df88be5453a58d6d311bd81', '6fa638b8bffa71750e1aefa0bb746bb747aa06c1']

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def read(p):return json.loads(Path(p).read_bytes())
def bound(p,h):
    p=Path(p);assert p.is_absolute() and p.is_file() and not p.is_symlink()
    assert re.fullmatch('[0-9a-f]{64}',h) and sha(p)==h
    return read(p)
def save(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
    return sha(p)
def fresh(root):
    # The source inventory may exist; actual qualification producers may not.
    for pattern in ('cal-*','guard-*','pairs-*','ar-pairs-*','ar-guard-*','online-primary-*'):
        assert not list(root.glob(pattern)), 'original calibration/pair namespace already exists: '+pattern

def immutable():
    m=read(HERE/'immutable-inputs.json')
    for p,h in m.items():assert sha(BASE/p)==h, 'immutable preparation input drift: '+p
    return m

def actual(i):
    assert i['accepted_by_root'] is True and i['qualification'] is False
    assert i['binding_writes_authorized'] is True and i['collection_authorized'] is False
    for k in ('native_correctness_accepted','source_performance_admissibility_accepted','landed_harness_attested','host_clock_and_serialization_accepted'):
        assert i[k] is True, 'actual root decision missing: '+k
    assert i['actual_receipt_contents_accepted']=={r:True for r in ('source','build','native','runner')}
    root=Path(i['campaign_root']);assert root.is_absolute() and root.is_dir() and not root.is_symlink() and root.name=='qualification-v10' and root==CAMPAIGN_ROOT
    fresh(root)
    inv=bound(root/'inventory-complete.json',i['inventory_sha256'])
    assert i['v10_source_lock']['sha256']==SOURCE_LOCK_SHA256
    verify_reuse(root,inv,i)
    assert inv['accepted_by_root'] is True and inv['qualification'] is False and inv['performance_runs']==0
    assert type(inv['content_accepted_ns']) is int
    manifest=bound(root/'manifest.json',i['manifest_sha256'])
    assert inv['manifest_sha256']==i['manifest_sha256'] and set(manifest['receipts'])=={'source','build','native','runner'}
    assert i['sources']==manifest['sources'] and i['libraries']==manifest['libraries']
    assert i['receipt_sha256']=={r:x['sha256'] for r,x in manifest['receipts'].items()}
    assert inv['receipts']==manifest['receipts']
    for r,x in manifest['receipts'].items():assert sha(root/x['path'])==x['sha256']
    content=bound(inv['actual_content_acceptance_path'],inv['actual_content_acceptance_sha256'])
    assert content['accepted_by_root'] is True and content['collection_authorized'] is False
    assert content['manifest_sha256']==i['manifest_sha256'] and content['receipt_sha256']==i['receipt_sha256']
    for role,(head,tree) in PINS.items():
        for slot in (role,role+'_unified'):
            source=manifest['sources'][slot]
            assert (source['head'],source['tree'])==(head,tree) and source['built_against_head']==head
            assert sha(root/'bin'/source['binary'])==source['binary_sha256']
    for p,x in manifest['libraries'].items():assert sha(p)==x['sha256']
    frozen=bound(i['source_freeze']['path'],i['source_freeze']['sha256'])
    assert frozen['accepted_by_root'] is True and frozen['collection_authorized'] is False
    assert frozen['b_normal_merge_parents']==PARENTS
    assert {r:(x['head'],x['tree']) for r,x in frozen['variants'].items()}==PINS
    assert frozen['held_excluded']==[5004,5006]
    assert type(i['source_frozen_ns']) is int and inv['content_accepted_ns']<=i['source_frozen_ns']<=time.time_ns()
    correctness=bound(i['native_correctness_receipt']['path'],i['native_correctness_receipt']['sha256'])
    assert correctness['accepted_by_root'] is True and correctness['native_correctness_accepted'] is True
    assert correctness['qualification'] is False and correctness['collection_authorized'] is False
    assert correctness['performance_accepted'] is False and correctness['commands']==46
    assert correctness['original30_rows_preserved'] is True and correctness['additive_check_count']==16
    assert correctness['manifest_sha256']==i['manifest_sha256']
    assert correctness['composition_sha256']=='b9342c5a67c83d26046eaede93c223dd91e1427af51a3e4ba4c8e98cada2bfc9'
    assert {r:(v['head'],v['tree']) for r,v in correctness['variants'].items()}==PINS
    assert correctness['held_excluded']==[5004,5006]
    assert correctness['inventory_actual_content_acceptance_sha256']==inv['actual_content_acceptance_sha256']
    assert correctness['checks_sha256']=='4aa3a4c2ac28204ed1807292bee64a0a01b9b434ee32fd16940b8e7349c506b7'
    assert type(correctness['accepted_ns']) is int and correctness['accepted_ns']<=i['source_frozen_ns']
    for path,digest in correctness['files'].items():assert sha(path)==digest
    assert isinstance(i['campaign_id'],str) and i['campaign_id']
    return root,manifest

def original_calibration_selection(anchor, root, imm, manifest):
    # Presence in files is insufficient: executable selectors must choose the
    # actual immutable original B definition/evaluator/analysis driver.
    assert anchor['schema']==1
    selections={
        'definition':'qualification-prep/revised-draft/protocol-definition-root-frozen.json',
        'evaluator':'qualification-prep/evaluator.py',
        'driver':'qualification-analysis-controller.py'}
    for field, relative in selections.items():
        path=(BASE/relative).resolve(strict=True)
        assert anchor[field]==str(path), 'wrong original B '+field+' selection'
        assert path.is_file() and anchor['files'][str(path)]==imm[relative]
        assert sha(path)==imm[relative], 'selected original '+field+' digest drift'
    definition=read(anchor['definition'])
    assert definition['accepted_by_root'] is True and definition['selected_candidate_variants']==['B']
    for field in ('landed_harness_attested','receipt_contents_accepted','host_clock_and_serialization_accepted'):
        assert anchor[field] is True, 'original anchor acceptance missing: '+field
    # Empty/weakened controls would disable original runtime comparisons.
    assert anchor['controls']==manifest['build_env'], 'original anchor controls differ from actual manifest'
    inventory=read(root/'inventory-complete.json')
    lock=reuse_bound(bound(anchor['v10_root_input'],anchor['v10_root_input_sha256'])['v10_source_lock'])
    harness=common_harness(root,inventory,lock)
    source=Path(inventory['collector_source']).resolve(strict=True)
    names={'observer':'owned_process_rss.py','collector':'unified_bench_quicksilver_capture.py','maintenance':'quicksilver_maintenance.py'}
    expected={field:str((source/'scripts'/name).resolve(strict=True)) for field,name in names.items()}
    assert anchor['harness_files']==expected, 'wrong actual original collector selection'
    for path in expected.values():
        selected=Path(path)
        assert selected.is_file() and anchor['files'][path]==sha(selected), 'selected harness digest drift'


def main():
    imm=immutable(); mode=sys.argv[1]
    if mode=='bind':
        assert len(sys.argv)==5
        inp=Path(sys.argv[2]);i=bound(inp,sys.argv[3]);root,m=actual(i)
        out=Path(sys.argv[4]);assert out.is_absolute() and out.parent==root and not out.exists()
        out.mkdir(); files={}
        def emit(name,v):
            p=out/name;h=save(p,v);files[str(p)]=h;return str(p),h
        definition=read(BASE/'r-material-gate-preparation-v2/r-definition.draft.json')
        assert definition['accepted_by_root'] is False and definition['candidate_source_pins'] is None
        definition.update(accepted_by_root=True,status='ROOT_FROZEN_PROSPECTIVE_R_SUPPLEMENT',candidate_source_pins={r:m['sources'][r] for r in ('A','R','A_unified','R_unified')})
        d,dh=emit('r-definition.accepted.json',definition)
        policy=read(BASE/'qualification-v3-policy-preparation/accounting-policy.draft.json');assert policy['accepted_by_root'] is False
        policy['accepted_by_root']=True;p,ph=emit('accounting-policy.accepted.json',policy)
        now=time.time_ns();common=dict(manifest=i['manifest_sha256'],receipts=i['receipt_sha256'])
        freeze=read(BASE/'qualification-v3-policy-preparation/accounting-freeze.template.json')
        freeze.update(accepted_by_root=True,fresh_affected_campaign=True,source_inventory_accepted=True,campaign_id=i['campaign_id'],campaign_root=str(root),common_inventory=common,source_frozen_ns=i['source_frozen_ns'],root_policy_frozen_ns=now,policy_sha256=ph)
        f,fh=emit('accounting-freeze.accepted.json',freeze)
        ext=read(BASE/'r-material-gate-preparation-v2/r-policy-extension.template.json')
        ext.update(accepted_by_root=True,universal_original_B_rule_applies_to_R=True,common_inventory=common,frozen_ns=time.time_ns(),definition_sha256=dh,original_B_accounting_policy_sha256=ph,original_B_accounting_freeze_sha256=fh)
        e,eh=emit('r-policy-extension.accepted.json',ext)
        for x in (inp,root/'inventory-complete.json',root/'manifest.json',Path(i['source_freeze']['path']),Path(i['native_correctness_receipt']['path'])):files[str(x.resolve())]=sha(x)
        correctness=bound(i['native_correctness_receipt']['path'],i['native_correctness_receipt']['sha256'])
        for path,digest in correctness['files'].items():files[str(Path(path).resolve(strict=True))]=digest
        for x in m['receipts'].values():files[str((root/x['path']).resolve())]=x['sha256']
        reuse=reuse_bound(i['reuse_applicability'])
        current_host=reuse_bound(reuse['current_host_readback'])
        for ref in (i['v10_source_lock'],i['reuse_applicability'],reuse['current_host_readback'],current_host['runner_receipt'],read(root/'inventory-complete.json')['common_harness']):
            files[ref['path']]=ref['sha256']
        lock=reuse_bound(i['v10_source_lock'])
        files.update(lock['original_actual_files'])
        for b in lock['runtime_harness'].values():
            path=str(PROVENANCE_BASE/'source-qualification-v10-common-H'/b['path']);files[path]=b['sha256']
        files[str((SOURCE_HERE/'v10_applicability.py').resolve())]=sha(SOURCE_HERE/'v10_applicability.py')
        for x in (Path(__file__),HERE/'immutable-inputs.json'):files[str(x.resolve())]=sha(x)
        for name,h in imm.items():files[str((BASE/name).resolve())]=h
        receipt=dict(schema=1,accepted_by_root=True,qualification=False,collection_authorized=False,campaign_id=i['campaign_id'],campaign_root=str(root),root_input=str(inp),root_input_sha256=sys.argv[3],common_inventory=common,definition=d,accounting_policy=p,accounting_freeze=f,r_prospective_policy_extension=e,accounting_checker=str(BASE/'qualification-v3-policy-preparation/allocation_accounting.py'),files=files,note='Root-owned prospective source/policy binding only. GH anchor and explicit calibration launch authority still required; R pair activation requires future B36/R18 freezes.')
        h=save(out/'pre-c1-binding.json',receipt);print(json.dumps(dict(binding=str(out/'pre-c1-binding.json'),sha256=h,qualification=False,collection_authorized=False)))
    elif mode=='check':
        assert len(sys.argv)==6
        receipt=bound(sys.argv[2],sys.argv[3]);activation=bound(sys.argv[4],sys.argv[5]);root=Path(receipt['campaign_root'])
        assert receipt['accepted_by_root'] is True and receipt['qualification'] is False and receipt['collection_authorized'] is False
        for p,h in receipt['files'].items():assert sha(p)==h
        checked_root,manifest=actual(bound(receipt['root_input'],receipt['root_input_sha256']))
        assert checked_root==root
        assert activation['accepted_by_root'] is True and activation['collection_authorized'] is True and activation['qualification'] is False
        assert activation['prospective_binding_sha256']==sys.argv[3] and activation['campaign_root']==str(root)
        assert activation['campaign_id']==receipt['campaign_id'] and activation['allowed_stages']==['fixtures','offline-calibration','online-calibration']
        assert re.fullmatch(r'https://github\.com/snissn/gomap/issues/[0-9]+#issuecomment-[0-9]+',activation['github_external_anchor_url'])
        anchor=bound(activation['anchor'],activation['anchor_sha256'])
        assert anchor['accepted_by_root'] is True and anchor['root']==str(root)
        for p,h in receipt['files'].items():assert anchor['files'][p]==h
        assert anchor['files'][str(Path(sys.argv[2]).resolve())]==sys.argv[3]
        for k in ('campaign_id','accounting_policy','accounting_freeze','accounting_checker'):assert anchor[k]==receipt[k]
        assert anchor['v10_root_input']==receipt['root_input'] and anchor['v10_root_input_sha256']==receipt['root_input_sha256']
        original_calibration_selection(anchor,root,imm,manifest)
        print(json.dumps(dict(status='PRE_C1_BINDINGS_PRESENT_ROOT_AUTHORIZED_CALIBRATION_ONLY',qualification=False,native_commands_launched=0)))
    else:raise ValueError('bind or check required')
if __name__=='__main__':main()
