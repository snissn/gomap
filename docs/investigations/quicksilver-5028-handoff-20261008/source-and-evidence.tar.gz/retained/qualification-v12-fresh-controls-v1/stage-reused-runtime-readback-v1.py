"""Exclusive byte-reuse staging/read-back; no database opens or qualification."""
import sys
sys.dont_write_bytecode=True
import hashlib, importlib.util, json, os, shutil, subprocess, time
from pathlib import Path
BASE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
OLD=BASE/'qualification-v12-source-inventory'; NEW=Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')
SOURCE_HERE=Path(__file__).resolve().parent
assert __debug__ and sys.pycache_prefix is None
PACK=BASE/'qualification-v10-source-preparation-v2'
LOCK=SOURCE_HERE/'v10-source-lock.json'
EXPECTED='bda4d2486d2e66ee33533d601d216092ce1cd8f5211cfb02aac0d9d2bf823c75'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as s:
  for data in iter(lambda:s.read(1<<20),b''):h.update(data)
 return h.hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def require(ok,why):
 if not ok:raise ValueError(why)
require(sha(LOCK)==EXPECTED,'lock drift')
lock=json.loads(LOCK.read_bytes());require(not NEW.exists(),'exclusive new namespace required')
NEW.mkdir();(NEW/'bin').mkdir();(NEW/'receipts').mkdir();(NEW/'fixture-receipts').mkdir()
copies={}
def copy(src,dst,digest):
 require(src.is_file() and not src.is_symlink() and sha(src)==digest,'original copy input drift')
 require(not dst.exists(),'no overwrite')
 with src.open('rb') as incoming,dst.open('xb') as out:shutil.copyfileobj(incoming,out)
 shutil.copymode(src,dst);require(sha(dst)==digest,'copied bytes drift')
 copies[str(dst)]={'original_path':str(src),'sha256':digest,'bytes':dst.stat().st_size,'mode':oct(dst.stat().st_mode&0o777)}
copy(OLD/'manifest.json',NEW/'manifest.json',lock['manifest_sha256'])
for v in lock['manifest']['receipts'].values():copy(OLD/v['path'],NEW/v['path'],v['sha256'])
for v in lock['manifest']['sources'].values():copy(OLD/'bin'/v['binary'],NEW/'bin'/v['binary'],v['binary_sha256'])
for fixture in lock['fixtures']:
 ref=fixture['receipt'];src=Path(ref['path']);copy(src,NEW/'fixture-receipts'/src.name,ref['sha256'])
require(len(copies)==18,'complete 1+4+8+5 copy selection')
original={}
for path,digest in lock['original_actual_files'].items():
 p=Path(path);require(p.is_file() and not p.is_symlink() and sha(p)==digest,'original evidence missing/drift: '+path)
 original[path]=digest
app_path=SOURCE_HERE/'v10_applicability.py'
require(sha(app_path)=='86ac1a866ed604705c86f3403c152e16dc5078a9802b0cd22f8bf9ce0d0d1362' and not (app_path.parent/'__pycache__').exists(),'selected fresh applicability source drift')
import types
app=types.ModuleType('applicability_stage');app.__file__=str(app_path)
exec(compile(app_path.read_bytes(),str(app_path),'exec'),app.__dict__)
tracked={}
for role,ref in lock['tracked_manifests'].items():
 tree=app.bound(ref);app.tracked_export(Path(lock['source_paths'][role]),tree)
 tracked[role]={'head':tree['head'],'tree':tree['tree'],'files':len(tree['files']),'actual_full_export_verified':True}
common={}
for role,b in lock['runtime_harness'].items():
 p=BASE/'source-qualification-v10-common-H'/b['path']
 require(p.is_file() and not p.is_symlink() and sha(p)==b['sha256'],'staged candidate common-H drift')
 require(('100755' if p.stat().st_mode&0o111 else '100644')==b['mode'],'candidate mode drift')
 common[role]={'path':str(p),**b}
current={}
for path,digest in lock['required_current_files'].items():
 require(sha(path)==digest,'selected binary/lib/tool drift: '+path);current[path]=digest
for path,b in lock['manifest']['libraries'].items():require(str(Path(path).resolve(strict=True))==b['resolved'],'loader target drift')
export=BASE/'source-qualification-v10-common-H'
require({v.relative_to(export).as_posix() for v in export.rglob('*')}=={'scripts'}|{v['path'] for v in lock['runtime_harness'].values()},'unselected common-H import objects')
require(all(not v.is_symlink() and v.resolve(strict=True)==v for v in export.rglob('*')),'noncanonical common-H objects')
sys.path.insert(0,str(BASE/'source-qualification-v10-common-H/scripts'))
import quicksilver_maintenance as maintenance
fixtures=[]
for f in lock['fixtures']:
 receipt=app.bound(f['receipt']);require(receipt==f['original_receipt'],'fixture provenance drift')
 require(maintenance.fingerprint(receipt['directory'])==receipt['fingerprint'],'closed fixture bytes drift')
 directory=Path(receipt['directory'])
 census=[dict(path=p.relative_to(directory).as_posix(),apparent_bytes=p.stat().st_size,allocated_bytes=p.stat().st_blocks*512,device=p.stat().st_dev,inode=p.stat().st_ino) for p in sorted(directory.rglob('*')) if p.is_file()]
 require(census==receipt['physical_census'],'fixture physical identity drift')
 fixtures.append({'receipt':f['receipt'],'directory':str(directory),'fingerprint':receipt['fingerprint'],'physical_census':census,'closed_original_provenance_retained':True})
oldrunner=json.loads((OLD/lock['manifest']['receipts']['runner']['path']).read_bytes())
runner={'schema':1,'recorded_ns':time.time_ns(),'owner':'/root','serial_collection':True,'source_only_readback':True,'qualification':False,'collection_authorized':False,'origin_runner_sha256':lock['manifest']['receipts']['runner']['sha256']}
for name in ('host','uname','cpu','storage','mount','processes','ntp'):
 argv=[str(NEW) if a==str(OLD) else a for a in oldrunner[name]['argv']]
 result=subprocess.run(argv,capture_output=True,text=True,timeout=30)
 runner[name]={'argv':argv,'rc':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
 require(result.returncode==0 and result.stderr=='','runner probe failed: '+name)
for name in ('host','uname','mount','ntp'):require(runner[name]['stdout']==oldrunner[name]['stdout'],'stable runner identity drift: '+name)
stable=lambda raw:[line for line in raw.splitlines() if not line.startswith('CPU(s) scaling MHz:')]
require(stable(runner['cpu']['stdout'])==stable(oldrunner['cpu']['stdout']),'CPU identity drift')
runner['clock_resolution']={name:vars(time.get_clock_info(name)) for name in ('time','monotonic','perf_counter')}
require(runner['clock_resolution']==oldrunner['clock_resolution'],'clock implementation drift')
# Contracts describe unchanged sampling/capture behavior; actual per-pause checks remain mandatory later.
runner['clock_contract']=oldrunner['clock_contract'];runner['cache_state']=oldrunner['cache_state']
runner['external_tools']={path:{'path':str(Path(path).resolve(strict=True)),'sha256':sha(path)} for path in oldrunner['external_tools']}
require(runner['external_tools']==oldrunner['external_tools'],'external tool identity drift')
runner['load']=list(os.getloadavg());runner['meminfo']=Path('/proc/meminfo').read_text()
runnerpath=NEW/'current-runner-readback-v1.json';save(runnerpath,runner)
packet={'schema':1,'status':'ACTUAL_NATIVE_SOURCE_REUSE_READBACK_NOT_ACTIVATION','qualification':False,'collection_authorized':False,'performance_accepted':False,'native_commands_built_or_tested':0,'database_opens':0,'v10_source_lock_sha256':EXPECTED,'campaign_root':str(NEW),'copies':copies,'original_actual_files':original,'tracked_exports':tracked,'common_H_candidate_files':common,'actual_files':current,'fixtures':fixtures,'runner_receipt':{'path':str(runnerpath),'sha256':sha(runnerpath)},'runner_raw':runner,'finished_ns':time.time_ns()}
save(NEW/'source-reuse-readback-v1.json',packet)
print(json.dumps(packet,allow_nan=False),flush=True)
