"""Root's serial orchestration of the accepted, landed original collectors."""
if not __debug__:
    raise RuntimeError('qualification orchestration requires unoptimized Python')

import hashlib
import importlib.util
import json
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')
GRID = [('primary', 24, n) for n in (30000, 300000, 3000000)] + [('holdout', 73, n) for n in (300000, 3000000)]
ORDER = ['A1', 'B1', 'B2', 'A2', 'A3', 'B3']


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            h.update(data)
    return h.hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def settings(label, variant, mixture, seed, n, **extra):
    return dict(label=label, source=variant+'_unified', engine='treedb',
                case='realistic', profile='durable', keys=n, seed=seed,
                mixture=mixture, working_set='uniform', miss_percent=90,
                reads=2*n, workers=4, updates=min(40000, n//4), duration='8s',
                commit='ordinary', keep=True, profiled=False,
                rss_sample_interval_ms=200, **extra)


def main():
    stage = sys.argv[1]
    # A small complete baseline cell validates the resolved analysis plumbing
    # before the 3M cells. Selection never reduces the global frozen matrix.
    selection = sys.argv[2] if len(sys.argv) == 3 else None
    assert len(sys.argv) in (2, 3)
    grid = GRID
    if selection is not None:
        grid = [v for v in GRID if selection == f'{v[0]}-s{v[1]}-n{v[2]}']
        assert len(grid) == 1, 'selection must name an accepted fixture'
    inventory = json.loads((ROOT/'inventory-complete.json').read_bytes())
    assert inventory['accepted_by_root'] and sha(ROOT/'manifest.json') == inventory['manifest_sha256']
    from v10_applicability import selected_for_controller
    selected_for_controller(ROOT, inventory)
    source = pathlib.Path(inventory['collector_source'])
    scripts = source/'scripts'
    sys.path.insert(0, str(scripts))
    import quicksilver_maintenance as maintenance
    import unified_bench_quicksilver_capture as unified
    env = {k: v for k, v in os.environ.items() if not k.startswith('TREEDB_')}
    env.update(json.loads((ROOT/'manifest.json').read_bytes())['build_env'])

    def capture(label, kind, plan):
        path = ROOT/'plans'/(label+'.json')
        if path.exists():
            assert json.loads(path.read_bytes()) == plan, 'resolved plan drift'
        else:
            save(path, plan)
        out = ROOT/plan['output']
        if out.exists():
            # A failed or interrupted attempt is a result, never overwritten.
            for cell in plan['cells']:
                run_path = out/(cell['label'] if kind=='offline' else '1-'+cell['label'])/'run.json'
                data = json.loads(run_path.read_bytes())
                assert data.get('validated') is True and data['rc']==0 and 'error' not in data, 'retained failed run; coordinator diagnosis required'
                if kind=='offline':
                    run, report = maintenance.load_run(run_path)
                    assert maintenance.policy_complete(report)
            print(json.dumps(dict(reused_complete_capture=str(path), kind=kind)), flush=True)
            return
        receipt = ROOT/'receipts'/('orchestration-'+label)
        receipt.mkdir(exist_ok=False)
        script = scripts/('quicksilver_maintenance.py' if kind=='offline' else 'unified_bench_quicksilver_capture.py')
        argv = ['python3', '-B', str(script)] + (['capture'] if kind=='offline' else []) + [str(ROOT/'manifest.json'), str(path)]
        record = dict(schema=1, stage=stage, command=argv, started_ns=time.time_ns(),
                      root_owner='/root', load_before=os.getloadavg(), plan_sha256=sha(path),
                      manifest_sha256=inventory['manifest_sha256'])
        print(json.dumps(dict(start=label, kind=kind, started_ns=record['started_ns'])), flush=True)
        with (receipt/'stdout.txt').open('w') as stdout, (receipt/'stderr.txt').open('w') as stderr:
            proc = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
        record.update(rc=proc.returncode, finished_ns=time.time_ns(), load_after=os.getloadavg(),
                      stdout_sha256=sha(receipt/'stdout.txt'), stderr_sha256=sha(receipt/'stderr.txt'))
        save(receipt/'run.json', record)
        print(json.dumps(dict(finish=label, rc=proc.returncode, receipt=str(receipt))), flush=True)
        assert proc.returncode == 0, 'preserved failed collector result: '+str(receipt)
        for cell in plan['cells']:
            run_path = out/(cell['label'] if kind=='offline' else '1-'+cell['label'])/'run.json'
            data = json.loads(run_path.read_bytes())
            assert data.get('validated') is True and data['rc']==0 and 'error' not in data
            if kind=='offline':
                run, report = maintenance.load_run(run_path)
                assert maintenance.policy_complete(report), 'endpoint completed without policy completion'

    def fixture(mixture, seed, n):
        slug=f'{mixture}-s{seed}-n{n}'
        receipt_path=ROOT/'fixture-receipts'/(slug+'.json')
        if receipt_path.exists():
            value=json.loads(receipt_path.read_bytes())
            assert maintenance.fingerprint(value['directory'])['sha256']==value['fixture_sha256']
            return value['directory'], dict(path=str(receipt_path), sha256=sha(receipt_path))
        plan=dict(output='fixture-'+slug, repeats=1,
                  cells=[settings('closed-source', 'A', mixture, seed, n)])
        capture('fixture-'+slug, 'online', plan)
        run_path=ROOT/('fixture-'+slug)/'1-closed-source/run.json'
        run=json.loads(run_path.read_bytes())
        report_path=run_path.parent/'stdout.json'
        report=json.loads(report_path.read_bytes())[0]
        directory=pathlib.Path(report['data_dir'])
        assert directory.is_absolute() and directory.is_dir() and run['finished']<=time.time()
        frozen=maintenance.fingerprint(directory)
        census=[dict(path=p.relative_to(directory).as_posix(), apparent_bytes=p.stat().st_size,
                     allocated_bytes=p.stat().st_blocks*512, device=p.stat().st_dev, inode=p.stat().st_ino)
                for p in sorted(directory.rglob('*')) if p.is_file()]
        receipt=dict(schema=1, closed=True, verified=True, directory=str(directory),
                     fixture_sha256=frozen['sha256'], fingerprint=frozen, physical_census=census,
                     recorded_ns=time.time_ns(), source=run['source'],
                     oracle_run=str(run_path), oracle_run_sha256=sha(run_path),
                     oracle_stdout=str(report_path), oracle_stdout_sha256=sha(report_path),
                     oracle=dict(verified_keys=report['verified_keys'], verified_misses=report['verified_misses'],
                                 reopen_ms=report['reopen_ms'], final_reopen_ms=report['final_reopen_ms']),
                     close_evidence='fully validated original capture process exited; fixture never opened again',
                     ordinary_open_before_clone_boundary=True)
        save(receipt_path, receipt)
        return str(directory), dict(path=str(receipt_path), sha256=sha(receipt_path))

    if stage=='fixtures':
        for mixture, seed, n in grid:
            fixture(mixture, seed, n)
    elif stage in ('offline-calibration', 'offline-pairs'):
        if stage=='offline-pairs':
            gate=json.loads((ROOT/'global-calibration-freeze.json').read_bytes())
            assert gate['accepted_by_root'] and gate['all_selected_service_online_noises_frozen']
        labels=['C1','C2','C3'] if stage=='offline-calibration' else ORDER
        prefix='cal' if stage=='offline-calibration' else 'pairs'
        for mixture, seed, n in grid:
            directory, binding=fixture(mixture, seed, n)
            for mode in ('full','exhaustive'):
                slug=f'{mixture}-s{seed}-n{n}-{mode}-b8192'
                base=dict(fixture=directory, fixture_receipt=binding, mode=mode,
                          batch_size=8192, endpoint='compact-command-wal-settle-v1', timeout_seconds=1800)
                plan=dict(output=prefix+'-'+slug,
                          cells=[dict(base,label=label,source='A' if label.startswith('C') else label[0]) for label in labels])
                capture(prefix+'-'+slug, 'offline', plan)
                # Census from maintenance is kept separately from this idempotent
                # writer, which can create new legitimate post-guard debt.
                for label in labels:
                    measured=str(ROOT/plan['output']/label/'db')
                    variant='A' if label.startswith('C') else label[0]
                    guard=dict(output='guard-'+slug+'-'+label, repeats=1,
                               cells=[settings(label,variant,mixture,seed,n,measure_dir=measured)])
                    capture('guard-'+slug+'-'+label,'online',guard)
    elif stage in ('online-calibration','online-pairs'):
        if stage=='online-pairs':
            gate=json.loads((ROOT/'global-calibration-freeze.json').read_bytes())
            assert gate['accepted_by_root'] and gate['all_selected_service_online_noises_frozen']
        labels=['C1','C2','C3'] if stage=='online-calibration' else ORDER
        prefix='calibration' if stage=='online-calibration' else 'pairs'
        sizes = (30000,300000,3000000)
        if selection is not None:
            assert grid[0][:2] == ('primary', 24), 'online matrix is primary only'
            sizes = (grid[0][2],)
        for n in sizes:
            slug=f'online-primary-n{n}'
            plan=dict(output=slug+'-'+prefix, repeats=1,
                      cells=[settings(label,'A' if label.startswith('C') else label[0], 'primary',24,n,
                         churn_rounds=3,churn_shape='sparse',churn_pause='1m0s',churn_pause_ns=60000000000) for label in labels])
            capture(slug+'-'+prefix,'online',plan)
            for label in labels:
                original=ROOT/plan['output']/('1-'+label)/'stdout.json'
                measured=json.loads(original.read_bytes())[0]['data_dir']
                variant='A' if label.startswith('C') else label[0]
                guard=dict(output=slug+'-'+label+'-post-churn-guard',repeats=1,
                           cells=[settings(label,variant,'primary',24,n,measure_dir=measured)])
                capture(slug+'-'+label+'-post-churn-guard','online',guard)
    else:
        raise ValueError('unknown stage: '+stage)
    print('STAGE_COMPLETE '+stage, flush=True)


if __name__=='__main__':
    main()
