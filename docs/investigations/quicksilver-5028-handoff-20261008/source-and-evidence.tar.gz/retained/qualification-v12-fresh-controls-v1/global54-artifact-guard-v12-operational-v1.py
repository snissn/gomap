"""Read-only post-calibration GLOBAL54 replay. No launcher or pair authority.

CLI: ROOT_INPUT ROOT_INPUT_SHA256. Success is an artifact check only.
"""
if not __debug__:
    raise RuntimeError('GLOBAL54 requires unoptimized Python')
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import time
sys.dont_write_bytecode = True
# Retain the original hash-bound dependency directory from this sibling repair.
SOURCE_HERE = Path(__file__).resolve().parent
HERE = SOURCE_HERE.parent/'qualification-v10-global-deployment-preparation-v2'
BASE = HERE.parent
ROOT = Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')
MANIFEST = 'fe243316b55e429a276a8a060607c8920973275c3e089125dbf66f13370a5092'
COMPOSITION = 'b9342c5a67c83d26046eaede93c223dd91e1427af51a3e4ba4c8e98cada2bfc9'
PINS_SHA = '2fccfac7a950aad6f397e15d94d5cc7b45d4b45ec5943d567c1a19e26cc4d406'


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def bound(ref):
    require(set(ref) == {'path','sha256'}, 'exact path/SHA reference required')
    path = Path(ref['path'])
    require(path.is_absolute() and path.is_file() and path.resolve() == path and not path.is_symlink(), 'canonical bound file required')
    require(sha(path) == ref['sha256'], 'bound file drift: '+str(path))
    return read(path)


def module(path, name):
    # Execute the already hash-bound source itself, never a cached .pyc.
    import types
    result = types.ModuleType(name)
    result.__file__ = str(path)
    exec(compile(Path(path).read_bytes(),str(path),'exec'),result.__dict__)
    return result


def source_only_imports(files):
    require(sys.pycache_prefix is None, 'external Python cache prefix is not admissible')
    # Original nested loaders retain their bytes and math. With -B and absent
    # cache directories they can only read the anchored .py source files.
    for path in files:
        if str(path).endswith('.py'):
            require(not (Path(path).parent/'__pycache__').exists(),
                    'unbound Python cache in selected source directory: '+str(path))


def call_main(mod, args):
    argv = sys.argv
    try:
        sys.argv = [mod.__file__, *args]
        with contextlib.redirect_stdout(io.StringIO()):
            mod.main()
    finally:
        sys.argv = argv


def matrix(gate, groups, slots, count):
    require(gate['accepted_by_root'] is True and gate['qualification'] is False,
            'actual accepted diagnostic global gate required')
    require(gate['candidate_collection_accepted_by_root'] is True and
            gate['all_selected_service_online_noises_frozen'] is True and
            gate['offline_cells_complete'] == 10 and
            gate['offline_noise_metrics'] == ['elapsed_seconds','peak_rss_bytes'],
            'complete global gate required')
    require(gate['original_pair_groups'] == groups, 'exact original pair matrix drift')
    require(len(slots) == count and len(gate['noise_freeze_receipts']) == count and
            len(set(gate['noise_freeze_receipts'])) == count, 'missing/duplicate noise freeze')
    require(type(gate['frozen_ns']) is int and 0 < gate['frozen_ns'] < time.time_ns(), 'actual past freeze time required')


def same_replay(frozen, replay, offline):
    keys = ('metric','contract','baseline_source','paths','hashes','values','E') if offline else (
        'definition_sha256','calibration','contract','ledger','original_evidence')
    require(all(frozen[k] == replay[k] for k in keys), 'original noise math/raw replay drift')


def noise_after_calibration(inv, bundle, noise):
    offline = 'metric' in bundle
    paths = bundle['calibration_runs' if offline else 'calibration']
    require(len(paths) == 3, 'exact three calibration packets required')
    rows = [inv.json(path) for path in paths]
    finishes = [row['finished_ns'] if offline else row['finished']*1e9 for row in rows]
    require(max(finishes) < noise['created_ns'], 'noise creation must follow own completed calibration')


def applicability_before_root_decision(applicability, accepted):
    require(type(applicability['frozen_ns']) is int and
            0 < applicability['frozen_ns'] <= accepted['accepted_ns'] < time.time_ns(),
            'R applicability must precede actual pre-pair root decision')


def replay_slot(inv, ev, driver, maintenance, out, name, expected, definition_sha, gate, freeze):
    bundle_path = inv.local(out/(name+'.bundle.json'))
    bundle = read(bundle_path)
    require(bundle == expected, 'resolved pre-pair bundle drift')
    noise_path = out/(name+'.noise.json')
    noise = inv.json(str(noise_path))
    require(freeze['noise_cell'] == name and freeze['noise'] == str(noise_path) and
            freeze['accepted_by_root'] is True and freeze['qualification'] is False and
            freeze['definition_sha256'] == definition_sha and freeze['noise_sha256'] == sha(inv.local(noise_path)),
            'slot identity/acceptance/hash drift')
    require(type(freeze['frozen_ns']) is int and type(noise['created_ns']) is int and
            0 < noise['created_ns'] <= freeze['frozen_ns'] <= gate['frozen_ns'], 'noise timestamp/freeze drift')
    if 'metric' in bundle:
        captured = []
        old_save = maintenance.save
        def retain(path, value, exclusive=False):
            require(Path(path) == noise_path and exclusive, 'unexpected original calibration write')
            captured.append(value)
        try:
            maintenance.save = retain
            maintenance.calibrate(bundle['calibration_runs'], bundle['metric'], noise_path)
        finally:
            maintenance.save = old_save
        require(len(captured) == 1, 'missing original calibrator replay')
        replay = captured[0]
    else:
        driver.DEFINITION_SHA = definition_sha
        replay = driver.invoke_evaluator(ev, 'calibrate', bundle_path, inv.anchor_path, inv.expected_sha)
    same_replay(noise, replay, 'metric' in bundle)
    noise_after_calibration(inv, bundle, noise)
    unknown = driver.unresolved_metrics(name, noise)
    require(freeze['unresolved_noise_metrics'] == unknown, 'UNKNOWN ledger drift')
    return unknown


def validate_input(inp):
    require(inp['phase'] == 'post-calibration-pre-first-pair', 'explicit post-calibration phase required')
    require(inp['schema'] == 1 and inp['accepted_by_root'] is True and inp['artifact_replay_authorized'] is True,
            'root accepted artifact replay input required')
    require(inp['qualification'] is False and inp['collection_authorized'] is False and
            inp['candidate_pairs_authorized'] is False, 'artifact input cannot grant collection authority')
    require(inp['campaign_root'] == str(ROOT) and inp['manifest_sha256'] == MANIFEST and
            inp['composition_sha256'] == COMPOSITION and inp['held_excluded'] == [5004,5006], 'current campaign/exclusion binding required')
    require(inp['guard'] == {'path':str(Path(__file__).resolve()), 'sha256':sha(__file__)}, 'guard itself must be externally selected')


def check(inp):
    validate_input(inp)
    require(sha(HERE/'immutable-pins.json') == PINS_SHA, 'immutable guard dependency manifest drift')
    pins = read(HERE/'immutable-pins.json')
    for name, digest in pins.items():
        require(sha(BASE/name) == digest, 'original/selected source drift: '+name)
    calibration = bound(inp['calibration_activation'])
    calibration_anchor = bound(dict(path=calibration['anchor'],sha256=calibration['anchor_sha256']))
    source_only_imports(calibration_anchor['files'])
    source_only_imports(bound(inp['R_anchor'])['files'])
    # These remain calibration-authority checks; their success never authorizes pairs.
    # Bind and execute only the reviewed applicability source before importing
    # the derived binder's explicit v10_applicability dependency.
    import types
    current_sources = {'v10_applicability.py': '86ac1a866ed604705c86f3403c152e16dc5078a9802b0cd22f8bf9ce0d0d1362', 'bind-prospective-v10-v1.py': 'a4a3f6f700023b67c037465e8e163df86051446ccb3f97489945b093b5714128', 'qualification-v10-collection-controller.py': 'f05ac1dd8ace960cf0dc9914a0996f9b4d4e3ee43a6019d80e685c17d20f2043', 'r-collection-controller.py': '6835c2e5acc9120b9d555c88e7b06a78fe950fa59355d77b3a02ff3b4c56cbe9', 'verify-qualification-v10-deployment-v1.py': '245fe8a8a671cb0b409532e79c34d05210e74abb52d6acda46b792a1a3531d34', 'deployment-helpers-selection.json': 'eaf90e128e43bbfee259f65a5e8866028899abb25e28877bd42c52afa6e8b7fd'}
    for name, digest in current_sources.items():
        p = SOURCE_HERE/name
        require(sha(p) == digest and calibration_anchor['files'][str(p)] == digest, 'fresh operational source drift: '+name)
    app_path = SOURCE_HERE/'v10_applicability.py'
    app = types.ModuleType('v10_applicability')
    app.__file__ = str(app_path)
    exec(compile(app_path.read_bytes(),str(app_path),'exec'),app.__dict__)
    previous_app = sys.modules.get('v10_applicability')
    require(previous_app is None, 'fresh GLOBAL54 process required for selected applicability')
    sys.modules['v10_applicability'] = app
    binder = module(SOURCE_HERE/'bind-prospective-v10-v1.py', 'global54_binder')
    verifier = module(SOURCE_HERE/'verify-qualification-v10-deployment-v1.py', 'global54_deployment')
    b, a, d = (inp[k] for k in ('prospective_binding','calibration_activation','deployment'))
    for ref in (b,a,d):
        bound(ref)
    seam_path = BASE/'qualification-v10-source-preparation-v2/post-calibration-identity-seam-v1.py'
    require(sha(seam_path) == '78b660b14f7eeab54a7fb18a5d298c0b74cce7386af2f50b0080419fbf1bee2b', 'post-calibration seam drift')
    seam = module(seam_path, 'global54_post_calibration_identity')
    with contextlib.redirect_stdout(io.StringIO()):
        seam.check(binder, [b['path'],b['sha256'],a['path'],a['sha256']], inp['phase'])
    call_main(verifier, [d['path'],d['sha256'],b['path'],b['sha256'],a['path'],a['sha256']])
    ev = module(BASE/'qualification-prep/evaluator.py', 'global54_evaluator')
    ref = inp['R_anchor']
    inv = ev.Inventory(ref['path'],ref['sha256'])
    # Keep evaluator API unchanged; replay_slot carries its explicit anchor args.
    inv.anchor_path, inv.expected_sha = ref['path'],ref['sha256']
    require(inv.root == ROOT and sha(inv.local(ROOT/'manifest.json')) == MANIFEST, 'current native manifest required')
    require(inv.anchor['evaluator'] == str(BASE/'qualification-prep/evaluator.py') and
            inv.anchor['driver'] == str(BASE/'r-material-gate-preparation-v2/r-analysis-controller.py') and
            inv.anchor['executed_controllers'] == bound(d)['executed_controllers'],
            'actual R evaluator/analysis/executed R+B controller selectors required')
    for name,digest in pins.items():
        require(sha(inv.local(BASE/name)) == digest, 'dependency missing from full actual raw anchor')
    inv.local(Path(__file__)); inv.local(HERE/'immutable-pins.json')
    for name, digest in current_sources.items():
        require(sha(inv.local(SOURCE_HERE/name)) == digest, 'fresh operational source absent from full actual anchor')
    inv.local(seam_path)
    for ref in (b,a,d):
        require(sha(inv.local(Path(ref['path']))) == ref['sha256'], 'accepted source bindings absent from global anchor')
    accepted = bound(inp['actual_global_content_acceptance'])
    require(accepted['accepted_by_root'] is True and accepted['global54_actual_contents_accepted'] is True and
            accepted['qualification'] is False and accepted['performance_accepted'] is False and
            accepted['manifest_sha256'] == MANIFEST and accepted['composition_sha256'] == COMPOSITION and
            accepted['held_excluded'] == [5004,5006] and accepted['files'] == inv.anchor['files'] and
            accepted['R_anchor'] == inp['R_anchor'], 'separate root actual GLOBAL54 content acceptance required')
    support = module(BASE/'r-material-gate-preparation-v2/r_protocol_support.py', 'r_protocol_support')
    old_support = sys.modules.get('r_protocol_support')
    sys.modules['r_protocol_support'] = support
    try:
        bd = module(BASE/'qualification-analysis-controller.py', 'global54_B_analysis')
        rd = module(BASE/'r-material-gate-preparation-v2/r-analysis-controller.py', 'global54_R_analysis')
        definition = inv.json(inv.anchor['definition'])
        common = support.verify_prerequisites(inv,ev,definition,pairs=False)
        applicability_before_root_decision(inv.json(inv.anchor['calibration_applicability']), accepted)
        B_inv = ev.Inventory(inv.anchor['original_B_anchor'],inv.anchor['original_B_anchor_sha256'])
        B_inv.anchor_path,B_inv.expected_sha = inv.anchor['original_B_anchor'],inv.anchor['original_B_anchor_sha256']
        require(B_inv.root == inv.root, 'B/R campaign anchor drift')
        binding = bound(b)
        require(common == binding['common_inventory'], 'pre-C1/current global common inventory drift')
        require(inv.anchor['definition'] == binding['definition'] and
                inv.anchor['accounting_policy'] == binding['accounting_policy'] and
                inv.anchor['accounting_freeze'] == binding['accounting_freeze'] and
                inv.anchor['r_prospective_policy_extension'] == binding['r_prospective_policy_extension'],
                'new definition/accounting substitution')
        collector,maintenance = ev.load_collectors(inv)
        all_baselines,all_guards,unresolved = [],[],[]
        gates = []
        for role,driver,definition_path,gate_path,out_ref,count in (
            ('B',bd,inv.anchor['original_B_definition'],inv.anchor['original_B_global_gate'],inp['B_analysis_directory'],36),
            ('R',rd,inv.anchor['definition'],inv.anchor['global_calibration_gate'],inp['R_analysis_directory'],18)):
            out = Path(out_ref)
            require(out.is_absolute() and out.resolve() == out and out.parent == ROOT and out.name.startswith('analysis' if role == 'B' else 'ar-analysis'), 'canonical campaign analysis directory required')
            de = inv.json(definition_path); gate = inv.json(gate_path); gates.append(gate)
            groups,slots,origins = driver.layout(ROOT,out,de)
            matrix(gate,groups,slots,count)
            freezes = {}
            for receipt_path in gate['noise_freeze_receipts']:
                f = inv.json(receipt_path)
                require(type(f['noise_cell']) is str and f['noise_cell'] in slots, 'unknown freeze slot identity')
                # Original full-calibration derives this path for every slot,
                # including offline bundles without noise_freeze_receipt.
                require(receipt_path == str(out/(f['noise_cell']+'.freeze.json')), 'freeze receipt path substitution')
                require(f['noise_cell'] not in freezes, 'duplicate freeze slot identity')
                freezes[f['noise_cell']] = f
            require(len(freezes)==count and set(freezes)==set(slots), 'global exact slot identity drift')
            # A failed/partial paired directory is evidence of a started attempt too.
            require(not any(Path(p).parent.exists() for g in groups for p in g['runs']), 'paired A1/candidate timing or partial attempt already exists')
            ledger = []
            for name,expected in slots.items():
                ledger += replay_slot(B_inv if role=='B' else inv,ev,driver,maintenance,out,name,expected,sha(inv.file(definition_path)),gate,freezes[name])
            sort = lambda rows:sorted(rows,key=lambda r:(r['noise_cell'],r['id']))
            require(sort(ledger)==sort(gate['unresolved_noise_metrics']), 'complete global UNKNOWN ledger drift')
            unresolved += [dict(variant=role,**x) for x in ledger]
            for group in groups:
                bundle = slots[group['cell']+'-service-final']
                guards = [ev.load_run(inv,collector,p) for p in bundle['calibration']]
                originals = ev.attach_origins(inv,collector,maintenance,guards,bundle)
                require([v['run']['cell']['label'] for v in guards]==['C1','C2','C3'], 'guard replicate order')
                require([v['name'] for v in originals] == group['calibration'], 'state-specific guard/original slot substitution')
                require(all(x['finished_ns'] < gate['frozen_ns'] for x in originals) and
                        all(int(x['run']['finished']*1e9) < gate['frozen_ns'] for x in guards), 'freeze preceded complete original/guard evidence')
                if role == 'B':
                    all_baselines += originals; all_guards += guards
        require(gates[0]['frozen_ns'] <= gates[1]['frozen_ns'], 'R gate preceded B gate')
        require(len({v['name'] for v in all_baselines})==39 and len({v['name'] for v in all_guards})==39,
                'all39 current C/all39 state-specific guards required')
        intervals = [(v['started_ns'],v['finished_ns']) for v in all_baselines]
        intervals += [(int(v['run']['started']*1e9),int(v['run']['finished']*1e9)) for v in all_guards]
        intervals.sort()
        require(all(a[1] <= b[0] for a,b in zip(intervals,intervals[1:])), 'current C/guard processes overlapped')
        require(type(accepted['accepted_ns']) is int and max(g['frozen_ns'] for g in gates) <= accepted['accepted_ns'] < time.time_ns(), 'actual global acceptance time required')
        require(accepted['B_global_gate_sha256']==sha(inv.file(inv.anchor['original_B_global_gate'])) and
                accepted['R_global_gate_sha256']==sha(inv.file(inv.anchor['global_calibration_gate'])), 'accepted global receipt substitution')
        return dict(status='GLOBAL54_ARTIFACT_REPLAY_COMPLETE_ROOT_LAUNCH_STILL_REQUIRED',
                    manifest_sha256=MANIFEST,composition_sha256=COMPOSITION,
                    baseline_captures=39,guard_captures=39,B_slots=36,R_slots=18,
                    unresolved_noise_metrics=unresolved,numerical_UNKNOWN_can_pass=False,
                    qualification=False,performance_accepted=False,collection_authorized=False,
                    candidate_pairs_authorized=False,native_commands_launched=0)
    finally:
        if old_support is None:
            sys.modules.pop('r_protocol_support',None)
        else:
            sys.modules['r_protocol_support']=old_support


def main():
    require(len(sys.argv)==3, 'ROOT_INPUT ROOT_INPUT_SHA256 required')
    inp = bound(dict(path=sys.argv[1],sha256=sys.argv[2]))
    print(json.dumps(check(inp),allow_nan=False))


if __name__ == '__main__':
    main()
