"""UNEXECUTED supplemental artifact-only deployment check; launches nothing.
CLI: DEPLOYMENT SHA256 BINDING SHA256 CALIBRATION_ACTIVATION SHA256
Run original prospective binder check as well. Root must launch the exact selected
controller paths afterwards; this check is not collection or pair authority.
"""
if not __debug__:
    raise RuntimeError('deployment verification requires assertions enabled')
import hashlib
import json
from pathlib import Path
import re
import sys
import types

ROOT = Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')
SOURCE_HERE = Path(__file__).resolve().parent
PROVENANCE_BASE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
PINS = {'A': ('192e5019e579af3b98ae4fbf4ea497bb9ccd672f', '79100a06e3258caacbc127678f1a4d17bcc9f3e6'), 'B': ('73100c5b8cc2337d9cff36c60a8e4182f1820fe9', '41331819ecb921ea477baf1997a652506700cf56'), 'R': ('6fa638b8bffa71750e1aefa0bb746bb747aa06c1', 'b4bbd98c74c21f7f68bce288341a0925c83e18f1')}
ORIGINALS = {'qualification-v4-source-preparation/qualification-v4-collection-controller.py': 'b9f5f789480ebf1dd4573f6d35816c4bc51b4e0800434cb72b3971abeb3369d2', 'qualification-v4-source-preparation/accept-qualification-v4-inventory-v1.py': '46d1a651e8152274ffe79951d6d16cced81158394c65d87bb0a478a2d69c68d4', 'qualification-v4-source-preparation/build-qualification-v4-sources-v1.py': '3eb08486a9f55014e78b718ed280456df12041b2dbe90c86b633e38f8b5f300a', 'qualification-v4-main-edbd-source-preparation/prepare-qualification-v4-sources-v3.py': '1ff44e7df86e66772978fab049da73ce08964d8adca3fc9172dcc8cfda487029', 'qualification-v4-main-edbd-source-preparation/inventory-qualification-v4-sources-v2.py': 'ada9514d99bf9ae3c9f4755feccc31403ac2aea56028314f4e9a340276b6a6cf', 'qualification-analysis-controller.py': 'e5744ead53031c489e3345c16a48c0b2e7b91c577177d50d25d94adfbe7b79fd', 'qualification-prep/evaluator.py': '9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd', 'qualification-prep/revised-draft/protocol-definition-root-frozen.json': '4005f6369837ecb7000d3a89b86aeac361b3c9d07ccc323450b60bfa4fbd6219', 'qualification-v3-policy-preparation/allocation_accounting.py': 'aee4bc7d1784c1ee4e6adb3d4e899a6fdaa86d3a21ba7a08c4c6d838ff99e8ee', 'qualification-v3-policy-preparation/accounting-policy.draft.json': '5b1eb4a4126716932899285c07877d3b4c1d6236c0a9127550a8bde1213c1dca', 'qualification-v3-policy-preparation/accounting-freeze.template.json': '9761c03dd0c23092fd617901fd2a2e6df322a0b473d61ecf88f899e0cd515d2a', 'qualification-v3-policy-preparation/POLICY.md': '7e367d7b17caa0c36ef0ed2b82918b8163b60c216dea174d4510d01e1e047775', 'qualification-v3-policy-preparation/INTEGRATION.md': '95f7b76a8e31383732b9bf3c0960774b65b6756a1521a4ae793d0cbc4418830c', 'r-material-gate-preparation-v2/r-definition.draft.json': '4a2a8e79dd4884e2ce6e0c53449d413732e13524585b75966a3a742172f345fa', 'r-material-gate-preparation-v2/r-policy-extension.template.json': '3dba8b6ccc6e7b410bedc96289852bece5ca963577f7f6922cd9a3f48229f80e', 'r-material-gate-preparation-v2/r_protocol_support.py': '0f2590a04e3959110e5e5d6f5e2e350a7476a162cbe925939de52191a7efc810', 'r-material-gate-preparation-v2/r-analysis-controller.py': '433c5df7016136afc8920b6663c5c0ed5d167cea993b35554a0b54a663764dc6', 'r-material-gate-preparation-v2/r-collection-controller.py': 'dd292ab0f5fc70d58781a453fe5253d37eaffb3731b76c8bda1fdbd335dc6625', 'r-material-gate-preparation-v2/root-preparation-acceptance.json': 'a13ebf1a4b64e210e45c681e2663cf02acecaa3925e381818d3d2e49f07ce54d'}
R_SUPPORT_ORIGINALS = {'qualification-v3-collection-controller.py': '7e8d6c3eb72bd34c522ae7304d2e4d73d933111d5a105361fb76fd9109256246', 'qualification-analysis-controller.py': 'e5744ead53031c489e3345c16a48c0b2e7b91c577177d50d25d94adfbe7b79fd', 'qualification-prep/evaluator.py': '9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd', 'qualification-prep/revised-draft/protocol-definition-root-frozen.json': '4005f6369837ecb7000d3a89b86aeac361b3c9d07ccc323450b60bfa4fbd6219', 'qualification-v3-policy-preparation/allocation_accounting.py': 'aee4bc7d1784c1ee4e6adb3d4e899a6fdaa86d3a21ba7a08c4c6d838ff99e8ee', 'qualification-v3-policy-preparation/accounting-policy.draft.json': '5b1eb4a4126716932899285c07877d3b4c1d6236c0a9127550a8bde1213c1dca'}
HELPERS = {'source_export': ('build-native-v12.py', 'f030d78a793e7a77fd7dfef0fbffb7099c5ee64a141871917852723d7cda93b3'), 'inventory': ('inventory-native-v12.py', '63fe818d98aaef3ac12002b1d55080e557eb2f7e6af5246b74bf05d9433cbb8c'), 'builder': ('build-native-v12.py', 'f030d78a793e7a77fd7dfef0fbffb7099c5ee64a141871917852723d7cda93b3'), 'inventory_acceptor': ('accept-fresh-inventory-v12.py', '871e2c57c209425fc2455a96e0d52548b0a683964cee4f5429b0b5b65fa10ab4'), 'correctness_checker': ('correctness-only-v12.py', '4327a100e96d113f707edf7970901a432e77e4561e77548143268122e81e72bb'), 'correctness_checks': ('checks-fresh.template.json', '4aa3a4c2ac28204ed1807292bee64a0a01b9b434ee32fd16940b8e7349c506b7'), 'binder': ('bind-prospective-v10-v1.py', 'a4a3f6f700023b67c037465e8e163df86051446ccb3f97489945b093b5714128'), 'R_controller': ('r-collection-controller.py', '6835c2e5acc9120b9d555c88e7b06a78fe950fa59355d77b3a02ff3b4c56cbe9'), 'B_controller': ('qualification-v10-collection-controller.py', 'f05ac1dd8ace960cf0dc9914a0996f9b4d4e3ee43a6019d80e685c17d20f2043'), 'reuse_applicability': ('v10_applicability.py', '86ac1a866ed604705c86f3403c152e16dc5078a9802b0cd22f8bf9ce0d0d1362'), 'reuse_lock': ('v10-source-lock.json', 'bda4d2486d2e66ee33533d601d216092ce1cd8f5211cfb02aac0d9d2bf823c75'), 'post_calibration_seam': ('post-calibration-identity-seam-v1.py', '78b660b14f7eeab54a7fb18a5d298c0b74cce7386af2f50b0080419fbf1bee2b')}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound(path, expected):
    path = Path(path)
    assert path.is_absolute() and path.is_file() and not path.is_symlink()
    assert re.fullmatch('[0-9a-f]{64}', expected) and sha(path) == expected
    return json.loads(path.read_bytes())


def main():
    assert sys.pycache_prefix is None, 'external Python cache prefix is not admissible'
    assert len(sys.argv) == 7
    deployment = bound(sys.argv[1], sys.argv[2])
    binding = bound(sys.argv[3], sys.argv[4])
    activation = bound(sys.argv[5], sys.argv[6])
    assert deployment['schema'] == 1 and deployment['accepted_by_root'] is True
    assert deployment['collection_authorized'] is False and deployment['qualification'] is False
    assert binding['accepted_by_root'] is True and binding['collection_authorized'] is False and binding['qualification'] is False
    assert deployment['campaign_root'] == binding['campaign_root'] == activation['campaign_root'] == str(ROOT)
    assert activation['accepted_by_root'] is True and activation['collection_authorized'] is True and activation['qualification'] is False
    assert activation['prospective_binding_sha256'] == sys.argv[4]
    assert activation['allowed_stages'] == ['fixtures','offline-calibration','online-calibration']
    assert activation['campaign_id'] == binding['campaign_id'] == deployment['campaign_id']
    assert re.fullmatch(r'https://github\.com/snissn/gomap/issues/[0-9]+#issuecomment-[0-9]+', activation['github_external_anchor_url'])
    anchor = bound(activation['anchor'], activation['anchor_sha256'])
    assert anchor['schema'] == 1 and anchor['accepted_by_root'] is True and anchor['root'] == str(ROOT)
    anchor_files = anchor['files']
    canonical = set()
    for path, digest in anchor_files.items():
        resolved = Path(path)
        if not resolved.is_absolute():
            resolved = ROOT / resolved
        resolved = resolved.resolve(strict=True)
        assert resolved not in canonical, 'canonical raw anchor alias'
        canonical.add(resolved)
        assert resolved.is_file() and sha(resolved) == digest, 'actual anchored file drift'
        if str(resolved).endswith('.py'):
            assert not (resolved.parent/'__pycache__').exists(), 'unbound Python cache in selected source directory'
    def anchored(path, expected):
        path = Path(path)
        assert path.is_absolute() and path.is_file() and not path.is_symlink()
        assert str(path) == str(path.resolve(strict=True)), 'selected path must be canonical'
        assert anchor_files[str(path)] == expected and sha(path) == expected, 'unbound actual deployment helper'
        return path
    anchored(sys.argv[1], sys.argv[2]); anchored(sys.argv[3], sys.argv[4])
    assert anchor_files[str(Path(__file__).resolve())] == sha(__file__), 'deployment verifier must itself be anchored'
    root_input = bound(binding['root_input'], binding['root_input_sha256'])
    assert root_input['deployment_binding'] == {'path':sys.argv[1], 'sha256':sys.argv[2]}
    for path, digest in binding['files'].items():
        anchored(path, digest)
    base = Path(deployment['original_provenance_base'])
    assert base == PROVENANCE_BASE and base.is_absolute() and base.is_dir() and not base.is_symlink()
    for name, digest in ORIGINALS.items():
        anchored(base / name, digest)
    support = base / 'r-material-gate-preparation-v2'
    assert deployment['preserved_support_import_directory'] == str(support)
    for name, digest in R_SUPPORT_ORIGINALS.items():
        anchored(base / name, digest)
    anchored(support / 'r_protocol_support.py', ORIGINALS['r-material-gate-preparation-v2/r_protocol_support.py'])
    support_manifest = support / 'immutable-inputs.json'
    anchored(support_manifest, deployment['preserved_support_manifest_sha256'])
    assert json.loads(support_manifest.read_bytes()) == R_SUPPORT_ORIGINALS
    nineteen_manifest = bound(deployment['original_19_manifest']['path'], deployment['original_19_manifest']['sha256'])
    assert nineteen_manifest == ORIGINALS
    anchored(deployment['original_19_manifest']['path'], deployment['original_19_manifest']['sha256'])
    assert set(deployment['helpers']) == set(HELPERS)
    for role, (name, digest) in HELPERS.items():
        selected = deployment['helpers'][role]
        assert selected['sha256'] == digest
        path = anchored(selected['path'], digest)
        assert path.name == name, 'wrong selected helper name'
        assert str(path) == {'source_export': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-native-source-adapters-v4/build-native-v12.py', 'inventory': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-native-source-adapters-v4/inventory-native-v12.py', 'builder': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-native-source-adapters-v4/build-native-v12.py', 'inventory_acceptor': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-source-inventory/inputs/accept-fresh-inventory-v12.py', 'correctness_checker': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-native-source-adapters-v4/correctness-only-v12.py', 'correctness_checks': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-native-source-adapters-v4/checks-fresh.template.json', 'binder': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-fresh-controls-v1/bind-prospective-v10-v1.py', 'R_controller': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-fresh-controls-v1/r-collection-controller.py', 'B_controller': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-fresh-controls-v1/qualification-v10-collection-controller.py', 'reuse_applicability': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-fresh-controls-v1/v10_applicability.py', 'reuse_lock': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-fresh-controls-v1/v10-source-lock.json', 'post_calibration_seam': '/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v10-source-preparation-v2/post-calibration-identity-seam-v1.py'}[role], 'wrong exact selected fresh helper path'
    inventory = json.loads((ROOT/'inventory-complete.json').read_bytes())
    assert root_input['v10_source_lock'] == deployment['helpers']['reuse_lock'], 'wrong v10 source lock selection'
    assert inventory['reuse_applicability'] == root_input['reuse_applicability'], 'wrong v10 applicability selection'
    # Execute only the selected source bytes; no unbound Python bytecode cache.
    app_path = Path(deployment['helpers']['reuse_applicability']['path'])
    app = types.ModuleType('v10_applicability')
    app.__file__ = str(app_path)
    exec(compile(app_path.read_bytes(),str(app_path),'exec'),app.__dict__)
    app.verify(ROOT,inventory,root_input)
    selected_refs = [inventory['common_harness'],root_input['reuse_applicability'],root_input['v10_source_lock']]
    reuse = bound(root_input['reuse_applicability']['path'],root_input['reuse_applicability']['sha256'])
    current = bound(reuse['current_host_readback']['path'],reuse['current_host_readback']['sha256'])
    selected_refs += [reuse['current_host_readback'],current['runner_receipt']]
    for ref in selected_refs:
        anchored(ref['path'],ref['sha256'])
    assert anchor['v10_root_input'] == binding['root_input'] and anchor['v10_root_input_sha256'] == binding['root_input_sha256'], 'wrong externally frozen v10 root input'
    expected_controllers = {role:deployment['helpers'][role+'_controller'] for role in ('R','B')}
    assert deployment['executed_controllers'] == expected_controllers, 'executed controller selections must be explicit'
    assert anchor['executed_controllers'] == expected_controllers, 'new executed controllers absent from anchor selection'
    assert anchor['deployment_binding'] == {'path':sys.argv[1], 'sha256':sys.argv[2]}
    assert deployment['actual_source_pin_review_accepted'] is True
    assert deployment['root_native_library_contents_accepted'] is True
    assert deployment['root_host_environment_contents_accepted'] is True
    assert {role:(v['head'],v['tree']) for role,v in deployment['variants'].items()} == PINS, 'stale prospective source pins'
    manifest_path = ROOT / 'manifest.json'
    manifest = bound(manifest_path, deployment['manifest_sha256'])
    anchored(manifest_path, deployment['manifest_sha256'])
    for role, (head,tree) in PINS.items():
        for slot in (role,role+'_unified'):
            source = manifest['sources'][slot]
            assert (source['head'],source['tree'],source['built_against_head']) == (head,tree,head)
    libraries = manifest['libraries']
    assert len(libraries) == 16, 'prospective quiet-host actual library union count'
    assert deployment['libraries'] == libraries, 'root-reviewed complete native library map required'
    for path, identity in libraries.items():
        # The loader key may be a soname symlink; freeze its exact anchor and target.
        loader = Path(path)
        assert loader.is_absolute() and str(loader) == path and loader.is_file(), 'invalid actual loader key'
        digest = identity['sha256']
        assert re.fullmatch('[0-9a-f]{64}', digest), 'invalid frozen library digest'
        assert anchor_files[path] == digest, 'unbound actual loader key'
        target = loader.resolve(strict=True)
        assert str(target) == identity['resolved'], 'actual library target rebound'
        assert target.is_file() and not target.is_symlink(), 'library target must be a canonical regular file'
        assert sha(loader) == sha(target) == digest, 'actual library contents drift'
    assert deployment['controls'] == manifest['build_env'] == anchor['controls'], 'actual same-environment controls required'
    assert deployment['controls']['GOMAXPROCS'] == '12' and deployment['controls']['GOGC'] == '100' and deployment['controls']['GOMEMLIMIT'] == 'off'
    assert deployment['controls']['GOWORK'] == 'off' and deployment['controls']['CGO_ENABLED'] == '1'
    print(json.dumps({'status':'SUPPLEMENTAL_DEPLOYMENT_IDENTITIES_VERIFIED_NO_LAUNCH','qualification':False,'collection_launched':False,'original_binder_check_still_required':True}))


if __name__ == '__main__':
    main()
