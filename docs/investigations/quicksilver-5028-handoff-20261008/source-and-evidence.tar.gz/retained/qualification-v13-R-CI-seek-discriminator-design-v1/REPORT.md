# R CI snapshot Seek discriminator design

**Recommend a script-only, post-failure diagnostic using the already built TreeDB binaries.** Preserve both failures and the original acceptance contract. No cause is proven and no production repair is justified yet. The proposal below is source-reviewed, not implemented or compiled/run; root owns its integration after the memtable writer returns.

## Evidence update

Exact candidate R `01ad34afed6d64f58d8504a57a247170289e4772`, base `2d6b07f58902537cfe8d2b3e3a8c3c9ba0f3c07c`. Both retained packets and stdout/job logs are hashed in [source-artifact-bindings.json](source-artifact-bindings.json). Structured data is `summary.json`. Sources are bound to exact committed Git objects, not unfinished writer bytes. Two untracked writer test files became visible during inspection; neither was opened or incorporated. No source, Git, GitHub, SSH, CI or native state was changed.

| Block | Base median | R median | Paired median | Odd AB median | Even BA median |
|---|---:|---:|---:|---:|---:|
| Original |381.95 ns|399.8 ns|+5.02185583%|+5.0004%|+5.0219%|
| One authorized rerun |232.2 ns|242.1 ns|+5.42800069%|+12.7260%|−0.7685%|

Original: all eight R samples slower. Rerun raw deltas: **−3.3784, −0.5455, +24.6107, −0.9914, +13.5787, −1.1188, +11.8734, +11.4015%**; four faster/four slower. Thus the rerun is not a second uniformly slower block. Most large losses occur when R runs second, but pair 8 also loses with R first. Order/variance is a useful discrimination target, not a demonstrated noise cause or reason to waive either FAIL. Zero B/op and allocs/op hold in both blocks.

The owning test executable SHA-256s are exactly the same across attempts for each revision: base `5034eefe8548d3cb9cc2c34022ed41054fce4745d7dbd75321dc255218805c26`; R `648bf64a3171e6f96225f9856b50c5c5e12b5f61fdfd73e20f300bd6c4a9497c`. Go remains 1.26.8. Runner CPU changed **EPYC 7763 → EPYC 9V45**, and image changed **20260927.320.1 → 20261004.327.1**. Absolute timings cannot be pooled as one matched hardware experiment. Both within-job pairs still compare the same base/head identities on their runner. Rerun artifact ID `11552625841`, ZIP SHA-256 `c964155188448a17148366372f0f541e165927b7e0a7de20f07e31b303de2838` is reported by retained stdout; no independent archive retrieval here. B's reported pass is context only and not a matched R discriminator.

## Causes independently narrowed

At R, [the timed loop](https://github.com/snissn/gomap/blob/01ad34afed6d64f58d8504a57a247170289e4772/TreeDB/snapshot_seek_iterator_bench_test.go#L62) only performs Seek/Valid/Key over a snapshot built after Checkpoint. Benchmark/options, snapshot guards, tree.Iterator, Pager and node sources are base/R-identical blobs. Alternative leaf encodings and outer value-log leaves are explicitly disabled. Default mode is adaptive, not COW. Changed owned-inline Get/GetAppend code in tree.go is not called by this loop. Pointer decode/dictionary/outer-leaf projection and freelist allocation do not directly execute in the immutable timed Seek path. These facts rule out direct invocation of those changed bodies as a per-operation source explanation; they do not rule out setup-derived tree differences or code-generation effects.

The changed Checkpoint owned-prefix attempt can affect construction only if its multi-lane/unit eligibility holds; the retained packets have no route/fixture state. Freelist allocation and Zipper scratch changes can also affect setup. Actual snapshot/iterator concrete type, selected tree shape, wrapper dispatch and hot machine instructions are not bound by the current artifact. The checker's CANDIDATE label is based on full executable inequality, not measured hot-code attribution. Identical source does not imply identical machine code/alignment, and identical logical keys do not imply identical physical pages. No special numeric-key optimization is indicated: the existing BE8 branch is already present identically in both node/leaf.go blobs.

## Concrete smallest diff proposal

Change only `scripts/mvcc_raw_path_gate.sh`. Keep the original eight-pair five-group loop, original log paths, binary hashes, checker invocation and `gate_status`/exit untouched. Add one independent snapshot branch alongside the existing [RepeatedIterator retention block](https://github.com/snissn/gomap/blob/01ad34afed6d64f58d8504a57a247170289e4772/scripts/mvcc_raw_path_gate.sh#L198), before final echo/exit. Both branches may run when both rows fail. Avoid rewriting the checker, workflow, fixtures, memtable or caching tests. The branch should:

1. Trigger only for the exact snapshot row's timing failure with unequal owning binaries, using the same summary fields as the existing block.
2. Copy the two exact already-measured `*-treedb.test` executables before TMP_ROOT cleanup; hash the copies and check them against `summary.json`'s owning binary digests. Retain any failure status without replacing the original gate status.
3. Retain targeted hot disassembly from both, including the benchmark closure, snapshot guard and any cached wrapper, tree Seek/descent/loadCurrent/key lookup, pager Get/verification and node separator/leaf search. Record objdump status and whether output is empty. Missing standalone symbols can result from inlining; inspect their containing callers before claiming equivalence.
4. Run the existing `keys=1024/public_seek_baseline` from those same copied binaries in **eight alternating AB/BA pairs, 2s, CPU0, GOMAXPROCS1**. Keep diagnostic per-revision/pair output and pre-sample process observations in a separate subdirectory; never append benchmark rows to original base/head logs or feed diagnostics to the gate checker. No new comparison threshold or acceptance verdict.

Illustrative insertion (complete bounded branch; no proposed file was installed):

```bash
# Snapshot-only diagnostics follow the frozen verdict, without replacing samples.
if ((gate_status != 0)) && python3 - "$SUMMARY_JSON" <<'PY_CHECK'
import json, sys
with open(sys.argv[1]) as source:
    rows = json.load(source)["results"]
sys.exit(0 if any(row["benchmark"] ==
                  "BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek"
                  and not row["timing_pass"] and not row["binary_equivalent"]
                  for row in rows) else 1)
PY_CHECK
then
  (
    diagnostics="$OUT_DIR/snapshot-seek-diagnostics"
    mkdir -p "$diagnostics" || exit 1
    public_regex='^BenchmarkSnapshotIteratorSeekNext/keys=1024/public_seek_baseline$'
    hot_symbols='github.com/snissn/gomap/TreeDB\.BenchmarkSnapshotIteratorSeekNext|github.com/snissn/gomap/TreeDB/(db|caching|tree|node|pager)\.\(\*[^)]*\)\.(begin|endOperation|Seek|seek|Valid|Key|UnsafeKey|resetStack|resetPointerPrefetch|loadCurrent|getLeafKeyFlags|loadNodeRef|loadChildRefView|loadChildRefViewInto|loadNodeViewWithLoadKind|loadNodeViewWithLoadKindInto|Get|IsVerified|MarkVerified|Type|Count|InternalFenceBounds|SearchInternal|GetInternalChildRef|SearchLeaf|GetLeafKeyFlagsView)$|github.com/snissn/gomap/TreeDB/(tree|node)\.(compareTreeKey|InitFreshNodeView)'
    for revision in baseline candidate; do
      binary="$diagnostics/$revision-treedb.test"
      cp "$TMP_ROOT/$revision-treedb.test" "$binary" || exit 1
      status=0
      timeout --kill-after=5s 30s env GOWORK="$SCRIPT_GOWORK" \
        go tool objdump -s "$hot_symbols" "$binary" \
        >"$diagnostics/$revision-hot-objdump.txt" 2>&1 || status=$?
      printf 'exit=%s\n' "$status" >"$diagnostics/$revision-objdump-status.txt"
      if [[ ! -s "$diagnostics/$revision-hot-objdump.txt" ]]; then
        printf 'empty_output=true\n' >>"$diagnostics/$revision-objdump-status.txt"
      fi
    done
    (cd "$diagnostics" && sha256sum baseline-treedb.test candidate-treedb.test) \
      >"$diagnostics/binary-sha256.txt" || exit 1
    # Assert copied digests match summary.json before executing diagnostics.
    python3 - "$SUMMARY_JSON" "$diagnostics" <<'PY_HASH'
import hashlib, json, pathlib, sys
expected = json.load(open(sys.argv[1]))["binary_digests"]["treedb"]
for revision in ("baseline", "candidate"):
    actual = hashlib.sha256((pathlib.Path(sys.argv[2]) /
                             (revision + "-treedb.test")).read_bytes()).hexdigest()
    if actual != expected[revision]:
        raise SystemExit("retained binary mismatch: " + revision)
PY_HASH
    # Explicit guard: this subshell may run as a conditional OR operand.
    [[ $? -eq 0 ]] || exit 1
    for ((sample = 1; sample <= RUNS; sample++)); do
      if ((sample % 2 == 1)); then revisions='baseline candidate'; else revisions='candidate baseline'; fi
      for revision in $revisions; do
        {
          printf 'revision=%s sample=%s group=public_seek_baseline\n' "$revision" "$sample"
          date -Iseconds
          ps -eo pid,ppid,etime,%cpu,cmd --sort=-%cpu | head -20 || true
        } >>"$diagnostics/processes.txt"
        status=0
        taskset -c "$CPUSET" timeout --kill-after=5s 30s env GOMAXPROCS=1 \
          "$diagnostics/$revision-treedb.test" -test.run '^$' \
          -test.bench "$public_regex" -test.benchmem \
          -test.benchtime="$BENCHTIME" -test.count=1 \
          >"$diagnostics/$revision-$sample-public-seek.txt" 2>&1 || status=$?
        printf 'exit=%s\n' "$status" >"$diagnostics/$revision-$sample-public-seek-status.txt"
      done
    done
  ) || echo "Snapshot Seek diagnostics incomplete; original gate status preserved" >&2
fi
```

This introduces no new Go source to compile: both exact fixture revisions already contain `public_seek_baseline`, and the binaries are those originally built/measured. SHA matching explicitly prevents accidental substitution. Runtime limits and failures are recorded as diagnostic status, while the final script still exits the original `gate_status`. The regex is a source-informed proposal, not a tool-verified symbol list; root must check it produces relevant symbols on retained binaries. Existing workflow already uploads the entire OUT_DIR on failure, so no workflow change is needed. Its current RUNS=8/BENCHTIME=2s/CPUSET=0/GOMAXPROCS1 and thresholds remain unchanged.

## How to read the result, and optional second stage

A similar public Seek loss narrows toward shared descent/fixture/code placement; a snapshot-only loss narrows toward wrapper/dispatch/route/code placement. Neither alone proves a specific cause, since the public diagnostic runs later and has independent process/fixture instances. Separate per-pair files permit order/variance comparison. Retained binaries/disassembly make claims about changed hot instructions testable instead of inferred from whole-binary hashes. Gate qualification still requires the existing complete contract on the coherent repaired/pushed head; diagnostics cannot promote FAIL to PASS.

Do not add fixture logging to the first patch. If bin/asm/public comparisons leave route/input ambiguity, use a **separate untimed test-only probe** at both revisions with byte-identical probe code, not a production API or an asymmetric change to the accepted gate fixture. Existing Snapshot.State/Pager and Node.Type/Count/GetInternalChildRef are available in both revisions to report concrete snapshot/iterator type, root page, height and leaf occupancy. Do not prewalk pages before accepted timing: Pager.Get/verification/cache warming can change it. Any matched instrumented binaries must be labeled diagnostic and distinct from the retained exact gate executables. Existing Stats can show drain units/frontier lanes, but those counters are shared with old routes and cannot prove owned-prefix execution; do not claim a unique prefix route without an existing distinguishing trace. A test-only route discriminator would require a separately reviewed seam if later necessary. No such source/API/test change is proposed now.

For root validation after integration: existing bash syntax/self-checks and gate pairing/equivalence/CI contract checks remain applicable; actual base/R compilations and post-failure artifact retention must be exercised under root's authorized window. None were run by this inquiry. Effective executor guidance and AGENTS were read/bound; the explicit source-only task overrides execution defaults. All implementation, rerun, acceptance, qualification, threshold-waiver and merge flags are false. Return ownership to root.
