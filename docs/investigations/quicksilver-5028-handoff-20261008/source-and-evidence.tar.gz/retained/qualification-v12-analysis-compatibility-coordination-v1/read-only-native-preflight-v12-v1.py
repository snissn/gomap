"""Read-only exact frozen inputs and absent preparation outputs; no campaign."""
import hashlib,json,os,pathlib,time
base=pathlib.Path('/home/mikers/quicksilver-maintenance-5028-20261006')
root=base/'qualification-v12-refresh/qualification-v10'
later=base/'qualification-v12-later-execution-preparation-v3'
pins={
 base/'qualification-analysis-controller.py':'e5744ead53031c489e3345c16a48c0b2e7b91c577177d50d25d94adfbe7b79fd',
 base/'r-material-gate-preparation-v2/r-analysis-controller.py':'433c5df7016136afc8920b6663c5c0ed5d167cea993b35554a0b54a663764dc6',
 base/'qualification-prep/evaluator.py':'9f20a9746b5f26ddf7dbd61f1b9afece8b2b8d01bbebf76147365b7c835edbcd',
 base/'qualification-prep/revised-draft/protocol-definition-root-frozen.json':'4005f6369837ecb7000d3a89b86aeac361b3c9d07ccc323450b60bfa4fbd6219',
 root/'prospective-v10-root-v1/r-definition.accepted.json':'cf1d1d0455e8cd2b1e50cb117b1af439a6d413287615e0b58ff1909fb29e00d7',
 root/'manifest.json':'fe243316b55e429a276a8a060607c8920973275c3e089125dbf66f13370a5092',
 root/'receipts/source-inventory.json':'30eb9fe190c0b65cd7097333285d8b5e324532bc930a967af6423c6cb300ef81',
 base/'qualification-v12-source-inventory/inputs/qualification-v12-A-tracked-tree.json':'320207420455ed1392400711e9dedc4983afb66ecf65c0f34fdc5a77e50761b4',
 base/'qualification-v12-source-inventory/inputs/qualification-v12-B-tracked-tree.json':'c181652857444632fc5a79cc498a5e78fc272fe46ffb2fd0f3949fef4ad9501a',
 base/'qualification-v12-source-inventory/inputs/qualification-v12-R-tracked-tree.json':'15de5d5f280ef971649fdee97780d91e9ddcb7b28f0e97bcd138b2821f0ee79c'}
files=[]
for p,expected in pins.items():
    assert p.is_absolute() and p.resolve(strict=True)==p and p.is_file() and not p.is_symlink(),str(p)
    data=p.read_bytes();h=hashlib.sha256(data).hexdigest();assert h==expected,str(p)
    files.append(dict(path=str(p),sha256=h,bytes=len(data)))
absent=[
 root/'analysis-global-original-v1',root/'ar-analysis-global-original-v1',
 later/'qualification-v12-global-analysis-transitions-v1',
 later/'root-B-prepare-receipt-view-provenance-v12-v1.json',
 later/'root-R-prepare-receipt-view-provenance-v12-v1.json',
 root/'full-R-canonical-B-closure-v12-v1',root/'global-calibration-freeze.json']
for p in absent:assert not os.path.lexists(p),str(p)
active=[]
for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdecimal():continue
    try:
        a=[v.decode(errors='replace') for v in (p/'cmdline').read_bytes().split(bytes([0])) if v]
        if a and ((pathlib.Path(a[0]).name in ('unified-bench','treemap','snapshot-restore') and any(str(base) in v for v in a)) or (pathlib.Path(a[0]).name.startswith('python') and len(a)>2 and a[1]=='-B' and pathlib.Path(a[2]).name.startswith('collection-native-driver'))):
            active.append(dict(pid=int(p.name),argv=a))
    except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not active,active
print(json.dumps(dict(schema=1,status='ACTUAL_EXACT_RECEIPT_COMPATIBILITY_PREFLIGHT_PASS',
    owner='/root',checked_ns=time.time_ns(),files=files,absent=[str(p) for p in absent],
    active_owned_measurements=active,qualification=False,performance_accepted=False,
    collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False,
    held_excluded=[5004,5006])))
