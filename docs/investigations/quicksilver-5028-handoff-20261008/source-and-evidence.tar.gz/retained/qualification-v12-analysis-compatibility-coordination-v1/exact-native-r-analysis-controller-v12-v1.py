#!/usr/bin/env python3
"""Analysis only: no capture, DB command, rerun or acceptance authority.

First run STAGE --prepare to emit resolved bundles, origins and a deduplicated
raw anchor draft. Root must inspect receipt contents/landed harness/host evidence,
accept origins and the anchor, and supply --anchor PATH --anchor-sha256 DIGEST.
The anchor must externally bind this driver and accepted evaluator as well.
Calibration writes unaccepted observation freeze receipts, including complete
UNKNOWN ledgers. Unknown metrics never pass a qualification gate. R allocation accounting only
inherits the separately accepted universal original B rule; its numerical
UNKNOWN ledger stays intact. Root explicitly
accepts unresolved observations and collection permission before any R timing, and
refreshes the external anchor before final-evaluate; it must preserve their
original timestamps. Both the inherited original B36-slot gate and the separate
R18-slot gate precede ANY AR pair. No B campaign files are changed.
Use a fresh --out for each preparation; analysis outputs are exclusive. Failed
outputs are retained and require diagnosis, never automatically retried.
"""
if not __debug__:
    raise RuntimeError('qualification orchestration requires unoptimized Python')

import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import math
import pathlib
import sys
import time
sys.dont_write_bytecode = True

DEFINITION_SHA = None  # Supplied by externally anchored accepted R definition
C = ['C1', 'C2', 'C3']
ORDER = ['A1', 'R1', 'R2', 'A2', 'A3', 'R3']
HERE = pathlib.Path(__file__).resolve().parent
EVALUATOR = HERE.parent/'qualification-prep/evaluator.py'
DEFINITION = None  # Never the original B definition
from r_protocol_support import verify_immutable, verify_prerequisites, allocation_ledger, extend_anchor


def require(ok, why):
    if not ok:
        raise ValueError(why)


def sha(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(pathlib.Path(path).read_bytes())


def save(path, value):
    with pathlib.Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def module(path):
    spec = importlib.util.spec_from_file_location('qualification_evaluator', path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def layout(root, out, definition):
    require(definition['selected_candidate_variants'] == ['R'], 'driver supports the supplemental R inventory only')
    cells, slots, origins = [], {}, {}
    for cell in definition['required_original_cells']:
        online = cell.startswith('online-')
        kind = 'online' if online else 'offline'
        def original(label):
            phase = ('calibration' if label.startswith('C') else 'pairs') if online else ('cal' if label.startswith('C') else 'ar-pairs')
            directory = (cell+'-'+phase) if online else (phase+'-'+cell)
            return str(root/directory/(('1-' if online else '')+label)/'run.json')
        def guard(label):
            directory = (cell+'-'+label+'-post-churn-guard') if online else (('guard-' if label.startswith('C') else 'ar-guard-')+cell+'-'+label)
            return str(root/directory/('1-'+label)/'run.json')
        group = dict(cell=cell, kind=kind, variant='R', calibration=[original(v) for v in C], runs=[original(v) for v in ORDER])
        cells.append(group)
        for label in C+ORDER:
            path = pathlib.Path(original(label))
            if not path.exists():
                continue
            data = read(path)
            directory = read(path.parent/'stdout.json')[0]['data_dir'] if online else str(path.parent/'db')
            origins[guard(label)] = dict(original_run=str(path), kind=kind, directory=directory)
        service = cell+'-service-final'
        slots[service] = dict(metric_set='service_final_inplace', metrics=definition['metric_sets']['service_final_inplace'],
            calibration=[guard(v) for v in C], pairs=[dict(A=guard('A'+str(i)), B=guard('R'+str(i))) for i in (1,2,3)],
            variant='R', guard_origins=str(out/'guard-origins.json'), noise=str(out/(service+'.noise.json')),
            noise_freeze_receipt=str(out/(service+'.freeze.json')))
        if online:
            slots[cell] = dict(metric_set='online_churn', metrics=definition['metric_sets']['online_churn'],
                calibration=group['calibration'], pairs=[dict(A=original('A'+str(i)), B=original('R'+str(i))) for i in (1,2,3)],
                variant='R', noise=str(out/(cell+'.noise.json')), noise_freeze_receipt=str(out/(cell+'.freeze.json')))
        else:
            for metric in ('elapsed_seconds', 'peak_rss_bytes'):
                name = cell+'-'+metric
                slots[name] = dict(metric=metric, calibration=str(out/(name+'.noise.json')), calibration_sha256=None,
                    calibration_runs=group['calibration'], pairs=[dict(A=original('A'+str(i)), B=original('R'+str(i))) for i in (1,2,3)])
    require(set(slots) == set(definition['required_noise_cells']), 'resolved noise matrix drift')
    return cells, slots, origins


def prepare(root, out, definition, cells, slots, origins, pairs, original_anchor, original_anchor_sha):
    # Canonical aliases are deduplicated before hashing, including shared large
    # binaries/libraries. DB payload trees are not recursively inventoried.
    inventory = read(root/'inventory-complete.json')
    collector = pathlib.Path(inventory['collector_source']).resolve(strict=True)/'scripts'
    files = set()
    def add(path):
        path = pathlib.Path(path).resolve(strict=True)
        require(path.is_file(), 'dependency is not a file: '+str(path))
        files.add(path)
    for path in (root/'inventory-complete.json', root/'manifest.json', EVALUATOR, DEFINITION, pathlib.Path(__file__)):
        add(path)
    manifest = read(root/'manifest.json')
    for role in ('source', 'build', 'native', 'runner'):
        receipt = manifest['receipts'][role]
        path = root/receipt['path']
        require(sha(path)==receipt['sha256'], 'common receipt digest drift: '+role)
        add(path)
        data=read(path)
        if role=='build':
            for binary in data['binaries'].values():
                add(binary['original_build_path'])
        if role=='source':
            for variant in data['variants'].values():
                add(root.parent/variant['tracked_manifest'])
    harness = dict(observer=str(collector/'owned_process_rss.py'), collector=str(collector/'unified_bench_quicksilver_capture.py'),
                   maintenance=str(collector/'quicksilver_maintenance.py'))
    for path in harness.values():
        add(path)
    run_names = set()
    labels = C+ORDER if pairs else C
    for group in cells:
        run_names.update(group['calibration'])
        if pairs:
            run_names.update(group['runs'])
        for slot_name in (group['cell']+'-service-final',):
            bundle = slots[slot_name]
            run_names.update(bundle['calibration'])
            if pairs:
                run_names.update(v[k] for v in bundle['pairs'] for k in ('A','B'))
    for name in sorted(run_names):
        path = pathlib.Path(name).resolve(strict=True)
        data = read(path)
        directories=[path.parent/'db']
        if data['cell'].get('measure_dir'):
            directories.append(pathlib.Path(data['cell']['measure_dir']))
        if data['cell'].get('fixture'):
            directories.append(pathlib.Path(data['cell']['fixture']))
        if 'snapshot_restore' not in data:
            directories.append(pathlib.Path(read(path.parent/'stdout.json')[0]['data_dir']))
        for directory in directories:
            directory=directory.resolve()
            require(not out.is_relative_to(directory) and not directory.is_relative_to(out), 'analysis output overlaps retained DB/fixture')
        for folder in (path.parent, path.parent.parent):
            for raw in folder.iterdir():
                if raw.is_file():
                    add(raw)
        add(data['command'][0])
        for library in data['native_resolution']['libraries']:
            add(library)
        if 'snapshot_restore' in data:
            restore = data['snapshot_restore']
            add(restore['command'][0])
            for library in restore['native']['native_resolution']['libraries']:
                add(library)
    # Common manifest inventories ALL variants before timing, not only runs
    # selected for this analysis. Receipt CONTENT acceptance remains root's job.
    manifest = read(root/'manifest.json')
    binaries = (root/'bin').resolve(strict=True)
    for source in manifest['sources'].values():
        add(binaries/source['binary'])
    for library in manifest['libraries']:
        add(library)
    out.mkdir(parents=False, exist_ok=False)
    origin_path = out/'guard-origins.json'
    save(origin_path, dict(schema=1, accepted_by_root=False, inplace_no_reload_restore=False,
        before_after_census_retained=False, runs=origins, note='Root reviews directory/census/inplace evidence before acceptance.'))
    add(origin_path)
    for name, bundle in slots.items():
        path = out/(name+'.bundle.json')
        save(path, bundle)
        add(path)
    gate = dict(schema=1, accepted_by_root=False, frozen_ns=None, offline_cells_complete=10,
        offline_noise_metrics=['elapsed_seconds','peak_rss_bytes'], all_selected_service_online_noises_frozen=False,
        noise_freeze_receipts=[str(out/(name+'.freeze.json')) for name in sorted(slots)], original_pair_groups=cells,
        unresolved_noise_metrics=None, qualification=False,
        candidate_collection_accepted_by_root=False)
    save(out/'global-gate-template.json', gate)
    add(out/'global-gate-template.json')
    anchor = dict(schema=1, root=str(root), accepted_by_root=False, files={str(p):sha(p) for p in sorted(files)},
        definition=str(DEFINITION), harness_files=harness, global_calibration_gate=str(out/'global-calibration-freeze.json'),
        landed_harness_attested=False, receipt_contents_accepted=False, host_clock_and_serialization_accepted=False,
        controls=None, driver=str(pathlib.Path(__file__).resolve()), evaluator=str(EVALUATOR),
        original_B_global_gate=None, original_B_global_gate_sha256=None, original_B_definition=str(HERE.parent/'qualification-prep/revised-draft/protocol-definition-root-frozen.json'),
        calibration_applicability=None, r_prospective_policy_extension=None, accounting_policy=None, accounting_freeze=None, accounting_checker=str(HERE.parent/'qualification-v3-policy-preparation/allocation_accounting.py'), campaign_id=None,
        note='Root must accept actual source/build/native/runner contents, strict C applicability before AR and inherited B universal allocation policy before original common-v3 C1; no acceptance inferred.')
    anchor = extend_anchor(anchor, original_anchor, original_anchor_sha)
    save(out/'external-anchor.draft.json', anchor)
    print(json.dumps(dict(status='root_review_required', anchor=str(out/'external-anchor.draft.json'),
        anchor_sha256=sha(out/'external-anchor.draft.json'), qualification=False)))


def invoke_evaluator(ev, command, bundle, anchor, anchor_sha):
    argv = sys.argv
    sys.argv = [str(EVALUATOR), command, str(bundle), '--anchor', str(anchor), '--anchor-sha256', anchor_sha,
                '--definition-sha256', DEFINITION_SHA]
    stream = io.StringIO()
    try:
        with contextlib.redirect_stdout(stream):
            ev.main()
    finally:
        sys.argv = argv
    return json.loads(stream.getvalue())


def calibration_valid(noise):
    """Validate a complete diagnostic packet; return unresolved observations.

    Freezing UNKNOWN is evidence retention, not numerical precision or a pass.
    The accepted evaluator validates raw closure before emitting its ledger.
    """
    unresolved = []
    if 'ledger' in noise:
        require(noise['qualification'] is False and noise['ledger'], 'missing diagnostic noise ledger')
        require(len({v['id'] for v in noise['ledger']})==len(noise['ledger']), 'duplicate noise metric')
        for entry in noise['ledger']:
            if entry['status']=='unknown':
                require(isinstance(entry.get('reason'),str) and entry['reason'], 'unknown metric lacks exact reason')
                unresolved.append(dict(id=entry['id'], status='unknown', reason=entry['reason']))
            else:
                require(entry['status']=='calibrated' and math.isfinite(entry['E']) and entry['E']>0,
                        'invalid calibrated noise precision')
    else:
        require(len(noise['values'])==3 and all(v>=0 and math.isfinite(v) for v in noise['values']) and
                math.isfinite(noise['E']) and noise['E']>=0, 'invalid offline calibration values/spread')
        if any(v==0 for v in noise['values']):
            unresolved.append(dict(id=noise['metric'], status='unknown',
                reason='zero calibration value; fractional denominator/measurement support unresolved'))
        elif noise['E']==0:
            unresolved.append(dict(id=noise['metric'], status='unknown',
                reason='zero spread requires independently frozen resolution evidence; unresolved'))
    return unresolved


def unresolved_metrics(name, noise):
    return [dict(noise_cell=name, **entry) for entry in calibration_valid(noise)]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage', choices=('calibrate-one','full-calibration','final-evaluate'))
    p.add_argument('--campaign', required=True); p.add_argument('--out', required=True)
    p.add_argument('--cell', help='one exact noise cell or original cell (all its slots)')
    p.add_argument('--original-B-anchor', required=True); p.add_argument('--original-B-anchor-sha256', required=True)
    p.add_argument('--definition', required=True); p.add_argument('--definition-sha256', required=True)
    p.add_argument('--prepare', action='store_true'); p.add_argument('--anchor'); p.add_argument('--anchor-sha256')
    a = p.parse_args()
    global DEFINITION, DEFINITION_SHA
    DEFINITION = pathlib.Path(a.definition).resolve(strict=True); DEFINITION_SHA = a.definition_sha256
    verify_immutable()
    require(__debug__, 'original validators require assertions')
    root = pathlib.Path(a.campaign).resolve(strict=True); out = pathlib.Path(a.out).resolve()
    require(out.parent==root and out.name.startswith('ar-analysis'), 'output must be a direct campaign analysis directory')
    require(sha(DEFINITION)==DEFINITION_SHA, 'frozen root definition drift')
    definition = read(DEFINITION)
    cells, slots, origins = layout(root, out, definition)
    selected = sorted(slots)
    if a.stage!='final-evaluate':
        require(not any(pathlib.Path(name).exists() for group in cells for name in group['runs']),
                'original paired timing has begun; preserve evidence, cannot create later calibration freezes')
    if a.stage=='calibrate-one':
        require(a.cell, 'calibrate-one requires --cell')
        selected = [name for name in selected if name==a.cell or name in (a.cell+'-service-final',a.cell+'-elapsed_seconds',a.cell+'-peak_rss_bytes')]
        require(selected, 'unknown cell')
    if a.prepare:
        require(a.stage!='final-evaluate', 'final preparation requires root to extend the accepted calibration anchor with pairs/noises/freezes/global gate; preserve the same output paths')
        # Small-cell preparation inventories only that original group and its
        # guards; the full matrix remains described but missing inputs fail on use.
        chosen = [v for v in cells if any(name==v['cell'] or name.startswith(v['cell']+'-') for name in selected)]
        prepare(root,out,definition,chosen,slots,origins,a.stage=='final-evaluate',a.original_B_anchor,a.original_B_anchor_sha256)
        return
    require(a.anchor and a.anchor_sha256, 'root-accepted external anchor and digest required; use --prepare first')
    ev = module(EVALUATOR)
    inv = ev.Inventory(a.anchor,a.anchor_sha256)
    require(inv.anchor['driver']==str(pathlib.Path(__file__).resolve()) and inv.anchor['evaluator']==str(EVALUATOR), 'analysis source binding')
    inv.local(pathlib.Path(__file__)); inv.local(EVALUATOR); inv.local(DEFINITION)
    require(inv.anchor['receipt_contents_accepted'] is True and inv.anchor['host_clock_and_serialization_accepted'] is True,
            'root receipt/host acceptance missing')
    verify_prerequisites(inv, ev, definition, pairs=(a.stage=='final-evaluate'))
    collector, maintenance = ev.load_collectors(inv)
    # Revalidate originals before computing any noise. This uses actual source
    # inventory and original raw collectors, not product_patch descriptive labels.
    chosen = cells if a.stage!='calibrate-one' else [v for v in cells if any(n==v['cell'] or n.startswith(v['cell']+'-') for n in selected)]
    common = None
    for group in chosen:
        loaded = [ev.load_original(inv,collector,maintenance,name,group['kind']) for name in group['calibration']]
        require([v['run']['cell']['label'] for v in loaded]==C and all(v['run']['cell']['source']==('A_unified' if group['kind']=='online' else 'A') for v in loaded), 'original baseline role/labels')
        require(all(v['original_contract']==loaded[0]['original_contract'] and v['run']['source']==loaded[0]['run']['source'] for v in loaded), 'original calibration contract/source')
        require(all(x['finished_ns']<=y['started_ns'] for x,y in zip(loaded,loaded[1:])), 'original calibration order')
        for packet in loaded:
            common = common or packet['common_inventory']
            require(packet['common_inventory']==common, 'common inventory drift')
    if a.stage=='final-evaluate':
        gate=inv.json(inv.anchor['global_calibration_gate'])
        require(gate['accepted_by_root'] is True and gate['offline_cells_complete']==10 and
            gate['offline_noise_metrics']==['elapsed_seconds','peak_rss_bytes'] and
            gate['all_selected_service_online_noises_frozen'] is True and
            gate['candidate_collection_accepted_by_root'] is True and gate['qualification'] is False,
            'global freeze incomplete/unaccepted')
        require(len(gate['original_pair_groups'])==6 and gate['original_pair_groups']==cells, 'global original group matrix drift')
        originals=[v for group in cells for v in ev.original_pairs(inv,collector,maintenance,group,common)]
        require(len({v['name'] for v in originals})==36, 'original pair reuse')
        earliest=min(v['started_ns'] for v in originals)
        require(gate['frozen_ns']<earliest, 'global freeze after original pairs')
        freezes=[inv.json(name) for name in gate['noise_freeze_receipts']]
        require(len(freezes)==18 and {v['noise_cell'] for v in freezes}==set(slots), 'missing/reused global noise slots')
        frozen_unresolved=[]
        for freeze in freezes:
            raw=inv.json(freeze['noise'])
            unknown=unresolved_metrics(freeze['noise_cell'],raw)
            frozen_unresolved.extend(unknown)
            require(freeze['unresolved_noise_metrics']==unknown and freeze['qualification'] is False, 'frozen unknown ledger drift')
            require(freeze['accepted_by_root'] is True and freeze['definition_sha256']==DEFINITION_SHA and
                freeze['noise_sha256']==sha(inv.file(freeze['noise'])) and
                raw['created_ns']<=freeze['frozen_ns']<=gate['frozen_ns']<earliest, 'global noise freeze drift/order')
        require(sorted(gate['unresolved_noise_metrics'],key=lambda v:(v['noise_cell'],v['id']))==
            sorted(frozen_unresolved,key=lambda v:(v['noise_cell'],v['id'])), 'global unresolved observation drift')
    receipts = []
    def original_calibrate(bundle, output, existing=False):
        if not existing:
            return maintenance.calibrate(bundle['calibration_runs'],bundle['metric'],output)
        # Replay the ORIGINAL calibrator without overwriting its immutable
        # previous output. Its ordinary validation/order/metric path still runs.
        captured=[]; old_save=maintenance.save
        def retain(path,value,exclusive=False):
            require(pathlib.Path(path)==output and exclusive, 'unexpected original calibration output')
            captured.append(value)
        try:
            maintenance.save=retain
            maintenance.calibrate(bundle['calibration_runs'],bundle['metric'],output)
        finally:
            maintenance.save=old_save
        require(len(captured)==1, 'missing original calibration replay')
        return captured[0]
    for name in selected:
        bundle_path = inv.local(out/(name+'.bundle.json'))
        bundle = read(bundle_path)
        expected=slots[name]
        if a.stage=='final-evaluate' and 'metric' in expected:
            # Root may bind only the required calibration and ordered pair
            # digests. Every bound digest must match the external raw anchor;
            # all paths and other frozen fields remain exactly unchanged.
            require(set(bundle)==set(expected) and
                {k:v for k,v in bundle.items() if k not in ('calibration_sha256','pairs')}==
                {k:v for k,v in expected.items() if k not in ('calibration_sha256','pairs')},
                'resolved offline bundle drift')
            require(bundle['calibration_sha256']==sha(inv.file(expected['calibration'])),
                'offline calibration digest is not externally anchored')
            require(isinstance(bundle['pairs'],list) and len(bundle['pairs'])==len(expected['pairs'])==3,
                'offline pair count drift')
            for pair, frozen in zip(bundle['pairs'],expected['pairs']):
                require(isinstance(pair,dict) and set(pair)=={'A','B','A_sha256','B_sha256'} and
                    pair['A']==frozen['A'] and pair['B']==frozen['B'], 'offline pair paths/order/fields drift')
                for role in ('A','B'):
                    require(pair[role+'_sha256']==sha(inv.file(frozen[role])),
                        'offline pair digest is not externally anchored: '+role)
        else:
            require(bundle==expected, 'resolved bundle drift')
        noise_path = out/(name+'.noise.json'); freeze_path = out/(name+'.freeze.json')
        try:
            if a.stage=='final-evaluate':
                inv.local(noise_path); inv.local(freeze_path)
                # Reuse evaluator global original-order/noise gates for every
                # unified slot before allowing offline pairs to be summarized.
                if 'metric' in bundle:
                    gate=inv.json(inv.anchor['global_calibration_gate'])
                    require(gate['accepted_by_root'] is True and gate['all_selected_service_online_noises_frozen'] is True, 'global freeze unaccepted')
                    noise=inv.json(str(noise_path)); calibration_valid(noise)
                    freeze=inv.json(str(freeze_path))
                    require(freeze['accepted_by_root'] is True and freeze['noise_sha256']==sha(noise_path) and
                        noise['created_ns']<=freeze['frozen_ns']<=gate['frozen_ns'], 'offline freeze acceptance/order')
                    require(bundle['calibration_sha256']==sha(noise_path), 'offline noise bundle hash requires root binding')
                    result=maintenance.analyze(bundle_path)
                    unknown=unresolved_metrics(name,noise)
                    if unknown:
                        # Preserve original validation/completion diagnostics, but
                        # never treat the original analyzer's E=0 as precision.
                        result.update(status='unknown', material=False, E=None, threshold=None,
                            unresolved_noise_metrics=unknown,
                            conclusion='unresolved calibration; final qualification gate remains unmet')
                else:
                    result=invoke_evaluator(ev,'evaluate',bundle_path,a.anchor,a.anchor_sha256)
                if 'metric' not in bundle:
                    result['allocation_ledger'] = allocation_ledger(inv, ev, collector, maintenance, bundle, result)
                result.update(qualification=False, root_acceptance_required=True, candidate_variant='R')
                save(out/(name+'.evaluation.json'),result)
            else:
                require(noise_path.exists()==freeze_path.exists(), 'partial retained calibration output; diagnose before continuing')
                existing=noise_path.exists()
                if 'metric' in bundle:
                    noise=original_calibrate(bundle,noise_path,existing)
                else:
                    noise=invoke_evaluator(ev,'calibrate',bundle_path,a.anchor,a.anchor_sha256)
                    if not existing:
                        save(noise_path,noise)
                calibration_valid(noise)
                if existing:
                    inv.local(noise_path); inv.local(freeze_path)
                    frozen=read(noise_path)
                    fields=('metric','contract','baseline_source','paths','hashes','values','E') if 'metric' in bundle else ('definition_sha256','calibration','contract','ledger','original_evidence')
                    require(all(frozen[k]==noise[k] for k in fields), 'retained noise replay drift')
                    receipt=read(freeze_path)
                    require(receipt['noise_cell']==name and receipt['noise_sha256']==sha(noise_path) and
                        receipt['definition_sha256']==DEFINITION_SHA and frozen['created_ns']<=receipt['frozen_ns'] and
                        receipt['unresolved_noise_metrics']==unresolved_metrics(name,frozen) and receipt['qualification'] is False,
                        'retained freeze drift')
                else:
                    receipt=dict(schema=1, accepted_by_root=False, noise_cell=name, noise=str(noise_path), noise_sha256=sha(noise_path),
                        frozen_ns=time.time_ns(), definition_sha256=DEFINITION_SHA, input_anchor_sha256=a.anchor_sha256,
                        qualification=False, unresolved_noise_metrics=unresolved_metrics(name,noise),
                        note='Observation freeze candidate, including UNKNOWN diagnostics; root must explicitly accept contents before R. Unknown is never a passing gate.')
                    save(freeze_path,receipt)
                receipts.append(str(freeze_path))
        except Exception as error:
            failure=out/(name+'.analysis-failure.json')
            if not failure.exists():
                save(failure,dict(status='rejected', reason=str(error), qualification=False, recorded_ns=time.time_ns()))
            raise
    if a.stage=='full-calibration':
        require(len(cells)==6 and len(selected)==18 and len(receipts)==18, 'incomplete global matrix')
        unresolved=[]
        for name in selected:
            unresolved.extend(unresolved_metrics(name,read(out/(name+'.noise.json'))))
        gate=dict(schema=1, accepted_by_root=False, frozen_ns=time.time_ns(), offline_cells_complete=10,
            offline_noise_metrics=['elapsed_seconds','peak_rss_bytes'], all_selected_service_online_noises_frozen=True,
            noise_freeze_receipts=receipts, original_pair_groups=cells, definition_sha256=DEFINITION_SHA,
            input_anchor_sha256=a.anchor_sha256, qualification=False,
            unresolved_noise_metrics=unresolved, candidate_collection_accepted_by_root=False,
            note='All18 supplemental observation slots and6 common-v3 original C groups validated; original B all36 freeze remains separately required. Root must explicitly accept unresolved observations and collection permission before R; unknown primary/guard metrics leave final gates unmet.')
        save(out/'global-calibration-freeze.json',gate)
    print(json.dumps(dict(status='analysis_complete_root_review_required', stage=a.stage, slots=selected, qualification=False)))


if __name__=='__main__':
    try:
        main()
    except (ValueError,KeyError,TypeError,OSError,AssertionError) as error:
        print(json.dumps(dict(status='rejected',reason=str(error),qualification=False)),file=sys.stderr)
        sys.exit(1)
