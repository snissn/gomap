"""Source-only exclusive construction; no campaign imports, native, Git or GH."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
LATER = BASE/'qualification-v12-later-execution-preparation-v3'
COMPAT = BASE/'qualification-v12-analysis-receipt-compatibility-preparation-v1'
REMOTE = Path('/home/mikers/quicksilver-maintenance-5028-20261006')
ADAPTER = COMPAT/'prepare-original-analysis-receipt-view-v12-v1.py'
ADAPTER_SHA = '536dc37e797bc30b0bde5c779f3471a861b4c04d5178683c4d1c7ca5f2a61ddf'
ADAPTER_REMOTE = str(REMOTE/ADAPTER.relative_to(BASE))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(p, value):
    with p.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')

def build(old, oldsha, new, edits):
    assert sha(old) == oldsha
    initial = old.read_text()
    text = initial
    for before, after in edits:
        assert text.count(before) == 1, before[:100]
        text = text.replace(before, after, 1)
    ast.parse(text)
    reversed_text = text
    for before, after in reversed(edits):
        assert reversed_text.count(after) == 1
        reversed_text = reversed_text.replace(after, before, 1)
    assert reversed_text == initial
    assert ast.dump(ast.parse(reversed_text)) == ast.dump(ast.parse(initial))
    with new.open('x') as f:
        f.write(text)
    with (HERE/(new.name+'.diff')).open('x') as f:
        f.write(''.join(difflib.unified_diff(initial.splitlines(True),
            text.splitlines(True), fromfile=str(old), tofile=str(new))))
    return {'original': {'path': str(old), 'sha256': oldsha},
        'prepared': {'path': str(new), 'sha256': sha(new)},
        'exact_reversal': True, 'edits': len(edits)}

assert sha(ADAPTER) == ADAPTER_SHA
transition_addition = '''
def preparation_transport(request, role, out, files):
    """Bind the actual prepare-only adapter without changing original analysis."""
    transport=request['preparation_transport']
    assert set(transport)=={'adapter','request','provenance','execution'}
    adapter_ref={'path':ADAPTER_PATH,'sha256':ADAPTER_SHA}
    assert transport['adapter']==adapter_ref
    adapter=source(Path(ADAPTER_PATH),'root_prepare_receipt_view')
    q=bound(transport['request']); provenance=bound(transport['provenance'])
    assert q['adapter']==adapter_ref and q['role']==role
    assert q['schema']==1 and q['owner']=='/root' and q['accepted_by_root'] is True
    assert q['prepare_receipt_read_view_authorized'] is True and q.get('source_only') is not True
    assert all(q[k] is False for k in adapter.FLAGS)
    expected=['python3','-B',str(BD if role=='B' else RD),'full-calibration',
        '--campaign',str(ROOT),'--out',str(out)]
    if role=='R':
        expected+=['--original-B-anchor',request['base_anchor']['path'],
            '--original-B-anchor-sha256',request['base_anchor']['sha256'],
            '--definition',str(RDEF),'--definition-sha256',RDEF_SHA]
    expected+=['--prepare']
    assert q['original_argv']==expected
    adapter.validate_argv(role,expected)
    assert q['controller']=={'path':str(BD if role=='B' else RD),
        'sha256':PINS[BD if role=='B' else RD]}
    lock=bound(q['source_lock'])
    assert q['source_lock']['sha256']==adapter.LOCK_SHA
    manifest=bound(q['campaign_manifest'])
    assert q['campaign_manifest']=={'path':str(ROOT/'manifest.json'),
        'sha256':lock['manifest_sha256']}
    source_ref={'path':str(ROOT/manifest['receipts']['source']['path']),
        'sha256':manifest['receipts']['source']['sha256']}
    assert source_ref==q['source_receipt'] and source_ref['sha256']==adapter.SOURCE_SHA
    view,changes=adapter.normalized_view(bound(source_ref),lock)
    assert provenance['schema']==1 and provenance['owner']=='/root'
    assert provenance['scope']=='ACTUAL_PREPARE_ONLY_RECEIPT_READ_VIEW'
    assert provenance['request']==transport['request']
    assert provenance['controller']==q['controller']
    assert provenance['source_receipt']==source_ref and provenance['source_lock']==q['source_lock']
    assert provenance['logical_original_argv']==expected
    assert provenance['read_view_changes']==changes
    assert provenance['normalized_view_sha256']==hashlib.sha256(
        json.dumps(view,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    assert provenance['returncode']==0 and provenance['error'] is None
    assert type(provenance['pid']) is int and provenance['pid']>0
    assert type(provenance['started_ns']) is type(provenance['finished_ns']) is int
    assert 0<provenance['started_ns']<provenance['finished_ns']
    assert all(provenance[k] is False for k in adapter.FLAGS)
    assert q['provenance_path']==transport['provenance']['path']
    execution=bound(transport['execution']['run'])
    assert set(transport['execution'])=={'run','stdout','stderr'}
    outer=['python3','-B',ADAPTER_PATH,transport['request']['path'],
        transport['request']['sha256']]
    assert execution['native_argv']==provenance['outer_argv']==outer
    assert execution['rc']==0 and not execution.get('error')
    assert type(execution['started_ns']) is type(execution['finished_ns']) is int
    assert 0<execution['started_ns']<execution['finished_ns']
    for key in ('stdout','stderr'):
        p=Path(transport['execution'][key]['path'])
        assert reference(p)==transport['execution'][key]
        assert p.resolve(strict=True)==p and not p.is_symlink()
        assert execution[key]['sha256']==sha(p) and execution[key]['bytes']==p.stat().st_size
        add_file(files,p)
    assert not Path(transport['execution']['stderr']['path']).read_bytes()
    result=read(transport['execution']['stdout']['path'])
    assert result['status']=='root_review_required' and result['qualification'] is False
    assert result['anchor']==str(out/'external-anchor.draft.json')
    assert result['anchor_sha256']==request['prepared_draft']['sha256']
    for ref in (adapter_ref,transport['request'],transport['provenance'],
                transport['execution']['run'],q['controller'],q['source_lock'],
                q['campaign_manifest'],source_ref):
        add_file(files,ref['path'])
    for change in changes:
        add_file(files,change['original']['path'])

'''
oldtransition=LATER/'root-global-calibration-transition-v12-v1.py'
newtransition=LATER/'root-global-calibration-transition-v12-v2.py'
transition_edits=[
    ("PINS = {SEAM:",f"ADAPTER_PATH={ADAPTER_REMOTE!r}\nADAPTER_SHA={ADAPTER_SHA!r}\nPINS = {{Path(ADAPTER_PATH):ADAPTER_SHA,SEAM:"),
    ("def main():\n",transition_addition+"def main():\n"),
    ("    if pre:\n        draft=out/'external-anchor.draft.json';",
        "    if pre:\n        preparation_transport(req,role,out,files)\n        draft=out/'external-anchor.draft.json';")
]
transition=build(oldtransition,
    'a909511009ac765f83185f5a8f07c9e628c2719831f0b50e85c2c2e3722e8f56',
    newtransition,transition_edits)

prepare_block='''    prep_label = 'v12-original-'+role+'-full-calibration-prepare-v2'
    adapter = actual_request['prepare_adapter']
    assert adapter == dict(path=str(REMOTE/'qualification-v12-analysis-receipt-compatibility-preparation-v1/prepare-original-analysis-receipt-view-v12-v1.py'),
        sha256='536dc37e797bc30b0bde5c779f3471a861b4c04d5178683c4d1c7ca5f2a61ddf')
    preparation = dict(schema=1, status='ROOT_AUTHORIZED_PREPARE_ONLY_EXACT_RECEIPT_READ_VIEW',
        owner='/root', accepted_by_root=True, authorized_ns=time.time_ns(),
        prepare_receipt_read_view_authorized=True, role=role, adapter=adapter,
        controller=dict(path=str(driver), sha256=('e5744ead53031c489e3345c16a48c0b2e7b91c577177d50d25d94adfbe7b79fd'
            if role=='B' else '433c5df7016136afc8920b6663c5c0ed5d167cea993b35554a0b54a663764dc6')),
        original_argv=command+extra+['--prepare'],
        source_lock=actual_request['source_lock'],campaign_manifest=actual_request['campaign_manifest'],
        source_receipt=actual_request['source_receipt'],
        provenance_path=str(REMOTE/HERE.relative_to(BASE)/('root-'+role+'-prepare-receipt-view-provenance-v12-v1.json')),
        qualification=False,performance_accepted=False,collection_authorized=False,
        candidate_pairs_authorized=False,merge_authorized=False,held_excluded=[5004,5006],
        source_compatibility_acceptance=actual_request['compatibility_source_acceptance'])
    pp=HERE/('root-'+role+'-prepare-receipt-view-actual-request-v12-v1.json')
    save(pp,preparation)
    io.put({pp.relative_to(BASE).as_posix():pp},
        'v12-'+role+'-prepare-receipt-view-request-exclusive-stage-v1')
    prepared = json.loads(io.native(['python3','-B',adapter['path'],
        remote_ref(pp)['path'],sha(pp)],prep_label,7200))
    actual_execution(prep_label)
    provenance_reader = "import hashlib,json,pathlib,sys; p=pathlib.Path(sys.argv[1]); assert p.is_absolute() and p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p; data=p.read_bytes(); print(json.dumps(dict(reference=dict(path=str(p),sha256=hashlib.sha256(data).hexdigest()),bytes=len(data),value=json.loads(data))))"
    observed=json.loads(io.native(['python3','-B','-c',provenance_reader,
        preparation['provenance_path']],'v12-'+role+'-prepare-receipt-view-actual-provenance-readback-v1',120))
    assert observed['reference']['path']==preparation['provenance_path']
    pv=observed['value']
    assert pv['request']==remote_ref(pp) and pv['logical_original_argv']==preparation['original_argv']
    assert pv['outer_argv']==['python3','-B',adapter['path'],remote_ref(pp)['path'],sha(pp)]
    assert pv['returncode']==0 and pv['error'] is None
    assert all(pv[k] is False for k in ('qualification','performance_accepted','collection_authorized','candidate_pairs_authorized','merge_authorized'))
    paths = dict(run=RECEIPTS/(prep_label+'-run.json'),
        stdout=RECEIPTS/(prep_label+'-stdout.txt'),stderr=RECEIPTS/(prep_label+'-stderr.txt'))
    io.put({p.relative_to(BASE).as_posix():p for p in paths.values()},
        'v12-'+role+'-prepare-receipt-view-execution-exclusive-stage-v1')
    preparation_transport=dict(adapter=adapter,request=remote_ref(pp),
        provenance=observed['reference'],
        execution={name:remote_ref(path) for name,path in paths.items()})
'''
oldlauncher=LATER/'root-run-original-global-analyses-v12-v1.py'
newlauncher=LATER/'root-run-original-global-analyses-v12-v2.py'
launcher_edits=[
    ("HELPER_REL = 'qualification-v12-later-execution-preparation-v3/root-global-calibration-transition-v12-v1.py'",
     "HELPER_REL = 'qualification-v12-later-execution-preparation-v3/root-global-calibration-transition-v12-v2.py'"),
    ("HELPER_SHA = 'a909511009ac765f83185f5a8f07c9e628c2719831f0b50e85c2c2e3722e8f56'",
     f"HELPER_SHA = {sha(newtransition)!r}"),
    ("    prep_label = 'v12-original-'+role+'-full-calibration-prepare-v1'\n    prepared = json.loads(io.native(command+extra+['--prepare'], prep_label, 7200))\n    actual_execution(prep_label)\n",prepare_block),
    ("        prepared_draft=dict(path=prepared['anchor'], sha256=prepared['anchor_sha256']),",
     "        preparation_transport=preparation_transport,\n        prepared_draft=dict(path=prepared['anchor'], sha256=prepared['anchor_sha256']),"),
    ("    source = read(HERE/'root-global-transition-source-acceptance-v12-v1.json')",
     "    source = read(HERE/'root-global-transition-source-acceptance-v12-v2.json')\n    assert actual_request['compatibility_source_acceptance']==remote_ref(HERE/'root-global-transition-source-acceptance-v12-v2.json')\n    assert source['helper']==dict(path=str(HELPER),sha256=HELPER_SHA)\n    assert source['prepare_adapter']==actual_request['prepare_adapter']")
]
launcher=build(oldlauncher,
    'bf391958e4d1f08f16f5b0f3e784eb635cec839208198fdf61f042efdd5b84e0',
    newlauncher,launcher_edits)
save(HERE/'exact-deltas-and-source-reversal-v12-v1.json',dict(schema=1,
    source_only=True,qualification=False,performance_accepted=False,
    collection_authorized=False,candidate_pairs_authorized=False,merge_authorized=False,
    transitions=[transition,launcher],original_full_analysis_argv_unchanged=True,
    original_analysis_execution_function_unchanged=True,
    original_accepted_output_paths_unchanged=True,
    source_view_adapter=dict(path=str(ADAPTER),sha256=ADAPTER_SHA)))
print(json.dumps({'status':'SOURCE_ONLY_TWO_EXACT_TRANSPORT_COPIES_PREPARED',
    'transition':transition,'launcher':launcher},indent=2))
