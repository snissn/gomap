"""Exclusive source-only final lookup rebinding; no native or campaign imports."""
import ast,difflib,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
FINAL=BASE/'qualification-v12-final-artifact-preparation-v1'
COMPAT=BASE/'qualification-v12-analysis-receipt-compatibility-preparation-v1'
REMOTE=Path('/home/mikers/quicksilver-maintenance-5028-20261006')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
old=FINAL/'root-run-final-raw-and-metadata-v12-v2.py'
new=FINAL/'root-run-final-raw-and-metadata-v12-v3.py'
assert sha(old)=='1c9d04ee4f7a770f360ef401c7c00529279277861c913bee1a516cc0483cc8f0'
raw=COMPAT/'root-final-raw-closure-v12-v2.py'
assert sha(raw)=='f8f4c9b86730fe8266f6268370f51461ecfab89e2e1387bf7fcec4425e5d5c17'
before=old.read_text();after=before
edits=[
 ("RAW = PREP/'root-final-raw-closure-v12-v1.py'",
  "RAW = BASE/'qualification-v12-analysis-receipt-compatibility-preparation-v1/root-final-raw-closure-v12-v2.py'"),
 ("RAW_SHA = '34cd215d65da201bf50f468042959988c13c004bd89674cf6b7a8ee626b6a5b2'",
  "RAW_SHA = 'f8f4c9b86730fe8266f6268370f51461ecfab89e2e1387bf7fcec4425e5d5c17'"),
 ("    for path,helper in ((raw_adopt,RAW),(metadata_adopt,METADATA)):\n",
  "    metadata_review=local_path(q['metadata_independent_source_review'])\n    for path,helper,review in ((raw_adopt,RAW,INDEPENDENT),(metadata_adopt,METADATA,metadata_review)):\n"),
 ("        assert selection['helper']==remote_ref(helper) and selection['independent_source_review']==remote_ref(INDEPENDENT)\n",
  "        assert selection['helper']==remote_ref(helper) and selection['independent_source_review']==remote_ref(review)\n"),
 ("        request=read(PREP/'raw-request.draft.json');request.pop('source_only')",
  "        request=read(BASE/'qualification-v12-analysis-compatibility-coordination-v1/raw-request.draft-v12-v2.json');request.pop('source_only')"),
 ("        sources=(RAW,METADATA,raw_adopt,metadata_adopt,INDEPENDENT,rp)",
  "        sources=(RAW,METADATA,raw_adopt,metadata_adopt,INDEPENDENT,metadata_review,rp)")
]
for a,b in edits:
    assert after.count(a)==1,a
    after=after.replace(a,b,1)
ast.parse(after)
reverse=after
for a,b in reversed(edits):
    assert reverse.count(b)==1
    reverse=reverse.replace(b,a,1)
assert reverse==before
assert ast.dump(ast.parse(reverse))==ast.dump(ast.parse(before))
with new.open('x') as f:f.write(after)
with (HERE/(new.name+'.diff')).open('x') as f:
    f.write(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
        fromfile=str(old),tofile=str(new))))
draft=json.loads((FINAL/'raw-request.draft.json').read_bytes())
original=json.loads((FINAL/'raw-request.draft.json').read_bytes())
draft['helper']={'path':str(REMOTE/raw.relative_to(BASE)),'sha256':sha(raw)}
assert {k:v for k,v in draft.items() if k!='helper'}=={k:v for k,v in original.items() if k!='helper'}
assert draft['source_only'] is True and draft['accepted_by_root'] is False
save(HERE/'raw-request.draft-v12-v2.json',draft)
save(HERE/'final-transport-exact-deltas-v12-v1.json',dict(schema=1,source_only=True,
    qualification=False,performance_accepted=False,collection_authorized=False,
    candidate_pairs_authorized=False,merge_authorized=False,
    original={'path':str(old),'sha256':sha(old)},prepared={'path':str(new),'sha256':sha(new)},
    raw_helper={'path':str(raw),'sha256':sha(raw)},exact_reversal=True,
    edits=len(edits),metadata_helper_unchanged=True,
    metadata_original_review_retained=True,raw_draft_only_helper_changed=True))
print(json.dumps(dict(status='SOURCE_ONLY_FINAL_TRANSPORT_PREPARED',
    helper={'path':str(new),'sha256':sha(new)})))
