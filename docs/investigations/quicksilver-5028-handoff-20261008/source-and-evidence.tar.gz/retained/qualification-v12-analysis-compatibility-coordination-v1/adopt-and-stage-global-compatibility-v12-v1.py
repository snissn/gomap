"""Root coordination only: bind reviewed transport bytes and stage exact files."""
import hashlib
import json
from pathlib import Path
import time
import types

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
REMOTE = Path("/home/mikers/quicksilver-maintenance-5028-20261006")
ROOT = REMOTE / "qualification-v12-refresh/qualification-v10"
PREP = BASE / "qualification-v12-root-preparation-v1"
LATER = BASE / "qualification-v12-later-execution-preparation-v3"
COMPAT = BASE / "qualification-v12-analysis-receipt-compatibility-preparation-v1"
REVIEW = BASE / "qualification-v12-analysis-compatibility-independent-review-v2"
FLAGS = ("qualification", "performance_accepted", "collection_authorized",
         "candidate_pairs_authorized", "merge_authorized")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def ref(path, native=True):
    path = Path(path)
    assert path.is_absolute() and path.resolve(strict=True) == path
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(REMOTE / path.relative_to(BASE) if native else path),
                sha256=sha(path))


def save(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def load(path, name, expected):
    assert sha(path) == expected
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(path.read_bytes(), str(path), "exec"), module.__dict__)
    return module


assert __debug__
report = REVIEW / "REPORT.md"
manifest_path = REVIEW / "exact-source-manifest.json"
assert sha(report) == "05e1e145af84301b40997ff863f7bbb26da9c04b11b2ded9bbd02df49dd2a8d3"
assert sha(manifest_path) == "d2f7c8366041e1c33f0b88f4335113141e29472955d348c02efc261c1e91c4fd"
manifest = read(manifest_path)
assert manifest["verdict"] == "ACCEPT_SOURCE_COMPATIBILITY"
assert manifest["source_only"] is True and manifest["execution_authorized"] is False
assert manifest["held_excluded"] == [5004, 5006]
assert all(manifest[k] is False for k in FLAGS)
for row in manifest["inputs"] + manifest["outputs"]:
    path = Path(row["path"])
    assert ref(path, False)["sha256"] == row["sha256"]
    assert path.stat().st_size == row["bytes"]

preflight_label = "v12-receipt-compatibility-actual-readonly-preflight-v74"
p9 = BASE / "qualification-v9-selected-source-preparation-v1"
preflight = read(p9 / (preflight_label + "-stdout.txt"))
assert preflight["status"] == "ACTUAL_EXACT_RECEIPT_COMPATIBILITY_PREFLIGHT_PASS"
actual_run = read(p9 / (preflight_label + "-run.json"))
assert actual_run["rc"] == 0 and actual_run["started_ns"] < actual_run["finished_ns"]
for key in ("stdout", "stderr"):
    path = p9 / (preflight_label + "-" + key + ".txt")
    assert actual_run[key]["sha256"] == sha(path)
    assert actual_run[key]["bytes"] == path.stat().st_size
assert not (p9 / (preflight_label + "-stderr.txt")).read_bytes()

adapter = COMPAT / "prepare-original-analysis-receipt-view-v12-v2.py"
transition = LATER / "root-global-calibration-transition-v12-v3.py"
launcher = LATER / "root-run-original-global-analyses-v12-v3.py"
assert sha(adapter) == "830f832be33ffd6c6c757f3c86ca0a5d3089357f8d2fc2d6705ae17c42ef8466"
assert sha(transition) == "1f5fe209749617ebe65f1bccf4fd579c557a145047cbc8c1093ce1fbdd793b97"
assert sha(launcher) == "b85dd702c40c2219399fbb68bd4544c6f9e5e9b1225ba92407d89fe0dffa5f4d"

adoption_path = LATER / "root-global-transition-source-acceptance-v12-v3.json"
adoption = dict(
    schema=1, status="ROOT_ACCEPTED_EXACT_RECEIPT_TRANSPORT_SOURCE_ONLY",
    source_only=True, accepted_by_root=True, accepted_ns=time.time_ns(),
    owner="/root", campaign_root=str(ROOT), held_excluded=[5004, 5006],
    helper=ref(transition), prepare_adapter=ref(adapter), global_launcher=ref(launcher),
    independent_source_review=ref(report),
    independent_source_manifest=ref(manifest_path),
    finite_source_manifest=manifest["finite_manifest"],
    actual_native_preflight={key: ref(p9 / (preflight_label + "-" + suffix), False)
                            for key, suffix in (("run", "run.json"),
                                                ("stdout", "stdout.txt"),
                                                ("stderr", "stderr.txt"))},
    exact_native_R_controller_custody=ref(
        HERE / "exact-native-R-controller-readback-custody-v12-v1.json", False),
    source_boundary="Receipt field compatibility only; immutable controllers, evaluator, rules, matrix, raw files, scientific functions and performance gates unchanged",
    continuation_ownership="Root invokes the unchanged selected full-R, physical34, pairs and final-content launchers serially; failed continuation V2 is retained and will not restart",
    **{key: False for key in FLAGS})
save(adoption_path, adoption)

old_request = PREP / "original-global-analysis-actual-request-v12-v1.json"
assert sha(old_request) == "aad810553d9766a4e34179ed611a949e59ee9f061170a3a40fd895dce8cb55d8"
request = read(old_request)
request.update(
    authorized_ns=time.time_ns(), helper=ref(launcher), prepare_adapter=ref(adapter),
    compatibility_source_acceptance=ref(adoption_path),
    source_lock=ref(PREP / "actual-fresh-source-lock-v12.json"),
    campaign_manifest=dict(path=str(ROOT / "manifest.json"),
        sha256="fe243316b55e429a276a8a060607c8920973275c3e089125dbf66f13370a5092"),
    source_receipt=dict(path=str(ROOT / "receipts/source-inventory.json"),
        sha256="30eb9fe190c0b65cd7097333285d8b5e324532bc930a967af6423c6cb300ef81"))
assert all(request[k] is False for k in FLAGS)
request_path = PREP / "original-global-analysis-actual-request-v12-v2.json"
save(request_path, request)
save(HERE / "root-global-compatibility-source-adoption-and-request-v12-v1.json",
     dict(schema=1, owner="/root", source_adoption=ref(adoption_path),
          actual_root_request=ref(request_path, False),
          old_failed_request=ref(old_request, False), reviewed_inputs_verified=len(manifest["inputs"]),
          original_science_unchanged=True, held_excluded=[5004, 5006],
          **{key: False for key in FLAGS}))

io = load(p9 / "root_native_io.py", "root_io",
    "fe805bf7f6445dddba369db050df0df6461404613d14485befdf2da5292c2ba1")
stage_path = BASE / "qualification-v12-exact-stage-preparation-v1/exact_stage_v12_v1.py"
stage = load(stage_path, "exact_stage",
    "27515da907ab4bf3bdcb5fc56773364189b70159317521c2e22e5e4ce068dd03")
sources = [adapter, transition, launcher, report, manifest_path, adoption_path,
           PREP / "actual-fresh-source-lock-v12.json"]
result = stage.exact_stage(
    io, {path.relative_to(BASE).as_posix(): path for path in sources},
    "v12-current-global-receipt-compatibility-source-v1")
assert result["status"] == "EXACT_STAGE_COMPLETE"
state = read(BASE / "state.json")
assert state["native_active"] is None
state.update(
    active_advisers=[], active_adviser=None,
    qualification_v12_receipt_compatibility_source_acceptance=ref(adoption_path, False),
    qualification_v12_original_global_actual_request=ref(request_path, False),
    current_execution_status="Reviewed exact receipt compatibility staged; original global artifact replay next",
    next_action="Root invokes current global launcher V3 once; unchanged original B36/R18 gates; no pairs yet")
pending = HERE / "state-compatibility-source-adoption-v12-v1.json"
save(pending, state)
pending.replace(BASE / "state.json")
print(json.dumps(dict(status="REVIEWED_EXACT_GLOBAL_TRANSPORT_STAGED",
    source_adoption=ref(adoption_path), actual_request=ref(request_path, False),
    source_files=len(sources), reused=len(result["reused"]),
    transferred=len(result["transferred"]), qualification=False,
    candidate_pairs_authorized=False), allow_nan=False), flush=True)
