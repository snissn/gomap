"""Root source-only admission repair and binding of actual prepare custody."""
import ast,difflib,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
LATER=BASE/'qualification-v12-later-execution-preparation-v3'
COMPAT=BASE/'qualification-v12-analysis-receipt-compatibility-preparation-v1'
ADAPTER=COMPAT/'prepare-original-analysis-receipt-view-v12-v2.py'
OLD_ADAPTER_SHA='536dc37e797bc30b0bde5c779f3471a861b4c04d5178683c4d1c7ca5f2a61ddf'
ADAPTER_SHA='830f832be33ffd6c6c757f3c86ca0a5d3089357f8d2fc2d6705ae17c42ef8466'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def build(old,pin,new,edits):
    assert sha(old)==pin
    original=old.read_text();text=original
    for before,after,count in edits:
        assert text.count(before)==count,before
        text=text.replace(before,after)
    ast.parse(text)
    reverse=text
    for before,after,count in reversed(edits):
        assert reverse.count(after)==count,after
        reverse=reverse.replace(after,before)
    assert reverse==original
    with new.open('x') as f:f.write(text)
    with (HERE/(new.name+'.diff')).open('x') as f:
        f.write(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),
            fromfile=str(old),tofile=str(new))))
    return dict(original=dict(path=str(old),sha256=pin),
        prepared=dict(path=str(new),sha256=sha(new)),exact_reversal=True)
assert sha(ADAPTER)==ADAPTER_SHA
admission="""    assert q['held_excluded']==[5004,5006]
    assert type(q['authorized_ns']) is int and q['authorized_ns']>0
    adoption=bound(q['source_compatibility_acceptance'])
    assert adoption['schema']==1 and adoption['owner']=='/root'
    assert adoption['accepted_by_root'] is adoption['source_only'] is True
    assert adoption['held_excluded']==[5004,5006] and adoption['campaign_root']==str(ROOT)
    assert all(adoption[k] is False for k in adapter.FLAGS)
    assert adoption['prepare_adapter']==adapter_ref
    assert adoption['helper']==reference(Path(__file__).resolve())
    add_file(files,q['source_compatibility_acceptance']['path'])
    for key in ('independent_source_review','independent_source_manifest'):
        ref=adoption[key];assert reference(Path(ref['path']))==ref
        add_file(files,ref['path'])
"""
oldtransition=LATER/'root-global-calibration-transition-v12-v2.py'
newtransition=LATER/'root-global-calibration-transition-v12-v3.py'
t=build(oldtransition,'fe4263c76d4bda7c2c5882e989f4407a9c8486d0345b73c8a734642ec36da05f',
    newtransition,[
        ('prepare-original-analysis-receipt-view-v12-v1.py','prepare-original-analysis-receipt-view-v12-v2.py',1),
        (OLD_ADAPTER_SHA,ADAPTER_SHA,1),
        ("    adapter.validate_argv(role,expected)\n",admission,1)])
oldlauncher=LATER/'root-run-original-global-analyses-v12-v2.py'
newlauncher=LATER/'root-run-original-global-analyses-v12-v3.py'
l=build(oldlauncher,'d11575ce3d7ddd3bee76a6c54afc7e77fcfb3853eb1aa729fb46df627bd6193e',
    newlauncher,[
        ('root-global-calibration-transition-v12-v2.py','root-global-calibration-transition-v12-v3.py',1),
        ('fe4263c76d4bda7c2c5882e989f4407a9c8486d0345b73c8a734642ec36da05f',sha(newtransition),1),
        ('prepare-original-analysis-receipt-view-v12-v1.py','prepare-original-analysis-receipt-view-v12-v2.py',1),
        (OLD_ADAPTER_SHA,ADAPTER_SHA,1),
        ('root-global-transition-source-acceptance-v12-v2.json','root-global-transition-source-acceptance-v12-v3.json',2)])
def funcs(p):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
original=funcs(LATER/'root-global-calibration-transition-v12-v1.py')
new=funcs(newtransition)
assert new['original_analysis_execution']==original['original_analysis_execution']
assert [k for k in original if original[k]!=new[k]]==['main']
save(HERE/'global-admission-exact-reversal-v12-v1.json',dict(schema=1,source_only=True,
    qualification=False,performance_accepted=False,collection_authorized=False,
    candidate_pairs_authorized=False,merge_authorized=False,
    transition=t,launcher=l,prepare_adapter=dict(path=str(ADAPTER),sha256=ADAPTER_SHA),
    original_full_analysis_execution_unchanged=True,
    no_cross_clock_containment_rule=True,
    post_prepare_argv_exact_comparison_retained=True))
print(json.dumps(dict(status='SOURCE_ONLY_GLOBAL_ADMISSION_REVISION_PREPARED',
    transition=t,launcher=l),indent=2))
