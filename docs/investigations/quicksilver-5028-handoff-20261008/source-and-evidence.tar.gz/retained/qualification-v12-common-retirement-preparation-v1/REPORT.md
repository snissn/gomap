# Provisional common-retirement integration preparation

This is source-only local preparation for gomap #5028. The externally owned prerequisite #5083 / PR5084 remains active under #5044; its supplied head is `2c313a7562d6ed8d074099b445951c80cea711a9`. Consume the prerequisite only after its owner lands it and recheck the final landed source. Nothing here adopts its branch, claims an approved fix, or establishes a resolved or landed integration. #5004 and PR5006 were excluded.

No native binary, compiler, Go test, performance run, or dependency-resolution command was executed. Git object inspection and `git merge-tree` created only diagnostic loose objects; no checkout, index, branch, or ref was changed. The dirty primary status was identical before and after artifact creation. These documents contain object identities and inventories, not duplicate source archives.

## Exact source bindings

| Role | Object | Tree | Status |
| --- | --- | --- | --- |
| current_main | `af56fe515668b5c8ddf7d1b06a01f251fefcf8d6` | `398bf757731d9988156d5d1a14aea671c4942a43` | exact commit |
| old_A | `3325dfe77940fec8587d8b61b1ac4e0b2f72caca` | `0600b47bf0a3a609917d224d7fd06c40737bcd8e` | exact commit |
| old_B | `3b72833df173d1277df88be5453a58d6d311bd81` | `10010860069c44a7384cf03d122066692528fc54` | exact commit |
| old_R | `7f7dd3b126df465ed971a410651d44b2ecc62383` | `5b0b0073939710d8e37367698398ceead21440e1` | exact commit |
| provisional_A | `2c313a7562d6ed8d074099b445951c80cea711a9` | `79100a06e3258caacbc127678f1a4d17bcc9f3e6` | exact commit |
| provisional_B_unresolved | `1c5a08388dee72568f61892fe8ffe8f3b9fca02b` | `1c5a08388dee72568f61892fe8ffe8f3b9fca02b` | unresolved diagnostic tree |
| provisional_R_unresolved | `6f1347d889633103bfd1b073b373b6327c652f23` | `6f1347d889633103bfd1b073b373b6327c652f23` | unresolved diagnostic tree |

`provisional_A` is the exact supplied PR head, not current main and not a landed prerequisite. The two additional tree IDs are conflict-bearing diagnostic outputs. They must never be used as frozen compiler source receipts or presented as actual resolved A/R/B candidates.

## Merge results and conflict scope

1. `git merge-tree --write-tree --name-only 7f7dd3b126df465ed971a410651d44b2ecc62383 2c313a7562d6ed8d074099b445951c80cea711a9` returned exit 1 and diagnostic tree `6f1347d889633103bfd1b073b373b6327c652f23`.
2. `git merge-tree --write-tree --name-only --merge-base=7f7dd3b126df465ed971a410651d44b2ecc62383 3b72833df173d1277df88be5453a58d6d311bd81 6f1347d889633103bfd1b073b373b6327c652f23` returned exit 1 and diagnostic tree `1c5a08388dee72568f61892fe8ffe8f3b9fca02b`. The explicit old-R merge base applies the B-versus-old-R delta to the unresolved provisional R tree. It does not resolve or accept the first conflict.

Both commands report exactly `.github/ci/ci_impact.json` as a textual conflict. Their raw stdout, stderr, exit codes, and arguments are retained in `provisional-R-merge-tree.txt`, `provisional-B-merge-tree.txt`, and `source-manifest.json`. CI inventory resolution is concrete outstanding work; this preparation does not guess its final content.

There is no reported textual conflict in runtime or harness inputs. In the R merge, Git automatically combines `TreeDB/internal/valuelog/stable_resource.go`, `TreeDB/internal/rootpublication/resource_token.go`, and `TreeDB/internal/rootpublication/resource_identity_unix.go` as well as the Windows test, lifecycle spec, and benchmark documentation. The B stage additionally automatically combines the lifecycle spec. Automatic combination establishes textual compatibility only. In particular, R adds shared physical-handle release callbacks and private Apply resource-family/frontier certification to the same resource-token and value-log files changed by the retirement prerequisite. Their combined ownership, pin release, parent-handle lifetime, deletion admission, retry, and platform behavior require review and fresh correctness checks after the real integration is resolved.

## Complete changed compiler-input inventory

`source-manifest.json` contains every changed tracked compiler candidate for old A -> provisional A, old R -> unresolved provisional R, and old B -> unresolved provisional B, with old/new Git blob IDs, modes, classes, and add/delete/modify disposition. It also contains all changed paths, changed harness paths, exact tree bindings, static candidate counts and canonical inventory SHA-256 values, and all `go:embed` directives with matched assets. `inventory-summary.json` provides the compact counts and production path lists.

The inventory conservatively selects all tracked repository Go files including tests, Go assembly, native source/header/object files in the listed suffix families, module/workspace files, and matched embedded assets. It includes nested modules, experiments, and archived evidence Go files rather than silently excluding them. It is an all-platform static superset, not a target-specific compiled dependency closure: no `go list`, external module-body resolution, generated untracked source discovery, or build was performed. Future build receipts must select the actual target closure and bind toolchain, build flags, external dependencies/native libraries, binary bytes, and resolved source content.

Each of the three old-to-provisional comparisons changes the same 56 static candidates: 16 non-test Go files and 40 test Go files. Four are archived evidence source (two non-test Go and two test Go), leaving 14 production files and 38 repository test files. No selected assembly, native source/object/header, module/workspace file, or embedded asset changed. A separate object diff also found no change in tracked `.a`, `.o`, `.obj`, `.lib`, `.so`, `.dylib`, `.dll`, `.rs`, `.asm`, `.sx`, `.inc`, or `.for` files. The two embedded assets remain `TreeDB/cmd/treedb_rag_benchmark/testdata/semantic_vectors.json` and `TreeDB/mvcc/mvcctest/testdata/public_trace_v1.json`.

The complete changed production-file list for each old A/R/B comparison is:

- `TreeDB/db/api.go`
- `TreeDB/internal/rootpublication/resource_identity_other.go`
- `TreeDB/internal/rootpublication/resource_identity_unix.go`
- `TreeDB/internal/rootpublication/resource_identity_windows.go`
- `TreeDB/internal/rootpublication/resource_token.go`
- `TreeDB/internal/valuelog/manager.go`
- `TreeDB/internal/valuelog/retirement_namespace_other.go`
- `TreeDB/internal/valuelog/retirement_namespace_unix.go`
- `TreeDB/internal/valuelog/retirement_namespace_windows.go`
- `TreeDB/internal/valuelog/retirement_parent_other.go`
- `TreeDB/internal/valuelog/retirement_parent_pool.go`
- `TreeDB/internal/valuelog/stable_resource.go`
- `cmd/collection_workload_bench/r1.go`
- `cmd/unified_bench/suite_quicksilver.go`

Relative to supplied current main `af56fe515668b5c8ddf7d1b06a01f251fefcf8d6`, the prerequisite changes 43 static candidates: 13 production Go files and 30 test Go files. The additional differences against old A/R/B include the current-main collection R1 harness and archived evidence source. All differences are recorded separately in the manifest so prerequisite changes are not conflated with mainline drift.

## Runtime and harness implications

The prerequisite updates retirement state and refresh, exact parent/child identity validation, parent-handle pooling, physical namespace deletion/quarantine/recovery, and deletion ownership. Its `Refresh` avoids using a closed retired handle while independently checking retained retirement path identity. Source coverage includes refresh during the close-before-unlink interval for both successful and failed unlink; rebound paths, special paths and directories; direct-retirement concurrency; namespace/parent identity; parent accounting; restore collisions; and platform cases. These are source coverage observations, not executed test results. See the exact-head [refresh regression](https://github.com/snissn/gomap/blob/2c313a7562d6ed8d074099b445951c80cea711a9/TreeDB/internal/valuelog/refresh_retired_test.go#L13) and [manager refresh](https://github.com/snissn/gomap/blob/2c313a7562d6ed8d074099b445951c80cea711a9/TreeDB/internal/valuelog/manager.go#L1964).

The prerequisite also changes the copy-on-write private append path in `TreeDB/db/api.go`: a synchronously owned private capture calls `snap.snapshot.tree.GetAppend` / `GetVersionedAppend` directly while retaining deferred private-capture close. This is shared production behavior in the provisional A, R, and B sources and can affect read timing/allocation. See [GetAppend](https://github.com/snissn/gomap/blob/2c313a7562d6ed8d074099b445951c80cea711a9/TreeDB/db/api.go#L525). Thus adding a common prerequisite does not preserve old runtime calibration.

The Quicksilver suite changes checkpoint-duration conversion to `math.Round`; this changes benchprof duration serialization, not the ordinary-writer/readers phase choreography. The maintenance Python harness, compared with old A/R/B, validates the current 16-field leaf-generation/manifest-revision GC receipt, preserves `leaf_gc` in validated measurements, and makes unsupported manifest-revision GC nonqualifying for the settle endpoint. Its tests and docs change alongside it. These analyzer/receipt changes must be source-bound with new capture plans; do not use the older parser to silently reinterpret new packets. The separate collection R1 harness gains configurable read operation counts, inheriting the old count when zero; it is included in the compiler inventory even though it is not the Quicksilver workload.

## Evidence reuse and remaining gates

Old exact-head correctness receipts remain valid historical observations about their original A/R/B sources and help preserve unchanged test obligations and workload contracts. They cannot establish correctness of this new common-retirement/private-append integration. Preserve the actual failed A guard, raw engine stderr, and failed database as causal evidence; do not relabel them as a passing baseline or qualifying fixture. The retained failure is the `failed to refresh value-log set ... file already closed` seam, and this source inspection does not certify that its complete runtime call path is now repaired.

Previously sealed closed physical fixture bytes, their close/verification receipts, logical-content contract, layout binding, and fingerprints can remain inputs where the campaign contract permits. This preparation performs no fixture open and proves no cross-source reopen compatibility. Before reuse, prove the selected immutable fixture still matches its receipt and has no active owner, restore/clone it into a distinct per-cell database, and establish compatibility/readback with the eventual frozen resolved source. Do not mutate the canonical closed fixture or the retained failed database. A restored cell that fails current checks cannot be accepted merely because its original fixture passed on old sources.

Fresh runtime qualification is required after owner landing and actual conflict resolution: rebind exact A/R/B source and compiler inputs, rerun the affected lifetime/correctness gates and the previously failing concurrent durable guard, then generate fresh endpoint/source calibration and paired measurements with the retained workload/mode/seed/fixture contracts. Common retirement and private append changes can alter time, allocations, memory, deletion behavior, and tails in every arm. Old calibration distributions, old pairs, old control effect/noise estimates, and old runtime RSS samples cannot qualify new sources or be mixed into the new source family. Old physical fixture receipts and source-bound correctness history do not substitute for these fresh captures.

The parent objective remains faster maintenance AND lower memory with unchanged correctness and performance gates. The baseline concurrency failure is blocking and cannot be waived. This preparation establishes neither a passing baseline nor faster maintenance, lower memory, material effects, noise qualification, performance parity, or landed behavior.

Artifacts in this directory are limited to this report, the exact JSON manifest and summary, two raw merge-tree outputs, and SHA-256 bindings. No source archives or native outputs were created.
