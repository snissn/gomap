import ast,difflib,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
OLD=BASE/'qualification-v12-root-preparation-v1/continue-reviewed-v12-qualification-v1.py'
NEW=OLD.with_name('continue-reviewed-v12-qualification-v2.py')
assert hashlib.sha256(OLD.read_bytes()).hexdigest()=='77cf3438315731a69dc54288e2a5b36717f2e3bd9cf3091148fc76cef856c4c0'
original=OLD.read_text();new=original
files={
'full-R-global54':('qualification-v12-later-execution-preparation-v3/root-run-full-R-and-global54-v12-v2.py','ACTUAL_FULL_R_COMPLETE24_CANONICAL_B_AND_GLOBAL54_REPLAY_PASS'),
'physical34':('qualification-v12-later-execution-preparation-v3/root-accept-physical34-v12-v1.py','ACTUAL_PHYSICAL34_ROOT_CONTENT_ACCEPTANCE_PASS'),
'original-pairs':('qualification-v12-later-execution-preparation-v3/root-run-original-pairs-v12-v2.py','ORIGINAL_PAIR_DRIVER_JOINED_ACTUAL_RAW_CONTENT_REVIEW_REQUIRED'),
'raw-metadata':('qualification-v12-final-artifact-preparation-v1/root-run-final-raw-and-metadata-v12-v2.py','ACTUAL_RAW114_ACCEPTED_EXACT34_IO_PENDING_FINAL_CONTENT_ACCEPTANCE'),
'content-evaluations':('qualification-v12-final-artifact-preparation-v1/root-run-final-content-and-evaluations-v12-v3.py','ACTUAL_ORIGINAL_FULL54_THEN_SEPARATE_STRICT19_JOINED_PRODUCT_DECISION_PENDING')}
contracts={};inputs=[OLD]
for phase,(name,status) in files.items():
 p=BASE/name;inputs.append(p);tree=ast.parse(p.read_bytes())
 matches=[node for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='dict' and any(k.arg=='status' and isinstance(k.value,ast.Constant) and k.value.value==status for k in node.keywords)]
 assert len(matches)==1
 contracts[phase]=dict(status=status,keys=[k.arg for k in matches[0].keywords])
addition='''OUTPUT_CONTRACTS = CONTRACT_LITERAL
PHYSICAL_ACCEPTANCE_KEYS = {'original_anchors', 'global54_actual_content_acceptance', 'consumer', 'candidate_pairs_authorized', 'accepted_ns', 'qualification', 'mapping', 'merge_authorized', 'status', 'owner', 'held_excluded', 'physical_anchors', 'receipt', 'accepted_by_root', 'schema', 'metadata_preservation_actual_contents_accepted', 'performance_accepted', 'preserved_completed_ns', 'request', 'campaign_root', 'collection_authorized', 'no_pair_namespace_at_acceptance', 'physical34_content_request'}
PHYSICAL_READBACK = HERE/'physical34-continuation-native-acceptance-readback-v12-v2.json'

def admit_output(phase,value,physical_acceptance=None):
    contract=OUTPUT_CONTRACTS[phase]
    assert isinstance(value,dict) and set(value)==set(contract['keys'])
    assert value['schema']==1 and value['status']==contract['status'];flags(value)
    if phase=='physical34':
        assert value['preserved_count']==34 and value['no_pair_namespace'] is True
        assert type(value['accepted_ns']) is int and 0<value['accepted_ns']<time.time_ns()
        for key in ('acceptance',):
            r=value[key];assert set(r)=={'path','sha256'} and isinstance(r['sha256'],str) and len(r['sha256'])==64
        assert set(value['original_anchors'])==set(value['physical_anchors'])=={'B','R'}
        a=physical_acceptance;assert isinstance(a,dict) and set(a)==PHYSICAL_ACCEPTANCE_KEYS;scope(a)
        assert a['schema']==1 and a['status']=='ACTUAL_EXACT34_BYTES_AND_PHYSICAL_ANCHORS_ROOT_ACCEPTED'
        assert a['accepted_by_root'] is a['metadata_preservation_actual_contents_accepted'] is True and a['owner']=='/root'
        assert a['accepted_ns']==value['accepted_ns'] and a['no_pair_namespace_at_acceptance'] is True
        assert a['original_anchors']==value['original_anchors'] and a['physical_anchors']==value['physical_anchors']
        assert type(a['preserved_completed_ns']) is int and 0<a['preserved_completed_ns']<a['accepted_ns']
    else:
        scope(value)
        if phase=='full-R-global54':
            assert value['accepted_by_root'] is True and type(value['accepted_ns']) is int and 0<value['accepted_ns']<time.time_ns()
            replay=value['replay_result']
            assert (replay['baseline_captures'],replay['guard_captures'],replay['B_slots'],replay['R_slots'])==(39,39,36,18)
        else:
            assert value['accepted_by_root'] is False and value['original_pair_count']==value['state_specific_guard_count']==114
            if phase=='original-pairs':
                assert value['raw_contents_accepted'] is value['raw_content_acceptance'] is False
                assert value['counts_are_expected_until_raw_replay'] is True
                assert value['expected_original_pairs']==value['expected_state_specific_guards']==114
                assert type(value['joined_ns']) is int and 0<value['joined_ns']<time.time_ns()
            elif phase=='raw-metadata':
                assert value['original_evaluation_required'] is value['strict_supplement_separate'] is True
                assert set(value['final_anchors'])=={'B','R'}
            elif phase=='content-evaluations':
                assert value['original_numerical_UNKNOWN_must_remain'] is True and len(value['separate_strict_proofs'])==19
                assert type(value['completed_ns']) is int and 0<value['completed_ns']<time.time_ns()
    return value

def read_physical_acceptance(io,value):
    r=value['acceptance'];assert set(r)=={'path','sha256'}
    assert Path(r['path']).parent==ROOT/'pre-pair-root-physical34-acceptance-v12-v1'
    assert Path(r['path']).name=='metadata-preservation-actual-content-acceptance.json'
    code="from pathlib import Path;import hashlib,sys;p=Path(sys.argv[1]);assert p.is_absolute() and p.resolve(strict=True)==p and p.is_file() and not p.is_symlink();data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==sys.argv[2];sys.stdout.buffer.write(data)"
    label='v12-continuation-physical34-native-acceptance-readback-v2'
    raw=io.native(['python3','-B','-c',code,r['path'],r['sha256']],label,180)
    assert hashlib.sha256(raw).hexdigest()==r['sha256']
    actual=json.loads(raw);admit_output('physical34',value,actual)
    # Preserve exact original native bytes; no authority or scope fields synthesized.
    with PHYSICAL_READBACK.open('xb') as out:out.write(raw)
    return actual

'''.replace('CONTRACT_LITERAL',repr(contracts))
new=new.replace("def save(p,v):\n",addition+"def save(p,v):\n",1)
new=new.replace("PACKET=BASE/'qualification-v12-root-continuation-preparation-v1'","PACKET=BASE/'qualification-v12-root-continuation-output-fix-preparation-v1'")
new=new.replace('def invoke(config,phase,actual_fields,authorization):','def invoke(config,phase,actual_fields,authorization,io=None):')
new=new.replace("value=json.loads(out.read_bytes());scope(value)\n return value","rows=[json.loads(line) for line in out.read_bytes().splitlines() if line.strip()]\n assert rows and all(isinstance(row,dict) for row in rows)\n value=rows[-1]\n acceptance=read_physical_acceptance(io,value) if phase=='physical34' else None\n return admit_output(phase,value,acceptance)")
new=new.replace('def genuine_outcome(path,value,status):\n actual=read(path);assert actual==value and actual[\'status\']==status;scope(actual);return ref(path)',"def genuine_outcome(path,value,status,phase):\n actual=read(path);assert actual==value and actual['status']==status\n acceptance=read(PHYSICAL_READBACK) if phase=='physical34' else None\n if acceptance is not None:assert sha(PHYSICAL_READBACK)==actual['acceptance']['sha256']\n admit_output(phase,actual,acceptance);return ref(path)")
new=new.replace("'later_artifact_execution_authorized')\n physical_ref=", "'later_artifact_execution_authorized',io=io)\n physical_ref=")
for phase,(_,status) in files.items():
 new=new.replace(",physical,'"+status+"')",",physical,'"+status+"','"+phase+"')") if phase=='physical34' else new
 if phase in ('full-R-global54','original-pairs','raw-metadata'):
  var={'full-R-global54':'full','original-pairs':'pairs','raw-metadata':'raw'}[phase]
  new=new.replace(','+var+",'"+status+"')",','+var+",'"+status+"','"+phase+"')")
new=new.replace("assert read(FINAL/'root-final-evaluations-actual-outcome-v12-v1.json')==content","genuine_outcome(FINAL/'root-final-evaluations-actual-outcome-v12-v1.json',content,'ACTUAL_ORIGINAL_FULL54_THEN_SEPARATE_STRICT19_JOINED_PRODUCT_DECISION_PENDING','content-evaluations')")
new=new.replace("physical_ref=genuine_outcome(LATER/'actual-physical34-root-content-result-v12-v1.json',physical,'ACTUAL_PHYSICAL34_ROOT_CONTENT_ACCEPTANCE_PASS','physical34')","physical_ref=genuine_outcome(LATER/'actual-physical34-root-content-result-v12-v1.json',physical,'ACTUAL_PHYSICAL34_ROOT_CONTENT_ACCEPTANCE_PASS','physical34')\n assert physical['original_anchors']['R']==full['full_R']")
compile(new,str(NEW),'exec')
assert new!=original
with NEW.open('x') as out:out.write(new)
config=BASE/'qualification-v12-root-continuation-preparation-v1/finite-config.json'
with (HERE/'finite-config.json').open('xb') as out:out.write(config.read_bytes())
with (HERE/'continuation-v1-to-v2.diff').open('x') as out:out.write(''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True),fromfile=str(OLD),tofile=str(NEW))))
with (HERE/'output-contracts.json').open('x') as out:json.dump(contracts,out,indent=2);out.write('\n')
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
with (HERE/'source-manifest.json').open('x') as out:json.dump(dict(source_only=True,accepted=False,runtime_authority=False,qualification_acceptance=False,merge_authority=False,inputs=[identity(p) for p in inputs+[config]],output=identity(NEW)),out,indent=2);out.write('\n')
print(json.dumps(identity(NEW)))
