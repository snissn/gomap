"""Synthetic exact original output contracts; never execute a launcher/module/main."""
import ast,copy,json,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
p=BASE/'qualification-v12-root-preparation-v1/continue-reviewed-v12-qualification-v2.py'
tree=ast.parse(p.read_bytes());compile(p.read_bytes(),str(p),'exec')
selected=[n for n in tree.body if (isinstance(n,ast.FunctionDef) and n.name in ('flags','scope','admit_output')) or (isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id in ('FLAGS','OUTPUT_CONTRACTS','PHYSICAL_ACCEPTANCE_KEYS') for x in n.targets))]
root=Path('/home/mikers/quicksilver-maintenance-5028-20261006/qualification-v12-refresh/qualification-v10')
env=dict(ROOT=root,time=time,Path=Path)
exec(compile(ast.Module(body=selected,type_ignores=[]),'isolated-output-contracts','exec'),env)
contracts=env['OUTPUT_CONTRACTS'];now=time.time_ns()-1000000
ref=dict(path=str(root/'synthetic-only'),sha256='0'*64)
outputs={}
for phase,c in contracts.items():
 v={k:copy.deepcopy(ref) for k in c['keys']}
 v.update(schema=1,status=c['status'],**{k:False for k in env['FLAGS']})
 if phase!='physical34':v.update(campaign_root=str(root),held_excluded=[5004,5006])
 if phase=='full-R-global54':v.update(accepted_by_root=True,accepted_ns=now,replay_result=dict(baseline_captures=39,guard_captures=39,B_slots=36,R_slots=18))
 elif phase=='physical34':v.update(accepted_ns=now,preserved_count=34,no_pair_namespace=True,original_anchors={'B':copy.deepcopy(ref),'R':copy.deepcopy(ref)},physical_anchors={'B':copy.deepcopy(ref),'R':copy.deepcopy(ref)})
 else:
  v.update(accepted_by_root=False,original_pair_count=114,state_specific_guard_count=114)
  if phase=='original-pairs':v.update(raw_contents_accepted=False,raw_content_acceptance=False,counts_are_expected_until_raw_replay=True,expected_original_pairs=114,expected_state_specific_guards=114,joined_ns=now)
  elif phase=='raw-metadata':v.update(original_evaluation_required=True,strict_supplement_separate=True,final_anchors={'B':copy.deepcopy(ref),'R':copy.deepcopy(ref)})
  else:v.update(original_numerical_UNKNOWN_must_remain=True,separate_strict_proofs=[copy.deepcopy(ref) for _ in range(19)],completed_ns=now,original_evaluations={'B':{},'R':{}})
 outputs[phase]=v
physical=outputs['physical34']
# Native acceptance representative uses the exact original acceptance keys extracted as source.
native_source=BASE/'qualification-v12-later-execution-preparation-v3/root-accept-physical34-v12-v1.py'
native_tree=ast.parse(native_source.read_bytes())
accept_call=next(n for n in ast.walk(native_tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='dict' and any(k.arg=='status' and isinstance(k.value,ast.Constant) and k.value.value=='ACTUAL_EXACT34_BYTES_AND_PHYSICAL_ANCHORS_ROOT_ACCEPTED' for k in n.keywords))
acceptance={k.arg:copy.deepcopy(ref) for k in accept_call.keywords}
acceptance.update(schema=1,status='ACTUAL_EXACT34_BYTES_AND_PHYSICAL_ANCHORS_ROOT_ACCEPTED',accepted_by_root=True,metadata_preservation_actual_contents_accepted=True,owner='/root',accepted_ns=now,campaign_root=str(root),held_excluded=[5004,5006],original_anchors=copy.deepcopy(physical['original_anchors']),physical_anchors=copy.deepcopy(physical['physical_anchors']),preserved_completed_ns=now-1,no_pair_namespace_at_acceptance=True,**{k:False for k in env['FLAGS']})
checks=[]
def test(name,phase,value,a=None,deny=False):
 try:got=env['admit_output'](phase,value,a)
 except (AssertionError,KeyError,TypeError):assert deny,name;checks.append(dict(name=name,status='PASS_DENIED'))
 else:assert not deny and got is value,name;checks.append(dict(name=name,status='PASS'))
for phase,v in outputs.items():
 a=acceptance if phase=='physical34' else None
 test(phase+'-exact-original-contract',phase,v,a)
 bad=copy.deepcopy(v);bad.pop('schema');test(phase+'-missing-key',phase,bad,a,True)
 bad=copy.deepcopy(v);bad['invented_scope']=str(root);test(phase+'-extra-key',phase,bad,a,True)
 bad=copy.deepcopy(v);bad['status']='WRONG';test(phase+'-wrong-status',phase,bad,a,True)
 bad=copy.deepcopy(v);bad['qualification']=True;test(phase+'-forbidden-authority',phase,bad,a,True)
 if phase=='physical34':bad=copy.deepcopy(v);bad['preserved_count']=33
 elif phase=='full-R-global54':bad=copy.deepcopy(v);bad['replay_result']['B_slots']=35
 else:bad=copy.deepcopy(v);bad['original_pair_count']=113
 test(phase+'-count-drift',phase,bad,a,True)
for name,mutate in [('acceptance-scope',lambda a:a.update(campaign_root='wrong')),('acceptance-owner',lambda a:a.update(owner='other')),('acceptance-authority',lambda a:a.update(merge_authorized=True)),('acceptance-time',lambda a:a.update(accepted_ns=now-2)),('acceptance-anchors',lambda a:a.update(original_anchors={})),('acceptance-no-pair',lambda a:a.update(no_pair_namespace_at_acceptance=False)),('acceptance-completion-order',lambda a:a.update(preserved_completed_ns=now+1)),('acceptance-root-approval',lambda a:a.update(accepted_by_root=False))]:
 bad=copy.deepcopy(acceptance);mutate(bad);test(name,'physical34',physical,bad,True)
bad=copy.deepcopy(acceptance);bad.pop('consumer');test('acceptance-missing-original-key','physical34',physical,bad,True)
bad=copy.deepcopy(acceptance);bad['invented']=True;test('acceptance-extra-key','physical34',physical,bad,True)
test('physical-missing-native-acceptance','physical34',physical,None,True)
bad=copy.deepcopy(physical);bad.update(campaign_root=str(root),held_excluded=[5004,5006]);test('physical-no-fabricated-scope-fields','physical34',bad,acceptance,True)
# Exercise exactly the three AST statements that select the last dictionary stream row.
invoke=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='invoke')
rows_index=next(i for i,n in enumerate(invoke.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='rows' for t in n.targets))
body=invoke.body[rows_index:rows_index+3];assert isinstance(body[1],ast.Assert)
class BytesOnly:
 def __init__(self,data):self.data=data
 def read_bytes(self):return self.data
snippet=ast.Module(body=body,type_ignores=[])
stream_env=dict(json=json,out=BytesOnly(json.dumps({'progress':'synthetic'}).encode()+b'\n'+json.dumps(physical).encode()+b'\n'))
exec(compile(snippet,'isolated-stream-selection','exec'),stream_env)
assert stream_env['value']==physical and len(stream_env['rows'])==2
checks.append(dict(name='multirow-dictionary-stream-final-outcome',status='PASS'))
stream_env['out']=BytesOnly(b'[]\n'+json.dumps(physical).encode())
try:exec(compile(snippet,'isolated-stream-selection','exec'),stream_env)
except AssertionError:checks.append(dict(name='nondictionary-stream-row',status='PASS_DENIED'))
else:raise AssertionError('stream shape')
# Both original physical scope sites now route through exact phase admission.
genuine=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='genuine_outcome')
assert any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='admit_output' for n in ast.walk(genuine))
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='scope' for n in ast.walk(genuine))
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
invokes=sorted([n for n in ast.walk(main) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='invoke'],key=lambda n:n.lineno)
assert [n.args[1].value for n in invokes]==list(contracts)
assert any(k.arg=='io' for k in invokes[1].keywords)
result=dict(source_only=True,accepted=False,runtime_authority=False,qualification_acceptance=False,merge_authority=False,status='EXACT_ORIGINAL_OUTPUT_CONTRACT_CHECKS_PASS',case_count=len(checks),cases=checks,all_five_original_key_sets_source_extracted=True,both_scope_blockers_removed=True,phase_order_unchanged=True,no_launcher_or_native_helper_module_executed=True,no_native_or_network=True)
with (HERE/'static-check-results-v2.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(status=result['status'],case_count=len(checks))))
