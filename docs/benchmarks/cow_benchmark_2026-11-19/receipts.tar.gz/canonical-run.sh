#!/usr/bin/env bash
set -eu -o pipefail
task_dir=$(dirname "$(realpath "$0")")
cd "$task_dir/main"
source "$task_dir/go-env.sh"
locks=(
  /mnt/fast4tb/gomap-clienttail-K4YyLITS/host185-comparison.lock
  /mnt/fast4tb/gomap-host185-perf-custody.lock
  /tmp/gomap-ycsb-qualification.lock
)
exec 7>"${locks[0]}"
exec 8>"${locks[1]}"
exec 9>"${locks[2]}"
flock -n 7
flock -n 8
flock -n 9
run() {
  local label="$1" indexes="$2" formats="$3"
  ./scripts/bench_collections_canonical.sh -native-cow-companion \
    -skip-offline-rewrite -skip-full-leafgen -skip-sqlite \
    -out-dir "$task_dir/$label" -docs 100000 -batch-size 16000 \
    -indexes "$indexes" -formats "$formats" -benchtime 100000x -count 3 \
    2>&1 | tee "$task_dir/evidence/$label.log"
}
run collections-retained-zero-01 0 bson,json
run collections-retained-two-01 2 bson
