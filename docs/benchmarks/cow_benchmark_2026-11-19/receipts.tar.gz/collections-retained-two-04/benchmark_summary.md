# TreeDB Collections Canonical Benchmark

## Executive Summary

This run measures matched legacy-backend and shared native COW collection inserts through publication. It reports the checked post-timer checkpoints separately.

## Benchmark Configuration

| Key | Value |
| --- | --- |
| `generated_at` | `2026-11-20T03:42:35Z` |
| `run_dir` | `/mnt/fast4tb/gomap-cow-bench-20261119.IwVeTHK8/collections-retained-two-04` |
| `worktree` | `/mnt/fast4tb/gomap-cow-bench-20261119.IwVeTHK8/main` |
| `branch` | `codex/5541-cow-benchmark-coverage` |
| `commit` | `2c37febdd587` |
| `command_line` | `./scripts/bench_collections_canonical.sh -native-cow-companion -skip-offline-rewrite -skip-full-leafgen -skip-sqlite -out-dir /mnt/fast4tb/gomap-cow-bench-20261119.IwVeTHK8/collections-retained-two-04 -docs 16000 -batch-size 1000 -indexes 2 -formats bson -benchtime 16000x -count 3` |
| `docs` | `16000` |
| `batch_size` | `1000` |
| `indexes` | `2` |
| `tree_engine` | `command_wal_relaxed` |
| `profile` | `command_wal_relaxed` |
| `formats` | `bson` |
| `leaf_segment_target_bytes` | `1048576` |
| `leafgen_pack_force` | `true` |
| `leafgen_pack_max_generations` | `0` |
| `leafgen_pack_frame_k` | `16` |
| `index_vacuum` | `offline` |
| `profile_timed_matrix` | `false` |
| `profile_benchtime` | `16000x` |
| `profile_count` | `1` |

## Throughput Results

These rows are benchmark-timed post-insert measurements. Maintenance rows are excluded from throughput ranking.

| Config | Format | Indexes | Docs/sec | ns/doc | Batch size | Source |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| `treedb_bson_collection_2_indexes` | bson | 2 | 406449 | 2460.3 | 1000 | go_benchmark |
| `treedb_native_cow_bson_collection_2_indexes` | bson | 2 | 191144 | 5231.7 | 1000 | go_benchmark |

## Matched owner samples

The timer covers `InsertBatch` publication and the legacy final flush when buffered. The checked checkpoint and primary-key census follow the timer. One benchmark operation is one document.

| Config | Owner | Sample | ns/doc | B/op | allocs/op | Checkpoint ns | COW insert publications |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `treedb_bson_collection_2_indexes` | `legacy_backend` | 1 | 2546.0 | 3971 | 1 | 51504169 | - |
| `treedb_bson_collection_2_indexes` | `legacy_backend` | 2 | 2447.0 | 3351 | 1 | 46972723 | - |
| `treedb_bson_collection_2_indexes` | `legacy_backend` | 3 | 2388.0 | 3350 | 1 | 49899054 | - |
| `treedb_native_cow_bson_collection_2_indexes` | `shared_native_cow_btree` | 1 | 5363.0 | 3890 | 22 | 155676061 | 16 |
| `treedb_native_cow_bson_collection_2_indexes` | `shared_native_cow_btree` | 2 | 5133.0 | 3889 | 22 | 153416402 | 16 |
| `treedb_native_cow_bson_collection_2_indexes` | `shared_native_cow_btree` | 3 | 5199.0 | 3889 | 22 | 149971941 | 16 |

## Post-Insert Storage Comparison

These rows use the timed benchmark matrix post-insert basis. They are fair to compare with each other, but they are not compacted-state numbers.

| Config | Format | Indexes | Total bytes | B/doc | Docs/sec |
| --- | --- | ---: | ---: | ---: | ---: |
| `treedb_native_cow_bson_collection_2_indexes` | bson | 2 | 9,050,209 | 565.6 | 191144 |
| `treedb_bson_collection_2_indexes` | bson | 2 | 13,061,199 | 816.3 | 406449 |

## Storage Results by Phase

| Config | Shape | Phase | Total bytes | B/doc | Measurement | Note |
| --- | --- | --- | ---: | ---: | --- | --- |
| `treedb_bson_collection_2_indexes` | collection | `post_insert` | 13,061,199 | 816.3 | go_benchmark | post-insert benchmark size; not compacted |
| `treedb_native_cow_bson_collection_2_indexes` | collection | `post_insert` | 9,050,209 | 565.6 | go_benchmark | InsertBatch through native COW publication. Checked public checkpoint and primary-key census follow the timer. |

## Production Evidence

| Config | Phase | Producer route | Route used ops | Route fallbacks | GOMAXPROCS | Physical cores | Effective concurrency | Admitted | Span-native | Backlog coalescing | Storage policy |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | --- | --- | --- |
| `treedb_bson_collection_2_indexes` | `post_insert` | `command_wal_publish` | 4 | 0 | 12 | 6 | 6 | true | true | true | data_outer=true,index_outer=true |

## Guardrail Checks

| Severity | Code | Message |
| --- | --- | --- |
| info | `compaction.not_requested` | Timed-only companion run omits SQLite and canonical compaction comparisons |
| warning | `sqlite.skipped` | SQLite rows were intentionally skipped; fair compacted SQLite comparisons are omitted |

## Raw Results Appendix

Machine-readable JSON: `benchmark_results.json`

CSV matrix: `benchmark_matrix.csv`

| Config | Phase | Engine | Format | Indexes | Docs | Bytes | B/doc | Docs/sec | ns/doc |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `treedb_bson_collection_2_indexes` | `post_insert` | command_wal_relaxed | bson | 2 | 16000 | 13,061,199 | 816.3 | 406449 | 2460.3 |
| `treedb_native_cow_bson_collection_2_indexes` | `post_insert` | command_wal_relaxed | bson | 2 | 16000 | 9,050,209 | 565.6 | 191144 | 5231.7 |

## Reproduction Commands

Canonical entry point:

```bash
./scripts/bench_collections_canonical.sh
# or
make bench-collections-canonical
```

Exact command records from this run:

### timed_matrix

TREEDB_COLLECTION_BENCH_NATIVE_COW_COMPANION=true go run ./cmd/collection_bench_matrix -out-dir /mnt/fast4tb/gomap-cow-bench-20261119.IwVeTHK8/collections-retained-two-04/timed_matrix -formats bson -engine command_wal_relaxed -storage-cells index-vlog -tree-bench-pattern '^(BenchmarkCollectionShapeInsertBatch|BenchmarkCollectionShapeInsertBatchNativeCOW)$/^indexes_2$' -sqlite-bench-pattern '^(BenchmarkSQLiteShapeInsertBatchJSON|BenchmarkSQLiteShapeInsertBatchNativeColumns)$/^indexes_2$' -batch-size 1000 -benchtime 16000x -count 3 -leaf-segment-target-bytes 1048576 -leafgen-pack-frame-k 16 -skip-sqlite -report-vlog-rewrite=false -report-leafgen-pack-gc=false -report-post-maintenance-index-vacuum=false

