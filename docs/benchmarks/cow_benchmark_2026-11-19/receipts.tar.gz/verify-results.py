from pathlib import Path
import json

root = Path(__file__).resolve().parent


def read(path):
    return json.loads((root/path).read_text())


build = read('evidence/builds.json')
ack_cases = {'w1': (100000, 'command_wal_relaxed', 'Visible'),
             'journaled': (1000, 'command_wal_durable', 'Journal')}
for ack, (count, profile, concern) in ack_cases.items():
    campaign = root/f'load-{ack}-retained-01'
    result = read(campaign/'results.json')
    plan, trials = result['plan'], result['trials']
    assert plan == read(campaign/'plan.json')
    assert plan['source'] == build['load_runner_checkout']
    assert plan['binaries'] == {k: v['sha256'] for k, v in build['binaries'].items()}
    assert (plan['count'], plan['threads']) == (count, 64)
    assert [t['target'] for t in trials] == ['gomap', 'mongodb', 'mongodb', 'gomap', 'gomap', 'mongodb']
    for trial in trials:
        directory = campaign/trial['trial']
        case = directory/('treedb_mongo' if trial['target'] == 'gomap' else 'mongodb')
        stop, = case.glob('*-cleanup-1.stop.json')
        closed = read(stop)
        assert closed['absent'] and closed['graceful'] and not closed['errors']
        assert read(directory/'trial.json') == trial
        assert trial['drain']['elapsed_ns'] > 0
        assert trial['load']['INSERT']['count'] == count
        if trial['target'] == 'gomap':
            owner = trial['owner']
            assert owner['profile'] == profile and owner['memtable_mode'] == 'cow_btree'
            assert owner['publications'] > 0 and owner['counters'][concern+'Acknowledgements'] == count
            if ack == 'journaled':
                key = 'ycsb.gateway.write_concern.PhysicalSyncBoundaries'
                boundaries = [int(read(case/f'load.phase-stats-{side}.response.json')['receipt']['owner']['stats'][key])
                              for side in ('before', 'after')]
                assert boundaries[1] - boundaries[0] == count
        else:
            assert trial['drain']['mongodb_version'] == '8.2.7'
    print(campaign.name, len(trials), 'checked trials')

for label, formats, indexes in (('zero', {'bson', 'json'}, 0), ('two', {'bson'}, 2)):
    path = f'collections-retained-{label}-04/benchmark_results.json'
    result = read(path)
    assert build['canonical_checkout'].startswith(result['commit'])
    assert not any(x['severity'] == 'error' for x in result['guardrail_checks'])
    rows = [r for r in result['results'] if r['phase'] == 'post_insert' and r.get('owner')]
    owners = {'shared_native_cow_btree', 'legacy_backend'}
    assert {(r['format'], r['owner']) for r in rows} == {(f, o) for f in formats for o in owners}
    assert len(rows) == len(formats)*len(owners)
    for row in rows:
        assert (row['index_count'], row['document_count'], row['batch_size']) == (indexes, 16000, 1000)
        assert len(row['samples']) == 3
        for sample in row['samples']:
            assert sample['iterations'] == 16000 and sample['ns_per_op'] > 0
            metrics = sample['metrics']
            assert metrics['verified_shape_docs'] == 16000 and metrics['checkpoint_ns/op'] > 0
            if row['owner'] == 'shared_native_cow_btree':
                assert metrics['cow_insert_publication_delta'] == metrics['native_insert_batches'] == 16
                assert metrics['native_checkpoint_calls'] == 1
                assert metrics['native_checkpoint_calls_during_insert'] == metrics['native_checkpoint_errors'] == 0
                assert metrics['native_checkpoint_applied_lsn'] >= metrics['native_accepted_lsn_after_insert']
            else:
                assert row['production_evidence']['producer_route'] == 'command_wal_publish'
                assert metrics['ordered_root_route_command_wal_publish_used_ops'] > 0
    print(path, len(rows)*3, 'checked samples')
