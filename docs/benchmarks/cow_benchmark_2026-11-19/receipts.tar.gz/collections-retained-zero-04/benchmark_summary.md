# TreeDB Collections Canonical Benchmark

## Executive Summary

This run measures matched legacy-backend and shared native COW collection inserts through publication. It reports the checked post-timer checkpoints separately.

## Benchmark Configuration

| Key | Value |
| --- | --- |
| `generated_at` | `2026-11-20T03:42:27Z` |
| `run_dir` | `/mnt/fast4tb/gomap-cow-bench-20261119.IwVeTHK8/collections-retained-zero-04` |
| `worktree` | `/mnt/fast4tb/gomap-cow-bench-20261119.IwVeTHK8/main` |
| `branch` | `codex/5541-cow-benchmark-coverage` |
| `commit` | `2c37febdd587` |
| `command_line` | `./scripts/bench_collections_canonical.sh -native-cow-companion -skip-offline-rewrite -skip-full-leafgen -skip-sqlite -out-dir /mnt/fast4tb/gomap-cow-bench-20261119.IwVeTHK8/collections-retained-zero-04 -docs 16000 -batch-size 1000 -indexes 0 -formats bson\,json -benchtime 16000x -count 3` |
| `docs` | `16000` |
| `batch_size` | `1000` |
| `indexes` | `0` |
| `tree_engine` | `command_wal_relaxed` |
| `profile` | `command_wal_relaxed` |
| `formats` | `bson,json` |
| `leaf_segment_target_bytes` | `1048576` |
| `leafgen_pack_force` | `true` |
| `leafgen_pack_max_generations` | `0` |
| `leafgen_pack_frame_k` | `16` |
| `index_vacuum` | `offline` |
| `profile_timed_matrix` | `false` |
| `profile_benchtime` | `16000x` |
| `profile_count` | `1` |

## Throughput Results

These rows are benchmark-timed post-insert measurements. Maintenance rows are excluded from throughput ranking.

| Config | Format | Indexes | Docs/sec | ns/doc | Batch size | Source |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| `treedb_json_collection_0_indexes` | json | 0 | 817884 | 1222.7 | 1000 | go_benchmark |
| `treedb_bson_collection_0_indexes` | bson | 0 | 748130 | 1336.7 | 1000 | go_benchmark |
| `treedb_native_cow_json_collection_0_indexes` | json | 0 | 559806 | 1786.3 | 1000 | go_benchmark |
| `treedb_native_cow_bson_collection_0_indexes` | bson | 0 | 517509 | 1932.3 | 1000 | go_benchmark |

## Matched owner samples

The timer covers `InsertBatch` publication and the legacy final flush when buffered. The checked checkpoint and primary-key census follow the timer. One benchmark operation is one document.

| Config | Owner | Sample | ns/doc | B/op | allocs/op | Checkpoint ns | COW insert publications |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `treedb_bson_collection_0_indexes` | `legacy_backend` | 1 | 1351.0 | 1966 | 1 | 35084349 | - |
| `treedb_bson_collection_0_indexes` | `legacy_backend` | 2 | 1308.0 | 1798 | 1 | 34620603 | - |
| `treedb_bson_collection_0_indexes` | `legacy_backend` | 3 | 1351.0 | 1798 | 1 | 33930626 | - |
| `treedb_json_collection_0_indexes` | `legacy_backend` | 1 | 1232.0 | 1927 | 1 | 34274571 | - |
| `treedb_json_collection_0_indexes` | `legacy_backend` | 2 | 1223.0 | 1760 | 1 | 34158241 | - |
| `treedb_json_collection_0_indexes` | `legacy_backend` | 3 | 1213.0 | 1767 | 1 | 34163283 | - |
| `treedb_native_cow_bson_collection_0_indexes` | `shared_native_cow_btree` | 1 | 2215.0 | 1712 | 7 | 118335675 | 16 |
| `treedb_native_cow_bson_collection_0_indexes` | `shared_native_cow_btree` | 2 | 1798.0 | 1711 | 7 | 106848930 | 16 |
| `treedb_native_cow_bson_collection_0_indexes` | `shared_native_cow_btree` | 3 | 1784.0 | 1711 | 7 | 105450602 | 16 |
| `treedb_native_cow_json_collection_0_indexes` | `shared_native_cow_btree` | 1 | 1724.0 | 1686 | 7 | 106236599 | 16 |
| `treedb_native_cow_json_collection_0_indexes` | `shared_native_cow_btree` | 2 | 1727.0 | 1686 | 7 | 104504462 | 16 |
| `treedb_native_cow_json_collection_0_indexes` | `shared_native_cow_btree` | 3 | 1908.0 | 1686 | 7 | 104969999 | 16 |

## Post-Insert Storage Comparison

These rows use the timed benchmark matrix post-insert basis. They are fair to compare with each other, but they are not compacted-state numbers.

| Config | Format | Indexes | Total bytes | B/doc | Docs/sec |
| --- | --- | ---: | ---: | ---: | ---: |
| `treedb_native_cow_json_collection_0_indexes` | json | 0 | 8,722,626 | 545.2 | 559806 |
| `treedb_native_cow_bson_collection_0_indexes` | bson | 0 | 8,744,146 | 546.5 | 517509 |
| `treedb_bson_collection_0_indexes` | bson | 0 | 12,891,893 | 805.7 | 748130 |
| `treedb_json_collection_0_indexes` | json | 0 | 12,892,064 | 805.8 | 817884 |

## Storage Results by Phase

| Config | Shape | Phase | Total bytes | B/doc | Measurement | Note |
| --- | --- | --- | ---: | ---: | --- | --- |
| `treedb_bson_collection_0_indexes` | collection | `post_insert` | 12,891,893 | 805.7 | go_benchmark | post-insert benchmark size; not compacted |
| `treedb_json_collection_0_indexes` | collection | `post_insert` | 12,892,064 | 805.8 | go_benchmark | post-insert benchmark size; not compacted |
| `treedb_native_cow_bson_collection_0_indexes` | collection | `post_insert` | 8,744,146 | 546.5 | go_benchmark | InsertBatch through native COW publication. Checked public checkpoint and primary-key census follow the timer. |
| `treedb_native_cow_json_collection_0_indexes` | collection | `post_insert` | 8,722,626 | 545.2 | go_benchmark | InsertBatch through native COW publication. Checked public checkpoint and primary-key census follow the timer. |

## Production Evidence

| Config | Phase | Producer route | Route used ops | Route fallbacks | GOMAXPROCS | Physical cores | Effective concurrency | Admitted | Span-native | Backlog coalescing | Storage policy |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | --- | --- | --- |
| `treedb_bson_collection_0_indexes` | `post_insert` | `command_wal_publish` | 2 | 0 | 12 | 6 | 6 | true | true | true | data_outer=true,index_outer=true |
| `treedb_json_collection_0_indexes` | `post_insert` | `command_wal_publish` | 2 | 0 | 12 | 6 | 6 | true | true | true | data_outer=true,index_outer=true |

## Guardrail Checks

| Severity | Code | Message |
| --- | --- | --- |
| info | `compaction.not_requested` | Timed-only companion run omits SQLite and canonical compaction comparisons |
| warning | `sqlite.skipped` | SQLite rows were intentionally skipped; fair compacted SQLite comparisons are omitted |

## Raw Results Appendix

Machine-readable JSON: `benchmark_results.json`

CSV matrix: `benchmark_matrix.csv`

| Config | Phase | Engine | Format | Indexes | Docs | Bytes | B/doc | Docs/sec | ns/doc |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `treedb_bson_collection_0_indexes` | `post_insert` | command_wal_relaxed | bson | 0 | 16000 | 12,891,893 | 805.7 | 748130 | 1336.7 |
| `treedb_json_collection_0_indexes` | `post_insert` | command_wal_relaxed | json | 0 | 16000 | 12,892,064 | 805.8 | 817884 | 1222.7 |
| `treedb_native_cow_bson_collection_0_indexes` | `post_insert` | command_wal_relaxed | bson | 0 | 16000 | 8,744,146 | 546.5 | 517509 | 1932.3 |
| `treedb_native_cow_json_collection_0_indexes` | `post_insert` | command_wal_relaxed | json | 0 | 16000 | 8,722,626 | 545.2 | 559806 | 1786.3 |

## Reproduction Commands

Canonical entry point:

```bash
./scripts/bench_collections_canonical.sh
# or
make bench-collections-canonical
```

Exact command records from this run:

### timed_matrix

TREEDB_COLLECTION_BENCH_NATIVE_COW_COMPANION=true go run ./cmd/collection_bench_matrix -out-dir /mnt/fast4tb/gomap-cow-bench-20261119.IwVeTHK8/collections-retained-zero-04/timed_matrix -formats bson,json -engine command_wal_relaxed -storage-cells index-vlog -tree-bench-pattern '^(BenchmarkCollectionShapeInsertBatch|BenchmarkCollectionShapeInsertBatchNativeCOW)$/^indexes_0$' -sqlite-bench-pattern '^(BenchmarkSQLiteShapeInsertBatchJSON|BenchmarkSQLiteShapeInsertBatchNativeColumns)$/^indexes_0$' -batch-size 1000 -benchtime 16000x -count 3 -leaf-segment-target-bytes 1048576 -leafgen-pack-frame-k 16 -skip-sqlite -report-vlog-rewrite=false -report-leafgen-pack-gc=false -report-post-maintenance-index-vacuum=false

