#!/usr/bin/env bash
set -eu
task_dir=$(dirname "$(realpath "$0")")
cd "$task_dir/main"
source "$task_dir/go-env.sh"
export PYTHONDONTWRITEBYTECODE=1
python3 scripts/readme_mongodb_bench/standalone_load.py \
  --bin-dir "$task_dir/bin" --out "$task_dir/$1" \
  --mongo-image-id sha256:690f1371c118a8389ecd6c82c9a7f0e37320732b1d56935a24b29dfca6933f54 \
  --lane-lock /tmp/gomap-ycsb-qualification.lock \
  --lane-lock /mnt/fast4tb/gomap-host185-perf-custody.lock \
  --lane-lock /mnt/fast4tb/gomap-clienttail-K4YyLITS/host185-comparison.lock \
  --count "$2" --threads 64 --pairs "$3" --ack "${4:-journaled}"
