#!/usr/bin/env python3
"""Read-only closeout after all timed cases have exited; retain a receipt."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/mnt/fast4tb/gomap-readme-server185-20261113')
EXPECTED_FREEZE = 'cf01a72ab5c317225006e49aa80c61ae1d45f3549ef51b3634668ec8bc9cd4f0'

def command(argv):
    return subprocess.check_output(argv, text=True)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

receipt = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), suites={})
for suite, expected in [('ycsb', 12), ('shape', 18), ('sweep', 18)]:
    done = json.loads((ROOT/'setup'/('retained-'+suite+'-exit.json')).read_text())
    cases = ROOT/'runs'/suite
    value = dict(attempts=len(list(cases.glob('*/attempt.json'))),
                 valid=len(list(cases.glob('*/result.json'))),
                 invalid=len(list(cases.glob('*/failure.json'))), exit=done)
    assert done['exit_code'] == 0 and value['attempts'] == value['valid'] == expected and value['invalid'] == 0
    receipt['suites'][suite] = value

spec = importlib.util.spec_from_file_location('frozen_recipe', ROOT/'recipe/run.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
runner.ROOT = ROOT
runner.BIN = ROOT/'bin'
runner.FREEZE_HASH = EXPECTED_FREEZE
runner.FREEZE = json.loads((ROOT/'freeze.json').read_text())
runner.verify_freeze()
receipt['frozen_source_recipe_and_binary_identity_verified'] = True
receipt['harness_tree'] = command(['git','-C',str(ROOT/'harness'),'rev-parse','HEAD:scripts/readme_mongodb_bench']).strip()
assert receipt['harness_tree'] == runner.FREEZE['harness']['tree']
assert command(['git','-C',str(ROOT/'harness'),'rev-parse','HEAD']).strip() == runner.FREEZE['harness']['commit']
assert not command(['git','-C',str(ROOT/'harness'),'status','--porcelain=v1','--untracked-files=all']).strip()

containers = [json.loads(line) for line in command(['docker','ps','-a','--no-trunc','--format','{{json .}}']).splitlines()]
all_cids = {c['ID'] for c in containers}
owned_cids = set()
for path in (ROOT/'runs').rglob('*-create.out'):
    value = path.read_text().strip()
    if len(value) == 64 and all(c in '0123456789abcdef' for c in value):
        owned_cids.add(value)
receipt['owned_container_count'] = len(owned_cids)
receipt['owned_containers_remaining'] = sorted(owned_cids & all_cids)
receipt['task_named_containers_remaining'] = [c['ID'] for c in containers if c['Names'].startswith('gomap-readme-5407-')]
assert not receipt['owned_containers_remaining'] and not receipt['task_named_containers_remaining']
receipt['owned_executables_remaining'] = []
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        executable = os.readlink(proc/'exe')
    except OSError:
        continue
    if executable.startswith(str(ROOT/'bin')+'/'):
        receipt['owned_executables_remaining'].append(dict(pid=int(proc.name), executable=executable))
assert not receipt['owned_executables_remaining']
receipt['db_paths_remaining'] = [str(p.relative_to(ROOT)) for p in (ROOT/'db').rglob('*')]
assert not receipt['db_paths_remaining']

receipt['protected_checkouts'] = {}
for name, repo in [('gomap', Path('/home/mikers/dev/snissn/gomap')), ('ycsb', Path('/home/mikers/dev/snissn/go-ycsb'))]:
    original = json.loads((ROOT/'preflight'/(name+'-protected-files.json')).read_text())
    changed = [p for p, expected in original.items() if not (repo/p).is_file() or sha(repo/p) != expected]
    status = command(['git','-C',str(repo),'status','--porcelain=v1','--untracked-files=all'])
    head = command(['git','-C',str(repo),'rev-parse','HEAD'])
    receipt['protected_checkouts'][name] = dict(original_files=len(original), changed_files=changed,
        status_unchanged=status == (ROOT/'preflight'/(name+'-protected-status.txt')).read_text(),
        head_unchanged=head == (ROOT/'preflight'/(name+'-head.txt')).read_text())
receipt['loadavg'] = Path('/proc/loadavg').read_text().strip()
receipt['meminfo'] = Path('/proc/meminfo').read_text()
receipt['filesystem'] = command(['df','-B1',str(ROOT)])
receipt['task_allocated_bytes'] = command(['du','-s','-B1',str(ROOT)]).split()[0]
path = ROOT/'setup/collection-end-verification.json'
with path.open('x') as handle:
    json.dump(receipt, handle, indent=2)
    handle.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k != 'meminfo'}, indent=2))
