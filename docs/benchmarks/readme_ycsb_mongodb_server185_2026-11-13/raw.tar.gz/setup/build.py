from pathlib import Path
import subprocess,os,json,datetime
root=Path('/mnt/fast4tb/gomap-readme-server185-20261113')
env=os.environ.copy();env.pop('GOROOT',None);env.update(GOTOOLCHAIN='go1.26.10',GOWORK='off',CGO_ENABLED='1')
for job in json.loads((root/'setup/build-plan.json').read_text()):
    name=job['name']; print('BUILD '+name,flush=True)
    with (root/'setup'/(name+'.build.log')).open('x') as log:
        p=subprocess.run(job['argv'],cwd=job['cwd'],env=env,stdout=log,stderr=subprocess.STDOUT)
    (root/'setup'/(name+'.build.json')).write_text(json.dumps(dict(job,exit_code=p.returncode,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
    if p.returncode: raise SystemExit(p.returncode)
print('BUILDS_COMPLETE',flush=True)
