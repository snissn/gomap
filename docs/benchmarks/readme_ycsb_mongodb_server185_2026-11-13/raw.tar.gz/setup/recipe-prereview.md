# Independent pre-review: server185 README comparison harness

**Functional decision: ACCEPT the exact candidate identified below for the documented Linux server185 campaign. No remaining concrete functional blocker was found.** This supersedes the initial rejection of the unadapted PR #5408 archive recipe. This is a source/contract review verdict, not permission to collect retained evidence yet, not a benchmark result, and not a merge approval from the owner.

The candidate is committed at `b2d6cf787f9e0dd49fb6c668085f39c6595b5fc4` in a verified clean checkout at `/Users/michaelseiler/dev/snissn/gomap-readme-server185-20261113/scripts/readme_mongodb_bench`. Review used read-only access to that candidate, the original recovered archive recipe, and landed product source `4988738a2689b462cdb2053fa1e563f8c0091e23`, which includes PR #5410. This reviewer changed only this review document, ran bounded offline controls with Python bytecode writing disabled, and performed no SSH, service, GitHub, benchmark or repository mutation.

## Exact reviewed candidate

| File | SHA-256 |
|---|---|
| `README.md` | `811582243f982f858608d40ab92df63e9a96da2868c8c9f73d43e6b840407b6a` |
| `aggregate.py` | `37d30912233e937d558ab128d7237f7ed52e139dd675b2b51f0ab6c68bf03545` |
| `archive.py` | `284ff0a178005bdf45315b9d274a81d57da3eda43d1251ab32f81f2650102fc7` |
| `census.go` | `ab5b80005fc2ce1e681682756a9d0df8f723d29c33a090137f92f9f26756c483` |
| `freeze.py` | `99e77befc64c81c670ff8a8e82f3bacaeab65be4c1751ea38954a2bf854ab917` |
| `run.py` | `2271e50af381d847a52fe7d8b3e44497808870241cda3693a4d63ae9e80965f7` |
| `test_recipe.py` | `a29fb2d519964647532f55a2776df322a181d5c02143d38ea8650ee900b65a39` |
| `verify_archive.py` | `40cc7e98e20be5c0af879646c0840896ad3e670ca8a1812eb50dbf71e63488dd` |
| `ycsb_log.py` | `dfd767c7f8f59a531b920befad9b600cd49d640cd3434fba9895be0611442a7c` |

Any subsequent acceptance-harness changes require a focused review of the changed risk and a new freeze before affected collection. The verdict is bound to these bytes; committing them without changing bytes does not invalidate the source review.

## Review and verification

Compared the candidate with the recovered recipe and reviewed the changed code plus its surrounding lifecycle, census, source/binary freeze and aggregation paths. Independently ran:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest -v test_recipe.py
Ran 6 tests in 0.003s — OK
```

The six groups cover real retained YCSB progress/final output and rejection controls, Linux/macOS path identity, strict JSON, Close identity/error checks, changed frozen manifest/recipe rejection before any launch, and mismatched Mongo container-user rejection. Independently compared Python ASTs for `parse_log` and `check_counts` in the candidate's `ycsb_log.py` against `scripts/ycsb_compare_validate.py` at the product commit: both are exactly identical. No expensive product test suite or live workload was run by this reviewer. Census self-test and Linux smoke remain precollection operational checks for the final frozen build, rather than claims made by this offline review.

### Provenance

The revised freeze records clean product and external client commits/root trees/subtrees, the clean separately pinned harness commit/tree, copied recipe Git-blob equality with that harness, all seven execution/acceptance recipe SHA-256s, executable hashes and Go build information, immutable Mongo image identity/platform, and actual host/filesystem/Docker metadata. Run-level verification checks the frozen manifest, all recorded recipe bytes, all six required binaries and the product/client source identities before each case. Aggregation requires an externally recorded expected freeze digest, verifies the frozen recipe identities and case provenance, and checks raw command/output identities and exact inventories.

This fixes the original recipe's old manifest constant, incomplete acceptance-source freeze and Linux-incompatible host capture. The strict YCSB parser now runs before a sample can be accepted, including smoke, and aggregation validates the full original output before selecting final rows. The parser extraction avoids importing the unrelated heavyweight Linux runtime-attestation machinery.

This harness intentionally does not independently prove that its commit has landed; that is the coordinator's live GitHub/Git gate. The exact requested product commit, external client commit `3c8148495b8d4490cf0ec30e9eb92d14a7a71bac`, Linux/amd64 binaries, Go 1.26.10/CGO configuration and Mongo image `sha256:690f1371c118a8389ecd6c82c9a7f0e37320732b1d56935a24b29dfca6933f54` must be checked against the completed freeze before collection. Recording metadata does not itself validate that the selected inputs satisfy those task choices.

### Concurrency and isolation

An exclusive nonblocking `flock` acquired in `main()` covers each suite invocation for the task root, preventing overlap among the documented suite processes. Each suite remains sequential internally. Cases retain fresh owned DB directories, unique labeled containers, ephemeral loopback ports and checked lifecycle/cleanup receipts. The existing owner/root checks and failure retention are preserved. No automatic sample retry is introduced.

The campaign still has 48 retained slots in the archived order: 12 YCSB, 18 client-shape and 18 index/concurrency sweep. It preserves producer concurrency, count, phase timing and workload flags; smoke is separate. A failure stops the suite. Any continuation implementation must receive its own review and execute only slots never started; this ACCEPT does not preapprove a future continuation script.

The shared 12 logical CPU/32 GiB host is explicitly a fallback, with `INFRASTRUCTURE_UNAVAILABLE: runner: shared user-selected server185; unrelated services remain active`. Existing unrelated services must remain untouched. Coordinator ownership must also prevent out-of-band campaigns or build/test work from competing with the timing interval: the task lock only controls processes that honor that same lock. Baseline/during-run load observations and real cache/storage availability belong in the campaign records and final interpretation; this is not a dedicated quiet-runner claim.

### Linux container-user follow-up

Accepted the added Linux-only `docker run --user <actual-host-uid>:<actual-host-gid>` adaptation at this exact committed candidate. It keeps newly created bind-mount files writable by the host owner for untimed allocation inspection and release, avoiding dependence on root entrypoint ownership changes. It leaves workload flags, the immutable image and timed producer clocks unchanged. It is an execution-environment difference from default-user MongoDB containers and must be explicit in the report.

The freeze now records `host.mongo_container_user`; aggregation requires exact `Config.User` equality in both lifecycle inspection records and the exact Docker-create argv, including the inspected unique name, UID/GID, loopback port policy, owned bind path and immutable image ID. The sixth offline control rejects mismatched empty/default, root and other user identities. The task-scoped Docker cleanup continues to require name/image/label/mount/CID identity before removing a container.

Whether the frozen image successfully runs its entrypoint and MongoDB under this numeric user remains an actual-image smoke check. A tiny nonretained 16-case smoke before landing is diagnostic harness validation and is permitted; it must not be relabeled as retained performance acceptance evidence or substitute for the final frozen campaign smoke. The 48-case retained collection stays behind the landing gate. If diagnostic smoke finds a defect, repair/review/freeze before retaining measurements.

### Fail-closed acceptance and evidence wording

The final parser rejects malformed, truncated, duplicate, incomplete, nonfinite or error-bearing YCSB measurement records and validates actual final operation counts. Original YCSB command and Close receipts remain mandatory. Full census validates observed key/typed-shape inventory, canonical digest and selected queries; index-command unavailability remains explicit and is not promoted to index proof. Graceful lifecycle and independent reopen checks remain required. Exact phase/count/configuration and fixed-slot checks remain in aggregation; incomplete three-repeat groups cannot provide comparison summaries.

Linux recorded paths are now preserved instead of mapping `/tmp` to macOS `/private/tmp`. Allocation remains stopped `st_blocks * 512` across the complete owned DB directory, including persistent value logs and redo/command journals, with Linux-accurate basis text. Generic census and platform-correct gateway labels replace Mac-only labels. Historical Mac rendering is excluded; the new README/report must be written from the actual freeze and ledger.

The README accurately bounds claims: full observed census is not proof of every acknowledged update, physical index activation, crash or power-loss durability. The macrobenchmark's original deferred Close return remains explicitly unobserved; a later reopen cannot recover it. The two YCSB durability-request labels are different requests, not proven equivalent durability. Tail summaries remain summaries of per-run statistics, not pooled request percentiles. These limitations preserve the archived method without inventing stronger authority.

## Landing policy and minimal path

`github-pr-mergeable/references/retained-evidence-velocity.md:5-7` requires the harness/schema to be reviewed **and landed before expensive collection**, then frozen to exact commits and subtree/blob identities. The executor skill adopts this policy. This candidate satisfies focused functional pre-review; the landing gate is still pending. An uncommitted or unmerged accepted candidate does not satisfy it.

The already-landed timed producers can be used unchanged. However, no exact archive recipe blob exists anywhere in the product tree, and the existing maintained alternatives are not equivalent to this full campaign: the ordinary YCSB runner refuses MongoDB execution; the gateway matrix shell has different force-removal/storage and census lifecycle behavior. The narrow harness-only precursor is therefore justified. No new daemon, generalized supervisor, benchmark product change or service infrastructure is required.

Next: commit/publish these exact reviewed harness bytes, complete applicable review/CI, obtain the owner's narrowly scoped authorization for that precursor's landing, verify its actual landed tree, freeze the requested product separately from the harness, run the final native census self-test and tiny Linux smoke, then collect once. Preserve PR #5408 and leave the final alternative README PR unmerged. The request to rerun does not itself override the explicit landing policy or grant a new precursor merge authority.

Final disposition: **ACCEPT functional harness candidate at the hashes above; retained collection remains gated on authorized landing, exact freeze and final Linux smoke.**
