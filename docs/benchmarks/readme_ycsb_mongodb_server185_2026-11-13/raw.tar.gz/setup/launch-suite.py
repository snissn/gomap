#!/usr/bin/env python3
"""Capture a single frozen recipe invocation's terminal exit; never retry."""
import datetime,json,os,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent.parent
suite=sys.argv[1]
assert suite in ('ycsb','shape','sweep')
receipt=root/'setup'/('retained-'+suite+'-exit.json')
assert not receipt.exists()
argv=[sys.executable,str(root/'recipe/run.py'),'--root',str(root),'--repo',str(root/'source'),'--suite',suite]
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
record={'suite':suite,'argv':argv,'started_utc':now(),'wrapper_pid':os.getpid()}
with (root/'setup'/('retained-'+suite+'-start.json')).open('x') as f:
 json.dump(record,f,indent=2);f.write('\n')
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
code=subprocess.call(argv,cwd=root/'source',env=env)
record.update(ended_utc=now(),exit_code=code)
with receipt.open('x') as f:
 json.dump(record,f,indent=2);f.write('\n')
sys.exit(code)
