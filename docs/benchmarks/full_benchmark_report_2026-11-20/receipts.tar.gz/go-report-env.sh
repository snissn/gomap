export GOWORK=off CGO_ENABLED=1 GOENV=off GOTOOLCHAIN=local
unset GOCACHEPROG GOMAXPROCS GOMEMLIMIT GOGC GOFLAGS GOEXPERIMENT
export GOROOT=/home/mikers/.gvm/gos/go1.26.3
export PATH="$GOROOT/bin:$PATH"
export GOCACHE="$lane/gocache" GOMODCACHE=/home/mikers/go/pkg/mod
export TMPDIR="$lane/tmp" GOTMPDIR="$lane/tmp"
