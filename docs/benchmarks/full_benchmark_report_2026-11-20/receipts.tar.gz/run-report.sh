#!/usr/bin/env bash
set -euo pipefail
lane=$(dirname "$(realpath "$0")")
source "$lane/go-report-env.sh"
cd "$lane/report-src"
export RUN_ROOT="$lane/report"
export MONGO_IMAGE=mongo@sha256:7abfba0d07c9330373f8173981ea4d09cd8a82cdf0e86ccaf7008848d1d24f62
exec 7>>/mnt/fast4tb/gomap-clienttail-K4YyLITS/host185-comparison.lock
exec 8>>/mnt/fast4tb/gomap-host185-perf-custody.lock
exec 9>>/tmp/gomap-ycsb-qualification.lock
flock -w 60 7
flock -w 10 8
flock -w 10 9
test "$(git rev-parse HEAD)" = "$(cat "$lane/evidence/base")"
test -z "$(git status --porcelain --untracked-files=no)"
test "$(go version | cut -d ' ' -f 3)" = go1.26.3
test "$(go tool compile -V | cut -d ' ' -f 3)" = go1.26.3
test "$(go env GOROOT)" = "$GOROOT"
test "$(docker image inspect "$MONGO_IMAGE" --format '{{.Id}}')" = sha256:690f1371c118a8389ecd6c82c9a7f0e37320732b1d56935a24b29dfca6933f54
{
    date -u +start_utc=%FT%T.%NZ
    git show -s --format='%H %T %P'
    go version
    go tool compile -V
    go env GOROOT GOTOOLDIR GOWORK GOENV GOAMD64 CGO_ENABLED
    hostname
    uname -a
    lscpu | awk '/^CPU\(s\)|^Model name|^Thread\(s\)/'
    docker version --format '{{.Server.Version}}'
    docker image inspect "$MONGO_IMAGE" --format '{{.Id}} {{json .RepoDigests}}'
    findmnt -T "$lane" -o TARGET,SOURCE,FSTYPE,OPTIONS
    df -h "$lane"
    free -h
    uptime
    stat -Lc '%n %d:%i' /proc/$$/fd/{7,8,9}
    env | sort | rg '^(CGO_ENABLED|GO[A-Z]+|TMPDIR|RUN_ROOT|MONGO_IMAGE)='
    printf 'argv=make deep-benchmark\n'
} > "$lane/evidence/report-host.txt"
(
    while true; do
        date -u +%FT%T.%NZ
        uptime
        df -B 1 --output=avail "$lane" | tail -1
        ps -eo pid,%cpu,comm --sort=-%cpu | head -14 || :
        sleep 6
    done
) > "$lane/evidence/report-host-samples.txt" &
sampler=$!
trap 'kill "$sampler" 2>/dev/null || true; wait "$sampler" 2>/dev/null || true' EXIT
result=0
make deep-benchmark > "$lane/evidence/make-deep-benchmark.log" 2>&1 || result=$?
printf '%s\n' "$result" > "$lane/evidence/deep.exit"
date -u +end_utc=%FT%T.%NZ > "$lane/evidence/deep.end"
# Collect all companion cells independently of the report's terminal status.
bash "$lane/run-cow.sh"
