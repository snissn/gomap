from collections import defaultdict
from html.parser import HTMLParser
from pathlib import Path
from statistics import median
import json
import re
import sys

root = Path(sys.argv[1])
deep = root / "report"
cow = root / "cow"


class ReportHTML(HTMLParser):
    def __init__(self, raw):
        super().__init__()
        self.ids = set()
        self.references = set()
        self.external_assets = []
        self.feed(raw)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.add(attrs["id"])
        if tag == "a" and attrs.get("href", "").startswith("#"):
            self.references.add(attrs["href"][1:])
        if tag in ("img", "script", "link", "iframe"):
            asset = attrs.get("src", attrs.get("href"))
            if asset and not asset.startswith("data:"):
                self.external_assets.append(asset)


commands = []
command = None
for row in (deep / "commands.log").read_text().splitlines():
    if row.startswith("command:"):
        assert command is None, "missing command status"
        command = row.removeprefix("command:").strip()
    if status := re.fullmatch(r"exit_status: (\d+) duration_sec: (\d+)", row):
        assert command is not None
        code, seconds = map(int, status.groups())
        commands.append(dict(argv=command, code=code, elapsed_s=seconds))
        command = None
assert command is None and len(commands) == 20, "default PR-tier stage inventory differs"
assert "benchmark_run_report" in commands[-1]["argv"] and commands[-1]["code"] == 0
html = (deep / "deep_report.html").read_text()
parsed = ReportHTML(html)
assert {"run-status", "collections", "raw-engine", "scaling", "profiles"} <= parsed.ids
assert not (parsed.references - parsed.ids) and not parsed.external_assets
# The renderer is itself the last command. It sees the preceding 19 terminal
# statuses. The final published renderer pass below will see all 20.

benchmark = re.compile(r"^BenchmarkCollectionShapeInsertBatch(NativeCOW)?/indexes_([02])-\d+[ \t]*", re.M)
metrics_line = re.compile(r"^[ \t]*(16000[ \t]+[^\n]+\bns/op[^\n]*)$", re.M)
rows = []
for path in sorted(cow.glob("*.exit")):
    fmt, index, order, arm = path.stem.split("-")
    raw = path.with_suffix(".log").read_text()
    assert path.read_text().strip() == "0", path
    names = list(benchmark.finditer(raw))
    assert len(names) == 1 and names[0].group(2) == index, path
    assert bool(names[0].group(1)) == (arm == "native"), path
    # Diagnostic logs can interrupt testing.B's prefix before the metrics line.
    matches = metrics_line.findall(raw[names[0].end():])
    assert len(matches) == 1 and "PASS" in raw, path
    parts = matches[0].split()
    metrics = {key: float(value) for value, key in zip(parts[1::2], parts[2::2], strict=True)}
    assert metrics["indexes/doc"] == int(index) and metrics["target_docs/batch"] == 1000, path
    for name in ["stored_docs", "verified_shape_docs"]:
        assert metrics[name] == 16000, (path, name)
    assert metrics["checkpoint_ns/op"] > 0 and metrics["disk_total_bytes"] > 0, path
    if arm == "native":
        for name, want in {
            "native_cow_owner": 1, "native_acknowledged_docs": 16000, "native_insert_batches": 16,
            "cow_insert_publication_delta": 16, "native_checkpoint_calls": 1,
            "native_checkpoint_errors": 0, "native_checkpoint_calls_during_insert": 0,
        }.items():
            assert metrics[name] == want, (path, name)
        assert metrics["cow_publications_after_insert"] - metrics["cow_publications_before_insert"] == 16, path
        assert metrics["native_accepted_lsn_before_insert"] < metrics["native_accepted_lsn_after_insert"] <= metrics["native_checkpoint_applied_lsn"], path
    else:
        assert metrics["legacy_backend_owner"] == 1, path
        for count in ("candidate_ops", "used_ops"):
            assert metrics["ordered_root_route_command_wal_publish_" + count] > 0, path
    rows.append(dict(format=fmt, indexes=int(index), order=int(order), arm=arm,
                     ns_doc=metrics["ns/op"], bytes_doc=metrics["B/op"],
                     allocs_doc=metrics["allocs/op"], checkpoint_ms=metrics["checkpoint_ns/op"] / 1e6))

groups = defaultdict(list)
for row in rows:
    groups[row["format"], row["indexes"], row["arm"]].append(row)
expected = {(fmt, index, arm) for fmt, index in [("bson", 0), ("json", 0), ("bson", 2)] for arm in ["legacy", "native"]}
assert groups.keys() == expected and all(len(samples) == 3 for samples in groups.values())
assert len(rows) == 18
summary = []
for key, entries in groups.items():
    summary.append(dict(format=key[0], indexes=key[1], arm=key[2],
                        **{metric: median(row[metric] for row in entries)
                           for metric in ["ns_doc", "bytes_doc", "allocs_doc", "checkpoint_ms"]}))
print(json.dumps(dict(commands=commands, cow_samples=rows, cow_medians=summary), indent=2))
