#!/usr/bin/env bash
set -euo pipefail
lane=$(dirname "$(realpath "$0")")
exec 7>>/mnt/fast4tb/gomap-clienttail-K4YyLITS/host185-comparison.lock
exec 8>>/mnt/fast4tb/gomap-host185-perf-custody.lock
exec 9>>/tmp/gomap-ycsb-qualification.lock
flock -w 60 7
flock -w 20 8
flock -w 20 9
date -u +acquired_utc=%FT%T.%NZ
stat -Lc '%n %d:%i' /proc/$$/fd/{7,8,9}
trap 'date -u +release_utc=%FT%T.%NZ' EXIT
case "${1:?build, normal, race, baseline-control or render}" in
    build) bash "$lane/build-journal.sh";;
    normal|race) bash "$lane/test-fence.sh" "$1";;
    baseline-control)
        source "$lane/go-journal-env.sh"
        cd "$lane/report-src"
        test "$(git rev-parse HEAD)" = "$(cat "$lane/evidence/base")"
        GOMAXPROCS=6 go test -p=3 -v -timeout 90s -count=1 \
            -run '^TestStandaloneRelaxedExt4StreamJournalAckCrashReopen$' ./TreeDB/mongo_gateway
        ;;
    render)
        source "$lane/go-report-env.sh"
        cd "$lane/report-src"
        GOMAXPROCS=4 go run -p=2 ./cmd/benchmark_run_report \
            -run-root "$lane/report" -out "$lane/evidence/deep-final.html" -title 'TreeDB Benchmark Run Report'
        ;;
    *) exit 2 ;;
esac
