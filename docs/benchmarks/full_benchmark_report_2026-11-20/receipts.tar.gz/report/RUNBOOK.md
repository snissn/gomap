# Full TreeDB Benchmark Report Run

- generated_at: 2026-11-20T18:06:25Z
- worktree: /mnt/fast4tb/gomap-deep-journal.EElzpZMM/report-src
- run_root: /mnt/fast4tb/gomap-deep-journal.EElzpZMM/report
- tier: pr
- indexes: 0 1 2
- raw_keys: 200000
- collection_docs: 100000
- collection_profiles: true
- collection_profile_benchtime: 100000x
- collection_profile_count: 1
- mongo_docs: 100000
- mongo_load_scaling_docs: 100000
- mongo_load_scaling_batch_size: 1000
- mongo_load_producers: 1 2 4 8 16 32
- mongo_mode: docker
- mongo_image: mongo@sha256:7abfba0d07c9330373f8173981ea4d09cd8a82cdf0e86ccaf7008848d1d24f62
- mongo_compact: true
- mongo_uri: mongodb://127.0.0.1:27017
- timeout: 120m
- mongo_readers: 1 2 4 8 16 32
- mongo_writers: 1 2 4 8 16 32
- mongo_max_pool_size: 128
- mongo_max_connecting: 32
- skip_raw: false
- skip_collections: false
- skip_mongo: false
- skip_load_modes: false
- skip_load_scaling: false
- skip_scaling: false
- go: go version go1.26.3 linux/amd64
- uname: Linux mikers-B560-DS3H-AC-Y1 6.8.0-138-generic #138~22.04.1-Ubuntu SMP PREEMPT_DYNAMIC Fri Aug  7 13:43:15 UTC  x86_64 x86_64 x86_64 GNU/Linux

## Exact Invocation

```sh
scripts/treedb_benchmark_run_report.sh
```

## One Command

```sh
scripts/treedb_benchmark_run_report.sh --out /mnt/fast4tb/gomap-deep-journal.EElzpZMM/report --tier pr --indexes 0\ 1\ 2 --mongo-mode docker --mongo-image mongo@sha256:7abfba0d07c9330373f8173981ea4d09cd8a82cdf0e86ccaf7008848d1d24f62 --mongo-compact true --mongo-uri mongodb://127.0.0.1:27017
```
