# Mongo Gateway Comparison Bundle

- output directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded`
- report: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/report.md`
- summary TSV: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/summary.tsv`
- matrix TSV: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/matrix.tsv`
- raw JSON directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/raw`
- TreeDB data directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/treedb_data`
- MongoDB data directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/mongodb_data`
- docs list: `100000`
- secondary-index list: `0 1 2`
- batch size: `10000`
- insert producers: `8`
- MongoDB Go driver pool options: `maxPoolSize=128 minPoolSize=0 maxConnecting=32`
- prebuild documents: `true`
- range index: `true`
- TreeDB pprof profiles: `true`
- profile directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/profiles`
- reads: `50000`
- range reads: `5000`
- updates: `5000`
- deletes: `0`
- concurrent read kinds: `id,email,range`
- concurrent readers: `0`
- concurrent reader sweep: `1,2,4,8,16,32`
- concurrent reads: `80000`
- concurrent range readers: `0`
- concurrent range reader sweep: `none`
- concurrent range reads: `documents / 10 when range readers or range reader sweep is set`
- concurrent writers: `0`
- concurrent writer sweep: `1,2,4,8,16,32`
- concurrent writes: `80000`
- MongoDB mode: `docker`
- MongoDB compact before final stats: `true`
- MongoDB image: `mongo@sha256:7abfba0d07c9330373f8173981ea4d09cd8a82cdf0e86ccaf7008848d1d24f62`
- MongoDB client modes: `driver-command-raw`
- benchmark timeout: `120m`
- TreeDB profile: `bench_unsafe`
- TreeDB document formats: `bson`
- TreeDB client modes: `driver-command-raw`
- TreeDB root storage: `data=compressed index_state=compressed index=compressed`
- TreeDB maintenance: `full`
- TreeDB read state: `settled`

Regenerate from the raw run index:

```sh
GOWORK=off go run ./cmd/mongo_gateway_compare_report \
  -matrix "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/matrix.tsv" \
  -report "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/report.md" \
  -summary "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/summary.tsv" \
  -title "Mongo API Full Sweep"
```
