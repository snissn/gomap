# Mongo API Full Sweep

- generated_at: `2026-11-20T18:20:20Z`
- matrix: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/matrix.tsv`
- comparison cells: `3`
- targets: `treedb`, `mongo`

## Highlights

- Largest TreeDB ops/sec lead: `concurrent_id_find_one_r16` at 100000 docs / 1 indexes / `treedb_bson_driver_command_raw_range_index`, 115603 ops/sec vs 34993 ops/sec (3.30x TreeDB / MongoDB).
- No phase in this matrix had MongoDB ahead on ops/sec.
- Largest cell disk: at 100000 docs / 2 indexes / `treedb_bson_driver_command_raw_range_index`, TreeDB maintenance snapshot used 72.71 MiB (762.4 B/doc), TreeDB physical du was 72.81 MiB, MongoDB dbStats dataSize was 31.96 MiB, MongoDB dbStats totalSize was 17.10 MiB, and MongoDB physical du was 217.56 MiB (2281.3 B/doc).

## Disk Summary

| docs | indexes | range index | TreeDB config | MongoDB baseline config | TreeDB snapshot | TreeDB bytes | TreeDB bytes/doc | TreeDB physical du | TreeDB physical bytes/doc | MongoDB dbStats dataSize | MongoDB dbStats totalSize | MongoDB physical du | MongoDB physical bytes/doc | TreeDB / MongoDB dbStats totalSize | TreeDB / MongoDB physical |
| ---: | ---: | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 0 | true | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | maintenance | 71.72 MiB | 752.0 B | 71.81 MiB | 753.0 B | 31.96 MiB | 12.93 MiB | 213.34 MiB | 2237.0 B | 5.55x | 0.34x |
| 100000 | 1 | true | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | maintenance | 72.44 MiB | 759.6 B | 72.54 MiB | 760.6 B | 31.96 MiB | 16.47 MiB | 216.89 MiB | 2274.2 B | 4.40x | 0.33x |
| 100000 | 2 | true | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | maintenance | 72.71 MiB | 762.4 B | 72.81 MiB | 763.5 B | 31.96 MiB | 17.10 MiB | 217.56 MiB | 2281.3 B | 4.25x | 0.33x |

## Mongo Matrix Rows

These rows list every MongoDB matrix row, including non-baseline client-mode rows that are not used as the TreeDB comparison baseline.

| docs | indexes | range index | config | phase | ops/sec | sampled ops/sec | p95 us | dbStats totalSize | physical du | raw json |
| ---: | ---: | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 100000 | 0 | true | `mongo_driver_command_raw_range_index` | `load_insert_many` | 458721 | 69741 | 169506 | 12.93 MiB | 213.34 MiB | `raw/mongo_driver_command_raw_range_index_docs_100000_idx_0.json` |
| 100000 | 1 | true | `mongo_driver_command_raw_range_index` | `load_insert_many` | 257044 | 38965 | 319304 | 16.47 MiB | 216.89 MiB | `raw/mongo_driver_command_raw_range_index_docs_100000_idx_1.json` |
| 100000 | 2 | true | `mongo_driver_command_raw_range_index` | `load_insert_many` | 195423 | 31108 | 374593 | 17.10 MiB | 217.56 MiB | `raw/mongo_driver_command_raw_range_index_docs_100000_idx_2.json` |


## Concurrent Read Sweep

These rows group `concurrent_*_rN` phases as read throughput sweeps. Serial read phases remain separate single-in-flight latency phases.

| docs | indexes | TreeDB config | MongoDB baseline config | phase | readers | TreeDB wall ops/sec | TreeDB sampled ops/sec | MongoDB wall ops/sec | MongoDB sampled ops/sec | TreeDB / MongoDB wall | TreeDB p95 us | MongoDB p95 us |
| ---: | ---: | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r1` | 1 | 14407 | 14660 | 8721 | 8813 | 1.65x | 84.0 | 136 |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r2` | 2 | 28194 | 14347 | 15496 | 7827 | 1.82x | 88.0 | 169 |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r4` | 4 | 50645 | 12882 | 24309 | 6137 | 2.08x | 97.0 | 243 |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r8` | 8 | 88961 | 11303 | 32125 | 4055 | 2.77x | 122 | 387 |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r16` | 16 | 109830 | 6960 | 36104 | 2273 | 3.04x | 229 | 757 |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r32` | 32 | 120867 | 3806 | 39623 | 1246 | 3.05x | 514 | 1548 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r1` | 1 | 13158 | 13342 | 7795 | 7865 | 1.69x | 90.0 | 157 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r2` | 2 | 23786 | 12060 | 14175 | 7149 | 1.68x | 107 | 178 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r4` | 4 | 39940 | 10110 | 22777 | 5741 | 1.75x | 141 | 246 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r8` | 8 | 51920 | 6543 | 28954 | 3649 | 1.79x | 310 | 428 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r16` | 16 | 52404 | 3289 | 32873 | 2067 | 1.59x | 850 | 823 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r32` | 32 | 51143 | 1602 | 35714 | 1122 | 1.43x | 1380 | 1677 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r1` | 1 | 14916 | 15179 | 8806 | 8901 | 1.69x | 79.0 | 133 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r2` | 2 | 28206 | 14352 | 15637 | 7900 | 1.80x | 88.0 | 162 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r4` | 4 | 50743 | 12905 | 24154 | 6099 | 2.10x | 97.0 | 243 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r8` | 8 | 85177 | 10822 | 31783 | 4012 | 2.68x | 128 | 393 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r16` | 16 | 115603 | 7312 | 34993 | 2205 | 3.30x | 215 | 797 |
| 100000 | 1 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r32` | 32 | 118520 | 3730 | 36278 | 1142 | 3.27x | 519 | 1746 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r1` | 1 | 13131 | 13316 | 8040 | 8112 | 1.63x | 91.0 | 146 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r2` | 2 | 23412 | 11867 | 14119 | 7122 | 1.66x | 110 | 180 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r4` | 4 | 40837 | 10338 | 22775 | 5742 | 1.79x | 136 | 247 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r8` | 8 | 51078 | 6438 | 29810 | 3757 | 1.71x | 315 | 404 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r16` | 16 | 50799 | 3191 | 32316 | 2034 | 1.57x | 871 | 843 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_email_find_one_r32` | 32 | 51551 | 1615 | 35418 | 1112 | 1.46x | 1388 | 1691 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r1` | 1 | 14789 | 15045 | 8794 | 8890 | 1.68x | 80.0 | 134 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r2` | 2 | 27683 | 14080 | 15776 | 7971 | 1.75x | 91.0 | 157 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r4` | 4 | 50038 | 12723 | 24889 | 6285 | 2.01x | 100 | 232 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r8` | 8 | 90922 | 11551 | 31304 | 3952 | 2.90x | 119 | 402 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r16` | 16 | 119306 | 7549 | 36528 | 2300 | 3.27x | 207 | 738 |
| 100000 | 2 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_find_one_r32` | 32 | 122916 | 3866 | 39746 | 1249 | 3.09x | 497 | 1527 |

## Concurrent Range Read Sweep

These rows group `concurrent_age_range_*_rN` phases as one age range-read throughput sweep. Serial `age_range_*_limit_10` remains a separate single-in-flight latency phase.

| docs | indexes | range mode | TreeDB config | MongoDB baseline config | readers | TreeDB wall ops/sec | TreeDB sampled ops/sec | MongoDB wall ops/sec | MongoDB sampled ops/sec | TreeDB / MongoDB wall | TreeDB p95 us | MongoDB p95 us |
| ---: | ---: | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 0 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 1 | 14913 | 15586 | 6546 | 6792 | 2.28x | 77.0 | 175 |
| 100000 | 0 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 2 | 27320 | 14263 | 11560 | 5986 | 2.36x | 93.0 | 209 |
| 100000 | 0 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 4 | 35337 | 9090 | 18744 | 4853 | 1.89x | 188 | 274 |
| 100000 | 0 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 8 | 35651 | 4521 | 24700 | 3191 | 1.44x | 623 | 446 |
| 100000 | 0 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 16 | 36339 | 2288 | 25767 | 1648 | 1.41x | 1241 | 997 |
| 100000 | 0 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 32 | 40560 | 1273 | 26016 | 825 | 1.56x | 1764 | 2195 |
| 100000 | 1 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 1 | 14616 | 15266 | 6701 | 6863 | 2.18x | 79.0 | 170 |
| 100000 | 1 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 2 | 27387 | 14292 | 11911 | 6097 | 2.30x | 92.0 | 207 |
| 100000 | 1 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 4 | 34438 | 8855 | 19331 | 4959 | 1.78x | 195 | 262 |
| 100000 | 1 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 8 | 34312 | 4351 | 24537 | 3152 | 1.40x | 659 | 457 |
| 100000 | 1 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 16 | 34868 | 2195 | 25930 | 1652 | 1.34x | 1346 | 981 |
| 100000 | 1 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 32 | 40171 | 1261 | 26410 | 835 | 1.52x | 1789 | 2181 |
| 100000 | 2 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 1 | 14293 | 14918 | 6869 | 7041 | 2.08x | 81.0 | 165 |
| 100000 | 2 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 2 | 26368 | 13752 | 11961 | 6124 | 2.20x | 96.0 | 208 |
| 100000 | 2 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 4 | 36250 | 9323 | 19379 | 4965 | 1.87x | 183 | 261 |
| 100000 | 2 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 8 | 36056 | 4572 | 24787 | 3182 | 1.45x | 623 | 446 |
| 100000 | 2 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 16 | 36509 | 2299 | 24948 | 1592 | 1.46x | 1235 | 1055 |
| 100000 | 2 | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 32 | 39706 | 1247 | 25674 | 813 | 1.55x | 1814 | 2245 |

## 0-Index Writer Sweep Counters

These rows preserve TreeDB per-phase counter deltas for `concurrent_id_update_set_wN` phases. Values come from `phase.treedb_metrics` when present, so load counters and writer counters remain separate.

| docs | indexes | TreeDB config | MongoDB baseline config | writers | TreeDB ops/s | MongoDB ops/s | TreeDB p95 us | MongoDB p95 us | TreeDB driver calls | MongoDB driver calls | publish calls/doc | root apply calls/doc | roots/publish | root apply ns/doc | leaf-log loads/doc | leaf-log pages written/doc | leaf-log read bytes/doc | leaf-log write bytes/doc | indexed flush calls/doc | indexed flush units/batch | indexed flush docs/batch | indexed flush root-runs/doc | root-delta entries/doc | root-delta key bytes/doc | root-delta value bytes/doc | root-delta tombstones/doc | affected primary roots/doc | affected secondary roots/doc | primary root publishes/doc | primary root delta entries/doc | primary root delta bytes/doc | primary-only coalesced docs/publish | raw JSON |
| ---: | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 1 | 13022 | 7648 | 93.0 | 151 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1152 | 0.10 | 0.19 | 394 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 346 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver_command_raw_range_index_docs_100000_idx_0.json` |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 2 | 22743 | 13637 | 105 | 178 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1605 | 0.19 | 0.19 | 788 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 346 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver_command_raw_range_index_docs_100000_idx_0.json` |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 4 | 36442 | 23350 | 137 | 215 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1687 | 0.19 | 0.19 | 788 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 346 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver_command_raw_range_index_docs_100000_idx_0.json` |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 8 | 51897 | 31170 | 185 | 364 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1574 | 0.19 | 0.19 | 788 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 346 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver_command_raw_range_index_docs_100000_idx_0.json` |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 16 | 80689 | 33963 | 235 | 760 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1565 | 0.19 | 0.19 | 788 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 346 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver_command_raw_range_index_docs_100000_idx_0.json` |
| 100000 | 0 | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | 32 | 96147 | 34939 | 414 | 1671 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1562 | 0.19 | 0.19 | 788 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 346 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver_command_raw_range_index_docs_100000_idx_0.json` |

## Ops/Sec Summary

| docs | indexes | range index | range mode | TreeDB config | MongoDB baseline config | phase | TreeDB wall ops/sec | TreeDB sampled ops/sec | MongoDB wall ops/sec | MongoDB sampled ops/sec | TreeDB / MongoDB wall | TreeDB / MongoDB sampled | TreeDB p95 us | MongoDB p95 us |
| ---: | ---: | --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 0 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `load_insert_many` | 535131 | 139424 | 458721 | 69741 | 1.17x | 2.00x | 97809 | 169506 |
| 100000 | 0 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `id_find_one` | 14549 | 14767 | 8765 | 8845 | 1.66x | 1.67x | 83.0 | 138 |
| 100000 | 0 | true | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `age_range_indexed_limit_10` | 14108 | 14728 | 6825 | 7031 | 2.07x | 2.09x | 84.0 | 167 |
| 100000 | 0 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `id_update_set` | 12017 | 13593 | 7753 | 7811 | 1.55x | 1.74x | 92.0 | 144 |
| 100000 | 0 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w1` | 13022 | 13567 | 7648 | 7713 | 1.70x | 1.76x | 93.0 | 151 |
| 100000 | 0 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w2` | 22743 | 12220 | 13637 | 6874 | 1.67x | 1.78x | 105 | 178 |
| 100000 | 0 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w4` | 36442 | 10158 | 23350 | 5886 | 1.56x | 1.73x | 137 | 215 |
| 100000 | 0 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w8` | 51897 | 7531 | 31170 | 3926 | 1.66x | 1.92x | 185 | 364 |
| 100000 | 0 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w16` | 80689 | 6271 | 33963 | 2134 | 2.38x | 2.94x | 235 | 760 |
| 100000 | 0 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w32` | 96147 | 3922 | 34939 | 1097 | 2.75x | 3.58x | 414 | 1671 |
| 100000 | 1 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `load_insert_many` | 413766 | 117804 | 257044 | 38965 | 1.61x | 3.02x | 122302 | 319304 |
| 100000 | 1 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `id_find_one` | 15095 | 15323 | 8832 | 8914 | 1.71x | 1.72x | 79.0 | 134 |
| 100000 | 1 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `email_find_one` | 13445 | 13607 | 8028 | 8091 | 1.67x | 1.68x | 88.0 | 147 |
| 100000 | 1 | true | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `age_range_indexed_limit_10` | 14732 | 15386 | 6913 | 7081 | 2.13x | 2.17x | 83.0 | 160 |
| 100000 | 1 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `id_update_set` | 12447 | 14057 | 7741 | 7797 | 1.61x | 1.80x | 89.0 | 147 |
| 100000 | 1 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w1` | 13042 | 13595 | 7613 | 7677 | 1.71x | 1.77x | 92.0 | 151 |
| 100000 | 1 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w2` | 22207 | 11907 | 14290 | 7202 | 1.55x | 1.65x | 109 | 171 |
| 100000 | 1 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w4` | 35937 | 9952 | 23569 | 5941 | 1.52x | 1.68x | 140 | 212 |
| 100000 | 1 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w8` | 53141 | 7707 | 31742 | 4000 | 1.67x | 1.93x | 179 | 345 |
| 100000 | 1 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w16` | 80340 | 6223 | 32376 | 2034 | 2.48x | 3.06x | 237 | 822 |
| 100000 | 1 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w32` | 98950 | 4015 | 35037 | 1099 | 2.82x | 3.65x | 398 | 1679 |
| 100000 | 2 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `load_insert_many` | 378290 | 108226 | 195423 | 31108 | 1.94x | 3.48x | 124537 | 374593 |
| 100000 | 2 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `id_find_one` | 15140 | 15364 | 8858 | 8941 | 1.71x | 1.72x | 78.0 | 133 |
| 100000 | 2 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `email_find_one` | 13146 | 13301 | 7984 | 8047 | 1.65x | 1.65x | 92.0 | 146 |
| 100000 | 2 | true | `indexed` | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `age_range_indexed_limit_10` | 14228 | 14837 | 6826 | 6990 | 2.08x | 2.12x | 89.0 | 172 |
| 100000 | 2 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `id_update_set` | 11166 | 12860 | 7690 | 7746 | 1.45x | 1.66x | 116 | 151 |
| 100000 | 2 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w1` | 13097 | 13646 | 7639 | 7703 | 1.71x | 1.77x | 91.0 | 152 |
| 100000 | 2 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w2` | 22444 | 12038 | 14273 | 7193 | 1.57x | 1.67x | 107 | 172 |
| 100000 | 2 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w4` | 35565 | 9832 | 23639 | 5958 | 1.50x | 1.65x | 143 | 212 |
| 100000 | 2 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w8` | 53176 | 7695 | 32151 | 4052 | 1.65x | 1.90x | 180 | 338 |
| 100000 | 2 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w16` | 79792 | 6180 | 33473 | 2103 | 2.38x | 2.94x | 240 | 775 |
| 100000 | 2 | true | n/a | `treedb_bson_driver_command_raw_range_index` | `mongo_driver_command_raw_range_index` | `concurrent_id_update_set_w32` | 100862 | 4128 | 33705 | 1058 | 2.99x | 3.90x | 374 | 1785 |

## Raw Inputs

| docs | indexes | range index | config | target | raw json | profile dir |
| ---: | ---: | --- | --- | --- | --- | --- |
| 100000 | 0 | true | `treedb_bson_driver_command_raw_range_index` | treedb | `raw/treedb_bson_driver_command_raw_range_index_docs_100000_idx_0.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/profiles/treedb_bson_driver_command_raw_range_index_docs_100000_idx_0` |
| 100000 | 1 | true | `treedb_bson_driver_command_raw_range_index` | treedb | `raw/treedb_bson_driver_command_raw_range_index_docs_100000_idx_1.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/profiles/treedb_bson_driver_command_raw_range_index_docs_100000_idx_1` |
| 100000 | 2 | true | `treedb_bson_driver_command_raw_range_index` | treedb | `raw/treedb_bson_driver_command_raw_range_index_docs_100000_idx_2.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_full_sweep_1m_expanded/profiles/treedb_bson_driver_command_raw_range_index_docs_100000_idx_2` |
| 100000 | 0 | true | `mongo_driver_command_raw_range_index` | mongo | `raw/mongo_driver_command_raw_range_index_docs_100000_idx_0.json` | n/a |
| 100000 | 1 | true | `mongo_driver_command_raw_range_index` | mongo | `raw/mongo_driver_command_raw_range_index_docs_100000_idx_1.json` | n/a |
| 100000 | 2 | true | `mongo_driver_command_raw_range_index` | mongo | `raw/mongo_driver_command_raw_range_index_docs_100000_idx_2.json` | n/a |

## Notes

- TreeDB disk bytes prefer `treedb_disk_after_maintenance.total_bytes`, then fall back to `treedb_disk_after_checkpoint.total_bytes` and `treedb_disk_after_load.total_bytes` for older runs.
- TreeDB physical bytes come from the matrix runner's `du` measurement of the isolated TreeDB directory.
- MongoDB `dbStats.dataSize` is uncompressed logical document size, not disk usage.
- MongoDB `dbStats.totalSize` is reported separately because it can diverge sharply from the isolated data-directory `du` measurement on small WiredTiger workloads.
- MongoDB physical bytes are the preferred local disk comparison when the matrix runner has an isolated data directory, such as Docker mode.
- Wall ops/sec values include the full benchmark phase loop. Sampled ops/sec values isolate the timed driver/gateway call inside each phase and are useful when prebuilt fixtures are enabled.
- `concurrent_id_find_one_rN` phases are an `_id` read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Read Sweep section when present.
- `concurrent_email_find_one_rN` phases are an email read throughput sweep over `N` concurrent readers, and are also grouped in the Concurrent Read Sweep section when present.
- `concurrent_age_range_*_rN` phases are an age range-read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Range Read Sweep section when present.
- Range-query benchmark rows use explicit phase names: `age_range_indexed_limit_10` means `-range-index` created `age_1`; `age_range_scan_limit_10` means bounded scan fallback.
- Main comparison tables label the MongoDB config chosen as the baseline. In multi-mode matrices, all other MongoDB rows remain visible in the Mongo Matrix Rows section.
