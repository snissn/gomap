# Mongo API Reader/Writer Scaling, 0 indexes

- generated_at: `2026-11-20T18:24:29Z`
- matrix: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0/matrix.tsv`
- comparison cells: `12`
- targets: `treedb`, `mongo`

## Highlights

- Largest TreeDB ops/sec lead: `concurrent_id_find_one_r16` at 100000 docs / 0 indexes / `treedb_bson_driver-command-raw_readers_16`, 127259 ops/sec vs 35167 ops/sec (3.62x TreeDB / MongoDB).
- No phase in this matrix had MongoDB ahead on ops/sec.
- Largest cell disk: at 100000 docs / 0 indexes / `treedb_bson_driver-command-raw_writers_1`, TreeDB load snapshot used 8.63 MiB (90.5 B/doc), TreeDB physical du was 16.94 MiB, MongoDB dbStats dataSize was 31.81 MiB, MongoDB dbStats totalSize was 7.31 MiB, and MongoDB physical du was 207.71 MiB (2178.0 B/doc).

## Disk Summary

| docs | indexes | range index | TreeDB config | MongoDB baseline config | TreeDB snapshot | TreeDB bytes | TreeDB bytes/doc | TreeDB physical du | TreeDB physical bytes/doc | MongoDB dbStats dataSize | MongoDB dbStats totalSize | MongoDB physical du | MongoDB physical bytes/doc | TreeDB / MongoDB dbStats totalSize | TreeDB / MongoDB physical |
| ---: | ---: | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | load | 8.63 MiB | 90.5 B | 8.71 MiB | 91.3 B | 27.85 MiB | 6.17 MiB | 206.56 MiB | 2165.9 B | 1.40x | 0.04x |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | load | 8.63 MiB | 90.5 B | 8.71 MiB | 91.3 B | 27.85 MiB | 6.16 MiB | 206.56 MiB | 2165.9 B | 1.40x | 0.04x |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | load | 8.63 MiB | 90.5 B | 8.71 MiB | 91.3 B | 27.85 MiB | 6.17 MiB | 206.54 MiB | 2165.7 B | 1.40x | 0.04x |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | load | 8.63 MiB | 90.5 B | 8.71 MiB | 91.3 B | 27.85 MiB | 6.17 MiB | 206.54 MiB | 2165.7 B | 1.40x | 0.04x |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | load | 8.63 MiB | 90.5 B | 8.71 MiB | 91.3 B | 27.85 MiB | 6.16 MiB | 206.54 MiB | 2165.7 B | 1.40x | 0.04x |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | load | 8.63 MiB | 90.5 B | 8.71 MiB | 91.3 B | 27.85 MiB | 6.17 MiB | 206.54 MiB | 2165.7 B | 1.40x | 0.04x |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | load | 8.63 MiB | 90.5 B | 16.94 MiB | 177.6 B | 31.81 MiB | 7.31 MiB | 207.71 MiB | 2178.0 B | 1.18x | 0.08x |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | load | 8.63 MiB | 90.5 B | 16.91 MiB | 177.4 B | 31.81 MiB | 7.30 MiB | 207.70 MiB | 2177.9 B | 1.18x | 0.08x |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | load | 8.63 MiB | 90.5 B | 16.92 MiB | 177.4 B | 31.81 MiB | 7.30 MiB | 207.67 MiB | 2177.6 B | 1.18x | 0.08x |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | load | 8.63 MiB | 90.5 B | 16.95 MiB | 177.8 B | 31.81 MiB | 7.27 MiB | 207.65 MiB | 2177.4 B | 1.19x | 0.08x |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | load | 8.63 MiB | 90.5 B | 16.95 MiB | 177.8 B | 31.81 MiB | 7.27 MiB | 207.64 MiB | 2177.3 B | 1.19x | 0.08x |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | load | 8.63 MiB | 90.5 B | 16.93 MiB | 177.6 B | 31.81 MiB | 7.29 MiB | 207.66 MiB | 2177.5 B | 1.18x | 0.08x |

## Mongo Matrix Rows

These rows list every MongoDB matrix row, including non-baseline client-mode rows that are not used as the TreeDB comparison baseline.

| docs | indexes | range index | config | phase | ops/sec | sampled ops/sec | p95 us | dbStats totalSize | physical du | raw json |
| ---: | ---: | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 100000 | 0 | false | `mongo_readers_1` | `concurrent_id_find_one_r1` | 8694 | 8790 | 140 | 6.17 MiB | 206.56 MiB | `raw/mongo_readers_1.json` |
| 100000 | 0 | false | `mongo_readers_16` | `concurrent_id_find_one_r16` | 35167 | 2214 | 791 | 6.16 MiB | 206.56 MiB | `raw/mongo_readers_16.json` |
| 100000 | 0 | false | `mongo_readers_2` | `concurrent_id_find_one_r2` | 15486 | 7824 | 169 | 6.17 MiB | 206.54 MiB | `raw/mongo_readers_2.json` |
| 100000 | 0 | false | `mongo_readers_32` | `concurrent_id_find_one_r32` | 38546 | 1211 | 1605 | 6.17 MiB | 206.54 MiB | `raw/mongo_readers_32.json` |
| 100000 | 0 | false | `mongo_readers_4` | `concurrent_id_find_one_r4` | 23167 | 5849 | 255 | 6.16 MiB | 206.54 MiB | `raw/mongo_readers_4.json` |
| 100000 | 0 | false | `mongo_readers_8` | `concurrent_id_find_one_r8` | 31753 | 4008 | 401 | 6.17 MiB | 206.54 MiB | `raw/mongo_readers_8.json` |
| 100000 | 0 | false | `mongo_writers_1` | `concurrent_id_update_set_w1` | 7683 | 7748 | 152 | 7.31 MiB | 207.71 MiB | `raw/mongo_writers_1.json` |
| 100000 | 0 | false | `mongo_writers_16` | `concurrent_id_update_set_w16` | 31052 | 1952 | 841 | 7.30 MiB | 207.70 MiB | `raw/mongo_writers_16.json` |
| 100000 | 0 | false | `mongo_writers_2` | `concurrent_id_update_set_w2` | 13830 | 6970 | 175 | 7.30 MiB | 207.67 MiB | `raw/mongo_writers_2.json` |
| 100000 | 0 | false | `mongo_writers_32` | `concurrent_id_update_set_w32` | 32238 | 1011 | 1814 | 7.27 MiB | 207.65 MiB | `raw/mongo_writers_32.json` |
| 100000 | 0 | false | `mongo_writers_4` | `concurrent_id_update_set_w4` | 22433 | 5653 | 221 | 7.27 MiB | 207.64 MiB | `raw/mongo_writers_4.json` |
| 100000 | 0 | false | `mongo_writers_8` | `concurrent_id_update_set_w8` | 30018 | 3784 | 368 | 7.29 MiB | 207.66 MiB | `raw/mongo_writers_8.json` |


## 0-Index Writer Sweep Counters

These rows preserve TreeDB per-phase counter deltas for `concurrent_id_update_set_wN` phases. Values come from `phase.treedb_metrics` when present, so load counters and writer counters remain separate.

| docs | indexes | TreeDB config | MongoDB baseline config | writers | TreeDB ops/s | MongoDB ops/s | TreeDB p95 us | MongoDB p95 us | TreeDB driver calls | MongoDB driver calls | publish calls/doc | root apply calls/doc | roots/publish | root apply ns/doc | leaf-log loads/doc | leaf-log pages written/doc | leaf-log read bytes/doc | leaf-log write bytes/doc | indexed flush calls/doc | indexed flush units/batch | indexed flush docs/batch | indexed flush root-runs/doc | root-delta entries/doc | root-delta key bytes/doc | root-delta value bytes/doc | root-delta tombstones/doc | affected primary roots/doc | affected secondary roots/doc | primary root publishes/doc | primary root delta entries/doc | primary root delta bytes/doc | primary-only coalesced docs/publish | raw JSON |
| ---: | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 100000 | 0 | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | 1 | 13690 | 7683 | 86.0 | 152 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1172 | 0.10 | 0.19 | 394 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 344 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver-command-raw_writers_1.json` |
| 100000 | 0 | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | 16 | 75894 | 31052 | 267 | 841 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1154 | 0.10 | 0.19 | 394 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 344 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver-command-raw_writers_16.json` |
| 100000 | 0 | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | 2 | 22359 | 13830 | 108 | 175 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1137 | 0.10 | 0.19 | 394 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 344 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver-command-raw_writers_2.json` |
| 100000 | 0 | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | 32 | 98800 | 32238 | 421 | 1814 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1185 | 0.10 | 0.19 | 394 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 344 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver-command-raw_writers_32.json` |
| 100000 | 0 | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | 4 | 35132 | 22433 | 146 | 221 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1146 | 0.10 | 0.19 | 394 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 344 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver-command-raw_writers_4.json` |
| 100000 | 0 | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | 8 | 51830 | 30018 | 190 | 368 | 80000 | 80000 | 0.00 | 0.00 | 1.00 | 1144 | 0.10 | 0.19 | 394 | 788 | 0.00 | 1.00 | 80000 | 0.00 | 1.00 | 23.0 | 344 | 0 | 0.00 | 0 | 0 | 0 | 0 | n/a | `raw/treedb_bson_driver-command-raw_writers_8.json` |

## Ops/Sec Summary

| docs | indexes | range index | range mode | TreeDB config | MongoDB baseline config | phase | TreeDB wall ops/sec | TreeDB sampled ops/sec | MongoDB wall ops/sec | MongoDB sampled ops/sec | TreeDB / MongoDB wall | TreeDB / MongoDB sampled | TreeDB p95 us | MongoDB p95 us |
| ---: | ---: | --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `load_insert_many` | 522155 | 135509 | 221603 | 30329 | 2.36x | 4.47x | 101357 | 451150 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `concurrent_id_find_one_r1` | 15454 | 15718 | 8694 | 8790 | 1.78x | 1.79x | 78.0 | 140 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `load_insert_many` | 544791 | 146099 | 223212 | 29315 | 2.44x | 4.98x | 104163 | 447897 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `concurrent_id_find_one_r16` | 127259 | 8048 | 35167 | 2214 | 3.62x | 3.63x | 196 | 791 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `load_insert_many` | 566974 | 146358 | 226752 | 30260 | 2.50x | 4.84x | 92564 | 440921 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `concurrent_id_find_one_r2` | 29174 | 14841 | 15486 | 7824 | 1.88x | 1.90x | 87.0 | 169 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `load_insert_many` | 534999 | 136895 | 224977 | 30277 | 2.38x | 4.52x | 99275 | 444413 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `concurrent_id_find_one_r32` | 124382 | 3913 | 38546 | 1211 | 3.23x | 3.23x | 494 | 1605 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `load_insert_many` | 547335 | 142122 | 214075 | 28884 | 2.56x | 4.92x | 95368 | 467057 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `concurrent_id_find_one_r4` | 50577 | 12864 | 23167 | 5849 | 2.18x | 2.20x | 99.0 | 255 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `load_insert_many` | 543994 | 131134 | 233999 | 31274 | 2.32x | 4.19x | 105926 | 427301 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `concurrent_id_find_one_r8` | 92264 | 11716 | 31753 | 4008 | 2.91x | 2.92x | 119 | 401 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `load_insert_many` | 549654 | 141828 | 230446 | 31016 | 2.39x | 4.57x | 95683 | 433764 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `concurrent_id_update_set_w1` | 13690 | 14273 | 7683 | 7748 | 1.78x | 1.84x | 86.0 | 152 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `load_insert_many` | 472870 | 142887 | 226852 | 30023 | 2.08x | 4.76x | 94496 | 440790 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `concurrent_id_update_set_w16` | 75894 | 5611 | 31052 | 1952 | 2.44x | 2.87x | 267 | 841 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `load_insert_many` | 468088 | 115375 | 227659 | 30178 | 2.06x | 3.82x | 119149 | 439111 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `concurrent_id_update_set_w2` | 22359 | 11858 | 13830 | 6970 | 1.62x | 1.70x | 108 | 175 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `load_insert_many` | 478094 | 121618 | 222915 | 28976 | 2.14x | 4.20x | 112391 | 448446 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `concurrent_id_update_set_w32` | 98800 | 3849 | 32238 | 1011 | 3.06x | 3.81x | 421 | 1814 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `load_insert_many` | 564600 | 130910 | 251067 | 35841 | 2.25x | 3.65x | 100356 | 398258 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `concurrent_id_update_set_w4` | 35132 | 9555 | 22433 | 5653 | 1.57x | 1.69x | 146 | 221 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `load_insert_many` | 550680 | 133001 | 227462 | 30860 | 2.42x | 4.31x | 103245 | 439606 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `concurrent_id_update_set_w8` | 51830 | 7324 | 30018 | 3784 | 1.73x | 1.94x | 190 | 368 |

## Raw Inputs

| docs | indexes | range index | config | target | raw json | profile dir |
| ---: | ---: | --- | --- | --- | --- | --- |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_1` | treedb | `raw/treedb_bson_driver-command-raw_readers_1.json` | n/a |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_16` | treedb | `raw/treedb_bson_driver-command-raw_readers_16.json` | n/a |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_2` | treedb | `raw/treedb_bson_driver-command-raw_readers_2.json` | n/a |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_32` | treedb | `raw/treedb_bson_driver-command-raw_readers_32.json` | n/a |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_4` | treedb | `raw/treedb_bson_driver-command-raw_readers_4.json` | n/a |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_readers_8` | treedb | `raw/treedb_bson_driver-command-raw_readers_8.json` | n/a |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_1` | treedb | `raw/treedb_bson_driver-command-raw_writers_1.json` | n/a |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_16` | treedb | `raw/treedb_bson_driver-command-raw_writers_16.json` | n/a |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_2` | treedb | `raw/treedb_bson_driver-command-raw_writers_2.json` | n/a |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_32` | treedb | `raw/treedb_bson_driver-command-raw_writers_32.json` | n/a |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_4` | treedb | `raw/treedb_bson_driver-command-raw_writers_4.json` | n/a |
| 100000 | 0 | false | `treedb_bson_driver-command-raw_writers_8` | treedb | `raw/treedb_bson_driver-command-raw_writers_8.json` | n/a |
| 100000 | 0 | false | `mongo_readers_1` | mongo | `raw/mongo_readers_1.json` | n/a |
| 100000 | 0 | false | `mongo_readers_16` | mongo | `raw/mongo_readers_16.json` | n/a |
| 100000 | 0 | false | `mongo_readers_2` | mongo | `raw/mongo_readers_2.json` | n/a |
| 100000 | 0 | false | `mongo_readers_32` | mongo | `raw/mongo_readers_32.json` | n/a |
| 100000 | 0 | false | `mongo_readers_4` | mongo | `raw/mongo_readers_4.json` | n/a |
| 100000 | 0 | false | `mongo_readers_8` | mongo | `raw/mongo_readers_8.json` | n/a |
| 100000 | 0 | false | `mongo_writers_1` | mongo | `raw/mongo_writers_1.json` | n/a |
| 100000 | 0 | false | `mongo_writers_16` | mongo | `raw/mongo_writers_16.json` | n/a |
| 100000 | 0 | false | `mongo_writers_2` | mongo | `raw/mongo_writers_2.json` | n/a |
| 100000 | 0 | false | `mongo_writers_32` | mongo | `raw/mongo_writers_32.json` | n/a |
| 100000 | 0 | false | `mongo_writers_4` | mongo | `raw/mongo_writers_4.json` | n/a |
| 100000 | 0 | false | `mongo_writers_8` | mongo | `raw/mongo_writers_8.json` | n/a |

## Notes

- TreeDB disk bytes prefer `treedb_disk_after_maintenance.total_bytes`, then fall back to `treedb_disk_after_checkpoint.total_bytes` and `treedb_disk_after_load.total_bytes` for older runs.
- TreeDB physical bytes come from the matrix runner's `du` measurement of the isolated TreeDB directory.
- MongoDB `dbStats.dataSize` is uncompressed logical document size, not disk usage.
- MongoDB `dbStats.totalSize` is reported separately because it can diverge sharply from the isolated data-directory `du` measurement on small WiredTiger workloads.
- MongoDB physical bytes are the preferred local disk comparison when the matrix runner has an isolated data directory, such as Docker mode.
- Wall ops/sec values include the full benchmark phase loop. Sampled ops/sec values isolate the timed driver/gateway call inside each phase and are useful when prebuilt fixtures are enabled.
- `concurrent_id_find_one_rN` phases are an `_id` read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Read Sweep section when present.
- `concurrent_email_find_one_rN` phases are an email read throughput sweep over `N` concurrent readers, and are also grouped in the Concurrent Read Sweep section when present.
- `concurrent_age_range_*_rN` phases are an age range-read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Range Read Sweep section when present.
- Range-query benchmark rows use explicit phase names: `age_range_indexed_limit_10` means `-range-index` created `age_1`; `age_range_scan_limit_10` means bounded scan fallback.
- Main comparison tables label the MongoDB config chosen as the baseline. In multi-mode matrices, all other MongoDB rows remain visible in the Mongo Matrix Rows section.
