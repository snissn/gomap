# Mongo Gateway Scaling Bundle

- output directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0`
- report: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0/report.md`
- summary TSV: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0/summary.tsv`
- matrix TSV: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0/matrix.tsv`
- writer metrics TSV: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0/writer_metrics.tsv`
- raw JSON directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0/raw`
- TreeDB data directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0/treedb_data`
- TreeDB location metadata: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0/treedb-location.txt`
- docs: `100000`
- secondary indexes: `0`
- batch size: `10000`
- insert producers: `8`
- writer sweep: `1 2 4 8 16 32`
- reader sweep: `1 2 4 8 16 32`
- run reader sweep: `1`
- concurrent writes per writer cell: `80000`
- concurrent reads per reader cell: `80000`
- TreeDB profile: `bench_unsafe`
- TreeDB document format: `bson`
- TreeDB client mode: `driver-command-raw`
- TreeDB maintenance: `none`
- update indexed field: `false`
- include MongoDB: `1`
- MongoDB mode: `docker`
- MongoDB URI: `mongodb://127.0.0.1:27017`
- MongoDB image: `mongo@sha256:7abfba0d07c9330373f8173981ea4d09cd8a82cdf0e86ccaf7008848d1d24f62`
- MongoDB compact before final stats: `true`
- MongoDB database prefix: `mongo_gateway_scaling_indexes_0`
- GOWORK: `off`
- timeout: `120m`

Regenerate the report:

```sh
GOWORK=off go run ./cmd/mongo_gateway_compare_report \
  -matrix "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0/matrix.tsv" \
  -report "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0/report.md" \
  -summary "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_0/summary.tsv" \
  -title "Mongo API Reader/Writer Scaling, 0 indexes"
```
