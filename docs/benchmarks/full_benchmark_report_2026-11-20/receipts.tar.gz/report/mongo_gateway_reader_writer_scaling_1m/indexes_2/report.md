# Mongo API Reader/Writer Scaling, 2 indexes

- generated_at: `2026-11-20T18:28:41Z`
- matrix: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_2/matrix.tsv`
- comparison cells: `12`
- targets: `treedb`, `mongo`

## Highlights

- Largest TreeDB ops/sec lead: `concurrent_id_find_one_r32` at 100000 docs / 2 indexes / `treedb_bson_driver-command-raw_readers_32`, 123614 ops/sec vs 37384 ops/sec (3.31x TreeDB / MongoDB).
- No phase in this matrix had MongoDB ahead on ops/sec.
- Largest cell disk: at 100000 docs / 2 indexes / `treedb_bson_driver-command-raw_writers_1`, TreeDB load snapshot used 9.84 MiB (103.2 B/doc), TreeDB physical du was 18.16 MiB, MongoDB dbStats dataSize was 31.81 MiB, MongoDB dbStats totalSize was 10.22 MiB, and MongoDB physical du was 210.63 MiB (2208.6 B/doc).

## Disk Summary

| docs | indexes | range index | TreeDB config | MongoDB baseline config | TreeDB snapshot | TreeDB bytes | TreeDB bytes/doc | TreeDB physical du | TreeDB physical bytes/doc | MongoDB dbStats dataSize | MongoDB dbStats totalSize | MongoDB physical du | MongoDB physical bytes/doc | TreeDB / MongoDB dbStats totalSize | TreeDB / MongoDB physical |
| ---: | ---: | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | load | 9.78 MiB | 102.5 B | 9.93 MiB | 104.1 B | 27.85 MiB | 9.18 MiB | 209.58 MiB | 2197.6 B | 1.07x | 0.05x |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | load | 9.87 MiB | 103.5 B | 9.96 MiB | 104.4 B | 27.85 MiB | 9.17 MiB | 209.55 MiB | 2197.3 B | 1.08x | 0.05x |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | load | 9.81 MiB | 102.9 B | 9.96 MiB | 104.4 B | 27.85 MiB | 9.18 MiB | 209.55 MiB | 2197.3 B | 1.07x | 0.05x |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | load | 9.87 MiB | 103.5 B | 9.96 MiB | 104.4 B | 27.85 MiB | 9.16 MiB | 209.56 MiB | 2197.4 B | 1.08x | 0.05x |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | load | 9.87 MiB | 103.5 B | 9.96 MiB | 104.4 B | 27.85 MiB | 9.17 MiB | 209.58 MiB | 2197.6 B | 1.08x | 0.05x |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | load | 9.87 MiB | 103.5 B | 9.96 MiB | 104.4 B | 27.85 MiB | 9.16 MiB | 209.54 MiB | 2197.2 B | 1.08x | 0.05x |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | load | 9.84 MiB | 103.2 B | 18.16 MiB | 190.4 B | 31.81 MiB | 10.22 MiB | 210.63 MiB | 2208.6 B | 0.96x | 0.09x |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | load | 9.84 MiB | 103.2 B | 18.13 MiB | 190.1 B | 31.81 MiB | 10.15 MiB | 210.56 MiB | 2207.9 B | 0.97x | 0.09x |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | load | 9.84 MiB | 103.2 B | 18.14 MiB | 190.2 B | 31.81 MiB | 10.20 MiB | 210.59 MiB | 2208.2 B | 0.96x | 0.09x |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | load | 9.87 MiB | 103.5 B | 18.20 MiB | 190.8 B | 31.81 MiB | 10.17 MiB | 210.56 MiB | 2207.9 B | 0.97x | 0.09x |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | load | 9.87 MiB | 103.5 B | 18.20 MiB | 190.8 B | 31.81 MiB | 10.14 MiB | 210.53 MiB | 2207.5 B | 0.97x | 0.09x |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | load | 9.84 MiB | 103.2 B | 18.15 MiB | 190.3 B | 31.81 MiB | 10.11 MiB | 210.49 MiB | 2207.1 B | 0.97x | 0.09x |

## Mongo Matrix Rows

These rows list every MongoDB matrix row, including non-baseline client-mode rows that are not used as the TreeDB comparison baseline.

| docs | indexes | range index | config | phase | ops/sec | sampled ops/sec | p95 us | dbStats totalSize | physical du | raw json |
| ---: | ---: | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 100000 | 2 | false | `mongo_readers_1` | `concurrent_id_find_one_r1` | 8684 | 8779 | 136 | 9.18 MiB | 209.58 MiB | `raw/mongo_readers_1.json` |
| 100000 | 2 | false | `mongo_readers_16` | `concurrent_id_find_one_r16` | 35247 | 2218 | 790 | 9.17 MiB | 209.55 MiB | `raw/mongo_readers_16.json` |
| 100000 | 2 | false | `mongo_readers_2` | `concurrent_id_find_one_r2` | 15397 | 7779 | 171 | 9.18 MiB | 209.55 MiB | `raw/mongo_readers_2.json` |
| 100000 | 2 | false | `mongo_readers_32` | `concurrent_id_find_one_r32` | 37384 | 1175 | 1690 | 9.16 MiB | 209.56 MiB | `raw/mongo_readers_32.json` |
| 100000 | 2 | false | `mongo_readers_4` | `concurrent_id_find_one_r4` | 23080 | 5826 | 259 | 9.17 MiB | 209.58 MiB | `raw/mongo_readers_4.json` |
| 100000 | 2 | false | `mongo_readers_8` | `concurrent_id_find_one_r8` | 30952 | 3907 | 409 | 9.16 MiB | 209.54 MiB | `raw/mongo_readers_8.json` |
| 100000 | 2 | false | `mongo_writers_1` | `concurrent_id_update_set_w1` | 7671 | 7734 | 152 | 10.22 MiB | 210.63 MiB | `raw/mongo_writers_1.json` |
| 100000 | 2 | false | `mongo_writers_16` | `concurrent_id_update_set_w16` | 31587 | 1986 | 823 | 10.15 MiB | 210.56 MiB | `raw/mongo_writers_16.json` |
| 100000 | 2 | false | `mongo_writers_2` | `concurrent_id_update_set_w2` | 13886 | 6996 | 175 | 10.20 MiB | 210.59 MiB | `raw/mongo_writers_2.json` |
| 100000 | 2 | false | `mongo_writers_32` | `concurrent_id_update_set_w32` | 31796 | 997 | 1836 | 10.17 MiB | 210.56 MiB | `raw/mongo_writers_32.json` |
| 100000 | 2 | false | `mongo_writers_4` | `concurrent_id_update_set_w4` | 22274 | 5615 | 225 | 10.14 MiB | 210.53 MiB | `raw/mongo_writers_4.json` |
| 100000 | 2 | false | `mongo_writers_8` | `concurrent_id_update_set_w8` | 29863 | 3765 | 365 | 10.11 MiB | 210.49 MiB | `raw/mongo_writers_8.json` |


## Ops/Sec Summary

| docs | indexes | range index | range mode | TreeDB config | MongoDB baseline config | phase | TreeDB wall ops/sec | TreeDB sampled ops/sec | MongoDB wall ops/sec | MongoDB sampled ops/sec | TreeDB / MongoDB wall | TreeDB / MongoDB sampled | TreeDB p95 us | MongoDB p95 us |
| ---: | ---: | --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `load_insert_many` | 409419 | 109131 | 200281 | 30674 | 2.04x | 3.56x | 124513 | 387635 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `concurrent_id_find_one_r1` | 15325 | 15592 | 8684 | 8779 | 1.76x | 1.78x | 77.0 | 136 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `load_insert_many` | 383301 | 108655 | 195805 | 30761 | 1.96x | 3.53x | 138332 | 389448 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `concurrent_id_find_one_r16` | 105955 | 6702 | 35247 | 2218 | 3.01x | 3.02x | 234 | 790 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `load_insert_many` | 405208 | 110827 | 200637 | 30838 | 2.02x | 3.59x | 130406 | 386533 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `concurrent_id_find_one_r2` | 28819 | 14660 | 15397 | 7779 | 1.87x | 1.88x | 87.0 | 171 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `load_insert_many` | 413137 | 113849 | 200456 | 30964 | 2.06x | 3.68x | 126460 | 397024 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `concurrent_id_find_one_r32` | 123614 | 3888 | 37384 | 1175 | 3.31x | 3.31x | 500 | 1690 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `load_insert_many` | 442621 | 116301 | 203103 | 31020 | 2.18x | 3.75x | 123820 | 394800 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `concurrent_id_find_one_r4` | 50708 | 12890 | 23080 | 5826 | 2.20x | 2.21x | 100 | 259 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `load_insert_many` | 388262 | 108549 | 197489 | 30625 | 1.97x | 3.54x | 122682 | 396125 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `concurrent_id_find_one_r8` | 84050 | 10673 | 30952 | 3907 | 2.72x | 2.73x | 132 | 409 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `load_insert_many` | 417209 | 107317 | 201738 | 30592 | 2.07x | 3.51x | 127531 | 400252 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `concurrent_id_update_set_w1` | 13146 | 13734 | 7671 | 7734 | 1.71x | 1.78x | 95.0 | 152 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `load_insert_many` | 429960 | 112518 | 203119 | 30901 | 2.12x | 3.64x | 128362 | 388203 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `concurrent_id_update_set_w16` | 75927 | 5805 | 31587 | 1986 | 2.40x | 2.92x | 252 | 823 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `load_insert_many` | 427819 | 109573 | 199112 | 30730 | 2.15x | 3.57x | 131494 | 394653 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `concurrent_id_update_set_w2` | 21559 | 11492 | 13886 | 6996 | 1.55x | 1.64x | 114 | 175 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `load_insert_many` | 423343 | 114851 | 189548 | 29375 | 2.23x | 3.91x | 118044 | 405754 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `concurrent_id_update_set_w32` | 96611 | 3770 | 31796 | 997 | 3.04x | 3.78x | 420 | 1836 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `load_insert_many` | 411157 | 109088 | 209499 | 32087 | 1.96x | 3.40x | 133071 | 378412 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `concurrent_id_update_set_w4` | 34917 | 9484 | 22274 | 5615 | 1.57x | 1.69x | 146 | 225 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `load_insert_many` | 440331 | 116582 | 194998 | 29795 | 2.26x | 3.91x | 124926 | 407198 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `concurrent_id_update_set_w8` | 51462 | 7274 | 29863 | 3765 | 1.72x | 1.93x | 188 | 365 |

## Raw Inputs

| docs | indexes | range index | config | target | raw json | profile dir |
| ---: | ---: | --- | --- | --- | --- | --- |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_1` | treedb | `raw/treedb_bson_driver-command-raw_readers_1.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_16` | treedb | `raw/treedb_bson_driver-command-raw_readers_16.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_2` | treedb | `raw/treedb_bson_driver-command-raw_readers_2.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_32` | treedb | `raw/treedb_bson_driver-command-raw_readers_32.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_4` | treedb | `raw/treedb_bson_driver-command-raw_readers_4.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_readers_8` | treedb | `raw/treedb_bson_driver-command-raw_readers_8.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_1` | treedb | `raw/treedb_bson_driver-command-raw_writers_1.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_16` | treedb | `raw/treedb_bson_driver-command-raw_writers_16.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_2` | treedb | `raw/treedb_bson_driver-command-raw_writers_2.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_32` | treedb | `raw/treedb_bson_driver-command-raw_writers_32.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_4` | treedb | `raw/treedb_bson_driver-command-raw_writers_4.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver-command-raw_writers_8` | treedb | `raw/treedb_bson_driver-command-raw_writers_8.json` | n/a |
| 100000 | 2 | false | `mongo_readers_1` | mongo | `raw/mongo_readers_1.json` | n/a |
| 100000 | 2 | false | `mongo_readers_16` | mongo | `raw/mongo_readers_16.json` | n/a |
| 100000 | 2 | false | `mongo_readers_2` | mongo | `raw/mongo_readers_2.json` | n/a |
| 100000 | 2 | false | `mongo_readers_32` | mongo | `raw/mongo_readers_32.json` | n/a |
| 100000 | 2 | false | `mongo_readers_4` | mongo | `raw/mongo_readers_4.json` | n/a |
| 100000 | 2 | false | `mongo_readers_8` | mongo | `raw/mongo_readers_8.json` | n/a |
| 100000 | 2 | false | `mongo_writers_1` | mongo | `raw/mongo_writers_1.json` | n/a |
| 100000 | 2 | false | `mongo_writers_16` | mongo | `raw/mongo_writers_16.json` | n/a |
| 100000 | 2 | false | `mongo_writers_2` | mongo | `raw/mongo_writers_2.json` | n/a |
| 100000 | 2 | false | `mongo_writers_32` | mongo | `raw/mongo_writers_32.json` | n/a |
| 100000 | 2 | false | `mongo_writers_4` | mongo | `raw/mongo_writers_4.json` | n/a |
| 100000 | 2 | false | `mongo_writers_8` | mongo | `raw/mongo_writers_8.json` | n/a |

## Notes

- TreeDB disk bytes prefer `treedb_disk_after_maintenance.total_bytes`, then fall back to `treedb_disk_after_checkpoint.total_bytes` and `treedb_disk_after_load.total_bytes` for older runs.
- TreeDB physical bytes come from the matrix runner's `du` measurement of the isolated TreeDB directory.
- MongoDB `dbStats.dataSize` is uncompressed logical document size, not disk usage.
- MongoDB `dbStats.totalSize` is reported separately because it can diverge sharply from the isolated data-directory `du` measurement on small WiredTiger workloads.
- MongoDB physical bytes are the preferred local disk comparison when the matrix runner has an isolated data directory, such as Docker mode.
- Wall ops/sec values include the full benchmark phase loop. Sampled ops/sec values isolate the timed driver/gateway call inside each phase and are useful when prebuilt fixtures are enabled.
- `concurrent_id_find_one_rN` phases are an `_id` read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Read Sweep section when present.
- `concurrent_email_find_one_rN` phases are an email read throughput sweep over `N` concurrent readers, and are also grouped in the Concurrent Read Sweep section when present.
- `concurrent_age_range_*_rN` phases are an age range-read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Range Read Sweep section when present.
- Range-query benchmark rows use explicit phase names: `age_range_indexed_limit_10` means `-range-index` created `age_1`; `age_range_scan_limit_10` means bounded scan fallback.
- Main comparison tables label the MongoDB config chosen as the baseline. In multi-mode matrices, all other MongoDB rows remain visible in the Mongo Matrix Rows section.
