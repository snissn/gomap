# Mongo API Reader/Writer Scaling, 1 indexes

- generated_at: `2026-11-20T18:26:34Z`
- matrix: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_reader_writer_scaling_1m/indexes_1/matrix.tsv`
- comparison cells: `12`
- targets: `treedb`, `mongo`

## Highlights

- Largest TreeDB ops/sec lead: `concurrent_id_find_one_r16` at 100000 docs / 1 indexes / `treedb_bson_driver-command-raw_readers_16`, 122893 ops/sec vs 34035 ops/sec (3.61x TreeDB / MongoDB).
- No phase in this matrix had MongoDB ahead on ops/sec.
- Largest cell disk: at 100000 docs / 1 indexes / `treedb_bson_driver-command-raw_writers_2`, TreeDB load snapshot used 9.35 MiB (98.0 B/doc), TreeDB physical du was 17.64 MiB, MongoDB dbStats dataSize was 31.81 MiB, MongoDB dbStats totalSize was 9.80 MiB, and MongoDB physical du was 210.21 MiB (2204.2 B/doc).

## Disk Summary

| docs | indexes | range index | TreeDB config | MongoDB baseline config | TreeDB snapshot | TreeDB bytes | TreeDB bytes/doc | TreeDB physical du | TreeDB physical bytes/doc | MongoDB dbStats dataSize | MongoDB dbStats totalSize | MongoDB physical du | MongoDB physical bytes/doc | TreeDB / MongoDB dbStats totalSize | TreeDB / MongoDB physical |
| ---: | ---: | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | load | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.65 MiB | 209.03 MiB | 2191.9 B | 1.08x | 0.05x |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | load | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.67 MiB | 209.05 MiB | 2192.0 B | 1.08x | 0.05x |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | load | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.65 MiB | 209.03 MiB | 2191.8 B | 1.08x | 0.05x |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | load | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.64 MiB | 209.02 MiB | 2191.7 B | 1.08x | 0.05x |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | load | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.64 MiB | 209.02 MiB | 2191.8 B | 1.08x | 0.05x |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | load | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.65 MiB | 209.03 MiB | 2191.9 B | 1.08x | 0.05x |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | load | 9.35 MiB | 98.0 B | 17.66 MiB | 185.2 B | 31.81 MiB | 9.76 MiB | 210.17 MiB | 2203.8 B | 0.96x | 0.08x |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | load | 9.35 MiB | 98.0 B | 17.64 MiB | 184.9 B | 31.81 MiB | 9.74 MiB | 210.12 MiB | 2203.3 B | 0.96x | 0.08x |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | load | 9.35 MiB | 98.0 B | 17.64 MiB | 184.9 B | 31.81 MiB | 9.80 MiB | 210.21 MiB | 2204.2 B | 0.95x | 0.08x |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | load | 9.35 MiB | 98.0 B | 17.67 MiB | 185.3 B | 31.81 MiB | 9.75 MiB | 210.13 MiB | 2203.4 B | 0.96x | 0.08x |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | load | 9.35 MiB | 98.0 B | 17.67 MiB | 185.3 B | 31.81 MiB | 9.72 MiB | 210.13 MiB | 2203.4 B | 0.96x | 0.08x |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | load | 9.35 MiB | 98.0 B | 17.65 MiB | 185.1 B | 31.81 MiB | 9.68 MiB | 210.07 MiB | 2202.7 B | 0.97x | 0.08x |

## Mongo Matrix Rows

These rows list every MongoDB matrix row, including non-baseline client-mode rows that are not used as the TreeDB comparison baseline.

| docs | indexes | range index | config | phase | ops/sec | sampled ops/sec | p95 us | dbStats totalSize | physical du | raw json |
| ---: | ---: | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 100000 | 1 | false | `mongo_readers_1` | `concurrent_id_find_one_r1` | 8600 | 8693 | 140 | 8.65 MiB | 209.03 MiB | `raw/mongo_readers_1.json` |
| 100000 | 1 | false | `mongo_readers_16` | `concurrent_id_find_one_r16` | 34035 | 2143 | 832 | 8.67 MiB | 209.05 MiB | `raw/mongo_readers_16.json` |
| 100000 | 1 | false | `mongo_readers_2` | `concurrent_id_find_one_r2` | 15674 | 7917 | 160 | 8.65 MiB | 209.03 MiB | `raw/mongo_readers_2.json` |
| 100000 | 1 | false | `mongo_readers_32` | `concurrent_id_find_one_r32` | 36038 | 1132 | 1750 | 8.64 MiB | 209.02 MiB | `raw/mongo_readers_32.json` |
| 100000 | 1 | false | `mongo_readers_4` | `concurrent_id_find_one_r4` | 23631 | 5966 | 245 | 8.64 MiB | 209.02 MiB | `raw/mongo_readers_4.json` |
| 100000 | 1 | false | `mongo_readers_8` | `concurrent_id_find_one_r8` | 30106 | 3803 | 424 | 8.65 MiB | 209.03 MiB | `raw/mongo_readers_8.json` |
| 100000 | 1 | false | `mongo_writers_1` | `concurrent_id_update_set_w1` | 7687 | 7751 | 151 | 9.76 MiB | 210.17 MiB | `raw/mongo_writers_1.json` |
| 100000 | 1 | false | `mongo_writers_16` | `concurrent_id_update_set_w16` | 30813 | 1937 | 852 | 9.74 MiB | 210.12 MiB | `raw/mongo_writers_16.json` |
| 100000 | 1 | false | `mongo_writers_2` | `concurrent_id_update_set_w2` | 13581 | 6843 | 184 | 9.80 MiB | 210.21 MiB | `raw/mongo_writers_2.json` |
| 100000 | 1 | false | `mongo_writers_32` | `concurrent_id_update_set_w32` | 32674 | 1025 | 1777 | 9.75 MiB | 210.13 MiB | `raw/mongo_writers_32.json` |
| 100000 | 1 | false | `mongo_writers_4` | `concurrent_id_update_set_w4` | 21968 | 5536 | 234 | 9.72 MiB | 210.13 MiB | `raw/mongo_writers_4.json` |
| 100000 | 1 | false | `mongo_writers_8` | `concurrent_id_update_set_w8` | 28937 | 3646 | 394 | 9.68 MiB | 210.07 MiB | `raw/mongo_writers_8.json` |


## Ops/Sec Summary

| docs | indexes | range index | range mode | TreeDB config | MongoDB baseline config | phase | TreeDB wall ops/sec | TreeDB sampled ops/sec | MongoDB wall ops/sec | MongoDB sampled ops/sec | TreeDB / MongoDB wall | TreeDB / MongoDB sampled | TreeDB p95 us | MongoDB p95 us |
| ---: | ---: | --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `load_insert_many` | 446329 | 117715 | 238694 | 36320 | 1.87x | 3.24x | 126215 | 330786 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_1` | `mongo_readers_1` | `concurrent_id_find_one_r1` | 15059 | 15318 | 8600 | 8693 | 1.75x | 1.76x | 81.0 | 140 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `load_insert_many` | 455199 | 117435 | 228845 | 35805 | 1.99x | 3.28x | 124044 | 334438 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_16` | `mongo_readers_16` | `concurrent_id_find_one_r16` | 122893 | 7772 | 34035 | 2143 | 3.61x | 3.63x | 204 | 832 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `load_insert_many` | 448177 | 121689 | 212145 | 32567 | 2.11x | 3.74x | 116717 | 379379 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_2` | `mongo_readers_2` | `concurrent_id_find_one_r2` | 28821 | 14660 | 15674 | 7917 | 1.84x | 1.85x | 88.0 | 160 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `load_insert_many` | 434002 | 116498 | 218145 | 33514 | 1.99x | 3.48x | 122496 | 357212 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_32` | `mongo_readers_32` | `concurrent_id_find_one_r32` | 101297 | 3188 | 36038 | 1132 | 2.81x | 2.82x | 691 | 1750 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `load_insert_many` | 453062 | 118379 | 216387 | 34770 | 2.09x | 3.40x | 121872 | 353361 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_4` | `mongo_readers_4` | `concurrent_id_find_one_r4` | 50997 | 12968 | 23631 | 5966 | 2.16x | 2.17x | 99.0 | 245 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `load_insert_many` | 430650 | 102777 | 242223 | 36109 | 1.78x | 2.85x | 145680 | 331778 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_readers_8` | `mongo_readers_8` | `concurrent_id_find_one_r8` | 89292 | 11339 | 30106 | 3803 | 2.97x | 2.98x | 123 | 424 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `load_insert_many` | 463772 | 119813 | 239528 | 37180 | 1.94x | 3.22x | 121349 | 330664 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_1` | `mongo_writers_1` | `concurrent_id_update_set_w1` | 13203 | 13776 | 7687 | 7751 | 1.72x | 1.78x | 94.0 | 151 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `load_insert_many` | 449803 | 119215 | 231720 | 36146 | 1.94x | 3.30x | 121894 | 335321 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_16` | `mongo_writers_16` | `concurrent_id_update_set_w16` | 77141 | 5717 | 30813 | 1937 | 2.50x | 2.95x | 261 | 852 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `load_insert_many` | 461807 | 110597 | 232902 | 35774 | 1.98x | 3.09x | 132264 | 344931 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_2` | `mongo_writers_2` | `concurrent_id_update_set_w2` | 21868 | 11605 | 13581 | 6843 | 1.61x | 1.70x | 112 | 184 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `load_insert_many` | 455077 | 128051 | 217071 | 35280 | 2.10x | 3.63x | 111277 | 342732 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_32` | `mongo_writers_32` | `concurrent_id_update_set_w32` | 97513 | 3821 | 32674 | 1025 | 2.98x | 3.73x | 416 | 1777 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `load_insert_many` | 455087 | 109896 | 206228 | 35154 | 2.21x | 3.13x | 134414 | 328718 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_4` | `mongo_writers_4` | `concurrent_id_update_set_w4` | 34589 | 9382 | 21968 | 5536 | 1.57x | 1.69x | 148 | 234 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `load_insert_many` | 447882 | 120731 | 235807 | 36283 | 1.90x | 3.33x | 113127 | 338023 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver-command-raw_writers_8` | `mongo_writers_8` | `concurrent_id_update_set_w8` | 51316 | 7247 | 28937 | 3646 | 1.77x | 1.99x | 192 | 394 |

## Raw Inputs

| docs | indexes | range index | config | target | raw json | profile dir |
| ---: | ---: | --- | --- | --- | --- | --- |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_1` | treedb | `raw/treedb_bson_driver-command-raw_readers_1.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_16` | treedb | `raw/treedb_bson_driver-command-raw_readers_16.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_2` | treedb | `raw/treedb_bson_driver-command-raw_readers_2.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_32` | treedb | `raw/treedb_bson_driver-command-raw_readers_32.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_4` | treedb | `raw/treedb_bson_driver-command-raw_readers_4.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_readers_8` | treedb | `raw/treedb_bson_driver-command-raw_readers_8.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_1` | treedb | `raw/treedb_bson_driver-command-raw_writers_1.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_16` | treedb | `raw/treedb_bson_driver-command-raw_writers_16.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_2` | treedb | `raw/treedb_bson_driver-command-raw_writers_2.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_32` | treedb | `raw/treedb_bson_driver-command-raw_writers_32.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_4` | treedb | `raw/treedb_bson_driver-command-raw_writers_4.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver-command-raw_writers_8` | treedb | `raw/treedb_bson_driver-command-raw_writers_8.json` | n/a |
| 100000 | 1 | false | `mongo_readers_1` | mongo | `raw/mongo_readers_1.json` | n/a |
| 100000 | 1 | false | `mongo_readers_16` | mongo | `raw/mongo_readers_16.json` | n/a |
| 100000 | 1 | false | `mongo_readers_2` | mongo | `raw/mongo_readers_2.json` | n/a |
| 100000 | 1 | false | `mongo_readers_32` | mongo | `raw/mongo_readers_32.json` | n/a |
| 100000 | 1 | false | `mongo_readers_4` | mongo | `raw/mongo_readers_4.json` | n/a |
| 100000 | 1 | false | `mongo_readers_8` | mongo | `raw/mongo_readers_8.json` | n/a |
| 100000 | 1 | false | `mongo_writers_1` | mongo | `raw/mongo_writers_1.json` | n/a |
| 100000 | 1 | false | `mongo_writers_16` | mongo | `raw/mongo_writers_16.json` | n/a |
| 100000 | 1 | false | `mongo_writers_2` | mongo | `raw/mongo_writers_2.json` | n/a |
| 100000 | 1 | false | `mongo_writers_32` | mongo | `raw/mongo_writers_32.json` | n/a |
| 100000 | 1 | false | `mongo_writers_4` | mongo | `raw/mongo_writers_4.json` | n/a |
| 100000 | 1 | false | `mongo_writers_8` | mongo | `raw/mongo_writers_8.json` | n/a |

## Notes

- TreeDB disk bytes prefer `treedb_disk_after_maintenance.total_bytes`, then fall back to `treedb_disk_after_checkpoint.total_bytes` and `treedb_disk_after_load.total_bytes` for older runs.
- TreeDB physical bytes come from the matrix runner's `du` measurement of the isolated TreeDB directory.
- MongoDB `dbStats.dataSize` is uncompressed logical document size, not disk usage.
- MongoDB `dbStats.totalSize` is reported separately because it can diverge sharply from the isolated data-directory `du` measurement on small WiredTiger workloads.
- MongoDB physical bytes are the preferred local disk comparison when the matrix runner has an isolated data directory, such as Docker mode.
- Wall ops/sec values include the full benchmark phase loop. Sampled ops/sec values isolate the timed driver/gateway call inside each phase and are useful when prebuilt fixtures are enabled.
- `concurrent_id_find_one_rN` phases are an `_id` read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Read Sweep section when present.
- `concurrent_email_find_one_rN` phases are an email read throughput sweep over `N` concurrent readers, and are also grouped in the Concurrent Read Sweep section when present.
- `concurrent_age_range_*_rN` phases are an age range-read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Range Read Sweep section when present.
- Range-query benchmark rows use explicit phase names: `age_range_indexed_limit_10` means `-range-index` created `age_1`; `age_range_scan_limit_10` means bounded scan fallback.
- Main comparison tables label the MongoDB config chosen as the baseline. In multi-mode matrices, all other MongoDB rows remain visible in the Mongo Matrix Rows section.
