# Mongo API Client-Mode Load Matrix

- generated_at: `2026-11-20T18:21:10Z`
- matrix: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/matrix.tsv`
- comparison cells: `15`
- targets: `treedb`, `mongo`

## Highlights

- Largest TreeDB ops/sec lead: `load_insert_many` at 100000 docs / 0 indexes / `treedb_bson_raw_wire`, 545749 ops/sec vs 222780 ops/sec (2.45x TreeDB / MongoDB).
- No phase in this matrix had MongoDB ahead on ops/sec.
- Largest cell disk: at 100000 docs / 2 indexes / `treedb_bson_driver_command_raw`, TreeDB maintenance snapshot used 9.87 MiB (103.5 B/doc), TreeDB physical du was 9.96 MiB, MongoDB dbStats dataSize was 27.85 MiB, MongoDB dbStats totalSize was 9.18 MiB, and MongoDB physical du was 209.55 MiB (2197.3 B/doc).

## Disk Summary

| docs | indexes | range index | TreeDB config | MongoDB baseline config | TreeDB snapshot | TreeDB bytes | TreeDB bytes/doc | TreeDB physical du | TreeDB physical bytes/doc | MongoDB dbStats dataSize | MongoDB dbStats totalSize | MongoDB physical du | MongoDB physical bytes/doc | TreeDB / MongoDB dbStats totalSize | TreeDB / MongoDB physical |
| ---: | ---: | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 0 | false | `treedb_bson_driver` | `mongo_driver` | maintenance | 8.63 MiB | 90.5 B | 8.71 MiB | 91.4 B | 27.85 MiB | 6.16 MiB | 206.53 MiB | 2165.6 B | 1.40x | 0.04x |
| 100000 | 0 | false | `treedb_bson_driver_command` | `mongo_driver` | maintenance | 8.63 MiB | 90.5 B | 8.71 MiB | 91.4 B | 27.85 MiB | 6.16 MiB | 206.53 MiB | 2165.6 B | 1.40x | 0.04x |
| 100000 | 0 | false | `treedb_bson_driver_command_raw` | `mongo_driver` | maintenance | 8.63 MiB | 90.5 B | 8.71 MiB | 91.4 B | 27.85 MiB | 6.16 MiB | 206.53 MiB | 2165.6 B | 1.40x | 0.04x |
| 100000 | 0 | false | `treedb_bson_raw_wire` | `mongo_driver` | maintenance | 8.63 MiB | 90.5 B | 8.71 MiB | 91.4 B | 27.85 MiB | 6.16 MiB | 206.53 MiB | 2165.6 B | 1.40x | 0.04x |
| 100000 | 0 | false | `treedb_bson_raw_wire_tcp` | `mongo_driver` | maintenance | 8.63 MiB | 90.5 B | 8.71 MiB | 91.4 B | 27.85 MiB | 6.16 MiB | 206.53 MiB | 2165.6 B | 1.40x | 0.04x |
| 100000 | 1 | false | `treedb_bson_driver` | `mongo_driver` | maintenance | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.64 MiB | 209.04 MiB | 2191.9 B | 1.08x | 0.05x |
| 100000 | 1 | false | `treedb_bson_driver_command` | `mongo_driver` | maintenance | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.64 MiB | 209.04 MiB | 2191.9 B | 1.08x | 0.05x |
| 100000 | 1 | false | `treedb_bson_driver_command_raw` | `mongo_driver` | maintenance | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.64 MiB | 209.04 MiB | 2191.9 B | 1.08x | 0.05x |
| 100000 | 1 | false | `treedb_bson_raw_wire` | `mongo_driver` | maintenance | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.64 MiB | 209.04 MiB | 2191.9 B | 1.08x | 0.05x |
| 100000 | 1 | false | `treedb_bson_raw_wire_tcp` | `mongo_driver` | maintenance | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.64 MiB | 209.04 MiB | 2191.9 B | 1.08x | 0.05x |
| 100000 | 2 | false | `treedb_bson_driver` | `mongo_driver` | maintenance | 9.84 MiB | 103.2 B | 9.93 MiB | 104.1 B | 27.85 MiB | 9.18 MiB | 209.55 MiB | 2197.3 B | 1.07x | 0.05x |
| 100000 | 2 | false | `treedb_bson_driver_command` | `mongo_driver` | maintenance | 9.84 MiB | 103.2 B | 9.93 MiB | 104.1 B | 27.85 MiB | 9.18 MiB | 209.55 MiB | 2197.3 B | 1.07x | 0.05x |
| 100000 | 2 | false | `treedb_bson_driver_command_raw` | `mongo_driver` | maintenance | 9.87 MiB | 103.5 B | 9.96 MiB | 104.4 B | 27.85 MiB | 9.18 MiB | 209.55 MiB | 2197.3 B | 1.08x | 0.05x |
| 100000 | 2 | false | `treedb_bson_raw_wire` | `mongo_driver` | maintenance | 9.87 MiB | 103.5 B | 9.96 MiB | 104.4 B | 27.85 MiB | 9.18 MiB | 209.55 MiB | 2197.3 B | 1.08x | 0.05x |
| 100000 | 2 | false | `treedb_bson_raw_wire_tcp` | `mongo_driver` | maintenance | 9.87 MiB | 103.5 B | 9.96 MiB | 104.4 B | 27.85 MiB | 9.18 MiB | 209.55 MiB | 2197.3 B | 1.08x | 0.05x |

## Mongo Matrix Rows

These rows list every MongoDB matrix row, including non-baseline client-mode rows that are not used as the TreeDB comparison baseline.

| docs | indexes | range index | config | phase | ops/sec | sampled ops/sec | p95 us | dbStats totalSize | physical du | raw json |
| ---: | ---: | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 100000 | 0 | false | `mongo_driver` | `load_insert_many` | 222780 | 29976 | 448773 | 6.16 MiB | 206.53 MiB | `raw/mongo_driver_docs_100000_idx_0.json` |
| 100000 | 0 | false | `mongo_driver_command` | `load_insert_many` | 268899 | 36648 | 371784 | 6.18 MiB | 206.54 MiB | `raw/mongo_driver_command_docs_100000_idx_0.json` |
| 100000 | 0 | false | `mongo_driver_command_raw` | `load_insert_many` | 278047 | 38362 | 359607 | 6.16 MiB | 206.53 MiB | `raw/mongo_driver_command_raw_docs_100000_idx_0.json` |
| 100000 | 0 | false | `mongo_driver_unack` | `load_insert_many` | 247000 | 104568 | 106308 | 6.16 MiB | 206.52 MiB | `raw/mongo_driver_unack_docs_100000_idx_0.json` |
| 100000 | 1 | false | `mongo_driver` | `load_insert_many` | 233382 | 35841 | 336944 | 8.64 MiB | 209.04 MiB | `raw/mongo_driver_docs_100000_idx_1.json` |
| 100000 | 1 | false | `mongo_driver_command` | `load_insert_many` | 300438 | 46162 | 263770 | 8.67 MiB | 209.07 MiB | `raw/mongo_driver_command_docs_100000_idx_1.json` |
| 100000 | 1 | false | `mongo_driver_command_raw` | `load_insert_many` | 297858 | 44890 | 280569 | 8.65 MiB | 209.02 MiB | `raw/mongo_driver_command_raw_docs_100000_idx_1.json` |
| 100000 | 1 | false | `mongo_driver_unack` | `load_insert_many` | 184554 | 103356 | 112871 | 8.64 MiB | 209.02 MiB | `raw/mongo_driver_unack_docs_100000_idx_1.json` |
| 100000 | 2 | false | `mongo_driver` | `load_insert_many` | 197923 | 29979 | 398599 | 9.18 MiB | 209.55 MiB | `raw/mongo_driver_docs_100000_idx_2.json` |
| 100000 | 2 | false | `mongo_driver_command` | `load_insert_many` | 223594 | 36237 | 323000 | 9.17 MiB | 209.54 MiB | `raw/mongo_driver_command_docs_100000_idx_2.json` |
| 100000 | 2 | false | `mongo_driver_command_raw` | `load_insert_many` | 241889 | 36292 | 329174 | 9.17 MiB | 209.54 MiB | `raw/mongo_driver_command_raw_docs_100000_idx_2.json` |
| 100000 | 2 | false | `mongo_driver_unack` | `load_insert_many` | 157516 | 105446 | 109991 | 9.16 MiB | 209.54 MiB | `raw/mongo_driver_unack_docs_100000_idx_2.json` |


## Ops/Sec Summary

| docs | indexes | range index | range mode | TreeDB config | MongoDB baseline config | phase | TreeDB wall ops/sec | TreeDB sampled ops/sec | MongoDB wall ops/sec | MongoDB sampled ops/sec | TreeDB / MongoDB wall | TreeDB / MongoDB sampled | TreeDB p95 us | MongoDB p95 us |
| ---: | ---: | --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 0 | false | n/a | `treedb_bson_driver` | `mongo_driver` | `load_insert_many` | 389328 | 78883 | 222780 | 29976 | 1.75x | 2.63x | 166909 | 448773 |
| 100000 | 0 | false | n/a | `treedb_bson_driver` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver_command` | `mongo_driver` | `load_insert_many` | 499670 | 141558 | 222780 | 29976 | 2.24x | 4.72x | 112479 | 448773 |
| 100000 | 0 | false | n/a | `treedb_bson_driver_command` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver_command` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver_command` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver` | `load_insert_many` | 522446 | 127384 | 222780 | 29976 | 2.35x | 4.25x | 107551 | 448773 |
| 100000 | 0 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver_command_raw` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_raw_wire` | `mongo_driver` | `load_insert_many` | 545749 | 139387 | 222780 | 29976 | 2.45x | 4.65x | 101490 | 448773 |
| 100000 | 0 | false | n/a | `treedb_bson_raw_wire` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_raw_wire` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_raw_wire` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `load_insert_many` | 538618 | 133505 | 222780 | 29976 | 2.42x | 4.45x | 103686 | 448773 |
| 100000 | 0 | false | n/a | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver` | `mongo_driver` | `load_insert_many` | 339641 | 73024 | 233382 | 35841 | 1.46x | 2.04x | 186770 | 336944 |
| 100000 | 1 | false | n/a | `treedb_bson_driver` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver_command` | `mongo_driver` | `load_insert_many` | 440579 | 109840 | 233382 | 35841 | 1.89x | 3.06x | 121484 | 336944 |
| 100000 | 1 | false | n/a | `treedb_bson_driver_command` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver_command` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver_command` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver` | `load_insert_many` | 450892 | 107959 | 233382 | 35841 | 1.93x | 3.01x | 134172 | 336944 |
| 100000 | 1 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver_command_raw` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_raw_wire` | `mongo_driver` | `load_insert_many` | 433636 | 138560 | 233382 | 35841 | 1.86x | 3.87x | 107039 | 336944 |
| 100000 | 1 | false | n/a | `treedb_bson_raw_wire` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_raw_wire` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_raw_wire` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `load_insert_many` | 475069 | 139439 | 233382 | 35841 | 2.04x | 3.89x | 104727 | 336944 |
| 100000 | 1 | false | n/a | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver` | `mongo_driver` | `load_insert_many` | 330985 | 70477 | 197923 | 29979 | 1.67x | 2.35x | 192018 | 398599 |
| 100000 | 2 | false | n/a | `treedb_bson_driver` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver_command` | `mongo_driver` | `load_insert_many` | 430846 | 112337 | 197923 | 29979 | 2.18x | 3.75x | 129578 | 398599 |
| 100000 | 2 | false | n/a | `treedb_bson_driver_command` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver_command` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver_command` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver` | `load_insert_many` | 431045 | 124461 | 197923 | 29979 | 2.18x | 4.15x | 114921 | 398599 |
| 100000 | 2 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver_command_raw` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_raw_wire` | `mongo_driver` | `load_insert_many` | 458745 | 137313 | 197923 | 29979 | 2.32x | 4.58x | 108401 | 398599 |
| 100000 | 2 | false | n/a | `treedb_bson_raw_wire` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_raw_wire` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_raw_wire` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `load_insert_many` | 452385 | 137376 | 197923 | 29979 | 2.29x | 4.58x | 100803 | 398599 |
| 100000 | 2 | false | n/a | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_raw_wire_tcp` | `mongo_driver` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |

## Raw Inputs

| docs | indexes | range index | config | target | raw json | profile dir |
| ---: | ---: | --- | --- | --- | --- | --- |
| 100000 | 0 | false | `treedb_bson_driver` | treedb | `raw/treedb_bson_driver_docs_100000_idx_0.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_driver_docs_100000_idx_0` |
| 100000 | 0 | false | `treedb_bson_driver_command` | treedb | `raw/treedb_bson_driver_command_docs_100000_idx_0.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_driver_command_docs_100000_idx_0` |
| 100000 | 0 | false | `treedb_bson_driver_command_raw` | treedb | `raw/treedb_bson_driver_command_raw_docs_100000_idx_0.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_driver_command_raw_docs_100000_idx_0` |
| 100000 | 0 | false | `treedb_bson_raw_wire` | treedb | `raw/treedb_bson_raw_wire_docs_100000_idx_0.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_raw_wire_docs_100000_idx_0` |
| 100000 | 0 | false | `treedb_bson_raw_wire_tcp` | treedb | `raw/treedb_bson_raw_wire_tcp_docs_100000_idx_0.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_raw_wire_tcp_docs_100000_idx_0` |
| 100000 | 1 | false | `treedb_bson_driver` | treedb | `raw/treedb_bson_driver_docs_100000_idx_1.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_driver_docs_100000_idx_1` |
| 100000 | 1 | false | `treedb_bson_driver_command` | treedb | `raw/treedb_bson_driver_command_docs_100000_idx_1.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_driver_command_docs_100000_idx_1` |
| 100000 | 1 | false | `treedb_bson_driver_command_raw` | treedb | `raw/treedb_bson_driver_command_raw_docs_100000_idx_1.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_driver_command_raw_docs_100000_idx_1` |
| 100000 | 1 | false | `treedb_bson_raw_wire` | treedb | `raw/treedb_bson_raw_wire_docs_100000_idx_1.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_raw_wire_docs_100000_idx_1` |
| 100000 | 1 | false | `treedb_bson_raw_wire_tcp` | treedb | `raw/treedb_bson_raw_wire_tcp_docs_100000_idx_1.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_raw_wire_tcp_docs_100000_idx_1` |
| 100000 | 2 | false | `treedb_bson_driver` | treedb | `raw/treedb_bson_driver_docs_100000_idx_2.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_driver_docs_100000_idx_2` |
| 100000 | 2 | false | `treedb_bson_driver_command` | treedb | `raw/treedb_bson_driver_command_docs_100000_idx_2.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_driver_command_docs_100000_idx_2` |
| 100000 | 2 | false | `treedb_bson_driver_command_raw` | treedb | `raw/treedb_bson_driver_command_raw_docs_100000_idx_2.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_driver_command_raw_docs_100000_idx_2` |
| 100000 | 2 | false | `treedb_bson_raw_wire` | treedb | `raw/treedb_bson_raw_wire_docs_100000_idx_2.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_raw_wire_docs_100000_idx_2` |
| 100000 | 2 | false | `treedb_bson_raw_wire_tcp` | treedb | `raw/treedb_bson_raw_wire_tcp_docs_100000_idx_2.json` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_client_mode_load_matrix_1m/profiles/treedb_bson_raw_wire_tcp_docs_100000_idx_2` |
| 100000 | 0 | false | `mongo_driver` | mongo | `raw/mongo_driver_docs_100000_idx_0.json` | n/a |
| 100000 | 0 | false | `mongo_driver_command` | mongo | `raw/mongo_driver_command_docs_100000_idx_0.json` | n/a |
| 100000 | 0 | false | `mongo_driver_command_raw` | mongo | `raw/mongo_driver_command_raw_docs_100000_idx_0.json` | n/a |
| 100000 | 0 | false | `mongo_driver_unack` | mongo | `raw/mongo_driver_unack_docs_100000_idx_0.json` | n/a |
| 100000 | 1 | false | `mongo_driver` | mongo | `raw/mongo_driver_docs_100000_idx_1.json` | n/a |
| 100000 | 1 | false | `mongo_driver_command` | mongo | `raw/mongo_driver_command_docs_100000_idx_1.json` | n/a |
| 100000 | 1 | false | `mongo_driver_command_raw` | mongo | `raw/mongo_driver_command_raw_docs_100000_idx_1.json` | n/a |
| 100000 | 1 | false | `mongo_driver_unack` | mongo | `raw/mongo_driver_unack_docs_100000_idx_1.json` | n/a |
| 100000 | 2 | false | `mongo_driver` | mongo | `raw/mongo_driver_docs_100000_idx_2.json` | n/a |
| 100000 | 2 | false | `mongo_driver_command` | mongo | `raw/mongo_driver_command_docs_100000_idx_2.json` | n/a |
| 100000 | 2 | false | `mongo_driver_command_raw` | mongo | `raw/mongo_driver_command_raw_docs_100000_idx_2.json` | n/a |
| 100000 | 2 | false | `mongo_driver_unack` | mongo | `raw/mongo_driver_unack_docs_100000_idx_2.json` | n/a |

## Notes

- TreeDB disk bytes prefer `treedb_disk_after_maintenance.total_bytes`, then fall back to `treedb_disk_after_checkpoint.total_bytes` and `treedb_disk_after_load.total_bytes` for older runs.
- TreeDB physical bytes come from the matrix runner's `du` measurement of the isolated TreeDB directory.
- MongoDB `dbStats.dataSize` is uncompressed logical document size, not disk usage.
- MongoDB `dbStats.totalSize` is reported separately because it can diverge sharply from the isolated data-directory `du` measurement on small WiredTiger workloads.
- MongoDB physical bytes are the preferred local disk comparison when the matrix runner has an isolated data directory, such as Docker mode.
- Wall ops/sec values include the full benchmark phase loop. Sampled ops/sec values isolate the timed driver/gateway call inside each phase and are useful when prebuilt fixtures are enabled.
- `concurrent_id_find_one_rN` phases are an `_id` read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Read Sweep section when present.
- `concurrent_email_find_one_rN` phases are an email read throughput sweep over `N` concurrent readers, and are also grouped in the Concurrent Read Sweep section when present.
- `concurrent_age_range_*_rN` phases are an age range-read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Range Read Sweep section when present.
- Range-query benchmark rows use explicit phase names: `age_range_indexed_limit_10` means `-range-index` created `age_1`; `age_range_scan_limit_10` means bounded scan fallback.
- Main comparison tables label the MongoDB config chosen as the baseline. In multi-mode matrices, all other MongoDB rows remain visible in the Mongo Matrix Rows section.
