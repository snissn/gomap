# Mongo API InsertMany Producer Scaling, producers=8

- generated_at: `2026-11-20T18:22:01Z`
- matrix: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_8/matrix.tsv`
- comparison cells: `3`
- targets: `treedb`, `mongo`

## Highlights

- Largest TreeDB ops/sec lead: `load_insert_many` at 100000 docs / 0 indexes / `treedb_bson_driver_command_raw`, 509169 ops/sec vs 292525 ops/sec (1.74x TreeDB / MongoDB).
- Largest MongoDB ops/sec lead: `load_insert_many` at 100000 docs / 2 indexes / `treedb_bson_driver_command_raw`, 300168 ops/sec vs 304003 ops/sec (0.99x TreeDB / MongoDB).
- Largest cell disk: at 100000 docs / 2 indexes / `treedb_bson_driver_command_raw`, TreeDB maintenance snapshot used 9.84 MiB (103.2 B/doc), TreeDB physical du was 9.93 MiB, MongoDB dbStats dataSize was 27.85 MiB, MongoDB dbStats totalSize was 9.16 MiB, and MongoDB physical du was 209.53 MiB (2197.1 B/doc).

## Disk Summary

| docs | indexes | range index | TreeDB config | MongoDB baseline config | TreeDB snapshot | TreeDB bytes | TreeDB bytes/doc | TreeDB physical du | TreeDB physical bytes/doc | MongoDB dbStats dataSize | MongoDB dbStats totalSize | MongoDB physical du | MongoDB physical bytes/doc | TreeDB / MongoDB dbStats totalSize | TreeDB / MongoDB physical |
| ---: | ---: | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 0 | false | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | maintenance | 8.63 MiB | 90.5 B | 8.71 MiB | 91.4 B | 27.85 MiB | 6.16 MiB | 206.53 MiB | 2165.6 B | 1.40x | 0.04x |
| 100000 | 1 | false | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | maintenance | 9.35 MiB | 98.0 B | 9.43 MiB | 98.9 B | 27.85 MiB | 8.63 MiB | 209.00 MiB | 2191.6 B | 1.08x | 0.05x |
| 100000 | 2 | false | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | maintenance | 9.84 MiB | 103.2 B | 9.93 MiB | 104.1 B | 27.85 MiB | 9.16 MiB | 209.53 MiB | 2197.1 B | 1.07x | 0.05x |

## Mongo Matrix Rows

These rows list every MongoDB matrix row, including non-baseline client-mode rows that are not used as the TreeDB comparison baseline.

| docs | indexes | range index | config | phase | ops/sec | sampled ops/sec | p95 us | dbStats totalSize | physical du | raw json |
| ---: | ---: | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 100000 | 0 | false | `mongo_driver_command_raw` | `load_insert_many` | 292525 | 36867 | 291094 | 6.16 MiB | 206.53 MiB | `raw/mongo_driver_command_raw_docs_100000_idx_0.json` |
| 100000 | 1 | false | `mongo_driver_command_raw` | `load_insert_many` | 361321 | 46555 | 26927 | 8.63 MiB | 209.00 MiB | `raw/mongo_driver_command_raw_docs_100000_idx_1.json` |
| 100000 | 2 | false | `mongo_driver_command_raw` | `load_insert_many` | 304003 | 38679 | 33078 | 9.16 MiB | 209.53 MiB | `raw/mongo_driver_command_raw_docs_100000_idx_2.json` |


## Ops/Sec Summary

| docs | indexes | range index | range mode | TreeDB config | MongoDB baseline config | phase | TreeDB wall ops/sec | TreeDB sampled ops/sec | MongoDB wall ops/sec | MongoDB sampled ops/sec | TreeDB / MongoDB wall | TreeDB / MongoDB sampled | TreeDB p95 us | MongoDB p95 us |
| ---: | ---: | --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100000 | 0 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `load_insert_many` | 509169 | 100814 | 292525 | 36867 | 1.74x | 2.73x | 32181 | 291094 |
| 100000 | 0 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | `scan` | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 0 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `load_insert_many` | 410151 | 95719 | 361321 | 46555 | 1.14x | 2.06x | 20414 | 26927 |
| 100000 | 1 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | `scan` | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 1 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `load_insert_many` | 300168 | 83619 | 304003 | 38679 | 0.99x | 2.16x | 21174 | 33078 |
| 100000 | 2 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `id_find_one` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | `scan` | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `age_range_scan_limit_10` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |
| 100000 | 2 | false | n/a | `treedb_bson_driver_command_raw` | `mongo_driver_command_raw` | `id_update_set` | 0 | n/a | 0 | n/a | n/a | n/a | 0 | 0 |

## Raw Inputs

| docs | indexes | range index | config | target | raw json | profile dir |
| ---: | ---: | --- | --- | --- | --- | --- |
| 100000 | 0 | false | `treedb_bson_driver_command_raw` | treedb | `raw/treedb_bson_driver_command_raw_docs_100000_idx_0.json` | n/a |
| 100000 | 1 | false | `treedb_bson_driver_command_raw` | treedb | `raw/treedb_bson_driver_command_raw_docs_100000_idx_1.json` | n/a |
| 100000 | 2 | false | `treedb_bson_driver_command_raw` | treedb | `raw/treedb_bson_driver_command_raw_docs_100000_idx_2.json` | n/a |
| 100000 | 0 | false | `mongo_driver_command_raw` | mongo | `raw/mongo_driver_command_raw_docs_100000_idx_0.json` | n/a |
| 100000 | 1 | false | `mongo_driver_command_raw` | mongo | `raw/mongo_driver_command_raw_docs_100000_idx_1.json` | n/a |
| 100000 | 2 | false | `mongo_driver_command_raw` | mongo | `raw/mongo_driver_command_raw_docs_100000_idx_2.json` | n/a |

## Notes

- TreeDB disk bytes prefer `treedb_disk_after_maintenance.total_bytes`, then fall back to `treedb_disk_after_checkpoint.total_bytes` and `treedb_disk_after_load.total_bytes` for older runs.
- TreeDB physical bytes come from the matrix runner's `du` measurement of the isolated TreeDB directory.
- MongoDB `dbStats.dataSize` is uncompressed logical document size, not disk usage.
- MongoDB `dbStats.totalSize` is reported separately because it can diverge sharply from the isolated data-directory `du` measurement on small WiredTiger workloads.
- MongoDB physical bytes are the preferred local disk comparison when the matrix runner has an isolated data directory, such as Docker mode.
- Wall ops/sec values include the full benchmark phase loop. Sampled ops/sec values isolate the timed driver/gateway call inside each phase and are useful when prebuilt fixtures are enabled.
- `concurrent_id_find_one_rN` phases are an `_id` read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Read Sweep section when present.
- `concurrent_email_find_one_rN` phases are an email read throughput sweep over `N` concurrent readers, and are also grouped in the Concurrent Read Sweep section when present.
- `concurrent_age_range_*_rN` phases are an age range-read throughput sweep over `N` concurrent readers, and are grouped in the Concurrent Range Read Sweep section when present.
- Range-query benchmark rows use explicit phase names: `age_range_indexed_limit_10` means `-range-index` created `age_1`; `age_range_scan_limit_10` means bounded scan fallback.
- Main comparison tables label the MongoDB config chosen as the baseline. In multi-mode matrices, all other MongoDB rows remain visible in the Mongo Matrix Rows section.
