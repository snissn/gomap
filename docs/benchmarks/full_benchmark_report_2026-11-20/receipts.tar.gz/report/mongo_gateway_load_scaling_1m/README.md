# Mongo Gateway InsertMany Producer Scaling Bundle

- output directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m`
- aggregate summary TSV: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/summary.tsv`
- producer run index: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producer_runs.tsv`
- docs: `100000`
- secondary indexes: `0 1 2`
- batch size: `1000`
- load batches: `100`
- producer counts: `1 2 4 8 16 32`
- MongoDB mode: `docker`
- MongoDB image: `mongo@sha256:7abfba0d07c9330373f8173981ea4d09cd8a82cdf0e86ccaf7008848d1d24f62`
- MongoDB URI: `mongodb://127.0.0.1:27017`
- MongoDB compact: `true`
- MongoDB Go driver pool options: `maxPoolSize=128 maxConnecting=32`
- timeout: `120m`

Each `producers_<N>/` directory is a normal load-only `mongo_gateway_compare.sh`
bundle with raw JSON, `matrix.tsv`, `summary.tsv`, and `report.md`.

The aggregate `summary.tsv` keeps one header and only the `load_insert_many`
rows from each producer run summary.
Use the `insert_producers`, `effective_producers`, and `load_batch_count`
columns to distinguish requested producer counts from capped effective counts.
