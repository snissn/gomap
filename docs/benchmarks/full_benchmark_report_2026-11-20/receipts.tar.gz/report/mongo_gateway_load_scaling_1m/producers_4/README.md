# Mongo Gateway Comparison Bundle

- output directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_4`
- report: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_4/report.md`
- summary TSV: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_4/summary.tsv`
- matrix TSV: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_4/matrix.tsv`
- raw JSON directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_4/raw`
- TreeDB data directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_4/treedb_data`
- MongoDB data directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_4/mongodb_data`
- docs list: `100000`
- secondary-index list: `0 1 2`
- batch size: `1000`
- insert producers: `4`
- MongoDB Go driver pool options: `maxPoolSize=128 minPoolSize=0 maxConnecting=32`
- prebuild documents: `true`
- range index: `false`
- TreeDB pprof profiles: `false`
- profile directory: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_4/profiles`
- reads: `0`
- range reads: `0`
- updates: `0`
- deletes: `0`
- concurrent read kinds: `id`
- concurrent readers: `0`
- concurrent reader sweep: `none`
- concurrent reads: `0`
- concurrent range readers: `0`
- concurrent range reader sweep: `none`
- concurrent range reads: `0`
- concurrent writers: `0`
- concurrent writer sweep: `none`
- concurrent writes: `0`
- MongoDB mode: `docker`
- MongoDB compact before final stats: `true`
- MongoDB image: `mongo@sha256:7abfba0d07c9330373f8173981ea4d09cd8a82cdf0e86ccaf7008848d1d24f62`
- MongoDB client modes: `driver-command-raw`
- benchmark timeout: `120m`
- TreeDB profile: `bench_unsafe`
- TreeDB document formats: `bson`
- TreeDB client modes: `driver-command-raw`
- TreeDB root storage: `data=compressed index_state=compressed index=compressed`
- TreeDB maintenance: `full`
- TreeDB read state: `settled`

Regenerate from the raw run index:

```sh
GOWORK=off go run ./cmd/mongo_gateway_compare_report \
  -matrix "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_4/matrix.tsv" \
  -report "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_4/report.md" \
  -summary "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/mongo_gateway_load_scaling_1m/producers_4/summary.tsv" \
  -title "Mongo API InsertMany Producer Scaling, producers=4"
```
