# Bench Profile Insights

- generated: `2026-11-20T18:08:25Z`
- profiles dir: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests`
- binary: `./bin/unified-bench`
- ops source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/benchprof_results.json`

## Scan Ops/Sec

| Label | Full Scan | Prefix Scan | Prefix / Full |
|---|---:|---:|---:|
| TreeDB | 2,790,190 | 3,716,417 | 1.33x |

## CPU Hotspots

### batch_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_batch_delete_treedb.pprof`
- total samples: `150ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 60ms | 40.00% | 80ms | 53.33% | `runtime.scanObject` |
| 10ms | 6.67% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 10ms | 6.67% | 10ms | 6.67% | `internal/sync.(*Mutex).Lock (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.(*mspan).moveInlineMarks` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.findRunnable` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.mapaccess2_faststr` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.scanblock` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.tryDeferToSpanScan` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.typePointers.next` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 40ms | 26.67% | `main.main` |
| 0 | 0.00% | 40ms | 26.67% | `main.runBenchmark` |
| 0 | 0.00% | 30ms | 20.00% | `main.runBenchmark.func26` |
| 0 | 0.00% | 10ms | 6.67% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 10ms | 6.67% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 10ms | 6.67% | `runtime.(*sweepLocked).sweep` |
| 0 | 0.00% | 10ms | 6.67% | `runtime.bgsweep` |
| 0 | 0.00% | 90ms | 60.00% | `runtime.gcBgMarkWorker` |

### batch_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_batch_random_treedb.pprof`
- total samples: `160ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 40ms | 25.00% | 40ms | 25.00% | `runtime.tryDeferToSpanScan` |
| 20ms | 12.50% | 20ms | 12.50% | `runtime.memmove` |
| 20ms | 12.50% | 90ms | 56.25% | `runtime.scanObject` |
| 20ms | 12.50% | 30ms | 18.75% | `runtime.typePointers.next` |
| 10ms | 6.25% | 30ms | 18.75% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setWithMVCCInput` |
| 10ms | 6.25% | 20ms | 12.50% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 10ms | 6.25% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/caching.pointEntryRevisionStats (inline)` |
| 10ms | 6.25% | 10ms | 6.25% | `math/rand.(*Rand).Int31n` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.pMask.read (inline)` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.typePointers.nextFast (inline)` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Set` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetWithRevision (inline)` |
| 0 | 0.00% | 20ms | 12.50% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 20ms | 12.50% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).cloneKeyValue` |
| 0 | 0.00% | 20ms | 12.50% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 20ms | 12.50% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).prepareEntryRevisionAssignment` |
| 0 | 0.00% | 20ms | 12.50% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Set` |
| 0 | 0.00% | 60ms | 37.50% | `main.main` |
| 0 | 0.00% | 60ms | 37.50% | `main.runBenchmark` |
| 0 | 0.00% | 60ms | 37.50% | `main.runBenchmark.func25` |
| 0 | 0.00% | 10ms | 6.25% | `math/rand.(*Rand).Intn` |
| 0 | 0.00% | 10ms | 6.25% | `runtime.findRunnable` |
| 0 | 0.00% | 90ms | 56.25% | `runtime.gcBgMarkWorker` |

### batch_small_seq (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_batch_small_seq_treedb.pprof`
- total samples: `210ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 80ms | 38.10% | 80ms | 38.10% | `runtime.memclrNoHeapPointers` |
| 50ms | 23.81% | 80ms | 38.10% | `runtime.scanObject` |
| 30ms | 14.29% | 30ms | 14.29% | `runtime.tryDeferToSpanScan` |
| 10ms | 4.76% | 10ms | 4.76% | `aeshashbody` |
| 10ms | 4.76% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/caching.batchShardFirstLast (inline)` |
| 10ms | 4.76% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` |
| 10ms | 4.76% | 10ms | 4.76% | `internal/runtime/atomic.(*Uint32).CompareAndSwap` |
| 10ms | 4.76% | 10ms | 4.76% | `runtime.traceAcquireEnabled` |
| 0 | 0.00% | 70ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Close` |
| 0 | 0.00% | 30ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 30ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).tryApplySmallSelectedSortedShard` |
| 0 | 0.00% | 30ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 30ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 30ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 70ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).putBatchEntries` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/caching.reserveAppendOnlyMemtableEntries` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/caching.reserveMemtableEntries` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ApplyCopySelectedSortedBatchTrusted` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ReserveAdditionalEntries` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).canAppendTrustedSortedFirstKeyLocked` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).growEntriesLocked` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).reserveAdditionalEntriesLocked` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.putAppendOnlyEntries` |
| 0 | 0.00% | 70ms | 33.33% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Close` |
| 0 | 0.00% | 30ms | 14.29% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |

### batch_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_batch_write_treedb.pprof`
- total samples: `120ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 25.00% | 30ms | 25.00% | `runtime.typePointers.next` |
| 20ms | 16.67% | 70ms | 58.33% | `runtime.scanObject` |
| 20ms | 16.67% | 20ms | 16.67% | `runtime.tryDeferToSpanScan` |
| 10ms | 8.33% | 10ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).noteEntryAppend` |
| 10ms | 8.33% | 10ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.pointEntryRevisionStats (inline)` |
| 10ms | 8.33% | 10ms | 8.33% | `runtime.(*sweepLocker).tryAcquire` |
| 10ms | 8.33% | 10ms | 8.33% | `runtime.findObject` |
| 10ms | 8.33% | 10ms | 8.33% | `runtime.mapaccess2_fast64` |
| 0 | 0.00% | 10ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetView` |
| 0 | 0.00% | 10ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetViewValidatedWithRevision (inline)` |
| 0 | 0.00% | 10ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetViewWithRevision` |
| 0 | 0.00% | 10ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 10ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setViewValidatedWithMVCCInput` |
| 0 | 0.00% | 10ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 10ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 10ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 10ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).prepareEntryRevisionAssignment` |
| 0 | 0.00% | 10ms | 8.33% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 10ms | 8.33% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).SetView` |
| 0 | 0.00% | 30ms | 25.00% | `main.main` |
| 0 | 0.00% | 30ms | 25.00% | `main.runBenchmark` |
| 0 | 0.00% | 20ms | 16.67% | `main.runBenchmark.func23` |
| 0 | 0.00% | 20ms | 16.67% | `main.runBenchmark.func6` |
| 0 | 0.00% | 10ms | 8.33% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 10ms | 8.33% | `main.writeAllocsSnapshotTemp` |

### batch_write_steady (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_batch_write_steady_treedb.pprof`
- total samples: `200ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 20ms | 10.00% | 20ms | 10.00% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 20ms | 10.00% | 20ms | 10.00% | `internal/runtime/syscall/linux.Syscall6` |
| 10ms | 5.00% | 10ms | 5.00% | `encoding/binary.littleEndian.Uint64 (inline)` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).reset (inline)` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 10ms | 5.00% | 20ms | 10.00% | `github.com/snissn/go-crc32-asm.updateIEEE` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setViewValidatedWithMVCCInput` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).up` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithCOWPolicy` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadMissAdmissionLane).resetReadMissCandidateLocked` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ApplyCopySortedBatchWithValueCopierTrusted` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/node.(*Builder).leafColumnarV2AppendBytes` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/node.(*Builder).releaseInternalBaseDeltaScratch` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).applySpanNativeWithPrepared` |
| 10ms | 5.00% | 10ms | 5.00% | `runtime.memclrNoHeapPointers` |
| 10ms | 5.00% | 10ms | 5.00% | `runtime.memmove` |
| 10ms | 5.00% | 10ms | 5.00% | `sync/atomic.(*Uint64).Add` |
| 0 | 0.00% | 20ms | 10.00% | `github.com/pierrec/lz4/v4.(*Compressor).CompressBlock` |
| 0 | 0.00% | 20ms | 10.00% | `github.com/pierrec/lz4/v4.UncompressBlock` |
| 0 | 0.00% | 20ms | 10.00% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 0 | 0.00% | 20ms | 10.00% | `github.com/pierrec/lz4/v4/internal/lz4block.UncompressBlock` |
| 0 | 0.00% | 10ms | 5.00% | `github.com/snissn/go-crc32-asm.Checksum` |
| 0 | 0.00% | 20ms | 10.00% | `github.com/snissn/go-crc32-asm.Update` |
| 0 | 0.00% | 10ms | 5.00% | `github.com/snissn/go-crc32-asm.checksumIEEE` |

### checkpoint/batch_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_batch_delete_treedb.pprof`
- total samples: `630ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 170ms | 26.98% | 170ms | 26.98% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 60ms | 9.52% | 60ms | 9.52% | `runtime.memmove` |
| 30ms | 4.76% | 30ms | 4.76% | `cmpbody` |
| 30ms | 4.76% | 30ms | 4.76% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 30ms | 4.76% | 280ms | 44.44% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).mergeLeaf` |
| 20ms | 3.17% | 60ms | 9.52% | `github.com/snissn/gomap/TreeDB/node.(*Builder).addLeafEntryColumnarPrefixV2` |
| 20ms | 3.17% | 20ms | 3.17% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2ValueMetaAt` |
| 20ms | 3.17% | 20ms | 3.17% | `internal/runtime/syscall/linux.Syscall6` |
| 20ms | 3.17% | 20ms | 3.17% | `sync/atomic.(*Int32).Add (inline)` |
| 10ms | 1.59% | 10ms | 1.59% | `encoding/binary.littleEndian.PutUint64 (inline)` |
| 10ms | 1.59% | 20ms | 3.17% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).setViewWithMVCCInput` |
| 10ms | 1.59% | 30ms | 4.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogInternalObserved` |
| 10ms | 1.59% | 10ms | 1.59% | `github.com/snissn/gomap/TreeDB/caching.clearValueLogRecordValues (inline)` |
| 10ms | 1.59% | 80ms | 12.70% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 10ms | 1.59% | 20ms | 3.17% | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Less` |
| 10ms | 1.59% | 10ms | 1.59% | `github.com/snissn/gomap/TreeDB/db.(*DB).releasePendingValueLogAppendFileIDsFromEntries` |
| 10ms | 1.59% | 10ms | 1.59% | `github.com/snissn/gomap/TreeDB/db.(*leafPageLogWithRecordLengthHints).PreparedLeafPageAppends` |
| 10ms | 1.59% | 30ms | 4.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked.func1` |
| 10ms | 1.59% | 10ms | 1.59% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).UnsafeEntryWithRevision` |
| 10ms | 1.59% | 10ms | 1.59% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` |
| 10ms | 1.59% | 220ms | 34.92% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).ReadUnsafeTo` |
| 10ms | 1.59% | 180ms | 28.57% | `github.com/snissn/gomap/TreeDB/internal/valuelog.decodeFramePayloadTo` |
| 10ms | 1.59% | 10ms | 1.59% | `github.com/snissn/gomap/TreeDB/node.(*Builder).leafColumnarV2AppendBytes` |
| 10ms | 1.59% | 10ms | 1.59% | `github.com/snissn/gomap/TreeDB/node.sharedPrefixLen (inline)` |
| 10ms | 1.59% | 10ms | 1.59% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).stitchSpanNativeRecursive` |

### checkpoint/batch_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_batch_random_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/batch_small_seq (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_batch_small_seq_treedb.pprof`
- total samples: `1.15s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.69s | 60.00% | 0.69s | 60.00% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.12s | 10.43% | 0.12s | 10.43% | `internal/runtime/syscall/linux.Syscall6` |
| 0.03s | 2.61% | 0.03s | 2.61% | `cmpbody` |
| 0.02s | 1.74% | 0.02s | 1.74% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL256` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).PointRevisionStats` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).down` |
| 0.01s | 0.87% | 0.02s | 1.74% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).pop` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/gomap/TreeDB/caching.dispatchBackendValueLogReadBarrierWithSize` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/gomap/TreeDB/db.(*valueLogRefCounts).find` |
| 0.01s | 0.87% | 0.85s | 73.91% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).takeDecodeScratch` |
| 0.01s | 0.87% | 0.02s | 1.74% | `github.com/snissn/gomap/TreeDB/node.(*Builder).addLeafEntryColumnarPrefixV2` |
| 0.01s | 0.87% | 0.02s | 1.74% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafEntryViewWithRevision` |
| 0.01s | 0.87% | 0.04s | 3.48% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafValueView` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafEntryViewColumnarPrefixV2` |
| 0.01s | 0.87% | 0.02s | 1.74% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafValueViewColumnarPrefixV2` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2ValueMetaAt` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/gomap/TreeDB/node.getUint16At (inline)` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/gomap/TreeDB/page.DecodeLogRecordRef` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/gomap/TreeDB/zipper.(*mergeScratch).acquireLeafRefCacheBuildPage` |
| 0.01s | 0.87% | 0.01s | 0.87% | `github.com/snissn/gomap/TreeDB/zipper.validateLoadedLeafLogNode` |
| 0.01s | 0.87% | 0.01s | 0.87% | `internal/bytealg.LastIndexByteString (inline)` |
| 0.01s | 0.87% | 0.01s | 0.87% | `runtime.(*_panic).nextDefer` |

### checkpoint/batch_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_batch_write_treedb.pprof`
- total samples: `480ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 230ms | 47.92% | 230ms | 47.92% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 40ms | 8.33% | 80ms | 16.67% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 40ms | 8.33% | 40ms | 8.33% | `runtime.memmove` |
| 20ms | 4.17% | 20ms | 4.17% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).put (inline)` |
| 10ms | 2.08% | 10ms | 2.08% | `encoding/binary.littleEndian.Uint64 (inline)` |
| 10ms | 2.08% | 10ms | 2.08% | `github.com/pierrec/lz4/v4/internal/lz4block.blockHash (inline)` |
| 10ms | 2.08% | 10ms | 2.08% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).PointRevisionStats` |
| 10ms | 2.08% | 10ms | 2.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogWriterMuHeld` |
| 10ms | 2.08% | 10ms | 2.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).preferLeafPageBlockCodec` |
| 10ms | 2.08% | 10ms | 2.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).rotateValueLogForMaxSegmentMuHeldCapture` |
| 10ms | 2.08% | 10ms | 2.08% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).down` |
| 10ms | 2.08% | 10ms | 2.08% | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Swap` |
| 10ms | 2.08% | 10ms | 2.08% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeIntoBackingLocked` |
| 10ms | 2.08% | 10ms | 2.08% | `github.com/snissn/gomap/TreeDB/internal/mvccadmission.(*Summary).Observe` |
| 10ms | 2.08% | 10ms | 2.08% | `github.com/snissn/gomap/TreeDB/node.(*Builder).finishLeafColumnarPrefixV2.func1` |
| 10ms | 2.08% | 10ms | 2.08% | `internal/runtime/syscall/linux.Syscall6` |
| 10ms | 2.08% | 10ms | 2.08% | `internal/sync.(*Mutex).Lock` |
| 10ms | 2.08% | 10ms | 2.08% | `internal/sync.(*Mutex).Unlock` |
| 10ms | 2.08% | 10ms | 2.08% | `sync.(*Once).Do` |
| 0 | 0.00% | 80ms | 16.67% | `github.com/pierrec/lz4/v4.(*Compressor).CompressBlock` |
| 0 | 0.00% | 230ms | 47.92% | `github.com/pierrec/lz4/v4.UncompressBlock` |
| 0 | 0.00% | 230ms | 47.92% | `github.com/pierrec/lz4/v4/internal/lz4block.UncompressBlock` |
| 0 | 0.00% | 10ms | 2.08% | `github.com/snissn/go-crc32-asm.Update` |
| 0 | 0.00% | 10ms | 2.08% | `github.com/snissn/go-crc32-asm.checksumIEEEFallback (inline)` |
| 0 | 0.00% | 10ms | 2.08% | `github.com/snissn/go-crc32-asm.updateIEEE` |

### checkpoint/batch_write_steady (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_batch_write_steady_treedb.pprof`
- total samples: `160ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 18.75% | 30ms | 18.75% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 10ms | 6.25% | 10ms | 6.25% | `cmpbody` |
| 10ms | 6.25% | 10ms | 6.25% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 10ms | 6.25% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogInternalObserved` |
| 10ms | 6.25% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).down` |
| 10ms | 6.25% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/caching.(*stableUnsafeOpIter).Entry` |
| 10ms | 6.25% | 50ms | 31.25% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 10ms | 6.25% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/freelist.(*ReservationLedger).firstUnreservedAtOrAfter` |
| 10ms | 6.25% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/node.(*Builder).leafColumnarV2AppendBytes` |
| 10ms | 6.25% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/node.sharedPrefixLen (inline)` |
| 10ms | 6.25% | 60ms | 37.50% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).mergeLeaf` |
| 10ms | 6.25% | 10ms | 6.25% | `internal/sync.(*Mutex).lockSlow` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.(*unwinder).resolveInternal` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.funcInfo.entry` |
| 0 | 0.00% | 10ms | 6.25% | `bytes.Compare (inline)` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/pierrec/lz4/v4.UncompressBlock` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/pierrec/lz4/v4/internal/lz4block.UncompressBlock` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/go-crc32-asm.Checksum (inline)` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/go-crc32-asm.Update` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/go-crc32-asm.updateIEEE` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).SetViewWithRevision (inline)` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).noteKeyOrder` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).setViewWithMVCCInput` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLog` |

### checkpoint/dataset_write_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_dataset_write_random_treedb.pprof`
- total samples: `360ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 70ms | 19.44% | 70ms | 19.44% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 40ms | 11.11% | 40ms | 11.11% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey` |
| 40ms | 11.11% | 40ms | 11.11% | `runtime.memmove` |
| 30ms | 8.33% | 30ms | 8.33% | `cmpbody` |
| 20ms | 5.56% | 40ms | 11.11% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 20ms | 5.56% | 20ms | 5.56% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).put (inline)` |
| 20ms | 5.56% | 20ms | 5.56% | `github.com/snissn/gomap/TreeDB/node.sharedPrefixLen` |
| 10ms | 2.78% | 10ms | 2.78% | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Swap` |
| 10ms | 2.78% | 20ms | 5.56% | `github.com/snissn/gomap/TreeDB/node.(*Builder).addLeafEntryColumnarPrefixV2` |
| 10ms | 2.78% | 10ms | 2.78% | `github.com/snissn/gomap/TreeDB/node.(*Builder).finalize` |
| 10ms | 2.78% | 10ms | 2.78% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2KeyMetaAt` |
| 10ms | 2.78% | 10ms | 2.78% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2RevisionAt` |
| 10ms | 2.78% | 10ms | 2.78% | `internal/bytealg.Compare` |
| 10ms | 2.78% | 10ms | 2.78% | `runtime.deductSweepCredit` |
| 10ms | 2.78% | 10ms | 2.78% | `runtime.mapassign_fast32` |
| 10ms | 2.78% | 10ms | 2.78% | `runtime.memclrNoHeapPointers` |
| 10ms | 2.78% | 10ms | 2.78% | `sync.indexLocal` |
| 10ms | 2.78% | 10ms | 2.78% | `sync/atomic.(*Int32).Add` |
| 10ms | 2.78% | 10ms | 2.78% | `time.runtimeNow` |
| 0 | 0.00% | 40ms | 11.11% | `bytes.Compare (inline)` |
| 0 | 0.00% | 40ms | 11.11% | `github.com/pierrec/lz4/v4.(*Compressor).CompressBlock` |
| 0 | 0.00% | 70ms | 19.44% | `github.com/pierrec/lz4/v4.UncompressBlock` |
| 0 | 0.00% | 70ms | 19.44% | `github.com/pierrec/lz4/v4/internal/lz4block.UncompressBlock` |
| 0 | 0.00% | 10ms | 2.78% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).SetViewWithRevision` |
| 0 | 0.00% | 10ms | 2.78% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).noteKeyOrder` |

### checkpoint/dataset_write_sorted (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_dataset_write_sorted_treedb.pprof`
- total samples: `230ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 50ms | 21.74% | 50ms | 21.74% | `cmpbody` |
| 40ms | 17.39% | 40ms | 17.39% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` |
| 30ms | 13.04% | 30ms | 13.04% | `runtime.memmove` |
| 20ms | 8.70% | 20ms | 8.70% | `runtime.memclrNoHeapPointers` |
| 10ms | 4.35% | 20ms | 8.70% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 10ms | 4.35% | 10ms | 4.35% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).get (inline)` |
| 10ms | 4.35% | 150ms | 65.22% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 10ms | 4.35% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).resetLockedWithPolicy` |
| 10ms | 4.35% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/internal/outerleaf.HasMagic (inline)` |
| 10ms | 4.35% | 20ms | 8.70% | `github.com/snissn/gomap/TreeDB/node.(*Builder).leafEntrySize` |
| 10ms | 4.35% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/node.sharedPrefixLen (inline)` |
| 10ms | 4.35% | 10ms | 4.35% | `memeqbody` |
| 10ms | 4.35% | 50ms | 21.74% | `sort.partition_func` |
| 0 | 0.00% | 50ms | 21.74% | `bytes.Compare (inline)` |
| 0 | 0.00% | 10ms | 4.35% | `bytes.Equal (inline)` |
| 0 | 0.00% | 10ms | 4.35% | `bytes.HasPrefix (inline)` |
| 0 | 0.00% | 20ms | 8.70% | `github.com/pierrec/lz4/v4.(*Compressor).CompressBlock` |
| 0 | 0.00% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve (inline)` |
| 0 | 0.00% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).SetViewWithRevision (inline)` |
| 0 | 0.00% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).observeMVCCInput (inline)` |
| 0 | 0.00% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).setViewWithMVCCInput` |
| 0 | 0.00% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLog` |
| 0 | 0.00% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogInternal (inline)` |
| 0 | 0.00% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogInternalObserved` |
| 0 | 0.00% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/caching.(*DB).classifyVlogPayloadKindForRecords (inline)` |

### checkpoint/full_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_full_scan_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/post (run_treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_post_run_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/prefix_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_prefix_scan_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/random_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_delete_treedb.pprof`
- total samples: `150ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 20.00% | 30ms | 20.00% | `runtime.memmove` |
| 20ms | 13.33% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).down` |
| 10ms | 6.67% | 10ms | 6.67% | `bytes.Compare (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 10ms | 6.67% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).pop` |
| 10ms | 6.67% | 50ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 10ms | 6.67% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/db.(*DB).NoteLeafGenerationRecordLength` |
| 10ms | 6.67% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/node.(*Builder).addLeafEntryColumnarPrefixV2` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/node.(*Builder).finishLeafColumnarPrefixV2` |
| 10ms | 6.67% | 80ms | 53.33% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).mergeLeaf` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/zipper.(*spanNativeLeafOutputs).setRef` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.memclrNoHeapPointers` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/pierrec/lz4/v4.(*Compressor).CompressBlock (inline)` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogOneInternal` |
| 0 | 0.00% | 50ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 50ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func5` |
| 0 | 0.00% | 50ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 50ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCheckpointFrontierLocked.func1` |
| 0 | 0.00% | 50ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteLeafGenerationRecordLength` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).prepareAppendFrameOne` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).writeCanonicalFlushRunOpsChunk` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/caching.(*cachingLeafPageLog).AppendPreparedLeafPage` |

### checkpoint/random_read (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_read_treedb.pprof`
- total samples: `1.18s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.66s | 55.93% | 0.66s | 55.93% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.05s | 4.24% | 0.05s | 4.24% | `cmpbody` |
| 0.04s | 3.39% | 0.07s | 5.93% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafValueViewColumnarPrefixV2` |
| 0.04s | 3.39% | 0.04s | 3.39% | `internal/runtime/syscall/linux.Syscall6` |
| 0.03s | 2.54% | 0.03s | 2.54% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 0.03s | 2.54% | 0.03s | 2.54% | `runtime.memclrNoHeapPointers` |
| 0.02s | 1.69% | 0.02s | 1.69% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).UnsafeEntryWithRevision` |
| 0.02s | 1.69% | 0.02s | 1.69% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2EnsureMeta` |
| 0.02s | 1.69% | 0.02s | 1.69% | `github.com/snissn/gomap/TreeDB/page.DecodeLogRecordRef (inline)` |
| 0.02s | 1.69% | 0.02s | 1.69% | `runtime.releasem (inline)` |
| 0.01s | 0.85% | 0.01s | 0.85% | `aeshashbody` |
| 0.01s | 0.85% | 0.01s | 0.85% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 0.01s | 0.85% | 0.01s | 0.85% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogOneInternal.func2` |
| 0.01s | 0.85% | 0.06s | 5.08% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 0.01s | 0.85% | 0.01s | 0.85% | `github.com/snissn/gomap/TreeDB/db.(*DB).releasePendingValueLogAppendFileIDsFromEntries` |
| 0.01s | 0.85% | 0.02s | 1.69% | `github.com/snissn/gomap/TreeDB/internal/crc.ChecksumParts` |
| 0.01s | 0.85% | 0.01s | 0.85% | `github.com/snissn/gomap/TreeDB/node.(*Builder).addLeafEntryColumnarPrefixV2` |
| 0.01s | 0.85% | 0.93s | 78.81% | `github.com/snissn/gomap/TreeDB/node.(*Node).WalkInternalChildren` |
| 0.01s | 0.85% | 0.02s | 1.69% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnar (inline)` |
| 0.01s | 0.85% | 0.03s | 2.54% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2ValueMetaAt` |
| 0.01s | 0.85% | 0.01s | 0.85% | `github.com/snissn/gomap/TreeDB/node.decodeEntryRevision` |
| 0.01s | 0.85% | 0.01s | 0.85% | `github.com/snissn/gomap/TreeDB/node.getUint16At (inline)` |
| 0.01s | 0.85% | 0.01s | 0.85% | `github.com/snissn/gomap/TreeDB/node.putUint16At` |
| 0.01s | 0.85% | 0.02s | 1.69% | `github.com/snissn/gomap/TreeDB/zipper.(*mergeScratch).acquireLeafRefCacheBuildPage` |
| 0.01s | 0.85% | 0.01s | 0.85% | `hash/crc32.ieeeCLMUL` |

### checkpoint/random_read_batch (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_read_batch_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/random_read_parallel (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_read_parallel_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/random_read_parallel_acquire_snapshot (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/random_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_write_treedb.pprof`
- total samples: `30ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 10ms | 33.33% | 10ms | 33.33% | `cmpbody` |
| 10ms | 33.33% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.appendCanonicalFlushRunChunkToBackendBatch` |
| 10ms | 33.33% | 10ms | 33.33% | `runtime.memmove` |
| 0 | 0.00% | 10ms | 33.33% | `bytes.Compare (inline)` |
| 0 | 0.00% | 30ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 30ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 20ms | 66.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4 (partial-inline)` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func5` |
| 0 | 0.00% | 30ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 30ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCheckpointFrontierLocked.func1` |
| 0 | 0.00% | 30ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 20ms | 66.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).writeCanonicalFlushRunOpsChunk` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).down` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).pop` |
| 0 | 0.00% | 20ms | 66.67% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Less` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/db.(*Batch).Write` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/db.(*Batch).write` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/db.(*DB).storeLeafPageReadCache (inline)` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/db.(*RootPublicationBuildGroup).applyBatchLocked` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/db.(*RootPublicationBuildGroup).writeBatch` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/db.(*leafPageLogWithRecordLengthHints).AppendPreparedLeafPageChildRefs` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/db.(*leafPageLogWithRecordLengthHints).noteLeafPagePointer` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).storeInBucketLocked (inline)` |
| 0 | 0.00% | 10ms | 33.33% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).storeInBucketWithAllocationPolicyLocked` |

### checkpoint/sequential_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_sequential_write_treedb.pprof`
- total samples: `0`

_No entries parsed._

### dataset_write_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_dataset_write_random_treedb.pprof`
- total samples: `170ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 17.65% | 30ms | 17.65% | `internal/sync.(*Mutex).Unlock (inline)` |
| 20ms | 11.76% | 20ms | 11.76% | `runtime.memmove` |
| 20ms | 11.76% | 50ms | 29.41% | `runtime.scanObject` |
| 20ms | 11.76% | 20ms | 11.76% | `runtime.tryDeferToSpanScan` |
| 10ms | 5.88% | 10ms | 5.88% | `compress/flate.(*huffmanBitWriter).writeCode` |
| 10ms | 5.88% | 10ms | 5.88% | `internal/runtime/atomic.(*UnsafePointer).StoreNoWB (inline)` |
| 10ms | 5.88% | 10ms | 5.88% | `memeqbody` |
| 10ms | 5.88% | 30ms | 17.65% | `runtime.mapassign_faststr` |
| 10ms | 5.88% | 10ms | 5.88% | `runtime.nanotime` |
| 10ms | 5.88% | 20ms | 11.76% | `runtime.sweepone` |
| 10ms | 5.88% | 10ms | 5.88% | `runtime.typePointers.next` |
| 10ms | 5.88% | 10ms | 5.88% | `time.runtimeNow` |
| 0 | 0.00% | 10ms | 5.88% | `compress/flate.(*Writer).Close (inline)` |
| 0 | 0.00% | 10ms | 5.88% | `compress/flate.(*compressor).close` |
| 0 | 0.00% | 10ms | 5.88% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 10ms | 5.88% | `compress/flate.(*huffmanBitWriter).writeBlockDynamic` |
| 0 | 0.00% | 10ms | 5.88% | `compress/flate.(*huffmanBitWriter).writeTokens` |
| 0 | 0.00% | 10ms | 5.88% | `compress/gzip.(*Writer).Close` |
| 0 | 0.00% | 80ms | 47.06% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 80ms | 47.06% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 80ms | 47.06% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeAssistFlush` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWrite` |
| 0 | 0.00% | 80ms | 47.06% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 80ms | 47.06% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |

### dataset_write_sorted (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_dataset_write_sorted_treedb.pprof`
- total samples: `150ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 20.00% | 30ms | 20.00% | `runtime.typePointers.next` |
| 20ms | 13.33% | 20ms | 13.33% | `internal/sync.(*Mutex).Lock (inline)` |
| 20ms | 13.33% | 20ms | 13.33% | `runtime.tryDeferToSpanScan` |
| 10ms | 6.67% | 10ms | 6.67% | `bytes.Equal (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/cespare/xxhash/v2.Sum64` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).beginMVCCInputCut (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `internal/runtime/syscall/linux.Syscall6` |
| 10ms | 6.67% | 10ms | 6.67% | `internal/sync.(*Mutex).Unlock (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.futex` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.pMask.read` |
| 10ms | 6.67% | 10ms | 6.67% | `sync/atomic.(*Int32).Add (inline)` |
| 0 | 0.00% | 10ms | 6.67% | `bytes.HasPrefix (inline)` |
| 0 | 0.00% | 70ms | 46.67% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 70ms | 46.67% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 70ms | 46.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).lockUpdateKey (inline)` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeAssistFlush` |
| 0 | 0.00% | 60ms | 40.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 60ms | 40.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).shardForKey` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).shardIndex (inline)` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.hashKey` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/internal/keyupdate.(*Locks).Lock` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |

### full_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_full_scan_treedb.pprof`
- total samples: `450ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 190ms | 42.22% | 190ms | 42.22% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 30ms | 6.67% | 40ms | 8.89% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 30ms | 6.67% | 70ms | 15.56% | `runtime.scanObject` |
| 20ms | 4.44% | 20ms | 4.44% | `internal/runtime/syscall/linux.Syscall6` |
| 20ms | 4.44% | 340ms | 75.56% | `main.runBenchmark.func37` |
| 20ms | 4.44% | 20ms | 4.44% | `runtime.memmove` |
| 10ms | 2.22% | 10ms | 2.22% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).UnsafeKey (inline)` |
| 10ms | 2.22% | 10ms | 2.22% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadChecksumEnabled` |
| 10ms | 2.22% | 10ms | 2.22% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafPrefixCompressed (inline)` |
| 10ms | 2.22% | 10ms | 2.22% | `hash/crc32.simpleUpdate (inline)` |
| 10ms | 2.22% | 10ms | 2.22% | `internal/runtime/atomic.(*Uint32).CompareAndSwap` |
| 10ms | 2.22% | 10ms | 2.22% | `internal/sync.(*Mutex).Unlock (inline)` |
| 10ms | 2.22% | 10ms | 2.22% | `runtime.(*gcBitsArena).tryAlloc` |
| 10ms | 2.22% | 10ms | 2.22% | `runtime.(*mspan).markBitsForIndex (inline)` |
| 10ms | 2.22% | 10ms | 2.22% | `runtime.getMCache (inline)` |
| 10ms | 2.22% | 10ms | 2.22% | `runtime.spanClass.sizeclass (inline)` |
| 10ms | 2.22% | 10ms | 2.22% | `runtime.step` |
| 10ms | 2.22% | 20ms | 4.44% | `runtime.tryDeferToSpanScan` |
| 10ms | 2.22% | 10ms | 2.22% | `runtime.typePointers.next` |
| 10ms | 2.22% | 10ms | 2.22% | `runtime.unlock2` |
| 0 | 0.00% | 190ms | 42.22% | `github.com/pierrec/lz4/v4.UncompressBlock (inline)` |
| 0 | 0.00% | 190ms | 42.22% | `github.com/pierrec/lz4/v4/internal/lz4block.UncompressBlock` |
| 0 | 0.00% | 10ms | 2.22% | `github.com/snissn/go-crc32-asm.Update` |
| 0 | 0.00% | 10ms | 2.22% | `github.com/snissn/go-crc32-asm.checksumIEEEFallback (inline)` |
| 0 | 0.00% | 10ms | 2.22% | `github.com/snissn/go-crc32-asm.updateIEEE` |

### prefix_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_prefix_scan_treedb.pprof`
- total samples: `120ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 60ms | 50.00% | 90ms | 75.00% | `runtime.scanObject` |
| 10ms | 8.33% | 10ms | 8.33% | `aeshashbody` |
| 10ms | 8.33% | 10ms | 8.33% | `runtime.(*sweepClass).update (inline)` |
| 10ms | 8.33% | 10ms | 8.33% | `runtime.divRoundUp (inline)` |
| 10ms | 8.33% | 10ms | 8.33% | `runtime.findObject` |
| 10ms | 8.33% | 10ms | 8.33% | `runtime.heapArenaOf (inline)` |
| 10ms | 8.33% | 10ms | 8.33% | `runtime.spanClass.sizeclass (inline)` |
| 0 | 0.00% | 20ms | 16.67% | `main.main` |
| 0 | 0.00% | 20ms | 16.67% | `main.runBenchmark` |
| 0 | 0.00% | 10ms | 8.33% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 10ms | 8.33% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 10ms | 8.33% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 10ms | 8.33% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 10ms | 8.33% | `runtime.(*mheap).nextSpanForSweep` |
| 0 | 0.00% | 10ms | 8.33% | `runtime.(*mspan).moveInlineMarks` |
| 0 | 0.00% | 10ms | 8.33% | `runtime.(*sweepLocked).sweep` |
| 0 | 0.00% | 10ms | 8.33% | `runtime.GC` |
| 0 | 0.00% | 10ms | 8.33% | `runtime.bgsweep` |
| 0 | 0.00% | 90ms | 75.00% | `runtime.gcBgMarkWorker` |
| 0 | 0.00% | 90ms | 75.00% | `runtime.gcBgMarkWorker.func2` |
| 0 | 0.00% | 90ms | 75.00% | `runtime.gcDrain` |
| 0 | 0.00% | 20ms | 16.67% | `runtime.gcDrainMarkWorkerDedicated (inline)` |
| 0 | 0.00% | 70ms | 58.33% | `runtime.gcDrainMarkWorkerIdle (inline)` |
| 0 | 0.00% | 20ms | 16.67% | `runtime.main` |
| 0 | 0.00% | 10ms | 8.33% | `runtime.mapaccess2_faststr` |

### random_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_random_delete_treedb.pprof`
- total samples: `190ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 60ms | 31.58% | 100ms | 52.63% | `runtime.scanObject` |
| 30ms | 15.79% | 30ms | 15.79% | `runtime.typePointers.next` |
| 20ms | 10.53% | 20ms | 10.53% | `sync/atomic.(*Int32).Add (inline)` |
| 10ms | 5.26% | 10ms | 5.26% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWrite` |
| 10ms | 5.26% | 10ms | 5.26% | `internal/runtime/atomic.(*Uint32).CompareAndSwap (inline)` |
| 10ms | 5.26% | 10ms | 5.26% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 10ms | 5.26% | 10ms | 5.26% | `internal/sync.(*Mutex).Unlock (inline)` |
| 10ms | 5.26% | 10ms | 5.26% | `runtime.(*mheap).freeMSpanLocked` |
| 10ms | 5.26% | 10ms | 5.26% | `runtime.funcInfo.entry (inline)` |
| 10ms | 5.26% | 20ms | 10.53% | `runtime.mapassign_fast64` |
| 10ms | 5.26% | 10ms | 5.26% | `runtime.tryDeferToSpanScan` |
| 0 | 0.00% | 60ms | 31.58% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 50ms | 26.32% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Delete` |
| 0 | 0.00% | 50ms | 26.32% | `github.com/snissn/gomap/TreeDB/caching.(*DB).delete` |
| 0 | 0.00% | 50ms | 26.32% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirect` |
| 0 | 0.00% | 30ms | 15.79% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 30ms | 15.79% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 20ms | 10.53% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 20ms | 10.53% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 0 | 0.00% | 60ms | 31.58% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Delete` |
| 0 | 0.00% | 80ms | 42.11% | `main.main` |
| 0 | 0.00% | 80ms | 42.11% | `main.runBenchmark` |
| 0 | 0.00% | 60ms | 31.58% | `main.runBenchmark.func31` |
| 0 | 0.00% | 10ms | 5.26% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 10ms | 5.26% | `main.writeAllocsSnapshotTemp` |

### random_read (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_random_read_treedb.pprof`
- total samples: `500ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 40ms | 8.00% | 40ms | 8.00% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 40ms | 8.00% | 60ms | 12.00% | `runtime.scanObject` |
| 30ms | 6.00% | 30ms | 6.00% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 30ms | 6.00% | 50ms | 10.00% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` |
| 30ms | 6.00% | 30ms | 6.00% | `internal/sync.(*Mutex).Unlock (inline)` |
| 20ms | 4.00% | 20ms | 4.00% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getViewLockedWithState` |
| 20ms | 4.00% | 30ms | 6.00% | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView (inline)` |
| 20ms | 4.00% | 20ms | 4.00% | `github.com/snissn/gomap/TreeDB/pager.(*Pager).isVerifiedPage` |
| 20ms | 4.00% | 20ms | 4.00% | `sync/atomic.(*Bool).CompareAndSwap` |
| 20ms | 4.00% | 20ms | 4.00% | `sync/atomic.(*Uint64).Add (inline)` |
| 10ms | 2.00% | 10ms | 2.00% | `cmpbody` |
| 10ms | 2.00% | 20ms | 4.00% | `github.com/snissn/gomap/TreeDB/caching.livePointRootDomainSnapshot` |
| 10ms | 2.00% | 50ms | 10.00% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead` |
| 10ms | 2.00% | 70ms | 14.00% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 10ms | 2.00% | 10ms | 2.00% | `github.com/snissn/gomap/TreeDB/internal/mvcckey.VersionAffinityPrefix` |
| 10ms | 2.00% | 20ms | 4.00% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` |
| 10ms | 2.00% | 60ms | 12.00% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildRef` |
| 10ms | 2.00% | 10ms | 2.00% | `github.com/snissn/gomap/TreeDB/node.(*Node).internalBaseDelta (inline)` |
| 10ms | 2.00% | 10ms | 2.00% | `github.com/snissn/gomap/TreeDB/node.getUint16At (inline)` |
| 10ms | 2.00% | 10ms | 2.00% | `github.com/snissn/gomap/TreeDB/node.getUint64BEAt (inline)` |
| 10ms | 2.00% | 260ms | 52.00% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView` |
| 10ms | 2.00% | 10ms | 2.00% | `internal/runtime/atomic.(*Uint32).CompareAndSwap` |
| 10ms | 2.00% | 10ms | 2.00% | `internal/runtime/atomic.(*Uint64).CompareAndSwap` |
| 10ms | 2.00% | 10ms | 2.00% | `internal/runtime/syscall/linux.Syscall6` |
| 10ms | 2.00% | 10ms | 2.00% | `runtime.(*profBuf).read` |

### random_read_batch (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_random_read_batch_treedb.pprof`
- total samples: `490ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 70ms | 14.29% | 80ms | 16.33% | `runtime.scanObject` |
| 60ms | 12.24% | 60ms | 12.24% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 50ms | 10.20% | 50ms | 10.20% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 40ms | 8.16% | 40ms | 8.16% | `internal/runtime/syscall/linux.Syscall6` |
| 20ms | 4.08% | 80ms | 16.33% | `github.com/snissn/gomap/TreeDB/node.(*Node).VerifyChecksum` |
| 20ms | 4.08% | 20ms | 4.08% | `internal/sync.(*Mutex).Lock` |
| 20ms | 4.08% | 20ms | 4.08% | `sync/atomic.(*Bool).Load (inline)` |
| 10ms | 2.04% | 10ms | 2.04% | `bytes.Compare (inline)` |
| 10ms | 2.04% | 10ms | 2.04% | `encoding/binary.bigEndian.Uint64 (inline)` |
| 10ms | 2.04% | 20ms | 4.08% | `github.com/snissn/gomap/TreeDB/db.(*DB).GetManyView.func1` |
| 10ms | 2.04% | 40ms | 8.16% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel.func3.1` |
| 10ms | 2.04% | 10ms | 2.04% | `github.com/snissn/gomap/TreeDB/db.(*DB).refreshOnValueLogFileNotFound` |
| 10ms | 2.04% | 20ms | 4.08% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeViewWithState` |
| 10ms | 2.04% | 30ms | 6.12% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` |
| 10ms | 2.04% | 10ms | 2.04% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildRef` |
| 10ms | 2.04% | 10ms | 2.04% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafValueViewColumnarPrefixV2` |
| 10ms | 2.04% | 20ms | 4.08% | `github.com/snissn/gomap/TreeDB/node.(*Node).searchLeafColumnarPrefixV2BlockWithMeta` |
| 10ms | 2.04% | 10ms | 2.04% | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView` |
| 10ms | 2.04% | 10ms | 2.04% | `github.com/snissn/gomap/TreeDB/node.getUint64BEAt (inline)` |
| 10ms | 2.04% | 10ms | 2.04% | `github.com/snissn/gomap/TreeDB/pager.(*Pager).getLocalMapping` |
| 10ms | 2.04% | 10ms | 2.04% | `hash/crc32.update` |
| 10ms | 2.04% | 10ms | 2.04% | `internal/runtime/atomic.(*Uint8).Load` |
| 10ms | 2.04% | 10ms | 2.04% | `internal/runtime/maps.ctrlGroup.matchH2` |
| 10ms | 2.04% | 10ms | 2.04% | `memeqbody` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.step` |

### random_read_parallel (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_random_read_parallel_treedb.pprof`
- total samples: `5.36s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.63s | 11.75% | 0.63s | 11.75% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.37s | 6.90% | 0.37s | 6.90% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 0.36s | 6.72% | 0.36s | 6.72% | `internal/runtime/syscall/linux.Syscall6` |
| 0.23s | 4.29% | 4.75s | 88.62% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView` |
| 0.20s | 3.73% | 0.31s | 5.78% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` |
| 0.20s | 3.73% | 0.21s | 3.92% | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView (inline)` |
| 0.19s | 3.54% | 0.39s | 7.28% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` |
| 0.17s | 3.17% | 0.23s | 4.29% | `github.com/snissn/gomap/TreeDB/tree.noteOuterLeafLoad` |
| 0.14s | 2.61% | 0.14s | 2.61% | `cmpbody` |
| 0.12s | 2.24% | 0.26s | 4.85% | `github.com/snissn/gomap/TreeDB/node.(*Node).searchLeafColumnarPrefixV2BlockWithMeta` |
| 0.12s | 2.24% | 0.12s | 2.24% | `hash/crc32.ieeeCLMUL` |
| 0.10s | 1.87% | 0.10s | 1.87% | `github.com/snissn/gomap/TreeDB/pager.(*Pager).getLocalMapping` |
| 0.10s | 1.87% | 0.10s | 1.87% | `runtime.memmove` |
| 0.09s | 1.68% | 0.09s | 1.68% | `github.com/snissn/gomap/TreeDB/node.getUint16At (inline)` |
| 0.08s | 1.49% | 0.18s | 3.36% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getViewLockedWithState` |
| 0.08s | 1.49% | 0.08s | 1.49% | `hash/crc32.simpleUpdate (inline)` |
| 0.08s | 1.49% | 0.15s | 2.80% | `internal/sync.(*Mutex).Lock (inline)` |
| 0.07s | 1.31% | 0.12s | 2.24% | `runtime.scanObject` |
| 0.07s | 1.31% | 0.07s | 1.31% | `sync/atomic.(*Int32).Add (inline)` |
| 0.06s | 1.12% | 0.06s | 1.12% | `internal/poll.(*fdMutex).decref (inline)` |
| 0.06s | 1.12% | 0.06s | 1.12% | `sync/atomic.(*Bool).Load (inline)` |
| 0.05s | 0.93% | 0.05s | 0.93% | `github.com/snissn/gomap/TreeDB/node.getUint64BEAt (inline)` |
| 0.05s | 0.93% | 0.30s | 5.60% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).loadNodeViewWithLoadKindInto` |
| 0.05s | 0.93% | 0.05s | 0.93% | `github.com/snissn/gomap/TreeDB/tree.outerLeafRecentRingContains (inline)` |
| 0.04s | 0.75% | 0.04s | 0.75% | `encoding/binary.bigEndian.Uint64 (inline)` |

### random_read_parallel_acquire_snapshot (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `13.34s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2.09s | 15.67% | 2.09s | 15.67% | `runtime.procyieldAsm` |
| 1.20s | 9.00% | 1.20s | 9.00% | `sync/atomic.(*Int32).Add (inline)` |
| 0.75s | 5.62% | 0.75s | 5.62% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.57s | 4.27% | 3.02s | 22.64% | `internal/sync.(*Mutex).Lock (inline)` |
| 0.42s | 3.15% | 0.42s | 3.15% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 0.42s | 3.15% | 0.42s | 3.15% | `internal/runtime/syscall/linux.Syscall6` |
| 0.35s | 2.62% | 0.49s | 3.67% | `internal/sync.(*Mutex).Unlock (inline)` |
| 0.35s | 2.62% | 2.45s | 18.37% | `internal/sync.(*Mutex).lockSlow` |
| 0.28s | 2.10% | 4.53s | 33.96% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView` |
| 0.23s | 1.72% | 0.34s | 2.55% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` |
| 0.23s | 1.72% | 12.39s | 92.88% | `main.runBenchmark.func34.1` |
| 0.17s | 1.27% | 0.29s | 2.17% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` |
| 0.17s | 1.27% | 0.17s | 1.27% | `runtime.heapSetTypeSmallHeader (inline)` |
| 0.17s | 1.27% | 0.17s | 1.27% | `time.runtimeNow` |
| 0.16s | 1.20% | 0.25s | 1.87% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getViewLockedWithState` |
| 0.16s | 1.20% | 0.17s | 1.27% | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView (inline)` |
| 0.15s | 1.12% | 2.70s | 20.24% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0.14s | 1.05% | 1.25s | 9.37% | `github.com/snissn/gomap/TreeDB/caching.memtableViewAllowsBackendSnapshotFastPath` |
| 0.14s | 1.05% | 0.27s | 2.02% | `github.com/snissn/gomap/TreeDB/node.(*Node).searchLeafColumnarPrefixV2BlockWithMeta` |
| 0.14s | 1.05% | 0.39s | 2.92% | `runtime.scanObject` |
| 0.14s | 1.05% | 0.14s | 1.05% | `sync/atomic.(*Uint64).Add (inline)` |
| 0.13s | 0.97% | 1.90s | 14.24% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead` |
| 0.12s | 0.90% | 1.01s | 7.57% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).Len` |
| 0.12s | 0.90% | 0.24s | 1.80% | `github.com/snissn/gomap/TreeDB/tree.noteOuterLeafLoad` |
| 0.12s | 0.90% | 0.12s | 0.90% | `hash/crc32.ieeeCLMUL` |

### random_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_random_write_treedb.pprof`
- total samples: `150ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 20.00% | 50ms | 33.33% | `runtime.scanObject` |
| 20ms | 13.33% | 20ms | 13.33% | `internal/sync.(*Mutex).Unlock (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).conditionalRecordCommittedEntries` |
| 10ms | 6.67% | 80ms | 53.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 10ms | 6.67% | 10ms | 6.67% | `internal/runtime/maps.bitset.first (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.(*sweepClass).update` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.procyieldAsm` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.spanClass.sizeclass (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.typePointers.next` |
| 10ms | 6.67% | 10ms | 6.67% | `sync/atomic.(*Int32).Add (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `time.runtimeNow` |
| 0 | 0.00% | 80ms | 53.33% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 80ms | 53.33% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 80ms | 53.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).beginDirectWrite` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).conditionalRecordPointWrite (inline)` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWrite` |
| 0 | 0.00% | 80ms | 53.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 0 | 0.00% | 80ms | 53.33% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 10ms | 6.67% | `internal/runtime/maps.(*table).rehash` |

### sequential_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/cpu_sequential_write_treedb.pprof`
- total samples: `150ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 20.00% | 30ms | 20.00% | `runtime.tryDeferToSpanScan` |
| 20ms | 13.33% | 30ms | 20.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 20ms | 13.33% | 20ms | 13.33% | `runtime.memmove` |
| 20ms | 13.33% | 50ms | 33.33% | `runtime.scanObject` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.hashKey` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Swap (inline)` |
| 10ms | 6.67% | 40ms | 26.67% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/internal/mvccadmission.(*Cut).Commit` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.memclrNoHeapPointers` |
| 10ms | 6.67% | 10ms | 6.67% | `sync.(*RWMutex).RLock (inline)` |
| 0 | 0.00% | 80ms | 53.33% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 80ms | 53.33% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 80ms | 53.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func5` |
| 0 | 0.00% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionMode (inline)` |
| 0 | 0.00% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 20ms | 13.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCommandPublish (inline)` |
| 0 | 0.00% | 80ms | 53.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 80ms | 53.33% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).shardForKey` |

## Allocation Hotspots

### batch_delete (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_batch_delete_treedb.pprof`
- total: `3054`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2185 | 71.55% | 2185 | 71.55% | `runtime/pprof.allFrames` |
| 317 | 10.38% | 317 | 10.38% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 256 | 8.38% | 256 | 8.38% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 108 | 3.54% | 108 | 3.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchIntSlice` |
| 80 | 2.62% | 80 | 2.62% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 40 | 1.31% | 139 | 4.55% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 24 | 0.79% | 24 | 0.79% | `runtime/pprof.(*protobuf).string (inline)` |
| 20 | 0.65% | 20 | 0.65% | `compress/flate.newDeflateFast (inline)` |
| 12 | 0.39% | 32 | 1.05% | `compress/flate.(*compressor).init` |
| 5 | 0.16% | 37 | 1.21% | `compress/flate.NewWriter (inline)` |
| 1 | 0.03% | 688 | 22.53% | `main.runBenchmark.func26` |
| 0 | 0.00% | 37 | 1.21% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 687 | 22.50% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 687 | 22.50% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 687 | 22.50% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 687 | 22.50% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 573 | 18.76% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 573 | 18.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 573 | 18.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 687 | 22.50% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 3036 | 99.41% | `main.main` |
| 0 | 0.00% | 3036 | 99.41% | `main.runBenchmark` |
| 0 | 0.00% | 2212 | 72.43% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2212 | 72.43% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 136 | 4.45% | `main.writeRuntimeProfileSnapshot` |

### batch_delete (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_batch_delete_treedb.pprof`
- total: `19328.29kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5731.58kB | 29.65% | 5731.58kB | 29.65% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 2707.76kB | 14.01% | 6196.73kB | 32.06% | `compress/flate.NewWriter (inline)` |
| 2293.69kB | 11.87% | 2293.69kB | 11.87% | `compress/flate.newDeflateFast (inline)` |
| 2124.03kB | 10.99% | 2124.03kB | 10.99% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 1644.93kB | 8.51% | 10527.92kB | 54.47% | `main.runBenchmark.func26` |
| 1195.29kB | 6.18% | 3488.97kB | 18.05% | `compress/flate.(*compressor).init` |
| 1053.63kB | 5.45% | 5773.64kB | 29.87% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 522.70kB | 2.70% | 522.70kB | 2.70% | `runtime/pprof.(*protobuf).string` |
| 515.19kB | 2.67% | 515.19kB | 2.67% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 514.38kB | 2.66% | 514.38kB | 2.66% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchIntSlice` |
| 513kB | 2.65% | 513kB | 2.65% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 512.12kB | 2.65% | 512.12kB | 2.65% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 6196.73kB | 32.06% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 8882.98kB | 45.96% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 8882.98kB | 45.96% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 8882.98kB | 45.96% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 8882.98kB | 45.96% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 6244.58kB | 32.31% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 2124.03kB | 10.99% | `github.com/snissn/gomap/TreeDB/caching.reserveAppendOnlyMemtableEntries` |
| 0 | 0.00% | 2124.03kB | 10.99% | `github.com/snissn/gomap/TreeDB/caching.reserveMemtableEntries` |
| 0 | 0.00% | 2124.03kB | 10.99% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ReserveAdditionalEntries` |
| 0 | 0.00% | 6244.58kB | 32.31% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 6244.58kB | 32.31% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 2124.03kB | 10.99% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).growEntriesLocked` |
| 0 | 0.00% | 2124.03kB | 10.99% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).reserveAdditionalEntriesLocked` |

### batch_random (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_batch_random_treedb.pprof`
- total: `7439`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4370 | 58.74% | 4370 | 58.74% | `runtime/pprof.allFrames` |
| 2185 | 29.37% | 6750 | 90.74% | `runtime/pprof.printCountCycleProfile` |
| 346 | 4.65% | 346 | 4.65% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 256 | 3.44% | 256 | 3.44% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 98 | 1.32% | 98 | 1.32% | `runtime/pprof.(*protobuf).varint (inline)` |
| 80 | 1.08% | 195 | 2.62% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1 | 0.01% | 673 | 9.05% | `main.runBenchmark.func25` |
| 0 | 0.00% | 643 | 8.64% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 643 | 8.64% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 643 | 8.64% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 643 | 8.64% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 602 | 8.09% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchSet` |
| 0 | 0.00% | 602 | 8.09% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 602 | 8.09% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 643 | 8.64% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 7423 | 99.78% | `main.main` |
| 0 | 0.00% | 7423 | 99.78% | `main.runBenchmark` |
| 0 | 0.00% | 6750 | 90.74% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 6750 | 90.74% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 7423 | 99.78% | `runtime.main` |
| 0 | 0.00% | 6750 | 90.74% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 4565 | 61.37% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 98 | 1.32% | `runtime/pprof.(*protobuf).endMessage` |
| 0 | 0.00% | 98 | 1.32% | `runtime/pprof.(*protobuf).length (inline)` |
| 0 | 0.00% | 2366 | 31.81% | `runtime/pprof.writeBlock` |

### batch_random (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_batch_random_treedb.pprof`
- total: `53.66MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 28.03MB | 52.23% | 28.03MB | 52.23% | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` |
| 6.33MB | 11.80% | 6.33MB | 11.80% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 6.11MB | 11.38% | 6.11MB | 11.38% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 3.53MB | 6.57% | 7MB | 13.04% | `compress/flate.NewWriter (inline)` |
| 2.33MB | 4.35% | 3.47MB | 6.47% | `compress/flate.(*compressor).init` |
| 1.61MB | 2.99% | 44.16MB | 82.29% | `main.runBenchmark.func25` |
| 1.14MB | 2.12% | 1.14MB | 2.12% | `compress/flate.newDeflateFast (inline)` |
| 1.04MB | 1.94% | 1.04MB | 1.94% | `github.com/snissn/gomap/TreeDB/caching.compactBatchMainArenaTailAliases` |
| 1MB | 1.86% | 1MB | 1.86% | `runtime/pprof.allFrames` |
| 0.54MB | 1.01% | 0.54MB | 1.01% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` |
| 0.50MB | 0.94% | 5.39MB | 10.04% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0.50MB | 0.94% | 0.50MB | 0.94% | `runtime/pprof.(*protobuf).varint (inline)` |
| 0.50MB | 0.93% | 0.50MB | 0.93% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 0.50MB | 0.93% | 6.89MB | 12.83% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 7MB | 13.04% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 28.03MB | 52.23% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Set` |
| 0 | 0.00% | 28.03MB | 52.23% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetWithRevision (inline)` |
| 0 | 0.00% | 14.52MB | 27.06% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 28.03MB | 52.23% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopy` |
| 0 | 0.00% | 28.03MB | 52.23% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopyInto` |
| 0 | 0.00% | 28.03MB | 52.23% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).cloneKeyValue` |
| 0 | 0.00% | 1.04MB | 1.94% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).compactUnderfilledMainArenaTail` |
| 0 | 0.00% | 1.04MB | 1.94% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).maybeCompactUnderfilledArenaTails` |
| 0 | 0.00% | 28.03MB | 52.23% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setWithMVCCInput` |
| 0 | 0.00% | 14.52MB | 27.06% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |

### batch_small_seq (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_batch_small_seq_treedb.pprof`
- total: `13885`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 6555 | 47.21% | 6555 | 47.21% | `runtime/pprof.allFrames` |
| 4100 | 29.53% | 4176 | 30.08% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 1495 | 10.77% | 1495 | 10.77% | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` |
| 1490 | 10.73% | 1490 | 10.73% | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` |
| 128 | 0.92% | 128 | 0.92% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 0 | 0.00% | 1490 | 10.73% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatch` |
| 0 | 0.00% | 1495 | 10.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Set` |
| 0 | 0.00% | 1495 | 10.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetWithRevision (inline)` |
| 0 | 0.00% | 4176 | 30.08% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 1495 | 10.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopy` |
| 0 | 0.00% | 1495 | 10.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopyInto` |
| 0 | 0.00% | 1495 | 10.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).cloneKeyValue` |
| 0 | 0.00% | 1495 | 10.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setWithMVCCInput` |
| 0 | 0.00% | 4176 | 30.08% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 4176 | 30.08% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 1490 | 10.73% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).NewBatch` |
| 0 | 0.00% | 4176 | 30.08% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 1495 | 10.77% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Set` |
| 0 | 0.00% | 13883 | 100.00% | `main.main` |
| 0 | 0.00% | 13883 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 7161 | 51.57% | `main.runBenchmark.func28` |
| 0 | 0.00% | 4377 | 31.52% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 4377 | 31.52% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 2345 | 16.89% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 2345 | 16.89% | `main.writeRuntimeProfileSnapshotTemp` |

### batch_small_seq (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_batch_small_seq_treedb.pprof`
- total: `40302.59kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 23921.92kB | 59.36% | 23921.92kB | 59.36% | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` |
| 4613.06kB | 11.45% | 6740.21kB | 16.72% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 2255.35kB | 5.60% | 2255.35kB | 5.60% | `compress/flate.newDeflateFast (inline)` |
| 1951.87kB | 4.84% | 4207.21kB | 10.44% | `compress/flate.(*compressor).init` |
| 1805.17kB | 4.48% | 6012.38kB | 14.92% | `compress/flate.NewWriter (inline)` |
| 1609.12kB | 3.99% | 1609.12kB | 3.99% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 1536.35kB | 3.81% | 1536.35kB | 3.81% | `runtime/pprof.allFrames` |
| 1024.69kB | 2.54% | 1024.69kB | 2.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` |
| 553.04kB | 1.37% | 3233.92kB | 8.02% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 518.02kB | 1.29% | 518.02kB | 1.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).retainBatchArenaChunksForMemtablesWithPolicy` |
| 514kB | 1.28% | 514kB | 1.28% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 0 | 0.00% | 6012.38kB | 14.92% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 1024.69kB | 2.54% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatch` |
| 0 | 0.00% | 23921.92kB | 59.36% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Set` |
| 0 | 0.00% | 23921.92kB | 59.36% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetWithRevision (inline)` |
| 0 | 0.00% | 6740.21kB | 16.72% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 23921.92kB | 59.36% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopy` |
| 0 | 0.00% | 23921.92kB | 59.36% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopyInto` |
| 0 | 0.00% | 23921.92kB | 59.36% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).cloneKeyValue` |
| 0 | 0.00% | 23921.92kB | 59.36% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setWithMVCCInput` |
| 0 | 0.00% | 1609.12kB | 3.99% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).tryApplySmallSelectedSortedShard` |
| 0 | 0.00% | 6740.21kB | 16.72% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 6740.21kB | 16.72% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 518.02kB | 1.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).retainBatchArenaChunksForMemtables (inline)` |
| 0 | 0.00% | 1609.12kB | 3.99% | `github.com/snissn/gomap/TreeDB/caching.reserveAppendOnlyMemtableEntries` |

### batch_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_batch_write_treedb.pprof`
- total: `8189`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5461 | 66.69% | 5480 | 66.92% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 2048 | 25.01% | 2048 | 25.01% | `runtime/pprof.elfBuildID` |
| 585 | 7.14% | 585 | 7.14% | `github.com/snissn/gomap/TreeDB/caching.(*batchEntrySliceLeasePool).put (inline)` |
| 49 | 0.60% | 49 | 0.60% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` |
| 0 | 0.00% | 654 | 7.99% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 654 | 7.99% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 654 | 7.99% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 654 | 7.99% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 585 | 7.14% | `github.com/snissn/gomap/TreeDB/caching.(*DB).putBatchShardEntries` |
| 0 | 0.00% | 585 | 7.14% | `github.com/snissn/gomap/TreeDB/caching.(*DB).putBatchShardEntriesLease` |
| 0 | 0.00% | 654 | 7.99% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 8183 | 99.93% | `main.main` |
| 0 | 0.00% | 8183 | 99.93% | `main.runBenchmark` |
| 0 | 0.00% | 655 | 8.00% | `main.runBenchmark.func23` |
| 0 | 0.00% | 655 | 8.00% | `main.runBenchmark.func6` |
| 0 | 0.00% | 7515 | 91.77% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 7515 | 91.77% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 8183 | 99.93% | `runtime.main` |
| 0 | 0.00% | 7528 | 91.93% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 5480 | 66.92% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2048 | 25.01% | `runtime/pprof.(*profileBuilder).readMapping` |
| 0 | 0.00% | 2048 | 25.01% | `runtime/pprof.newProfileBuilder` |
| 0 | 0.00% | 2048 | 25.01% | `runtime/pprof.parseProcSelfMaps` |
| 0 | 0.00% | 7515 | 91.77% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 2052 | 25.06% | `runtime/pprof.writeBlock` |

### batch_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_batch_write_treedb.pprof`
- total: `31711.48kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 17203.68kB | 54.25% | 17203.68kB | 54.25% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 5415.52kB | 17.08% | 7844.43kB | 24.74% | `compress/flate.NewWriter (inline)` |
| 3858.69kB | 12.17% | 3858.69kB | 12.17% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` |
| 1301.24kB | 4.10% | 2428.92kB | 7.66% | `compress/flate.(*compressor).init` |
| 1268.07kB | 4.00% | 1268.07kB | 4.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchEntries` |
| 1127.67kB | 3.56% | 1127.67kB | 3.56% | `compress/flate.newDeflateFast (inline)` |
| 512.44kB | 1.62% | 512.44kB | 1.62% | `github.com/snissn/gomap/TreeDB/caching.(*batchEntrySliceLeasePool).put (inline)` |
| 512.12kB | 1.61% | 512.12kB | 1.61% | `runtime/pprof.elfBuildID` |
| 512.05kB | 1.61% | 6870.89kB | 21.67% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 7844.43kB | 24.74% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 1268.07kB | 4.00% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatchWithSize` |
| 0 | 0.00% | 21574.81kB | 68.03% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 21574.81kB | 68.03% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 21574.81kB | 68.03% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 21574.81kB | 68.03% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 1268.07kB | 4.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatchWithSize` |
| 0 | 0.00% | 512.44kB | 1.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).putBatchShardEntries` |
| 0 | 0.00% | 512.44kB | 1.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).putBatchShardEntriesLease` |
| 0 | 0.00% | 17203.68kB | 54.25% | `github.com/snissn/gomap/TreeDB/caching.reserveAppendOnlyMemtableEntries` |
| 0 | 0.00% | 17203.68kB | 54.25% | `github.com/snissn/gomap/TreeDB/caching.reserveMemtableEntries` |
| 0 | 0.00% | 17203.68kB | 54.25% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ReserveAdditionalEntries` |
| 0 | 0.00% | 17203.68kB | 54.25% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).growEntriesLocked` |
| 0 | 0.00% | 17203.68kB | 54.25% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).reserveAdditionalEntriesLocked` |
| 0 | 0.00% | 1268.07kB | 4.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).NewBatchWithSize` |
| 0 | 0.00% | 21574.81kB | 68.03% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |

### batch_write_steady (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_batch_write_steady_treedb.pprof`
- total: `9220`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 6613 | 71.72% | 6881 | 74.63% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 2185 | 23.70% | 2185 | 23.70% | `runtime/pprof.allFrames` |
| 228 | 2.47% | 228 | 2.47% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 97 | 1.05% | 97 | 1.05% | `github.com/snissn/gomap/TreeDB/internal/valuelog.getDecodeScratch` |
| 0 | 0.00% | 97 | 1.05% | `github.com/snissn/gomap/TreeDB/db.(*cachedLeafPageReader).ReadUnsafeToWithCacheHit` |
| 0 | 0.00% | 97 | 1.05% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |
| 0 | 0.00% | 97 | 1.05% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).readAtWithDictTo` |
| 0 | 0.00% | 97 | 1.05% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).takeDecodeScratch` |
| 0 | 0.00% | 97 | 1.05% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).ReadUnsafeTo` |
| 0 | 0.00% | 97 | 1.05% | `github.com/snissn/gomap/TreeDB/internal/valuelog.readAtWithDictToScratch` |
| 0 | 0.00% | 102 | 1.11% | `github.com/snissn/gomap/TreeDB/zipper.(*ApplyWorkerPool).worker` |
| 0 | 0.00% | 102 | 1.11% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).applySpanNativeWithPrepared.func2` |
| 0 | 0.00% | 97 | 1.05% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).loadNodeRef` |
| 0 | 0.00% | 102 | 1.11% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).writeRecursive` |
| 0 | 0.00% | 6742 | 73.12% | `main.main` |
| 0 | 0.00% | 6742 | 73.12% | `main.runBenchmark` |
| 0 | 0.00% | 830 | 9.00% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 830 | 9.00% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 5898 | 63.97% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 5898 | 63.97% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 6742 | 73.12% | `runtime.main` |
| 0 | 0.00% | 6728 | 72.97% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 9066 | 98.33% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2374 | 25.75% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 5898 | 63.97% | `runtime/pprof.printCountCycleProfile` |

### batch_write_steady (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_batch_write_steady_treedb.pprof`
- total: `27823.72kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4512.93kB | 16.22% | 8614.19kB | 30.96% | `compress/flate.NewWriter (inline)` |
| 4272.18kB | 15.35% | 4272.18kB | 15.35% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 3645.49kB | 13.10% | 10317kB | 37.08% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 3617.61kB | 13.00% | 3617.61kB | 13.00% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve (inline)` |
| 2390.58kB | 8.59% | 4101.26kB | 14.74% | `compress/flate.(*compressor).init` |
| 1762.94kB | 6.34% | 1762.94kB | 6.34% | `runtime/pprof.StartCPUProfile` |
| 1710.68kB | 6.15% | 1710.68kB | 6.15% | `compress/flate.newDeflateFast (inline)` |
| 1644.93kB | 5.91% | 8245.81kB | 29.64% | `main.runBenchmark.func6` |
| 1572.34kB | 5.65% | 1572.34kB | 5.65% | `github.com/snissn/gomap/TreeDB/internal/valuelog.getDecodeScratch` |
| 583.01kB | 2.10% | 583.01kB | 2.10% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*blockCodecScratch).lz4 (inline)` |
| 565.76kB | 2.03% | 565.76kB | 2.03% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildOrderedKey64Locked` |
| 520.04kB | 1.87% | 520.04kB | 1.87% | `runtime/pprof.(*protobuf).string` |
| 513.12kB | 1.84% | 513.12kB | 1.84% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 512.12kB | 1.84% | 512.12kB | 1.84% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 8614.19kB | 30.96% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 565.76kB | 2.03% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 565.76kB | 2.03% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 4272.18kB | 15.35% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 4272.18kB | 15.35% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 4272.18kB | 15.35% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 4272.18kB | 15.35% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 565.76kB | 2.03% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |
| 0 | 0.00% | 583.01kB | 2.10% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogOneInternal` |
| 0 | 0.00% | 565.76kB | 2.03% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 3617.61kB | 13.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |

### dataset_write_random (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_dataset_write_random_treedb.pprof`
- total: `6931`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2185 | 31.53% | 2185 | 31.53% | `runtime/pprof.allFrames` |
| 2088 | 30.13% | 2088 | 30.13% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 2048 | 29.55% | 4270 | 61.61% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 374 | 5.40% | 374 | 5.40% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 131 | 1.89% | 131 | 1.89% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 64 | 0.92% | 64 | 0.92% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 13 | 0.19% | 37 | 0.53% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 2526 | 36.44% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 2526 | 36.44% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 2526 | 36.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 2526 | 36.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 2526 | 36.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 2526 | 36.44% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 2526 | 36.44% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 2088 | 30.13% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 0 | 0.00% | 2526 | 36.44% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 2526 | 36.44% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 6927 | 99.94% | `main.main` |
| 0 | 0.00% | 6927 | 99.94% | `main.runBenchmark` |
| 0 | 0.00% | 2526 | 36.44% | `main.runBenchmark.func21` |
| 0 | 0.00% | 4387 | 63.30% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 4387 | 63.30% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 131 | 1.89% | `os.ReadFile` |
| 0 | 0.00% | 131 | 1.89% | `os.readFileContents` |
| 0 | 0.00% | 6927 | 99.94% | `runtime.main` |

### dataset_write_random (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_dataset_write_random_treedb.pprof`
- total: `25618.98kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 9983.13kB | 38.97% | 9983.13kB | 38.97% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 5415.52kB | 21.14% | 8427.44kB | 32.90% | `compress/flate.NewWriter (inline)` |
| 4103.88kB | 16.02% | 4103.88kB | 16.02% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 1710.68kB | 6.68% | 1710.68kB | 6.68% | `compress/flate.newDeflateFast (inline)` |
| 1301.24kB | 5.08% | 3011.92kB | 11.76% | `compress/flate.(*compressor).init` |
| 1032.02kB | 4.03% | 1032.02kB | 4.03% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 532.26kB | 2.08% | 7406.49kB | 28.91% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 516.01kB | 2.01% | 516.01kB | 2.01% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 512.12kB | 2.00% | 8430.73kB | 32.91% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 512.12kB | 2.00% | 512.12kB | 2.00% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 8427.44kB | 32.90% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 14603.02kB | 57.00% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 14603.02kB | 57.00% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 14603.02kB | 57.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 14603.02kB | 57.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 14603.02kB | 57.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 14603.02kB | 57.00% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 14603.02kB | 57.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 4103.88kB | 16.02% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 0 | 0.00% | 14603.02kB | 57.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 14603.02kB | 57.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 24065.77kB | 93.94% | `main.main` |
| 0 | 0.00% | 24065.77kB | 93.94% | `main.runBenchmark` |
| 0 | 0.00% | 14603.02kB | 57.00% | `main.runBenchmark.func21` |
| 0 | 0.00% | 1434.85kB | 5.60% | `main.writeAllocsSnapshot` |

### dataset_write_sorted (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_dataset_write_sorted_treedb.pprof`
- total: `6166`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3848 | 62.41% | 3848 | 62.41% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 2185 | 35.44% | 2185 | 35.44% | `runtime/pprof.allFrames` |
| 76 | 1.23% | 76 | 1.23% | `runtime/pprof.(*protobuf).string (inline)` |
| 39 | 0.63% | 44 | 0.71% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 3848 | 62.41% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 3848 | 62.41% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 3848 | 62.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 3848 | 62.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 3848 | 62.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 3848 | 62.41% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 3848 | 62.41% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 3848 | 62.41% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 0 | 0.00% | 3848 | 62.41% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 3848 | 62.41% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 6164 | 100.00% | `main.main` |
| 0 | 0.00% | 6164 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 3848 | 62.41% | `main.runBenchmark.func22` |
| 0 | 0.00% | 2303 | 37.35% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2303 | 37.35% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 6164 | 100.00% | `runtime.main` |
| 0 | 0.00% | 2316 | 37.56% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 2229 | 36.15% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 78 | 1.27% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 76 | 1.23% | `runtime/pprof.(*protobuf).strings` |
| 0 | 0.00% | 2303 | 37.35% | `runtime/pprof.writeAlloc` |

### dataset_write_sorted (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_dataset_write_sorted_treedb.pprof`
- total: `14960.46kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 8210.01kB | 54.88% | 8210.01kB | 54.88% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 2707.76kB | 18.10% | 5204.29kB | 34.79% | `compress/flate.NewWriter (inline)` |
| 2496.53kB | 16.69% | 2496.53kB | 16.69% | `compress/flate.(*compressor).init` |
| 518.65kB | 3.47% | 2722.48kB | 18.20% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 515.38kB | 3.44% | 515.38kB | 3.44% | `runtime/pprof.(*protobuf).string (inline)` |
| 512.12kB | 3.42% | 512.12kB | 3.42% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 5204.29kB | 34.79% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 8210.01kB | 54.88% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 8210.01kB | 54.88% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 8210.01kB | 54.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 8210.01kB | 54.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 8210.01kB | 54.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 8210.01kB | 54.88% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 8210.01kB | 54.88% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 8210.01kB | 54.88% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 0 | 0.00% | 8210.01kB | 54.88% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 8210.01kB | 54.88% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 14057.87kB | 93.97% | `main.main` |
| 0 | 0.00% | 14057.87kB | 93.97% | `main.runBenchmark` |
| 0 | 0.00% | 8210.01kB | 54.88% | `main.runBenchmark.func22` |
| 0 | 0.00% | 3099.36kB | 20.72% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 3099.36kB | 20.72% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 2748.50kB | 18.37% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 2748.50kB | 18.37% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 14057.87kB | 93.97% | `runtime.main` |

### full_scan (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_full_scan_treedb.pprof`
- total: `72718`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 65540 | 90.13% | 65540 | 90.13% | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` |
| 6555 | 9.01% | 6555 | 9.01% | `runtime/pprof.allFrames` |
| 122 | 0.17% | 369 | 0.51% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 65540 | 90.13% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 0 | 0.00% | 65540 | 90.13% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafKeyFlagsView` |
| 0 | 0.00% | 65540 | 90.13% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafKeyFlagsViewColumnarPrefixV2 (inline)` |
| 0 | 0.00% | 65540 | 90.13% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 0 | 0.00% | 65540 | 90.13% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).Next` |
| 0 | 0.00% | 65540 | 90.13% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).getLeafKeyFlags` |
| 0 | 0.00% | 65540 | 90.13% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadCurrent` |
| 0 | 0.00% | 72718 | 100.00% | `main.main` |
| 0 | 0.00% | 72718 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 65540 | 90.13% | `main.runBenchmark.func37` |
| 0 | 0.00% | 7169 | 9.86% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 7169 | 9.86% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 72718 | 100.00% | `runtime.main` |
| 0 | 0.00% | 7178 | 9.87% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 6924 | 9.52% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 7169 | 9.86% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 2583 | 3.55% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 4586 | 6.31% | `runtime/pprof.writeMutex` |
| 0 | 0.00% | 7169 | 9.86% | `runtime/pprof.writeProfileInternal` |

### full_scan (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_full_scan_treedb.pprof`
- total: `15106.32kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4096.25kB | 27.12% | 4096.25kB | 27.12% | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` |
| 2707.76kB | 17.92% | 5787.30kB | 38.31% | `compress/flate.NewWriter (inline)` |
| 1951.87kB | 12.92% | 3079.54kB | 20.39% | `compress/flate.(*compressor).init` |
| 1620.46kB | 10.73% | 7787.28kB | 51.55% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1536.35kB | 10.17% | 1536.35kB | 10.17% | `runtime/pprof.allFrames` |
| 1127.67kB | 7.46% | 1127.67kB | 7.46% | `compress/flate.newDeflateFast (inline)` |
| 522.70kB | 3.46% | 522.70kB | 3.46% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 516.64kB | 3.42% | 516.64kB | 3.42% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 513.50kB | 3.40% | 513.50kB | 3.40% | `runtime/pprof.(*protobuf).varint (inline)` |
| 513.12kB | 3.40% | 513.12kB | 3.40% | `compress/flate.(*huffmanEncoder).generate` |
| 0 | 0.00% | 513.12kB | 3.40% | `compress/flate.(*Writer).Close (inline)` |
| 0 | 0.00% | 513.12kB | 3.40% | `compress/flate.(*compressor).close` |
| 0 | 0.00% | 513.12kB | 3.40% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 513.12kB | 3.40% | `compress/flate.(*huffmanBitWriter).indexTokens` |
| 0 | 0.00% | 513.12kB | 3.40% | `compress/flate.(*huffmanBitWriter).writeBlockDynamic` |
| 0 | 0.00% | 513.12kB | 3.40% | `compress/gzip.(*Writer).Close` |
| 0 | 0.00% | 5787.30kB | 38.31% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 4096.25kB | 27.12% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 0 | 0.00% | 4096.25kB | 27.12% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafKeyFlagsView` |
| 0 | 0.00% | 4096.25kB | 27.12% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafKeyFlagsViewColumnarPrefixV2 (inline)` |
| 0 | 0.00% | 4096.25kB | 27.12% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 0 | 0.00% | 4096.25kB | 27.12% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).Next` |
| 0 | 0.00% | 4096.25kB | 27.12% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).getLeafKeyFlags` |
| 0 | 0.00% | 4096.25kB | 27.12% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadCurrent` |
| 0 | 0.00% | 15106.32kB | 100.00% | `main.main` |

### prefix_scan (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_prefix_scan_treedb.pprof`
- total: `6080`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5474 | 90.03% | 5502 | 90.49% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 512 | 8.42% | 512 | 8.42% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 49 | 0.81% | 49 | 0.81% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 38 | 0.62% | 38 | 0.62% | `compress/flate.newDeflateFast (inline)` |
| 5 | 0.08% | 45 | 0.74% | `compress/flate.NewWriter (inline)` |
| 2 | 0.03% | 40 | 0.66% | `compress/flate.(*compressor).init` |
| 0 | 0.00% | 512 | 8.42% | `github.com/snissn/gomap/TreeDB.(*DB).Iterator` |
| 0 | 0.00% | 512 | 8.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Iterator` |
| 0 | 0.00% | 512 | 8.42% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 512 | 8.42% | `github.com/snissn/gomap/TreeDB/db.(*DB).Iterator` |
| 0 | 0.00% | 512 | 8.42% | `github.com/snissn/gomap/TreeDB/db.(*DB).IteratorWithOptions` |
| 0 | 0.00% | 512 | 8.42% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotOrErr` |
| 0 | 0.00% | 512 | 8.42% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 512 | 8.42% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Iterator` |
| 0 | 0.00% | 6063 | 99.72% | `main.main` |
| 0 | 0.00% | 6063 | 99.72% | `main.runBenchmark` |
| 0 | 0.00% | 512 | 8.42% | `main.runBenchmark.func39` |
| 0 | 0.00% | 5507 | 90.58% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 5507 | 90.58% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 6063 | 99.72% | `runtime.main` |

### prefix_scan (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_prefix_scan_treedb.pprof`
- total: `9917.42kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3383.02kB | 34.11% | 3383.02kB | 34.11% | `compress/flate.newDeflateFast (inline)` |
| 2707.76kB | 27.30% | 6741.40kB | 67.98% | `compress/flate.NewWriter (inline)` |
| 1618.13kB | 16.32% | 5678.65kB | 57.26% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1045.40kB | 10.54% | 1045.40kB | 10.54% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 650.62kB | 6.56% | 4033.64kB | 40.67% | `compress/flate.(*compressor).init` |
| 512.50kB | 5.17% | 512.50kB | 5.17% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 0 | 0.00% | 6741.40kB | 67.98% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 512.50kB | 5.17% | `github.com/snissn/gomap/TreeDB.(*DB).Iterator` |
| 0 | 0.00% | 512.50kB | 5.17% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Iterator` |
| 0 | 0.00% | 512.50kB | 5.17% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 512.50kB | 5.17% | `github.com/snissn/gomap/TreeDB/db.(*DB).Iterator` |
| 0 | 0.00% | 512.50kB | 5.17% | `github.com/snissn/gomap/TreeDB/db.(*DB).IteratorWithOptions` |
| 0 | 0.00% | 512.50kB | 5.17% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotOrErr` |
| 0 | 0.00% | 512.50kB | 5.17% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 512.50kB | 5.17% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Iterator` |
| 0 | 0.00% | 7236.54kB | 72.97% | `main.main` |
| 0 | 0.00% | 7236.54kB | 72.97% | `main.runBenchmark` |
| 0 | 0.00% | 512.50kB | 5.17% | `main.runBenchmark.func39` |
| 0 | 0.00% | 2203.41kB | 22.22% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2203.41kB | 22.22% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 4520.63kB | 45.58% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 4520.63kB | 45.58% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 1045.40kB | 10.54% | `os.ReadFile` |
| 0 | 0.00% | 1045.40kB | 10.54% | `os.readFileContents` |
| 0 | 0.00% | 7236.54kB | 72.97% | `runtime.main` |

### random_delete (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_delete_treedb.pprof`
- total: `8318`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 7646 | 91.92% | 7646 | 91.92% | `runtime/pprof.allFrames` |
| 520 | 6.25% | 520 | 6.25% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 128 | 1.54% | 128 | 1.54% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 0 | 0.00% | 648 | 7.79% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 648 | 7.79% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Delete` |
| 0 | 0.00% | 648 | 7.79% | `github.com/snissn/gomap/TreeDB/caching.(*DB).delete` |
| 0 | 0.00% | 648 | 7.79% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirect` |
| 0 | 0.00% | 648 | 7.79% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 648 | 7.79% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 648 | 7.79% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 648 | 7.79% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Delete` |
| 0 | 0.00% | 8313 | 99.94% | `main.main` |
| 0 | 0.00% | 8313 | 99.94% | `main.runBenchmark` |
| 0 | 0.00% | 648 | 7.79% | `main.runBenchmark.func31` |
| 0 | 0.00% | 7646 | 91.92% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 7646 | 91.92% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 8313 | 99.94% | `runtime.main` |
| 0 | 0.00% | 7665 | 92.15% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 7665 | 92.15% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 7646 | 91.92% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 7646 | 91.92% | `runtime/pprof.writeHeapInternal` |
| 0 | 0.00% | 7646 | 91.92% | `runtime/pprof.writeHeapProto` |

### random_delete (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_delete_treedb.pprof`
- total: `16888.76kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 9378.95kB | 55.53% | 9378.95kB | 55.53% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 3610.34kB | 21.38% | 5971.65kB | 35.36% | `compress/flate.NewWriter (inline)` |
| 1195.29kB | 7.08% | 2361.30kB | 13.98% | `compress/flate.(*compressor).init` |
| 1166.01kB | 6.90% | 1166.01kB | 6.90% | `compress/flate.newDeflateFast (inline)` |
| 1024.16kB | 6.06% | 1024.16kB | 6.06% | `runtime/pprof.allFrames` |
| 514kB | 3.04% | 514kB | 3.04% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 0 | 0.00% | 5971.65kB | 35.36% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 9892.95kB | 58.58% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 9892.95kB | 58.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Delete` |
| 0 | 0.00% | 9892.95kB | 58.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).delete` |
| 0 | 0.00% | 9892.95kB | 58.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirect` |
| 0 | 0.00% | 9892.95kB | 58.58% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 9892.95kB | 58.58% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 9892.95kB | 58.58% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 9892.95kB | 58.58% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Delete` |
| 0 | 0.00% | 15403.17kB | 91.20% | `main.main` |
| 0 | 0.00% | 15403.17kB | 91.20% | `main.runBenchmark` |
| 0 | 0.00% | 9892.95kB | 58.58% | `main.runBenchmark.func31` |
| 0 | 0.00% | 1024.16kB | 6.06% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 1024.16kB | 6.06% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 4486.05kB | 26.56% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 4486.05kB | 26.56% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 15403.17kB | 91.20% | `runtime.main` |
| 0 | 0.00% | 5510.22kB | 32.63% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 5510.22kB | 32.63% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |

### random_read (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_read_treedb.pprof`
- total: `4632`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4370 | 94.34% | 4370 | 94.34% | `runtime/pprof.allFrames` |
| 110 | 2.37% | 110 | 2.37% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 80 | 1.73% | 80 | 1.73% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 55 | 1.19% | 55 | 1.19% | `runtime/pprof.(*protobuf).string (inline)` |
| 0 | 0.00% | 4541 | 98.04% | `main.main` |
| 0 | 0.00% | 4541 | 98.04% | `main.runBenchmark` |
| 0 | 0.00% | 4539 | 97.99% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 4539 | 97.99% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 110 | 2.37% | `os.ReadFile` |
| 0 | 0.00% | 110 | 2.37% | `os.readFileContents` |
| 0 | 0.00% | 4541 | 98.04% | `runtime.main` |
| 0 | 0.00% | 4541 | 98.04% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 4466 | 96.42% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 146 | 3.15% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 96 | 2.07% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 110 | 2.37% | `runtime/pprof.(*profileBuilder).readMapping` |
| 0 | 0.00% | 55 | 1.19% | `runtime/pprof.(*protobuf).strings` |
| 0 | 0.00% | 110 | 2.37% | `runtime/pprof.newProfileBuilder` |
| 0 | 0.00% | 4539 | 97.99% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 91 | 1.96% | `runtime/pprof.profileWriter` |
| 0 | 0.00% | 2243 | 48.42% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 2296 | 49.57% | `runtime/pprof.writeMutex` |
| 0 | 0.00% | 4539 | 97.99% | `runtime/pprof.writeProfileInternal` |

### random_read (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_read_treedb.pprof`
- total: `7643.01kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2707.76kB | 35.43% | 4553.67kB | 59.58% | `compress/flate.NewWriter (inline)` |
| 1845.91kB | 24.15% | 1845.91kB | 24.15% | `compress/flate.(*compressor).init` |
| 1033.28kB | 13.52% | 1033.28kB | 13.52% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 1024.23kB | 13.40% | 1024.23kB | 13.40% | `runtime/pprof.allFrames` |
| 516.64kB | 6.76% | 516.64kB | 6.76% | `runtime/pprof.(*protobuf).string (inline)` |
| 515.19kB | 6.74% | 515.19kB | 6.74% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 0 | 0.00% | 4553.67kB | 59.58% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 5680.57kB | 74.32% | `main.main` |
| 0 | 0.00% | 5680.57kB | 74.32% | `main.runBenchmark` |
| 0 | 0.00% | 650.62kB | 8.51% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 650.62kB | 8.51% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 5029.95kB | 65.81% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 5029.95kB | 65.81% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 1033.28kB | 13.52% | `os.ReadFile` |
| 0 | 0.00% | 1033.28kB | 13.52% | `os.readFileContents` |
| 0 | 0.00% | 5680.57kB | 74.32% | `runtime.main` |
| 0 | 0.00% | 5680.57kB | 74.32% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 5190.51kB | 67.91% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2479.08kB | 32.44% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 4166.28kB | 54.51% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 4553.67kB | 59.58% | `runtime/pprof.(*profileBuilder).flush` |
| 0 | 0.00% | 902.59kB | 11.81% | `runtime/pprof.(*profileBuilder).pbSample` |
| 0 | 0.00% | 1033.28kB | 13.52% | `runtime/pprof.(*profileBuilder).readMapping` |
| 0 | 0.00% | 516.64kB | 6.76% | `runtime/pprof.(*protobuf).strings` |
| 0 | 0.00% | 1033.28kB | 13.52% | `runtime/pprof.newProfileBuilder` |

### random_read_batch (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_read_batch_treedb.pprof`
- total: `14895`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 9831 | 66.00% | 9831 | 66.00% | `runtime/pprof.allFrames` |
| 4096 | 27.50% | 4096 | 27.50% | `compress/flate.newHuffmanBitWriter (inline)` |
| 488 | 3.28% | 488 | 3.28% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 327 | 2.20% | 327 | 2.20% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 77 | 0.52% | 77 | 0.52% | `github.com/snissn/gomap/TreeDB/tree.getGetManyScratch` |
| 39 | 0.26% | 4490 | 30.14% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 13 | 0.09% | 4117 | 27.64% | `compress/flate.(*compressor).init` |
| 7 | 0.05% | 4124 | 27.69% | `compress/flate.NewWriter (inline)` |
| 0 | 0.00% | 4124 | 27.69% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 14589 | 97.95% | `main.main` |
| 0 | 0.00% | 14589 | 97.95% | `main.runBenchmark` |
| 0 | 0.00% | 2302 | 15.45% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2302 | 15.45% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 12287 | 82.49% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 12287 | 82.49% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 488 | 3.28% | `os.ReadFile` |
| 0 | 0.00% | 488 | 3.28% | `os.readFileContents` |
| 0 | 0.00% | 14589 | 97.95% | `runtime.main` |
| 0 | 0.00% | 14589 | 97.95% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 14321 | 96.15% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 238 | 1.60% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 4124 | 27.69% | `runtime/pprof.(*profileBuilder).flush` |
| 0 | 0.00% | 488 | 3.28% | `runtime/pprof.(*profileBuilder).readMapping` |

### random_read_batch (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_read_batch_treedb.pprof`
- total: `17252.36kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5415.52kB | 31.39% | 8318.16kB | 48.21% | `compress/flate.NewWriter (inline)` |
| 3758.82kB | 21.79% | 3758.82kB | 21.79% | `github.com/snissn/gomap/TreeDB/tree.getGetManyScratch` |
| 1845.91kB | 10.70% | 2902.64kB | 16.82% | `compress/flate.(*compressor).init` |
| 1553.75kB | 9.01% | 1553.75kB | 9.01% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 1536.28kB | 8.90% | 1536.28kB | 8.90% | `runtime/pprof.allFrames` |
| 1026.19kB | 5.95% | 1026.19kB | 5.95% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 544.67kB | 3.16% | 544.67kB | 3.16% | `compress/flate.newDeflateFast (inline)` |
| 540.51kB | 3.13% | 540.51kB | 3.13% | `runtime/pprof.(*protobuf).string (inline)` |
| 518.65kB | 3.01% | 10390.55kB | 60.23% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 512.06kB | 2.97% | 512.06kB | 2.97% | `compress/flate.newHuffmanBitWriter (inline)` |
| 0 | 0.00% | 8318.16kB | 48.21% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 3758.82kB | 21.79% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel.func3` |
| 0 | 0.00% | 3758.82kB | 21.79% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).GetManyView` |
| 0 | 0.00% | 12077.82kB | 70.01% | `main.main` |
| 0 | 0.00% | 12077.82kB | 70.01% | `main.runBenchmark` |
| 0 | 0.00% | 3540.50kB | 20.52% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 3540.50kB | 20.52% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 8537.32kB | 49.48% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 8537.32kB | 49.48% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 1026.19kB | 5.95% | `os.ReadFile` |
| 0 | 0.00% | 1026.19kB | 5.95% | `os.readFileContents` |
| 0 | 0.00% | 12077.82kB | 70.01% | `runtime.main` |
| 0 | 0.00% | 12077.82kB | 70.01% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 11926.84kB | 69.13% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 1956.22kB | 11.34% | `runtime/pprof.(*profileBuilder).build` |

### random_read_parallel (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_read_parallel_treedb.pprof`
- total: `15220`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5507 | 36.18% | 5512 | 36.22% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 5461 | 35.88% | 5461 | 35.88% | `runtime/pprof.allFrames` |
| 2185 | 14.36% | 7729 | 50.78% | `runtime/pprof.printCountCycleProfile` |
| 2010 | 13.21% | 2010 | 13.21% | `runtime.mallocgc` |
| 0 | 0.00% | 13190 | 86.66% | `main.main` |
| 0 | 0.00% | 13190 | 86.66% | `main.runBenchmark` |
| 0 | 0.00% | 5461 | 35.88% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 5461 | 35.88% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 7729 | 50.78% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 7729 | 50.78% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 2010 | 13.21% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 2010 | 13.21% | `runtime.(*traceStackTable).dump` |
| 0 | 0.00% | 2010 | 13.21% | `runtime.dumpStacksRec` |
| 0 | 0.00% | 13190 | 86.66% | `runtime.main` |
| 0 | 0.00% | 2010 | 13.21% | `runtime.makeTraceFrames` |
| 0 | 0.00% | 2010 | 13.21% | `runtime.makeslice` |
| 0 | 0.00% | 2010 | 13.21% | `runtime.traceAdvance` |
| 0 | 0.00% | 13190 | 86.66% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 10973 | 72.10% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 5461 | 35.88% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 5465 | 35.91% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 5461 | 35.88% | `runtime/pprof.writeHeapInternal` |
| 0 | 0.00% | 5461 | 35.88% | `runtime/pprof.writeHeapProto` |
| 0 | 0.00% | 2264 | 14.88% | `runtime/pprof.writeMutex` |
| 0 | 0.00% | 7729 | 50.78% | `runtime/pprof.writeProfileInternal` |

### random_read_parallel (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_read_parallel_treedb.pprof`
- total: `10432.30kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4512.93kB | 43.26% | 5746.56kB | 55.08% | `compress/flate.NewWriter (inline)` |
| 2118.72kB | 20.31% | 4826.47kB | 46.26% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1024.84kB | 9.82% | 1024.84kB | 9.82% | `runtime.mallocgc` |
| 650.62kB | 6.24% | 1233.63kB | 11.83% | `compress/flate.(*compressor).init` |
| 583.01kB | 5.59% | 583.01kB | 5.59% | `compress/flate.newDeflateFast (inline)` |
| 518.02kB | 4.97% | 518.02kB | 4.97% | `runtime/pprof.(*protobuf).string (inline)` |
| 512.12kB | 4.91% | 6907.53kB | 66.21% | `runtime/pprof.printCountCycleProfile` |
| 512.05kB | 4.91% | 512.05kB | 4.91% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 5746.56kB | 55.08% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 7419.57kB | 71.12% | `main.main` |
| 0 | 0.00% | 7419.57kB | 71.12% | `main.runBenchmark` |
| 0 | 0.00% | 512.05kB | 4.91% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 512.05kB | 4.91% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 6907.53kB | 66.21% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 6907.53kB | 66.21% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 1024.84kB | 9.82% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1024.84kB | 9.82% | `runtime.(*traceStackTable).dump` |
| 0 | 0.00% | 1024.84kB | 9.82% | `runtime.dumpStacksRec` |
| 0 | 0.00% | 7419.57kB | 71.12% | `runtime.main` |
| 0 | 0.00% | 1024.84kB | 9.82% | `runtime.makeTraceFrames` |
| 0 | 0.00% | 1024.84kB | 9.82% | `runtime.makeslice` |
| 0 | 0.00% | 1024.84kB | 9.82% | `runtime.traceAdvance` |
| 0 | 0.00% | 7419.57kB | 71.12% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 5338.52kB | 51.17% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2505.91kB | 24.02% | `runtime/pprof.(*profileBuilder).build` |

### random_read_parallel_acquire_snapshot (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_read_parallel_acquire_snapshot_treedb.pprof`
- total: `2384803`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2376975 | 99.67% | 2376975 | 99.67% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 0 | 0.00% | 2376975 | 99.67% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2376975 | 99.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 2376975 | 99.67% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2376975 | 99.67% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 2376975 | 99.67% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).AcquireReadSnapshot` |
| 0 | 0.00% | 2377103 | 99.68% | `main.runBenchmark.func34.1` |
| 0 | 0.00% | 2377103 | 99.68% | `main.runBenchmark.func34.2` |

### random_read_parallel_acquire_snapshot (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_read_parallel_acquire_snapshot_treedb.pprof`
- total: `2.28GB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2.27GB | 99.46% | 2.27GB | 99.46% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 0 | 0.00% | 2.27GB | 99.46% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2.27GB | 99.46% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 2.27GB | 99.46% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2.27GB | 99.46% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 2.27GB | 99.46% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).AcquireReadSnapshot` |
| 0 | 0.00% | 2.27GB | 99.48% | `main.runBenchmark.func34.1` |
| 0 | 0.00% | 2.27GB | 99.48% | `main.runBenchmark.func34.2` |

### random_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_write_treedb.pprof`
- total: `3530`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2185 | 61.90% | 2185 | 61.90% | `runtime/pprof.allFrames` |
| 665 | 18.84% | 665 | 18.84% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 228 | 6.46% | 228 | 6.46% | `compress/flate.(*huffmanEncoder).generate` |
| 171 | 4.84% | 171 | 4.84% | `runtime/pprof.(*protobuf).varint (inline)` |
| 128 | 3.63% | 128 | 3.63% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 108 | 3.06% | 294 | 8.33% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 7 | 0.20% | 23 | 0.65% | `compress/flate.(*compressor).init` |
| 6 | 0.17% | 29 | 0.82% | `compress/flate.NewWriter (inline)` |
| 0 | 0.00% | 228 | 6.46% | `compress/flate.(*Writer).Close (inline)` |
| 0 | 0.00% | 228 | 6.46% | `compress/flate.(*compressor).close` |
| 0 | 0.00% | 228 | 6.46% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 228 | 6.46% | `compress/flate.(*huffmanBitWriter).indexTokens` |
| 0 | 0.00% | 228 | 6.46% | `compress/flate.(*huffmanBitWriter).writeBlockDynamic` |
| 0 | 0.00% | 228 | 6.46% | `compress/gzip.(*Writer).Close` |
| 0 | 0.00% | 809 | 22.92% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 809 | 22.92% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 809 | 22.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 809 | 22.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 809 | 22.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 809 | 22.92% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 809 | 22.92% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 809 | 22.92% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 809 | 22.92% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 3524 | 99.83% | `main.main` |

### random_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_random_write_treedb.pprof`
- total: `66.98MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 44.18MB | 65.96% | 44.18MB | 65.96% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 11.70MB | 17.47% | 11.70MB | 17.47% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 4.41MB | 6.58% | 8.59MB | 12.83% | `compress/flate.NewWriter (inline)` |
| 2.28MB | 3.40% | 2.28MB | 3.40% | `compress/flate.newDeflateFast (inline)` |
| 1.91MB | 2.85% | 4.18MB | 6.25% | `compress/flate.(*compressor).init` |
| 0.50MB | 0.75% | 6.06MB | 9.04% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0.50MB | 0.75% | 0.50MB | 0.75% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 0.50MB | 0.75% | 0.50MB | 0.75% | `runtime/pprof.(*protobuf).varint (inline)` |
| 0.50MB | 0.75% | 0.50MB | 0.75% | `compress/flate.(*huffmanEncoder).generate` |
| 0.50MB | 0.75% | 0.50MB | 0.75% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 8.59MB | 12.83% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 56.39MB | 84.18% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 56.39MB | 84.18% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 56.39MB | 84.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 56.39MB | 84.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 56.39MB | 84.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 56.39MB | 84.18% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 56.39MB | 84.18% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 44.18MB | 65.96% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |

### sequential_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_sequential_write_treedb.pprof`
- total: `3051`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1028 | 33.69% | 1028 | 33.69% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` |
| 899 | 29.47% | 899 | 29.47% | `github.com/snissn/gomap/TreeDB/zipper.init.func2` |
| 775 | 25.40% | 775 | 25.40% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 108 | 3.54% | 111 | 3.64% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 80 | 2.62% | 80 | 2.62% | `github.com/snissn/gomap/TreeDB/caching.getVlogPreparedFrames` |
| 62 | 2.03% | 62 | 2.03% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 34 | 1.11% | 34 | 1.11% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildOrderedKey64Locked` |
| 32 | 1.05% | 32 | 1.05% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).mergeLeaf.func4` |
| 8 | 0.26% | 20 | 0.66% | `compress/flate.(*compressor).init` |
| 4 | 0.13% | 24 | 0.79% | `compress/flate.NewWriter (inline)` |
| 0 | 0.00% | 871 | 28.55% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 871 | 28.55% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 871 | 28.55% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 81 | 2.65% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLog` |
| 0 | 0.00% | 81 | 2.65% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogInternal (inline)` |
| 0 | 0.00% | 81 | 2.65% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogInternalObserved` |
| 0 | 0.00% | 2048 | 67.13% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 2048 | 67.13% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 2048 | 67.13% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 2047 | 67.09% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4` |
| 0 | 0.00% | 2047 | 67.09% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func5` |
| 0 | 0.00% | 2048 | 67.13% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 2048 | 67.13% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionMode (inline)` |
| 0 | 0.00% | 2048 | 67.13% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |

### sequential_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/allocs_sequential_write_treedb.pprof`
- total: `86.13MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 24.24MB | 28.15% | 24.24MB | 28.15% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 22.47MB | 26.09% | 22.47MB | 26.09% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 7.07MB | 8.20% | 7.07MB | 8.20% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve (inline)` |
| 4.61MB | 5.35% | 4.61MB | 5.35% | `github.com/snissn/gomap/TreeDB/zipper.acquireSpanNativeLeafLogPayloadArena` |
| 4.02MB | 4.66% | 4.02MB | 4.66% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` |
| 4MB | 4.65% | 4MB | 4.65% | `github.com/snissn/gomap/TreeDB/internal/valuelog.getWriterAppendBuf` |
| 3.53MB | 4.09% | 7.17MB | 8.32% | `compress/flate.NewWriter (inline)` |
| 3.51MB | 4.08% | 3.51MB | 4.08% | `github.com/snissn/gomap/TreeDB/zipper.init.func2` |
| 3.13MB | 3.64% | 3.13MB | 3.64% | `github.com/snissn/gomap/TreeDB/zipper.(*ReadOnlyPrepareResult).ensureInitialCapacity` |
| 2.54MB | 2.95% | 3.64MB | 4.23% | `compress/flate.(*compressor).init` |
| 2.28MB | 2.64% | 2.28MB | 2.64% | `github.com/snissn/gomap/TreeDB/caching.getEntrySlice` |
| 2.13MB | 2.47% | 2.13MB | 2.47% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildOrderedKey64Locked` |
| 1.10MB | 1.28% | 1.10MB | 1.28% | `compress/flate.newDeflateFast (inline)` |
| 0.51MB | 0.59% | 0.51MB | 0.59% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).mergeLeaf.func4` |
| 0.50MB | 0.58% | 0.50MB | 0.58% | `github.com/snissn/gomap/TreeDB/caching.getVlogPreparedFrames` |
| 0.50MB | 0.58% | 2.02MB | 2.34% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 7.17MB | 8.32% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 48.84MB | 56.70% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 48.84MB | 56.70% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 48.84MB | 56.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 4.50MB | 5.23% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLog` |
| 0 | 0.00% | 4.50MB | 5.23% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogInternal (inline)` |
| 0 | 0.00% | 4.50MB | 5.23% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogInternalObserved` |
| 0 | 0.00% | 29.62MB | 34.39% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 29.62MB | 34.39% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |

## Full vs Prefix Comparison

### treedb

- shared hotspots:
  - `runtime.scanObject` (full 6.67%, prefix 50.00%)
  - `runtime.spanClass.sizeclass (inline)` (full 2.22%, prefix 8.33%)
- prefix-only hotspots:
  - `aeshashbody` (8.33% flat)
  - `runtime.(*sweepClass).update (inline)` (8.33% flat)
  - `runtime.divRoundUp (inline)` (8.33% flat)
  - `runtime.findObject` (8.33% flat)
  - `runtime.heapArenaOf (inline)` (8.33% flat)
- full-only hotspots:
  - `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` (42.22% flat)
  - `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` (6.67% flat)
  - `internal/runtime/syscall/linux.Syscall6` (4.44% flat)
  - `main.runBenchmark.func37` (4.44% flat)
  - `runtime.memmove` (4.44% flat)

## Contention Profiles (Per Test)

### batch_delete (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_batch_delete_treedb.pprof`
- total samples: `468.16us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 468.16us | 100.00% | 468.16us | 100.00% | `runtime.chanrecv1` |
| 0 | 0.00% | 468.16us | 100.00% | `main.main` |
| 0 | 0.00% | 468.16us | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 468.16us | 100.00% | `main.runBenchmark.func47` |
| 0 | 0.00% | 468.16us | 100.00% | `main.runBenchmark.func48` |
| 0 | 0.00% | 468.16us | 100.00% | `runtime.main` |
| 0 | 0.00% | 468.16us | 100.00% | `runtime/pprof.StopCPUProfile` |

### batch_delete (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_batch_delete_treedb.pprof`
- total samples: `0`

_No entries parsed._

### batch_random (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_batch_random_treedb.pprof`
- total samples: `100.40ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 100.01ms | 99.61% | 100.01ms | 99.61% | `runtime.selectgo` |
| 0 | 0.00% | 100.01ms | 99.61% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 100.01ms | 99.61% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |

### batch_random (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_batch_random_treedb.pprof`
- total samples: `0`

_No entries parsed._

### batch_small_seq (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_batch_small_seq_treedb.pprof`
- total samples: `1003.19ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 902.05ms | 89.92% | 902.05ms | 89.92% | `runtime.selectgo` |
| 101.14ms | 10.08% | 101.14ms | 10.08% | `runtime.chanrecv1` |
| 0 | 0.00% | 500.10ms | 49.85% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 100.71ms | 10.04% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 500.10ms | 49.85% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 100.71ms | 10.04% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 249.93ms | 24.91% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 249.93ms | 24.91% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 51.31ms | 5.11% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 100.69ms | 10.04% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.69ms | 10.04% | `runtime.traceStartReadCPU.func1` |

### batch_small_seq (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_batch_small_seq_treedb.pprof`
- total samples: `0`

_No entries parsed._

### batch_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_batch_write_treedb.pprof`
- total samples: `357.28us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 357.28us | 100.00% | 357.28us | 100.00% | `runtime.chanrecv1` |
| 0 | 0.00% | 357.28us | 100.00% | `main.main` |
| 0 | 0.00% | 357.28us | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 357.28us | 100.00% | `main.runBenchmark.func47` |
| 0 | 0.00% | 357.28us | 100.00% | `main.runBenchmark.func48` |
| 0 | 0.00% | 357.28us | 100.00% | `runtime.main` |
| 0 | 0.00% | 357.28us | 100.00% | `runtime/pprof.StopCPUProfile` |

### batch_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_batch_write_treedb.pprof`
- total samples: `0`

_No entries parsed._

### batch_write_steady (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_batch_write_steady_treedb.pprof`
- total samples: `1.36s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.76s | 55.60% | 0.76s | 55.60% | `runtime.chanrecv2` |
| 0.39s | 28.94% | 0.39s | 28.94% | `runtime.selectgo` |
| 0.11s | 8.02% | 0.11s | 8.02% | `sync.(*WaitGroup).Wait` |
| 0.10s | 7.41% | 0.10s | 7.41% | `runtime.chanrecv1` |
| 0 | 0.00% | 0.10s | 7.11% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 0.10s | 7.11% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 0.10s | 7.11% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |
| 0 | 0.00% | 0.10s | 7.11% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 0.03s | 1.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 0.03s | 1.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 0.03s | 1.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4` |
| 0 | 0.00% | 0.03s | 1.86% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func5` |
| 0 | 0.00% | 0.03s | 1.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 0.08s | 6.13% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCheckpointFrontierLocked` |
| 0 | 0.00% | 0.03s | 1.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCheckpointFrontierLocked.func1` |
| 0 | 0.00% | 0.03s | 1.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 0.10s | 7.36% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 0.10s | 7.36% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 0.03s | 1.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).writeCanonicalFlushRunOpsChunk` |
| 0 | 0.00% | 0.03s | 1.86% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 0 | 0.00% | 0.03s | 1.89% | `github.com/snissn/gomap/TreeDB/db.(*Batch).Write` |
| 0 | 0.00% | 0.03s | 1.89% | `github.com/snissn/gomap/TreeDB/db.(*Batch).write` |

### batch_write_steady (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_batch_write_steady_treedb.pprof`
- total samples: `671.18us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 547.92us | 81.64% | 547.92us | 81.64% | `sync.(*Mutex).Unlock (inline)` |
| 65.18us | 9.71% | 605.68us | 90.24% | `sync.(*RWMutex).Unlock` |
| 51.78us | 7.72% | 51.78us | 7.72% | `runtime.unlock (inline)` |
| 6.30us | 0.94% | 6.30us | 0.94% | `sync.(*RWMutex).RUnlock` |
| 0 | 0.00% | 17.67us | 2.63% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogOneInternal` |
| 0 | 0.00% | 7.42us | 1.11% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushValueLogLaneWithSize` |
| 0 | 0.00% | 7.42us | 1.11% | `github.com/snissn/gomap/TreeDB/caching.(*DB).installBackendValueLogReadBarrier.func2` |
| 0 | 0.00% | 65.18us | 9.71% | `github.com/snissn/gomap/TreeDB/caching.(*DB).leafLogAppendLaneForWorkerIndex` |
| 0 | 0.00% | 499.59us | 74.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteLeafGenerationRecordLength` |
| 0 | 0.00% | 11.38us | 1.69% | `github.com/snissn/gomap/TreeDB/caching.(*DB).prepareAppendFrameOne` |
| 0 | 0.00% | 517.27us | 77.07% | `github.com/snissn/gomap/TreeDB/caching.(*cachingLeafPageLog).AppendPreparedLeafPage` |
| 0 | 0.00% | 65.18us | 9.71% | `github.com/snissn/gomap/TreeDB/caching.(*cachingLeafPageLogGroup).LeafPageLogLane` |
| 0 | 0.00% | 65.18us | 9.71% | `github.com/snissn/gomap/TreeDB/caching.(*cachingLeafPageLogGroup).laneForWorkerIndex` |
| 0 | 0.00% | 65.18us | 9.71% | `github.com/snissn/gomap/TreeDB/caching.(*cachingLeafPageLogGroup).laneLog` |
| 0 | 0.00% | 7.42us | 1.11% | `github.com/snissn/gomap/TreeDB/caching.dispatchBackendValueLogReadBarrierWithSize` |
| 0 | 0.00% | 499.59us | 74.44% | `github.com/snissn/gomap/TreeDB/db.(*DB).NoteLeafGenerationRecordLength` |
| 0 | 0.00% | 550.58us | 82.03% | `github.com/snissn/gomap/TreeDB/db.(*DB).noteLeafGenerationRecordLengthRaw` |
| 0 | 0.00% | 7.42us | 1.11% | `github.com/snissn/gomap/TreeDB/db.(*cachedLeafPageReader).ReadUnsafeToWithCacheHit` |
| 0 | 0.00% | 568.26us | 84.67% | `github.com/snissn/gomap/TreeDB/db.(*leafPageLogWithRecordLengthHints).AppendPreparedLeafPage` |
| 0 | 0.00% | 65.18us | 9.71% | `github.com/snissn/gomap/TreeDB/db.(*leafPageLogWithRecordLengthHints).LeafPageLogLane` |
| 0 | 0.00% | 65.18us | 9.71% | `github.com/snissn/gomap/TreeDB/db.(*leafPageLogWithRecordLengthHints).LeafPageLogLaneAny` |
| 0 | 0.00% | 50.99us | 7.60% | `github.com/snissn/gomap/TreeDB/db.(*leafPageLogWithRecordLengthHints).noteLeafPagePointer` |
| 0 | 0.00% | 7.42us | 1.11% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |
| 0 | 0.00% | 7.42us | 1.11% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ensureCurrentWritableReadableFor` |

### dataset_write_random (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_dataset_write_random_treedb.pprof`
- total samples: `201.16ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 100.81ms | 50.12% | 100.81ms | 50.12% | `runtime.chanrecv1` |
| 100.34ms | 49.88% | 100.34ms | 49.88% | `runtime.selectgo` |
| 0 | 0.00% | 100.34ms | 49.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 100.34ms | 49.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 100.31ms | 49.87% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.31ms | 49.87% | `runtime.traceStartReadCPU.func1` |

### dataset_write_random (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_dataset_write_random_treedb.pprof`
- total samples: `0`

_No entries parsed._

### dataset_write_sorted (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_dataset_write_sorted_treedb.pprof`
- total samples: `201.61ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 101.30ms | 50.24% | 101.30ms | 50.24% | `runtime.chanrecv1` |
| 100.31ms | 49.76% | 100.31ms | 49.76% | `runtime.selectgo` |
| 0 | 0.00% | 100.31ms | 49.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 100.31ms | 49.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 100.84ms | 50.02% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.84ms | 50.02% | `runtime.traceStartReadCPU.func1` |

### dataset_write_sorted (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_dataset_write_sorted_treedb.pprof`
- total samples: `0`

_No entries parsed._

### full_scan (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_full_scan_treedb.pprof`
- total samples: `2203ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1800.19ms | 81.72% | 1800.19ms | 81.72% | `runtime.selectgo` |
| 402.81ms | 18.28% | 402.81ms | 18.28% | `runtime.chanrecv1` |
| 0 | 0.00% | 500.18ms | 22.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 300.16ms | 13.63% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 500.18ms | 22.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 300.16ms | 13.63% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 499.41ms | 22.67% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 499.41ms | 22.67% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 500.44ms | 22.72% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 402.17ms | 18.26% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 402.17ms | 18.26% | `runtime.traceStartReadCPU.func1` |

### full_scan (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_full_scan_treedb.pprof`
- total samples: `0`

_No entries parsed._

### prefix_scan (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_prefix_scan_treedb.pprof`
- total samples: `283.60us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 283.60us | 100.00% | 283.60us | 100.00% | `runtime.chanrecv1` |
| 0 | 0.00% | 283.60us | 100.00% | `main.main` |
| 0 | 0.00% | 283.60us | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 283.60us | 100.00% | `main.runBenchmark.func47` |
| 0 | 0.00% | 283.60us | 100.00% | `main.runBenchmark.func48` |
| 0 | 0.00% | 283.60us | 100.00% | `runtime.main` |
| 0 | 0.00% | 283.60us | 100.00% | `runtime/pprof.StopCPUProfile` |

### prefix_scan (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_prefix_scan_treedb.pprof`
- total samples: `0`

_No entries parsed._

### random_delete (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_random_delete_treedb.pprof`
- total samples: `1201.94ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1100.70ms | 91.58% | 1100.70ms | 91.58% | `runtime.selectgo` |
| 101.24ms | 8.42% | 101.24ms | 8.42% | `runtime.chanrecv1` |
| 0 | 0.00% | 100.72ms | 8.38% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 100.72ms | 8.38% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 999.98ms | 83.20% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |
| 0 | 0.00% | 999.98ms | 83.20% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).start.gowrap1` |
| 0 | 0.00% | 100.81ms | 8.39% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.81ms | 8.39% | `runtime.traceStartReadCPU.func1` |

### random_delete (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_random_delete_treedb.pprof`
- total samples: `0`

_No entries parsed._

### random_read (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_random_read_treedb.pprof`
- total samples: `3097.90ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1694.74ms | 54.71% | 1694.74ms | 54.71% | `runtime.selectgo` |
| 1403.16ms | 45.29% | 1403.16ms | 45.29% | `runtime.chanrecv1` |
| 0 | 0.00% | 499.33ms | 16.12% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 400.18ms | 12.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 499.33ms | 16.12% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 400.18ms | 12.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 499.13ms | 16.11% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 499.13ms | 16.11% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 296.11ms | 9.56% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 1000.38ms | 32.29% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1402.41ms | 45.27% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 402.03ms | 12.98% | `runtime.traceStartReadCPU.func1` |

### random_read (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_random_read_treedb.pprof`
- total samples: `2.65us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2.65us | 100.00% | 2.65us | 100.00% | `runtime.unlock (inline)` |
| 0 | 0.00% | 2.65us | 100.00% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 2.65us | 100.00% | `runtime.(*traceMap).newTraceMapNode` |
| 0 | 0.00% | 2.65us | 100.00% | `runtime.(*traceMap).put` |
| 0 | 0.00% | 2.65us | 100.00% | `runtime.(*traceRegionAlloc).alloc` |
| 0 | 0.00% | 2.65us | 100.00% | `runtime.(*traceRegionAlloc).alloc.func1` |
| 0 | 0.00% | 2.65us | 100.00% | `runtime.(*traceStackTable).put` |
| 0 | 0.00% | 2.65us | 100.00% | `runtime.systemstack` |
| 0 | 0.00% | 2.65us | 100.00% | `runtime.traceAdvance` |
| 0 | 0.00% | 2.65us | 100.00% | `runtime.traceLocker.Gomaxprocs` |
| 0 | 0.00% | 2.65us | 100.00% | `runtime.traceLocker.stack (inline)` |
| 0 | 0.00% | 2.65us | 100.00% | `runtime.traceStack` |

### random_read_batch (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_random_read_batch_treedb.pprof`
- total samples: `657.12ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 600.45ms | 91.38% | 600.45ms | 91.38% | `runtime.selectgo` |
| 54.33ms | 8.27% | 54.33ms | 8.27% | `sync.(*WaitGroup).Wait` |
| 0 | 0.00% | 54.33ms | 8.27% | `github.com/snissn/gomap/TreeDB.(*DB).GetManyView` |
| 0 | 0.00% | 54.33ms | 8.27% | `github.com/snissn/gomap/TreeDB/caching.(*DB).GetManyView` |
| 0 | 0.00% | 54.33ms | 8.27% | `github.com/snissn/gomap/TreeDB/caching.(*DB).backendGetManyView` |
| 0 | 0.00% | 99.96ms | 15.21% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 99.96ms | 15.21% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 250.63ms | 38.14% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 250.63ms | 38.14% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 54.33ms | 8.27% | `github.com/snissn/gomap/TreeDB/db.(*DB).GetManyView` |
| 0 | 0.00% | 54.33ms | 8.27% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewOnce` |
| 0 | 0.00% | 54.33ms | 8.27% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel` |
| 0 | 0.00% | 249.86ms | 38.02% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 54.33ms | 8.27% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).GetManyView` |
| 0 | 0.00% | 55.09ms | 8.38% | `main.main` |
| 0 | 0.00% | 55.09ms | 8.38% | `main.runBenchmark` |
| 0 | 0.00% | 54.33ms | 8.27% | `main.runBenchmark.func35` |
| 0 | 0.00% | 55.09ms | 8.38% | `runtime.main` |

### random_read_batch (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_random_read_batch_treedb.pprof`
- total samples: `2153.42us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1711.30us | 79.47% | 1711.30us | 79.47% | `sync.(*Mutex).Unlock (partial-inline)` |
| 289.27us | 13.43% | 289.27us | 13.43% | `runtime.unlock (inline)` |
| 147.43us | 6.85% | 147.43us | 6.85% | `runtime._LostContendedRuntimeLock` |
| 0 | 0.00% | 1044.38us | 48.50% | `github.com/snissn/gomap/TreeDB/caching.(*DB).installBackendValueLogReadBarrier.func2` |
| 0 | 0.00% | 1044.38us | 48.50% | `github.com/snissn/gomap/TreeDB/caching.dispatchBackendValueLogReadBarrierWithSize` |
| 0 | 0.00% | 45.24us | 2.10% | `github.com/snissn/gomap/TreeDB/caching.readPoolPressureMemStats` |
| 0 | 0.00% | 45.24us | 2.10% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 45.24us | 2.10% | `github.com/snissn/gomap/TreeDB/caching.sampleAndPublishPoolPressureSnapshot` |
| 0 | 0.00% | 45.24us | 2.10% | `github.com/snissn/gomap/TreeDB/caching.samplePoolPressureSnapshot` |
| 0 | 0.00% | 1042.77us | 48.42% | `github.com/snissn/gomap/TreeDB/caching.snapshotBackendValueLogReadBarrierDBs` |
| 0 | 0.00% | 1723.42us | 80.03% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel.func3` |
| 0 | 0.00% | 1716.72us | 79.72% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel.gowrap1` |
| 0 | 0.00% | 1688.87us | 78.43% | `github.com/snissn/gomap/TreeDB/db.(*valueReader).ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 1695.22us | 78.72% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 1695.22us | 78.72% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadUnsafeTo` |
| 0 | 0.00% | 1695.22us | 78.72% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |
| 0 | 0.00% | 1044.38us | 48.50% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ensureCurrentWritableReadableFor` |
| 0 | 0.00% | 650.84us | 30.22% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).readAtWithDictTo` |
| 0 | 0.00% | 306.15us | 14.22% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).releaseDecodeScratch` |
| 0 | 0.00% | 306.15us | 14.22% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).releaseDecodeScratch-fm` |
| 0 | 0.00% | 338.34us | 15.71% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).takeDecodeScratch` |
| 0 | 0.00% | 338.34us | 15.71% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).takeDecodeScratch-fm` |
| 0 | 0.00% | 1695.22us | 78.72% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*Set).ReadUnsafeTo` |
| 0 | 0.00% | 650.84us | 30.22% | `github.com/snissn/gomap/TreeDB/internal/valuelog.readAtWithDictToScratch` |
| 0 | 0.00% | 1723.42us | 80.03% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).GetManyView` |

### random_read_parallel (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_random_read_parallel_treedb.pprof`
- total samples: `8.53s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 6.32s | 74.11% | 6.32s | 74.11% | `runtime.selectgo` |
| 1.53s | 17.88% | 1.53s | 17.88% | `runtime.chanrecv1` |
| 0.50s | 5.86% | 0.50s | 5.86% | `sync.(*WaitGroup).Wait` |
| 0.18s | 2.15% | 0.18s | 2.15% | `sync.(*Mutex).Lock (inline)` |
| 0 | 0.00% | 0.50s | 5.90% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 0.30s | 3.53% | `github.com/snissn/gomap/TreeDB/caching.(*DB).foregroundVlogMaintenanceContextWithResumeGrace.func1` |
| 0 | 0.00% | 0.30s | 3.53% | `github.com/snissn/gomap/TreeDB/caching.(*DB).foregroundVlogMaintenanceContextWithResumeGrace.gowrap1` |
| 0 | 0.00% | 0.50s | 5.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 1s | 11.74% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 1s | 11.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 0.50s | 5.90% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 1s | 11.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 0.50s | 5.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 0.50s | 5.85% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 0.50s | 5.85% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 0.18s | 2.13% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetAppend` |
| 0 | 0.00% | 2.01s | 23.58% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |
| 0 | 0.00% | 2.01s | 23.58% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).start.gowrap1` |
| 0 | 0.00% | 0.50s | 5.88% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 0.17s | 2.03% | `github.com/snissn/gomap/TreeDB/db.(*valueReader).ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 0.17s | 2.05% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 0.17s | 2.05% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadUnsafeTo` |
| 0 | 0.00% | 0.17s | 2.05% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |
| 0 | 0.00% | 0.12s | 1.45% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).readAtWithDictTo` |

### random_read_parallel (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_random_read_parallel_treedb.pprof`
- total samples: `156.73ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 153.70ms | 98.07% | 153.70ms | 98.07% | `sync.(*Mutex).Unlock (partial-inline)` |
| 2.72ms | 1.73% | 2.72ms | 1.73% | `runtime.unlock (inline)` |
| 0 | 0.00% | 36.54ms | 23.31% | `github.com/snissn/gomap/TreeDB/caching.(*DB).installBackendValueLogReadBarrier.func2` |
| 0 | 0.00% | 24.43ms | 15.59% | `github.com/snissn/gomap/TreeDB/caching.(*DB).leafLogAppendLaneMatchesSeq` |
| 0 | 0.00% | 24.43ms | 15.59% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogLaneForFileID` |
| 0 | 0.00% | 36.54ms | 23.31% | `github.com/snissn/gomap/TreeDB/caching.dispatchBackendValueLogReadBarrierWithSize` |
| 0 | 0.00% | 11.75ms | 7.50% | `github.com/snissn/gomap/TreeDB/caching.snapshotBackendValueLogReadBarrierDBs` |
| 0 | 0.00% | 153.83ms | 98.15% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetAppend` |
| 0 | 0.00% | 143.34ms | 91.46% | `github.com/snissn/gomap/TreeDB/db.(*valueReader).ReadLeafLogPageUnsafeToWithState` |

### random_read_parallel_acquire_snapshot (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `15510.22ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 10378ms | 66.91% | 10378ms | 66.91% | `runtime.selectgo` |
| 2507.81ms | 16.17% | 2507.81ms | 16.17% | `runtime.chanrecv1` |
| 1439.85ms | 9.28% | 1439.85ms | 9.28% | `sync.(*WaitGroup).Wait` |
| 1184.53ms | 7.64% | 1184.53ms | 7.64% | `sync.(*Mutex).Lock (inline)` |
| 0.02ms | 0.00% | 656.57ms | 4.23% | `sync.(*RWMutex).Lock` |
| 0 | 0.00% | 639.06ms | 4.12% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 639.06ms | 4.12% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 999.41ms | 6.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 343.53ms | 2.21% | `github.com/snissn/gomap/TreeDB/caching.(*DB).foregroundVlogMaintenanceContextWithResumeGrace.func1` |
| 0 | 0.00% | 343.53ms | 2.21% | `github.com/snissn/gomap/TreeDB/caching.(*DB).foregroundVlogMaintenanceContextWithResumeGrace.gowrap1` |
| 0 | 0.00% | 1399.56ms | 9.02% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 996.48ms | 6.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 999.41ms | 6.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 1399.56ms | 9.02% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 1247.92ms | 8.05% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 1247.92ms | 8.05% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 639.06ms | 4.12% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 639.06ms | 4.12% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 639.06ms | 4.12% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 639.06ms | 4.12% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotWithValueLogPublicationLockHeld (inline)` |
| 0 | 0.00% | 460.06ms | 2.97% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).Close` |

### random_read_parallel_acquire_snapshot (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `1147509.61us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 992793.38us | 86.52% | 1004144.83us | 87.51% | `sync.(*Mutex).Unlock (partial-inline)` |
| 151706.71us | 13.22% | 151706.71us | 13.22% | `runtime.unlock (inline)` |
| 2.83us | 0.00% | 487320.92us | 42.47% | `sync.(*RWMutex).Unlock` |
| 0 | 0.00% | 686199.04us | 59.80% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 686199.04us | 59.80% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 686199.04us | 59.80% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 686199.04us | 59.80% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 563948.65us | 49.15% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 563948.65us | 49.15% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotWithValueLogPublicationLockHeld (inline)` |
| 0 | 0.00% | 66838.08us | 5.82% | `github.com/snissn/gomap/TreeDB/db.(*DB).releaseLeafGenerationPinSet (inline)` |
| 0 | 0.00% | 68844.80us | 6.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).retainLeafGenerationPinSet (inline)` |
| 0 | 0.00% | 357065.42us | 31.12% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).Close` |
| 0 | 0.00% | 86360.43us | 7.53% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetAppend` |
| 0 | 0.00% | 357065.42us | 31.12% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead` |
| 0 | 0.00% | 357065.42us | 31.12% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead` |
| 0 | 0.00% | 66838.08us | 5.82% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).releaseLeafGenerationPins` |
| 0 | 0.00% | 122250.39us | 10.65% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 0 | 0.00% | 66838.08us | 5.82% | `github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinSet).release` |
| 0 | 0.00% | 66838.08us | 5.82% | `github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinSet).releasePinWork` |
| 0 | 0.00% | 68844.80us | 6.00% | `github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinSet).retain` |
| 0 | 0.00% | 67490.56us | 5.88% | `github.com/snissn/gomap/TreeDB/db.(*valueReader).ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 67798.60us | 5.91% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 67795.77us | 5.91% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadUnsafeTo` |
| 0 | 0.00% | 67795.77us | 5.91% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |

### random_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_random_write_treedb.pprof`
- total samples: `477.26us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 477.26us | 100.00% | 477.26us | 100.00% | `runtime.chanrecv1` |
| 0 | 0.00% | 477.26us | 100.00% | `main.main` |
| 0 | 0.00% | 477.26us | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 477.26us | 100.00% | `main.runBenchmark.func47` |
| 0 | 0.00% | 477.26us | 100.00% | `main.runBenchmark.func48` |
| 0 | 0.00% | 477.26us | 100.00% | `runtime.main` |
| 0 | 0.00% | 477.26us | 100.00% | `runtime/pprof.StopCPUProfile` |

### random_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_random_write_treedb.pprof`
- total samples: `0`

_No entries parsed._

### sequential_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block_sequential_write_treedb.pprof`
- total samples: `34.64ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 33.89ms | 97.84% | 33.89ms | 97.84% | `runtime.selectgo` |
| 0.74ms | 2.13% | 0.74ms | 2.13% | `runtime.chanrecv1` |
| 0 | 0.00% | 33.70ms | 97.27% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureVlogDictPrepWorkers.gowrap1` |
| 0 | 0.00% | 33.70ms | 97.27% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop` |

### sequential_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex_sequential_write_treedb.pprof`
- total samples: `136.46us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 129.56us | 94.95% | 129.56us | 94.95% | `runtime.unlock (inline)` |
| 4.12us | 3.02% | 4.12us | 3.02% | `sync.(*Mutex).Unlock` |
| 2.78us | 2.04% | 2.78us | 2.04% | `runtime._LostContendedRuntimeLock` |
| 0 | 0.00% | 4.12us | 3.02% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureVlogDictPrepWorkers.gowrap1` |
| 0 | 0.00% | 4.12us | 3.02% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop` |
| 0 | 0.00% | 4.12us | 3.02% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop.func1` |
| 0 | 0.00% | 4.12us | 3.02% | `github.com/snissn/gomap/TreeDB/caching.getVlogPreparedFrameBody` |
| 0 | 0.00% | 21.53us | 15.78% | `runtime.(*gcWork).init` |
| 0 | 0.00% | 21.53us | 15.78% | `runtime.(*gcWork).putObj` |
| 0 | 0.00% | 21.53us | 15.78% | `runtime.(*mheap).allocManual` |

## Contention Profiles (Global)

### block

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/block.pprof`
- total samples: `282.11s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 200.38s | 71.03% | 200.38s | 71.03% | `runtime.selectgo` |
| 54.40s | 19.28% | 54.40s | 19.28% | `runtime.chanrecv2` |
| 20.06s | 7.11% | 20.06s | 7.11% | `runtime.chanrecv1` |
| 5.78s | 2.05% | 5.78s | 2.05% | `sync.(*WaitGroup).Wait` |
| 1.48s | 0.53% | 1.48s | 0.53% | `sync.(*Mutex).Lock` |
| 0 | 0.00% | 3.47s | 1.23% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 3.47s | 1.23% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 3.47s | 1.23% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |
| 0 | 0.00% | 3.47s | 1.23% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 9.70s | 3.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 38.42s | 13.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureVlogDictPrepWorkers.gowrap1` |
| 0 | 0.00% | 3.30s | 1.17% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCheckpointFrontierLocked` |
| 0 | 0.00% | 9.92s | 3.52% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 9.68s | 3.43% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 9.20s | 3.26% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 8.36s | 2.96% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 56.28s | 19.95% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogWriter.gowrap1` |
| 0 | 0.00% | 9.70s | 3.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 38.42s | 13.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop` |
| 0 | 0.00% | 8.36s | 2.96% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 56.28s | 19.95% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogWriteLoop` |
| 0 | 0.00% | 9.68s | 3.43% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 9.92s | 3.52% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 9.95s | 3.53% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 9.95s | 3.53% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |

### mutex

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/mutex.pprof`
- total samples: `1436.10ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1271.91ms | 88.57% | 1283.28ms | 89.36% | `sync.(*Mutex).Unlock (partial-inline)` |
| 156.95ms | 10.93% | 156.95ms | 10.93% | `runtime.unlock (inline)` |
| 2.39ms | 0.17% | 601.94ms | 41.92% | `sync.(*RWMutex).Unlock` |
| 0 | 0.00% | 686.20ms | 47.78% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 686.20ms | 47.78% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 45.14ms | 3.14% | `github.com/snissn/gomap/TreeDB/caching.(*DB).installBackendValueLogReadBarrier.func2` |
| 0 | 0.00% | 30.04ms | 2.09% | `github.com/snissn/gomap/TreeDB/caching.(*DB).leafLogAppendLaneMatchesSeq` |
| 0 | 0.00% | 30.04ms | 2.09% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogLaneForFileID` |
| 0 | 0.00% | 45.14ms | 3.14% | `github.com/snissn/gomap/TreeDB/caching.dispatchBackendValueLogReadBarrierWithSize` |
| 0 | 0.00% | 686.20ms | 47.78% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 686.20ms | 47.78% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 563.95ms | 39.27% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 563.95ms | 39.27% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotWithValueLogPublicationLockHeld (inline)` |
| 0 | 0.00% | 66.84ms | 4.65% | `github.com/snissn/gomap/TreeDB/db.(*DB).releaseLeafGenerationPinSet (inline)` |
| 0 | 0.00% | 68.84ms | 4.79% | `github.com/snissn/gomap/TreeDB/db.(*DB).retainLeafGenerationPinSet (inline)` |
| 0 | 0.00% | 357.07ms | 24.86% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).Close` |
| 0 | 0.00% | 240.19ms | 16.72% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetAppend` |
| 0 | 0.00% | 357.07ms | 24.86% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead` |
| 0 | 0.00% | 357.07ms | 24.86% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead` |
| 0 | 0.00% | 66.84ms | 4.65% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).releaseLeafGenerationPins` |
| 0 | 0.00% | 122.25ms | 8.51% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 0 | 0.00% | 66.84ms | 4.65% | `github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinSet).release` |
| 0 | 0.00% | 66.84ms | 4.65% | `github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinSet).releasePinWork` |
| 0 | 0.00% | 68.84ms | 4.79% | `github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinSet).retain` |

## TreeDB Stats Metadata

### keys=200000 / TreeDB

| stat | value |
|---|---:|
| `treedb.applied_command_lsn` | `0` |
| `treedb.cache.append_only.entry_hint_capacity_bytes` | `1228128` |
| `treedb.cache.append_only.entry_hint_entries` | `12793` |
| `treedb.cache.append_only.entry_pool_admission_drop_bytes_total` | `0` |
| `treedb.cache.append_only.entry_pool_admission_drops_total` | `0` |
| `treedb.cache.append_only.entry_pool_drop_bytes_total` | `0` |
| `treedb.cache.append_only.entry_pool_drops_total` | `0` |
| `treedb.cache.append_only.entry_pool_gets_total` | `682` |
| `treedb.cache.append_only.entry_pool_puts_total` | `828` |
| `treedb.cache.append_only.entry_pool_retained_bytes_estimate` | `97168104` |
| `treedb.cache.append_only.entry_pool_retained_bytes_max_estimate` | `97168104` |
| `treedb.cache.append_only.mem_lease_count` | `8` |
| `treedb.cache.append_only.mem_lease_entry_backing_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_entry_capacity` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_active_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_active_chunks` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_retained_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_retained_chunks` | `0` |
| `treedb.cache.append_only.mutable_count` | `16` |
| `treedb.cache.append_only.mutable_entry_backing_bytes` | `0` |
| `treedb.cache.append_only.mutable_entry_capacity` | `0` |
| `treedb.cache.append_only.mutable_from_lease_total` | `88` |
| `treedb.cache.append_only.mutable_from_pool_total` | `0` |
| `treedb.cache.append_only.mutable_new_alloc_queue_bytes_sum` | `1412124008` |
| `treedb.cache.append_only.mutable_new_alloc_total` | `88` |
| `treedb.cache.append_only.mutable_new_alloc_with_queue_total` | `88` |
| `treedb.cache.append_only.mutable_pool_drops_total` | `0` |
| `treedb.cache.append_only.mutable_pool_entry_backing_dropped_bytes_total` | `2610784` |
| `treedb.cache.append_only.mutable_pool_puts_total` | `80` |
| `treedb.cache.append_only.mutable_sparse_trim_dropped_bytes_total` | `0` |
| `treedb.cache.append_only.mutable_sparse_trim_total` | `0` |
| `treedb.cache.append_only.mutable_trim_dropped_bytes_total` | `21605760` |
| `treedb.cache.append_only.mutable_trim_total` | `320` |
| `treedb.cache.append_only.mutable_value_arena_active_bytes` | `0` |
| `treedb.cache.append_only.mutable_value_arena_active_chunks` | `0` |
| `treedb.cache.append_only.mutable_value_arena_retained_bytes` | `0` |
| `treedb.cache.append_only.mutable_value_arena_retained_chunks` | `0` |
| `treedb.cache.append_only.reserve.calls_total` | `432` |
| `treedb.cache.append_only.reserve.entries_total` | `153761` |
| `treedb.cache.append_only.reserve.grow_bytes_total` | `235158176` |
| `treedb.cache.append_only.reserve.grow_calls_total` | `432` |
| `treedb.cache.append_only.reserve.skipped_growth_allocs_total` | `83` |
| `treedb.cache.append_only.reserve.skipped_growth_bytes_total` | `1576960` |
| `treedb.cache.append_only.value_arena_pool_admission_drop_bytes_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_admission_drops_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_drop_bytes_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_drops_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_gets_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_puts_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_retained_bytes_estimate` | `0` |
| `treedb.cache.append_only.value_arena_pool_retained_bytes_max_estimate` | `0` |
| `treedb.cache.auto_checkpoint.count` | `0` |
| `treedb.cache.auto_checkpoint.last_reason` | `interval` |
| `treedb.cache.backpressure_mode` | `adaptive` |
| `treedb.cache.checkpoint.active` | `false` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_last` | `0` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_max` | `0` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_total` | `0` |
| `treedb.cache.checkpoint.active_background_flush_wait_samples` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_last_internal_fill_avg_ppm` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_last_internal_fill_p50_ppm` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_last_pages` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_runs` | `0` |
| `treedb.cache.checkpoint.barrier_wait_ns_max` | `719` |
| `treedb.cache.checkpoint.barrier_wait_ns_total` | `8009` |
| `treedb.cache.checkpoint.barrier_wait_samples` | `20` |
| `treedb.cache.checkpoint.cutover_avg_ms` | `0.273` |
| `treedb.cache.checkpoint.cutover_last_ms` | `0.000` |
| `treedb.cache.checkpoint.cutover_last_unix_nano` | `1795198100283744181` |
| `treedb.cache.checkpoint.cutover_max_ms` | `1.690` |
| `treedb.cache.checkpoint.cutover_samples` | `20` |
| `treedb.cache.checkpoint.debt.active_in_flight_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt.active_in_flight_bytes_max` | `0` |
| `treedb.cache.checkpoint.debt.active_workers_last` | `0` |
| `treedb.cache.checkpoint.debt.active_workers_max` | `0` |
| `treedb.cache.checkpoint.debt.frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.debt.frontier_lanes_max` | `0` |
| `treedb.cache.checkpoint.debt.mutable_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt.mutable_bytes_max` | `32000000` |
| `treedb.cache.checkpoint.debt.queue_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt.queue_bytes_max` | `0` |
| `treedb.cache.checkpoint.debt.queue_units_last` | `0` |
| `treedb.cache.checkpoint.debt.queue_units_max` | `0` |
| `treedb.cache.checkpoint.debt_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt_bytes_max` | `32000000` |
| `treedb.cache.checkpoint.debt_memtables_last` | `0` |
| `treedb.cache.checkpoint.debt_memtables_max` | `1` |
| `treedb.cache.checkpoint.flush_all.background_drain_bytes_last` | `0` |
| `treedb.cache.checkpoint.flush_all.background_drain_ops_last` | `0` |
| `treedb.cache.checkpoint.flush_all.background_drain_units_last` | `0` |
| `treedb.cache.checkpoint.flush_all.frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.flush_all.frontier_lanes_max` | `1` |
| `treedb.cache.checkpoint.flush_all.owned_drain_bytes_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_bytes_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.flush_all.owned_drain_ns_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_ops_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_units_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_units_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.flush_all.worker_passes_total` | `10` |
| `treedb.cache.checkpoint.flush_all.workers_last` | `0` |
| `treedb.cache.checkpoint.flush_all.workers_max` | `1` |
| `treedb.cache.checkpoint.flush_all.workers_total` | `10` |
| `treedb.cache.checkpoint.flush_preempt_requests_total` | `20` |
| `treedb.cache.checkpoint.flushmu_wait_max_ms` | `0.001` |
| `treedb.cache.checkpoint.flushmu_wait_total_ms` | `0.007` |
| `treedb.cache.checkpoint.frontier.bytes_last` | `1600000` |
| `treedb.cache.checkpoint.frontier.bytes_max` | `32000000` |
| `treedb.cache.checkpoint.frontier.drained_bytes_last` | `1600000` |
| `treedb.cache.checkpoint.frontier.drained_units_last` | `16` |
| `treedb.cache.checkpoint.frontier.post_bytes_last` | `0` |
| `treedb.cache.checkpoint.frontier.post_bytes_max` | `0` |
| `treedb.cache.checkpoint.frontier.post_units_last` | `0` |
| `treedb.cache.checkpoint.frontier.post_units_max` | `0` |
| `treedb.cache.checkpoint.frontier.samples` | `10` |
| `treedb.cache.checkpoint.frontier.units_last` | `16` |
| `treedb.cache.checkpoint.frontier.units_max` | `16` |
| `treedb.cache.checkpoint.max_ms` | `1083.537` |
| `treedb.cache.checkpoint.noop_skips` | `10` |
| `treedb.cache.checkpoint.post_frontier_admission.active` | `false` |
| `treedb.cache.checkpoint.post_frontier_admission_enabled` | `false` |
| `treedb.cache.checkpoint.preflush_kick_skips_total` | `10` |
| `treedb.cache.checkpoint.productive_wait_ratio_last` | `0.000000` |
| `treedb.cache.checkpoint.runs` | `20` |
| `treedb.cache.checkpoint.shared_drain.background_bytes_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.background_ops_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.background_units_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_bytes_total` | `213622768` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_ops_total` | `1876638` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_units_total` | `160` |
| `treedb.cache.checkpoint.shared_drain.flushmu_releases_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.wait_ns_max` | `0` |
| `treedb.cache.checkpoint.shared_drain.wait_ns_total` | `0` |
| `treedb.cache.checkpoint.stage.auto_critical_section.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.auto_critical_section.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.auto_critical_section.samples` | `0` |
| `treedb.cache.checkpoint.stage.auto_critical_section.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.backend_boundary.last_ns` | `1387` |
| `treedb.cache.checkpoint.stage.backend_boundary.max_ns` | `22520380` |
| `treedb.cache.checkpoint.stage.backend_boundary.samples` | `20` |
| `treedb.cache.checkpoint.stage.backend_boundary.total_ns` | `169004934` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.samples` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.samples` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.samples` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_publish.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_publish.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_publish.samples` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_publish.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.cutover.last_ns` | `243` |
| `treedb.cache.checkpoint.stage.cutover.max_ns` | `1690009` |
| `treedb.cache.checkpoint.stage.cutover.samples` | `20` |
| `treedb.cache.checkpoint.stage.cutover.total_ns` | `5455623` |
| `treedb.cache.checkpoint.stage.flush_all.last_ns` | `1070254516` |
| `treedb.cache.checkpoint.stage.flush_all.max_ns` | `1070254516` |
| `treedb.cache.checkpoint.stage.flush_all.samples` | `10` |
| `treedb.cache.checkpoint.stage.flush_all.total_ns` | `3298313069` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.last_ns` | `7692107` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.max_ns` | `7770273` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.samples` | `10` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.total_ns` | `18160790` |
| `treedb.cache.checkpoint.stage.post_maintenance.last_ns` | `18112` |
| `treedb.cache.checkpoint.stage.post_maintenance.max_ns` | `43065` |
| `treedb.cache.checkpoint.stage.post_maintenance.samples` | `10` |
| `treedb.cache.checkpoint.stage.post_maintenance.total_ns` | `223627` |
| `treedb.cache.checkpoint.stage.reducer_publish.last_ns` | `1526` |
| `treedb.cache.checkpoint.stage.reducer_publish.max_ns` | `4724012` |
| `treedb.cache.checkpoint.stage.reducer_publish.samples` | `10` |
| `treedb.cache.checkpoint.stage.reducer_publish.total_ns` | `16829280` |
| `treedb.cache.checkpoint.stage.value_log_flush.last_ns` | `239` |
| `treedb.cache.checkpoint.stage.value_log_flush.max_ns` | `1353` |
| `treedb.cache.checkpoint.stage.value_log_flush.samples` | `10` |
| `treedb.cache.checkpoint.stage.value_log_flush.total_ns` | `4911` |
| `treedb.cache.checkpoint.stage.wal_cleanup.last_ns` | `511` |
| `treedb.cache.checkpoint.stage.wal_cleanup.max_ns` | `553` |
| `treedb.cache.checkpoint.stage.wal_cleanup.samples` | `10` |
| `treedb.cache.checkpoint.stage.wal_cleanup.total_ns` | `4744` |
| `treedb.cache.checkpoint.stage.wal_rotate.last_ns` | `32` |
| `treedb.cache.checkpoint.stage.wal_rotate.max_ns` | `53` |
| `treedb.cache.checkpoint.stage.wal_rotate.samples` | `10` |
| `treedb.cache.checkpoint.stage.wal_rotate.total_ns` | `399` |
| `treedb.cache.checkpoint.total_ms` | `3473.542` |
| `treedb.cache.checkpoint.wait.active_in_flight_bytes_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.active_workers_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_bytes_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_units_last` | `0` |
| `treedb.cache.checkpoint.wait.frontier_bytes_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.frontier_drain_bytes_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.wait.frontier_drain_units_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.wait.frontier_lanes_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.frontier_units_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.post_frontier_bytes_last` | `0` |
| `treedb.cache.checkpoint.wait.post_frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.wait.post_frontier_units_last` | `0` |
| `treedb.cache.checkpoint.wait.remaining_frontier_bytes_last` | `0` |
| `treedb.cache.checkpoint.wait.remaining_frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.wait.remaining_frontier_units_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.considered_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.removed_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_current_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_pre_rotate_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_retained_last` | `0` |
| `treedb.cache.checkpoint.write_cutover.active` | `false` |
| `treedb.cache.command_wal.checkpoint_publish.piggybacked` | `0` |
| `treedb.cache.command_wal.checkpoint_publish.separate` | `0` |
| `treedb.cache.command_wal.cleanup.active` | `false` |
| `treedb.cache.command_wal.cleanup.coalesced_total` | `0` |
| `treedb.cache.command_wal.cleanup.completions_total` | `0` |
| `treedb.cache.command_wal.cleanup.pending` | `false` |
| `treedb.cache.command_wal.cleanup.requests_total` | `0` |
| `treedb.cache.command_wal.cleanup.retries_total` | `0` |
| `treedb.cache.command_wal.external_durability` | `false` |
| `treedb.cache.flush_apply.backend_batch_write_ns_total` | `2663297183` |
| `treedb.cache.flush_apply.backend_write_ns_total` | `3185670234` |
| `treedb.cache.flush_apply.batches_total` | `11` |
| `treedb.cache.flush_apply.build_ns_total` | `182745970` |
| `treedb.cache.flush_apply.bytes_total` | `230400000` |
| `treedb.cache.flush_apply.concurrency` | `6` |
| `treedb.cache.flush_apply.coordinator.active` | `0` |
| `treedb.cache.flush_apply.coordinator.active_assist_skips_total` | `0` |
| `treedb.cache.flush_apply.coordinator.active_workers` | `0` |
| `treedb.cache.flush_apply.coordinator.blocking_fallbacks_total` | `0` |
| `treedb.cache.flush_apply.coordinator.checkpoint_preemptions_total` | `0` |
| `treedb.cache.flush_apply.coordinator.errors_total` | `0` |
| `treedb.cache.flush_apply.coordinator.hard_overload_fallbacks_total` | `0` |
| `treedb.cache.flush_apply.coordinator.in_flight_bytes` | `0` |
| `treedb.cache.flush_apply.coordinator.progress_total` | `11` |
| `treedb.cache.flush_apply.coordinator.progress_wait_ns_total` | `0` |
| `treedb.cache.flush_apply.coordinator.progress_waits_total` | `0` |
| `treedb.cache.flush_apply.coordinator.stall_waits_total` | `0` |
| `treedb.cache.flush_apply.deferred_vlog_pointer_materialize_ns_total` | `17059` |
| `treedb.cache.flush_apply.entries_total` | `2000000` |
| `treedb.cache.flush_apply.foreground_assist_calls_total` | `0` |
| `treedb.cache.flush_apply.foreground_assist_flushes_total` | `0` |
| `treedb.cache.flush_apply.foreground_assist_wait_ns_total` | `0` |
| `treedb.cache.flush_apply.leaf_log_append_bytes_total` | `47009729` |
| `treedb.cache.flush_apply.leaf_log_append_frames_per_op` | `0.033762` |
| `treedb.cache.flush_apply.leaf_log_append_frames_total` | `67524` |
| `treedb.cache.flush_apply.leaf_log_append_ns_total` | `420309933` |
| `treedb.cache.flush_apply.leaf_log_append_records_total` | `112603` |
| `treedb.cache.flush_apply.leaf_log_append_wait_ns_total` | `18156968` |
| `treedb.cache.flush_apply.leaf_log_encode_compress_ns_total` | `128655850` |
| `treedb.cache.flush_apply.planning_ns_total` | `39881` |
| `treedb.cache.flush_apply.span_native` | `true` |
| `treedb.cache.flush_apply.units_total` | `176` |
| `treedb.cache.flush_apply.vlog_flush_ns_total` | `28101` |
| `treedb.cache.flush_apply.vlog_sync_ns_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_runs_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.admitted_runs_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.base_budget_covered_total` | `10` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_bytes_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_memtables_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_ops_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.decisions_total` | `11` |
| `treedb.cache.flush_backlog_coalescing.enabled` | `true` |
| `treedb.cache.flush_backlog_coalescing.last_old_leaf_bytes_per_op` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.last_ops_per_span` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.last_single_op_span_ratio` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.queued_age_ns_max` | `1714513` |
| `treedb.cache.flush_backlog_coalescing.queued_bytes_max` | `32000000` |
| `treedb.cache.flush_backlog_coalescing.queued_memtables_max` | `16` |
| `treedb.cache.flush_backlog_coalescing.selected_bytes_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_memtables_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_ops_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.checkpoint_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.close_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.disabled_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.lane_barrier_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.memory_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.memtable_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.no_pressure_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.ops_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.queue_age_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.queue_depth_total` | `11` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.range_barrier_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.stop_pressure_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.writer_stall_budget_total` | `0` |
| `treedb.cache.flush_span_run.backend_chunks_total` | `110` |
| `treedb.cache.flush_span_run.max_chunks_per_target_leaf` | `0` |
| `treedb.cache.flush_span_run.ops_per_run` | `166679.545455` |
| `treedb.cache.flush_span_run.planned_ops_total` | `1833475` |
| `treedb.cache.flush_span_run.planned_point_ops_total` | `1833475` |
| `treedb.cache.flush_span_run.range_barriers_total` | `0` |
| `treedb.cache.flush_span_run.range_delete_ops_total` | `0` |
| `treedb.cache.flush_span_run.runs_total` | `11` |
| `treedb.cache.flush_span_run.shadowed_ops_total` | `0` |
| `treedb.cache.flush_span_run.single_op_spans_total` | `0` |
| `treedb.cache.flush_span_run.source_memtables_max` | `16` |
| `treedb.cache.flush_span_run.source_memtables_total` | `176` |
| `treedb.cache.flush_span_run.source_point_ops_total` | `2000000` |
| `treedb.cache.flush_span_run.span_bytes_total` | `0` |
| `treedb.cache.flush_span_run.span_ops_total` | `0` |
| `treedb.cache.flush_span_run.target_leaf_spans_total` | `0` |
| `treedb.cache.flush_span_run.target_leaves_split_across_chunks_total` | `0` |
| `treedb.cache.leaf_log_lanes.active` | `7` |
| `treedb.cache.leaf_log_lanes.append_bytes_total` | `47009729` |
| `treedb.cache.leaf_log_lanes.append_calls_total` | `64155` |
| `treedb.cache.leaf_log_lanes.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.append_lanes_used` | `7` |
| `treedb.cache.leaf_log_lanes.append_lock_hold_ns_total` | `228852231` |
| `treedb.cache.leaf_log_lanes.append_lock_wait_ns_total` | `18156968` |
| `treedb.cache.leaf_log_lanes.append_pages_total` | `112603` |
| `treedb.cache.leaf_log_lanes.configured` | `7` |
| `treedb.cache.leaf_log_lanes.lane.00.append_bytes_total` | `13943456` |
| `treedb.cache.leaf_log_lanes.lane.00.append_calls_total` | `14383` |
| `treedb.cache.leaf_log_lanes.lane.00.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.00.append_lock_hold_ns_total` | `15120812` |
| `treedb.cache.leaf_log_lanes.lane.00.append_lock_wait_ns_total` | `15466582` |
| `treedb.cache.leaf_log_lanes.lane.00.append_pages_total` | `35851` |
| `treedb.cache.leaf_log_lanes.lane.00.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.00.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.00.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.00.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.append_bytes_total` | `6063347` |
| `treedb.cache.leaf_log_lanes.lane.01.append_calls_total` | `9773` |
| `treedb.cache.leaf_log_lanes.lane.01.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.append_lock_hold_ns_total` | `36415150` |
| `treedb.cache.leaf_log_lanes.lane.01.append_lock_wait_ns_total` | `730197` |
| `treedb.cache.leaf_log_lanes.lane.01.append_pages_total` | `14205` |
| `treedb.cache.leaf_log_lanes.lane.01.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.01.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.01.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.append_bytes_total` | `5514519` |
| `treedb.cache.leaf_log_lanes.lane.02.append_calls_total` | `8615` |
| `treedb.cache.leaf_log_lanes.lane.02.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.append_lock_hold_ns_total` | `32428024` |
| `treedb.cache.leaf_log_lanes.lane.02.append_lock_wait_ns_total` | `262954` |
| `treedb.cache.leaf_log_lanes.lane.02.append_pages_total` | `12957` |
| `treedb.cache.leaf_log_lanes.lane.02.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.02.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.02.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.append_bytes_total` | `5364613` |
| `treedb.cache.leaf_log_lanes.lane.03.append_calls_total` | `7890` |
| `treedb.cache.leaf_log_lanes.lane.03.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.append_lock_hold_ns_total` | `38888169` |
| `treedb.cache.leaf_log_lanes.lane.03.append_lock_wait_ns_total` | `482169` |
| `treedb.cache.leaf_log_lanes.lane.03.append_pages_total` | `12375` |
| `treedb.cache.leaf_log_lanes.lane.03.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.03.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.03.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.append_bytes_total` | `5331342` |
| `treedb.cache.leaf_log_lanes.lane.04.append_calls_total` | `7829` |
| `treedb.cache.leaf_log_lanes.lane.04.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.append_lock_hold_ns_total` | `38254883` |
| `treedb.cache.leaf_log_lanes.lane.04.append_lock_wait_ns_total` | `310447` |
| `treedb.cache.leaf_log_lanes.lane.04.append_pages_total` | `12243` |
| `treedb.cache.leaf_log_lanes.lane.04.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.04.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.04.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.append_bytes_total` | `5330922` |
| `treedb.cache.leaf_log_lanes.lane.05.append_calls_total` | `7811` |
| `treedb.cache.leaf_log_lanes.lane.05.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.append_lock_hold_ns_total` | `29267789` |
| `treedb.cache.leaf_log_lanes.lane.05.append_lock_wait_ns_total` | `249816` |
| `treedb.cache.leaf_log_lanes.lane.05.append_pages_total` | `12249` |
| `treedb.cache.leaf_log_lanes.lane.05.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.05.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.05.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.append_bytes_total` | `5461530` |
| `treedb.cache.leaf_log_lanes.lane.06.append_calls_total` | `7854` |
| `treedb.cache.leaf_log_lanes.lane.06.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.append_lock_hold_ns_total` | `38477404` |
| `treedb.cache.leaf_log_lanes.lane.06.append_lock_wait_ns_total` | `654803` |
| `treedb.cache.leaf_log_lanes.lane.06.append_pages_total` | `12723` |
| `treedb.cache.leaf_log_lanes.lane.06.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.06.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.06.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.segment_rotations_total` | `7` |
| `treedb.cache.memtable_mode` | `append_only` |
| `treedb.cache.memtable_residency.mutable.append_only.count` | `16` |
| `treedb.cache.memtable_residency.mutable.append_only.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.count` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.count` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.count` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.total.count` | `16` |
| `treedb.cache.memtable_residency.mutable.total.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.total.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.total.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.count` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entries` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.btree.count` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entries` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.btree.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.count` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entries` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.count` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entries` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.total.count` | `0` |
| `treedb.cache.memtable_residency.queue.total.entries` | `0` |
| `treedb.cache.memtable_residency.queue.total.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.total.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_retained_chunks` | `0` |
| `treedb.cache.queue_backlog_bytes` | `0` |
| `treedb.cache.queue_laneid_misses` | `0` |
| `treedb.cache.queue_len` | `0` |
| `treedb.cache.stats.backend_write_batches_total` | `110` |
| `treedb.cache.vlog_auto.bypass_bytes` | `0` |
| `treedb.cache.vlog_auto.bytes.block_lz4` | `392481611` |
| `treedb.cache.vlog_auto.bytes.block_snappy` | `0` |
| `treedb.cache.vlog_auto.bytes.block_zstd` | `0` |
| `treedb.cache.vlog_auto.bytes.dict` | `0` |
| `treedb.cache.vlog_auto.bytes.off` | `28` |
| `treedb.cache.vlog_auto.frames.block_lz4` | `67523` |
| `treedb.cache.vlog_auto.frames.block_snappy` | `0` |
| `treedb.cache.vlog_auto.frames.block_zstd` | `0` |
| `treedb.cache.vlog_auto.frames.dict` | `0` |
| `treedb.cache.vlog_auto.frames.off` | `1` |
| `treedb.cache.vlog_auto.frames_frac.block_lz4` | `0.999985` |
| `treedb.cache.vlog_auto.frames_frac.off` | `0.000015` |
| `treedb.cache.vlog_auto.hold_enters` | `0` |
| `treedb.cache.vlog_auto.hold_exits` | `0` |
| `treedb.cache.vlog_auto.probe_attempts` | `0` |
| `treedb.cache.vlog_auto.probe_successes` | `0` |
| `treedb.cache.vlog_autotune.encode_ns_per_raw_byte` | `0.657` |
| `treedb.cache.vlog_autotune.io_ns_per_stored_byte` | `8.486` |
| `treedb.cache.vlog_autotune.observed_ratio` | `0.082123` |
| `treedb.cache.vlog_autotune.throughput_raw_MBps` | `772.014` |
| `treedb.cache.vlog_block.k.avg.lz4` | `1.668` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_1` | `49344` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_2` | `8859` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_4` | `5764` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_8` | `3556` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_1` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_2` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_4` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_8` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_1` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_2` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_4` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_8` | `0` |
| `treedb.cache.vlog_block.k.count.lz4` | `67523` |
| `treedb.cache.vlog_block.k.count.snappy` | `0` |
| `treedb.cache.vlog_block.k.count.zstd` | `0` |
| `treedb.cache.vlog_block.k.max.lz4` | `8` |
| `treedb.cache.vlog_block.k.max.snappy` | `0` |
| `treedb.cache.vlog_block.k.max.zstd` | `0` |
| `treedb.cache.vlog_block.ratio.lz4` | `0.110139` |
| `treedb.cache.vlog_block.ratio.samples.lz4` | `0` |
| `treedb.cache.vlog_block.ratio.samples.snappy` | `0` |
| `treedb.cache.vlog_block.ratio.samples.zstd` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.capacity_waste_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.copied_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_fit_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_fit_requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_present_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_current_mmap_direct_decode.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_current_mmap_direct_decode.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_fit_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_fit_requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_present_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_template_encoded_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_template_encoded_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.realloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retain_max_bytes` | `131072` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_buffers` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_bytes` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_files` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.spare_max_count` | `2` |
| `treedb.cache.vlog_decode_scratch.large_pool.alloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.entries` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.gets_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.hits_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.max_entries` | `8` |
| `treedb.cache.vlog_decode_scratch.large_pool.misses_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.puts_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.retained_buffers` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.retained_bytes` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.too_small_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.alloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.alloc_calls_total` | `99` |
| `treedb.cache.vlog_decode_scratch.small_pool.allocated_bytes_total` | `3045288` |
| `treedb.cache.vlog_decode_scratch.small_pool.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.entries` | `9` |
| `treedb.cache.vlog_decode_scratch.small_pool.gets_total` | `81429` |
| `treedb.cache.vlog_decode_scratch.small_pool.hits_total` | `81330` |
| `treedb.cache.vlog_decode_scratch.small_pool.max_entries` | `128` |
| `treedb.cache.vlog_decode_scratch.small_pool.misses_total` | `99` |
| `treedb.cache.vlog_decode_scratch.small_pool.puts_total` | `81408` |
| `treedb.cache.vlog_decode_scratch.small_pool.retained_buffers` | `9` |
| `treedb.cache.vlog_decode_scratch.small_pool.retained_bytes` | `293410` |
| `treedb.cache.vlog_decode_scratch.small_pool.too_small_total` | `69` |
| `treedb.cache.vlog_dict.attempted_frac` | `1.000000` |
| `treedb.cache.vlog_dict.cached_dict_bytes` | `0` |
| `treedb.cache.vlog_dict.cached_dict_id` | `0` |
| `treedb.cache.vlog_dict.classifier.sampled` | `0` |
| `treedb.cache.vlog_dict.classifier.skipped` | `0` |
| `treedb.cache.vlog_dict.current_k` | `0` |
| `treedb.cache.vlog_dict.frames_attempted` | `67524` |
| `treedb.cache.vlog_dict.frames_kept` | `67523` |
| `treedb.cache.vlog_dict.frames_total` | `67524` |
| `treedb.cache.vlog_dict.incompressible_bypass_bytes` | `0` |
| `treedb.cache.vlog_dict.incompressible_hits` | `0` |
| `treedb.cache.vlog_dict.incompressible_hold_remaining_bytes` | `0` |
| `treedb.cache.vlog_dict.incompressible_holds` | `0` |
| `treedb.cache.vlog_dict.kept_frac` | `0.999985` |
| `treedb.cache.vlog_dict.last_applied_dict_hash` | `0` |
| `treedb.cache.vlog_dict.last_applied_dict_id` | `0` |
| `treedb.cache.vlog_dict.last_k_update_unix_nano` | `0` |
| `treedb.cache.vlog_dict.last_publish_unix_nano` | `0` |
| `treedb.cache.vlog_dict.pause_remaining_bytes` | `0` |
| `treedb.cache.vlog_dict.trainer.last_accept_unix_nano` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_accepts` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_attempts` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_reject_reason` | `` |
| `treedb.cache.vlog_dict.trainer.profile_rejects` | `0` |
| `treedb.cache.vlog_generation.bytes.live.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.live.hot` | `47009729` |
| `treedb.cache.vlog_generation.bytes.live.total` | `47009729` |
| `treedb.cache.vlog_generation.bytes.live.warm` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.hot` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.total` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.warm` | `0` |
| `treedb.cache.vlog_generation.bytes.total.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.total.hot` | `47009729` |
| `treedb.cache.vlog_generation.bytes.total.total` | `47009729` |
| `treedb.cache.vlog_generation.bytes.total.warm` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.active` | `false` |
| `treedb.cache.vlog_generation.checkpoint_kick.gc_runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.hot_no_debt_wake.running` | `true` |
| `treedb.cache.vlog_generation.checkpoint_kick.hot_no_debt_wake.runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.pending` | `false` |
| `treedb.cache.vlog_generation.checkpoint_kick.rewrite_runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.skipped_hot_no_debt` | `10` |
| `treedb.cache.vlog_generation.churn_bytes_per_sec` | `0` |
| `treedb.cache.vlog_generation.churn_bytes_total` | `33372995` |
| `treedb.cache.vlog_generation.cold.segment_target_bytes` | `536870912` |
| `treedb.cache.vlog_generation.deferred_vector_build.active` | `false` |
| `treedb.cache.vlog_generation.deferred_vector_build.debt` | `false` |
| `treedb.cache.vlog_generation.deferred_vector_build.debt_set` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.failures` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.finalizations` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.skips` | `0` |
| `treedb.cache.vlog_generation.enabled` | `true` |
| `treedb.cache.vlog_generation.gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.deleted_segments` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_eligible_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_eligible_segments` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.gc.exec.avg_ms` | `829.386` |
| `treedb.cache.vlog_generation.gc.exec.max_ms` | `829.386` |
| `treedb.cache.vlog_generation.gc.exec.total_ms` | `829.386` |
| `treedb.cache.vlog_generation.gc.last_active_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_active_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_deleted_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_eligible_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_eligible_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_active` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_deleted` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_eligible` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_pending` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_in_use` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_other` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_overlap` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_retained` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_referenced` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_active` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_deleted` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_eligible` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_pending` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_in_use` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_other` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_overlap` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_retained` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_referenced` | `0` |
| `treedb.cache.vlog_generation.gc.last_pending_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_pending_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_in_use_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_in_use_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_other_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_other_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_overlap_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_overlap_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_retained_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_retained_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_referenced_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_referenced_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_unix_nano` | `1795198097102044064` |
| `treedb.cache.vlog_generation.gc.runs` | `1` |
| `treedb.cache.vlog_generation.hot.segment_target_bytes` | `268435456` |
| `treedb.cache.vlog_generation.leaf.segment_target_bytes` | `33554432` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_manifest_bytes` | `554` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_manifest_revisions` | `2` |
| `treedb.cache.vlog_generation.leaf_gc.errors` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.exec.total_ms` | `15.607` |
| `treedb.cache.vlog_generation.leaf_gc.runs` | `1` |
| `treedb.cache.vlog_generation.leaf_pack.admitted` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attempts` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attributed_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attributed_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.bytes_copied` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.canceled` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.deadline` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.deadline_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.errors` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.expected_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.expected_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.eligible_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_eligible_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.runs` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_attributed_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_attributed_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_bytes_copied` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_expected_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_expected_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.bytes_dead` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.bytes_to_copy` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_skip_reason` | `` |
| `treedb.cache.vlog_generation.leaf_pack.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_wall_ms` | `0.000` |
| `treedb.cache.vlog_generation.leaf_pack.max_bytes_to_copy` | `268435456` |
| `treedb.cache.vlog_generation.leaf_pack.max_foreground_queue` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.max_generations` | `32` |
| `treedb.cache.vlog_generation.leaf_pack.min_candidate_generations` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.min_interval_ms` | `30000` |
| `treedb.cache.vlog_generation.leaf_pack.min_reclaim_per_byte_copied_ppm` | `250000` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_default` | `false` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_last_attempt_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_max_bytes_to_copy` | `33554432` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_max_generations` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_timeout_ms` | `5000` |
| `treedb.cache.vlog_generation.leaf_pack.runs` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.bytes_dead` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.bytes_to_copy` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.foreground_iterators` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.min_interval` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.queue_pressure` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.write_burst` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skips` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.stop.low_yield` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.timeout_ms` | `30000` |
| `treedb.cache.vlog_generation.leaf_pack.write_burst_grace_ms` | `250` |
| `treedb.cache.vlog_generation.maintenance.acquired` | `5` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.periodic` | `5` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.active` | `false` |
| `treedb.cache.vlog_generation.maintenance.attempts` | `5` |
| `treedb.cache.vlog_generation.maintenance.collisions` | `0` |
| `treedb.cache.vlog_generation.maintenance.foreground_active_iterators` | `0` |
| `treedb.cache.vlog_generation.maintenance.foreground_last_read_unix_nano` | `1795198100098183148` |
| `treedb.cache.vlog_generation.maintenance.foreground_last_write_unix_nano` | `1795198095039119698` |
| `treedb.cache.vlog_generation.maintenance.foreground_quiet` | `false` |
| `treedb.cache.vlog_generation.maintenance.foreground_read_age_ms` | `185` |
| `treedb.cache.vlog_generation.maintenance.foreground_read_quiet` | `false` |
| `treedb.cache.vlog_generation.maintenance.foreground_write_age_ms` | `5245` |
| `treedb.cache.vlog_generation.maintenance.foreground_write_quiet` | `false` |
| `treedb.cache.vlog_generation.maintenance.pass.avg_ms` | `169.288` |
| `treedb.cache.vlog_generation.maintenance.pass.max_ms` | `846.211` |
| `treedb.cache.vlog_generation.maintenance.pass.total_ms` | `846.440` |
| `treedb.cache.vlog_generation.maintenance.passes.noop` | `4` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.periodic` | `4` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc` | `1` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.periodic` | `1` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.pause_file.configured` | `false` |
| `treedb.cache.vlog_generation.maintenance.pause_file.paused` | `false` |
| `treedb.cache.vlog_generation.maintenance.skip.age_blocked_gate` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.before_first_checkpoint` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.checkpoint_inflight` | `1` |
| `treedb.cache.vlog_generation.maintenance.skip.maintenance_phase` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.pause_file` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.priority_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.quiet_window` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate_due_reserved` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate_not_due` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.wal_on_periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance_phase` | `steady` |
| `treedb.cache.vlog_generation.observed_gc.latency.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.observed_gc.latency.completed_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.dropped_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.max_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.total_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_oldest_age_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_oldest_unix_nano` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_attempts_max` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_attempts_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.queued_batches` | `0` |
| `treedb.cache.vlog_generation.observed_gc.queued_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.retry_dropped` | `0` |
| `treedb.cache.vlog_generation.observed_gc.retry_max_attempts` | `3` |
| `treedb.cache.vlog_generation.observed_gc.retry_queued` | `0` |
| `treedb.cache.vlog_generation.observed_gc.runs` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_deleted_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_eligible_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_in_use_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_other_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_overlap_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_retained_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_deleted_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_eligible_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_in_use_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_other_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_overlap_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_retained_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.taken_batches` | `0` |
| `treedb.cache.vlog_generation.observed_gc.taken_ids` | `0` |
| `treedb.cache.vlog_generation.policy` | `2` |
| `treedb.cache.vlog_generation.remap.failures` | `0` |
| `treedb.cache.vlog_generation.remap.successes` | `0` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_due` | `false` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_remaining_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_until_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.bytes_in` | `0` |
| `treedb.cache.vlog_generation.rewrite.bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs.queued_debt` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs.queued_debt` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.bytes_in_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.bytes_out_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.last_duration_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_live_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.last_live_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.reclaimed_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.reclaimed_vs_churn_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_still_referenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_still_referenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_still_referenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_still_referenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_unreferenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_unreferenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.ineffective_backoff_seconds` | `120` |
| `treedb.cache.vlog_generation.rewrite.ineffective_bytes_in` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_chunk_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_chunks` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_stale_ratio_ppm` | `0` |
| `treedb.cache.vlog_generation.rewrite.min_segment_age_ms` | `30000` |
| `treedb.cache.vlog_generation.rewrite.no_reclaim_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.no_reclaim_stale_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.output_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.penalties_active` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan_canceled` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty.age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty.no_selection` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_errors` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.to_empty_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_chunks_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_segments_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_live_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_stale_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_stale_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.queue.pending` | `false` |
| `treedb.cache.vlog_generation.rewrite.queue.running` | `false` |
| `treedb.cache.vlog_generation.rewrite.queue_config.debt_drain_max_segments` | `8` |
| `treedb.cache.vlog_generation.rewrite.queue_config.fresh_plan_debt_drain_max_segments` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_config.fresh_plan_debt_drain_min_segments` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_config.resume_max_segments` | `1` |
| `treedb.cache.vlog_generation.rewrite.queue_eta_seconds.budget` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_eta_seconds.recent_exec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_len` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_bytes_after_tokens` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.coverage_pct` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.ids_known` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.ids_present` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.known` | `true` |
| `treedb.cache.vlog_generation.rewrite.queue_loaded` | `true` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_after_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_after_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_before_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_before_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_delta_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_drained_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_grown_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_known_passes` | `5` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_unknown_passes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.passes` | `5` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_after_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_after_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_before_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_before_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_delta_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_drained_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_grown_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.snapshot_errors` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_prune_ids` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_prune_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.decisions` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.decisions.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter.checkpoint_kick` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter.fresh_plan` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_empty.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_per_segment` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_per_segment.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_tokens` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_tokens.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_burst` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_burst.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_safety` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_safety.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.debt_drain_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.debt_drain_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_queue_threshold` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_queue_threshold.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.none` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.none.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.queue_len` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.queue_len.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.resume_default` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.resume_default.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.effective_bytes_after` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.effective_bytes_before` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.gc_bytes_deleted` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.no_reclaim_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.reclaimed_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.source_bytes_requested` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.source_bytes_unreferenced` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.followup_suppressed` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.passes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.rewrite_started` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.budget_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.cancel_backoff` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.ineffective_backoff` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.min_interval` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.no_chunk` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.quiet_window` | `0` |
| `treedb.cache.vlog_generation.rewrite.reclaim_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.reclaimed_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_due` | `false` |
| `treedb.cache.vlog_generation.rewrite.stage_due_in_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_observed_age_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_observed_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_pending` | `false` |
| `treedb.cache.vlog_generation.rewrite.value_bytes_copied` | `0` |
| `treedb.cache.vlog_generation.rewrite.value_records_copied` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.bytes_per_sec` | `134217728` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_share_of_budget_pct` | `0.000` |
| `treedb.cache.vlog_generation.rewrite_budget.records_per_sec` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_bytes` | `402321777` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_cap_bytes` | `4294967296` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_utilization_pct` | `9.367` |
| `treedb.cache.vlog_generation.rewrite_trigger.churn_per_sec` | `0` |
| `treedb.cache.vlog_generation.rewrite_trigger.stale_ratio_ppm` | `200000` |
| `treedb.cache.vlog_generation.rewrite_trigger.total_bytes` | `4294967296` |
| `treedb.cache.vlog_generation.scheduler_last_reason` | `periodic_gc` |
| `treedb.cache.vlog_generation.scheduler_state` | `idle` |
| `treedb.cache.vlog_generation.segments.cold` | `0` |
| `treedb.cache.vlog_generation.segments.hot` | `7` |
| `treedb.cache.vlog_generation.segments.total` | `7` |
| `treedb.cache.vlog_generation.segments.warm` | `0` |
| `treedb.cache.vlog_generation.vacuum.exec.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.exec.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.exec.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.failures` | `0` |
| `treedb.cache.vlog_generation.vacuum.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.vacuum.runs` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_cooldown` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_disabled` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_rewrite_bytes` | `0` |
| `treedb.cache.vlog_generation.warm.segment_target_bytes` | `268435456` |
| `treedb.cache.vlog_grouped_frame_cache.allocated_shards` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.allocated_slots` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.budget_bytes` | `67108864` |
| `treedb.cache.vlog_grouped_frame_cache.capacity` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.entries` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.evictions` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.hits` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.misses` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.releases` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.retained_bytes` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_budget` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_contention` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_disabled` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_oversize` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.stores` | `0` |
| `treedb.cache.vlog_io.bytes` | `0` |
| `treedb.cache.vlog_io.syscalls` | `0` |
| `treedb.cache.vlog_mmap.active_bytes` | `0` |
| `treedb.cache.vlog_mmap.active_segments` | `0` |
| `treedb.cache.vlog_mmap.current_bytes` | `0` |
| `treedb.cache.vlog_mmap.current_segments` | `0` |
| `treedb.cache.vlog_mmap.current_writable_map_target_bytes` | `33554432` |
| `treedb.cache.vlog_mmap.dead_bytes` | `0` |
| `treedb.cache.vlog_mmap.dead_mappings` | `0` |
| `treedb.cache.vlog_mmap.dead_mappings.cap_base` | `64` |
| `treedb.cache.vlog_mmap.max_mapped_leaf_sealed_bytes` | `1610612736` |
| `treedb.cache.vlog_mmap.max_mapped_leaf_sealed_segments` | `512` |
| `treedb.cache.vlog_mmap.max_mapped_sealed_bytes` | `67108864` |
| `treedb.cache.vlog_mmap.max_mapped_sealed_segments` | `8` |
| `treedb.cache.vlog_mmap.read.fallback_readat` | `0` |
| `treedb.cache.vlog_mmap.read.hits` | `0` |
| `treedb.cache.vlog_mmap.read.miss_dead_mapping_cap` | `0` |
| `treedb.cache.vlog_mmap.read.miss_no_mapping` | `0` |
| `treedb.cache.vlog_mmap.read.miss_out_of_range` | `0` |
| `treedb.cache.vlog_mmap.remaps` | `0` |
| `treedb.cache.vlog_mmap.sealed_bytes` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied.bytes_cap` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied.count_cap` | `0` |
| `treedb.cache.vlog_mmap.sealed_segments` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.legacy_page` | `1` |
| `treedb.cache.vlog_outer_leaf_codec.frames.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.unknown` | `67523` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.legacy_page` | `28` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.unknown` | `392481611` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.legacy_page` | `28` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.unknown` | `43227601` |
| `treedb.cache.vlog_outer_leaf_codec.stored_ratio.legacy_page` | `1.000000` |
| `treedb.cache.vlog_outer_leaf_codec.stored_ratio.unknown` | `0.110139` |
| `treedb.cache.vlog_payload_kind.frames.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.frames.outer_leaf` | `67524` |
| `treedb.cache.vlog_payload_kind.frames.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.raw_bytes.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.raw_bytes.outer_leaf` | `392481639` |
| `treedb.cache.vlog_payload_kind.raw_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.stored_bytes.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.stored_bytes.outer_leaf` | `43227629` |
| `treedb.cache.vlog_payload_kind.stored_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.stored_ratio.outer_leaf` | `0.110139` |
| `treedb.cache.vlog_payload_split.frames.outer_leaf` | `67524` |
| `treedb.cache.vlog_payload_split.raw_bytes.outer_leaf` | `392481639` |
| `treedb.cache.vlog_payload_split.raw_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_split.records.outer_leaf` | `112603` |
| `treedb.cache.vlog_payload_split.records.single_value` | `0` |
| `treedb.cache.vlog_payload_split.stored_bytes.outer_leaf` | `43227629` |
| `treedb.cache.vlog_payload_split.stored_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_split.stored_ratio.outer_leaf` | `0.110139` |
| `treedb.cache.vlog_read.crc32_checks_total` | `0` |
| `treedb.cache.vlog_retained_bytes_estimate` | `47009729` |
| `treedb.cache.vlog_retained_prune.active` | `false` |
| `treedb.cache.vlog_retained_prune.budget_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.candidate_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.candidate_segments` | `0` |
| `treedb.cache.vlog_retained_prune.close_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.closed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.completed_runs` | `0` |
| `treedb.cache.vlog_retained_prune.error_runs` | `0` |
| `treedb.cache.vlog_retained_prune.force_pending` | `false` |
| `treedb.cache.vlog_retained_prune.forced_runs` | `0` |
| `treedb.cache.vlog_retained_prune.foreground_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.full_live_id_scan_runs` | `0` |
| `treedb.cache.vlog_retained_prune.in_use_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.in_use_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.inflight` | `false` |
| `treedb.cache.vlog_retained_prune.last_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.last_force` | `false` |
| `treedb.cache.vlog_retained_prune.last_mode` | `none` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_candidate` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_in_use_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_live_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_parse_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_removed` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_zombie_marked` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_candidate` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_in_use_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_live_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_parse_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_removed` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_zombie_marked` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.nested_value_pointers` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.outer_leaf_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.outer_leaf_records` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.records` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.value_pointer_records` | `0` |
| `treedb.cache.vlog_retained_prune.last_start_unix_nano` | `0` |
| `treedb.cache.vlog_retained_prune.last_status` | `none` |
| `treedb.cache.vlog_retained_prune.last_unix_nano` | `0` |
| `treedb.cache.vlog_retained_prune.live_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.live_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.max_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.no_candidate_runs` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_candidate_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_in_use_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_live_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_parse_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_removed_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_zombie_marked_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_candidate_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_in_use_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_live_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_parse_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_removed_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_zombie_marked_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source_fast_path_runs` | `0` |
| `treedb.cache.vlog_retained_prune.parse_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.parse_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.pressure_bytes` | `17179869164` |
| `treedb.cache.vlog_retained_prune.removed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.removed_segments` | `0` |
| `treedb.cache.vlog_retained_prune.runs` | `0` |
| `treedb.cache.vlog_retained_prune.scan.nested_value_pointers_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.outer_leaf_bytes_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.outer_leaf_records_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.records_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.value_pointer_records_total` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_forced_requests` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_requests` | `20` |
| `treedb.cache.vlog_retained_prune.schedule_skip.below_pressure` | `20` |
| `treedb.cache.vlog_retained_prune.schedule_skip.closing` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.inflight` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.min_interval` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.no_closed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.total_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.write_gate_retries` | `0` |
| `treedb.cache.vlog_retained_prune.write_gate_retry_successes` | `0` |
| `treedb.cache.vlog_retained_prune.zombie_marked_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.zombie_marked_segments` | `0` |
| `treedb.cache.vlog_retained_segments` | `7` |
| `treedb.cache.vlog_template_def_cache.hits` | `0` |
| `treedb.cache.vlog_template_def_cache.misses` | `0` |
| `treedb.cache.vlog_write.bytes` | `0` |
| `treedb.cache.vlog_write.calls` | `0` |
| `treedb.cache.vlog_write.syscalls` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.frames.block` | `67523` |
| `treedb.cache.vlog_write_mode.frames.dict` | `0` |
| `treedb.cache.vlog_write_mode.frames.off` | `1` |
| `treedb.cache.vlog_write_mode.raw_bytes.block` | `392481611` |
| `treedb.cache.vlog_write_mode.raw_bytes.dict` | `0` |
| `treedb.cache.vlog_write_mode.raw_bytes.off` | `28` |
| `treedb.cache.vlog_write_mode.stored_bytes.block` | `43227601` |
| `treedb.cache.vlog_write_mode.stored_bytes.dict` | `0` |
| `treedb.cache.vlog_write_mode.stored_bytes.off` | `28` |
| `treedb.cache.vlog_write_mode.stored_ratio.block` | `0.110139` |
| `treedb.cache.vlog_write_mode.stored_ratio.off` | `1.000000` |
| `treedb.cache.vlog_writer_append_buf.alloc_calls_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.allocated_bytes_total` | `29360128` |
| `treedb.cache.vlog_writer_append_buf.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.drops_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.gets_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.hits_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.misses_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.pool.entries` | `0` |
| `treedb.cache.vlog_writer_append_buf.pool.max_entries` | `16` |
| `treedb.cache.vlog_writer_append_buf.pool.retained_buffers` | `0` |
| `treedb.cache.vlog_writer_append_buf.pool.retained_bytes` | `0` |
| `treedb.cache.vlog_writer_append_buf.puts_total` | `0` |
| `treedb.cache.vlog_writev.bytes` | `0` |
| `treedb.cache.vlog_writev.flushes` | `0` |
| `treedb.cache.vlog_writev.iovecs` | `0` |
| `treedb.cache.vlog_writev.syscalls` | `0` |
| `treedb.cache.vlog_zombie.bytes` | `0` |
| `treedb.cache.vlog_zombie.pinned_bytes` | `0` |
| `treedb.cache.vlog_zombie.pinned_segments` | `0` |
| `treedb.cache.vlog_zombie.segments` | `0` |
| `treedb.cache.vlog_zombie.unpinned_bytes` | `0` |
| `treedb.cache.vlog_zombie.unpinned_segments` | `0` |
| `treedb.cache.write.wait_for_checkpoint.count_total` | `0` |
| `treedb.cache.write.wait_for_checkpoint.ns_total` | `0` |
| `treedb.command_wal.active_segment.name` | `` |
| `treedb.command_wal.active_segments` | `0` |
| `treedb.command_wal.append.count_total` | `0` |
| `treedb.command_wal.append.entry_scan.count_total` | `0` |
| `treedb.command_wal.append.entry_scan.ns_total` | `0` |
| `treedb.command_wal.append.intent.count_total` | `0` |
| `treedb.command_wal.append.intent.ns_total` | `0` |
| `treedb.command_wal.append.ns_total` | `0` |
| `treedb.command_wal.append.payload.count_total` | `0` |
| `treedb.command_wal.append.payload.ns_total` | `0` |
| `treedb.command_wal.append.point.count_total` | `0` |
| `treedb.command_wal.append.point.ns_total` | `0` |
| `treedb.command_wal.applied_lsn` | `0` |
| `treedb.command_wal.bytes` | `0` |
| `treedb.command_wal.bytes.active` | `0` |
| `treedb.command_wal.bytes.total` | `0` |
| `treedb.command_wal.cleanup.covered_bytes_total` | `0` |
| `treedb.command_wal.cleanup.covered_segments_total` | `0` |
| `treedb.command_wal.cleanup.namespace_sync.calls_total` | `0` |
| `treedb.command_wal.cleanup.namespace_sync.errors_total` | `0` |
| `treedb.command_wal.cleanup.namespace_sync.pending` | `false` |
| `treedb.command_wal.cleanup.ns_total` | `0` |
| `treedb.command_wal.cleanup.oldest_pinned_lsn` | `0` |
| `treedb.command_wal.cleanup.proof.capture_epoch` | `0` |
| `treedb.command_wal.cleanup.proof.count_total` | `0` |
| `treedb.command_wal.cleanup.proof.durable_wal_lsn` | `0` |
| `treedb.command_wal.cleanup.proof.frontier_lsn` | `0` |
| `treedb.command_wal.cleanup.proof.namespace_generation` | `0` |
| `treedb.command_wal.cleanup.proof.ns_total` | `0` |
| `treedb.command_wal.cleanup.proof.older_root_commit_seq` | `0` |
| `treedb.command_wal.cleanup.proof.selected_root_commit_seq` | `0` |
| `treedb.command_wal.cleanup.removed_bytes` | `0` |
| `treedb.command_wal.cleanup.removed_bytes_total` | `0` |
| `treedb.command_wal.cleanup.removed_segments` | `0` |
| `treedb.command_wal.cleanup.removed_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.active_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.error_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.pinned_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.uncovered_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained_bytes_total` | `0` |
| `treedb.command_wal.cleanup.retained_segments_total` | `0` |
| `treedb.command_wal.cleanup.retries_total` | `0` |
| `treedb.command_wal.cleanup.scan.count_total` | `0` |
| `treedb.command_wal.cleanup.scan.ns_total` | `0` |
| `treedb.command_wal.cleanup.scanned_bytes_total` | `0` |
| `treedb.command_wal.cleanup.scanned_frames_total` | `0` |
| `treedb.command_wal.cleanup.scans` | `0` |
| `treedb.command_wal.cleanup.unlinked_sync_pending_bytes` | `0` |
| `treedb.command_wal.cleanup.unlinked_sync_pending_segments` | `0` |
| `treedb.command_wal.dependency_debt.entries` | `0` |
| `treedb.command_wal.dependency_debt.max_age_ns` | `0` |
| `treedb.command_wal.dependency_debt.pending_bytes` | `0` |
| `treedb.command_wal.dependency_debt.pending_count` | `0` |
| `treedb.command_wal.dependency_debt.retries_total` | `0` |
| `treedb.command_wal.directory_sync.calls_total` | `0` |
| `treedb.command_wal.directory_sync.errors_total` | `0` |
| `treedb.command_wal.directory_sync.ns_total` | `0` |
| `treedb.command_wal.durable_wal_lsn` | `0` |
| `treedb.command_wal.enabled` | `false` |
| `treedb.command_wal.file_sync.calls_total` | `0` |
| `treedb.command_wal.file_sync.errors_total` | `0` |
| `treedb.command_wal.file_sync.ns_total` | `0` |
| `treedb.command_wal.flush.barrier.count_total` | `0` |
| `treedb.command_wal.flush.barrier.ns_total` | `0` |
| `treedb.command_wal.flush.count_total` | `0` |
| `treedb.command_wal.flush.entry_scan.count_total` | `0` |
| `treedb.command_wal.flush.entry_scan.ns_total` | `0` |
| `treedb.command_wal.flush.intent.count_total` | `0` |
| `treedb.command_wal.flush.intent.ns_total` | `0` |
| `treedb.command_wal.flush.ns_total` | `0` |
| `treedb.command_wal.flush.payload.count_total` | `0` |
| `treedb.command_wal.flush.payload.ns_total` | `0` |
| `treedb.command_wal.flush.point.count_total` | `0` |
| `treedb.command_wal.flush.point.ns_total` | `0` |
| `treedb.command_wal.frames` | `0` |
| `treedb.command_wal.live_accepted_frames` | `0` |
| `treedb.command_wal.live_accepted_max_lsn` | `0` |
| `treedb.command_wal.live_covered_frames` | `0` |
| `treedb.command_wal.live_covered_max_lsn` | `0` |
| `treedb.command_wal.max_lsn` | `0` |
| `treedb.command_wal.next_lsn` | `0` |
| `treedb.command_wal.required_feature` | `false` |
| `treedb.command_wal.segment_files` | `0` |
| `treedb.command_wal.segments.active` | `0` |
| `treedb.command_wal.segments.total` | `0` |
| `treedb.command_wal.stats_scan` | `false` |
| `treedb.command_wal.sync.barrier.count_total` | `0` |
| `treedb.command_wal.sync.barrier.ns_total` | `0` |
| `treedb.command_wal.sync.count_total` | `0` |
| `treedb.command_wal.sync.entry_scan.count_total` | `0` |
| `treedb.command_wal.sync.entry_scan.ns_total` | `0` |
| `treedb.command_wal.sync.intent.count_total` | `0` |
| `treedb.command_wal.sync.intent.ns_total` | `0` |
| `treedb.command_wal.sync.ns_total` | `0` |
| `treedb.command_wal.sync.payload.count_total` | `0` |
| `treedb.command_wal.sync.payload.ns_total` | `0` |
| `treedb.command_wal.sync.point.count_total` | `0` |
| `treedb.command_wal.sync.point.ns_total` | `0` |
| `treedb.command_wal.typed_segments` | `0` |
| `treedb.command_wal.write.bytes_total` | `0` |
| `treedb.command_wal.write.errors_total` | `0` |
| `treedb.command_wal.write.ns_total` | `0` |
| `treedb.command_wal.write.syscalls_total` | `0` |
| `treedb.command_wal.writer.buffer_size_bytes` | `0` |
| `treedb.command_wal.writer.buffered_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.capacity_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.dropped_bytes_total` | `0` |
| `treedb.command_wal.writer.command_buffer.length_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.limit_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.retain_limit_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.trim_count` | `0` |
| `treedb.command_wal.writer.pending_batch.capacity_bytes` | `0` |
| `treedb.command_wal.writer.pending_batch.length_bytes` | `0` |
| `treedb.command_wal.writer.scratch_capacity_bytes` | `0` |
| `treedb.commit_seq` | `12` |
| `treedb.durability_mode` | `wal_off_relaxed_sync` |
| `treedb.flush_admission.admitted` | `true` |
| `treedb.flush_admission.flush_apply_concurrency` | `6` |
| `treedb.flush_admission.flush_apply_concurrency_cap_reason` | `default_physical_cores` |
| `treedb.flush_admission.flush_apply_concurrency_configured` | `0` |
| `treedb.flush_admission.flush_apply_concurrency_defaulted` | `true` |
| `treedb.flush_admission.flush_apply_span_native` | `true` |
| `treedb.flush_admission.flush_backlog_coalescing` | `true` |
| `treedb.flush_admission.gomaxprocs` | `12` |
| `treedb.flush_admission.leaf_page_read_cache_write_admission` | `adaptive` |
| `treedb.flush_admission.physical_cores` | `6` |
| `treedb.flush_admission.policy` | `auto` |
| `treedb.flush_admission.reason` | `auto_admitted_hardware_aware` |
| `treedb.flush_apply.apply_calls_total` | `110` |
| `treedb.flush_apply.apply_errors_total` | `0` |
| `treedb.flush_apply.apply_ns_total` | `570442923` |
| `treedb.flush_apply.apply_ops_total` | `1833475` |
| `treedb.flush_apply.commit_wait_ns_total` | `0` |
| `treedb.flush_apply.guarded_publish.calls_total` | `0` |
| `treedb.flush_apply.guarded_publish.ns_per_op` | `0.000000` |
| `treedb.flush_apply.guarded_publish.ns_total` | `0` |
| `treedb.flush_apply.leaf_log_output.append_calls_total` | `64155` |
| `treedb.flush_apply.leaf_log_output.append_pages_total` | `112603` |
| `treedb.flush_apply.leaf_log_output.append_wait_ns_total` | `581771912` |
| `treedb.flush_apply.leaf_log_output.lane.01.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.02.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.03.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.04.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.05.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.06.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_lanes_used` | `6` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_max` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_overflow_total` | `0` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_total` | `396` |
| `treedb.flush_apply.leaf_log_output.reservation_wait_ns_total` | `8138188` |
| `treedb.flush_apply.merge_build.internal_child_refs_total` | `139511` |
| `treedb.flush_apply.merge_build.internal_merges_total` | `132` |
| `treedb.flush_apply.merge_build.internal_page_bytes_written_total` | `6057984` |
| `treedb.flush_apply.merge_build.internal_pages_written_total` | `1479` |
| `treedb.flush_apply.merge_build.internal_parallel_children_total` | `116` |
| `treedb.flush_apply.merge_build.internal_parallel_merges_total` | `8` |
| `treedb.flush_apply.merge_build.internal_parallel_ops_total` | `252824` |
| `treedb.flush_apply.merge_build.internal_parallel_workers_total` | `48` |
| `treedb.flush_apply.merge_build.leaf_log_page_bytes_written_total` | `461221888` |
| `treedb.flush_apply.merge_build.leaf_log_pages_written_total` | `112603` |
| `treedb.flush_apply.merge_build.leaf_log_record_hint_bytes_written_total` | `162338149` |
| `treedb.flush_apply.merge_build.leaf_merges_per_op` | `0.034963` |
| `treedb.flush_apply.merge_build.leaf_merges_total` | `64104` |
| `treedb.flush_apply.merge_build.leaf_page_bytes_written_total` | `461221888` |
| `treedb.flush_apply.merge_build.leaf_pages_written_total` | `112603` |
| `treedb.flush_apply.merge_build.pager_leaf_page_bytes_written_total` | `0` |
| `treedb.flush_apply.merge_build.pager_leaf_pages_written_total` | `0` |
| `treedb.flush_apply.merge_build.replacement_leaf_pages_per_op` | `0.061415` |
| `treedb.flush_apply.merge_build.replacement_leaf_pages_total` | `112603` |
| `treedb.flush_apply.mismatch_total` | `0` |
| `treedb.flush_apply.old_leaf_read_decode.bytes_per_op` | `148.510229` |
| `treedb.flush_apply.old_leaf_read_decode.bytes_total` | `272289792` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_bytes_total` | `268775424` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_cache_hits_total` | `17501` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_node_loads_total` | `65619` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_reader_calls_total` | `48118` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_record_hint_bytes_total` | `107520156` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_scratch_reads_total` | `48118` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_view_reads_total` | `0` |
| `treedb.flush_apply.old_leaf_read_decode.node_loads_total` | `66477` |
| `treedb.flush_apply.old_leaf_read_decode.pager_bytes_total` | `3514368` |
| `treedb.flush_apply.old_leaf_read_decode.pager_node_loads_total` | `858` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_installed_total` | `461221888` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_prepared_total` | `461221888` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_installed_total` | `112603` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_prepared_total` | `112603` |
| `treedb.flush_apply.prepared_output.retired_pages_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.retired_pages_installed_total` | `858` |
| `treedb.flush_apply.prepared_output.retired_pages_prepared_total` | `858` |
| `treedb.flush_apply.publish_final_install.calls_total` | `0` |
| `treedb.flush_apply.publish_final_install.ns_per_op` | `0.000000` |
| `treedb.flush_apply.publish_final_install.ns_total` | `0` |
| `treedb.flush_apply.publish_prepare.calls_total` | `11` |
| `treedb.flush_apply.publish_prepare.errors_total` | `0` |
| `treedb.flush_apply.publish_prepare.ns_per_op` | `7.850217` |
| `treedb.flush_apply.publish_prepare.ns_total` | `14393177` |
| `treedb.flush_apply.publish_total.ns_per_op` | `7.850217` |
| `treedb.flush_apply.publish_total.ns_total` | `14393177` |
| `treedb.flush_apply.read_only_prepare.calls_total` | `110` |
| `treedb.flush_apply.read_only_prepare.errors_total` | `0` |
| `treedb.flush_apply.read_only_prepare.ns_total` | `68866725` |
| `treedb.flush_apply.read_only_prepare.requested_workers_max` | `6` |
| `treedb.flush_apply.read_only_prepare.requested_workers_total` | `660` |
| `treedb.flush_apply.read_only_prepare.single_op_spans_max` | `1180` |
| `treedb.flush_apply.read_only_prepare.single_op_spans_total` | `3966` |
| `treedb.flush_apply.read_only_prepare.span_bytes_max` | `2621440` |
| `treedb.flush_apply.read_only_prepare.span_bytes_total` | `226591128` |
| `treedb.flush_apply.read_only_prepare.span_ops_max` | `31608` |
| `treedb.flush_apply.read_only_prepare.span_ops_total` | `1833475` |
| `treedb.flush_apply.read_only_prepare.spans_max` | `5857` |
| `treedb.flush_apply.read_only_prepare.spans_total` | `64104` |
| `treedb.flush_apply.read_only_prepare.validation_failures_total` | `0` |
| `treedb.flush_apply.read_only_prepare.worker_ranges_max` | `6` |
| `treedb.flush_apply.read_only_prepare.worker_ranges_total` | `480` |
| `treedb.flush_apply.reducer_publish.ns_per_op` | `9.482459` |
| `treedb.flush_apply.reducer_publish.ns_total` | `17385852` |
| `treedb.flush_apply.retry_total` | `0` |
| `treedb.flush_apply.root_reduce.ns_per_op` | `9.482459` |
| `treedb.flush_apply.root_reduce.ns_total` | `17385852` |
| `treedb.flush_apply.root_reduce.split_levels_total` | `3` |
| `treedb.flush_apply.span_native.candidate_ops_total` | `1833475` |
| `treedb.flush_apply.span_native.candidate_spans_total` | `64104` |
| `treedb.flush_apply.span_native.eligible_ops_total` | `1580651` |
| `treedb.flush_apply.span_native.eligible_spans_total` | `49808` |
| `treedb.flush_apply.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.maintenance.ops_total` | `252824` |
| `treedb.flush_apply.span_native.fallback.reason.maintenance.spans_total` | `14296` |
| `treedb.flush_apply.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallbacks_total` | `8` |
| `treedb.flush_apply.span_native.ineligible_ops_total` | `252824` |
| `treedb.flush_apply.span_native.ineligible_spans_total` | `14296` |
| `treedb.flush_apply.span_native.reducer_validation_guard.active` | `false` |
| `treedb.flush_apply.span_native.reducer_validation_guard.trips_total` | `0` |
| `treedb.flush_apply.span_native.scheduler.completed_tasks_total` | `432` |
| `treedb.flush_apply.span_native.scheduler.dispatched_tasks_total` | `432` |
| `treedb.flush_apply.span_native.scheduler.queue_depth_max` | `6` |
| `treedb.flush_apply.span_native.scheduler.ready_tasks_total` | `432` |
| `treedb.flush_apply.span_native.scheduler.scheduled_workers_max` | `6` |
| `treedb.flush_apply.span_native.scheduler.scheduled_workers_total` | `432` |
| `treedb.flush_apply.span_native.scheduler.single_span_tasks_total` | `41` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_max` | `2621440` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_min` | `272` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_per_task` | `519834.574074` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_total` | `224568536` |
| `treedb.flush_apply.span_native.scheduler.task_ops_max` | `16384` |
| `treedb.flush_apply.span_native.scheduler.task_ops_min` | `2` |
| `treedb.flush_apply.span_native.scheduler.task_ops_per_task` | `3658.914352` |
| `treedb.flush_apply.span_native.scheduler.task_ops_total` | `1580651` |
| `treedb.flush_apply.span_native.scheduler.task_spans_max` | `996` |
| `treedb.flush_apply.span_native.scheduler.task_spans_min` | `1` |
| `treedb.flush_apply.span_native.scheduler.task_spans_per_task` | `115.296296` |
| `treedb.flush_apply.span_native.scheduler.task_spans_total` | `49808` |
| `treedb.flush_apply.span_native.scheduler.worker_busy_ns_total` | `1627845357` |
| `treedb.flush_apply.span_native.scheduler.worker_idle_ns_total` | `378889126` |
| `treedb.flush_apply.span_native.scheduler.worker_wait_ns_total` | `470678273` |
| `treedb.flush_apply.span_native.used_ops_total` | `1580651` |
| `treedb.flush_apply.span_native.used_spans_total` | `49808` |
| `treedb.flush_apply.span_run.bytes_per_span` | `3534.742419` |
| `treedb.flush_apply.span_run.ops_per_span` | `28.601569` |
| `treedb.flush_apply.span_run.single_op_spans_total` | `3966` |
| `treedb.flush_apply.span_run.span_bytes_total` | `226591128` |
| `treedb.flush_apply.span_run.span_ops_total` | `1833475` |
| `treedb.flush_apply.span_run.target_leaf_spans_total` | `64104` |
| `treedb.leaf_generation.bytes.deleted` | `0` |
| `treedb.leaf_generation.bytes.retained` | `41645116` |
| `treedb.leaf_generation.bytes.retiring` | `0` |
| `treedb.leaf_generation.bytes.sealed` | `41645116` |
| `treedb.leaf_generation.bytes.total` | `47009729` |
| `treedb.leaf_generation.bytes.writable` | `5364613` |
| `treedb.leaf_generation.current.bytes` | `5364613` |
| `treedb.leaf_generation.current.files` | `1` |
| `treedb.leaf_generation.current_generation_id` | `7` |
| `treedb.leaf_generation.enabled` | `true` |
| `treedb.leaf_generation.files.deleted` | `0` |
| `treedb.leaf_generation.files.retained` | `6` |
| `treedb.leaf_generation.files.retiring` | `0` |
| `treedb.leaf_generation.files.sealed` | `6` |
| `treedb.leaf_generation.files.total` | `7` |
| `treedb.leaf_generation.files.writable` | `1` |
| `treedb.leaf_generation.generations.deleted` | `0` |
| `treedb.leaf_generation.generations.pinned` | `0` |
| `treedb.leaf_generation.generations.retained` | `6` |
| `treedb.leaf_generation.generations.retiring` | `0` |
| `treedb.leaf_generation.generations.sealed` | `6` |
| `treedb.leaf_generation.generations.total` | `7` |
| `treedb.leaf_generation.generations.writable` | `1` |
| `treedb.leaf_generation.pins.total` | `0` |
| `treedb.leaf_generation.plan_cache.subtree_pages` | `0` |
| `treedb.process.append_only.entry_hint_capacity_bytes` | `1228128` |
| `treedb.process.append_only.entry_hint_entries` | `12793` |
| `treedb.process.append_only.entry_pool_admission_drop_bytes_total` | `0` |
| `treedb.process.append_only.entry_pool_admission_drops_total` | `0` |
| `treedb.process.append_only.entry_pool_drop_bytes_total` | `0` |
| `treedb.process.append_only.entry_pool_drops_total` | `0` |
| `treedb.process.append_only.entry_pool_gets_total` | `682` |
| `treedb.process.append_only.entry_pool_puts_total` | `828` |
| `treedb.process.append_only.entry_pool_retained_bytes_estimate` | `97168104` |
| `treedb.process.append_only.entry_pool_retained_bytes_max_estimate` | `97168104` |
| `treedb.process.append_only.mem_lease_count` | `8` |
| `treedb.process.append_only.mem_lease_entry_backing_bytes` | `0` |
| `treedb.process.append_only.mem_lease_entry_capacity` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_active_bytes` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_active_chunks` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_retained_bytes` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_retained_chunks` | `0` |
| `treedb.process.append_only.mutable_count` | `16` |
| `treedb.process.append_only.mutable_entry_backing_bytes` | `0` |
| `treedb.process.append_only.mutable_entry_capacity` | `0` |
| `treedb.process.append_only.mutable_from_lease_total` | `88` |
| `treedb.process.append_only.mutable_from_pool_total` | `0` |
| `treedb.process.append_only.mutable_new_alloc_queue_bytes_sum` | `1412124008` |
| `treedb.process.append_only.mutable_new_alloc_total` | `88` |
| `treedb.process.append_only.mutable_new_alloc_with_queue_total` | `88` |
| `treedb.process.append_only.mutable_pool_drops_total` | `0` |
| `treedb.process.append_only.mutable_pool_entry_backing_dropped_bytes_total` | `2610784` |
| `treedb.process.append_only.mutable_pool_puts_total` | `80` |
| `treedb.process.append_only.mutable_sparse_trim_dropped_bytes_total` | `0` |
| `treedb.process.append_only.mutable_sparse_trim_total` | `0` |
| `treedb.process.append_only.mutable_trim_dropped_bytes_total` | `21605760` |
| `treedb.process.append_only.mutable_trim_total` | `320` |
| `treedb.process.append_only.mutable_value_arena_active_bytes` | `0` |
| `treedb.process.append_only.mutable_value_arena_active_chunks` | `0` |
| `treedb.process.append_only.mutable_value_arena_retained_bytes` | `0` |
| `treedb.process.append_only.mutable_value_arena_retained_chunks` | `0` |
| `treedb.process.append_only.reserve.calls_total` | `432` |
| `treedb.process.append_only.reserve.entries_total` | `153761` |
| `treedb.process.append_only.reserve.grow_bytes_total` | `235158176` |
| `treedb.process.append_only.reserve.grow_calls_total` | `432` |
| `treedb.process.append_only.reserve.skipped_growth_allocs_total` | `83` |
| `treedb.process.append_only.reserve.skipped_growth_bytes_total` | `1576960` |
| `treedb.process.append_only.value_arena_pool_admission_drop_bytes_total` | `0` |
| `treedb.process.append_only.value_arena_pool_admission_drops_total` | `0` |
| `treedb.process.append_only.value_arena_pool_drop_bytes_total` | `0` |
| `treedb.process.append_only.value_arena_pool_drops_total` | `0` |
| `treedb.process.append_only.value_arena_pool_gets_total` | `0` |
| `treedb.process.append_only.value_arena_pool_puts_total` | `0` |
| `treedb.process.append_only.value_arena_pool_retained_bytes_estimate` | `0` |
| `treedb.process.append_only.value_arena_pool_retained_bytes_max_estimate` | `0` |
| `treedb.process.memory.gc_cpu_fraction` | `0.010130` |
| `treedb.process.memory.gomemlimit_bytes` | `9223372036854775807` |
| `treedb.process.memory.heap_alloc_bytes` | `350154488` |
| `treedb.process.memory.heap_idle_bytes` | `376070144` |
| `treedb.process.memory.heap_idle_unreleased_bytes` | `25264128` |
| `treedb.process.memory.heap_inuse_bytes` | `353837056` |
| `treedb.process.memory.heap_released_bytes` | `350806016` |
| `treedb.process.memory.heap_sys_bytes` | `729907200` |
| `treedb.process.memory.memtable_view_deferred_bytes_current` | `0` |
| `treedb.process.memory.memtable_view_deferred_bytes_max` | `0` |
| `treedb.process.memory.memtable_view_deferred_memtables_current` | `0` |
| `treedb.process.memory.memtable_view_deferred_memtables_max` | `0` |
| `treedb.process.memory.memtable_view_deferred_oldest_age_ms` | `0.000` |
| `treedb.process.memory.mutable_bytes` | `0` |
| `treedb.process.memory.next_gc_bytes` | `688887874` |
| `treedb.process.memory.non_heap_sys_bytes` | `29401528` |
| `treedb.process.memory.num_gc` | `77` |
| `treedb.process.memory.peak_heap_alloc_bytes` | `453489632` |
| `treedb.process.memory.peak_heap_inuse_bytes` | `457711616` |
| `treedb.process.memory.peak_rss_bytes` | `756969472` |
| `treedb.process.memory.peak_total_sys_bytes` | `759374264` |
| `treedb.process.memory.peak_vlog_mmap_active_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_active_segments` | `0` |
| `treedb.process.memory.peak_vlog_mmap_current_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_current_segments` | `0` |
| `treedb.process.memory.peak_vlog_mmap_sealed_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_sealed_segments` | `0` |
| `treedb.process.memory.pool_pressure_critical_samples_total` | `0` |
| `treedb.process.memory.pool_pressure_high_samples_total` | `0` |
| `treedb.process.memory.pool_pressure_level` | `normal` |
| `treedb.process.memory.pool_pressure_normal_samples_total` | `108` |
| `treedb.process.memory.pool_pressure_used_bytes` | `379101184` |
| `treedb.process.memory.queue_backlog_bytes` | `0` |
| `treedb.process.memory.rss_bytes` | `411385856` |
| `treedb.process.memory.rss_hwm_bytes` | `755552256` |
| `treedb.process.memory.rss_minus_heap_inuse_bytes` | `57548800` |
| `treedb.process.memory.rss_minus_total_sys_bytes` | `0` |
| `treedb.process.memory.stack_inuse_bytes` | `4096000` |
| `treedb.process.memory.stack_sys_bytes` | `4096000` |
| `treedb.process.memory.total_sys_bytes` | `759308728` |
| `treedb.process.memory.vlog_mmap_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_sealed_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_sealed_segments` | `0` |
| `treedb.process.memory.vlog_mmap_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_sealed_segments` | `0` |
| `treedb.process.memory.vlog_retained_bytes_estimate` | `47009729` |
| `treedb.process.memory.vlog_zombie_bytes_estimate` | `0` |
| `treedb.process.memory.vlog_zombie_pinned_bytes_estimate` | `0` |
| `treedb.process.memory.vlog_zombie_unpinned_bytes_estimate` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.count` | `16` |
| `treedb.process.memtable_residency.mutable.append_only.entries` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.btree.count` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entries` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.btree.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.count` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entries` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.count` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entries` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.total.count` | `16` |
| `treedb.process.memtable_residency.mutable.total.entries` | `0` |
| `treedb.process.memtable_residency.mutable.total.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.total.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.append_only.count` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entries` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.append_only.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.btree.count` | `0` |
| `treedb.process.memtable_residency.queue.btree.entries` | `0` |
| `treedb.process.memtable_residency.queue.btree.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.btree.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.count` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entries` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.count` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entries` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.total.count` | `0` |
| `treedb.process.memtable_residency.queue.total.entries` | `0` |
| `treedb.process.memtable_residency.queue.total.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.total.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_retained_chunks` | `0` |
| `treedb.process.read_path.backend_tree.get_append_inline_bytes_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_inline_hits_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_pointer_bytes_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_pointer_hits_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.calls_total` | `200` |
| `treedb.process.read_path.backend_tree.getmany.fallback_calls_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.grouped_calls_total` | `200` |
| `treedb.process.read_path.backend_tree.getmany.leaf_group_items_total` | `200000` |
| `treedb.process.read_path.backend_tree.getmany.leaf_groups_total` | `186719` |
| `treedb.process.read_path.backend_tree.getmany.leaf_loads_saved_total` | `13281` |
| `treedb.process.read_path.outer_leaf.bytes_total` | `21446914048` |
| `treedb.process.read_path.outer_leaf.cache.backing_bytes` | `33554432` |
| `treedb.process.read_path.outer_leaf.cache.buckets` | `2048` |
| `treedb.process.read_path.outer_leaf.cache.bytes` | `33554432` |
| `treedb.process.read_path.outer_leaf.cache.capacity` | `8192` |
| `treedb.process.read_path.outer_leaf.cache.capacity_evictions` | `376773` |
| `treedb.process.read_path.outer_leaf.cache.conflict_evictions` | `20630` |
| `treedb.process.read_path.outer_leaf.cache.cow_read_policy_bytes` | `196608` |
| `treedb.process.read_path.outer_leaf.cache.entries` | `8192` |
| `treedb.process.read_path.outer_leaf.cache.evictions` | `397403` |
| `treedb.process.read_path.outer_leaf.cache.hits` | `4458251` |
| `treedb.process.read_path.outer_leaf.cache.misses` | `946297` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_mark_misses` | `0` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_mark_unsafe_skips` | `0` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_unverified_hits` | `2904443` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_verified_hits` | `1553808` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_verified_marks` | `278851` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_candidate_skips` | `0` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_lock_skips` | `63` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_skips` | `653295` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_stores` | `293001` |
| `treedb.process.read_path.outer_leaf.cache.record_checksum_verified_stores` | `293001` |
| `treedb.process.read_path.outer_leaf.cache.stores` | `405595` |
| `treedb.process.read_path.outer_leaf.cache.ways` | `4` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_attempts` | `112603` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_lock_skips` | `9` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_policy` | `adaptive` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_skips` | `9` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_stores` | `112594` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_1024_hit_ratio` | `0.132326` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_1024_hits_total` | `10826` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_256_hit_ratio` | `0.034848` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_256_hits_total` | `2851` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_4096_hit_ratio` | `0.423466` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_4096_hits_total` | `34645` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_64_hit_ratio` | `0.009192` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_64_hits_total` | `752` |
| `treedb.process.read_path.outer_leaf.checksum.skips_total` | `1549937` |
| `treedb.process.read_path.outer_leaf.checksum.verifications_total` | `3686126` |
| `treedb.process.read_path.outer_leaf.iterator_loads_total` | `49344` |
| `treedb.process.read_path.outer_leaf.loads_total` | `5236063` |
| `treedb.process.read_path.outer_leaf.point_loads_total` | `5186719` |
| `treedb.process.read_path.outer_leaf.sample_mod` | `64` |
| `treedb.process.read_path.outer_leaf.samples_total` | `81813` |
| `treedb.profile.bench_unsafe` | `false` |
| `treedb.profile.resolved` | `no_wal_fast` |
| `treedb.publish.ordered_root_delta_group.avg_roots_per_call` | `0.000` |
| `treedb.publish.ordered_root_delta_group.calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.finalize_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.finalize_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.latency_max_ms` | `0.000` |
| `treedb.publish.ordered_root_delta_group.latency_p99_ms` | `0.000` |
| `treedb.publish.ordered_root_delta_group.preflight_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_child_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_leaf_log_ref_copies_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_leaf_log_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_page_child_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_children_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_workers_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_cache_hits_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_node_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_reader_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_record_hint_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_record_hint_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_scratch_reads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_view_reads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_leaf_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_leaf_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_node_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_parallel_groups_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_parallel_roots_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_requested_workers_max` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_requested_workers_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_span_bytes_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_span_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_validation_failures_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_worker_ranges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_root_split_levels_total` | `0` |
| `treedb.publish.ordered_root_delta_group.roots_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.fallback_reason` | `route_ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.fallback_reason` | `route_ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.fallback_reason` | `cold_build` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_build_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_hold_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_wait_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_wait_share_pct` | `0.000` |
| `treedb.publish.watermark.lag_drift_bytes_per_sec` | `0.000` |
| `treedb.publish.watermark.latency_p99_ms` | `0.000` |
| `treedb.publish.watermark.lock_delay_share_pct` | `0.000` |
| `treedb.raw.span_native.candidate_ops_total` | `1833475` |
| `treedb.raw.span_native.candidate_spans_total` | `0` |
| `treedb.raw.span_native.eligible_ops_total` | `1580651` |
| `treedb.raw.span_native.eligible_spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.maintenance.count_total` | `8` |
| `treedb.raw.span_native.fallback.reason.maintenance.ops_total` | `252824` |
| `treedb.raw.span_native.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.fallbacks_total` | `8` |
| `treedb.raw.span_native.ineligible_ops_total` | `252824` |
| `treedb.raw.span_native.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.public.command_wal_rejections_total` | `0` |
| `treedb.raw.span_native.public.route.update.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.public.route.update.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.public.route.update_sync.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.public.route.update_sync.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.observations_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.used_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.used_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.observations_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.used_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.used_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.observations_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.used_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.used_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.observations_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.candidate_ops_total` | `252824` |
| `treedb.raw.span_native.route.point_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.count_total` | `8` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.ops_total` | `252824` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallbacks_total` | `8` |
| `treedb.raw.span_native.route.point_delete.ineligible_ops_total` | `252824` |
| `treedb.raw.span_native.route.point_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.observations_total` | `8` |
| `treedb.raw.span_native.route.point_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.candidate_ops_total` | `1580651` |
| `treedb.raw.span_native.route.point_put.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.eligible_ops_total` | `1580651` |
| `treedb.raw.span_native.route.point_put.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.point_put.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.observations_total` | `102` |
| `treedb.raw.span_native.route.point_put.used_ops_total` | `1580651` |
| `treedb.raw.span_native.route.point_put.used_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.range_delete.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.observations_total` | `0` |
| `treedb.raw.span_native.route.range_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.used_ops_total` | `1580651` |
| `treedb.raw.span_native.used_spans_total` | `0` |
| `treedb.vlog.decode_buffer_grow.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.capacity_waste_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.copied_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_fit_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_fit_requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_present_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_current_mmap_direct_decode.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_current_mmap_direct_decode.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_fit_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_fit_requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_present_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_template_encoded_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_template_encoded_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.realloc_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.requested_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.file_stash.retain_max_bytes` | `131072` |
| `treedb.vlog.decode_scratch.file_stash.retained_buffers` | `21` |
| `treedb.vlog.decode_scratch.file_stash.retained_bytes` | `682287` |
| `treedb.vlog.decode_scratch.file_stash.retained_files` | `7` |
| `treedb.vlog.decode_scratch.file_stash.spare_max_count` | `2` |
| `treedb.vlog.decode_scratch.large_pool.alloc_calls_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.drops_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.entries` | `0` |
| `treedb.vlog.decode_scratch.large_pool.gets_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.hits_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.max_entries` | `8` |
| `treedb.vlog.decode_scratch.large_pool.misses_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.puts_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.retained_buffers` | `0` |
| `treedb.vlog.decode_scratch.large_pool.retained_bytes` | `0` |
| `treedb.vlog.decode_scratch.large_pool.too_small_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.alloc_calls_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.drops_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.alloc_calls_total` | `99` |
| `treedb.vlog.decode_scratch.small_pool.allocated_bytes_total` | `3045288` |
| `treedb.vlog.decode_scratch.small_pool.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.drops_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.entries` | `9` |
| `treedb.vlog.decode_scratch.small_pool.gets_total` | `81429` |
| `treedb.vlog.decode_scratch.small_pool.hits_total` | `81330` |
| `treedb.vlog.decode_scratch.small_pool.max_entries` | `128` |
| `treedb.vlog.decode_scratch.small_pool.misses_total` | `99` |
| `treedb.vlog.decode_scratch.small_pool.puts_total` | `81408` |
| `treedb.vlog.decode_scratch.small_pool.retained_buffers` | `9` |
| `treedb.vlog.decode_scratch.small_pool.retained_bytes` | `293410` |
| `treedb.vlog.decode_scratch.small_pool.too_small_total` | `69` |
| `treedb.vlog.grouped_frame_cache.allocated_shards` | `0` |
| `treedb.vlog.grouped_frame_cache.allocated_slots` | `0` |
| `treedb.vlog.grouped_frame_cache.budget_bytes` | `67108864` |
| `treedb.vlog.grouped_frame_cache.capacity` | `0` |
| `treedb.vlog.grouped_frame_cache.entries` | `0` |
| `treedb.vlog.grouped_frame_cache.evictions` | `0` |
| `treedb.vlog.grouped_frame_cache.hits` | `0` |
| `treedb.vlog.grouped_frame_cache.misses` | `0` |
| `treedb.vlog.grouped_frame_cache.releases` | `0` |
| `treedb.vlog.grouped_frame_cache.retained_bytes` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_budget` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_contention` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_disabled` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_oversize` | `0` |
| `treedb.vlog.grouped_frame_cache.stores` | `0` |
| `treedb.vlog.mmap_active_bytes` | `0` |
| `treedb.vlog.mmap_active_segments` | `0` |
| `treedb.vlog.mmap_current_bytes` | `0` |
| `treedb.vlog.mmap_current_segments` | `0` |
| `treedb.vlog.mmap_current_writable_map_target_bytes` | `33554432` |
| `treedb.vlog.mmap_dead_bytes` | `0` |
| `treedb.vlog.mmap_dead_mappings` | `0` |
| `treedb.vlog.mmap_dead_mappings.cap_base` | `64` |
| `treedb.vlog.mmap_max_mapped_leaf_sealed_bytes` | `1610612736` |
| `treedb.vlog.mmap_max_mapped_leaf_sealed_segments` | `512` |
| `treedb.vlog.mmap_max_mapped_sealed_bytes` | `67108864` |
| `treedb.vlog.mmap_max_mapped_sealed_segments` | `8` |
| `treedb.vlog.mmap_read.fallback_readat` | `1236787` |
| `treedb.vlog.mmap_read.hit_ratio` | `0.000000` |
| `treedb.vlog.mmap_read.hits` | `0` |
| `treedb.vlog.mmap_read.miss_dead_mapping_cap` | `0` |
| `treedb.vlog.mmap_read.miss_no_mapping` | `1236787` |
| `treedb.vlog.mmap_read.miss_out_of_range` | `0` |
| `treedb.vlog.mmap_remaps` | `0` |
| `treedb.vlog.mmap_sealed_bytes` | `0` |
| `treedb.vlog.mmap_sealed_map_denied` | `0` |
| `treedb.vlog.mmap_sealed_map_denied.bytes_cap` | `0` |
| `treedb.vlog.mmap_sealed_map_denied.count_cap` | `0` |
| `treedb.vlog.mmap_sealed_segments` | `0` |
| `treedb.vlog.read.crc32_checks_total` | `1236787` |
| `treedb.vlog.read_integrity` | `verify` |
| `treedb.vlog.template_def_cache.hits` | `0` |
| `treedb.vlog.template_def_cache.misses` | `0` |
| `treedb.vlog.writer_append_buf.alloc_calls_total` | `7` |
| `treedb.vlog.writer_append_buf.allocated_bytes_total` | `29360128` |
| `treedb.vlog.writer_append_buf.dropped_bytes_total` | `0` |
| `treedb.vlog.writer_append_buf.drops_total` | `0` |
| `treedb.vlog.writer_append_buf.gets_total` | `7` |
| `treedb.vlog.writer_append_buf.hits_total` | `0` |
| `treedb.vlog.writer_append_buf.misses_total` | `7` |
| `treedb.vlog.writer_append_buf.pool.entries` | `0` |
| `treedb.vlog.writer_append_buf.pool.max_entries` | `16` |
| `treedb.vlog.writer_append_buf.pool.retained_buffers` | `0` |
| `treedb.vlog.writer_append_buf.pool.retained_bytes` | `0` |
| `treedb.vlog.writer_append_buf.puts_total` | `0` |

## Key Insights

- TreeDB: prefix_scan is 1.33x faster than full_scan (3716417 vs 2790190 ops/s).
- treedb: shared hotspot "runtime.scanObject" (full 6.67% flat, prefix 50.00% flat).
- treedb: prefix_scan-specific hotspot "aeshashbody" (8.33% flat).
- treedb: full_scan-specific hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" (42.22% flat).
- block/batch_delete/treedb: contention hotspot "runtime.chanrecv1" (100.00% flat).
- block/batch_random/treedb: contention hotspot "runtime.selectgo" (99.61% flat).
- block/batch_small_seq/treedb: contention hotspot "runtime.selectgo" (89.92% flat).
- block/batch_write/treedb: contention hotspot "runtime.chanrecv1" (100.00% flat).
- block/batch_write_steady/treedb: contention hotspot "runtime.chanrecv2" (55.60% flat).
- block/dataset_write_random/treedb: contention hotspot "runtime.chanrecv1" (50.12% flat).
- block/dataset_write_sorted/treedb: contention hotspot "runtime.chanrecv1" (50.24% flat).
- block/full_scan/treedb: contention hotspot "runtime.selectgo" (81.72% flat).
- block/prefix_scan/treedb: contention hotspot "runtime.chanrecv1" (100.00% flat).
- block/random_delete/treedb: contention hotspot "runtime.selectgo" (91.58% flat).
- block/random_read/treedb: contention hotspot "runtime.selectgo" (54.71% flat).
- block/random_read_batch/treedb: contention hotspot "runtime.selectgo" (91.38% flat).
- block/random_read_parallel/treedb: contention hotspot "runtime.selectgo" (74.11% flat).
- block/random_read_parallel_acquire_snapshot/treedb: contention hotspot "runtime.selectgo" (66.91% flat).
- block/random_write/treedb: contention hotspot "runtime.chanrecv1" (100.00% flat).
- block/sequential_write/treedb: contention hotspot "runtime.selectgo" (97.84% flat).
- mutex/batch_write_steady/treedb: contention hotspot "sync.(*Mutex).Unlock (inline)" (81.64% flat).
- mutex/random_read/treedb: contention hotspot "runtime.unlock (inline)" (100.00% flat).
- mutex/random_read_batch/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (79.47% flat).
- mutex/random_read_parallel/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (98.07% flat).
- mutex/random_read_parallel_acquire_snapshot/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (86.52% flat).
- mutex/sequential_write/treedb: contention hotspot "runtime.unlock (inline)" (94.95% flat).
- Global block contention hotspot: "runtime.selectgo" (71.03% flat).
- Global mutex contention hotspot: "sync.(*Mutex).Unlock (partial-inline)" (88.57% flat).
- alloc_objects/batch_delete/treedb: top allocator by count is "runtime/pprof.allFrames" (2185 flat, 71.55%).
- alloc_objects/batch_delete/treedb: top hotspot "runtime/pprof.allFrames" is 71.55% flat; this section is highly concentrated in one function.
- alloc_objects/batch_random/treedb: top allocator by count is "runtime/pprof.allFrames" (4370 flat, 58.74%).
- alloc_objects/batch_random/treedb: top hotspot "runtime/pprof.allFrames" is 58.74% flat; this section is highly concentrated in one function.
- alloc_objects/batch_small_seq/treedb: dominant theme is write/delete/flush path (51.03% flat across top nodes).
- alloc_objects/batch_small_seq/treedb: top allocator by count is "runtime/pprof.allFrames" (6555 flat, 47.21%).
- alloc_objects/batch_small_seq/treedb: top hotspot "runtime/pprof.allFrames" is 47.21% flat; this section is highly concentrated in one function.
- alloc_objects/batch_write/treedb: top allocator by count is "runtime/pprof.(*profileBuilder).emitLocation" (5461 flat, 66.69%).
- alloc_objects/batch_write/treedb: top hotspot "runtime/pprof.(*profileBuilder).emitLocation" is 66.69% flat; this section is highly concentrated in one function.
- alloc_objects/batch_write_steady/treedb: top allocator by count is "runtime/pprof.(*profileBuilder).emitLocation" (6613 flat, 71.72%).
- alloc_objects/batch_write_steady/treedb: top hotspot "runtime/pprof.(*profileBuilder).emitLocation" is 71.72% flat; this section is highly concentrated in one function.
- alloc_objects/dataset_write_random/treedb: dominant theme is write/delete/flush path (66.00% flat across top nodes).
- alloc_objects/dataset_write_random/treedb: top allocator by count is "runtime/pprof.allFrames" (2185 flat, 31.53%).
- alloc_objects/dataset_write_sorted/treedb: dominant theme is write/delete/flush path (62.41% flat across top nodes).
- alloc_objects/dataset_write_sorted/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc" (3848 flat, 62.41%).
- alloc_objects/dataset_write_sorted/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc" is 62.41% flat; this section is highly concentrated in one function.
- alloc_objects/full_scan/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)" (65540 flat, 90.13%).
- alloc_objects/full_scan/treedb: top hotspot "github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)" is 90.13% flat; this section is highly concentrated in one function.
- alloc_objects/prefix_scan/treedb: top allocator by count is "runtime/pprof.(*profileBuilder).emitLocation" (5474 flat, 90.03%).
- alloc_objects/prefix_scan/treedb: top hotspot "runtime/pprof.(*profileBuilder).emitLocation" is 90.03% flat; this section is highly concentrated in one function.
- alloc_objects/random_delete/treedb: top allocator by count is "runtime/pprof.allFrames" (7646 flat, 91.92%).
- alloc_objects/random_delete/treedb: top hotspot "runtime/pprof.allFrames" is 91.92% flat; this section is highly concentrated in one function.
- alloc_objects/random_read/treedb: top allocator by count is "runtime/pprof.allFrames" (4370 flat, 94.34%).
- alloc_objects/random_read/treedb: top hotspot "runtime/pprof.allFrames" is 94.34% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_batch/treedb: top allocator by count is "runtime/pprof.allFrames" (9831 flat, 66.00%).
- alloc_objects/random_read_batch/treedb: top hotspot "runtime/pprof.allFrames" is 66.00% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_parallel/treedb: top allocator by count is "runtime/pprof.(*profileBuilder).emitLocation" (5507 flat, 36.18%).
- alloc_objects/random_read_parallel/treedb: top hotspot "runtime/pprof.(*profileBuilder).emitLocation" is 36.18% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_parallel_acquire_snapshot/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" (2376975 flat, 99.67%).
- alloc_objects/random_read_parallel_acquire_snapshot/treedb: top hotspot "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" is 99.67% flat; this section is highly concentrated in one function.
- alloc_objects/random_write/treedb: top allocator by count is "runtime/pprof.allFrames" (2185 flat, 61.90%).
- alloc_objects/random_write/treedb: top hotspot "runtime/pprof.allFrames" is 61.90% flat; this section is highly concentrated in one function.
- alloc_objects/sequential_write/treedb: dominant theme is value decode/read I/O (36.70% flat across top nodes).
- alloc_objects/sequential_write/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState" (1028 flat, 33.69%).
- alloc_space/batch_delete/treedb: dominant theme is write/delete/flush path (45.95% flat across top nodes).
- alloc_space/batch_delete/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked" (5731.58kB flat, 29.65%).
- alloc_space/batch_random/treedb: dominant theme is write/delete/flush path (79.29% flat across top nodes).
- alloc_space/batch_random/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/caching.getBatchArena" (28.03MB flat, 52.23%).
- alloc_space/batch_random/treedb: top hotspot "github.com/snissn/gomap/TreeDB/caching.getBatchArena" is 52.23% flat; this section is highly concentrated in one function.
- alloc_space/batch_small_seq/treedb: dominant theme is write/delete/flush path (78.63% flat across top nodes).
- alloc_space/batch_small_seq/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/caching.getBatchArena" (23921.92kB flat, 59.36%).
- alloc_space/batch_small_seq/treedb: top hotspot "github.com/snissn/gomap/TreeDB/caching.getBatchArena" is 59.36% flat; this section is highly concentrated in one function.
- alloc_space/batch_write/treedb: dominant theme is write/delete/flush path (72.04% flat across top nodes).
- alloc_space/batch_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (17203.68kB flat, 54.25%).
- alloc_space/batch_write/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 54.25% flat; this section is highly concentrated in one function.
- alloc_space/batch_write_steady/treedb: dominant theme is value decode/read I/O (38.71% flat across top nodes).
- alloc_space/batch_write_steady/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (4512.93kB flat, 16.22%).
- alloc_space/dataset_write_random/treedb: dominant theme is write/delete/flush path (59.00% flat across top nodes).
- alloc_space/dataset_write_random/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked" (9983.13kB flat, 38.97%).
- alloc_space/dataset_write_random/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked" is 38.97% flat; this section is highly concentrated in one function.
- alloc_space/dataset_write_sorted/treedb: dominant theme is write/delete/flush path (54.88% flat across top nodes).
- alloc_space/dataset_write_sorted/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc" (8210.01kB flat, 54.88%).
- alloc_space/dataset_write_sorted/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc" is 54.88% flat; this section is highly concentrated in one function.
- alloc_space/full_scan/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)" (4096.25kB flat, 27.12%).
- alloc_space/prefix_scan/treedb: dominant theme is value decode/read I/O (67.97% flat across top nodes).
- alloc_space/prefix_scan/treedb: top allocator by bytes is "compress/flate.newDeflateFast (inline)" (3383.02kB flat, 34.11%).
- alloc_space/random_delete/treedb: dominant theme is write/delete/flush path (58.57% flat across top nodes).
- alloc_space/random_delete/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked" (9378.95kB flat, 55.53%).
- alloc_space/random_delete/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked" is 55.53% flat; this section is highly concentrated in one function.
- alloc_space/random_read/treedb: dominant theme is value decode/read I/O (59.58% flat across top nodes).
- alloc_space/random_read/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (2707.76kB flat, 35.43%).
- alloc_space/random_read/treedb: top hotspot "compress/flate.NewWriter (inline)" is 35.43% flat; this section is highly concentrated in one function.
- alloc_space/random_read_batch/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (5415.52kB flat, 31.39%).
- alloc_space/random_read_parallel/treedb: dominant theme is value decode/read I/O (55.09% flat across top nodes).
- alloc_space/random_read_parallel/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (4512.93kB flat, 43.26%).
- alloc_space/random_read_parallel/treedb: top hotspot "compress/flate.NewWriter (inline)" is 43.26% flat; this section is highly concentrated in one function.
- alloc_space/random_read_parallel_acquire_snapshot/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" (2.27GB flat, 99.46%).
- alloc_space/random_read_parallel_acquire_snapshot/treedb: top hotspot "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" is 99.46% flat; this section is highly concentrated in one function.
- alloc_space/random_write/treedb: dominant theme is write/delete/flush path (84.18% flat across top nodes).
- alloc_space/random_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (44.18MB flat, 65.96%).
- alloc_space/random_write/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 65.96% flat; this section is highly concentrated in one function.
- alloc_space/sequential_write/treedb: dominant theme is write/delete/flush path (69.56% flat across top nodes).
- alloc_space/sequential_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk" (24.24MB flat, 28.15%).
- block/batch_delete/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_delete/treedb: top hotspot "runtime.chanrecv1" is 100.00% flat; this section is highly concentrated in one function.
- block/batch_random/treedb: dominant theme is locking/scheduling contention (99.61% flat across top nodes).
- block/batch_random/treedb: top hotspot "runtime.selectgo" is 99.61% flat; this section is highly concentrated in one function.
- block/batch_small_seq/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_small_seq/treedb: top hotspot "runtime.selectgo" is 89.92% flat; this section is highly concentrated in one function.
- block/batch_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_write/treedb: top hotspot "runtime.chanrecv1" is 100.00% flat; this section is highly concentrated in one function.
- block/batch_write_steady/treedb: dominant theme is locking/scheduling contention (91.95% flat across top nodes).
- block/batch_write_steady/treedb: top hotspot "runtime.chanrecv2" is 55.60% flat; this section is highly concentrated in one function.
- block/dataset_write_random/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/dataset_write_random/treedb: top hotspot "runtime.chanrecv1" is 50.12% flat; this section is highly concentrated in one function.
- block/dataset_write_sorted/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/dataset_write_sorted/treedb: top hotspot "runtime.chanrecv1" is 50.24% flat; this section is highly concentrated in one function.
- block/full_scan/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/full_scan/treedb: top hotspot "runtime.selectgo" is 81.72% flat; this section is highly concentrated in one function.
- block/prefix_scan/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/prefix_scan/treedb: top hotspot "runtime.chanrecv1" is 100.00% flat; this section is highly concentrated in one function.
- block/random_delete/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/random_delete/treedb: top hotspot "runtime.selectgo" is 91.58% flat; this section is highly concentrated in one function.
- block/random_read/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/random_read/treedb: top hotspot "runtime.selectgo" is 54.71% flat; this section is highly concentrated in one function.
- block/random_read_batch/treedb: dominant theme is locking/scheduling contention (91.38% flat across top nodes).
- block/random_read_batch/treedb: top hotspot "runtime.selectgo" is 91.38% flat; this section is highly concentrated in one function.
- block/random_read_parallel/treedb: dominant theme is locking/scheduling contention (94.14% flat across top nodes).
- block/random_read_parallel/treedb: top hotspot "runtime.selectgo" is 74.11% flat; this section is highly concentrated in one function.
- block/random_read_parallel_acquire_snapshot/treedb: dominant theme is locking/scheduling contention (90.72% flat across top nodes).
- block/random_read_parallel_acquire_snapshot/treedb: top hotspot "runtime.selectgo" is 66.91% flat; this section is highly concentrated in one function.
- block/random_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/random_write/treedb: top hotspot "runtime.chanrecv1" is 100.00% flat; this section is highly concentrated in one function.
- block/sequential_write/treedb: dominant theme is locking/scheduling contention (99.97% flat across top nodes).
- block/sequential_write/treedb: top hotspot "runtime.selectgo" is 97.84% flat; this section is highly concentrated in one function.
- batch_delete/treedb: dominant theme is iterator/seek/compare overhead (60.01% flat across top nodes).
- batch_delete/treedb: top hotspot "runtime.scanObject" is 40.00% flat; this section is highly concentrated in one function.
- batch_random/treedb: dominant theme is iterator/seek/compare overhead (56.25% flat across top nodes).
- batch_small_seq/treedb: dominant theme is iterator/seek/compare overhead (42.86% flat across top nodes).
- batch_small_seq/treedb: top hotspot "runtime.memclrNoHeapPointers" is 38.10% flat; this section is highly concentrated in one function.
- batch_write/treedb: dominant theme is iterator/seek/compare overhead (58.34% flat across top nodes).
- checkpoint/batch_delete/treedb: dominant theme is value decode/read I/O (39.69% flat across top nodes).
- checkpoint/batch_small_seq/treedb: dominant theme is value decode/read I/O (66.09% flat across top nodes).
- checkpoint/batch_small_seq/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 60.00% flat; this section is highly concentrated in one function.
- checkpoint/batch_write/treedb: dominant theme is value decode/read I/O (66.66% flat across top nodes).
- checkpoint/batch_write/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 47.92% flat; this section is highly concentrated in one function.
- checkpoint/batch_write_steady/treedb: dominant theme is value decode/read I/O (31.25% flat across top nodes).
- checkpoint/dataset_write_random/treedb: dominant theme is value decode/read I/O (30.56% flat across top nodes).
- checkpoint/dataset_write_sorted/treedb: dominant theme is iterator/seek/compare overhead (26.09% flat across top nodes).
- checkpoint/random_read/treedb: dominant theme is value decode/read I/O (65.26% flat across top nodes).
- checkpoint/random_read/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 55.93% flat; this section is highly concentrated in one function.
- checkpoint/random_write/treedb: dominant theme is allocation/copy/gc (33.33% flat across top nodes).
- dataset_write_random/treedb: dominant theme is iterator/seek/compare overhead (29.40% flat across top nodes).
- dataset_write_sorted/treedb: dominant theme is iterator/seek/compare overhead (33.33% flat across top nodes).
- full_scan/treedb: dominant theme is value decode/read I/O (48.88% flat across top nodes).
- full_scan/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 42.22% flat; this section is highly concentrated in one function.
- prefix_scan/treedb: dominant theme is iterator/seek/compare overhead (50.00% flat across top nodes).
- prefix_scan/treedb: top hotspot "runtime.scanObject" is 50.00% flat; this section is highly concentrated in one function.
- random_delete/treedb: dominant theme is iterator/seek/compare overhead (57.89% flat across top nodes).
- random_read/treedb: dominant theme is iterator/seek/compare overhead (28.00% flat across top nodes).
- random_read_batch/treedb: dominant theme is value decode/read I/O (32.64% flat across top nodes).
- random_read_parallel/treedb: dominant theme is value decode/read I/O (23.87% flat across top nodes).
- random_write/treedb: dominant theme is write/delete/flush path (26.68% flat across top nodes).
- sequential_write/treedb: dominant theme is iterator/seek/compare overhead (33.33% flat across top nodes).
- mutex/batch_write_steady/treedb: dominant theme is locking/scheduling contention (100.01% flat across top nodes).
- mutex/batch_write_steady/treedb: top hotspot "sync.(*Mutex).Unlock (inline)" is 81.64% flat; this section is highly concentrated in one function.
- mutex/random_read/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/random_read/treedb: top hotspot "runtime.unlock (inline)" is 100.00% flat; this section is highly concentrated in one function.
- mutex/random_read_batch/treedb: dominant theme is locking/scheduling contention (99.75% flat across top nodes).
- mutex/random_read_batch/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 79.47% flat; this section is highly concentrated in one function.
- mutex/random_read_parallel/treedb: dominant theme is locking/scheduling contention (99.80% flat across top nodes).
- mutex/random_read_parallel/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 98.07% flat; this section is highly concentrated in one function.
- mutex/random_read_parallel_acquire_snapshot/treedb: dominant theme is locking/scheduling contention (99.74% flat across top nodes).
- mutex/random_read_parallel_acquire_snapshot/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 86.52% flat; this section is highly concentrated in one function.
- mutex/sequential_write/treedb: dominant theme is locking/scheduling contention (100.01% flat across top nodes).
- mutex/sequential_write/treedb: top hotspot "runtime.unlock (inline)" is 94.95% flat; this section is highly concentrated in one function.

## Investigation Targets

| db tag | test | category | function | flat% | code | why |
|---|---|---|---|---:|---|---|
| treedb | batch_delete | other | `runtime/pprof.allFrames` | 71.55% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 10.38% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` | 8.38% | `TreeDB/internal/memtable/append_only.go:1217` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchIntSlice` | 3.54% | `TreeDB/caching/db.go:36555` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 2.62% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `runtime/pprof.(*profileBuilder).emitLocation` | 1.31% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `runtime/pprof.(*protobuf).string (inline)` | 0.79% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | decode_read_io | `compress/flate.newDeflateFast (inline)` | 0.65% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_random | other | `runtime/pprof.allFrames` | 58.74% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | other | `runtime/pprof.printCountCycleProfile` | 29.37% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 4.65% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` | 3.44% | `TreeDB/internal/memtable/append_only.go:1217` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | other | `runtime/pprof.(*protobuf).varint (inline)` | 1.32% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | other | `runtime/pprof.(*profileBuilder).emitLocation` | 1.08% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | other | `main.runBenchmark.func25` | 0.01% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | other | `runtime/pprof.allFrames` | 47.21% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 29.53% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` | 10.77% | `TreeDB/caching/db.go:1738` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` | 10.73% | `TreeDB/caching/db.go:35746` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 0.92% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | other | `runtime/pprof.(*profileBuilder).emitLocation` | 66.69% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | other | `runtime/pprof.elfBuildID` | 25.01% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*batchEntrySliceLeasePool).put (inline)` | 7.14% | `TreeDB/caching/db.go:36169` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` | 0.60% | `TreeDB/caching/db.go:36506` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | other | `runtime/pprof.(*profileBuilder).emitLocation` | 71.72% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | other | `runtime/pprof.allFrames` | 23.70% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 2.47% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/valuelog.getDecodeScratch` | 1.05% | `TreeDB/internal/valuelog/reader.go:91` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_random | other | `runtime/pprof.allFrames` | 31.53% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 30.13% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `runtime/pprof.(*profileBuilder).appendLocsForStack` | 29.55% | - | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 5.40% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 1.89% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` | 0.92% | `TreeDB/internal/memtable/append_only.go:1217` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | other | `runtime/pprof.(*profileBuilder).emitLocation` | 0.19% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 62.41% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | other | `runtime/pprof.allFrames` | 35.44% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | other | `runtime/pprof.(*protobuf).string (inline)` | 1.23% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | other | `runtime/pprof.(*profileBuilder).emitLocation` | 0.63% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` | 90.13% | `TreeDB/node/leaf.go:106` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.allFrames` | 9.01% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 0.17% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 90.03% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 8.42% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 0.81% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | decode_read_io | `compress/flate.newDeflateFast (inline)` | 0.62% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | decode_read_io | `compress/flate.NewWriter (inline)` | 0.08% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | decode_read_io | `compress/flate.(*compressor).init` | 0.03% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | other | `runtime/pprof.allFrames` | 91.92% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 6.25% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` | 1.54% | `TreeDB/internal/memtable/append_only.go:1217` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read | other | `runtime/pprof.allFrames` | 94.34% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 2.37% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 1.73% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `runtime/pprof.(*protobuf).string (inline)` | 1.19% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.allFrames` | 66.00% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.newHuffmanBitWriter (inline)` | 27.50% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 3.28% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 2.20% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `github.com/snissn/gomap/TreeDB/tree.getGetManyScratch` | 0.52% | `TreeDB/tree/tree.go:1188` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.(*profileBuilder).emitLocation` | 0.26% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.(*compressor).init` | 0.09% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | decode_read_io | `compress/flate.NewWriter (inline)` | 0.05% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `runtime/pprof.(*profileBuilder).emitLocation` | 36.18% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.allFrames` | 35.88% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.printCountCycleProfile` | 14.36% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | alloc_copy_gc | `runtime.mallocgc` | 13.21% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | random_read_parallel_acquire_snapshot | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 99.67% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | other | `runtime/pprof.allFrames` | 61.90% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 18.84% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | decode_read_io | `compress/flate.(*huffmanEncoder).generate` | 6.46% | `TreeDB/db/fuzz_test.go:22` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | other | `runtime/pprof.(*protobuf).varint (inline)` | 4.84% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` | 3.63% | `TreeDB/internal/memtable/append_only.go:1217` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | other | `runtime/pprof.(*profileBuilder).emitLocation` | 3.06% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | decode_read_io | `compress/flate.(*compressor).init` | 0.20% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | decode_read_io | `compress/flate.NewWriter (inline)` | 0.17% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | decode_read_io | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` | 33.69% | `TreeDB/db/leaf_page_read_cache.go:552` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.init.func2` | 29.47% | `TreeDB/caching/db.go:1256` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 25.40% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | other | `runtime/pprof.(*profileBuilder).emitLocation` | 3.54% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | decode_read_io | `github.com/snissn/gomap/TreeDB/caching.getVlogPreparedFrames` | 2.62% | `TreeDB/caching/db.go:2352` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 2.03% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildOrderedKey64Locked` | 1.11% | `TreeDB/internal/memtable/append_only.go:2341` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).mergeLeaf.func4` | 1.05% | `TreeDB/zipper/zipper.go:2612` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 29.65% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | decode_read_io | `compress/flate.NewWriter (inline)` | 14.01% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | decode_read_io | `compress/flate.newDeflateFast (inline)` | 11.87% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 10.99% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | other | `main.runBenchmark.func26` | 8.51% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | decode_read_io | `compress/flate.(*compressor).init` | 6.18% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | other | `runtime/pprof.(*profileBuilder).emitLocation` | 5.45% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `runtime/pprof.(*protobuf).string` | 2.70% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` | 52.23% | `TreeDB/caching/db.go:1738` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 11.80% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 11.38% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | decode_read_io | `compress/flate.NewWriter (inline)` | 6.57% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_random | decode_read_io | `compress/flate.(*compressor).init` | 4.35% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_random | other | `main.runBenchmark.func25` | 2.99% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | decode_read_io | `compress/flate.newDeflateFast (inline)` | 2.12% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.compactBatchMainArenaTailAliases` | 1.94% | `TreeDB/caching/db.go:37210` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` | 59.36% | `TreeDB/caching/db.go:1738` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 11.45% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | decode_read_io | `compress/flate.newDeflateFast (inline)` | 5.60% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_small_seq | decode_read_io | `compress/flate.(*compressor).init` | 4.84% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_small_seq | decode_read_io | `compress/flate.NewWriter (inline)` | 4.48% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 3.99% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | other | `runtime/pprof.allFrames` | 3.81% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` | 2.54% | `TreeDB/caching/db.go:35746` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 54.25% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | decode_read_io | `compress/flate.NewWriter (inline)` | 17.08% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` | 12.17% | `TreeDB/caching/db.go:36506` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | decode_read_io | `compress/flate.(*compressor).init` | 4.10% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchEntries` | 4.00% | `TreeDB/caching/db.go:36457` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | decode_read_io | `compress/flate.newDeflateFast (inline)` | 3.56% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*batchEntrySliceLeasePool).put (inline)` | 1.62% | `TreeDB/caching/db.go:36169` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | other | `runtime/pprof.elfBuildID` | 1.61% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | decode_read_io | `compress/flate.NewWriter (inline)` | 16.22% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 15.35% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | other | `runtime/pprof.(*profileBuilder).emitLocation` | 13.10% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve (inline)` | 13.00% | `TreeDB/batch/batch.go:448` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | decode_read_io | `compress/flate.(*compressor).init` | 8.59% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | other | `runtime/pprof.StartCPUProfile` | 6.34% | `TreeDB/cmd/vlog_dict_realdata/main.go:2197` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | decode_read_io | `compress/flate.newDeflateFast (inline)` | 6.15% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | other | `main.runBenchmark.func6` | 5.91% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 38.97% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | decode_read_io | `compress/flate.NewWriter (inline)` | 21.14% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 16.02% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | decode_read_io | `compress/flate.newDeflateFast (inline)` | 6.68% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_random | decode_read_io | `compress/flate.(*compressor).init` | 5.08% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_random | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 4.03% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | other | `runtime/pprof.(*profileBuilder).emitLocation` | 2.08% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` | 2.01% | `TreeDB/internal/memtable/append_only.go:1217` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 54.88% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | decode_read_io | `compress/flate.NewWriter (inline)` | 18.10% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_sorted | decode_read_io | `compress/flate.(*compressor).init` | 16.69% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_sorted | other | `runtime/pprof.(*profileBuilder).emitLocation` | 3.47% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | other | `runtime/pprof.(*protobuf).string (inline)` | 3.44% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | other | `runtime/pprof.allFrames` | 3.42% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` | 27.12% | `TreeDB/node/leaf.go:106` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | decode_read_io | `compress/flate.NewWriter (inline)` | 17.92% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | decode_read_io | `compress/flate.(*compressor).init` | 12.92% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 10.73% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.allFrames` | 10.17% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | decode_read_io | `compress/flate.newDeflateFast (inline)` | 7.46% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 3.46% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 3.42% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | decode_read_io | `compress/flate.newDeflateFast (inline)` | 34.11% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | decode_read_io | `compress/flate.NewWriter (inline)` | 27.30% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 16.32% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 10.54% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | decode_read_io | `compress/flate.(*compressor).init` | 6.56% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 5.17% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 55.53% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | decode_read_io | `compress/flate.NewWriter (inline)` | 21.38% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | decode_read_io | `compress/flate.(*compressor).init` | 7.08% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | decode_read_io | `compress/flate.newDeflateFast (inline)` | 6.90% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | other | `runtime/pprof.allFrames` | 6.06% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` | 3.04% | `TreeDB/internal/memtable/append_only.go:1217` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read | decode_read_io | `compress/flate.NewWriter (inline)` | 35.43% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | decode_read_io | `compress/flate.(*compressor).init` | 24.15% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 13.52% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `runtime/pprof.allFrames` | 13.40% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `runtime/pprof.(*protobuf).string (inline)` | 6.76% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 6.74% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.NewWriter (inline)` | 31.39% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `github.com/snissn/gomap/TreeDB/tree.getGetManyScratch` | 21.79% | `TreeDB/tree/tree.go:1188` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.(*compressor).init` | 10.70% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 9.01% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.allFrames` | 8.90% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 5.95% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.newDeflateFast (inline)` | 3.16% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `runtime/pprof.(*protobuf).string (inline)` | 3.13% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.NewWriter (inline)` | 43.26% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `runtime/pprof.(*profileBuilder).emitLocation` | 20.31% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | alloc_copy_gc | `runtime.mallocgc` | 9.82% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.(*compressor).init` | 6.24% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.newDeflateFast (inline)` | 5.59% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `runtime/pprof.(*protobuf).string (inline)` | 4.97% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.printCountCycleProfile` | 4.91% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.allFrames` | 4.91% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 99.46% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 65.96% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 17.47% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | decode_read_io | `compress/flate.NewWriter (inline)` | 6.58% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | decode_read_io | `compress/flate.newDeflateFast (inline)` | 3.40% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | decode_read_io | `compress/flate.(*compressor).init` | 2.85% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | other | `runtime/pprof.(*profileBuilder).emitLocation` | 0.75% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` | 0.75% | `TreeDB/internal/memtable/append_only.go:1217` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | other | `runtime/pprof.(*protobuf).varint (inline)` | 0.75% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 28.15% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 26.09% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve (inline)` | 8.20% | `TreeDB/batch/batch.go:448` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.acquireSpanNativeLeafLogPayloadArena` | 5.35% | `TreeDB/zipper/span_native_apply.go:87` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | decode_read_io | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` | 4.66% | `TreeDB/db/leaf_page_read_cache.go:552` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/valuelog.getWriterAppendBuf` | 4.65% | `TreeDB/internal/valuelog/writer.go:382` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | decode_read_io | `compress/flate.NewWriter (inline)` | 4.09% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.init.func2` | 4.08% | `TreeDB/caching/db.go:1256` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | locking_scheduling | `runtime.chanrecv1` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_random | locking_scheduling | `runtime.selectgo` | 99.61% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_small_seq | locking_scheduling | `runtime.selectgo` | 89.92% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_small_seq | locking_scheduling | `runtime.chanrecv1` | 10.08% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write | locking_scheduling | `runtime.chanrecv1` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `runtime.chanrecv2` | 55.60% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `runtime.selectgo` | 28.94% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | other | `sync.(*WaitGroup).Wait` | 8.02% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | locking_scheduling | `runtime.chanrecv1` | 7.41% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | locking_scheduling | `runtime.chanrecv1` | 50.12% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | locking_scheduling | `runtime.selectgo` | 49.88% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | locking_scheduling | `runtime.chanrecv1` | 50.24% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | locking_scheduling | `runtime.selectgo` | 49.76% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | locking_scheduling | `runtime.selectgo` | 81.72% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | locking_scheduling | `runtime.chanrecv1` | 18.28% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | prefix_scan | locking_scheduling | `runtime.chanrecv1` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | locking_scheduling | `runtime.selectgo` | 91.58% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | locking_scheduling | `runtime.chanrecv1` | 8.42% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | locking_scheduling | `runtime.selectgo` | 54.71% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | locking_scheduling | `runtime.chanrecv1` | 45.29% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `runtime.selectgo` | 91.38% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | other | `sync.(*WaitGroup).Wait` | 8.27% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | locking_scheduling | `runtime.selectgo` | 74.11% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | locking_scheduling | `runtime.chanrecv1` | 17.88% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | other | `sync.(*WaitGroup).Wait` | 5.86% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 2.15% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.selectgo` | 66.91% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.chanrecv1` | 16.17% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | other | `sync.(*WaitGroup).Wait` | 9.28% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 7.64% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | locking_scheduling | `runtime.chanrecv1` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime.selectgo` | 97.84% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime.chanrecv1` | 2.13% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_delete | iterator_seek_compare | `runtime.scanObject` | 40.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` | 6.67% | `TreeDB/internal/memtable/append_only.go:1519` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 6.67% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 6.67% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_delete | runtime_syscall | `runtime.(*mspan).moveInlineMarks` | 6.67% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_delete | runtime_syscall | `runtime.findRunnable` | 6.67% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_delete | map_hash_lookup | `runtime.mapaccess2_faststr` | 6.67% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | batch_delete | iterator_seek_compare | `runtime.scanblock` | 6.67% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_random | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 25.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_random | alloc_copy_gc | `runtime.memmove` | 12.50% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_random | iterator_seek_compare | `runtime.scanObject` | 12.50% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_random | iterator_seek_compare | `runtime.typePointers.next` | 12.50% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setWithMVCCInput` | 6.25% | `TreeDB/caching/db.go:37411` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 6.25% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | other | `github.com/snissn/gomap/TreeDB/caching.pointEntryRevisionStats (inline)` | 6.25% | `TreeDB/caching/db.go:11160` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | other | `math/rand.(*Rand).Int31n` | 6.25% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | alloc_copy_gc | `runtime.memclrNoHeapPointers` | 38.10% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_small_seq | iterator_seek_compare | `runtime.scanObject` | 23.81% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_small_seq | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 14.29% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_small_seq | map_hash_lookup | `aeshashbody` | 4.76% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.batchShardFirstLast (inline)` | 4.76% | `TreeDB/caching/db.go:36661` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` | 4.76% | `TreeDB/internal/memtable/append_only.go:718` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | iterator_seek_compare | `internal/runtime/atomic.(*Uint32).CompareAndSwap` | 4.76% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_small_seq | runtime_syscall | `runtime.traceAcquireEnabled` | 4.76% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_write | iterator_seek_compare | `runtime.typePointers.next` | 25.00% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write | iterator_seek_compare | `runtime.scanObject` | 16.67% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 16.67% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).noteEntryAppend` | 8.33% | `TreeDB/caching/db.go:36868` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | other | `github.com/snissn/gomap/TreeDB/caching.pointEntryRevisionStats (inline)` | 8.33% | `TreeDB/caching/db.go:11160` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | locking_scheduling | `runtime.(*sweepLocker).tryAcquire` | 8.33% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write | runtime_syscall | `runtime.findObject` | 8.33% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_write | map_hash_lookup | `runtime.mapaccess2_fast64` | 8.33% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | batch_write_steady | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 10.00% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | other | `internal/runtime/syscall/linux.Syscall6` | 10.00% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | other | `encoding/binary.littleEndian.Uint64 (inline)` | 5.00% | `TreeDB/internal/quantizedasset/quantized_asset.go:984` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).reset (inline)` | 5.00% | `TreeDB/db/batch.go:928` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 5.00% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | decode_read_io | `github.com/snissn/go-crc32-asm.updateIEEE` | 5.00% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setViewValidatedWithMVCCInput` | 5.00% | `TreeDB/caching/db.go:37540` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | other | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).up` | 5.00% | `TreeDB/caching/flush_run_planner.go:374` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_delete | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 26.98% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_delete | alloc_copy_gc | `runtime.memmove` | 9.52% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/batch_delete | iterator_seek_compare | `cmpbody` | 4.76% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/batch_delete | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` | 4.76% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_delete | other | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).mergeLeaf` | 4.76% | `TreeDB/zipper/zipper.go:2612` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_delete | other | `github.com/snissn/gomap/TreeDB/node.(*Builder).addLeafEntryColumnarPrefixV2` | 3.17% | `TreeDB/node/builder.go:701` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_delete | other | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2ValueMetaAt` | 3.17% | `TreeDB/node/leaf.go:1253` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_delete | other | `internal/runtime/syscall/linux.Syscall6` | 3.17% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_small_seq | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 60.00% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_small_seq | other | `internal/runtime/syscall/linux.Syscall6` | 10.43% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_small_seq | iterator_seek_compare | `cmpbody` | 2.61% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey` | 1.74% | `TreeDB/internal/memtable/append_only.go:718` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/batch_small_seq | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL256` | 0.87% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_small_seq | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 0.87% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/batch.(*Batch).PointRevisionStats` | 0.87% | `TreeDB/batch/batch.go:1060` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/batch_small_seq | other | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).down` | 0.87% | `TreeDB/caching/flush_run_planner.go:385` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_write | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 47.92% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` | 8.33% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write | alloc_copy_gc | `runtime.memmove` | 8.33% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/batch_write | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).put (inline)` | 4.17% | `TreeDB/db/pools.go:100` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write | other | `encoding/binary.littleEndian.Uint64 (inline)` | 2.08% | `TreeDB/internal/quantizedasset/quantized_asset.go:984` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_write | map_hash_lookup | `github.com/pierrec/lz4/v4/internal/lz4block.blockHash (inline)` | 2.08% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | checkpoint/batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/batch.(*Batch).PointRevisionStats` | 2.08% | `TreeDB/batch/batch.go:1060` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/batch_write | decode_read_io | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogWriterMuHeld` | 2.08% | `TreeDB/caching/db.go:29311` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write_steady | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 18.75% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write_steady | iterator_seek_compare | `cmpbody` | 6.25% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/batch_write_steady | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 6.25% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write_steady | decode_read_io | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogInternalObserved` | 6.25% | `TreeDB/caching/db.go:17854` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write_steady | other | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).down` | 6.25% | `TreeDB/caching/flush_run_planner.go:385` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_write_steady | other | `github.com/snissn/gomap/TreeDB/caching.(*stableUnsafeOpIter).Entry` | 6.25% | `TreeDB/caching/flush_run_planner.go:307` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_write_steady | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` | 6.25% | `TreeDB/caching/flush_run_planner.go:468` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/batch_write_steady | other | `github.com/snissn/gomap/TreeDB/freelist.(*ReservationLedger).firstUnreservedAtOrAfter` | 6.25% | `TreeDB/freelist/generation_v1_reservation.go:486` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/dataset_write_random | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 19.44% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey` | 11.11% | `TreeDB/internal/memtable/append_only.go:718` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/dataset_write_random | alloc_copy_gc | `runtime.memmove` | 11.11% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/dataset_write_random | iterator_seek_compare | `cmpbody` | 8.33% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/dataset_write_random | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` | 5.56% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_random | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).put (inline)` | 5.56% | `TreeDB/db/pools.go:100` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_random | other | `github.com/snissn/gomap/TreeDB/node.sharedPrefixLen` | 5.56% | `TreeDB/node/builder.go:1860` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/dataset_write_random | other | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Swap` | 2.78% | `TreeDB/caching/db.go:15549` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/dataset_write_sorted | iterator_seek_compare | `cmpbody` | 21.74% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` | 17.39% | `TreeDB/internal/memtable/append_only.go:718` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/dataset_write_sorted | alloc_copy_gc | `runtime.memmove` | 13.04% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/dataset_write_sorted | alloc_copy_gc | `runtime.memclrNoHeapPointers` | 8.70% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/dataset_write_sorted | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` | 4.35% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_sorted | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).get (inline)` | 4.35% | `TreeDB/db/db.go:5218` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_sorted | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` | 4.35% | `TreeDB/caching/flush_run_planner.go:468` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).resetLockedWithPolicy` | 4.35% | `TreeDB/internal/memtable/append_only.go:2497` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/random_delete | alloc_copy_gc | `runtime.memmove` | 20.00% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/random_delete | other | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).down` | 13.33% | `TreeDB/caching/flush_run_planner.go:385` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_delete | iterator_seek_compare | `bytes.Compare (inline)` | 6.67% | `TreeDB/collections/text_v2_search.go:219` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/random_delete | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` | 6.67% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_delete | other | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).pop` | 6.67% | `TreeDB/caching/flush_run_planner.go:354` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_delete | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` | 6.67% | `TreeDB/caching/flush_run_planner.go:468` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/random_delete | other | `github.com/snissn/gomap/TreeDB/db.(*DB).NoteLeafGenerationRecordLength` | 6.67% | `TreeDB/db/leaf_generation_record_length_index.go:191` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_delete | other | `github.com/snissn/gomap/TreeDB/node.(*Builder).addLeafEntryColumnarPrefixV2` | 6.67% | `TreeDB/node/builder.go:701` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_read | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 55.93% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_read | iterator_seek_compare | `cmpbody` | 4.24% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/random_read | other | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafValueViewColumnarPrefixV2` | 3.39% | `TreeDB/node/leaf.go:1376` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_read | other | `internal/runtime/syscall/linux.Syscall6` | 3.39% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_read | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 2.54% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_read | alloc_copy_gc | `runtime.memclrNoHeapPointers` | 2.54% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/random_read | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).UnsafeEntryWithRevision` | 1.69% | `TreeDB/internal/memtable/append_only.go:2939` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/random_read | other | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2EnsureMeta` | 1.69% | `TreeDB/node/leaf.go:1157` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_write | iterator_seek_compare | `cmpbody` | 33.33% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.appendCanonicalFlushRunChunkToBackendBatch` | 33.33% | `TreeDB/caching/flush_run_planner.go:971` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/random_write | alloc_copy_gc | `runtime.memmove` | 33.33% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | dataset_write_random | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 17.65% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | alloc_copy_gc | `runtime.memmove` | 11.76% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | dataset_write_random | iterator_seek_compare | `runtime.scanObject` | 11.76% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_random | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 11.76% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_random | decode_read_io | `compress/flate.(*huffmanBitWriter).writeCode` | 5.88% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_random | other | `internal/runtime/atomic.(*UnsafePointer).StoreNoWB (inline)` | 5.88% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | other | `memeqbody` | 5.88% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | map_hash_lookup | `runtime.mapassign_faststr` | 5.88% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | dataset_write_sorted | iterator_seek_compare | `runtime.typePointers.next` | 20.00% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_sorted | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 13.33% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 13.33% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_sorted | other | `bytes.Equal (inline)` | 6.67% | `TreeDB/db/recoverable_root_set.go:65` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | map_hash_lookup | `github.com/cespare/xxhash/v2.Sum64` | 6.67% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).beginMVCCInputCut (inline)` | 6.67% | `TreeDB/caching/mvcc_admission.go:8` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | other | `internal/runtime/syscall/linux.Syscall6` | 6.67% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 6.67% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 42.22% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | other | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` | 6.67% | `TreeDB/node/leaf.go:1284` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | iterator_seek_compare | `runtime.scanObject` | 6.67% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | full_scan | other | `internal/runtime/syscall/linux.Syscall6` | 4.44% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `main.runBenchmark.func37` | 4.44% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | alloc_copy_gc | `runtime.memmove` | 4.44% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | full_scan | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).UnsafeKey (inline)` | 2.22% | `TreeDB/db/api.go:734` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | full_scan | decode_read_io | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadChecksumEnabled` | 2.22% | `TreeDB/db/value_reader.go:91` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.scanObject` | 50.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | map_hash_lookup | `aeshashbody` | 8.33% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | prefix_scan | write_delete_flush | `runtime.(*sweepClass).update (inline)` | 8.33% | `TreeDB/public.go:2264` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | prefix_scan | runtime_syscall | `runtime.divRoundUp (inline)` | 8.33% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | prefix_scan | runtime_syscall | `runtime.findObject` | 8.33% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | prefix_scan | runtime_syscall | `runtime.heapArenaOf (inline)` | 8.33% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | prefix_scan | runtime_syscall | `runtime.spanClass.sizeclass (inline)` | 8.33% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_delete | iterator_seek_compare | `runtime.scanObject` | 31.58% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | iterator_seek_compare | `runtime.typePointers.next` | 15.79% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | other | `sync/atomic.(*Int32).Add (inline)` | 10.53% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWrite` | 5.26% | `TreeDB/caching/db.go:14420` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | iterator_seek_compare | `internal/runtime/atomic.(*Uint32).CompareAndSwap (inline)` | 5.26% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 5.26% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 5.26% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | locking_scheduling | `runtime.(*mheap).freeMSpanLocked` | 5.26% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 8.00% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | iterator_seek_compare | `runtime.scanObject` | 8.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 6.00% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` | 6.00% | `TreeDB/node/internal.go:513` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 6.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | decode_read_io | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getViewLockedWithState` | 4.00% | `TreeDB/db/leaf_page_read_cache.go:931` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | other | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView (inline)` | 4.00% | `TreeDB/node/node.go:165` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `github.com/snissn/gomap/TreeDB/pager.(*Pager).isVerifiedPage` | 4.00% | `TreeDB/pager/pager.go:542` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | iterator_seek_compare | `runtime.scanObject` | 14.29% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_batch | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 12.24% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 10.20% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `internal/runtime/syscall/linux.Syscall6` | 8.16% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `github.com/snissn/gomap/TreeDB/node.(*Node).VerifyChecksum` | 4.08% | `TreeDB/node/node.go:441` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | locking_scheduling | `internal/sync.(*Mutex).Lock` | 4.08% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | other | `sync/atomic.(*Bool).Load (inline)` | 4.08% | `TreeDB/caching/db.go:8970` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | iterator_seek_compare | `bytes.Compare (inline)` | 2.04% | `TreeDB/collections/text_v2_search.go:219` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_parallel | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 11.75% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 6.90% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `internal/runtime/syscall/linux.Syscall6` | 6.72% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | map_hash_lookup | `github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView` | 4.29% | `TreeDB/tree/tree.go:761` | Focus on key-shape and hash-table lookup/update costs. |
| treedb | random_read_parallel | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` | 3.73% | `TreeDB/node/internal.go:513` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_parallel | other | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView (inline)` | 3.73% | `TreeDB/node/node.go:165` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` | 3.54% | `TreeDB/node/internal.go:671` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_parallel | other | `github.com/snissn/gomap/TreeDB/tree.noteOuterLeafLoad` | 3.17% | `TreeDB/tree/outer_leaf_stats.go:140` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | runtime_syscall | `runtime.procyieldAsm` | 15.67% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_read_parallel_acquire_snapshot | other | `sync/atomic.(*Int32).Add (inline)` | 9.00% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 5.62% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 4.27% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 3.15% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel_acquire_snapshot | other | `internal/runtime/syscall/linux.Syscall6` | 3.15% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 2.62% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).lockSlow` | 2.62% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | iterator_seek_compare | `runtime.scanObject` | 20.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_write | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 13.33% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).conditionalRecordCommittedEntries` | 6.67% | `TreeDB/caching/conditional_txn.go:695` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` | 6.67% | `TreeDB/caching/db.go:27309` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `internal/runtime/maps.bitset.first (inline)` | 6.67% | `TreeDB/internal/cowbtree/map.go:1237` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 6.67% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `runtime.(*sweepClass).update` | 6.67% | `TreeDB/public.go:2264` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | runtime_syscall | `runtime.procyieldAsm` | 6.67% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | sequential_write | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 20.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` | 13.33% | `TreeDB/internal/memtable/append_only.go:1461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | alloc_copy_gc | `runtime.memmove` | 13.33% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | sequential_write | iterator_seek_compare | `runtime.scanObject` | 13.33% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | sequential_write | map_hash_lookup | `github.com/snissn/gomap/TreeDB/caching.hashKey` | 6.67% | `TreeDB/caching/db.go:8260` | Focus on key-shape and hash-table lookup/update costs. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Swap (inline)` | 6.67% | `TreeDB/caching/db.go:15549` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` | 6.67% | `TreeDB/internal/memtable/append_only.go:1610` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/mvccadmission.(*Cut).Commit` | 6.67% | `TreeDB/internal/mvccadmission/admission.go:187` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | locking_scheduling | `sync.(*Mutex).Unlock (inline)` | 81.64% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `sync.(*RWMutex).RUnlock` | 0.94% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | locking_scheduling | `runtime.unlock (inline)` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 79.47% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `runtime.unlock (inline)` | 13.43% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `runtime._LostContendedRuntimeLock` | 6.85% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 98.07% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | locking_scheduling | `runtime.unlock (inline)` | 1.73% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 86.52% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.unlock (inline)` | 13.22% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime.unlock (inline)` | 94.95% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime._LostContendedRuntimeLock` | 2.04% | - | Focus on lock scope, contention points, and channel/select coordination. |

## Warnings

- no CPU samples for checkpoint/batch_random/treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/full_scan/treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/post/run_treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/prefix_scan/treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/random_read_batch/treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/random_read_parallel/treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/random_read_parallel_acquire_snapshot/treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/sequential_write/treedb: consider larger -keys or longer workload
- trace detected at "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_checkpoint_between_tests/trace.out" (trace analysis not yet implemented)

