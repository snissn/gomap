- execution path: `native-fastpath`

# unified_bench

- keys: 200,000
- key-shape: be8
- valsize: 128
- batchsize: 8000
- range-queries: 200
- range-span: 100
- val-pattern: zero
- val-pool-size: 0
- profile: fast
- dbs: treedb
- tests: all
- seed: 1

## Resolved TreeDB Options

```text
report_scope=canonical_treedb_options (variant profile/compression overrides excluded)
index_primary_directory_requested=false
index_primary_directory_supported=true
index_primary_directory_configured_enabled=false
profile_resolved=no_wal_fast
durability=wal_off_relaxed
read_integrity=verify
benchmark_unsafe=false
vlog_current_writable_mmap=false
maintenance_mode=normal
index_optimizations=false
leaf_prefix_compression=true
index_columnar_leaves=true
index_packed_valueptr=true
index_internal_base_delta=false
index_outer_leaves_in_vlog=true
outer_leaf_read_cache_entries=default/env (effective=8192)
outer_leaf_read_cache_write_admission=adaptive
cached.domain_ingress_workers=0
cached.domain_ingress_queue_size=0
flush_admission_policy=auto
flush_admission_admitted=true
flush_admission_reason=auto_admitted_hardware_aware
flush_admission_configured_concurrency=0
flush_admission_effective_concurrency=6
flush_admission_concurrency_cap_reason=default_physical_cores
flush_admission_concurrency_defaulted=true
runtime_gomaxprocs=12
flush_admission_flush_apply_span_native=true
flush_admission_flush_backlog_coalescing=true
hardware_physical_cores=6
flush_apply_concurrency=6
flush_apply_min_entries_configured=1
flush_apply_min_spans_configured=1
flush_apply_min_bytes_configured=1
flush_apply_span_native=true
flush_span_run_target_planning=false
flush_backlog_coalescing=true
flush_backlog_coalescing_max_memtables=default (effective=64)
flush_backlog_coalescing_max_bytes=default (effective=536870912)
flush_backlog_coalescing_max_ops=default (effective=2097152)
flush_backlog_coalescing_min_age_ms=0
flush_backlog_coalescing_single_op_ratio=default (effective=0.500000)
flush_backlog_coalescing_max_ops_per_span=default (effective=4.000000)
flush_backlog_coalescing_min_old_leaf_bytes_per_op=0.000000
journal_lanes_configured=0
journal_lanes_effective_default=3
journal_lanes_defaulted=true
journal_lanes_hot=1
journal_lanes_warm=1
journal_lanes_cold=1
vlog.force_pointers=false
vlog.pointer_threshold=default (effective=512B)
vlog.compression=auto
vlog.block_codec=snappy
vlog.auto_policy=balanced
vlog.compression_autotune=medium
vlog.dict_class_mode=single
vlog.generation_policy=hot_warm_cold
vlog.generation_hot_segment_bytes=0
vlog.generation_warm_segment_bytes=0
vlog.generation_cold_segment_bytes=0
vlog.rewrite_budget_bytes_per_sec=0
vlog.rewrite_budget_records_per_sec=0
vlog.rewrite_trigger_stale_ratio_ppm=0
vlog.rewrite_trigger_total_bytes=0
vlog.rewrite_trigger_churn_per_sec=0
vlog.rewrite_min_segment_age_ms=default (effective=30000)
vlog.block_target_bytes=default (effective=4096B)
vlog.incompressible_hold_bytes=default (effective=67108864B)
vlog.incompressible_probe_bytes=default (effective=8388608B)
notes:
  - disable_wal takes precedence over relaxed_sync (durability=wal_off_relaxed)
  - flush_admission_policy=auto admitted: auto_admitted_hardware_aware
  - index_internal_base_delta disabled: leaf-log child pages use explicit LogRecordRef entries
  - index_optimizations enables leaf prefix compression + columnar leaves + packed value pointers + internal base-delta
  - index_packed_valueptr uses a packed 12B leaf ValuePtr encoding (u32 offset cap; cached mode rotates value-log segments automatically)
  - index_primary_directory configuration is not runtime path qualification; verify actual operation/path counters separately
  - leaf_prefix_compression + index_columnar_leaves: enabling combined columnar+prefix leaf encoding for new pages
  - leaf_prefix_compression uses front-coding with restart points (compact v2 leaf entry header for new pages)
  - maintenance_mode=normal defaults vlog.generation_policy=hot_warm_cold
  - vlog.compression=auto selects the actual per-frame codec at runtime; vlog.block_codec is the forced block-mode/default block codec, not proof that auto used that codec. Use treedb.cache.vlog_auto.* and treedb.cache.vlog_write_mode.* stats for actual selection.
```

```text
                                    Test         TreeDB
----------------------------------------  -------------
                        Sequential Write      2,865,018
                            Random Write      2,127,001
                  Dataset Write (Random)      1,869,377
                  Dataset Write (Sorted)      1,731,544
                             Batch Write      5,395,751
                    Batch Write (Steady)        452,238
                            Batch Random      3,209,014
                            Batch Delete      4,443,304
                         Batch Small Seq      1,481,814
                           Random Delete      2,483,625
                             Random Read      2,087,041
                  Random Read (Parallel)     25,568,491
Random Read (Parallel, Snapshot Per Key)      1,696,920
                     Random Read (Batch)      3,755,690
                               Full Scan      2,592,985
                             Prefix Scan      3,963,341
```

## Disk Usage (End of Run)

```text
TreeDB:
  maindb/index.db: 4 MiB
  maindb/leaf_vlog: total=37 MiB files=15 value=37 MiB other=2 KiB
  dictdb/index.db: 64 KiB
```

## TreeDB Perf Instrumentation

```text
Dataset Write (Random) / TreeDB
  vlog_mmap.read.hits.delta=0 miss_out_of_range.delta=0 miss_no_mapping.delta=858 miss_dead_mapping_cap.delta=0 fallback_readat.delta=858 hit_ratio.delta=0.000000
  leaf_generation.generations.pinned.after=1 leaf_generation.pins.total.after=1

Batch Write (Steady) / TreeDB
  vlog_mmap.read.hits.delta=0 miss_out_of_range.delta=0 miss_no_mapping.delta=14585 miss_dead_mapping_cap.delta=0 fallback_readat.delta=14585 hit_ratio.delta=0.000000
  leaf_generation.generations.pinned.after=0 leaf_generation.pins.total.after=0

Random Read (Parallel) / TreeDB
  snapshot.acquire.calls=12 total_ms=0.139 avg_us=11.556
  snapshot.close.calls=12 total_ms=0.044 avg_us=3.694
  vlog_mmap.read.hits.delta=0 miss_out_of_range.delta=0 miss_no_mapping.delta=164536 miss_dead_mapping_cap.delta=0 fallback_readat.delta=164536 hit_ratio.delta=0.000000
  leaf_generation.generations.pinned.after=0 leaf_generation.pins.total.after=0

Random Read (Parallel, Snapshot Per Key) / TreeDB
  snapshot.acquire.calls=2400000 total_ms=7993.271 avg_us=3.331
  snapshot.close.calls=2400000 total_ms=3662.917 avg_us=1.526
  vlog_mmap.read.hits.delta=0 miss_out_of_range.delta=0 miss_no_mapping.delta=472386 miss_dead_mapping_cap.delta=0 fallback_readat.delta=472386 hit_ratio.delta=0.000000
  leaf_generation.generations.pinned.after=0 leaf_generation.pins.total.after=0

Random Read (Batch) / TreeDB
  vlog_mmap.read.hits.delta=0 miss_out_of_range.delta=0 miss_no_mapping.delta=28648 miss_dead_mapping_cap.delta=0 fallback_readat.delta=28648 hit_ratio.delta=0.000000
  leaf_generation.generations.pinned.after=0 leaf_generation.pins.total.after=0

Full Scan / TreeDB
  vlog_mmap.read.hits.delta=0 miss_out_of_range.delta=0 miss_no_mapping.delta=40591 miss_dead_mapping_cap.delta=0 fallback_readat.delta=40591 hit_ratio.delta=0.000000
  leaf_generation.generations.pinned.after=0 leaf_generation.pins.total.after=0

Prefix Scan / TreeDB
  vlog_mmap.read.hits.delta=0 miss_out_of_range.delta=0 miss_no_mapping.delta=135 miss_dead_mapping_cap.delta=0 fallback_readat.delta=135 hit_ratio.delta=0.000000
  leaf_generation.generations.pinned.after=0 leaf_generation.pins.total.after=0
```

## TreeDB Value-Log Codec Summary (End of Run)

```text
TreeDB:
  vlog_auto.frames: off=0 dict=0 block_snappy=0 block_lz4=44372 block_zstd=0
  vlog_auto.bytes: off=0 dict=0 block_snappy=0 block_lz4=305885906 block_zstd=0
  vlog_auto.frames_frac: block_lz4=1.000000
  vlog_write_mode.block: frames=44372 raw_bytes=305885906 stored_bytes=36542187 stored_ratio=0.119463
  vlog_payload_kind.outer_leaf: frames=44372 raw_bytes=305885906 stored_bytes=36542187 stored_ratio=0.119463
  vlog_payload_split.outer_leaf: records=86877 raw_bytes=305885906 stored_bytes=36542187 stored_ratio=0.119463
  vlog_outer_leaf_codec.unknown: frames=44372 raw_bytes=305885906 stored_bytes=36542187 stored_ratio=0.119463
  vlog_block.k.lz4: count=44372 avg=1.958 max=8 ratio=0.119463
  vlog_block.k.bucket.lz4: le_1=29109 le_2=5233 le_4=6559 le_8=3471 le_16=0 le_32=0 le_64=0
```

## TreeDB Selected Stats (End of Run)

```text
TreeDB:
  vlog_mmap.read.hits: 0
  vlog_mmap.read.miss_out_of_range: 0
  vlog_mmap.read.miss_no_mapping: 721739
  vlog_mmap.read.miss_dead_mapping_cap: 0
  vlog_mmap.read.fallback_readat: 721739
  vlog_mmap.read.hit_ratio: 0.000000
  write_path.mode: cached
  write_path.redo_log: off
  flush_admission.policy: auto
  flush_admission.admitted: true
  flush_admission.reason: auto_admitted_hardware_aware
  flush_admission.flush_apply_concurrency_configured: 0
  flush_admission.flush_apply_concurrency: 6
  flush_admission.flush_apply_concurrency_cap_reason: default_physical_cores
  flush_admission.flush_apply_concurrency_defaulted: true
  flush_admission.gomaxprocs: 12
  flush_admission.physical_cores: 6
  flush_admission.flush_apply_span_native: true
  flush_admission.flush_backlog_coalescing: true
  flush_admission.leaf_page_read_cache_write_admission: adaptive
  vlog_mmap.current_writable_map_target_bytes: 33554432
  vlog_mmap.max_mapped_sealed_segments: 8
  vlog_mmap.max_mapped_sealed_bytes: 67108864
  vlog_mmap.max_mapped_leaf_sealed_segments: 512
  vlog_mmap.max_mapped_leaf_sealed_bytes: 1610612736
  vlog_mmap.sealed_map_denied: 0
  vlog_mmap.sealed_map_denied.count_cap: 0
  vlog_mmap.sealed_map_denied.bytes_cap: 0
  applied_command_lsn: 0
  command_wal.enabled: false
  command_wal.required_feature: false
  command_wal.live_accepted_frames: 0
  command_wal.live_accepted_max_lsn: 0
  command_wal.live_covered_frames: 0
  command_wal.live_covered_max_lsn: 0
  command_wal.frames: 0
  command_wal.typed_segments: 0
  command_wal.max_lsn: 0
  leaf_generation.generations.pinned: 0
  leaf_generation.pins.total: 0
  flush_apply.cache.batches_total: 5
  flush_apply.cache.planning_ns_total: 31221
  flush_apply.cache.build_ns_total: 383670976
  flush_apply.cache.backend_write_ns_total: 2106614749
  flush_apply.cache.leaf_log_append_wait_ns_total: 20099036
  flush_apply.cache.leaf_log_append_ns_total: 339305286
  flush_apply.cache.leaf_log_append_bytes_total: 39182103
  flush_apply.cache.leaf_log_append_frames_total: 44372
  flush_apply.cache.leaf_log_append_frames_per_op: 0.022186
  flush_apply.cache.leaf_log_append_records_total: 86877
  leaf_log_lanes.configured: 7
  leaf_log_lanes.active: 7
  leaf_log_lanes.append_lanes_used: 7
  leaf_log_lanes.append_calls_total: 41088
  leaf_log_lanes.append_pages_total: 86877
  leaf_log_lanes.append_bytes_total: 39182103
  leaf_log_lanes.append_lock_wait_ns_total: 20099036
  leaf_log_lanes.append_lock_hold_ns_total: 191055348
  leaf_log_lanes.append_errors_total: 0
  leaf_log_lanes.segment_rotations_total: 7
  journal_lanes.configured: 0
  journal_lanes.defaulted: true
  journal_lanes.effective: 3
  journal_lanes.hot: 1
  journal_lanes.warm: 1
  journal_lanes.cold: 1
  memtable_shards: 16
  flush_span_run.target_leaves_split_across_chunks_total: 0
  flush_span_run.target_leaf_spans_total: 0
  flush_span_run.single_op_spans_total: 0
  flush_span_run.source_point_ops_total: 2000000
  flush_span_run.planned_ops_total: 1514406
  flush_span_run.planned_point_ops_total: 1514406
  flush_span_run.source_memtables_total: 80
  flush_span_run.shadowed_ops_total: 0
  flush_span_run.range_barriers_total: 0
  flush_span_run.backend_chunks_total: 76
  flush_backlog_coalescing.admitted_runs_total: 0
  flush_backlog_coalescing.admitted_extra_memtables_total: 0
  flush_backlog_coalescing.admitted_extra_ops_total: 0
  flush_backlog_coalescing.selected_memtables_max: 0
  flush_backlog_coalescing.selected_ops_max: 0
  flush_backlog_coalescing.checkpoint.admitted_runs_total: 0
  flush_backlog_coalescing.checkpoint.selected_memtables_max: 0
  flush_backlog_coalescing.checkpoint.selected_ops_max: 0
  flush_backlog_coalescing.checkpoint.base_budget_covered_total: 2
  flush_backlog_coalescing.last_single_op_span_ratio: 0.000000
  flush_backlog_coalescing.last_ops_per_span: 0.000000
  flush_backlog_coalescing.skip.memory_budget_total: 0
  flush_backlog_coalescing.skip.ops_budget_total: 0
  flush_backlog_coalescing.skip.range_barrier_total: 0
  flush_backlog_coalescing.skip.lane_barrier_total: 0
  flush_backlog_coalescing.skip.stop_pressure_total: 0
  flush_apply.prepared_output.leaf_log_pages_prepared_total: 86877
  flush_apply.prepared_output.leaf_log_pages_installed_total: 86877
  flush_apply.prepared_output.leaf_log_pages_abandoned_total: 0
  flush_apply.cache.foreground_assist_wait_ns_total: 0
  flush_apply.cache.coordinator.active: 0
  flush_apply.cache.coordinator.active_workers: 0
  flush_apply.cache.coordinator.in_flight_bytes: 0
  flush_apply.cache.coordinator.active_assist_skips_total: 0
  flush_apply.cache.coordinator.progress_wait_ns_total: 0
  flush_apply.cache.coordinator.stall_waits_total: 0
  flush_apply.cache.coordinator.checkpoint_preemptions_total: 0
  flush_apply.cache.coordinator.blocking_fallbacks_total: 0
  flush_apply.cache.coordinator.hard_overload_fallbacks_total: 0
  checkpoint.flushmu_wait_total_ms: 295.774
  checkpoint.active_background_flush_wait_ns_total: 295773110
  checkpoint.flush_preempt_requests_total: 3
  checkpoint.preflush_kick_skips_total: 2
  checkpoint.shared_drain.flushmu_releases_total: 0
  checkpoint.shared_drain.checkpoint_units_total: 32
  checkpoint.shared_drain.background_units_total: 0
  checkpoint.shared_drain.checkpoint_ops_total: 960000
  checkpoint.shared_drain.background_ops_total: 0
  checkpoint.shared_drain.checkpoint_bytes_total: 79360000
  checkpoint.shared_drain.background_bytes_total: 0
  checkpoint.shared_drain.wait_ns_total: 0
  checkpoint.shared_drain.wait_ns_max: 0
  checkpoint.stage.value_log_flush.total_ns: 1090
  checkpoint.stage.flush_all.total_ns: 1571724198
  checkpoint.stage.leaf_value_log_sync.total_ns: 19715184
  checkpoint.stage.reducer_publish.total_ns: 2828012
  flush_apply.apply_ns_total: 502479981
  flush_apply.old_leaf_read_decode.bytes_total: 161505280
  flush_apply.old_leaf_read_decode.bytes_per_op: 106.645959
  flush_apply.merge_build.leaf_merges_total: 38307
  flush_apply.merge_build.leaf_merges_per_op: 0.025295
  flush_apply.merge_build.replacement_leaf_pages_per_op: 0.057367
  flush_apply.leaf_log_output.reservation_wait_ns_total: 3666362
  flush_apply.leaf_log_output.append_wait_ns_total: 467685701
  flush_apply.leaf_log_output.append_calls_total: 41088
  flush_apply.leaf_log_output.append_pages_total: 86877
  flush_apply.leaf_log_output.lane.tasks_total: 228
  flush_apply.leaf_log_output.lane.tasks_lanes_used: 6
  flush_apply.leaf_log_output.lane.tasks_max: 38
  flush_apply.leaf_log_output.lane.tasks_overflow_total: 0
  flush_apply.span_run.target_leaf_spans_total: 38307
  flush_apply.span_run.single_op_spans_total: 2121
  flush_apply.span_run.ops_per_span: 39.533401
  flush_apply.span_run.bytes_per_span: 5204.689691
  flush_apply.span_native.candidate_ops_total: 1514406
  flush_apply.span_native.eligible_ops_total: 1235955
  flush_apply.span_native.ineligible_ops_total: 278451
  flush_apply.span_native.scheduler.worker_busy_ns_total: 1078810976
  flush_apply.span_native.scheduler.worker_idle_ns_total: 167412158
  flush_apply.span_native.scheduler.worker_wait_ns_total: 348663929
  flush_apply.span_native.scheduler.ready_tasks_total: 263
  flush_apply.span_native.scheduler.dispatched_tasks_total: 263
  flush_apply.span_native.scheduler.completed_tasks_total: 263
  flush_apply.span_native.scheduler.queue_depth_max: 6
  flush_apply.span_native.scheduler.scheduled_workers_total: 263
  flush_apply.span_native.scheduler.scheduled_workers_max: 6
  flush_apply.span_native.scheduler.task_spans_per_task: 84.433460
  flush_apply.span_native.scheduler.task_spans_max: 964
  flush_apply.span_native.scheduler.task_ops_per_task: 4699.448669
  flush_apply.span_native.scheduler.task_ops_max: 16384
  flush_apply.span_native.scheduler.task_bytes_per_task: 675626.920152
  flush_apply.span_native.scheduler.task_bytes_max: 2621440
  flush_apply.span_native.scheduler.single_span_tasks_total: 36
  flush_apply.span_native.fallback.not_implemented_ops_total: 0
  flush_apply.span_native.fallback.root_mismatch_ops_total: 0
  flush_apply.span_native.fallback.range_delete_ops_total: 0
  flush_apply.span_native.fallback.maintenance_ops_total: 278451
  flush_apply.span_native.fallback.inexact_leaf_spans_ops_total: 0
  flush_apply.span_native.fallback.close_or_checkpoint_ops_total: 0
  flush_apply.span_native.fallback.memory_or_emergency_cap_ops_total: 0
  flush_apply.span_native.fallback.output_ownership_failure_ops_total: 0
  flush_apply.span_native.fallback.reducer_validation_failed_ops_total: 0
  flush_apply.root_reduce.ns_total: 11001858
  flush_apply.commit_wait_ns_total: 0
  flush_apply.publish_prepare.ns_total: 9146113
  flush_apply.guarded_publish.ns_total: 0
  flush_apply.publish_final_install.ns_total: 0
  flush_apply.publish_total.ns_total: 9146113
  flush_apply.reducer_publish.ns_total: 11001858
  flush_apply.retry_total: 0
  flush_apply.mismatch_total: 0
  publish.ordered_root_delta_group.calls_total: 0
  publish.ordered_root_delta_group.roots_total: 0
  publish.ordered_root_delta_group.avg_roots_per_call: 0.000
  publish.ordered_root_delta_group.span_native.candidate_ops_total: 0
  publish.ordered_root_delta_group.span_native.eligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.used_ops_total: 0
  publish.ordered_root_delta_group.span_native.ineligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallbacks_total: 0
  publish.ordered_root_delta_group.span_native.fallback.not_implemented_count_total: 0
  publish.ordered_root_delta_group.span_native.fallback.not_implemented_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.prepare_error_count_total: 0
  publish.ordered_root_delta_group.span_native.fallback.prepare_error_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.route_ineligible_count_total: 0
  publish.ordered_root_delta_group.span_native.fallback.route_ineligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.disabled_count_total: 0
  publish.ordered_root_delta_group.span_native.fallback.disabled_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.admission_policy_decline_count_total: 0
  publish.ordered_root_delta_group.span_native.fallback.admission_policy_decline_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.validation_failed_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.range_delete_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.cold_build_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.inexact_leaf_spans_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.memory_or_emergency_cap_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.output_ownership_failure_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.reducer_validation_failed_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.root_mismatch_ops_total: 0
  publish.ordered_root_delta_group.span_native.fallback.unknown_count_total: 0
  publish.ordered_root_delta_group.span_native.fallback.unknown_ops_total: 0
  publish.ordered_root_delta_group.root_apply_calls_total: 0
  publish.ordered_root_delta_group.root_apply_ns_total: 0
  publish.ordered_root_delta_group.root_apply_ops_total: 0
  publish.ordered_root_delta_group.root_apply_node_loads_total: 0
  publish.ordered_root_delta_group.root_apply_leaf_log_node_loads_total: 0
  publish.ordered_root_delta_group.root_apply_leaf_log_pages_written_total: 0
  publish.ordered_root_delta_group.root_apply_leaf_log_node_bytes_read_total: 0
  publish.ordered_root_delta_group.root_apply_leaf_log_page_bytes_written_total: 0
  publish.ordered_root_delta_group.publish_prepare_ns_total: 0
  publish.ordered_root_delta_group.write_lock_wait_ns_total: 0
  publish.ordered_root_delta_group.write_lock_hold_ns_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.observations_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.candidate_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.eligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.used_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.ineligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallbacks_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.count_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.count_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.count_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.count_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.count_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.count_total: 0
  publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.ops_total: 0
  publish.ordered_root_delta_group.span_native.triage.direct_publish.context: full ordered-root iterator publish
  publish.ordered_root_delta_group.span_native.triage.direct_publish.status: ineligible
  publish.ordered_root_delta_group.span_native.triage.direct_publish.candidate: false
  publish.ordered_root_delta_group.span_native.triage.direct_publish.eligible: false
  publish.ordered_root_delta_group.span_native.triage.direct_publish.used: false
  publish.ordered_root_delta_group.span_native.triage.direct_publish.fallback_reason: route_ineligible
  publish.ordered_root_delta_group.span_native.triage.direct_publish.fallback_class: route
  publish.ordered_root_delta_group.span_native.triage.direct_publish.admission_policy: auto
  publish.ordered_root_delta_group.span_native.triage.direct_publish.admission_admitted: true
  publish.ordered_root_delta_group.span_native.triage.direct_publish.admission_reason: auto_admitted_hardware_aware
  publish.ordered_root_delta_group.span_native.triage.direct_publish.selected_workers: 6
  publish.ordered_root_delta_group.span_native.triage.direct_publish.detail: direct full-root publish is not a span-native delta route
  publish.ordered_root_delta_group.span_native.route.grouped_publish.observations_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.candidate_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.eligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.used_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.ineligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallbacks_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.count_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.count_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.count_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.count_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.count_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.count_total: 0
  publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.ops_total: 0
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.context: full ordered-root group publish
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.status: ineligible
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.candidate: false
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.eligible: false
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.used: false
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.fallback_reason: route_ineligible
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.fallback_class: route
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.admission_policy: auto
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.admission_admitted: true
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.admission_reason: auto_admitted_hardware_aware
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.selected_workers: 6
  publish.ordered_root_delta_group.span_native.triage.grouped_publish.detail: grouped full-root publish is not a span-native delta route
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.observations_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.candidate_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.eligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.used_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.ineligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallbacks_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.count_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.count_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.count_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.count_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.count_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.count_total: 0
  publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.ops_total: 0
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.context: ordered-root delta group with system delta builder
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.status: eligible
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.candidate: true
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.eligible: true
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.used: false
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.fallback_reason: 
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.fallback_class: none
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.admission_policy: auto
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.admission_admitted: true
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.admission_reason: auto_admitted_hardware_aware
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.selected_workers: 6
  publish.ordered_root_delta_group.span_native.triage.system_delta_builder_publish.detail: warm ordered-root system delta groups can use span-native apply when admitted; unsupported rows fail closed with route-specific fallback reasons
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.observations_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.candidate_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.eligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.used_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.ineligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallbacks_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.count_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.count_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.count_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.count_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.count_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.count_total: 0
  publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.ops_total: 0
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.context: command-WAL covered ordered-root delta publish
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.status: eligible
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.candidate: true
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.eligible: true
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.used: false
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.fallback_reason: 
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.fallback_class: none
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.admission_policy: auto
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.admission_admitted: true
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.admission_reason: auto_admitted_hardware_aware
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.selected_workers: 6
  publish.ordered_root_delta_group.span_native.triage.command_wal_publish.detail: command-WAL ordered-root deltas can use span-native apply after the command frame is appended and before the covered commit finalizes
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.observations_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.candidate_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.eligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.used_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.ineligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallbacks_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.count_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.count_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.count_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.count_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.count_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.count_total: 0
  publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.ops_total: 0
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.context: collection buffered root delta publish
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.status: eligible
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.candidate: true
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.eligible: true
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.used: false
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.fallback_reason: 
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.fallback_class: none
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.admission_policy: auto
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.admission_admitted: true
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.admission_reason: auto_admitted_hardware_aware
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.selected_workers: 6
  publish.ordered_root_delta_group.span_native.triage.collection_buffered_roots.detail: collection buffered roots publish through ordered-root delta routes and inherit the ordered-root span-native correctness contract
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.observations_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.candidate_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.eligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.used_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.ineligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallbacks_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.count_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.count_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.count_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.count_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.count_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.count_total: 0
  publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.ops_total: 0
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.context: overlay zero-base cold-build publish
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.status: ineligible
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.candidate: false
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.eligible: false
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.used: false
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.fallback_reason: cold_build
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.fallback_class: route
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.admission_policy: auto
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.admission_admitted: true
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.admission_reason: auto_admitted_hardware_aware
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.selected_workers: 6
  publish.ordered_root_delta_group.span_native.triage.overlay_cold_build.detail: zero-base overlay/cold-build routes do not have existing leaf spans to replace
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.observations_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.candidate_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.eligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.used_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.ineligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallbacks_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.count_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.count_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.count_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.count_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.count_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.count_total: 0
  publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.ops_total: 0
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.context: multi-index ordered-root group publish
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.status: eligible
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.candidate: true
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.eligible: true
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.used: false
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.fallback_reason: 
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.fallback_class: none
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.admission_policy: auto
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.admission_admitted: true
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.admission_reason: auto_admitted_hardware_aware
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.selected_workers: 6
  publish.ordered_root_delta_group.span_native.triage.multi_index_group_publish.detail: multi-index warm ordered-root groups can use span-native apply when admitted; cold and maintenance rows remain deterministic fallbacks
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.observations_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.candidate_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.eligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.used_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.ineligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallbacks_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.count_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.count_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.count_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.count_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.count_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.count_total: 0
  publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.ops_total: 0
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.context: ordered-root delta batch root apply
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.status: eligible
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.candidate: true
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.eligible: true
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.used: false
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.fallback_reason: 
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.fallback_class: none
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.admission_policy: auto
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.admission_admitted: true
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.admission_reason: auto_admitted_hardware_aware
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.selected_workers: 6
  publish.ordered_root_delta_group.span_native.triage.delta_batch_publish.detail: warm ordered-root delta batches are the runtime span-native candidate surface
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.observations_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.candidate_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.eligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.used_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.ineligible_ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallbacks_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.count_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.count_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.count_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.count_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.count_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.ops_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.count_total: 0
  publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.ops_total: 0
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.context: ordered-root read-only prepare proof
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.status: eligible
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.candidate: true
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.eligible: true
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.used: false
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.fallback_reason: 
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.fallback_class: none
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.admission_policy: auto
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.admission_admitted: true
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.admission_reason: auto_admitted_hardware_aware
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.selected_workers: 6
  publish.ordered_root_delta_group.span_native.triage.read_only_prepare.detail: read-only prepare validates leaf-span planning for admitted ordered-root span-native apply
```
