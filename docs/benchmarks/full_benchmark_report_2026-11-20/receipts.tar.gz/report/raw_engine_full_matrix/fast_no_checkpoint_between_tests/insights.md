# Bench Profile Insights

- generated: `2026-11-20T18:08:43Z`
- profiles dir: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests`
- binary: `./bin/unified-bench`
- ops source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/benchprof_results.json`

## Scan Ops/Sec

| Label | Full Scan | Prefix Scan | Prefix / Full |
|---|---:|---:|---:|
| TreeDB | 2,592,985 | 3,963,341 | 1.53x |

## CPU Hotspots

### batch_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_batch_delete_treedb.pprof`
- total samples: `160ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 40ms | 25.00% | 90ms | 56.25% | `runtime.scanObject` |
| 30ms | 18.75% | 50ms | 31.25% | `runtime.tryDeferToSpanScan` |
| 20ms | 12.50% | 20ms | 12.50% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 10ms | 6.25% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).cloneKey` |
| 10ms | 6.25% | 20ms | 12.50% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.(*gcBitsArena).tryAlloc (inline)` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.futex` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.heapArenaOf (inline)` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.spanClass.noscan (inline)` |
| 10ms | 6.25% | 10ms | 6.25% | `sync/atomic.(*Int32).Add (inline)` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Delete` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).DeleteWithRevision` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 0 | 0.00% | 30ms | 18.75% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Delete` |
| 0 | 0.00% | 60ms | 37.50% | `main.main` |
| 0 | 0.00% | 60ms | 37.50% | `main.runBenchmark` |
| 0 | 0.00% | 40ms | 25.00% | `main.runBenchmark.func26` |
| 0 | 0.00% | 10ms | 6.25% | `main.writeAllocsSnapshot` |

### batch_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_batch_random_treedb.pprof`
- total samples: `140ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 21.43% | 40ms | 28.57% | `runtime.tryDeferToSpanScan` |
| 30ms | 21.43% | 30ms | 21.43% | `runtime.typePointers.next` |
| 10ms | 7.14% | 10ms | 7.14% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).noteEntryAppend` |
| 10ms | 7.14% | 10ms | 7.14% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWriteKey` |
| 10ms | 7.14% | 10ms | 7.14% | `internal/runtime/maps.(*table).uncheckedPutSlot` |
| 10ms | 7.14% | 10ms | 7.14% | `runtime.cheaprandn (inline)` |
| 10ms | 7.14% | 10ms | 7.14% | `runtime.memmove` |
| 10ms | 7.14% | 10ms | 7.14% | `runtime.spanClass.sizeclass (inline)` |
| 10ms | 7.14% | 10ms | 7.14% | `runtime.step` |
| 10ms | 7.14% | 10ms | 7.14% | `sync/atomic.(*Int32).Add (inline)` |
| 0 | 0.00% | 10ms | 7.14% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Set` |
| 0 | 0.00% | 10ms | 7.14% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetWithRevision (inline)` |
| 0 | 0.00% | 50ms | 35.71% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 10ms | 7.14% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setWithMVCCInput` |
| 0 | 0.00% | 50ms | 35.71% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 50ms | 35.71% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 50ms | 35.71% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 30ms | 21.43% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchSet` |
| 0 | 0.00% | 10ms | 7.14% | `github.com/snissn/gomap/TreeDB/caching.reserveAppendOnlyMemtableEntries` |
| 0 | 0.00% | 10ms | 7.14% | `github.com/snissn/gomap/TreeDB/caching.reserveMemtableEntries` |
| 0 | 0.00% | 10ms | 7.14% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ReserveAdditionalEntries` |
| 0 | 0.00% | 30ms | 21.43% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 20ms | 14.29% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 10ms | 7.14% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).growEntriesLocked` |
| 0 | 0.00% | 10ms | 7.14% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).reserveAdditionalEntriesLocked` |

### batch_small_seq (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_batch_small_seq_treedb.pprof`
- total samples: `260ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 50ms | 19.23% | 90ms | 34.62% | `runtime.scanObject` |
| 40ms | 15.38% | 40ms | 15.38% | `runtime.memclrNoHeapPointers` |
| 20ms | 7.69% | 20ms | 7.69% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 20ms | 7.69% | 20ms | 7.69% | `runtime.futex` |
| 20ms | 7.69% | 20ms | 7.69% | `runtime.memmove` |
| 20ms | 7.69% | 20ms | 7.69% | `runtime.tryDeferToSpanScan` |
| 10ms | 3.85% | 10ms | 3.85% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 10ms | 3.85% | 10ms | 3.85% | `internal/runtime/atomic.(*UnsafePointer).Load` |
| 10ms | 3.85% | 10ms | 3.85% | `internal/runtime/maps.h1 (inline)` |
| 10ms | 3.85% | 10ms | 3.85% | `internal/runtime/syscall/linux.Syscall6` |
| 10ms | 3.85% | 10ms | 3.85% | `internal/sync.(*Mutex).Lock (inline)` |
| 10ms | 3.85% | 40ms | 15.38% | `runtime.mapassign_fast64` |
| 10ms | 3.85% | 20ms | 7.69% | `runtime.typePointers.next` |
| 10ms | 3.85% | 10ms | 3.85% | `runtime.typePointers.nextFast (inline)` |
| 10ms | 3.85% | 10ms | 3.85% | `sync/atomic.(*Int32).Add (inline)` |
| 0 | 0.00% | 40ms | 15.38% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Close` |
| 0 | 0.00% | 10ms | 3.85% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Set` |
| 0 | 0.00% | 10ms | 3.85% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetWithRevision (inline)` |
| 0 | 0.00% | 80ms | 30.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 10ms | 3.85% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).cloneKeyValue` |
| 0 | 0.00% | 10ms | 3.85% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setWithMVCCInput` |
| 0 | 0.00% | 80ms | 30.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).tryApplySmallSelectedSortedShard` |
| 0 | 0.00% | 80ms | 30.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 80ms | 30.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 80ms | 30.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |

### batch_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_batch_write_treedb.pprof`
- total samples: `190ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 60ms | 31.58% | 140ms | 73.68% | `runtime.scanObject` |
| 30ms | 15.79% | 30ms | 15.79% | `runtime.tryDeferToSpanScan` |
| 30ms | 15.79% | 30ms | 15.79% | `runtime.typePointers.next` |
| 20ms | 10.53% | 20ms | 10.53% | `runtime.spanOf (inline)` |
| 10ms | 5.26% | 40ms | 21.05% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ApplyCopySortedBatchWithValueCopierTrusted` |
| 10ms | 5.26% | 10ms | 5.26% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 10ms | 5.26% | 10ms | 5.26% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 10ms | 5.26% | 10ms | 5.26% | `runtime.(*sweepClass).update (inline)` |
| 10ms | 5.26% | 20ms | 10.53% | `runtime.mapassign_fast64` |
| 0 | 0.00% | 40ms | 21.05% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 40ms | 21.05% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 40ms | 21.05% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 40ms | 21.05% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 30ms | 15.79% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 20ms | 10.53% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 0 | 0.00% | 40ms | 21.05% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 50ms | 26.32% | `main.main` |
| 0 | 0.00% | 50ms | 26.32% | `main.runBenchmark` |
| 0 | 0.00% | 40ms | 21.05% | `main.runBenchmark.func23` |
| 0 | 0.00% | 40ms | 21.05% | `main.runBenchmark.func6` |
| 0 | 0.00% | 10ms | 5.26% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 10ms | 5.26% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 10ms | 5.26% | `runtime.(*mheap).nextSpanForSweep` |
| 0 | 0.00% | 10ms | 5.26% | `runtime.GC` |
| 0 | 0.00% | 20ms | 10.53% | `runtime.findObject` |

### batch_write_steady (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_batch_write_steady_treedb.pprof`
- total samples: `920ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 250ms | 27.17% | 250ms | 27.17% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 80ms | 8.70% | 80ms | 8.70% | `runtime.memmove` |
| 40ms | 4.35% | 40ms | 4.35% | `cmpbody` |
| 40ms | 4.35% | 40ms | 4.35% | `internal/runtime/syscall/linux.Syscall6` |
| 30ms | 3.26% | 80ms | 8.70% | `sort.partition_func` |
| 20ms | 2.17% | 50ms | 5.43% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked.func1` |
| 20ms | 2.17% | 20ms | 2.17% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).entryAt` |
| 20ms | 2.17% | 20ms | 2.17% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafValueViewColumnarPrefixV2` |
| 20ms | 2.17% | 30ms | 3.26% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).applySpanNativeWithPrepared` |
| 20ms | 2.17% | 20ms | 2.17% | `runtime.step` |
| 10ms | 1.09% | 10ms | 1.09% | `encoding/binary.littleEndian.Uint64 (inline)` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/cespare/xxhash/v2.Sum64` |
| 10ms | 1.09% | 40ms | 4.35% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).put (inline)` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/pierrec/lz4/v4/internal/lz4block.blockHash (inline)` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).PointRevisionStats` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).setViewWithMVCCInput` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setViewValidatedWithMVCCInput` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).pop` |
| 10ms | 1.09% | 50ms | 5.43% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).push` |
| 10ms | 1.09% | 40ms | 4.35% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).up` |
| 10ms | 1.09% | 20ms | 2.17% | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Less` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Swap (inline)` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB/db.(*DB).observeRawSpanNativeObservation` |

### dataset_write_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_dataset_write_random_treedb.pprof`
- total samples: `170ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 20ms | 11.76% | 20ms | 11.76% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 20ms | 11.76% | 20ms | 11.76% | `internal/sync.(*Mutex).Lock (inline)` |
| 20ms | 11.76% | 30ms | 17.65% | `runtime.tryDeferToSpanScan` |
| 20ms | 11.76% | 20ms | 11.76% | `sync/atomic.(*Int32).Add (inline)` |
| 10ms | 5.88% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 10ms | 5.88% | 10ms | 5.88% | `internal/runtime/atomic.(*Uint32).CompareAndSwap` |
| 10ms | 5.88% | 10ms | 5.88% | `internal/runtime/maps.(*Iter).Next` |
| 10ms | 5.88% | 10ms | 5.88% | `internal/runtime/maps.(*ctrlGroup).setEmpty (inline)` |
| 10ms | 5.88% | 10ms | 5.88% | `internal/sync.(*Mutex).Unlock (inline)` |
| 10ms | 5.88% | 10ms | 5.88% | `runtime.heapArenaOf (inline)` |
| 10ms | 5.88% | 40ms | 23.53% | `runtime.scanObject` |
| 10ms | 5.88% | 20ms | 11.76% | `sync.(*RWMutex).RLock (inline)` |
| 10ms | 5.88% | 10ms | 5.88% | `sync/atomic.(*Uint64).Add (inline)` |
| 0 | 0.00% | 110ms | 64.71% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 110ms | 64.71% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 110ms | 64.71% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).beginDirectWrite` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionMode (inline)` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCommandPublish (inline)` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).nextEntryRevision (inline)` |

### dataset_write_sorted (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_dataset_write_sorted_treedb.pprof`
- total samples: `350ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 60ms | 17.14% | 60ms | 17.14% | `runtime.tryDeferToSpanScan` |
| 50ms | 14.29% | 50ms | 14.29% | `runtime.memclrNoHeapPointers` |
| 30ms | 8.57% | 150ms | 42.86% | `runtime.scanObject` |
| 20ms | 5.71% | 20ms | 5.71% | `github.com/cespare/xxhash/v2.Sum64` |
| 20ms | 5.71% | 20ms | 5.71% | `internal/sync.(*Mutex).Unlock (inline)` |
| 20ms | 5.71% | 20ms | 5.71% | `runtime.(*activeSweep).end` |
| 20ms | 5.71% | 20ms | 5.71% | `runtime.typePointers.next` |
| 10ms | 2.86% | 10ms | 2.86% | `github.com/snissn/gomap/TreeDB/caching.(*DB).beginMVCCInputCut (inline)` |
| 10ms | 2.86% | 10ms | 2.86% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 10ms | 2.86% | 10ms | 2.86% | `github.com/snissn/gomap/TreeDB/internal/mvccadmission.(*Cut).Observe` |
| 10ms | 2.86% | 10ms | 2.86% | `internal/runtime/atomic.(*Uint64).CompareAndSwap` |
| 10ms | 2.86% | 10ms | 2.86% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 10ms | 2.86% | 10ms | 2.86% | `internal/sync.(*Mutex).Lock (inline)` |
| 10ms | 2.86% | 20ms | 5.71% | `runtime.findObject` |
| 10ms | 2.86% | 10ms | 2.86% | `runtime.markBits.isMarked (inline)` |
| 10ms | 2.86% | 10ms | 2.86% | `runtime.spanOf (inline)` |
| 10ms | 2.86% | 10ms | 2.86% | `runtime.typePointers.nextFast (inline)` |
| 10ms | 2.86% | 10ms | 2.86% | `sync/atomic.(*Int32).Add (inline)` |
| 10ms | 2.86% | 10ms | 2.86% | `time.now` |
| 10ms | 2.86% | 10ms | 2.86% | `time.runtimeNow` |
| 0 | 0.00% | 110ms | 31.43% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 10ms | 2.86% | `github.com/snissn/gomap/TreeDB.(*DB).beginPublicOperation` |
| 0 | 0.00% | 110ms | 31.43% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 100ms | 28.57% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 50ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).finishFlushedCanonicalUnits` |

### full_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_full_scan_treedb.pprof`
- total samples: `520ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 170ms | 32.69% | 170ms | 32.69% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 80ms | 15.38% | 130ms | 25.00% | `runtime.scanObject` |
| 30ms | 5.77% | 30ms | 5.77% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 30ms | 5.77% | 30ms | 5.77% | `internal/runtime/syscall/linux.Syscall6` |
| 20ms | 3.85% | 30ms | 5.77% | `runtime.tryDeferToSpanScan` |
| 10ms | 1.92% | 10ms | 1.92% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL256` |
| 10ms | 1.92% | 30ms | 5.77% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).UnsafeValue` |
| 10ms | 1.92% | 20ms | 3.85% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithCOWPolicy` |
| 10ms | 1.92% | 10ms | 1.92% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2EnsureMeta` |
| 10ms | 1.92% | 10ms | 1.92% | `github.com/snissn/gomap/TreeDB/node.(*Node).rawFlags (inline)` |
| 10ms | 1.92% | 10ms | 1.92% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).getLeafKeyFlags` |
| 10ms | 1.92% | 320ms | 61.54% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).stepForward` |
| 10ms | 1.92% | 10ms | 1.92% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).shouldVerifyLeafRefChecksum` |
| 10ms | 1.92% | 10ms | 1.92% | `internal/poll.(*FD).decref` |
| 10ms | 1.92% | 10ms | 1.92% | `internal/runtime/atomic.(*Uint32).CompareAndSwap` |
| 10ms | 1.92% | 370ms | 71.15% | `main.runBenchmark.func37` |
| 10ms | 1.92% | 60ms | 11.54% | `os.(*File).pread (inline)` |
| 10ms | 1.92% | 10ms | 1.92% | `runtime.memmove` |
| 10ms | 1.92% | 10ms | 1.92% | `runtime.spanClass.sizeclass (inline)` |
| 10ms | 1.92% | 10ms | 1.92% | `runtime.step` |
| 10ms | 1.92% | 10ms | 1.92% | `runtime.traceLocker.GoSysCall` |
| 10ms | 1.92% | 10ms | 1.92% | `runtime.typePointers.next` |
| 10ms | 1.92% | 10ms | 1.92% | `runtime.typePointers.nextFast (inline)` |
| 10ms | 1.92% | 10ms | 1.92% | `sync/atomic.(*Uint64).CompareAndSwap (inline)` |
| 0 | 0.00% | 170ms | 32.69% | `github.com/pierrec/lz4/v4.UncompressBlock (inline)` |

### prefix_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_prefix_scan_treedb.pprof`
- total samples: `200ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 100ms | 50.00% | 170ms | 85.00% | `runtime.scanObject` |
| 30ms | 15.00% | 30ms | 15.00% | `runtime.typePointers.next` |
| 20ms | 10.00% | 30ms | 15.00% | `runtime.tryDeferToSpanScan` |
| 10ms | 5.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithCOWPolicy` |
| 10ms | 5.00% | 10ms | 5.00% | `internal/runtime/atomic.(*Uint32).Add (inline)` |
| 10ms | 5.00% | 10ms | 5.00% | `runtime.pcvalue` |
| 10ms | 5.00% | 10ms | 5.00% | `runtime.spanClass.sizeclass (inline)` |
| 10ms | 5.00% | 10ms | 5.00% | `runtime.typePointers.nextFast (inline)` |
| 0 | 0.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 0 | 0.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithRecordPolicy` |
| 0 | 0.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithState (inline)` |
| 0 | 0.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).Next` |
| 0 | 0.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadCurrent` |
| 0 | 0.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadNodeRef` |
| 0 | 0.00% | 10ms | 5.00% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).stepForward` |
| 0 | 0.00% | 20ms | 10.00% | `main.main` |
| 0 | 0.00% | 20ms | 10.00% | `main.runBenchmark` |
| 0 | 0.00% | 10ms | 5.00% | `main.runBenchmark.func39` |
| 0 | 0.00% | 10ms | 5.00% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 10ms | 5.00% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 10ms | 5.00% | `runtime.(*Frames).Next` |
| 0 | 0.00% | 10ms | 5.00% | `runtime.(*inlineUnwinder).resolveInternal (inline)` |
| 0 | 0.00% | 10ms | 5.00% | `runtime.(*mheap).nextSpanForSweep` |
| 0 | 0.00% | 10ms | 5.00% | `runtime.(*spanSet).pop` |

### random_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_random_delete_treedb.pprof`
- total samples: `210ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 50ms | 23.81% | 110ms | 52.38% | `runtime.scanObject` |
| 30ms | 14.29% | 30ms | 14.29% | `runtime.typePointers.next` |
| 20ms | 9.52% | 20ms | 9.52% | `runtime.tryDeferToSpanScan` |
| 10ms | 4.76% | 10ms | 4.76% | `github.com/cespare/xxhash/v2.Sum64` |
| 10ms | 4.76% | 10ms | 4.76% | `internal/runtime/atomic.(*Uint32).CompareAndSwap` |
| 10ms | 4.76% | 10ms | 4.76% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 10ms | 4.76% | 10ms | 4.76% | `internal/runtime/maps.h1 (inline)` |
| 10ms | 4.76% | 10ms | 4.76% | `internal/sync.(*Mutex).Lock (inline)` |
| 10ms | 4.76% | 10ms | 4.76% | `runtime.futex` |
| 10ms | 4.76% | 30ms | 14.29% | `runtime.mapassign_fast64` |
| 10ms | 4.76% | 10ms | 4.76% | `runtime.memmove` |
| 10ms | 4.76% | 10ms | 4.76% | `runtime.typePointers.nextFast (inline)` |
| 10ms | 4.76% | 10ms | 4.76% | `sync/atomic.(*Int32).Add (inline)` |
| 10ms | 4.76% | 10ms | 4.76% | `time.runtimeNow` |
| 0 | 0.00% | 80ms | 38.10% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 80ms | 38.10% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Delete` |
| 0 | 0.00% | 80ms | 38.10% | `github.com/snissn/gomap/TreeDB/caching.(*DB).delete` |
| 0 | 0.00% | 80ms | 38.10% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirect` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWrite` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).shardForKey` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).shardIndex (inline)` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/caching.hashKey` |
| 0 | 0.00% | 50ms | 23.81% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 50ms | 23.81% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 10ms | 4.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |

### random_read (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_random_read_treedb.pprof`
- total samples: `270ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 70ms | 25.93% | 130ms | 48.15% | `runtime.scanObject` |
| 30ms | 11.11% | 40ms | 14.81% | `runtime.typePointers.next` |
| 20ms | 7.41% | 20ms | 7.41% | `runtime.typePointers.nextFast (inline)` |
| 10ms | 3.70% | 10ms | 3.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteMemtableViewRelease (inline)` |
| 10ms | 3.70% | 10ms | 3.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).registerMemtableViewReader` |
| 10ms | 3.70% | 20ms | 7.41% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).lookupEntryLocked` |
| 10ms | 3.70% | 10ms | 3.70% | `internal/chacha8rand.block` |
| 10ms | 3.70% | 10ms | 3.70% | `internal/runtime/maps.(*table).uncheckedPutSlot` |
| 10ms | 3.70% | 10ms | 3.70% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 10ms | 3.70% | 10ms | 3.70% | `internal/sync.(*Mutex).Lock (inline)` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.(*_panic).start` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.(*sweepLocked).sweep` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.findObject` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.heapArenaOf (inline)` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.memmove` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.nanotime` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.typedslicecopy` |
| 10ms | 3.70% | 10ms | 3.70% | `sync/atomic.(*Int64).Add (inline)` |
| 0 | 0.00% | 100ms | 37.04% | `github.com/snissn/gomap/TreeDB.(*DB).GetAppend` |
| 0 | 0.00% | 100ms | 37.04% | `github.com/snissn/gomap/TreeDB/caching.(*DB).GetAppend` |
| 0 | 0.00% | 100ms | 37.04% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getMemtableAppend` |
| 0 | 0.00% | 50ms | 18.52% | `github.com/snissn/gomap/TreeDB/caching.(*DB).releaseMemtableView` |
| 0 | 0.00% | 50ms | 18.52% | `github.com/snissn/gomap/TreeDB/caching.(*DB).releaseMemtableViewRef` |
| 0 | 0.00% | 10ms | 3.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).retainMemtableView` |
| 0 | 0.00% | 40ms | 14.81% | `github.com/snissn/gomap/TreeDB/caching.(*DB).unregisterMemtableViewReader` |

### random_read_batch (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_random_read_batch_treedb.pprof`
- total samples: `520ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 70ms | 13.46% | 70ms | 13.46% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 70ms | 13.46% | 130ms | 25.00% | `runtime.scanObject` |
| 40ms | 7.69% | 40ms | 7.69% | `internal/runtime/syscall/linux.Syscall6` |
| 20ms | 3.85% | 30ms | 5.77% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).takeDecodeScratch` |
| 20ms | 3.85% | 40ms | 7.69% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` |
| 20ms | 3.85% | 20ms | 3.85% | `github.com/snissn/gomap/TreeDB/node.getUint64BEAt (inline)` |
| 20ms | 3.85% | 20ms | 3.85% | `runtime.step` |
| 20ms | 3.85% | 30ms | 5.77% | `runtime.tryDeferToSpanScan` |
| 20ms | 3.85% | 30ms | 5.77% | `runtime.typePointers.next` |
| 10ms | 1.92% | 10ms | 1.92% | `cmpbody` |
| 10ms | 1.92% | 10ms | 1.92% | `encoding/binary.bigEndian.Uint64` |
| 10ms | 1.92% | 10ms | 1.92% | `encoding/binary.littleEndian.Uint16` |
| 10ms | 1.92% | 20ms | 3.85% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getViewLockedWithState` |
| 10ms | 1.92% | 10ms | 1.92% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).recordStore` |
| 10ms | 1.92% | 10ms | 1.92% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeIntoBackingLocked` |
| 10ms | 1.92% | 10ms | 1.92% | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView (inline)` |
| 10ms | 1.92% | 270ms | 51.92% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).loadLeafNodeForGetMany` |
| 10ms | 1.92% | 10ms | 1.92% | `github.com/snissn/gomap/TreeDB/tree.outerLeafRecentRingContains (inline)` |
| 10ms | 1.92% | 10ms | 1.92% | `hash/crc32.slicingUpdate` |
| 10ms | 1.92% | 10ms | 1.92% | `internal/runtime/atomic.(*Uint32).CompareAndSwap` |
| 10ms | 1.92% | 10ms | 1.92% | `internal/runtime/atomic.(*UnsafePointer).Load` |
| 10ms | 1.92% | 10ms | 1.92% | `internal/sync.(*Mutex).Lock (inline)` |
| 10ms | 1.92% | 10ms | 1.92% | `runtime.empty` |
| 10ms | 1.92% | 10ms | 1.92% | `runtime.fpTracebackPCs (inline)` |
| 10ms | 1.92% | 10ms | 1.92% | `runtime.funcdata (inline)` |

### random_read_parallel (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_random_read_parallel_treedb.pprof`
- total samples: `1.16s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.28s | 24.14% | 0.28s | 24.14% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` |
| 0.14s | 12.07% | 0.14s | 12.07% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 0.10s | 8.62% | 0.27s | 23.28% | `runtime.mapaccess2_fast64` |
| 0.07s | 6.03% | 0.13s | 11.21% | `runtime.scanObject` |
| 0.06s | 5.17% | 0.06s | 5.17% | `runtime.memmove` |
| 0.05s | 4.31% | 0.06s | 5.17% | `runtime.tryDeferToSpanScan` |
| 0.04s | 3.45% | 0.04s | 3.45% | `github.com/cespare/xxhash/v2.Sum64` |
| 0.04s | 3.45% | 0.63s | 54.31% | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).lookupCachedRootDomainEntryWithRevision` |
| 0.03s | 2.59% | 0.53s | 45.69% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).getEntryFrozen` |
| 0.03s | 2.59% | 0.04s | 3.45% | `math/rand.(*Rand).Int31n` |
| 0.03s | 2.59% | 0.03s | 2.59% | `sync/atomic.(*Bool).Load (inline)` |
| 0.03s | 2.59% | 0.03s | 2.59% | `sync/atomic.(*Uint64).Add (inline)` |
| 0.02s | 1.72% | 0.81s | 69.83% | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).GetAppend` |
| 0.02s | 1.72% | 0.02s | 1.72% | `internal/runtime/maps.h1 (inline)` |
| 0.02s | 1.72% | 0.03s | 2.59% | `runtime.(*_panic).nextDefer` |
| 0.02s | 1.72% | 0.02s | 1.72% | `sort.order2_func` |
| 0.02s | 1.72% | 0.02s | 1.72% | `sync/atomic.(*Uint64).CompareAndSwap (inline)` |
| 0.01s | 0.86% | 0.01s | 0.86% | `bytes.Equal (inline)` |
| 0.01s | 0.86% | 0.01s | 0.86% | `cmpbody` |
| 0.01s | 0.86% | 0.04s | 3.45% | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).endRead` |
| 0.01s | 0.86% | 0.54s | 46.55% | `github.com/snissn/gomap/TreeDB/caching.memtableEntryWithRevision` |
| 0.01s | 0.86% | 0.55s | 47.41% | `github.com/snissn/gomap/TreeDB/caching.rootDomainSnapshot.getEntryWithRevision (inline)` |
| 0.01s | 0.86% | 0.01s | 0.86% | `internal/runtime/maps.(*groupsReference).group` |
| 0.01s | 0.86% | 0.89s | 76.72% | `main.runBenchmark.func33.1` |
| 0.01s | 0.86% | 0.01s | 0.86% | `math/rand.(*Rand).Int63 (inline)` |

### random_read_parallel_acquire_snapshot (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `14.03s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2.24s | 15.97% | 2.24s | 15.97% | `runtime.procyieldAsm` |
| 1.23s | 8.77% | 1.24s | 8.84% | `sync/atomic.(*Int32).Add (inline)` |
| 1.12s | 7.98% | 1.13s | 8.05% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.65s | 4.63% | 3.46s | 24.66% | `internal/sync.(*Mutex).Lock (inline)` |
| 0.53s | 3.78% | 0.53s | 3.78% | `internal/runtime/syscall/linux.Syscall6` |
| 0.48s | 3.42% | 2.81s | 20.03% | `internal/sync.(*Mutex).lockSlow` |
| 0.27s | 1.92% | 0.40s | 2.85% | `internal/sync.(*Mutex).Unlock (inline)` |
| 0.24s | 1.71% | 0.24s | 1.71% | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView (inline)` |
| 0.23s | 1.64% | 4.28s | 30.51% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView` |
| 0.23s | 1.64% | 0.45s | 3.21% | `runtime.scanObject` |
| 0.19s | 1.35% | 1.25s | 8.91% | `github.com/snissn/gomap/TreeDB/caching.memtableViewAllowsBackendSnapshotFastPath` |
| 0.18s | 1.28% | 0.18s | 1.28% | `runtime.heapSetTypeSmallHeader (inline)` |
| 0.17s | 1.21% | 0.29s | 2.07% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` |
| 0.17s | 1.21% | 0.34s | 2.42% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` |
| 0.17s | 1.21% | 12.21s | 87.03% | `main.runBenchmark.func34.1` |
| 0.17s | 1.21% | 0.17s | 1.21% | `sync/atomic.(*Int64).Add (inline)` |
| 0.16s | 1.14% | 0.16s | 1.14% | `cmpbody` |
| 0.16s | 1.14% | 2.94s | 20.96% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0.16s | 1.14% | 0.16s | 1.14% | `time.runtimeNow` |
| 0.15s | 1.07% | 0.15s | 1.07% | `runtime.memmove` |
| 0.14s | 1.00% | 0.32s | 2.28% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getViewLockedWithState` |
| 0.13s | 0.93% | 0.19s | 1.35% | `sync.(*RWMutex).TryRLock (inline)` |
| 0.12s | 0.86% | 0.12s | 0.86% | `encoding/binary.bigEndian.Uint64 (inline)` |
| 0.12s | 0.86% | 0.12s | 0.86% | `runtime.nanotime (inline)` |
| 0.12s | 0.86% | 0.12s | 0.86% | `sync/atomic.(*Int32).CompareAndSwap (inline)` |

### random_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_random_write_treedb.pprof`
- total samples: `170ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 17.65% | 40ms | 23.53% | `runtime.tryDeferToSpanScan` |
| 10ms | 5.88% | 20ms | 11.76% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 10ms | 5.88% | 10ms | 5.88% | `internal/runtime/maps.(*Map).directoryIndex (inline)` |
| 10ms | 5.88% | 10ms | 5.88% | `internal/runtime/maps.(*ctrlGroup).setEmpty (inline)` |
| 10ms | 5.88% | 10ms | 5.88% | `internal/sync.(*Mutex).Unlock (inline)` |
| 10ms | 5.88% | 10ms | 5.88% | `runtime.(*memRecordCycle).add` |
| 10ms | 5.88% | 10ms | 5.88% | `runtime.heapArenaOf (inline)` |
| 10ms | 5.88% | 50ms | 29.41% | `runtime.mapassign_fast64` |
| 10ms | 5.88% | 10ms | 5.88% | `runtime.memhash64` |
| 10ms | 5.88% | 10ms | 5.88% | `runtime.memmove` |
| 10ms | 5.88% | 10ms | 5.88% | `runtime.procyieldAsm` |
| 10ms | 5.88% | 50ms | 29.41% | `runtime.scanObject` |
| 10ms | 5.88% | 10ms | 5.88% | `runtime.step` |
| 10ms | 5.88% | 10ms | 5.88% | `sync/atomic.(*Int32).Add (inline)` |
| 10ms | 5.88% | 10ms | 5.88% | `time.runtimeNow` |
| 0 | 0.00% | 100ms | 58.82% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 100ms | 58.82% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 100ms | 58.82% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWrite` |
| 0 | 0.00% | 100ms | 58.82% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 100ms | 58.82% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 80ms | 47.06% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 80ms | 47.06% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 70ms | 41.18% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 10ms | 5.88% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).growEntriesLocked` |

### sequential_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/cpu_sequential_write_treedb.pprof`
- total samples: `140ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 21.43% | 30ms | 21.43% | `runtime.tryDeferToSpanScan` |
| 20ms | 14.29% | 70ms | 50.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 20ms | 14.29% | 20ms | 14.29% | `internal/sync.(*Mutex).Lock (inline)` |
| 10ms | 7.14% | 10ms | 7.14% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 10ms | 7.14% | 10ms | 7.14% | `internal/runtime/atomic.(*Uintptr).Load (inline)` |
| 10ms | 7.14% | 10ms | 7.14% | `internal/sync.(*Mutex).Unlock (inline)` |
| 10ms | 7.14% | 10ms | 7.14% | `runtime.memmove` |
| 10ms | 7.14% | 40ms | 28.57% | `runtime.scanObject` |
| 10ms | 7.14% | 10ms | 7.14% | `sort.partition` |
| 10ms | 7.14% | 10ms | 7.14% | `time.runtimeNow` |
| 0 | 0.00% | 10ms | 7.14% | `compress/flate.(*Writer).Close (inline)` |
| 0 | 0.00% | 10ms | 7.14% | `compress/flate.(*byFreq).sort (inline)` |
| 0 | 0.00% | 10ms | 7.14% | `compress/flate.(*compressor).close` |
| 0 | 0.00% | 10ms | 7.14% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 10ms | 7.14% | `compress/flate.(*huffmanBitWriter).indexTokens` |
| 0 | 0.00% | 10ms | 7.14% | `compress/flate.(*huffmanBitWriter).writeBlockDynamic` |
| 0 | 0.00% | 10ms | 7.14% | `compress/flate.(*huffmanEncoder).generate` |
| 0 | 0.00% | 10ms | 7.14% | `compress/gzip.(*Writer).Close` |
| 0 | 0.00% | 70ms | 50.00% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 70ms | 50.00% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 70ms | 50.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 20ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 20ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 20ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 20ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4` |

## Allocation Hotspots

### batch_delete (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_batch_delete_treedb.pprof`
- total: `4264`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2185 | 51.24% | 2185 | 51.24% | `runtime/pprof.allFrames` |
| 1024 | 24.02% | 1024 | 24.02% | `runtime/pprof.(*protobuf).varint (inline)` |
| 535 | 12.55% | 535 | 12.55% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 462 | 10.83% | 462 | 10.83% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 32 | 0.75% | 32 | 0.75% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 1 | 0.02% | 470 | 11.02% | `main.runBenchmark.func26` |
| 0 | 0.00% | 466 | 10.93% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 466 | 10.93% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 466 | 10.93% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 466 | 10.93% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 462 | 10.83% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 462 | 10.83% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 462 | 10.83% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 466 | 10.93% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 4259 | 99.88% | `main.main` |
| 0 | 0.00% | 4259 | 99.88% | `main.runBenchmark` |
| 0 | 0.00% | 1056 | 24.77% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 1056 | 24.77% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 2733 | 64.09% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 2733 | 64.09% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 4259 | 99.88% | `runtime.main` |
| 0 | 0.00% | 3789 | 88.86% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 3757 | 88.11% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |

### batch_delete (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_batch_delete_treedb.pprof`
- total: `30194.26kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 10169.74kB | 33.68% | 10169.74kB | 33.68% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 8336.84kB | 27.61% | 8336.84kB | 27.61% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 3610.34kB | 11.96% | 6009.99kB | 19.90% | `compress/flate.NewWriter (inline)` |
| 1749.02kB | 5.79% | 1749.02kB | 5.79% | `compress/flate.newDeflateFast (inline)` |
| 1644.93kB | 5.45% | 21612.11kB | 71.58% | `main.runBenchmark.func26` |
| 1460.59kB | 4.84% | 1460.59kB | 4.84% | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` |
| 1027.76kB | 3.40% | 1027.76kB | 3.40% | `runtime/pprof.(*profileBuilder).stringIndex` |
| 650.62kB | 2.15% | 2399.64kB | 7.95% | `compress/flate.(*compressor).init` |
| 520.04kB | 1.72% | 520.04kB | 1.72% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 512.25kB | 1.70% | 512.25kB | 1.70% | `runtime/pprof.(*protobuf).varint` |
| 512.12kB | 1.70% | 512.12kB | 1.70% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 6009.99kB | 19.90% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 1460.59kB | 4.84% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Delete` |
| 0 | 0.00% | 1460.59kB | 4.84% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).DeleteWithRevision` |
| 0 | 0.00% | 18506.58kB | 61.29% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 1460.59kB | 4.84% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopy` |
| 0 | 0.00% | 1460.59kB | 4.84% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopyInto` |
| 0 | 0.00% | 1460.59kB | 4.84% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).cloneKey` |
| 0 | 0.00% | 18506.58kB | 61.29% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 18506.58kB | 61.29% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 18506.58kB | 61.29% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 8336.84kB | 27.61% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 10169.74kB | 33.68% | `github.com/snissn/gomap/TreeDB/caching.reserveAppendOnlyMemtableEntries` |
| 0 | 0.00% | 10169.74kB | 33.68% | `github.com/snissn/gomap/TreeDB/caching.reserveMemtableEntries` |
| 0 | 0.00% | 10169.74kB | 33.68% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ReserveAdditionalEntries` |

### batch_random (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_batch_random_treedb.pprof`
- total: `41683`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 38242 | 91.74% | 38346 | 91.99% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 2185 | 5.24% | 40594 | 97.39% | `runtime/pprof.printCountCycleProfile` |
| 578 | 1.39% | 578 | 1.39% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 256 | 0.61% | 256 | 0.61% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 1 | 0.00% | 920 | 2.21% | `main.runBenchmark.func25` |
| 0 | 0.00% | 891 | 2.14% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 891 | 2.14% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 891 | 2.14% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 891 | 2.14% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 834 | 2.00% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchSet` |
| 0 | 0.00% | 834 | 2.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 834 | 2.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 891 | 2.14% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 41681 | 100.00% | `main.main` |
| 0 | 0.00% | 41681 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 40594 | 97.39% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 40594 | 97.39% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 41681 | 100.00% | `runtime.main` |
| 0 | 0.00% | 40761 | 97.79% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 38346 | 91.99% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 7749 | 18.59% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 32845 | 78.80% | `runtime/pprof.writeMutex` |
| 0 | 0.00% | 40594 | 97.39% | `runtime/pprof.writeProfileInternal` |

### batch_random (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_batch_random_treedb.pprof`
- total: `87.01MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 36.38MB | 41.82% | 36.38MB | 41.82% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 28.55MB | 32.81% | 28.55MB | 32.81% | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` |
| 10.18MB | 11.70% | 10.18MB | 11.70% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 3.53MB | 4.05% | 4.73MB | 5.44% | `compress/flate.NewWriter (inline)` |
| 1.61MB | 1.85% | 77.73MB | 89.34% | `main.runBenchmark.func25` |
| 1.52MB | 1.75% | 4.35MB | 5.00% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1.01MB | 1.16% | 1.01MB | 1.16% | `runtime/pprof.(*protobuf).varint (inline)` |
| 1.01MB | 1.16% | 1.51MB | 1.74% | `runtime/pprof.(*protobuf).string (inline)` |
| 0.64MB | 0.73% | 1.20MB | 1.38% | `compress/flate.(*compressor).init` |
| 0.57MB | 0.65% | 0.57MB | 0.65% | `compress/flate.newDeflateFast (inline)` |
| 0.52MB | 0.60% | 0.52MB | 0.60% | `github.com/snissn/gomap/TreeDB/caching.compactBatchMainArenaTailAliases` |
| 0.51MB | 0.58% | 0.51MB | 0.58% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 0.50MB | 0.58% | 0.50MB | 0.58% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 0.50MB | 0.57% | 4.84MB | 5.56% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 4.73MB | 5.44% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 28.55MB | 32.81% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Set` |
| 0 | 0.00% | 28.55MB | 32.81% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetWithRevision (inline)` |
| 0 | 0.00% | 47.58MB | 54.68% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 28.55MB | 32.81% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopy` |
| 0 | 0.00% | 28.55MB | 32.81% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopyInto` |
| 0 | 0.00% | 28.55MB | 32.81% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).cloneKeyValue` |
| 0 | 0.00% | 28.55MB | 32.81% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setWithMVCCInput` |
| 0 | 0.00% | 47.58MB | 54.68% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |

### batch_small_seq (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_batch_small_seq_treedb.pprof`
- total: `11500`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5922 | 51.50% | 5961 | 51.83% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 2185 | 19.00% | 2286 | 19.88% | `runtime/pprof.printCountCycleProfile` |
| 1657 | 14.41% | 1657 | 14.41% | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` |
| 1490 | 12.96% | 1490 | 12.96% | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` |
| 98 | 0.85% | 98 | 0.85% | `runtime/pprof.(*protobuf).varint (inline)` |
| 55 | 0.48% | 156 | 1.36% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 1490 | 12.96% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatch` |
| 0 | 0.00% | 1657 | 14.41% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Set` |
| 0 | 0.00% | 1657 | 14.41% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetWithRevision (inline)` |
| 0 | 0.00% | 5961 | 51.83% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 1657 | 14.41% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopy` |
| 0 | 0.00% | 1657 | 14.41% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopyInto` |
| 0 | 0.00% | 1657 | 14.41% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).cloneKeyValue` |
| 0 | 0.00% | 1657 | 14.41% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setWithMVCCInput` |
| 0 | 0.00% | 5961 | 51.83% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 5961 | 51.83% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 1490 | 12.96% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).NewBatch` |
| 0 | 0.00% | 5961 | 51.83% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 1657 | 14.41% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Set` |
| 0 | 0.00% | 11495 | 100.00% | `main.main` |
| 0 | 0.00% | 11495 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 9108 | 79.20% | `main.runBenchmark.func28` |
| 0 | 0.00% | 2286 | 19.88% | `main.writeRuntimeProfileSnapshot` |

### batch_small_seq (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_batch_small_seq_treedb.pprof`
- total: `99.26MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 60.61MB | 61.06% | 60.61MB | 61.06% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 25.90MB | 26.09% | 25.90MB | 26.09% | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` |
| 6.51MB | 6.56% | 67.63MB | 68.13% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 1.27MB | 1.28% | 1.84MB | 1.85% | `compress/flate.(*compressor).init` |
| 1MB | 1.01% | 1MB | 1.01% | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` |
| 0.88MB | 0.89% | 2.72MB | 2.74% | `compress/flate.NewWriter (inline)` |
| 0.57MB | 0.57% | 0.57MB | 0.57% | `compress/flate.newDeflateFast (inline)` |
| 0.51MB | 0.51% | 0.51MB | 0.51% | `github.com/snissn/gomap/TreeDB/caching.(*DB).retainBatchArenaChunksForMemtablesWithPolicy` |
| 0.51MB | 0.51% | 0.51MB | 0.51% | `runtime/pprof.(*protobuf).string` |
| 0.50MB | 0.51% | 2.52MB | 2.54% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0.50MB | 0.51% | 0.50MB | 0.51% | `runtime/pprof.(*protobuf).varint (inline)` |
| 0.50MB | 0.50% | 2.52MB | 2.54% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 2.72MB | 2.74% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 1MB | 1.01% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatch` |
| 0 | 0.00% | 25.90MB | 26.09% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Set` |
| 0 | 0.00% | 25.90MB | 26.09% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).SetWithRevision (inline)` |
| 0 | 0.00% | 67.63MB | 68.13% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 25.90MB | 26.09% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopy` |
| 0 | 0.00% | 25.90MB | 26.09% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).arenaCopyInto` |
| 0 | 0.00% | 25.90MB | 26.09% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).cloneKeyValue` |
| 0 | 0.00% | 25.90MB | 26.09% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setWithMVCCInput` |
| 0 | 0.00% | 60.61MB | 61.06% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).tryApplySmallSelectedSortedShard` |
| 0 | 0.00% | 67.63MB | 68.13% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 67.63MB | 68.13% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |

### batch_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_batch_write_treedb.pprof`
- total: `2843`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2185 | 76.86% | 2185 | 76.86% | `runtime/pprof.allFrames` |
| 289 | 10.17% | 289 | 10.17% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 108 | 3.80% | 242 | 8.51% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 108 | 3.80% | 108 | 3.80% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 55 | 1.93% | 55 | 1.93% | `runtime/pprof.(*protobuf).string (inline)` |
| 32 | 1.13% | 32 | 1.13% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 28 | 0.98% | 28 | 0.98% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` |
| 16 | 0.56% | 16 | 0.56% | `compress/flate.newDeflateFast (inline)` |
| 10 | 0.35% | 26 | 0.91% | `compress/flate.(*compressor).init` |
| 5 | 0.18% | 31 | 1.09% | `compress/flate.NewWriter (inline)` |
| 1 | 0.04% | 324 | 11.40% | `main.runBenchmark.func6` |
| 0 | 0.00% | 31 | 1.09% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 322 | 11.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 322 | 11.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 322 | 11.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 322 | 11.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 289 | 10.17% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ApplyCopySortedBatchWithValueCopierTrusted` |
| 0 | 0.00% | 289 | 10.17% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 322 | 11.33% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 2838 | 99.82% | `main.main` |
| 0 | 0.00% | 2838 | 99.82% | `main.runBenchmark` |
| 0 | 0.00% | 324 | 11.40% | `main.runBenchmark.func23` |
| 0 | 0.00% | 2190 | 77.03% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2190 | 77.03% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 324 | 11.40% | `main.writeRuntimeProfileSnapshot` |

### batch_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_batch_write_treedb.pprof`
- total: `38965.41kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 18641.66kB | 47.84% | 18641.66kB | 47.84% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 5210.53kB | 13.37% | 5210.53kB | 13.37% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 4512.93kB | 11.58% | 7418.90kB | 19.04% | `compress/flate.NewWriter (inline)` |
| 2203.77kB | 5.66% | 2203.77kB | 5.66% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` |
| 1710.68kB | 4.39% | 1710.68kB | 4.39% | `compress/flate.newDeflateFast (inline)` |
| 1644.93kB | 4.22% | 28968.96kB | 74.35% | `main.runBenchmark.func6` |
| 1268.07kB | 3.25% | 1268.07kB | 3.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchEntries` |
| 1195.29kB | 3.07% | 2905.97kB | 7.46% | `compress/flate.(*compressor).init` |
| 520.04kB | 1.33% | 520.04kB | 1.33% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 516.64kB | 1.33% | 516.64kB | 1.33% | `runtime/pprof.(*protobuf).string` |
| 514.38kB | 1.32% | 6962.06kB | 17.87% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 514.38kB | 1.32% | 514.38kB | 1.32% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 512.12kB | 1.31% | 512.12kB | 1.31% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 7418.90kB | 19.04% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 1268.07kB | 3.25% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatchWithSize` |
| 0 | 0.00% | 26055.96kB | 66.87% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 26055.96kB | 66.87% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 26055.96kB | 66.87% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 26055.96kB | 66.87% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 1268.07kB | 3.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatchWithSize` |
| 0 | 0.00% | 18641.66kB | 47.84% | `github.com/snissn/gomap/TreeDB/caching.reserveAppendOnlyMemtableEntries` |
| 0 | 0.00% | 18641.66kB | 47.84% | `github.com/snissn/gomap/TreeDB/caching.reserveMemtableEntries` |
| 0 | 0.00% | 5210.53kB | 13.37% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ApplyCopySortedBatchWithValueCopierTrusted` |
| 0 | 0.00% | 18641.66kB | 47.84% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ReserveAdditionalEntries` |
| 0 | 0.00% | 5210.53kB | 13.37% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |

### batch_write_steady (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_batch_write_steady_treedb.pprof`
- total: `57039`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 21845 | 38.30% | 21845 | 38.30% | `github.com/snissn/gomap/TreeDB/caching.(*cachingLeafPageLog).CurrentLeafPageLogSegmentsSnapshot` |
| 21845 | 38.30% | 21845 | 38.30% | `github.com/snissn/gomap/TreeDB/caching.putAppendOnlyDirectValueArenaChunk` |
| 5461 | 9.57% | 5461 | 9.57% | `syscall.ByteSliceFromString` |
| 4370 | 7.66% | 4370 | 7.66% | `runtime/pprof.allFrames` |
| 1638 | 2.87% | 1638 | 2.87% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).applySpanNativeWithPrepared` |
| 455 | 0.80% | 1146 | 2.01% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).applySpanNativeWithPrepared.func2` |
| 445 | 0.78% | 445 | 0.78% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 391 | 0.69% | 391 | 0.69% | `github.com/snissn/gomap/TreeDB/zipper.acquireSpanNativeSplitSlices` |
| 128 | 0.22% | 2330 | 4.08% | `runtime/pprof.writeProfileInternal` |
| 1 | 0.00% | 22335 | 39.16% | `main.runBenchmark.func6` |
| 0 | 0.00% | 21858 | 38.32% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 21858 | 38.32% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 21858 | 38.32% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |
| 0 | 0.00% | 21858 | 38.32% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 1693 | 2.97% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 23538 | 41.27% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 23538 | 41.27% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 23530 | 41.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4` |
| 0 | 0.00% | 23487 | 41.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func5` |
| 0 | 0.00% | 23538 | 41.27% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |

### batch_write_steady (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_batch_write_steady_treedb.pprof`
- total: `131.34MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 89.31MB | 68.00% | 89.31MB | 68.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 13.93MB | 10.60% | 13.93MB | 10.60% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 7.07MB | 5.38% | 7.07MB | 5.38% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve` |
| 4.41MB | 3.36% | 6.78MB | 5.16% | `compress/flate.NewWriter (inline)` |
| 1.83MB | 1.39% | 1.83MB | 1.39% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked` |
| 1.61MB | 1.22% | 108.12MB | 82.32% | `main.runBenchmark.func6` |
| 1.27MB | 0.97% | 2.37MB | 1.81% | `compress/flate.(*compressor).init` |
| 1.16MB | 0.88% | 1.16MB | 0.88% | `runtime/pprof.StartCPUProfile` |
| 1.10MB | 0.84% | 1.10MB | 0.84% | `compress/flate.newDeflateFast (inline)` |
| 1.08MB | 0.82% | 1.08MB | 0.82% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildOrderedKey64Locked` |
| 1MB | 0.76% | 1MB | 0.76% | `github.com/snissn/gomap/TreeDB/zipper.init.func2` |
| 1MB | 0.76% | 1MB | 0.76% | `github.com/snissn/gomap/TreeDB/zipper.acquireSpanNativeSplitSlices` |
| 1MB | 0.76% | 1MB | 0.76% | `runtime/pprof.allFrames` |
| 0.51MB | 0.39% | 6.40MB | 4.88% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0.50MB | 0.38% | 6.33MB | 4.82% | `runtime/pprof.writeProfileInternal` |
| 0.50MB | 0.38% | 3.53MB | 2.69% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).applySpanNativeWithPrepared.func2` |
| 0 | 0.00% | 6.78MB | 5.16% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 1.58MB | 1.20% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 1.58MB | 1.20% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 103.78MB | 79.02% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).Write` |
| 0 | 0.00% | 13.93MB | 10.60% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).copyValueToAppendOnlyDirectArena` |
| 0 | 0.00% | 103.78MB | 79.02% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).write` |
| 0 | 0.00% | 103.78MB | 79.02% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 103.78MB | 79.02% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 1.58MB | 1.20% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |

### dataset_write_random (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_dataset_write_random_treedb.pprof`
- total: `3940`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2372 | 60.20% | 2372 | 60.20% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 445 | 11.29% | 445 | 11.29% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 394 | 10.00% | 394 | 10.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 293 | 7.44% | 296 | 7.51% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 276 | 7.01% | 276 | 7.01% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` |
| 119 | 3.02% | 119 | 3.02% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 27 | 0.69% | 27 | 0.69% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 0 | 0.00% | 3514 | 89.19% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 3514 | 89.19% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 3514 | 89.19% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 3514 | 89.19% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 3514 | 89.19% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 445 | 11.29% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` |
| 0 | 0.00% | 445 | 11.29% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).takeRetainedChunk` |
| 0 | 0.00% | 3069 | 77.89% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 3069 | 77.89% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 2399 | 60.89% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 0 | 0.00% | 3069 | 77.89% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 276 | 7.01% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 0 | 0.00% | 3514 | 89.19% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 3934 | 99.85% | `main.main` |
| 0 | 0.00% | 3934 | 99.85% | `main.runBenchmark` |
| 0 | 0.00% | 3514 | 89.19% | `main.runBenchmark.func21` |
| 0 | 0.00% | 44 | 1.12% | `main.writeAllocsSnapshot` |

### dataset_write_random (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_dataset_write_random_treedb.pprof`
- total: `198.49MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 154.38MB | 77.78% | 154.38MB | 77.78% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 13.93MB | 7.02% | 13.93MB | 7.02% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 10.26MB | 5.17% | 10.26MB | 5.17% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 7.18MB | 3.62% | 7.18MB | 3.62% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` |
| 5.01MB | 2.53% | 5.01MB | 2.53% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 4.41MB | 2.22% | 4.98MB | 2.51% | `compress/flate.NewWriter (inline)` |
| 1.01MB | 0.51% | 1.01MB | 0.51% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 0.62MB | 0.31% | 1.23MB | 0.62% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestSnapshotLocked` |
| 0.50MB | 0.25% | 3.15MB | 1.58% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 4.98MB | 2.51% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 190.76MB | 96.11% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 190.76MB | 96.11% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 190.76MB | 96.11% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 190.76MB | 96.11% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 190.76MB | 96.11% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 13.93MB | 7.02% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` |
| 0 | 0.00% | 13.93MB | 7.02% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).takeRetainedChunk` |

### dataset_write_sorted (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_dataset_write_sorted_treedb.pprof`
- total: `7237`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4617 | 63.80% | 4617 | 63.80% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 2185 | 30.19% | 2185 | 30.19% | `runtime/pprof.allFrames` |
| 228 | 3.15% | 228 | 3.15% | `compress/flate.(*huffmanEncoder).generate` |
| 148 | 2.05% | 148 | 2.05% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 0 | 0.00% | 228 | 3.15% | `compress/flate.(*Writer).Close (inline)` |
| 0 | 0.00% | 228 | 3.15% | `compress/flate.(*compressor).close` |
| 0 | 0.00% | 228 | 3.15% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 228 | 3.15% | `compress/flate.(*huffmanBitWriter).writeBlockDynamic` |
| 0 | 0.00% | 228 | 3.15% | `compress/gzip.(*Writer).Close` |
| 0 | 0.00% | 4785 | 66.12% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 4785 | 66.12% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 4785 | 66.12% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 4785 | 66.12% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 4785 | 66.12% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 148 | 2.05% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` |
| 0 | 0.00% | 148 | 2.05% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).takeRetainedChunk` |
| 0 | 0.00% | 4637 | 64.07% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 4637 | 64.07% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 4618 | 63.81% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 0 | 0.00% | 4637 | 64.07% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 4785 | 66.12% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 7000 | 96.73% | `main.main` |
| 0 | 0.00% | 7000 | 96.73% | `main.runBenchmark` |
| 0 | 0.00% | 4785 | 66.12% | `main.runBenchmark.func22` |
| 0 | 0.00% | 2199 | 30.39% | `main.writeRuntimeProfileSnapshot` |

### dataset_write_sorted (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_dataset_write_sorted_treedb.pprof`
- total: `28068.01kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 9234.01kB | 32.90% | 9234.01kB | 32.90% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 4753.50kB | 16.94% | 4753.50kB | 16.94% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 4512.93kB | 16.08% | 7524.85kB | 26.81% | `compress/flate.NewWriter (inline)` |
| 4472.72kB | 15.94% | 4472.72kB | 15.94% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 1710.68kB | 6.09% | 1710.68kB | 6.09% | `compress/flate.newDeflateFast (inline)` |
| 1301.24kB | 4.64% | 3011.92kB | 10.73% | `compress/flate.(*compressor).init` |
| 532.26kB | 1.90% | 6609.86kB | 23.55% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 525.43kB | 1.87% | 525.43kB | 1.87% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 513.12kB | 1.83% | 513.12kB | 1.83% | `compress/flate.(*huffmanEncoder).generate` |
| 512.12kB | 1.82% | 512.12kB | 1.82% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 513.12kB | 1.83% | `compress/flate.(*Writer).Close (inline)` |
| 0 | 0.00% | 513.12kB | 1.83% | `compress/flate.(*compressor).close` |
| 0 | 0.00% | 513.12kB | 1.83% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 513.12kB | 1.83% | `compress/flate.(*huffmanBitWriter).writeBlockDynamic` |
| 0 | 0.00% | 513.12kB | 1.83% | `compress/gzip.(*Writer).Close` |
| 0 | 0.00% | 7524.85kB | 26.81% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 18985.66kB | 67.64% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 18985.66kB | 67.64% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 18985.66kB | 67.64% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 18985.66kB | 67.64% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 18985.66kB | 67.64% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 4753.50kB | 16.94% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` |
| 0 | 0.00% | 4753.50kB | 16.94% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).takeRetainedChunk` |
| 0 | 0.00% | 14232.16kB | 50.71% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 14232.16kB | 50.71% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |

### full_scan (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_full_scan_treedb.pprof`
- total: `71309`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 49155 | 68.93% | 49155 | 68.93% | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` |
| 21939 | 30.77% | 21962 | 30.80% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 49155 | 68.93% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 0 | 0.00% | 49155 | 68.93% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafKeyFlagsView` |
| 0 | 0.00% | 49155 | 68.93% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafKeyFlagsViewColumnarPrefixV2 (inline)` |
| 0 | 0.00% | 49155 | 68.93% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 0 | 0.00% | 49155 | 68.93% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).Next` |
| 0 | 0.00% | 49155 | 68.93% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).getLeafKeyFlags` |
| 0 | 0.00% | 49155 | 68.93% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadCurrent` |
| 0 | 0.00% | 71254 | 99.92% | `main.main` |
| 0 | 0.00% | 71254 | 99.92% | `main.runBenchmark` |
| 0 | 0.00% | 49155 | 68.93% | `main.runBenchmark.func37` |
| 0 | 0.00% | 5468 | 7.67% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 5468 | 7.67% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 16631 | 23.32% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 16631 | 23.32% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 71254 | 99.92% | `runtime.main` |
| 0 | 0.00% | 22099 | 30.99% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 21962 | 30.80% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 16631 | 23.32% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 5468 | 7.67% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 11145 | 15.63% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 5468 | 7.67% | `runtime/pprof.writeHeapInternal` |
| 0 | 0.00% | 5468 | 7.67% | `runtime/pprof.writeHeapProto` |
| 0 | 0.00% | 5486 | 7.69% | `runtime/pprof.writeMutex` |

### full_scan (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_full_scan_treedb.pprof`
- total: `16994.56kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4735.43kB | 27.86% | 12366.24kB | 72.77% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 4512.93kB | 26.56% | 7630.81kB | 44.90% | `compress/flate.NewWriter (inline)` |
| 3072.19kB | 18.08% | 3072.19kB | 18.08% | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` |
| 1951.87kB | 11.49% | 3117.88kB | 18.35% | `compress/flate.(*compressor).init` |
| 1166.01kB | 6.86% | 1166.01kB | 6.86% | `compress/flate.newDeflateFast (inline)` |
| 526.13kB | 3.10% | 1041.51kB | 6.13% | `runtime/pprof.(*protobuf).string (inline)` |
| 515.38kB | 3.03% | 515.38kB | 3.03% | `runtime/pprof.(*protobuf).varint (inline)` |
| 514.63kB | 3.03% | 514.63kB | 3.03% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 0 | 0.00% | 7630.81kB | 44.90% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 3072.19kB | 18.08% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 0 | 0.00% | 3072.19kB | 18.08% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafKeyFlagsView` |
| 0 | 0.00% | 3072.19kB | 18.08% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafKeyFlagsViewColumnarPrefixV2 (inline)` |
| 0 | 0.00% | 3072.19kB | 18.08% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 0 | 0.00% | 3072.19kB | 18.08% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).Next` |
| 0 | 0.00% | 3072.19kB | 18.08% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).getLeafKeyFlags` |
| 0 | 0.00% | 3072.19kB | 18.08% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadCurrent` |
| 0 | 0.00% | 16477.92kB | 96.96% | `main.main` |
| 0 | 0.00% | 16477.92kB | 96.96% | `main.runBenchmark` |
| 0 | 0.00% | 3072.19kB | 18.08% | `main.runBenchmark.func37` |
| 0 | 0.00% | 1967.67kB | 11.58% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 1967.67kB | 11.58% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 11438.06kB | 67.30% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 11438.06kB | 67.30% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 514.63kB | 3.03% | `os.ReadFile` |
| 0 | 0.00% | 514.63kB | 3.03% | `os.readFileContents` |

### prefix_scan (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_prefix_scan_treedb.pprof`
- total: `11146`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 6085 | 54.59% | 6151 | 55.19% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 4370 | 39.21% | 4370 | 39.21% | `runtime/pprof.allFrames` |
| 512 | 4.59% | 512 | 4.59% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 80 | 0.72% | 80 | 0.72% | `runtime/pprof.(*protobuf).string (inline)` |
| 56 | 0.50% | 56 | 0.50% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 0 | 0.00% | 512 | 4.59% | `github.com/snissn/gomap/TreeDB.(*DB).Iterator` |
| 0 | 0.00% | 512 | 4.59% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Iterator` |
| 0 | 0.00% | 512 | 4.59% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 512 | 4.59% | `github.com/snissn/gomap/TreeDB/db.(*DB).Iterator` |
| 0 | 0.00% | 512 | 4.59% | `github.com/snissn/gomap/TreeDB/db.(*DB).IteratorWithOptions` |
| 0 | 0.00% | 512 | 4.59% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotOrErr` |
| 0 | 0.00% | 512 | 4.59% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 512 | 4.59% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Iterator` |
| 0 | 0.00% | 11140 | 99.95% | `main.main` |
| 0 | 0.00% | 11140 | 99.95% | `main.runBenchmark` |
| 0 | 0.00% | 512 | 4.59% | `main.runBenchmark.func39` |
| 0 | 0.00% | 5520 | 49.52% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 5520 | 49.52% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 5108 | 45.83% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 5108 | 45.83% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 11140 | 99.95% | `runtime.main` |
| 0 | 0.00% | 10628 | 95.35% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 10521 | 94.39% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |

### prefix_scan (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_prefix_scan_treedb.pprof`
- total: `12138.74kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4512.93kB | 37.18% | 6980.19kB | 57.50% | `compress/flate.NewWriter (inline)` |
| 1543.14kB | 12.71% | 6001.17kB | 49.44% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1301.25kB | 10.72% | 2467.26kB | 20.33% | `compress/flate.(*compressor).init` |
| 1166.01kB | 9.61% | 1166.01kB | 9.61% | `compress/flate.newDeflateFast (inline)` |
| 1039.34kB | 8.56% | 1039.34kB | 8.56% | `runtime/pprof.(*protobuf).string (inline)` |
| 1024.23kB | 8.44% | 1024.23kB | 8.44% | `runtime/pprof.allFrames` |
| 522.70kB | 4.31% | 522.70kB | 4.31% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 516.64kB | 4.26% | 516.64kB | 4.26% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 512.50kB | 4.22% | 512.50kB | 4.22% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 0 | 0.00% | 6980.19kB | 57.50% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 512.50kB | 4.22% | `github.com/snissn/gomap/TreeDB.(*DB).Iterator` |
| 0 | 0.00% | 512.50kB | 4.22% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Iterator` |
| 0 | 0.00% | 512.50kB | 4.22% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 512.50kB | 4.22% | `github.com/snissn/gomap/TreeDB/db.(*DB).Iterator` |
| 0 | 0.00% | 512.50kB | 4.22% | `github.com/snissn/gomap/TreeDB/db.(*DB).IteratorWithOptions` |
| 0 | 0.00% | 512.50kB | 4.22% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotOrErr` |
| 0 | 0.00% | 512.50kB | 4.22% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 512.50kB | 4.22% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Iterator` |
| 0 | 0.00% | 10653.14kB | 87.76% | `main.main` |
| 0 | 0.00% | 10653.14kB | 87.76% | `main.runBenchmark` |
| 0 | 0.00% | 512.50kB | 4.22% | `main.runBenchmark.func39` |
| 0 | 0.00% | 2581.89kB | 21.27% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2581.89kB | 21.27% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 7558.75kB | 62.27% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 7558.75kB | 62.27% | `main.writeRuntimeProfileSnapshotTemp` |

### random_delete (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_delete_treedb.pprof`
- total: `35954`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 34953 | 97.22% | 34953 | 97.22% | `runtime/pprof.allFrames` |
| 677 | 1.88% | 677 | 1.88% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 293 | 0.81% | 991 | 2.76% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 35798 | 99.57% | `main.main` |
| 0 | 0.00% | 35798 | 99.57% | `main.runBenchmark` |
| 0 | 0.00% | 446 | 1.24% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 446 | 1.24% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 35347 | 98.31% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 35347 | 98.31% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 35798 | 99.57% | `runtime.main` |
| 0 | 0.00% | 35793 | 99.55% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 35944 | 100.00% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 35347 | 98.31% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 446 | 1.24% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 33155 | 92.22% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 446 | 1.24% | `runtime/pprof.writeHeapInternal` |
| 0 | 0.00% | 446 | 1.24% | `runtime/pprof.writeHeapProto` |
| 0 | 0.00% | 2192 | 6.10% | `runtime/pprof.writeMutex` |
| 0 | 0.00% | 35347 | 98.31% | `runtime/pprof.writeProfileInternal` |

### random_delete (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_delete_treedb.pprof`
- total: `81.96MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 71.98MB | 87.83% | 71.98MB | 87.83% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 3.53MB | 4.30% | 6.47MB | 7.89% | `compress/flate.NewWriter (inline)` |
| 2.01MB | 2.45% | 2.01MB | 2.45% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 1.67MB | 2.04% | 1.67MB | 2.04% | `compress/flate.newDeflateFast (inline)` |
| 1.27MB | 1.55% | 2.94MB | 3.59% | `compress/flate.(*compressor).init` |
| 1MB | 1.22% | 1MB | 1.22% | `runtime/pprof.allFrames` |
| 0.50MB | 0.61% | 7.52MB | 9.18% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 6.47MB | 7.89% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 71.98MB | 87.83% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 71.98MB | 87.83% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Delete` |
| 0 | 0.00% | 71.98MB | 87.83% | `github.com/snissn/gomap/TreeDB/caching.(*DB).delete` |
| 0 | 0.00% | 71.98MB | 87.83% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirect` |
| 0 | 0.00% | 71.98MB | 87.83% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 71.98MB | 87.83% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 71.98MB | 87.83% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 0 | 0.00% | 71.98MB | 87.83% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 71.98MB | 87.83% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).growEntriesLocked` |
| 0 | 0.00% | 71.98MB | 87.83% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Delete` |
| 0 | 0.00% | 80.89MB | 98.69% | `main.main` |
| 0 | 0.00% | 80.89MB | 98.69% | `main.runBenchmark` |
| 0 | 0.00% | 71.98MB | 87.83% | `main.runBenchmark.func31` |
| 0 | 0.00% | 1.88MB | 2.30% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 1.88MB | 2.30% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 7.02MB | 8.57% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 7.02MB | 8.57% | `main.writeRuntimeProfileSnapshotTemp` |

### random_read (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_read_treedb.pprof`
- total: `34978`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 34953 | 99.93% | 34953 | 99.93% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 34978 | 100.00% | `main.main` |
| 0 | 0.00% | 34978 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 2187 | 6.25% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2187 | 6.25% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 32791 | 93.75% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 32791 | 93.75% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 34978 | 100.00% | `runtime.main` |
| 0 | 0.00% | 34978 | 100.00% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 34976 | 100.00% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 32791 | 93.75% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 2187 | 6.25% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 32772 | 93.69% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 2187 | 6.25% | `runtime/pprof.writeHeapInternal` |
| 0 | 0.00% | 2187 | 6.25% | `runtime/pprof.writeHeapProto` |
| 0 | 0.00% | 32791 | 93.75% | `runtime/pprof.writeProfileInternal` |

### random_read (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_read_treedb.pprof`
- total: `7063.39kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3610.34kB | 51.11% | 6039.26kB | 85.50% | `compress/flate.NewWriter (inline)` |
| 1301.24kB | 18.42% | 2428.92kB | 34.39% | `compress/flate.(*compressor).init` |
| 1127.67kB | 15.97% | 1127.67kB | 15.97% | `compress/flate.newDeflateFast (inline)` |
| 1024.12kB | 14.50% | 1024.12kB | 14.50% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 6039.26kB | 85.50% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 7063.39kB | 100.00% | `main.main` |
| 0 | 0.00% | 7063.39kB | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 1414.70kB | 20.03% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 1414.70kB | 20.03% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 5648.68kB | 79.97% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 5648.68kB | 79.97% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 7063.39kB | 100.00% | `runtime.main` |
| 0 | 0.00% | 7063.39kB | 100.00% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 6160.80kB | 87.22% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 5136.67kB | 72.72% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 6039.26kB | 85.50% | `runtime/pprof.(*profileBuilder).flush` |
| 0 | 0.00% | 902.59kB | 12.78% | `runtime/pprof.(*profileBuilder).pbSample` |
| 0 | 0.00% | 5648.68kB | 79.97% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 1414.70kB | 20.03% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 2065.22kB | 29.24% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 1414.70kB | 20.03% | `runtime/pprof.writeHeapInternal` |
| 0 | 0.00% | 1414.70kB | 20.03% | `runtime/pprof.writeHeapProto` |
| 0 | 0.00% | 3583.47kB | 50.73% | `runtime/pprof.writeMutex` |
| 0 | 0.00% | 5648.68kB | 79.97% | `runtime/pprof.writeProfileInternal` |

### random_read_batch (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_read_batch_treedb.pprof`
- total: `10168`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 7646 | 75.20% | 7646 | 75.20% | `runtime/pprof.allFrames` |
| 2185 | 21.49% | 10061 | 98.95% | `runtime/pprof.printCountCycleProfile` |
| 158 | 1.55% | 232 | 2.28% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 56 | 0.55% | 56 | 0.55% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 0 | 0.00% | 10124 | 99.57% | `main.main` |
| 0 | 0.00% | 10124 | 99.57% | `main.runBenchmark` |
| 0 | 0.00% | 10061 | 98.95% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 10061 | 98.95% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 10124 | 99.57% | `runtime.main` |
| 0 | 0.00% | 10124 | 99.57% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 7878 | 77.48% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 225 | 2.21% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 9836 | 96.73% | `runtime/pprof.writeMutex` |
| 0 | 0.00% | 10061 | 98.95% | `runtime/pprof.writeProfileInternal` |

### random_read_batch (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_read_batch_treedb.pprof`
- total: `14263.91kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5415.52kB | 37.97% | 7950.39kB | 55.74% | `compress/flate.NewWriter (inline)` |
| 2153.79kB | 15.10% | 2153.79kB | 15.10% | `github.com/snissn/gomap/TreeDB/tree.getGetManyScratch` |
| 1951.87kB | 13.68% | 2534.87kB | 17.77% | `compress/flate.(*compressor).init` |
| 1066.73kB | 7.48% | 9533.76kB | 66.84% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1024.16kB | 7.18% | 1024.16kB | 7.18% | `runtime/pprof.allFrames` |
| 583.01kB | 4.09% | 583.01kB | 4.09% | `compress/flate.newDeflateFast (inline)` |
| 520.04kB | 3.65% | 520.04kB | 3.65% | `runtime/pprof.(*protobuf).varint (inline)` |
| 520.04kB | 3.65% | 520.04kB | 3.65% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 516.64kB | 3.62% | 516.64kB | 3.62% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 512.12kB | 3.59% | 8584.65kB | 60.18% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 7950.39kB | 55.74% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 2153.79kB | 15.10% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel.func3` |
| 0 | 0.00% | 2153.79kB | 15.10% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).GetManyView` |
| 0 | 0.00% | 10556.91kB | 74.01% | `main.main` |
| 0 | 0.00% | 10556.91kB | 74.01% | `main.runBenchmark` |
| 0 | 0.00% | 1972.27kB | 13.83% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 1972.27kB | 13.83% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 8584.65kB | 60.18% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 8584.65kB | 60.18% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 520.04kB | 3.65% | `os.ReadFile` |
| 0 | 0.00% | 520.04kB | 3.65% | `os.readFileContents` |
| 0 | 0.00% | 10556.91kB | 74.01% | `runtime.main` |
| 0 | 0.00% | 10556.91kB | 74.01% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 10557.92kB | 74.02% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2073.25kB | 14.53% | `runtime/pprof.(*profileBuilder).build` |

### random_read_parallel (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_read_parallel_treedb.pprof`
- total: `15589`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 7646 | 49.05% | 7646 | 49.05% | `runtime/pprof.allFrames` |
| 5568 | 35.72% | 5647 | 36.22% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 2185 | 14.02% | 15462 | 99.19% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 15554 | 99.78% | `main.main` |
| 0 | 0.00% | 15554 | 99.78% | `main.runBenchmark` |
| 0 | 0.00% | 15462 | 99.19% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 15462 | 99.19% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 15554 | 99.78% | `runtime.main` |
| 0 | 0.00% | 15554 | 99.78% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 13293 | 85.27% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 7812 | 50.11% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 7650 | 49.07% | `runtime/pprof.writeMutex` |
| 0 | 0.00% | 15462 | 99.19% | `runtime/pprof.writeProfileInternal` |

### random_read_parallel (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_read_parallel_treedb.pprof`
- total: `16171.69kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3656.99kB | 22.61% | 3656.99kB | 22.61% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked` |
| 3610.34kB | 22.33% | 5350.30kB | 33.08% | `compress/flate.NewWriter (inline)` |
| 3047.49kB | 18.84% | 6704.48kB | 41.46% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestSnapshotLocked` |
| 1548.61kB | 9.58% | 7415.55kB | 45.86% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1195.29kB | 7.39% | 1739.96kB | 10.76% | `compress/flate.(*compressor).init` |
| 1024.16kB | 6.33% | 1024.16kB | 6.33% | `runtime/pprof.allFrames` |
| 544.67kB | 3.37% | 544.67kB | 3.37% | `compress/flate.newDeflateFast (inline)` |
| 516.64kB | 3.19% | 516.64kB | 3.19% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 515.38kB | 3.19% | 515.38kB | 3.19% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 512.12kB | 3.17% | 6981.95kB | 43.17% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 5350.30kB | 33.08% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 6704.48kB | 41.46% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 6704.48kB | 41.46% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 6704.48kB | 41.46% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 6704.48kB | 41.46% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCheckpointFrontierLocked.func1` |
| 0 | 0.00% | 6704.48kB | 41.46% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 6704.48kB | 41.46% | `github.com/snissn/gomap/TreeDB/caching.countCanonicalStableIteratorUnits` |
| 0 | 0.00% | 6704.48kB | 41.46% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).NewIterator` |
| 0 | 0.00% | 9467.21kB | 58.54% | `main.main` |
| 0 | 0.00% | 9467.21kB | 58.54% | `main.runBenchmark` |
| 0 | 0.00% | 2485.26kB | 15.37% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2485.26kB | 15.37% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 6981.95kB | 43.17% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 6981.95kB | 43.17% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 515.38kB | 3.19% | `os.ReadFile` |

### random_read_parallel_acquire_snapshot (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_read_parallel_acquire_snapshot_treedb.pprof`
- total: `2443405`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2395425 | 98.04% | 2395425 | 98.04% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 32768 | 1.34% | 33084 | 1.35% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 14201 | 0.58% | 14201 | 0.58% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 2395425 | 98.04% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2395425 | 98.04% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 2395425 | 98.04% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2395425 | 98.04% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 2395425 | 98.04% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).AcquireReadSnapshot` |
| 0 | 0.00% | 2395553 | 98.04% | `main.runBenchmark.func34.1` |
| 0 | 0.00% | 2395553 | 98.04% | `main.runBenchmark.func34.2` |
| 0 | 0.00% | 47285 | 1.94% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 33302 | 1.36% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 33074 | 1.35% | `runtime/pprof.profileWriter` |

### random_read_parallel_acquire_snapshot (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_read_parallel_acquire_snapshot_treedb.pprof`
- total: `2.30GB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2.28GB | 99.48% | 2.28GB | 99.48% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 0 | 0.00% | 2.28GB | 99.48% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2.28GB | 99.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 2.28GB | 99.48% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2.28GB | 99.48% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 2.28GB | 99.48% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).AcquireReadSnapshot` |
| 0 | 0.00% | 2.28GB | 99.50% | `main.runBenchmark.func34.1` |
| 0 | 0.00% | 2.28GB | 99.50% | `main.runBenchmark.func34.2` |

### random_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_write_treedb.pprof`
- total: `1714`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 926 | 54.03% | 926 | 54.03% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 313 | 18.26% | 313 | 18.26% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 228 | 13.30% | 228 | 13.30% | `compress/flate.(*huffmanEncoder).generate` |
| 115 | 6.71% | 115 | 6.71% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` |
| 98 | 5.72% | 98 | 5.72% | `runtime/pprof.(*protobuf).string` |
| 16 | 0.93% | 16 | 0.93% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 8 | 0.47% | 8 | 0.47% | `compress/flate.newDeflateFast (inline)` |
| 5 | 0.29% | 13 | 0.76% | `compress/flate.(*compressor).init` |
| 5 | 0.29% | 18 | 1.05% | `compress/flate.NewWriter (inline)` |
| 0 | 0.00% | 228 | 13.30% | `compress/flate.(*Writer).Close (inline)` |
| 0 | 0.00% | 228 | 13.30% | `compress/flate.(*compressor).close` |
| 0 | 0.00% | 228 | 13.30% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 228 | 13.30% | `compress/flate.(*huffmanBitWriter).indexTokens` |
| 0 | 0.00% | 228 | 13.30% | `compress/flate.(*huffmanBitWriter).writeBlockDynamic` |
| 0 | 0.00% | 228 | 13.30% | `compress/gzip.(*Writer).Close` |
| 0 | 0.00% | 18 | 1.05% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 1370 | 79.93% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 1370 | 79.93% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 1370 | 79.93% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 1370 | 79.93% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 1370 | 79.93% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 313 | 18.26% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` |
| 0 | 0.00% | 313 | 18.26% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).takeRetainedChunk` |
| 0 | 0.00% | 1057 | 61.67% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 1057 | 61.67% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |

### random_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_random_write_treedb.pprof`
- total: `68.74MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 32.80MB | 47.72% | 32.80MB | 47.72% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 16.28MB | 23.69% | 16.28MB | 23.69% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 9.80MB | 14.26% | 9.80MB | 14.26% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 4.41MB | 6.41% | 6.82MB | 9.92% | `compress/flate.NewWriter (inline)` |
| 2.04MB | 2.96% | 2.04MB | 2.96% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` |
| 1.27MB | 1.85% | 2.41MB | 3.51% | `compress/flate.(*compressor).init` |
| 1.14MB | 1.66% | 1.14MB | 1.66% | `compress/flate.newDeflateFast (inline)` |
| 0.50MB | 0.73% | 0.50MB | 0.73% | `runtime/pprof.(*protobuf).string` |
| 0.50MB | 0.73% | 0.50MB | 0.73% | `compress/flate.(*huffmanEncoder).generate` |
| 0 | 0.00% | 6.82MB | 9.92% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 60.92MB | 88.62% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 60.92MB | 88.62% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 60.92MB | 88.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 60.92MB | 88.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 60.92MB | 88.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 9.80MB | 14.26% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` |
| 0 | 0.00% | 9.80MB | 14.26% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).takeRetainedChunk` |
| 0 | 0.00% | 51.12MB | 74.37% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 51.12MB | 74.37% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |

### sequential_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_sequential_write_treedb.pprof`
- total: `8877`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4370 | 49.23% | 4370 | 49.23% | `runtime/pprof.allFrames` |
| 1413 | 15.92% | 1413 | 15.92% | `github.com/snissn/gomap/TreeDB/zipper.init.func2` |
| 1285 | 14.48% | 1285 | 14.48% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` |
| 874 | 9.85% | 874 | 9.85% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 586 | 6.60% | 586 | 6.60% | `github.com/snissn/gomap/TreeDB/internal/valuelog.ensureFrameBody (inline)` |
| 128 | 1.44% | 128 | 1.44% | `github.com/snissn/gomap/TreeDB/zipper.newMergeScratch (inline)` |
| 98 | 1.10% | 98 | 1.10% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 0 | 0.00% | 914 | 10.30% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 914 | 10.30% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 914 | 10.30% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 2878 | 32.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 2878 | 32.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 2878 | 32.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 2877 | 32.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4` |
| 0 | 0.00% | 2877 | 32.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func5` |
| 0 | 0.00% | 2878 | 32.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 2878 | 32.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionMode (inline)` |
| 0 | 0.00% | 2878 | 32.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 2878 | 32.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCommandPublish (inline)` |
| 0 | 0.00% | 914 | 10.30% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 914 | 10.30% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 586 | 6.60% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop` |
| 0 | 0.00% | 586 | 6.60% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop.func1` |
| 0 | 0.00% | 2877 | 32.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).writeCanonicalFlushRunOpsChunk` |
| 0 | 0.00% | 874 | 9.85% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` |

### sequential_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/allocs_sequential_write_treedb.pprof`
- total: `82.73MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 27.34MB | 33.05% | 27.34MB | 33.05% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 10.71MB | 12.95% | 10.71MB | 12.95% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 7.07MB | 8.54% | 7.07MB | 8.54% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve` |
| 5.52MB | 6.67% | 5.52MB | 6.67% | `github.com/snissn/gomap/TreeDB/zipper.init.func2` |
| 5.02MB | 6.07% | 5.02MB | 6.07% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` |
| 4.61MB | 5.57% | 4.61MB | 5.57% | `github.com/snissn/gomap/TreeDB/zipper.acquireSpanNativeLeafLogPayloadArena` |
| 4.41MB | 5.33% | 7.95MB | 9.61% | `compress/flate.NewWriter (inline)` |
| 4MB | 4.84% | 4MB | 4.84% | `github.com/snissn/gomap/TreeDB/internal/valuelog.getWriterAppendBuf` |
| 3.13MB | 3.78% | 3.13MB | 3.78% | `github.com/snissn/gomap/TreeDB/zipper.(*ReadOnlyPrepareResult).ensureInitialCapacity` |
| 2.44MB | 2.95% | 3.54MB | 4.28% | `compress/flate.(*compressor).init` |
| 2.28MB | 2.75% | 2.28MB | 2.75% | `github.com/snissn/gomap/TreeDB/caching.getEntrySlice` |
| 1.60MB | 1.93% | 1.60MB | 1.93% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildOrderedKey64Locked` |
| 1.10MB | 1.33% | 1.10MB | 1.33% | `compress/flate.newDeflateFast (inline)` |
| 1MB | 1.21% | 1MB | 1.21% | `github.com/snissn/gomap/TreeDB/internal/valuelog.ensureFrameBody` |
| 1MB | 1.21% | 1MB | 1.21% | `runtime/pprof.allFrames` |
| 0.51MB | 0.61% | 0.51MB | 0.61% | `github.com/snissn/gomap/TreeDB/node.init.func4` |
| 0.50MB | 0.61% | 0.50MB | 0.61% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 0.50MB | 0.61% | 0.50MB | 0.61% | `github.com/snissn/gomap/TreeDB/zipper.newMergeScratch` |
| 0 | 0.00% | 7.95MB | 9.61% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 39.64MB | 47.92% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 39.64MB | 47.92% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 39.64MB | 47.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 4MB | 4.84% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLog` |
| 0 | 0.00% | 4MB | 4.84% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogInternal (inline)` |
| 0 | 0.00% | 4MB | 4.84% | `github.com/snissn/gomap/TreeDB/caching.(*DB).appendValueLogInternalObserved` |

## Full vs Prefix Comparison

### treedb

- shared hotspots:
  - `runtime.scanObject` (full 15.38%, prefix 50.00%)
  - `runtime.typePointers.next` (full 1.92%, prefix 15.00%)
  - `runtime.tryDeferToSpanScan` (full 3.85%, prefix 10.00%)
  - `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithCOWPolicy` (full 1.92%, prefix 5.00%)
  - `runtime.spanClass.sizeclass (inline)` (full 1.92%, prefix 5.00%)
- prefix-only hotspots:
  - `internal/runtime/atomic.(*Uint32).Add (inline)` (5.00% flat)
  - `runtime.pcvalue` (5.00% flat)
  - `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` (0.00% flat)
  - `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithRecordPolicy` (0.00% flat)
  - `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithState (inline)` (0.00% flat)
- full-only hotspots:
  - `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` (32.69% flat)
  - `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` (5.77% flat)
  - `internal/runtime/syscall/linux.Syscall6` (5.77% flat)
  - `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL256` (1.92% flat)
  - `github.com/snissn/gomap/TreeDB/db.(*DBIterator).UnsafeValue` (1.92% flat)

## Contention Profiles (Per Test)

### batch_delete (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_batch_delete_treedb.pprof`
- total samples: `688.79us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 688.79us | 100.00% | 688.79us | 100.00% | `runtime.chanrecv1` |
| 0 | 0.00% | 688.79us | 100.00% | `main.main` |
| 0 | 0.00% | 688.79us | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 688.79us | 100.00% | `main.runBenchmark.func47` |
| 0 | 0.00% | 688.79us | 100.00% | `main.runBenchmark.func48` |
| 0 | 0.00% | 688.79us | 100.00% | `runtime.main` |
| 0 | 0.00% | 688.79us | 100.00% | `runtime/pprof.StopCPUProfile` |

### batch_delete (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_batch_delete_treedb.pprof`
- total samples: `0`

_No entries parsed._

### batch_random (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_batch_random_treedb.pprof`
- total samples: `200.77ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 100.66ms | 50.14% | 100.66ms | 50.14% | `runtime.chanrecv1` |
| 100.11ms | 49.86% | 100.11ms | 49.86% | `runtime.selectgo` |
| 0 | 0.00% | 100.11ms | 49.86% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 100.11ms | 49.86% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 100.17ms | 49.89% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.17ms | 49.89% | `runtime.traceStartReadCPU.func1` |

### batch_random (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_batch_random_treedb.pprof`
- total samples: `774ns`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 774ns | 100.00% | 774ns | 100.00% | `runtime.unlock (inline)` |
| 0 | 0.00% | 774ns | 100.00% | `runtime.findRunnable` |
| 0 | 0.00% | 774ns | 100.00% | `runtime.gopreempt_m (inline)` |
| 0 | 0.00% | 774ns | 100.00% | `runtime.goschedImpl` |
| 0 | 0.00% | 774ns | 100.00% | `runtime.morestack` |
| 0 | 0.00% | 774ns | 100.00% | `runtime.newstack` |
| 0 | 0.00% | 774ns | 100.00% | `runtime.schedule` |

### batch_small_seq (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_batch_small_seq_treedb.pprof`
- total samples: `400.71ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 201.57ms | 50.30% | 201.57ms | 50.30% | `runtime.chanrecv1` |
| 199.14ms | 49.70% | 199.14ms | 49.70% | `runtime.selectgo` |
| 0 | 0.00% | 199.14ms | 49.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 199.14ms | 49.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 200.98ms | 50.16% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 200.98ms | 50.16% | `runtime.traceStartReadCPU.func1` |

### batch_small_seq (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_batch_small_seq_treedb.pprof`
- total samples: `0`

_No entries parsed._

### batch_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_batch_write_treedb.pprof`
- total samples: `500.01ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 499.62ms | 99.92% | 499.62ms | 99.92% | `runtime.selectgo` |
| 0 | 0.00% | 249.27ms | 49.85% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 249.27ms | 49.85% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 250.34ms | 50.07% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |

### batch_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_batch_write_treedb.pprof`
- total samples: `0`

_No entries parsed._

### batch_write_steady (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_batch_write_steady_treedb.pprof`
- total samples: `15.58s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 7.31s | 46.95% | 7.31s | 46.95% | `runtime.chanrecv2` |
| 6.04s | 38.80% | 6.04s | 38.80% | `runtime.selectgo` |
| 1.40s | 9.01% | 1.40s | 9.01% | `runtime.chanrecv1` |
| 0.51s | 3.30% | 0.51s | 3.30% | `sync.(*WaitGroup).Wait` |
| 0.30s | 1.92% | 0.30s | 1.92% | `sync.(*Mutex).Lock` |
| 0 | 0.00% | 0.40s | 2.60% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 0.40s | 2.60% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 0.40s | 2.60% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |
| 0 | 0.00% | 0.40s | 2.60% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 0.50s | 3.21% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 0.32s | 2.05% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAll` |
| 0 | 0.00% | 0.32s | 2.05% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked` |
| 0 | 0.00% | 0.82s | 5.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 1s | 6.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 1s | 6.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |

### batch_write_steady (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_batch_write_steady_treedb.pprof`
- total samples: `302.27ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 298.69ms | 98.82% | 298.69ms | 98.82% | `sync.(*Mutex).Unlock (partial-inline)` |
| 3.58ms | 1.18% | 4.96ms | 1.64% | `sync.(*RWMutex).Unlock` |
| 0 | 0.00% | 295.74ms | 97.84% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAll` |
| 0 | 0.00% | 3.58ms | 1.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 3.58ms | 1.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 3.58ms | 1.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 3.58ms | 1.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 3.58ms | 1.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionMode (inline)` |
| 0 | 0.00% | 3.58ms | 1.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 3.58ms | 1.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCommandPublish (inline)` |
| 0 | 0.00% | 295.74ms | 97.84% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 295.74ms | 97.84% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 3.58ms | 1.18% | `github.com/snissn/gomap/TreeDB/caching.countCanonicalStableIteratorUnits` |
| 0 | 0.00% | 3.58ms | 1.18% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).NewIterator` |

### dataset_write_random (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_dataset_write_random_treedb.pprof`
- total samples: `602.99ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 501.53ms | 83.17% | 501.53ms | 83.17% | `runtime.selectgo` |
| 101.46ms | 16.83% | 101.46ms | 16.83% | `runtime.chanrecv1` |
| 0 | 0.00% | 501.53ms | 83.17% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 501.53ms | 83.17% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 100.94ms | 16.74% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.94ms | 16.74% | `runtime.traceStartReadCPU.func1` |

### dataset_write_random (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_dataset_write_random_treedb.pprof`
- total samples: `0`

_No entries parsed._

### dataset_write_sorted (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_dataset_write_sorted_treedb.pprof`
- total samples: `1658.56ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 957.82ms | 57.75% | 957.82ms | 57.75% | `runtime.selectgo` |
| 599.54ms | 36.15% | 599.54ms | 36.15% | `sync.(*WaitGroup).Wait` |
| 101.20ms | 6.10% | 101.20ms | 6.10% | `runtime.chanrecv1` |
| 0 | 0.00% | 500.04ms | 30.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 599.54ms | 36.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAll` |
| 0 | 0.00% | 599.54ms | 36.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked` |
| 0 | 0.00% | 599.54ms | 36.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 500.04ms | 30.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 599.54ms | 36.15% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 249.73ms | 15.06% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 249.73ms | 15.06% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 107.07ms | 6.46% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 100.97ms | 6.09% | `github.com/snissn/gomap/TreeDB/internal/rootpublication.(*Coordinator).run` |
| 0 | 0.00% | 100.97ms | 6.09% | `github.com/snissn/gomap/TreeDB/internal/rootpublication.New.gowrap1` |
| 0 | 0.00% | 100.63ms | 6.07% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.63ms | 6.07% | `runtime.traceStartReadCPU.func1` |

### dataset_write_sorted (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_dataset_write_sorted_treedb.pprof`
- total samples: `0`

_No entries parsed._

### full_scan (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_full_scan_treedb.pprof`
- total samples: `2301.59ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1899.32ms | 82.52% | 1899.32ms | 82.52% | `runtime.selectgo` |
| 402.27ms | 17.48% | 402.27ms | 17.48% | `runtime.chanrecv1` |
| 0 | 0.00% | 499.97ms | 21.72% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 400.24ms | 17.39% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 499.97ms | 21.72% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 400.24ms | 17.39% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 499.80ms | 21.72% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 499.80ms | 21.72% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 499.30ms | 21.69% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 401.69ms | 17.45% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 401.69ms | 17.45% | `runtime.traceStartReadCPU.func1` |

### full_scan (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_full_scan_treedb.pprof`
- total samples: `1.27us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1.27us | 100.00% | 1.27us | 100.00% | `runtime.unlock (inline)` |
| 0 | 0.00% | 1.27us | 100.00% | `runtime.gopreempt_m (inline)` |
| 0 | 0.00% | 1.27us | 100.00% | `runtime.goschedImpl` |
| 0 | 0.00% | 1.27us | 100.00% | `runtime.morestack` |
| 0 | 0.00% | 1.27us | 100.00% | `runtime.newstack` |
| 0 | 0.00% | 1.27us | 100.00% | `runtime.startm` |
| 0 | 0.00% | 1.27us | 100.00% | `runtime.wakep` |

### prefix_scan (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_prefix_scan_treedb.pprof`
- total samples: `301.83us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 301.83us | 100.00% | 301.83us | 100.00% | `runtime.chanrecv1` |
| 0 | 0.00% | 301.83us | 100.00% | `main.main` |
| 0 | 0.00% | 301.83us | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 301.83us | 100.00% | `main.runBenchmark.func47` |
| 0 | 0.00% | 301.83us | 100.00% | `main.runBenchmark.func48` |
| 0 | 0.00% | 301.83us | 100.00% | `runtime.main` |
| 0 | 0.00% | 301.83us | 100.00% | `runtime/pprof.StopCPUProfile` |

### prefix_scan (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_prefix_scan_treedb.pprof`
- total samples: `0`

_No entries parsed._

### random_delete (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_random_delete_treedb.pprof`
- total samples: `1000.48ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1000.04ms | 100.00% | 1000.04ms | 100.00% | `runtime.selectgo` |
| 0 | 0.00% | 500.94ms | 50.07% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 500.94ms | 50.07% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 248.92ms | 24.88% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 248.92ms | 24.88% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 250.18ms | 25.01% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |

### random_delete (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_random_delete_treedb.pprof`
- total samples: `0`

_No entries parsed._

### random_read (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_random_read_treedb.pprof`
- total samples: `700.14ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 598.91ms | 85.54% | 598.91ms | 85.54% | `runtime.selectgo` |
| 101.23ms | 14.46% | 101.23ms | 14.46% | `runtime.chanrecv1` |
| 0 | 0.00% | 99.66ms | 14.23% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 99.66ms | 14.23% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 249.08ms | 35.58% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 249.08ms | 35.58% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 250.16ms | 35.73% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 100.69ms | 14.38% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.69ms | 14.38% | `runtime.traceStartReadCPU.func1` |

### random_read (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_random_read_treedb.pprof`
- total samples: `210ns`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 210ns | 100.00% | 210ns | 100.00% | `runtime.unlock (inline)` |
| 0 | 0.00% | 210ns | 100.00% | `runtime.gopreempt_m (inline)` |
| 0 | 0.00% | 210ns | 100.00% | `runtime.goschedImpl` |
| 0 | 0.00% | 210ns | 100.00% | `runtime.morestack` |
| 0 | 0.00% | 210ns | 100.00% | `runtime.newstack` |
| 0 | 0.00% | 210ns | 100.00% | `runtime.startm` |
| 0 | 0.00% | 210ns | 100.00% | `runtime.wakep` |

### random_read_batch (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_random_read_batch_treedb.pprof`
- total samples: `151ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 100.93ms | 66.84% | 100.93ms | 66.84% | `runtime.chanrecv1` |
| 49.64ms | 32.87% | 49.64ms | 32.87% | `sync.(*WaitGroup).Wait` |
| 0 | 0.00% | 49.64ms | 32.87% | `github.com/snissn/gomap/TreeDB.(*DB).GetManyView` |
| 0 | 0.00% | 49.64ms | 32.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).GetManyView` |
| 0 | 0.00% | 49.64ms | 32.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).backendGetManyView` |
| 0 | 0.00% | 49.64ms | 32.87% | `github.com/snissn/gomap/TreeDB/db.(*DB).GetManyView` |
| 0 | 0.00% | 49.64ms | 32.87% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewOnce` |
| 0 | 0.00% | 49.64ms | 32.87% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel` |
| 0 | 0.00% | 49.64ms | 32.87% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).GetManyView` |
| 0 | 0.00% | 50.44ms | 33.40% | `main.main` |
| 0 | 0.00% | 50.44ms | 33.40% | `main.runBenchmark` |
| 0 | 0.00% | 49.64ms | 32.87% | `main.runBenchmark.func35` |
| 0 | 0.00% | 100.13ms | 66.31% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 50.44ms | 33.40% | `runtime.main` |
| 0 | 0.00% | 100.13ms | 66.31% | `runtime.traceStartReadCPU.func1` |

### random_read_batch (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_random_read_batch_treedb.pprof`
- total samples: `487.73us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 435.98us | 89.39% | 435.98us | 89.39% | `sync.(*Mutex).Unlock (partial-inline)` |
| 42.66us | 8.75% | 42.66us | 8.75% | `sync.(*RWMutex).Unlock` |
| 5.37us | 1.10% | 5.37us | 1.10% | `sync.(*RWMutex).RUnlock (inline)` |
| 3.71us | 0.76% | 3.71us | 0.76% | `runtime.unlock (inline)` |
| 0 | 0.00% | 487.30us | 99.91% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel.func3` |
| 0 | 0.00% | 484.02us | 99.24% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel.gowrap1` |
| 0 | 0.00% | 42.66us | 8.75% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).markPageChecksumVerified` |
| 0 | 0.00% | 5.37us | 1.10% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).ReleaseLeafLogPageView` |
| 0 | 0.00% | 435.98us | 89.39% | `github.com/snissn/gomap/TreeDB/db.(*valueReader).ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 42.66us | 8.75% | `github.com/snissn/gomap/TreeDB/db.valueReader.MarkLeafLogPageChecksumVerified` |
| 0 | 0.00% | 438.99us | 90.01% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 438.99us | 90.01% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadUnsafeTo` |
| 0 | 0.00% | 438.99us | 90.01% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |
| 0 | 0.00% | 168.41us | 34.53% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).maybeScheduleRemap` |
| 0 | 0.00% | 267.57us | 54.86% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).readAtWithDictTo` |
| 0 | 0.00% | 171.42us | 35.15% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).readViaMmapViewTo` |
| 0 | 0.00% | 109.32us | 22.41% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).releaseDecodeScratch` |
| 0 | 0.00% | 109.32us | 22.41% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).releaseDecodeScratch-fm` |
| 0 | 0.00% | 158.25us | 32.45% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).takeDecodeScratch` |
| 0 | 0.00% | 158.25us | 32.45% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).takeDecodeScratch-fm` |
| 0 | 0.00% | 438.99us | 90.01% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*Set).ReadUnsafeTo` |
| 0 | 0.00% | 267.57us | 54.86% | `github.com/snissn/gomap/TreeDB/internal/valuelog.readAtWithDictToScratch` |
| 0 | 0.00% | 487.30us | 99.91% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).GetManyView` |
| 0 | 0.00% | 481.65us | 98.75% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).loadLeafNodeForGetMany` |
| 0 | 0.00% | 42.66us | 8.75% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).markLeafLogPageChecksumVerified (inline)` |

### random_read_parallel (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_random_read_parallel_treedb.pprof`
- total samples: `208.04ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 114.32ms | 54.95% | 114.32ms | 54.95% | `runtime.chanrecv1` |
| 93.72ms | 45.05% | 93.72ms | 45.05% | `sync.(*WaitGroup).Wait` |
| 0 | 0.00% | 94.30ms | 45.33% | `main.main` |
| 0 | 0.00% | 94.30ms | 45.33% | `main.runBenchmark` |
| 0 | 0.00% | 93.72ms | 45.05% | `main.runBenchmark.func33` |
| 0 | 0.00% | 113.74ms | 54.67% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 94.30ms | 45.33% | `runtime.main` |
| 0 | 0.00% | 113.74ms | 54.67% | `runtime.traceStartReadCPU.func1` |

### random_read_parallel (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_random_read_parallel_treedb.pprof`
- total samples: `0`

_No entries parsed._

### random_read_parallel_acquire_snapshot (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `15918.18ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 10849.09ms | 68.16% | 10849.09ms | 68.16% | `runtime.selectgo` |
| 2404.93ms | 15.11% | 2404.93ms | 15.11% | `runtime.chanrecv1` |
| 1414.20ms | 8.88% | 1414.20ms | 8.88% | `sync.(*WaitGroup).Wait` |
| 1122.97ms | 7.05% | 1122.97ms | 7.05% | `sync.(*Mutex).Lock (inline)` |
| 126.92ms | 0.80% | 126.92ms | 0.80% | `sync.(*RWMutex).RLock (inline)` |
| 0.08ms | 0.00% | 672.10ms | 4.22% | `sync.(*RWMutex).Lock` |
| 0 | 0.00% | 728.92ms | 4.58% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 728.92ms | 4.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 1500.28ms | 9.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 1139.19ms | 7.16% | `github.com/snissn/gomap/TreeDB/caching.(*DB).foregroundVlogMaintenanceContextWithResumeGrace.func1` |
| 0 | 0.00% | 1139.19ms | 7.16% | `github.com/snissn/gomap/TreeDB/caching.(*DB).foregroundVlogMaintenanceContextWithResumeGrace.gowrap1` |
| 0 | 0.00% | 1398.72ms | 8.79% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 999.87ms | 6.28% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 1500.28ms | 9.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 1398.72ms | 8.79% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 1499.01ms | 9.42% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 1499.01ms | 9.42% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 728.86ms | 4.58% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 728.86ms | 4.58% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 728.86ms | 4.58% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 728.86ms | 4.58% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotWithValueLogPublicationLockHeld (inline)` |
| 0 | 0.00% | 464.03ms | 2.92% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).Close` |
| 0 | 0.00% | 464.03ms | 2.92% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead` |
| 0 | 0.00% | 464.03ms | 2.92% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead` |
| 0 | 0.00% | 2999.54ms | 18.84% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |

### random_read_parallel_acquire_snapshot (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `1194.90ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 899.32ms | 75.26% | 905.16ms | 75.75% | `sync.(*Mutex).Unlock (partial-inline)` |
| 168.13ms | 14.07% | 168.13ms | 14.07% | `runtime.unlock (inline)` |
| 126.89ms | 10.62% | 590.57ms | 49.42% | `sync.(*RWMutex).Unlock` |
| 0 | 0.00% | 617.38ms | 51.67% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 617.38ms | 51.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 130.67ms | 10.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeRunPeriodicVlogGenerationMaintenance` |
| 0 | 0.00% | 130.67ms | 10.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeRunVlogGenerationMaintenance (inline)` |
| 0 | 0.00% | 130.67ms | 10.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeRunVlogGenerationMaintenanceWithOptions` |
| 0 | 0.00% | 129.35ms | 10.82% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeRunVlogGenerationMaintenanceWithOptions.func3` |
| 0 | 0.00% | 124.91ms | 10.45% | `github.com/snissn/gomap/TreeDB/caching.(*DB).runVlogGenerationLeafGC` |
| 0 | 0.00% | 130.67ms | 10.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).runWithBackendMaintenanceOptions` |
| 0 | 0.00% | 130.55ms | 10.93% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 130.67ms | 10.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 617.38ms | 51.67% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 124.91ms | 10.45% | `github.com/snissn/gomap/TreeDB/db.(*DB).LeafGenerationGC` |
| 0 | 0.00% | 617.38ms | 51.67% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 479.76ms | 40.15% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 479.76ms | 40.15% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotWithValueLogPublicationLockHeld (inline)` |
| 0 | 0.00% | 124.77ms | 10.44% | `github.com/snissn/gomap/TreeDB/db.(*DB).gcLeafManifestRevisions` |
| 0 | 0.00% | 124.77ms | 10.44% | `github.com/snissn/gomap/TreeDB/db.(*DB).gcLeafManifestRevisions.deferwrap4` |
| 0 | 0.00% | 124.91ms | 10.45% | `github.com/snissn/gomap/TreeDB/db.(*DB).leafGenerationGC` |

### random_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_random_write_treedb.pprof`
- total samples: `101.49ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 101.49ms | 100.00% | 101.49ms | 100.00% | `runtime.chanrecv1` |
| 0 | 0.00% | 100.98ms | 99.50% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.98ms | 99.50% | `runtime.traceStartReadCPU.func1` |

### random_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_random_write_treedb.pprof`
- total samples: `0`

_No entries parsed._

### sequential_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block_sequential_write_treedb.pprof`
- total samples: `27.41ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 26.74ms | 97.56% | 26.74ms | 97.56% | `runtime.selectgo` |
| 0.67ms | 2.44% | 0.67ms | 2.44% | `runtime.chanrecv1` |
| 0 | 0.00% | 26.55ms | 96.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureVlogDictPrepWorkers.gowrap1` |
| 0 | 0.00% | 26.55ms | 96.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop` |

### sequential_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex_sequential_write_treedb.pprof`
- total samples: `76.11us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 76.11us | 100.00% | 76.11us | 100.00% | `runtime.unlock (inline)` |
| 0 | 0.00% | 66.16us | 86.92% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 66.16us | 86.92% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 66.16us | 86.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetPointWithMVCCInput` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func5` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionMode (inline)` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCommandPublish (inline)` |
| 0 | 0.00% | 66.16us | 86.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` |
| 0 | 0.00% | 66.16us | 86.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).writeCanonicalFlushRunOpsChunk` |
| 0 | 0.00% | 66.16us | 86.92% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/db.(*Batch).Write` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/db.(*Batch).write` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/db.(*DB).storeLeafPageReadCache (inline)` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/db.(*RootPublicationBuildGroup).applyBatchLocked` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/db.(*RootPublicationBuildGroup).writeBatch` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/db.(*leafPageLogWithRecordLengthHints).AppendPreparedLeafPageChildRefs` |
| 0 | 0.00% | 9.95us | 13.08% | `github.com/snissn/gomap/TreeDB/db.(*leafPageLogWithRecordLengthHints).noteLeafPagePointer` |

## Contention Profiles (Global)

### block

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/block.pprof`
- total samples: `216.12s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 151.44s | 70.07% | 151.44s | 70.07% | `runtime.selectgo` |
| 41.05s | 19.00% | 41.05s | 19.00% | `runtime.chanrecv2` |
| 15.93s | 7.37% | 15.93s | 7.37% | `runtime.chanrecv1` |
| 4.46s | 2.06% | 4.46s | 2.06% | `sync.(*WaitGroup).Wait` |
| 3.09s | 1.43% | 3.09s | 1.43% | `sync.(*Mutex).Lock (partial-inline)` |
| 0 | 0.00% | 7.65s | 3.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 29.91s | 13.84% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureVlogDictPrepWorkers.gowrap1` |
| 0 | 0.00% | 7.88s | 3.64% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 5.73s | 2.65% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 7.15s | 3.31% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 6.01s | 2.78% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 42.70s | 19.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogWriter.gowrap1` |
| 0 | 0.00% | 7.65s | 3.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 29.91s | 13.84% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop` |

### mutex

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/mutex.pprof`
- total samples: `3184.65ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2878.71ms | 90.39% | 2884.55ms | 90.58% | `sync.(*Mutex).Unlock (partial-inline)` |
| 170.54ms | 5.36% | 170.54ms | 5.36% | `runtime.unlock (inline)` |
| 132.83ms | 4.17% | 765.89ms | 24.05% | `sync.(*RWMutex).Unlock` |
| 0 | 0.00% | 617.38ms | 19.39% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 617.38ms | 19.39% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 295.74ms | 9.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAll` |
| 0 | 0.00% | 348.47ms | 10.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 1506.38ms | 47.30% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 1506.38ms | 47.30% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 1502.80ms | 47.19% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4` |
| 0 | 0.00% | 1506.38ms | 47.30% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 1157.91ms | 36.36% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCheckpointFrontierLocked.func1` |
| 0 | 0.00% | 348.47ms | 10.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionMode (inline)` |
| 0 | 0.00% | 1506.38ms | 47.30% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 348.47ms | 10.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCommandPublish (inline)` |
| 0 | 0.00% | 295.74ms | 9.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 130.67ms | 4.10% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeRunPeriodicVlogGenerationMaintenance` |
| 0 | 0.00% | 130.67ms | 4.10% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeRunVlogGenerationMaintenance (inline)` |
| 0 | 0.00% | 130.67ms | 4.10% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeRunVlogGenerationMaintenanceWithOptions` |
| 0 | 0.00% | 129.35ms | 4.06% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeRunVlogGenerationMaintenanceWithOptions.func3` |
| 0 | 0.00% | 124.91ms | 3.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).runVlogGenerationLeafGC` |
| 0 | 0.00% | 130.67ms | 4.10% | `github.com/snissn/gomap/TreeDB/caching.(*DB).runWithBackendMaintenanceOptions` |
| 0 | 0.00% | 130.55ms | 4.10% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 130.67ms | 4.10% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 1502.80ms | 47.19% | `github.com/snissn/gomap/TreeDB/caching.(*DB).writeCanonicalFlushRunOpsChunk` |

## TreeDB Stats Metadata

### keys=200000 / TreeDB

| stat | value |
|---|---:|
| `treedb.applied_command_lsn` | `0` |
| `treedb.cache.append_only.entry_hint_capacity_bytes` | `4850304` |
| `treedb.cache.append_only.entry_hint_entries` | `50524` |
| `treedb.cache.append_only.entry_pool_admission_drop_bytes_total` | `75452608` |
| `treedb.cache.append_only.entry_pool_admission_drops_total` | `5` |
| `treedb.cache.append_only.entry_pool_drop_bytes_total` | `266945184` |
| `treedb.cache.append_only.entry_pool_drops_total` | `1` |
| `treedb.cache.append_only.entry_pool_gets_total` | `35` |
| `treedb.cache.append_only.entry_pool_puts_total` | `227` |
| `treedb.cache.append_only.entry_pool_retained_bytes_estimate` | `186001904` |
| `treedb.cache.append_only.entry_pool_retained_bytes_max_estimate` | `266945184` |
| `treedb.cache.append_only.mem_lease_count` | `8` |
| `treedb.cache.append_only.mem_lease_entry_backing_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_entry_capacity` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_active_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_active_chunks` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_retained_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_retained_chunks` | `0` |
| `treedb.cache.append_only.mutable_count` | `16` |
| `treedb.cache.append_only.mutable_entry_backing_bytes` | `0` |
| `treedb.cache.append_only.mutable_entry_capacity` | `0` |
| `treedb.cache.append_only.mutable_from_lease_total` | `56` |
| `treedb.cache.append_only.mutable_from_pool_total` | `0` |
| `treedb.cache.append_only.mutable_new_alloc_queue_bytes_sum` | `502792240` |
| `treedb.cache.append_only.mutable_new_alloc_total` | `24` |
| `treedb.cache.append_only.mutable_new_alloc_with_queue_total` | `24` |
| `treedb.cache.append_only.mutable_pool_drops_total` | `0` |
| `treedb.cache.append_only.mutable_pool_entry_backing_dropped_bytes_total` | `0` |
| `treedb.cache.append_only.mutable_pool_puts_total` | `16` |
| `treedb.cache.append_only.mutable_sparse_trim_dropped_bytes_total` | `155056` |
| `treedb.cache.append_only.mutable_sparse_trim_total` | `10` |
| `treedb.cache.append_only.mutable_trim_dropped_bytes_total` | `5182848` |
| `treedb.cache.append_only.mutable_trim_total` | `58` |
| `treedb.cache.append_only.mutable_value_arena_active_bytes` | `0` |
| `treedb.cache.append_only.mutable_value_arena_active_chunks` | `0` |
| `treedb.cache.append_only.mutable_value_arena_retained_bytes` | `0` |
| `treedb.cache.append_only.mutable_value_arena_retained_chunks` | `0` |
| `treedb.cache.append_only.reserve.calls_total` | `132` |
| `treedb.cache.append_only.reserve.entries_total` | `60896` |
| `treedb.cache.append_only.reserve.grow_bytes_total` | `272375664` |
| `treedb.cache.append_only.reserve.grow_calls_total` | `132` |
| `treedb.cache.append_only.reserve.skipped_growth_allocs_total` | `21` |
| `treedb.cache.append_only.reserve.skipped_growth_bytes_total` | `405504` |
| `treedb.cache.append_only.value_arena_pool_admission_drop_bytes_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_admission_drops_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_drop_bytes_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_drops_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_gets_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_puts_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_retained_bytes_estimate` | `0` |
| `treedb.cache.append_only.value_arena_pool_retained_bytes_max_estimate` | `0` |
| `treedb.cache.auto_checkpoint.count` | `0` |
| `treedb.cache.auto_checkpoint.last_reason` | `interval` |
| `treedb.cache.backpressure_mode` | `adaptive` |
| `treedb.cache.checkpoint.active` | `false` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_last` | `0` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_max` | `295773110` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_total` | `295773110` |
| `treedb.cache.checkpoint.active_background_flush_wait_samples` | `1` |
| `treedb.cache.checkpoint.auto_vacuum_last_internal_fill_avg_ppm` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_last_internal_fill_p50_ppm` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_last_pages` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_runs` | `0` |
| `treedb.cache.checkpoint.barrier_wait_ns_max` | `295773130` |
| `treedb.cache.checkpoint.barrier_wait_ns_total` | `295774038` |
| `treedb.cache.checkpoint.barrier_wait_samples` | `3` |
| `treedb.cache.checkpoint.cutover_avg_ms` | `0.654` |
| `treedb.cache.checkpoint.cutover_last_ms` | `0.001` |
| `treedb.cache.checkpoint.cutover_last_unix_nano` | `1795198119167404226` |
| `treedb.cache.checkpoint.cutover_max_ms` | `1.874` |
| `treedb.cache.checkpoint.cutover_samples` | `3` |
| `treedb.cache.checkpoint.debt.active_in_flight_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt.active_in_flight_bytes_max` | `67153760` |
| `treedb.cache.checkpoint.debt.active_workers_last` | `0` |
| `treedb.cache.checkpoint.debt.active_workers_max` | `1` |
| `treedb.cache.checkpoint.debt.frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.debt.frontier_lanes_max` | `1` |
| `treedb.cache.checkpoint.debt.mutable_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt.mutable_bytes_max` | `57600000` |
| `treedb.cache.checkpoint.debt.queue_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt.queue_bytes_max` | `67153760` |
| `treedb.cache.checkpoint.debt.queue_units_last` | `0` |
| `treedb.cache.checkpoint.debt.queue_units_max` | `16` |
| `treedb.cache.checkpoint.debt_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt_bytes_max` | `88913760` |
| `treedb.cache.checkpoint.debt_memtables_last` | `0` |
| `treedb.cache.checkpoint.debt_memtables_max` | `17` |
| `treedb.cache.checkpoint.flush_all.background_drain_bytes_last` | `0` |
| `treedb.cache.checkpoint.flush_all.background_drain_ops_last` | `0` |
| `treedb.cache.checkpoint.flush_all.background_drain_units_last` | `0` |
| `treedb.cache.checkpoint.flush_all.frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.flush_all.frontier_lanes_max` | `1` |
| `treedb.cache.checkpoint.flush_all.owned_drain_bytes_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_bytes_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.flush_all.owned_drain_ns_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_ops_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_units_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_units_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.flush_all.worker_passes_total` | `2` |
| `treedb.cache.checkpoint.flush_all.workers_last` | `0` |
| `treedb.cache.checkpoint.flush_all.workers_max` | `1` |
| `treedb.cache.checkpoint.flush_all.workers_total` | `2` |
| `treedb.cache.checkpoint.flush_preempt_requests_total` | `3` |
| `treedb.cache.checkpoint.flushmu_wait_max_ms` | `295.773` |
| `treedb.cache.checkpoint.flushmu_wait_total_ms` | `295.774` |
| `treedb.cache.checkpoint.frontier.bytes_last` | `57600000` |
| `treedb.cache.checkpoint.frontier.bytes_max` | `57600000` |
| `treedb.cache.checkpoint.frontier.drained_bytes_last` | `57600000` |
| `treedb.cache.checkpoint.frontier.drained_units_last` | `16` |
| `treedb.cache.checkpoint.frontier.post_bytes_last` | `0` |
| `treedb.cache.checkpoint.frontier.post_bytes_max` | `0` |
| `treedb.cache.checkpoint.frontier.post_units_last` | `0` |
| `treedb.cache.checkpoint.frontier.post_units_max` | `0` |
| `treedb.cache.checkpoint.frontier.samples` | `2` |
| `treedb.cache.checkpoint.frontier.units_last` | `16` |
| `treedb.cache.checkpoint.frontier.units_max` | `16` |
| `treedb.cache.checkpoint.max_ms` | `1517.140` |
| `treedb.cache.checkpoint.noop_skips` | `1` |
| `treedb.cache.checkpoint.post_frontier_admission.active` | `false` |
| `treedb.cache.checkpoint.post_frontier_admission_enabled` | `false` |
| `treedb.cache.checkpoint.preflush_kick_skips_total` | `2` |
| `treedb.cache.checkpoint.productive_wait_ratio_last` | `0.000000` |
| `treedb.cache.checkpoint.runs` | `3` |
| `treedb.cache.checkpoint.shared_drain.background_bytes_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.background_ops_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.background_units_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_bytes_total` | `79360000` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_ops_total` | `960000` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_units_total` | `32` |
| `treedb.cache.checkpoint.shared_drain.flushmu_releases_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.wait_ns_max` | `0` |
| `treedb.cache.checkpoint.shared_drain.wait_ns_total` | `0` |
| `treedb.cache.checkpoint.stage.auto_critical_section.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.auto_critical_section.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.auto_critical_section.samples` | `0` |
| `treedb.cache.checkpoint.stage.auto_critical_section.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.backend_boundary.last_ns` | `3472` |
| `treedb.cache.checkpoint.stage.backend_boundary.max_ns` | `27227181` |
| `treedb.cache.checkpoint.stage.backend_boundary.samples` | `3` |
| `treedb.cache.checkpoint.stage.backend_boundary.total_ns` | `50884504` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.samples` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.samples` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.samples` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_publish.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_publish.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_publish.samples` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_publish.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.cutover.last_ns` | `654` |
| `treedb.cache.checkpoint.stage.cutover.max_ns` | `1873541` |
| `treedb.cache.checkpoint.stage.cutover.samples` | `3` |
| `treedb.cache.checkpoint.stage.cutover.total_ns` | `1962780` |
| `treedb.cache.checkpoint.stage.flush_all.last_ns` | `1489678690` |
| `treedb.cache.checkpoint.stage.flush_all.max_ns` | `1489678690` |
| `treedb.cache.checkpoint.stage.flush_all.samples` | `2` |
| `treedb.cache.checkpoint.stage.flush_all.total_ns` | `1571724198` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.last_ns` | `19396716` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.max_ns` | `19396716` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.samples` | `2` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.total_ns` | `19715184` |
| `treedb.cache.checkpoint.stage.post_maintenance.last_ns` | `101024` |
| `treedb.cache.checkpoint.stage.post_maintenance.max_ns` | `150549` |
| `treedb.cache.checkpoint.stage.post_maintenance.samples` | `2` |
| `treedb.cache.checkpoint.stage.post_maintenance.total_ns` | `251573` |
| `treedb.cache.checkpoint.stage.reducer_publish.last_ns` | `936887` |
| `treedb.cache.checkpoint.stage.reducer_publish.max_ns` | `1891125` |
| `treedb.cache.checkpoint.stage.reducer_publish.samples` | `2` |
| `treedb.cache.checkpoint.stage.reducer_publish.total_ns` | `2828012` |
| `treedb.cache.checkpoint.stage.value_log_flush.last_ns` | `442` |
| `treedb.cache.checkpoint.stage.value_log_flush.max_ns` | `648` |
| `treedb.cache.checkpoint.stage.value_log_flush.samples` | `2` |
| `treedb.cache.checkpoint.stage.value_log_flush.total_ns` | `1090` |
| `treedb.cache.checkpoint.stage.wal_cleanup.last_ns` | `413` |
| `treedb.cache.checkpoint.stage.wal_cleanup.max_ns` | `1145` |
| `treedb.cache.checkpoint.stage.wal_cleanup.samples` | `2` |
| `treedb.cache.checkpoint.stage.wal_cleanup.total_ns` | `1558` |
| `treedb.cache.checkpoint.stage.wal_rotate.last_ns` | `89` |
| `treedb.cache.checkpoint.stage.wal_rotate.max_ns` | `89` |
| `treedb.cache.checkpoint.stage.wal_rotate.samples` | `2` |
| `treedb.cache.checkpoint.stage.wal_rotate.total_ns` | `125` |
| `treedb.cache.checkpoint.total_ms` | `1924.370` |
| `treedb.cache.checkpoint.wait.active_in_flight_bytes_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.active_workers_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_bytes_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_units_last` | `0` |
| `treedb.cache.checkpoint.wait.frontier_bytes_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.frontier_drain_bytes_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.wait.frontier_drain_units_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.wait.frontier_lanes_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.frontier_units_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.post_frontier_bytes_last` | `0` |
| `treedb.cache.checkpoint.wait.post_frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.wait.post_frontier_units_last` | `0` |
| `treedb.cache.checkpoint.wait.remaining_frontier_bytes_last` | `0` |
| `treedb.cache.checkpoint.wait.remaining_frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.wait.remaining_frontier_units_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.considered_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.removed_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_current_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_pre_rotate_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_retained_last` | `0` |
| `treedb.cache.checkpoint.write_cutover.active` | `false` |
| `treedb.cache.command_wal.checkpoint_publish.piggybacked` | `0` |
| `treedb.cache.command_wal.checkpoint_publish.separate` | `0` |
| `treedb.cache.command_wal.cleanup.active` | `false` |
| `treedb.cache.command_wal.cleanup.coalesced_total` | `0` |
| `treedb.cache.command_wal.cleanup.completions_total` | `0` |
| `treedb.cache.command_wal.cleanup.pending` | `false` |
| `treedb.cache.command_wal.cleanup.requests_total` | `0` |
| `treedb.cache.command_wal.cleanup.retries_total` | `0` |
| `treedb.cache.command_wal.external_durability` | `false` |
| `treedb.cache.flush_apply.backend_batch_write_ns_total` | `1632739415` |
| `treedb.cache.flush_apply.backend_write_ns_total` | `2106614749` |
| `treedb.cache.flush_apply.batches_total` | `5` |
| `treedb.cache.flush_apply.build_ns_total` | `383670976` |
| `treedb.cache.flush_apply.bytes_total` | `230400000` |
| `treedb.cache.flush_apply.concurrency` | `6` |
| `treedb.cache.flush_apply.coordinator.active` | `0` |
| `treedb.cache.flush_apply.coordinator.active_assist_skips_total` | `0` |
| `treedb.cache.flush_apply.coordinator.active_workers` | `0` |
| `treedb.cache.flush_apply.coordinator.blocking_fallbacks_total` | `0` |
| `treedb.cache.flush_apply.coordinator.checkpoint_preemptions_total` | `0` |
| `treedb.cache.flush_apply.coordinator.errors_total` | `0` |
| `treedb.cache.flush_apply.coordinator.hard_overload_fallbacks_total` | `0` |
| `treedb.cache.flush_apply.coordinator.in_flight_bytes` | `0` |
| `treedb.cache.flush_apply.coordinator.progress_total` | `5` |
| `treedb.cache.flush_apply.coordinator.progress_wait_ns_total` | `0` |
| `treedb.cache.flush_apply.coordinator.progress_waits_total` | `0` |
| `treedb.cache.flush_apply.coordinator.stall_waits_total` | `0` |
| `treedb.cache.flush_apply.deferred_vlog_pointer_materialize_ns_total` | `13122` |
| `treedb.cache.flush_apply.entries_total` | `2000000` |
| `treedb.cache.flush_apply.foreground_assist_calls_total` | `0` |
| `treedb.cache.flush_apply.foreground_assist_flushes_total` | `0` |
| `treedb.cache.flush_apply.foreground_assist_wait_ns_total` | `0` |
| `treedb.cache.flush_apply.leaf_log_append_bytes_total` | `39182103` |
| `treedb.cache.flush_apply.leaf_log_append_frames_per_op` | `0.022186` |
| `treedb.cache.flush_apply.leaf_log_append_frames_total` | `44372` |
| `treedb.cache.flush_apply.leaf_log_append_ns_total` | `339305286` |
| `treedb.cache.flush_apply.leaf_log_append_records_total` | `86877` |
| `treedb.cache.flush_apply.leaf_log_append_wait_ns_total` | `20099036` |
| `treedb.cache.flush_apply.leaf_log_encode_compress_ns_total` | `103146697` |
| `treedb.cache.flush_apply.planning_ns_total` | `31221` |
| `treedb.cache.flush_apply.span_native` | `true` |
| `treedb.cache.flush_apply.units_total` | `80` |
| `treedb.cache.flush_apply.vlog_flush_ns_total` | `9484` |
| `treedb.cache.flush_apply.vlog_sync_ns_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_runs_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.admitted_runs_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.base_budget_covered_total` | `2` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_bytes_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_memtables_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_ops_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.decisions_total` | `5` |
| `treedb.cache.flush_backlog_coalescing.enabled` | `true` |
| `treedb.cache.flush_backlog_coalescing.last_old_leaf_bytes_per_op` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.last_ops_per_span` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.last_single_op_span_ratio` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.queued_age_ns_max` | `1883087` |
| `treedb.cache.flush_backlog_coalescing.queued_bytes_max` | `67153760` |
| `treedb.cache.flush_backlog_coalescing.queued_memtables_max` | `16` |
| `treedb.cache.flush_backlog_coalescing.selected_bytes_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_memtables_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_ops_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.checkpoint_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.close_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.disabled_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.lane_barrier_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.memory_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.memtable_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.no_pressure_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.ops_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.queue_age_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.queue_depth_total` | `5` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.range_barrier_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.stop_pressure_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.writer_stall_budget_total` | `0` |
| `treedb.cache.flush_span_run.backend_chunks_total` | `76` |
| `treedb.cache.flush_span_run.max_chunks_per_target_leaf` | `0` |
| `treedb.cache.flush_span_run.ops_per_run` | `302881.200000` |
| `treedb.cache.flush_span_run.planned_ops_total` | `1514406` |
| `treedb.cache.flush_span_run.planned_point_ops_total` | `1514406` |
| `treedb.cache.flush_span_run.range_barriers_total` | `0` |
| `treedb.cache.flush_span_run.range_delete_ops_total` | `0` |
| `treedb.cache.flush_span_run.runs_total` | `5` |
| `treedb.cache.flush_span_run.shadowed_ops_total` | `0` |
| `treedb.cache.flush_span_run.single_op_spans_total` | `0` |
| `treedb.cache.flush_span_run.source_memtables_max` | `16` |
| `treedb.cache.flush_span_run.source_memtables_total` | `80` |
| `treedb.cache.flush_span_run.source_point_ops_total` | `2000000` |
| `treedb.cache.flush_span_run.span_bytes_total` | `0` |
| `treedb.cache.flush_span_run.span_ops_total` | `0` |
| `treedb.cache.flush_span_run.target_leaf_spans_total` | `0` |
| `treedb.cache.flush_span_run.target_leaves_split_across_chunks_total` | `0` |
| `treedb.cache.leaf_log_lanes.active` | `7` |
| `treedb.cache.leaf_log_lanes.append_bytes_total` | `39182103` |
| `treedb.cache.leaf_log_lanes.append_calls_total` | `41088` |
| `treedb.cache.leaf_log_lanes.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.append_lanes_used` | `7` |
| `treedb.cache.leaf_log_lanes.append_lock_hold_ns_total` | `191055348` |
| `treedb.cache.leaf_log_lanes.append_lock_wait_ns_total` | `20099036` |
| `treedb.cache.leaf_log_lanes.append_pages_total` | `86877` |
| `treedb.cache.leaf_log_lanes.configured` | `7` |
| `treedb.cache.leaf_log_lanes.lane.00.append_bytes_total` | `15589551` |
| `treedb.cache.leaf_log_lanes.lane.00.append_calls_total` | `18917` |
| `treedb.cache.leaf_log_lanes.lane.00.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.00.append_lock_hold_ns_total` | `19741086` |
| `treedb.cache.leaf_log_lanes.lane.00.append_lock_wait_ns_total` | `19307929` |
| `treedb.cache.leaf_log_lanes.lane.00.append_pages_total` | `40027` |
| `treedb.cache.leaf_log_lanes.lane.00.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.00.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.00.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.00.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.append_bytes_total` | `3895563` |
| `treedb.cache.leaf_log_lanes.lane.01.append_calls_total` | `3933` |
| `treedb.cache.leaf_log_lanes.lane.01.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.append_lock_hold_ns_total` | `29020275` |
| `treedb.cache.leaf_log_lanes.lane.01.append_lock_wait_ns_total` | `127601` |
| `treedb.cache.leaf_log_lanes.lane.01.append_pages_total` | `8057` |
| `treedb.cache.leaf_log_lanes.lane.01.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.01.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.01.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.append_bytes_total` | `4006322` |
| `treedb.cache.leaf_log_lanes.lane.02.append_calls_total` | `3944` |
| `treedb.cache.leaf_log_lanes.lane.02.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.append_lock_hold_ns_total` | `29401907` |
| `treedb.cache.leaf_log_lanes.lane.02.append_lock_wait_ns_total` | `114693` |
| `treedb.cache.leaf_log_lanes.lane.02.append_pages_total` | `8005` |
| `treedb.cache.leaf_log_lanes.lane.02.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.02.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.02.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.append_bytes_total` | `4073970` |
| `treedb.cache.leaf_log_lanes.lane.03.append_calls_total` | `3980` |
| `treedb.cache.leaf_log_lanes.lane.03.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.append_lock_hold_ns_total` | `25691085` |
| `treedb.cache.leaf_log_lanes.lane.03.append_lock_wait_ns_total` | `130805` |
| `treedb.cache.leaf_log_lanes.lane.03.append_pages_total` | `8083` |
| `treedb.cache.leaf_log_lanes.lane.03.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.03.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.03.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.append_bytes_total` | `4075366` |
| `treedb.cache.leaf_log_lanes.lane.04.append_calls_total` | `3985` |
| `treedb.cache.leaf_log_lanes.lane.04.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.append_lock_hold_ns_total` | `28895942` |
| `treedb.cache.leaf_log_lanes.lane.04.append_lock_wait_ns_total` | `215591` |
| `treedb.cache.leaf_log_lanes.lane.04.append_pages_total` | `8068` |
| `treedb.cache.leaf_log_lanes.lane.04.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.04.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.04.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.append_bytes_total` | `3787835` |
| `treedb.cache.leaf_log_lanes.lane.05.append_calls_total` | `3282` |
| `treedb.cache.leaf_log_lanes.lane.05.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.append_lock_hold_ns_total` | `30151421` |
| `treedb.cache.leaf_log_lanes.lane.05.append_lock_wait_ns_total` | `100546` |
| `treedb.cache.leaf_log_lanes.lane.05.append_pages_total` | `7371` |
| `treedb.cache.leaf_log_lanes.lane.05.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.05.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.05.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.append_bytes_total` | `3753496` |
| `treedb.cache.leaf_log_lanes.lane.06.append_calls_total` | `3047` |
| `treedb.cache.leaf_log_lanes.lane.06.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.append_lock_hold_ns_total` | `28153632` |
| `treedb.cache.leaf_log_lanes.lane.06.append_lock_wait_ns_total` | `101871` |
| `treedb.cache.leaf_log_lanes.lane.06.append_pages_total` | `7266` |
| `treedb.cache.leaf_log_lanes.lane.06.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.06.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.06.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.segment_rotations_total` | `7` |
| `treedb.cache.memtable_mode` | `append_only` |
| `treedb.cache.memtable_residency.mutable.append_only.count` | `16` |
| `treedb.cache.memtable_residency.mutable.append_only.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.count` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.count` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.count` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.total.count` | `16` |
| `treedb.cache.memtable_residency.mutable.total.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.total.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.total.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.count` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entries` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.btree.count` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entries` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.btree.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.count` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entries` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.count` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entries` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.total.count` | `0` |
| `treedb.cache.memtable_residency.queue.total.entries` | `0` |
| `treedb.cache.memtable_residency.queue.total.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.total.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_retained_chunks` | `0` |
| `treedb.cache.queue_backlog_bytes` | `0` |
| `treedb.cache.queue_laneid_misses` | `0` |
| `treedb.cache.queue_len` | `0` |
| `treedb.cache.stats.backend_write_batches_total` | `76` |
| `treedb.cache.vlog_auto.bypass_bytes` | `0` |
| `treedb.cache.vlog_auto.bytes.block_lz4` | `305885906` |
| `treedb.cache.vlog_auto.bytes.block_snappy` | `0` |
| `treedb.cache.vlog_auto.bytes.block_zstd` | `0` |
| `treedb.cache.vlog_auto.bytes.dict` | `0` |
| `treedb.cache.vlog_auto.bytes.off` | `0` |
| `treedb.cache.vlog_auto.frames.block_lz4` | `44372` |
| `treedb.cache.vlog_auto.frames.block_snappy` | `0` |
| `treedb.cache.vlog_auto.frames.block_zstd` | `0` |
| `treedb.cache.vlog_auto.frames.dict` | `0` |
| `treedb.cache.vlog_auto.frames.off` | `0` |
| `treedb.cache.vlog_auto.frames_frac.block_lz4` | `1.000000` |
| `treedb.cache.vlog_auto.hold_enters` | `0` |
| `treedb.cache.vlog_auto.hold_exits` | `0` |
| `treedb.cache.vlog_auto.probe_attempts` | `0` |
| `treedb.cache.vlog_auto.probe_successes` | `0` |
| `treedb.cache.vlog_autotune.encode_ns_per_raw_byte` | `0.731` |
| `treedb.cache.vlog_autotune.io_ns_per_stored_byte` | `9.507` |
| `treedb.cache.vlog_autotune.observed_ratio` | `0.079241` |
| `treedb.cache.vlog_autotune.throughput_raw_MBps` | `1343.589` |
| `treedb.cache.vlog_block.k.avg.lz4` | `1.958` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_1` | `29109` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_2` | `5233` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_4` | `6559` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_8` | `3471` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_1` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_2` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_4` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_8` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_1` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_2` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_4` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_8` | `0` |
| `treedb.cache.vlog_block.k.count.lz4` | `44372` |
| `treedb.cache.vlog_block.k.count.snappy` | `0` |
| `treedb.cache.vlog_block.k.count.zstd` | `0` |
| `treedb.cache.vlog_block.k.max.lz4` | `8` |
| `treedb.cache.vlog_block.k.max.snappy` | `0` |
| `treedb.cache.vlog_block.k.max.zstd` | `0` |
| `treedb.cache.vlog_block.ratio.lz4` | `0.119463` |
| `treedb.cache.vlog_block.ratio.samples.lz4` | `0` |
| `treedb.cache.vlog_block.ratio.samples.snappy` | `0` |
| `treedb.cache.vlog_block.ratio.samples.zstd` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.capacity_waste_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.copied_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_fit_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_fit_requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_present_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_current_mmap_direct_decode.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_current_mmap_direct_decode.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_fit_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_fit_requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_present_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_template_encoded_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_template_encoded_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.realloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retain_max_bytes` | `131072` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_buffers` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_bytes` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_files` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.spare_max_count` | `2` |
| `treedb.cache.vlog_decode_scratch.large_pool.alloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.entries` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.gets_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.hits_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.max_entries` | `8` |
| `treedb.cache.vlog_decode_scratch.large_pool.misses_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.puts_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.retained_buffers` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.retained_bytes` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.too_small_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.alloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.alloc_calls_total` | `112` |
| `treedb.cache.vlog_decode_scratch.small_pool.allocated_bytes_total` | `3443096` |
| `treedb.cache.vlog_decode_scratch.small_pool.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.entries` | `9` |
| `treedb.cache.vlog_decode_scratch.small_pool.gets_total` | `42240` |
| `treedb.cache.vlog_decode_scratch.small_pool.hits_total` | `42128` |
| `treedb.cache.vlog_decode_scratch.small_pool.max_entries` | `128` |
| `treedb.cache.vlog_decode_scratch.small_pool.misses_total` | `112` |
| `treedb.cache.vlog_decode_scratch.small_pool.puts_total` | `42219` |
| `treedb.cache.vlog_decode_scratch.small_pool.retained_buffers` | `9` |
| `treedb.cache.vlog_decode_scratch.small_pool.retained_bytes` | `293427` |
| `treedb.cache.vlog_decode_scratch.small_pool.too_small_total` | `82` |
| `treedb.cache.vlog_dict.attempted_frac` | `1.000000` |
| `treedb.cache.vlog_dict.cached_dict_bytes` | `0` |
| `treedb.cache.vlog_dict.cached_dict_id` | `0` |
| `treedb.cache.vlog_dict.classifier.sampled` | `0` |
| `treedb.cache.vlog_dict.classifier.skipped` | `0` |
| `treedb.cache.vlog_dict.current_k` | `0` |
| `treedb.cache.vlog_dict.frames_attempted` | `44372` |
| `treedb.cache.vlog_dict.frames_kept` | `44372` |
| `treedb.cache.vlog_dict.frames_total` | `44372` |
| `treedb.cache.vlog_dict.incompressible_bypass_bytes` | `0` |
| `treedb.cache.vlog_dict.incompressible_hits` | `0` |
| `treedb.cache.vlog_dict.incompressible_hold_remaining_bytes` | `0` |
| `treedb.cache.vlog_dict.incompressible_holds` | `0` |
| `treedb.cache.vlog_dict.kept_frac` | `1.000000` |
| `treedb.cache.vlog_dict.last_applied_dict_hash` | `0` |
| `treedb.cache.vlog_dict.last_applied_dict_id` | `0` |
| `treedb.cache.vlog_dict.last_k_update_unix_nano` | `0` |
| `treedb.cache.vlog_dict.last_publish_unix_nano` | `0` |
| `treedb.cache.vlog_dict.pause_remaining_bytes` | `0` |
| `treedb.cache.vlog_dict.trainer.last_accept_unix_nano` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_accepts` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_attempts` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_reject_reason` | `` |
| `treedb.cache.vlog_dict.trainer.profile_rejects` | `0` |
| `treedb.cache.vlog_generation.bytes.live.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.live.hot` | `39182103` |
| `treedb.cache.vlog_generation.bytes.live.total` | `39182103` |
| `treedb.cache.vlog_generation.bytes.live.warm` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.hot` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.total` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.warm` | `0` |
| `treedb.cache.vlog_generation.bytes.total.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.total.hot` | `39182103` |
| `treedb.cache.vlog_generation.bytes.total.total` | `39182103` |
| `treedb.cache.vlog_generation.bytes.total.warm` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.active` | `false` |
| `treedb.cache.vlog_generation.checkpoint_kick.gc_runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.hot_no_debt_wake.running` | `true` |
| `treedb.cache.vlog_generation.checkpoint_kick.hot_no_debt_wake.runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.pending` | `false` |
| `treedb.cache.vlog_generation.checkpoint_kick.rewrite_runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.skipped_hot_no_debt` | `2` |
| `treedb.cache.vlog_generation.churn_bytes_per_sec` | `0` |
| `treedb.cache.vlog_generation.churn_bytes_total` | `31218486` |
| `treedb.cache.vlog_generation.cold.segment_target_bytes` | `536870912` |
| `treedb.cache.vlog_generation.deferred_vector_build.active` | `false` |
| `treedb.cache.vlog_generation.deferred_vector_build.debt` | `false` |
| `treedb.cache.vlog_generation.deferred_vector_build.debt_set` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.failures` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.finalizations` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.skips` | `0` |
| `treedb.cache.vlog_generation.enabled` | `true` |
| `treedb.cache.vlog_generation.gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.deleted_segments` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_eligible_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_eligible_segments` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.gc.exec.avg_ms` | `1129.007` |
| `treedb.cache.vlog_generation.gc.exec.max_ms` | `1129.007` |
| `treedb.cache.vlog_generation.gc.exec.total_ms` | `1129.007` |
| `treedb.cache.vlog_generation.gc.last_active_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_active_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_deleted_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_eligible_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_eligible_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_active` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_deleted` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_eligible` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_pending` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_in_use` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_other` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_overlap` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_retained` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_referenced` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_active` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_deleted` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_eligible` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_pending` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_in_use` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_other` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_overlap` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_retained` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_referenced` | `0` |
| `treedb.cache.vlog_generation.gc.last_pending_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_pending_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_in_use_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_in_use_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_other_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_other_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_overlap_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_overlap_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_retained_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_retained_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_referenced_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_referenced_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_unix_nano` | `1795198116543253490` |
| `treedb.cache.vlog_generation.gc.runs` | `1` |
| `treedb.cache.vlog_generation.hot.segment_target_bytes` | `268435456` |
| `treedb.cache.vlog_generation.leaf.segment_target_bytes` | `33554432` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_manifest_bytes` | `554` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_manifest_revisions` | `2` |
| `treedb.cache.vlog_generation.leaf_gc.errors` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.exec.total_ms` | `10.631` |
| `treedb.cache.vlog_generation.leaf_gc.runs` | `1` |
| `treedb.cache.vlog_generation.leaf_pack.admitted` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attempts` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attributed_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attributed_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.bytes_copied` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.canceled` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.deadline` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.deadline_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.errors` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.expected_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.expected_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.eligible_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_eligible_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.runs` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_attributed_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_attributed_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_bytes_copied` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_expected_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_expected_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.bytes_dead` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.bytes_to_copy` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_skip_reason` | `` |
| `treedb.cache.vlog_generation.leaf_pack.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_wall_ms` | `0.000` |
| `treedb.cache.vlog_generation.leaf_pack.max_bytes_to_copy` | `268435456` |
| `treedb.cache.vlog_generation.leaf_pack.max_foreground_queue` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.max_generations` | `32` |
| `treedb.cache.vlog_generation.leaf_pack.min_candidate_generations` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.min_interval_ms` | `30000` |
| `treedb.cache.vlog_generation.leaf_pack.min_reclaim_per_byte_copied_ppm` | `250000` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_default` | `false` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_last_attempt_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_max_bytes_to_copy` | `33554432` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_max_generations` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_timeout_ms` | `5000` |
| `treedb.cache.vlog_generation.leaf_pack.runs` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.bytes_dead` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.bytes_to_copy` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.foreground_iterators` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.min_interval` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.queue_pressure` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.write_burst` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skips` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.stop.low_yield` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.timeout_ms` | `30000` |
| `treedb.cache.vlog_generation.leaf_pack.write_burst_grace_ms` | `250` |
| `treedb.cache.vlog_generation.maintenance.acquired` | `4` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.periodic` | `4` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.active` | `false` |
| `treedb.cache.vlog_generation.maintenance.attempts` | `4` |
| `treedb.cache.vlog_generation.maintenance.collisions` | `0` |
| `treedb.cache.vlog_generation.maintenance.foreground_active_iterators` | `0` |
| `treedb.cache.vlog_generation.maintenance.foreground_last_read_unix_nano` | `1795198118994758670` |
| `treedb.cache.vlog_generation.maintenance.foreground_last_write_unix_nano` | `1795198114531019105` |
| `treedb.cache.vlog_generation.maintenance.foreground_quiet` | `false` |
| `treedb.cache.vlog_generation.maintenance.foreground_read_age_ms` | `173` |
| `treedb.cache.vlog_generation.maintenance.foreground_read_quiet` | `false` |
| `treedb.cache.vlog_generation.maintenance.foreground_write_age_ms` | `4636` |
| `treedb.cache.vlog_generation.maintenance.foreground_write_quiet` | `false` |
| `treedb.cache.vlog_generation.maintenance.pass.avg_ms` | `664.313` |
| `treedb.cache.vlog_generation.maintenance.pass.max_ms` | `2657.184` |
| `treedb.cache.vlog_generation.maintenance.pass.total_ms` | `2657.254` |
| `treedb.cache.vlog_generation.maintenance.passes.noop` | `3` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.periodic` | `3` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc` | `1` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.periodic` | `1` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.pause_file.configured` | `false` |
| `treedb.cache.vlog_generation.maintenance.pause_file.paused` | `false` |
| `treedb.cache.vlog_generation.maintenance.skip.age_blocked_gate` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.before_first_checkpoint` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.checkpoint_inflight` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.maintenance_phase` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.pause_file` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.priority_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.quiet_window` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate_due_reserved` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate_not_due` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.wal_on_periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance_phase` | `steady` |
| `treedb.cache.vlog_generation.observed_gc.latency.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.observed_gc.latency.completed_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.dropped_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.max_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.total_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_oldest_age_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_oldest_unix_nano` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_attempts_max` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_attempts_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.queued_batches` | `0` |
| `treedb.cache.vlog_generation.observed_gc.queued_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.retry_dropped` | `0` |
| `treedb.cache.vlog_generation.observed_gc.retry_max_attempts` | `3` |
| `treedb.cache.vlog_generation.observed_gc.retry_queued` | `0` |
| `treedb.cache.vlog_generation.observed_gc.runs` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_deleted_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_eligible_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_in_use_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_other_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_overlap_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_retained_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_deleted_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_eligible_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_in_use_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_other_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_overlap_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_retained_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.taken_batches` | `0` |
| `treedb.cache.vlog_generation.observed_gc.taken_ids` | `0` |
| `treedb.cache.vlog_generation.policy` | `2` |
| `treedb.cache.vlog_generation.remap.failures` | `0` |
| `treedb.cache.vlog_generation.remap.successes` | `0` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_due` | `false` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_remaining_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_until_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.bytes_in` | `0` |
| `treedb.cache.vlog_generation.rewrite.bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs.queued_debt` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs.queued_debt` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.bytes_in_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.bytes_out_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.last_duration_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_live_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.last_live_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.reclaimed_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.reclaimed_vs_churn_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_still_referenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_still_referenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_still_referenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_still_referenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_unreferenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_unreferenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.ineffective_backoff_seconds` | `120` |
| `treedb.cache.vlog_generation.rewrite.ineffective_bytes_in` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_chunk_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_chunks` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_stale_ratio_ppm` | `0` |
| `treedb.cache.vlog_generation.rewrite.min_segment_age_ms` | `30000` |
| `treedb.cache.vlog_generation.rewrite.no_reclaim_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.no_reclaim_stale_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.output_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.penalties_active` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan_canceled` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty.age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty.no_selection` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_errors` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.to_empty_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_chunks_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_segments_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_live_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_stale_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_stale_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.queue.pending` | `false` |
| `treedb.cache.vlog_generation.rewrite.queue.running` | `false` |
| `treedb.cache.vlog_generation.rewrite.queue_config.debt_drain_max_segments` | `8` |
| `treedb.cache.vlog_generation.rewrite.queue_config.fresh_plan_debt_drain_max_segments` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_config.fresh_plan_debt_drain_min_segments` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_config.resume_max_segments` | `1` |
| `treedb.cache.vlog_generation.rewrite.queue_eta_seconds.budget` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_eta_seconds.recent_exec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_len` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_bytes_after_tokens` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.coverage_pct` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.ids_known` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.ids_present` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.known` | `true` |
| `treedb.cache.vlog_generation.rewrite.queue_loaded` | `true` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_after_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_after_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_before_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_before_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_delta_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_drained_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_grown_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_known_passes` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_unknown_passes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.passes` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_after_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_after_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_before_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_before_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_delta_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_drained_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_grown_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.snapshot_errors` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_prune_ids` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_prune_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.decisions` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.decisions.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter.checkpoint_kick` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter.fresh_plan` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_empty.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_per_segment` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_per_segment.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_tokens` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_tokens.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_burst` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_burst.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_safety` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_safety.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.debt_drain_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.debt_drain_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_queue_threshold` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_queue_threshold.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.none` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.none.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.queue_len` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.queue_len.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.resume_default` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.resume_default.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.effective_bytes_after` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.effective_bytes_before` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.gc_bytes_deleted` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.no_reclaim_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.reclaimed_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.source_bytes_requested` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.source_bytes_unreferenced` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.followup_suppressed` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.passes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.rewrite_started` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.budget_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.cancel_backoff` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.ineffective_backoff` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.min_interval` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.no_chunk` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.quiet_window` | `0` |
| `treedb.cache.vlog_generation.rewrite.reclaim_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.reclaimed_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_due` | `false` |
| `treedb.cache.vlog_generation.rewrite.stage_due_in_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_observed_age_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_observed_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_pending` | `false` |
| `treedb.cache.vlog_generation.rewrite.value_bytes_copied` | `0` |
| `treedb.cache.vlog_generation.rewrite.value_records_copied` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.bytes_per_sec` | `134217728` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_share_of_budget_pct` | `0.000` |
| `treedb.cache.vlog_generation.rewrite_budget.records_per_sec` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_bytes` | `537073804` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_cap_bytes` | `4294967296` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_utilization_pct` | `12.505` |
| `treedb.cache.vlog_generation.rewrite_trigger.churn_per_sec` | `0` |
| `treedb.cache.vlog_generation.rewrite_trigger.stale_ratio_ppm` | `200000` |
| `treedb.cache.vlog_generation.rewrite_trigger.total_bytes` | `4294967296` |
| `treedb.cache.vlog_generation.scheduler_last_reason` | `periodic_gc` |
| `treedb.cache.vlog_generation.scheduler_state` | `idle` |
| `treedb.cache.vlog_generation.segments.cold` | `0` |
| `treedb.cache.vlog_generation.segments.hot` | `7` |
| `treedb.cache.vlog_generation.segments.total` | `7` |
| `treedb.cache.vlog_generation.segments.warm` | `0` |
| `treedb.cache.vlog_generation.vacuum.exec.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.exec.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.exec.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.failures` | `0` |
| `treedb.cache.vlog_generation.vacuum.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.vacuum.runs` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_cooldown` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_disabled` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_rewrite_bytes` | `0` |
| `treedb.cache.vlog_generation.warm.segment_target_bytes` | `268435456` |
| `treedb.cache.vlog_grouped_frame_cache.allocated_shards` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.allocated_slots` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.budget_bytes` | `67108864` |
| `treedb.cache.vlog_grouped_frame_cache.capacity` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.entries` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.evictions` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.hits` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.misses` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.releases` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.retained_bytes` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_budget` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_contention` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_disabled` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_oversize` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.stores` | `0` |
| `treedb.cache.vlog_io.bytes` | `0` |
| `treedb.cache.vlog_io.syscalls` | `0` |
| `treedb.cache.vlog_mmap.active_bytes` | `0` |
| `treedb.cache.vlog_mmap.active_segments` | `0` |
| `treedb.cache.vlog_mmap.current_bytes` | `0` |
| `treedb.cache.vlog_mmap.current_segments` | `0` |
| `treedb.cache.vlog_mmap.current_writable_map_target_bytes` | `33554432` |
| `treedb.cache.vlog_mmap.dead_bytes` | `0` |
| `treedb.cache.vlog_mmap.dead_mappings` | `0` |
| `treedb.cache.vlog_mmap.dead_mappings.cap_base` | `64` |
| `treedb.cache.vlog_mmap.max_mapped_leaf_sealed_bytes` | `1610612736` |
| `treedb.cache.vlog_mmap.max_mapped_leaf_sealed_segments` | `512` |
| `treedb.cache.vlog_mmap.max_mapped_sealed_bytes` | `67108864` |
| `treedb.cache.vlog_mmap.max_mapped_sealed_segments` | `8` |
| `treedb.cache.vlog_mmap.read.fallback_readat` | `0` |
| `treedb.cache.vlog_mmap.read.hits` | `0` |
| `treedb.cache.vlog_mmap.read.miss_dead_mapping_cap` | `0` |
| `treedb.cache.vlog_mmap.read.miss_no_mapping` | `0` |
| `treedb.cache.vlog_mmap.read.miss_out_of_range` | `0` |
| `treedb.cache.vlog_mmap.remaps` | `0` |
| `treedb.cache.vlog_mmap.sealed_bytes` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied.bytes_cap` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied.count_cap` | `0` |
| `treedb.cache.vlog_mmap.sealed_segments` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.legacy_page` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.unknown` | `44372` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.legacy_page` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.unknown` | `305885906` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.legacy_page` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.unknown` | `36542187` |
| `treedb.cache.vlog_outer_leaf_codec.stored_ratio.unknown` | `0.119463` |
| `treedb.cache.vlog_payload_kind.frames.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.frames.outer_leaf` | `44372` |
| `treedb.cache.vlog_payload_kind.frames.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.raw_bytes.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.raw_bytes.outer_leaf` | `305885906` |
| `treedb.cache.vlog_payload_kind.raw_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.stored_bytes.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.stored_bytes.outer_leaf` | `36542187` |
| `treedb.cache.vlog_payload_kind.stored_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.stored_ratio.outer_leaf` | `0.119463` |
| `treedb.cache.vlog_payload_split.frames.outer_leaf` | `44372` |
| `treedb.cache.vlog_payload_split.raw_bytes.outer_leaf` | `305885906` |
| `treedb.cache.vlog_payload_split.raw_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_split.records.outer_leaf` | `86877` |
| `treedb.cache.vlog_payload_split.records.single_value` | `0` |
| `treedb.cache.vlog_payload_split.stored_bytes.outer_leaf` | `36542187` |
| `treedb.cache.vlog_payload_split.stored_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_split.stored_ratio.outer_leaf` | `0.119463` |
| `treedb.cache.vlog_read.crc32_checks_total` | `0` |
| `treedb.cache.vlog_retained_bytes_estimate` | `39182103` |
| `treedb.cache.vlog_retained_prune.active` | `false` |
| `treedb.cache.vlog_retained_prune.budget_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.candidate_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.candidate_segments` | `0` |
| `treedb.cache.vlog_retained_prune.close_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.closed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.completed_runs` | `0` |
| `treedb.cache.vlog_retained_prune.error_runs` | `0` |
| `treedb.cache.vlog_retained_prune.force_pending` | `false` |
| `treedb.cache.vlog_retained_prune.forced_runs` | `0` |
| `treedb.cache.vlog_retained_prune.foreground_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.full_live_id_scan_runs` | `0` |
| `treedb.cache.vlog_retained_prune.in_use_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.in_use_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.inflight` | `false` |
| `treedb.cache.vlog_retained_prune.last_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.last_force` | `false` |
| `treedb.cache.vlog_retained_prune.last_mode` | `none` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_candidate` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_in_use_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_live_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_parse_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_removed` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_zombie_marked` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_candidate` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_in_use_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_live_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_parse_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_removed` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_zombie_marked` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.nested_value_pointers` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.outer_leaf_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.outer_leaf_records` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.records` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.value_pointer_records` | `0` |
| `treedb.cache.vlog_retained_prune.last_start_unix_nano` | `0` |
| `treedb.cache.vlog_retained_prune.last_status` | `none` |
| `treedb.cache.vlog_retained_prune.last_unix_nano` | `0` |
| `treedb.cache.vlog_retained_prune.live_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.live_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.max_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.no_candidate_runs` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_candidate_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_in_use_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_live_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_parse_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_removed_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_zombie_marked_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_candidate_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_in_use_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_live_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_parse_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_removed_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_zombie_marked_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source_fast_path_runs` | `0` |
| `treedb.cache.vlog_retained_prune.parse_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.parse_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.pressure_bytes` | `17179869164` |
| `treedb.cache.vlog_retained_prune.removed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.removed_segments` | `0` |
| `treedb.cache.vlog_retained_prune.runs` | `0` |
| `treedb.cache.vlog_retained_prune.scan.nested_value_pointers_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.outer_leaf_bytes_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.outer_leaf_records_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.records_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.value_pointer_records_total` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_forced_requests` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_requests` | `3` |
| `treedb.cache.vlog_retained_prune.schedule_skip.below_pressure` | `3` |
| `treedb.cache.vlog_retained_prune.schedule_skip.closing` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.inflight` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.min_interval` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.no_closed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.total_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.write_gate_retries` | `0` |
| `treedb.cache.vlog_retained_prune.write_gate_retry_successes` | `0` |
| `treedb.cache.vlog_retained_prune.zombie_marked_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.zombie_marked_segments` | `0` |
| `treedb.cache.vlog_retained_segments` | `7` |
| `treedb.cache.vlog_template_def_cache.hits` | `0` |
| `treedb.cache.vlog_template_def_cache.misses` | `0` |
| `treedb.cache.vlog_write.bytes` | `0` |
| `treedb.cache.vlog_write.calls` | `0` |
| `treedb.cache.vlog_write.syscalls` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.frames.block` | `44372` |
| `treedb.cache.vlog_write_mode.frames.dict` | `0` |
| `treedb.cache.vlog_write_mode.frames.off` | `0` |
| `treedb.cache.vlog_write_mode.raw_bytes.block` | `305885906` |
| `treedb.cache.vlog_write_mode.raw_bytes.dict` | `0` |
| `treedb.cache.vlog_write_mode.raw_bytes.off` | `0` |
| `treedb.cache.vlog_write_mode.stored_bytes.block` | `36542187` |
| `treedb.cache.vlog_write_mode.stored_bytes.dict` | `0` |
| `treedb.cache.vlog_write_mode.stored_bytes.off` | `0` |
| `treedb.cache.vlog_write_mode.stored_ratio.block` | `0.119463` |
| `treedb.cache.vlog_writer_append_buf.alloc_calls_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.allocated_bytes_total` | `29360128` |
| `treedb.cache.vlog_writer_append_buf.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.drops_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.gets_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.hits_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.misses_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.pool.entries` | `0` |
| `treedb.cache.vlog_writer_append_buf.pool.max_entries` | `16` |
| `treedb.cache.vlog_writer_append_buf.pool.retained_buffers` | `0` |
| `treedb.cache.vlog_writer_append_buf.pool.retained_bytes` | `0` |
| `treedb.cache.vlog_writer_append_buf.puts_total` | `0` |
| `treedb.cache.vlog_writev.bytes` | `0` |
| `treedb.cache.vlog_writev.flushes` | `0` |
| `treedb.cache.vlog_writev.iovecs` | `0` |
| `treedb.cache.vlog_writev.syscalls` | `0` |
| `treedb.cache.vlog_zombie.bytes` | `0` |
| `treedb.cache.vlog_zombie.pinned_bytes` | `0` |
| `treedb.cache.vlog_zombie.pinned_segments` | `0` |
| `treedb.cache.vlog_zombie.segments` | `0` |
| `treedb.cache.vlog_zombie.unpinned_bytes` | `0` |
| `treedb.cache.vlog_zombie.unpinned_segments` | `0` |
| `treedb.cache.write.wait_for_checkpoint.count_total` | `0` |
| `treedb.cache.write.wait_for_checkpoint.ns_total` | `0` |
| `treedb.command_wal.active_segment.name` | `` |
| `treedb.command_wal.active_segments` | `0` |
| `treedb.command_wal.append.count_total` | `0` |
| `treedb.command_wal.append.entry_scan.count_total` | `0` |
| `treedb.command_wal.append.entry_scan.ns_total` | `0` |
| `treedb.command_wal.append.intent.count_total` | `0` |
| `treedb.command_wal.append.intent.ns_total` | `0` |
| `treedb.command_wal.append.ns_total` | `0` |
| `treedb.command_wal.append.payload.count_total` | `0` |
| `treedb.command_wal.append.payload.ns_total` | `0` |
| `treedb.command_wal.append.point.count_total` | `0` |
| `treedb.command_wal.append.point.ns_total` | `0` |
| `treedb.command_wal.applied_lsn` | `0` |
| `treedb.command_wal.bytes` | `0` |
| `treedb.command_wal.bytes.active` | `0` |
| `treedb.command_wal.bytes.total` | `0` |
| `treedb.command_wal.cleanup.covered_bytes_total` | `0` |
| `treedb.command_wal.cleanup.covered_segments_total` | `0` |
| `treedb.command_wal.cleanup.namespace_sync.calls_total` | `0` |
| `treedb.command_wal.cleanup.namespace_sync.errors_total` | `0` |
| `treedb.command_wal.cleanup.namespace_sync.pending` | `false` |
| `treedb.command_wal.cleanup.ns_total` | `0` |
| `treedb.command_wal.cleanup.oldest_pinned_lsn` | `0` |
| `treedb.command_wal.cleanup.proof.capture_epoch` | `0` |
| `treedb.command_wal.cleanup.proof.count_total` | `0` |
| `treedb.command_wal.cleanup.proof.durable_wal_lsn` | `0` |
| `treedb.command_wal.cleanup.proof.frontier_lsn` | `0` |
| `treedb.command_wal.cleanup.proof.namespace_generation` | `0` |
| `treedb.command_wal.cleanup.proof.ns_total` | `0` |
| `treedb.command_wal.cleanup.proof.older_root_commit_seq` | `0` |
| `treedb.command_wal.cleanup.proof.selected_root_commit_seq` | `0` |
| `treedb.command_wal.cleanup.removed_bytes` | `0` |
| `treedb.command_wal.cleanup.removed_bytes_total` | `0` |
| `treedb.command_wal.cleanup.removed_segments` | `0` |
| `treedb.command_wal.cleanup.removed_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.active_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.error_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.pinned_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.uncovered_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained_bytes_total` | `0` |
| `treedb.command_wal.cleanup.retained_segments_total` | `0` |
| `treedb.command_wal.cleanup.retries_total` | `0` |
| `treedb.command_wal.cleanup.scan.count_total` | `0` |
| `treedb.command_wal.cleanup.scan.ns_total` | `0` |
| `treedb.command_wal.cleanup.scanned_bytes_total` | `0` |
| `treedb.command_wal.cleanup.scanned_frames_total` | `0` |
| `treedb.command_wal.cleanup.scans` | `0` |
| `treedb.command_wal.cleanup.unlinked_sync_pending_bytes` | `0` |
| `treedb.command_wal.cleanup.unlinked_sync_pending_segments` | `0` |
| `treedb.command_wal.dependency_debt.entries` | `0` |
| `treedb.command_wal.dependency_debt.max_age_ns` | `0` |
| `treedb.command_wal.dependency_debt.pending_bytes` | `0` |
| `treedb.command_wal.dependency_debt.pending_count` | `0` |
| `treedb.command_wal.dependency_debt.retries_total` | `0` |
| `treedb.command_wal.directory_sync.calls_total` | `0` |
| `treedb.command_wal.directory_sync.errors_total` | `0` |
| `treedb.command_wal.directory_sync.ns_total` | `0` |
| `treedb.command_wal.durable_wal_lsn` | `0` |
| `treedb.command_wal.enabled` | `false` |
| `treedb.command_wal.file_sync.calls_total` | `0` |
| `treedb.command_wal.file_sync.errors_total` | `0` |
| `treedb.command_wal.file_sync.ns_total` | `0` |
| `treedb.command_wal.flush.barrier.count_total` | `0` |
| `treedb.command_wal.flush.barrier.ns_total` | `0` |
| `treedb.command_wal.flush.count_total` | `0` |
| `treedb.command_wal.flush.entry_scan.count_total` | `0` |
| `treedb.command_wal.flush.entry_scan.ns_total` | `0` |
| `treedb.command_wal.flush.intent.count_total` | `0` |
| `treedb.command_wal.flush.intent.ns_total` | `0` |
| `treedb.command_wal.flush.ns_total` | `0` |
| `treedb.command_wal.flush.payload.count_total` | `0` |
| `treedb.command_wal.flush.payload.ns_total` | `0` |
| `treedb.command_wal.flush.point.count_total` | `0` |
| `treedb.command_wal.flush.point.ns_total` | `0` |
| `treedb.command_wal.frames` | `0` |
| `treedb.command_wal.live_accepted_frames` | `0` |
| `treedb.command_wal.live_accepted_max_lsn` | `0` |
| `treedb.command_wal.live_covered_frames` | `0` |
| `treedb.command_wal.live_covered_max_lsn` | `0` |
| `treedb.command_wal.max_lsn` | `0` |
| `treedb.command_wal.next_lsn` | `0` |
| `treedb.command_wal.required_feature` | `false` |
| `treedb.command_wal.segment_files` | `0` |
| `treedb.command_wal.segments.active` | `0` |
| `treedb.command_wal.segments.total` | `0` |
| `treedb.command_wal.stats_scan` | `false` |
| `treedb.command_wal.sync.barrier.count_total` | `0` |
| `treedb.command_wal.sync.barrier.ns_total` | `0` |
| `treedb.command_wal.sync.count_total` | `0` |
| `treedb.command_wal.sync.entry_scan.count_total` | `0` |
| `treedb.command_wal.sync.entry_scan.ns_total` | `0` |
| `treedb.command_wal.sync.intent.count_total` | `0` |
| `treedb.command_wal.sync.intent.ns_total` | `0` |
| `treedb.command_wal.sync.ns_total` | `0` |
| `treedb.command_wal.sync.payload.count_total` | `0` |
| `treedb.command_wal.sync.payload.ns_total` | `0` |
| `treedb.command_wal.sync.point.count_total` | `0` |
| `treedb.command_wal.sync.point.ns_total` | `0` |
| `treedb.command_wal.typed_segments` | `0` |
| `treedb.command_wal.write.bytes_total` | `0` |
| `treedb.command_wal.write.errors_total` | `0` |
| `treedb.command_wal.write.ns_total` | `0` |
| `treedb.command_wal.write.syscalls_total` | `0` |
| `treedb.command_wal.writer.buffer_size_bytes` | `0` |
| `treedb.command_wal.writer.buffered_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.capacity_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.dropped_bytes_total` | `0` |
| `treedb.command_wal.writer.command_buffer.length_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.limit_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.retain_limit_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.trim_count` | `0` |
| `treedb.command_wal.writer.pending_batch.capacity_bytes` | `0` |
| `treedb.command_wal.writer.pending_batch.length_bytes` | `0` |
| `treedb.command_wal.writer.scratch_capacity_bytes` | `0` |
| `treedb.commit_seq` | `6` |
| `treedb.durability_mode` | `wal_off_relaxed_sync` |
| `treedb.flush_admission.admitted` | `true` |
| `treedb.flush_admission.flush_apply_concurrency` | `6` |
| `treedb.flush_admission.flush_apply_concurrency_cap_reason` | `default_physical_cores` |
| `treedb.flush_admission.flush_apply_concurrency_configured` | `0` |
| `treedb.flush_admission.flush_apply_concurrency_defaulted` | `true` |
| `treedb.flush_admission.flush_apply_span_native` | `true` |
| `treedb.flush_admission.flush_backlog_coalescing` | `true` |
| `treedb.flush_admission.gomaxprocs` | `12` |
| `treedb.flush_admission.leaf_page_read_cache_write_admission` | `adaptive` |
| `treedb.flush_admission.physical_cores` | `6` |
| `treedb.flush_admission.policy` | `auto` |
| `treedb.flush_admission.reason` | `auto_admitted_hardware_aware` |
| `treedb.flush_apply.apply_calls_total` | `76` |
| `treedb.flush_apply.apply_errors_total` | `0` |
| `treedb.flush_apply.apply_ns_total` | `502479981` |
| `treedb.flush_apply.apply_ops_total` | `1514406` |
| `treedb.flush_apply.commit_wait_ns_total` | `0` |
| `treedb.flush_apply.guarded_publish.calls_total` | `0` |
| `treedb.flush_apply.guarded_publish.ns_per_op` | `0.000000` |
| `treedb.flush_apply.guarded_publish.ns_total` | `0` |
| `treedb.flush_apply.leaf_log_output.append_calls_total` | `41088` |
| `treedb.flush_apply.leaf_log_output.append_pages_total` | `86877` |
| `treedb.flush_apply.leaf_log_output.append_wait_ns_total` | `467685701` |
| `treedb.flush_apply.leaf_log_output.lane.01.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.02.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.03.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.04.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.05.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.06.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_lanes_used` | `6` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_max` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_overflow_total` | `0` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_total` | `228` |
| `treedb.flush_apply.leaf_log_output.reservation_wait_ns_total` | `3666362` |
| `treedb.flush_apply.merge_build.internal_child_refs_total` | `102320` |
| `treedb.flush_apply.merge_build.internal_merges_total` | `136` |
| `treedb.flush_apply.merge_build.internal_page_bytes_written_total` | `4689920` |
| `treedb.flush_apply.merge_build.internal_pages_written_total` | `1145` |
| `treedb.flush_apply.merge_build.internal_parallel_children_total` | `130` |
| `treedb.flush_apply.merge_build.internal_parallel_merges_total` | `3` |
| `treedb.flush_apply.merge_build.internal_parallel_ops_total` | `278451` |
| `treedb.flush_apply.merge_build.internal_parallel_workers_total` | `18` |
| `treedb.flush_apply.merge_build.leaf_log_page_bytes_written_total` | `355848192` |
| `treedb.flush_apply.merge_build.leaf_log_pages_written_total` | `86877` |
| `treedb.flush_apply.merge_build.leaf_log_record_hint_bytes_written_total` | `151971797` |
| `treedb.flush_apply.merge_build.leaf_merges_per_op` | `0.025295` |
| `treedb.flush_apply.merge_build.leaf_merges_total` | `38307` |
| `treedb.flush_apply.merge_build.leaf_page_bytes_written_total` | `355848192` |
| `treedb.flush_apply.merge_build.leaf_pages_written_total` | `86877` |
| `treedb.flush_apply.merge_build.pager_leaf_page_bytes_written_total` | `0` |
| `treedb.flush_apply.merge_build.pager_leaf_pages_written_total` | `0` |
| `treedb.flush_apply.merge_build.replacement_leaf_pages_per_op` | `0.057367` |
| `treedb.flush_apply.merge_build.replacement_leaf_pages_total` | `86877` |
| `treedb.flush_apply.mismatch_total` | `0` |
| `treedb.flush_apply.old_leaf_read_decode.bytes_per_op` | `106.645959` |
| `treedb.flush_apply.old_leaf_read_decode.bytes_total` | `161505280` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_bytes_total` | `159182848` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_cache_hits_total` | `4441` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_node_loads_total` | `38863` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_reader_calls_total` | `34422` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_record_hint_bytes_total` | `94974540` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_scratch_reads_total` | `34422` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_view_reads_total` | `0` |
| `treedb.flush_apply.old_leaf_read_decode.node_loads_total` | `39430` |
| `treedb.flush_apply.old_leaf_read_decode.pager_bytes_total` | `2322432` |
| `treedb.flush_apply.old_leaf_read_decode.pager_node_loads_total` | `567` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_installed_total` | `355848192` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_prepared_total` | `355848192` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_installed_total` | `86877` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_prepared_total` | `86877` |
| `treedb.flush_apply.prepared_output.retired_pages_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.retired_pages_installed_total` | `567` |
| `treedb.flush_apply.prepared_output.retired_pages_prepared_total` | `567` |
| `treedb.flush_apply.publish_final_install.calls_total` | `0` |
| `treedb.flush_apply.publish_final_install.ns_per_op` | `0.000000` |
| `treedb.flush_apply.publish_final_install.ns_total` | `0` |
| `treedb.flush_apply.publish_prepare.calls_total` | `5` |
| `treedb.flush_apply.publish_prepare.errors_total` | `0` |
| `treedb.flush_apply.publish_prepare.ns_per_op` | `6.039406` |
| `treedb.flush_apply.publish_prepare.ns_total` | `9146113` |
| `treedb.flush_apply.publish_total.ns_per_op` | `6.039406` |
| `treedb.flush_apply.publish_total.ns_total` | `9146113` |
| `treedb.flush_apply.read_only_prepare.calls_total` | `76` |
| `treedb.flush_apply.read_only_prepare.errors_total` | `0` |
| `treedb.flush_apply.read_only_prepare.ns_total` | `76782722` |
| `treedb.flush_apply.read_only_prepare.requested_workers_max` | `6` |
| `treedb.flush_apply.read_only_prepare.requested_workers_total` | `456` |
| `treedb.flush_apply.read_only_prepare.single_op_spans_max` | `1373` |
| `treedb.flush_apply.read_only_prepare.single_op_spans_total` | `2121` |
| `treedb.flush_apply.read_only_prepare.span_bytes_max` | `12622840` |
| `treedb.flush_apply.read_only_prepare.span_bytes_total` | `199376048` |
| `treedb.flush_apply.read_only_prepare.span_ops_max` | `92817` |
| `treedb.flush_apply.read_only_prepare.span_ops_total` | `1514406` |
| `treedb.flush_apply.read_only_prepare.spans_max` | `9470` |
| `treedb.flush_apply.read_only_prepare.spans_total` | `38307` |
| `treedb.flush_apply.read_only_prepare.validation_failures_total` | `0` |
| `treedb.flush_apply.read_only_prepare.worker_ranges_max` | `6` |
| `treedb.flush_apply.read_only_prepare.worker_ranges_total` | `281` |
| `treedb.flush_apply.reducer_publish.ns_per_op` | `7.264801` |
| `treedb.flush_apply.reducer_publish.ns_total` | `11001858` |
| `treedb.flush_apply.retry_total` | `0` |
| `treedb.flush_apply.root_reduce.ns_per_op` | `7.264801` |
| `treedb.flush_apply.root_reduce.ns_total` | `11001858` |
| `treedb.flush_apply.root_reduce.split_levels_total` | `3` |
| `treedb.flush_apply.span_native.candidate_ops_total` | `1514406` |
| `treedb.flush_apply.span_native.candidate_spans_total` | `38307` |
| `treedb.flush_apply.span_native.eligible_ops_total` | `1235955` |
| `treedb.flush_apply.span_native.eligible_spans_total` | `22206` |
| `treedb.flush_apply.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.maintenance.ops_total` | `278451` |
| `treedb.flush_apply.span_native.fallback.reason.maintenance.spans_total` | `16101` |
| `treedb.flush_apply.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallbacks_total` | `3` |
| `treedb.flush_apply.span_native.ineligible_ops_total` | `278451` |
| `treedb.flush_apply.span_native.ineligible_spans_total` | `16101` |
| `treedb.flush_apply.span_native.reducer_validation_guard.active` | `false` |
| `treedb.flush_apply.span_native.reducer_validation_guard.trips_total` | `0` |
| `treedb.flush_apply.span_native.scheduler.completed_tasks_total` | `263` |
| `treedb.flush_apply.span_native.scheduler.dispatched_tasks_total` | `263` |
| `treedb.flush_apply.span_native.scheduler.queue_depth_max` | `6` |
| `treedb.flush_apply.span_native.scheduler.ready_tasks_total` | `263` |
| `treedb.flush_apply.span_native.scheduler.scheduled_workers_max` | `6` |
| `treedb.flush_apply.span_native.scheduler.scheduled_workers_total` | `263` |
| `treedb.flush_apply.span_native.scheduler.single_span_tasks_total` | `36` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_max` | `2621440` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_min` | `115328` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_per_task` | `675626.920152` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_total` | `177689880` |
| `treedb.flush_apply.span_native.scheduler.task_ops_max` | `16384` |
| `treedb.flush_apply.span_native.scheduler.task_ops_min` | `848` |
| `treedb.flush_apply.span_native.scheduler.task_ops_per_task` | `4699.448669` |
| `treedb.flush_apply.span_native.scheduler.task_ops_total` | `1235955` |
| `treedb.flush_apply.span_native.scheduler.task_spans_max` | `964` |
| `treedb.flush_apply.span_native.scheduler.task_spans_min` | `1` |
| `treedb.flush_apply.span_native.scheduler.task_spans_per_task` | `84.433460` |
| `treedb.flush_apply.span_native.scheduler.task_spans_total` | `22206` |
| `treedb.flush_apply.span_native.scheduler.worker_busy_ns_total` | `1078810976` |
| `treedb.flush_apply.span_native.scheduler.worker_idle_ns_total` | `167412158` |
| `treedb.flush_apply.span_native.scheduler.worker_wait_ns_total` | `348663929` |
| `treedb.flush_apply.span_native.used_ops_total` | `1235955` |
| `treedb.flush_apply.span_native.used_spans_total` | `22206` |
| `treedb.flush_apply.span_run.bytes_per_span` | `5204.689691` |
| `treedb.flush_apply.span_run.ops_per_span` | `39.533401` |
| `treedb.flush_apply.span_run.single_op_spans_total` | `2121` |
| `treedb.flush_apply.span_run.span_bytes_total` | `199376048` |
| `treedb.flush_apply.span_run.span_ops_total` | `1514406` |
| `treedb.flush_apply.span_run.target_leaf_spans_total` | `38307` |
| `treedb.leaf_generation.bytes.deleted` | `0` |
| `treedb.leaf_generation.bytes.retained` | `35428607` |
| `treedb.leaf_generation.bytes.retiring` | `0` |
| `treedb.leaf_generation.bytes.sealed` | `35428607` |
| `treedb.leaf_generation.bytes.total` | `39182103` |
| `treedb.leaf_generation.bytes.writable` | `3753496` |
| `treedb.leaf_generation.current.bytes` | `3753496` |
| `treedb.leaf_generation.current.files` | `1` |
| `treedb.leaf_generation.current_generation_id` | `7` |
| `treedb.leaf_generation.enabled` | `true` |
| `treedb.leaf_generation.files.deleted` | `0` |
| `treedb.leaf_generation.files.retained` | `6` |
| `treedb.leaf_generation.files.retiring` | `0` |
| `treedb.leaf_generation.files.sealed` | `6` |
| `treedb.leaf_generation.files.total` | `7` |
| `treedb.leaf_generation.files.writable` | `1` |
| `treedb.leaf_generation.generations.deleted` | `0` |
| `treedb.leaf_generation.generations.pinned` | `0` |
| `treedb.leaf_generation.generations.retained` | `6` |
| `treedb.leaf_generation.generations.retiring` | `0` |
| `treedb.leaf_generation.generations.sealed` | `6` |
| `treedb.leaf_generation.generations.total` | `7` |
| `treedb.leaf_generation.generations.writable` | `1` |
| `treedb.leaf_generation.pins.total` | `0` |
| `treedb.leaf_generation.plan_cache.subtree_pages` | `0` |
| `treedb.process.append_only.entry_hint_capacity_bytes` | `4850304` |
| `treedb.process.append_only.entry_hint_entries` | `50524` |
| `treedb.process.append_only.entry_pool_admission_drop_bytes_total` | `75452608` |
| `treedb.process.append_only.entry_pool_admission_drops_total` | `5` |
| `treedb.process.append_only.entry_pool_drop_bytes_total` | `266945184` |
| `treedb.process.append_only.entry_pool_drops_total` | `1` |
| `treedb.process.append_only.entry_pool_gets_total` | `35` |
| `treedb.process.append_only.entry_pool_puts_total` | `227` |
| `treedb.process.append_only.entry_pool_retained_bytes_estimate` | `186001904` |
| `treedb.process.append_only.entry_pool_retained_bytes_max_estimate` | `266945184` |
| `treedb.process.append_only.mem_lease_count` | `8` |
| `treedb.process.append_only.mem_lease_entry_backing_bytes` | `0` |
| `treedb.process.append_only.mem_lease_entry_capacity` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_active_bytes` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_active_chunks` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_retained_bytes` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_retained_chunks` | `0` |
| `treedb.process.append_only.mutable_count` | `16` |
| `treedb.process.append_only.mutable_entry_backing_bytes` | `0` |
| `treedb.process.append_only.mutable_entry_capacity` | `0` |
| `treedb.process.append_only.mutable_from_lease_total` | `56` |
| `treedb.process.append_only.mutable_from_pool_total` | `0` |
| `treedb.process.append_only.mutable_new_alloc_queue_bytes_sum` | `502792240` |
| `treedb.process.append_only.mutable_new_alloc_total` | `24` |
| `treedb.process.append_only.mutable_new_alloc_with_queue_total` | `24` |
| `treedb.process.append_only.mutable_pool_drops_total` | `0` |
| `treedb.process.append_only.mutable_pool_entry_backing_dropped_bytes_total` | `0` |
| `treedb.process.append_only.mutable_pool_puts_total` | `16` |
| `treedb.process.append_only.mutable_sparse_trim_dropped_bytes_total` | `155056` |
| `treedb.process.append_only.mutable_sparse_trim_total` | `10` |
| `treedb.process.append_only.mutable_trim_dropped_bytes_total` | `5182848` |
| `treedb.process.append_only.mutable_trim_total` | `58` |
| `treedb.process.append_only.mutable_value_arena_active_bytes` | `0` |
| `treedb.process.append_only.mutable_value_arena_active_chunks` | `0` |
| `treedb.process.append_only.mutable_value_arena_retained_bytes` | `0` |
| `treedb.process.append_only.mutable_value_arena_retained_chunks` | `0` |
| `treedb.process.append_only.reserve.calls_total` | `132` |
| `treedb.process.append_only.reserve.entries_total` | `60896` |
| `treedb.process.append_only.reserve.grow_bytes_total` | `272375664` |
| `treedb.process.append_only.reserve.grow_calls_total` | `132` |
| `treedb.process.append_only.reserve.skipped_growth_allocs_total` | `21` |
| `treedb.process.append_only.reserve.skipped_growth_bytes_total` | `405504` |
| `treedb.process.append_only.value_arena_pool_admission_drop_bytes_total` | `0` |
| `treedb.process.append_only.value_arena_pool_admission_drops_total` | `0` |
| `treedb.process.append_only.value_arena_pool_drop_bytes_total` | `0` |
| `treedb.process.append_only.value_arena_pool_drops_total` | `0` |
| `treedb.process.append_only.value_arena_pool_gets_total` | `0` |
| `treedb.process.append_only.value_arena_pool_puts_total` | `0` |
| `treedb.process.append_only.value_arena_pool_retained_bytes_estimate` | `0` |
| `treedb.process.append_only.value_arena_pool_retained_bytes_max_estimate` | `0` |
| `treedb.process.memory.gc_cpu_fraction` | `0.014834` |
| `treedb.process.memory.gomemlimit_bytes` | `9223372036854775807` |
| `treedb.process.memory.heap_alloc_bytes` | `460971376` |
| `treedb.process.memory.heap_idle_bytes` | `638222336` |
| `treedb.process.memory.heap_idle_unreleased_bytes` | `43352064` |
| `treedb.process.memory.heap_inuse_bytes` | `465043456` |
| `treedb.process.memory.heap_released_bytes` | `594870272` |
| `treedb.process.memory.heap_sys_bytes` | `1103265792` |
| `treedb.process.memory.memtable_view_deferred_bytes_current` | `0` |
| `treedb.process.memory.memtable_view_deferred_bytes_max` | `0` |
| `treedb.process.memory.memtable_view_deferred_memtables_current` | `0` |
| `treedb.process.memory.memtable_view_deferred_memtables_max` | `0` |
| `treedb.process.memory.memtable_view_deferred_oldest_age_ms` | `0.000` |
| `treedb.process.memory.mutable_bytes` | `0` |
| `treedb.process.memory.next_gc_bytes` | `918011922` |
| `treedb.process.memory.non_heap_sys_bytes` | `35122712` |
| `treedb.process.memory.num_gc` | `73` |
| `treedb.process.memory.peak_heap_alloc_bytes` | `776084584` |
| `treedb.process.memory.peak_heap_inuse_bytes` | `780689408` |
| `treedb.process.memory.peak_rss_bytes` | `1132408832` |
| `treedb.process.memory.peak_total_sys_bytes` | `1138388504` |
| `treedb.process.memory.peak_vlog_mmap_active_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_active_segments` | `0` |
| `treedb.process.memory.peak_vlog_mmap_current_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_current_segments` | `0` |
| `treedb.process.memory.peak_vlog_mmap_sealed_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_sealed_segments` | `0` |
| `treedb.process.memory.pool_pressure_critical_samples_total` | `0` |
| `treedb.process.memory.pool_pressure_high_samples_total` | `0` |
| `treedb.process.memory.pool_pressure_level` | `normal` |
| `treedb.process.memory.pool_pressure_normal_samples_total` | `75` |
| `treedb.process.memory.pool_pressure_used_bytes` | `508395520` |
| `treedb.process.memory.queue_backlog_bytes` | `0` |
| `treedb.process.memory.rss_bytes` | `545230848` |
| `treedb.process.memory.rss_hwm_bytes` | `1131732992` |
| `treedb.process.memory.rss_minus_heap_inuse_bytes` | `80187392` |
| `treedb.process.memory.rss_minus_total_sys_bytes` | `0` |
| `treedb.process.memory.stack_inuse_bytes` | `4030464` |
| `treedb.process.memory.stack_sys_bytes` | `4030464` |
| `treedb.process.memory.total_sys_bytes` | `1138388504` |
| `treedb.process.memory.vlog_mmap_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_sealed_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_sealed_segments` | `0` |
| `treedb.process.memory.vlog_mmap_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_sealed_segments` | `0` |
| `treedb.process.memory.vlog_retained_bytes_estimate` | `39182103` |
| `treedb.process.memory.vlog_zombie_bytes_estimate` | `0` |
| `treedb.process.memory.vlog_zombie_pinned_bytes_estimate` | `0` |
| `treedb.process.memory.vlog_zombie_unpinned_bytes_estimate` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.count` | `16` |
| `treedb.process.memtable_residency.mutable.append_only.entries` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.btree.count` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entries` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.btree.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.count` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entries` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.count` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entries` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.total.count` | `16` |
| `treedb.process.memtable_residency.mutable.total.entries` | `0` |
| `treedb.process.memtable_residency.mutable.total.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.total.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.append_only.count` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entries` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.append_only.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.btree.count` | `0` |
| `treedb.process.memtable_residency.queue.btree.entries` | `0` |
| `treedb.process.memtable_residency.queue.btree.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.btree.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.count` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entries` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.count` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entries` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.total.count` | `0` |
| `treedb.process.memtable_residency.queue.total.entries` | `0` |
| `treedb.process.memtable_residency.queue.total.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.total.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_retained_chunks` | `0` |
| `treedb.process.read_path.backend_tree.get_append_inline_bytes_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_inline_hits_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_pointer_bytes_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_pointer_hits_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.calls_total` | `200` |
| `treedb.process.read_path.backend_tree.getmany.fallback_calls_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.grouped_calls_total` | `200` |
| `treedb.process.read_path.backend_tree.getmany.leaf_group_items_total` | `200000` |
| `treedb.process.read_path.backend_tree.getmany.leaf_groups_total` | `186702` |
| `treedb.process.read_path.backend_tree.getmany.leaf_loads_saved_total` | `13298` |
| `treedb.process.read_path.outer_leaf.bytes_total` | `10797690880` |
| `treedb.process.read_path.outer_leaf.cache.backing_bytes` | `33554432` |
| `treedb.process.read_path.outer_leaf.cache.buckets` | `2048` |
| `treedb.process.read_path.outer_leaf.cache.bytes` | `33554432` |
| `treedb.process.read_path.outer_leaf.cache.capacity` | `8192` |
| `treedb.process.read_path.outer_leaf.cache.capacity_evictions` | `203128` |
| `treedb.process.read_path.outer_leaf.cache.conflict_evictions` | `23699` |
| `treedb.process.read_path.outer_leaf.cache.cow_read_policy_bytes` | `196608` |
| `treedb.process.read_path.outer_leaf.cache.entries` | `8192` |
| `treedb.process.read_path.outer_leaf.cache.evictions` | `226827` |
| `treedb.process.read_path.outer_leaf.cache.hits` | `2215625` |
| `treedb.process.read_path.outer_leaf.cache.misses` | `576182` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_mark_misses` | `0` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_mark_unsafe_skips` | `0` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_unverified_hits` | `144258` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_verified_hits` | `2071367` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_verified_marks` | `141385` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_candidate_skips` | `1` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_lock_skips` | `21` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_skips` | `428035` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_stores` | `148146` |
| `treedb.process.read_path.outer_leaf.cache.record_checksum_verified_stores` | `148146` |
| `treedb.process.read_path.outer_leaf.cache.stores` | `235019` |
| `treedb.process.read_path.outer_leaf.cache.ways` | `4` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_attempts` | `86877` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_lock_skips` | `4` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_policy` | `adaptive` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_skips` | `4` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_stores` | `86873` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_1024_hit_ratio` | `0.131103` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_1024_hits_total` | `5400` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_256_hit_ratio` | `0.034500` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_256_hits_total` | `1421` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_4096_hit_ratio` | `0.414407` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_4096_hits_total` | `17069` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_64_hit_ratio` | `0.009857` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_64_hits_total` | `406` |
| `treedb.process.read_path.outer_leaf.checksum.skips_total` | `2061322` |
| `treedb.process.read_path.outer_leaf.checksum.verifications_total` | `574833` |
| `treedb.process.read_path.outer_leaf.iterator_loads_total` | `49453` |
| `treedb.process.read_path.outer_leaf.loads_total` | `2636155` |
| `treedb.process.read_path.outer_leaf.point_loads_total` | `2586702` |
| `treedb.process.read_path.outer_leaf.sample_mod` | `64` |
| `treedb.process.read_path.outer_leaf.samples_total` | `41189` |
| `treedb.profile.bench_unsafe` | `false` |
| `treedb.profile.resolved` | `no_wal_fast` |
| `treedb.publish.ordered_root_delta_group.avg_roots_per_call` | `0.000` |
| `treedb.publish.ordered_root_delta_group.calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.finalize_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.finalize_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.latency_max_ms` | `0.000` |
| `treedb.publish.ordered_root_delta_group.latency_p99_ms` | `0.000` |
| `treedb.publish.ordered_root_delta_group.preflight_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_child_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_leaf_log_ref_copies_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_leaf_log_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_page_child_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_children_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_workers_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_cache_hits_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_node_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_reader_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_record_hint_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_record_hint_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_scratch_reads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_view_reads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_leaf_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_leaf_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_node_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_parallel_groups_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_parallel_roots_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_requested_workers_max` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_requested_workers_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_span_bytes_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_span_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_validation_failures_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_worker_ranges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_root_split_levels_total` | `0` |
| `treedb.publish.ordered_root_delta_group.roots_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.fallback_reason` | `route_ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.fallback_reason` | `route_ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.fallback_reason` | `cold_build` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_build_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_hold_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_wait_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_wait_share_pct` | `0.000` |
| `treedb.publish.watermark.lag_drift_bytes_per_sec` | `0.000` |
| `treedb.publish.watermark.latency_p99_ms` | `0.000` |
| `treedb.publish.watermark.lock_delay_share_pct` | `0.000` |
| `treedb.raw.span_native.candidate_ops_total` | `1514406` |
| `treedb.raw.span_native.candidate_spans_total` | `0` |
| `treedb.raw.span_native.eligible_ops_total` | `1235955` |
| `treedb.raw.span_native.eligible_spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.maintenance.count_total` | `3` |
| `treedb.raw.span_native.fallback.reason.maintenance.ops_total` | `278451` |
| `treedb.raw.span_native.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.fallbacks_total` | `3` |
| `treedb.raw.span_native.ineligible_ops_total` | `278451` |
| `treedb.raw.span_native.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.public.command_wal_rejections_total` | `0` |
| `treedb.raw.span_native.public.route.update.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.public.route.update.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.public.route.update_sync.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.public.route.update_sync.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.observations_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.used_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.used_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.observations_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.used_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.used_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.candidate_ops_total` | `278451` |
| `treedb.raw.span_native.route.mixed_point.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.count_total` | `3` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.ops_total` | `278451` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallbacks_total` | `3` |
| `treedb.raw.span_native.route.mixed_point.ineligible_ops_total` | `278451` |
| `treedb.raw.span_native.route.mixed_point.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.observations_total` | `3` |
| `treedb.raw.span_native.route.mixed_point.used_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.used_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.observations_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.point_delete.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.observations_total` | `0` |
| `treedb.raw.span_native.route.point_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.candidate_ops_total` | `1235955` |
| `treedb.raw.span_native.route.point_put.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.eligible_ops_total` | `1235955` |
| `treedb.raw.span_native.route.point_put.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.point_put.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.observations_total` | `73` |
| `treedb.raw.span_native.route.point_put.used_ops_total` | `1235955` |
| `treedb.raw.span_native.route.point_put.used_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.range_delete.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.observations_total` | `0` |
| `treedb.raw.span_native.route.range_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.used_ops_total` | `1235955` |
| `treedb.raw.span_native.used_spans_total` | `0` |
| `treedb.vlog.decode_buffer_grow.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.capacity_waste_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.copied_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_fit_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_fit_requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_present_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_current_mmap_direct_decode.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_current_mmap_direct_decode.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_fit_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_fit_requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_present_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_template_encoded_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_template_encoded_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.realloc_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.requested_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.file_stash.retain_max_bytes` | `131072` |
| `treedb.vlog.decode_scratch.file_stash.retained_buffers` | `21` |
| `treedb.vlog.decode_scratch.file_stash.retained_bytes` | `684566` |
| `treedb.vlog.decode_scratch.file_stash.retained_files` | `7` |
| `treedb.vlog.decode_scratch.file_stash.spare_max_count` | `2` |
| `treedb.vlog.decode_scratch.large_pool.alloc_calls_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.drops_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.entries` | `0` |
| `treedb.vlog.decode_scratch.large_pool.gets_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.hits_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.max_entries` | `8` |
| `treedb.vlog.decode_scratch.large_pool.misses_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.puts_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.retained_buffers` | `0` |
| `treedb.vlog.decode_scratch.large_pool.retained_bytes` | `0` |
| `treedb.vlog.decode_scratch.large_pool.too_small_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.alloc_calls_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.drops_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.alloc_calls_total` | `112` |
| `treedb.vlog.decode_scratch.small_pool.allocated_bytes_total` | `3443096` |
| `treedb.vlog.decode_scratch.small_pool.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.drops_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.entries` | `9` |
| `treedb.vlog.decode_scratch.small_pool.gets_total` | `42240` |
| `treedb.vlog.decode_scratch.small_pool.hits_total` | `42128` |
| `treedb.vlog.decode_scratch.small_pool.max_entries` | `128` |
| `treedb.vlog.decode_scratch.small_pool.misses_total` | `112` |
| `treedb.vlog.decode_scratch.small_pool.puts_total` | `42219` |
| `treedb.vlog.decode_scratch.small_pool.retained_buffers` | `9` |
| `treedb.vlog.decode_scratch.small_pool.retained_bytes` | `293427` |
| `treedb.vlog.decode_scratch.small_pool.too_small_total` | `82` |
| `treedb.vlog.grouped_frame_cache.allocated_shards` | `0` |
| `treedb.vlog.grouped_frame_cache.allocated_slots` | `0` |
| `treedb.vlog.grouped_frame_cache.budget_bytes` | `67108864` |
| `treedb.vlog.grouped_frame_cache.capacity` | `0` |
| `treedb.vlog.grouped_frame_cache.entries` | `0` |
| `treedb.vlog.grouped_frame_cache.evictions` | `0` |
| `treedb.vlog.grouped_frame_cache.hits` | `0` |
| `treedb.vlog.grouped_frame_cache.misses` | `0` |
| `treedb.vlog.grouped_frame_cache.releases` | `0` |
| `treedb.vlog.grouped_frame_cache.retained_bytes` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_budget` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_contention` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_disabled` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_oversize` | `0` |
| `treedb.vlog.grouped_frame_cache.stores` | `0` |
| `treedb.vlog.mmap_active_bytes` | `0` |
| `treedb.vlog.mmap_active_segments` | `0` |
| `treedb.vlog.mmap_current_bytes` | `0` |
| `treedb.vlog.mmap_current_segments` | `0` |
| `treedb.vlog.mmap_current_writable_map_target_bytes` | `33554432` |
| `treedb.vlog.mmap_dead_bytes` | `0` |
| `treedb.vlog.mmap_dead_mappings` | `0` |
| `treedb.vlog.mmap_dead_mappings.cap_base` | `64` |
| `treedb.vlog.mmap_max_mapped_leaf_sealed_bytes` | `1610612736` |
| `treedb.vlog.mmap_max_mapped_leaf_sealed_segments` | `512` |
| `treedb.vlog.mmap_max_mapped_sealed_bytes` | `67108864` |
| `treedb.vlog.mmap_max_mapped_sealed_segments` | `8` |
| `treedb.vlog.mmap_read.fallback_readat` | `721739` |
| `treedb.vlog.mmap_read.hit_ratio` | `0.000000` |
| `treedb.vlog.mmap_read.hits` | `0` |
| `treedb.vlog.mmap_read.miss_dead_mapping_cap` | `0` |
| `treedb.vlog.mmap_read.miss_no_mapping` | `721739` |
| `treedb.vlog.mmap_read.miss_out_of_range` | `0` |
| `treedb.vlog.mmap_remaps` | `0` |
| `treedb.vlog.mmap_sealed_bytes` | `0` |
| `treedb.vlog.mmap_sealed_map_denied` | `0` |
| `treedb.vlog.mmap_sealed_map_denied.bytes_cap` | `0` |
| `treedb.vlog.mmap_sealed_map_denied.count_cap` | `0` |
| `treedb.vlog.mmap_sealed_segments` | `0` |
| `treedb.vlog.read.crc32_checks_total` | `721739` |
| `treedb.vlog.read_integrity` | `verify` |
| `treedb.vlog.template_def_cache.hits` | `0` |
| `treedb.vlog.template_def_cache.misses` | `0` |
| `treedb.vlog.writer_append_buf.alloc_calls_total` | `7` |
| `treedb.vlog.writer_append_buf.allocated_bytes_total` | `29360128` |
| `treedb.vlog.writer_append_buf.dropped_bytes_total` | `0` |
| `treedb.vlog.writer_append_buf.drops_total` | `0` |
| `treedb.vlog.writer_append_buf.gets_total` | `7` |
| `treedb.vlog.writer_append_buf.hits_total` | `0` |
| `treedb.vlog.writer_append_buf.misses_total` | `7` |
| `treedb.vlog.writer_append_buf.pool.entries` | `0` |
| `treedb.vlog.writer_append_buf.pool.max_entries` | `16` |
| `treedb.vlog.writer_append_buf.pool.retained_buffers` | `0` |
| `treedb.vlog.writer_append_buf.pool.retained_bytes` | `0` |
| `treedb.vlog.writer_append_buf.puts_total` | `0` |

## Key Insights

- TreeDB: prefix_scan is 1.53x faster than full_scan (3963341 vs 2592985 ops/s).
- treedb: shared hotspot "runtime.scanObject" (full 15.38% flat, prefix 50.00% flat).
- treedb: prefix_scan-specific hotspot "internal/runtime/atomic.(*Uint32).Add (inline)" (5.00% flat).
- treedb: full_scan-specific hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" (32.69% flat).
- block/batch_delete/treedb: contention hotspot "runtime.chanrecv1" (100.00% flat).
- block/batch_random/treedb: contention hotspot "runtime.chanrecv1" (50.14% flat).
- block/batch_small_seq/treedb: contention hotspot "runtime.chanrecv1" (50.30% flat).
- block/batch_write/treedb: contention hotspot "runtime.selectgo" (99.92% flat).
- block/batch_write_steady/treedb: contention hotspot "runtime.chanrecv2" (46.95% flat).
- block/dataset_write_random/treedb: contention hotspot "runtime.selectgo" (83.17% flat).
- block/dataset_write_sorted/treedb: contention hotspot "runtime.selectgo" (57.75% flat).
- block/full_scan/treedb: contention hotspot "runtime.selectgo" (82.52% flat).
- block/prefix_scan/treedb: contention hotspot "runtime.chanrecv1" (100.00% flat).
- block/random_delete/treedb: contention hotspot "runtime.selectgo" (100.00% flat).
- block/random_read/treedb: contention hotspot "runtime.selectgo" (85.54% flat).
- block/random_read_batch/treedb: contention hotspot "runtime.chanrecv1" (66.84% flat).
- block/random_read_parallel/treedb: contention hotspot "runtime.chanrecv1" (54.95% flat).
- block/random_read_parallel_acquire_snapshot/treedb: contention hotspot "runtime.selectgo" (68.16% flat).
- block/random_write/treedb: contention hotspot "runtime.chanrecv1" (100.00% flat).
- block/sequential_write/treedb: contention hotspot "runtime.selectgo" (97.56% flat).
- mutex/batch_random/treedb: contention hotspot "runtime.unlock (inline)" (100.00% flat).
- mutex/batch_write_steady/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (98.82% flat).
- mutex/full_scan/treedb: contention hotspot "runtime.unlock (inline)" (100.00% flat).
- mutex/random_read/treedb: contention hotspot "runtime.unlock (inline)" (100.00% flat).
- mutex/random_read_batch/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (89.39% flat).
- mutex/random_read_parallel_acquire_snapshot/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (75.26% flat).
- mutex/sequential_write/treedb: contention hotspot "runtime.unlock (inline)" (100.00% flat).
- Global block contention hotspot: "runtime.selectgo" (70.07% flat).
- Global mutex contention hotspot: "sync.(*Mutex).Unlock (partial-inline)" (90.39% flat).
- alloc_objects/batch_delete/treedb: top allocator by count is "runtime/pprof.allFrames" (2185 flat, 51.24%).
- alloc_objects/batch_delete/treedb: top hotspot "runtime/pprof.allFrames" is 51.24% flat; this section is highly concentrated in one function.
- alloc_objects/batch_random/treedb: top allocator by count is "runtime/pprof.(*profileBuilder).emitLocation" (38242 flat, 91.74%).
- alloc_objects/batch_random/treedb: top hotspot "runtime/pprof.(*profileBuilder).emitLocation" is 91.74% flat; this section is highly concentrated in one function.
- alloc_objects/batch_small_seq/treedb: dominant theme is write/delete/flush path (78.87% flat across top nodes).
- alloc_objects/batch_small_seq/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked" (5922 flat, 51.50%).
- alloc_objects/batch_small_seq/treedb: top hotspot "github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked" is 51.50% flat; this section is highly concentrated in one function.
- alloc_objects/batch_write/treedb: top allocator by count is "runtime/pprof.allFrames" (2185 flat, 76.86%).
- alloc_objects/batch_write/treedb: top hotspot "runtime/pprof.allFrames" is 76.86% flat; this section is highly concentrated in one function.
- alloc_objects/batch_write_steady/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/caching.(*cachingLeafPageLog).CurrentLeafPageLogSegmentsSnapshot" (21845 flat, 38.30%).
- alloc_objects/batch_write_steady/treedb: top hotspot "github.com/snissn/gomap/TreeDB/caching.(*cachingLeafPageLog).CurrentLeafPageLogSegmentsSnapshot" is 38.30% flat; this section is highly concentrated in one function.
- alloc_objects/dataset_write_random/treedb: dominant theme is write/delete/flush path (89.19% flat across top nodes).
- alloc_objects/dataset_write_random/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc" (2372 flat, 60.20%).
- alloc_objects/dataset_write_random/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc" is 60.20% flat; this section is highly concentrated in one function.
- alloc_objects/dataset_write_sorted/treedb: dominant theme is write/delete/flush path (65.85% flat across top nodes).
- alloc_objects/dataset_write_sorted/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc" (4617 flat, 63.80%).
- alloc_objects/dataset_write_sorted/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc" is 63.80% flat; this section is highly concentrated in one function.
- alloc_objects/full_scan/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)" (49155 flat, 68.93%).
- alloc_objects/full_scan/treedb: top hotspot "github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)" is 68.93% flat; this section is highly concentrated in one function.
- alloc_objects/prefix_scan/treedb: top allocator by count is "runtime/pprof.(*profileBuilder).emitLocation" (6085 flat, 54.59%).
- alloc_objects/prefix_scan/treedb: top hotspot "runtime/pprof.(*profileBuilder).emitLocation" is 54.59% flat; this section is highly concentrated in one function.
- alloc_objects/random_delete/treedb: top allocator by count is "runtime/pprof.allFrames" (34953 flat, 97.22%).
- alloc_objects/random_delete/treedb: top hotspot "runtime/pprof.allFrames" is 97.22% flat; this section is highly concentrated in one function.
- alloc_objects/random_read/treedb: top allocator by count is "runtime/pprof.allFrames" (34953 flat, 99.93%).
- alloc_objects/random_read/treedb: top hotspot "runtime/pprof.allFrames" is 99.93% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_batch/treedb: top allocator by count is "runtime/pprof.allFrames" (7646 flat, 75.20%).
- alloc_objects/random_read_batch/treedb: top hotspot "runtime/pprof.allFrames" is 75.20% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_parallel/treedb: top allocator by count is "runtime/pprof.allFrames" (7646 flat, 49.05%).
- alloc_objects/random_read_parallel/treedb: top hotspot "runtime/pprof.allFrames" is 49.05% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_parallel_acquire_snapshot/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" (2395425 flat, 98.04%).
- alloc_objects/random_read_parallel_acquire_snapshot/treedb: top hotspot "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" is 98.04% flat; this section is highly concentrated in one function.
- alloc_objects/random_write/treedb: dominant theme is write/delete/flush path (79.93% flat across top nodes).
- alloc_objects/random_write/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked" (926 flat, 54.03%).
- alloc_objects/random_write/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked" is 54.03% flat; this section is highly concentrated in one function.
- alloc_objects/sequential_write/treedb: top allocator by count is "runtime/pprof.allFrames" (4370 flat, 49.23%).
- alloc_objects/sequential_write/treedb: top hotspot "runtime/pprof.allFrames" is 49.23% flat; this section is highly concentrated in one function.
- alloc_space/batch_delete/treedb: dominant theme is write/delete/flush path (66.13% flat across top nodes).
- alloc_space/batch_delete/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (10169.74kB flat, 33.68%).
- alloc_space/batch_random/treedb: dominant theme is write/delete/flush path (87.51% flat across top nodes).
- alloc_space/batch_random/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (36.38MB flat, 41.82%).
- alloc_space/batch_random/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 41.82% flat; this section is highly concentrated in one function.
- alloc_space/batch_small_seq/treedb: dominant theme is write/delete/flush path (95.23% flat across top nodes).
- alloc_space/batch_small_seq/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (60.61MB flat, 61.06%).
- alloc_space/batch_small_seq/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 61.06% flat; this section is highly concentrated in one function.
- alloc_space/batch_write/treedb: dominant theme is write/delete/flush path (70.12% flat across top nodes).
- alloc_space/batch_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (18641.66kB flat, 47.84%).
- alloc_space/batch_write/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 47.84% flat; this section is highly concentrated in one function.
- alloc_space/batch_write_steady/treedb: dominant theme is write/delete/flush path (86.57% flat across top nodes).
- alloc_space/batch_write_steady/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (89.31MB flat, 68.00%).
- alloc_space/batch_write_steady/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 68.00% flat; this section is highly concentrated in one function.
- alloc_space/dataset_write_random/treedb: dominant theme is write/delete/flush path (96.43% flat across top nodes).
- alloc_space/dataset_write_random/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (154.38MB flat, 77.78%).
- alloc_space/dataset_write_random/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 77.78% flat; this section is highly concentrated in one function.
- alloc_space/dataset_write_sorted/treedb: dominant theme is write/delete/flush path (67.65% flat across top nodes).
- alloc_space/dataset_write_sorted/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc" (9234.01kB flat, 32.90%).
- alloc_space/full_scan/treedb: top allocator by bytes is "runtime/pprof.(*profileBuilder).emitLocation" (4735.43kB flat, 27.86%).
- alloc_space/prefix_scan/treedb: dominant theme is value decode/read I/O (57.51% flat across top nodes).
- alloc_space/prefix_scan/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (4512.93kB flat, 37.18%).
- alloc_space/prefix_scan/treedb: top hotspot "compress/flate.NewWriter (inline)" is 37.18% flat; this section is highly concentrated in one function.
- alloc_space/random_delete/treedb: dominant theme is write/delete/flush path (87.83% flat across top nodes).
- alloc_space/random_delete/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (71.98MB flat, 87.83%).
- alloc_space/random_delete/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 87.83% flat; this section is highly concentrated in one function.
- alloc_space/random_read/treedb: dominant theme is value decode/read I/O (85.50% flat across top nodes).
- alloc_space/random_read/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (3610.34kB flat, 51.11%).
- alloc_space/random_read/treedb: top hotspot "compress/flate.NewWriter (inline)" is 51.11% flat; this section is highly concentrated in one function.
- alloc_space/random_read_batch/treedb: dominant theme is value decode/read I/O (55.74% flat across top nodes).
- alloc_space/random_read_batch/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (5415.52kB flat, 37.97%).
- alloc_space/random_read_batch/treedb: top hotspot "compress/flate.NewWriter (inline)" is 37.97% flat; this section is highly concentrated in one function.
- alloc_space/random_read_parallel/treedb: dominant theme is write/delete/flush path (41.45% flat across top nodes).
- alloc_space/random_read_parallel/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked" (3656.99kB flat, 22.61%).
- alloc_space/random_read_parallel_acquire_snapshot/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" (2.28GB flat, 99.48%).
- alloc_space/random_read_parallel_acquire_snapshot/treedb: top hotspot "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" is 99.48% flat; this section is highly concentrated in one function.
- alloc_space/random_write/treedb: dominant theme is write/delete/flush path (88.63% flat across top nodes).
- alloc_space/random_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (32.80MB flat, 47.72%).
- alloc_space/random_write/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 47.72% flat; this section is highly concentrated in one function.
- alloc_space/sequential_write/treedb: dominant theme is write/delete/flush path (61.31% flat across top nodes).
- alloc_space/sequential_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk" (27.34MB flat, 33.05%).
- block/batch_delete/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_delete/treedb: top hotspot "runtime.chanrecv1" is 100.00% flat; this section is highly concentrated in one function.
- block/batch_random/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_random/treedb: top hotspot "runtime.chanrecv1" is 50.14% flat; this section is highly concentrated in one function.
- block/batch_small_seq/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_small_seq/treedb: top hotspot "runtime.chanrecv1" is 50.30% flat; this section is highly concentrated in one function.
- block/batch_write/treedb: dominant theme is locking/scheduling contention (99.92% flat across top nodes).
- block/batch_write/treedb: top hotspot "runtime.selectgo" is 99.92% flat; this section is highly concentrated in one function.
- block/batch_write_steady/treedb: dominant theme is locking/scheduling contention (96.68% flat across top nodes).
- block/batch_write_steady/treedb: top hotspot "runtime.chanrecv2" is 46.95% flat; this section is highly concentrated in one function.
- block/dataset_write_random/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/dataset_write_random/treedb: top hotspot "runtime.selectgo" is 83.17% flat; this section is highly concentrated in one function.
- block/dataset_write_sorted/treedb: dominant theme is locking/scheduling contention (63.85% flat across top nodes).
- block/dataset_write_sorted/treedb: top hotspot "runtime.selectgo" is 57.75% flat; this section is highly concentrated in one function.
- block/full_scan/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/full_scan/treedb: top hotspot "runtime.selectgo" is 82.52% flat; this section is highly concentrated in one function.
- block/prefix_scan/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/prefix_scan/treedb: top hotspot "runtime.chanrecv1" is 100.00% flat; this section is highly concentrated in one function.
- block/random_delete/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/random_delete/treedb: top hotspot "runtime.selectgo" is 100.00% flat; this section is highly concentrated in one function.
- block/random_read/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/random_read/treedb: top hotspot "runtime.selectgo" is 85.54% flat; this section is highly concentrated in one function.
- block/random_read_batch/treedb: dominant theme is locking/scheduling contention (66.84% flat across top nodes).
- block/random_read_batch/treedb: top hotspot "runtime.chanrecv1" is 66.84% flat; this section is highly concentrated in one function.
- block/random_read_parallel/treedb: dominant theme is locking/scheduling contention (54.95% flat across top nodes).
- block/random_read_parallel/treedb: top hotspot "runtime.chanrecv1" is 54.95% flat; this section is highly concentrated in one function.
- block/random_read_parallel_acquire_snapshot/treedb: dominant theme is locking/scheduling contention (91.12% flat across top nodes).
- block/random_read_parallel_acquire_snapshot/treedb: top hotspot "runtime.selectgo" is 68.16% flat; this section is highly concentrated in one function.
- block/random_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/random_write/treedb: top hotspot "runtime.chanrecv1" is 100.00% flat; this section is highly concentrated in one function.
- block/sequential_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/sequential_write/treedb: top hotspot "runtime.selectgo" is 97.56% flat; this section is highly concentrated in one function.
- batch_delete/treedb: dominant theme is iterator/seek/compare overhead (50.00% flat across top nodes).
- batch_random/treedb: dominant theme is iterator/seek/compare overhead (42.86% flat across top nodes).
- batch_small_seq/treedb: dominant theme is iterator/seek/compare overhead (34.62% flat across top nodes).
- batch_write/treedb: dominant theme is iterator/seek/compare overhead (63.16% flat across top nodes).
- batch_write_steady/treedb: dominant theme is value decode/read I/O (29.35% flat across top nodes).
- dataset_write_sorted/treedb: dominant theme is iterator/seek/compare overhead (37.14% flat across top nodes).
- full_scan/treedb: dominant theme is value decode/read I/O (46.14% flat across top nodes).
- prefix_scan/treedb: dominant theme is iterator/seek/compare overhead (80.00% flat across top nodes).
- prefix_scan/treedb: top hotspot "runtime.scanObject" is 50.00% flat; this section is highly concentrated in one function.
- random_delete/treedb: dominant theme is iterator/seek/compare overhead (57.14% flat across top nodes).
- random_read/treedb: dominant theme is iterator/seek/compare overhead (44.45% flat across top nodes).
- random_read_batch/treedb: dominant theme is iterator/seek/compare overhead (28.85% flat across top nodes).
- random_read_parallel/treedb: dominant theme is write/delete/flush path (28.45% flat across top nodes).
- random_write/treedb: dominant theme is iterator/seek/compare overhead (23.53% flat across top nodes).
- sequential_write/treedb: dominant theme is iterator/seek/compare overhead (28.57% flat across top nodes).
- mutex/batch_random/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/batch_random/treedb: top hotspot "runtime.unlock (inline)" is 100.00% flat; this section is highly concentrated in one function.
- mutex/batch_write_steady/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/batch_write_steady/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 98.82% flat; this section is highly concentrated in one function.
- mutex/full_scan/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/full_scan/treedb: top hotspot "runtime.unlock (inline)" is 100.00% flat; this section is highly concentrated in one function.
- mutex/random_read/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/random_read/treedb: top hotspot "runtime.unlock (inline)" is 100.00% flat; this section is highly concentrated in one function.
- mutex/random_read_batch/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/random_read_batch/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 89.39% flat; this section is highly concentrated in one function.
- mutex/random_read_parallel_acquire_snapshot/treedb: dominant theme is locking/scheduling contention (99.95% flat across top nodes).
- mutex/random_read_parallel_acquire_snapshot/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 75.26% flat; this section is highly concentrated in one function.
- mutex/sequential_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/sequential_write/treedb: top hotspot "runtime.unlock (inline)" is 100.00% flat; this section is highly concentrated in one function.

## Investigation Targets

| db tag | test | category | function | flat% | code | why |
|---|---|---|---|---:|---|---|
| treedb | batch_delete | other | `runtime/pprof.allFrames` | 51.24% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `runtime/pprof.(*protobuf).varint (inline)` | 24.02% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 12.55% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 10.83% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 0.75% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `main.runBenchmark.func26` | 0.02% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | other | `runtime/pprof.(*profileBuilder).emitLocation` | 91.74% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | other | `runtime/pprof.printCountCycleProfile` | 5.24% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 1.39% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` | 0.61% | `TreeDB/internal/memtable/append_only.go:1217` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | other | `main.runBenchmark.func25` | 0.00% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 51.50% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | other | `runtime/pprof.printCountCycleProfile` | 19.00% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` | 14.41% | `TreeDB/caching/db.go:1738` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` | 12.96% | `TreeDB/caching/db.go:35746` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | other | `runtime/pprof.(*protobuf).varint (inline)` | 0.85% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | other | `runtime/pprof.(*profileBuilder).emitLocation` | 0.48% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | other | `runtime/pprof.allFrames` | 76.86% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 10.17% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | other | `runtime/pprof.(*profileBuilder).emitLocation` | 3.80% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 3.80% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | other | `runtime/pprof.(*protobuf).string (inline)` | 1.93% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 1.13% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` | 0.98% | `TreeDB/caching/db.go:36506` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | decode_read_io | `compress/flate.newDeflateFast (inline)` | 0.56% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | other | `github.com/snissn/gomap/TreeDB/caching.(*cachingLeafPageLog).CurrentLeafPageLogSegmentsSnapshot` | 38.30% | `TreeDB/caching/leaf_page_log.go:104` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.putAppendOnlyDirectValueArenaChunk` | 38.30% | `TreeDB/caching/db.go:1924` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | runtime_syscall | `syscall.ByteSliceFromString` | 9.57% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_write_steady | other | `runtime/pprof.allFrames` | 7.66% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | other | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).applySpanNativeWithPrepared` | 2.87% | `TreeDB/zipper/span_native_apply.go:320` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 0.78% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | other | `github.com/snissn/gomap/TreeDB/zipper.acquireSpanNativeSplitSlices` | 0.69% | `TreeDB/zipper/span_native_apply.go:796` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 60.20% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 11.29% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 10.00% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | other | `runtime/pprof.(*profileBuilder).emitLocation` | 7.44% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` | 7.01% | `TreeDB/internal/memtable/append_only.go:1405` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 3.02% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 0.69% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 63.80% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | other | `runtime/pprof.allFrames` | 30.19% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | decode_read_io | `compress/flate.(*huffmanEncoder).generate` | 3.15% | `TreeDB/db/fuzz_test.go:22` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 2.05% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | full_scan | other | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` | 68.93% | `TreeDB/node/leaf.go:106` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 30.77% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 54.59% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.allFrames` | 39.21% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 4.59% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.(*protobuf).string (inline)` | 0.72% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 0.50% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | other | `runtime/pprof.allFrames` | 97.22% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 1.88% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | other | `runtime/pprof.(*profileBuilder).emitLocation` | 0.81% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `runtime/pprof.allFrames` | 99.93% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.allFrames` | 75.20% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.printCountCycleProfile` | 21.49% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.(*profileBuilder).emitLocation` | 1.55% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 0.55% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.allFrames` | 49.05% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.(*profileBuilder).emitLocation` | 35.72% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.printCountCycleProfile` | 14.02% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 98.04% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | other | `runtime/pprof.(*profileBuilder).emitLocation` | 1.34% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | other | `runtime/pprof.allFrames` | 0.58% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 54.03% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 18.26% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | decode_read_io | `compress/flate.(*huffmanEncoder).generate` | 13.30% | `TreeDB/db/fuzz_test.go:22` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` | 6.71% | `TreeDB/internal/memtable/append_only.go:1405` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | other | `runtime/pprof.(*protobuf).string` | 5.72% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 0.93% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | decode_read_io | `compress/flate.newDeflateFast (inline)` | 0.47% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | decode_read_io | `compress/flate.(*compressor).init` | 0.29% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | other | `runtime/pprof.allFrames` | 49.23% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.init.func2` | 15.92% | `TreeDB/caching/db.go:1256` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | decode_read_io | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` | 14.48% | `TreeDB/db/leaf_page_read_cache.go:552` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 9.85% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/valuelog.ensureFrameBody (inline)` | 6.60% | `TreeDB/internal/valuelog/frame_preparer.go:266` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.newMergeScratch (inline)` | 1.44% | `TreeDB/zipper/zipper.go:304` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` | 1.10% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 33.68% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 27.61% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | decode_read_io | `compress/flate.NewWriter (inline)` | 11.96% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | decode_read_io | `compress/flate.newDeflateFast (inline)` | 5.79% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | other | `main.runBenchmark.func26` | 5.45% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` | 4.84% | `TreeDB/caching/db.go:1738` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | other | `runtime/pprof.(*profileBuilder).stringIndex` | 3.40% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | decode_read_io | `compress/flate.(*compressor).init` | 2.15% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 41.82% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` | 32.81% | `TreeDB/caching/db.go:1738` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 11.70% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | decode_read_io | `compress/flate.NewWriter (inline)` | 4.05% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_random | other | `main.runBenchmark.func25` | 1.85% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | other | `runtime/pprof.(*profileBuilder).emitLocation` | 1.75% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | other | `runtime/pprof.(*protobuf).varint (inline)` | 1.16% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | other | `runtime/pprof.(*protobuf).string (inline)` | 1.16% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 61.06% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getBatchArena` | 26.09% | `TreeDB/caching/db.go:1738` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 6.56% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | decode_read_io | `compress/flate.(*compressor).init` | 1.28% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` | 1.01% | `TreeDB/caching/db.go:35746` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | decode_read_io | `compress/flate.NewWriter (inline)` | 0.89% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_small_seq | decode_read_io | `compress/flate.newDeflateFast (inline)` | 0.57% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).retainBatchArenaChunksForMemtablesWithPolicy` | 0.51% | `TreeDB/caching/db.go:11348` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 47.84% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 13.37% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | decode_read_io | `compress/flate.NewWriter (inline)` | 11.58% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` | 5.66% | `TreeDB/caching/db.go:36506` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | decode_read_io | `compress/flate.newDeflateFast (inline)` | 4.39% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | other | `main.runBenchmark.func6` | 4.22% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchEntries` | 3.25% | `TreeDB/caching/db.go:36457` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | decode_read_io | `compress/flate.(*compressor).init` | 3.07% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 68.00% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 10.60% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve` | 5.38% | `TreeDB/batch/batch.go:448` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | decode_read_io | `compress/flate.NewWriter (inline)` | 3.36% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked` | 1.39% | `TreeDB/internal/memtable/append_only.go:1354` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | other | `main.runBenchmark.func6` | 1.22% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | decode_read_io | `compress/flate.(*compressor).init` | 0.97% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | other | `runtime/pprof.StartCPUProfile` | 0.88% | `TreeDB/cmd/vlog_dict_realdata/main.go:2197` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 77.78% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 7.02% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 5.17% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` | 3.62% | `TreeDB/internal/memtable/append_only.go:1405` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 2.53% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | decode_read_io | `compress/flate.NewWriter (inline)` | 2.22% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_random | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` | 0.51% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestSnapshotLocked` | 0.31% | `TreeDB/internal/memtable/append_only.go:2633` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 32.90% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 16.94% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | decode_read_io | `compress/flate.NewWriter (inline)` | 16.08% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 15.94% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | decode_read_io | `compress/flate.newDeflateFast (inline)` | 6.09% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_sorted | decode_read_io | `compress/flate.(*compressor).init` | 4.64% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_sorted | other | `runtime/pprof.(*profileBuilder).emitLocation` | 1.90% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 1.87% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | full_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 27.86% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | decode_read_io | `compress/flate.NewWriter (inline)` | 26.56% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | other | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` | 18.08% | `TreeDB/node/leaf.go:106` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | decode_read_io | `compress/flate.(*compressor).init` | 11.49% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | decode_read_io | `compress/flate.newDeflateFast (inline)` | 6.86% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | other | `runtime/pprof.(*protobuf).string (inline)` | 3.10% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.(*protobuf).varint (inline)` | 3.03% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 3.03% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | decode_read_io | `compress/flate.NewWriter (inline)` | 37.18% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 12.71% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | decode_read_io | `compress/flate.(*compressor).init` | 10.72% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | decode_read_io | `compress/flate.newDeflateFast (inline)` | 9.61% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | other | `runtime/pprof.(*protobuf).string (inline)` | 8.56% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.allFrames` | 8.44% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 4.31% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 4.26% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 87.83% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | decode_read_io | `compress/flate.NewWriter (inline)` | 4.30% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 2.45% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | decode_read_io | `compress/flate.newDeflateFast (inline)` | 2.04% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | decode_read_io | `compress/flate.(*compressor).init` | 1.55% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | other | `runtime/pprof.allFrames` | 1.22% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | other | `runtime/pprof.(*profileBuilder).emitLocation` | 0.61% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | decode_read_io | `compress/flate.NewWriter (inline)` | 51.11% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | decode_read_io | `compress/flate.(*compressor).init` | 18.42% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | decode_read_io | `compress/flate.newDeflateFast (inline)` | 15.97% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | other | `runtime/pprof.allFrames` | 14.50% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.NewWriter (inline)` | 37.97% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `github.com/snissn/gomap/TreeDB/tree.getGetManyScratch` | 15.10% | `TreeDB/tree/tree.go:1188` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.(*compressor).init` | 13.68% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `runtime/pprof.(*profileBuilder).emitLocation` | 7.48% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.allFrames` | 7.18% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.newDeflateFast (inline)` | 4.09% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `runtime/pprof.(*protobuf).varint (inline)` | 3.65% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 3.65% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked` | 22.61% | `TreeDB/internal/memtable/append_only.go:1354` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.NewWriter (inline)` | 22.33% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestSnapshotLocked` | 18.84% | `TreeDB/internal/memtable/append_only.go:2633` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read_parallel | other | `runtime/pprof.(*profileBuilder).emitLocation` | 9.58% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.(*compressor).init` | 7.39% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `runtime/pprof.allFrames` | 6.33% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.newDeflateFast (inline)` | 3.37% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 3.19% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 99.48% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 47.72% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 23.69% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 14.26% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | decode_read_io | `compress/flate.NewWriter (inline)` | 6.41% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` | 2.96% | `TreeDB/internal/memtable/append_only.go:1405` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | decode_read_io | `compress/flate.(*compressor).init` | 1.85% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | decode_read_io | `compress/flate.newDeflateFast (inline)` | 1.66% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | other | `runtime/pprof.(*protobuf).string` | 0.73% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 33.05% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 12.95% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve` | 8.54% | `TreeDB/batch/batch.go:448` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.init.func2` | 6.67% | `TreeDB/caching/db.go:1256` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | decode_read_io | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` | 6.07% | `TreeDB/db/leaf_page_read_cache.go:552` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.acquireSpanNativeLeafLogPayloadArena` | 5.57% | `TreeDB/zipper/span_native_apply.go:87` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | decode_read_io | `compress/flate.NewWriter (inline)` | 5.33% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/valuelog.getWriterAppendBuf` | 4.84% | `TreeDB/internal/valuelog/writer.go:382` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | locking_scheduling | `runtime.chanrecv1` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_random | locking_scheduling | `runtime.chanrecv1` | 50.14% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_random | locking_scheduling | `runtime.selectgo` | 49.86% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_small_seq | locking_scheduling | `runtime.chanrecv1` | 50.30% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_small_seq | locking_scheduling | `runtime.selectgo` | 49.70% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write | locking_scheduling | `runtime.selectgo` | 99.92% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `runtime.chanrecv2` | 46.95% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `runtime.selectgo` | 38.80% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `runtime.chanrecv1` | 9.01% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | other | `sync.(*WaitGroup).Wait` | 3.30% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | locking_scheduling | `sync.(*Mutex).Lock` | 1.92% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | locking_scheduling | `runtime.selectgo` | 83.17% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | locking_scheduling | `runtime.chanrecv1` | 16.83% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | locking_scheduling | `runtime.selectgo` | 57.75% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | other | `sync.(*WaitGroup).Wait` | 36.15% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | locking_scheduling | `runtime.chanrecv1` | 6.10% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | locking_scheduling | `runtime.selectgo` | 82.52% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | locking_scheduling | `runtime.chanrecv1` | 17.48% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | prefix_scan | locking_scheduling | `runtime.chanrecv1` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | locking_scheduling | `runtime.selectgo` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | locking_scheduling | `runtime.selectgo` | 85.54% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | locking_scheduling | `runtime.chanrecv1` | 14.46% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `runtime.chanrecv1` | 66.84% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | other | `sync.(*WaitGroup).Wait` | 32.87% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | locking_scheduling | `runtime.chanrecv1` | 54.95% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | other | `sync.(*WaitGroup).Wait` | 45.05% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.selectgo` | 68.16% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.chanrecv1` | 15.11% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | other | `sync.(*WaitGroup).Wait` | 8.88% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 7.05% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `sync.(*RWMutex).RLock (inline)` | 0.80% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | locking_scheduling | `runtime.chanrecv1` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime.selectgo` | 97.56% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime.chanrecv1` | 2.44% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_delete | iterator_seek_compare | `runtime.scanObject` | 25.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_delete | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 18.75% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_delete | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 12.50% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).cloneKey` | 6.25% | `TreeDB/caching/db.go:37077` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` | 6.25% | `TreeDB/internal/memtable/append_only.go:1519` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | alloc_copy_gc | `runtime.(*gcBitsArena).tryAlloc (inline)` | 6.25% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_delete | runtime_syscall | `runtime.futex` | 6.25% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_delete | runtime_syscall | `runtime.heapArenaOf (inline)` | 6.25% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_random | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 21.43% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_random | iterator_seek_compare | `runtime.typePointers.next` | 21.43% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).noteEntryAppend` | 7.14% | `TreeDB/caching/db.go:36868` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWriteKey` | 7.14% | `TreeDB/caching/db.go:12338` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `internal/runtime/maps.(*table).uncheckedPutSlot` | 7.14% | - | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | runtime_syscall | `runtime.cheaprandn (inline)` | 7.14% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_random | alloc_copy_gc | `runtime.memmove` | 7.14% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_random | runtime_syscall | `runtime.spanClass.sizeclass (inline)` | 7.14% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_small_seq | iterator_seek_compare | `runtime.scanObject` | 19.23% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_small_seq | alloc_copy_gc | `runtime.memclrNoHeapPointers` | 15.38% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_small_seq | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 7.69% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | runtime_syscall | `runtime.futex` | 7.69% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_small_seq | alloc_copy_gc | `runtime.memmove` | 7.69% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_small_seq | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 7.69% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` | 3.85% | `TreeDB/internal/memtable/append_only.go:1461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | other | `internal/runtime/atomic.(*UnsafePointer).Load` | 3.85% | `TreeDB/caching/db.go:8970` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | iterator_seek_compare | `runtime.scanObject` | 31.58% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 15.79% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write | iterator_seek_compare | `runtime.typePointers.next` | 15.79% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write | runtime_syscall | `runtime.spanOf (inline)` | 10.53% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ApplyCopySortedBatchWithValueCopierTrusted` | 5.26% | `TreeDB/internal/memtable/append_only.go:1749` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` | 5.26% | `TreeDB/internal/memtable/append_only.go:1461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 5.26% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | write_delete_flush | `runtime.(*sweepClass).update (inline)` | 5.26% | `TreeDB/public.go:2264` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 27.17% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | alloc_copy_gc | `runtime.memmove` | 8.70% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_write_steady | iterator_seek_compare | `cmpbody` | 4.35% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write_steady | other | `internal/runtime/syscall/linux.Syscall6` | 4.35% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | other | `sort.partition_func` | 3.26% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked.func1` | 2.17% | `TreeDB/internal/memtable/append_only.go:1354` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).entryAt` | 2.17% | `TreeDB/internal/memtable/append_only.go:2819` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write_steady | other | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafValueViewColumnarPrefixV2` | 2.17% | `TreeDB/node/leaf.go:1376` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 11.76% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 11.76% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 11.76% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_random | other | `sync/atomic.(*Int32).Add (inline)` | 11.76% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` | 5.88% | `TreeDB/internal/memtable/append_only.go:1461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | iterator_seek_compare | `internal/runtime/atomic.(*Uint32).CompareAndSwap` | 5.88% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_random | iterator_seek_compare | `internal/runtime/maps.(*Iter).Next` | 5.88% | `HashDB/BTreeOnHashDB/iter.go:251` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_random | write_delete_flush | `internal/runtime/maps.(*ctrlGroup).setEmpty (inline)` | 5.88% | - | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 17.14% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_sorted | alloc_copy_gc | `runtime.memclrNoHeapPointers` | 14.29% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | dataset_write_sorted | iterator_seek_compare | `runtime.scanObject` | 8.57% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_sorted | map_hash_lookup | `github.com/cespare/xxhash/v2.Sum64` | 5.71% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | dataset_write_sorted | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 5.71% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | runtime_syscall | `runtime.(*activeSweep).end` | 5.71% | `TreeDB/bg_vacuum.go:348` | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | dataset_write_sorted | iterator_seek_compare | `runtime.typePointers.next` | 5.71% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).beginMVCCInputCut (inline)` | 2.86% | `TreeDB/caching/mvcc_admission.go:8` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | full_scan | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 32.69% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | iterator_seek_compare | `runtime.scanObject` | 15.38% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | full_scan | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 5.77% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | other | `internal/runtime/syscall/linux.Syscall6` | 5.77% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 3.85% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | full_scan | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL256` | 1.92% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).UnsafeValue` | 1.92% | `TreeDB/db/api.go:738` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | full_scan | decode_read_io | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithCOWPolicy` | 1.92% | `TreeDB/db/leaf_page_read_cache.go:814` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.scanObject` | 50.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.typePointers.next` | 15.00% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 10.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | decode_read_io | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithCOWPolicy` | 5.00% | `TreeDB/db/leaf_page_read_cache.go:814` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | other | `internal/runtime/atomic.(*Uint32).Add (inline)` | 5.00% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | runtime_syscall | `runtime.pcvalue` | 5.00% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | prefix_scan | runtime_syscall | `runtime.spanClass.sizeclass (inline)` | 5.00% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.typePointers.nextFast (inline)` | 5.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | iterator_seek_compare | `runtime.scanObject` | 23.81% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | iterator_seek_compare | `runtime.typePointers.next` | 14.29% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 9.52% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | map_hash_lookup | `github.com/cespare/xxhash/v2.Sum64` | 4.76% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | random_delete | iterator_seek_compare | `internal/runtime/atomic.(*Uint32).CompareAndSwap` | 4.76% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 4.76% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | other | `internal/runtime/maps.h1 (inline)` | 4.76% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 4.76% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | iterator_seek_compare | `runtime.scanObject` | 25.93% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read | iterator_seek_compare | `runtime.typePointers.next` | 11.11% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read | iterator_seek_compare | `runtime.typePointers.nextFast (inline)` | 7.41% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read | other | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteMemtableViewRelease (inline)` | 3.70% | `TreeDB/caching/db.go:10536` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | decode_read_io | `github.com/snissn/gomap/TreeDB/caching.(*DB).registerMemtableViewReader` | 3.70% | `TreeDB/caching/db.go:10732` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).lookupEntryLocked` | 3.70% | `TreeDB/internal/memtable/append_only.go:2069` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read | locking_scheduling | `internal/chacha8rand.block` | 3.70% | `TreeDB/internal/typedcolumn/stats.go:134` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | write_delete_flush | `internal/runtime/maps.(*table).uncheckedPutSlot` | 3.70% | - | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read_batch | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 13.46% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | iterator_seek_compare | `runtime.scanObject` | 13.46% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_batch | other | `internal/runtime/syscall/linux.Syscall6` | 7.69% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).takeDecodeScratch` | 3.85% | `TreeDB/internal/valuelog/manager.go:406` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` | 3.85% | `TreeDB/node/internal.go:671` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_batch | other | `github.com/snissn/gomap/TreeDB/node.getUint64BEAt (inline)` | 3.85% | `TreeDB/node/node.go:70` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | runtime_syscall | `runtime.step` | 3.85% | `TreeDB/pager/grow_work.go:94` | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_read_batch | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 3.85% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_parallel | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` | 24.14% | `TreeDB/internal/memtable/append_only.go:718` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read_parallel | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 12.07% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | map_hash_lookup | `runtime.mapaccess2_fast64` | 8.62% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | random_read_parallel | iterator_seek_compare | `runtime.scanObject` | 6.03% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_parallel | alloc_copy_gc | `runtime.memmove` | 5.17% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | random_read_parallel | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 4.31% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_parallel | map_hash_lookup | `github.com/cespare/xxhash/v2.Sum64` | 3.45% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | random_read_parallel | map_hash_lookup | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).lookupCachedRootDomainEntryWithRevision` | 3.45% | `TreeDB/caching/snapshot.go:480` | Focus on key-shape and hash-table lookup/update costs. |
| treedb | random_read_parallel_acquire_snapshot | runtime_syscall | `runtime.procyieldAsm` | 15.97% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_read_parallel_acquire_snapshot | other | `sync/atomic.(*Int32).Add (inline)` | 8.77% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 7.98% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 4.63% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | other | `internal/runtime/syscall/linux.Syscall6` | 3.78% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).lockSlow` | 3.42% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 1.92% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | other | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView (inline)` | 1.71% | `TreeDB/node/node.go:165` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 17.65% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` | 5.88% | `TreeDB/internal/memtable/append_only.go:1461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | other | `internal/runtime/maps.(*Map).directoryIndex (inline)` | 5.88% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `internal/runtime/maps.(*ctrlGroup).setEmpty (inline)` | 5.88% | - | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 5.88% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | runtime_syscall | `runtime.(*memRecordCycle).add` | 5.88% | `TreeDB/db/pools.go:215` | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_write | runtime_syscall | `runtime.heapArenaOf (inline)` | 5.88% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_write | map_hash_lookup | `runtime.mapassign_fast64` | 5.88% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | sequential_write | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 21.43% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectWithMVCCInput` | 14.29% | `TreeDB/caching/db.go:27309` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 14.29% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` | 7.14% | `TreeDB/internal/memtable/append_only.go:1461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | other | `internal/runtime/atomic.(*Uintptr).Load (inline)` | 7.14% | `TreeDB/caching/db.go:8970` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 7.14% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | alloc_copy_gc | `runtime.memmove` | 7.14% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | sequential_write | iterator_seek_compare | `runtime.scanObject` | 7.14% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_random | locking_scheduling | `runtime.unlock (inline)` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 98.82% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `sync.(*RWMutex).Unlock` | 1.18% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | locking_scheduling | `runtime.unlock (inline)` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | locking_scheduling | `runtime.unlock (inline)` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 89.39% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `sync.(*RWMutex).Unlock` | 8.75% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `sync.(*RWMutex).RUnlock (inline)` | 1.10% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 75.26% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.unlock (inline)` | 14.07% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime.unlock (inline)` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |

## Warnings

- trace detected at "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/fast_no_checkpoint_between_tests/trace.out" (trace analysis not yet implemented)

