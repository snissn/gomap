# Bench Profile Insights

- generated: `2026-11-20T18:07:40Z`
- profiles dir: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests`
- binary: `./bin/unified-bench`
- ops source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/benchprof_results.json`

## Scan Ops/Sec

| Label | Full Scan | Prefix Scan | Prefix / Full |
|---|---:|---:|---:|
| TreeDB | 2,701,489 | 3,907,378 | 1.45x |

## CPU Hotspots

### batch_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_batch_delete_treedb.pprof`
- total samples: `150ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 20.00% | 70ms | 46.67% | `runtime.scanObject` |
| 10ms | 6.67% | 10ms | 6.67% | `compress/flate.hash (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Delete` |
| 10ms | 6.67% | 40ms | 26.67% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 10ms | 6.67% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB/caching.assignLegacyPointEntryRevisions (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `internal/runtime/maps.probeSeq.next (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.(*spanSet).pop` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.cheaprand` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.findObject` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.spanClass.sizeclass (inline)` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.typePointers.next` |
| 10ms | 6.67% | 10ms | 6.67% | `runtime.typePointers.nextFast (inline)` |
| 0 | 0.00% | 10ms | 6.67% | `compress/flate.(*Writer).Close (inline)` |
| 0 | 0.00% | 10ms | 6.67% | `compress/flate.(*compressor).close` |
| 0 | 0.00% | 10ms | 6.67% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 10ms | 6.67% | `compress/flate.(*deflateFast).encode` |
| 0 | 0.00% | 10ms | 6.67% | `compress/gzip.(*Writer).Close` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared (inline)` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func1` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 10ms | 6.67% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |

### batch_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_batch_random_treedb.pprof`
- total samples: `270ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 40ms | 14.81% | 40ms | 14.81% | `internal/runtime/syscall/linux.Syscall6` |
| 40ms | 14.81% | 40ms | 14.81% | `runtime.tryDeferToSpanScan` |
| 20ms | 7.41% | 20ms | 7.41% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayload.func1` |
| 20ms | 7.41% | 20ms | 7.41% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 20ms | 7.41% | 70ms | 25.93% | `runtime.scanObject` |
| 20ms | 7.41% | 20ms | 7.41% | `runtime.step` |
| 10ms | 3.70% | 10ms | 3.70% | `encoding/binary.littleEndian.PutUint32 (inline)` |
| 10ms | 3.70% | 100ms | 37.04% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 10ms | 3.70% | 30ms | 11.11% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 10ms | 3.70% | 10ms | 3.70% | `internal/runtime/atomic.(*Uint64).CompareAndSwap` |
| 10ms | 3.70% | 10ms | 3.70% | `internal/runtime/maps.(*ctrlGroup).get (inline)` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.(*spanSet).push` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.ifaceeq` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.memclrNoHeapPointers` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.memmove` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.typePointers.next` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.typedmemmove` |
| 0 | 0.00% | 40ms | 14.81% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 40ms | 14.81% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared (inline)` |
| 0 | 0.00% | 40ms | 14.81% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 40ms | 14.81% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 40ms | 14.81% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 40ms | 14.81% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 40ms | 14.81% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 20ms | 7.41% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Set` |

### batch_small_seq (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_batch_small_seq_treedb.pprof`
- total samples: `310ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 70ms | 22.58% | 70ms | 22.58% | `internal/runtime/syscall/linux.Syscall6` |
| 40ms | 12.90% | 90ms | 29.03% | `runtime.scanObject` |
| 30ms | 9.68% | 30ms | 9.68% | `runtime.memclrNoHeapPointers` |
| 30ms | 9.68% | 30ms | 9.68% | `runtime.step` |
| 30ms | 9.68% | 30ms | 9.68% | `runtime.tryDeferToSpanScan` |
| 10ms | 3.23% | 70ms | 22.58% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 10ms | 3.23% | 20ms | 6.45% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setViewValidatedWithMVCCInput` |
| 10ms | 3.23% | 10ms | 3.23% | `github.com/snissn/gomap/TreeDB/caching.assignLegacyPointEntryRevisions (inline)` |
| 10ms | 3.23% | 10ms | 3.23% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey` |
| 10ms | 3.23% | 10ms | 3.23% | `github.com/snissn/gomap/TreeDB/internal/mvccadmission.(*Summary).Observe` |
| 10ms | 3.23% | 10ms | 3.23% | `internal/bytealg.Compare` |
| 10ms | 3.23% | 10ms | 3.23% | `runtime.(*consistentHeapStats).release` |
| 10ms | 3.23% | 10ms | 3.23% | `runtime.(*mspan).moveInlineMarks` |
| 10ms | 3.23% | 10ms | 3.23% | `runtime.findObject` |
| 10ms | 3.23% | 10ms | 3.23% | `runtime.reentersyscall` |
| 10ms | 3.23% | 10ms | 3.23% | `runtime.typePointers.next` |
| 0 | 0.00% | 10ms | 3.23% | `bytes.Compare` |
| 0 | 0.00% | 70ms | 22.58% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 70ms | 22.58% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared` |
| 0 | 0.00% | 70ms | 22.58% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 10ms | 3.23% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func1` |
| 0 | 0.00% | 60ms | 19.35% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 70ms | 22.58% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 70ms | 22.58% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 30ms | 9.68% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Close` |

### batch_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_batch_write_treedb.pprof`
- total samples: `240ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 80ms | 33.33% | 80ms | 33.33% | `internal/runtime/syscall/linux.Syscall6` |
| 40ms | 16.67% | 40ms | 16.67% | `runtime.tryDeferToSpanScan` |
| 20ms | 8.33% | 20ms | 8.33% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setViewValidatedWithMVCCInput` |
| 20ms | 8.33% | 20ms | 8.33% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 20ms | 8.33% | 20ms | 8.33% | `runtime.memmove` |
| 10ms | 4.17% | 10ms | 4.17% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 10ms | 4.17% | 10ms | 4.17% | `runtime.getempty` |
| 10ms | 4.17% | 10ms | 4.17% | `runtime.memclrNoHeapPointers` |
| 10ms | 4.17% | 70ms | 29.17% | `runtime.scanObject` |
| 10ms | 4.17% | 10ms | 4.17% | `runtime.typePointers.next` |
| 10ms | 4.17% | 10ms | 4.17% | `runtime.typePointers.nextFast (inline)` |
| 0 | 0.00% | 10ms | 4.17% | `compress/flate.NewWriter (inline)` |
| 0 | 0.00% | 10ms | 4.17% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 10ms | 4.17% | `github.com/snissn/go-crc32-asm.Checksum (inline)` |
| 0 | 0.00% | 10ms | 4.17% | `github.com/snissn/go-crc32-asm.Update` |
| 0 | 0.00% | 10ms | 4.17% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 0 | 0.00% | 10ms | 4.17% | `github.com/snissn/go-crc32-asm.updateIEEE` |
| 0 | 0.00% | 70ms | 29.17% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 70ms | 29.17% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 70ms | 29.17% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared` |
| 0 | 0.00% | 70ms | 29.17% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared.func1` |
| 0 | 0.00% | 70ms | 29.17% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 70ms | 29.17% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 70ms | 29.17% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 20ms | 8.33% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).SetView` |

### batch_write_steady (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_batch_write_steady_treedb.pprof`
- total samples: `1.60s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.80s | 50.00% | 0.81s | 50.62% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.22s | 13.75% | 0.22s | 13.75% | `internal/runtime/syscall/linux.Syscall6` |
| 0.08s | 5.00% | 0.08s | 5.00% | `runtime.memmove` |
| 0.04s | 2.50% | 0.05s | 3.12% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 0.02s | 1.25% | 0.02s | 1.25% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 0.02s | 1.25% | 0.09s | 5.62% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0.02s | 1.25% | 0.02s | 1.25% | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Less` |
| 0.02s | 1.25% | 1.03s | 64.38% | `github.com/snissn/gomap/TreeDB/internal/valuelog.readAtWithDictToScratch` |
| 0.02s | 1.25% | 0.02s | 1.25% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2ValueMetaAt` |
| 0.02s | 1.25% | 0.02s | 1.25% | `github.com/snissn/gomap/TreeDB/page.DecodeLogRecordRef` |
| 0.02s | 1.25% | 0.02s | 1.25% | `runtime.fpTracebackPCs (inline)` |
| 0.01s | 0.62% | 0.01s | 0.62% | `cmpbody` |
| 0.01s | 0.62% | 0.01s | 0.62% | `countbody` |
| 0.01s | 0.62% | 0.01s | 0.62% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 0.01s | 0.62% | 0.04s | 2.50% | `github.com/snissn/go-crc32-asm.Update` |
| 0.01s | 0.62% | 0.02s | 1.25% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).setViewWithMVCCInput` |
| 0.01s | 0.62% | 0.03s | 1.88% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).pop` |
| 0.01s | 0.62% | 0.07s | 4.38% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 0.01s | 0.62% | 0.01s | 0.62% | `github.com/snissn/gomap/TreeDB/caching.pointEntryRevisionStats (inline)` |
| 0.01s | 0.62% | 0.04s | 2.50% | `github.com/snissn/gomap/TreeDB/db.(*DB).maintenanceReachabilityScan.func3` |
| 0.01s | 0.62% | 0.07s | 4.38% | `github.com/snissn/gomap/TreeDB/db.(*DB).maintenanceReachabilityScan.func4` |
| 0.01s | 0.62% | 0.01s | 0.62% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchRIDs.func1` |
| 0.01s | 0.62% | 0.01s | 0.62% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).resetLockedWithPolicy` |
| 0.01s | 0.62% | 0.01s | 0.62% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).entryAt (inline)` |
| 0.01s | 0.62% | 0.02s | 1.25% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).validIndex` |

### checkpoint/batch_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_batch_delete_treedb.pprof`
- total samples: `1.74s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.88s | 50.57% | 0.89s | 51.15% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.12s | 6.90% | 0.12s | 6.90% | `internal/runtime/syscall/linux.Syscall6` |
| 0.05s | 2.87% | 0.05s | 2.87% | `runtime.memmove` |
| 0.04s | 2.30% | 0.06s | 3.45% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 0.04s | 2.30% | 0.04s | 2.30% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 0.04s | 2.30% | 0.04s | 2.30% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).UnsafeEntryWithRevision` |
| 0.02s | 1.15% | 0.02s | 1.15% | `cmpbody` |
| 0.02s | 1.15% | 0.02s | 1.15% | `countbody` |
| 0.02s | 1.15% | 0.02s | 1.15% | `encoding/binary.littleEndian.Uint64 (inline)` |
| 0.02s | 1.15% | 0.02s | 1.15% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` |
| 0.02s | 1.15% | 0.03s | 1.72% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafValueView` |
| 0.02s | 1.15% | 0.02s | 1.15% | `hash/crc32.ieeeCLMUL` |
| 0.02s | 1.15% | 0.02s | 1.15% | `runtime.fpTracebackPCs` |
| 0.02s | 1.15% | 0.02s | 1.15% | `runtime.nanotime` |
| 0.02s | 1.15% | 0.02s | 1.15% | `runtime.step` |
| 0.01s | 0.57% | 0.90s | 51.72% | `github.com/pierrec/lz4/v4/internal/lz4block.UncompressBlock` |
| 0.01s | 0.57% | 0.06s | 3.45% | `github.com/snissn/go-crc32-asm.updateIEEEFast` |
| 0.01s | 0.57% | 0.01s | 0.57% | `github.com/snissn/gomap/TreeDB/batch.DeleteRangesContainKey` |
| 0.01s | 0.57% | 0.01s | 0.57% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ReserveValueLogRIDs` |
| 0.01s | 0.57% | 0.02s | 1.15% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).pop` |
| 0.01s | 0.57% | 0.01s | 0.57% | `github.com/snissn/gomap/TreeDB/caching.clearValueLogRecordValues` |
| 0.01s | 0.57% | 0.08s | 4.60% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 0.01s | 0.57% | 0.01s | 0.57% | `github.com/snissn/gomap/TreeDB/caching.recordLaneVlogPayloadKindObservation` |
| 0.01s | 0.57% | 0.01s | 0.57% | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Swap (inline)` |
| 0.01s | 0.57% | 0.28s | 16.09% | `github.com/snissn/gomap/TreeDB/db.(*cachedLeafPageReader).ReadUnsafeToWithCacheHit` |

### checkpoint/batch_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_batch_random_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/batch_small_seq (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_batch_small_seq_treedb.pprof`
- total samples: `1.21s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.66s | 54.55% | 0.66s | 54.55% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.12s | 9.92% | 0.12s | 9.92% | `internal/runtime/syscall/linux.Syscall6` |
| 0.03s | 2.48% | 0.03s | 2.48% | `cmpbody` |
| 0.02s | 1.65% | 0.02s | 1.65% | `github.com/snissn/gomap/TreeDB/internal/valuelog.decodeFrameValueBounds` |
| 0.02s | 1.65% | 0.94s | 77.69% | `github.com/snissn/gomap/TreeDB/node.(*Node).WalkInternalChildren` |
| 0.02s | 1.65% | 0.02s | 1.65% | `hash/crc32.ieeeCLMUL` |
| 0.02s | 1.65% | 0.02s | 1.65% | `runtime.nanotime (inline)` |
| 0.01s | 0.83% | 0.01s | 0.83% | `countbody` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/pierrec/lz4/v4/internal/lz4block.blockHash` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).down` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/caching.recordLaneVlogPayloadKindObservation` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeIntoBackingLocked` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayload.func1` |
| 0.01s | 0.83% | 0.02s | 1.65% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked.func1` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).UnsafeEntryWithRevision` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).currentWritablePersistentMmapEnabled` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/internal/valuelog.decodeFramePayloadTo.func1` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafEntryViewWithRevision` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2ValueMetaAt` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/page.DecodeLogRecordRef (inline)` |
| 0.01s | 0.83% | 0.01s | 0.83% | `github.com/snissn/gomap/TreeDB/zipper.(*mergeScratch).acquireLeafRefCacheBuildPage` |
| 0.01s | 0.83% | 0.01s | 0.83% | `hash/crc32.init.OnceFunc.func4` |
| 0.01s | 0.83% | 0.01s | 0.83% | `hash/crc32.slicingUpdate` |

### checkpoint/batch_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_batch_write_treedb.pprof`
- total samples: `2.45s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1.04s | 42.45% | 1.04s | 42.45% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.23s | 9.39% | 0.23s | 9.39% | `internal/runtime/syscall/linux.Syscall6` |
| 0.15s | 6.12% | 0.15s | 6.12% | `runtime.memmove` |
| 0.11s | 4.49% | 0.11s | 4.49% | `hash/crc32.ieeeCLMUL` |
| 0.11s | 4.49% | 0.11s | 4.49% | `hash/crc32.simpleUpdate (inline)` |
| 0.05s | 2.04% | 0.05s | 2.04% | `internal/sync.(*Mutex).Lock (inline)` |
| 0.03s | 1.22% | 0.04s | 1.63% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 0.03s | 1.22% | 0.14s | 5.71% | `github.com/snissn/gomap/TreeDB/internal/commitlog.validateFixedWALFrames` |
| 0.03s | 1.22% | 0.19s | 7.76% | `io.ReadAtLeast` |
| 0.02s | 0.82% | 0.16s | 6.53% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 0.02s | 0.82% | 0.02s | 0.82% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL256` |
| 0.02s | 0.82% | 0.02s | 0.82% | `github.com/snissn/gomap/TreeDB/caching.clearValueLogRecordValues` |
| 0.02s | 0.82% | 0.03s | 1.22% | `github.com/snissn/gomap/TreeDB/node.(*Builder).addLeafEntryColumnarPrefixV2` |
| 0.02s | 0.82% | 1.10s | 44.90% | `github.com/snissn/gomap/TreeDB/node.(*Node).WalkInternalChildren` |
| 0.02s | 0.82% | 0.14s | 5.71% | `hash/crc32.ChecksumIEEE` |
| 0.02s | 0.82% | 0.02s | 0.82% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 0.02s | 0.82% | 0.02s | 0.82% | `memeqbody` |
| 0.02s | 0.82% | 0.02s | 0.82% | `runtime.(*traceMap).put` |
| 0.01s | 0.41% | 0.15s | 6.12% | `bufio.(*Reader).Read` |
| 0.01s | 0.41% | 0.35s | 14.29% | `github.com/snissn/go-crc32-asm.Update` |
| 0.01s | 0.41% | 0.15s | 6.12% | `github.com/snissn/go-crc32-asm.checksumIEEEFallback (inline)` |
| 0.01s | 0.41% | 0.02s | 0.82% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).down` |
| 0.01s | 0.41% | 0.22s | 8.98% | `github.com/snissn/gomap/TreeDB/db.scanCommandWALSegmentReader` |
| 0.01s | 0.41% | 0.17s | 6.94% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Reader).ReadValidatedCommandFrameLSN` |
| 0.01s | 0.41% | 0.07s | 2.86% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*fixedWALStream).Read` |

### checkpoint/batch_write_steady (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_batch_write_steady_treedb.pprof`
- total samples: `1.48s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.88s | 59.46% | 0.90s | 60.81% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.13s | 8.78% | 0.13s | 8.78% | `internal/runtime/syscall/linux.Syscall6` |
| 0.07s | 4.73% | 0.07s | 4.73% | `runtime.memmove` |
| 0.04s | 2.70% | 0.04s | 2.70% | `runtime.fpTracebackPCs (inline)` |
| 0.03s | 2.03% | 0.03s | 2.03% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 0.02s | 1.35% | 0.02s | 1.35% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 0.02s | 1.35% | 0.02s | 1.35% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).setViewWithMVCCInput` |
| 0.02s | 1.35% | 0.02s | 1.35% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafValueViewColumnarPrefixV2` |
| 0.02s | 1.35% | 0.02s | 1.35% | `internal/sync.(*Mutex).Unlock (inline)` |
| 0.01s | 0.68% | 0.01s | 0.68% | `cmpbody` |
| 0.01s | 0.68% | 0.01s | 0.68% | `countbody` |
| 0.01s | 0.68% | 0.01s | 0.68% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 0.01s | 0.68% | 0.02s | 1.35% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).down` |
| 0.01s | 0.68% | 0.01s | 0.68% | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Swap (inline)` |
| 0.01s | 0.68% | 0.01s | 0.68% | `github.com/snissn/gomap/TreeDB/db.(*Batch).rawSpanNativeBatchPlan` |
| 0.01s | 0.68% | 0.06s | 4.05% | `github.com/snissn/gomap/TreeDB/db.(*DB).maintenanceReachabilityScan.func4` |
| 0.01s | 0.68% | 1.21s | 81.76% | `github.com/snissn/gomap/TreeDB/db.(*DB).maintenanceReachabilityScan.func5` |
| 0.01s | 0.68% | 0.01s | 0.68% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheBucket).resetReadMissCandidateLocked` |
| 0.01s | 0.68% | 0.01s | 0.68% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildOrderedKey64Locked` |
| 0.01s | 0.68% | 0.01s | 0.68% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).UnsafeKey` |
| 0.01s | 0.68% | 1.15s | 77.70% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |
| 0.01s | 0.68% | 0.01s | 0.68% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).stashDecodeScratchLocked` |
| 0.01s | 0.68% | 0.03s | 2.03% | `github.com/snissn/gomap/TreeDB/internal/valuelog.maybeDecodeLeafLogPayloadToAllowed` |
| 0.01s | 0.68% | 1.12s | 75.68% | `github.com/snissn/gomap/TreeDB/internal/valuelog.readAtWithDictToScratch` |
| 0.01s | 0.68% | 0.02s | 1.35% | `github.com/snissn/gomap/TreeDB/node.(*Builder).addLeafEntryColumnarPrefixV2` |

### checkpoint/dataset_write_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_dataset_write_random_treedb.pprof`
- total samples: `1.77s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.53s | 29.94% | 0.54s | 30.51% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.14s | 7.91% | 0.14s | 7.91% | `internal/runtime/syscall/linux.Syscall6` |
| 0.13s | 7.34% | 0.13s | 7.34% | `runtime.memmove` |
| 0.10s | 5.65% | 0.10s | 5.65% | `hash/crc32.simpleUpdate (inline)` |
| 0.09s | 5.08% | 0.09s | 5.08% | `hash/crc32.ieeeCLMUL` |
| 0.04s | 2.26% | 0.55s | 31.07% | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` |
| 0.04s | 2.26% | 0.23s | 12.99% | `hash/crc32.archUpdateIEEE` |
| 0.04s | 2.26% | 0.18s | 10.17% | `io.ReadAtLeast` |
| 0.03s | 1.69% | 0.03s | 1.69% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey` |
| 0.02s | 1.13% | 0.02s | 1.13% | `cmpbody` |
| 0.02s | 1.13% | 0.02s | 1.13% | `encoding/binary.littleEndian.Uint32 (inline)` |
| 0.02s | 1.13% | 0.03s | 1.69% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 0.02s | 1.13% | 0.02s | 1.13% | `github.com/snissn/go-crc32-asm.crc32IEEEPCLMUL8` |
| 0.02s | 1.13% | 0.29s | 16.38% | `github.com/snissn/go-crc32-asm.updateIEEE` |
| 0.02s | 1.13% | 0.06s | 3.39% | `github.com/snissn/gomap/TreeDB/internal/commitlog.RawKVExternalRefFenceV1` |
| 0.02s | 1.13% | 0.06s | 3.39% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 0.02s | 1.13% | 0.12s | 6.78% | `github.com/snissn/gomap/TreeDB/internal/commitlog.decodeCommandFrameV2` |
| 0.02s | 1.13% | 0.02s | 1.13% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).UnsafeEntryWithRevision` |
| 0.02s | 1.13% | 0.10s | 5.65% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).mergeLeaf` |
| 0.02s | 1.13% | 0.02s | 1.13% | `internal/runtime/maps.ctrlGroup.matchH2` |
| 0.02s | 1.13% | 0.02s | 1.13% | `runtime.scanObject` |
| 0.02s | 1.13% | 0.02s | 1.13% | `runtime.step` |
| 0.02s | 1.13% | 0.02s | 1.13% | `sort.partition_func` |
| 0.01s | 0.56% | 0.14s | 7.91% | `bufio.(*Reader).Read` |
| 0.01s | 0.56% | 0.01s | 0.56% | `encoding/binary.littleEndian.Uint64 (inline)` |

### checkpoint/dataset_write_sorted (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_dataset_write_sorted_treedb.pprof`
- total samples: `2.29s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1.05s | 45.85% | 1.05s | 45.85% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.20s | 8.73% | 0.20s | 8.73% | `internal/runtime/syscall/linux.Syscall6` |
| 0.12s | 5.24% | 0.12s | 5.24% | `runtime.memmove` |
| 0.08s | 3.49% | 0.08s | 3.49% | `hash/crc32.ieeeCLMUL` |
| 0.08s | 3.49% | 0.08s | 3.49% | `hash/crc32.simpleUpdate (inline)` |
| 0.08s | 3.49% | 0.08s | 3.49% | `memeqbody` |
| 0.06s | 2.62% | 0.06s | 2.62% | `cmpbody` |
| 0.04s | 1.75% | 0.04s | 1.75% | `encoding/binary.littleEndian.Uint32 (inline)` |
| 0.04s | 1.75% | 0.20s | 8.73% | `hash/crc32.archUpdateIEEE` |
| 0.03s | 1.31% | 0.07s | 3.06% | `github.com/snissn/gomap/TreeDB/internal/commitlog.RawKVExternalRefFenceV1` |
| 0.03s | 1.31% | 0.07s | 3.06% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 0.02s | 0.87% | 0.09s | 3.93% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 0.02s | 0.87% | 1.17s | 51.09% | `github.com/snissn/gomap/TreeDB/db.(*DB).maintenanceReachabilityScan.func6.1` |
| 0.02s | 0.87% | 0.20s | 8.73% | `github.com/snissn/gomap/TreeDB/db.scanCommandWALSegmentReader` |
| 0.02s | 0.87% | 0.02s | 0.87% | `github.com/snissn/gomap/TreeDB/internal/commitlog.allZeroBytes` |
| 0.02s | 0.87% | 0.17s | 7.42% | `github.com/snissn/gomap/TreeDB/internal/commitlog.decodeCommandFrameV2` |
| 0.02s | 0.87% | 0.02s | 0.87% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey` |
| 0.02s | 0.87% | 0.02s | 0.87% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 0.02s | 0.87% | 0.02s | 0.87% | `runtime.fpTracebackPCs (inline)` |
| 0.02s | 0.87% | 0.02s | 0.87% | `runtime.memclrNoHeapPointers` |
| 0.02s | 0.87% | 0.02s | 0.87% | `runtime.step` |
| 0.01s | 0.44% | 0.27s | 11.79% | `github.com/snissn/go-crc32-asm.Update` |
| 0.01s | 0.44% | 0.02s | 0.87% | `github.com/snissn/go-crc32-asm.updateIEEEFast` |
| 0.01s | 0.44% | 0.04s | 1.75% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).push` |
| 0.01s | 0.44% | 0.08s | 3.49% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*fixedWALStream).Read` |

### checkpoint/full_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_full_scan_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/post (run_treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_post_run_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/prefix_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_prefix_scan_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/random_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_delete_treedb.pprof`
- total samples: `2.24s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1.33s | 59.38% | 1.33s | 59.38% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.23s | 10.27% | 0.23s | 10.27% | `internal/runtime/syscall/linux.Syscall6` |
| 0.06s | 2.68% | 0.06s | 2.68% | `runtime.memmove` |
| 0.05s | 2.23% | 0.05s | 2.23% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 0.04s | 1.79% | 0.04s | 1.79% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 0.04s | 1.79% | 0.04s | 1.79% | `hash/crc32.simpleUpdate (inline)` |
| 0.03s | 1.34% | 0.03s | 1.34% | `runtime.fpTracebackPCs (inline)` |
| 0.02s | 0.89% | 0.03s | 1.34% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` |
| 0.02s | 0.89% | 1.79s | 79.91% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |
| 0.02s | 0.89% | 1.75s | 78.12% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).readAtWithDictTo` |
| 0.02s | 0.89% | 0.04s | 1.79% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafValueViewColumnarPrefixV2` |
| 0.02s | 0.89% | 0.02s | 0.89% | `internal/sync.(*Mutex).Unlock (inline)` |
| 0.01s | 0.45% | 0.11s | 4.91% | `github.com/snissn/go-crc32-asm.Update` |
| 0.01s | 0.45% | 0.02s | 0.89% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).push (inline)` |
| 0.01s | 0.45% | 0.05s | 2.23% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 0.01s | 0.45% | 0.05s | 2.23% | `github.com/snissn/gomap/TreeDB/db.(*DB).maintenanceReachabilityScan.func3` |
| 0.01s | 0.45% | 1.92s | 85.71% | `github.com/snissn/gomap/TreeDB/db.(*DB).maintenanceReachabilityScan.func5` |
| 0.01s | 0.45% | 1.81s | 80.80% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0.01s | 0.45% | 1.80s | 80.36% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadUnsafeTo` |
| 0.01s | 0.45% | 0.05s | 2.23% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*FramePreparer).PrepareFrameInto` |
| 0.01s | 0.45% | 0.04s | 1.79% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*FramePreparer).prepareBlockFrameBody` |
| 0.01s | 0.45% | 0.05s | 2.23% | `github.com/snissn/gomap/TreeDB/node.(*Node).VerifyChecksum (inline)` |
| 0.01s | 0.45% | 0.02s | 0.89% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2ValueMetaAt` |
| 0.01s | 0.45% | 0.09s | 4.02% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).mergeLeaf` |
| 0.01s | 0.45% | 0.05s | 2.23% | `hash/crc32.slicingUpdate` |

### checkpoint/random_read (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_read_treedb.pprof`
- total samples: `1.88s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.68s | 36.17% | 0.68s | 36.17% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.22s | 11.70% | 0.22s | 11.70% | `internal/runtime/syscall/linux.Syscall6` |
| 0.12s | 6.38% | 0.12s | 6.38% | `runtime.memmove` |
| 0.08s | 4.26% | 0.08s | 4.26% | `hash/crc32.simpleUpdate (inline)` |
| 0.07s | 3.72% | 0.07s | 3.72% | `hash/crc32.ieeeCLMUL` |
| 0.06s | 3.19% | 0.06s | 3.19% | `cmpbody` |
| 0.06s | 3.19% | 0.16s | 8.51% | `github.com/snissn/gomap/TreeDB/internal/commitlog.decodeCommandFrameV2` |
| 0.03s | 1.60% | 0.03s | 1.60% | `github.com/snissn/gomap/TreeDB/internal/commitlog.allZeroBytes (inline)` |
| 0.03s | 1.60% | 0.03s | 1.60% | `runtime.fpTracebackPCs (inline)` |
| 0.02s | 1.06% | 0.02s | 1.06% | `github.com/snissn/go-crc32-asm.useIEEEFallback (inline)` |
| 0.02s | 1.06% | 0.04s | 2.13% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayload` |
| 0.02s | 1.06% | 0.48s | 25.53% | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` |
| 0.02s | 1.06% | 0.02s | 1.06% | `github.com/snissn/gomap/TreeDB/internal/commitlog.validateCommandEnvelopePayload` |
| 0.02s | 1.06% | 0.02s | 1.06% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey` |
| 0.02s | 1.06% | 0.03s | 1.60% | `internal/sync.(*Mutex).Lock (inline)` |
| 0.01s | 0.53% | 0.11s | 5.85% | `bufio.(*Reader).Read` |
| 0.01s | 0.53% | 0.01s | 0.53% | `countbody` |
| 0.01s | 0.53% | 0.01s | 0.53% | `encoding/binary.littleEndian.Uint32 (inline)` |
| 0.01s | 0.53% | 0.01s | 0.53% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 0.01s | 0.53% | 0.03s | 1.60% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).DeleteViewWithRevision` |
| 0.01s | 0.53% | 0.02s | 1.06% | `github.com/snissn/gomap/TreeDB/caching.(*stableOpMergeHeap).pop` |
| 0.01s | 0.53% | 0.01s | 0.53% | `github.com/snissn/gomap/TreeDB/db.(*DB).buildValueLogRefDeltaWithOptions` |
| 0.01s | 0.53% | 0.92s | 48.94% | `github.com/snissn/gomap/TreeDB/db.(*DB).maintenanceReachabilityScan.func6.1` |
| 0.01s | 0.53% | 0.01s | 0.53% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).storeInBucketWithAllocationPolicyLocked` |
| 0.01s | 0.53% | 0.88s | 46.81% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadUnsafeTo` |

### checkpoint/random_read_batch (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_read_batch_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/random_read_parallel (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_read_parallel_treedb.pprof`
- total samples: `10ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 10ms | 100.00% | 10ms | 100.00% | `internal/runtime/syscall/linux.Syscall6` |
| 0 | 0.00% | 10ms | 100.00% | `bufio.(*Reader).Peek` |
| 0 | 0.00% | 10ms | 100.00% | `bufio.(*Reader).fill` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).CleanupCommandWALCoveredSegments` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).CleanupCommandWALCoveredSegmentsAtCheckpoint` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).cleanupCommandWALCoveredSegmentsV1` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).scanCommandWALCleanupProof` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).scanCommandWALCleanupProof.func1` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*commandWALCleanupScan).scanFile` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*commandWALCleanupScan).scanLockedDirectory` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*commandWALCleanupScan).scanSegment` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.scanCommandWALSegmentFileWithOptions` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CleanupReadBuffer).Open` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).WithCleanupScan` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).WithCleanupScan.func1` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).WithCleanupScanSnapshot` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.NewReaderFromFileWithOptions` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` |
| 0 | 0.00% | 10ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Checkpoint` |
| 0 | 0.00% | 10ms | 100.00% | `internal/poll.(*FD).Pread` |
| 0 | 0.00% | 10ms | 100.00% | `internal/poll.(*FD).Pread.func1 (inline)` |
| 0 | 0.00% | 10ms | 100.00% | `internal/poll.ignoringEINTR2[go.shape.int] (inline)` |
| 0 | 0.00% | 10ms | 100.00% | `io.(*SectionReader).Read` |

### checkpoint/random_read_parallel_acquire_snapshot (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `0`

_No entries parsed._

### checkpoint/random_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_random_write_treedb.pprof`
- total samples: `540ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 110ms | 20.37% | 110ms | 20.37% | `hash/crc32.simpleUpdate (inline)` |
| 80ms | 14.81% | 80ms | 14.81% | `hash/crc32.ieeeCLMUL` |
| 70ms | 12.96% | 70ms | 12.96% | `internal/runtime/syscall/linux.Syscall6` |
| 60ms | 11.11% | 60ms | 11.11% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 20ms | 3.70% | 50ms | 9.26% | `github.com/snissn/gomap/TreeDB/internal/commitlog.RawKVExternalRefFenceV1` |
| 20ms | 3.70% | 30ms | 5.56% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 20ms | 3.70% | 110ms | 20.37% | `github.com/snissn/gomap/TreeDB/internal/commitlog.decodeCommandFrame` |
| 10ms | 1.85% | 10ms | 1.85% | `encoding/binary.littleEndian.Uint32 (inline)` |
| 10ms | 1.85% | 240ms | 44.44% | `github.com/snissn/go-crc32-asm.Update` |
| 10ms | 1.85% | 100ms | 18.52% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 10ms | 1.85% | 10ms | 1.85% | `github.com/snissn/go-crc32-asm.crc32IEEEPCLMUL8` |
| 10ms | 1.85% | 130ms | 24.07% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Reader).ReadValidatedCommandFrameLSN` |
| 10ms | 1.85% | 80ms | 14.81% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Reader).readSegmentPayloadWithCompressionBuffers` |
| 10ms | 1.85% | 10ms | 1.85% | `github.com/snissn/gomap/TreeDB/internal/commitlog.allZeroBytes` |
| 10ms | 1.85% | 10ms | 1.85% | `github.com/snissn/gomap/TreeDB/internal/commitlog.decodeCommandExtensions` |
| 10ms | 1.85% | 80ms | 14.81% | `github.com/snissn/gomap/TreeDB/internal/commitlog.decodeCommandFrameV2` |
| 10ms | 1.85% | 10ms | 1.85% | `github.com/snissn/gomap/TreeDB/internal/commitlog.validateCommandEnvelopePayloadV2` |
| 10ms | 1.85% | 200ms | 37.04% | `hash/crc32.archUpdateIEEE` |
| 10ms | 1.85% | 10ms | 1.85% | `hash/crc32.init.OnceFunc.func4` |
| 10ms | 1.85% | 10ms | 1.85% | `internal/runtime/maps.ctrlGroup.matchH2` |
| 10ms | 1.85% | 10ms | 1.85% | `internal/runtime/maps.h1` |
| 10ms | 1.85% | 50ms | 9.26% | `io.ReadAtLeast` |
| 10ms | 1.85% | 10ms | 1.85% | `memeqbody` |
| 0 | 0.00% | 10ms | 1.85% | `bufio.(*Reader).Peek` |
| 0 | 0.00% | 40ms | 7.41% | `bufio.(*Reader).Read` |

### checkpoint/sequential_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/checkpoint_cpu_checkpoint_sequential_write_treedb.pprof`
- total samples: `0`

_No entries parsed._

### dataset_write_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_dataset_write_random_treedb.pprof`
- total samples: `890ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 130ms | 14.61% | 130ms | 14.61% | `internal/runtime/syscall/linux.Syscall6` |
| 40ms | 4.49% | 40ms | 4.49% | `hash/crc32.simpleUpdate (inline)` |
| 40ms | 4.49% | 70ms | 7.87% | `runtime.scanObject` |
| 30ms | 3.37% | 80ms | 8.99% | `github.com/snissn/gomap/TreeDB/internal/commitlog.prepareCommandFrameV2Encoding` |
| 30ms | 3.37% | 30ms | 3.37% | `time.runtimeNow` |
| 20ms | 2.25% | 20ms | 2.25% | `encoding/binary.littleEndian.Uint32 (inline)` |
| 20ms | 2.25% | 640ms | 71.91% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 20ms | 2.25% | 620ms | 69.66% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 20ms | 2.25% | 20ms | 2.25% | `runtime.madvise` |
| 20ms | 2.25% | 20ms | 2.25% | `runtime.makeslice` |
| 20ms | 2.25% | 20ms | 2.25% | `runtime.memclrNoHeapPointers` |
| 20ms | 2.25% | 20ms | 2.25% | `runtime.nextFreeFast (inline)` |
| 20ms | 2.25% | 30ms | 3.37% | `runtime.step` |
| 10ms | 1.12% | 10ms | 1.12% | `aeshashbody` |
| 10ms | 1.12% | 10ms | 1.12% | `encoding/binary.littleEndian.PutUint16 (inline)` |
| 10ms | 1.12% | 10ms | 1.12% | `encoding/binary.littleEndian.Uint16 (inline)` |
| 10ms | 1.12% | 10ms | 1.12% | `github.com/cespare/xxhash/v2.Sum64` |
| 10ms | 1.12% | 10ms | 1.12% | `github.com/snissn/go-crc32-asm.crc32IEEEPCLMUL8` |
| 10ms | 1.12% | 60ms | 6.74% | `github.com/snissn/go-crc32-asm.updateIEEE` |
| 10ms | 1.12% | 450ms | 50.56% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 10ms | 1.12% | 440ms | 49.44% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 10ms | 1.12% | 10ms | 1.12% | `github.com/snissn/gomap/TreeDB.(*DB).beginPublicOperation` |
| 10ms | 1.12% | 10ms | 1.12% | `github.com/snissn/gomap/TreeDB.(*DB).publicCommandWALAutoCheckpointBytes` |
| 10ms | 1.12% | 660ms | 74.16% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 10ms | 1.12% | 460ms | 51.69% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |

### dataset_write_sorted (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_dataset_write_sorted_treedb.pprof`
- total samples: `860ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 180ms | 20.93% | 180ms | 20.93% | `internal/runtime/syscall/linux.Syscall6` |
| 50ms | 5.81% | 50ms | 5.81% | `internal/sync.(*Mutex).Lock (inline)` |
| 40ms | 4.65% | 40ms | 4.65% | `time.runtimeNow` |
| 30ms | 3.49% | 30ms | 3.49% | `github.com/cespare/xxhash/v2.Sum64` |
| 30ms | 3.49% | 30ms | 3.49% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL256` |
| 30ms | 3.49% | 30ms | 3.49% | `internal/sync.(*Mutex).Unlock (inline)` |
| 30ms | 3.49% | 60ms | 6.98% | `runtime.scanObject` |
| 20ms | 2.33% | 20ms | 2.33% | `github.com/snissn/go-crc32-asm.crc32IEEEPCLMUL8` |
| 20ms | 2.33% | 20ms | 2.33% | `github.com/snissn/gomap/TreeDB/internal/commitlog.commandFrameV2Encoding.encodeTo` |
| 20ms | 2.33% | 60ms | 6.98% | `github.com/snissn/gomap/TreeDB/internal/commitlog.prepareCommandFrameV2ForEncode` |
| 20ms | 2.33% | 20ms | 2.33% | `internal/poll.(*fdMutex).decref (inline)` |
| 20ms | 2.33% | 30ms | 3.49% | `runtime.exitsyscall` |
| 20ms | 2.33% | 20ms | 2.33% | `runtime.nextFreeFast (inline)` |
| 10ms | 1.16% | 10ms | 1.16% | `aeshashbody` |
| 10ms | 1.16% | 10ms | 1.16% | `encoding/binary.littleEndian.PutUint16 (inline)` |
| 10ms | 1.16% | 540ms | 62.79% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 10ms | 1.16% | 530ms | 61.63% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 10ms | 1.16% | 520ms | 60.47% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 10ms | 1.16% | 10ms | 1.16% | `github.com/snissn/gomap/TreeDB/db.(*DB).commandWALPoisonedError` |
| 10ms | 1.16% | 10ms | 1.16% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ExternalRefFenceV1FromRawKVPayload` |
| 10ms | 1.16% | 10ms | 1.16% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayload.func1` |
| 10ms | 1.16% | 10ms | 1.16% | `github.com/snissn/gomap/TreeDB/internal/commitlog.validateCommandEnvelopeIdentity` |
| 10ms | 1.16% | 20ms | 2.33% | `github.com/snissn/gomap/TreeDB/internal/commitlog.validateCommandEnvelopePayloadV2` |
| 10ms | 1.16% | 20ms | 2.33% | `github.com/snissn/gomap/TreeDB/internal/commitlog.validateCommandEnvelopeV2Identity` |
| 10ms | 1.16% | 270ms | 31.40% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeFixedAt` |

### full_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_full_scan_treedb.pprof`
- total samples: `490ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 180ms | 36.73% | 180ms | 36.73% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 30ms | 6.12% | 100ms | 20.41% | `runtime.scanObject` |
| 30ms | 6.12% | 30ms | 6.12% | `runtime.spanClass.sizeclass (inline)` |
| 20ms | 4.08% | 20ms | 4.08% | `hash/crc32.simpleUpdate (inline)` |
| 20ms | 4.08% | 20ms | 4.08% | `runtime.memmove` |
| 10ms | 2.04% | 10ms | 2.04% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 10ms | 2.04% | 30ms | 6.12% | `github.com/snissn/go-crc32-asm.updateIEEEFast` |
| 10ms | 2.04% | 320ms | 65.31% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 10ms | 2.04% | 10ms | 2.04% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).UnsafeValue` |
| 10ms | 2.04% | 20ms | 4.08% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Valid (partial-inline)` |
| 10ms | 2.04% | 20ms | 4.08% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 10ms | 2.04% | 10ms | 2.04% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).Valid` |
| 10ms | 2.04% | 280ms | 57.14% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadNodeRef` |
| 10ms | 2.04% | 10ms | 2.04% | `internal/poll.(*fdMutex).incref (inline)` |
| 10ms | 2.04% | 10ms | 2.04% | `internal/runtime/maps.probeSeq.next` |
| 10ms | 2.04% | 10ms | 2.04% | `internal/runtime/syscall/linux.Syscall6` |
| 10ms | 2.04% | 350ms | 71.43% | `main.runBenchmark.func37` |
| 10ms | 2.04% | 10ms | 2.04% | `memeqbody` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.(*_panic).nextDefer` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.(*activeSweep).begin` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.(*spanSet).push` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.findObject` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.heapArenaOf (inline)` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.pcvalue` |
| 10ms | 2.04% | 50ms | 10.20% | `runtime.tryDeferToSpanScan` |

### prefix_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_prefix_scan_treedb.pprof`
- total samples: `100ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 40ms | 40.00% | 40ms | 40.00% | `runtime.typePointers.next` |
| 10ms | 10.00% | 10ms | 10.00% | `runtime.memmove` |
| 10ms | 10.00% | 80ms | 80.00% | `runtime.scanObject` |
| 10ms | 10.00% | 10ms | 10.00% | `runtime.spanClass.noscan (inline)` |
| 10ms | 10.00% | 10ms | 10.00% | `runtime.spanClass.sizeclass (inline)` |
| 10ms | 10.00% | 10ms | 10.00% | `runtime.step` |
| 10ms | 10.00% | 30ms | 30.00% | `runtime.tryDeferToSpanScan` |
| 0 | 0.00% | 20ms | 20.00% | `main.main` |
| 0 | 0.00% | 20ms | 20.00% | `main.runBenchmark` |
| 0 | 0.00% | 10ms | 10.00% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 10ms | 10.00% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 10ms | 10.00% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 10ms | 10.00% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 10ms | 10.00% | `runtime.(*Frames).Next` |
| 0 | 0.00% | 10ms | 10.00% | `runtime.funcline1` |
| 0 | 0.00% | 80ms | 80.00% | `runtime.gcBgMarkWorker` |
| 0 | 0.00% | 80ms | 80.00% | `runtime.gcBgMarkWorker.func2` |
| 0 | 0.00% | 80ms | 80.00% | `runtime.gcDrain` |
| 0 | 0.00% | 30ms | 30.00% | `runtime.gcDrainMarkWorkerDedicated (inline)` |
| 0 | 0.00% | 50ms | 50.00% | `runtime.gcDrainMarkWorkerIdle (inline)` |
| 0 | 0.00% | 20ms | 20.00% | `runtime.main` |
| 0 | 0.00% | 10ms | 10.00% | `runtime.pcvalue` |
| 0 | 0.00% | 80ms | 80.00% | `runtime.systemstack` |
| 0 | 0.00% | 20ms | 20.00% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 20ms | 20.00% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |

### random_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_random_delete_treedb.pprof`
- total samples: `850ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 160ms | 18.82% | 160ms | 18.82% | `internal/runtime/syscall/linux.Syscall6` |
| 70ms | 8.24% | 70ms | 8.24% | `time.runtimeNow` |
| 60ms | 7.06% | 110ms | 12.94% | `runtime.scanObject` |
| 50ms | 5.88% | 50ms | 5.88% | `hash/crc32.simpleUpdate (inline)` |
| 30ms | 3.53% | 610ms | 71.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` |
| 30ms | 3.53% | 30ms | 3.53% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 30ms | 3.53% | 30ms | 3.53% | `hash/crc32.ieeeCLMUL` |
| 20ms | 2.35% | 40ms | 4.71% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 20ms | 2.35% | 20ms | 2.35% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 20ms | 2.35% | 20ms | 2.35% | `internal/sync.(*Mutex).Lock (inline)` |
| 20ms | 2.35% | 20ms | 2.35% | `math/rand.(*rngSource).Uint64` |
| 20ms | 2.35% | 20ms | 2.35% | `runtime.nanotime (inline)` |
| 20ms | 2.35% | 30ms | 3.53% | `runtime.typePointers.next` |
| 20ms | 2.35% | 20ms | 2.35% | `runtime.typePointers.nextFast (inline)` |
| 10ms | 1.18% | 10ms | 1.18% | `github.com/cespare/xxhash/v2.Sum64` |
| 10ms | 1.18% | 10ms | 1.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).conditionalRecordCommittedEntries` |
| 10ms | 1.18% | 500ms | 58.82% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 10ms | 1.18% | 10ms | 1.18% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureCommandWALExternalDependencies` |
| 10ms | 1.18% | 10ms | 1.18% | `github.com/snissn/gomap/TreeDB/db.commandWALStableRotationTokens` |
| 10ms | 1.18% | 40ms | 4.71% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand.func1` |
| 10ms | 1.18% | 260ms | 30.59% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).flushLocked` |
| 10ms | 1.18% | 10ms | 1.18% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).reserveLSNLocked` |
| 10ms | 1.18% | 30ms | 3.53% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Writer).appendCommandV2Prepared` |
| 10ms | 1.18% | 10ms | 1.18% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Writer).observeWriteSyscalls (inline)` |
| 10ms | 1.18% | 10ms | 1.18% | `github.com/snissn/gomap/TreeDB/internal/commitlog.commandExtensionsEncodedLen` |

### random_read (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_random_read_treedb.pprof`
- total samples: `560ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 60ms | 10.71% | 100ms | 17.86% | `runtime.scanObject` |
| 40ms | 7.14% | 40ms | 7.14% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 40ms | 7.14% | 50ms | 8.93% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` |
| 30ms | 5.36% | 30ms | 5.36% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 20ms | 3.57% | 20ms | 3.57% | `internal/runtime/syscall/linux.Syscall6` |
| 20ms | 3.57% | 20ms | 3.57% | `runtime.madvise` |
| 20ms | 3.57% | 20ms | 3.57% | `runtime.tryDeferToSpanScan` |
| 10ms | 1.79% | 10ms | 1.79% | `compress/flate.(*deflateFast).encode` |
| 10ms | 1.79% | 10ms | 1.79% | `errors.Is` |
| 10ms | 1.79% | 40ms | 7.14% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead` |
| 10ms | 1.79% | 10ms | 1.79% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).putRead` |
| 10ms | 1.79% | 10ms | 1.79% | `github.com/snissn/gomap/TreeDB/db.(*indexGen).retainWrapperBorrow` |
| 10ms | 1.79% | 10ms | 1.79% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeIntoBackingLocked` |
| 10ms | 1.79% | 10ms | 1.79% | `github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryClaimFastForPurpose` |
| 10ms | 1.79% | 20ms | 3.57% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` |
| 10ms | 1.79% | 10ms | 1.79% | `github.com/snissn/gomap/TreeDB/node.(*Node).searchLeafColumnarPrefixV2BlockWithMeta` |
| 10ms | 1.79% | 10ms | 1.79% | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView` |
| 10ms | 1.79% | 10ms | 1.79% | `github.com/snissn/gomap/TreeDB/node.getUint64BEAt (inline)` |
| 10ms | 1.79% | 10ms | 1.79% | `github.com/snissn/gomap/TreeDB/pager.(*Pager).Get` |
| 10ms | 1.79% | 10ms | 1.79% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).ResetAppendReadBindings` |
| 10ms | 1.79% | 10ms | 1.79% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).shouldVerifyLeafRefChecksum` |
| 10ms | 1.79% | 10ms | 1.79% | `internal/bytealg.Compare` |
| 10ms | 1.79% | 10ms | 1.79% | `internal/sync.(*Mutex).Unlock (inline)` |
| 10ms | 1.79% | 10ms | 1.79% | `math/rand.(*Rand).Int31n` |
| 10ms | 1.79% | 10ms | 1.79% | `runtime.findObject` |

### random_read_batch (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_random_read_batch_treedb.pprof`
- total samples: `490ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 70ms | 14.29% | 70ms | 14.29% | `internal/runtime/syscall/linux.Syscall6` |
| 40ms | 8.16% | 40ms | 8.16% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 30ms | 6.12% | 50ms | 10.20% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getViewLockedWithState` |
| 30ms | 6.12% | 30ms | 6.12% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` |
| 30ms | 6.12% | 80ms | 16.33% | `runtime.scanObject` |
| 20ms | 4.08% | 20ms | 4.08% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 20ms | 4.08% | 30ms | 6.12% | `github.com/snissn/gomap/TreeDB/node.(*Node).searchLeafColumnarPrefixV2BlockWithMeta` |
| 20ms | 4.08% | 20ms | 4.08% | `github.com/snissn/gomap/TreeDB/tree.outerLeafRecentRingContains` |
| 20ms | 4.08% | 20ms | 4.08% | `hash/crc32.simpleUpdate` |
| 20ms | 4.08% | 20ms | 4.08% | `runtime.nanotime (inline)` |
| 20ms | 4.08% | 20ms | 4.08% | `runtime.typePointers.next` |
| 10ms | 2.04% | 130ms | 26.53% | `github.com/snissn/gomap/TreeDB/internal/valuelog.readAtWithDictToScratch` |
| 10ms | 2.04% | 10ms | 2.04% | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView` |
| 10ms | 2.04% | 10ms | 2.04% | `github.com/snissn/gomap/TreeDB/node.getUint64BEAt (inline)` |
| 10ms | 2.04% | 40ms | 8.16% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).findLeafRefForGetMany` |
| 10ms | 2.04% | 10ms | 2.04% | `internal/runtime/maps.(*Map).directoryAt` |
| 10ms | 2.04% | 10ms | 2.04% | `internal/sync.(*Mutex).Unlock` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.(*moduledata).textAddr` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.(*pageAlloc).update` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.(*traceBuf).byte (inline)` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.findObject` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.heapArenaOf (inline)` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.procyieldAsm` |
| 10ms | 2.04% | 10ms | 2.04% | `runtime.stealWork` |
| 10ms | 2.04% | 20ms | 4.08% | `runtime.tryDeferToSpanScan` |

### random_read_parallel (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_random_read_parallel_treedb.pprof`
- total samples: `5090ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 560ms | 11.00% | 560ms | 11.00% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 400ms | 7.86% | 400ms | 7.86% | `internal/runtime/syscall/linux.Syscall6` |
| 340ms | 6.68% | 340ms | 6.68% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 230ms | 4.52% | 240ms | 4.72% | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView (inline)` |
| 170ms | 3.34% | 250ms | 4.91% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` |
| 170ms | 3.34% | 310ms | 6.09% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` |
| 170ms | 3.34% | 280ms | 5.50% | `github.com/snissn/gomap/TreeDB/tree.noteOuterLeafLoad` |
| 160ms | 3.14% | 4790ms | 94.11% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView` |
| 120ms | 2.36% | 280ms | 5.50% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getViewLockedWithState` |
| 110ms | 2.16% | 160ms | 3.14% | `github.com/snissn/gomap/TreeDB/node.(*Node).searchLeafColumnarPrefixV2BlockWithMeta` |
| 110ms | 2.16% | 110ms | 2.16% | `github.com/snissn/gomap/TreeDB/pager.(*Pager).getLocalMapping` |
| 110ms | 2.16% | 110ms | 2.16% | `sync/atomic.(*Bool).Load (inline)` |
| 100ms | 1.96% | 100ms | 1.96% | `cmpbody` |
| 90ms | 1.77% | 680ms | 13.36% | `github.com/snissn/gomap/TreeDB/node.(*Node).VerifyChecksum (inline)` |
| 90ms | 1.77% | 90ms | 1.77% | `github.com/snissn/gomap/TreeDB/tree.outerLeafRecentRingContains (inline)` |
| 90ms | 1.77% | 90ms | 1.77% | `hash/crc32.simpleUpdate (inline)` |
| 90ms | 1.77% | 90ms | 1.77% | `sync/atomic.(*Int32).Add (inline)` |
| 70ms | 1.38% | 70ms | 1.38% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetInternalChildRef` |
| 70ms | 1.38% | 70ms | 1.38% | `github.com/snissn/gomap/TreeDB/node.getUint64BEAt (inline)` |
| 70ms | 1.38% | 70ms | 1.38% | `runtime.memmove` |
| 70ms | 1.38% | 70ms | 1.38% | `runtime.procyieldAsm` |
| 60ms | 1.18% | 60ms | 1.18% | `github.com/snissn/gomap/TreeDB/node.getUint16At (inline)` |
| 60ms | 1.18% | 60ms | 1.18% | `hash/crc32.ieeeCLMUL` |
| 60ms | 1.18% | 60ms | 1.18% | `internal/poll.(*fdMutex).decref (inline)` |
| 60ms | 1.18% | 120ms | 2.36% | `internal/sync.(*Mutex).Lock (inline)` |

### random_read_parallel_acquire_snapshot (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `13.35s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2.58s | 19.33% | 2.58s | 19.33% | `runtime.procyieldAsm` |
| 1.29s | 9.66% | 1.29s | 9.66% | `sync/atomic.(*Int32).Add (inline)` |
| 0.68s | 5.09% | 3.70s | 27.72% | `internal/sync.(*Mutex).Lock (inline)` |
| 0.40s | 3.00% | 0.40s | 3.00% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.40s | 3.00% | 3.02s | 22.62% | `internal/sync.(*Mutex).lockSlow` |
| 0.36s | 2.70% | 0.36s | 2.70% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 0.36s | 2.70% | 0.36s | 2.70% | `internal/runtime/syscall/linux.Syscall6` |
| 0.29s | 2.17% | 0.38s | 2.85% | `internal/sync.(*Mutex).Unlock (inline)` |
| 0.24s | 1.80% | 0.28s | 2.10% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` |
| 0.22s | 1.65% | 0.23s | 1.72% | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView (inline)` |
| 0.22s | 1.65% | 12.68s | 94.98% | `main.runBenchmark.func34.1` |
| 0.22s | 1.65% | 0.36s | 2.70% | `runtime.scanObject` |
| 0.19s | 1.42% | 4.38s | 32.81% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView` |
| 0.18s | 1.35% | 0.30s | 2.25% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getViewLockedWithState` |
| 0.18s | 1.35% | 0.34s | 2.55% | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` |
| 0.18s | 1.35% | 0.28s | 2.10% | `github.com/snissn/gomap/TreeDB/node.(*Node).searchLeafColumnarPrefixV2BlockWithMeta` |
| 0.18s | 1.35% | 0.18s | 1.35% | `runtime.heapSetTypeSmallHeader (inline)` |
| 0.18s | 1.35% | 0.18s | 1.35% | `time.runtimeNow` |
| 0.15s | 1.12% | 1.25s | 9.36% | `github.com/snissn/gomap/TreeDB/caching.memtableViewAllowsBackendSnapshotFastPath` |
| 0.15s | 1.12% | 3.12s | 23.37% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0.14s | 1.05% | 0.22s | 1.65% | `github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryJoinFastForPurpose` |
| 0.13s | 0.97% | 0.13s | 0.97% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.func1.1` |
| 0.12s | 0.90% | 0.12s | 0.90% | `github.com/snissn/gomap/TreeDB/node.getUint64BEAt (inline)` |
| 0.12s | 0.90% | 0.12s | 0.90% | `sync/atomic.(*Int64).Add (inline)` |
| 0.11s | 0.82% | 0.11s | 0.82% | `runtime.nanotime (inline)` |

### random_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_random_write_treedb.pprof`
- total samples: `800ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 150ms | 18.75% | 150ms | 18.75% | `internal/runtime/syscall/linux.Syscall6` |
| 50ms | 6.25% | 50ms | 6.25% | `time.runtimeNow` |
| 30ms | 3.75% | 30ms | 3.75% | `hash/crc32.simpleUpdate (inline)` |
| 20ms | 2.50% | 20ms | 2.50% | `encoding/binary.littleEndian.Uint32 (inline)` |
| 20ms | 2.50% | 40ms | 5.00% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 20ms | 2.50% | 30ms | 3.75% | `github.com/snissn/gomap/TreeDB/db.(*DB).observeCommandWALAppend` |
| 20ms | 2.50% | 50ms | 6.25% | `github.com/snissn/gomap/TreeDB/internal/commitlog.prepareCommandFrameV2ForEncode` |
| 20ms | 2.50% | 20ms | 2.50% | `internal/sync.(*Mutex).Lock (inline)` |
| 20ms | 2.50% | 20ms | 2.50% | `runtime.spanClass.noscan (inline)` |
| 20ms | 2.50% | 50ms | 6.25% | `runtime.tryDeferToSpanScan` |
| 10ms | 1.25% | 70ms | 8.75% | `github.com/snissn/go-crc32-asm.Update` |
| 10ms | 1.25% | 620ms | 77.50% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 10ms | 1.25% | 550ms | 68.75% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 10ms | 1.25% | 10ms | 1.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).shardForKey` |
| 10ms | 1.25% | 10ms | 1.25% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureCommandWALExternalDependencies` |
| 10ms | 1.25% | 340ms | 42.50% | `github.com/snissn/gomap/TreeDB/db.(*DB).flushCommandWALForPath` |
| 10ms | 1.25% | 20ms | 2.50% | `github.com/snissn/gomap/TreeDB/db.(*DB).observeCommandWALFlush` |
| 10ms | 1.25% | 10ms | 1.25% | `github.com/snissn/gomap/TreeDB/db.commandWALDurationNs (inline)` |
| 10ms | 1.25% | 10ms | 1.25% | `github.com/snissn/gomap/TreeDB/db.commandWALStoreMax (inline)` |
| 10ms | 1.25% | 60ms | 7.50% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand.func1` |
| 10ms | 1.25% | 310ms | 38.75% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).flushLocked` |
| 10ms | 1.25% | 300ms | 37.50% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Writer).Flush` |
| 10ms | 1.25% | 10ms | 1.25% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Writer).fixedFitsAppend` |
| 10ms | 1.25% | 290ms | 36.25% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Writer).flushFixed` |
| 10ms | 1.25% | 240ms | 30.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*fixedWAL).flushExtent` |

### sequential_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/cpu_sequential_write_treedb.pprof`
- total samples: `830ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 130ms | 15.66% | 130ms | 15.66% | `internal/runtime/syscall/linux.Syscall6` |
| 40ms | 4.82% | 40ms | 4.82% | `internal/sync.(*Mutex).Lock (inline)` |
| 40ms | 4.82% | 40ms | 4.82% | `time.runtimeNow` |
| 30ms | 3.61% | 30ms | 3.61% | `encoding/binary.littleEndian.Uint32 (inline)` |
| 30ms | 3.61% | 30ms | 3.61% | `runtime.(*traceMap).put` |
| 30ms | 3.61% | 50ms | 6.02% | `runtime.scanObject` |
| 20ms | 2.41% | 440ms | 53.01% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 20ms | 2.41% | 60ms | 7.23% | `github.com/snissn/gomap/TreeDB/internal/commitlog.prepareCommandFrameV2ForEncode` |
| 20ms | 2.41% | 20ms | 2.41% | `hash/crc32.ieeeCLMUL` |
| 20ms | 2.41% | 20ms | 2.41% | `runtime.memclrNoHeapPointers` |
| 20ms | 2.41% | 20ms | 2.41% | `sync/atomic.(*Int32).Add (inline)` |
| 10ms | 1.20% | 10ms | 1.20% | `cmpbody` |
| 10ms | 1.20% | 40ms | 4.82% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 10ms | 1.20% | 10ms | 1.20% | `github.com/snissn/go-crc32-asm.crc32IEEEPCLMUL8` |
| 10ms | 1.20% | 480ms | 57.83% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 10ms | 1.20% | 490ms | 59.04% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 10ms | 1.20% | 20ms | 2.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWriteKey` |
| 10ms | 1.20% | 620ms | 74.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 10ms | 1.20% | 10ms | 1.20% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` |
| 10ms | 1.20% | 60ms | 7.23% | `github.com/snissn/gomap/TreeDB/caching.mergeCanonicalStableIteratorUnits` |
| 10ms | 1.20% | 470ms | 56.63% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 10ms | 1.20% | 10ms | 1.20% | `github.com/snissn/gomap/TreeDB/db.commandWALStableRotationTokens` |
| 10ms | 1.20% | 130ms | 15.66% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 10ms | 1.20% | 270ms | 32.53% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).flushDirectCommandWALLocked` |
| 10ms | 1.20% | 20ms | 2.41% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Writer).appendFixedCommandV2Prepared` |

## Allocation Hotspots

### batch_delete (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_batch_delete_treedb.pprof`
- total: `16548`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 9831 | 59.41% | 9831 | 59.41% | `runtime/pprof.allFrames` |
| 5480 | 33.12% | 5512 | 33.31% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 491 | 2.97% | 491 | 2.97% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 455 | 2.75% | 1058 | 6.39% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 110 | 0.66% | 110 | 0.66% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` |
| 108 | 0.65% | 108 | 0.65% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchIntSlice` |
| 0 | 0.00% | 1058 | 6.39% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 1058 | 6.39% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 1058 | 6.39% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 1058 | 6.39% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 491 | 2.97% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 491 | 2.97% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 491 | 2.97% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 1058 | 6.39% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 16540 | 100.00% | `main.main` |
| 0 | 0.00% | 16540 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 1172 | 7.08% | `main.runBenchmark.func26` |
| 0 | 0.00% | 2205 | 13.32% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2205 | 13.32% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 13163 | 79.54% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 13163 | 79.54% | `main.writeRuntimeProfileSnapshotTemp` |

### batch_delete (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_batch_delete_treedb.pprof`
- total: `27377.21kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 8857.89kB | 32.35% | 8857.89kB | 32.35% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 5415.52kB | 19.78% | 10311.69kB | 37.67% | `compress/flate.NewWriter (inline)` |
| 3147.15kB | 11.50% | 4896.17kB | 17.88% | `compress/flate.(*compressor).init` |
| 2089.55kB | 7.63% | 2089.55kB | 7.63% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` |
| 1749.02kB | 6.39% | 1749.02kB | 6.39% | `compress/flate.newDeflateFast (inline)` |
| 1536.28kB | 5.61% | 1536.28kB | 5.61% | `runtime/pprof.allFrames` |
| 1416.02kB | 5.17% | 1416.02kB | 5.17% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 1037.47kB | 3.79% | 9212.95kB | 33.65% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 578.66kB | 2.11% | 578.66kB | 2.11% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace` |
| 522.70kB | 1.91% | 522.70kB | 1.91% | `runtime/pprof.(*protobuf).string` |
| 514.38kB | 1.88% | 514.38kB | 1.88% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchIntSlice` |
| 512.56kB | 1.87% | 11300.85kB | 41.28% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 10311.69kB | 37.67% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 2668.21kB | 9.75% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Delete` |
| 0 | 0.00% | 11300.85kB | 41.28% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 2668.21kB | 9.75% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).deleteView` |
| 0 | 0.00% | 11300.85kB | 41.28% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 11300.85kB | 41.28% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 11300.85kB | 41.28% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 8857.89kB | 32.35% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 1416.02kB | 5.17% | `github.com/snissn/gomap/TreeDB/caching.reserveAppendOnlyMemtableEntries` |
| 0 | 0.00% | 1416.02kB | 5.17% | `github.com/snissn/gomap/TreeDB/caching.reserveMemtableEntries` |
| 0 | 0.00% | 2668.21kB | 9.75% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).AppendDelete` |
| 0 | 0.00% | 1416.02kB | 5.17% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ReserveAdditionalEntries` |
| 0 | 0.00% | 8857.89kB | 32.35% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |

### batch_random (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_batch_random_treedb.pprof`
- total: `3697`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1845 | 49.91% | 1845 | 49.91% | `runtime.mallocgc` |
| 537 | 14.53% | 537 | 14.53% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` |
| 455 | 12.31% | 1029 | 27.83% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 433 | 11.71% | 433 | 11.71% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 147 | 3.98% | 147 | 3.98% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace` |
| 129 | 3.49% | 129 | 3.49% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 79 | 2.14% | 79 | 2.14% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 24 | 0.65% | 24 | 0.65% | `runtime/pprof.(*protobuf).string` |
| 21 | 0.57% | 21 | 0.57% | `compress/flate.newDeflateFast (inline)` |
| 7 | 0.19% | 28 | 0.76% | `compress/flate.(*compressor).init` |
| 7 | 0.19% | 35 | 0.95% | `compress/flate.NewWriter (inline)` |
| 1 | 0.03% | 1714 | 46.36% | `main.runBenchmark.func25` |
| 0 | 0.00% | 684 | 18.50% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Set` |
| 0 | 0.00% | 1029 | 27.83% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 684 | 18.50% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setView (inline)` |
| 0 | 0.00% | 684 | 18.50% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setViewWithMVCCInput` |
| 0 | 0.00% | 1029 | 27.83% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 1029 | 27.83% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 1029 | 27.83% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 562 | 15.20% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchSet` |
| 0 | 0.00% | 684 | 18.50% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).AppendSetKnownZeroValue (inline)` |
| 0 | 0.00% | 684 | 18.50% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendSet` |
| 0 | 0.00% | 562 | 15.20% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 562 | 15.20% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |

### batch_random (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_batch_random_treedb.pprof`
- total: `91.29MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 56.58MB | 61.98% | 56.58MB | 61.98% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace` |
| 7.63MB | 8.36% | 7.63MB | 8.36% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 5.65MB | 6.19% | 5.65MB | 6.19% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 4.39MB | 4.81% | 4.39MB | 4.81% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 4.07MB | 4.46% | 4.07MB | 4.46% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` |
| 3.53MB | 3.86% | 7.06MB | 7.74% | `compress/flate.NewWriter (inline)` |
| 1.91MB | 2.09% | 3.54MB | 3.88% | `compress/flate.(*compressor).init` |
| 1.63MB | 1.79% | 1.63MB | 1.79% | `compress/flate.newDeflateFast (inline)` |
| 1.61MB | 1.76% | 81.57MB | 89.36% | `main.runBenchmark.func25` |
| 1.27MB | 1.39% | 1.27MB | 1.39% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 1.01MB | 1.10% | 1.01MB | 1.10% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` |
| 1MB | 1.10% | 1MB | 1.10% | `runtime.mallocgc` |
| 0.51MB | 0.56% | 0.51MB | 0.56% | `runtime/pprof.(*protobuf).string` |
| 0.50MB | 0.55% | 19.32MB | 21.16% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 7.06MB | 7.74% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 4.52MB | 4.96% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 4.52MB | 4.96% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared (inline)` |
| 0 | 0.00% | 4.52MB | 4.96% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 4.52MB | 4.96% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 4.52MB | 4.96% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 4.52MB | 4.96% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 4.52MB | 4.96% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 60.65MB | 66.44% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Set` |
| 0 | 0.00% | 19.32MB | 21.16% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 4.52MB | 4.96% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |

### batch_small_seq (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_batch_small_seq_treedb.pprof`
- total: `49745`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 37138 | 74.66% | 37138 | 74.66% | `runtime/pprof.allFrames` |
| 5011 | 10.07% | 5011 | 10.07% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 3072 | 6.18% | 3072 | 6.18% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` |
| 2732 | 5.49% | 2732 | 5.49% | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatchWithCustody` |
| 1490 | 3.00% | 1490 | 3.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` |
| 0 | 0.00% | 4222 | 8.49% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatch` |
| 0 | 0.00% | 3072 | 6.18% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Set` |
| 0 | 0.00% | 5011 | 10.07% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 3072 | 6.18% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setView (inline)` |
| 0 | 0.00% | 3072 | 6.18% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setViewWithMVCCInput` |
| 0 | 0.00% | 5011 | 10.07% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 2732 | 5.49% | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatch (inline)` |
| 0 | 0.00% | 5011 | 10.07% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 5011 | 10.07% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 3072 | 6.18% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).AppendSetKnownZeroValue (inline)` |
| 0 | 0.00% | 3072 | 6.18% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendSet` |
| 0 | 0.00% | 4222 | 8.49% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).NewBatch` |
| 0 | 0.00% | 5011 | 10.07% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 3072 | 6.18% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Set` |
| 0 | 0.00% | 49741 | 100.00% | `main.main` |
| 0 | 0.00% | 49741 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 12305 | 24.74% | `main.runBenchmark.func28` |
| 0 | 0.00% | 2329 | 4.68% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2329 | 4.68% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 35107 | 70.57% | `main.writeRuntimeProfileSnapshot` |

### batch_small_seq (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_batch_small_seq_treedb.pprof`
- total: `20793.24kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5638.19kB | 27.12% | 5638.19kB | 27.12% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 4512.93kB | 21.70% | 7312.94kB | 35.17% | `compress/flate.NewWriter (inline)` |
| 2255.35kB | 10.85% | 2255.35kB | 10.85% | `compress/flate.newDeflateFast (inline)` |
| 1549.30kB | 7.45% | 1549.30kB | 7.45% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 1536.84kB | 7.39% | 1536.84kB | 7.39% | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatchWithCustody` |
| 1536.24kB | 7.39% | 1536.24kB | 7.39% | `runtime/pprof.allFrames` |
| 1024.69kB | 4.93% | 1024.69kB | 4.93% | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` |
| 1024.38kB | 4.93% | 1024.38kB | 4.93% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` |
| 650.62kB | 3.13% | 650.62kB | 3.13% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 544.67kB | 2.62% | 2800.01kB | 13.47% | `compress/flate.(*compressor).init` |
| 520.04kB | 2.50% | 520.04kB | 2.50% | `runtime/pprof.(*protobuf).string` |
| 0 | 0.00% | 7312.94kB | 35.17% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 2561.53kB | 12.32% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatch` |
| 0 | 0.00% | 1024.38kB | 4.93% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Set` |
| 0 | 0.00% | 5638.19kB | 27.12% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 1024.38kB | 4.93% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setView (inline)` |
| 0 | 0.00% | 1024.38kB | 4.93% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setViewWithMVCCInput` |
| 0 | 0.00% | 5638.19kB | 27.12% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 1536.84kB | 7.39% | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatch (inline)` |
| 0 | 0.00% | 5638.19kB | 27.12% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 5638.19kB | 27.12% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 650.62kB | 3.13% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 1024.38kB | 4.93% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).AppendSetKnownZeroValue (inline)` |
| 0 | 0.00% | 1024.38kB | 4.93% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendSet` |
| 0 | 0.00% | 2561.53kB | 12.32% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).NewBatch` |

### batch_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_batch_write_treedb.pprof`
- total: `1413`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 910 | 64.40% | 910 | 64.40% | `runtime/pprof.(*profMap).lookup` |
| 228 | 16.14% | 228 | 16.14% | `compress/flate.(*huffmanEncoder).generate` |
| 80 | 5.66% | 80 | 5.66% | `runtime/pprof.(*profileBuilder).stringIndex` |
| 56 | 3.96% | 56 | 3.96% | `runtime/pprof.(*protobuf).string` |
| 55 | 3.89% | 55 | 3.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` |
| 26 | 1.84% | 26 | 1.84% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 23 | 1.63% | 23 | 1.63% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 13 | 0.92% | 13 | 0.92% | `compress/flate.newDeflateFast (inline)` |
| 5 | 0.35% | 18 | 1.27% | `compress/flate.(*compressor).init` |
| 5 | 0.35% | 23 | 1.63% | `compress/flate.NewWriter (inline)` |
| 1 | 0.07% | 114 | 8.07% | `main.runBenchmark.func6` |
| 0 | 0.00% | 228 | 16.14% | `compress/flate.(*Writer).Close (inline)` |
| 0 | 0.00% | 228 | 16.14% | `compress/flate.(*compressor).close` |
| 0 | 0.00% | 228 | 16.14% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 228 | 16.14% | `compress/flate.(*huffmanBitWriter).writeBlockDynamic` |
| 0 | 0.00% | 228 | 16.14% | `compress/gzip.(*Writer).Close` |
| 0 | 0.00% | 23 | 1.63% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 31 | 2.19% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 31 | 2.19% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 31 | 2.19% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared` |
| 0 | 0.00% | 31 | 2.19% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared.func1` |
| 0 | 0.00% | 31 | 2.19% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 31 | 2.19% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 31 | 2.19% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 112 | 7.93% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |

### batch_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_batch_write_treedb.pprof`
- total: `72.32MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 27.22MB | 37.64% | 27.22MB | 37.64% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 20.10MB | 27.80% | 20.10MB | 27.80% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 5.19MB | 7.17% | 5.19MB | 7.17% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 4.41MB | 6.09% | 6.78MB | 9.37% | `compress/flate.NewWriter (inline)` |
| 4.32MB | 5.97% | 4.32MB | 5.97% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` |
| 2.59MB | 3.58% | 2.59MB | 3.58% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*fixedWAL).flushExtent` |
| 1.61MB | 2.22% | 62.90MB | 86.97% | `main.runBenchmark.func6` |
| 1.27MB | 1.76% | 2.37MB | 3.28% | `compress/flate.(*compressor).init` |
| 1.27MB | 1.76% | 1.27MB | 1.76% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 1.24MB | 1.71% | 1.24MB | 1.71% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchEntries` |
| 1.10MB | 1.52% | 1.10MB | 1.52% | `compress/flate.newDeflateFast (inline)` |
| 0.50MB | 0.70% | 0.50MB | 0.70% | `runtime/pprof.(*protobuf).string` |
| 0.50MB | 0.70% | 0.50MB | 0.70% | `runtime/pprof.(*profileBuilder).stringIndex` |
| 0.50MB | 0.69% | 0.50MB | 0.69% | `compress/flate.(*huffmanEncoder).generate` |
| 0.50MB | 0.69% | 0.50MB | 0.69% | `runtime/pprof.(*profMap).lookup` |
| 0 | 0.00% | 6.78MB | 9.37% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 1.24MB | 1.71% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatchWithSize` |
| 0 | 0.00% | 35.63MB | 49.27% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 35.63MB | 49.27% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 35.63MB | 49.27% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared` |

### batch_write_steady (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_batch_write_steady_treedb.pprof`
- total: `8041`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 7646 | 95.09% | 7646 | 95.09% | `runtime/pprof.allFrames` |
| 150 | 1.87% | 174 | 2.16% | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` |
| 58 | 0.72% | 58 | 0.72% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 41 | 0.51% | 41 | 0.51% | `bufio.NewReaderSize (inline)` |
| 19 | 0.24% | 59 | 0.73% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 7 | 0.09% | 40 | 0.50% | `compress/flate.NewWriter (inline)` |
| 1 | 0.01% | 258 | 3.21% | `main.runBenchmark.func6` |
| 0 | 0.00% | 212 | 2.64% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 212 | 2.64% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 185 | 2.30% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |
| 0 | 0.00% | 156 | 1.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).backendCheckpointBoundary` |
| 0 | 0.00% | 185 | 2.30% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 156 | 1.94% | `github.com/snissn/gomap/TreeDB/caching.backendSyncBoundary` |
| 0 | 0.00% | 156 | 1.94% | `github.com/snissn/gomap/TreeDB/db.(*DB).Checkpoint` |
| 0 | 0.00% | 156 | 1.94% | `github.com/snissn/gomap/TreeDB/db.(*DB).checkpoint` |
| 0 | 0.00% | 156 | 1.94% | `github.com/snissn/gomap/TreeDB/db.(*DB).checkpointTeardownPinned` |
| 0 | 0.00% | 156 | 1.94% | `github.com/snissn/gomap/TreeDB/db.(*DB).cleanupCommandWALCoveredSegmentsAtCheckpointV1` |

### batch_write_steady (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_batch_write_steady_treedb.pprof`
- total: `107.80MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 32.41MB | 30.06% | 32.41MB | 30.06% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 29.02MB | 26.92% | 30.62MB | 28.40% | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` |
| 14.26MB | 13.23% | 14.26MB | 13.23% | `github.com/snissn/gomap/TreeDB/internal/commitlog.resizeReaderBuffer (inline)` |
| 4.41MB | 4.09% | 8.52MB | 7.90% | `compress/flate.NewWriter (inline)` |
| 4.39MB | 4.08% | 4.39MB | 4.08% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 4.17MB | 3.87% | 4.17MB | 3.87% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 2.66MB | 2.47% | 2.66MB | 2.47% | `bufio.NewReaderSize (inline)` |
| 2.54MB | 2.36% | 2.54MB | 2.36% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 2.44MB | 2.26% | 4.11MB | 3.81% | `compress/flate.(*compressor).init` |
| 2.28MB | 2.11% | 2.28MB | 2.11% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve` |
| 1.67MB | 1.55% | 1.67MB | 1.55% | `compress/flate.newDeflateFast (inline)` |
| 1.61MB | 1.49% | 92.08MB | 85.42% | `main.runBenchmark.func6` |
| 1.16MB | 1.07% | 1.16MB | 1.07% | `runtime/pprof.StartCPUProfile` |
| 1.10MB | 1.03% | 1.10MB | 1.03% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildOrderedKey64Locked` |
| 1.06MB | 0.98% | 9.58MB | 8.88% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1MB | 0.93% | 1MB | 0.93% | `runtime/pprof.allFrames` |
| 0.57MB | 0.53% | 0.57MB | 0.53% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*blockCodecScratch).lz4` |
| 0.54MB | 0.50% | 0.54MB | 0.50% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` |
| 0 | 0.00% | 8.52MB | 7.90% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 47.04MB | 43.64% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 37.57MB | 34.85% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 37.57MB | 34.85% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 37.57MB | 34.85% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared` |
| 0 | 0.00% | 37.57MB | 34.85% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared.func1` |
| 0 | 0.00% | 47.04MB | 43.64% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |

### dataset_write_random (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_dataset_write_random_treedb.pprof`
- total: `1028808`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 347356 | 33.76% | 347356 | 33.76% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 283994 | 27.60% | 1018881 | 99.04% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 196611 | 19.11% | 196611 | 19.11% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 188450 | 18.32% | 535806 | 52.08% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 5461 | 0.53% | 5461 | 0.53% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 1018881 | 99.04% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 732417 | 71.19% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 732417 | 71.19% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 732417 | 71.19% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 732417 | 71.19% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 732417 | 71.19% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 732417 | 71.19% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 732417 | 71.19% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 1018881 | 99.04% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 732417 | 71.19% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 1018881 | 99.04% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 1018881 | 99.04% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 732417 | 71.19% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 732417 | 71.19% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 535806 | 52.08% | `github.com/snissn/gomap/TreeDB/internal/commitlog.EncodeRawKVBatchPayload` |
| 0 | 0.00% | 1018881 | 99.04% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 1021153 | 99.26% | `main.main` |
| 0 | 0.00% | 1021153 | 99.26% | `main.runBenchmark` |
| 0 | 0.00% | 1018881 | 99.04% | `main.runBenchmark.func21` |
| 0 | 0.00% | 1021153 | 99.26% | `runtime.main` |

### dataset_write_random (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_dataset_write_random_treedb.pprof`
- total: `83.94MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 34.51MB | 41.11% | 51.01MB | 60.77% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 16.50MB | 19.66% | 16.50MB | 19.66% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 8.72MB | 10.39% | 8.72MB | 10.39% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 5.50MB | 6.55% | 73.26MB | 87.27% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 5.29MB | 6.30% | 7.53MB | 8.97% | `compress/flate.NewWriter (inline)` |
| 4.51MB | 5.38% | 4.51MB | 5.38% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 3MB | 3.57% | 3MB | 3.57% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 1.71MB | 2.03% | 1.71MB | 2.03% | `compress/flate.newDeflateFast (inline)` |
| 0.64MB | 0.76% | 0.64MB | 0.76% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 0.53MB | 0.63% | 2.24MB | 2.67% | `compress/flate.(*compressor).init` |
| 0.51MB | 0.61% | 0.51MB | 0.61% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` |
| 0.51MB | 0.61% | 1.93MB | 2.29% | `runtime/pprof.writeHeapInternal` |
| 0.51MB | 0.60% | 0.51MB | 0.60% | `runtime/pprof.(*protobuf).string (inline)` |
| 0.50MB | 0.60% | 0.50MB | 0.60% | `runtime.mallocgc` |
| 0.50MB | 0.60% | 5.67MB | 6.76% | `runtime/pprof.printCountCycleProfile` |
| 0.50MB | 0.60% | 0.50MB | 0.60% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 7.53MB | 8.97% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 73.26MB | 87.27% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 54.01MB | 64.34% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 54.01MB | 64.34% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 54.01MB | 64.34% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 54.01MB | 64.34% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 54.01MB | 64.34% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 54.01MB | 64.34% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 54.01MB | 64.34% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |

### dataset_write_sorted (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_dataset_write_sorted_treedb.pprof`
- total: `1357781`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 504645 | 37.17% | 504645 | 37.17% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 425992 | 31.37% | 1353249 | 99.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 229379 | 16.89% | 229379 | 16.89% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 191181 | 14.08% | 695826 | 51.25% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 0 | 0.00% | 1353249 | 99.67% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 925205 | 68.14% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 925205 | 68.14% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 925205 | 68.14% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 925205 | 68.14% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 925205 | 68.14% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 925205 | 68.14% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 925205 | 68.14% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 1353249 | 99.67% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 925205 | 68.14% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 1353249 | 99.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 1353249 | 99.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 925205 | 68.14% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 925205 | 68.14% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 695826 | 51.25% | `github.com/snissn/gomap/TreeDB/internal/commitlog.EncodeRawKVBatchPayload` |
| 0 | 0.00% | 1353249 | 99.67% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 1357771 | 100.00% | `main.main` |
| 0 | 0.00% | 1357771 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 1353249 | 99.67% | `main.runBenchmark.func22` |
| 0 | 0.00% | 1357771 | 100.00% | `runtime.main` |

### dataset_write_sorted (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_dataset_write_sorted_treedb.pprof`
- total: `80.31MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 35.01MB | 43.59% | 53.51MB | 66.63% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 18.50MB | 23.04% | 18.50MB | 23.04% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 9MB | 11.21% | 70.02MB | 87.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 4.01MB | 4.99% | 4.01MB | 4.99% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 3.53MB | 4.39% | 6.50MB | 8.10% | `compress/flate.NewWriter (inline)` |
| 3.50MB | 4.36% | 3.50MB | 4.36% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 1.71MB | 2.13% | 1.71MB | 2.13% | `compress/flate.newDeflateFast (inline)` |
| 1.27MB | 1.58% | 1.27MB | 1.58% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 1.27MB | 1.58% | 2.98MB | 3.71% | `compress/flate.(*compressor).init` |
| 1.01MB | 1.26% | 1.01MB | 1.26% | `runtime/pprof.(*protobuf).string` |
| 1MB | 1.25% | 1MB | 1.25% | `runtime/pprof.allFrames` |
| 0.50MB | 0.63% | 0.50MB | 0.63% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 0 | 0.00% | 6.50MB | 8.10% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 70.02MB | 87.18% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 57.01MB | 70.98% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 57.01MB | 70.98% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 57.01MB | 70.98% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 57.01MB | 70.98% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 57.01MB | 70.98% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 57.01MB | 70.98% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 57.01MB | 70.98% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 70.02MB | 87.18% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 57.01MB | 70.98% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 70.02MB | 87.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 70.02MB | 87.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |

### full_scan (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_full_scan_treedb.pprof`
- total: `85425`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 65540 | 76.72% | 65540 | 76.72% | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` |
| 12016 | 14.07% | 12016 | 14.07% | `runtime/pprof.allFrames` |
| 5911 | 6.92% | 5980 | 7.00% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1820 | 2.13% | 1820 | 2.13% | `runtime.mallocgc` |
| 0 | 0.00% | 65540 | 76.72% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 0 | 0.00% | 65540 | 76.72% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafKeyFlagsView` |
| 0 | 0.00% | 65540 | 76.72% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafKeyFlagsViewColumnarPrefixV2 (inline)` |
| 0 | 0.00% | 65540 | 76.72% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 0 | 0.00% | 65540 | 76.72% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).Next` |
| 0 | 0.00% | 65540 | 76.72% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).getLeafKeyFlags` |
| 0 | 0.00% | 65540 | 76.72% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadCurrent` |
| 0 | 0.00% | 83194 | 97.39% | `main.main` |
| 0 | 0.00% | 83194 | 97.39% | `main.runBenchmark` |
| 0 | 0.00% | 65540 | 76.72% | `main.runBenchmark.func37` |
| 0 | 0.00% | 2251 | 2.64% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2251 | 2.64% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 15403 | 18.03% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 15403 | 18.03% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 1820 | 2.13% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1820 | 2.13% | `runtime.(*traceStackTable).dump` |
| 0 | 0.00% | 1820 | 2.13% | `runtime.dumpStacksRec` |
| 0 | 0.00% | 83194 | 97.39% | `runtime.main` |
| 0 | 0.00% | 1820 | 2.13% | `runtime.makeTraceFrames` |
| 0 | 0.00% | 1820 | 2.13% | `runtime.makeslice` |
| 0 | 0.00% | 1820 | 2.13% | `runtime.traceAdvance` |

### full_scan (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_full_scan_treedb.pprof`
- total: `18730.08kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5415.52kB | 28.91% | 8427.44kB | 44.99% | `compress/flate.NewWriter (inline)` |
| 4096.25kB | 21.87% | 4096.25kB | 21.87% | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` |
| 2078.30kB | 11.10% | 10121.81kB | 54.04% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 2048.40kB | 10.94% | 2048.40kB | 10.94% | `runtime/pprof.allFrames` |
| 1845.91kB | 9.86% | 3011.92kB | 16.08% | `compress/flate.(*compressor).init` |
| 1166.01kB | 6.23% | 1166.01kB | 6.23% | `compress/flate.newDeflateFast (inline)` |
| 532.26kB | 2.84% | 1048.90kB | 5.60% | `runtime/pprof.(*protobuf).string (inline)` |
| 518.65kB | 2.77% | 518.65kB | 2.77% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 516.64kB | 2.76% | 516.64kB | 2.76% | `runtime/pprof.(*protobuf).varint (inline)` |
| 512.14kB | 2.73% | 512.14kB | 2.73% | `runtime.mallocgc` |
| 0 | 0.00% | 8427.44kB | 44.99% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 4096.25kB | 21.87% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 0 | 0.00% | 4096.25kB | 21.87% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafKeyFlagsView` |
| 0 | 0.00% | 4096.25kB | 21.87% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafKeyFlagsViewColumnarPrefixV2 (inline)` |
| 0 | 0.00% | 4096.25kB | 21.87% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 0 | 0.00% | 4096.25kB | 21.87% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).Next` |
| 0 | 0.00% | 4096.25kB | 21.87% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).getLeafKeyFlags` |
| 0 | 0.00% | 4096.25kB | 21.87% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadCurrent` |
| 0 | 0.00% | 16802.73kB | 89.71% | `main.main` |
| 0 | 0.00% | 16802.73kB | 89.71% | `main.runBenchmark` |
| 0 | 0.00% | 4096.25kB | 21.87% | `main.runBenchmark.func37` |
| 0 | 0.00% | 4195.88kB | 22.40% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 4195.88kB | 22.40% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 8510.60kB | 45.44% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 8510.60kB | 45.44% | `main.writeRuntimeProfileSnapshotTemp` |

### prefix_scan (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_prefix_scan_treedb.pprof`
- total: `20417`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 14201 | 69.55% | 14201 | 69.55% | `runtime/pprof.allFrames` |
| 5513 | 27.00% | 6128 | 30.01% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 585 | 2.87% | 585 | 2.87% | `runtime/pprof.(*protobuf).varint (inline)` |
| 43 | 0.21% | 9988 | 48.92% | `runtime/pprof.writeProfileInternal` |
| 0 | 0.00% | 20416 | 100.00% | `main.main` |
| 0 | 0.00% | 20416 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 10428 | 51.08% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 10428 | 51.08% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 9988 | 48.92% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 9988 | 48.92% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 20416 | 100.00% | `runtime.main` |
| 0 | 0.00% | 20416 | 100.00% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 20329 | 99.57% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 585 | 2.87% | `runtime/pprof.(*protobuf).endMessage` |
| 0 | 0.00% | 585 | 2.87% | `runtime/pprof.(*protobuf).length (inline)` |
| 0 | 0.00% | 9945 | 48.71% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 10428 | 51.08% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 7655 | 37.49% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 10428 | 51.08% | `runtime/pprof.writeHeapInternal` |
| 0 | 0.00% | 10428 | 51.08% | `runtime/pprof.writeHeapProto` |
| 0 | 0.00% | 2333 | 11.43% | `runtime/pprof.writeMutex` |

### prefix_scan (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_prefix_scan_treedb.pprof`
- total: `15360.17kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5415.52kB | 35.26% | 9145.68kB | 59.54% | `compress/flate.NewWriter (inline)` |
| 3147.16kB | 20.49% | 3730.16kB | 24.28% | `compress/flate.(*compressor).init` |
| 2560.52kB | 16.67% | 2560.52kB | 16.67% | `runtime/pprof.allFrames` |
| 1562.96kB | 10.18% | 9415.90kB | 61.30% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1060.55kB | 6.90% | 1060.55kB | 6.90% | `runtime/pprof.(*protobuf).string (inline)` |
| 583.01kB | 3.80% | 583.01kB | 3.80% | `compress/flate.newDeflateFast (inline)` |
| 518.02kB | 3.37% | 10965.76kB | 71.39% | `runtime/pprof.writeProfileInternal` |
| 512.44kB | 3.34% | 512.44kB | 3.34% | `runtime/pprof.(*protobuf).varint (inline)` |
| 0 | 0.00% | 9145.68kB | 59.54% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 14457.58kB | 94.12% | `main.main` |
| 0 | 0.00% | 14457.58kB | 94.12% | `main.runBenchmark` |
| 0 | 0.00% | 3491.82kB | 22.73% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 3491.82kB | 22.73% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 10965.76kB | 71.39% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 10965.76kB | 71.39% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 14457.58kB | 94.12% | `runtime.main` |
| 0 | 0.00% | 14457.58kB | 94.12% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 11976.42kB | 77.97% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 1963.14kB | 12.78% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 8243.09kB | 53.67% | `runtime/pprof.(*profileBuilder).flush` |
| 0 | 0.00% | 902.59kB | 5.88% | `runtime/pprof.(*profileBuilder).pbSample` |
| 0 | 0.00% | 512.44kB | 3.34% | `runtime/pprof.(*protobuf).endMessage` |
| 0 | 0.00% | 512.44kB | 3.34% | `runtime/pprof.(*protobuf).length (inline)` |
| 0 | 0.00% | 1060.55kB | 6.90% | `runtime/pprof.(*protobuf).strings` |
| 0 | 0.00% | 10447.74kB | 68.02% | `runtime/pprof.printCountCycleProfile` |

### random_delete (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_delete_treedb.pprof`
- total: `1072623`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 294916 | 27.49% | 294916 | 27.49% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 268711 | 25.05% | 268711 | 25.05% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 262152 | 24.44% | 530863 | 49.49% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 240304 | 22.40% | 1066377 | 99.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` |
| 5462 | 0.51% | 5462 | 0.51% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 1066377 | 99.42% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 825786 | 76.99% | `github.com/snissn/gomap/TreeDB.(*DB).Delete.func1` |
| 0 | 0.00% | 825786 | 76.99% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 825786 | 76.99% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 825786 | 76.99% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 825786 | 76.99% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 825786 | 76.99% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 825786 | 76.99% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 825786 | 76.99% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 1066377 | 99.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).DeleteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 825786 | 76.99% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 530863 | 49.49% | `github.com/snissn/gomap/TreeDB/internal/commitlog.EncodeRawKVBatchPayload` |
| 0 | 0.00% | 1066377 | 99.42% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Delete` |
| 0 | 0.00% | 1072029 | 99.94% | `main.main` |
| 0 | 0.00% | 1072029 | 99.94% | `main.runBenchmark` |
| 0 | 0.00% | 1066377 | 99.42% | `main.runBenchmark.func31` |
| 0 | 0.00% | 1072029 | 99.94% | `runtime.main` |

### random_delete (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_delete_treedb.pprof`
- total: `53.83MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 14.50MB | 26.94% | 14.50MB | 26.94% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 8MB | 14.86% | 22.50MB | 41.80% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 5.50MB | 10.22% | 39.50MB | 73.37% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` |
| 5.29MB | 9.82% | 8.33MB | 15.48% | `compress/flate.NewWriter (inline)` |
| 4.50MB | 8.36% | 4.50MB | 8.36% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 4.07MB | 7.56% | 4.07MB | 7.56% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 3.81MB | 7.08% | 3.81MB | 7.08% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 1.91MB | 3.54% | 3.04MB | 5.66% | `compress/flate.(*compressor).init` |
| 1.14MB | 2.12% | 1.14MB | 2.12% | `compress/flate.newDeflateFast (inline)` |
| 1.05MB | 1.96% | 8.37MB | 15.55% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1.02MB | 1.89% | 1.02MB | 1.89% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` |
| 0.52MB | 0.97% | 3.01MB | 5.60% | `runtime/pprof.writeHeapInternal` |
| 0.51MB | 0.95% | 0.51MB | 0.95% | `runtime/pprof.(*protobuf).string` |
| 0.51MB | 0.95% | 0.51MB | 0.95% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 0.50MB | 0.93% | 0.50MB | 0.93% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 0.50MB | 0.93% | 0.50MB | 0.93% | `runtime.mallocgc` |
| 0.50MB | 0.93% | 0.50MB | 0.93% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 8.33MB | 15.48% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 39.50MB | 73.37% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 28.91MB | 53.70% | `github.com/snissn/gomap/TreeDB.(*DB).Delete.func1` |
| 0 | 0.00% | 28.91MB | 53.70% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 28.91MB | 53.70% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 28.91MB | 53.70% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 28.91MB | 53.70% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 28.91MB | 53.70% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |

### random_read (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_read_treedb.pprof`
- total: `24244`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 16402 | 67.65% | 16452 | 67.86% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 7647 | 31.54% | 7647 | 31.54% | `runtime/pprof.allFrames` |
| 13 | 0.05% | 2209 | 9.11% | `runtime/pprof.writeHeapInternal` |
| 0 | 0.00% | 13316 | 54.92% | `main.main` |
| 0 | 0.00% | 13316 | 54.92% | `main.runBenchmark` |
| 0 | 0.00% | 2209 | 9.11% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2209 | 9.11% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 11107 | 45.81% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 11107 | 45.81% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 13316 | 54.92% | `runtime.main` |
| 0 | 0.00% | 13316 | 54.92% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 24099 | 99.40% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 10992 | 45.34% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 11107 | 45.81% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 10928 | 45.08% | `runtime/pprof.profileWriter` |
| 0 | 0.00% | 2209 | 9.11% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 5565 | 22.95% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 2196 | 9.06% | `runtime/pprof.writeHeapProto` |
| 0 | 0.00% | 5542 | 22.86% | `runtime/pprof.writeMutex` |
| 0 | 0.00% | 11107 | 45.81% | `runtime/pprof.writeProfileInternal` |

### random_read (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_read_treedb.pprof`
- total: `13190.93kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4512.93kB | 34.21% | 6397.18kB | 48.50% | `compress/flate.NewWriter (inline)` |
| 2621.44kB | 19.87% | 7984.07kB | 60.53% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1301.25kB | 9.86% | 1884.25kB | 14.28% | `compress/flate.(*compressor).init` |
| 1057.15kB | 8.01% | 1057.15kB | 8.01% | `runtime/pprof.(*protobuf).string (inline)` |
| 1040.08kB | 7.88% | 1040.08kB | 7.88% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 1024.16kB | 7.76% | 1024.16kB | 7.76% | `runtime/pprof.allFrames` |
| 583.01kB | 4.42% | 583.01kB | 4.42% | `compress/flate.newDeflateFast (inline)` |
| 532.26kB | 4.04% | 2487.47kB | 18.86% | `runtime/pprof.writeHeapInternal` |
| 518.65kB | 3.93% | 518.65kB | 3.93% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 0 | 0.00% | 6397.18kB | 48.50% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 10681.25kB | 80.97% | `main.main` |
| 0 | 0.00% | 10681.25kB | 80.97% | `main.runBenchmark` |
| 0 | 0.00% | 2487.47kB | 18.86% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2487.47kB | 18.86% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 8193.77kB | 62.12% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 8193.77kB | 62.12% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 1040.08kB | 7.88% | `os.ReadFile` |
| 0 | 0.00% | 1040.08kB | 7.88% | `os.readFileContents` |
| 0 | 0.00% | 10681.25kB | 80.97% | `runtime.main` |
| 0 | 0.00% | 10681.25kB | 80.97% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 9008.23kB | 68.29% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 3566.83kB | 27.04% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 6397.18kB | 48.50% | `runtime/pprof.(*profileBuilder).flush` |
| 0 | 0.00% | 1553.21kB | 11.77% | `runtime/pprof.(*profileBuilder).pbSample` |
| 0 | 0.00% | 1040.08kB | 7.88% | `runtime/pprof.(*profileBuilder).readMapping` |

### random_read_batch (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_read_batch_treedb.pprof`
- total: `2330`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2185 | 93.78% | 2185 | 93.78% | `runtime/pprof.allFrames` |
| 58 | 2.49% | 58 | 2.49% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 28 | 1.20% | 28 | 1.20% | `github.com/snissn/gomap/TreeDB/tree.getGetManyScratch` |
| 26 | 1.12% | 101 | 4.33% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 13 | 0.56% | 13 | 0.56% | `runtime/pprof.(*protobuf).string (inline)` |
| 8 | 0.34% | 12 | 0.52% | `compress/flate.(*compressor).init` |
| 5 | 0.21% | 17 | 0.73% | `compress/flate.NewWriter (inline)` |
| 0 | 0.00% | 28 | 1.20% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel.func3` |
| 0 | 0.00% | 28 | 1.20% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).GetManyView` |
| 0 | 0.00% | 2299 | 98.67% | `main.main` |
| 0 | 0.00% | 2299 | 98.67% | `main.runBenchmark` |
| 0 | 0.00% | 47 | 2.02% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 47 | 2.02% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 2249 | 96.52% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 2249 | 96.52% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 2299 | 98.67% | `runtime.main` |
| 0 | 0.00% | 2296 | 98.54% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 2286 | 98.11% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2249 | 96.52% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 47 | 2.02% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 47 | 2.02% | `runtime/pprof.writeHeapInternal` |

### random_read_batch (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_read_batch_treedb.pprof`
- total: `11547.66kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3610.34kB | 31.26% | 6145.22kB | 53.22% | `compress/flate.NewWriter (inline)` |
| 1951.87kB | 16.90% | 2534.87kB | 21.95% | `compress/flate.(*compressor).init` |
| 1621.53kB | 14.04% | 1621.53kB | 14.04% | `github.com/snissn/gomap/TreeDB/tree.getGetManyScratch` |
| 1078.47kB | 9.34% | 8267.77kB | 71.60% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1044.08kB | 9.04% | 1044.08kB | 9.04% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 613.99kB | 5.32% | 613.99kB | 5.32% | `main.runBenchmark.func35` |
| 583.01kB | 5.05% | 583.01kB | 5.05% | `compress/flate.newDeflateFast (inline)` |
| 532.26kB | 4.61% | 532.26kB | 4.61% | `runtime/pprof.(*protobuf).string (inline)` |
| 512.12kB | 4.43% | 512.12kB | 4.43% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 6145.22kB | 53.22% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 1621.53kB | 14.04% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel.func3` |
| 0 | 0.00% | 1621.53kB | 14.04% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).GetManyView` |
| 0 | 0.00% | 9275.51kB | 80.32% | `main.main` |
| 0 | 0.00% | 9275.51kB | 80.32% | `main.runBenchmark` |
| 0 | 0.00% | 1974.28kB | 17.10% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 1974.28kB | 17.10% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 6687.24kB | 57.91% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 6687.24kB | 57.91% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 9275.51kB | 80.32% | `runtime.main` |
| 0 | 0.00% | 8661.52kB | 75.01% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 8779.89kB | 76.03% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 1182.88kB | 10.24% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 6145.22kB | 53.22% | `runtime/pprof.(*profileBuilder).flush` |
| 0 | 0.00% | 532.26kB | 4.61% | `runtime/pprof.(*protobuf).strings` |
| 0 | 0.00% | 6687.24kB | 57.91% | `runtime/pprof.printCountCycleProfile` |

### random_read_parallel (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_read_parallel_treedb.pprof`
- total: `2533`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2185 | 86.26% | 2185 | 86.26% | `runtime/pprof.allFrames` |
| 101 | 3.99% | 101 | 3.99% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 98 | 3.87% | 98 | 3.87% | `math/rand.newSource (inline)` |
| 68 | 2.68% | 68 | 2.68% | `runtime/pprof.(*protobuf).string (inline)` |
| 55 | 2.17% | 55 | 2.17% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 12 | 0.47% | 12 | 0.47% | `compress/flate.newDeflateFast (inline)` |
| 9 | 0.36% | 21 | 0.83% | `compress/flate.(*compressor).init` |
| 5 | 0.20% | 26 | 1.03% | `compress/flate.NewWriter (inline)` |
| 0 | 0.00% | 26 | 1.03% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 341 | 13.46% | `main.main` |
| 0 | 0.00% | 341 | 13.46% | `main.runBenchmark` |
| 0 | 0.00% | 98 | 3.87% | `main.runBenchmark.func33` |
| 0 | 0.00% | 59 | 2.33% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 59 | 2.33% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 184 | 7.26% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 184 | 7.26% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 98 | 3.87% | `math/rand.NewSource (inline)` |
| 0 | 0.00% | 101 | 3.99% | `os.ReadFile` |
| 0 | 0.00% | 101 | 3.99% | `os.readFileContents` |
| 0 | 0.00% | 341 | 13.46% | `runtime.main` |
| 0 | 0.00% | 243 | 9.59% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 2258 | 89.14% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2260 | 89.22% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 73 | 2.88% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 26 | 1.03% | `runtime/pprof.(*profileBuilder).flush` |

### random_read_parallel (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_read_parallel_treedb.pprof`
- total: `10933.42kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3610.34kB | 33.02% | 7311.23kB | 66.87% | `compress/flate.NewWriter (inline)` |
| 1951.87kB | 17.85% | 3700.89kB | 33.85% | `compress/flate.(*compressor).init` |
| 1749.02kB | 16.00% | 1749.02kB | 16.00% | `compress/flate.newDeflateFast (inline)` |
| 1040.72kB | 9.52% | 1040.72kB | 9.52% | `runtime/pprof.(*protobuf).string (inline)` |
| 1038.08kB | 9.49% | 1038.08kB | 9.49% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 516.64kB | 4.73% | 516.64kB | 4.73% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 514.63kB | 4.71% | 514.63kB | 4.71% | `math/rand.newSource (inline)` |
| 512.12kB | 4.68% | 512.12kB | 4.68% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 7311.23kB | 66.87% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 9187.67kB | 84.03% | `main.main` |
| 0 | 0.00% | 9187.67kB | 84.03% | `main.runBenchmark` |
| 0 | 0.00% | 514.63kB | 4.71% | `main.runBenchmark.func33` |
| 0 | 0.00% | 2069.85kB | 18.93% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2069.85kB | 18.93% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 6603.20kB | 60.39% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 6603.20kB | 60.39% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 514.63kB | 4.71% | `math/rand.NewSource (inline)` |
| 0 | 0.00% | 1038.08kB | 9.49% | `os.ReadFile` |
| 0 | 0.00% | 1038.08kB | 9.49% | `os.readFileContents` |
| 0 | 0.00% | 9187.67kB | 84.03% | `runtime.main` |
| 0 | 0.00% | 8673.04kB | 79.33% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 6203.77kB | 56.74% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2786.47kB | 25.49% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 5691.65kB | 52.06% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 7311.23kB | 66.87% | `runtime/pprof.(*profileBuilder).flush` |

### random_read_parallel_acquire_snapshot (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_read_parallel_acquire_snapshot_treedb.pprof`
- total: `2397535`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2359550 | 98.42% | 2359550 | 98.42% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 16384 | 0.68% | 19331 | 0.81% | `github.com/snissn/gomap/TreeDB/db.(*vacuumInternalTreeBuilder).append` |
| 13108 | 0.55% | 13108 | 0.55% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 2359550 | 98.42% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2359550 | 98.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 2359550 | 98.42% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2359550 | 98.42% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 2359550 | 98.42% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).AcquireReadSnapshot` |

### random_read_parallel_acquire_snapshot (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_read_parallel_acquire_snapshot_treedb.pprof`
- total: `2.26GB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2.25GB | 99.39% | 2.25GB | 99.39% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 0 | 0.00% | 2.25GB | 99.39% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2.25GB | 99.39% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 2.25GB | 99.39% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2.25GB | 99.39% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 2.25GB | 99.39% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).AcquireReadSnapshot` |
| 0 | 0.00% | 2.25GB | 99.39% | `main.runBenchmark.func34.1` |
| 0 | 0.00% | 2.25GB | 99.39% | `main.runBenchmark.func34.2` |

### random_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_write_treedb.pprof`
- total: `1336122`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 524313 | 39.24% | 524313 | 39.24% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 360455 | 26.98% | 1334451 | 99.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 262148 | 19.62% | 262148 | 19.62% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 186806 | 13.98% | 711119 | 53.22% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 0 | 0.00% | 1334451 | 99.87% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 973267 | 72.84% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 973267 | 72.84% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 973267 | 72.84% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 973267 | 72.84% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 973267 | 72.84% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 973267 | 72.84% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 973267 | 72.84% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 1334451 | 99.87% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 973267 | 72.84% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 1334451 | 99.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 1334451 | 99.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 973267 | 72.84% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 973267 | 72.84% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 711119 | 53.22% | `github.com/snissn/gomap/TreeDB/internal/commitlog.EncodeRawKVBatchPayload` |
| 0 | 0.00% | 1334451 | 99.87% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 1334688 | 99.89% | `main.main` |
| 0 | 0.00% | 1334688 | 99.89% | `main.runBenchmark` |
| 0 | 0.00% | 1334451 | 99.87% | `main.runBenchmark.func19` |
| 0 | 0.00% | 1334688 | 99.89% | `runtime.main` |

### random_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_random_write_treedb.pprof`
- total: `142.10MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 44.18MB | 31.09% | 44.18MB | 31.09% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 28.50MB | 20.06% | 54.51MB | 38.36% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 26MB | 18.30% | 26MB | 18.30% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 8.77MB | 6.17% | 8.77MB | 6.17% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 8MB | 5.63% | 127.09MB | 89.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 7.63MB | 5.37% | 7.63MB | 5.37% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 4.41MB | 3.10% | 10.08MB | 7.10% | `compress/flate.NewWriter (inline)` |
| 4MB | 2.81% | 4MB | 2.81% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 2.87MB | 2.02% | 5.68MB | 3.99% | `compress/flate.(*compressor).init` |
| 2.81MB | 1.98% | 2.81MB | 1.98% | `compress/flate.newDeflateFast (inline)` |
| 1.91MB | 1.34% | 1.91MB | 1.34% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 1.01MB | 0.71% | 1.01MB | 0.71% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 1MB | 0.70% | 1MB | 0.70% | `runtime.mallocgc` |
| 0.50MB | 0.36% | 7.15MB | 5.03% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 10.08MB | 7.10% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 127.09MB | 89.44% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 58.51MB | 41.17% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 58.51MB | 41.17% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 58.51MB | 41.17% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 58.51MB | 41.17% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 58.51MB | 41.17% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 58.51MB | 41.17% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 58.51MB | 41.17% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 127.09MB | 89.44% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 58.51MB | 41.17% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |

### sequential_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_sequential_write_treedb.pprof`
- total: `1118543`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 511201 | 45.70% | 511201 | 45.70% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 218457 | 19.53% | 1110487 | 99.28% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 216301 | 19.34% | 727502 | 65.04% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 163842 | 14.65% | 163842 | 14.65% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 0 | 0.00% | 1110487 | 99.28% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 891344 | 79.69% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 891344 | 79.69% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 891344 | 79.69% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 891344 | 79.69% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 891344 | 79.69% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 891344 | 79.69% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 891344 | 79.69% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 1110487 | 99.28% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 891344 | 79.69% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 1110487 | 99.28% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 1110487 | 99.28% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 891344 | 79.69% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 891344 | 79.69% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 727502 | 65.04% | `github.com/snissn/gomap/TreeDB/internal/commitlog.EncodeRawKVBatchPayload` |
| 0 | 0.00% | 1110487 | 99.28% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 1112714 | 99.48% | `main.main` |
| 0 | 0.00% | 1112714 | 99.48% | `main.runBenchmark` |
| 0 | 0.00% | 1110487 | 99.28% | `main.runBenchmark.func18` |
| 0 | 0.00% | 1112714 | 99.48% | `runtime.main` |

### sequential_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/allocs_sequential_write_treedb.pprof`
- total: `153.96MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 33.01MB | 21.44% | 54.01MB | 35.08% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 25.26MB | 16.41% | 25.26MB | 16.41% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 21MB | 13.64% | 21MB | 13.64% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 19.08MB | 12.40% | 19.08MB | 12.40% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 14.56MB | 9.45% | 14.56MB | 9.45% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` |
| 6.53MB | 4.24% | 6.53MB | 4.24% | `github.com/snissn/gomap/TreeDB/zipper.init.func2` |
| 4.61MB | 2.99% | 4.61MB | 2.99% | `github.com/snissn/gomap/TreeDB/zipper.acquireSpanNativeLeafLogPayloadArena` |
| 4.50MB | 2.92% | 106.42MB | 69.12% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 4MB | 2.60% | 4MB | 2.60% | `github.com/snissn/gomap/TreeDB/internal/valuelog.getWriterAppendBuf` |
| 3.53MB | 2.29% | 8.67MB | 5.63% | `compress/flate.NewWriter (inline)` |
| 3.13MB | 2.03% | 3.13MB | 2.03% | `github.com/snissn/gomap/TreeDB/zipper.(*ReadOnlyPrepareResult).ensureInitialCapacity` |
| 2.81MB | 1.82% | 2.81MB | 1.82% | `compress/flate.newDeflateFast (inline)` |
| 2.50MB | 1.62% | 2.50MB | 1.62% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 2.33MB | 1.52% | 5.14MB | 3.34% | `compress/flate.(*compressor).init` |
| 2.28MB | 1.48% | 2.28MB | 1.48% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve` |
| 2.28MB | 1.48% | 2.28MB | 1.48% | `github.com/snissn/gomap/TreeDB/caching.getEntrySlice` |
| 1.06MB | 0.69% | 1.06MB | 0.69% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildOrderedKey64Locked` |
| 0 | 0.00% | 8.67MB | 5.63% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 106.42MB | 69.12% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 56.51MB | 36.70% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 56.51MB | 36.70% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 56.51MB | 36.70% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 56.51MB | 36.70% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 56.51MB | 36.70% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 56.51MB | 36.70% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |

## Full vs Prefix Comparison

### treedb

- shared hotspots:
  - `runtime.scanObject` (full 6.12%, prefix 10.00%)
  - `runtime.spanClass.sizeclass (inline)` (full 6.12%, prefix 10.00%)
  - `runtime.memmove` (full 4.08%, prefix 10.00%)
  - `runtime.tryDeferToSpanScan` (full 2.04%, prefix 10.00%)
  - `runtime.pcvalue` (full 2.04%, prefix 0.00%)
- prefix-only hotspots:
  - `runtime.typePointers.next` (40.00% flat)
  - `runtime.spanClass.noscan (inline)` (10.00% flat)
  - `runtime.step` (10.00% flat)
  - `main.main` (0.00% flat)
  - `main.runBenchmark` (0.00% flat)
- full-only hotspots:
  - `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` (36.73% flat)
  - `hash/crc32.simpleUpdate (inline)` (4.08% flat)
  - `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` (2.04% flat)
  - `github.com/snissn/go-crc32-asm.updateIEEEFast` (2.04% flat)
  - `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` (2.04% flat)

## Contention Profiles (Per Test)

### batch_delete (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_batch_delete_treedb.pprof`
- total samples: `1853.26ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1842.86ms | 99.44% | 1842.86ms | 99.44% | `runtime.selectgo` |
| 0 | 0.00% | 1842.86ms | 99.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 1842.86ms | 99.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |

### batch_delete (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_batch_delete_treedb.pprof`
- total samples: `8.35ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 8.35ms | 100.00% | 8.35ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared (inline)` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write.func4` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).invokeCommandWALAppend` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVBatchPayloadCommandWALTrustedPreparedWithMode` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVBatchPayloadCommandWALPrepared (inline)` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVBatchPayloadCommandWALPreparedCapture` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 8.35ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 8.35ms | 100.00% | `main.main` |
| 0 | 0.00% | 8.35ms | 100.00% | `main.runBenchmark` |

### batch_random (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_batch_random_treedb.pprof`
- total samples: `6.90s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5.15s | 74.60% | 5.15s | 74.60% | `runtime.selectgo` |
| 1.70s | 24.70% | 1.70s | 24.70% | `runtime.chanrecv1` |
| 0.05s | 0.70% | 0.05s | 0.70% | `sync.(*Mutex).Lock (inline)` |
| 0 | 0.00% | 2.45s | 35.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 2.45s | 35.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 0.50s | 7.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 0.70s | 10.13% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 0.50s | 7.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 0.70s | 10.13% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 0.75s | 10.86% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 0.75s | 10.86% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 0.75s | 10.88% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 1s | 14.50% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1.70s | 24.69% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 0.70s | 10.19% | `runtime.traceStartReadCPU.func1` |

### batch_random (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_batch_random_treedb.pprof`
- total samples: `48.59ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 48.59ms | 100.00% | 48.59ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared (inline)` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write.func4` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).invokeCommandWALAppend` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVBatchPayloadCommandWALTrustedPreparedWithMode` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVBatchPayloadCommandWALPrepared (inline)` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVBatchPayloadCommandWALPreparedCapture` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 48.59ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 48.59ms | 100.00% | `main.main` |
| 0 | 0.00% | 48.59ms | 100.00% | `main.runBenchmark` |

### batch_small_seq (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_batch_small_seq_treedb.pprof`
- total samples: `6.55s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4.80s | 73.28% | 4.80s | 73.28% | `runtime.selectgo` |
| 1.70s | 26.03% | 1.70s | 26.03% | `runtime.chanrecv1` |
| 0.05s | 0.69% | 0.05s | 0.69% | `sync.(*Mutex).Lock (inline)` |
| 0 | 0.00% | 2.12s | 32.37% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 2.12s | 32.37% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 0.50s | 7.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 0.70s | 10.68% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 0.50s | 7.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 0.70s | 10.68% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 0.75s | 11.45% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 0.75s | 11.45% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 0.73s | 11.16% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 1s | 15.28% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1.70s | 26.02% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 0.70s | 10.74% | `runtime.traceStartReadCPU.func1` |

### batch_small_seq (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_batch_small_seq_treedb.pprof`
- total samples: `45.05ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 45.05ms | 100.00% | 45.05ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared (inline)` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write.func4` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).invokeCommandWALAppend` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVBatchPayloadCommandWALTrustedPreparedWithMode` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVBatchPayloadCommandWALPrepared (inline)` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVBatchPayloadCommandWALPreparedCapture` |
| 0 | 0.00% | 45.02ms | 99.94% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 45.02ms | 99.94% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 45.05ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 45.05ms | 100.00% | `main.main` |
| 0 | 0.00% | 45.05ms | 100.00% | `main.runBenchmark` |

### batch_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_batch_write_treedb.pprof`
- total samples: `1162.39ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 913.44ms | 78.58% | 913.44ms | 78.58% | `runtime.selectgo` |
| 201.53ms | 17.34% | 201.53ms | 17.34% | `runtime.chanrecv1` |
| 47.41ms | 4.08% | 47.41ms | 4.08% | `sync.(*Mutex).Lock (inline)` |
| 0 | 0.00% | 464.04ms | 39.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 464.04ms | 39.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 200ms | 17.21% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 200ms | 17.21% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 249.40ms | 21.46% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 249.40ms | 21.46% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 47.41ms | 4.08% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 47.41ms | 4.08% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 200.80ms | 17.28% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 200.80ms | 17.28% | `runtime.traceStartReadCPU.func1` |

### batch_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_batch_write_treedb.pprof`
- total samples: `47.40ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 47.40ms | 100.00% | 47.40ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared.func1` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write.func4` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).invokeCommandWALAppend` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVCommandWALOrderedEntryScanWithHintPreparedFinalizedAndMode` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVCommandWALOrderedEntryScanWithHintPreparedFinalized` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 47.40ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 47.40ms | 100.00% | `main.main` |
| 0 | 0.00% | 47.40ms | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 47.40ms | 100.00% | `main.runBenchmark.func23` |

### batch_write_steady (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_batch_write_steady_treedb.pprof`
- total samples: `55.56s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 31.31s | 56.35% | 31.31s | 56.35% | `runtime.selectgo` |
| 16.75s | 30.14% | 16.75s | 30.14% | `runtime.chanrecv2` |
| 5.72s | 10.29% | 5.72s | 10.29% | `runtime.chanrecv1` |
| 1.23s | 2.21% | 1.23s | 2.21% | `sync.(*WaitGroup).Wait` |
| 0.56s | 1.01% | 0.56s | 1.01% | `sync.(*Mutex).Lock (inline)` |
| 0 | 0.00% | 1.24s | 2.24% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 1.24s | 2.24% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 1.23s | 2.22% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |
| 0 | 0.00% | 2.97s | 5.35% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 2.97s | 5.35% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 1.23s | 2.22% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 2.50s | 4.50% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 1.20s | 2.16% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCheckpointFrontierLocked` |
| 0 | 0.00% | 2.70s | 4.86% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 2s | 3.60% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 2s | 3.60% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 2.50s | 4.50% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 2s | 3.60% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 2.70s | 4.86% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 2.75s | 4.95% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |

### batch_write_steady (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_batch_write_steady_treedb.pprof`
- total samples: `735.63ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 735.57ms | 100.00% | 735.57ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 52.39ms | 7.12% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared.func1` |
| 0 | 0.00% | 52.39ms | 7.12% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 50.95ms | 6.93% | `github.com/snissn/gomap/TreeDB.(*DB).snapshotPublicCommandWALCheckpointCutover` |
| 0 | 0.00% | 50.95ms | 6.93% | `github.com/snissn/gomap/TreeDB.(*DB).snapshotPublicCommandWALCheckpointCutover-fm` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write.func4` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).invokeCommandWALAppend` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 52.39ms | 7.12% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |
| 0 | 0.00% | 52.39ms | 7.12% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 50.95ms | 6.93% | `github.com/snissn/gomap/TreeDB/caching.(*DB).snapshotCommandWALCheckpointCutover` |
| 0 | 0.00% | 682.44ms | 92.77% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVCommandWALOrderedEntryScanWithHintPreparedFinalizedAndMode` |
| 0 | 0.00% | 50.95ms | 6.93% | `github.com/snissn/gomap/TreeDB/db.(*DB).RotateCommandWALActiveSegment` |

### dataset_write_random (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_dataset_write_random_treedb.pprof`
- total samples: `11680.19ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 9841.65ms | 84.26% | 9841.65ms | 84.26% | `runtime.selectgo` |
| 1819.71ms | 15.58% | 1819.71ms | 15.58% | `runtime.chanrecv1` |
| 0 | 0.00% | 2641.96ms | 22.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 2641.96ms | 22.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 999.42ms | 8.56% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 700.17ms | 5.99% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 1000.36ms | 8.56% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 1000.34ms | 8.56% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 999.42ms | 8.56% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 1000.34ms | 8.56% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 700.17ms | 5.99% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 749.08ms | 6.41% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 749.08ms | 6.41% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 2000.07ms | 17.12% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |
| 0 | 0.00% | 2000.07ms | 17.12% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).start.gowrap1` |
| 0 | 0.00% | 750.25ms | 6.42% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 135.07ms | 1.16% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 135.07ms | 1.16% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 1000.20ms | 8.56% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1702.42ms | 14.58% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 702.22ms | 6.01% | `runtime.traceStartReadCPU.func1` |

### dataset_write_random (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_dataset_write_random_treedb.pprof`
- total samples: `18.90ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 18.81ms | 99.55% | 18.81ms | 99.55% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntent (inline)` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 18.81ms | 99.52% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 18.81ms | 99.52% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 18.88ms | 99.93% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 18.88ms | 99.93% | `main.main` |
| 0 | 0.00% | 18.88ms | 99.93% | `main.runBenchmark` |
| 0 | 0.00% | 18.88ms | 99.93% | `main.runBenchmark.func21` |
| 0 | 0.00% | 18.81ms | 99.52% | `runtime.deferreturn` |

### dataset_write_sorted (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_dataset_write_sorted_treedb.pprof`
- total samples: `5515.96ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3692.49ms | 66.94% | 3692.49ms | 66.94% | `runtime.selectgo` |
| 1797.96ms | 32.60% | 1797.96ms | 32.60% | `runtime.chanrecv1` |
| 0 | 0.00% | 992.21ms | 17.99% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 992.21ms | 17.99% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 500.66ms | 9.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 700.37ms | 12.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 500.66ms | 9.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 700.37ms | 12.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 749.86ms | 13.59% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 749.86ms | 13.59% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 749.40ms | 13.59% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 119.71ms | 2.17% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 119.71ms | 2.17% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 1000.36ms | 18.14% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1702.68ms | 30.87% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 702.32ms | 12.73% | `runtime.traceStartReadCPU.func1` |

### dataset_write_sorted (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_dataset_write_sorted_treedb.pprof`
- total samples: `25.50ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 25.48ms | 99.93% | 25.48ms | 99.93% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntent (inline)` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 25.48ms | 99.93% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 25.48ms | 99.93% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 25.49ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 25.49ms | 100.00% | `main.main` |
| 0 | 0.00% | 25.49ms | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 25.49ms | 100.00% | `main.runBenchmark.func22` |
| 0 | 0.00% | 25.48ms | 99.93% | `runtime.deferreturn` |

### full_scan (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_full_scan_treedb.pprof`
- total samples: `6703.18ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5299.79ms | 79.06% | 5299.79ms | 79.06% | `runtime.selectgo` |
| 1403.38ms | 20.94% | 1403.38ms | 20.94% | `runtime.chanrecv1` |
| 0 | 0.00% | 499.39ms | 7.45% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 300.37ms | 4.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 999.85ms | 14.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 999.94ms | 14.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 499.39ms | 7.45% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 999.94ms | 14.92% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 300.37ms | 4.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 249.44ms | 3.72% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 249.44ms | 3.72% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 2000.35ms | 29.84% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |
| 0 | 0.00% | 2000.35ms | 29.84% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).start.gowrap1` |
| 0 | 0.00% | 250.45ms | 3.74% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 1000.90ms | 14.93% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1402.77ms | 20.93% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 401.87ms | 6.00% | `runtime.traceStartReadCPU.func1` |

### full_scan (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_full_scan_treedb.pprof`
- total samples: `14.80us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 14.80us | 100.00% | 14.80us | 100.00% | `runtime.unlock (inline)` |
| 0 | 0.00% | 3.25us | 21.98% | `github.com/snissn/gomap/TreeDB/caching.readPoolPressureMemStats` |
| 0 | 0.00% | 3.25us | 21.98% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 3.25us | 21.98% | `github.com/snissn/gomap/TreeDB/caching.sampleAndPublishPoolPressureSnapshot` |
| 0 | 0.00% | 3.25us | 21.98% | `github.com/snissn/gomap/TreeDB/caching.samplePoolPressureSnapshot` |
| 0 | 0.00% | 11.55us | 78.02% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 0 | 0.00% | 11.55us | 78.02% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 11.55us | 78.02% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadUnsafeTo` |
| 0 | 0.00% | 11.55us | 78.02% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |
| 0 | 0.00% | 11.55us | 78.02% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).readAtWithDictTo` |
| 0 | 0.00% | 11.55us | 78.02% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*Set).ReadUnsafeTo` |
| 0 | 0.00% | 11.55us | 78.02% | `github.com/snissn/gomap/TreeDB/internal/valuelog.readAtWithDictToScratch` |
| 0 | 0.00% | 11.55us | 78.02% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).Next` |
| 0 | 0.00% | 11.55us | 78.02% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadCurrent` |
| 0 | 0.00% | 11.55us | 78.02% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadNodeRef` |
| 0 | 0.00% | 11.55us | 78.02% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).stepForward` |
| 0 | 0.00% | 11.55us | 78.02% | `internal/poll.(*FD).Pread` |
| 0 | 0.00% | 11.55us | 78.02% | `internal/poll.(*FD).Pread.func1 (inline)` |
| 0 | 0.00% | 11.55us | 78.02% | `internal/poll.ignoringEINTR2[go.shape.int] (inline)` |
| 0 | 0.00% | 11.55us | 78.02% | `main.main` |
| 0 | 0.00% | 11.55us | 78.02% | `main.runBenchmark` |
| 0 | 0.00% | 11.55us | 78.02% | `main.runBenchmark.func37` |
| 0 | 0.00% | 11.55us | 78.02% | `os.(*File).ReadAt` |
| 0 | 0.00% | 11.55us | 78.02% | `os.(*File).pread (inline)` |
| 0 | 0.00% | 11.55us | 78.02% | `runtime.(*traceMap).newTraceMapNode` |

### prefix_scan (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_prefix_scan_treedb.pprof`
- total samples: `270.37us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 270.37us | 100.00% | 270.37us | 100.00% | `runtime.chanrecv1` |
| 0 | 0.00% | 270.37us | 100.00% | `main.main` |
| 0 | 0.00% | 270.37us | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 270.37us | 100.00% | `main.runBenchmark.func47` |
| 0 | 0.00% | 270.37us | 100.00% | `main.runBenchmark.func48` |
| 0 | 0.00% | 270.37us | 100.00% | `runtime.main` |
| 0 | 0.00% | 270.37us | 100.00% | `runtime/pprof.StopCPUProfile` |

### prefix_scan (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_prefix_scan_treedb.pprof`
- total samples: `0`

_No entries parsed._

### random_delete (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_random_delete_treedb.pprof`
- total samples: `22884.05ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 18256.51ms | 79.78% | 18256.51ms | 79.78% | `runtime.selectgo` |
| 4113.56ms | 17.98% | 4113.56ms | 17.98% | `runtime.chanrecv1` |
| 513.98ms | 2.25% | 513.98ms | 2.25% | `sync.(*Mutex).Lock (inline)` |
| 0 | 0.00% | 464.76ms | 2.03% | `github.com/snissn/gomap/TreeDB.(*DB).publicCommandWALAutoCheckpointBytes` |
| 0 | 0.00% | 2161.18ms | 9.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 2161.18ms | 9.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 2000.46ms | 8.74% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 464.76ms | 2.03% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeRunPeriodicVlogGenerationMaintenance` |
| 0 | 0.00% | 464.76ms | 2.03% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeRunVlogGenerationMaintenance (inline)` |
| 0 | 0.00% | 464.76ms | 2.03% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeRunVlogGenerationMaintenanceWithOptions` |
| 0 | 0.00% | 464.76ms | 2.03% | `github.com/snissn/gomap/TreeDB/caching.(*DB).reclaimableWALBytes` |
| 0 | 0.00% | 2100.30ms | 9.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 2000.15ms | 8.74% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 2465.14ms | 10.77% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 2000.46ms | 8.74% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 2465.14ms | 10.77% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 2100.30ms | 9.18% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 1999.85ms | 8.74% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 1999.85ms | 8.74% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 464.76ms | 2.03% | `github.com/snissn/gomap/TreeDB/db.(*DB).CommandWALBytes` |
| 0 | 0.00% | 464.76ms | 2.03% | `github.com/snissn/gomap/TreeDB/db.(*DB).commandWALActiveSegmentSnapshot` |
| 0 | 0.00% | 4000.71ms | 17.48% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |
| 0 | 0.00% | 4000.71ms | 17.48% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).start.gowrap1` |
| 0 | 0.00% | 1993.48ms | 8.71% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 464.76ms | 2.03% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).ActiveSegmentSnapshot` |

### random_delete (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_random_delete_treedb.pprof`
- total samples: `736.21ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 736.21ms | 100.00% | 736.21ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).Delete.func1` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).DeleteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntent (inline)` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 736.21ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Delete` |
| 0 | 0.00% | 736.21ms | 100.00% | `main.main` |
| 0 | 0.00% | 736.21ms | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 736.21ms | 100.00% | `main.runBenchmark.func31` |
| 0 | 0.00% | 736.21ms | 100.00% | `runtime.deferreturn` |
| 0 | 0.00% | 736.21ms | 100.00% | `runtime.main` |

### random_read (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_random_read_treedb.pprof`
- total samples: `4301.96ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2898.33ms | 67.37% | 2898.33ms | 67.37% | `runtime.selectgo` |
| 1403.63ms | 32.63% | 1403.63ms | 32.63% | `runtime.chanrecv1` |
| 0 | 0.00% | 399.61ms | 9.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 399.61ms | 9.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 249.49ms | 5.80% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 249.49ms | 5.80% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 1999.29ms | 46.47% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |
| 0 | 0.00% | 1999.29ms | 46.47% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).start.gowrap1` |
| 0 | 0.00% | 249.94ms | 5.81% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 1000.34ms | 23.25% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1402.69ms | 32.61% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 402.36ms | 9.35% | `runtime.traceStartReadCPU.func1` |

### random_read (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_random_read_treedb.pprof`
- total samples: `0`

_No entries parsed._

### random_read_batch (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_random_read_batch_treedb.pprof`
- total samples: `154.25ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 100.98ms | 65.47% | 100.98ms | 65.47% | `runtime.chanrecv1` |
| 53.25ms | 34.52% | 53.25ms | 34.52% | `sync.(*WaitGroup).Wait` |
| 0 | 0.00% | 53.25ms | 34.52% | `github.com/snissn/gomap/TreeDB.(*DB).GetManyView` |
| 0 | 0.00% | 53.25ms | 34.52% | `github.com/snissn/gomap/TreeDB/caching.(*DB).GetManyView` |
| 0 | 0.00% | 53.25ms | 34.52% | `github.com/snissn/gomap/TreeDB/caching.(*DB).backendGetManyView` |
| 0 | 0.00% | 53.25ms | 34.52% | `github.com/snissn/gomap/TreeDB/db.(*DB).GetManyView` |
| 0 | 0.00% | 53.25ms | 34.52% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewOnce` |
| 0 | 0.00% | 53.25ms | 34.52% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel` |
| 0 | 0.00% | 53.25ms | 34.52% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).GetManyView` |
| 0 | 0.00% | 53.93ms | 34.96% | `main.main` |
| 0 | 0.00% | 53.93ms | 34.96% | `main.runBenchmark` |
| 0 | 0.00% | 53.25ms | 34.52% | `main.runBenchmark.func35` |
| 0 | 0.00% | 100.30ms | 65.02% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 53.93ms | 34.96% | `runtime.main` |
| 0 | 0.00% | 100.30ms | 65.02% | `runtime.traceStartReadCPU.func1` |

### random_read_batch (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_random_read_batch_treedb.pprof`
- total samples: `9451ns`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 8228ns | 87.06% | 8228ns | 87.06% | `sync.(*RWMutex).RUnlock (inline)` |
| 1223ns | 12.94% | 1223ns | 12.94% | `runtime.unlock (inline)` |
| 0 | 0.00% | 9451ns | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel.func3` |
| 0 | 0.00% | 8228ns | 87.06% | `github.com/snissn/gomap/TreeDB/db.(*DB).getManyViewParallel.gowrap1` |
| 0 | 0.00% | 8228ns | 87.06% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).ReleaseLeafLogPageView` |
| 0 | 0.00% | 1223ns | 12.94% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 1223ns | 12.94% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadUnsafeTo` |
| 0 | 0.00% | 1223ns | 12.94% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |
| 0 | 0.00% | 1223ns | 12.94% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).readAtWithDictTo` |
| 0 | 0.00% | 120ns | 1.27% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).takeDecodeScratch` |
| 0 | 0.00% | 1223ns | 12.94% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*Set).ReadUnsafeTo` |
| 0 | 0.00% | 1103ns | 11.67% | `github.com/snissn/gomap/TreeDB/internal/valuelog.decodeFramePayloadTo` |
| 0 | 0.00% | 1103ns | 11.67% | `github.com/snissn/gomap/TreeDB/internal/valuelog.decodeRecordToScratch` |
| 0 | 0.00% | 120ns | 1.27% | `github.com/snissn/gomap/TreeDB/internal/valuelog.getDecodeScratch` |
| 0 | 0.00% | 1223ns | 12.94% | `github.com/snissn/gomap/TreeDB/internal/valuelog.readAtWithDictToScratch` |
| 0 | 0.00% | 9451ns | 100.00% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).GetManyView` |
| 0 | 0.00% | 1223ns | 12.94% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).loadLeafNodeForGetMany` |
| 0 | 0.00% | 8228ns | 87.06% | `github.com/snissn/gomap/TreeDB/tree.getManyLeafNodeLease.Release` |
| 0 | 0.00% | 120ns | 1.27% | `runtime.chanrecv` |
| 0 | 0.00% | 1103ns | 11.67% | `runtime.copystack` |
| 0 | 0.00% | 1103ns | 11.67% | `runtime.newstack` |
| 0 | 0.00% | 120ns | 1.27% | `runtime.selectnbrecv` |
| 0 | 0.00% | 1103ns | 11.67% | `runtime.stackalloc` |
| 0 | 0.00% | 1103ns | 11.67% | `runtime.stackcacherefill` |

### random_read_parallel (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_random_read_parallel_treedb.pprof`
- total samples: `3.33s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2s | 60.20% | 2s | 60.20% | `runtime.selectgo` |
| 0.52s | 15.58% | 0.52s | 15.58% | `sync.(*WaitGroup).Wait` |
| 0.51s | 15.34% | 0.51s | 15.34% | `runtime.chanrecv1` |
| 0.30s | 8.88% | 0.30s | 8.88% | `sync.(*Mutex).Lock (inline)` |
| 0 | 0.00% | 0.50s | 15.09% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 0.07s | 1.96% | `github.com/snissn/gomap/TreeDB/caching.(*DB).installBackendValueLogReadBarrier.func2` |
| 0 | 0.00% | 0.50s | 15.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 0.50s | 15.09% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 0.50s | 15.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 0.07s | 1.96% | `github.com/snissn/gomap/TreeDB/caching.dispatchBackendValueLogReadBarrierWithSize` |
| 0 | 0.00% | 0.50s | 15.08% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 0.50s | 15.08% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 0.05s | 1.41% | `github.com/snissn/gomap/TreeDB/caching.snapshotBackendValueLogReadBarrierDBs` |
| 0 | 0.00% | 0.30s | 8.89% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetAppend` |
| 0 | 0.00% | 0.50s | 15.02% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 0.23s | 6.87% | `github.com/snissn/gomap/TreeDB/db.(*valueReader).ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 0.23s | 6.87% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 0.23s | 6.87% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadUnsafeTo` |
| 0 | 0.00% | 0.23s | 6.87% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |
| 0 | 0.00% | 0.07s | 1.96% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ensureCurrentWritableReadableFor` |
| 0 | 0.00% | 0.14s | 4.34% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).readAtWithDictTo` |

### random_read_parallel (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_random_read_parallel_treedb.pprof`
- total samples: `309.63ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 307.48ms | 99.31% | 307.65ms | 99.36% | `sync.(*Mutex).Unlock (partial-inline)` |
| 1.82ms | 0.59% | 1.82ms | 0.59% | `runtime.unlock (inline)` |
| 0 | 0.00% | 66.70ms | 21.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).installBackendValueLogReadBarrier.func2` |
| 0 | 0.00% | 19.17ms | 6.19% | `github.com/snissn/gomap/TreeDB/caching.(*DB).leafLogAppendLaneMatchesSeq` |
| 0 | 0.00% | 19.17ms | 6.19% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogLaneForFileID` |
| 0 | 0.00% | 66.70ms | 21.54% | `github.com/snissn/gomap/TreeDB/caching.dispatchBackendValueLogReadBarrierWithSize` |
| 0 | 0.00% | 47.10ms | 15.21% | `github.com/snissn/gomap/TreeDB/caching.snapshotBackendValueLogReadBarrierDBs` |
| 0 | 0.00% | 308.85ms | 99.75% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetAppend` |
| 0 | 0.00% | 231.97ms | 74.92% | `github.com/snissn/gomap/TreeDB/db.(*valueReader).ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 233.09ms | 75.28% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 232.83ms | 75.20% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadUnsafeTo` |
| 0 | 0.00% | 232.83ms | 75.20% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ReadUnsafeTo` |
| 0 | 0.00% | 66.70ms | 21.54% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).ensureCurrentWritableReadableFor` |
| 0 | 0.00% | 19.06ms | 6.16% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).maybeScheduleRemap` |
| 0 | 0.00% | 147.07ms | 47.50% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).readAtWithDictTo` |
| 0 | 0.00% | 19.06ms | 6.16% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).readViaMmapViewTo` |
| 0 | 0.00% | 45.35ms | 14.65% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).releaseDecodeScratch` |
| 0 | 0.00% | 45.28ms | 14.63% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).releaseDecodeScratch-fm` |
| 0 | 0.00% | 101.55ms | 32.80% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).takeDecodeScratch` |
| 0 | 0.00% | 101.36ms | 32.73% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*File).takeDecodeScratch-fm` |
| 0 | 0.00% | 232.83ms | 75.20% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*Set).ReadUnsafeTo` |
| 0 | 0.00% | 147.07ms | 47.50% | `github.com/snissn/gomap/TreeDB/internal/valuelog.readAtWithDictToScratch` |
| 0 | 0.00% | 308.85ms | 99.75% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).GetAppend` |
| 0 | 0.00% | 308.85ms | 99.75% | `github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView` |
| 0 | 0.00% | 75.77ms | 24.47% | `github.com/snissn/gomap/TreeDB/tree.(*outerLeafRecentEstimatorState).observe` |

### random_read_parallel_acquire_snapshot (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `22.22s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 17.34s | 78.02% | 17.34s | 78.02% | `runtime.selectgo` |
| 2.41s | 10.83% | 2.41s | 10.83% | `runtime.chanrecv1` |
| 1.39s | 6.26% | 1.39s | 6.26% | `sync.(*WaitGroup).Wait` |
| 1s | 4.49% | 1s | 4.49% | `sync.(*Mutex).Lock (inline)` |
| 0.09s | 0.40% | 0.62s | 2.79% | `sync.(*RWMutex).Lock` |
| 0 | 0.00% | 0.57s | 2.56% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 0.57s | 2.56% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 1.49s | 6.69% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 1.49s | 6.69% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 1.50s | 6.74% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 1.50s | 6.75% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 2s | 9.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 2s | 9.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 1.50s | 6.74% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 2s | 9.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 1.50s | 6.75% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 1.50s | 6.75% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 1.50s | 6.75% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 0.57s | 2.56% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 0.57s | 2.56% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 0.57s | 2.56% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 0.57s | 2.56% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotWithValueLogPublicationLockHeld (inline)` |
| 0 | 0.00% | 0.38s | 1.72% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).Close` |
| 0 | 0.00% | 0.38s | 1.72% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead` |
| 0 | 0.00% | 0.38s | 1.72% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead` |

### random_read_parallel_acquire_snapshot (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `1005.87ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 832.39ms | 82.75% | 833.56ms | 82.87% | `sync.(*Mutex).Unlock (partial-inline)` |
| 88.59ms | 8.81% | 88.59ms | 8.81% | `sync.(*RWMutex).RUnlock (inline)` |
| 81.69ms | 8.12% | 81.69ms | 8.12% | `runtime.unlock (inline)` |
| 0.36ms | 0.04% | 379.05ms | 37.68% | `sync.(*RWMutex).Unlock` |
| 0 | 0.00% | 539.11ms | 53.60% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 89.36ms | 8.88% | `github.com/snissn/gomap/TreeDB.(*DB).runCachedBackendMaintenance` |
| 0 | 0.00% | 89.36ms | 8.88% | `github.com/snissn/gomap/TreeDB.(*DB).vacuumIndexOnlineStats` |
| 0 | 0.00% | 89.36ms | 8.88% | `github.com/snissn/gomap/TreeDB.(*DB).vacuumIndexOnlineStats.func2` |
| 0 | 0.00% | 89.36ms | 8.88% | `github.com/snissn/gomap/TreeDB.(*bgIndexVacuumWorker).Start.func1` |
| 0 | 0.00% | 89.36ms | 8.88% | `github.com/snissn/gomap/TreeDB.(*bgIndexVacuumWorker).runOnceContext` |
| 0 | 0.00% | 89.36ms | 8.88% | `github.com/snissn/gomap/TreeDB.(*bgIndexVacuumWorker).runOnceContextLocked` |
| 0 | 0.00% | 89.36ms | 8.88% | `github.com/snissn/gomap/TreeDB.backgroundIndexVacuumRun` |
| 0 | 0.00% | 539.11ms | 53.60% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireBackendSnapshotFastPath` |
| 0 | 0.00% | 539.11ms | 53.60% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 89.36ms | 8.88% | `github.com/snissn/gomap/TreeDB/db.(*DB).VacuumIndexOnlineWithStats` |
| 0 | 0.00% | 539.11ms | 53.60% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 469.97ms | 46.72% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 469.97ms | 46.72% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotWithValueLogPublicationLockHeld (inline)` |
| 0 | 0.00% | 45.89ms | 4.56% | `github.com/snissn/gomap/TreeDB/db.(*DB).releaseLeafGenerationPinSet` |
| 0 | 0.00% | 32.16ms | 3.20% | `github.com/snissn/gomap/TreeDB/db.(*DB).retainLeafGenerationPinSet (inline)` |
| 0 | 0.00% | 89.36ms | 8.88% | `github.com/snissn/gomap/TreeDB/db.(*DB).vacuumIndexOnlineProductionV1` |

### random_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_random_write_treedb.pprof`
- total samples: `6742.01ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4881.32ms | 72.40% | 4881.32ms | 72.40% | `runtime.selectgo` |
| 1841.71ms | 27.32% | 1841.71ms | 27.32% | `runtime.chanrecv1` |
| 0 | 0.00% | 681.58ms | 10.11% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 681.58ms | 10.11% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 499.81ms | 7.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 700.47ms | 10.39% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 499.81ms | 7.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 700.47ms | 10.39% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 499.61ms | 7.41% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 499.61ms | 7.41% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 2000.10ms | 29.67% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |
| 0 | 0.00% | 2000.10ms | 29.67% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).start.gowrap1` |
| 0 | 0.00% | 499.76ms | 7.41% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 156.53ms | 2.32% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 156.53ms | 2.32% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 1000.73ms | 14.84% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1703.22ms | 25.26% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 702.49ms | 10.42% | `runtime.traceStartReadCPU.func1` |

### random_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_random_write_treedb.pprof`
- total samples: `18.98ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 18.97ms | 100.00% | 18.97ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntent (inline)` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 18.97ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 18.97ms | 100.00% | `main.main` |
| 0 | 0.00% | 18.97ms | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 18.97ms | 100.00% | `main.runBenchmark.func19` |
| 0 | 0.00% | 18.97ms | 100.00% | `runtime.deferreturn` |

### sequential_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block_sequential_write_treedb.pprof`
- total samples: `2.61s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1.75s | 67.10% | 1.75s | 67.10% | `runtime.selectgo` |
| 0.74s | 28.34% | 0.74s | 28.34% | `runtime.chanrecv1` |
| 0.09s | 3.32% | 0.09s | 3.32% | `sync.(*WaitGroup).Wait` |
| 0.03s | 1.25% | 0.03s | 1.25% | `sync.(*Mutex).Lock (inline)` |
| 0 | 0.00% | 0.64s | 24.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 0.64s | 24.42% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 0.10s | 3.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureVlogDictPrepWorkers.gowrap1` |
| 0 | 0.00% | 0.09s | 3.32% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAll` |
| 0 | 0.00% | 0.09s | 3.32% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked` |
| 0 | 0.00% | 0.09s | 3.32% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 0.10s | 3.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop` |
| 0 | 0.00% | 0.09s | 3.32% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 0.50s | 19.19% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 0.50s | 19.19% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 0.50s | 19.18% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 0.16s | 6.10% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 0.16s | 6.10% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 0.60s | 23.07% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 0.60s | 23.07% | `runtime.traceStartReadCPU.func1` |

### sequential_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex_sequential_write_treedb.pprof`
- total samples: `32.57ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 32.47ms | 99.70% | 32.47ms | 99.70% | `sync.(*Mutex).Unlock (partial-inline)` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 9.50ms | 29.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 9.50ms | 29.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 9.50ms | 29.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 9.50ms | 29.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4` |
| 0 | 0.00% | 9.50ms | 29.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 9.50ms | 29.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionMode (inline)` |
| 0 | 0.00% | 9.50ms | 29.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 9.50ms | 29.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCommandPublish (inline)` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 22.99ms | 70.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 9.50ms | 29.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).writeCanonicalFlushRunOpsChunk` |
| 0 | 0.00% | 9.50ms | 29.15% | `github.com/snissn/gomap/TreeDB/db.(*Batch).Write` |

## Contention Profiles (Global)

### block

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/block.pprof`
- total samples: `924.41s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 673.27s | 72.83% | 673.27s | 72.83% | `runtime.selectgo` |
| 168.30s | 18.21% | 168.30s | 18.21% | `runtime.chanrecv2` |
| 65.21s | 7.05% | 65.21s | 7.05% | `runtime.chanrecv1` |
| 12.94s | 1.40% | 12.94s | 1.40% | `sync.(*WaitGroup).Wait` |
| 0 | 0.00% | 10.93s | 1.18% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 10.93s | 1.18% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 10.86s | 1.17% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |
| 0 | 0.00% | 32.30s | 3.49% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 32.30s | 3.49% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 11.62s | 1.26% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 32.07s | 3.47% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 120.41s | 13.03% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureVlogDictPrepWorkers.gowrap1` |
| 0 | 0.00% | 10.50s | 1.14% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCheckpointFrontierLocked` |
| 0 | 0.00% | 31.93s | 3.45% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 29.87s | 3.23% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 31.56s | 3.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 30.84s | 3.34% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 170.21s | 18.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogWriter.gowrap1` |
| 0 | 0.00% | 32.07s | 3.47% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 120.41s | 13.03% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop` |
| 0 | 0.00% | 30.84s | 3.34% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 170.21s | 18.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogWriteLoop` |
| 0 | 0.00% | 29.87s | 3.23% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 31.93s | 3.45% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 32.31s | 3.50% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |

### mutex

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/mutex.pprof`
- total samples: `5024.39ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4835.88ms | 96.25% | 4837.23ms | 96.27% | `sync.(*Mutex).Unlock (partial-inline)` |
| 90.15ms | 1.79% | 90.16ms | 1.79% | `sync.(*RWMutex).RUnlock` |
| 85.79ms | 1.71% | 85.79ms | 1.71% | `runtime.unlock (inline)` |
| 9.48ms | 0.19% | 987.26ms | 19.65% | `sync.(*RWMutex).Unlock` |
| 0 | 0.00% | 539.11ms | 10.73% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 1738.26ms | 34.60% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 736.21ms | 14.65% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 736.21ms | 14.65% | `github.com/snissn/gomap/TreeDB.(*DB).Delete.func1` |
| 0 | 0.00% | 86.34ms | 1.72% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 1552.40ms | 30.90% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 1654.38ms | 32.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 729.85ms | 14.53% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared` |
| 0 | 0.00% | 729.85ms | 14.53% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared.func1` |
| 0 | 0.00% | 101.98ms | 2.03% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared` |
| 0 | 0.00% | 101.98ms | 2.03% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 101.98ms | 2.03% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 822.55ms | 16.37% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 822.55ms | 16.37% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 1738.26ms | 34.60% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 553.10ms | 11.01% | `github.com/snissn/gomap/TreeDB.(*DB).cleanupPublicCommandWALCheckpoint` |
| 0 | 0.00% | 553.10ms | 11.01% | `github.com/snissn/gomap/TreeDB.(*DB).cleanupPublicCommandWALCheckpoint-fm` |
| 0 | 0.00% | 477.91ms | 9.51% | `github.com/snissn/gomap/TreeDB.(*DB).refreshPublicCommandWALCheckpointFallback` |
| 0 | 0.00% | 477.91ms | 9.51% | `github.com/snissn/gomap/TreeDB.(*DB).refreshPublicCommandWALCheckpointFallback.deferwrap1` |
| 0 | 0.00% | 1654.38ms | 32.93% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 1654.38ms | 32.93% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |

## TreeDB Stats Metadata

### keys=200000 / TreeDB

| stat | value |
|---|---:|
| `treedb.applied_command_lsn` | `1002100` |
| `treedb.cache.append_only.entry_hint_capacity_bytes` | `1228128` |
| `treedb.cache.append_only.entry_hint_entries` | `12793` |
| `treedb.cache.append_only.entry_pool_admission_drop_bytes_total` | `0` |
| `treedb.cache.append_only.entry_pool_admission_drops_total` | `0` |
| `treedb.cache.append_only.entry_pool_drop_bytes_total` | `0` |
| `treedb.cache.append_only.entry_pool_drops_total` | `0` |
| `treedb.cache.append_only.entry_pool_gets_total` | `682` |
| `treedb.cache.append_only.entry_pool_puts_total` | `828` |
| `treedb.cache.append_only.entry_pool_retained_bytes_estimate` | `97168104` |
| `treedb.cache.append_only.entry_pool_retained_bytes_max_estimate` | `97168104` |
| `treedb.cache.append_only.mem_lease_count` | `8` |
| `treedb.cache.append_only.mem_lease_entry_backing_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_entry_capacity` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_active_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_active_chunks` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_retained_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_retained_chunks` | `0` |
| `treedb.cache.append_only.mutable_count` | `16` |
| `treedb.cache.append_only.mutable_entry_backing_bytes` | `0` |
| `treedb.cache.append_only.mutable_entry_capacity` | `0` |
| `treedb.cache.append_only.mutable_from_lease_total` | `88` |
| `treedb.cache.append_only.mutable_from_pool_total` | `0` |
| `treedb.cache.append_only.mutable_new_alloc_queue_bytes_sum` | `1412615048` |
| `treedb.cache.append_only.mutable_new_alloc_total` | `88` |
| `treedb.cache.append_only.mutable_new_alloc_with_queue_total` | `88` |
| `treedb.cache.append_only.mutable_pool_drops_total` | `0` |
| `treedb.cache.append_only.mutable_pool_entry_backing_dropped_bytes_total` | `2610784` |
| `treedb.cache.append_only.mutable_pool_puts_total` | `80` |
| `treedb.cache.append_only.mutable_sparse_trim_dropped_bytes_total` | `0` |
| `treedb.cache.append_only.mutable_sparse_trim_total` | `0` |
| `treedb.cache.append_only.mutable_trim_dropped_bytes_total` | `21605760` |
| `treedb.cache.append_only.mutable_trim_total` | `368` |
| `treedb.cache.append_only.mutable_value_arena_active_bytes` | `0` |
| `treedb.cache.append_only.mutable_value_arena_active_chunks` | `0` |
| `treedb.cache.append_only.mutable_value_arena_retained_bytes` | `0` |
| `treedb.cache.append_only.mutable_value_arena_retained_chunks` | `0` |
| `treedb.cache.append_only.reserve.calls_total` | `432` |
| `treedb.cache.append_only.reserve.entries_total` | `153761` |
| `treedb.cache.append_only.reserve.grow_bytes_total` | `235158176` |
| `treedb.cache.append_only.reserve.grow_calls_total` | `432` |
| `treedb.cache.append_only.reserve.skipped_growth_allocs_total` | `83` |
| `treedb.cache.append_only.reserve.skipped_growth_bytes_total` | `1576960` |
| `treedb.cache.append_only.value_arena_pool_admission_drop_bytes_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_admission_drops_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_drop_bytes_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_drops_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_gets_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_puts_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_retained_bytes_estimate` | `0` |
| `treedb.cache.append_only.value_arena_pool_retained_bytes_max_estimate` | `0` |
| `treedb.cache.auto_checkpoint.count` | `2` |
| `treedb.cache.auto_checkpoint.last_reason` | `idle` |
| `treedb.cache.backpressure_mode` | `adaptive` |
| `treedb.cache.checkpoint.active` | `false` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_last` | `0` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_max` | `0` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_total` | `0` |
| `treedb.cache.checkpoint.active_background_flush_wait_samples` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_last_internal_fill_avg_ppm` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_last_internal_fill_p50_ppm` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_last_pages` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_runs` | `0` |
| `treedb.cache.checkpoint.barrier_wait_ns_max` | `4563` |
| `treedb.cache.checkpoint.barrier_wait_ns_total` | `14510` |
| `treedb.cache.checkpoint.barrier_wait_samples` | `23` |
| `treedb.cache.checkpoint.cutover_avg_ms` | `37.217` |
| `treedb.cache.checkpoint.cutover_last_ms` | `0.001` |
| `treedb.cache.checkpoint.cutover_last_unix_nano` | `1795198054534728793` |
| `treedb.cache.checkpoint.cutover_max_ms` | `469.815` |
| `treedb.cache.checkpoint.cutover_samples` | `23` |
| `treedb.cache.checkpoint.debt.active_in_flight_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt.active_in_flight_bytes_max` | `0` |
| `treedb.cache.checkpoint.debt.active_workers_last` | `0` |
| `treedb.cache.checkpoint.debt.active_workers_max` | `0` |
| `treedb.cache.checkpoint.debt.frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.debt.frontier_lanes_max` | `0` |
| `treedb.cache.checkpoint.debt.mutable_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt.mutable_bytes_max` | `32000000` |
| `treedb.cache.checkpoint.debt.queue_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt.queue_bytes_max` | `0` |
| `treedb.cache.checkpoint.debt.queue_units_last` | `0` |
| `treedb.cache.checkpoint.debt.queue_units_max` | `0` |
| `treedb.cache.checkpoint.debt_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt_bytes_max` | `32000000` |
| `treedb.cache.checkpoint.debt_memtables_last` | `0` |
| `treedb.cache.checkpoint.debt_memtables_max` | `1` |
| `treedb.cache.checkpoint.flush_all.background_drain_bytes_last` | `0` |
| `treedb.cache.checkpoint.flush_all.background_drain_ops_last` | `0` |
| `treedb.cache.checkpoint.flush_all.background_drain_units_last` | `0` |
| `treedb.cache.checkpoint.flush_all.frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.flush_all.frontier_lanes_max` | `1` |
| `treedb.cache.checkpoint.flush_all.owned_drain_bytes_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_bytes_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.flush_all.owned_drain_ns_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_ops_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_units_last` | `0` |
| `treedb.cache.checkpoint.flush_all.owned_drain_units_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.flush_all.worker_passes_total` | `10` |
| `treedb.cache.checkpoint.flush_all.workers_last` | `0` |
| `treedb.cache.checkpoint.flush_all.workers_max` | `1` |
| `treedb.cache.checkpoint.flush_all.workers_total` | `10` |
| `treedb.cache.checkpoint.flush_preempt_requests_total` | `23` |
| `treedb.cache.checkpoint.flushmu_wait_max_ms` | `0.005` |
| `treedb.cache.checkpoint.flushmu_wait_total_ms` | `0.013` |
| `treedb.cache.checkpoint.frontier.bytes_last` | `1600000` |
| `treedb.cache.checkpoint.frontier.bytes_max` | `32000000` |
| `treedb.cache.checkpoint.frontier.drained_bytes_last` | `1600000` |
| `treedb.cache.checkpoint.frontier.drained_units_last` | `16` |
| `treedb.cache.checkpoint.frontier.post_bytes_last` | `0` |
| `treedb.cache.checkpoint.frontier.post_bytes_max` | `0` |
| `treedb.cache.checkpoint.frontier.post_units_last` | `0` |
| `treedb.cache.checkpoint.frontier.post_units_max` | `0` |
| `treedb.cache.checkpoint.frontier.samples` | `10` |
| `treedb.cache.checkpoint.frontier.units_last` | `16` |
| `treedb.cache.checkpoint.frontier.units_max` | `16` |
| `treedb.cache.checkpoint.max_ms` | `2050.059` |
| `treedb.cache.checkpoint.noop_skips` | `13` |
| `treedb.cache.checkpoint.post_frontier_admission.active` | `false` |
| `treedb.cache.checkpoint.post_frontier_admission_enabled` | `true` |
| `treedb.cache.checkpoint.preflush_kick_skips_total` | `10` |
| `treedb.cache.checkpoint.productive_wait_ratio_last` | `0.000000` |
| `treedb.cache.checkpoint.runs` | `23` |
| `treedb.cache.checkpoint.shared_drain.background_bytes_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.background_ops_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.background_units_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_bytes_total` | `213622768` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_ops_total` | `1876638` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_units_total` | `160` |
| `treedb.cache.checkpoint.shared_drain.flushmu_releases_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.wait_ns_max` | `0` |
| `treedb.cache.checkpoint.shared_drain.wait_ns_total` | `0` |
| `treedb.cache.checkpoint.stage.auto_critical_section.last_ns` | `513708011` |
| `treedb.cache.checkpoint.stage.auto_critical_section.max_ns` | `513708011` |
| `treedb.cache.checkpoint.stage.auto_critical_section.samples` | `2` |
| `treedb.cache.checkpoint.stage.auto_critical_section.total_ns` | `761323248` |
| `treedb.cache.checkpoint.stage.backend_boundary.last_ns` | `4052` |
| `treedb.cache.checkpoint.stage.backend_boundary.max_ns` | `345923664` |
| `treedb.cache.checkpoint.stage.backend_boundary.samples` | `23` |
| `treedb.cache.checkpoint.stage.backend_boundary.total_ns` | `2730019056` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.last_ns` | `1020300` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.max_ns` | `316567371` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.samples` | `21` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.total_ns` | `1809656846` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.samples` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.last_ns` | `43875503` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.max_ns` | `239369253` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.samples` | `2` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.total_ns` | `283244756` |
| `treedb.cache.checkpoint.stage.command_wal_publish.last_ns` | `500188` |
| `treedb.cache.checkpoint.stage.command_wal_publish.max_ns` | `1508608` |
| `treedb.cache.checkpoint.stage.command_wal_publish.samples` | `10` |
| `treedb.cache.checkpoint.stage.command_wal_publish.total_ns` | `8404602` |
| `treedb.cache.checkpoint.stage.cutover.last_ns` | `1282` |
| `treedb.cache.checkpoint.stage.cutover.max_ns` | `469814595` |
| `treedb.cache.checkpoint.stage.cutover.samples` | `23` |
| `treedb.cache.checkpoint.stage.cutover.total_ns` | `856002253` |
| `treedb.cache.checkpoint.stage.flush_all.last_ns` | `1089481894` |
| `treedb.cache.checkpoint.stage.flush_all.max_ns` | `1414576185` |
| `treedb.cache.checkpoint.stage.flush_all.samples` | `10` |
| `treedb.cache.checkpoint.stage.flush_all.total_ns` | `10501190031` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.last_ns` | `12837054` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.max_ns` | `12837054` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.samples` | `10` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.total_ns` | `21224827` |
| `treedb.cache.checkpoint.stage.post_maintenance.last_ns` | `26697` |
| `treedb.cache.checkpoint.stage.post_maintenance.max_ns` | `35652` |
| `treedb.cache.checkpoint.stage.post_maintenance.samples` | `10` |
| `treedb.cache.checkpoint.stage.post_maintenance.total_ns` | `289525` |
| `treedb.cache.checkpoint.stage.reducer_publish.last_ns` | `1238` |
| `treedb.cache.checkpoint.stage.reducer_publish.max_ns` | `4809287` |
| `treedb.cache.checkpoint.stage.reducer_publish.samples` | `10` |
| `treedb.cache.checkpoint.stage.reducer_publish.total_ns` | `16977835` |
| `treedb.cache.checkpoint.stage.value_log_flush.last_ns` | `673` |
| `treedb.cache.checkpoint.stage.value_log_flush.max_ns` | `881` |
| `treedb.cache.checkpoint.stage.value_log_flush.samples` | `10` |
| `treedb.cache.checkpoint.stage.value_log_flush.total_ns` | `6380` |
| `treedb.cache.checkpoint.stage.wal_cleanup.last_ns` | `674` |
| `treedb.cache.checkpoint.stage.wal_cleanup.max_ns` | `1077` |
| `treedb.cache.checkpoint.stage.wal_cleanup.samples` | `10` |
| `treedb.cache.checkpoint.stage.wal_cleanup.total_ns` | `6510` |
| `treedb.cache.checkpoint.stage.wal_rotate.last_ns` | `59` |
| `treedb.cache.checkpoint.stage.wal_rotate.max_ns` | `59` |
| `treedb.cache.checkpoint.stage.wal_rotate.samples` | `10` |
| `treedb.cache.checkpoint.stage.wal_rotate.total_ns` | `422` |
| `treedb.cache.checkpoint.total_ms` | `15906.617` |
| `treedb.cache.checkpoint.wait.active_in_flight_bytes_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.active_workers_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_bytes_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_units_last` | `0` |
| `treedb.cache.checkpoint.wait.frontier_bytes_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.frontier_drain_bytes_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.wait.frontier_drain_units_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.wait.frontier_lanes_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.frontier_units_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.post_frontier_bytes_last` | `0` |
| `treedb.cache.checkpoint.wait.post_frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.wait.post_frontier_units_last` | `0` |
| `treedb.cache.checkpoint.wait.remaining_frontier_bytes_last` | `0` |
| `treedb.cache.checkpoint.wait.remaining_frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.wait.remaining_frontier_units_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.considered_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.removed_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_current_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_pre_rotate_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_retained_last` | `0` |
| `treedb.cache.checkpoint.write_cutover.active` | `false` |
| `treedb.cache.command_wal.checkpoint_publish.piggybacked` | `10` |
| `treedb.cache.command_wal.checkpoint_publish.separate` | `0` |
| `treedb.cache.command_wal.cleanup.active` | `false` |
| `treedb.cache.command_wal.cleanup.coalesced_total` | `0` |
| `treedb.cache.command_wal.cleanup.completions_total` | `0` |
| `treedb.cache.command_wal.cleanup.pending` | `false` |
| `treedb.cache.command_wal.cleanup.requests_total` | `0` |
| `treedb.cache.command_wal.cleanup.retries_total` | `0` |
| `treedb.cache.command_wal.external_durability` | `true` |
| `treedb.cache.flush_apply.backend_batch_write_ns_total` | `9815714602` |
| `treedb.cache.flush_apply.backend_write_ns_total` | `10349221279` |
| `treedb.cache.flush_apply.batches_total` | `11` |
| `treedb.cache.flush_apply.build_ns_total` | `202790609` |
| `treedb.cache.flush_apply.bytes_total` | `230400000` |
| `treedb.cache.flush_apply.concurrency` | `6` |
| `treedb.cache.flush_apply.coordinator.active` | `0` |
| `treedb.cache.flush_apply.coordinator.active_assist_skips_total` | `0` |
| `treedb.cache.flush_apply.coordinator.active_workers` | `0` |
| `treedb.cache.flush_apply.coordinator.blocking_fallbacks_total` | `0` |
| `treedb.cache.flush_apply.coordinator.checkpoint_preemptions_total` | `0` |
| `treedb.cache.flush_apply.coordinator.errors_total` | `0` |
| `treedb.cache.flush_apply.coordinator.hard_overload_fallbacks_total` | `0` |
| `treedb.cache.flush_apply.coordinator.in_flight_bytes` | `0` |
| `treedb.cache.flush_apply.coordinator.progress_total` | `11` |
| `treedb.cache.flush_apply.coordinator.progress_wait_ns_total` | `0` |
| `treedb.cache.flush_apply.coordinator.progress_waits_total` | `0` |
| `treedb.cache.flush_apply.coordinator.stall_waits_total` | `0` |
| `treedb.cache.flush_apply.deferred_vlog_pointer_materialize_ns_total` | `17459` |
| `treedb.cache.flush_apply.entries_total` | `2000000` |
| `treedb.cache.flush_apply.foreground_assist_calls_total` | `0` |
| `treedb.cache.flush_apply.foreground_assist_flushes_total` | `0` |
| `treedb.cache.flush_apply.foreground_assist_wait_ns_total` | `0` |
| `treedb.cache.flush_apply.leaf_log_append_bytes_total` | `47005144` |
| `treedb.cache.flush_apply.leaf_log_append_frames_per_op` | `0.033757` |
| `treedb.cache.flush_apply.leaf_log_append_frames_total` | `67514` |
| `treedb.cache.flush_apply.leaf_log_append_ns_total` | `409031774` |
| `treedb.cache.flush_apply.leaf_log_append_records_total` | `112576` |
| `treedb.cache.flush_apply.leaf_log_append_wait_ns_total` | `21219302` |
| `treedb.cache.flush_apply.leaf_log_encode_compress_ns_total` | `134245998` |
| `treedb.cache.flush_apply.planning_ns_total` | `38097` |
| `treedb.cache.flush_apply.span_native` | `true` |
| `treedb.cache.flush_apply.units_total` | `176` |
| `treedb.cache.flush_apply.vlog_flush_ns_total` | `18550` |
| `treedb.cache.flush_apply.vlog_sync_ns_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_runs_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.admitted_runs_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.base_budget_covered_total` | `10` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_bytes_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_memtables_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_ops_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.decisions_total` | `11` |
| `treedb.cache.flush_backlog_coalescing.enabled` | `true` |
| `treedb.cache.flush_backlog_coalescing.last_old_leaf_bytes_per_op` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.last_ops_per_span` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.last_single_op_span_ratio` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.queued_age_ns_max` | `59141548` |
| `treedb.cache.flush_backlog_coalescing.queued_bytes_max` | `32000000` |
| `treedb.cache.flush_backlog_coalescing.queued_memtables_max` | `16` |
| `treedb.cache.flush_backlog_coalescing.selected_bytes_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_memtables_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_ops_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.checkpoint_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.close_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.disabled_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.lane_barrier_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.memory_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.memtable_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.no_pressure_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.ops_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.queue_age_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.queue_depth_total` | `11` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.range_barrier_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.stop_pressure_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.writer_stall_budget_total` | `0` |
| `treedb.cache.flush_span_run.backend_chunks_total` | `110` |
| `treedb.cache.flush_span_run.max_chunks_per_target_leaf` | `0` |
| `treedb.cache.flush_span_run.ops_per_run` | `166679.545455` |
| `treedb.cache.flush_span_run.planned_ops_total` | `1833475` |
| `treedb.cache.flush_span_run.planned_point_ops_total` | `1833475` |
| `treedb.cache.flush_span_run.range_barriers_total` | `0` |
| `treedb.cache.flush_span_run.range_delete_ops_total` | `0` |
| `treedb.cache.flush_span_run.runs_total` | `11` |
| `treedb.cache.flush_span_run.shadowed_ops_total` | `0` |
| `treedb.cache.flush_span_run.single_op_spans_total` | `0` |
| `treedb.cache.flush_span_run.source_memtables_max` | `16` |
| `treedb.cache.flush_span_run.source_memtables_total` | `176` |
| `treedb.cache.flush_span_run.source_point_ops_total` | `2000000` |
| `treedb.cache.flush_span_run.span_bytes_total` | `0` |
| `treedb.cache.flush_span_run.span_ops_total` | `0` |
| `treedb.cache.flush_span_run.target_leaf_spans_total` | `0` |
| `treedb.cache.flush_span_run.target_leaves_split_across_chunks_total` | `0` |
| `treedb.cache.leaf_log_lanes.active` | `7` |
| `treedb.cache.leaf_log_lanes.append_bytes_total` | `47005144` |
| `treedb.cache.leaf_log_lanes.append_calls_total` | `64145` |
| `treedb.cache.leaf_log_lanes.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.append_lanes_used` | `7` |
| `treedb.cache.leaf_log_lanes.append_lock_hold_ns_total` | `210396886` |
| `treedb.cache.leaf_log_lanes.append_lock_wait_ns_total` | `21219302` |
| `treedb.cache.leaf_log_lanes.append_pages_total` | `112576` |
| `treedb.cache.leaf_log_lanes.configured` | `7` |
| `treedb.cache.leaf_log_lanes.lane.00.append_bytes_total` | `13943677` |
| `treedb.cache.leaf_log_lanes.lane.00.append_calls_total` | `14381` |
| `treedb.cache.leaf_log_lanes.lane.00.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.00.append_lock_hold_ns_total` | `15519602` |
| `treedb.cache.leaf_log_lanes.lane.00.append_lock_wait_ns_total` | `18708578` |
| `treedb.cache.leaf_log_lanes.lane.00.append_pages_total` | `35849` |
| `treedb.cache.leaf_log_lanes.lane.00.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.00.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.00.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.00.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.append_bytes_total` | `6039886` |
| `treedb.cache.leaf_log_lanes.lane.01.append_calls_total` | `9746` |
| `treedb.cache.leaf_log_lanes.lane.01.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.append_lock_hold_ns_total` | `32973969` |
| `treedb.cache.leaf_log_lanes.lane.01.append_lock_wait_ns_total` | `573022` |
| `treedb.cache.leaf_log_lanes.lane.01.append_pages_total` | `14161` |
| `treedb.cache.leaf_log_lanes.lane.01.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.01.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.01.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.append_bytes_total` | `5516513` |
| `treedb.cache.leaf_log_lanes.lane.02.append_calls_total` | `8625` |
| `treedb.cache.leaf_log_lanes.lane.02.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.append_lock_hold_ns_total` | `32359824` |
| `treedb.cache.leaf_log_lanes.lane.02.append_lock_wait_ns_total` | `490034` |
| `treedb.cache.leaf_log_lanes.lane.02.append_pages_total` | `12962` |
| `treedb.cache.leaf_log_lanes.lane.02.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.02.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.02.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.append_bytes_total` | `5365482` |
| `treedb.cache.leaf_log_lanes.lane.03.append_calls_total` | `7891` |
| `treedb.cache.leaf_log_lanes.lane.03.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.append_lock_hold_ns_total` | `37724483` |
| `treedb.cache.leaf_log_lanes.lane.03.append_lock_wait_ns_total` | `277397` |
| `treedb.cache.leaf_log_lanes.lane.03.append_pages_total` | `12364` |
| `treedb.cache.leaf_log_lanes.lane.03.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.03.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.03.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.append_bytes_total` | `5334978` |
| `treedb.cache.leaf_log_lanes.lane.04.append_calls_total` | `7830` |
| `treedb.cache.leaf_log_lanes.lane.04.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.append_lock_hold_ns_total` | `34243970` |
| `treedb.cache.leaf_log_lanes.lane.04.append_lock_wait_ns_total` | `283286` |
| `treedb.cache.leaf_log_lanes.lane.04.append_pages_total` | `12247` |
| `treedb.cache.leaf_log_lanes.lane.04.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.04.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.04.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.append_bytes_total` | `5339929` |
| `treedb.cache.leaf_log_lanes.lane.05.append_calls_total` | `7819` |
| `treedb.cache.leaf_log_lanes.lane.05.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.append_lock_hold_ns_total` | `26843909` |
| `treedb.cache.leaf_log_lanes.lane.05.append_lock_wait_ns_total` | `378660` |
| `treedb.cache.leaf_log_lanes.lane.05.append_pages_total` | `12264` |
| `treedb.cache.leaf_log_lanes.lane.05.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.05.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.05.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.append_bytes_total` | `5464679` |
| `treedb.cache.leaf_log_lanes.lane.06.append_calls_total` | `7853` |
| `treedb.cache.leaf_log_lanes.lane.06.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.append_lock_hold_ns_total` | `30731129` |
| `treedb.cache.leaf_log_lanes.lane.06.append_lock_wait_ns_total` | `508325` |
| `treedb.cache.leaf_log_lanes.lane.06.append_pages_total` | `12729` |
| `treedb.cache.leaf_log_lanes.lane.06.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.06.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.06.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.segment_rotations_total` | `7` |
| `treedb.cache.memtable_mode` | `append_only` |
| `treedb.cache.memtable_residency.mutable.append_only.count` | `16` |
| `treedb.cache.memtable_residency.mutable.append_only.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.count` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.count` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.count` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.total.count` | `16` |
| `treedb.cache.memtable_residency.mutable.total.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.total.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.total.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.count` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entries` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.btree.count` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entries` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.btree.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.count` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entries` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.count` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entries` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.total.count` | `0` |
| `treedb.cache.memtable_residency.queue.total.entries` | `0` |
| `treedb.cache.memtable_residency.queue.total.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.total.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_retained_chunks` | `0` |
| `treedb.cache.queue_backlog_bytes` | `0` |
| `treedb.cache.queue_laneid_misses` | `0` |
| `treedb.cache.queue_len` | `0` |
| `treedb.cache.stats.backend_write_batches_total` | `110` |
| `treedb.cache.vlog_auto.bypass_bytes` | `0` |
| `treedb.cache.vlog_auto.bytes.block_lz4` | `392490158` |
| `treedb.cache.vlog_auto.bytes.block_snappy` | `0` |
| `treedb.cache.vlog_auto.bytes.block_zstd` | `0` |
| `treedb.cache.vlog_auto.bytes.dict` | `0` |
| `treedb.cache.vlog_auto.bytes.off` | `0` |
| `treedb.cache.vlog_auto.frames.block_lz4` | `67514` |
| `treedb.cache.vlog_auto.frames.block_snappy` | `0` |
| `treedb.cache.vlog_auto.frames.block_zstd` | `0` |
| `treedb.cache.vlog_auto.frames.dict` | `0` |
| `treedb.cache.vlog_auto.frames.off` | `0` |
| `treedb.cache.vlog_auto.frames_frac.block_lz4` | `1.000000` |
| `treedb.cache.vlog_auto.hold_enters` | `0` |
| `treedb.cache.vlog_auto.hold_exits` | `0` |
| `treedb.cache.vlog_auto.probe_attempts` | `0` |
| `treedb.cache.vlog_auto.probe_successes` | `0` |
| `treedb.cache.vlog_autotune.encode_ns_per_raw_byte` | `0.817` |
| `treedb.cache.vlog_autotune.io_ns_per_stored_byte` | `11.701` |
| `treedb.cache.vlog_autotune.observed_ratio` | `0.078493` |
| `treedb.cache.vlog_autotune.throughput_raw_MBps` | `667.733` |
| `treedb.cache.vlog_block.k.avg.lz4` | `1.667` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_1` | `49335` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_2` | `8875` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_4` | `5748` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_8` | `3556` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_1` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_2` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_4` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_8` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_1` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_2` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_4` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_8` | `0` |
| `treedb.cache.vlog_block.k.count.lz4` | `67514` |
| `treedb.cache.vlog_block.k.count.snappy` | `0` |
| `treedb.cache.vlog_block.k.count.zstd` | `0` |
| `treedb.cache.vlog_block.k.max.lz4` | `8` |
| `treedb.cache.vlog_block.k.max.snappy` | `0` |
| `treedb.cache.vlog_block.k.max.zstd` | `0` |
| `treedb.cache.vlog_block.ratio.lz4` | `0.110127` |
| `treedb.cache.vlog_block.ratio.samples.lz4` | `0` |
| `treedb.cache.vlog_block.ratio.samples.snappy` | `0` |
| `treedb.cache.vlog_block.ratio.samples.zstd` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.capacity_waste_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.copied_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_fit_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_fit_requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_present_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_current_mmap_direct_decode.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_current_mmap_direct_decode.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_fit_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_fit_requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_present_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_template_encoded_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_template_encoded_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.realloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retain_max_bytes` | `131072` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_buffers` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_bytes` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_files` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.spare_max_count` | `2` |
| `treedb.cache.vlog_decode_scratch.large_pool.alloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.entries` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.gets_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.hits_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.max_entries` | `8` |
| `treedb.cache.vlog_decode_scratch.large_pool.misses_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.puts_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.retained_buffers` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.retained_bytes` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.too_small_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.alloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.alloc_calls_total` | `175` |
| `treedb.cache.vlog_decode_scratch.small_pool.allocated_bytes_total` | `5417704` |
| `treedb.cache.vlog_decode_scratch.small_pool.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.entries` | `9` |
| `treedb.cache.vlog_decode_scratch.small_pool.gets_total` | `139627` |
| `treedb.cache.vlog_decode_scratch.small_pool.hits_total` | `139452` |
| `treedb.cache.vlog_decode_scratch.small_pool.max_entries` | `128` |
| `treedb.cache.vlog_decode_scratch.small_pool.misses_total` | `175` |
| `treedb.cache.vlog_decode_scratch.small_pool.puts_total` | `139606` |
| `treedb.cache.vlog_decode_scratch.small_pool.retained_buffers` | `9` |
| `treedb.cache.vlog_decode_scratch.small_pool.retained_bytes` | `293426` |
| `treedb.cache.vlog_decode_scratch.small_pool.too_small_total` | `145` |
| `treedb.cache.vlog_dict.attempted_frac` | `1.000000` |
| `treedb.cache.vlog_dict.cached_dict_bytes` | `0` |
| `treedb.cache.vlog_dict.cached_dict_id` | `0` |
| `treedb.cache.vlog_dict.classifier.sampled` | `0` |
| `treedb.cache.vlog_dict.classifier.skipped` | `0` |
| `treedb.cache.vlog_dict.current_k` | `0` |
| `treedb.cache.vlog_dict.frames_attempted` | `67514` |
| `treedb.cache.vlog_dict.frames_kept` | `67514` |
| `treedb.cache.vlog_dict.frames_total` | `67514` |
| `treedb.cache.vlog_dict.incompressible_bypass_bytes` | `0` |
| `treedb.cache.vlog_dict.incompressible_hits` | `0` |
| `treedb.cache.vlog_dict.incompressible_hold_remaining_bytes` | `0` |
| `treedb.cache.vlog_dict.incompressible_holds` | `0` |
| `treedb.cache.vlog_dict.kept_frac` | `1.000000` |
| `treedb.cache.vlog_dict.last_applied_dict_hash` | `0` |
| `treedb.cache.vlog_dict.last_applied_dict_id` | `0` |
| `treedb.cache.vlog_dict.last_k_update_unix_nano` | `0` |
| `treedb.cache.vlog_dict.last_publish_unix_nano` | `0` |
| `treedb.cache.vlog_dict.pause_remaining_bytes` | `0` |
| `treedb.cache.vlog_dict.trainer.last_accept_unix_nano` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_accepts` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_attempts` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_reject_reason` | `` |
| `treedb.cache.vlog_dict.trainer.profile_rejects` | `0` |
| `treedb.cache.vlog_generation.bytes.live.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.live.hot` | `47005144` |
| `treedb.cache.vlog_generation.bytes.live.total` | `47005144` |
| `treedb.cache.vlog_generation.bytes.live.warm` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.hot` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.total` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.warm` | `0` |
| `treedb.cache.vlog_generation.bytes.total.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.total.hot` | `47005144` |
| `treedb.cache.vlog_generation.bytes.total.total` | `47005144` |
| `treedb.cache.vlog_generation.bytes.total.warm` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.active` | `false` |
| `treedb.cache.vlog_generation.checkpoint_kick.gc_runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.hot_no_debt_wake.running` | `true` |
| `treedb.cache.vlog_generation.checkpoint_kick.hot_no_debt_wake.runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.pending` | `false` |
| `treedb.cache.vlog_generation.checkpoint_kick.rewrite_runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.skipped_hot_no_debt` | `10` |
| `treedb.cache.vlog_generation.churn_bytes_per_sec` | `0` |
| `treedb.cache.vlog_generation.churn_bytes_total` | `33368797` |
| `treedb.cache.vlog_generation.cold.segment_target_bytes` | `536870912` |
| `treedb.cache.vlog_generation.deferred_vector_build.active` | `false` |
| `treedb.cache.vlog_generation.deferred_vector_build.debt` | `false` |
| `treedb.cache.vlog_generation.deferred_vector_build.debt_set` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.failures` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.finalizations` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.skips` | `0` |
| `treedb.cache.vlog_generation.enabled` | `true` |
| `treedb.cache.vlog_generation.gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.deleted_segments` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_eligible_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_eligible_segments` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.gc.exec.avg_ms` | `77.186` |
| `treedb.cache.vlog_generation.gc.exec.max_ms` | `77.186` |
| `treedb.cache.vlog_generation.gc.exec.total_ms` | `77.186` |
| `treedb.cache.vlog_generation.gc.last_active_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_active_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_deleted_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_eligible_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_eligible_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_active` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_deleted` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_eligible` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_pending` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_in_use` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_other` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_overlap` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_retained` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_referenced` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_active` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_deleted` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_eligible` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_pending` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_in_use` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_other` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_overlap` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_retained` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_referenced` | `0` |
| `treedb.cache.vlog_generation.gc.last_pending_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_pending_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_in_use_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_in_use_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_other_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_other_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_overlap_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_overlap_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_retained_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_retained_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_referenced_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_referenced_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_unix_nano` | `1795198024669222793` |
| `treedb.cache.vlog_generation.gc.runs` | `1` |
| `treedb.cache.vlog_generation.hot.segment_target_bytes` | `268435456` |
| `treedb.cache.vlog_generation.leaf.segment_target_bytes` | `33554432` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_manifest_bytes` | `253` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_manifest_revisions` | `1` |
| `treedb.cache.vlog_generation.leaf_gc.errors` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.exec.total_ms` | `6.352` |
| `treedb.cache.vlog_generation.leaf_gc.runs` | `1` |
| `treedb.cache.vlog_generation.leaf_pack.admitted` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attempts` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attributed_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attributed_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.bytes_copied` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.canceled` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.deadline` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.deadline_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.errors` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.expected_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.expected_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.eligible_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_eligible_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.runs` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_attributed_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_attributed_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_bytes_copied` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_expected_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_expected_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.bytes_dead` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.bytes_to_copy` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_skip_reason` | `` |
| `treedb.cache.vlog_generation.leaf_pack.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_wall_ms` | `0.000` |
| `treedb.cache.vlog_generation.leaf_pack.max_bytes_to_copy` | `268435456` |
| `treedb.cache.vlog_generation.leaf_pack.max_foreground_queue` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.max_generations` | `32` |
| `treedb.cache.vlog_generation.leaf_pack.min_candidate_generations` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.min_interval_ms` | `30000` |
| `treedb.cache.vlog_generation.leaf_pack.min_reclaim_per_byte_copied_ppm` | `250000` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_default` | `false` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_last_attempt_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_max_bytes_to_copy` | `33554432` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_max_generations` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_timeout_ms` | `5000` |
| `treedb.cache.vlog_generation.leaf_pack.runs` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.bytes_dead` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.bytes_to_copy` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.foreground_iterators` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.min_interval` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.queue_pressure` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.write_burst` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skips` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.stop.low_yield` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.timeout_ms` | `30000` |
| `treedb.cache.vlog_generation.leaf_pack.write_burst_grace_ms` | `250` |
| `treedb.cache.vlog_generation.maintenance.acquired` | `14` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.periodic` | `14` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.active` | `false` |
| `treedb.cache.vlog_generation.maintenance.attempts` | `14` |
| `treedb.cache.vlog_generation.maintenance.collisions` | `0` |
| `treedb.cache.vlog_generation.maintenance.foreground_active_iterators` | `0` |
| `treedb.cache.vlog_generation.maintenance.foreground_last_read_unix_nano` | `1795198054349766710` |
| `treedb.cache.vlog_generation.maintenance.foreground_last_write_unix_nano` | `1795198048442178428` |
| `treedb.cache.vlog_generation.maintenance.foreground_quiet` | `false` |
| `treedb.cache.vlog_generation.maintenance.foreground_read_age_ms` | `187` |
| `treedb.cache.vlog_generation.maintenance.foreground_read_quiet` | `false` |
| `treedb.cache.vlog_generation.maintenance.foreground_write_age_ms` | `6094` |
| `treedb.cache.vlog_generation.maintenance.foreground_write_quiet` | `false` |
| `treedb.cache.vlog_generation.maintenance.pass.avg_ms` | `140.474` |
| `treedb.cache.vlog_generation.maintenance.pass.max_ms` | `778.711` |
| `treedb.cache.vlog_generation.maintenance.pass.total_ms` | `1966.631` |
| `treedb.cache.vlog_generation.maintenance.passes.noop` | `13` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.periodic` | `13` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc` | `1` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.periodic` | `1` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.pause_file.configured` | `false` |
| `treedb.cache.vlog_generation.maintenance.pause_file.paused` | `false` |
| `treedb.cache.vlog_generation.maintenance.skip.age_blocked_gate` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.before_first_checkpoint` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.checkpoint_inflight` | `5` |
| `treedb.cache.vlog_generation.maintenance.skip.maintenance_phase` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.pause_file` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.priority_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.quiet_window` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate_due_reserved` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate_not_due` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.wal_on_periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance_phase` | `steady` |
| `treedb.cache.vlog_generation.observed_gc.latency.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.observed_gc.latency.completed_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.dropped_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.max_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.total_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_oldest_age_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_oldest_unix_nano` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_attempts_max` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_attempts_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.queued_batches` | `0` |
| `treedb.cache.vlog_generation.observed_gc.queued_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.retry_dropped` | `0` |
| `treedb.cache.vlog_generation.observed_gc.retry_max_attempts` | `3` |
| `treedb.cache.vlog_generation.observed_gc.retry_queued` | `0` |
| `treedb.cache.vlog_generation.observed_gc.runs` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_deleted_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_eligible_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_in_use_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_other_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_overlap_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_retained_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_deleted_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_eligible_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_in_use_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_other_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_overlap_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_retained_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.taken_batches` | `0` |
| `treedb.cache.vlog_generation.observed_gc.taken_ids` | `0` |
| `treedb.cache.vlog_generation.policy` | `2` |
| `treedb.cache.vlog_generation.remap.failures` | `0` |
| `treedb.cache.vlog_generation.remap.successes` | `0` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_due` | `false` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_remaining_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_until_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.bytes_in` | `0` |
| `treedb.cache.vlog_generation.rewrite.bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs.queued_debt` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs.queued_debt` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.bytes_in_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.bytes_out_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.last_duration_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_live_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.last_live_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.reclaimed_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.reclaimed_vs_churn_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_still_referenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_still_referenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_still_referenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_still_referenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_unreferenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_unreferenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.ineffective_backoff_seconds` | `120` |
| `treedb.cache.vlog_generation.rewrite.ineffective_bytes_in` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_chunk_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_chunks` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_stale_ratio_ppm` | `0` |
| `treedb.cache.vlog_generation.rewrite.min_segment_age_ms` | `30000` |
| `treedb.cache.vlog_generation.rewrite.no_reclaim_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.no_reclaim_stale_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.output_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.penalties_active` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan_canceled` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty.age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty.no_selection` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_errors` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.to_empty_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_chunks_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_segments_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_live_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_stale_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_stale_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.queue.pending` | `false` |
| `treedb.cache.vlog_generation.rewrite.queue.running` | `false` |
| `treedb.cache.vlog_generation.rewrite.queue_config.debt_drain_max_segments` | `8` |
| `treedb.cache.vlog_generation.rewrite.queue_config.fresh_plan_debt_drain_max_segments` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_config.fresh_plan_debt_drain_min_segments` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_config.resume_max_segments` | `1` |
| `treedb.cache.vlog_generation.rewrite.queue_eta_seconds.budget` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_eta_seconds.recent_exec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_len` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_bytes_after_tokens` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.coverage_pct` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.ids_known` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.ids_present` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.known` | `true` |
| `treedb.cache.vlog_generation.rewrite.queue_loaded` | `true` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_after_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_after_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_before_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_before_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_delta_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_drained_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_grown_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_known_passes` | `14` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_unknown_passes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.passes` | `14` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_after_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_after_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_before_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_before_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_delta_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_drained_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_grown_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.snapshot_errors` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_prune_ids` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_prune_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.decisions` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.decisions.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter.checkpoint_kick` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter.fresh_plan` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_empty.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_per_segment` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_per_segment.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_tokens` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_tokens.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_burst` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_burst.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_safety` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_safety.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.debt_drain_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.debt_drain_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_queue_threshold` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_queue_threshold.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.none` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.none.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.queue_len` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.queue_len.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.resume_default` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.resume_default.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.effective_bytes_after` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.effective_bytes_before` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.gc_bytes_deleted` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.no_reclaim_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.reclaimed_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.source_bytes_requested` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.source_bytes_unreferenced` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.followup_suppressed` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.passes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.rewrite_started` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.budget_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.cancel_backoff` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.ineffective_backoff` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.min_interval` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.no_chunk` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.quiet_window` | `0` |
| `treedb.cache.vlog_generation.rewrite.reclaim_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.reclaimed_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_due` | `false` |
| `treedb.cache.vlog_generation.rewrite.stage_due_in_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_observed_age_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_observed_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_pending` | `false` |
| `treedb.cache.vlog_generation.rewrite.value_bytes_copied` | `0` |
| `treedb.cache.vlog_generation.rewrite.value_records_copied` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.bytes_per_sec` | `134217728` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_share_of_budget_pct` | `0.000` |
| `treedb.cache.vlog_generation.rewrite_budget.records_per_sec` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_bytes` | `3892209907` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_cap_bytes` | `4294967296` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_utilization_pct` | `90.623` |
| `treedb.cache.vlog_generation.rewrite_trigger.churn_per_sec` | `0` |
| `treedb.cache.vlog_generation.rewrite_trigger.stale_ratio_ppm` | `200000` |
| `treedb.cache.vlog_generation.rewrite_trigger.total_bytes` | `4294967296` |
| `treedb.cache.vlog_generation.scheduler_last_reason` | `periodic_gc` |
| `treedb.cache.vlog_generation.scheduler_state` | `idle` |
| `treedb.cache.vlog_generation.segments.cold` | `0` |
| `treedb.cache.vlog_generation.segments.hot` | `7` |
| `treedb.cache.vlog_generation.segments.total` | `7` |
| `treedb.cache.vlog_generation.segments.warm` | `0` |
| `treedb.cache.vlog_generation.vacuum.exec.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.exec.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.exec.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.failures` | `0` |
| `treedb.cache.vlog_generation.vacuum.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.vacuum.runs` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_cooldown` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_disabled` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_rewrite_bytes` | `0` |
| `treedb.cache.vlog_generation.warm.segment_target_bytes` | `268435456` |
| `treedb.cache.vlog_grouped_frame_cache.allocated_shards` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.allocated_slots` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.budget_bytes` | `67108864` |
| `treedb.cache.vlog_grouped_frame_cache.capacity` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.entries` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.evictions` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.hits` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.misses` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.releases` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.retained_bytes` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_budget` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_contention` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_disabled` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_oversize` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.stores` | `0` |
| `treedb.cache.vlog_io.bytes` | `0` |
| `treedb.cache.vlog_io.syscalls` | `0` |
| `treedb.cache.vlog_mmap.active_bytes` | `0` |
| `treedb.cache.vlog_mmap.active_segments` | `0` |
| `treedb.cache.vlog_mmap.current_bytes` | `0` |
| `treedb.cache.vlog_mmap.current_segments` | `0` |
| `treedb.cache.vlog_mmap.current_writable_map_target_bytes` | `33554432` |
| `treedb.cache.vlog_mmap.dead_bytes` | `0` |
| `treedb.cache.vlog_mmap.dead_mappings` | `0` |
| `treedb.cache.vlog_mmap.dead_mappings.cap_base` | `64` |
| `treedb.cache.vlog_mmap.max_mapped_leaf_sealed_bytes` | `1610612736` |
| `treedb.cache.vlog_mmap.max_mapped_leaf_sealed_segments` | `512` |
| `treedb.cache.vlog_mmap.max_mapped_sealed_bytes` | `67108864` |
| `treedb.cache.vlog_mmap.max_mapped_sealed_segments` | `8` |
| `treedb.cache.vlog_mmap.read.fallback_readat` | `0` |
| `treedb.cache.vlog_mmap.read.hits` | `0` |
| `treedb.cache.vlog_mmap.read.miss_dead_mapping_cap` | `0` |
| `treedb.cache.vlog_mmap.read.miss_no_mapping` | `0` |
| `treedb.cache.vlog_mmap.read.miss_out_of_range` | `0` |
| `treedb.cache.vlog_mmap.remaps` | `0` |
| `treedb.cache.vlog_mmap.sealed_bytes` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied.bytes_cap` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied.count_cap` | `0` |
| `treedb.cache.vlog_mmap.sealed_segments` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.legacy_page` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.unknown` | `67514` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.legacy_page` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.unknown` | `392490158` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.legacy_page` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.unknown` | `43223728` |
| `treedb.cache.vlog_outer_leaf_codec.stored_ratio.unknown` | `0.110127` |
| `treedb.cache.vlog_payload_kind.frames.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.frames.outer_leaf` | `67514` |
| `treedb.cache.vlog_payload_kind.frames.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.raw_bytes.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.raw_bytes.outer_leaf` | `392490158` |
| `treedb.cache.vlog_payload_kind.raw_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.stored_bytes.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.stored_bytes.outer_leaf` | `43223728` |
| `treedb.cache.vlog_payload_kind.stored_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.stored_ratio.outer_leaf` | `0.110127` |
| `treedb.cache.vlog_payload_split.frames.outer_leaf` | `67514` |
| `treedb.cache.vlog_payload_split.raw_bytes.outer_leaf` | `392490158` |
| `treedb.cache.vlog_payload_split.raw_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_split.records.outer_leaf` | `112576` |
| `treedb.cache.vlog_payload_split.records.single_value` | `0` |
| `treedb.cache.vlog_payload_split.stored_bytes.outer_leaf` | `43223728` |
| `treedb.cache.vlog_payload_split.stored_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_split.stored_ratio.outer_leaf` | `0.110127` |
| `treedb.cache.vlog_read.crc32_checks_total` | `0` |
| `treedb.cache.vlog_retained_bytes_estimate` | `47005144` |
| `treedb.cache.vlog_retained_prune.active` | `false` |
| `treedb.cache.vlog_retained_prune.budget_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.candidate_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.candidate_segments` | `0` |
| `treedb.cache.vlog_retained_prune.close_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.closed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.completed_runs` | `0` |
| `treedb.cache.vlog_retained_prune.error_runs` | `0` |
| `treedb.cache.vlog_retained_prune.force_pending` | `false` |
| `treedb.cache.vlog_retained_prune.forced_runs` | `0` |
| `treedb.cache.vlog_retained_prune.foreground_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.full_live_id_scan_runs` | `0` |
| `treedb.cache.vlog_retained_prune.in_use_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.in_use_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.inflight` | `false` |
| `treedb.cache.vlog_retained_prune.last_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.last_force` | `false` |
| `treedb.cache.vlog_retained_prune.last_mode` | `none` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_candidate` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_in_use_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_live_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_parse_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_removed` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_zombie_marked` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_candidate` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_in_use_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_live_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_parse_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_removed` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_zombie_marked` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.nested_value_pointers` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.outer_leaf_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.outer_leaf_records` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.records` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.value_pointer_records` | `0` |
| `treedb.cache.vlog_retained_prune.last_start_unix_nano` | `0` |
| `treedb.cache.vlog_retained_prune.last_status` | `none` |
| `treedb.cache.vlog_retained_prune.last_unix_nano` | `0` |
| `treedb.cache.vlog_retained_prune.live_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.live_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.max_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.no_candidate_runs` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_candidate_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_in_use_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_live_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_parse_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_removed_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_zombie_marked_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_candidate_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_in_use_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_live_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_parse_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_removed_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_zombie_marked_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source_fast_path_runs` | `0` |
| `treedb.cache.vlog_retained_prune.parse_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.parse_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.pressure_bytes` | `17179869164` |
| `treedb.cache.vlog_retained_prune.removed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.removed_segments` | `0` |
| `treedb.cache.vlog_retained_prune.runs` | `0` |
| `treedb.cache.vlog_retained_prune.scan.nested_value_pointers_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.outer_leaf_bytes_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.outer_leaf_records_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.records_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.value_pointer_records_total` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_forced_requests` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_requests` | `23` |
| `treedb.cache.vlog_retained_prune.schedule_skip.below_pressure` | `23` |
| `treedb.cache.vlog_retained_prune.schedule_skip.closing` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.inflight` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.min_interval` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.no_closed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.total_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.write_gate_retries` | `0` |
| `treedb.cache.vlog_retained_prune.write_gate_retry_successes` | `0` |
| `treedb.cache.vlog_retained_prune.zombie_marked_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.zombie_marked_segments` | `0` |
| `treedb.cache.vlog_retained_segments` | `7` |
| `treedb.cache.vlog_template_def_cache.hits` | `0` |
| `treedb.cache.vlog_template_def_cache.misses` | `0` |
| `treedb.cache.vlog_write.bytes` | `0` |
| `treedb.cache.vlog_write.calls` | `0` |
| `treedb.cache.vlog_write.syscalls` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.frames.block` | `67514` |
| `treedb.cache.vlog_write_mode.frames.dict` | `0` |
| `treedb.cache.vlog_write_mode.frames.off` | `0` |
| `treedb.cache.vlog_write_mode.raw_bytes.block` | `392490158` |
| `treedb.cache.vlog_write_mode.raw_bytes.dict` | `0` |
| `treedb.cache.vlog_write_mode.raw_bytes.off` | `0` |
| `treedb.cache.vlog_write_mode.stored_bytes.block` | `43223728` |
| `treedb.cache.vlog_write_mode.stored_bytes.dict` | `0` |
| `treedb.cache.vlog_write_mode.stored_bytes.off` | `0` |
| `treedb.cache.vlog_write_mode.stored_ratio.block` | `0.110127` |
| `treedb.cache.vlog_writer_append_buf.alloc_calls_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.allocated_bytes_total` | `29360128` |
| `treedb.cache.vlog_writer_append_buf.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.drops_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.gets_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.hits_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.misses_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.pool.entries` | `0` |
| `treedb.cache.vlog_writer_append_buf.pool.max_entries` | `16` |
| `treedb.cache.vlog_writer_append_buf.pool.retained_buffers` | `0` |
| `treedb.cache.vlog_writer_append_buf.pool.retained_bytes` | `0` |
| `treedb.cache.vlog_writer_append_buf.puts_total` | `0` |
| `treedb.cache.vlog_writev.bytes` | `0` |
| `treedb.cache.vlog_writev.flushes` | `0` |
| `treedb.cache.vlog_writev.iovecs` | `0` |
| `treedb.cache.vlog_writev.syscalls` | `0` |
| `treedb.cache.vlog_zombie.bytes` | `0` |
| `treedb.cache.vlog_zombie.pinned_bytes` | `0` |
| `treedb.cache.vlog_zombie.pinned_segments` | `0` |
| `treedb.cache.vlog_zombie.segments` | `0` |
| `treedb.cache.vlog_zombie.unpinned_bytes` | `0` |
| `treedb.cache.vlog_zombie.unpinned_segments` | `0` |
| `treedb.cache.write.wait_for_checkpoint.count_total` | `0` |
| `treedb.cache.write.wait_for_checkpoint.ns_total` | `0` |
| `treedb.command_wal.active_segment.name` | `` |
| `treedb.command_wal.active_segments` | `0` |
| `treedb.command_wal.append.count_total` | `1002100` |
| `treedb.command_wal.append.entry_scan.count_total` | `50` |
| `treedb.command_wal.append.entry_scan.ns_total` | `1152271622` |
| `treedb.command_wal.append.intent.count_total` | `0` |
| `treedb.command_wal.append.intent.ns_total` | `0` |
| `treedb.command_wal.append.ns_total` | `4534610255` |
| `treedb.command_wal.append.payload.count_total` | `2050` |
| `treedb.command_wal.append.payload.ns_total` | `1210219629` |
| `treedb.command_wal.append.point.count_total` | `1000000` |
| `treedb.command_wal.append.point.ns_total` | `2172119004` |
| `treedb.command_wal.applied_lsn` | `1002100` |
| `treedb.command_wal.bytes` | `0` |
| `treedb.command_wal.bytes.active` | `0` |
| `treedb.command_wal.bytes.total` | `0` |
| `treedb.command_wal.cleanup.covered_bytes_total` | `1129235456` |
| `treedb.command_wal.cleanup.covered_segments_total` | `94` |
| `treedb.command_wal.cleanup.namespace_sync.calls_total` | `10` |
| `treedb.command_wal.cleanup.namespace_sync.errors_total` | `0` |
| `treedb.command_wal.cleanup.namespace_sync.pending` | `false` |
| `treedb.command_wal.cleanup.ns_total` | `4704156269` |
| `treedb.command_wal.cleanup.oldest_pinned_lsn` | `0` |
| `treedb.command_wal.cleanup.proof.capture_epoch` | `1002154` |
| `treedb.command_wal.cleanup.proof.count_total` | `51` |
| `treedb.command_wal.cleanup.proof.durable_wal_lsn` | `1002100` |
| `treedb.command_wal.cleanup.proof.frontier_lsn` | `1002100` |
| `treedb.command_wal.cleanup.proof.namespace_generation` | `54` |
| `treedb.command_wal.cleanup.proof.ns_total` | `234384` |
| `treedb.command_wal.cleanup.proof.older_root_commit_seq` | `23` |
| `treedb.command_wal.cleanup.proof.selected_root_commit_seq` | `24` |
| `treedb.command_wal.cleanup.removed_bytes` | `915064832` |
| `treedb.command_wal.cleanup.removed_bytes_total` | `915064832` |
| `treedb.command_wal.cleanup.removed_segments` | `43` |
| `treedb.command_wal.cleanup.removed_segments_total` | `43` |
| `treedb.command_wal.cleanup.retained.reason.active_segments_total` | `51` |
| `treedb.command_wal.cleanup.retained.reason.error_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.pinned_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.uncovered_segments_total` | `91` |
| `treedb.command_wal.cleanup.retained_bytes_total` | `2174400512` |
| `treedb.command_wal.cleanup.retained_segments_total` | `142` |
| `treedb.command_wal.cleanup.retries_total` | `0` |
| `treedb.command_wal.cleanup.scan.count_total` | `51` |
| `treedb.command_wal.cleanup.scan.ns_total` | `4558569670` |
| `treedb.command_wal.cleanup.scanned_bytes_total` | `1099541800` |
| `treedb.command_wal.cleanup.scanned_frames_total` | `3206300` |
| `treedb.command_wal.cleanup.scans` | `51` |
| `treedb.command_wal.cleanup.unlinked_sync_pending_bytes` | `0` |
| `treedb.command_wal.cleanup.unlinked_sync_pending_segments` | `0` |
| `treedb.command_wal.dependency_debt.entries` | `0` |
| `treedb.command_wal.dependency_debt.max_age_ns` | `0` |
| `treedb.command_wal.dependency_debt.pending_bytes` | `0` |
| `treedb.command_wal.dependency_debt.pending_count` | `0` |
| `treedb.command_wal.dependency_debt.retries_total` | `0` |
| `treedb.command_wal.directory_sync.calls_total` | `11` |
| `treedb.command_wal.directory_sync.errors_total` | `0` |
| `treedb.command_wal.directory_sync.ns_total` | `70889306` |
| `treedb.command_wal.durable_wal_lsn` | `1002100` |
| `treedb.command_wal.enabled` | `true` |
| `treedb.command_wal.file_sync.calls_total` | `30` |
| `treedb.command_wal.file_sync.errors_total` | `0` |
| `treedb.command_wal.file_sync.ns_total` | `102807138` |
| `treedb.command_wal.flush.barrier.count_total` | `0` |
| `treedb.command_wal.flush.barrier.ns_total` | `0` |
| `treedb.command_wal.flush.count_total` | `1002100` |
| `treedb.command_wal.flush.entry_scan.count_total` | `50` |
| `treedb.command_wal.flush.entry_scan.ns_total` | `21772168` |
| `treedb.command_wal.flush.intent.count_total` | `0` |
| `treedb.command_wal.flush.intent.ns_total` | `0` |
| `treedb.command_wal.flush.ns_total` | `1339293895` |
| `treedb.command_wal.flush.payload.count_total` | `2050` |
| `treedb.command_wal.flush.payload.ns_total` | `30181147` |
| `treedb.command_wal.flush.point.count_total` | `1000000` |
| `treedb.command_wal.flush.point.ns_total` | `1287340580` |
| `treedb.command_wal.frames` | `1002100` |
| `treedb.command_wal.group_commit.attempts_total` | `0` |
| `treedb.command_wal.group_commit.bypass.reason.relaxed_race_no_group_total` | `0` |
| `treedb.command_wal.group_commit.bypass.reason.solo_durable_sync_total` | `0` |
| `treedb.command_wal.group_commit.bypasses_total` | `0` |
| `treedb.command_wal.group_commit.commits_total` | `0` |
| `treedb.command_wal.group_commit.dependency_entries_attempted_total` | `0` |
| `treedb.command_wal.group_commit.dependency_entries_covered_max` | `0` |
| `treedb.command_wal.group_commit.dependency_entries_covered_total` | `0` |
| `treedb.command_wal.group_commit.errors_total` | `0` |
| `treedb.command_wal.group_commit.fallback.reason.coordinator_unavailable_total` | `0` |
| `treedb.command_wal.group_commit.fallbacks_total` | `0` |
| `treedb.command_wal.group_commit.followers_total` | `0` |
| `treedb.command_wal.group_commit.forced_total` | `0` |
| `treedb.command_wal.group_commit.group_size_max` | `0` |
| `treedb.command_wal.group_commit.groups_total` | `0` |
| `treedb.command_wal.group_commit.leaders_total` | `0` |
| `treedb.command_wal.group_commit.participants_total` | `0` |
| `treedb.command_wal.group_commit.syncs_total` | `0` |
| `treedb.command_wal.group_commit.trigger.byte_limit_total` | `0` |
| `treedb.command_wal.group_commit.trigger.commit_limit_total` | `0` |
| `treedb.command_wal.group_commit.trigger.explicit_sync_total` | `0` |
| `treedb.command_wal.group_commit.trigger.sealed_collection_total` | `0` |
| `treedb.command_wal.group_commit.trigger.timeout_total` | `0` |
| `treedb.command_wal.group_commit.wait_ns_max` | `0` |
| `treedb.command_wal.group_commit.wait_ns_total` | `0` |
| `treedb.command_wal.live_accepted_frames` | `1002100` |
| `treedb.command_wal.live_accepted_max_lsn` | `1002100` |
| `treedb.command_wal.live_covered_frames` | `1002100` |
| `treedb.command_wal.live_covered_max_lsn` | `1002100` |
| `treedb.command_wal.live_frames` | `1002100` |
| `treedb.command_wal.live_max_lsn` | `0` |
| `treedb.command_wal.max_lsn` | `1002100` |
| `treedb.command_wal.next_lsn` | `1002101` |
| `treedb.command_wal.public_batch.delete.bytes_total` | `1600000` |
| `treedb.command_wal.public_batch.delete.calls_total` | `200000` |
| `treedb.command_wal.public_batch.delete_view.bytes_total` | `0` |
| `treedb.command_wal.public_batch.delete_view.calls_total` | `0` |
| `treedb.command_wal.public_batch.set.bytes_total` | `54400000` |
| `treedb.command_wal.public_batch.set.calls_total` | `400000` |
| `treedb.command_wal.public_batch.set_view.bytes_total` | `54400000` |
| `treedb.command_wal.public_batch.set_view.calls_total` | `400000` |
| `treedb.command_wal.required_feature` | `true` |
| `treedb.command_wal.segment_files` | `0` |
| `treedb.command_wal.segments.active` | `0` |
| `treedb.command_wal.segments.total` | `0` |
| `treedb.command_wal.stats_scan` | `false` |
| `treedb.command_wal.sync.barrier.count_total` | `20` |
| `treedb.command_wal.sync.barrier.ns_total` | `17341464` |
| `treedb.command_wal.sync.count_total` | `20` |
| `treedb.command_wal.sync.entry_scan.count_total` | `0` |
| `treedb.command_wal.sync.entry_scan.ns_total` | `0` |
| `treedb.command_wal.sync.intent.count_total` | `0` |
| `treedb.command_wal.sync.intent.ns_total` | `0` |
| `treedb.command_wal.sync.ns_total` | `17341464` |
| `treedb.command_wal.sync.payload.count_total` | `0` |
| `treedb.command_wal.sync.payload.ns_total` | `0` |
| `treedb.command_wal.sync.point.count_total` | `0` |
| `treedb.command_wal.sync.point.ns_total` | `0` |
| `treedb.command_wal.typed_segments` | `0` |
| `treedb.command_wal.write.bytes_total` | `576063584` |
| `treedb.command_wal.write.errors_total` | `0` |
| `treedb.command_wal.write.ns_total` | `777855681` |
| `treedb.command_wal.write.syscalls_total` | `1002100` |
| `treedb.command_wal.writer.buffer_size_bytes` | `16777216` |
| `treedb.command_wal.writer.buffered_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.capacity_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.dropped_bytes_total` | `0` |
| `treedb.command_wal.writer.command_buffer.length_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.limit_bytes` | `67108864` |
| `treedb.command_wal.writer.command_buffer.retain_limit_bytes` | `4194304` |
| `treedb.command_wal.writer.command_buffer.trim_count` | `0` |
| `treedb.command_wal.writer.container` | `fixed` |
| `treedb.command_wal.writer.container_reason` | `persistent_or_unknown_filesystem` |
| `treedb.command_wal.writer.filesystem_type` | `61267` |
| `treedb.command_wal.writer.memory_filesystem` | `false` |
| `treedb.command_wal.writer.path` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/tmp/bench-treedb2929660301/maindb/wal/commit-l0-000044.log` |
| `treedb.command_wal.writer.pending_batch.capacity_bytes` | `0` |
| `treedb.command_wal.writer.pending_batch.length_bytes` | `0` |
| `treedb.command_wal.writer.scratch_capacity_bytes` | `1224320` |
| `treedb.commit_seq` | `24` |
| `treedb.durability_mode` | `wal_on_relaxed_sync` |
| `treedb.flush_admission.admitted` | `true` |
| `treedb.flush_admission.flush_apply_concurrency` | `6` |
| `treedb.flush_admission.flush_apply_concurrency_cap_reason` | `default_physical_cores` |
| `treedb.flush_admission.flush_apply_concurrency_configured` | `0` |
| `treedb.flush_admission.flush_apply_concurrency_defaulted` | `true` |
| `treedb.flush_admission.flush_apply_span_native` | `true` |
| `treedb.flush_admission.flush_backlog_coalescing` | `true` |
| `treedb.flush_admission.gomaxprocs` | `12` |
| `treedb.flush_admission.leaf_page_read_cache_write_admission` | `adaptive` |
| `treedb.flush_admission.physical_cores` | `6` |
| `treedb.flush_admission.policy` | `auto` |
| `treedb.flush_admission.reason` | `auto_admitted_hardware_aware` |
| `treedb.flush_apply.apply_calls_total` | `110` |
| `treedb.flush_apply.apply_errors_total` | `0` |
| `treedb.flush_apply.apply_ns_total` | `582578478` |
| `treedb.flush_apply.apply_ops_total` | `1833475` |
| `treedb.flush_apply.commit_wait_ns_total` | `0` |
| `treedb.flush_apply.guarded_publish.calls_total` | `0` |
| `treedb.flush_apply.guarded_publish.ns_per_op` | `0.000000` |
| `treedb.flush_apply.guarded_publish.ns_total` | `0` |
| `treedb.flush_apply.leaf_log_output.append_calls_total` | `64145` |
| `treedb.flush_apply.leaf_log_output.append_pages_total` | `112576` |
| `treedb.flush_apply.leaf_log_output.append_wait_ns_total` | `566374600` |
| `treedb.flush_apply.leaf_log_output.lane.01.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.02.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.03.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.04.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.05.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.06.tasks_total` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_lanes_used` | `6` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_max` | `66` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_overflow_total` | `0` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_total` | `396` |
| `treedb.flush_apply.leaf_log_output.reservation_wait_ns_total` | `8023049` |
| `treedb.flush_apply.merge_build.internal_child_refs_total` | `139565` |
| `treedb.flush_apply.merge_build.internal_merges_total` | `130` |
| `treedb.flush_apply.merge_build.internal_page_bytes_written_total` | `6053888` |
| `treedb.flush_apply.merge_build.internal_pages_written_total` | `1478` |
| `treedb.flush_apply.merge_build.internal_parallel_children_total` | `114` |
| `treedb.flush_apply.merge_build.internal_parallel_merges_total` | `8` |
| `treedb.flush_apply.merge_build.internal_parallel_ops_total` | `252824` |
| `treedb.flush_apply.merge_build.internal_parallel_workers_total` | `48` |
| `treedb.flush_apply.merge_build.leaf_log_page_bytes_written_total` | `461111296` |
| `treedb.flush_apply.merge_build.leaf_log_pages_written_total` | `112576` |
| `treedb.flush_apply.merge_build.leaf_log_record_hint_bytes_written_total` | `162275382` |
| `treedb.flush_apply.merge_build.leaf_merges_per_op` | `0.034957` |
| `treedb.flush_apply.merge_build.leaf_merges_total` | `64093` |
| `treedb.flush_apply.merge_build.leaf_page_bytes_written_total` | `461111296` |
| `treedb.flush_apply.merge_build.leaf_pages_written_total` | `112576` |
| `treedb.flush_apply.merge_build.pager_leaf_page_bytes_written_total` | `0` |
| `treedb.flush_apply.merge_build.pager_leaf_pages_written_total` | `0` |
| `treedb.flush_apply.merge_build.replacement_leaf_pages_per_op` | `0.061400` |
| `treedb.flush_apply.merge_build.replacement_leaf_pages_total` | `112576` |
| `treedb.flush_apply.mismatch_total` | `0` |
| `treedb.flush_apply.old_leaf_read_decode.bytes_per_op` | `149.379259` |
| `treedb.flush_apply.old_leaf_read_decode.bytes_total` | `273883136` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_bytes_total` | `270368768` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_cache_hits_total` | `17689` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_node_loads_total` | `66008` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_reader_calls_total` | `48319` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_record_hint_bytes_total` | `107586073` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_scratch_reads_total` | `48319` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_view_reads_total` | `0` |
| `treedb.flush_apply.old_leaf_read_decode.node_loads_total` | `66866` |
| `treedb.flush_apply.old_leaf_read_decode.pager_bytes_total` | `3514368` |
| `treedb.flush_apply.old_leaf_read_decode.pager_node_loads_total` | `858` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_installed_total` | `461111296` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_prepared_total` | `461111296` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_installed_total` | `112576` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_prepared_total` | `112576` |
| `treedb.flush_apply.prepared_output.retired_pages_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.retired_pages_installed_total` | `858` |
| `treedb.flush_apply.prepared_output.retired_pages_prepared_total` | `858` |
| `treedb.flush_apply.publish_final_install.calls_total` | `0` |
| `treedb.flush_apply.publish_final_install.ns_per_op` | `0.000000` |
| `treedb.flush_apply.publish_final_install.ns_total` | `0` |
| `treedb.flush_apply.publish_prepare.calls_total` | `22` |
| `treedb.flush_apply.publish_prepare.errors_total` | `0` |
| `treedb.flush_apply.publish_prepare.ns_per_op` | `7.623257` |
| `treedb.flush_apply.publish_prepare.ns_total` | `13977051` |
| `treedb.flush_apply.publish_total.ns_per_op` | `7.623257` |
| `treedb.flush_apply.publish_total.ns_total` | `13977051` |
| `treedb.flush_apply.read_only_prepare.calls_total` | `110` |
| `treedb.flush_apply.read_only_prepare.errors_total` | `0` |
| `treedb.flush_apply.read_only_prepare.ns_total` | `72609280` |
| `treedb.flush_apply.read_only_prepare.requested_workers_max` | `6` |
| `treedb.flush_apply.read_only_prepare.requested_workers_total` | `660` |
| `treedb.flush_apply.read_only_prepare.single_op_spans_max` | `1180` |
| `treedb.flush_apply.read_only_prepare.single_op_spans_total` | `3967` |
| `treedb.flush_apply.read_only_prepare.span_bytes_max` | `2621440` |
| `treedb.flush_apply.read_only_prepare.span_bytes_total` | `226591128` |
| `treedb.flush_apply.read_only_prepare.span_ops_max` | `31608` |
| `treedb.flush_apply.read_only_prepare.span_ops_total` | `1833475` |
| `treedb.flush_apply.read_only_prepare.spans_max` | `5857` |
| `treedb.flush_apply.read_only_prepare.spans_total` | `64093` |
| `treedb.flush_apply.read_only_prepare.validation_failures_total` | `0` |
| `treedb.flush_apply.read_only_prepare.worker_ranges_max` | `6` |
| `treedb.flush_apply.read_only_prepare.worker_ranges_total` | `480` |
| `treedb.flush_apply.reducer_publish.ns_per_op` | `9.504335` |
| `treedb.flush_apply.reducer_publish.ns_total` | `17425960` |
| `treedb.flush_apply.retry_total` | `0` |
| `treedb.flush_apply.root_reduce.ns_per_op` | `9.504335` |
| `treedb.flush_apply.root_reduce.ns_total` | `17425960` |
| `treedb.flush_apply.root_reduce.split_levels_total` | `3` |
| `treedb.flush_apply.span_native.candidate_ops_total` | `1833475` |
| `treedb.flush_apply.span_native.candidate_spans_total` | `64093` |
| `treedb.flush_apply.span_native.eligible_ops_total` | `1580651` |
| `treedb.flush_apply.span_native.eligible_spans_total` | `49800` |
| `treedb.flush_apply.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.maintenance.ops_total` | `252824` |
| `treedb.flush_apply.span_native.fallback.reason.maintenance.spans_total` | `14293` |
| `treedb.flush_apply.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallbacks_total` | `8` |
| `treedb.flush_apply.span_native.ineligible_ops_total` | `252824` |
| `treedb.flush_apply.span_native.ineligible_spans_total` | `14293` |
| `treedb.flush_apply.span_native.reducer_validation_guard.active` | `false` |
| `treedb.flush_apply.span_native.reducer_validation_guard.trips_total` | `0` |
| `treedb.flush_apply.span_native.scheduler.completed_tasks_total` | `432` |
| `treedb.flush_apply.span_native.scheduler.dispatched_tasks_total` | `432` |
| `treedb.flush_apply.span_native.scheduler.queue_depth_max` | `6` |
| `treedb.flush_apply.span_native.scheduler.ready_tasks_total` | `432` |
| `treedb.flush_apply.span_native.scheduler.scheduled_workers_max` | `6` |
| `treedb.flush_apply.span_native.scheduler.scheduled_workers_total` | `432` |
| `treedb.flush_apply.span_native.scheduler.single_span_tasks_total` | `41` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_max` | `2621440` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_min` | `272` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_per_task` | `519834.574074` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_total` | `224568536` |
| `treedb.flush_apply.span_native.scheduler.task_ops_max` | `16384` |
| `treedb.flush_apply.span_native.scheduler.task_ops_min` | `2` |
| `treedb.flush_apply.span_native.scheduler.task_ops_per_task` | `3658.914352` |
| `treedb.flush_apply.span_native.scheduler.task_ops_total` | `1580651` |
| `treedb.flush_apply.span_native.scheduler.task_spans_max` | `996` |
| `treedb.flush_apply.span_native.scheduler.task_spans_min` | `1` |
| `treedb.flush_apply.span_native.scheduler.task_spans_per_task` | `115.277778` |
| `treedb.flush_apply.span_native.scheduler.task_spans_total` | `49800` |
| `treedb.flush_apply.span_native.scheduler.worker_busy_ns_total` | `1586087064` |
| `treedb.flush_apply.span_native.scheduler.worker_idle_ns_total` | `422590396` |
| `treedb.flush_apply.span_native.scheduler.worker_wait_ns_total` | `465182405` |
| `treedb.flush_apply.span_native.used_ops_total` | `1580651` |
| `treedb.flush_apply.span_native.used_spans_total` | `49800` |
| `treedb.flush_apply.span_run.bytes_per_span` | `3535.349071` |
| `treedb.flush_apply.span_run.ops_per_span` | `28.606478` |
| `treedb.flush_apply.span_run.single_op_spans_total` | `3967` |
| `treedb.flush_apply.span_run.span_bytes_total` | `226591128` |
| `treedb.flush_apply.span_run.span_ops_total` | `1833475` |
| `treedb.flush_apply.span_run.target_leaf_spans_total` | `64093` |
| `treedb.leaf_generation.bytes.deleted` | `0` |
| `treedb.leaf_generation.bytes.retained` | `41670166` |
| `treedb.leaf_generation.bytes.retiring` | `0` |
| `treedb.leaf_generation.bytes.sealed` | `41670166` |
| `treedb.leaf_generation.bytes.total` | `47005144` |
| `treedb.leaf_generation.bytes.writable` | `5334978` |
| `treedb.leaf_generation.current.bytes` | `5334978` |
| `treedb.leaf_generation.current.files` | `1` |
| `treedb.leaf_generation.current_generation_id` | `7` |
| `treedb.leaf_generation.enabled` | `true` |
| `treedb.leaf_generation.files.deleted` | `0` |
| `treedb.leaf_generation.files.retained` | `6` |
| `treedb.leaf_generation.files.retiring` | `0` |
| `treedb.leaf_generation.files.sealed` | `6` |
| `treedb.leaf_generation.files.total` | `7` |
| `treedb.leaf_generation.files.writable` | `1` |
| `treedb.leaf_generation.generations.deleted` | `0` |
| `treedb.leaf_generation.generations.pinned` | `0` |
| `treedb.leaf_generation.generations.retained` | `6` |
| `treedb.leaf_generation.generations.retiring` | `0` |
| `treedb.leaf_generation.generations.sealed` | `6` |
| `treedb.leaf_generation.generations.total` | `7` |
| `treedb.leaf_generation.generations.writable` | `1` |
| `treedb.leaf_generation.pins.total` | `0` |
| `treedb.leaf_generation.plan_cache.subtree_pages` | `0` |
| `treedb.process.append_only.entry_hint_capacity_bytes` | `1228128` |
| `treedb.process.append_only.entry_hint_entries` | `12793` |
| `treedb.process.append_only.entry_pool_admission_drop_bytes_total` | `0` |
| `treedb.process.append_only.entry_pool_admission_drops_total` | `0` |
| `treedb.process.append_only.entry_pool_drop_bytes_total` | `0` |
| `treedb.process.append_only.entry_pool_drops_total` | `0` |
| `treedb.process.append_only.entry_pool_gets_total` | `682` |
| `treedb.process.append_only.entry_pool_puts_total` | `828` |
| `treedb.process.append_only.entry_pool_retained_bytes_estimate` | `97168104` |
| `treedb.process.append_only.entry_pool_retained_bytes_max_estimate` | `97168104` |
| `treedb.process.append_only.mem_lease_count` | `8` |
| `treedb.process.append_only.mem_lease_entry_backing_bytes` | `0` |
| `treedb.process.append_only.mem_lease_entry_capacity` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_active_bytes` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_active_chunks` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_retained_bytes` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_retained_chunks` | `0` |
| `treedb.process.append_only.mutable_count` | `16` |
| `treedb.process.append_only.mutable_entry_backing_bytes` | `0` |
| `treedb.process.append_only.mutable_entry_capacity` | `0` |
| `treedb.process.append_only.mutable_from_lease_total` | `88` |
| `treedb.process.append_only.mutable_from_pool_total` | `0` |
| `treedb.process.append_only.mutable_new_alloc_queue_bytes_sum` | `1412615048` |
| `treedb.process.append_only.mutable_new_alloc_total` | `88` |
| `treedb.process.append_only.mutable_new_alloc_with_queue_total` | `88` |
| `treedb.process.append_only.mutable_pool_drops_total` | `0` |
| `treedb.process.append_only.mutable_pool_entry_backing_dropped_bytes_total` | `2610784` |
| `treedb.process.append_only.mutable_pool_puts_total` | `80` |
| `treedb.process.append_only.mutable_sparse_trim_dropped_bytes_total` | `0` |
| `treedb.process.append_only.mutable_sparse_trim_total` | `0` |
| `treedb.process.append_only.mutable_trim_dropped_bytes_total` | `21605760` |
| `treedb.process.append_only.mutable_trim_total` | `368` |
| `treedb.process.append_only.mutable_value_arena_active_bytes` | `0` |
| `treedb.process.append_only.mutable_value_arena_active_chunks` | `0` |
| `treedb.process.append_only.mutable_value_arena_retained_bytes` | `0` |
| `treedb.process.append_only.mutable_value_arena_retained_chunks` | `0` |
| `treedb.process.append_only.reserve.calls_total` | `432` |
| `treedb.process.append_only.reserve.entries_total` | `153761` |
| `treedb.process.append_only.reserve.grow_bytes_total` | `235158176` |
| `treedb.process.append_only.reserve.grow_calls_total` | `432` |
| `treedb.process.append_only.reserve.skipped_growth_allocs_total` | `83` |
| `treedb.process.append_only.reserve.skipped_growth_bytes_total` | `1576960` |
| `treedb.process.append_only.value_arena_pool_admission_drop_bytes_total` | `0` |
| `treedb.process.append_only.value_arena_pool_admission_drops_total` | `0` |
| `treedb.process.append_only.value_arena_pool_drop_bytes_total` | `0` |
| `treedb.process.append_only.value_arena_pool_drops_total` | `0` |
| `treedb.process.append_only.value_arena_pool_gets_total` | `0` |
| `treedb.process.append_only.value_arena_pool_puts_total` | `0` |
| `treedb.process.append_only.value_arena_pool_retained_bytes_estimate` | `0` |
| `treedb.process.append_only.value_arena_pool_retained_bytes_max_estimate` | `0` |
| `treedb.process.memory.gc_cpu_fraction` | `0.003229` |
| `treedb.process.memory.gomemlimit_bytes` | `9223372036854775807` |
| `treedb.process.memory.heap_alloc_bytes` | `341829728` |
| `treedb.process.memory.heap_idle_bytes` | `367173632` |
| `treedb.process.memory.heap_idle_unreleased_bytes` | `23871488` |
| `treedb.process.memory.heap_inuse_bytes` | `345563136` |
| `treedb.process.memory.heap_released_bytes` | `343302144` |
| `treedb.process.memory.heap_sys_bytes` | `712736768` |
| `treedb.process.memory.memtable_view_deferred_bytes_current` | `0` |
| `treedb.process.memory.memtable_view_deferred_bytes_max` | `0` |
| `treedb.process.memory.memtable_view_deferred_memtables_current` | `0` |
| `treedb.process.memory.memtable_view_deferred_memtables_max` | `0` |
| `treedb.process.memory.memtable_view_deferred_oldest_age_ms` | `0.000` |
| `treedb.process.memory.mutable_bytes` | `0` |
| `treedb.process.memory.next_gc_bytes` | `670589314` |
| `treedb.process.memory.non_heap_sys_bytes` | `30065080` |
| `treedb.process.memory.num_gc` | `78` |
| `treedb.process.memory.peak_heap_alloc_bytes` | `607276648` |
| `treedb.process.memory.peak_heap_inuse_bytes` | `611368960` |
| `treedb.process.memory.peak_rss_bytes` | `726745088` |
| `treedb.process.memory.peak_total_sys_bytes` | `742801848` |
| `treedb.process.memory.peak_vlog_mmap_active_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_active_segments` | `0` |
| `treedb.process.memory.peak_vlog_mmap_current_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_current_segments` | `0` |
| `treedb.process.memory.peak_vlog_mmap_sealed_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_sealed_segments` | `0` |
| `treedb.process.memory.pool_pressure_critical_samples_total` | `0` |
| `treedb.process.memory.pool_pressure_high_samples_total` | `0` |
| `treedb.process.memory.pool_pressure_level` | `normal` |
| `treedb.process.memory.pool_pressure_normal_samples_total` | `220` |
| `treedb.process.memory.pool_pressure_used_bytes` | `369434624` |
| `treedb.process.memory.queue_backlog_bytes` | `0` |
| `treedb.process.memory.rss_bytes` | `390782976` |
| `treedb.process.memory.rss_hwm_bytes` | `726745088` |
| `treedb.process.memory.rss_minus_heap_inuse_bytes` | `45219840` |
| `treedb.process.memory.rss_minus_total_sys_bytes` | `0` |
| `treedb.process.memory.stack_inuse_bytes` | `4489216` |
| `treedb.process.memory.stack_sys_bytes` | `4489216` |
| `treedb.process.memory.total_sys_bytes` | `742801848` |
| `treedb.process.memory.vlog_mmap_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_sealed_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_sealed_segments` | `0` |
| `treedb.process.memory.vlog_mmap_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_sealed_segments` | `0` |
| `treedb.process.memory.vlog_retained_bytes_estimate` | `47005144` |
| `treedb.process.memory.vlog_zombie_bytes_estimate` | `0` |
| `treedb.process.memory.vlog_zombie_pinned_bytes_estimate` | `0` |
| `treedb.process.memory.vlog_zombie_unpinned_bytes_estimate` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.count` | `16` |
| `treedb.process.memtable_residency.mutable.append_only.entries` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.btree.count` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entries` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.btree.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.count` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entries` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.count` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entries` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.total.count` | `16` |
| `treedb.process.memtable_residency.mutable.total.entries` | `0` |
| `treedb.process.memtable_residency.mutable.total.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.total.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.append_only.count` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entries` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.append_only.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.btree.count` | `0` |
| `treedb.process.memtable_residency.queue.btree.entries` | `0` |
| `treedb.process.memtable_residency.queue.btree.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.btree.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.count` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entries` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.count` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entries` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.total.count` | `0` |
| `treedb.process.memtable_residency.queue.total.entries` | `0` |
| `treedb.process.memtable_residency.queue.total.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.total.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_retained_chunks` | `0` |
| `treedb.process.read_path.backend_tree.get_append_inline_bytes_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_inline_hits_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_pointer_bytes_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_pointer_hits_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.calls_total` | `200` |
| `treedb.process.read_path.backend_tree.getmany.fallback_calls_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.grouped_calls_total` | `200` |
| `treedb.process.read_path.backend_tree.getmany.leaf_group_items_total` | `200000` |
| `treedb.process.read_path.backend_tree.getmany.leaf_groups_total` | `186707` |
| `treedb.process.read_path.backend_tree.getmany.leaf_loads_saved_total` | `13293` |
| `treedb.process.read_path.outer_leaf.bytes_total` | `21446787072` |
| `treedb.process.read_path.outer_leaf.cache.backing_bytes` | `33554432` |
| `treedb.process.read_path.outer_leaf.cache.buckets` | `2048` |
| `treedb.process.read_path.outer_leaf.cache.bytes` | `33554432` |
| `treedb.process.read_path.outer_leaf.cache.capacity` | `8192` |
| `treedb.process.read_path.outer_leaf.cache.capacity_evictions` | `370842` |
| `treedb.process.read_path.outer_leaf.cache.conflict_evictions` | `20927` |
| `treedb.process.read_path.outer_leaf.cache.cow_read_policy_bytes` | `196608` |
| `treedb.process.read_path.outer_leaf.cache.entries` | `8192` |
| `treedb.process.read_path.outer_leaf.cache.evictions` | `391769` |
| `treedb.process.read_path.outer_leaf.cache.hits` | `4442998` |
| `treedb.process.read_path.outer_leaf.cache.misses` | `871704` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_mark_misses` | `0` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_mark_unsafe_skips` | `0` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_unverified_hits` | `3000970` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_verified_hits` | `1442028` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_verified_marks` | `272109` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_candidate_skips` | `1` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_lock_skips` | `62` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_skips` | `584305` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_stores` | `287397` |
| `treedb.process.read_path.outer_leaf.cache.record_checksum_verified_stores` | `287397` |
| `treedb.process.read_path.outer_leaf.cache.stores` | `399961` |
| `treedb.process.read_path.outer_leaf.cache.ways` | `4` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_attempts` | `112576` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_lock_skips` | `12` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_policy` | `adaptive` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_skips` | `12` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_stores` | `112564` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_1024_hit_ratio` | `0.130542` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_1024_hits_total` | `10680` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_256_hit_ratio` | `0.034701` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_256_hits_total` | `2839` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_4096_hit_ratio` | `0.423576` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_4096_hits_total` | `34654` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_64_hit_ratio` | `0.008642` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_64_hits_total` | `707` |
| `treedb.process.read_path.outer_leaf.checksum.skips_total` | `1441628` |
| `treedb.process.read_path.outer_leaf.checksum.verifications_total` | `3794404` |
| `treedb.process.read_path.outer_leaf.iterator_loads_total` | `49325` |
| `treedb.process.read_path.outer_leaf.loads_total` | `5236032` |
| `treedb.process.read_path.outer_leaf.point_loads_total` | `5186707` |
| `treedb.process.read_path.outer_leaf.sample_mod` | `64` |
| `treedb.process.read_path.outer_leaf.samples_total` | `81813` |
| `treedb.profile.bench_unsafe` | `false` |
| `treedb.profile.resolved` | `command_wal_relaxed` |
| `treedb.publish.ordered_root_delta_group.avg_roots_per_call` | `0.000` |
| `treedb.publish.ordered_root_delta_group.calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.finalize_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.finalize_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.latency_max_ms` | `0.000` |
| `treedb.publish.ordered_root_delta_group.latency_p99_ms` | `0.000` |
| `treedb.publish.ordered_root_delta_group.preflight_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_child_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_leaf_log_ref_copies_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_leaf_log_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_page_child_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_children_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_workers_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_cache_hits_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_node_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_reader_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_record_hint_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_record_hint_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_scratch_reads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_view_reads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_leaf_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_leaf_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_node_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_parallel_groups_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_parallel_roots_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_requested_workers_max` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_requested_workers_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_span_bytes_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_span_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_validation_failures_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_worker_ranges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_root_split_levels_total` | `0` |
| `treedb.publish.ordered_root_delta_group.roots_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.fallback_reason` | `route_ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.fallback_reason` | `route_ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.fallback_reason` | `cold_build` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_build_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_hold_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_wait_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_wait_share_pct` | `0.000` |
| `treedb.publish.watermark.lag_drift_bytes_per_sec` | `0.000` |
| `treedb.publish.watermark.latency_p99_ms` | `0.000` |
| `treedb.publish.watermark.lock_delay_share_pct` | `0.000` |
| `treedb.raw.span_native.candidate_ops_total` | `1833475` |
| `treedb.raw.span_native.candidate_spans_total` | `0` |
| `treedb.raw.span_native.eligible_ops_total` | `1580651` |
| `treedb.raw.span_native.eligible_spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.maintenance.count_total` | `8` |
| `treedb.raw.span_native.fallback.reason.maintenance.ops_total` | `252824` |
| `treedb.raw.span_native.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.fallbacks_total` | `8` |
| `treedb.raw.span_native.ineligible_ops_total` | `252824` |
| `treedb.raw.span_native.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.public.command_wal_rejections_total` | `0` |
| `treedb.raw.span_native.public.route.update.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.public.route.update.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.public.route.update_sync.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.public.route.update_sync.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.observations_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.used_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.used_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.observations_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.used_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.used_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.observations_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.used_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.used_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.observations_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.candidate_ops_total` | `252824` |
| `treedb.raw.span_native.route.point_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.count_total` | `8` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.ops_total` | `252824` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallbacks_total` | `8` |
| `treedb.raw.span_native.route.point_delete.ineligible_ops_total` | `252824` |
| `treedb.raw.span_native.route.point_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.observations_total` | `8` |
| `treedb.raw.span_native.route.point_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.candidate_ops_total` | `1580651` |
| `treedb.raw.span_native.route.point_put.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.eligible_ops_total` | `1580651` |
| `treedb.raw.span_native.route.point_put.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.point_put.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.observations_total` | `102` |
| `treedb.raw.span_native.route.point_put.used_ops_total` | `1580651` |
| `treedb.raw.span_native.route.point_put.used_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.range_delete.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.observations_total` | `0` |
| `treedb.raw.span_native.route.range_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.used_ops_total` | `1580651` |
| `treedb.raw.span_native.used_spans_total` | `0` |
| `treedb.vlog.decode_buffer_grow.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.capacity_waste_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.copied_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_fit_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_fit_requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_present_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_current_mmap_direct_decode.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_current_mmap_direct_decode.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_fit_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_fit_requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_present_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_template_encoded_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_template_encoded_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.realloc_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.requested_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.file_stash.retain_max_bytes` | `131072` |
| `treedb.vlog.decode_scratch.file_stash.retained_buffers` | `21` |
| `treedb.vlog.decode_scratch.file_stash.retained_bytes` | `684626` |
| `treedb.vlog.decode_scratch.file_stash.retained_files` | `7` |
| `treedb.vlog.decode_scratch.file_stash.spare_max_count` | `2` |
| `treedb.vlog.decode_scratch.large_pool.alloc_calls_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.drops_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.entries` | `0` |
| `treedb.vlog.decode_scratch.large_pool.gets_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.hits_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.max_entries` | `8` |
| `treedb.vlog.decode_scratch.large_pool.misses_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.puts_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.retained_buffers` | `0` |
| `treedb.vlog.decode_scratch.large_pool.retained_bytes` | `0` |
| `treedb.vlog.decode_scratch.large_pool.too_small_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.alloc_calls_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.drops_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.alloc_calls_total` | `175` |
| `treedb.vlog.decode_scratch.small_pool.allocated_bytes_total` | `5417704` |
| `treedb.vlog.decode_scratch.small_pool.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.drops_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.entries` | `9` |
| `treedb.vlog.decode_scratch.small_pool.gets_total` | `139627` |
| `treedb.vlog.decode_scratch.small_pool.hits_total` | `139452` |
| `treedb.vlog.decode_scratch.small_pool.max_entries` | `128` |
| `treedb.vlog.decode_scratch.small_pool.misses_total` | `175` |
| `treedb.vlog.decode_scratch.small_pool.puts_total` | `139606` |
| `treedb.vlog.decode_scratch.small_pool.retained_buffers` | `9` |
| `treedb.vlog.decode_scratch.small_pool.retained_bytes` | `293426` |
| `treedb.vlog.decode_scratch.small_pool.too_small_total` | `145` |
| `treedb.vlog.grouped_frame_cache.allocated_shards` | `0` |
| `treedb.vlog.grouped_frame_cache.allocated_slots` | `0` |
| `treedb.vlog.grouped_frame_cache.budget_bytes` | `67108864` |
| `treedb.vlog.grouped_frame_cache.capacity` | `0` |
| `treedb.vlog.grouped_frame_cache.entries` | `0` |
| `treedb.vlog.grouped_frame_cache.evictions` | `0` |
| `treedb.vlog.grouped_frame_cache.hits` | `0` |
| `treedb.vlog.grouped_frame_cache.misses` | `0` |
| `treedb.vlog.grouped_frame_cache.releases` | `0` |
| `treedb.vlog.grouped_frame_cache.retained_bytes` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_budget` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_contention` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_disabled` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_oversize` | `0` |
| `treedb.vlog.grouped_frame_cache.stores` | `0` |
| `treedb.vlog.mmap_active_bytes` | `0` |
| `treedb.vlog.mmap_active_segments` | `0` |
| `treedb.vlog.mmap_current_bytes` | `0` |
| `treedb.vlog.mmap_current_segments` | `0` |
| `treedb.vlog.mmap_current_writable_map_target_bytes` | `33554432` |
| `treedb.vlog.mmap_dead_bytes` | `0` |
| `treedb.vlog.mmap_dead_mappings` | `0` |
| `treedb.vlog.mmap_dead_mappings.cap_base` | `64` |
| `treedb.vlog.mmap_max_mapped_leaf_sealed_bytes` | `1610612736` |
| `treedb.vlog.mmap_max_mapped_leaf_sealed_segments` | `512` |
| `treedb.vlog.mmap_max_mapped_sealed_bytes` | `67108864` |
| `treedb.vlog.mmap_max_mapped_sealed_segments` | `8` |
| `treedb.vlog.mmap_read.fallback_readat` | `2054829` |
| `treedb.vlog.mmap_read.hit_ratio` | `0.000000` |
| `treedb.vlog.mmap_read.hits` | `0` |
| `treedb.vlog.mmap_read.miss_dead_mapping_cap` | `0` |
| `treedb.vlog.mmap_read.miss_no_mapping` | `2054829` |
| `treedb.vlog.mmap_read.miss_out_of_range` | `0` |
| `treedb.vlog.mmap_remaps` | `0` |
| `treedb.vlog.mmap_sealed_bytes` | `0` |
| `treedb.vlog.mmap_sealed_map_denied` | `0` |
| `treedb.vlog.mmap_sealed_map_denied.bytes_cap` | `0` |
| `treedb.vlog.mmap_sealed_map_denied.count_cap` | `0` |
| `treedb.vlog.mmap_sealed_segments` | `0` |
| `treedb.vlog.read.crc32_checks_total` | `2054829` |
| `treedb.vlog.read_integrity` | `verify` |
| `treedb.vlog.template_def_cache.hits` | `0` |
| `treedb.vlog.template_def_cache.misses` | `0` |
| `treedb.vlog.writer_append_buf.alloc_calls_total` | `7` |
| `treedb.vlog.writer_append_buf.allocated_bytes_total` | `29360128` |
| `treedb.vlog.writer_append_buf.dropped_bytes_total` | `0` |
| `treedb.vlog.writer_append_buf.drops_total` | `0` |
| `treedb.vlog.writer_append_buf.gets_total` | `7` |
| `treedb.vlog.writer_append_buf.hits_total` | `0` |
| `treedb.vlog.writer_append_buf.misses_total` | `7` |
| `treedb.vlog.writer_append_buf.pool.entries` | `0` |
| `treedb.vlog.writer_append_buf.pool.max_entries` | `16` |
| `treedb.vlog.writer_append_buf.pool.retained_buffers` | `0` |
| `treedb.vlog.writer_append_buf.pool.retained_bytes` | `0` |
| `treedb.vlog.writer_append_buf.puts_total` | `0` |

## Key Insights

- TreeDB: prefix_scan is 1.45x faster than full_scan (3907378 vs 2701489 ops/s).
- treedb: shared hotspot "runtime.scanObject" (full 6.12% flat, prefix 10.00% flat).
- treedb: prefix_scan-specific hotspot "runtime.typePointers.next" (40.00% flat).
- treedb: full_scan-specific hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" (36.73% flat).
- block/batch_delete/treedb: contention hotspot "runtime.selectgo" (99.44% flat).
- block/batch_random/treedb: contention hotspot "runtime.selectgo" (74.60% flat).
- block/batch_small_seq/treedb: contention hotspot "runtime.selectgo" (73.28% flat).
- block/batch_write/treedb: contention hotspot "runtime.selectgo" (78.58% flat).
- block/batch_write_steady/treedb: contention hotspot "runtime.selectgo" (56.35% flat).
- block/dataset_write_random/treedb: contention hotspot "runtime.selectgo" (84.26% flat).
- block/dataset_write_sorted/treedb: contention hotspot "runtime.selectgo" (66.94% flat).
- block/full_scan/treedb: contention hotspot "runtime.selectgo" (79.06% flat).
- block/prefix_scan/treedb: contention hotspot "runtime.chanrecv1" (100.00% flat).
- block/random_delete/treedb: contention hotspot "runtime.selectgo" (79.78% flat).
- block/random_read/treedb: contention hotspot "runtime.selectgo" (67.37% flat).
- block/random_read_batch/treedb: contention hotspot "runtime.chanrecv1" (65.47% flat).
- block/random_read_parallel/treedb: contention hotspot "runtime.selectgo" (60.20% flat).
- block/random_read_parallel_acquire_snapshot/treedb: contention hotspot "runtime.selectgo" (78.02% flat).
- block/random_write/treedb: contention hotspot "runtime.selectgo" (72.40% flat).
- block/sequential_write/treedb: contention hotspot "runtime.selectgo" (67.10% flat).
- mutex/batch_delete/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/batch_random/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/batch_small_seq/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/batch_write/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/batch_write_steady/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/dataset_write_random/treedb: contention hotspot "sync.(*Mutex).Unlock" (99.55% flat).
- mutex/dataset_write_sorted/treedb: contention hotspot "sync.(*Mutex).Unlock" (99.93% flat).
- mutex/full_scan/treedb: contention hotspot "runtime.unlock (inline)" (100.00% flat).
- mutex/random_delete/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/random_read_batch/treedb: contention hotspot "sync.(*RWMutex).RUnlock (inline)" (87.06% flat).
- mutex/random_read_parallel/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (99.31% flat).
- mutex/random_read_parallel_acquire_snapshot/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (82.75% flat).
- mutex/random_write/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/sequential_write/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (99.70% flat).
- Global block contention hotspot: "runtime.selectgo" (72.83% flat).
- Global mutex contention hotspot: "sync.(*Mutex).Unlock (partial-inline)" (96.25% flat).
- alloc_objects/batch_delete/treedb: top allocator by count is "runtime/pprof.allFrames" (9831 flat, 59.41%).
- alloc_objects/batch_delete/treedb: top hotspot "runtime/pprof.allFrames" is 59.41% flat; this section is highly concentrated in one function.
- alloc_objects/batch_random/treedb: dominant theme is allocation/copy/gc (49.91% flat across top nodes).
- alloc_objects/batch_random/treedb: top allocator by count is "runtime.mallocgc" (1845 flat, 49.91%).
- alloc_objects/batch_random/treedb: top hotspot "runtime.mallocgc" is 49.91% flat; this section is highly concentrated in one function.
- alloc_objects/batch_small_seq/treedb: top allocator by count is "runtime/pprof.allFrames" (37138 flat, 74.66%).
- alloc_objects/batch_small_seq/treedb: top hotspot "runtime/pprof.allFrames" is 74.66% flat; this section is highly concentrated in one function.
- alloc_objects/batch_write/treedb: dominant theme is map/hash lookup (64.40% flat across top nodes).
- alloc_objects/batch_write/treedb: top allocator by count is "runtime/pprof.(*profMap).lookup" (910 flat, 64.40%).
- alloc_objects/batch_write/treedb: top hotspot "runtime/pprof.(*profMap).lookup" is 64.40% flat; this section is highly concentrated in one function.
- alloc_objects/batch_write_steady/treedb: top allocator by count is "runtime/pprof.allFrames" (7646 flat, 95.09%).
- alloc_objects/batch_write_steady/treedb: top hotspot "runtime/pprof.allFrames" is 95.09% flat; this section is highly concentrated in one function.
- alloc_objects/dataset_write_random/treedb: dominant theme is write/delete/flush path (79.68% flat across top nodes).
- alloc_objects/dataset_write_random/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" (347356 flat, 33.76%).
- alloc_objects/dataset_write_sorted/treedb: dominant theme is write/delete/flush path (82.62% flat across top nodes).
- alloc_objects/dataset_write_sorted/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" (504645 flat, 37.17%).
- alloc_objects/dataset_write_sorted/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" is 37.17% flat; this section is highly concentrated in one function.
- alloc_objects/full_scan/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)" (65540 flat, 76.72%).
- alloc_objects/full_scan/treedb: top hotspot "github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)" is 76.72% flat; this section is highly concentrated in one function.
- alloc_objects/prefix_scan/treedb: top allocator by count is "runtime/pprof.allFrames" (14201 flat, 69.55%).
- alloc_objects/prefix_scan/treedb: top hotspot "runtime/pprof.allFrames" is 69.55% flat; this section is highly concentrated in one function.
- alloc_objects/random_delete/treedb: dominant theme is write/delete/flush path (71.89% flat across top nodes).
- alloc_objects/random_delete/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers" (294916 flat, 27.49%).
- alloc_objects/random_read/treedb: top allocator by count is "runtime/pprof.(*profileBuilder).emitLocation" (16402 flat, 67.65%).
- alloc_objects/random_read/treedb: top hotspot "runtime/pprof.(*profileBuilder).emitLocation" is 67.65% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_batch/treedb: top allocator by count is "runtime/pprof.allFrames" (2185 flat, 93.78%).
- alloc_objects/random_read_batch/treedb: top hotspot "runtime/pprof.allFrames" is 93.78% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_parallel/treedb: top allocator by count is "runtime/pprof.allFrames" (2185 flat, 86.26%).
- alloc_objects/random_read_parallel/treedb: top hotspot "runtime/pprof.allFrames" is 86.26% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_parallel_acquire_snapshot/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" (2359550 flat, 98.42%).
- alloc_objects/random_read_parallel_acquire_snapshot/treedb: top hotspot "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" is 98.42% flat; this section is highly concentrated in one function.
- alloc_objects/random_write/treedb: dominant theme is write/delete/flush path (80.20% flat across top nodes).
- alloc_objects/random_write/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" (524313 flat, 39.24%).
- alloc_objects/random_write/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" is 39.24% flat; this section is highly concentrated in one function.
- alloc_objects/sequential_write/treedb: dominant theme is write/delete/flush path (84.57% flat across top nodes).
- alloc_objects/sequential_write/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" (511201 flat, 45.70%).
- alloc_objects/sequential_write/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" is 45.70% flat; this section is highly concentrated in one function.
- alloc_space/batch_delete/treedb: dominant theme is write/delete/flush path (51.01% flat across top nodes).
- alloc_space/batch_delete/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked" (8857.89kB flat, 32.35%).
- alloc_space/batch_random/treedb: dominant theme is write/delete/flush path (84.03% flat across top nodes).
- alloc_space/batch_random/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace" (56.58MB flat, 61.98%).
- alloc_space/batch_random/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace" is 61.98% flat; this section is highly concentrated in one function.
- alloc_space/batch_small_seq/treedb: dominant theme is write/delete/flush path (47.50% flat across top nodes).
- alloc_space/batch_small_seq/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked" (5638.19kB flat, 27.12%).
- alloc_space/batch_write/treedb: dominant theme is write/delete/flush path (78.46% flat across top nodes).
- alloc_space/batch_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo" (27.22MB flat, 37.64%).
- alloc_space/batch_write/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo" is 37.64% flat; this section is highly concentrated in one function.
- alloc_space/batch_write_steady/treedb: dominant theme is write/delete/flush path (66.85% flat across top nodes).
- alloc_space/batch_write_steady/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo" (32.41MB flat, 30.06%).
- alloc_space/dataset_write_random/treedb: dominant theme is write/delete/flush path (85.07% flat across top nodes).
- alloc_space/dataset_write_random/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo" (34.51MB flat, 41.11%).
- alloc_space/dataset_write_random/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo" is 41.11% flat; this section is highly concentrated in one function.
- alloc_space/dataset_write_sorted/treedb: dominant theme is write/delete/flush path (84.41% flat across top nodes).
- alloc_space/dataset_write_sorted/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo" (35.01MB flat, 43.59%).
- alloc_space/dataset_write_sorted/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo" is 43.59% flat; this section is highly concentrated in one function.
- alloc_space/full_scan/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (5415.52kB flat, 28.91%).
- alloc_space/prefix_scan/treedb: dominant theme is value decode/read I/O (59.55% flat across top nodes).
- alloc_space/prefix_scan/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (5415.52kB flat, 35.26%).
- alloc_space/prefix_scan/treedb: top hotspot "compress/flate.NewWriter (inline)" is 35.26% flat; this section is highly concentrated in one function.
- alloc_space/random_delete/treedb: dominant theme is write/delete/flush path (69.52% flat across top nodes).
- alloc_space/random_delete/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" (14.50MB flat, 26.94%).
- alloc_space/random_read/treedb: dominant theme is value decode/read I/O (48.49% flat across top nodes).
- alloc_space/random_read/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (4512.93kB flat, 34.21%).
- alloc_space/random_read_batch/treedb: dominant theme is value decode/read I/O (53.21% flat across top nodes).
- alloc_space/random_read_batch/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (3610.34kB flat, 31.26%).
- alloc_space/random_read_parallel/treedb: dominant theme is value decode/read I/O (66.87% flat across top nodes).
- alloc_space/random_read_parallel/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (3610.34kB flat, 33.02%).
- alloc_space/random_read_parallel_acquire_snapshot/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" (2.25GB flat, 99.39%).
- alloc_space/random_read_parallel_acquire_snapshot/treedb: top hotspot "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" is 99.39% flat; this section is highly concentrated in one function.
- alloc_space/random_write/treedb: dominant theme is write/delete/flush path (87.96% flat across top nodes).
- alloc_space/random_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (44.18MB flat, 31.09%).
- alloc_space/sequential_write/treedb: dominant theme is write/delete/flush path (71.58% flat across top nodes).
- alloc_space/sequential_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo" (33.01MB flat, 21.44%).
- block/batch_delete/treedb: dominant theme is locking/scheduling contention (99.44% flat across top nodes).
- block/batch_delete/treedb: top hotspot "runtime.selectgo" is 99.44% flat; this section is highly concentrated in one function.
- block/batch_random/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_random/treedb: top hotspot "runtime.selectgo" is 74.60% flat; this section is highly concentrated in one function.
- block/batch_small_seq/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_small_seq/treedb: top hotspot "runtime.selectgo" is 73.28% flat; this section is highly concentrated in one function.
- block/batch_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_write/treedb: top hotspot "runtime.selectgo" is 78.58% flat; this section is highly concentrated in one function.
- block/batch_write_steady/treedb: dominant theme is locking/scheduling contention (97.79% flat across top nodes).
- block/batch_write_steady/treedb: top hotspot "runtime.selectgo" is 56.35% flat; this section is highly concentrated in one function.
- block/dataset_write_random/treedb: dominant theme is locking/scheduling contention (99.84% flat across top nodes).
- block/dataset_write_random/treedb: top hotspot "runtime.selectgo" is 84.26% flat; this section is highly concentrated in one function.
- block/dataset_write_sorted/treedb: dominant theme is locking/scheduling contention (99.54% flat across top nodes).
- block/dataset_write_sorted/treedb: top hotspot "runtime.selectgo" is 66.94% flat; this section is highly concentrated in one function.
- block/full_scan/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/full_scan/treedb: top hotspot "runtime.selectgo" is 79.06% flat; this section is highly concentrated in one function.
- block/prefix_scan/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/prefix_scan/treedb: top hotspot "runtime.chanrecv1" is 100.00% flat; this section is highly concentrated in one function.
- block/random_delete/treedb: dominant theme is locking/scheduling contention (100.01% flat across top nodes).
- block/random_delete/treedb: top hotspot "runtime.selectgo" is 79.78% flat; this section is highly concentrated in one function.
- block/random_read/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/random_read/treedb: top hotspot "runtime.selectgo" is 67.37% flat; this section is highly concentrated in one function.
- block/random_read_batch/treedb: dominant theme is locking/scheduling contention (65.47% flat across top nodes).
- block/random_read_batch/treedb: top hotspot "runtime.chanrecv1" is 65.47% flat; this section is highly concentrated in one function.
- block/random_read_parallel/treedb: dominant theme is locking/scheduling contention (84.42% flat across top nodes).
- block/random_read_parallel/treedb: top hotspot "runtime.selectgo" is 60.20% flat; this section is highly concentrated in one function.
- block/random_read_parallel_acquire_snapshot/treedb: dominant theme is locking/scheduling contention (93.74% flat across top nodes).
- block/random_read_parallel_acquire_snapshot/treedb: top hotspot "runtime.selectgo" is 78.02% flat; this section is highly concentrated in one function.
- block/random_write/treedb: dominant theme is locking/scheduling contention (99.72% flat across top nodes).
- block/random_write/treedb: top hotspot "runtime.selectgo" is 72.40% flat; this section is highly concentrated in one function.
- block/sequential_write/treedb: dominant theme is locking/scheduling contention (96.69% flat across top nodes).
- block/sequential_write/treedb: top hotspot "runtime.selectgo" is 67.10% flat; this section is highly concentrated in one function.
- batch_delete/treedb: dominant theme is iterator/seek/compare overhead (40.01% flat across top nodes).
- batch_random/treedb: dominant theme is iterator/seek/compare overhead (29.62% flat across top nodes).
- batch_write_steady/treedb: dominant theme is value decode/read I/O (54.99% flat across top nodes).
- batch_write_steady/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 50.00% flat; this section is highly concentrated in one function.
- checkpoint/batch_delete/treedb: dominant theme is value decode/read I/O (59.74% flat across top nodes).
- checkpoint/batch_delete/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 50.57% flat; this section is highly concentrated in one function.
- checkpoint/batch_small_seq/treedb: dominant theme is value decode/read I/O (64.49% flat across top nodes).
- checkpoint/batch_small_seq/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 54.55% flat; this section is highly concentrated in one function.
- checkpoint/batch_write/treedb: dominant theme is value decode/read I/O (59.20% flat across top nodes).
- checkpoint/batch_write/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 42.45% flat; this section is highly concentrated in one function.
- checkpoint/batch_write_steady/treedb: dominant theme is value decode/read I/O (64.21% flat across top nodes).
- checkpoint/batch_write_steady/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 59.46% flat; this section is highly concentrated in one function.
- checkpoint/dataset_write_random/treedb: dominant theme is value decode/read I/O (50.27% flat across top nodes).
- checkpoint/dataset_write_sorted/treedb: dominant theme is value decode/read I/O (57.64% flat across top nodes).
- checkpoint/dataset_write_sorted/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 45.85% flat; this section is highly concentrated in one function.
- checkpoint/random_delete/treedb: dominant theme is value decode/read I/O (69.22% flat across top nodes).
- checkpoint/random_delete/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 59.38% flat; this section is highly concentrated in one function.
- checkpoint/random_read/treedb: dominant theme is value decode/read I/O (51.05% flat across top nodes).
- checkpoint/random_read/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 36.17% flat; this section is highly concentrated in one function.
- checkpoint/random_read_parallel/treedb: top hotspot "internal/runtime/syscall/linux.Syscall6" is 100.00% flat; this section is highly concentrated in one function.
- checkpoint/random_write/treedb: dominant theme is value decode/read I/O (68.49% flat across top nodes).
- full_scan/treedb: dominant theme is value decode/read I/O (44.89% flat across top nodes).
- full_scan/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 36.73% flat; this section is highly concentrated in one function.
- prefix_scan/treedb: dominant theme is iterator/seek/compare overhead (70.00% flat across top nodes).
- prefix_scan/treedb: top hotspot "runtime.typePointers.next" is 40.00% flat; this section is highly concentrated in one function.
- random_read/treedb: dominant theme is iterator/seek/compare overhead (26.79% flat across top nodes).
- random_read_parallel_acquire_snapshot/treedb: dominant theme is runtime/syscall overhead (20.15% flat across top nodes).
- mutex/batch_delete/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/batch_delete/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/batch_random/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/batch_random/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/batch_small_seq/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/batch_small_seq/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/batch_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/batch_write/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/batch_write_steady/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/batch_write_steady/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/dataset_write_random/treedb: dominant theme is locking/scheduling contention (99.55% flat across top nodes).
- mutex/dataset_write_random/treedb: top hotspot "sync.(*Mutex).Unlock" is 99.55% flat; this section is highly concentrated in one function.
- mutex/dataset_write_sorted/treedb: dominant theme is locking/scheduling contention (99.93% flat across top nodes).
- mutex/dataset_write_sorted/treedb: top hotspot "sync.(*Mutex).Unlock" is 99.93% flat; this section is highly concentrated in one function.
- mutex/full_scan/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/full_scan/treedb: top hotspot "runtime.unlock (inline)" is 100.00% flat; this section is highly concentrated in one function.
- mutex/random_delete/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/random_delete/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/random_read_batch/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/random_read_batch/treedb: top hotspot "sync.(*RWMutex).RUnlock (inline)" is 87.06% flat; this section is highly concentrated in one function.
- mutex/random_read_parallel/treedb: dominant theme is locking/scheduling contention (99.90% flat across top nodes).
- mutex/random_read_parallel/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 99.31% flat; this section is highly concentrated in one function.
- mutex/random_read_parallel_acquire_snapshot/treedb: dominant theme is locking/scheduling contention (99.72% flat across top nodes).
- mutex/random_read_parallel_acquire_snapshot/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 82.75% flat; this section is highly concentrated in one function.
- mutex/random_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/random_write/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/sequential_write/treedb: dominant theme is locking/scheduling contention (99.70% flat across top nodes).
- mutex/sequential_write/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 99.70% flat; this section is highly concentrated in one function.

## Investigation Targets

| db tag | test | category | function | flat% | code | why |
|---|---|---|---|---:|---|---|
| treedb | batch_delete | other | `runtime/pprof.allFrames` | 59.41% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `runtime/pprof.(*profileBuilder).emitLocation` | 33.12% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 2.97% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 2.75% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` | 0.66% | `TreeDB/internal/commitlog/command_frame.go:444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchIntSlice` | 0.65% | `TreeDB/caching/db.go:36555` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | alloc_copy_gc | `runtime.mallocgc` | 49.91% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` | 14.53% | `TreeDB/internal/commitlog/command_frame.go:444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 12.31% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 11.71% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace` | 3.98% | `TreeDB/internal/commitlog/command_frame.go:964` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).extendSortedRunsLocked` | 3.49% | `TreeDB/internal/memtable/append_only.go:1217` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 2.14% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | other | `runtime/pprof.(*protobuf).string` | 0.65% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | other | `runtime/pprof.allFrames` | 74.66% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 10.07% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` | 6.18% | `TreeDB/internal/commitlog/command_frame.go:444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatchWithCustody` | 5.49% | `TreeDB/command_wal_public_cached.go:580` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` | 3.00% | `TreeDB/caching/db.go:35746` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | map_hash_lookup | `runtime/pprof.(*profMap).lookup` | 64.40% | `TreeDB/caching/db.go:25110` | Focus on key-shape and hash-table lookup/update costs. |
| treedb | batch_write | decode_read_io | `compress/flate.(*huffmanEncoder).generate` | 16.14% | `TreeDB/db/fuzz_test.go:22` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | other | `runtime/pprof.(*profileBuilder).stringIndex` | 5.66% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | other | `runtime/pprof.(*protobuf).string` | 3.96% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` | 3.89% | `TreeDB/caching/db.go:36506` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 1.84% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 1.63% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | decode_read_io | `compress/flate.newDeflateFast (inline)` | 0.92% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | other | `runtime/pprof.allFrames` | 95.09% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` | 1.87% | `TreeDB/internal/commitlog/fixed_wal.go:336` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` | 0.72% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | decode_read_io | `bufio.NewReaderSize (inline)` | 0.51% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | other | `runtime/pprof.(*profileBuilder).emitLocation` | 0.24% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | decode_read_io | `compress/flate.NewWriter (inline)` | 0.09% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | other | `main.runBenchmark.func6` | 0.01% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 33.76% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 27.60% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 19.11% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 18.32% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | other | `runtime/pprof.allFrames` | 0.53% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 37.17% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 31.37% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 16.89% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 14.08% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | full_scan | other | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` | 76.72% | `TreeDB/node/leaf.go:106` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.allFrames` | 14.07% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 6.92% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | alloc_copy_gc | `runtime.mallocgc` | 2.13% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | prefix_scan | other | `runtime/pprof.allFrames` | 69.55% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 27.00% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.(*protobuf).varint (inline)` | 2.87% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | write_delete_flush | `runtime/pprof.writeProfileInternal` | 0.21% | - | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 27.49% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 25.05% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 24.44% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` | 22.40% | `TreeDB/caching/db.go:28712` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | other | `runtime/pprof.allFrames` | 0.51% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `runtime/pprof.(*profileBuilder).emitLocation` | 67.65% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `runtime/pprof.allFrames` | 31.54% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | write_delete_flush | `runtime/pprof.writeHeapInternal` | 0.05% | - | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read_batch | other | `runtime/pprof.allFrames` | 93.78% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 2.49% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `github.com/snissn/gomap/TreeDB/tree.getGetManyScratch` | 1.20% | `TreeDB/tree/tree.go:1188` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.(*profileBuilder).emitLocation` | 1.12% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.(*protobuf).string (inline)` | 0.56% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.(*compressor).init` | 0.34% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | decode_read_io | `compress/flate.NewWriter (inline)` | 0.21% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `runtime/pprof.allFrames` | 86.26% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 3.99% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `math/rand.newSource (inline)` | 3.87% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.(*protobuf).string (inline)` | 2.68% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 2.17% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.newDeflateFast (inline)` | 0.47% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.(*compressor).init` | 0.36% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.NewWriter (inline)` | 0.20% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel_acquire_snapshot | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 98.42% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | write_delete_flush | `github.com/snissn/gomap/TreeDB/db.(*vacuumInternalTreeBuilder).append` | 0.68% | `TreeDB/db/vacuum_online.go:2450` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read_parallel_acquire_snapshot | other | `runtime/pprof.allFrames` | 0.55% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 39.24% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 26.98% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 19.62% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 13.98% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 45.70% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 19.53% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 19.34% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 14.65% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 32.35% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | decode_read_io | `compress/flate.NewWriter (inline)` | 19.78% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | decode_read_io | `compress/flate.(*compressor).init` | 11.50% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` | 7.63% | `TreeDB/internal/commitlog/command_frame.go:444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | decode_read_io | `compress/flate.newDeflateFast (inline)` | 6.39% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | other | `runtime/pprof.allFrames` | 5.61% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 5.17% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | other | `runtime/pprof.(*profileBuilder).emitLocation` | 3.79% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace` | 61.98% | `TreeDB/internal/commitlog/command_frame.go:964` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 8.36% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 6.19% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 4.81% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` | 4.46% | `TreeDB/internal/commitlog/command_frame.go:444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | decode_read_io | `compress/flate.NewWriter (inline)` | 3.86% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_random | decode_read_io | `compress/flate.(*compressor).init` | 2.09% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_random | decode_read_io | `compress/flate.newDeflateFast (inline)` | 1.79% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 27.12% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | decode_read_io | `compress/flate.NewWriter (inline)` | 21.70% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_small_seq | decode_read_io | `compress/flate.newDeflateFast (inline)` | 10.85% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_small_seq | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` | 7.45% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatchWithCustody` | 7.39% | `TreeDB/command_wal_public_cached.go:580` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | other | `runtime/pprof.allFrames` | 7.39% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` | 4.93% | `TreeDB/caching/db.go:35746` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` | 4.93% | `TreeDB/internal/commitlog/command_frame.go:444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 37.64% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 27.80% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 7.17% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | decode_read_io | `compress/flate.NewWriter (inline)` | 6.09% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` | 5.97% | `TreeDB/caching/db.go:36506` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*fixedWAL).flushExtent` | 3.58% | `TreeDB/internal/commitlog/fixed_wal.go:531` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | other | `main.runBenchmark.func6` | 2.22% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | decode_read_io | `compress/flate.(*compressor).init` | 1.76% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 30.06% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` | 26.92% | `TreeDB/internal/commitlog/fixed_wal.go:336` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/commitlog.resizeReaderBuffer (inline)` | 13.23% | `TreeDB/internal/commitlog/reader.go:188` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | decode_read_io | `compress/flate.NewWriter (inline)` | 4.09% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 4.08% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 3.87% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | decode_read_io | `bufio.NewReaderSize (inline)` | 2.47% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` | 2.36% | `TreeDB/internal/commitlog/fixed_wal.go:260` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 41.11% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 19.66% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 10.39% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 6.55% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | decode_read_io | `compress/flate.NewWriter (inline)` | 6.30% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 5.38% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 3.57% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | decode_read_io | `compress/flate.newDeflateFast (inline)` | 2.03% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 43.59% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 23.04% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 11.21% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 4.99% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | decode_read_io | `compress/flate.NewWriter (inline)` | 4.39% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_sorted | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 4.36% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | decode_read_io | `compress/flate.newDeflateFast (inline)` | 2.13% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` | 1.58% | `TreeDB/internal/commitlog/fixed_wal.go:260` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | full_scan | decode_read_io | `compress/flate.NewWriter (inline)` | 28.91% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | other | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` | 21.87% | `TreeDB/node/leaf.go:106` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 11.10% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.allFrames` | 10.94% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | decode_read_io | `compress/flate.(*compressor).init` | 9.86% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | decode_read_io | `compress/flate.newDeflateFast (inline)` | 6.23% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | other | `runtime/pprof.(*protobuf).string (inline)` | 2.84% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 2.77% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | decode_read_io | `compress/flate.NewWriter (inline)` | 35.26% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | decode_read_io | `compress/flate.(*compressor).init` | 20.49% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | other | `runtime/pprof.allFrames` | 16.67% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 10.18% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.(*protobuf).string (inline)` | 6.90% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | decode_read_io | `compress/flate.newDeflateFast (inline)` | 3.80% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | write_delete_flush | `runtime/pprof.writeProfileInternal` | 3.37% | - | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | prefix_scan | other | `runtime/pprof.(*protobuf).varint (inline)` | 3.34% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 26.94% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 14.86% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` | 10.22% | `TreeDB/caching/db.go:28712` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | decode_read_io | `compress/flate.NewWriter (inline)` | 9.82% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 8.36% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 7.56% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` | 7.08% | `TreeDB/internal/commitlog/fixed_wal.go:260` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | decode_read_io | `compress/flate.(*compressor).init` | 3.54% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | decode_read_io | `compress/flate.NewWriter (inline)` | 34.21% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | other | `runtime/pprof.(*profileBuilder).emitLocation` | 19.87% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | decode_read_io | `compress/flate.(*compressor).init` | 9.86% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | other | `runtime/pprof.(*protobuf).string (inline)` | 8.01% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 7.88% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `runtime/pprof.allFrames` | 7.76% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | decode_read_io | `compress/flate.newDeflateFast (inline)` | 4.42% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | write_delete_flush | `runtime/pprof.writeHeapInternal` | 4.04% | - | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read_batch | decode_read_io | `compress/flate.NewWriter (inline)` | 31.26% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | decode_read_io | `compress/flate.(*compressor).init` | 16.90% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `github.com/snissn/gomap/TreeDB/tree.getGetManyScratch` | 14.04% | `TreeDB/tree/tree.go:1188` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.(*profileBuilder).emitLocation` | 9.34% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 9.04% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `main.runBenchmark.func35` | 5.32% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.newDeflateFast (inline)` | 5.05% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `runtime/pprof.(*protobuf).string (inline)` | 4.61% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.NewWriter (inline)` | 33.02% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.(*compressor).init` | 17.85% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.newDeflateFast (inline)` | 16.00% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `runtime/pprof.(*protobuf).string (inline)` | 9.52% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 9.49% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 4.73% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `math/rand.newSource (inline)` | 4.71% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.allFrames` | 4.68% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 99.39% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 31.09% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 20.06% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 18.30% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 6.17% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 5.63% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 5.37% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | decode_read_io | `compress/flate.NewWriter (inline)` | 3.10% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 2.81% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 21.44% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 16.41% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 13.64% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 12.40% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | decode_read_io | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` | 9.45% | `TreeDB/db/leaf_page_read_cache.go:552` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.init.func2` | 4.24% | `TreeDB/caching/db.go:1256` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.acquireSpanNativeLeafLogPayloadArena` | 2.99% | `TreeDB/zipper/span_native_apply.go:87` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 2.92% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | locking_scheduling | `runtime.selectgo` | 99.44% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_random | locking_scheduling | `runtime.selectgo` | 74.60% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_random | locking_scheduling | `runtime.chanrecv1` | 24.70% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_random | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 0.70% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_small_seq | locking_scheduling | `runtime.selectgo` | 73.28% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_small_seq | locking_scheduling | `runtime.chanrecv1` | 26.03% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_small_seq | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 0.69% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write | locking_scheduling | `runtime.selectgo` | 78.58% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write | locking_scheduling | `runtime.chanrecv1` | 17.34% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 4.08% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `runtime.selectgo` | 56.35% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `runtime.chanrecv2` | 30.14% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `runtime.chanrecv1` | 10.29% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | other | `sync.(*WaitGroup).Wait` | 2.21% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 1.01% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | locking_scheduling | `runtime.selectgo` | 84.26% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | locking_scheduling | `runtime.chanrecv1` | 15.58% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | locking_scheduling | `runtime.selectgo` | 66.94% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | locking_scheduling | `runtime.chanrecv1` | 32.60% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | locking_scheduling | `runtime.selectgo` | 79.06% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | locking_scheduling | `runtime.chanrecv1` | 20.94% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | prefix_scan | locking_scheduling | `runtime.chanrecv1` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | locking_scheduling | `runtime.selectgo` | 79.78% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | locking_scheduling | `runtime.chanrecv1` | 17.98% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 2.25% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | locking_scheduling | `runtime.selectgo` | 67.37% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | locking_scheduling | `runtime.chanrecv1` | 32.63% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `runtime.chanrecv1` | 65.47% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | other | `sync.(*WaitGroup).Wait` | 34.52% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | locking_scheduling | `runtime.selectgo` | 60.20% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | other | `sync.(*WaitGroup).Wait` | 15.58% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | locking_scheduling | `runtime.chanrecv1` | 15.34% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 8.88% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.selectgo` | 78.02% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.chanrecv1` | 10.83% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | other | `sync.(*WaitGroup).Wait` | 6.26% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 4.49% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | locking_scheduling | `runtime.selectgo` | 72.40% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | locking_scheduling | `runtime.chanrecv1` | 27.32% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime.selectgo` | 67.10% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime.chanrecv1` | 28.34% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | other | `sync.(*WaitGroup).Wait` | 3.32% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 1.25% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_delete | iterator_seek_compare | `runtime.scanObject` | 20.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_delete | decode_read_io | `compress/flate.hash (inline)` | 6.67% | `HashDB/hashindex.go:70` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Delete` | 6.67% | `TreeDB/command_wal_public_cached.go:918` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 6.67% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | other | `github.com/snissn/gomap/TreeDB/caching.assignLegacyPointEntryRevisions (inline)` | 6.67% | `TreeDB/caching/db.go:11236` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 6.67% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | iterator_seek_compare | `internal/runtime/maps.probeSeq.next (inline)` | 6.67% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_delete | write_delete_flush | `runtime.(*spanSet).pop` | 6.67% | `TreeDB/caching/db.go:15558` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | other | `internal/runtime/syscall/linux.Syscall6` | 14.81% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 14.81% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayload.func1` | 7.41% | `TreeDB/internal/commitlog/command_frame.go:2749` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 7.41% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | iterator_seek_compare | `runtime.scanObject` | 7.41% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_random | runtime_syscall | `runtime.step` | 7.41% | `TreeDB/pager/grow_work.go:94` | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_random | write_delete_flush | `encoding/binary.littleEndian.PutUint32 (inline)` | 3.70% | `TreeDB/node/node.go:81` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 3.70% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | other | `internal/runtime/syscall/linux.Syscall6` | 22.58% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | iterator_seek_compare | `runtime.scanObject` | 12.90% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_small_seq | alloc_copy_gc | `runtime.memclrNoHeapPointers` | 9.68% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_small_seq | runtime_syscall | `runtime.step` | 9.68% | `TreeDB/pager/grow_work.go:94` | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_small_seq | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 9.68% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_small_seq | other | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` | 3.23% | `TreeDB/command_wal_group_commit.go:309` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setViewValidatedWithMVCCInput` | 3.23% | `TreeDB/caching/db.go:37540` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | other | `github.com/snissn/gomap/TreeDB/caching.assignLegacyPointEntryRevisions (inline)` | 3.23% | `TreeDB/caching/db.go:11236` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | other | `internal/runtime/syscall/linux.Syscall6` | 33.33% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 16.67% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).setViewValidatedWithMVCCInput` | 8.33% | `TreeDB/caching/db.go:37540` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` | 8.33% | `TreeDB/internal/memtable/append_only.go:1461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | alloc_copy_gc | `runtime.memmove` | 8.33% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_write | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 4.17% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | runtime_syscall | `runtime.getempty` | 4.17% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_write | alloc_copy_gc | `runtime.memclrNoHeapPointers` | 4.17% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_write_steady | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 50.00% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | other | `internal/runtime/syscall/linux.Syscall6` | 13.75% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | alloc_copy_gc | `runtime.memmove` | 5.00% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` | 2.50% | `TreeDB/internal/commitlog/command_frame.go:2780` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 1.25% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 1.25% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | other | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Less` | 1.25% | `TreeDB/caching/db.go:15541` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/valuelog.readAtWithDictToScratch` | 1.25% | `TreeDB/internal/valuelog/reader.go:1009` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_delete | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 50.57% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_delete | other | `internal/runtime/syscall/linux.Syscall6` | 6.90% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_delete | alloc_copy_gc | `runtime.memmove` | 2.87% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/batch_delete | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` | 2.30% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_delete | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 2.30% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_delete | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).UnsafeEntryWithRevision` | 2.30% | `TreeDB/internal/memtable/append_only.go:2939` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/batch_delete | iterator_seek_compare | `cmpbody` | 1.15% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/batch_delete | other | `countbody` | 1.15% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_small_seq | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 54.55% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_small_seq | other | `internal/runtime/syscall/linux.Syscall6` | 9.92% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_small_seq | iterator_seek_compare | `cmpbody` | 2.48% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/batch_small_seq | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/valuelog.decodeFrameValueBounds` | 1.65% | `TreeDB/internal/valuelog/valuelog.go:223` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_small_seq | other | `github.com/snissn/gomap/TreeDB/node.(*Node).WalkInternalChildren` | 1.65% | `TreeDB/node/internal.go:261` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_small_seq | decode_read_io | `hash/crc32.ieeeCLMUL` | 1.65% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_small_seq | runtime_syscall | `runtime.nanotime (inline)` | 1.65% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | checkpoint/batch_small_seq | other | `countbody` | 0.83% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_write | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 42.45% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write | other | `internal/runtime/syscall/linux.Syscall6` | 9.39% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_write | alloc_copy_gc | `runtime.memmove` | 6.12% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/batch_write | decode_read_io | `hash/crc32.ieeeCLMUL` | 4.49% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 4.49% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 2.04% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | checkpoint/batch_write | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` | 1.22% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.validateFixedWALFrames` | 1.22% | `TreeDB/internal/commitlog/fixed_wal.go:497` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/batch_write_steady | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 59.46% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write_steady | other | `internal/runtime/syscall/linux.Syscall6` | 8.78% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/batch_write_steady | alloc_copy_gc | `runtime.memmove` | 4.73% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/batch_write_steady | runtime_syscall | `runtime.fpTracebackPCs (inline)` | 2.70% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | checkpoint/batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` | 2.03% | `TreeDB/internal/commitlog/command_frame.go:2780` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/batch_write_steady | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 1.35% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/batch.(*Batch).setViewWithMVCCInput` | 1.35% | `TreeDB/batch/batch.go:477` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/batch_write_steady | other | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafValueViewColumnarPrefixV2` | 1.35% | `TreeDB/node/leaf.go:1376` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/dataset_write_random | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 29.94% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_random | other | `internal/runtime/syscall/linux.Syscall6` | 7.91% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/dataset_write_random | alloc_copy_gc | `runtime.memmove` | 7.34% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/dataset_write_random | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 5.65% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_random | decode_read_io | `hash/crc32.ieeeCLMUL` | 5.08% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` | 2.26% | `TreeDB/internal/commitlog/fixed_wal.go:336` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/dataset_write_random | decode_read_io | `hash/crc32.archUpdateIEEE` | 2.26% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_random | decode_read_io | `io.ReadAtLeast` | 2.26% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_sorted | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 45.85% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_sorted | other | `internal/runtime/syscall/linux.Syscall6` | 8.73% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/dataset_write_sorted | alloc_copy_gc | `runtime.memmove` | 5.24% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/dataset_write_sorted | decode_read_io | `hash/crc32.ieeeCLMUL` | 3.49% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_sorted | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 3.49% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/dataset_write_sorted | other | `memeqbody` | 3.49% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/dataset_write_sorted | iterator_seek_compare | `cmpbody` | 2.62% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/dataset_write_sorted | other | `encoding/binary.littleEndian.Uint32 (inline)` | 1.75% | `TreeDB/internal/quantizedasset/quantized_asset.go:960` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_delete | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 59.38% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_delete | other | `internal/runtime/syscall/linux.Syscall6` | 10.27% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_delete | alloc_copy_gc | `runtime.memmove` | 2.68% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/random_delete | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 2.23% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` | 1.79% | `TreeDB/internal/commitlog/command_frame.go:2780` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/random_delete | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 1.79% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_delete | runtime_syscall | `runtime.fpTracebackPCs (inline)` | 1.34% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | checkpoint/random_delete | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).CompressBlock` | 0.89% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_read | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 36.17% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_read | other | `internal/runtime/syscall/linux.Syscall6` | 11.70% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_read | alloc_copy_gc | `runtime.memmove` | 6.38% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | checkpoint/random_read | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 4.26% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_read | decode_read_io | `hash/crc32.ieeeCLMUL` | 3.72% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_read | iterator_seek_compare | `cmpbody` | 3.19% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | checkpoint/random_read | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/commitlog.decodeCommandFrameV2` | 3.19% | `TreeDB/internal/commitlog/command_frame_v2.go:202` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_read | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.allZeroBytes (inline)` | 1.60% | `TreeDB/internal/commitlog/writer.go:115` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/random_read_parallel | other | `internal/runtime/syscall/linux.Syscall6` | 100.00% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_write | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 20.37% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_write | decode_read_io | `hash/crc32.ieeeCLMUL` | 14.81% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_write | other | `internal/runtime/syscall/linux.Syscall6` | 12.96% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | checkpoint/random_write | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 11.11% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.RawKVExternalRefFenceV1` | 3.70% | `TreeDB/internal/commitlog/command_frame_v2.go:519` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` | 3.70% | `TreeDB/internal/commitlog/command_frame.go:2780` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | checkpoint/random_write | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/commitlog.decodeCommandFrame` | 3.70% | `TreeDB/internal/commitlog/command_frame.go:2049` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | checkpoint/random_write | other | `encoding/binary.littleEndian.Uint32 (inline)` | 1.85% | `TreeDB/internal/quantizedasset/quantized_asset.go:960` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | other | `internal/runtime/syscall/linux.Syscall6` | 14.61% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 4.49% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_random | iterator_seek_compare | `runtime.scanObject` | 4.49% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.prepareCommandFrameV2Encoding` | 3.37% | `TreeDB/internal/commitlog/command_frame_v2.go:85` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | other | `time.runtimeNow` | 3.37% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | other | `encoding/binary.littleEndian.Uint32 (inline)` | 2.25% | `TreeDB/internal/quantizedasset/quantized_asset.go:960` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` | 2.25% | `TreeDB/caching/db.go:27143` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | other | `internal/runtime/syscall/linux.Syscall6` | 20.93% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 5.81% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | other | `time.runtimeNow` | 4.65% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | map_hash_lookup | `github.com/cespare/xxhash/v2.Sum64` | 3.49% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | dataset_write_sorted | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL256` | 3.49% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_sorted | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 3.49% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | iterator_seek_compare | `runtime.scanObject` | 3.49% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_sorted | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEPCLMUL8` | 2.33% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 36.73% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | iterator_seek_compare | `runtime.scanObject` | 6.12% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | full_scan | runtime_syscall | `runtime.spanClass.sizeclass (inline)` | 6.12% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | full_scan | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 4.08% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | alloc_copy_gc | `runtime.memmove` | 4.08% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | full_scan | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 2.04% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | decode_read_io | `github.com/snissn/go-crc32-asm.updateIEEEFast` | 2.04% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` | 2.04% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.typePointers.next` | 40.00% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | alloc_copy_gc | `runtime.memmove` | 10.00% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.scanObject` | 10.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.spanClass.noscan (inline)` | 10.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | runtime_syscall | `runtime.spanClass.sizeclass (inline)` | 10.00% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | prefix_scan | runtime_syscall | `runtime.step` | 10.00% | `TreeDB/pager/grow_work.go:94` | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 10.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | other | `internal/runtime/syscall/linux.Syscall6` | 18.82% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | other | `time.runtimeNow` | 8.24% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | iterator_seek_compare | `runtime.scanObject` | 7.06% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 5.88% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` | 3.53% | `TreeDB/caching/db.go:28712` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` | 3.53% | `TreeDB/internal/commitlog/command_frame.go:2780` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | decode_read_io | `hash/crc32.ieeeCLMUL` | 3.53% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 2.35% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read | iterator_seek_compare | `runtime.scanObject` | 10.71% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 7.14% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` | 7.14% | `TreeDB/node/internal.go:671` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 5.36% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | other | `internal/runtime/syscall/linux.Syscall6` | 3.57% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | runtime_syscall | `runtime.madvise` | 3.57% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_read | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 3.57% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read | decode_read_io | `compress/flate.(*deflateFast).encode` | 1.79% | `TreeDB/page/meta.go:33` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `internal/runtime/syscall/linux.Syscall6` | 14.29% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 8.16% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | decode_read_io | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getViewLockedWithState` | 6.12% | `TreeDB/db/leaf_page_read_cache.go:931` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` | 6.12% | `TreeDB/node/internal.go:513` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_batch | iterator_seek_compare | `runtime.scanObject` | 6.12% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_batch | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 4.08% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/node.(*Node).searchLeafColumnarPrefixV2BlockWithMeta` | 4.08% | `TreeDB/node/leaf.go:1869` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_batch | other | `github.com/snissn/gomap/TreeDB/tree.outerLeafRecentRingContains` | 4.08% | `TreeDB/tree/outer_leaf_stats.go:123` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 11.00% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `internal/runtime/syscall/linux.Syscall6` | 7.86% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 6.68% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `github.com/snissn/gomap/TreeDB/node.InitFreshNodeView (inline)` | 4.52% | `TreeDB/node/node.go:165` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternal` | 3.34% | `TreeDB/node/internal.go:513` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_parallel | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID` | 3.34% | `TreeDB/node/internal.go:671` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_parallel | other | `github.com/snissn/gomap/TreeDB/tree.noteOuterLeafLoad` | 3.34% | `TreeDB/tree/outer_leaf_stats.go:140` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | map_hash_lookup | `github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView` | 3.14% | `TreeDB/tree/tree.go:761` | Focus on key-shape and hash-table lookup/update costs. |
| treedb | random_read_parallel_acquire_snapshot | runtime_syscall | `runtime.procyieldAsm` | 19.33% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_read_parallel_acquire_snapshot | other | `sync/atomic.(*Int32).Add (inline)` | 9.66% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 5.09% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 3.00% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).lockSlow` | 3.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 2.70% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel_acquire_snapshot | other | `internal/runtime/syscall/linux.Syscall6` | 2.70% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 2.17% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | other | `internal/runtime/syscall/linux.Syscall6` | 18.75% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | other | `time.runtimeNow` | 6.25% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 3.75% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | other | `encoding/binary.littleEndian.Uint32 (inline)` | 2.50% | `TreeDB/internal/quantizedasset/quantized_asset.go:960` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | decode_read_io | `github.com/snissn/go-crc32-asm.checksumIEEE` | 2.50% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/db.(*DB).observeCommandWALAppend` | 2.50% | `TreeDB/db/command_wal_stats.go:350` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/commitlog.prepareCommandFrameV2ForEncode` | 2.50% | `TreeDB/internal/commitlog/command_frame_v2.go:157` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 2.50% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | other | `internal/runtime/syscall/linux.Syscall6` | 15.66% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 4.82% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | other | `time.runtimeNow` | 4.82% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | other | `encoding/binary.littleEndian.Uint32 (inline)` | 3.61% | `TreeDB/internal/quantizedasset/quantized_asset.go:960` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | write_delete_flush | `runtime.(*traceMap).put` | 3.61% | `TreeDB/db/pools.go:100` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | iterator_seek_compare | `runtime.scanObject` | 3.61% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` | 2.41% | `TreeDB/db/command_wal_raw.go:2928` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/commitlog.prepareCommandFrameV2ForEncode` | 2.41% | `TreeDB/internal/commitlog/command_frame_v2.go:157` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_random | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_small_seq | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | locking_scheduling | `sync.(*Mutex).Unlock` | 99.55% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | locking_scheduling | `sync.(*Mutex).Unlock` | 99.93% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | locking_scheduling | `runtime.unlock (inline)` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `sync.(*RWMutex).RUnlock (inline)` | 87.06% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `runtime.unlock (inline)` | 12.94% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 99.31% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | locking_scheduling | `runtime.unlock (inline)` | 0.59% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 82.75% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `sync.(*RWMutex).RUnlock (inline)` | 8.81% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.unlock (inline)` | 8.12% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 99.70% | - | Focus on lock scope, contention points, and channel/select coordination. |

## Warnings

- no CPU samples for checkpoint/batch_random/treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/full_scan/treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/post/run_treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/prefix_scan/treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/random_read_batch/treedb: consider larger -keys or longer workload
- low CPU sample duration for checkpoint/random_read_parallel/treedb (10ms): consider larger -keys or longer workload
- no CPU samples for checkpoint/random_read_parallel_acquire_snapshot/treedb: consider larger -keys or longer workload
- no CPU samples for checkpoint/sequential_write/treedb: consider larger -keys or longer workload
- trace detected at "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_checkpoint_between_tests/trace.out" (trace analysis not yet implemented)

