# Bench Profile Insights

- generated: `2026-11-20T18:08:05Z`
- profiles dir: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests`
- binary: `./bin/unified-bench`
- ops source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/benchprof_results.json`

## Scan Ops/Sec

| Label | Full Scan | Prefix Scan | Prefix / Full |
|---|---:|---:|---:|
| TreeDB | 1,354,031 | 328,430 | 0.24x |

## CPU Hotspots

### batch_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_batch_delete_treedb.pprof`
- total samples: `180ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 40ms | 22.22% | 80ms | 44.44% | `runtime.scanObject` |
| 20ms | 11.11% | 20ms | 11.11% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 20ms | 11.11% | 20ms | 11.11% | `runtime.typePointers.nextFast (inline)` |
| 10ms | 5.56% | 10ms | 5.56% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).DeleteViewValidatedWithRevision` |
| 10ms | 5.56% | 10ms | 5.56% | `github.com/snissn/gomap/TreeDB/caching.pointEntryRevisionStats (inline)` |
| 10ms | 5.56% | 10ms | 5.56% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 10ms | 5.56% | 10ms | 5.56% | `internal/runtime/maps.(*table).uncheckedPutSlot` |
| 10ms | 5.56% | 10ms | 5.56% | `runtime.(*mspan).base` |
| 10ms | 5.56% | 10ms | 5.56% | `runtime.mProf_FlushLocked` |
| 10ms | 5.56% | 10ms | 5.56% | `runtime.releasem` |
| 10ms | 5.56% | 10ms | 5.56% | `runtime.spanClass.sizeclass (inline)` |
| 10ms | 5.56% | 10ms | 5.56% | `runtime.traceLocker.eventWriter` |
| 10ms | 5.56% | 20ms | 11.11% | `runtime.tryDeferToSpanScan` |
| 0 | 0.00% | 20ms | 11.11% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 20ms | 11.11% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared (inline)` |
| 0 | 0.00% | 20ms | 11.11% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 20ms | 11.11% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 20ms | 11.11% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 20ms | 11.11% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 20ms | 11.11% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 10ms | 5.56% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Delete` |
| 0 | 0.00% | 60ms | 33.33% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 20ms | 11.11% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 10ms | 5.56% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).deleteView` |
| 0 | 0.00% | 10ms | 5.56% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).innerDeleteView` |

### batch_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_batch_random_treedb.pprof`
- total samples: `270ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 40ms | 14.81% | 40ms | 14.81% | `internal/runtime/syscall/linux.Syscall6` |
| 30ms | 11.11% | 30ms | 11.11% | `runtime.memmove` |
| 30ms | 11.11% | 90ms | 33.33% | `runtime.scanObject` |
| 30ms | 11.11% | 30ms | 11.11% | `runtime.typePointers.next` |
| 20ms | 7.41% | 20ms | 7.41% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 10ms | 3.70% | 10ms | 3.70% | `encoding/binary.littleEndian.Uint32 (inline)` |
| 10ms | 3.70% | 100ms | 37.04% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 10ms | 3.70% | 10ms | 3.70% | `github.com/snissn/gomap/TreeDB/caching.appendUniqueMemtable (inline)` |
| 10ms | 3.70% | 20ms | 7.41% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 10ms | 3.70% | 10ms | 3.70% | `github.com/snissn/gomap/TreeDB/internal/mvccadmission.inputMatchesKey` |
| 10ms | 3.70% | 10ms | 3.70% | `internal/runtime/maps.(*groupReference).elem (inline)` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.madvise` |
| 10ms | 3.70% | 20ms | 7.41% | `runtime.pcvalue` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.spanClass.sizeclass (inline)` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.step` |
| 10ms | 3.70% | 20ms | 7.41% | `runtime.tryDeferToSpanScan` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.typePointers.nextFast (inline)` |
| 0 | 0.00% | 50ms | 18.52% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 50ms | 18.52% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared (inline)` |
| 0 | 0.00% | 50ms | 18.52% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 50ms | 18.52% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 50ms | 18.52% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 50ms | 18.52% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 50ms | 18.52% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 30ms | 11.11% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Set` |

### batch_small_seq (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_batch_small_seq_treedb.pprof`
- total samples: `280ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 60ms | 21.43% | 60ms | 21.43% | `runtime.memclrNoHeapPointers` |
| 30ms | 10.71% | 30ms | 10.71% | `internal/runtime/maps.ctrlGroup.matchH2` |
| 20ms | 7.14% | 20ms | 7.14% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 20ms | 7.14% | 20ms | 7.14% | `internal/runtime/syscall/linux.Syscall6` |
| 20ms | 7.14% | 60ms | 21.43% | `runtime.scanObject` |
| 10ms | 3.57% | 10ms | 3.57% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).innerSetViewWithMVCCInput` |
| 10ms | 3.57% | 20ms | 7.14% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setViewWithMVCCInput` |
| 10ms | 3.57% | 10ms | 3.57% | `github.com/snissn/gomap/TreeDB/caching.batchShardFirstLast` |
| 10ms | 3.57% | 10ms | 3.57% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireCommandWALPublishWithBarriersAfterAppend` |
| 10ms | 3.57% | 10ms | 3.57% | `internal/runtime/atomic.(*Uint8).Load (inline)` |
| 10ms | 3.57% | 20ms | 7.14% | `runtime.(*sweepLocked).sweep` |
| 10ms | 3.57% | 10ms | 3.57% | `runtime.getGCMask (inline)` |
| 10ms | 3.57% | 10ms | 3.57% | `runtime.nextFreeFast` |
| 10ms | 3.57% | 10ms | 3.57% | `runtime.step` |
| 10ms | 3.57% | 10ms | 3.57% | `runtime.tryDeferToSpanScan` |
| 10ms | 3.57% | 20ms | 7.14% | `runtime.typePointers.next` |
| 10ms | 3.57% | 10ms | 3.57% | `runtime.typePointers.nextFast (inline)` |
| 10ms | 3.57% | 10ms | 3.57% | `runtime.unlock2` |
| 0 | 0.00% | 30ms | 10.71% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 30ms | 10.71% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared` |
| 0 | 0.00% | 30ms | 10.71% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 30ms | 10.71% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 30ms | 10.71% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 30ms | 10.71% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 30ms | 10.71% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |

### batch_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_batch_write_treedb.pprof`
- total samples: `270ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 70ms | 25.93% | 150ms | 55.56% | `runtime.scanObject` |
| 40ms | 14.81% | 60ms | 22.22% | `runtime.tryDeferToSpanScan` |
| 30ms | 11.11% | 30ms | 11.11% | `runtime.memmove` |
| 20ms | 7.41% | 20ms | 7.41% | `internal/runtime/syscall/linux.Syscall6` |
| 10ms | 3.70% | 10ms | 3.70% | `compress/flate.(*huffmanBitWriter).indexTokens` |
| 10ms | 3.70% | 10ms | 3.70% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` |
| 10ms | 3.70% | 10ms | 3.70% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 10ms | 3.70% | 10ms | 3.70% | `internal/runtime/atomic.(*Uint32).CompareAndSwap` |
| 10ms | 3.70% | 10ms | 3.70% | `internal/runtime/maps.ctrlGroup.matchH2` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.(*mheap).allocMSpanLocked` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.(*spanInlineMarkBits).tryAcquire` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.findObject` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.spanClass.noscan (inline)` |
| 10ms | 3.70% | 20ms | 7.41% | `runtime.typePointers.next` |
| 10ms | 3.70% | 10ms | 3.70% | `runtime.typePointers.nextFast (inline)` |
| 0 | 0.00% | 10ms | 3.70% | `compress/flate.(*Writer).Close (inline)` |
| 0 | 0.00% | 10ms | 3.70% | `compress/flate.(*compressor).close` |
| 0 | 0.00% | 10ms | 3.70% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 10ms | 3.70% | `compress/flate.(*huffmanBitWriter).writeBlockDynamic` |
| 0 | 0.00% | 10ms | 3.70% | `compress/gzip.(*Writer).Close` |
| 0 | 0.00% | 10ms | 3.70% | `github.com/snissn/go-crc32-asm.Checksum (inline)` |
| 0 | 0.00% | 10ms | 3.70% | `github.com/snissn/go-crc32-asm.Update` |
| 0 | 0.00% | 10ms | 3.70% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 0 | 0.00% | 10ms | 3.70% | `github.com/snissn/go-crc32-asm.updateIEEE` |
| 0 | 0.00% | 60ms | 22.22% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL` |

### batch_write_steady (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_batch_write_steady_treedb.pprof`
- total samples: `4.27s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.54s | 12.65% | 0.54s | 12.65% | `internal/runtime/syscall/linux.Syscall6` |
| 0.42s | 9.84% | 0.42s | 9.84% | `hash/crc32.simpleUpdate (inline)` |
| 0.35s | 8.20% | 0.35s | 8.20% | `hash/crc32.ieeeCLMUL` |
| 0.26s | 6.09% | 0.26s | 6.09% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 0.19s | 4.45% | 0.19s | 4.45% | `runtime.memmove` |
| 0.16s | 3.75% | 0.52s | 12.18% | `github.com/snissn/gomap/TreeDB/internal/commitlog.decodeCommandFrameV2` |
| 0.14s | 3.28% | 0.19s | 4.45% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 0.11s | 2.58% | 0.11s | 2.58% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 0.10s | 2.34% | 0.10s | 2.34% | `github.com/snissn/go-crc32-asm.crc32IEEEPCLMUL8` |
| 0.10s | 2.34% | 0.65s | 15.22% | `io.ReadAtLeast` |
| 0.09s | 2.11% | 0.09s | 2.11% | `github.com/snissn/gomap/TreeDB/internal/commitlog.allZeroBytes` |
| 0.08s | 1.87% | 0.54s | 12.65% | `bufio.(*Reader).Read` |
| 0.08s | 1.87% | 0.08s | 1.87% | `runtime.memclrNoHeapPointers` |
| 0.06s | 1.41% | 0.66s | 15.46% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 0.06s | 1.41% | 0.06s | 1.41% | `memeqbody` |
| 0.05s | 1.17% | 0.43s | 10.07% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Reader).readSegmentPayloadWithCompressionBuffers` |
| 0.05s | 1.17% | 0.18s | 4.22% | `github.com/snissn/gomap/TreeDB/internal/commitlog.RawKVExternalRefFenceV1` |
| 0.05s | 1.17% | 0.85s | 19.91% | `hash/crc32.archUpdateIEEE` |
| 0.05s | 1.17% | 0.20s | 4.68% | `runtime.mapaccess2_fast64` |
| 0.04s | 0.94% | 0.04s | 0.94% | `cmpbody` |
| 0.04s | 0.94% | 1.18s | 27.63% | `github.com/snissn/go-crc32-asm.updateIEEE` |
| 0.04s | 0.94% | 0.70s | 16.39% | `github.com/snissn/gomap/TreeDB/internal/commitlog.validateFixedWALFrames` |
| 0.04s | 0.94% | 0.08s | 1.87% | `runtime.scanObject` |
| 0.04s | 0.94% | 0.09s | 2.11% | `sort.partition_func` |
| 0.03s | 0.70% | 0.03s | 0.70% | `encoding/binary.littleEndian.Uint32 (inline)` |

### dataset_write_random (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_dataset_write_random_treedb.pprof`
- total samples: `920ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 110ms | 11.96% | 110ms | 11.96% | `internal/runtime/syscall/linux.Syscall6` |
| 70ms | 7.61% | 70ms | 7.61% | `time.runtimeNow` |
| 40ms | 4.35% | 40ms | 4.35% | `runtime.tryDeferToSpanScan` |
| 40ms | 4.35% | 40ms | 4.35% | `runtime.typePointers.next` |
| 40ms | 4.35% | 40ms | 4.35% | `sync/atomic.(*Int32).Add (inline)` |
| 30ms | 3.26% | 30ms | 3.26% | `hash/crc32.ieeeCLMUL` |
| 30ms | 3.26% | 30ms | 3.26% | `hash/crc32.simpleUpdate (inline)` |
| 20ms | 2.17% | 540ms | 58.70% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 20ms | 2.17% | 110ms | 11.96% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 20ms | 2.17% | 50ms | 5.43% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand.func1` |
| 20ms | 2.17% | 20ms | 2.17% | `runtime.greyobject` |
| 20ms | 2.17% | 120ms | 13.04% | `runtime.scanObject` |
| 20ms | 2.17% | 20ms | 2.17% | `sync/atomic.(*Bool).CompareAndSwap (inline)` |
| 10ms | 1.09% | 20ms | 2.17% | `bytes.Compare` |
| 10ms | 1.09% | 10ms | 1.09% | `cmpbody` |
| 10ms | 1.09% | 10ms | 1.09% | `encoding/binary.littleEndian.PutUint16 (inline)` |
| 10ms | 1.09% | 10ms | 1.09% | `encoding/binary.littleEndian.Uint16 (inline)` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/go-crc32-asm.crc32IEEEPCLMUL8` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL256` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1.1` |
| 10ms | 1.09% | 650ms | 70.65% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB/caching.(*DB).thresholdsLocked` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureCommandWALExternalDependencies` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).fixedWALAheadErrorLocked` |
| 10ms | 1.09% | 10ms | 1.09% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Writer).fixedFitsAppend` |

### dataset_write_sorted (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_dataset_write_sorted_treedb.pprof`
- total samples: `1.06s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 0.16s | 15.09% | 0.16s | 15.09% | `internal/runtime/syscall/linux.Syscall6` |
| 0.06s | 5.66% | 0.18s | 16.98% | `runtime.scanObject` |
| 0.05s | 4.72% | 0.05s | 4.72% | `runtime.memclrNoHeapPointers` |
| 0.03s | 2.83% | 0.07s | 6.60% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWrite` |
| 0.03s | 2.83% | 0.03s | 2.83% | `internal/sync.(*Mutex).Unlock (inline)` |
| 0.03s | 2.83% | 0.04s | 3.77% | `runtime.tryDeferToSpanScan` |
| 0.03s | 2.83% | 0.03s | 2.83% | `runtime.typePointers.next` |
| 0.03s | 2.83% | 0.03s | 2.83% | `time.runtimeNow` |
| 0.02s | 1.89% | 0.02s | 1.89% | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL256` |
| 0.02s | 1.89% | 0.67s | 63.21% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 0.02s | 1.89% | 0.28s | 26.42% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).FlushObserved` |
| 0.02s | 1.89% | 0.04s | 3.77% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand.func1` |
| 0.02s | 1.89% | 0.02s | 1.89% | `hash/crc32.simpleUpdate (inline)` |
| 0.02s | 1.89% | 0.02s | 1.89% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 0.02s | 1.89% | 0.02s | 1.89% | `internal/sync.(*Mutex).Lock (inline)` |
| 0.02s | 1.89% | 0.02s | 1.89% | `runtime.findObject` |
| 0.02s | 1.89% | 0.04s | 3.77% | `runtime.mapassign_faststr` |
| 0.02s | 1.89% | 0.02s | 1.89% | `runtime.nextFreeFast (inline)` |
| 0.02s | 1.89% | 0.03s | 2.83% | `runtime.step` |
| 0.02s | 1.89% | 0.02s | 1.89% | `runtime.traceAcquireEnabled` |
| 0.02s | 1.89% | 0.02s | 1.89% | `runtime.typePointers.nextFast (inline)` |
| 0.01s | 0.94% | 0.01s | 0.94% | `github.com/cespare/xxhash/v2.Sum64` |
| 0.01s | 0.94% | 0.05s | 4.72% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 0.01s | 0.94% | 0.01s | 0.94% | `github.com/snissn/go-crc32-asm.crc32IEEEPCLMUL8` |
| 0.01s | 0.94% | 0.50s | 47.17% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |

### full_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_full_scan_treedb.pprof`
- total samples: `870ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 330ms | 37.93% | 330ms | 37.93% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 100ms | 11.49% | 140ms | 16.09% | `runtime.scanObject` |
| 40ms | 4.60% | 40ms | 4.60% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` |
| 30ms | 3.45% | 30ms | 3.45% | `cmpbody` |
| 30ms | 3.45% | 60ms | 6.90% | `github.com/snissn/gomap/TreeDB/internal/merging.iteratorHeap.Less` |
| 20ms | 2.30% | 30ms | 3.45% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithCOWPolicy` |
| 20ms | 2.30% | 20ms | 2.30% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).UnsafeEntryWithRevision` |
| 20ms | 2.30% | 240ms | 27.59% | `github.com/snissn/gomap/TreeDB/internal/merging.(*MergingIterator).advance` |
| 20ms | 2.30% | 20ms | 2.30% | `github.com/snissn/gomap/TreeDB/internal/merging.iteratorHeap.Swap (inline)` |
| 20ms | 2.30% | 20ms | 2.30% | `runtime.memmove` |
| 20ms | 2.30% | 20ms | 2.30% | `runtime.typePointers.next` |
| 10ms | 1.15% | 40ms | 4.60% | `bytes.Compare (inline)` |
| 10ms | 1.15% | 10ms | 1.15% | `github.com/snissn/gomap/TreeDB/caching.(*valueLogIterator).IsDeleted` |
| 10ms | 1.15% | 70ms | 8.05% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked` |
| 10ms | 1.15% | 40ms | 4.60% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked.func1` |
| 10ms | 1.15% | 10ms | 1.15% | `github.com/snissn/gomap/TreeDB/internal/merging.(*MergingIterator).captureIteratorError` |
| 10ms | 1.15% | 60ms | 6.90% | `github.com/snissn/gomap/TreeDB/internal/merging.(*iteratorHeap).up` |
| 10ms | 1.15% | 10ms | 1.15% | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` |
| 10ms | 1.15% | 20ms | 2.30% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 10ms | 1.15% | 10ms | 1.15% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2ValueMetaAt` |
| 10ms | 1.15% | 10ms | 1.15% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafPrefixCompressed (inline)` |
| 10ms | 1.15% | 460ms | 52.87% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadCurrent` |
| 10ms | 1.15% | 420ms | 48.28% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).stepForward` |
| 10ms | 1.15% | 10ms | 1.15% | `internal/bytealg.LastIndexByteString (inline)` |
| 10ms | 1.15% | 10ms | 1.15% | `internal/reflectlite.Swapper.func5` |

### prefix_scan (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_prefix_scan_treedb.pprof`
- total samples: `160ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30ms | 18.75% | 30ms | 18.75% | `runtime.tryDeferToSpanScan` |
| 20ms | 12.50% | 90ms | 56.25% | `runtime.scanObject` |
| 20ms | 12.50% | 20ms | 12.50% | `runtime.typePointers.next` |
| 10ms | 6.25% | 10ms | 6.25% | `compress/flate.(*deflateFast).encode` |
| 10ms | 6.25% | 10ms | 6.25% | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` |
| 10ms | 6.25% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/pager.isPrimaryBankID (inline)` |
| 10ms | 6.25% | 10ms | 6.25% | `internal/runtime/atomic.(*Uint32).Add` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.futex` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.headTailIndex.head` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.spanOfUnchecked (inline)` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.typePointers.nextFast (inline)` |
| 10ms | 6.25% | 10ms | 6.25% | `runtime.unlock2` |
| 0 | 0.00% | 10ms | 6.25% | `compress/flate.(*Writer).Write (inline)` |
| 0 | 0.00% | 10ms | 6.25% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 10ms | 6.25% | `compress/flate.(*compressor).write` |
| 0 | 0.00% | 10ms | 6.25% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/pierrec/lz4/v4.UncompressBlock (inline)` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/pierrec/lz4/v4/internal/lz4block.UncompressBlock` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB.(*DB).Iterator` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Iterator` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/db.(*DB).Iterator` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/db.(*DB).IteratorWithOptions` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadLeafLogPageUnsafeToWithState` |
| 0 | 0.00% | 10ms | 6.25% | `github.com/snissn/gomap/TreeDB/db.valueReader.ReadUnsafeTo` |

### random_delete (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_random_delete_treedb.pprof`
- total samples: `770ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 120ms | 15.58% | 120ms | 15.58% | `internal/runtime/syscall/linux.Syscall6` |
| 60ms | 7.79% | 60ms | 7.79% | `internal/sync.(*Mutex).Lock (inline)` |
| 50ms | 6.49% | 110ms | 14.29% | `runtime.scanObject` |
| 50ms | 6.49% | 50ms | 6.49% | `runtime.tryDeferToSpanScan` |
| 30ms | 3.90% | 30ms | 3.90% | `hash/crc32.simpleUpdate (inline)` |
| 30ms | 3.90% | 30ms | 3.90% | `sync/atomic.(*Int32).Add (inline)` |
| 20ms | 2.60% | 20ms | 2.60% | `encoding/binary.littleEndian.Uint32 (inline)` |
| 20ms | 2.60% | 70ms | 9.09% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand.func1` |
| 20ms | 2.60% | 20ms | 2.60% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayload.func1` |
| 20ms | 2.60% | 60ms | 7.79% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 20ms | 2.60% | 60ms | 7.79% | `hash/crc32.archUpdateIEEE` |
| 20ms | 2.60% | 20ms | 2.60% | `internal/runtime/maps.ctrlGroup.matchH2` |
| 20ms | 2.60% | 20ms | 2.60% | `time.Now` |
| 10ms | 1.30% | 460ms | 59.74% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 10ms | 1.30% | 10ms | 1.30% | `github.com/snissn/gomap/TreeDB.(*DB).beginPublicOperation` |
| 10ms | 1.30% | 20ms | 2.60% | `github.com/snissn/gomap/TreeDB.(*DB).publicCommandWALAutoCheckpointBytes` |
| 10ms | 1.30% | 450ms | 58.44% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 10ms | 1.30% | 40ms | 5.19% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWrite` |
| 10ms | 1.30% | 10ms | 1.30% | `github.com/snissn/gomap/TreeDB/caching.(*keyRange).add` |
| 10ms | 1.30% | 10ms | 1.30% | `github.com/snissn/gomap/TreeDB/caching.hashKey` |
| 10ms | 1.30% | 10ms | 1.30% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming.func2` |
| 10ms | 1.30% | 20ms | 2.60% | `github.com/snissn/gomap/TreeDB/db.(*DB).observeCommandWALFlush` |
| 10ms | 1.30% | 240ms | 31.17% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).flushDirectCommandWALLocked` |
| 10ms | 1.30% | 230ms | 29.87% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Writer).Flush` |
| 10ms | 1.30% | 220ms | 28.57% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*Writer).flushFixed` |

### random_read (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_random_read_treedb.pprof`
- total samples: `230ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 80ms | 34.78% | 130ms | 56.52% | `runtime.scanObject` |
| 40ms | 17.39% | 40ms | 17.39% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 20ms | 8.70% | 60ms | 26.09% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).lookupEntryLocked` |
| 20ms | 8.70% | 20ms | 8.70% | `runtime.findObject` |
| 20ms | 8.70% | 20ms | 8.70% | `runtime.tryDeferToSpanScan` |
| 10ms | 4.35% | 70ms | 30.43% | `github.com/snissn/gomap/TreeDB/caching.memtableEntryWithRevision` |
| 10ms | 4.35% | 10ms | 4.35% | `internal/runtime/atomic.(*Uint32).CompareAndSwap (inline)` |
| 10ms | 4.35% | 10ms | 4.35% | `runtime.futex` |
| 10ms | 4.35% | 10ms | 4.35% | `runtime.typePointers.next` |
| 10ms | 4.35% | 10ms | 4.35% | `time.runtimeNow` |
| 0 | 0.00% | 80ms | 34.78% | `github.com/snissn/gomap/TreeDB.(*DB).GetAppend` |
| 0 | 0.00% | 80ms | 34.78% | `github.com/snissn/gomap/TreeDB/caching.(*DB).GetAppend` |
| 0 | 0.00% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/caching.(*DB).beginForegroundRead` |
| 0 | 0.00% | 70ms | 30.43% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getMemtableAppend` |
| 0 | 0.00% | 10ms | 4.35% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteRead` |
| 0 | 0.00% | 70ms | 30.43% | `github.com/snissn/gomap/TreeDB/caching.rootDomainSnapshot.getEntry (inline)` |
| 0 | 0.00% | 70ms | 30.43% | `github.com/snissn/gomap/TreeDB/caching.rootDomainSnapshot.getEntryWithRevisionSource` |
| 0 | 0.00% | 60ms | 26.09% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).GetEntryWithRevision` |
| 0 | 0.00% | 80ms | 34.78% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).GetAppend` |
| 0 | 0.00% | 80ms | 34.78% | `main.main` |
| 0 | 0.00% | 80ms | 34.78% | `main.runBenchmark` |
| 0 | 0.00% | 80ms | 34.78% | `main.runBenchmark.func32` |
| 0 | 0.00% | 10ms | 4.35% | `runtime.(*activeSweep).begin (inline)` |
| 0 | 0.00% | 10ms | 4.35% | `runtime.bgsweep` |
| 0 | 0.00% | 10ms | 4.35% | `runtime.findRunnable` |

### random_read_batch (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_random_read_batch_treedb.pprof`
- total samples: `250ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 80ms | 32.00% | 140ms | 56.00% | `runtime.scanObject` |
| 40ms | 16.00% | 40ms | 16.00% | `runtime.tryDeferToSpanScan` |
| 10ms | 4.00% | 20ms | 8.00% | `bytes.Compare (inline)` |
| 10ms | 4.00% | 10ms | 4.00% | `cmpbody` |
| 10ms | 4.00% | 30ms | 12.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getManyViewFromPublishedRootPointShards.func1` |
| 10ms | 4.00% | 20ms | 8.00% | `github.com/snissn/gomap/TreeDB/caching.probeRootDomainTablePointRefs` |
| 10ms | 4.00% | 10ms | 4.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` |
| 10ms | 4.00% | 10ms | 4.00% | `internal/runtime/atomic.(*Uint32).Add` |
| 10ms | 4.00% | 10ms | 4.00% | `runtime.(*lfstack).push` |
| 10ms | 4.00% | 10ms | 4.00% | `runtime.findObject` |
| 10ms | 4.00% | 10ms | 4.00% | `runtime.getGCMask (inline)` |
| 10ms | 4.00% | 10ms | 4.00% | `runtime.madvise` |
| 10ms | 4.00% | 10ms | 4.00% | `runtime.memclrNoHeapPointers` |
| 10ms | 4.00% | 10ms | 4.00% | `runtime.step` |
| 10ms | 4.00% | 40ms | 16.00% | `sort.partition_func` |
| 0 | 0.00% | 70ms | 28.00% | `github.com/snissn/gomap/TreeDB.(*DB).GetManyView` |
| 0 | 0.00% | 70ms | 28.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).GetManyView` |
| 0 | 0.00% | 70ms | 28.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getManyViewFromPublishedRootPointShards` |
| 0 | 0.00% | 20ms | 8.00% | `github.com/snissn/gomap/TreeDB/caching.probeRootDomainTableSortedRefs` |
| 0 | 0.00% | 20ms | 8.00% | `github.com/snissn/gomap/TreeDB/caching.rootDomainSnapshot.getManySortedRefs` |
| 0 | 0.00% | 10ms | 4.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).GetEntry` |
| 0 | 0.00% | 10ms | 4.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).GetEntryWithRevision` |
| 0 | 0.00% | 10ms | 4.00% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).getEntryFrozen` |
| 0 | 0.00% | 70ms | 28.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).GetManyView` |
| 0 | 0.00% | 80ms | 32.00% | `main.main` |

### random_read_parallel (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_random_read_parallel_treedb.pprof`
- total samples: `900ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 200ms | 22.22% | 200ms | 22.22% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` |
| 120ms | 13.33% | 120ms | 13.33% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 80ms | 8.89% | 240ms | 26.67% | `runtime.mapaccess2_fast64` |
| 50ms | 5.56% | 140ms | 15.56% | `runtime.scanObject` |
| 40ms | 4.44% | 500ms | 55.56% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).getEntryFrozen` |
| 40ms | 4.44% | 40ms | 4.44% | `runtime.tryDeferToSpanScan` |
| 40ms | 4.44% | 40ms | 4.44% | `sync/atomic.(*Uint64).CompareAndSwap (inline)` |
| 30ms | 3.33% | 570ms | 63.33% | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).lookupCachedRootDomainEntryWithRevision` |
| 30ms | 3.33% | 30ms | 3.33% | `internal/runtime/maps.h1 (inline)` |
| 30ms | 3.33% | 40ms | 4.44% | `math/rand.(*Rand).Int31n` |
| 30ms | 3.33% | 30ms | 3.33% | `sync/atomic.(*Bool).Load` |
| 20ms | 2.22% | 30ms | 3.33% | `github.com/snissn/gomap/TreeDB/caching.hashKey` |
| 20ms | 2.22% | 20ms | 2.22% | `memeqbody` |
| 20ms | 2.22% | 20ms | 2.22% | `runtime.memmove` |
| 20ms | 2.22% | 30ms | 3.33% | `runtime.typePointers.next` |
| 20ms | 2.22% | 20ms | 2.22% | `sync/atomic.(*Uint64).Add (inline)` |
| 10ms | 1.11% | 680ms | 75.56% | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).GetAppend` |
| 10ms | 1.11% | 30ms | 3.33% | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).endRead` |
| 10ms | 1.11% | 510ms | 56.67% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).GetEntryWithRevision` |
| 10ms | 1.11% | 10ms | 1.11% | `github.com/snissn/gomap/TreeDB/internal/mvcckey.VersionAffinityPrefix` |
| 10ms | 1.11% | 10ms | 1.11% | `internal/runtime/maps.(*Map).Used (inline)` |
| 10ms | 1.11% | 10ms | 1.11% | `math/rand.(*rngSource).Uint64 (inline)` |
| 10ms | 1.11% | 10ms | 1.11% | `runtime.deferprocStack` |
| 10ms | 1.11% | 20ms | 2.22% | `runtime.findObject` |
| 10ms | 1.11% | 10ms | 1.11% | `runtime.findfunc` |

### random_read_parallel_acquire_snapshot (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `11.59s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2.16s | 18.64% | 2.16s | 18.64% | `runtime.procyieldAsm` |
| 1.22s | 10.53% | 1.22s | 10.53% | `sync/atomic.(*Int32).Add (inline)` |
| 0.79s | 6.82% | 3.72s | 32.10% | `internal/sync.(*Mutex).Lock (inline)` |
| 0.63s | 5.44% | 2.93s | 25.28% | `internal/sync.(*Mutex).lockSlow` |
| 0.42s | 3.62% | 0.42s | 3.62% | `sync/atomic.(*Int64).Add (inline)` |
| 0.41s | 3.54% | 0.69s | 5.95% | `internal/sync.(*Mutex).Unlock (inline)` |
| 0.22s | 1.90% | 10.71s | 92.41% | `main.runBenchmark.func34.1` |
| 0.21s | 1.81% | 0.21s | 1.81% | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` |
| 0.21s | 1.81% | 0.21s | 1.81% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 0.20s | 1.73% | 0.45s | 3.88% | `runtime.scanObject` |
| 0.19s | 1.64% | 0.19s | 1.64% | `sync/atomic.(*Uint64).Add (inline)` |
| 0.18s | 1.55% | 0.18s | 1.55% | `sync/atomic.(*Int32).CompareAndSwap (inline)` |
| 0.15s | 1.29% | 0.15s | 1.29% | `runtime.nanotime (inline)` |
| 0.13s | 1.12% | 6.05s | 52.20% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireSnapshot` |
| 0.13s | 1.12% | 0.17s | 1.47% | `runtime.tryDeferToSpanScan` |
| 0.12s | 1.04% | 0.14s | 1.21% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteMemtableViewRetain (inline)` |
| 0.12s | 1.04% | 3.22s | 27.78% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0.11s | 0.95% | 0.12s | 1.04% | `runtime.heapSetTypeSmallHeader (inline)` |
| 0.11s | 0.95% | 0.20s | 1.73% | `sync.(*RWMutex).TryRLock (inline)` |
| 0.11s | 0.95% | 0.11s | 0.95% | `time.runtimeNow` |
| 0.10s | 0.86% | 0.21s | 1.81% | `github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryJoinFastForPurpose` |
| 0.09s | 0.78% | 0.09s | 0.78% | `runtime.memclrNoHeapPointers` |
| 0.08s | 0.69% | 0.08s | 0.69% | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteMemtableViewRelease (inline)` |
| 0.08s | 0.69% | 0.37s | 3.19% | `runtime.mapaccess2_fast64` |
| 0.07s | 0.60% | 0.78s | 6.73% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |

### random_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_random_write_treedb.pprof`
- total samples: `800ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 110ms | 13.75% | 110ms | 13.75% | `internal/runtime/syscall/linux.Syscall6` |
| 30ms | 3.75% | 30ms | 3.75% | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` |
| 30ms | 3.75% | 30ms | 3.75% | `hash/crc32.simpleUpdate (inline)` |
| 30ms | 3.75% | 30ms | 3.75% | `sync/atomic.(*Int32).Add (inline)` |
| 30ms | 3.75% | 30ms | 3.75% | `time.runtimeNow` |
| 20ms | 2.50% | 20ms | 2.50% | `github.com/snissn/go-crc32-asm.crc32IEEEPCLMUL8` |
| 20ms | 2.50% | 180ms | 22.50% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeFixedAt` |
| 20ms | 2.50% | 20ms | 2.50% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` |
| 20ms | 2.50% | 20ms | 2.50% | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` |
| 20ms | 2.50% | 20ms | 2.50% | `internal/sync.(*Mutex).Lock (inline)` |
| 20ms | 2.50% | 20ms | 2.50% | `internal/sync.(*Mutex).Unlock (inline)` |
| 20ms | 2.50% | 20ms | 2.50% | `runtime.fpTracebackPCs (inline)` |
| 20ms | 2.50% | 20ms | 2.50% | `runtime.nextFreeFast (inline)` |
| 20ms | 2.50% | 20ms | 2.50% | `runtime.step` |
| 10ms | 1.25% | 10ms | 1.25% | `github.com/cespare/xxhash/v2.Sum64` |
| 10ms | 1.25% | 70ms | 8.75% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 10ms | 1.25% | 450ms | 56.25% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 10ms | 1.25% | 460ms | 57.50% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 10ms | 1.25% | 10ms | 1.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).beginDirectWrite` |
| 10ms | 1.25% | 640ms | 80.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 10ms | 1.25% | 620ms | 77.50% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 10ms | 1.25% | 10ms | 1.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).shardExceedsLimit (inline)` |
| 10ms | 1.25% | 40ms | 5.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureCommandWALExternalDependencies` |
| 10ms | 1.25% | 10ms | 1.25% | `github.com/snissn/gomap/TreeDB/db.(*DB).commandWALPoisonedError` |
| 10ms | 1.25% | 10ms | 1.25% | `github.com/snissn/gomap/TreeDB/db.(*DB).observeCommandWALAppend` |

### sequential_write (treedb)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/cpu_sequential_write_treedb.pprof`
- total samples: `880ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 130ms | 14.77% | 130ms | 14.77% | `internal/runtime/syscall/linux.Syscall6` |
| 50ms | 5.68% | 50ms | 5.68% | `sync/atomic.(*Int32).Add (inline)` |
| 30ms | 3.41% | 610ms | 69.32% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 30ms | 3.41% | 30ms | 3.41% | `runtime.nanotime (inline)` |
| 30ms | 3.41% | 70ms | 7.95% | `runtime.scanObject` |
| 30ms | 3.41% | 30ms | 3.41% | `time.runtimeNow` |
| 20ms | 2.27% | 430ms | 48.86% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 20ms | 2.27% | 20ms | 2.27% | `hash/crc32.ieeeCLMUL` |
| 20ms | 2.27% | 20ms | 2.27% | `hash/crc32.simpleUpdate (inline)` |
| 20ms | 2.27% | 20ms | 2.27% | `internal/sync.(*Mutex).Unlock (inline)` |
| 20ms | 2.27% | 20ms | 2.27% | `runtime.memmove` |
| 10ms | 1.14% | 10ms | 1.14% | `encoding/binary.littleEndian.Uint16 (inline)` |
| 10ms | 1.14% | 10ms | 1.14% | `github.com/pierrec/lz4/v4/internal/lz4block.(*Compressor).put` |
| 10ms | 1.14% | 60ms | 6.82% | `github.com/snissn/go-crc32-asm.Update` |
| 10ms | 1.14% | 30ms | 3.41% | `github.com/snissn/go-crc32-asm.checksumIEEE` |
| 10ms | 1.14% | 460ms | 52.27% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 10ms | 1.14% | 650ms | 73.86% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 10ms | 1.14% | 470ms | 53.41% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 10ms | 1.14% | 630ms | 71.59% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 10ms | 1.14% | 10ms | 1.14% | `github.com/snissn/gomap/TreeDB/caching.(*DB).beginMVCCInputCut (inline)` |
| 10ms | 1.14% | 10ms | 1.14% | `github.com/snissn/gomap/TreeDB/caching.(*DB).effectiveWALBytes` |
| 10ms | 1.14% | 40ms | 4.55% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func5` |
| 10ms | 1.14% | 620ms | 70.45% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 10ms | 1.14% | 50ms | 5.68% | `github.com/snissn/gomap/TreeDB/caching.memtableSetDirectBorrowValue` |
| 10ms | 1.14% | 10ms | 1.14% | `github.com/snissn/gomap/TreeDB/caching.stableOpMergeHeap.Swap` |

## Allocation Hotspots

### batch_delete (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_batch_delete_treedb.pprof`
- total: `26942`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 13109 | 48.66% | 13109 | 48.66% | `runtime/pprof.allFrames` |
| 5474 | 20.32% | 5650 | 20.97% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 5461 | 20.27% | 5461 | 20.27% | `runtime/pprof.(*pcDeck).tryAdd` |
| 2185 | 8.11% | 26404 | 98.00% | `runtime/pprof.printCountCycleProfile` |
| 404 | 1.50% | 404 | 1.50% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 171 | 0.63% | 171 | 0.63% | `runtime/pprof.(*protobuf).varint (inline)` |
| 1 | 0.00% | 487 | 1.81% | `main.runBenchmark.func26` |
| 0 | 0.00% | 410 | 1.52% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 410 | 1.52% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 410 | 1.52% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 410 | 1.52% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 410 | 1.52% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 404 | 1.50% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 404 | 1.50% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |
| 0 | 0.00% | 404 | 1.50% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 410 | 1.52% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 26935 | 100.00% | `main.main` |
| 0 | 0.00% | 26935 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 26404 | 98.00% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 26404 | 98.00% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 26935 | 100.00% | `runtime.main` |
| 0 | 0.00% | 26448 | 98.17% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 24220 | 89.90% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |

### batch_delete (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_batch_delete_treedb.pprof`
- total: `39489.85kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 18308.69kB | 46.36% | 18308.69kB | 46.36% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 7294.74kB | 18.47% | 7294.74kB | 18.47% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 3610.34kB | 9.14% | 5494.59kB | 13.91% | `compress/flate.NewWriter (inline)` |
| 2110.69kB | 5.34% | 2110.69kB | 5.34% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` |
| 1644.93kB | 4.17% | 29359.05kB | 74.35% | `main.runBenchmark.func26` |
| 1536.21kB | 3.89% | 1536.21kB | 3.89% | `runtime/pprof.allFrames` |
| 1301.24kB | 3.30% | 1884.25kB | 4.77% | `compress/flate.(*compressor).init` |
| 1044.31kB | 2.64% | 4916.19kB | 12.45% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 583.01kB | 1.48% | 583.01kB | 1.48% | `compress/flate.newDeflateFast (inline)` |
| 518.02kB | 1.31% | 518.02kB | 1.31% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 513.50kB | 1.30% | 513.50kB | 1.30% | `runtime/pprof.(*protobuf).varint (inline)` |
| 512.12kB | 1.30% | 6573.98kB | 16.65% | `runtime/pprof.printCountCycleProfile` |
| 512.05kB | 1.30% | 512.05kB | 1.30% | `runtime/pprof.(*pcDeck).tryAdd` |
| 0 | 0.00% | 5494.59kB | 13.91% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 2110.69kB | 5.34% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Delete` |
| 0 | 0.00% | 25603.43kB | 64.84% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 2110.69kB | 5.34% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).deleteView` |
| 0 | 0.00% | 25603.43kB | 64.84% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 25603.43kB | 64.84% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 25603.43kB | 64.84% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 25603.43kB | 64.84% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 7294.74kB | 18.47% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 18308.69kB | 46.36% | `github.com/snissn/gomap/TreeDB/caching.reserveAppendOnlyMemtableEntries` |
| 0 | 0.00% | 18308.69kB | 46.36% | `github.com/snissn/gomap/TreeDB/caching.reserveMemtableEntries` |
| 0 | 0.00% | 2110.69kB | 5.34% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).AppendDelete` |

### batch_random (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_batch_random_treedb.pprof`
- total: `14947`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 13107 | 87.69% | 13107 | 87.69% | `runtime/pprof.allFrames` |
| 910 | 6.09% | 910 | 6.09% | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatchWithCustody` |
| 346 | 2.31% | 346 | 2.31% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 213 | 1.43% | 213 | 1.43% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace` |
| 169 | 1.13% | 169 | 1.13% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` |
| 80 | 0.54% | 80 | 0.54% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 0 | 0.00% | 910 | 6.09% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatch` |
| 0 | 0.00% | 382 | 2.56% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Set` |
| 0 | 0.00% | 443 | 2.96% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 382 | 2.56% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setView (inline)` |
| 0 | 0.00% | 382 | 2.56% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setViewWithMVCCInput` |
| 0 | 0.00% | 443 | 2.96% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 910 | 6.09% | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatch (inline)` |
| 0 | 0.00% | 443 | 2.96% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 443 | 2.96% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 443 | 2.96% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 374 | 2.50% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchSet` |
| 0 | 0.00% | 382 | 2.56% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).AppendSetKnownZeroValue (inline)` |
| 0 | 0.00% | 382 | 2.56% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendSet` |
| 0 | 0.00% | 374 | 2.50% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryBorrowValueWithRevision` |
| 0 | 0.00% | 374 | 2.50% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 910 | 6.09% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).NewBatch` |
| 0 | 0.00% | 443 | 2.96% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 382 | 2.56% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Set` |
| 0 | 0.00% | 14931 | 99.89% | `main.main` |

### batch_random (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_batch_random_treedb.pprof`
- total: `116.32MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 60.35MB | 51.88% | 60.35MB | 51.88% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace` |
| 31.46MB | 27.04% | 31.46MB | 27.04% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 6.11MB | 5.25% | 6.11MB | 5.25% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 5.29MB | 4.55% | 6.39MB | 5.49% | `compress/flate.NewWriter (inline)` |
| 5.19MB | 4.46% | 5.19MB | 4.46% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 2.55MB | 2.19% | 2.55MB | 2.19% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` |
| 1.50MB | 1.29% | 1.50MB | 1.29% | `runtime/pprof.allFrames` |
| 1.27MB | 1.09% | 1.27MB | 1.09% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 0.53MB | 0.46% | 1.10MB | 0.95% | `compress/flate.(*compressor).init` |
| 0 | 0.00% | 6.39MB | 5.49% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 5.19MB | 4.46% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 5.19MB | 4.46% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared (inline)` |
| 0 | 0.00% | 5.19MB | 4.46% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 5.19MB | 4.46% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 5.19MB | 4.46% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 5.19MB | 4.46% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 5.19MB | 4.46% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 62.90MB | 54.08% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Set` |
| 0 | 0.00% | 43.26MB | 37.19% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 5.19MB | 4.46% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 62.90MB | 54.08% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setView (inline)` |
| 0 | 0.00% | 62.90MB | 54.08% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setViewWithMVCCInput` |
| 0 | 0.00% | 43.26MB | 37.19% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 5.19MB | 4.46% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write.func4` |
| 0 | 0.00% | 43.26MB | 37.19% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |

### batch_small_seq (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_batch_small_seq_treedb.pprof`
- total: `43673`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 21845 | 50.02% | 23677 | 54.21% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 10923 | 25.01% | 10981 | 25.14% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 3277 | 7.50% | 3277 | 7.50% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Close` |
| 3072 | 7.03% | 3072 | 7.03% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` |
| 1821 | 4.17% | 1821 | 4.17% | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatchWithCustody` |
| 1821 | 4.17% | 1832 | 4.19% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 745 | 1.71% | 745 | 1.71% | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` |
| 0 | 0.00% | 2566 | 5.88% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatch` |
| 0 | 0.00% | 3123 | 7.15% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Set` |
| 0 | 0.00% | 23677 | 54.21% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 3123 | 7.15% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setView (inline)` |
| 0 | 0.00% | 3123 | 7.15% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setViewWithMVCCInput` |
| 0 | 0.00% | 1821 | 4.17% | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatch (inline)` |
| 0 | 0.00% | 1832 | 4.19% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 1832 | 4.19% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 3123 | 7.15% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).AppendSetKnownZeroValue (inline)` |
| 0 | 0.00% | 3123 | 7.15% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendSet` |
| 0 | 0.00% | 2566 | 5.88% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).NewBatch` |
| 0 | 0.00% | 3277 | 7.50% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Close` |
| 0 | 0.00% | 23677 | 54.21% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 3123 | 7.15% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Set` |
| 0 | 0.00% | 43667 | 100.00% | `main.main` |
| 0 | 0.00% | 43667 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 32643 | 74.74% | `main.runBenchmark.func28` |
| 0 | 0.00% | 11011 | 25.21% | `main.writeRuntimeProfileSnapshot` |

### batch_small_seq (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_batch_small_seq_treedb.pprof`
- total: `74.54MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 60.61MB | 81.32% | 60.61MB | 81.32% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 2.44MB | 3.27% | 3.01MB | 4.03% | `compress/flate.(*compressor).init` |
| 2MB | 2.69% | 62.61MB | 84.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 1.76MB | 2.37% | 4.77MB | 6.40% | `compress/flate.NewWriter (inline)` |
| 1MB | 1.34% | 1MB | 1.34% | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatchWithCustody` |
| 1MB | 1.34% | 1MB | 1.34% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` |
| 1MB | 1.34% | 1MB | 1.34% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Close` |
| 1MB | 1.34% | 4.76MB | 6.39% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0.64MB | 0.85% | 0.64MB | 0.85% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 0.57MB | 0.76% | 0.57MB | 0.76% | `compress/flate.newDeflateFast (inline)` |
| 0.51MB | 0.68% | 0.51MB | 0.68% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 0.51MB | 0.68% | 0.51MB | 0.68% | `runtime/pprof.(*protobuf).string` |
| 0.50MB | 0.68% | 0.50MB | 0.68% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace` |
| 0.50MB | 0.67% | 0.50MB | 0.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` |
| 0.50MB | 0.67% | 63.11MB | 84.67% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 4.77MB | 6.40% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 1.50MB | 2.01% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatch` |
| 0 | 0.00% | 1.51MB | 2.02% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Set` |
| 0 | 0.00% | 63.11MB | 84.67% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 1.51MB | 2.02% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setView (inline)` |
| 0 | 0.00% | 1.51MB | 2.02% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setViewWithMVCCInput` |
| 0 | 0.00% | 1MB | 1.34% | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatch (inline)` |
| 0 | 0.00% | 62.61MB | 84.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 60.61MB | 81.32% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).tryApplySmallSelectedSortedShard` |
| 0 | 0.00% | 62.61MB | 84.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |

### batch_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_batch_write_treedb.pprof`
- total: `7431`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5461 | 73.49% | 5461 | 73.49% | `runtime/pprof.allFrames` |
| 1288 | 17.33% | 1315 | 17.70% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 260 | 3.50% | 260 | 3.50% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 128 | 1.72% | 128 | 1.72% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` |
| 98 | 1.32% | 98 | 1.32% | `runtime/pprof.(*protobuf).varint (inline)` |
| 78 | 1.05% | 78 | 1.05% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 7 | 0.09% | 41 | 0.55% | `compress/flate.NewWriter (inline)` |
| 1 | 0.01% | 467 | 6.28% | `main.runBenchmark.func6` |
| 0 | 0.00% | 465 | 6.26% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 465 | 6.26% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 465 | 6.26% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 128 | 1.72% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).copyValueToAppendOnlyDirectArena` |
| 0 | 0.00% | 465 | 6.26% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 465 | 6.26% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 388 | 5.22% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).ApplyCopySortedBatchWithValueCopierTrusted` |
| 0 | 0.00% | 260 | 3.50% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryLocked` |
| 0 | 0.00% | 465 | 6.26% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 7422 | 99.88% | `main.main` |
| 0 | 0.00% | 7422 | 99.88% | `main.runBenchmark` |
| 0 | 0.00% | 467 | 6.28% | `main.runBenchmark.func23` |
| 0 | 0.00% | 1262 | 16.98% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 1262 | 16.98% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 5693 | 76.61% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 5693 | 76.61% | `main.writeRuntimeProfileSnapshotTemp` |

### batch_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_batch_write_treedb.pprof`
- total: `114.20MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 59.29MB | 51.92% | 59.29MB | 51.92% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 28.52MB | 24.97% | 28.52MB | 24.97% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 5.29MB | 4.63% | 9.36MB | 8.20% | `compress/flate.NewWriter (inline)` |
| 4.58MB | 4.01% | 4.58MB | 4.01% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 3.10MB | 2.71% | 3.10MB | 2.71% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 2.97MB | 2.60% | 4.07MB | 3.56% | `compress/flate.(*compressor).init` |
| 2.70MB | 2.36% | 2.70MB | 2.36% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` |
| 1.61MB | 1.41% | 102.33MB | 89.60% | `main.runBenchmark.func6` |
| 1.30MB | 1.14% | 1.30MB | 1.14% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*fixedWAL).flushExtent` |
| 1.24MB | 1.08% | 1.24MB | 1.08% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchEntries` |
| 1.10MB | 0.96% | 1.10MB | 0.96% | `compress/flate.newDeflateFast (inline)` |
| 1.01MB | 0.88% | 6.80MB | 5.96% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 9.36MB | 8.20% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 1.24MB | 1.08% | `github.com/snissn/gomap/TreeDB.(*DB).NewBatchWithSize` |
| 0 | 0.00% | 32.41MB | 28.38% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 32.41MB | 28.38% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 32.41MB | 28.38% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared` |
| 0 | 0.00% | 32.41MB | 28.38% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared.func1` |
| 0 | 0.00% | 32.41MB | 28.38% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 32.41MB | 28.38% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 32.41MB | 28.38% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 99.48MB | 87.11% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 32.41MB | 28.38% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 99.48MB | 87.11% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 32.41MB | 28.38% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write.func4` |

### batch_write_steady (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_batch_write_steady_treedb.pprof`
- total: `14511`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4681 | 32.26% | 4681 | 32.26% | `syscall.ByteSliceFromString` |
| 4571 | 31.50% | 4609 | 31.76% | `github.com/snissn/gomap/TreeDB/db.scanCommandWALSegmentReader` |
| 2185 | 15.06% | 2185 | 15.06% | `runtime/pprof.allFrames` |
| 1173 | 8.08% | 1240 | 8.55% | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` |
| 745 | 5.13% | 745 | 5.13% | `github.com/snissn/gomap/TreeDB/internal/rootpublication.StabilizeStableNamespaceTokens` |
| 544 | 3.75% | 544 | 3.75% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 128 | 0.88% | 128 | 0.88% | `github.com/snissn/gomap/TreeDB/zipper.init.func2` |
| 107 | 0.74% | 107 | 0.74% | `github.com/snissn/gomap/TreeDB/db.(*leafGenerationRecordLengthIndex).add` |
| 100 | 0.69% | 100 | 0.69% | `bufio.NewReaderSize (inline)` |
| 1 | 0.01% | 11896 | 81.98% | `main.runBenchmark.func6` |
| 0 | 0.00% | 11295 | 77.84% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 11295 | 77.84% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 2849 | 19.63% | `github.com/snissn/gomap/TreeDB.(*DB).cleanupPublicCommandWALCheckpoint` |
| 0 | 0.00% | 599 | 4.13% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 599 | 4.13% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 599 | 4.13% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 544 | 3.75% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).copyValueToAppendOnlyDirectArena` |
| 0 | 0.00% | 599 | 4.13% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 599 | 4.13% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 10802 | 74.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |
| 0 | 0.00% | 3252 | 22.41% | `github.com/snissn/gomap/TreeDB/caching.(*DB).backendCheckpointBoundary` |
| 0 | 0.00% | 10802 | 74.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 2849 | 19.63% | `github.com/snissn/gomap/TreeDB/caching.(*DB).cleanupCommandWALCheckpoint` |
| 0 | 0.00% | 2849 | 19.63% | `github.com/snissn/gomap/TreeDB/caching.(*DB).cleanupCommandWALCheckpointBoundary` |
| 0 | 0.00% | 2849 | 19.63% | `github.com/snissn/gomap/TreeDB/caching.(*DB).cleanupCommandWALCheckpointTimed` |

### batch_write_steady (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_batch_write_steady_treedb.pprof`
- total: `1012.09MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 791.35MB | 78.19% | 795.60MB | 78.61% | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` |
| 80.40MB | 7.94% | 89.01MB | 8.79% | `github.com/snissn/gomap/TreeDB/db.scanCommandWALSegmentReader` |
| 46.79MB | 4.62% | 46.79MB | 4.62% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 31.11MB | 3.07% | 31.11MB | 3.07% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 17.02MB | 1.68% | 17.02MB | 1.68% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 7.07MB | 0.70% | 7.07MB | 0.70% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve` |
| 6.48MB | 0.64% | 6.48MB | 0.64% | `github.com/snissn/gomap/TreeDB/internal/commitlog.resizeReaderBuffer (inline)` |
| 6.38MB | 0.63% | 6.38MB | 0.63% | `bufio.NewReaderSize (inline)` |
| 2.64MB | 0.26% | 5.59MB | 0.55% | `compress/flate.NewWriter (inline)` |
| 1.61MB | 0.16% | 986MB | 97.42% | `main.runBenchmark.func6` |
| 0.54MB | 0.05% | 5.49MB | 0.54% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 887.23MB | 87.66% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 31.11MB | 3.07% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 31.11MB | 3.07% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 31.11MB | 3.07% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared` |
| 0 | 0.00% | 31.11MB | 3.07% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared.func1` |
| 0 | 0.00% | 887.23MB | 87.66% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 311.58MB | 30.79% | `github.com/snissn/gomap/TreeDB.(*DB).cleanupPublicCommandWALCheckpoint` |
| 0 | 0.00% | 31.11MB | 3.07% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 31.11MB | 3.07% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 31.11MB | 3.07% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 96.01MB | 9.49% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 31.11MB | 3.07% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 96.01MB | 9.49% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |

### dataset_write_random (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_dataset_write_random_treedb.pprof`
- total: `1186454`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 404146 | 34.06% | 1181016 | 99.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 393234 | 33.14% | 393234 | 33.14% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 196611 | 16.57% | 196611 | 16.57% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 182988 | 15.42% | 576222 | 48.57% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 0 | 0.00% | 1181016 | 99.54% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 772833 | 65.14% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 772833 | 65.14% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 772833 | 65.14% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 772833 | 65.14% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 772833 | 65.14% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 772833 | 65.14% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 772833 | 65.14% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 1181016 | 99.54% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 772833 | 65.14% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 1181016 | 99.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 1181016 | 99.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 772833 | 65.14% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 772833 | 65.14% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 576222 | 48.57% | `github.com/snissn/gomap/TreeDB/internal/commitlog.EncodeRawKVBatchPayload` |
| 0 | 0.00% | 1181016 | 99.54% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 1183231 | 99.73% | `main.main` |
| 0 | 0.00% | 1183231 | 99.73% | `main.runBenchmark` |
| 0 | 0.00% | 1181016 | 99.54% | `main.runBenchmark.func21` |
| 0 | 0.00% | 1183231 | 99.73% | `runtime.main` |

### dataset_write_random (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_dataset_write_random_treedb.pprof`
- total: `274.37MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 147MB | 53.58% | 147MB | 53.58% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 33.51MB | 12.21% | 51.51MB | 18.77% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 29.40MB | 10.72% | 29.40MB | 10.72% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 18MB | 6.56% | 18MB | 6.56% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 8.50MB | 3.10% | 261.84MB | 95.44% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 8.21MB | 2.99% | 8.21MB | 2.99% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` |
| 8.21MB | 2.99% | 8.21MB | 2.99% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 5.02MB | 1.83% | 5.02MB | 1.83% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 4.41MB | 1.61% | 7.95MB | 2.90% | `compress/flate.NewWriter (inline)` |
| 3MB | 1.09% | 3MB | 1.09% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 1.91MB | 0.69% | 3.54MB | 1.29% | `compress/flate.(*compressor).init` |
| 1.85MB | 0.67% | 1.85MB | 0.67% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked` |
| 1.63MB | 0.60% | 1.63MB | 0.60% | `compress/flate.newDeflateFast (inline)` |
| 1.23MB | 0.45% | 3.08MB | 1.12% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestSnapshotLocked` |
| 1MB | 0.37% | 30.40MB | 11.08% | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` |
| 0 | 0.00% | 7.95MB | 2.90% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 261.84MB | 95.44% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 54.51MB | 19.87% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 54.51MB | 19.87% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 54.51MB | 19.87% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 54.51MB | 19.87% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 54.51MB | 19.87% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 54.51MB | 19.87% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 54.51MB | 19.87% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 261.84MB | 95.44% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |

### dataset_write_sorted (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_dataset_write_sorted_treedb.pprof`
- total: `1126828`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 432556 | 38.39% | 432556 | 38.39% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 283995 | 25.20% | 1122103 | 99.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 204837 | 18.18% | 637393 | 56.57% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 196611 | 17.45% | 196611 | 17.45% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 0 | 0.00% | 1122103 | 99.58% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 834004 | 74.01% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 834004 | 74.01% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 834004 | 74.01% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 834004 | 74.01% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 834004 | 74.01% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 834004 | 74.01% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 834004 | 74.01% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 1122103 | 99.58% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 834004 | 74.01% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 1122103 | 99.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 1122103 | 99.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 834004 | 74.01% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 834004 | 74.01% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 637393 | 56.57% | `github.com/snissn/gomap/TreeDB/internal/commitlog.EncodeRawKVBatchPayload` |
| 0 | 0.00% | 1122103 | 99.58% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 1122289 | 99.60% | `main.main` |
| 0 | 0.00% | 1122289 | 99.60% | `main.runBenchmark` |
| 0 | 0.00% | 1122103 | 99.58% | `main.runBenchmark.func22` |
| 0 | 0.00% | 1122289 | 99.60% | `runtime.main` |

### dataset_write_sorted (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_dataset_write_sorted_treedb.pprof`
- total: `81.35MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 37.51MB | 46.11% | 56.51MB | 69.46% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 19MB | 23.36% | 19MB | 23.36% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 8.02MB | 9.85% | 8.02MB | 9.85% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` |
| 6MB | 7.38% | 73.52MB | 90.38% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 3MB | 3.69% | 3MB | 3.69% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 2.64MB | 3.25% | 4.31MB | 5.30% | `compress/flate.NewWriter (inline)` |
| 2.50MB | 3.08% | 2.50MB | 3.08% | `runtime.mallocgc` |
| 1.14MB | 1.40% | 1.14MB | 1.40% | `compress/flate.newDeflateFast (inline)` |
| 0.53MB | 0.65% | 1.67MB | 2.05% | `compress/flate.(*compressor).init` |
| 0.51MB | 0.62% | 0.51MB | 0.62% | `runtime/pprof.(*profileBuilder).stringIndex` |
| 0.50MB | 0.62% | 0.50MB | 0.62% | `slices.Grow[go.shape.[]uint8,go.shape.uint8]` |
| 0 | 0.00% | 4.31MB | 5.30% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 73.52MB | 90.38% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 59.51MB | 73.15% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 59.51MB | 73.15% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 59.51MB | 73.15% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 59.51MB | 73.15% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 59.51MB | 73.15% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 59.51MB | 73.15% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 59.51MB | 73.15% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 73.52MB | 90.38% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 59.51MB | 73.15% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 73.52MB | 90.38% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 73.52MB | 90.38% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 59.51MB | 73.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |

### full_scan (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_full_scan_treedb.pprof`
- total: `59158`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 49155 | 83.09% | 49155 | 83.09% | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` |
| 9832 | 16.62% | 9832 | 16.62% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 49155 | 83.09% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 0 | 0.00% | 49155 | 83.09% | `github.com/snissn/gomap/TreeDB/internal/merging.(*MergingIterator).Next` |
| 0 | 0.00% | 49155 | 83.09% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafKeyFlagsView` |
| 0 | 0.00% | 49155 | 83.09% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafKeyFlagsViewColumnarPrefixV2 (inline)` |
| 0 | 0.00% | 49155 | 83.09% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 0 | 0.00% | 49155 | 83.09% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).Next` |
| 0 | 0.00% | 49155 | 83.09% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).getLeafKeyFlags` |
| 0 | 0.00% | 49155 | 83.09% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadCurrent` |
| 0 | 0.00% | 59156 | 100.00% | `main.main` |
| 0 | 0.00% | 59156 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 49200 | 83.17% | `main.runBenchmark.func37` |
| 0 | 0.00% | 7677 | 12.98% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 7677 | 12.98% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 2279 | 3.85% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 2279 | 3.85% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 59156 | 100.00% | `runtime.main` |
| 0 | 0.00% | 9956 | 16.83% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 9851 | 16.65% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2279 | 3.85% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 7677 | 12.98% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 2246 | 3.80% | `runtime/pprof.writeBlock` |
| 0 | 0.00% | 7677 | 12.98% | `runtime/pprof.writeHeapInternal` |
| 0 | 0.00% | 7677 | 12.98% | `runtime/pprof.writeHeapProto` |

### full_scan (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_full_scan_treedb.pprof`
- total: `20.78MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 4.76MB | 22.92% | 4.76MB | 22.92% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked` |
| 3.58MB | 17.21% | 8.34MB | 40.13% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestSnapshotLocked` |
| 3.53MB | 16.97% | 4.80MB | 23.09% | `compress/flate.NewWriter (inline)` |
| 3MB | 14.44% | 3MB | 14.44% | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` |
| 2.06MB | 9.93% | 2.06MB | 9.93% | `runtime/pprof.(*protobuf).string (inline)` |
| 1.50MB | 7.22% | 1.50MB | 7.22% | `runtime/pprof.allFrames` |
| 1.27MB | 6.12% | 1.27MB | 6.12% | `compress/flate.(*compressor).init` |
| 1.08MB | 5.20% | 3.48MB | 16.74% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 4.80MB | 23.09% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 8.34MB | 40.13% | `github.com/snissn/gomap/TreeDB.(*DB).Iterator` |
| 0 | 0.00% | 8.34MB | 40.13% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Iterator` |
| 0 | 0.00% | 3MB | 14.44% | `github.com/snissn/gomap/TreeDB/db.(*DBIterator).Next` |
| 0 | 0.00% | 8.34MB | 40.13% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).NewIterator` |
| 0 | 0.00% | 3MB | 14.44% | `github.com/snissn/gomap/TreeDB/internal/merging.(*MergingIterator).Next` |
| 0 | 0.00% | 3MB | 14.44% | `github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafKeyFlagsView` |
| 0 | 0.00% | 3MB | 14.44% | `github.com/snissn/gomap/TreeDB/node.(*Node).getLeafKeyFlagsViewColumnarPrefixV2 (inline)` |
| 0 | 0.00% | 3MB | 14.44% | `github.com/snissn/gomap/TreeDB/node.(*Node).leafColumnarPrefixV2FullKeyFlagsAt` |
| 0 | 0.00% | 3MB | 14.44% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).Next` |
| 0 | 0.00% | 3MB | 14.44% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).getLeafKeyFlags` |
| 0 | 0.00% | 3MB | 14.44% | `github.com/snissn/gomap/TreeDB/tree.(*Iterator).loadCurrent` |
| 0 | 0.00% | 8.34MB | 40.13% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Iterator` |
| 0 | 0.00% | 20.14MB | 96.94% | `main.main` |
| 0 | 0.00% | 20.14MB | 96.94% | `main.runBenchmark` |
| 0 | 0.00% | 11.34MB | 54.57% | `main.runBenchmark.func37` |
| 0 | 0.00% | 3.47MB | 16.70% | `main.writeAllocsSnapshot` |

### prefix_scan (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_prefix_scan_treedb.pprof`
- total: `18037`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 8193 | 45.42% | 8193 | 45.42% | `github.com/snissn/gomap/TreeDB/caching.newValueLogIterator (inline)` |
| 4370 | 24.23% | 4370 | 24.23% | `runtime/pprof.allFrames` |
| 3641 | 20.19% | 3641 | 20.19% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).NewIterator` |
| 1025 | 5.68% | 1025 | 5.68% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 585 | 3.24% | 13444 | 74.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Iterator` |
| 0 | 0.00% | 13444 | 74.54% | `github.com/snissn/gomap/TreeDB.(*DB).Iterator` |
| 0 | 0.00% | 1025 | 5.68% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 1025 | 5.68% | `github.com/snissn/gomap/TreeDB/db.(*DB).Iterator` |
| 0 | 0.00% | 1025 | 5.68% | `github.com/snissn/gomap/TreeDB/db.(*DB).IteratorWithOptions` |
| 0 | 0.00% | 1025 | 5.68% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotOrErr` |
| 0 | 0.00% | 1025 | 5.68% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 13444 | 74.54% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Iterator` |
| 0 | 0.00% | 17970 | 99.63% | `main.main` |
| 0 | 0.00% | 17970 | 99.63% | `main.runBenchmark` |
| 0 | 0.00% | 13444 | 74.54% | `main.runBenchmark.func39` |
| 0 | 0.00% | 2214 | 12.27% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2214 | 12.27% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 2312 | 12.82% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 2312 | 12.82% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 17970 | 99.63% | `runtime.main` |
| 0 | 0.00% | 4526 | 25.09% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 4413 | 24.47% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2312 | 12.82% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 2214 | 12.27% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 2225 | 12.34% | `runtime/pprof.writeBlock` |

### prefix_scan (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_prefix_scan_treedb.pprof`
- total: `15600.70kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3610.34kB | 23.14% | 7817.56kB | 50.11% | `compress/flate.NewWriter (inline)` |
| 3041.20kB | 19.49% | 4207.21kB | 26.97% | `compress/flate.(*compressor).init` |
| 1166.01kB | 7.47% | 1166.01kB | 7.47% | `compress/flate.newDeflateFast (inline)` |
| 1045.40kB | 6.70% | 1045.40kB | 6.70% | `runtime/pprof.(*protobuf).string (inline)` |
| 1045.40kB | 6.70% | 1045.40kB | 6.70% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 1025kB | 6.57% | 1025kB | 6.57% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 1024.23kB | 6.57% | 1024.23kB | 6.57% | `runtime/pprof.allFrames` |
| 1024.12kB | 6.56% | 1024.12kB | 6.56% | `github.com/snissn/gomap/TreeDB/caching.newValueLogIterator (inline)` |
| 553.04kB | 3.54% | 5564.52kB | 35.67% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 525.43kB | 3.37% | 525.43kB | 3.37% | `runtime/pprof.(*profileBuilder).stringIndex (inline)` |
| 516.01kB | 3.31% | 516.01kB | 3.31% | `runtime/pprof.(*profMap).lookup` |
| 512.44kB | 3.28% | 3073.63kB | 19.70% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Iterator` |
| 512.07kB | 3.28% | 512.07kB | 3.28% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).NewIterator` |
| 0 | 0.00% | 7817.56kB | 50.11% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 3073.63kB | 19.70% | `github.com/snissn/gomap/TreeDB.(*DB).Iterator` |
| 0 | 0.00% | 1025kB | 6.57% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 1025kB | 6.57% | `github.com/snissn/gomap/TreeDB/db.(*DB).Iterator` |
| 0 | 0.00% | 1025kB | 6.57% | `github.com/snissn/gomap/TreeDB/db.(*DB).IteratorWithOptions` |
| 0 | 0.00% | 1025kB | 6.57% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotOrErr` |
| 0 | 0.00% | 1025kB | 6.57% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 3073.63kB | 19.70% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Iterator` |
| 0 | 0.00% | 14434.07kB | 92.52% | `main.main` |
| 0 | 0.00% | 14434.07kB | 92.52% | `main.runBenchmark` |
| 0 | 0.00% | 3073.63kB | 19.70% | `main.runBenchmark.func39` |
| 0 | 0.00% | 2520.41kB | 16.16% | `main.writeAllocsSnapshot` |

### random_delete (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_delete_treedb.pprof`
- total: `1132262`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 367019 | 32.41% | 367019 | 32.41% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 294917 | 26.05% | 1120703 | 98.98% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` |
| 262148 | 23.15% | 262148 | 23.15% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 196614 | 17.36% | 563633 | 49.78% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 7646 | 0.68% | 7646 | 0.68% | `runtime/pprof.allFrames` |
| 0 | 0.00% | 1120703 | 98.98% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 825781 | 72.93% | `github.com/snissn/gomap/TreeDB.(*DB).Delete.func1` |
| 0 | 0.00% | 825781 | 72.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 825781 | 72.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 825781 | 72.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 825781 | 72.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 825781 | 72.93% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 825781 | 72.93% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 825781 | 72.93% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 1120703 | 98.98% | `github.com/snissn/gomap/TreeDB/caching.(*DB).DeleteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 825781 | 72.93% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 563633 | 49.78% | `github.com/snissn/gomap/TreeDB/internal/commitlog.EncodeRawKVBatchPayload` |
| 0 | 0.00% | 1120703 | 98.98% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Delete` |
| 0 | 0.00% | 1127885 | 99.61% | `main.main` |
| 0 | 0.00% | 1127885 | 99.61% | `main.runBenchmark` |
| 0 | 0.00% | 1120703 | 98.98% | `main.runBenchmark.func31` |
| 0 | 0.00% | 1127885 | 99.61% | `runtime.main` |

### random_delete (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_delete_treedb.pprof`
- total: `114.95MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 71.98MB | 62.62% | 71.98MB | 62.62% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 18MB | 15.66% | 18MB | 15.66% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 6MB | 5.22% | 24MB | 20.88% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 6MB | 5.22% | 105.99MB | 92.20% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` |
| 4MB | 3.48% | 4MB | 3.48% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 3.53MB | 3.07% | 5.83MB | 5.07% | `compress/flate.NewWriter (inline)` |
| 1.80MB | 1.57% | 2.30MB | 2.00% | `compress/flate.(*compressor).init` |
| 1MB | 0.87% | 1MB | 0.87% | `runtime/pprof.allFrames` |
| 0.64MB | 0.55% | 0.64MB | 0.55% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 0 | 0.00% | 5.83MB | 5.07% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 105.99MB | 92.20% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 28MB | 24.36% | `github.com/snissn/gomap/TreeDB.(*DB).Delete.func1` |
| 0 | 0.00% | 28MB | 24.36% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 28MB | 24.36% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 28MB | 24.36% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 28MB | 24.36% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 28MB | 24.36% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 28MB | 24.36% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 28MB | 24.36% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 105.99MB | 92.20% | `github.com/snissn/gomap/TreeDB/caching.(*DB).DeleteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 71.98MB | 62.62% | `github.com/snissn/gomap/TreeDB/caching.memtableBatchDelete` |
| 0 | 0.00% | 28MB | 24.36% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 24MB | 20.88% | `github.com/snissn/gomap/TreeDB/internal/commitlog.EncodeRawKVBatchPayload` |
| 0 | 0.00% | 71.98MB | 62.62% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).SetEntryWithRevision` |

### random_read (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_read_treedb.pprof`
- total: `125`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 55 | 44.00% | 77 | 61.60% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 32 | 25.60% | 32 | 25.60% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 15 | 12.00% | 28 | 22.40% | `compress/flate.(*compressor).init` |
| 13 | 10.40% | 13 | 10.40% | `compress/flate.newDeflateFast (inline)` |
| 10 | 8.00% | 38 | 30.40% | `compress/flate.NewWriter (inline)` |
| 0 | 0.00% | 38 | 30.40% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 115 | 92.00% | `main.main` |
| 0 | 0.00% | 115 | 92.00% | `main.runBenchmark` |
| 0 | 0.00% | 6 | 4.80% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 6 | 4.80% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 109 | 87.20% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 109 | 87.20% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 32 | 25.60% | `os.ReadFile` |
| 0 | 0.00% | 32 | 25.60% | `os.readFileContents` |
| 0 | 0.00% | 115 | 92.00% | `runtime.main` |
| 0 | 0.00% | 115 | 92.00% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 77 | 61.60% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 10 | 8.00% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 28 | 22.40% | `runtime/pprof.(*profileBuilder).flush` |
| 0 | 0.00% | 6 | 4.80% | `runtime/pprof.(*profileBuilder).pbSample` |
| 0 | 0.00% | 32 | 25.60% | `runtime/pprof.(*profileBuilder).readMapping` |
| 0 | 0.00% | 32 | 25.60% | `runtime/pprof.newProfileBuilder` |
| 0 | 0.00% | 109 | 87.20% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 10 | 8.00% | `runtime/pprof.profileWriter` |
| 0 | 0.00% | 6 | 4.80% | `runtime/pprof.writeAlloc` |

### random_read (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_read_treedb.pprof`
- total: `10697.75kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5415.52kB | 50.62% | 9661.07kB | 90.31% | `compress/flate.NewWriter (inline)` |
| 2496.53kB | 23.34% | 4245.55kB | 39.69% | `compress/flate.(*compressor).init` |
| 1749.02kB | 16.35% | 1749.02kB | 16.35% | `compress/flate.newDeflateFast (inline)` |
| 520.04kB | 4.86% | 520.04kB | 4.86% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 516.64kB | 4.83% | 7244.86kB | 67.72% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 9661.07kB | 90.31% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 9250.50kB | 86.47% | `main.main` |
| 0 | 0.00% | 9250.50kB | 86.47% | `main.runBenchmark` |
| 0 | 0.00% | 1485.59kB | 13.89% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 1485.59kB | 13.89% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 7764.90kB | 72.58% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 7764.90kB | 72.58% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 520.04kB | 4.86% | `os.ReadFile` |
| 0 | 0.00% | 520.04kB | 4.86% | `os.readFileContents` |
| 0 | 0.00% | 9250.50kB | 86.47% | `runtime.main` |
| 0 | 0.00% | 9250.50kB | 86.47% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 7244.86kB | 67.72% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 1447.25kB | 13.53% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 8213.82kB | 76.78% | `runtime/pprof.(*profileBuilder).flush` |
| 0 | 0.00% | 1485.59kB | 13.89% | `runtime/pprof.(*profileBuilder).pbSample` |
| 0 | 0.00% | 520.04kB | 4.86% | `runtime/pprof.(*profileBuilder).readMapping` |
| 0 | 0.00% | 520.04kB | 4.86% | `runtime/pprof.newProfileBuilder` |
| 0 | 0.00% | 7764.90kB | 72.58% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 1447.25kB | 13.53% | `runtime/pprof.profileWriter` |
| 0 | 0.00% | 1485.59kB | 13.89% | `runtime/pprof.writeAlloc` |

### random_read_batch (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_read_batch_treedb.pprof`
- total: `25483`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 22941 | 90.02% | 22941 | 90.02% | `runtime/pprof.allFrames` |
| 2185 | 8.57% | 10049 | 39.43% | `runtime/pprof.printCountCycleProfile` |
| 128 | 0.50% | 128 | 0.50% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getManyViewFromPublishedRootPointShards` |
| 8 | 0.03% | 136 | 0.53% | `main.runBenchmark.func35` |
| 0 | 0.00% | 23295 | 91.41% | `main.main` |
| 0 | 0.00% | 23295 | 91.41% | `main.runBenchmark` |
| 0 | 0.00% | 13110 | 51.45% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 13110 | 51.45% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 10049 | 39.43% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 10049 | 39.43% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 23295 | 91.41% | `runtime.main` |
| 0 | 0.00% | 23159 | 90.88% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 23012 | 90.30% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2280 | 8.95% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 2188 | 8.59% | `runtime/pprof.profileWriter` |
| 0 | 0.00% | 13110 | 51.45% | `runtime/pprof.writeAlloc` |
| 0 | 0.00% | 13110 | 51.45% | `runtime/pprof.writeHeapInternal` |
| 0 | 0.00% | 13110 | 51.45% | `runtime/pprof.writeHeapProto` |
| 0 | 0.00% | 10000 | 39.24% | `runtime/pprof.writeMutex` |
| 0 | 0.00% | 10049 | 39.43% | `runtime/pprof.writeProfileInternal` |

### random_read_batch (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_read_batch_treedb.pprof`
- total: `46552.64kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30234.73kB | 64.95% | 30234.73kB | 64.95% | `github.com/snissn/gomap/TreeDB/caching.(*DB).getManyViewFromPublishedRootPointShards` |
| 5415.52kB | 11.63% | 8495.06kB | 18.25% | `compress/flate.NewWriter (inline)` |
| 3072.49kB | 6.60% | 3072.49kB | 6.60% | `runtime/pprof.allFrames` |
| 1951.87kB | 4.19% | 3079.54kB | 6.62% | `compress/flate.(*compressor).init` |
| 1603.95kB | 3.45% | 4856.38kB | 10.43% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 1571.60kB | 3.38% | 1571.60kB | 3.38% | `runtime/pprof.(*protobuf).string (inline)` |
| 1127.67kB | 2.42% | 1127.67kB | 2.42% | `compress/flate.newDeflateFast (inline)` |
| 544.67kB | 1.17% | 30779.40kB | 66.12% | `main.runBenchmark.func35` |
| 518.02kB | 1.11% | 518.02kB | 1.11% | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` |
| 512.12kB | 1.10% | 11269.12kB | 24.21% | `runtime/pprof.printCountCycleProfile` |
| 0 | 0.00% | 8495.06kB | 18.25% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 30234.73kB | 64.95% | `github.com/snissn/gomap/TreeDB.(*DB).GetManyView` |
| 0 | 0.00% | 30234.73kB | 64.95% | `github.com/snissn/gomap/TreeDB/caching.(*DB).GetManyView` |
| 0 | 0.00% | 30234.73kB | 64.95% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).GetManyView` |
| 0 | 0.00% | 44487.31kB | 95.56% | `main.main` |
| 0 | 0.00% | 44487.31kB | 95.56% | `main.runBenchmark` |
| 0 | 0.00% | 2438.80kB | 5.24% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2438.80kB | 5.24% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 11269.12kB | 24.21% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 11269.12kB | 24.21% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 518.02kB | 1.11% | `os.ReadFile` |
| 0 | 0.00% | 518.02kB | 1.11% | `os.readFileContents` |
| 0 | 0.00% | 44487.31kB | 95.56% | `runtime.main` |
| 0 | 0.00% | 13707.91kB | 29.45% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 7928.87kB | 17.03% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |

### random_read_parallel (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_read_parallel_treedb.pprof`
- total: `6927`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 6555 | 94.63% | 6555 | 94.63% | `runtime/pprof.allFrames` |
| 228 | 3.29% | 228 | 3.29% | `compress/flate.(*huffmanEncoder).generate` |
| 98 | 1.41% | 98 | 1.41% | `runtime/pprof.(*protobuf).varint (inline)` |
| 21 | 0.30% | 41 | 0.59% | `compress/flate.(*compressor).init` |
| 5 | 0.07% | 46 | 0.66% | `compress/flate.NewWriter (inline)` |
| 0 | 0.00% | 228 | 3.29% | `compress/flate.(*Writer).Write (inline)` |
| 0 | 0.00% | 228 | 3.29% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 228 | 3.29% | `compress/flate.(*compressor).write` |
| 0 | 0.00% | 228 | 3.29% | `compress/flate.(*huffmanBitWriter).indexTokens` |
| 0 | 0.00% | 228 | 3.29% | `compress/flate.(*huffmanBitWriter).writeBlockDynamic` |
| 0 | 0.00% | 274 | 3.96% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 4737 | 68.38% | `main.main` |
| 0 | 0.00% | 4737 | 68.38% | `main.runBenchmark` |
| 0 | 0.00% | 2417 | 34.89% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2417 | 34.89% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 2320 | 33.49% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 2320 | 33.49% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 4737 | 68.38% | `runtime.main` |
| 0 | 0.00% | 4737 | 68.38% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 6681 | 96.45% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2418 | 34.91% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 126 | 1.82% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 98 | 1.41% | `runtime/pprof.(*protobuf).uint64 (inline)` |
| 0 | 0.00% | 98 | 1.41% | `runtime/pprof.(*protobuf).uint64Opt (inline)` |

### random_read_parallel (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_read_parallel_treedb.pprof`
- total: `9586.74kB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3610.34kB | 37.66% | 7022.64kB | 73.25% | `compress/flate.NewWriter (inline)` |
| 1739.95kB | 18.15% | 3412.29kB | 35.59% | `compress/flate.(*compressor).init` |
| 1672.34kB | 17.44% | 1672.34kB | 17.44% | `compress/flate.newDeflateFast (inline)` |
| 1536.35kB | 16.03% | 1536.35kB | 16.03% | `runtime/pprof.allFrames` |
| 514.63kB | 5.37% | 514.63kB | 5.37% | `runtime/pprof.(*protobuf).varint (inline)` |
| 513.12kB | 5.35% | 513.12kB | 5.35% | `compress/flate.(*huffmanEncoder).generate` |
| 0 | 0.00% | 513.12kB | 5.35% | `compress/flate.(*Writer).Write (inline)` |
| 0 | 0.00% | 513.12kB | 5.35% | `compress/flate.(*compressor).encSpeed` |
| 0 | 0.00% | 513.12kB | 5.35% | `compress/flate.(*compressor).write` |
| 0 | 0.00% | 513.12kB | 5.35% | `compress/flate.(*huffmanBitWriter).indexTokens` |
| 0 | 0.00% | 513.12kB | 5.35% | `compress/flate.(*huffmanBitWriter).writeBlockDynamic` |
| 0 | 0.00% | 7535.76kB | 78.61% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 7589.03kB | 79.16% | `main.main` |
| 0 | 0.00% | 7589.03kB | 79.16% | `main.runBenchmark` |
| 0 | 0.00% | 2578.45kB | 26.90% | `main.writeAllocsSnapshot` |
| 0 | 0.00% | 2578.45kB | 26.90% | `main.writeAllocsSnapshotTemp` |
| 0 | 0.00% | 5010.58kB | 52.27% | `main.writeRuntimeProfileSnapshot` |
| 0 | 0.00% | 5010.58kB | 52.27% | `main.writeRuntimeProfileSnapshotTemp` |
| 0 | 0.00% | 7589.03kB | 79.16% | `runtime.main` |
| 0 | 0.00% | 7589.03kB | 79.16% | `runtime/pprof.(*Profile).WriteTo` |
| 0 | 0.00% | 5490.15kB | 57.27% | `runtime/pprof.(*profileBuilder).appendLocsForStack` |
| 0 | 0.00% | 2510.83kB | 26.19% | `runtime/pprof.(*profileBuilder).build` |
| 0 | 0.00% | 3953.80kB | 41.24% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 5537.04kB | 57.76% | `runtime/pprof.(*profileBuilder).flush` |
| 0 | 0.00% | 2097.87kB | 21.88% | `runtime/pprof.(*profileBuilder).pbSample` |

### random_read_parallel_acquire_snapshot (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_read_parallel_acquire_snapshot_treedb.pprof`
- total: `4788576`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2427200 | 50.69% | 2427200 | 50.69% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 2343698 | 48.94% | 2343698 | 48.94% | `github.com/snissn/gomap/TreeDB/caching.getSnapshot` |
| 0 | 0.00% | 4770898 | 99.63% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 4770898 | 99.63% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2427200 | 50.69% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2427200 | 50.69% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 4770898 | 99.63% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).AcquireReadSnapshot` |
| 0 | 0.00% | 4770898 | 99.63% | `main.runBenchmark.func34.1` |
| 0 | 0.00% | 4770898 | 99.63% | `main.runBenchmark.func34.2` |

### random_read_parallel_acquire_snapshot (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_read_parallel_acquire_snapshot_treedb.pprof`
- total: `3167.78MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2370.31MB | 74.83% | 2370.31MB | 74.83% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 786.76MB | 24.84% | 786.76MB | 24.84% | `github.com/snissn/gomap/TreeDB/caching.getSnapshot` |
| 0 | 0.00% | 3157.08MB | 99.66% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 3157.08MB | 99.66% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2370.31MB | 74.83% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2370.31MB | 74.83% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 3157.08MB | 99.66% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).AcquireReadSnapshot` |
| 0 | 0.00% | 3157.08MB | 99.66% | `main.runBenchmark.func34.1` |
| 0 | 0.00% | 3157.08MB | 99.66% | `main.runBenchmark.func34.2` |

### random_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_write_treedb.pprof`
- total: `1195146`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 511199 | 42.77% | 511199 | 42.77% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 262149 | 21.93% | 1194427 | 99.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 229379 | 19.19% | 229379 | 19.19% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 190083 | 15.90% | 701282 | 58.68% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 0 | 0.00% | 1194427 | 99.94% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 930661 | 77.87% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 930661 | 77.87% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 930661 | 77.87% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 930661 | 77.87% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 930661 | 77.87% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 930661 | 77.87% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 930661 | 77.87% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 1194427 | 99.94% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 930661 | 77.87% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 1194427 | 99.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 1194427 | 99.94% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 930661 | 77.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 930661 | 77.87% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 701282 | 58.68% | `github.com/snissn/gomap/TreeDB/internal/commitlog.EncodeRawKVBatchPayload` |
| 0 | 0.00% | 1194427 | 99.94% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 1194619 | 100.00% | `main.main` |
| 0 | 0.00% | 1194619 | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 1194427 | 99.94% | `main.runBenchmark.func19` |
| 0 | 0.00% | 1194619 | 100.00% | `runtime.main` |

### random_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_random_write_treedb.pprof`
- total: `135.78MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 30.14MB | 22.20% | 30.14MB | 22.20% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 29MB | 21.36% | 48.01MB | 35.35% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 21.15MB | 15.57% | 21.15MB | 15.57% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 19MB | 13.99% | 19MB | 13.99% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 14.76MB | 10.87% | 14.76MB | 10.87% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` |
| 5.50MB | 4.05% | 124.58MB | 91.75% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 4.41MB | 3.25% | 8.55MB | 6.30% | `compress/flate.NewWriter (inline)` |
| 3.50MB | 2.58% | 3.50MB | 2.58% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 2.44MB | 1.80% | 4.15MB | 3.05% | `compress/flate.(*compressor).init` |
| 1.71MB | 1.26% | 1.71MB | 1.26% | `compress/flate.newDeflateFast (inline)` |
| 1.53MB | 1.12% | 1.53MB | 1.12% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` |
| 1.52MB | 1.12% | 5.05MB | 3.72% | `runtime/pprof.(*profileBuilder).emitLocation` |
| 0 | 0.00% | 8.55MB | 6.30% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 124.58MB | 91.75% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 51.51MB | 37.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 51.51MB | 37.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 51.51MB | 37.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 51.51MB | 37.93% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 51.51MB | 37.93% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 51.51MB | 37.93% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 51.51MB | 37.93% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 124.58MB | 91.75% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 51.51MB | 37.93% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 124.58MB | 91.75% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 124.58MB | 91.75% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |

### sequential_write (treedb/alloc_objects)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_sequential_write_treedb.pprof`
- total: `1122504`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 393235 | 35.03% | 393235 | 35.03% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 262148 | 23.35% | 262148 | 23.35% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 235965 | 21.02% | 629200 | 56.05% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 218457 | 19.46% | 1115260 | 99.35% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 455 | 0.04% | 6922 | 0.62% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).applySpanNativeWithPrepared.func2` |
| 0 | 0.00% | 1115260 | 99.35% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 896029 | 79.82% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 896029 | 79.82% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 896029 | 79.82% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 896029 | 79.82% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 896029 | 79.82% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 896029 | 79.82% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 896029 | 79.82% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 1115260 | 99.35% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 896029 | 79.82% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 1115260 | 99.35% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |

### sequential_write (treedb/alloc_space)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/allocs_sequential_write_treedb.pprof`
- total: `156.42MB`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 36.01MB | 23.02% | 56.01MB | 35.80% | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` |
| 23.21MB | 14.84% | 23.21MB | 14.84% | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` |
| 20.08MB | 12.84% | 20.08MB | 12.84% | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` |
| 20MB | 12.79% | 20MB | 12.79% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` |
| 11.49MB | 7.34% | 11.49MB | 7.34% | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` |
| 8.24MB | 5.27% | 8.24MB | 5.27% | `github.com/snissn/gomap/TreeDB/zipper.acquireSpanNativeLeafLogPayloadArena` |
| 5.02MB | 3.21% | 5.02MB | 3.21% | `github.com/snissn/gomap/TreeDB/zipper.init.func2` |
| 4.50MB | 2.88% | 100MB | 63.93% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 4MB | 2.56% | 4MB | 2.56% | `github.com/snissn/gomap/TreeDB/internal/valuelog.getWriterAppendBuf` |
| 4MB | 2.56% | 4MB | 2.56% | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` |
| 3.53MB | 2.26% | 3.53MB | 2.26% | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve` |
| 3.13MB | 2.00% | 3.13MB | 2.00% | `github.com/snissn/gomap/TreeDB/zipper.(*ReadOnlyPrepareResult).ensureInitialCapacity` |
| 2.64MB | 1.69% | 4.95MB | 3.16% | `compress/flate.NewWriter (inline)` |
| 2.28MB | 1.45% | 2.28MB | 1.45% | `github.com/snissn/gomap/TreeDB/caching.getEntrySlice` |
| 1.67MB | 1.07% | 1.67MB | 1.07% | `compress/flate.newDeflateFast (inline)` |
| 1.27MB | 0.81% | 1.27MB | 0.81% | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` |
| 1.14MB | 0.73% | 1.14MB | 0.73% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*blockCodecScratch).lz4` |
| 1.06MB | 0.68% | 1.06MB | 0.68% | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildOrderedKey64Locked` |
| 0.64MB | 0.41% | 2.31MB | 1.47% | `compress/flate.(*compressor).init` |
| 0.50MB | 0.32% | 38.35MB | 24.52% | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).applySpanNativeWithPrepared.func2` |
| 0 | 0.00% | 4.95MB | 3.16% | `compress/gzip.(*Writer).Write` |
| 0 | 0.00% | 100MB | 63.93% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 60.51MB | 38.68% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 60.51MB | 38.68% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 60.51MB | 38.68% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |

## Full vs Prefix Comparison

### treedb

- shared hotspots:
  - `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` (full 37.93%, prefix 6.25%)
  - `runtime.scanObject` (full 11.49%, prefix 12.50%)
  - `runtime.typePointers.next` (full 2.30%, prefix 12.50%)
- prefix-only hotspots:
  - `runtime.tryDeferToSpanScan` (18.75% flat)
  - `compress/flate.(*deflateFast).encode` (6.25% flat)
  - `github.com/snissn/gomap/TreeDB/pager.isPrimaryBankID (inline)` (6.25% flat)
  - `internal/runtime/atomic.(*Uint32).Add` (6.25% flat)
  - `runtime.futex` (6.25% flat)
- full-only hotspots:
  - `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` (4.60% flat)
  - `cmpbody` (3.45% flat)
  - `github.com/snissn/gomap/TreeDB/internal/merging.iteratorHeap.Less` (3.45% flat)
  - `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithCOWPolicy` (2.30% flat)
  - `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).UnsafeEntryWithRevision` (2.30% flat)

## Contention Profiles (Per Test)

### batch_delete (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_batch_delete_treedb.pprof`
- total samples: `956.33ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 854.68ms | 89.37% | 854.68ms | 89.37% | `runtime.selectgo` |
| 101.66ms | 10.63% | 101.66ms | 10.63% | `runtime.chanrecv1` |
| 0 | 0.00% | 254.13ms | 26.57% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 254.13ms | 26.57% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 100.02ms | 10.46% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 100.02ms | 10.46% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 250.21ms | 26.16% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 250.21ms | 26.16% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 250.32ms | 26.17% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 100.94ms | 10.56% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.94ms | 10.56% | `runtime.traceStartReadCPU.func1` |

### batch_delete (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_batch_delete_treedb.pprof`
- total samples: `0`

_No entries parsed._

### batch_random (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_batch_random_treedb.pprof`
- total samples: `1712.08ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1565.08ms | 91.41% | 1565.08ms | 91.41% | `runtime.selectgo` |
| 103.04ms | 6.02% | 103.04ms | 6.02% | `runtime.chanrecv1` |
| 43.97ms | 2.57% | 43.97ms | 2.57% | `sync.(*Mutex).Lock (inline)` |
| 0 | 0.00% | 366.33ms | 21.40% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 366.33ms | 21.40% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 499.46ms | 29.17% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 199.23ms | 11.64% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 499.46ms | 29.17% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 199.23ms | 11.64% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 250.02ms | 14.60% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 250.02ms | 14.60% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 250.04ms | 14.60% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 45.58ms | 2.66% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 45.58ms | 2.66% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 100.64ms | 5.88% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.64ms | 5.88% | `runtime.traceStartReadCPU.func1` |

### batch_random (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_batch_random_treedb.pprof`
- total samples: `43.96ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 43.96ms | 100.00% | 43.96ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared (inline)` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write.func4` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).invokeCommandWALAppend` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVBatchPayloadCommandWALTrustedPreparedWithMode` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVBatchPayloadCommandWALPrepared (inline)` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVBatchPayloadCommandWALPreparedCapture` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 43.96ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 43.96ms | 100.00% | `main.main` |
| 0 | 0.00% | 43.96ms | 100.00% | `main.runBenchmark` |

### batch_small_seq (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_batch_small_seq_treedb.pprof`
- total samples: `3716.35ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3462.52ms | 93.17% | 3462.52ms | 93.17% | `runtime.selectgo` |
| 248.25ms | 6.68% | 248.25ms | 6.68% | `runtime.chanrecv1` |
| 0 | 0.00% | 362.64ms | 9.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 362.64ms | 9.76% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 500.12ms | 13.46% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 100.53ms | 2.71% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 999.50ms | 26.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 999.60ms | 26.90% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 500.12ms | 13.46% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 999.60ms | 26.90% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 100.53ms | 2.71% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 249.75ms | 6.72% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 249.75ms | 6.72% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 250.39ms | 6.74% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 52.77ms | 1.42% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 52.77ms | 1.42% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 200.48ms | 5.39% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 200.48ms | 5.39% | `runtime.traceStartReadCPU.func1` |

### batch_small_seq (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_batch_small_seq_treedb.pprof`
- total samples: `5.57ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5.57ms | 100.00% | 5.57ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared (inline)` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write.func4` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).invokeCommandWALAppend` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVBatchPayloadCommandWALTrustedPreparedWithMode` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVBatchPayloadCommandWALPrepared (inline)` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVBatchPayloadCommandWALPreparedCapture` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 5.57ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 5.57ms | 100.00% | `main.main` |
| 0 | 0.00% | 5.57ms | 100.00% | `main.runBenchmark` |

### batch_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_batch_write_treedb.pprof`
- total samples: `744.37ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 430.78ms | 57.87% | 430.78ms | 57.87% | `runtime.chanrecv1` |
| 307.72ms | 41.34% | 307.72ms | 41.34% | `runtime.selectgo` |
| 5.88ms | 0.79% | 5.88ms | 0.79% | `sync.(*Mutex).Lock (inline)` |
| 0 | 0.00% | 307.72ms | 41.34% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 307.72ms | 41.34% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 335.76ms | 45.11% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 335.76ms | 45.11% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 100.25ms | 13.47% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.25ms | 13.47% | `runtime.traceStartReadCPU.func1` |

### batch_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_batch_write_treedb.pprof`
- total samples: `5.87ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5.87ms | 100.00% | 5.87ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandEntryScanPrepared.func1` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Write` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).appendCommandWAL` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write.func4` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).WriteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).invokeCommandWALAppend` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegular` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVCommandWALOrderedEntryScanWithHintPreparedFinalizedAndMode` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendRawKVCommandWALOrderedEntryScanWithHintPreparedFinalized` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 5.87ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*batch).Commit` |
| 0 | 0.00% | 5.87ms | 100.00% | `main.main` |
| 0 | 0.00% | 5.87ms | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 5.87ms | 100.00% | `main.runBenchmark.func23` |

### batch_write_steady (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_batch_write_steady_treedb.pprof`
- total samples: `61.75s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 40.07s | 64.90% | 40.07s | 64.90% | `runtime.selectgo` |
| 12.04s | 19.50% | 12.04s | 19.50% | `runtime.chanrecv2` |
| 7.08s | 11.47% | 7.08s | 11.47% | `runtime.chanrecv1` |
| 2.01s | 3.26% | 2.01s | 3.26% | `sync.(*Mutex).Lock (partial-inline)` |
| 0.53s | 0.86% | 0.53s | 0.86% | `sync.(*WaitGroup).Wait` |
| 0 | 0.00% | 0.70s | 1.13% | `github.com/snissn/gomap/TreeDB.(*DB).publicCommandWALAutoCheckpointBytes` |
| 0 | 0.00% | 3.97s | 6.43% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 3.97s | 6.43% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 0.99s | 1.60% | `github.com/snissn/gomap/TreeDB/caching.(*DB).backendCheckpointBoundary` |
| 0 | 0.00% | 1.37s | 2.22% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 0.70s | 1.13% | `github.com/snissn/gomap/TreeDB/caching.(*DB).effectiveWALBytes` |
| 0 | 0.00% | 4s | 6.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 1.55s | 2.52% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 1.70s | 2.75% | `github.com/snissn/gomap/TreeDB/caching.(*DB).maybeAutoCheckpoint` |
| 0 | 0.00% | 1s | 1.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 4s | 6.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 4s | 6.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 4s | 6.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 4s | 6.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 1s | 1.62% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |

### batch_write_steady (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_batch_write_steady_treedb.pprof`
- total samples: `2016.80ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2011.31ms | 99.73% | 2011.31ms | 99.73% | `sync.(*Mutex).Unlock (partial-inline)` |
| 5.17ms | 0.26% | 27ms | 1.34% | `sync.(*RWMutex).Unlock` |
| 0 | 0.00% | 1730.28ms | 85.79% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 1730.28ms | 85.79% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 696.31ms | 34.53% | `github.com/snissn/gomap/TreeDB.(*DB).cleanupPublicCommandWALCheckpoint` |
| 0 | 0.00% | 696.31ms | 34.53% | `github.com/snissn/gomap/TreeDB.(*DB).cleanupPublicCommandWALCheckpoint-fm` |
| 0 | 0.00% | 21ms | 1.04% | `github.com/snissn/gomap/TreeDB.(*DB).refreshPublicCommandWALCheckpointFallback` |
| 0 | 0.00% | 21ms | 1.04% | `github.com/snissn/gomap/TreeDB.(*DB).refreshPublicCommandWALCheckpointFallback.deferwrap1` |
| 0 | 0.00% | 34.68ms | 1.72% | `github.com/snissn/gomap/TreeDB.(*DB).snapshotPublicCommandWALCheckpointCutover` |
| 0 | 0.00% | 34.68ms | 1.72% | `github.com/snissn/gomap/TreeDB.(*DB).snapshotPublicCommandWALCheckpointCutover-fm` |
| 0 | 0.00% | 731.46ms | 36.27% | `github.com/snissn/gomap/TreeDB/caching.(*DB).Checkpoint (inline)` |
| 0 | 0.00% | 731.46ms | 36.27% | `github.com/snissn/gomap/TreeDB/caching.(*DB).checkpointContext` |
| 0 | 0.00% | 696.31ms | 34.53% | `github.com/snissn/gomap/TreeDB/caching.(*DB).cleanupCommandWALCheckpoint` |
| 0 | 0.00% | 696.31ms | 34.53% | `github.com/snissn/gomap/TreeDB/caching.(*DB).cleanupCommandWALCheckpointBoundary` |
| 0 | 0.00% | 696.31ms | 34.53% | `github.com/snissn/gomap/TreeDB/caching.(*DB).cleanupCommandWALCheckpointTimed` |
| 0 | 0.00% | 279.73ms | 13.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAll` |
| 0 | 0.00% | 279.73ms | 13.87% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 34.68ms | 1.72% | `github.com/snissn/gomap/TreeDB/caching.(*DB).snapshotCommandWALCheckpointCutover` |
| 0 | 0.00% | 279.73ms | 13.87% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 1674.13ms | 83.01% | `github.com/snissn/gomap/TreeDB/db.(*DB).CleanupCommandWALCoveredSegments` |
| 0 | 0.00% | 1674.13ms | 83.01% | `github.com/snissn/gomap/TreeDB/db.(*DB).CleanupCommandWALCoveredSegmentsAtCheckpoint` |
| 0 | 0.00% | 34.68ms | 1.72% | `github.com/snissn/gomap/TreeDB/db.(*DB).RotateCommandWALActiveSegment` |
| 0 | 0.00% | 696.31ms | 34.53% | `github.com/snissn/gomap/TreeDB/db.(*DB).cleanupCommandWALCoveredSegmentsV1` |
| 0 | 0.00% | 696.31ms | 34.53% | `github.com/snissn/gomap/TreeDB/db.(*DB).scanCommandWALCleanupProof` |
| 0 | 0.00% | 34.68ms | 1.72% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).RotateActiveSegment` |

### dataset_write_random (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_dataset_write_random_treedb.pprof`
- total samples: `10468.12ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 8203.77ms | 78.37% | 8203.77ms | 78.37% | `runtime.selectgo` |
| 2251.47ms | 21.51% | 2251.47ms | 21.51% | `runtime.chanrecv1` |
| 0 | 0.00% | 875.01ms | 8.36% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 875.01ms | 8.36% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 999.35ms | 9.55% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 1831.73ms | 17.50% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 998.98ms | 9.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 998.94ms | 9.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 999.35ms | 9.55% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 998.94ms | 9.54% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 1831.73ms | 17.50% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 749.75ms | 7.16% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 749.75ms | 7.16% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 1000.56ms | 9.56% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |
| 0 | 0.00% | 1000.56ms | 9.56% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).start.gowrap1` |
| 0 | 0.00% | 749.45ms | 7.16% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 560.08ms | 5.35% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 560.08ms | 5.35% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 1000.87ms | 9.56% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1703.29ms | 16.27% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 702.42ms | 6.71% | `runtime.traceStartReadCPU.func1` |

### dataset_write_random (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_dataset_write_random_treedb.pprof`
- total samples: `12.95ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 12.87ms | 99.45% | 12.87ms | 99.45% | `sync.(*Mutex).Unlock` |
| 0.07ms | 0.55% | 0.07ms | 0.55% | `runtime.unlock (inline)` |
| 0 | 0.00% | 12.90ms | 99.68% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 12.90ms | 99.68% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 12.90ms | 99.68% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 12.90ms | 99.68% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 12.90ms | 99.68% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntent (inline)` |
| 0 | 0.00% | 12.89ms | 99.57% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 12.87ms | 99.45% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 12.87ms | 99.45% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 12.90ms | 99.68% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 12.90ms | 99.68% | `main.main` |
| 0 | 0.00% | 12.90ms | 99.68% | `main.runBenchmark` |
| 0 | 0.00% | 12.90ms | 99.68% | `main.runBenchmark.func21` |

### dataset_write_sorted (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_dataset_write_sorted_treedb.pprof`
- total samples: `5766.72ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3244.36ms | 56.26% | 3244.36ms | 56.26% | `runtime.selectgo` |
| 1901.09ms | 32.97% | 1901.09ms | 32.97% | `runtime.chanrecv1` |
| 605.58ms | 10.50% | 605.58ms | 10.50% | `sync.(*WaitGroup).Wait` |
| 0 | 0.00% | 1243.91ms | 21.57% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 1243.91ms | 21.57% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 500.02ms | 8.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 605.58ms | 10.50% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAll` |
| 0 | 0.00% | 605.58ms | 10.50% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked` |
| 0 | 0.00% | 605.58ms | 10.50% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 500.02ms | 8.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 605.58ms | 10.50% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 749.71ms | 13.00% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 749.71ms | 13.00% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 650.49ms | 11.28% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 203.71ms | 3.53% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 203.71ms | 3.53% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 100.24ms | 1.74% | `github.com/snissn/gomap/TreeDB/internal/rootpublication.(*Coordinator).run` |
| 0 | 0.00% | 100.24ms | 1.74% | `github.com/snissn/gomap/TreeDB/internal/rootpublication.New.gowrap1` |
| 0 | 0.00% | 1000.18ms | 17.34% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1702.73ms | 29.53% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 702.54ms | 12.18% | `runtime.traceStartReadCPU.func1` |

### dataset_write_sorted (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_dataset_write_sorted_treedb.pprof`
- total samples: `15.65ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 15.65ms | 100.00% | 15.65ms | 100.00% | `sync.(*Mutex).Unlock (partial-inline)` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 9.13ms | 58.34% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAll` |
| 0 | 0.00% | 9.13ms | 58.34% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked` |
| 0 | 0.00% | 9.13ms | 58.34% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 9.13ms | 58.34% | `github.com/snissn/gomap/TreeDB/caching.(*DB).trimRetainedArenasAfterFlush` |
| 0 | 0.00% | 9.13ms | 58.34% | `github.com/snissn/gomap/TreeDB/caching.(*DB).trimSparseAppendOnlyMutableShards` |
| 0 | 0.00% | 9.13ms | 58.34% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntent (inline)` |
| 0 | 0.00% | 6.52ms | 41.66% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 6.52ms | 41.65% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |

### full_scan (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_full_scan_treedb.pprof`
- total samples: `7609.89ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 6804.19ms | 89.41% | 6804.19ms | 89.41% | `runtime.selectgo` |
| 805.70ms | 10.59% | 805.70ms | 10.59% | `runtime.chanrecv1` |
| 0 | 0.00% | 500.73ms | 6.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 799.58ms | 10.51% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 1000.82ms | 13.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 1000.88ms | 13.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 500.73ms | 6.58% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 1000.88ms | 13.15% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 799.58ms | 10.51% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 750.45ms | 9.86% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 750.45ms | 9.86% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 2001.07ms | 26.30% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |
| 0 | 0.00% | 2001.07ms | 26.30% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).start.gowrap1` |
| 0 | 0.00% | 750.65ms | 9.86% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 804.97ms | 10.58% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 804.97ms | 10.58% | `runtime.traceStartReadCPU.func1` |

### full_scan (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_full_scan_treedb.pprof`
- total samples: `632ns`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 632ns | 100.00% | 632ns | 100.00% | `runtime.unlock (inline)` |
| 0 | 0.00% | 632ns | 100.00% | `github.com/snissn/gomap/TreeDB/caching.readPoolPressureMemStats` |
| 0 | 0.00% | 632ns | 100.00% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 632ns | 100.00% | `github.com/snissn/gomap/TreeDB/caching.sampleAndPublishPoolPressureSnapshot` |
| 0 | 0.00% | 632ns | 100.00% | `github.com/snissn/gomap/TreeDB/caching.samplePoolPressureSnapshot` |
| 0 | 0.00% | 632ns | 100.00% | `runtime.ReadMemStats` |
| 0 | 0.00% | 632ns | 100.00% | `runtime.stopTheWorld` |
| 0 | 0.00% | 632ns | 100.00% | `runtime.stopTheWorld.func1` |
| 0 | 0.00% | 632ns | 100.00% | `runtime.stopTheWorldWithSema` |
| 0 | 0.00% | 632ns | 100.00% | `runtime.systemstack` |

### prefix_scan (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_prefix_scan_treedb.pprof`
- total samples: `474.55us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 474.55us | 100.00% | 474.55us | 100.00% | `runtime.chanrecv1` |
| 0 | 0.00% | 474.55us | 100.00% | `main.main` |
| 0 | 0.00% | 474.55us | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 474.55us | 100.00% | `main.runBenchmark.func47` |
| 0 | 0.00% | 474.55us | 100.00% | `main.runBenchmark.func48` |
| 0 | 0.00% | 474.55us | 100.00% | `runtime.main` |
| 0 | 0.00% | 474.55us | 100.00% | `runtime/pprof.StopCPUProfile` |

### prefix_scan (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_prefix_scan_treedb.pprof`
- total samples: `0`

_No entries parsed._

### random_delete (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_random_delete_treedb.pprof`
- total samples: `6984.94ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 5001.30ms | 71.60% | 5001.30ms | 71.60% | `runtime.selectgo` |
| 1976.58ms | 28.30% | 1976.58ms | 28.30% | `runtime.chanrecv1` |
| 0 | 0.00% | 802.55ms | 11.49% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 802.55ms | 11.49% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 500.39ms | 7.16% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 699.15ms | 10.01% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 500.39ms | 7.16% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 699.15ms | 10.01% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 499.93ms | 7.16% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 499.93ms | 7.16% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 1999.24ms | 28.62% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |
| 0 | 0.00% | 1999.24ms | 28.62% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).start.gowrap1` |
| 0 | 0.00% | 500.04ms | 7.16% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 279.84ms | 4.01% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 279.84ms | 4.01% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 1000.14ms | 14.32% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1702.88ms | 24.38% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 702.74ms | 10.06% | `runtime.traceStartReadCPU.func1` |

### random_delete (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_random_delete_treedb.pprof`
- total samples: `7.06ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 7.06ms | 100.00% | 7.06ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).Delete` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).Delete.func1` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).DeleteAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntent (inline)` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 7.06ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Delete` |
| 0 | 0.00% | 7.06ms | 100.00% | `main.main` |
| 0 | 0.00% | 7.06ms | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 7.06ms | 100.00% | `main.runBenchmark.func31` |
| 0 | 0.00% | 7.06ms | 100.00% | `runtime.deferreturn` |
| 0 | 0.00% | 7.06ms | 100.00% | `runtime.main` |

### random_read (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_random_read_treedb.pprof`
- total samples: `701ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 600.09ms | 85.61% | 600.09ms | 85.61% | `runtime.selectgo` |
| 100.91ms | 14.39% | 100.91ms | 14.39% | `runtime.chanrecv1` |
| 0 | 0.00% | 100.20ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 100.20ms | 14.29% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 249.89ms | 35.65% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 249.89ms | 35.65% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 250ms | 35.66% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 100.54ms | 14.34% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 100.54ms | 14.34% | `runtime.traceStartReadCPU.func1` |

### random_read (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_random_read_treedb.pprof`
- total samples: `0`

_No entries parsed._

### random_read_batch (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_random_read_batch_treedb.pprof`
- total samples: `391.10us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 391.10us | 100.00% | 391.10us | 100.00% | `runtime.chanrecv1` |
| 0 | 0.00% | 391.10us | 100.00% | `main.main` |
| 0 | 0.00% | 391.10us | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 391.10us | 100.00% | `main.runBenchmark.func47` |
| 0 | 0.00% | 391.10us | 100.00% | `main.runBenchmark.func48` |
| 0 | 0.00% | 391.10us | 100.00% | `runtime.main` |
| 0 | 0.00% | 391.10us | 100.00% | `runtime/pprof.StopCPUProfile` |

### random_read_batch (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_random_read_batch_treedb.pprof`
- total samples: `0`

_No entries parsed._

### random_read_parallel (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_random_read_parallel_treedb.pprof`
- total samples: `1197.06ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1123.34ms | 93.84% | 1123.34ms | 93.84% | `runtime.selectgo` |
| 71.88ms | 6.00% | 71.88ms | 6.00% | `sync.(*WaitGroup).Wait` |
| 0 | 0.00% | 505.42ms | 42.22% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 100.06ms | 8.36% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 505.42ms | 42.22% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 100.06ms | 8.36% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 255.33ms | 21.33% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 255.33ms | 21.33% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 262.53ms | 21.93% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 72.32ms | 6.04% | `main.main` |
| 0 | 0.00% | 72.32ms | 6.04% | `main.runBenchmark` |
| 0 | 0.00% | 71.88ms | 6.00% | `main.runBenchmark.func33` |
| 0 | 0.00% | 72.32ms | 6.04% | `runtime.main` |

### random_read_parallel (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_random_read_parallel_treedb.pprof`
- total samples: `1883.30us`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1443.98us | 76.67% | 1443.98us | 76.67% | `sync.(*Mutex).Unlock (inline)` |
| 439.32us | 23.33% | 439.32us | 23.33% | `runtime.unlock (inline)` |
| 0 | 0.00% | 1443.98us | 76.67% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 1443.98us | 76.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 88.59us | 4.70% | `github.com/snissn/gomap/TreeDB/caching.readPoolPressureMemStats` |
| 0 | 0.00% | 88.59us | 4.70% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 88.59us | 4.70% | `github.com/snissn/gomap/TreeDB/caching.sampleAndPublishPoolPressureSnapshot` |
| 0 | 0.00% | 88.59us | 4.70% | `github.com/snissn/gomap/TreeDB/caching.samplePoolPressureSnapshot` |
| 0 | 0.00% | 1443.98us | 76.67% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).AcquireReadSnapshot` |
| 0 | 0.00% | 1443.98us | 76.67% | `main.runBenchmark.func33.1` |
| 0 | 0.00% | 1443.98us | 76.67% | `main.runBenchmark.func33.2` |
| 0 | 0.00% | 1443.98us | 76.67% | `main.runBenchmark.func33.gowrap1` |
| 0 | 0.00% | 88.59us | 4.70% | `runtime.ReadMemStats` |
| 0 | 0.00% | 350.73us | 18.62% | `runtime.findRunnable` |
| 0 | 0.00% | 350.73us | 18.62% | `runtime.gcstopm` |
| 0 | 0.00% | 350.73us | 18.62% | `runtime.gopreempt_m (inline)` |
| 0 | 0.00% | 350.73us | 18.62% | `runtime.goschedImpl` |
| 0 | 0.00% | 350.73us | 18.62% | `runtime.morestack` |
| 0 | 0.00% | 350.73us | 18.62% | `runtime.newstack` |
| 0 | 0.00% | 350.73us | 18.62% | `runtime.schedule` |
| 0 | 0.00% | 88.59us | 4.70% | `runtime.stopTheWorld` |
| 0 | 0.00% | 88.59us | 4.70% | `runtime.stopTheWorld.func1` |
| 0 | 0.00% | 88.59us | 4.70% | `runtime.stopTheWorldWithSema` |
| 0 | 0.00% | 178.26us | 9.47% | `runtime.stopm` |
| 0 | 0.00% | 88.59us | 4.70% | `runtime.systemstack` |

### random_read_parallel_acquire_snapshot (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `20693.06ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 15546.52ms | 75.13% | 15546.52ms | 75.13% | `runtime.selectgo` |
| 2302.80ms | 11.13% | 2302.80ms | 11.13% | `runtime.chanrecv1` |
| 1547.10ms | 7.48% | 1547.10ms | 7.48% | `sync.(*Mutex).Lock (inline)` |
| 1296.63ms | 6.27% | 1296.63ms | 6.27% | `sync.(*WaitGroup).Wait` |
| 0 | 0.00% | 923.81ms | 4.46% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 923.81ms | 4.46% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 2009.81ms | 9.71% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 2009.81ms | 9.71% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 1494.45ms | 7.22% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 1299.86ms | 6.28% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 1999.57ms | 9.66% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 1999.88ms | 9.66% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 1494.45ms | 7.22% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 1999.88ms | 9.66% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 1299.86ms | 6.28% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 623.29ms | 3.01% | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).Close` |
| 0 | 0.00% | 623.29ms | 3.01% | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).finalizeCloseIfUnreferenced` |
| 0 | 0.00% | 1493.64ms | 7.22% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 1493.64ms | 7.22% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 923.81ms | 4.46% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 923.81ms | 4.46% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 923.81ms | 4.46% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 923.81ms | 4.46% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotWithValueLogPublicationLockHeld (inline)` |
| 0 | 0.00% | 623.29ms | 3.01% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).Close (inline)` |
| 0 | 0.00% | 623.29ms | 3.01% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead` |

### random_read_parallel_acquire_snapshot (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_random_read_parallel_acquire_snapshot_treedb.pprof`
- total samples: `1274.16ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1194.56ms | 93.75% | 1198.13ms | 94.03% | `sync.(*Mutex).Unlock (partial-inline)` |
| 79.35ms | 6.23% | 79.35ms | 6.23% | `runtime.unlock (inline)` |
| 0 | 0.00% | 774.39ms | 60.78% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 774.39ms | 60.78% | `github.com/snissn/gomap/TreeDB/caching.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 493.80ms | 38.75% | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).Close` |
| 0 | 0.00% | 493.80ms | 38.75% | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).finalizeCloseIfUnreferenced` |
| 0 | 0.00% | 764.74ms | 60.02% | `github.com/snissn/gomap/TreeDB/db.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 764.74ms | 60.02% | `github.com/snissn/gomap/TreeDB/db.(*DB).acquireSnapshotWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 705.22ms | 55.35% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld` |
| 0 | 0.00% | 705.22ms | 55.35% | `github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotWithValueLogPublicationLockHeld (inline)` |
| 0 | 0.00% | 27.94ms | 2.19% | `github.com/snissn/gomap/TreeDB/db.(*DB).releaseLeafGenerationPinSet (inline)` |
| 0 | 0.00% | 32.03ms | 2.51% | `github.com/snissn/gomap/TreeDB/db.(*DB).retainLeafGenerationPinSet (inline)` |
| 0 | 0.00% | 493.80ms | 38.75% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).Close (inline)` |
| 0 | 0.00% | 493.80ms | 38.75% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead` |
| 0 | 0.00% | 493.80ms | 38.75% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead` |
| 0 | 0.00% | 27.94ms | 2.19% | `github.com/snissn/gomap/TreeDB/db.(*Snapshot).releaseLeafGenerationPins` |
| 0 | 0.00% | 59.52ms | 4.67% | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` |
| 0 | 0.00% | 27.94ms | 2.19% | `github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinSet).release` |
| 0 | 0.00% | 27.94ms | 2.19% | `github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinSet).releasePinWork` |
| 0 | 0.00% | 32.03ms | 2.51% | `github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinSet).retain` |
| 0 | 0.00% | 40.15ms | 3.15% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).Release` |
| 0 | 0.00% | 425.71ms | 33.41% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).ReleaseSnapshotWrapper` |
| 0 | 0.00% | 506.72ms | 39.77% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).RetainSnapshotWrapper` |
| 0 | 0.00% | 504.74ms | 39.61% | `github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).RetainSnapshotWrapper.deferwrap1` |

### random_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_random_write_treedb.pprof`
- total samples: `4780.80ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 2862.27ms | 59.87% | 2862.27ms | 59.87% | `runtime.selectgo` |
| 1912.07ms | 39.99% | 1912.07ms | 39.99% | `runtime.chanrecv1` |
| 0 | 0.00% | 863.60ms | 18.06% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 863.60ms | 18.06% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 499.41ms | 10.45% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 499.41ms | 10.45% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 748.61ms | 15.66% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 748.61ms | 15.66% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 750.65ms | 15.70% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 214.69ms | 4.49% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 214.69ms | 4.49% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 1000.91ms | 20.94% | `runtime.(*traceAdvancerState).start.func1` |
| 0 | 0.00% | 1702.67ms | 35.61% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 701.77ms | 14.68% | `runtime.traceStartReadCPU.func1` |

### random_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_random_write_treedb.pprof`
- total samples: `6.45ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 6.45ms | 100.00% | 6.45ms | 100.00% | `sync.(*Mutex).Unlock` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).Set (inline)` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput.func2` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntent (inline)` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB/db.(*DB).appendCommandWALIntentWithTiming` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).AppendCommandObservedWithHooks` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand` |
| 0 | 0.00% | 6.45ms | 100.00% | `github.com/snissn/gomap/kvstore/adapters/treedb.(*DB).Set` |
| 0 | 0.00% | 6.45ms | 100.00% | `main.main` |
| 0 | 0.00% | 6.45ms | 100.00% | `main.runBenchmark` |
| 0 | 0.00% | 6.45ms | 100.00% | `main.runBenchmark.func19` |
| 0 | 0.00% | 6.45ms | 100.00% | `runtime.deferreturn` |

### sequential_write (treedb/block)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block_sequential_write_treedb.pprof`
- total samples: `2.66s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 1.77s | 66.62% | 1.77s | 66.62% | `runtime.selectgo` |
| 0.75s | 28.08% | 0.75s | 28.08% | `runtime.chanrecv1` |
| 0.11s | 4.00% | 0.11s | 4.00% | `sync.(*WaitGroup).Wait` |
| 0.03s | 1.31% | 0.03s | 1.31% | `sync.(*Mutex).Lock (inline)` |
| 0 | 0.00% | 0.64s | 24.21% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 0.64s | 24.21% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 0.12s | 4.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureVlogDictPrepWorkers.gowrap1` |
| 0 | 0.00% | 0.11s | 4.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAll` |
| 0 | 0.00% | 0.11s | 4.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked` |
| 0 | 0.00% | 0.11s | 4.00% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 0.12s | 4.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop` |
| 0 | 0.00% | 0.11s | 4.00% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 0.50s | 18.75% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 0.50s | 18.75% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 0.50s | 18.77% | `github.com/snissn/gomap/TreeDB/db.(*pruneWorker).Start.func1` |
| 0 | 0.00% | 0.17s | 6.26% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).maybeStartFixedWALAheadLocked.gowrap1` |
| 0 | 0.00% | 0.17s | 6.26% | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).runFixedWALAhead` |
| 0 | 0.00% | 0.60s | 22.63% | `runtime.(*wakeableSleep).sleep` |
| 0 | 0.00% | 0.60s | 22.63% | `runtime.traceStartReadCPU.func1` |

### sequential_write (treedb/mutex)

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex_sequential_write_treedb.pprof`
- total samples: `35.08ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 34.86ms | 99.37% | 34.86ms | 99.37% | `sync.(*Mutex).Unlock (partial-inline)` |
| 0.22ms | 0.63% | 0.22ms | 0.63% | `runtime.unlock` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB/caching.(*DB).SetAfterCommandWALAppendWithMVCCInput (inline)` |
| 0 | 0.00% | 1.37ms | 3.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAll` |
| 0 | 0.00% | 1.37ms | 3.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked` |
| 0 | 0.00% | 10.76ms | 30.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushAllLocked.func2` |
| 0 | 0.00% | 10.76ms | 30.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnits` |
| 0 | 0.00% | 10.76ms | 30.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed` |
| 0 | 0.00% | 10.76ms | 30.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStableIteratorStreamed.func4` |
| 0 | 0.00% | 10.76ms | 30.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushCanonicalPointUnitsStreamed` |
| 0 | 0.00% | 10.76ms | 30.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionMode (inline)` |
| 0 | 0.00% | 10.76ms | 30.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCollectionModeFrontier` |
| 0 | 0.00% | 10.76ms | 30.67% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLaneOnceWithCommandPublish (inline)` |
| 0 | 0.00% | 1.37ms | 3.89% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 22.73ms | 64.81% | `github.com/snissn/gomap/TreeDB/caching.(*DB).setAfterCommandWALAppendWithMVCCInput` |

## Contention Profiles (Global)

### block

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/block.pprof`
- total samples: `431.46s`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 311.65s | 72.23% | 311.65s | 72.23% | `runtime.selectgo` |
| 78.09s | 18.10% | 78.09s | 18.10% | `runtime.chanrecv2` |
| 33.53s | 7.77% | 33.53s | 7.77% | `runtime.chanrecv1` |
| 4.11s | 0.95% | 4.11s | 0.95% | `sync.(*Mutex).Lock (partial-inline)` |
| 4.08s | 0.94% | 4.08s | 0.94% | `sync.(*WaitGroup).Wait` |
| 0 | 0.00% | 15.73s | 3.65% | `github.com/snissn/gomap/TreeDB/caching.(*DB).StartAutoCheckpoint.gowrap1` |
| 0 | 0.00% | 15.73s | 3.65% | `github.com/snissn/gomap/TreeDB/caching.(*DB).autoCheckpointLoop` |
| 0 | 0.00% | 15.50s | 3.59% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureValueLogDictTrainer.gowrap2` |
| 0 | 0.00% | 57.17s | 13.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).ensureVlogDictPrepWorkers.gowrap1` |
| 0 | 0.00% | 15.34s | 3.56% | `github.com/snissn/gomap/TreeDB/caching.(*DB).flushLoop` |
| 0 | 0.00% | 8.83s | 2.05% | `github.com/snissn/gomap/TreeDB/caching.(*DB).scheduleVlogGenerationCheckpointKickHotNoDebtWake.func1` |
| 0 | 0.00% | 15s | 3.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startProcessMemorySampler.func1` |
| 0 | 0.00% | 15s | 3.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogGenerationLoop.gowrap1` |
| 0 | 0.00% | 79.62s | 18.45% | `github.com/snissn/gomap/TreeDB/caching.(*DB).startVlogWriter.gowrap1` |
| 0 | 0.00% | 15.50s | 3.59% | `github.com/snissn/gomap/TreeDB/caching.(*DB).valueLogDictLoop` |
| 0 | 0.00% | 57.17s | 13.25% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogDictPrepareLoop` |
| 0 | 0.00% | 15s | 3.48% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogGenerationLoop` |
| 0 | 0.00% | 79.62s | 18.45% | `github.com/snissn/gomap/TreeDB/caching.(*DB).vlogWriteLoop` |
| 0 | 0.00% | 8.83s | 2.05% | `github.com/snissn/gomap/TreeDB/caching.(*DB).waitForForegroundMaintenanceQuietWindow` |
| 0 | 0.00% | 15.34s | 3.56% | `github.com/snissn/gomap/TreeDB/caching.Open.gowrap1` |
| 0 | 0.00% | 15.75s | 3.65% | `github.com/snissn/gomap/TreeDB/caching.retainPoolPressureSampler.gowrap1` |
| 0 | 0.00% | 15.75s | 3.65% | `github.com/snissn/gomap/TreeDB/caching.runPoolPressureSampler` |
| 0 | 0.00% | 30.17s | 6.99% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).loop` |
| 0 | 0.00% | 30.17s | 6.99% | `github.com/snissn/gomap/TreeDB/db.(*indexGhostManager).start.gowrap1` |

### mutex

- source: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/mutex.pprof`
- total samples: `3851.90ms`

| flat | flat% | cum | cum% | function |
|---:|---:|---:|---:|---|
| 3760.70ms | 97.63% | 3764.27ms | 97.72% | `sync.(*Mutex).Unlock (partial-inline)` |
| 82.69ms | 2.15% | 82.69ms | 2.15% | `runtime.unlock (inline)` |
| 6.30ms | 0.16% | 1088.80ms | 28.27% | `sync.(*RWMutex).Unlock` |
| 0 | 0.00% | 775.83ms | 20.14% | `github.com/snissn/gomap/TreeDB.(*DB).AcquireSnapshot` |
| 0 | 0.00% | 1730.28ms | 44.92% | `github.com/snissn/gomap/TreeDB.(*DB).Checkpoint` |
| 0 | 0.00% | 48.61ms | 1.26% | `github.com/snissn/gomap/TreeDB.(*DB).Set` |
| 0 | 0.00% | 61.53ms | 1.60% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWAL (inline)` |
| 0 | 0.00% | 111.06ms | 2.88% | `github.com/snissn/gomap/TreeDB.(*DB).appendAndRegisterPublicCommandWALCapture` |
| 0 | 0.00% | 49.53ms | 1.29% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPrepared` |
| 0 | 0.00% | 49.53ms | 1.29% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest` |
| 0 | 0.00% | 49.53ms | 1.29% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVCommandPayloadPreparedRequest.func2` |
| 0 | 0.00% | 55.65ms | 1.44% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand` |
| 0 | 0.00% | 55.65ms | 1.44% | `github.com/snissn/gomap/TreeDB.(*DB).appendPublicRawKVPointCommand.func1` |
| 0 | 0.00% | 1730.28ms | 44.92% | `github.com/snissn/gomap/TreeDB.(*DB).checkpointCachedForPublicCommandWAL` |
| 0 | 0.00% | 696.31ms | 18.08% | `github.com/snissn/gomap/TreeDB.(*DB).cleanupPublicCommandWALCheckpoint` |
| 0 | 0.00% | 696.31ms | 18.08% | `github.com/snissn/gomap/TreeDB.(*DB).cleanupPublicCommandWALCheckpoint-fm` |
| 0 | 0.00% | 111.06ms | 2.88% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWAL` |
| 0 | 0.00% | 111.06ms | 2.88% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALCollected` |
| 0 | 0.00% | 111.06ms | 2.88% | `github.com/snissn/gomap/TreeDB.(*DB).registerPublicCommandWALWithIntent (inline)` |
| 0 | 0.00% | 48.61ms | 1.26% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput` |
| 0 | 0.00% | 48.59ms | 1.26% | `github.com/snissn/gomap/TreeDB.(*DB).setWithMVCCInput.func1` |

## TreeDB Stats Metadata

### keys=200000 / TreeDB

| stat | value |
|---|---:|
| `treedb.applied_command_lsn` | `1002100` |
| `treedb.cache.append_only.entry_hint_capacity_bytes` | `4850304` |
| `treedb.cache.append_only.entry_hint_entries` | `50524` |
| `treedb.cache.append_only.entry_pool_admission_drop_bytes_total` | `75452608` |
| `treedb.cache.append_only.entry_pool_admission_drops_total` | `5` |
| `treedb.cache.append_only.entry_pool_drop_bytes_total` | `265329416` |
| `treedb.cache.append_only.entry_pool_drops_total` | `1` |
| `treedb.cache.append_only.entry_pool_gets_total` | `67` |
| `treedb.cache.append_only.entry_pool_puts_total` | `263` |
| `treedb.cache.append_only.entry_pool_retained_bytes_estimate` | `177498288` |
| `treedb.cache.append_only.entry_pool_retained_bytes_max_estimate` | `265329416` |
| `treedb.cache.append_only.mem_lease_count` | `8` |
| `treedb.cache.append_only.mem_lease_entry_backing_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_entry_capacity` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_active_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_active_chunks` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_retained_bytes` | `0` |
| `treedb.cache.append_only.mem_lease_value_arena_retained_chunks` | `0` |
| `treedb.cache.append_only.mutable_count` | `16` |
| `treedb.cache.append_only.mutable_entry_backing_bytes` | `0` |
| `treedb.cache.append_only.mutable_entry_capacity` | `0` |
| `treedb.cache.append_only.mutable_from_lease_total` | `56` |
| `treedb.cache.append_only.mutable_from_pool_total` | `0` |
| `treedb.cache.append_only.mutable_new_alloc_queue_bytes_sum` | `502792240` |
| `treedb.cache.append_only.mutable_new_alloc_total` | `24` |
| `treedb.cache.append_only.mutable_new_alloc_with_queue_total` | `24` |
| `treedb.cache.append_only.mutable_pool_drops_total` | `0` |
| `treedb.cache.append_only.mutable_pool_entry_backing_dropped_bytes_total` | `0` |
| `treedb.cache.append_only.mutable_pool_puts_total` | `16` |
| `treedb.cache.append_only.mutable_sparse_trim_dropped_bytes_total` | `25276504` |
| `treedb.cache.append_only.mutable_sparse_trim_total` | `26` |
| `treedb.cache.append_only.mutable_trim_dropped_bytes_total` | `25276504` |
| `treedb.cache.append_only.mutable_trim_total` | `74` |
| `treedb.cache.append_only.mutable_value_arena_active_bytes` | `0` |
| `treedb.cache.append_only.mutable_value_arena_active_chunks` | `0` |
| `treedb.cache.append_only.mutable_value_arena_retained_bytes` | `0` |
| `treedb.cache.append_only.mutable_value_arena_retained_chunks` | `0` |
| `treedb.cache.append_only.reserve.calls_total` | `135` |
| `treedb.cache.append_only.reserve.entries_total` | `62237` |
| `treedb.cache.append_only.reserve.grow_bytes_total` | `270804336` |
| `treedb.cache.append_only.reserve.grow_calls_total` | `135` |
| `treedb.cache.append_only.reserve.skipped_growth_allocs_total` | `21` |
| `treedb.cache.append_only.reserve.skipped_growth_bytes_total` | `405504` |
| `treedb.cache.append_only.value_arena_pool_admission_drop_bytes_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_admission_drops_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_drop_bytes_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_drops_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_gets_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_puts_total` | `0` |
| `treedb.cache.append_only.value_arena_pool_retained_bytes_estimate` | `0` |
| `treedb.cache.append_only.value_arena_pool_retained_bytes_max_estimate` | `0` |
| `treedb.cache.auto_checkpoint.count` | `1` |
| `treedb.cache.auto_checkpoint.last_reason` | `idle` |
| `treedb.cache.backpressure_mode` | `adaptive` |
| `treedb.cache.checkpoint.active` | `false` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_last` | `0` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_max` | `279751336` |
| `treedb.cache.checkpoint.active_background_flush_wait_ns_total` | `279751336` |
| `treedb.cache.checkpoint.active_background_flush_wait_samples` | `1` |
| `treedb.cache.checkpoint.auto_vacuum_last_internal_fill_avg_ppm` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_last_internal_fill_p50_ppm` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_last_pages` | `0` |
| `treedb.cache.checkpoint.auto_vacuum_runs` | `0` |
| `treedb.cache.checkpoint.barrier_wait_ns_max` | `279751364` |
| `treedb.cache.checkpoint.barrier_wait_ns_total` | `279903142` |
| `treedb.cache.checkpoint.barrier_wait_samples` | `3` |
| `treedb.cache.checkpoint.cutover_avg_ms` | `26.734` |
| `treedb.cache.checkpoint.cutover_last_ms` | `23.094` |
| `treedb.cache.checkpoint.cutover_last_unix_nano` | `1795198079110956877` |
| `treedb.cache.checkpoint.cutover_max_ms` | `36.035` |
| `treedb.cache.checkpoint.cutover_samples` | `3` |
| `treedb.cache.checkpoint.debt.active_in_flight_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt.active_in_flight_bytes_max` | `67153760` |
| `treedb.cache.checkpoint.debt.active_workers_last` | `0` |
| `treedb.cache.checkpoint.debt.active_workers_max` | `1` |
| `treedb.cache.checkpoint.debt.frontier_lanes_last` | `1` |
| `treedb.cache.checkpoint.debt.frontier_lanes_max` | `1` |
| `treedb.cache.checkpoint.debt.mutable_bytes_last` | `0` |
| `treedb.cache.checkpoint.debt.mutable_bytes_max` | `21760000` |
| `treedb.cache.checkpoint.debt.queue_bytes_last` | `57600000` |
| `treedb.cache.checkpoint.debt.queue_bytes_max` | `67153760` |
| `treedb.cache.checkpoint.debt.queue_units_last` | `16` |
| `treedb.cache.checkpoint.debt.queue_units_max` | `16` |
| `treedb.cache.checkpoint.debt_bytes_last` | `57600000` |
| `treedb.cache.checkpoint.debt_bytes_max` | `88913760` |
| `treedb.cache.checkpoint.debt_memtables_last` | `16` |
| `treedb.cache.checkpoint.debt_memtables_max` | `17` |
| `treedb.cache.checkpoint.flush_all.background_drain_bytes_last` | `0` |
| `treedb.cache.checkpoint.flush_all.background_drain_ops_last` | `0` |
| `treedb.cache.checkpoint.flush_all.background_drain_units_last` | `0` |
| `treedb.cache.checkpoint.flush_all.frontier_lanes_last` | `1` |
| `treedb.cache.checkpoint.flush_all.frontier_lanes_max` | `1` |
| `treedb.cache.checkpoint.flush_all.owned_drain_bytes_last` | `57600000` |
| `treedb.cache.checkpoint.flush_all.owned_drain_bytes_per_sec_last` | `44905766.161858` |
| `treedb.cache.checkpoint.flush_all.owned_drain_ns_last` | `1282686054` |
| `treedb.cache.checkpoint.flush_all.owned_drain_ops_last` | `800000` |
| `treedb.cache.checkpoint.flush_all.owned_drain_units_last` | `16` |
| `treedb.cache.checkpoint.flush_all.owned_drain_units_per_sec_last` | `12.473824` |
| `treedb.cache.checkpoint.flush_all.worker_passes_total` | `2` |
| `treedb.cache.checkpoint.flush_all.workers_last` | `1` |
| `treedb.cache.checkpoint.flush_all.workers_max` | `1` |
| `treedb.cache.checkpoint.flush_all.workers_total` | `2` |
| `treedb.cache.checkpoint.flush_preempt_requests_total` | `3` |
| `treedb.cache.checkpoint.flushmu_wait_max_ms` | `279.751` |
| `treedb.cache.checkpoint.flushmu_wait_total_ms` | `279.903` |
| `treedb.cache.checkpoint.frontier.bytes_last` | `57600000` |
| `treedb.cache.checkpoint.frontier.bytes_max` | `57600000` |
| `treedb.cache.checkpoint.frontier.drained_bytes_last` | `57600000` |
| `treedb.cache.checkpoint.frontier.drained_units_last` | `16` |
| `treedb.cache.checkpoint.frontier.post_bytes_last` | `0` |
| `treedb.cache.checkpoint.frontier.post_bytes_max` | `0` |
| `treedb.cache.checkpoint.frontier.post_units_last` | `0` |
| `treedb.cache.checkpoint.frontier.post_units_max` | `0` |
| `treedb.cache.checkpoint.frontier.samples` | `2` |
| `treedb.cache.checkpoint.frontier.units_last` | `16` |
| `treedb.cache.checkpoint.frontier.units_max` | `16` |
| `treedb.cache.checkpoint.max_ms` | `2697.077` |
| `treedb.cache.checkpoint.noop_skips` | `1` |
| `treedb.cache.checkpoint.post_frontier_admission.active` | `false` |
| `treedb.cache.checkpoint.post_frontier_admission_enabled` | `true` |
| `treedb.cache.checkpoint.preflush_kick_skips_total` | `2` |
| `treedb.cache.checkpoint.productive_wait_ratio_last` | `0.000000` |
| `treedb.cache.checkpoint.runs` | `3` |
| `treedb.cache.checkpoint.shared_drain.background_bytes_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.background_ops_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.background_units_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_bytes_total` | `79360000` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_ops_total` | `960000` |
| `treedb.cache.checkpoint.shared_drain.checkpoint_units_total` | `32` |
| `treedb.cache.checkpoint.shared_drain.flushmu_releases_total` | `0` |
| `treedb.cache.checkpoint.shared_drain.wait_ns_max` | `0` |
| `treedb.cache.checkpoint.shared_drain.wait_ns_total` | `0` |
| `treedb.cache.checkpoint.stage.auto_critical_section.last_ns` | `998967195` |
| `treedb.cache.checkpoint.stage.auto_critical_section.max_ns` | `998967195` |
| `treedb.cache.checkpoint.stage.auto_critical_section.samples` | `1` |
| `treedb.cache.checkpoint.stage.auto_critical_section.total_ns` | `998967195` |
| `treedb.cache.checkpoint.stage.backend_boundary.last_ns` | `359324722` |
| `treedb.cache.checkpoint.stage.backend_boundary.max_ns` | `1249420265` |
| `treedb.cache.checkpoint.stage.backend_boundary.samples` | `3` |
| `treedb.cache.checkpoint.stage.backend_boundary.total_ns` | `2586606121` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.last_ns` | `300924623` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.max_ns` | `1048542709` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.samples` | `2` |
| `treedb.cache.checkpoint.stage.command_wal_cleanup.total_ns` | `1349467332` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.last_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.max_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.samples` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_post_release_cleanup.total_ns` | `0` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.last_ns` | `977857372` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.max_ns` | `977857372` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.samples` | `1` |
| `treedb.cache.checkpoint.stage.command_wal_prefix_close.total_ns` | `977857372` |
| `treedb.cache.checkpoint.stage.command_wal_publish.last_ns` | `452824` |
| `treedb.cache.checkpoint.stage.command_wal_publish.max_ns` | `468349` |
| `treedb.cache.checkpoint.stage.command_wal_publish.samples` | `2` |
| `treedb.cache.checkpoint.stage.command_wal_publish.total_ns` | `921173` |
| `treedb.cache.checkpoint.stage.cutover.last_ns` | `23094349` |
| `treedb.cache.checkpoint.stage.cutover.max_ns` | `36035252` |
| `treedb.cache.checkpoint.stage.cutover.samples` | `3` |
| `treedb.cache.checkpoint.stage.cutover.total_ns` | `80201432` |
| `treedb.cache.checkpoint.stage.flush_all.last_ns` | `1282687971` |
| `treedb.cache.checkpoint.stage.flush_all.max_ns` | `1282687971` |
| `treedb.cache.checkpoint.stage.flush_all.samples` | `2` |
| `treedb.cache.checkpoint.stage.flush_all.total_ns` | `1360019643` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.last_ns` | `20782750` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.max_ns` | `20782750` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.samples` | `2` |
| `treedb.cache.checkpoint.stage.leaf_value_log_sync.total_ns` | `20987649` |
| `treedb.cache.checkpoint.stage.post_maintenance.last_ns` | `30047` |
| `treedb.cache.checkpoint.stage.post_maintenance.max_ns` | `147328` |
| `treedb.cache.checkpoint.stage.post_maintenance.samples` | `2` |
| `treedb.cache.checkpoint.stage.post_maintenance.total_ns` | `177375` |
| `treedb.cache.checkpoint.stage.reducer_publish.last_ns` | `785864` |
| `treedb.cache.checkpoint.stage.reducer_publish.max_ns` | `1904893` |
| `treedb.cache.checkpoint.stage.reducer_publish.samples` | `2` |
| `treedb.cache.checkpoint.stage.reducer_publish.total_ns` | `2690757` |
| `treedb.cache.checkpoint.stage.value_log_flush.last_ns` | `443` |
| `treedb.cache.checkpoint.stage.value_log_flush.max_ns` | `773` |
| `treedb.cache.checkpoint.stage.value_log_flush.samples` | `2` |
| `treedb.cache.checkpoint.stage.value_log_flush.total_ns` | `1216` |
| `treedb.cache.checkpoint.stage.wal_cleanup.last_ns` | `638` |
| `treedb.cache.checkpoint.stage.wal_cleanup.max_ns` | `1048` |
| `treedb.cache.checkpoint.stage.wal_cleanup.samples` | `2` |
| `treedb.cache.checkpoint.stage.wal_cleanup.total_ns` | `1686` |
| `treedb.cache.checkpoint.stage.wal_rotate.last_ns` | `37` |
| `treedb.cache.checkpoint.stage.wal_rotate.max_ns` | `55` |
| `treedb.cache.checkpoint.stage.wal_rotate.samples` | `2` |
| `treedb.cache.checkpoint.stage.wal_rotate.total_ns` | `92` |
| `treedb.cache.checkpoint.total_ms` | `5662.804` |
| `treedb.cache.checkpoint.wait.active_in_flight_bytes_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.active_workers_at_request_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_bytes_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.wait.drained_frontier_units_last` | `0` |
| `treedb.cache.checkpoint.wait.frontier_bytes_at_request_last` | `57600000` |
| `treedb.cache.checkpoint.wait.frontier_drain_bytes_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.wait.frontier_drain_units_per_sec_last` | `0.000000` |
| `treedb.cache.checkpoint.wait.frontier_lanes_at_request_last` | `1` |
| `treedb.cache.checkpoint.wait.frontier_units_at_request_last` | `16` |
| `treedb.cache.checkpoint.wait.post_frontier_bytes_last` | `0` |
| `treedb.cache.checkpoint.wait.post_frontier_lanes_last` | `0` |
| `treedb.cache.checkpoint.wait.post_frontier_units_last` | `0` |
| `treedb.cache.checkpoint.wait.remaining_frontier_bytes_last` | `57600000` |
| `treedb.cache.checkpoint.wait.remaining_frontier_lanes_last` | `1` |
| `treedb.cache.checkpoint.wait.remaining_frontier_units_last` | `16` |
| `treedb.cache.checkpoint.wal_cleanup.considered_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.removed_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_current_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_pre_rotate_last` | `0` |
| `treedb.cache.checkpoint.wal_cleanup.skipped_retained_last` | `0` |
| `treedb.cache.checkpoint.write_cutover.active` | `false` |
| `treedb.cache.command_wal.checkpoint_publish.piggybacked` | `2` |
| `treedb.cache.command_wal.checkpoint_publish.separate` | `0` |
| `treedb.cache.command_wal.cleanup.active` | `false` |
| `treedb.cache.command_wal.cleanup.coalesced_total` | `0` |
| `treedb.cache.command_wal.cleanup.completions_total` | `0` |
| `treedb.cache.command_wal.cleanup.pending` | `false` |
| `treedb.cache.command_wal.cleanup.requests_total` | `0` |
| `treedb.cache.command_wal.cleanup.retries_total` | `0` |
| `treedb.cache.command_wal.external_durability` | `true` |
| `treedb.cache.flush_apply.backend_batch_write_ns_total` | `1605632593` |
| `treedb.cache.flush_apply.backend_write_ns_total` | `2066611387` |
| `treedb.cache.flush_apply.batches_total` | `5` |
| `treedb.cache.flush_apply.build_ns_total` | `266408464` |
| `treedb.cache.flush_apply.bytes_total` | `230400000` |
| `treedb.cache.flush_apply.concurrency` | `6` |
| `treedb.cache.flush_apply.coordinator.active` | `0` |
| `treedb.cache.flush_apply.coordinator.active_assist_skips_total` | `0` |
| `treedb.cache.flush_apply.coordinator.active_workers` | `0` |
| `treedb.cache.flush_apply.coordinator.blocking_fallbacks_total` | `0` |
| `treedb.cache.flush_apply.coordinator.checkpoint_preemptions_total` | `0` |
| `treedb.cache.flush_apply.coordinator.errors_total` | `0` |
| `treedb.cache.flush_apply.coordinator.hard_overload_fallbacks_total` | `0` |
| `treedb.cache.flush_apply.coordinator.in_flight_bytes` | `0` |
| `treedb.cache.flush_apply.coordinator.progress_total` | `5` |
| `treedb.cache.flush_apply.coordinator.progress_wait_ns_total` | `0` |
| `treedb.cache.flush_apply.coordinator.progress_waits_total` | `0` |
| `treedb.cache.flush_apply.coordinator.stall_waits_total` | `0` |
| `treedb.cache.flush_apply.deferred_vlog_pointer_materialize_ns_total` | `13208` |
| `treedb.cache.flush_apply.entries_total` | `2000000` |
| `treedb.cache.flush_apply.foreground_assist_calls_total` | `0` |
| `treedb.cache.flush_apply.foreground_assist_flushes_total` | `0` |
| `treedb.cache.flush_apply.foreground_assist_wait_ns_total` | `0` |
| `treedb.cache.flush_apply.leaf_log_append_bytes_total` | `39190335` |
| `treedb.cache.flush_apply.leaf_log_append_frames_per_op` | `0.022184` |
| `treedb.cache.flush_apply.leaf_log_append_frames_total` | `44368` |
| `treedb.cache.flush_apply.leaf_log_append_ns_total` | `326062412` |
| `treedb.cache.flush_apply.leaf_log_append_records_total` | `86902` |
| `treedb.cache.flush_apply.leaf_log_append_wait_ns_total` | `21387019` |
| `treedb.cache.flush_apply.leaf_log_encode_compress_ns_total` | `93766675` |
| `treedb.cache.flush_apply.planning_ns_total` | `47953` |
| `treedb.cache.flush_apply.span_native` | `true` |
| `treedb.cache.flush_apply.units_total` | `80` |
| `treedb.cache.flush_apply.vlog_flush_ns_total` | `7358` |
| `treedb.cache.flush_apply.vlog_sync_ns_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_extra_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.admitted_runs_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.admitted_runs_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.base_budget_covered_total` | `2` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_bytes_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_memtables_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_ops_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.checkpoint.selected_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.decisions_total` | `5` |
| `treedb.cache.flush_backlog_coalescing.enabled` | `true` |
| `treedb.cache.flush_backlog_coalescing.last_old_leaf_bytes_per_op` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.last_ops_per_span` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.last_single_op_span_ratio` | `0.000000` |
| `treedb.cache.flush_backlog_coalescing.queued_age_ns_max` | `3267302268` |
| `treedb.cache.flush_backlog_coalescing.queued_bytes_max` | `67153760` |
| `treedb.cache.flush_backlog_coalescing.queued_memtables_max` | `16` |
| `treedb.cache.flush_backlog_coalescing.selected_bytes_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_bytes_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_memtables_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_memtables_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_ops_max` | `0` |
| `treedb.cache.flush_backlog_coalescing.selected_ops_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.checkpoint_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.close_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.disabled_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.lane_barrier_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.memory_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.memtable_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.no_pressure_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.ops_budget_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.queue_age_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.queue_depth_total` | `5` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.range_barrier_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.stop_pressure_total` | `0` |
| `treedb.cache.flush_backlog_coalescing.skip.reason.writer_stall_budget_total` | `0` |
| `treedb.cache.flush_span_run.backend_chunks_total` | `76` |
| `treedb.cache.flush_span_run.max_chunks_per_target_leaf` | `0` |
| `treedb.cache.flush_span_run.ops_per_run` | `302881.200000` |
| `treedb.cache.flush_span_run.planned_ops_total` | `1514406` |
| `treedb.cache.flush_span_run.planned_point_ops_total` | `1514406` |
| `treedb.cache.flush_span_run.range_barriers_total` | `0` |
| `treedb.cache.flush_span_run.range_delete_ops_total` | `0` |
| `treedb.cache.flush_span_run.runs_total` | `5` |
| `treedb.cache.flush_span_run.shadowed_ops_total` | `0` |
| `treedb.cache.flush_span_run.single_op_spans_total` | `0` |
| `treedb.cache.flush_span_run.source_memtables_max` | `16` |
| `treedb.cache.flush_span_run.source_memtables_total` | `80` |
| `treedb.cache.flush_span_run.source_point_ops_total` | `2000000` |
| `treedb.cache.flush_span_run.span_bytes_total` | `0` |
| `treedb.cache.flush_span_run.span_ops_total` | `0` |
| `treedb.cache.flush_span_run.target_leaf_spans_total` | `0` |
| `treedb.cache.flush_span_run.target_leaves_split_across_chunks_total` | `0` |
| `treedb.cache.leaf_log_lanes.active` | `7` |
| `treedb.cache.leaf_log_lanes.append_bytes_total` | `39190335` |
| `treedb.cache.leaf_log_lanes.append_calls_total` | `41084` |
| `treedb.cache.leaf_log_lanes.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.append_lanes_used` | `7` |
| `treedb.cache.leaf_log_lanes.append_lock_hold_ns_total` | `186683637` |
| `treedb.cache.leaf_log_lanes.append_lock_wait_ns_total` | `21387019` |
| `treedb.cache.leaf_log_lanes.append_pages_total` | `86902` |
| `treedb.cache.leaf_log_lanes.configured` | `7` |
| `treedb.cache.leaf_log_lanes.lane.00.append_bytes_total` | `15593781` |
| `treedb.cache.leaf_log_lanes.lane.00.append_calls_total` | `18914` |
| `treedb.cache.leaf_log_lanes.lane.00.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.00.append_lock_hold_ns_total` | `19070251` |
| `treedb.cache.leaf_log_lanes.lane.00.append_lock_wait_ns_total` | `20684701` |
| `treedb.cache.leaf_log_lanes.lane.00.append_pages_total` | `40024` |
| `treedb.cache.leaf_log_lanes.lane.00.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.00.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.00.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.00.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.append_bytes_total` | `3897599` |
| `treedb.cache.leaf_log_lanes.lane.01.append_calls_total` | `3936` |
| `treedb.cache.leaf_log_lanes.lane.01.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.append_lock_hold_ns_total` | `27594437` |
| `treedb.cache.leaf_log_lanes.lane.01.append_lock_wait_ns_total` | `119961` |
| `treedb.cache.leaf_log_lanes.lane.01.append_pages_total` | `8027` |
| `treedb.cache.leaf_log_lanes.lane.01.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.01.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.01.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.01.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.append_bytes_total` | `4019327` |
| `treedb.cache.leaf_log_lanes.lane.02.append_calls_total` | `3953` |
| `treedb.cache.leaf_log_lanes.lane.02.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.append_lock_hold_ns_total` | `27403415` |
| `treedb.cache.leaf_log_lanes.lane.02.append_lock_wait_ns_total` | `123764` |
| `treedb.cache.leaf_log_lanes.lane.02.append_pages_total` | `8035` |
| `treedb.cache.leaf_log_lanes.lane.02.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.02.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.02.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.02.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.append_bytes_total` | `4070261` |
| `treedb.cache.leaf_log_lanes.lane.03.append_calls_total` | `3979` |
| `treedb.cache.leaf_log_lanes.lane.03.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.append_lock_hold_ns_total` | `30508060` |
| `treedb.cache.leaf_log_lanes.lane.03.append_lock_wait_ns_total` | `127961` |
| `treedb.cache.leaf_log_lanes.lane.03.append_pages_total` | `8087` |
| `treedb.cache.leaf_log_lanes.lane.03.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.03.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.03.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.03.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.append_bytes_total` | `4076357` |
| `treedb.cache.leaf_log_lanes.lane.04.append_calls_total` | `3985` |
| `treedb.cache.leaf_log_lanes.lane.04.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.append_lock_hold_ns_total` | `29562658` |
| `treedb.cache.leaf_log_lanes.lane.04.append_lock_wait_ns_total` | `130920` |
| `treedb.cache.leaf_log_lanes.lane.04.append_pages_total` | `8062` |
| `treedb.cache.leaf_log_lanes.lane.04.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.04.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.04.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.04.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.append_bytes_total` | `3806600` |
| `treedb.cache.leaf_log_lanes.lane.05.append_calls_total` | `3298` |
| `treedb.cache.leaf_log_lanes.lane.05.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.append_lock_hold_ns_total` | `23081256` |
| `treedb.cache.leaf_log_lanes.lane.05.append_lock_wait_ns_total` | `98996` |
| `treedb.cache.leaf_log_lanes.lane.05.append_pages_total` | `7409` |
| `treedb.cache.leaf_log_lanes.lane.05.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.05.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.05.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.05.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.append_bytes_total` | `3726410` |
| `treedb.cache.leaf_log_lanes.lane.06.append_calls_total` | `3019` |
| `treedb.cache.leaf_log_lanes.lane.06.append_errors_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.append_lock_hold_ns_total` | `29463560` |
| `treedb.cache.leaf_log_lanes.lane.06.append_lock_wait_ns_total` | `100716` |
| `treedb.cache.leaf_log_lanes.lane.06.append_pages_total` | `7258` |
| `treedb.cache.leaf_log_lanes.lane.06.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.lane.06.segment_rotations_total` | `1` |
| `treedb.cache.leaf_log_lanes.lane.06.segments_active` | `1` |
| `treedb.cache.leaf_log_lanes.lane.06.segments_closed` | `0` |
| `treedb.cache.leaf_log_lanes.segment_rotations_idle_total` | `0` |
| `treedb.cache.leaf_log_lanes.segment_rotations_total` | `7` |
| `treedb.cache.memtable_mode` | `append_only` |
| `treedb.cache.memtable_residency.mutable.append_only.count` | `16` |
| `treedb.cache.memtable_residency.mutable.append_only.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.append_only.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.count` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.btree.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.count` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.count` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.total.count` | `16` |
| `treedb.cache.memtable_residency.mutable.total.entries` | `0` |
| `treedb.cache.memtable_residency.mutable.total.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.mutable.total.size_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.mutable.total.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.count` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entries` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.append_only.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.btree.count` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entries` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.btree.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.btree.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.count` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entries` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.count` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entries` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.total.count` | `0` |
| `treedb.cache.memtable_residency.queue.total.entries` | `0` |
| `treedb.cache.memtable_residency.queue.total.entry_backing_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.entry_capacity` | `0` |
| `treedb.cache.memtable_residency.queue.total.size_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_active_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_active_chunks` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_retained_bytes` | `0` |
| `treedb.cache.memtable_residency.queue.total.value_arena_retained_chunks` | `0` |
| `treedb.cache.queue_backlog_bytes` | `0` |
| `treedb.cache.queue_laneid_misses` | `0` |
| `treedb.cache.queue_len` | `0` |
| `treedb.cache.stats.backend_write_batches_total` | `76` |
| `treedb.cache.vlog_auto.bypass_bytes` | `0` |
| `treedb.cache.vlog_auto.bytes.block_lz4` | `305876814` |
| `treedb.cache.vlog_auto.bytes.block_snappy` | `0` |
| `treedb.cache.vlog_auto.bytes.block_zstd` | `0` |
| `treedb.cache.vlog_auto.bytes.dict` | `0` |
| `treedb.cache.vlog_auto.bytes.off` | `0` |
| `treedb.cache.vlog_auto.frames.block_lz4` | `44368` |
| `treedb.cache.vlog_auto.frames.block_snappy` | `0` |
| `treedb.cache.vlog_auto.frames.block_zstd` | `0` |
| `treedb.cache.vlog_auto.frames.dict` | `0` |
| `treedb.cache.vlog_auto.frames.off` | `0` |
| `treedb.cache.vlog_auto.frames_frac.block_lz4` | `1.000000` |
| `treedb.cache.vlog_auto.hold_enters` | `0` |
| `treedb.cache.vlog_auto.hold_exits` | `0` |
| `treedb.cache.vlog_auto.probe_attempts` | `0` |
| `treedb.cache.vlog_auto.probe_successes` | `0` |
| `treedb.cache.vlog_autotune.encode_ns_per_raw_byte` | `0.709` |
| `treedb.cache.vlog_autotune.io_ns_per_stored_byte` | `9.710` |
| `treedb.cache.vlog_autotune.observed_ratio` | `0.079182` |
| `treedb.cache.vlog_autotune.throughput_raw_MBps` | `1372.583` |
| `treedb.cache.vlog_block.k.avg.lz4` | `1.959` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_1` | `29110` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_2` | `5217` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_4` | `6570` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.lz4.le_8` | `3471` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_1` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_2` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_4` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.snappy.le_8` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_1` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_16` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_2` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_255` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_32` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_4` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_64` | `0` |
| `treedb.cache.vlog_block.k.bucket.zstd.le_8` | `0` |
| `treedb.cache.vlog_block.k.count.lz4` | `44368` |
| `treedb.cache.vlog_block.k.count.snappy` | `0` |
| `treedb.cache.vlog_block.k.count.zstd` | `0` |
| `treedb.cache.vlog_block.k.max.lz4` | `8` |
| `treedb.cache.vlog_block.k.max.snappy` | `0` |
| `treedb.cache.vlog_block.k.max.zstd` | `0` |
| `treedb.cache.vlog_block.ratio.lz4` | `0.119493` |
| `treedb.cache.vlog_block.ratio.samples.lz4` | `0` |
| `treedb.cache.vlog_block.ratio.samples.snappy` | `0` |
| `treedb.cache.vlog_block.ratio.samples.zstd` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.capacity_waste_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.copied_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_fit_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_fit_requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.dst_present_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_compressed_fallback.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_current_mmap_direct_decode.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_current_mmap_direct_decode.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_fit_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_fit_requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.dst_present_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_decoded_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_template_encoded_payload.calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.read_append_template_encoded_payload.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.realloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_buffer_grow.requested_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retain_max_bytes` | `131072` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_buffers` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_bytes` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.retained_files` | `0` |
| `treedb.cache.vlog_decode_scratch.file_stash.spare_max_count` | `2` |
| `treedb.cache.vlog_decode_scratch.large_pool.alloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.entries` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.gets_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.hits_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.max_entries` | `8` |
| `treedb.cache.vlog_decode_scratch.large_pool.misses_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.puts_total` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.retained_buffers` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.retained_bytes` | `0` |
| `treedb.cache.vlog_decode_scratch.large_pool.too_small_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.alloc_calls_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.allocated_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.oversize.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.alloc_calls_total` | `111` |
| `treedb.cache.vlog_decode_scratch.small_pool.allocated_bytes_total` | `3425523` |
| `treedb.cache.vlog_decode_scratch.small_pool.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.drops_total` | `0` |
| `treedb.cache.vlog_decode_scratch.small_pool.entries` | `9` |
| `treedb.cache.vlog_decode_scratch.small_pool.gets_total` | `13097` |
| `treedb.cache.vlog_decode_scratch.small_pool.hits_total` | `12986` |
| `treedb.cache.vlog_decode_scratch.small_pool.max_entries` | `128` |
| `treedb.cache.vlog_decode_scratch.small_pool.misses_total` | `111` |
| `treedb.cache.vlog_decode_scratch.small_pool.puts_total` | `13076` |
| `treedb.cache.vlog_decode_scratch.small_pool.retained_buffers` | `9` |
| `treedb.cache.vlog_decode_scratch.small_pool.retained_bytes` | `293427` |
| `treedb.cache.vlog_decode_scratch.small_pool.too_small_total` | `81` |
| `treedb.cache.vlog_dict.attempted_frac` | `1.000000` |
| `treedb.cache.vlog_dict.cached_dict_bytes` | `0` |
| `treedb.cache.vlog_dict.cached_dict_id` | `0` |
| `treedb.cache.vlog_dict.classifier.sampled` | `0` |
| `treedb.cache.vlog_dict.classifier.skipped` | `0` |
| `treedb.cache.vlog_dict.current_k` | `0` |
| `treedb.cache.vlog_dict.frames_attempted` | `44368` |
| `treedb.cache.vlog_dict.frames_kept` | `44368` |
| `treedb.cache.vlog_dict.frames_total` | `44368` |
| `treedb.cache.vlog_dict.incompressible_bypass_bytes` | `0` |
| `treedb.cache.vlog_dict.incompressible_hits` | `0` |
| `treedb.cache.vlog_dict.incompressible_hold_remaining_bytes` | `0` |
| `treedb.cache.vlog_dict.incompressible_holds` | `0` |
| `treedb.cache.vlog_dict.kept_frac` | `1.000000` |
| `treedb.cache.vlog_dict.last_applied_dict_hash` | `0` |
| `treedb.cache.vlog_dict.last_applied_dict_id` | `0` |
| `treedb.cache.vlog_dict.last_k_update_unix_nano` | `0` |
| `treedb.cache.vlog_dict.last_publish_unix_nano` | `0` |
| `treedb.cache.vlog_dict.pause_remaining_bytes` | `0` |
| `treedb.cache.vlog_dict.trainer.last_accept_unix_nano` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_accepts` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_attempts` | `0` |
| `treedb.cache.vlog_dict.trainer.profile_reject_reason` | `` |
| `treedb.cache.vlog_dict.trainer.profile_rejects` | `0` |
| `treedb.cache.vlog_generation.bytes.live.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.live.hot` | `39190335` |
| `treedb.cache.vlog_generation.bytes.live.total` | `39190335` |
| `treedb.cache.vlog_generation.bytes.live.warm` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.hot` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.total` | `0` |
| `treedb.cache.vlog_generation.bytes.stale.warm` | `0` |
| `treedb.cache.vlog_generation.bytes.total.cold` | `0` |
| `treedb.cache.vlog_generation.bytes.total.hot` | `39190335` |
| `treedb.cache.vlog_generation.bytes.total.total` | `39190335` |
| `treedb.cache.vlog_generation.bytes.total.warm` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.active` | `false` |
| `treedb.cache.vlog_generation.checkpoint_kick.gc_runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.hot_no_debt_wake.running` | `true` |
| `treedb.cache.vlog_generation.checkpoint_kick.hot_no_debt_wake.runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.pending` | `false` |
| `treedb.cache.vlog_generation.checkpoint_kick.rewrite_runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.runs` | `0` |
| `treedb.cache.vlog_generation.checkpoint_kick.skipped_hot_no_debt` | `2` |
| `treedb.cache.vlog_generation.churn_bytes_per_sec` | `0` |
| `treedb.cache.vlog_generation.churn_bytes_total` | `31223972` |
| `treedb.cache.vlog_generation.cold.segment_target_bytes` | `536870912` |
| `treedb.cache.vlog_generation.deferred_vector_build.active` | `false` |
| `treedb.cache.vlog_generation.deferred_vector_build.debt` | `false` |
| `treedb.cache.vlog_generation.deferred_vector_build.debt_set` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.failures` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.finalizations` | `0` |
| `treedb.cache.vlog_generation.deferred_vector_build.skips` | `0` |
| `treedb.cache.vlog_generation.enabled` | `true` |
| `treedb.cache.vlog_generation.gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.deleted_segments` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_eligible_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_eligible_segments` | `0` |
| `treedb.cache.vlog_generation.gc.dry_run.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.gc.exec.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.gc.exec.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.gc.exec.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.gc.last_active_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_active_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_deleted_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_eligible_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_eligible_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_active` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_deleted` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_eligible` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_pending` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_in_use` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_other` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_overlap` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_protected_retained` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.bytes_referenced` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_active` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_deleted` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_eligible` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_pending` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_in_use` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_other` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_overlap` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_protected_retained` | `0` |
| `treedb.cache.vlog_generation.gc.last_observed_source.segments_referenced` | `0` |
| `treedb.cache.vlog_generation.gc.last_pending_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_pending_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_in_use_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_in_use_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_other_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_other_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_overlap_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_overlap_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_retained_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_retained_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_protected_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_referenced_bytes` | `0` |
| `treedb.cache.vlog_generation.gc.last_referenced_segments` | `0` |
| `treedb.cache.vlog_generation.gc.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.gc.runs` | `0` |
| `treedb.cache.vlog_generation.hot.segment_target_bytes` | `268435456` |
| `treedb.cache.vlog_generation.leaf.segment_target_bytes` | `33554432` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_manifest_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.deleted_manifest_revisions` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.errors` | `0` |
| `treedb.cache.vlog_generation.leaf_gc.exec.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.leaf_gc.runs` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.admitted` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attempts` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attributed_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.attributed_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.bytes_copied` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.canceled` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.deadline` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.deadline_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.errors` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.expected_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.expected_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.eligible_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_files` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_deleted_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.last_eligible_generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.gc.runs` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_attributed_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_attributed_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_bytes_copied` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_expected_reclaim_bytes` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_expected_reclaim_per_byte_copied_ppm` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.bytes_dead` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.bytes_to_copy` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_selection.generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_skip_reason` | `` |
| `treedb.cache.vlog_generation.leaf_pack.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.last_wall_ms` | `0.000` |
| `treedb.cache.vlog_generation.leaf_pack.max_bytes_to_copy` | `268435456` |
| `treedb.cache.vlog_generation.leaf_pack.max_foreground_queue` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.max_generations` | `32` |
| `treedb.cache.vlog_generation.leaf_pack.min_candidate_generations` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.min_interval_ms` | `30000` |
| `treedb.cache.vlog_generation.leaf_pack.min_reclaim_per_byte_copied_ppm` | `250000` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_default` | `false` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_last_attempt_unix_nano` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_max_bytes_to_copy` | `33554432` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_max_generations` | `2` |
| `treedb.cache.vlog_generation.leaf_pack.private_cow_timeout_ms` | `5000` |
| `treedb.cache.vlog_generation.leaf_pack.runs` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.bytes_dead` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.bytes_to_copy` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.selection.generations` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.foreground_iterators` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.min_interval` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.queue_pressure` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skip.write_burst` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.skips` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.stop.low_yield` | `0` |
| `treedb.cache.vlog_generation.leaf_pack.timeout_ms` | `30000` |
| `treedb.cache.vlog_generation.leaf_pack.write_burst_grace_ms` | `250` |
| `treedb.cache.vlog_generation.maintenance.acquired` | `4` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.periodic` | `4` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.acquired.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.active` | `false` |
| `treedb.cache.vlog_generation.maintenance.attempts` | `4` |
| `treedb.cache.vlog_generation.maintenance.collisions` | `0` |
| `treedb.cache.vlog_generation.maintenance.foreground_active_iterators` | `0` |
| `treedb.cache.vlog_generation.maintenance.foreground_last_read_unix_nano` | `1795198078909929312` |
| `treedb.cache.vlog_generation.maintenance.foreground_last_write_unix_nano` | `1795198075342240231` |
| `treedb.cache.vlog_generation.maintenance.foreground_quiet` | `false` |
| `treedb.cache.vlog_generation.maintenance.foreground_read_age_ms` | `2462` |
| `treedb.cache.vlog_generation.maintenance.foreground_read_quiet` | `true` |
| `treedb.cache.vlog_generation.maintenance.foreground_write_age_ms` | `6029` |
| `treedb.cache.vlog_generation.maintenance.foreground_write_quiet` | `false` |
| `treedb.cache.vlog_generation.maintenance.pass.avg_ms` | `0.005` |
| `treedb.cache.vlog_generation.maintenance.pass.max_ms` | `0.005` |
| `treedb.cache.vlog_generation.maintenance.pass.total_ms` | `0.018` |
| `treedb.cache.vlog_generation.maintenance.passes.noop` | `4` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.periodic` | `4` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.noop.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_gc.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_leaf_pack.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.bypass` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.other` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.passes.with_rewrite.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.maintenance.pause_file.configured` | `false` |
| `treedb.cache.vlog_generation.maintenance.pause_file.paused` | `false` |
| `treedb.cache.vlog_generation.maintenance.skip.age_blocked_gate` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.before_first_checkpoint` | `2` |
| `treedb.cache.vlog_generation.maintenance.skip.checkpoint_inflight` | `2` |
| `treedb.cache.vlog_generation.maintenance.skip.maintenance_phase` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.pause_file` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.priority_pending` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.quiet_window` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate_due_reserved` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.stage_gate_not_due` | `0` |
| `treedb.cache.vlog_generation.maintenance.skip.wal_on_periodic` | `0` |
| `treedb.cache.vlog_generation.maintenance_phase` | `steady` |
| `treedb.cache.vlog_generation.observed_gc.latency.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.observed_gc.latency.completed_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.dropped_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.max_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.latency.total_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_oldest_age_ms` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_oldest_unix_nano` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_attempts_max` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_attempts_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.pending_retry_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.queued_batches` | `0` |
| `treedb.cache.vlog_generation.observed_gc.queued_ids` | `0` |
| `treedb.cache.vlog_generation.observed_gc.retry_dropped` | `0` |
| `treedb.cache.vlog_generation.observed_gc.retry_max_attempts` | `3` |
| `treedb.cache.vlog_generation.observed_gc.retry_queued` | `0` |
| `treedb.cache.vlog_generation.observed_gc.runs` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_deleted_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_eligible_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_in_use_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_other_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_overlap_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_protected_retained_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_bytes_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_deleted_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_eligible_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_in_use_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_other_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_overlap_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_protected_retained_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.source_segments_total` | `0` |
| `treedb.cache.vlog_generation.observed_gc.taken_batches` | `0` |
| `treedb.cache.vlog_generation.observed_gc.taken_ids` | `0` |
| `treedb.cache.vlog_generation.policy` | `2` |
| `treedb.cache.vlog_generation.remap.failures` | `0` |
| `treedb.cache.vlog_generation.remap.successes` | `0` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_due` | `false` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_remaining_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.age_blocked_until_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.bytes_in` | `0` |
| `treedb.cache.vlog_generation.rewrite.bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.canceled_runs.queued_debt` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.deadline_runs.queued_debt` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.bytes_in_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.bytes_out_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.last_duration_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_live_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.last_live_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.reclaimed_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.exec.reclaimed_vs_churn_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_requested_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_still_referenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_still_referenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_bytes_unreferenced_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_chunks_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_requested_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_requested_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_still_referenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_still_referenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_unreferenced_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.source_segments_unreferenced_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.exec.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.ineffective_backoff_seconds` | `120` |
| `treedb.cache.vlog_generation.rewrite.ineffective_bytes_in` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_bytes_out` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.ineffective_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_chunk_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_chunks` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.ledger_stale_ratio_ppm` | `0` |
| `treedb.cache.vlog_generation.rewrite.min_segment_age_ms` | `30000` |
| `treedb.cache.vlog_generation.rewrite.no_reclaim_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.no_reclaim_stale_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.output_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.penalties_active` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.plan_canceled` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_canceled_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty.age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_empty.no_selection` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_errors` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_penalty_filter.to_empty_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_chunks_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.plan_selected_segments_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_live_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_stale_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.processed_stale_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.queue.pending` | `false` |
| `treedb.cache.vlog_generation.rewrite.queue.running` | `false` |
| `treedb.cache.vlog_generation.rewrite.queue_config.debt_drain_max_segments` | `8` |
| `treedb.cache.vlog_generation.rewrite.queue_config.fresh_plan_debt_drain_max_segments` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_config.fresh_plan_debt_drain_min_segments` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_config.resume_max_segments` | `1` |
| `treedb.cache.vlog_generation.rewrite.queue_eta_seconds.budget` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_eta_seconds.recent_exec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_len` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_bytes_after_tokens` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.coverage_pct` | `0.000` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.ids_known` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.ids_present` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_live_hint.known` | `true` |
| `treedb.cache.vlog_generation.rewrite.queue_loaded` | `true` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_after_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_after_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_before_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_before_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_delta_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_drained_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_grown_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_known_passes` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.live_bytes_unknown_passes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.passes` | `4` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_after_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_after_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_before_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_before_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_delta_last` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_drained_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.segments_grown_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_progress.snapshot_errors` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_prune_ids` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_prune_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.by_budget.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.decisions` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.decisions.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter.checkpoint_kick` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter.fresh_plan` | `none` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_empty.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_per_segment` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_per_segment.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_tokens` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.budget_tokens.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_burst` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_burst.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_safety` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.checkpoint_kick_safety.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.debt_drain_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.debt_drain_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_cap` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_cap.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_queue_threshold` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.fresh_plan_queue_threshold.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.none` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.none.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.queue_len` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.queue_len.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.resume_default` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.limiter_count.resume_default.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes.checkpoint_kick` | `0` |
| `treedb.cache.vlog_generation.rewrite.queue_run_segment_cap.per_segment_budget_bytes.fresh_plan` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.effective_bytes_after` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.effective_bytes_before` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.gc_bytes_deleted` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.no_reclaim_runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_live` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_stale` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.plan_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.reclaimed_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.segments` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.source_bytes_requested` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.exec.source_bytes_unreferenced` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.followup_suppressed` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.passes` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.rewrite_started` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.budget_empty` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.cancel_backoff` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.ineffective_backoff` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.min_interval` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.no_chunk` | `0` |
| `treedb.cache.vlog_generation.rewrite.queued_debt.skip.quiet_window` | `0` |
| `treedb.cache.vlog_generation.rewrite.reclaim_ratio` | `0.000000` |
| `treedb.cache.vlog_generation.rewrite.reclaimed_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite.runs.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_due` | `false` |
| `treedb.cache.vlog_generation.rewrite.stage_due_in_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_observed_age_ms` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_observed_unix_nano` | `0` |
| `treedb.cache.vlog_generation.rewrite.stage_pending` | `false` |
| `treedb.cache.vlog_generation.rewrite.value_bytes_copied` | `0` |
| `treedb.cache.vlog_generation.rewrite.value_records_copied` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.bytes_per_sec` | `134217728` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_per_sec` | `0.000` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.bypass` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.checkpoint_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.other` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.periodic` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_age_blocked` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_queue_pending` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_bytes_total.source.rewrite_stage_confirm` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.consumed_share_of_budget_pct` | `0.000` |
| `treedb.cache.vlog_generation.rewrite_budget.records_per_sec` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_bytes` | `0` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_cap_bytes` | `4294967296` |
| `treedb.cache.vlog_generation.rewrite_budget.tokens_utilization_pct` | `0.000` |
| `treedb.cache.vlog_generation.rewrite_trigger.churn_per_sec` | `0` |
| `treedb.cache.vlog_generation.rewrite_trigger.stale_ratio_ppm` | `200000` |
| `treedb.cache.vlog_generation.rewrite_trigger.total_bytes` | `4294967296` |
| `treedb.cache.vlog_generation.scheduler_last_reason` | `none` |
| `treedb.cache.vlog_generation.scheduler_state` | `idle` |
| `treedb.cache.vlog_generation.segments.cold` | `0` |
| `treedb.cache.vlog_generation.segments.hot` | `7` |
| `treedb.cache.vlog_generation.segments.total` | `7` |
| `treedb.cache.vlog_generation.segments.warm` | `0` |
| `treedb.cache.vlog_generation.vacuum.exec.avg_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.exec.max_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.exec.total_ms` | `0.000` |
| `treedb.cache.vlog_generation.vacuum.failures` | `0` |
| `treedb.cache.vlog_generation.vacuum.last_unix_nano` | `0` |
| `treedb.cache.vlog_generation.vacuum.runs` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_cooldown` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_disabled` | `0` |
| `treedb.cache.vlog_generation.vacuum.skipped_rewrite_bytes` | `0` |
| `treedb.cache.vlog_generation.warm.segment_target_bytes` | `268435456` |
| `treedb.cache.vlog_grouped_frame_cache.allocated_shards` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.allocated_slots` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.budget_bytes` | `67108864` |
| `treedb.cache.vlog_grouped_frame_cache.capacity` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.entries` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.evictions` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.hits` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.misses` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.releases` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.retained_bytes` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_budget` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_contention` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_disabled` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.skipped_oversize` | `0` |
| `treedb.cache.vlog_grouped_frame_cache.stores` | `0` |
| `treedb.cache.vlog_io.bytes` | `0` |
| `treedb.cache.vlog_io.syscalls` | `0` |
| `treedb.cache.vlog_mmap.active_bytes` | `0` |
| `treedb.cache.vlog_mmap.active_segments` | `0` |
| `treedb.cache.vlog_mmap.current_bytes` | `0` |
| `treedb.cache.vlog_mmap.current_segments` | `0` |
| `treedb.cache.vlog_mmap.current_writable_map_target_bytes` | `33554432` |
| `treedb.cache.vlog_mmap.dead_bytes` | `0` |
| `treedb.cache.vlog_mmap.dead_mappings` | `0` |
| `treedb.cache.vlog_mmap.dead_mappings.cap_base` | `64` |
| `treedb.cache.vlog_mmap.max_mapped_leaf_sealed_bytes` | `1610612736` |
| `treedb.cache.vlog_mmap.max_mapped_leaf_sealed_segments` | `512` |
| `treedb.cache.vlog_mmap.max_mapped_sealed_bytes` | `67108864` |
| `treedb.cache.vlog_mmap.max_mapped_sealed_segments` | `8` |
| `treedb.cache.vlog_mmap.read.fallback_readat` | `0` |
| `treedb.cache.vlog_mmap.read.hits` | `0` |
| `treedb.cache.vlog_mmap.read.miss_dead_mapping_cap` | `0` |
| `treedb.cache.vlog_mmap.read.miss_no_mapping` | `0` |
| `treedb.cache.vlog_mmap.read.miss_out_of_range` | `0` |
| `treedb.cache.vlog_mmap.remaps` | `0` |
| `treedb.cache.vlog_mmap.sealed_bytes` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied.bytes_cap` | `0` |
| `treedb.cache.vlog_mmap.sealed_map_denied.count_cap` | `0` |
| `treedb.cache.vlog_mmap.sealed_segments` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.legacy_page` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.frames.unknown` | `44368` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.legacy_page` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.raw_bytes.unknown` | `305876814` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.legacy_page` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.lz4` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.mixed` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.none` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.snappy` | `0` |
| `treedb.cache.vlog_outer_leaf_codec.stored_bytes.unknown` | `36550263` |
| `treedb.cache.vlog_outer_leaf_codec.stored_ratio.unknown` | `0.119493` |
| `treedb.cache.vlog_payload_kind.frames.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.frames.outer_leaf` | `44368` |
| `treedb.cache.vlog_payload_kind.frames.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.raw_bytes.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.raw_bytes.outer_leaf` | `305876814` |
| `treedb.cache.vlog_payload_kind.raw_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.stored_bytes.mixed` | `0` |
| `treedb.cache.vlog_payload_kind.stored_bytes.outer_leaf` | `36550263` |
| `treedb.cache.vlog_payload_kind.stored_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_kind.stored_ratio.outer_leaf` | `0.119493` |
| `treedb.cache.vlog_payload_split.frames.outer_leaf` | `44368` |
| `treedb.cache.vlog_payload_split.raw_bytes.outer_leaf` | `305876814` |
| `treedb.cache.vlog_payload_split.raw_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_split.records.outer_leaf` | `86902` |
| `treedb.cache.vlog_payload_split.records.single_value` | `0` |
| `treedb.cache.vlog_payload_split.stored_bytes.outer_leaf` | `36550263` |
| `treedb.cache.vlog_payload_split.stored_bytes.single_value` | `0` |
| `treedb.cache.vlog_payload_split.stored_ratio.outer_leaf` | `0.119493` |
| `treedb.cache.vlog_read.crc32_checks_total` | `0` |
| `treedb.cache.vlog_retained_bytes_estimate` | `39190335` |
| `treedb.cache.vlog_retained_prune.active` | `false` |
| `treedb.cache.vlog_retained_prune.budget_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.candidate_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.candidate_segments` | `0` |
| `treedb.cache.vlog_retained_prune.close_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.closed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.completed_runs` | `0` |
| `treedb.cache.vlog_retained_prune.error_runs` | `0` |
| `treedb.cache.vlog_retained_prune.force_pending` | `false` |
| `treedb.cache.vlog_retained_prune.forced_runs` | `0` |
| `treedb.cache.vlog_retained_prune.foreground_abort_runs` | `0` |
| `treedb.cache.vlog_retained_prune.full_live_id_scan_runs` | `0` |
| `treedb.cache.vlog_retained_prune.in_use_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.in_use_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.inflight` | `false` |
| `treedb.cache.vlog_retained_prune.last_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.last_force` | `false` |
| `treedb.cache.vlog_retained_prune.last_mode` | `none` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_candidate` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_in_use_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_live_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_parse_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_removed` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.bytes_zombie_marked` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_candidate` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_in_use_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_live_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_parse_skipped` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_removed` | `0` |
| `treedb.cache.vlog_retained_prune.last_observed_source.segments_zombie_marked` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.nested_value_pointers` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.outer_leaf_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.outer_leaf_records` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.records` | `0` |
| `treedb.cache.vlog_retained_prune.last_scan.value_pointer_records` | `0` |
| `treedb.cache.vlog_retained_prune.last_start_unix_nano` | `0` |
| `treedb.cache.vlog_retained_prune.last_status` | `none` |
| `treedb.cache.vlog_retained_prune.last_unix_nano` | `0` |
| `treedb.cache.vlog_retained_prune.live_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.live_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.max_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.no_candidate_runs` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_candidate_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_in_use_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_live_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_parse_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_removed_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.bytes_zombie_marked_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_candidate_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_in_use_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_live_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_parse_skipped_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_removed_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source.segments_zombie_marked_total` | `0` |
| `treedb.cache.vlog_retained_prune.observed_source_fast_path_runs` | `0` |
| `treedb.cache.vlog_retained_prune.parse_skipped_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.parse_skipped_segments` | `0` |
| `treedb.cache.vlog_retained_prune.pressure_bytes` | `17179869164` |
| `treedb.cache.vlog_retained_prune.removed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.removed_segments` | `0` |
| `treedb.cache.vlog_retained_prune.runs` | `0` |
| `treedb.cache.vlog_retained_prune.scan.nested_value_pointers_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.outer_leaf_bytes_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.outer_leaf_records_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.records_total` | `0` |
| `treedb.cache.vlog_retained_prune.scan.value_pointer_records_total` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_forced_requests` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_requests` | `3` |
| `treedb.cache.vlog_retained_prune.schedule_skip.below_pressure` | `3` |
| `treedb.cache.vlog_retained_prune.schedule_skip.closing` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.inflight` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.min_interval` | `0` |
| `treedb.cache.vlog_retained_prune.schedule_skip.no_closed_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.total_elapsed_ms` | `0.000` |
| `treedb.cache.vlog_retained_prune.write_gate_retries` | `0` |
| `treedb.cache.vlog_retained_prune.write_gate_retry_successes` | `0` |
| `treedb.cache.vlog_retained_prune.zombie_marked_bytes` | `0` |
| `treedb.cache.vlog_retained_prune.zombie_marked_segments` | `0` |
| `treedb.cache.vlog_retained_segments` | `7` |
| `treedb.cache.vlog_template_def_cache.hits` | `0` |
| `treedb.cache.vlog_template_def_cache.misses` | `0` |
| `treedb.cache.vlog_write.bytes` | `0` |
| `treedb.cache.vlog_write.calls` | `0` |
| `treedb.cache.vlog_write.syscalls` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.frames.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.raw_bytes.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.block.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.dict.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.gt_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_1024` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_131072` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_16384` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_2048` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_32768` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_4096` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_49152` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_65536` | `0` |
| `treedb.cache.vlog_write_mode.bucket.stored_bytes.off.le_8192` | `0` |
| `treedb.cache.vlog_write_mode.frames.block` | `44368` |
| `treedb.cache.vlog_write_mode.frames.dict` | `0` |
| `treedb.cache.vlog_write_mode.frames.off` | `0` |
| `treedb.cache.vlog_write_mode.raw_bytes.block` | `305876814` |
| `treedb.cache.vlog_write_mode.raw_bytes.dict` | `0` |
| `treedb.cache.vlog_write_mode.raw_bytes.off` | `0` |
| `treedb.cache.vlog_write_mode.stored_bytes.block` | `36550263` |
| `treedb.cache.vlog_write_mode.stored_bytes.dict` | `0` |
| `treedb.cache.vlog_write_mode.stored_bytes.off` | `0` |
| `treedb.cache.vlog_write_mode.stored_ratio.block` | `0.119493` |
| `treedb.cache.vlog_writer_append_buf.alloc_calls_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.allocated_bytes_total` | `29360128` |
| `treedb.cache.vlog_writer_append_buf.dropped_bytes_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.drops_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.gets_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.hits_total` | `0` |
| `treedb.cache.vlog_writer_append_buf.misses_total` | `7` |
| `treedb.cache.vlog_writer_append_buf.pool.entries` | `0` |
| `treedb.cache.vlog_writer_append_buf.pool.max_entries` | `16` |
| `treedb.cache.vlog_writer_append_buf.pool.retained_buffers` | `0` |
| `treedb.cache.vlog_writer_append_buf.pool.retained_bytes` | `0` |
| `treedb.cache.vlog_writer_append_buf.puts_total` | `0` |
| `treedb.cache.vlog_writev.bytes` | `0` |
| `treedb.cache.vlog_writev.flushes` | `0` |
| `treedb.cache.vlog_writev.iovecs` | `0` |
| `treedb.cache.vlog_writev.syscalls` | `0` |
| `treedb.cache.vlog_zombie.bytes` | `0` |
| `treedb.cache.vlog_zombie.pinned_bytes` | `0` |
| `treedb.cache.vlog_zombie.pinned_segments` | `0` |
| `treedb.cache.vlog_zombie.segments` | `0` |
| `treedb.cache.vlog_zombie.unpinned_bytes` | `0` |
| `treedb.cache.vlog_zombie.unpinned_segments` | `0` |
| `treedb.cache.write.wait_for_checkpoint.count_total` | `0` |
| `treedb.cache.write.wait_for_checkpoint.ns_total` | `0` |
| `treedb.command_wal.active_segment.name` | `` |
| `treedb.command_wal.active_segments` | `0` |
| `treedb.command_wal.append.count_total` | `1002100` |
| `treedb.command_wal.append.entry_scan.count_total` | `50` |
| `treedb.command_wal.append.entry_scan.ns_total` | `24164908` |
| `treedb.command_wal.append.intent.count_total` | `0` |
| `treedb.command_wal.append.intent.ns_total` | `0` |
| `treedb.command_wal.append.ns_total` | `713214253` |
| `treedb.command_wal.append.payload.count_total` | `2050` |
| `treedb.command_wal.append.payload.ns_total` | `87144388` |
| `treedb.command_wal.append.point.count_total` | `1000000` |
| `treedb.command_wal.append.point.ns_total` | `601904957` |
| `treedb.command_wal.applied_lsn` | `1002100` |
| `treedb.command_wal.bytes` | `0` |
| `treedb.command_wal.bytes.active` | `0` |
| `treedb.command_wal.bytes.total` | `0` |
| `treedb.command_wal.cleanup.covered_bytes_total` | `692249600` |
| `treedb.command_wal.cleanup.covered_segments_total` | `23` |
| `treedb.command_wal.cleanup.namespace_sync.calls_total` | `2` |
| `treedb.command_wal.cleanup.namespace_sync.errors_total` | `0` |
| `treedb.command_wal.cleanup.namespace_sync.pending` | `false` |
| `treedb.command_wal.cleanup.ns_total` | `4029250187` |
| `treedb.command_wal.cleanup.oldest_pinned_lsn` | `0` |
| `treedb.command_wal.cleanup.proof.capture_epoch` | `1002118` |
| `treedb.command_wal.cleanup.proof.count_total` | `7` |
| `treedb.command_wal.cleanup.proof.durable_wal_lsn` | `1002100` |
| `treedb.command_wal.cleanup.proof.frontier_lsn` | `1002100` |
| `treedb.command_wal.cleanup.proof.namespace_generation` | `18` |
| `treedb.command_wal.cleanup.proof.ns_total` | `26394` |
| `treedb.command_wal.cleanup.proof.older_root_commit_seq` | `7` |
| `treedb.command_wal.cleanup.proof.selected_root_commit_seq` | `8` |
| `treedb.command_wal.cleanup.removed_bytes` | `662853632` |
| `treedb.command_wal.cleanup.removed_bytes_total` | `662853632` |
| `treedb.command_wal.cleanup.removed_segments` | `16` |
| `treedb.command_wal.cleanup.removed_segments_total` | `16` |
| `treedb.command_wal.cleanup.retained.reason.active_segments_total` | `7` |
| `treedb.command_wal.cleanup.retained.reason.error_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.pinned_segments_total` | `0` |
| `treedb.command_wal.cleanup.retained.reason.uncovered_segments_total` | `32` |
| `treedb.command_wal.cleanup.retained_bytes_total` | `1355103232` |
| `treedb.command_wal.cleanup.retained_segments_total` | `39` |
| `treedb.command_wal.cleanup.retries_total` | `0` |
| `treedb.command_wal.cleanup.scan.count_total` | `7` |
| `treedb.command_wal.cleanup.scan.ns_total` | `3949979495` |
| `treedb.command_wal.cleanup.scanned_bytes_total` | `1051741800` |
| `treedb.command_wal.cleanup.scanned_frames_total` | `3006300` |
| `treedb.command_wal.cleanup.scans` | `7` |
| `treedb.command_wal.cleanup.unlinked_sync_pending_bytes` | `0` |
| `treedb.command_wal.cleanup.unlinked_sync_pending_segments` | `0` |
| `treedb.command_wal.dependency_debt.entries` | `0` |
| `treedb.command_wal.dependency_debt.max_age_ns` | `0` |
| `treedb.command_wal.dependency_debt.pending_bytes` | `0` |
| `treedb.command_wal.dependency_debt.pending_count` | `0` |
| `treedb.command_wal.dependency_debt.retries_total` | `0` |
| `treedb.command_wal.directory_sync.calls_total` | `3` |
| `treedb.command_wal.directory_sync.errors_total` | `0` |
| `treedb.command_wal.directory_sync.ns_total` | `15231750` |
| `treedb.command_wal.durable_wal_lsn` | `1002100` |
| `treedb.command_wal.enabled` | `true` |
| `treedb.command_wal.file_sync.calls_total` | `6` |
| `treedb.command_wal.file_sync.errors_total` | `0` |
| `treedb.command_wal.file_sync.ns_total` | `23042085` |
| `treedb.command_wal.flush.barrier.count_total` | `0` |
| `treedb.command_wal.flush.barrier.ns_total` | `0` |
| `treedb.command_wal.flush.count_total` | `1002100` |
| `treedb.command_wal.flush.entry_scan.count_total` | `50` |
| `treedb.command_wal.flush.entry_scan.ns_total` | `23040920` |
| `treedb.command_wal.flush.intent.count_total` | `0` |
| `treedb.command_wal.flush.intent.ns_total` | `0` |
| `treedb.command_wal.flush.ns_total` | `1357773000` |
| `treedb.command_wal.flush.payload.count_total` | `2050` |
| `treedb.command_wal.flush.payload.ns_total` | `29822198` |
| `treedb.command_wal.flush.point.count_total` | `1000000` |
| `treedb.command_wal.flush.point.ns_total` | `1304909882` |
| `treedb.command_wal.frames` | `1002100` |
| `treedb.command_wal.group_commit.attempts_total` | `0` |
| `treedb.command_wal.group_commit.bypass.reason.relaxed_race_no_group_total` | `0` |
| `treedb.command_wal.group_commit.bypass.reason.solo_durable_sync_total` | `0` |
| `treedb.command_wal.group_commit.bypasses_total` | `0` |
| `treedb.command_wal.group_commit.commits_total` | `0` |
| `treedb.command_wal.group_commit.dependency_entries_attempted_total` | `0` |
| `treedb.command_wal.group_commit.dependency_entries_covered_max` | `0` |
| `treedb.command_wal.group_commit.dependency_entries_covered_total` | `0` |
| `treedb.command_wal.group_commit.errors_total` | `0` |
| `treedb.command_wal.group_commit.fallback.reason.coordinator_unavailable_total` | `0` |
| `treedb.command_wal.group_commit.fallbacks_total` | `0` |
| `treedb.command_wal.group_commit.followers_total` | `0` |
| `treedb.command_wal.group_commit.forced_total` | `0` |
| `treedb.command_wal.group_commit.group_size_max` | `0` |
| `treedb.command_wal.group_commit.groups_total` | `0` |
| `treedb.command_wal.group_commit.leaders_total` | `0` |
| `treedb.command_wal.group_commit.participants_total` | `0` |
| `treedb.command_wal.group_commit.syncs_total` | `0` |
| `treedb.command_wal.group_commit.trigger.byte_limit_total` | `0` |
| `treedb.command_wal.group_commit.trigger.commit_limit_total` | `0` |
| `treedb.command_wal.group_commit.trigger.explicit_sync_total` | `0` |
| `treedb.command_wal.group_commit.trigger.sealed_collection_total` | `0` |
| `treedb.command_wal.group_commit.trigger.timeout_total` | `0` |
| `treedb.command_wal.group_commit.wait_ns_max` | `0` |
| `treedb.command_wal.group_commit.wait_ns_total` | `0` |
| `treedb.command_wal.live_accepted_frames` | `1002100` |
| `treedb.command_wal.live_accepted_max_lsn` | `1002100` |
| `treedb.command_wal.live_covered_frames` | `1002100` |
| `treedb.command_wal.live_covered_max_lsn` | `1002100` |
| `treedb.command_wal.live_frames` | `1002100` |
| `treedb.command_wal.live_max_lsn` | `0` |
| `treedb.command_wal.max_lsn` | `1002100` |
| `treedb.command_wal.next_lsn` | `1002101` |
| `treedb.command_wal.public_batch.delete.bytes_total` | `1600000` |
| `treedb.command_wal.public_batch.delete.calls_total` | `200000` |
| `treedb.command_wal.public_batch.delete_view.bytes_total` | `0` |
| `treedb.command_wal.public_batch.delete_view.calls_total` | `0` |
| `treedb.command_wal.public_batch.set.bytes_total` | `54400000` |
| `treedb.command_wal.public_batch.set.calls_total` | `400000` |
| `treedb.command_wal.public_batch.set_view.bytes_total` | `54400000` |
| `treedb.command_wal.public_batch.set_view.calls_total` | `400000` |
| `treedb.command_wal.required_feature` | `true` |
| `treedb.command_wal.segment_files` | `0` |
| `treedb.command_wal.segments.active` | `0` |
| `treedb.command_wal.segments.total` | `0` |
| `treedb.command_wal.stats_scan` | `false` |
| `treedb.command_wal.sync.barrier.count_total` | `4` |
| `treedb.command_wal.sync.barrier.ns_total` | `1835069` |
| `treedb.command_wal.sync.count_total` | `4` |
| `treedb.command_wal.sync.entry_scan.count_total` | `0` |
| `treedb.command_wal.sync.entry_scan.ns_total` | `0` |
| `treedb.command_wal.sync.intent.count_total` | `0` |
| `treedb.command_wal.sync.intent.ns_total` | `0` |
| `treedb.command_wal.sync.ns_total` | `1835069` |
| `treedb.command_wal.sync.payload.count_total` | `0` |
| `treedb.command_wal.sync.payload.ns_total` | `0` |
| `treedb.command_wal.sync.point.count_total` | `0` |
| `treedb.command_wal.sync.point.ns_total` | `0` |
| `treedb.command_wal.typed_segments` | `0` |
| `treedb.command_wal.write.bytes_total` | `576063936` |
| `treedb.command_wal.write.errors_total` | `0` |
| `treedb.command_wal.write.ns_total` | `784264596` |
| `treedb.command_wal.write.syscalls_total` | `1002100` |
| `treedb.command_wal.writer.buffer_size_bytes` | `16777216` |
| `treedb.command_wal.writer.buffered_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.capacity_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.dropped_bytes_total` | `0` |
| `treedb.command_wal.writer.command_buffer.length_bytes` | `0` |
| `treedb.command_wal.writer.command_buffer.limit_bytes` | `67108864` |
| `treedb.command_wal.writer.command_buffer.retain_limit_bytes` | `4194304` |
| `treedb.command_wal.writer.command_buffer.trim_count` | `0` |
| `treedb.command_wal.writer.container` | `fixed` |
| `treedb.command_wal.writer.container_reason` | `persistent_or_unknown_filesystem` |
| `treedb.command_wal.writer.filesystem_type` | `61267` |
| `treedb.command_wal.writer.memory_filesystem` | `false` |
| `treedb.command_wal.writer.path` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/tmp/bench-treedb3623981672/maindb/wal/commit-l0-000017.log` |
| `treedb.command_wal.writer.pending_batch.capacity_bytes` | `0` |
| `treedb.command_wal.writer.pending_batch.length_bytes` | `0` |
| `treedb.command_wal.writer.scratch_capacity_bytes` | `1224320` |
| `treedb.commit_seq` | `8` |
| `treedb.durability_mode` | `wal_on_relaxed_sync` |
| `treedb.flush_admission.admitted` | `true` |
| `treedb.flush_admission.flush_apply_concurrency` | `6` |
| `treedb.flush_admission.flush_apply_concurrency_cap_reason` | `default_physical_cores` |
| `treedb.flush_admission.flush_apply_concurrency_configured` | `0` |
| `treedb.flush_admission.flush_apply_concurrency_defaulted` | `true` |
| `treedb.flush_admission.flush_apply_span_native` | `true` |
| `treedb.flush_admission.flush_backlog_coalescing` | `true` |
| `treedb.flush_admission.gomaxprocs` | `12` |
| `treedb.flush_admission.leaf_page_read_cache_write_admission` | `adaptive` |
| `treedb.flush_admission.physical_cores` | `6` |
| `treedb.flush_admission.policy` | `auto` |
| `treedb.flush_admission.reason` | `auto_admitted_hardware_aware` |
| `treedb.flush_apply.apply_calls_total` | `76` |
| `treedb.flush_apply.apply_errors_total` | `0` |
| `treedb.flush_apply.apply_ns_total` | `492326230` |
| `treedb.flush_apply.apply_ops_total` | `1514406` |
| `treedb.flush_apply.commit_wait_ns_total` | `0` |
| `treedb.flush_apply.guarded_publish.calls_total` | `0` |
| `treedb.flush_apply.guarded_publish.ns_per_op` | `0.000000` |
| `treedb.flush_apply.guarded_publish.ns_total` | `0` |
| `treedb.flush_apply.leaf_log_output.append_calls_total` | `41084` |
| `treedb.flush_apply.leaf_log_output.append_pages_total` | `86902` |
| `treedb.flush_apply.leaf_log_output.append_wait_ns_total` | `446215979` |
| `treedb.flush_apply.leaf_log_output.lane.01.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.02.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.03.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.04.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.05.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.06.tasks_total` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_lanes_used` | `6` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_max` | `38` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_overflow_total` | `0` |
| `treedb.flush_apply.leaf_log_output.lane.tasks_total` | `228` |
| `treedb.flush_apply.leaf_log_output.reservation_wait_ns_total` | `3584593` |
| `treedb.flush_apply.merge_build.internal_child_refs_total` | `102446` |
| `treedb.flush_apply.merge_build.internal_merges_total` | `136` |
| `treedb.flush_apply.merge_build.internal_page_bytes_written_total` | `4694016` |
| `treedb.flush_apply.merge_build.internal_pages_written_total` | `1146` |
| `treedb.flush_apply.merge_build.internal_parallel_children_total` | `130` |
| `treedb.flush_apply.merge_build.internal_parallel_merges_total` | `3` |
| `treedb.flush_apply.merge_build.internal_parallel_ops_total` | `278451` |
| `treedb.flush_apply.merge_build.internal_parallel_workers_total` | `18` |
| `treedb.flush_apply.merge_build.leaf_log_page_bytes_written_total` | `355950592` |
| `treedb.flush_apply.merge_build.leaf_log_pages_written_total` | `86902` |
| `treedb.flush_apply.merge_build.leaf_log_record_hint_bytes_written_total` | `152116498` |
| `treedb.flush_apply.merge_build.leaf_merges_per_op` | `0.025294` |
| `treedb.flush_apply.merge_build.leaf_merges_total` | `38306` |
| `treedb.flush_apply.merge_build.leaf_page_bytes_written_total` | `355950592` |
| `treedb.flush_apply.merge_build.leaf_pages_written_total` | `86902` |
| `treedb.flush_apply.merge_build.pager_leaf_page_bytes_written_total` | `0` |
| `treedb.flush_apply.merge_build.pager_leaf_pages_written_total` | `0` |
| `treedb.flush_apply.merge_build.replacement_leaf_pages_per_op` | `0.057384` |
| `treedb.flush_apply.merge_build.replacement_leaf_pages_total` | `86902` |
| `treedb.flush_apply.mismatch_total` | `0` |
| `treedb.flush_apply.old_leaf_read_decode.bytes_per_op` | `106.645959` |
| `treedb.flush_apply.old_leaf_read_decode.bytes_total` | `161505280` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_bytes_total` | `159178752` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_cache_hits_total` | `4413` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_node_loads_total` | `38862` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_reader_calls_total` | `34449` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_record_hint_bytes_total` | `95010337` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_scratch_reads_total` | `34449` |
| `treedb.flush_apply.old_leaf_read_decode.leaf_log_view_reads_total` | `0` |
| `treedb.flush_apply.old_leaf_read_decode.node_loads_total` | `39430` |
| `treedb.flush_apply.old_leaf_read_decode.pager_bytes_total` | `2326528` |
| `treedb.flush_apply.old_leaf_read_decode.pager_node_loads_total` | `568` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_installed_total` | `355950592` |
| `treedb.flush_apply.prepared_output.leaf_log_bytes_prepared_total` | `355950592` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_installed_total` | `86902` |
| `treedb.flush_apply.prepared_output.leaf_log_pages_prepared_total` | `86902` |
| `treedb.flush_apply.prepared_output.retired_pages_abandoned_total` | `0` |
| `treedb.flush_apply.prepared_output.retired_pages_installed_total` | `568` |
| `treedb.flush_apply.prepared_output.retired_pages_prepared_total` | `568` |
| `treedb.flush_apply.publish_final_install.calls_total` | `0` |
| `treedb.flush_apply.publish_final_install.ns_per_op` | `0.000000` |
| `treedb.flush_apply.publish_final_install.ns_total` | `0` |
| `treedb.flush_apply.publish_prepare.calls_total` | `7` |
| `treedb.flush_apply.publish_prepare.errors_total` | `0` |
| `treedb.flush_apply.publish_prepare.ns_per_op` | `5.885809` |
| `treedb.flush_apply.publish_prepare.ns_total` | `8913505` |
| `treedb.flush_apply.publish_total.ns_per_op` | `5.885809` |
| `treedb.flush_apply.publish_total.ns_total` | `8913505` |
| `treedb.flush_apply.read_only_prepare.calls_total` | `76` |
| `treedb.flush_apply.read_only_prepare.errors_total` | `0` |
| `treedb.flush_apply.read_only_prepare.ns_total` | `67054277` |
| `treedb.flush_apply.read_only_prepare.requested_workers_max` | `6` |
| `treedb.flush_apply.read_only_prepare.requested_workers_total` | `456` |
| `treedb.flush_apply.read_only_prepare.single_op_spans_max` | `1373` |
| `treedb.flush_apply.read_only_prepare.single_op_spans_total` | `2119` |
| `treedb.flush_apply.read_only_prepare.span_bytes_max` | `12622840` |
| `treedb.flush_apply.read_only_prepare.span_bytes_total` | `199376048` |
| `treedb.flush_apply.read_only_prepare.span_ops_max` | `92817` |
| `treedb.flush_apply.read_only_prepare.span_ops_total` | `1514406` |
| `treedb.flush_apply.read_only_prepare.spans_max` | `9470` |
| `treedb.flush_apply.read_only_prepare.spans_total` | `38306` |
| `treedb.flush_apply.read_only_prepare.validation_failures_total` | `0` |
| `treedb.flush_apply.read_only_prepare.worker_ranges_max` | `6` |
| `treedb.flush_apply.read_only_prepare.worker_ranges_total` | `281` |
| `treedb.flush_apply.reducer_publish.ns_per_op` | `7.061379` |
| `treedb.flush_apply.reducer_publish.ns_total` | `10693794` |
| `treedb.flush_apply.retry_total` | `0` |
| `treedb.flush_apply.root_reduce.ns_per_op` | `7.061379` |
| `treedb.flush_apply.root_reduce.ns_total` | `10693794` |
| `treedb.flush_apply.root_reduce.split_levels_total` | `3` |
| `treedb.flush_apply.span_native.candidate_ops_total` | `1514406` |
| `treedb.flush_apply.span_native.candidate_spans_total` | `38306` |
| `treedb.flush_apply.span_native.eligible_ops_total` | `1235955` |
| `treedb.flush_apply.span_native.eligible_spans_total` | `22205` |
| `treedb.flush_apply.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.maintenance.ops_total` | `278451` |
| `treedb.flush_apply.span_native.fallback.reason.maintenance.spans_total` | `16101` |
| `treedb.flush_apply.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.flush_apply.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.flush_apply.span_native.fallbacks_total` | `3` |
| `treedb.flush_apply.span_native.ineligible_ops_total` | `278451` |
| `treedb.flush_apply.span_native.ineligible_spans_total` | `16101` |
| `treedb.flush_apply.span_native.reducer_validation_guard.active` | `false` |
| `treedb.flush_apply.span_native.reducer_validation_guard.trips_total` | `0` |
| `treedb.flush_apply.span_native.scheduler.completed_tasks_total` | `263` |
| `treedb.flush_apply.span_native.scheduler.dispatched_tasks_total` | `263` |
| `treedb.flush_apply.span_native.scheduler.queue_depth_max` | `6` |
| `treedb.flush_apply.span_native.scheduler.ready_tasks_total` | `263` |
| `treedb.flush_apply.span_native.scheduler.scheduled_workers_max` | `6` |
| `treedb.flush_apply.span_native.scheduler.scheduled_workers_total` | `263` |
| `treedb.flush_apply.span_native.scheduler.single_span_tasks_total` | `36` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_max` | `2621440` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_min` | `115328` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_per_task` | `675626.920152` |
| `treedb.flush_apply.span_native.scheduler.task_bytes_total` | `177689880` |
| `treedb.flush_apply.span_native.scheduler.task_ops_max` | `16384` |
| `treedb.flush_apply.span_native.scheduler.task_ops_min` | `848` |
| `treedb.flush_apply.span_native.scheduler.task_ops_per_task` | `4699.448669` |
| `treedb.flush_apply.span_native.scheduler.task_ops_total` | `1235955` |
| `treedb.flush_apply.span_native.scheduler.task_spans_max` | `964` |
| `treedb.flush_apply.span_native.scheduler.task_spans_min` | `1` |
| `treedb.flush_apply.span_native.scheduler.task_spans_per_task` | `84.429658` |
| `treedb.flush_apply.span_native.scheduler.task_spans_total` | `22205` |
| `treedb.flush_apply.span_native.scheduler.worker_busy_ns_total` | `1062030074` |
| `treedb.flush_apply.span_native.scheduler.worker_idle_ns_total` | `198802129` |
| `treedb.flush_apply.span_native.scheduler.worker_wait_ns_total` | `356234548` |
| `treedb.flush_apply.span_native.used_ops_total` | `1235955` |
| `treedb.flush_apply.span_native.used_spans_total` | `22205` |
| `treedb.flush_apply.span_run.bytes_per_span` | `5204.825563` |
| `treedb.flush_apply.span_run.ops_per_span` | `39.534433` |
| `treedb.flush_apply.span_run.single_op_spans_total` | `2119` |
| `treedb.flush_apply.span_run.span_bytes_total` | `199376048` |
| `treedb.flush_apply.span_run.span_ops_total` | `1514406` |
| `treedb.flush_apply.span_run.target_leaf_spans_total` | `38306` |
| `treedb.leaf_generation.bytes.deleted` | `0` |
| `treedb.leaf_generation.bytes.retained` | `35463925` |
| `treedb.leaf_generation.bytes.retiring` | `0` |
| `treedb.leaf_generation.bytes.sealed` | `35463925` |
| `treedb.leaf_generation.bytes.total` | `39190335` |
| `treedb.leaf_generation.bytes.writable` | `3726410` |
| `treedb.leaf_generation.current.bytes` | `3726410` |
| `treedb.leaf_generation.current.files` | `1` |
| `treedb.leaf_generation.current_generation_id` | `7` |
| `treedb.leaf_generation.enabled` | `true` |
| `treedb.leaf_generation.files.deleted` | `0` |
| `treedb.leaf_generation.files.retained` | `6` |
| `treedb.leaf_generation.files.retiring` | `0` |
| `treedb.leaf_generation.files.sealed` | `6` |
| `treedb.leaf_generation.files.total` | `7` |
| `treedb.leaf_generation.files.writable` | `1` |
| `treedb.leaf_generation.generations.deleted` | `0` |
| `treedb.leaf_generation.generations.pinned` | `0` |
| `treedb.leaf_generation.generations.retained` | `6` |
| `treedb.leaf_generation.generations.retiring` | `0` |
| `treedb.leaf_generation.generations.sealed` | `6` |
| `treedb.leaf_generation.generations.total` | `7` |
| `treedb.leaf_generation.generations.writable` | `1` |
| `treedb.leaf_generation.pins.total` | `0` |
| `treedb.leaf_generation.plan_cache.subtree_pages` | `0` |
| `treedb.process.append_only.entry_hint_capacity_bytes` | `4850304` |
| `treedb.process.append_only.entry_hint_entries` | `50524` |
| `treedb.process.append_only.entry_pool_admission_drop_bytes_total` | `75452608` |
| `treedb.process.append_only.entry_pool_admission_drops_total` | `5` |
| `treedb.process.append_only.entry_pool_drop_bytes_total` | `265329416` |
| `treedb.process.append_only.entry_pool_drops_total` | `1` |
| `treedb.process.append_only.entry_pool_gets_total` | `67` |
| `treedb.process.append_only.entry_pool_puts_total` | `263` |
| `treedb.process.append_only.entry_pool_retained_bytes_estimate` | `177498288` |
| `treedb.process.append_only.entry_pool_retained_bytes_max_estimate` | `265329416` |
| `treedb.process.append_only.mem_lease_count` | `8` |
| `treedb.process.append_only.mem_lease_entry_backing_bytes` | `0` |
| `treedb.process.append_only.mem_lease_entry_capacity` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_active_bytes` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_active_chunks` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_retained_bytes` | `0` |
| `treedb.process.append_only.mem_lease_value_arena_retained_chunks` | `0` |
| `treedb.process.append_only.mutable_count` | `16` |
| `treedb.process.append_only.mutable_entry_backing_bytes` | `0` |
| `treedb.process.append_only.mutable_entry_capacity` | `0` |
| `treedb.process.append_only.mutable_from_lease_total` | `56` |
| `treedb.process.append_only.mutable_from_pool_total` | `0` |
| `treedb.process.append_only.mutable_new_alloc_queue_bytes_sum` | `502792240` |
| `treedb.process.append_only.mutable_new_alloc_total` | `24` |
| `treedb.process.append_only.mutable_new_alloc_with_queue_total` | `24` |
| `treedb.process.append_only.mutable_pool_drops_total` | `0` |
| `treedb.process.append_only.mutable_pool_entry_backing_dropped_bytes_total` | `0` |
| `treedb.process.append_only.mutable_pool_puts_total` | `16` |
| `treedb.process.append_only.mutable_sparse_trim_dropped_bytes_total` | `25276504` |
| `treedb.process.append_only.mutable_sparse_trim_total` | `26` |
| `treedb.process.append_only.mutable_trim_dropped_bytes_total` | `25276504` |
| `treedb.process.append_only.mutable_trim_total` | `74` |
| `treedb.process.append_only.mutable_value_arena_active_bytes` | `0` |
| `treedb.process.append_only.mutable_value_arena_active_chunks` | `0` |
| `treedb.process.append_only.mutable_value_arena_retained_bytes` | `0` |
| `treedb.process.append_only.mutable_value_arena_retained_chunks` | `0` |
| `treedb.process.append_only.reserve.calls_total` | `135` |
| `treedb.process.append_only.reserve.entries_total` | `62237` |
| `treedb.process.append_only.reserve.grow_bytes_total` | `270804336` |
| `treedb.process.append_only.reserve.grow_calls_total` | `135` |
| `treedb.process.append_only.reserve.skipped_growth_allocs_total` | `21` |
| `treedb.process.append_only.reserve.skipped_growth_bytes_total` | `405504` |
| `treedb.process.append_only.value_arena_pool_admission_drop_bytes_total` | `0` |
| `treedb.process.append_only.value_arena_pool_admission_drops_total` | `0` |
| `treedb.process.append_only.value_arena_pool_drop_bytes_total` | `0` |
| `treedb.process.append_only.value_arena_pool_drops_total` | `0` |
| `treedb.process.append_only.value_arena_pool_gets_total` | `0` |
| `treedb.process.append_only.value_arena_pool_puts_total` | `0` |
| `treedb.process.append_only.value_arena_pool_retained_bytes_estimate` | `0` |
| `treedb.process.append_only.value_arena_pool_retained_bytes_max_estimate` | `0` |
| `treedb.process.memory.gc_cpu_fraction` | `0.007827` |
| `treedb.process.memory.gomemlimit_bytes` | `9223372036854775807` |
| `treedb.process.memory.heap_alloc_bytes` | `498606120` |
| `treedb.process.memory.heap_idle_bytes` | `631070720` |
| `treedb.process.memory.heap_idle_unreleased_bytes` | `456531968` |
| `treedb.process.memory.heap_inuse_bytes` | `502800384` |
| `treedb.process.memory.heap_released_bytes` | `174538752` |
| `treedb.process.memory.heap_sys_bytes` | `1133871104` |
| `treedb.process.memory.memtable_view_deferred_bytes_current` | `0` |
| `treedb.process.memory.memtable_view_deferred_bytes_max` | `0` |
| `treedb.process.memory.memtable_view_deferred_memtables_current` | `0` |
| `treedb.process.memory.memtable_view_deferred_memtables_max` | `0` |
| `treedb.process.memory.memtable_view_deferred_oldest_age_ms` | `0.000` |
| `treedb.process.memory.mutable_bytes` | `0` |
| `treedb.process.memory.next_gc_bytes` | `962577346` |
| `treedb.process.memory.non_heap_sys_bytes` | `32960024` |
| `treedb.process.memory.num_gc` | `79` |
| `treedb.process.memory.peak_heap_alloc_bytes` | `976790640` |
| `treedb.process.memory.peak_heap_inuse_bytes` | `981475328` |
| `treedb.process.memory.peak_rss_bytes` | `1115570176` |
| `treedb.process.memory.peak_total_sys_bytes` | `1166831128` |
| `treedb.process.memory.peak_vlog_mmap_active_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_active_segments` | `0` |
| `treedb.process.memory.peak_vlog_mmap_current_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_current_segments` | `0` |
| `treedb.process.memory.peak_vlog_mmap_sealed_bytes` | `0` |
| `treedb.process.memory.peak_vlog_mmap_sealed_segments` | `0` |
| `treedb.process.memory.pool_pressure_critical_samples_total` | `0` |
| `treedb.process.memory.pool_pressure_high_samples_total` | `0` |
| `treedb.process.memory.pool_pressure_level` | `normal` |
| `treedb.process.memory.pool_pressure_normal_samples_total` | `113` |
| `treedb.process.memory.pool_pressure_used_bytes` | `959332352` |
| `treedb.process.memory.queue_backlog_bytes` | `0` |
| `treedb.process.memory.rss_bytes` | `916021248` |
| `treedb.process.memory.rss_hwm_bytes` | `1115570176` |
| `treedb.process.memory.rss_minus_heap_inuse_bytes` | `413220864` |
| `treedb.process.memory.rss_minus_total_sys_bytes` | `0` |
| `treedb.process.memory.stack_inuse_bytes` | `2785280` |
| `treedb.process.memory.stack_sys_bytes` | `2785280` |
| `treedb.process.memory.total_sys_bytes` | `1166831128` |
| `treedb.process.memory.vlog_mmap_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_backend_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_backend_sealed_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_active_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_active_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_cache_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_cache_sealed_segments` | `0` |
| `treedb.process.memory.vlog_mmap_current_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_current_segments` | `0` |
| `treedb.process.memory.vlog_mmap_dead_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_sealed_bytes` | `0` |
| `treedb.process.memory.vlog_mmap_sealed_segments` | `0` |
| `treedb.process.memory.vlog_retained_bytes_estimate` | `39190335` |
| `treedb.process.memory.vlog_zombie_bytes_estimate` | `0` |
| `treedb.process.memory.vlog_zombie_pinned_bytes_estimate` | `0` |
| `treedb.process.memory.vlog_zombie_unpinned_bytes_estimate` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.count` | `16` |
| `treedb.process.memtable_residency.mutable.append_only.entries` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.append_only.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.btree.count` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entries` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.btree.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.btree.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.count` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entries` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.count` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entries` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.total.count` | `16` |
| `treedb.process.memtable_residency.mutable.total.entries` | `0` |
| `treedb.process.memtable_residency.mutable.total.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.entry_capacity` | `0` |
| `treedb.process.memtable_residency.mutable.total.size_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.mutable.total.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.append_only.count` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entries` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.append_only.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.append_only.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.btree.count` | `0` |
| `treedb.process.memtable_residency.queue.btree.entries` | `0` |
| `treedb.process.memtable_residency.queue.btree.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.btree.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.btree.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.count` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entries` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.hash_sorted.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.count` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entries` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.skiplist.value_arena_retained_chunks` | `0` |
| `treedb.process.memtable_residency.queue.total.count` | `0` |
| `treedb.process.memtable_residency.queue.total.entries` | `0` |
| `treedb.process.memtable_residency.queue.total.entry_backing_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.entry_capacity` | `0` |
| `treedb.process.memtable_residency.queue.total.size_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_active_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_active_chunks` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_retained_bytes` | `0` |
| `treedb.process.memtable_residency.queue.total.value_arena_retained_chunks` | `0` |
| `treedb.process.read_path.backend_tree.get_append_inline_bytes_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_inline_hits_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_pointer_bytes_total` | `0` |
| `treedb.process.read_path.backend_tree.get_append_pointer_hits_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.calls_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.fallback_calls_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.grouped_calls_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.leaf_group_items_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.leaf_groups_total` | `0` |
| `treedb.process.read_path.backend_tree.getmany.leaf_loads_saved_total` | `0` |
| `treedb.process.read_path.outer_leaf.bytes_total` | `173645824` |
| `treedb.process.read_path.outer_leaf.cache.backing_bytes` | `33554432` |
| `treedb.process.read_path.outer_leaf.cache.buckets` | `2048` |
| `treedb.process.read_path.outer_leaf.cache.bytes` | `33554432` |
| `treedb.process.read_path.outer_leaf.cache.capacity` | `8192` |
| `treedb.process.read_path.outer_leaf.cache.capacity_evictions` | `60372` |
| `treedb.process.read_path.outer_leaf.cache.conflict_evictions` | `18594` |
| `treedb.process.read_path.outer_leaf.cache.cow_read_policy_bytes` | `196608` |
| `treedb.process.read_path.outer_leaf.cache.entries` | `8192` |
| `treedb.process.read_path.outer_leaf.cache.evictions` | `78966` |
| `treedb.process.read_path.outer_leaf.cache.hits` | `12252` |
| `treedb.process.read_path.outer_leaf.cache.misses` | `68656` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_mark_misses` | `0` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_mark_unsafe_skips` | `0` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_unverified_hits` | `12183` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_verified_hits` | `69` |
| `treedb.process.read_path.outer_leaf.cache.page_checksum_verified_marks` | `75` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_candidate_skips` | `0` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_lock_skips` | `0` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_skips` | `68395` |
| `treedb.process.read_path.outer_leaf.cache.read_miss_admission_stores` | `261` |
| `treedb.process.read_path.outer_leaf.cache.record_checksum_verified_stores` | `261` |
| `treedb.process.read_path.outer_leaf.cache.stores` | `87158` |
| `treedb.process.read_path.outer_leaf.cache.ways` | `4` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_attempts` | `86902` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_lock_skips` | `5` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_policy` | `adaptive` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_skips` | `5` |
| `treedb.process.read_path.outer_leaf.cache.write_admission_stores` | `86897` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_1024_hit_ratio` | `0.003021` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_1024_hits_total` | `2` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_256_hit_ratio` | `0.000000` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_256_hits_total` | `0` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_4096_hit_ratio` | `0.003021` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_4096_hits_total` | `2` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_64_hit_ratio` | `0.000000` |
| `treedb.process.read_path.outer_leaf.cache_potential.capacity_64_hits_total` | `0` |
| `treedb.process.read_path.outer_leaf.checksum.skips_total` | `6` |
| `treedb.process.read_path.outer_leaf.checksum.verifications_total` | `42388` |
| `treedb.process.read_path.outer_leaf.iterator_loads_total` | `42394` |
| `treedb.process.read_path.outer_leaf.loads_total` | `42394` |
| `treedb.process.read_path.outer_leaf.point_loads_total` | `0` |
| `treedb.process.read_path.outer_leaf.sample_mod` | `64` |
| `treedb.process.read_path.outer_leaf.samples_total` | `662` |
| `treedb.profile.bench_unsafe` | `false` |
| `treedb.profile.resolved` | `command_wal_relaxed` |
| `treedb.publish.ordered_root_delta_group.avg_roots_per_call` | `0.000` |
| `treedb.publish.ordered_root_delta_group.calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.finalize_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.finalize_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.latency_max_ms` | `0.000` |
| `treedb.publish.ordered_root_delta_group.latency_p99_ms` | `0.000` |
| `treedb.publish.ordered_root_delta_group.preflight_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.publish_prepare_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_child_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_leaf_log_ref_copies_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_leaf_log_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_page_child_refs_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_children_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_internal_parallel_workers_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_cache_hits_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_node_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_reader_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_record_hint_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_record_hint_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_scratch_reads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_log_view_reads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_merges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_leaf_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_leaf_page_bytes_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_leaf_pages_written_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_node_bytes_read_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_pager_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_parallel_groups_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_parallel_roots_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_errors_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_requested_workers_max` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_requested_workers_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_span_bytes_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_span_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_validation_failures_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_read_only_prepare_worker_ranges_total` | `0` |
| `treedb.publish.ordered_root_delta_group.root_apply_root_split_levels_total` | `0` |
| `treedb.publish.ordered_root_delta_group.roots_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.collection_buffered_roots.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.command_wal_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.delta_batch_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.direct_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.grouped_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.multi_index_group_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.overlay_cold_build.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.read_only_prepare.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.candidate_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.candidate_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.eligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.eligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.disabled.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.unknown.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.fallbacks_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.ineligible_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.ineligible_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.observations_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.route.system_delta_builder_publish.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.collection_buffered_roots.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.command_wal_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.delta_batch_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.fallback_reason` | `route_ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.direct_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.fallback_reason` | `route_ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.grouped_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.multi_index_group_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.candidate` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.eligible` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.fallback_class` | `route` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.fallback_reason` | `cold_build` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.status` | `ineligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.overlay_cold_build.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.read_only_prepare.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_admitted` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_policy` | `auto` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.admission_reason` | `auto_admitted_hardware_aware` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.candidate` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.eligible` | `true` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.fallback_class` | `none` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.fallback_reason` | `` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.selected_workers` | `6` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.status` | `eligible` |
| `treedb.publish.ordered_root_delta_group.span_native.triage.route.system_delta_builder_publish.used` | `false` |
| `treedb.publish.ordered_root_delta_group.span_native.used_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.span_native.used_spans_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_calls_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_node_loads_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_apply_ops_total` | `0` |
| `treedb.publish.ordered_root_delta_group.system_build_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_hold_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_wait_ns_total` | `0` |
| `treedb.publish.ordered_root_delta_group.write_lock_wait_share_pct` | `0.000` |
| `treedb.publish.watermark.lag_drift_bytes_per_sec` | `-25215159.247` |
| `treedb.publish.watermark.latency_p99_ms` | `0.000` |
| `treedb.publish.watermark.lock_delay_share_pct` | `0.000` |
| `treedb.raw.span_native.candidate_ops_total` | `1514406` |
| `treedb.raw.span_native.candidate_spans_total` | `0` |
| `treedb.raw.span_native.eligible_ops_total` | `1235955` |
| `treedb.raw.span_native.eligible_spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.maintenance.count_total` | `3` |
| `treedb.raw.span_native.fallback.reason.maintenance.ops_total` | `278451` |
| `treedb.raw.span_native.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.fallbacks_total` | `3` |
| `treedb.raw.span_native.ineligible_ops_total` | `278451` |
| `treedb.raw.span_native.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.public.command_wal_rejections_total` | `0` |
| `treedb.raw.span_native.public.route.update.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.public.route.update.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.public.route.update_sync.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.public.route.update_sync.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.observations_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.used_ops_total` | `0` |
| `treedb.raw.span_native.route.close_or_checkpoint_drain.used_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.observations_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.used_ops_total` | `0` |
| `treedb.raw.span_native.route.empty_batch.used_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.candidate_ops_total` | `278451` |
| `treedb.raw.span_native.route.mixed_point.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.count_total` | `3` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.ops_total` | `278451` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.fallbacks_total` | `3` |
| `treedb.raw.span_native.route.mixed_point.ineligible_ops_total` | `278451` |
| `treedb.raw.span_native.route.mixed_point.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.observations_total` | `3` |
| `treedb.raw.span_native.route.mixed_point.used_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_point.used_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.observations_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.mixed_range_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.point_delete.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_delete.observations_total` | `0` |
| `treedb.raw.span_native.route.point_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.point_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.candidate_ops_total` | `1235955` |
| `treedb.raw.span_native.route.point_put.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.eligible_ops_total` | `1235955` |
| `treedb.raw.span_native.route.point_put.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.point_put.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.point_put.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.point_put.observations_total` | `73` |
| `treedb.raw.span_native.route.point_put.used_ops_total` | `1235955` |
| `treedb.raw.span_native.route.point_put.used_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.candidate_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.candidate_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.eligible_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.eligible_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.admission_policy_decline.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.backend_chunk_split.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.below_threshold.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.close_or_checkpoint.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.cold_build.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.command_wal_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.disabled.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.inexact_leaf_spans.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.lane_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.maintenance.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.memory_or_emergency_cap.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.output_ownership_failure.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.prepare_error.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.range_delete_barrier.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.reducer_validation_guard.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.root_mismatch.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.route_ineligible.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.span_native_not_implemented.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.unknown.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.count_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallback.reason.validation_failed.spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.fallbacks_total` | `0` |
| `treedb.raw.span_native.route.range_delete.ineligible_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.ineligible_spans_total` | `0` |
| `treedb.raw.span_native.route.range_delete.observations_total` | `0` |
| `treedb.raw.span_native.route.range_delete.used_ops_total` | `0` |
| `treedb.raw.span_native.route.range_delete.used_spans_total` | `0` |
| `treedb.raw.span_native.used_ops_total` | `1235955` |
| `treedb.raw.span_native.used_spans_total` | `0` |
| `treedb.vlog.decode_buffer_grow.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.capacity_waste_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.copied_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_fit_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_fit_requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.dst_present_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_compressed_fallback.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_current_mmap_direct_decode.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_current_mmap_direct_decode.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_fit_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_fit_requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.dst_present_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_decoded_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_template_encoded_payload.calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.read_append_template_encoded_payload.requested_bytes_total` | `0` |
| `treedb.vlog.decode_buffer_grow.realloc_calls_total` | `0` |
| `treedb.vlog.decode_buffer_grow.requested_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.file_stash.retain_max_bytes` | `131072` |
| `treedb.vlog.decode_scratch.file_stash.retained_buffers` | `21` |
| `treedb.vlog.decode_scratch.file_stash.retained_bytes` | `684578` |
| `treedb.vlog.decode_scratch.file_stash.retained_files` | `7` |
| `treedb.vlog.decode_scratch.file_stash.spare_max_count` | `2` |
| `treedb.vlog.decode_scratch.large_pool.alloc_calls_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.drops_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.entries` | `0` |
| `treedb.vlog.decode_scratch.large_pool.gets_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.hits_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.max_entries` | `8` |
| `treedb.vlog.decode_scratch.large_pool.misses_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.puts_total` | `0` |
| `treedb.vlog.decode_scratch.large_pool.retained_buffers` | `0` |
| `treedb.vlog.decode_scratch.large_pool.retained_bytes` | `0` |
| `treedb.vlog.decode_scratch.large_pool.too_small_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.alloc_calls_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.allocated_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.oversize.drops_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.alloc_calls_total` | `111` |
| `treedb.vlog.decode_scratch.small_pool.allocated_bytes_total` | `3425523` |
| `treedb.vlog.decode_scratch.small_pool.dropped_bytes_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.drops_total` | `0` |
| `treedb.vlog.decode_scratch.small_pool.entries` | `9` |
| `treedb.vlog.decode_scratch.small_pool.gets_total` | `13097` |
| `treedb.vlog.decode_scratch.small_pool.hits_total` | `12986` |
| `treedb.vlog.decode_scratch.small_pool.max_entries` | `128` |
| `treedb.vlog.decode_scratch.small_pool.misses_total` | `111` |
| `treedb.vlog.decode_scratch.small_pool.puts_total` | `13076` |
| `treedb.vlog.decode_scratch.small_pool.retained_buffers` | `9` |
| `treedb.vlog.decode_scratch.small_pool.retained_bytes` | `293427` |
| `treedb.vlog.decode_scratch.small_pool.too_small_total` | `81` |
| `treedb.vlog.grouped_frame_cache.allocated_shards` | `0` |
| `treedb.vlog.grouped_frame_cache.allocated_slots` | `0` |
| `treedb.vlog.grouped_frame_cache.budget_bytes` | `67108864` |
| `treedb.vlog.grouped_frame_cache.capacity` | `0` |
| `treedb.vlog.grouped_frame_cache.entries` | `0` |
| `treedb.vlog.grouped_frame_cache.evictions` | `0` |
| `treedb.vlog.grouped_frame_cache.hits` | `0` |
| `treedb.vlog.grouped_frame_cache.misses` | `0` |
| `treedb.vlog.grouped_frame_cache.releases` | `0` |
| `treedb.vlog.grouped_frame_cache.retained_bytes` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_budget` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_contention` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_disabled` | `0` |
| `treedb.vlog.grouped_frame_cache.skipped_oversize` | `0` |
| `treedb.vlog.grouped_frame_cache.stores` | `0` |
| `treedb.vlog.mmap_active_bytes` | `0` |
| `treedb.vlog.mmap_active_segments` | `0` |
| `treedb.vlog.mmap_current_bytes` | `0` |
| `treedb.vlog.mmap_current_segments` | `0` |
| `treedb.vlog.mmap_current_writable_map_target_bytes` | `33554432` |
| `treedb.vlog.mmap_dead_bytes` | `0` |
| `treedb.vlog.mmap_dead_mappings` | `0` |
| `treedb.vlog.mmap_dead_mappings.cap_base` | `64` |
| `treedb.vlog.mmap_max_mapped_leaf_sealed_bytes` | `1610612736` |
| `treedb.vlog.mmap_max_mapped_leaf_sealed_segments` | `512` |
| `treedb.vlog.mmap_max_mapped_sealed_bytes` | `67108864` |
| `treedb.vlog.mmap_max_mapped_sealed_segments` | `8` |
| `treedb.vlog.mmap_read.fallback_readat` | `214297` |
| `treedb.vlog.mmap_read.hit_ratio` | `0.000000` |
| `treedb.vlog.mmap_read.hits` | `0` |
| `treedb.vlog.mmap_read.miss_dead_mapping_cap` | `0` |
| `treedb.vlog.mmap_read.miss_no_mapping` | `214297` |
| `treedb.vlog.mmap_read.miss_out_of_range` | `0` |
| `treedb.vlog.mmap_remaps` | `0` |
| `treedb.vlog.mmap_sealed_bytes` | `0` |
| `treedb.vlog.mmap_sealed_map_denied` | `0` |
| `treedb.vlog.mmap_sealed_map_denied.bytes_cap` | `0` |
| `treedb.vlog.mmap_sealed_map_denied.count_cap` | `0` |
| `treedb.vlog.mmap_sealed_segments` | `0` |
| `treedb.vlog.read.crc32_checks_total` | `214297` |
| `treedb.vlog.read_integrity` | `verify` |
| `treedb.vlog.template_def_cache.hits` | `0` |
| `treedb.vlog.template_def_cache.misses` | `0` |
| `treedb.vlog.writer_append_buf.alloc_calls_total` | `7` |
| `treedb.vlog.writer_append_buf.allocated_bytes_total` | `29360128` |
| `treedb.vlog.writer_append_buf.dropped_bytes_total` | `0` |
| `treedb.vlog.writer_append_buf.drops_total` | `0` |
| `treedb.vlog.writer_append_buf.gets_total` | `7` |
| `treedb.vlog.writer_append_buf.hits_total` | `0` |
| `treedb.vlog.writer_append_buf.misses_total` | `7` |
| `treedb.vlog.writer_append_buf.pool.entries` | `0` |
| `treedb.vlog.writer_append_buf.pool.max_entries` | `16` |
| `treedb.vlog.writer_append_buf.pool.retained_buffers` | `0` |
| `treedb.vlog.writer_append_buf.pool.retained_bytes` | `0` |
| `treedb.vlog.writer_append_buf.puts_total` | `0` |

## Key Insights

- TreeDB: prefix_scan is 0.24x slower than full_scan (328430 vs 1354031 ops/s).
- treedb: shared hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" (full 37.93% flat, prefix 6.25% flat).
- treedb: prefix_scan-specific hotspot "runtime.tryDeferToSpanScan" (18.75% flat).
- treedb: full_scan-specific hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)" (4.60% flat).
- block/batch_delete/treedb: contention hotspot "runtime.selectgo" (89.37% flat).
- block/batch_random/treedb: contention hotspot "runtime.selectgo" (91.41% flat).
- block/batch_small_seq/treedb: contention hotspot "runtime.selectgo" (93.17% flat).
- block/batch_write/treedb: contention hotspot "runtime.chanrecv1" (57.87% flat).
- block/batch_write_steady/treedb: contention hotspot "runtime.selectgo" (64.90% flat).
- block/dataset_write_random/treedb: contention hotspot "runtime.selectgo" (78.37% flat).
- block/dataset_write_sorted/treedb: contention hotspot "runtime.selectgo" (56.26% flat).
- block/full_scan/treedb: contention hotspot "runtime.selectgo" (89.41% flat).
- block/prefix_scan/treedb: contention hotspot "runtime.chanrecv1" (100.00% flat).
- block/random_delete/treedb: contention hotspot "runtime.selectgo" (71.60% flat).
- block/random_read/treedb: contention hotspot "runtime.selectgo" (85.61% flat).
- block/random_read_batch/treedb: contention hotspot "runtime.chanrecv1" (100.00% flat).
- block/random_read_parallel/treedb: contention hotspot "runtime.selectgo" (93.84% flat).
- block/random_read_parallel_acquire_snapshot/treedb: contention hotspot "runtime.selectgo" (75.13% flat).
- block/random_write/treedb: contention hotspot "runtime.selectgo" (59.87% flat).
- block/sequential_write/treedb: contention hotspot "runtime.selectgo" (66.62% flat).
- mutex/batch_random/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/batch_small_seq/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/batch_write/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/batch_write_steady/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (99.73% flat).
- mutex/dataset_write_random/treedb: contention hotspot "sync.(*Mutex).Unlock" (99.45% flat).
- mutex/dataset_write_sorted/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (100.00% flat).
- mutex/full_scan/treedb: contention hotspot "runtime.unlock (inline)" (100.00% flat).
- mutex/random_delete/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/random_read_parallel/treedb: contention hotspot "sync.(*Mutex).Unlock (inline)" (76.67% flat).
- mutex/random_read_parallel_acquire_snapshot/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (93.75% flat).
- mutex/random_write/treedb: contention hotspot "sync.(*Mutex).Unlock" (100.00% flat).
- mutex/sequential_write/treedb: contention hotspot "sync.(*Mutex).Unlock (partial-inline)" (99.37% flat).
- Global block contention hotspot: "runtime.selectgo" (72.23% flat).
- Global mutex contention hotspot: "sync.(*Mutex).Unlock (partial-inline)" (97.63% flat).
- alloc_objects/batch_delete/treedb: top allocator by count is "runtime/pprof.allFrames" (13109 flat, 48.66%).
- alloc_objects/batch_delete/treedb: top hotspot "runtime/pprof.allFrames" is 48.66% flat; this section is highly concentrated in one function.
- alloc_objects/batch_random/treedb: top allocator by count is "runtime/pprof.allFrames" (13107 flat, 87.69%).
- alloc_objects/batch_random/treedb: top hotspot "runtime/pprof.allFrames" is 87.69% flat; this section is highly concentrated in one function.
- alloc_objects/batch_small_seq/treedb: dominant theme is write/delete/flush path (74.60% flat across top nodes).
- alloc_objects/batch_small_seq/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write" (21845 flat, 50.02%).
- alloc_objects/batch_small_seq/treedb: top hotspot "github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write" is 50.02% flat; this section is highly concentrated in one function.
- alloc_objects/batch_write/treedb: top allocator by count is "runtime/pprof.allFrames" (5461 flat, 73.49%).
- alloc_objects/batch_write/treedb: top hotspot "runtime/pprof.allFrames" is 73.49% flat; this section is highly concentrated in one function.
- alloc_objects/batch_write_steady/treedb: dominant theme is runtime/syscall overhead (32.26% flat across top nodes).
- alloc_objects/batch_write_steady/treedb: top allocator by count is "syscall.ByteSliceFromString" (4681 flat, 32.26%).
- alloc_objects/dataset_write_random/treedb: dominant theme is write/delete/flush path (82.62% flat across top nodes).
- alloc_objects/dataset_write_random/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput" (404146 flat, 34.06%).
- alloc_objects/dataset_write_sorted/treedb: dominant theme is write/delete/flush path (81.77% flat across top nodes).
- alloc_objects/dataset_write_sorted/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" (432556 flat, 38.39%).
- alloc_objects/dataset_write_sorted/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" is 38.39% flat; this section is highly concentrated in one function.
- alloc_objects/full_scan/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)" (49155 flat, 83.09%).
- alloc_objects/full_scan/treedb: top hotspot "github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)" is 83.09% flat; this section is highly concentrated in one function.
- alloc_objects/prefix_scan/treedb: dominant theme is iterator/seek/compare overhead (68.85% flat across top nodes).
- alloc_objects/prefix_scan/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/caching.newValueLogIterator (inline)" (8193 flat, 45.42%).
- alloc_objects/prefix_scan/treedb: top hotspot "github.com/snissn/gomap/TreeDB/caching.newValueLogIterator (inline)" is 45.42% flat; this section is highly concentrated in one function.
- alloc_objects/random_delete/treedb: dominant theme is write/delete/flush path (75.82% flat across top nodes).
- alloc_objects/random_delete/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" (367019 flat, 32.41%).
- alloc_objects/random_read/treedb: top allocator by count is "runtime/pprof.(*profileBuilder).emitLocation" (55 flat, 44.00%).
- alloc_objects/random_read/treedb: top hotspot "runtime/pprof.(*profileBuilder).emitLocation" is 44.00% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_batch/treedb: top allocator by count is "runtime/pprof.allFrames" (22941 flat, 90.02%).
- alloc_objects/random_read_batch/treedb: top hotspot "runtime/pprof.allFrames" is 90.02% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_parallel/treedb: top allocator by count is "runtime/pprof.allFrames" (6555 flat, 94.63%).
- alloc_objects/random_read_parallel/treedb: top hotspot "runtime/pprof.allFrames" is 94.63% flat; this section is highly concentrated in one function.
- alloc_objects/random_read_parallel_acquire_snapshot/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" (2427200 flat, 50.69%).
- alloc_objects/random_read_parallel_acquire_snapshot/treedb: top hotspot "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" is 50.69% flat; this section is highly concentrated in one function.
- alloc_objects/random_write/treedb: dominant theme is write/delete/flush path (80.60% flat across top nodes).
- alloc_objects/random_write/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" (511199 flat, 42.77%).
- alloc_objects/random_write/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" is 42.77% flat; this section is highly concentrated in one function.
- alloc_objects/sequential_write/treedb: dominant theme is write/delete/flush path (75.51% flat across top nodes).
- alloc_objects/sequential_write/treedb: top allocator by count is "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" (393235 flat, 35.03%).
- alloc_objects/sequential_write/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo" is 35.03% flat; this section is highly concentrated in one function.
- alloc_space/batch_delete/treedb: dominant theme is write/delete/flush path (70.17% flat across top nodes).
- alloc_space/batch_delete/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (18308.69kB flat, 46.36%).
- alloc_space/batch_delete/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 46.36% flat; this section is highly concentrated in one function.
- alloc_space/batch_random/treedb: dominant theme is write/delete/flush path (87.45% flat across top nodes).
- alloc_space/batch_random/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace" (60.35MB flat, 51.88%).
- alloc_space/batch_random/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace" is 51.88% flat; this section is highly concentrated in one function.
- alloc_space/batch_small_seq/treedb: dominant theme is write/delete/flush path (90.90% flat across top nodes).
- alloc_space/batch_small_seq/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (60.61MB flat, 81.32%).
- alloc_space/batch_small_seq/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 81.32% flat; this section is highly concentrated in one function.
- alloc_space/batch_write/treedb: dominant theme is write/delete/flush path (85.48% flat across top nodes).
- alloc_space/batch_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (59.29MB flat, 51.92%).
- alloc_space/batch_write/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 51.92% flat; this section is highly concentrated in one function.
- alloc_space/batch_write_steady/treedb: dominant theme is write/delete/flush path (88.26% flat across top nodes).
- alloc_space/batch_write_steady/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL" (791.35MB flat, 78.19%).
- alloc_space/batch_write_steady/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL" is 78.19% flat; this section is highly concentrated in one function.
- alloc_space/dataset_write_random/treedb: dominant theme is write/delete/flush path (95.47% flat across top nodes).
- alloc_space/dataset_write_random/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (147MB flat, 53.58%).
- alloc_space/dataset_write_random/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 53.58% flat; this section is highly concentrated in one function.
- alloc_space/dataset_write_sorted/treedb: dominant theme is write/delete/flush path (86.70% flat across top nodes).
- alloc_space/dataset_write_sorted/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo" (37.51MB flat, 46.11%).
- alloc_space/dataset_write_sorted/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo" is 46.11% flat; this section is highly concentrated in one function.
- alloc_space/full_scan/treedb: dominant theme is write/delete/flush path (40.13% flat across top nodes).
- alloc_space/full_scan/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked" (4.76MB flat, 22.92%).
- alloc_space/prefix_scan/treedb: dominant theme is value decode/read I/O (50.10% flat across top nodes).
- alloc_space/prefix_scan/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (3610.34kB flat, 23.14%).
- alloc_space/random_delete/treedb: dominant theme is write/delete/flush path (89.27% flat across top nodes).
- alloc_space/random_delete/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (71.98MB flat, 62.62%).
- alloc_space/random_delete/treedb: top hotspot "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" is 62.62% flat; this section is highly concentrated in one function.
- alloc_space/random_read/treedb: dominant theme is value decode/read I/O (90.31% flat across top nodes).
- alloc_space/random_read/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (5415.52kB flat, 50.62%).
- alloc_space/random_read/treedb: top hotspot "compress/flate.NewWriter (inline)" is 50.62% flat; this section is highly concentrated in one function.
- alloc_space/random_read_batch/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/caching.(*DB).getManyViewFromPublishedRootPointShards" (30234.73kB flat, 64.95%).
- alloc_space/random_read_batch/treedb: top hotspot "github.com/snissn/gomap/TreeDB/caching.(*DB).getManyViewFromPublishedRootPointShards" is 64.95% flat; this section is highly concentrated in one function.
- alloc_space/random_read_parallel/treedb: dominant theme is value decode/read I/O (78.60% flat across top nodes).
- alloc_space/random_read_parallel/treedb: top allocator by bytes is "compress/flate.NewWriter (inline)" (3610.34kB flat, 37.66%).
- alloc_space/random_read_parallel/treedb: top hotspot "compress/flate.NewWriter (inline)" is 37.66% flat; this section is highly concentrated in one function.
- alloc_space/random_read_parallel_acquire_snapshot/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" (2370.31MB flat, 74.83%).
- alloc_space/random_read_parallel_acquire_snapshot/treedb: top hotspot "github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get" is 74.83% flat; this section is highly concentrated in one function.
- alloc_space/random_write/treedb: dominant theme is write/delete/flush path (89.16% flat across top nodes).
- alloc_space/random_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries" (30.14MB flat, 22.20%).
- alloc_space/sequential_write/treedb: dominant theme is write/delete/flush path (67.18% flat across top nodes).
- alloc_space/sequential_write/treedb: top allocator by bytes is "github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo" (36.01MB flat, 23.02%).
- block/batch_delete/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_delete/treedb: top hotspot "runtime.selectgo" is 89.37% flat; this section is highly concentrated in one function.
- block/batch_random/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_random/treedb: top hotspot "runtime.selectgo" is 91.41% flat; this section is highly concentrated in one function.
- block/batch_small_seq/treedb: dominant theme is locking/scheduling contention (99.85% flat across top nodes).
- block/batch_small_seq/treedb: top hotspot "runtime.selectgo" is 93.17% flat; this section is highly concentrated in one function.
- block/batch_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/batch_write/treedb: top hotspot "runtime.chanrecv1" is 57.87% flat; this section is highly concentrated in one function.
- block/batch_write_steady/treedb: dominant theme is locking/scheduling contention (99.13% flat across top nodes).
- block/batch_write_steady/treedb: top hotspot "runtime.selectgo" is 64.90% flat; this section is highly concentrated in one function.
- block/dataset_write_random/treedb: dominant theme is locking/scheduling contention (99.88% flat across top nodes).
- block/dataset_write_random/treedb: top hotspot "runtime.selectgo" is 78.37% flat; this section is highly concentrated in one function.
- block/dataset_write_sorted/treedb: dominant theme is locking/scheduling contention (89.23% flat across top nodes).
- block/dataset_write_sorted/treedb: top hotspot "runtime.selectgo" is 56.26% flat; this section is highly concentrated in one function.
- block/full_scan/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/full_scan/treedb: top hotspot "runtime.selectgo" is 89.41% flat; this section is highly concentrated in one function.
- block/prefix_scan/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/prefix_scan/treedb: top hotspot "runtime.chanrecv1" is 100.00% flat; this section is highly concentrated in one function.
- block/random_delete/treedb: dominant theme is locking/scheduling contention (99.90% flat across top nodes).
- block/random_delete/treedb: top hotspot "runtime.selectgo" is 71.60% flat; this section is highly concentrated in one function.
- block/random_read/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/random_read/treedb: top hotspot "runtime.selectgo" is 85.61% flat; this section is highly concentrated in one function.
- block/random_read_batch/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- block/random_read_batch/treedb: top hotspot "runtime.chanrecv1" is 100.00% flat; this section is highly concentrated in one function.
- block/random_read_parallel/treedb: dominant theme is locking/scheduling contention (93.84% flat across top nodes).
- block/random_read_parallel/treedb: top hotspot "runtime.selectgo" is 93.84% flat; this section is highly concentrated in one function.
- block/random_read_parallel_acquire_snapshot/treedb: dominant theme is locking/scheduling contention (93.74% flat across top nodes).
- block/random_read_parallel_acquire_snapshot/treedb: top hotspot "runtime.selectgo" is 75.13% flat; this section is highly concentrated in one function.
- block/random_write/treedb: dominant theme is locking/scheduling contention (99.86% flat across top nodes).
- block/random_write/treedb: top hotspot "runtime.selectgo" is 59.87% flat; this section is highly concentrated in one function.
- block/sequential_write/treedb: dominant theme is locking/scheduling contention (96.01% flat across top nodes).
- block/sequential_write/treedb: top hotspot "runtime.selectgo" is 66.62% flat; this section is highly concentrated in one function.
- batch_delete/treedb: dominant theme is iterator/seek/compare overhead (38.89% flat across top nodes).
- batch_random/treedb: dominant theme is iterator/seek/compare overhead (29.62% flat across top nodes).
- batch_small_seq/treedb: dominant theme is allocation/copy/gc (21.43% flat across top nodes).
- batch_write/treedb: dominant theme is iterator/seek/compare overhead (55.54% flat across top nodes).
- batch_write_steady/treedb: dominant theme is value decode/read I/O (39.12% flat across top nodes).
- full_scan/treedb: dominant theme is value decode/read I/O (41.38% flat across top nodes).
- full_scan/treedb: top hotspot "github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock" is 37.93% flat; this section is highly concentrated in one function.
- prefix_scan/treedb: dominant theme is iterator/seek/compare overhead (50.00% flat across top nodes).
- treedb: prefix_scan CPU is weighted toward iterator/seek work (50.00% flat) vs value decoding (12.50% flat). That points to iterator setup/seek overhead, not value decoding.
- random_read/treedb: dominant theme is iterator/seek/compare overhead (52.18% flat across top nodes).
- random_read_batch/treedb: dominant theme is iterator/seek/compare overhead (56.00% flat across top nodes).
- mutex/batch_random/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/batch_random/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/batch_small_seq/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/batch_small_seq/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/batch_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/batch_write/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/batch_write_steady/treedb: dominant theme is locking/scheduling contention (99.99% flat across top nodes).
- mutex/batch_write_steady/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 99.73% flat; this section is highly concentrated in one function.
- mutex/dataset_write_random/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/dataset_write_random/treedb: top hotspot "sync.(*Mutex).Unlock" is 99.45% flat; this section is highly concentrated in one function.
- mutex/dataset_write_sorted/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/dataset_write_sorted/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 100.00% flat; this section is highly concentrated in one function.
- mutex/full_scan/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/full_scan/treedb: top hotspot "runtime.unlock (inline)" is 100.00% flat; this section is highly concentrated in one function.
- mutex/random_delete/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/random_delete/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/random_read_parallel/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/random_read_parallel/treedb: top hotspot "sync.(*Mutex).Unlock (inline)" is 76.67% flat; this section is highly concentrated in one function.
- mutex/random_read_parallel_acquire_snapshot/treedb: dominant theme is locking/scheduling contention (99.98% flat across top nodes).
- mutex/random_read_parallel_acquire_snapshot/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 93.75% flat; this section is highly concentrated in one function.
- mutex/random_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/random_write/treedb: top hotspot "sync.(*Mutex).Unlock" is 100.00% flat; this section is highly concentrated in one function.
- mutex/sequential_write/treedb: dominant theme is locking/scheduling contention (100.00% flat across top nodes).
- mutex/sequential_write/treedb: top hotspot "sync.(*Mutex).Unlock (partial-inline)" is 99.37% flat; this section is highly concentrated in one function.

## Investigation Targets

| db tag | test | category | function | flat% | code | why |
|---|---|---|---|---:|---|---|
| treedb | batch_delete | other | `runtime/pprof.allFrames` | 48.66% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `runtime/pprof.(*profileBuilder).emitLocation` | 20.32% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `runtime/pprof.(*pcDeck).tryAdd` | 20.27% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `runtime/pprof.printCountCycleProfile` | 8.11% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 1.50% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | other | `runtime/pprof.(*protobuf).varint (inline)` | 0.63% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `main.runBenchmark.func26` | 0.00% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | other | `runtime/pprof.allFrames` | 87.69% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatchWithCustody` | 6.09% | `TreeDB/command_wal_public_cached.go:580` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 2.31% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace` | 1.43% | `TreeDB/internal/commitlog/command_frame.go:964` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` | 1.13% | `TreeDB/internal/commitlog/command_frame.go:444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | other | `runtime/pprof.(*profileBuilder).stringIndex (inline)` | 0.54% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).write` | 50.02% | `TreeDB/command_wal_public_cached.go:1132` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | other | `runtime/pprof.(*profileBuilder).emitLocation` | 25.01% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Close` | 7.50% | `TreeDB/command_wal_public_cached.go:1279` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` | 7.03% | `TreeDB/internal/commitlog/command_frame.go:444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatchWithCustody` | 4.17% | `TreeDB/command_wal_public_cached.go:580` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 4.17% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).NewBatch` | 1.71% | `TreeDB/caching/db.go:35746` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | other | `runtime/pprof.allFrames` | 73.49% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | other | `runtime/pprof.(*profileBuilder).emitLocation` | 17.33% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 3.50% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*appendOnlyDirectValueArena).alloc` | 1.72% | `TreeDB/caching/db.go:1983` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | other | `runtime/pprof.(*protobuf).varint (inline)` | 1.32% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 1.05% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | decode_read_io | `compress/flate.NewWriter (inline)` | 0.09% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | other | `main.runBenchmark.func6` | 0.01% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | runtime_syscall | `syscall.ByteSliceFromString` | 32.26% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_write_steady | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/db.scanCommandWALSegmentReader` | 31.50% | `TreeDB/db/command_wal_publish.go:667` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write_steady | other | `runtime/pprof.allFrames` | 15.06% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` | 8.08% | `TreeDB/internal/commitlog/fixed_wal.go:336` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | other | `github.com/snissn/gomap/TreeDB/internal/rootpublication.StabilizeStableNamespaceTokens` | 5.13% | `TreeDB/internal/rootpublication/resource_token.go:2328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 3.75% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | other | `github.com/snissn/gomap/TreeDB/zipper.init.func2` | 0.88% | `TreeDB/caching/db.go:1256` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | other | `github.com/snissn/gomap/TreeDB/db.(*leafGenerationRecordLengthIndex).add` | 0.74% | `TreeDB/db/leaf_generation_record_length_index.go:65` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 34.06% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 33.14% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 16.57% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 15.42% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 38.39% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 25.20% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 18.18% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 17.45% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | other | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` | 83.09% | `TreeDB/node/leaf.go:106` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.allFrames` | 16.62% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/caching.newValueLogIterator (inline)` | 45.42% | `TreeDB/caching/value_log_iterator.go:23` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | other | `runtime/pprof.allFrames` | 24.23% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).NewIterator` | 20.19% | `TreeDB/internal/memtable/append_only.go:2684` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 5.68% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/caching.(*DB).Iterator` | 3.24% | `TreeDB/caching/db.go:34964` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 32.41% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` | 26.05% | `TreeDB/caching/db.go:28712` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 23.15% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 17.36% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | other | `runtime/pprof.allFrames` | 0.68% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `runtime/pprof.(*profileBuilder).emitLocation` | 44.00% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 25.60% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | decode_read_io | `compress/flate.(*compressor).init` | 12.00% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | decode_read_io | `compress/flate.newDeflateFast (inline)` | 10.40% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | decode_read_io | `compress/flate.NewWriter (inline)` | 8.00% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `runtime/pprof.allFrames` | 90.02% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.printCountCycleProfile` | 8.57% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `github.com/snissn/gomap/TreeDB/caching.(*DB).getManyViewFromPublishedRootPointShards` | 0.50% | `TreeDB/caching/db.go:31148` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `main.runBenchmark.func35` | 0.03% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.allFrames` | 94.63% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.(*huffmanEncoder).generate` | 3.29% | `TreeDB/db/fuzz_test.go:22` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `runtime/pprof.(*protobuf).varint (inline)` | 1.41% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.(*compressor).init` | 0.30% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.NewWriter (inline)` | 0.07% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel_acquire_snapshot | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 50.69% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | other | `github.com/snissn/gomap/TreeDB/caching.getSnapshot` | 48.94% | `TreeDB/caching/snapshot.go:73` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 42.77% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 21.93% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 19.19% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 15.90% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 35.03% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 23.35% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 21.02% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 19.46% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.(*Zipper).applySpanNativeWithPrepared.func2` | 0.04% | `TreeDB/zipper/span_native_apply.go:320` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 46.36% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 18.47% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | decode_read_io | `compress/flate.NewWriter (inline)` | 9.14% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` | 5.34% | `TreeDB/internal/commitlog/command_frame.go:444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | other | `main.runBenchmark.func26` | 4.17% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | other | `runtime/pprof.allFrames` | 3.89% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | decode_read_io | `compress/flate.(*compressor).init` | 3.30% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_delete | other | `runtime/pprof.(*profileBuilder).emitLocation` | 2.64% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRawKVPayloadSpace` | 51.88% | `TreeDB/internal/commitlog/command_frame.go:964` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 27.04% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 5.25% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | decode_read_io | `compress/flate.NewWriter (inline)` | 4.55% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_random | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 4.46% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` | 2.19% | `TreeDB/internal/commitlog/command_frame.go:444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | other | `runtime/pprof.allFrames` | 1.29% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeInitializedFixedWAL` | 1.09% | `TreeDB/internal/commitlog/fixed_wal.go:260` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 81.32% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | decode_read_io | `compress/flate.(*compressor).init` | 3.27% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 2.69% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | decode_read_io | `compress/flate.NewWriter (inline)` | 2.37% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB.newCommandWALPublicBatchWithCustody` | 1.34% | `TreeDB/command_wal_public_cached.go:580` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*RawKVBatchPayloadBuilder).appendRevisionOffset (inline)` | 1.34% | `TreeDB/internal/commitlog/command_frame.go:444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).Close` | 1.34% | `TreeDB/command_wal_public_cached.go:1279` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | other | `runtime/pprof.(*profileBuilder).emitLocation` | 1.34% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 51.92% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 24.97% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | decode_read_io | `compress/flate.NewWriter (inline)` | 4.63% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 4.01% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 2.71% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | decode_read_io | `compress/flate.(*compressor).init` | 2.60% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).getBatchShardEntries` | 2.36% | `TreeDB/caching/db.go:36506` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | other | `main.runBenchmark.func6` | 1.41% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.loadFixedWAL` | 78.19% | `TreeDB/internal/commitlog/fixed_wal.go:336` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/db.scanCommandWALSegmentReader` | 7.94% | `TreeDB/db/command_wal_publish.go:667` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 4.62% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 3.07% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 1.68% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/batch.(*Batch).Reserve` | 0.70% | `TreeDB/batch/batch.go:448` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/commitlog.resizeReaderBuffer (inline)` | 0.64% | `TreeDB/internal/commitlog/reader.go:188` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | decode_read_io | `bufio.NewReaderSize (inline)` | 0.63% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 53.58% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 12.21% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 10.72% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 6.56% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 3.10% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).rebuildLatestIndexLocked` | 2.99% | `TreeDB/internal/memtable/append_only.go:1405` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 2.99% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 1.83% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 46.11% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 23.36% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyKeyArena).alloc` | 9.85% | `TreeDB/internal/memtable/append_only.go:954` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 7.38% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 3.69% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | decode_read_io | `compress/flate.NewWriter (inline)` | 3.25% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_sorted | alloc_copy_gc | `runtime.mallocgc` | 3.08% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | dataset_write_sorted | decode_read_io | `compress/flate.newDeflateFast (inline)` | 1.40% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestIndicesLocked` | 22.92% | `TreeDB/internal/memtable/append_only.go:1354` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | full_scan | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).buildSortedLatestSnapshotLocked` | 17.21% | `TreeDB/internal/memtable/append_only.go:2633` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | full_scan | decode_read_io | `compress/flate.NewWriter (inline)` | 16.97% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | other | `github.com/snissn/gomap/TreeDB/node.(*Node).ensureKeyScratch (inline)` | 14.44% | `TreeDB/node/leaf.go:106` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.(*protobuf).string (inline)` | 9.93% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | other | `runtime/pprof.allFrames` | 7.22% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | decode_read_io | `compress/flate.(*compressor).init` | 6.12% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | other | `runtime/pprof.(*profileBuilder).emitLocation` | 5.20% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | decode_read_io | `compress/flate.NewWriter (inline)` | 23.14% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | decode_read_io | `compress/flate.(*compressor).init` | 19.49% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | decode_read_io | `compress/flate.newDeflateFast (inline)` | 7.47% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | other | `runtime/pprof.(*protobuf).string (inline)` | 6.70% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 6.70% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 6.57% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `runtime/pprof.allFrames` | 6.57% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/caching.newValueLogIterator (inline)` | 6.56% | `TreeDB/caching/value_log_iterator.go:23` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 62.62% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 15.66% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 5.22% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).deleteDirectAfterCommandWALAppendWithPreparedRevision` | 5.22% | `TreeDB/caching/db.go:28712` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_delete | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 3.48% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | decode_read_io | `compress/flate.NewWriter (inline)` | 3.07% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | decode_read_io | `compress/flate.(*compressor).init` | 1.57% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | other | `runtime/pprof.allFrames` | 0.87% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | decode_read_io | `compress/flate.NewWriter (inline)` | 50.62% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | decode_read_io | `compress/flate.(*compressor).init` | 23.34% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | decode_read_io | `compress/flate.newDeflateFast (inline)` | 16.35% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read | other | `slices.Grow[go.shape.[]uint8,go.shape.uint8] (inline)` | 4.86% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | other | `runtime/pprof.(*profileBuilder).emitLocation` | 4.83% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `github.com/snissn/gomap/TreeDB/caching.(*DB).getManyViewFromPublishedRootPointShards` | 64.95% | `TreeDB/caching/db.go:31148` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.NewWriter (inline)` | 11.63% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `runtime/pprof.allFrames` | 6.60% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.(*compressor).init` | 4.19% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `runtime/pprof.(*profileBuilder).emitLocation` | 3.45% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `runtime/pprof.(*protobuf).string (inline)` | 3.38% | `TreeDB/db/span_run_contract.go:72` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | decode_read_io | `compress/flate.newDeflateFast (inline)` | 2.42% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_batch | other | `main.runBenchmark.func35` | 1.17% | `cmd/unified_bench/main.go:2472` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.NewWriter (inline)` | 37.66% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.(*compressor).init` | 18.15% | `TreeDB/caching/db.go:1256` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.newDeflateFast (inline)` | 17.44% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel | other | `runtime/pprof.allFrames` | 16.03% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | other | `runtime/pprof.(*protobuf).varint (inline)` | 5.37% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | decode_read_io | `compress/flate.(*huffmanEncoder).generate` | 5.35% | `TreeDB/db/fuzz_test.go:22` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_read_parallel_acquire_snapshot | other | `github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).Get` | 74.83% | `TreeDB/db/pools.go:91` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | other | `github.com/snissn/gomap/TreeDB/caching.getSnapshot` | 24.84% | `TreeDB/caching/snapshot.go:73` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 22.20% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 21.36% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 15.57% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 13.99% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).updateLatestIndexLocked` | 10.87% | `TreeDB/internal/memtable/append_only.go:1444` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 4.05% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | decode_read_io | `compress/flate.NewWriter (inline)` | 3.25% | `TreeDB/caching/cow_cut.go:216` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | locking_scheduling | `github.com/snissn/gomap/TreeDB/db.(*DB).LockCommandWALPublishWithBarriers` | 2.58% | `TreeDB/db/command_wal_barrier.go:262` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.encodeRawKVBatchPayloadPlannedTo` | 23.02% | `TreeDB/internal/commitlog/command_frame.go:2395` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.getAppendOnlyDirectValueArenaChunk` | 14.84% | `TreeDB/caching/db.go:1900` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | decode_read_io | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCacheSlot).storeLockedWithRecordChecksumState` | 12.84% | `TreeDB/db/leaf_page_read_cache.go:552` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeRawKVBatchPayloadTo` | 12.79% | `TreeDB/internal/commitlog/command_frame.go:2461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.getAppendOnlyEntries` | 7.34% | `TreeDB/internal/memtable/append_only.go:524` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.acquireSpanNativeLeafLogPayloadArena` | 5.27% | `TreeDB/zipper/span_native_apply.go:87` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | other | `github.com/snissn/gomap/TreeDB/zipper.init.func2` | 3.21% | `TreeDB/caching/db.go:1256` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 2.88% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | locking_scheduling | `runtime.selectgo` | 89.37% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_delete | locking_scheduling | `runtime.chanrecv1` | 10.63% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_random | locking_scheduling | `runtime.selectgo` | 91.41% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_random | locking_scheduling | `runtime.chanrecv1` | 6.02% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_random | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 2.57% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_small_seq | locking_scheduling | `runtime.selectgo` | 93.17% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_small_seq | locking_scheduling | `runtime.chanrecv1` | 6.68% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write | locking_scheduling | `runtime.chanrecv1` | 57.87% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write | locking_scheduling | `runtime.selectgo` | 41.34% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 0.79% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `runtime.selectgo` | 64.90% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `runtime.chanrecv2` | 19.50% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `runtime.chanrecv1` | 11.47% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `sync.(*Mutex).Lock (partial-inline)` | 3.26% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | other | `sync.(*WaitGroup).Wait` | 0.86% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | locking_scheduling | `runtime.selectgo` | 78.37% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | locking_scheduling | `runtime.chanrecv1` | 21.51% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | locking_scheduling | `runtime.selectgo` | 56.26% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | locking_scheduling | `runtime.chanrecv1` | 32.97% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | other | `sync.(*WaitGroup).Wait` | 10.50% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | locking_scheduling | `runtime.selectgo` | 89.41% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | locking_scheduling | `runtime.chanrecv1` | 10.59% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | prefix_scan | locking_scheduling | `runtime.chanrecv1` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | locking_scheduling | `runtime.selectgo` | 71.60% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | locking_scheduling | `runtime.chanrecv1` | 28.30% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | locking_scheduling | `runtime.selectgo` | 85.61% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read | locking_scheduling | `runtime.chanrecv1` | 14.39% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_batch | locking_scheduling | `runtime.chanrecv1` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | locking_scheduling | `runtime.selectgo` | 93.84% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | other | `sync.(*WaitGroup).Wait` | 6.00% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.selectgo` | 75.13% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.chanrecv1` | 11.13% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 7.48% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | other | `sync.(*WaitGroup).Wait` | 6.27% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | locking_scheduling | `runtime.selectgo` | 59.87% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | locking_scheduling | `runtime.chanrecv1` | 39.99% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime.selectgo` | 66.62% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime.chanrecv1` | 28.08% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | other | `sync.(*WaitGroup).Wait` | 4.00% | `TreeDB/internal/compression/trainer.go:328` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | locking_scheduling | `sync.(*Mutex).Lock (inline)` | 1.31% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_delete | iterator_seek_compare | `runtime.scanObject` | 22.22% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_delete | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 11.11% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | iterator_seek_compare | `runtime.typePointers.nextFast (inline)` | 11.11% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).DeleteViewValidatedWithRevision` | 5.56% | `TreeDB/caching/db.go:37745` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | other | `github.com/snissn/gomap/TreeDB/caching.pointEntryRevisionStats (inline)` | 5.56% | `TreeDB/caching/db.go:11160` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` | 5.56% | `TreeDB/internal/commitlog/command_frame.go:2780` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | write_delete_flush | `internal/runtime/maps.(*table).uncheckedPutSlot` | 5.56% | - | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_delete | runtime_syscall | `runtime.(*mspan).base` | 5.56% | `TreeDB/node/primary_directory_v1.go:221` | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | batch_random | other | `internal/runtime/syscall/linux.Syscall6` | 14.81% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | alloc_copy_gc | `runtime.memmove` | 11.11% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_random | iterator_seek_compare | `runtime.scanObject` | 11.11% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_random | iterator_seek_compare | `runtime.typePointers.next` | 11.11% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` | 7.41% | `TreeDB/internal/memtable/append_only.go:1461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | other | `encoding/binary.littleEndian.Uint32 (inline)` | 3.70% | `TreeDB/internal/quantizedasset/quantized_asset.go:960` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*Batch).writeRegularLocked` | 3.70% | `TreeDB/caching/db.go:38730` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.appendUniqueMemtable (inline)` | 3.70% | `TreeDB/caching/db.go:36649` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | alloc_copy_gc | `runtime.memclrNoHeapPointers` | 21.43% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_small_seq | other | `internal/runtime/maps.ctrlGroup.matchH2` | 10.71% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` | 7.14% | `TreeDB/internal/commitlog/command_frame.go:2780` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | other | `internal/runtime/syscall/linux.Syscall6` | 7.14% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_small_seq | iterator_seek_compare | `runtime.scanObject` | 7.14% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).innerSetViewWithMVCCInput` | 3.57% | `TreeDB/command_wal_public_cached.go:1643` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB.(*commandWALPublicBatch).setViewWithMVCCInput` | 3.57% | `TreeDB/command_wal_public_cached.go:834` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_small_seq | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.batchShardFirstLast` | 3.57% | `TreeDB/caching/db.go:36661` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | iterator_seek_compare | `runtime.scanObject` | 25.93% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 14.81% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write | alloc_copy_gc | `runtime.memmove` | 11.11% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_write | other | `internal/runtime/syscall/linux.Syscall6` | 7.41% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write | decode_read_io | `compress/flate.(*huffmanBitWriter).indexTokens` | 3.70% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEVPCLMUL512` | 3.70% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` | 3.70% | `TreeDB/internal/commitlog/command_frame.go:2780` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write | iterator_seek_compare | `internal/runtime/atomic.(*Uint32).CompareAndSwap` | 3.70% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | batch_write_steady | other | `internal/runtime/syscall/linux.Syscall6` | 12.65% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | batch_write_steady | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 9.84% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | decode_read_io | `hash/crc32.ieeeCLMUL` | 8.20% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 6.09% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | alloc_copy_gc | `runtime.memmove` | 4.45% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | batch_write_steady | decode_read_io | `github.com/snissn/gomap/TreeDB/internal/commitlog.decodeCommandFrameV2` | 3.75% | `TreeDB/internal/commitlog/command_frame_v2.go:202` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_write_steady | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` | 3.28% | `TreeDB/internal/commitlog/command_frame.go:2780` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | batch_write_steady | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 2.58% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | other | `internal/runtime/syscall/linux.Syscall6` | 11.96% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | other | `time.runtimeNow` | 7.61% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 4.35% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_random | iterator_seek_compare | `runtime.typePointers.next` | 4.35% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_random | other | `sync/atomic.(*Int32).Add (inline)` | 4.35% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_random | decode_read_io | `hash/crc32.ieeeCLMUL` | 3.26% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_random | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 3.26% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | dataset_write_random | write_delete_flush | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` | 2.17% | `TreeDB/db/command_wal_raw.go:2529` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | other | `internal/runtime/syscall/linux.Syscall6` | 15.09% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | dataset_write_sorted | iterator_seek_compare | `runtime.scanObject` | 5.66% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_sorted | alloc_copy_gc | `runtime.memclrNoHeapPointers` | 4.72% | - | Focus on allocation pressure, buffer growth, and copy-heavy code paths. |
| treedb | dataset_write_sorted | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).noteWrite` | 2.83% | `TreeDB/caching/db.go:14420` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | dataset_write_sorted | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 2.83% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 2.83% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_sorted | iterator_seek_compare | `runtime.typePointers.next` | 2.83% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | dataset_write_sorted | other | `time.runtimeNow` | 2.83% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | full_scan | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 37.93% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | iterator_seek_compare | `runtime.scanObject` | 11.49% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | full_scan | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` | 4.60% | `TreeDB/internal/memtable/append_only.go:718` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | full_scan | iterator_seek_compare | `cmpbody` | 3.45% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | full_scan | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/internal/merging.iteratorHeap.Less` | 3.45% | `TreeDB/internal/merging/merging.go:107` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | full_scan | decode_read_io | `github.com/snissn/gomap/TreeDB/db.(*leafPageReadCache).getToWithCOWPolicy` | 2.30% | `TreeDB/db/leaf_page_read_cache.go:814` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | full_scan | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/internal/memtable.(*appendOnlyIterator).UnsafeEntryWithRevision` | 2.30% | `TreeDB/internal/memtable/append_only.go:2939` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | full_scan | iterator_seek_compare | `github.com/snissn/gomap/TreeDB/internal/merging.(*MergingIterator).advance` | 2.30% | `TreeDB/internal/merging/merging.go:327` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 18.75% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.scanObject` | 12.50% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | iterator_seek_compare | `runtime.typePointers.next` | 12.50% | `TreeDB/db/api.go:668` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | prefix_scan | decode_read_io | `compress/flate.(*deflateFast).encode` | 6.25% | `TreeDB/page/meta.go:33` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | decode_read_io | `github.com/pierrec/lz4/v4/internal/lz4block.decodeBlock` | 6.25% | `TreeDB/internal/outerleaf/block.go:1893` | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | prefix_scan | other | `github.com/snissn/gomap/TreeDB/pager.isPrimaryBankID (inline)` | 6.25% | `TreeDB/pager/pager.go:1504` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | other | `internal/runtime/atomic.(*Uint32).Add` | 6.25% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | prefix_scan | runtime_syscall | `runtime.futex` | 6.25% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_delete | other | `internal/runtime/syscall/linux.Syscall6` | 15.58% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 7.79% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | iterator_seek_compare | `runtime.scanObject` | 6.49% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 6.49% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_delete | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 3.90% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_delete | other | `sync/atomic.(*Int32).Add (inline)` | 3.90% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | other | `encoding/binary.littleEndian.Uint32 (inline)` | 2.60% | `TreeDB/internal/quantizedasset/quantized_asset.go:960` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_delete | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.(*CommandJournal).appendCommand.func1` | 2.60% | `TreeDB/internal/commitlog/journal_owner.go:1365` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read | iterator_seek_compare | `runtime.scanObject` | 34.78% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 17.39% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).lookupEntryLocked` | 8.70% | `TreeDB/internal/memtable/append_only.go:2069` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read | runtime_syscall | `runtime.findObject` | 8.70% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_read | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 8.70% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read | other | `github.com/snissn/gomap/TreeDB/caching.memtableEntryWithRevision` | 4.35% | `TreeDB/caching/root_domain.go:115` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read | iterator_seek_compare | `internal/runtime/atomic.(*Uint32).CompareAndSwap (inline)` | 4.35% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read | runtime_syscall | `runtime.futex` | 4.35% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_read_batch | iterator_seek_compare | `runtime.scanObject` | 32.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_batch | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 16.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_batch | iterator_seek_compare | `bytes.Compare (inline)` | 4.00% | `TreeDB/collections/text_v2_search.go:219` | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_batch | iterator_seek_compare | `cmpbody` | 4.00% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_batch | other | `github.com/snissn/gomap/TreeDB/caching.(*DB).getManyViewFromPublishedRootPointShards.func1` | 4.00% | `TreeDB/caching/db.go:31148` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | other | `github.com/snissn/gomap/TreeDB/caching.probeRootDomainTablePointRefs` | 4.00% | `TreeDB/caching/root_domain.go:1240` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_batch | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` | 4.00% | `TreeDB/internal/memtable/append_only.go:718` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read_batch | other | `internal/runtime/atomic.(*Uint32).Add` | 4.00% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` | 22.22% | `TreeDB/internal/memtable/append_only.go:718` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read_parallel | other | `internal/runtime/maps.ctrlGroup.matchH2 (inline)` | 13.33% | `HashDB/hashindex.go:88` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel | map_hash_lookup | `runtime.mapaccess2_fast64` | 8.89% | - | Focus on key-shape and hash-table lookup/update costs. |
| treedb | random_read_parallel | iterator_seek_compare | `runtime.scanObject` | 5.56% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_parallel | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).getEntryFrozen` | 4.44% | `TreeDB/internal/memtable/append_only.go:1938` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_read_parallel | iterator_seek_compare | `runtime.tryDeferToSpanScan` | 4.44% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_parallel | iterator_seek_compare | `sync/atomic.(*Uint64).CompareAndSwap (inline)` | 4.44% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | random_read_parallel | map_hash_lookup | `github.com/snissn/gomap/TreeDB/caching.(*Snapshot).lookupCachedRootDomainEntryWithRevision` | 3.33% | `TreeDB/caching/snapshot.go:480` | Focus on key-shape and hash-table lookup/update costs. |
| treedb | random_read_parallel_acquire_snapshot | runtime_syscall | `runtime.procyieldAsm` | 18.64% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | random_read_parallel_acquire_snapshot | other | `sync/atomic.(*Int32).Add (inline)` | 10.53% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).Lock (inline)` | 6.82% | `TreeDB/internal/keyupdate/locks.go:34` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).lockSlow` | 5.44% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `internal/sync.(*Mutex).Unlock (inline)` | 3.54% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | other | `main.runBenchmark.func34.1` | 1.90% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_read_parallel_acquire_snapshot | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.appendOnlyEntryKey (inline)` | 1.81% | `TreeDB/internal/memtable/append_only.go:718` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | other | `internal/runtime/syscall/linux.Syscall6` | 13.75% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.ScanRawKVBatchPayloadWithRevision` | 3.75% | `TreeDB/internal/commitlog/command_frame.go:2780` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | decode_read_io | `hash/crc32.simpleUpdate (inline)` | 3.75% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | other | `sync/atomic.(*Int32).Add (inline)` | 3.75% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | other | `time.runtimeNow` | 3.75% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | random_write | decode_read_io | `github.com/snissn/go-crc32-asm.crc32IEEEPCLMUL8` | 2.50% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/commitlog.writeFixedAt` | 2.50% | `TreeDB/internal/commitlog/fixed_wal.go:298` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | random_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/internal/memtable.(*AppendOnly).appendEntryCoreLocked` | 2.50% | `TreeDB/internal/memtable/append_only.go:1461` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | other | `internal/runtime/syscall/linux.Syscall6` | 14.77% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | other | `sync/atomic.(*Int32).Add (inline)` | 5.68% | `TreeDB/db/pools.go:215` | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/caching.(*DB).setDirectAfterCommandWALAppendWithMVCCInput` | 3.41% | `TreeDB/caching/db.go:27504` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | runtime_syscall | `runtime.nanotime (inline)` | 3.41% | - | Focus on page-fault behavior, syscall frequency, and runtime scheduling effects. |
| treedb | sequential_write | iterator_seek_compare | `runtime.scanObject` | 3.41% | - | Focus on iterator construction, seek boundaries, and key-comparison loops. |
| treedb | sequential_write | other | `time.runtimeNow` | 3.41% | - | Inspect this symbol and its callers in the section-specific hot path. |
| treedb | sequential_write | write_delete_flush | `github.com/snissn/gomap/TreeDB/db.(*DB).AppendRawKVPointCommandWALTrustedWithPreparedRevisionAndMode` | 2.27% | `TreeDB/db/command_wal_raw.go:2529` | Focus on mutation hot loops, flush cadence, and checkpoint/compaction boundaries. |
| treedb | sequential_write | decode_read_io | `hash/crc32.ieeeCLMUL` | 2.27% | - | Focus on value materialization, read amplification, and decode/verification work. |
| treedb | batch_random | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_small_seq | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 99.73% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | batch_write_steady | locking_scheduling | `sync.(*RWMutex).Unlock` | 0.26% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_random | locking_scheduling | `sync.(*Mutex).Unlock` | 99.45% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | dataset_write_sorted | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 100.00% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | full_scan | locking_scheduling | `runtime.unlock (inline)` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_delete | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel | locking_scheduling | `sync.(*Mutex).Unlock (inline)` | 76.67% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 93.75% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_read_parallel_acquire_snapshot | locking_scheduling | `runtime.unlock (inline)` | 6.23% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | random_write | locking_scheduling | `sync.(*Mutex).Unlock` | 100.00% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `sync.(*Mutex).Unlock (partial-inline)` | 99.37% | - | Focus on lock scope, contention points, and channel/select coordination. |
| treedb | sequential_write | locking_scheduling | `runtime.unlock` | 0.63% | `TreeDB/collections/api.go:3729` | Focus on lock scope, contention points, and channel/select coordination. |

## Warnings

- trace detected at "/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/raw_engine_full_matrix/wal_on_fast_no_checkpoint_between_tests/trace.out" (trace analysis not yet implemented)

