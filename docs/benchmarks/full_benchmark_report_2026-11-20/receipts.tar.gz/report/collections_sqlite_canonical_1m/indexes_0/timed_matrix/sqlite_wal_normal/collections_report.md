# Collections Benchmark Report

- generated: `2026-11-20T18:09:36Z`
- status: `ok`
- execution path: `sqlite`
- benchmark engine: `sqlite_wal_normal`
- document format: `json`
- storage policy: `sqlite_wal_normal`
- pager chunk size: `-`
- pager sync concurrency: `-`
- worktree: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report-src`
- commit: `4fa77f0f54ba`
- benchmark regex: `^(BenchmarkSQLiteShapeInsertBatchJSON|BenchmarkSQLiteShapeInsertBatchNativeColumns)$/^indexes_0$`
- benchmark count: `1`
- collection batch size: `16000`
- raw benchmark json: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_0/timed_matrix/sqlite_wal_normal/go_test.json`
- throughput columns are derived from adjacent latency columns as `1e9/ns`

## SQLite Comparison

| Benchmark | Description | Samples | ns/op | Ops/sec | B/op | allocs/op | `target_docs/batch` | `indexes/doc` | `stored_docs` | `disk_total_bytes` | `disk_bytes/doc` | `sqlite_vacuum_ns/op` | `sqlite_vacuum_ops/sec` | `sqlite_vacuum_disk_total_bytes_before` | `sqlite_vacuum_disk_total_bytes_after` | `sqlite_vacuum_disk_total_bytes_delta` | `sqlite_vacuum_disk_bytes/doc_after` |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `BenchmarkSQLiteShapeInsertBatchJSON/indexes_0` | SQLite WAL/NORMAL batch insert using a JSON document column while sweeping secondary index count; ops/sec is documents/sec. | 1 | 1,354 | 738,552.44 | 192 | 7 | 16,000 | 0 | 100,000 | 14,635,008 | 146.4 | 28,282,501 | 35.36 | 14,635,008 | 12,824,576 | -1,810,432 | 128.2 |
| `BenchmarkSQLiteShapeInsertBatchNativeColumns/indexes_0` | SQLite WAL/NORMAL batch insert using native columns while sweeping secondary index count; ops/sec is documents/sec. | 1 | 1,631 | 613,120.78 | 368 | 10 | 16,000 | 0 | 100,000 | 10,014,720 | 100.1 | 23,790,225 | 42.03 | 10,014,720 | 8,929,280 | -1,085,440 | 89.29 |

