# TreeDB Collection Compression Matrix

- Run dir: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_0/offline_compact`
- Docs: `100000`
- Batch size: `16000`
- Document shape: template-v1 fixture fields `name`, `email`, `city`, `pad`
- Raw TreeDB case: generated template-v1 payloads stored directly by key
- Collection cases: generated template-v1 payloads inserted through collection mode with indexes `0 1 2`
- Compaction: `treemap compact <dir> -rw -mode full`
- Gzip ratio is `bytes/gzip_bytes`; lower is closer to gzip-compressed density already being present on disk.

| Mode | Indexes | Before bytes | Before gzip | Before bytes/gzip | After compact bytes | After compact gzip | After bytes/gzip | Disk delta | Gzip delta | After leaf_vlog bytes | After leaf bytes/gzip | After index.db bytes | After value_vlog bytes |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| raw_treedb | - | 10270209 | 344813 | 29.78 | 10269956 | 366190 | 28.05 | -0.0% | 6.2% | 1809509 | 5.89 | 4194304 | 0 |
| collection | 0 | 10099485 | 206741 | 48.85 | 10100729 | 212562 | 47.52 | 0.0% | 2.8% | 1640282 | 9.63 | 4194304 | 0 |
| collection | 1 | 11024695 | 349109 | 31.58 | 11026337 | 359289 | 30.69 | 0.0% | 2.9% | 2303686 | 8.15 | 4194304 | 0 |
| collection | 2 | 11928112 | 650354 | 18.34 | 10287575 | 880028 | 11.69 | -13.8% | 35.3% | 1564924 | 2.00 | 4194304 | 0 |

Raw TSV: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_0/offline_compact/compression_matrix.tsv`
