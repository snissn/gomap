# Collections Benchmark Matrix Run

## Run Metadata

- generated at: `2026-11-20T18:10:20Z`
- worktree: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report-src`
- branch: ``
- commit: `4fa77f0f54ba`
- bash command: `go run ./cmd/collection_bench_matrix -out-dir /mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_1/timed_matrix -formats template-v1,bson,json -engine command_wal_relaxed -storage-cells index-vlog -tree-bench-pattern '^BenchmarkCollectionShapeInsertBatch$/^indexes_1$' -sqlite-bench-pattern '^(BenchmarkSQLiteShapeInsertBatchJSON|BenchmarkSQLiteShapeInsertBatchNativeColumns)$/^indexes_1$' -batch-size 16000 -benchtime 100000x -count 1 -leaf-segment-target-bytes 1048576 -leafgen-pack-frame-k 16 -profile-cells -profile-benchtime 100000x -profile-count 1`
- argv json: `["go","run","./cmd/collection_bench_matrix","-out-dir","/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_1/timed_matrix","-formats","template-v1,bson,json","-engine","command_wal_relaxed","-storage-cells","index-vlog","-tree-bench-pattern","^BenchmarkCollectionShapeInsertBatch$/^indexes_1$","-sqlite-bench-pattern","^(BenchmarkSQLiteShapeInsertBatchJSON|BenchmarkSQLiteShapeInsertBatchNativeColumns)$/^indexes_1$","-batch-size","16000","-benchtime","100000x","-count","1","-leaf-segment-target-bytes","1048576","-leafgen-pack-frame-k","16","-profile-cells","-profile-benchtime","100000x","-profile-count","1"]`
- benchtime: `100000x`
- count: `1`
- collection batch size: `16000`
- profile cells: `true`
- profile benchtime: `100000x`
- profile count: `1`

## Primary Artifacts

- matrix summary markdown: `collections_matrix_summary.md`
- matrix summary html: `collections_matrix_summary.html`
- raw matrix tsv: `collections_matrix_summary.tsv`
- user-story tsv: `collections_user_story_summary.tsv`
- disk usage tsv: `collections_disk_usage_summary.tsv`
- maintenance tsv: `collections_maintenance_summary.tsv` (`treedb_vlog_rewrite` is value_vlog maintenance; `treedb_leafgen_pack_gc` is leaf_vlog generation maintenance)
- matrix index: `matrix_index.tsv`

## Cells

| Cell | Engine | Format | Data vlog | Index vlog | Bench pattern | Raw JSON | Report | Profiles |
| --- | --- | --- | ---: | ---: | --- | --- | --- | --- |
| `treedb_command_wal_relaxed_template_v1_data_vlog_index_vlog` | `command_wal_relaxed` | `template-v1` | `true` | `true` | `^BenchmarkCollectionShapeInsertBatch$/^indexes_1$` | `treedb_command_wal_relaxed_template_v1_data_vlog_index_vlog/go_test.json` | [report](treedb_command_wal_relaxed_template_v1_data_vlog_index_vlog/collections_report.md) | [manifest](treedb_command_wal_relaxed_template_v1_data_vlog_index_vlog/profiles/collection_profile_manifest.json) |
| `treedb_command_wal_relaxed_bson_data_vlog_index_vlog` | `command_wal_relaxed` | `bson` | `true` | `true` | `^BenchmarkCollectionShapeInsertBatch$/^indexes_1$` | `treedb_command_wal_relaxed_bson_data_vlog_index_vlog/go_test.json` | [report](treedb_command_wal_relaxed_bson_data_vlog_index_vlog/collections_report.md) | [manifest](treedb_command_wal_relaxed_bson_data_vlog_index_vlog/profiles/collection_profile_manifest.json) |
| `treedb_command_wal_relaxed_json_data_vlog_index_vlog` | `command_wal_relaxed` | `json` | `true` | `true` | `^BenchmarkCollectionShapeInsertBatch$/^indexes_1$` | `treedb_command_wal_relaxed_json_data_vlog_index_vlog/go_test.json` | [report](treedb_command_wal_relaxed_json_data_vlog_index_vlog/collections_report.md) | [manifest](treedb_command_wal_relaxed_json_data_vlog_index_vlog/profiles/collection_profile_manifest.json) |
| `sqlite_wal_normal` | `sqlite_wal_normal` | `json` | `-` | `-` | `^(BenchmarkSQLiteShapeInsertBatchJSON\|BenchmarkSQLiteShapeInsertBatchNativeColumns)$/^indexes_1$` | `sqlite_wal_normal/go_test.json` | [report](sqlite_wal_normal/collections_report.md) | [manifest](sqlite_wal_normal/profiles/collection_profile_manifest.json) |
