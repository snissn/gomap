# Collections Benchmark Report

- generated: `2026-11-20T18:10:11Z`
- status: `ok`
- execution path: `sqlite`
- benchmark engine: `sqlite_wal_normal`
- document format: `json`
- storage policy: `sqlite_wal_normal`
- pager chunk size: `-`
- pager sync concurrency: `-`
- worktree: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report-src`
- commit: `4fa77f0f54ba`
- benchmark regex: `^(BenchmarkSQLiteShapeInsertBatchJSON|BenchmarkSQLiteShapeInsertBatchNativeColumns)$/^indexes_1$`
- benchmark count: `1`
- collection batch size: `16000`
- raw benchmark json: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_1/timed_matrix/sqlite_wal_normal/go_test.json`
- throughput columns are derived from adjacent latency columns as `1e9/ns`

## SQLite Comparison

| Benchmark | Description | Samples | ns/op | Ops/sec | B/op | allocs/op | `target_docs/batch` | `indexes/doc` | `stored_docs` | `disk_total_bytes` | `disk_bytes/doc` | `sqlite_vacuum_ns/op` | `sqlite_vacuum_ops/sec` | `sqlite_vacuum_disk_total_bytes_before` | `sqlite_vacuum_disk_total_bytes_after` | `sqlite_vacuum_disk_total_bytes_delta` | `sqlite_vacuum_disk_bytes/doc_after` |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `BenchmarkSQLiteShapeInsertBatchJSON/indexes_1` | SQLite WAL/NORMAL batch insert using a JSON document column while sweeping secondary index count; ops/sec is documents/sec. | 1 | 2,199 | 454,752.16 | 192 | 7 | 16,000 | 1 | 100,000 | 22,736,896 | 227.4 | 48,375,530 | 20.67 | 22,736,896 | 20,111,360 | -2,625,536 | 201.1 |
| `BenchmarkSQLiteShapeInsertBatchNativeColumns/indexes_1` | SQLite WAL/NORMAL batch insert using native columns while sweeping secondary index count; ops/sec is documents/sec. | 1 | 2,042 | 489,715.96 | 368 | 10 | 16,000 | 1 | 100,000 | 14,901,248 | 149 | 34,868,275 | 28.68 | 14,901,248 | 13,250,560 | -1,650,688 | 132.5 |

