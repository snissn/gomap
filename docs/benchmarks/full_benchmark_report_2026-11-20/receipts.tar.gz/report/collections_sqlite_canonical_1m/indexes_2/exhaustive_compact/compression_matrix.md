# TreeDB Collection Compression Matrix

- Run dir: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_2/exhaustive_compact`
- Docs: `100000`
- Batch size: `16000`
- Document shape: template-v1 fixture fields `name`, `email`, `city`, `pad`
- Raw TreeDB case: generated template-v1 payloads stored directly by key
- Collection cases: generated template-v1 payloads inserted through collection mode with indexes `0 1 2`
- Compaction: `treemap compact <dir> -rw -mode exhaustive`
- Gzip ratio is `bytes/gzip_bytes`; lower is closer to gzip-compressed density already being present on disk.

| Mode | Indexes | Before bytes | Before gzip | Before bytes/gzip | After compact bytes | After compact gzip | After bytes/gzip | Disk delta | Gzip delta | After leaf_vlog bytes | After leaf bytes/gzip | After index.db bytes | After value_vlog bytes |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| raw_treedb | - | 10270209 | 344806 | 29.79 | 9927729 | 760250 | 13.06 | -3.3% | 120.5% | 1303382 | 1.88 | 4194304 | 0 |
| collection | 0 | 10099485 | 206678 | 48.87 | 9751192 | 523094 | 18.64 | -3.4% | 153.1% | 1126845 | 2.39 | 4194304 | 0 |
| collection | 1 | 11024695 | 349085 | 31.58 | 10027060 | 682966 | 14.68 | -9.0% | 95.6% | 1304409 | 2.15 | 4194304 | 0 |
| collection | 2 | 11928112 | 651129 | 18.32 | 10281778 | 878152 | 11.71 | -13.8% | 34.9% | 1559127 | 1.99 | 4194304 | 0 |

Raw TSV: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_2/exhaustive_compact/compression_matrix.tsv`
