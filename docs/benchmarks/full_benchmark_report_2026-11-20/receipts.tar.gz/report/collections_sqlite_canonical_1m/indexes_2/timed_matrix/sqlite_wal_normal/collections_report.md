# Collections Benchmark Report

- generated: `2026-11-20T18:10:47Z`
- status: `ok`
- execution path: `sqlite`
- benchmark engine: `sqlite_wal_normal`
- document format: `json`
- storage policy: `sqlite_wal_normal`
- pager chunk size: `-`
- pager sync concurrency: `-`
- worktree: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report-src`
- commit: `4fa77f0f54ba`
- benchmark regex: `^(BenchmarkSQLiteShapeInsertBatchJSON|BenchmarkSQLiteShapeInsertBatchNativeColumns)$/^indexes_2$`
- benchmark count: `1`
- collection batch size: `16000`
- raw benchmark json: `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_2/timed_matrix/sqlite_wal_normal/go_test.json`
- throughput columns are derived from adjacent latency columns as `1e9/ns`

## SQLite Comparison

| Benchmark | Description | Samples | ns/op | Ops/sec | B/op | allocs/op | `target_docs/batch` | `indexes/doc` | `stored_docs` | `disk_total_bytes` | `disk_bytes/doc` | `sqlite_vacuum_ns/op` | `sqlite_vacuum_ops/sec` | `sqlite_vacuum_disk_total_bytes_before` | `sqlite_vacuum_disk_total_bytes_after` | `sqlite_vacuum_disk_total_bytes_delta` | `sqlite_vacuum_disk_bytes/doc_after` |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `BenchmarkSQLiteShapeInsertBatchJSON/indexes_2` | SQLite WAL/NORMAL batch insert using a JSON document column while sweeping secondary index count; ops/sec is documents/sec. | 1 | 3,066 | 326,157.86 | 192 | 7 | 16,000 | 2 | 100,000 | 26,263,552 | 262.6 | 57,868,779 | 17.28 | 26,263,552 | 23,166,976 | -3,096,576 | 231.7 |
| `BenchmarkSQLiteShapeInsertBatchNativeColumns/indexes_2` | SQLite WAL/NORMAL batch insert using native columns while sweeping secondary index count; ops/sec is documents/sec. | 1 | 2,706 | 369,549.15 | 368 | 10 | 16,000 | 2 | 100,000 | 17,612,800 | 176.1 | 38,534,588 | 25.95 | 17,612,800 | 15,671,296 | -1,941,504 | 156.7 |

