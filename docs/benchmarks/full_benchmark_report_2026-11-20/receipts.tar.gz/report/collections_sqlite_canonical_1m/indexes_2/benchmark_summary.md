# TreeDB Collections Canonical Benchmark

## Executive Summary

`sqlite_native_columns_2_indexes` is the fastest indexed ingest row in this run. TreeDB byte-minimized two-index template-v1 collection storage is 102.8 B/doc via exhaustive compact; production offline compact is 102.9 B/doc. Compared with SQLite after `VACUUM`, exhaustive compact is about 1.5x smaller than SQLite native columns and 2.3x smaller than SQLite JSON; production offline compact is about 1.5x and 2.3x smaller, respectively.

## Benchmark Configuration

| Key | Value |
| --- | --- |
| `generated_at` | `2026-11-20T18:10:35Z` |
| `run_dir` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_2` |
| `worktree` | `/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report-src` |
| `branch` | `remotes/origin/HEAD` |
| `commit` | `4fa77f0f54ba` |
| `command_line` | `./scripts/bench_collections_canonical.sh -out-dir /mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_2 -docs 100000 -batch-size 16000 -indexes 2 -formats template-v1\,bson\,json -benchtime 100000x -count 1 -profile-timed-matrix -profile-benchtime 100000x -profile-count 1` |
| `docs` | `100000` |
| `batch_size` | `16000` |
| `indexes` | `2` |
| `tree_engine` | `command_wal_relaxed` |
| `profile` | `command_wal_relaxed` |
| `formats` | `template-v1,bson,json` |
| `leaf_segment_target_bytes` | `1048576` |
| `leafgen_pack_force` | `true` |
| `leafgen_pack_max_generations` | `0` |
| `leafgen_pack_frame_k` | `16` |
| `index_vacuum` | `offline` |
| `profile_timed_matrix` | `true` |
| `profile_benchtime` | `100000x` |
| `profile_count` | `1` |

## Throughput Results

These rows are benchmark-timed post-insert measurements. Maintenance rows are excluded from throughput ranking.

| Config | Format | Indexes | Docs/sec | ns/doc | Batch size | Source |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| `sqlite_native_columns_2_indexes` | native-columns | 2 | 369549 | 2706.0 | 16000 | go_benchmark |
| `sqlite_json_2_indexes` | json | 2 | 326158 | 3066.0 | 16000 | go_benchmark |
| `treedb_template_v1_collection_2_indexes` | template-v1 | 2 | 321130 | 3114.0 | 16000 | go_benchmark |
| `treedb_bson_collection_2_indexes` | bson | 2 | 298063 | 3355.0 | 16000 | go_benchmark |
| `treedb_json_collection_2_indexes` | json | 2 | 264550 | 3780.0 | 16000 | go_benchmark |

## Post-Insert Storage Comparison

These rows use the timed benchmark matrix post-insert basis. They are fair to compare with each other, but they are not compacted-state numbers.

| Config | Format | Indexes | Total bytes | B/doc | Docs/sec |
| --- | --- | ---: | ---: | ---: | ---: |
| `sqlite_native_columns_2_indexes` | native-columns | 2 | 17,612,800 | 176.1 | 369549 |
| `sqlite_json_2_indexes` | json | 2 | 26,263,552 | 262.6 | 326158 |
| `treedb_bson_collection_2_indexes` | bson | 2 | 28,624,668 | 286.2 | 298063 |
| `treedb_template_v1_collection_2_indexes` | template-v1 | 2 | 36,802,056 | 368.0 | 321130 |
| `treedb_json_collection_2_indexes` | json | 2 | 38,303,429 | 383.0 | 264550 |

## Storage Results by Phase

| Config | Shape | Phase | Total bytes | B/doc | Measurement | Note |
| --- | --- | --- | ---: | ---: | --- | --- |
| `sqlite_json_2_indexes` | collection | `post_insert` | 26,263,552 | 262.6 | go_benchmark | SQLite post-insert size before VACUUM; not compacted |
| `sqlite_json_2_indexes` | collection | `sqlite_vacuum` | 23,166,976 | 231.7 | benchmark_post_processing | SQLite compacted baseline; use this for compacted-state comparisons |
| `sqlite_native_columns_2_indexes` | collection | `post_insert` | 17,612,800 | 176.1 | go_benchmark | SQLite post-insert size before VACUUM; not compacted |
| `sqlite_native_columns_2_indexes` | collection | `sqlite_vacuum` | 15,671,296 | 156.7 | benchmark_post_processing | SQLite compacted baseline; use this for compacted-state comparisons |
| `treedb_bson_collection_2_indexes` | collection | `post_insert` | 28,952,953 | 289.5 | fixture_wall_timed | full leafgen fixture pre-maintenance size; use benchmark-timed rows for primary throughput |
| `treedb_bson_collection_2_indexes` | collection | `post_insert` | 28,624,668 | 286.2 | go_benchmark | post-insert benchmark size; not compacted |
| `treedb_bson_collection_2_indexes` | collection | `online_one_pass_maintenance` | 29,234,616 | 292.3 | benchmark_post_processing | partial online maintenance from the timed benchmark harness; not full compaction |
| `treedb_bson_collection_2_indexes` | collection | `full_leafgen_pack_gc` | 13,554,817 | 135.5 | fixture_post_processing | full leafgen pack/GC with explicit flags followed by configured index vacuum |
| `treedb_json_collection_2_indexes` | collection | `post_insert` | 38,631,714 | 386.3 | fixture_wall_timed | full leafgen fixture pre-maintenance size; use benchmark-timed rows for primary throughput |
| `treedb_json_collection_2_indexes` | collection | `post_insert` | 38,303,429 | 383.0 | go_benchmark | post-insert benchmark size; not compacted |
| `treedb_json_collection_2_indexes` | collection | `online_one_pass_maintenance` | 38,338,663 | 383.4 | benchmark_post_processing | partial online maintenance from the timed benchmark harness; not full compaction |
| `treedb_json_collection_2_indexes` | collection | `full_leafgen_pack_gc` | 15,484,366 | 154.8 | fixture_post_processing | full leafgen pack/GC with explicit flags followed by configured index vacuum |
| `treedb_template_v1_collection_0_indexes` | collection | `exhaustive_compact` | 9,751,192 | 97.5 | offline_script | High-level CompactStorage path using treemap compact -rw -mode exhaustive |
| `treedb_template_v1_collection_0_indexes` | collection | `post_insert` | 10,099,485 | 101.0 | offline_script | offline compact matrix before-compact size; not compacted |
| `treedb_template_v1_collection_0_indexes` | collection | `post_insert` | 10,099,485 | 101.0 | offline_script | offline compact matrix before-compact size; not compacted |
| `treedb_template_v1_collection_0_indexes` | collection | `offline_compact` | 10,100,729 | 101.0 | offline_script | High-level CompactStorage path using treemap compact -rw -mode full |
| `treedb_template_v1_collection_1_indexes` | collection | `exhaustive_compact` | 10,027,060 | 100.3 | offline_script | High-level CompactStorage path using treemap compact -rw -mode exhaustive |
| `treedb_template_v1_collection_1_indexes` | collection | `post_insert` | 11,024,695 | 110.2 | offline_script | offline compact matrix before-compact size; not compacted |
| `treedb_template_v1_collection_1_indexes` | collection | `post_insert` | 11,024,695 | 110.2 | offline_script | offline compact matrix before-compact size; not compacted |
| `treedb_template_v1_collection_1_indexes` | collection | `offline_compact` | 11,026,337 | 110.3 | offline_script | High-level CompactStorage path using treemap compact -rw -mode full |
| `treedb_template_v1_collection_2_indexes` | collection | `post_insert` | 20,332,645 | 203.3 | fixture_wall_timed | full leafgen fixture pre-maintenance size; use benchmark-timed rows for primary throughput |
| `treedb_template_v1_collection_2_indexes` | collection | `post_insert` | 36,802,056 | 368.0 | go_benchmark | post-insert benchmark size; not compacted |
| `treedb_template_v1_collection_2_indexes` | collection | `post_insert` | 11,928,112 | 119.3 | offline_script | offline compact matrix before-compact size; not compacted |
| `treedb_template_v1_collection_2_indexes` | collection | `post_insert` | 11,928,112 | 119.3 | offline_script | offline compact matrix before-compact size; not compacted |
| `treedb_template_v1_collection_2_indexes` | collection | `exhaustive_compact` | 10,281,778 | 102.8 | offline_script | High-level CompactStorage path using treemap compact -rw -mode exhaustive |
| `treedb_template_v1_collection_2_indexes` | collection | `online_one_pass_maintenance` | 36,836,715 | 368.4 | benchmark_post_processing | partial online maintenance from the timed benchmark harness; not full compaction |
| `treedb_template_v1_collection_2_indexes` | collection | `offline_compact` | 10,287,471 | 102.9 | offline_script | High-level CompactStorage path using treemap compact -rw -mode full |
| `treedb_template_v1_collection_2_indexes` | collection | `full_leafgen_pack_gc` | 13,337,923 | 133.4 | fixture_post_processing | full leafgen pack/GC with explicit flags followed by configured index vacuum |
| `treedb_template_v1_raw` | raw | `exhaustive_compact` | 9,927,729 | 99.3 | offline_script | High-level CompactStorage path using treemap compact -rw -mode exhaustive |
| `treedb_template_v1_raw` | raw | `post_insert` | 10,270,209 | 102.7 | offline_script | offline compact matrix before-compact size; not compacted |
| `treedb_template_v1_raw` | raw | `post_insert` | 10,270,209 | 102.7 | offline_script | offline compact matrix before-compact size; not compacted |
| `treedb_template_v1_raw` | raw | `offline_compact` | 10,269,956 | 102.7 | offline_script | High-level CompactStorage path using treemap compact -rw -mode full |

## Production Evidence

| Config | Phase | Producer route | Route used ops | Route fallbacks | GOMAXPROCS | Physical cores | Effective concurrency | Admitted | Span-native | Backlog coalescing | Storage policy |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | --- | --- | --- |
| `treedb_bson_collection_2_indexes` | `post_insert` | `command_wal_publish` | 252028 | 0 | 12 | 6 | 6 | true | true | true | data_outer=true,index_outer=true |
| `treedb_bson_collection_2_indexes` | `online_one_pass_maintenance` | `command_wal_publish` | 252028 | 0 | 12 | 6 | 6 | true | true | true | data_outer=true,index_outer=true |
| `treedb_bson_collection_2_indexes` | `full_leafgen_pack_gc` | `` | - | - | - | - | - | - | - | - | data_outer=true,index_outer=true |
| `treedb_json_collection_2_indexes` | `post_insert` | `command_wal_publish` | 336035 | 0 | 12 | 6 | 6 | true | true | true | data_outer=true,index_outer=true |
| `treedb_json_collection_2_indexes` | `online_one_pass_maintenance` | `command_wal_publish` | 336035 | 0 | 12 | 6 | 6 | true | true | true | data_outer=true,index_outer=true |
| `treedb_json_collection_2_indexes` | `full_leafgen_pack_gc` | `` | - | - | - | - | - | - | - | - | data_outer=true,index_outer=true |
| `treedb_template_v1_collection_0_indexes` | `exhaustive_compact` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_0_indexes` | `post_insert` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_0_indexes` | `post_insert` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_0_indexes` | `offline_compact` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_1_indexes` | `exhaustive_compact` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_1_indexes` | `post_insert` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_1_indexes` | `post_insert` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_1_indexes` | `offline_compact` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_2_indexes` | `post_insert` | `command_wal_publish` | 252029 | 0 | 12 | 6 | 6 | true | true | true | data_outer=true,index_outer=true |
| `treedb_template_v1_collection_2_indexes` | `post_insert` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_2_indexes` | `post_insert` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_2_indexes` | `exhaustive_compact` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_2_indexes` | `online_one_pass_maintenance` | `command_wal_publish` | 252029 | 0 | 12 | 6 | 6 | true | true | true | data_outer=true,index_outer=true |
| `treedb_template_v1_collection_2_indexes` | `offline_compact` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_collection_2_indexes` | `full_leafgen_pack_gc` | `` | - | - | - | - | - | - | - | - | data_outer=true,index_outer=true |
| `treedb_template_v1_raw` | `exhaustive_compact` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_raw` | `post_insert` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_raw` | `post_insert` | `` | - | - | - | - | - | - | - | - | index-vlog |
| `treedb_template_v1_raw` | `offline_compact` | `` | - | - | - | - | - | - | - | - | index-vlog |

## Fair Compacted-State Comparison

TreeDB compacted rows are compared with SQLite after `VACUUM`. Use `exhaustive_compact` for byte-minimized benchmark/VACUUM-equivalent claims; do not compare TreeDB compacted rows only against SQLite `post_insert` rows.

SQLite compacted baselines:

| Config | Phase | B/doc | Total bytes |
| --- | --- | ---: | ---: |
| `sqlite_json_2_indexes` | `sqlite_vacuum` | 231.7 | 23,166,976 |
| `sqlite_native_columns_2_indexes` | `sqlite_vacuum` | 156.7 | 15,671,296 |

TreeDB compacted rows versus SQLite after `VACUUM`:

| TreeDB config | Phase | B/doc | vs SQLite native-columns VACUUM | vs SQLite JSON VACUUM |
| --- | --- | ---: | ---: | ---: |
| `treedb_template_v1_collection_2_indexes` | `offline_compact` | 102.9 | 1.5x smaller | 2.3x smaller |
| `treedb_template_v1_collection_2_indexes` | `exhaustive_compact` | 102.8 | 1.5x smaller | 2.3x smaller |
| `treedb_template_v1_collection_2_indexes` | `full_leafgen_pack_gc` | 133.4 | 1.2x smaller | 1.7x smaller |

Derived comparison rows are also emitted in `benchmark_results.json` under `comparisons`.

## Maintenance/Compaction Details

| Phase | Canonical meaning | Required comparison basis |
| --- | --- | --- |
| `post_insert` | Size after insert benchmark/fixture and correctness flush/checkpoint. | Compare with other post-insert rows only. |
| `online_one_pass_maintenance` | Partial online maintenance from benchmark harness; currently one online rewrite/GC path and one leafgen-pack pass. | Do not present as full compaction. |
| `offline_compact` | Production high-level `treemap compact <dir> -rw -mode full` path. | Compare with SQLite `sqlite_vacuum`; not the byte-minimized headline. |
| `exhaustive_compact` | Benchmark/VACUUM-equivalent `treemap compact <dir> -rw -mode exhaustive` path. | Preferred TreeDB compacted-size headline versus SQLite `sqlite_vacuum`. |
| `full_leafgen_pack_gc` | Diagnostic forced/full leaf generation pack/GC with explicit knobs and configured index vacuum. | Diagnostic only; compare with SQLite `sqlite_vacuum` if reported. |
| `sqlite_vacuum` | SQLite compacted baseline after `VACUUM`. | Required baseline for compacted-state comparison. |

Full leafgen knobs recorded for this run:

| Key | Value |
| --- | --- |
| `leaf-segment-target-bytes` | `1048576` |
| `leafgen-pack-gc` | `true` |
| `leafgen-pack-force` | `true` |
| `leafgen-pack-max-generations` | `0` |
| `leafgen-pack-frame-k` | `16` |
| `index-vacuum` | `offline` |

## Guardrail Checks

| Severity | Code | Message |
| --- | --- | --- |
| warning | `phase.online_one_pass.partial` | online_one_pass_maintenance is partial online maintenance; do not describe it as full compaction |
| info | `raw_shape_labeled` | raw TreeDB rows are labeled shape=raw and should not be mixed with collection rows without that label |

## Raw Results Appendix

Machine-readable JSON: `benchmark_results.json`

CSV matrix: `benchmark_matrix.csv`

| Config | Phase | Engine | Format | Indexes | Docs | Bytes | B/doc | Docs/sec | ns/doc |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `sqlite_json_2_indexes` | `post_insert` | sqlite_wal_normal | json | 2 | 100000 | 26,263,552 | 262.6 | 326158 | 3066.0 |
| `sqlite_json_2_indexes` | `sqlite_vacuum` | sqlite_wal_normal | json | 2 | 100000 | 23,166,976 | 231.7 | - | - |
| `sqlite_native_columns_2_indexes` | `post_insert` | sqlite_wal_normal | native-columns | 2 | 100000 | 17,612,800 | 176.1 | 369549 | 2706.0 |
| `sqlite_native_columns_2_indexes` | `sqlite_vacuum` | sqlite_wal_normal | native-columns | 2 | 100000 | 15,671,296 | 156.7 | - | - |
| `treedb_bson_collection_2_indexes` | `post_insert` | treedb_command_wal_relaxed | bson | 2 | 100000 | 28,952,953 | 289.5 | 288914 | 3461.2 |
| `treedb_bson_collection_2_indexes` | `post_insert` | command_wal_relaxed | bson | 2 | 100000 | 28,624,668 | 286.2 | 298063 | 3355.0 |
| `treedb_bson_collection_2_indexes` | `online_one_pass_maintenance` | command_wal_relaxed | bson | 2 | 100000 | 29,234,616 | 292.3 | - | - |
| `treedb_bson_collection_2_indexes` | `full_leafgen_pack_gc` | treedb_command_wal_relaxed | bson | 2 | 100000 | 13,554,817 | 135.5 | - | - |
| `treedb_json_collection_2_indexes` | `post_insert` | treedb_command_wal_relaxed | json | 2 | 100000 | 38,631,714 | 386.3 | 264366 | 3782.6 |
| `treedb_json_collection_2_indexes` | `post_insert` | command_wal_relaxed | json | 2 | 100000 | 38,303,429 | 383.0 | 264550 | 3780.0 |
| `treedb_json_collection_2_indexes` | `online_one_pass_maintenance` | command_wal_relaxed | json | 2 | 100000 | 38,338,663 | 383.4 | - | - |
| `treedb_json_collection_2_indexes` | `full_leafgen_pack_gc` | treedb_command_wal_relaxed | json | 2 | 100000 | 15,484,366 | 154.8 | - | - |
| `treedb_template_v1_collection_0_indexes` | `exhaustive_compact` | treedb_command_wal_relaxed | template-v1 | 0 | 100000 | 9,751,192 | 97.5 | - | - |
| `treedb_template_v1_collection_0_indexes` | `post_insert` | treedb_command_wal_relaxed | template-v1 | 0 | 100000 | 10,099,485 | 101.0 | - | - |
| `treedb_template_v1_collection_0_indexes` | `post_insert` | treedb_command_wal_relaxed | template-v1 | 0 | 100000 | 10,099,485 | 101.0 | - | - |
| `treedb_template_v1_collection_0_indexes` | `offline_compact` | treedb_command_wal_relaxed | template-v1 | 0 | 100000 | 10,100,729 | 101.0 | - | - |
| `treedb_template_v1_collection_1_indexes` | `exhaustive_compact` | treedb_command_wal_relaxed | template-v1 | 1 | 100000 | 10,027,060 | 100.3 | - | - |
| `treedb_template_v1_collection_1_indexes` | `post_insert` | treedb_command_wal_relaxed | template-v1 | 1 | 100000 | 11,024,695 | 110.2 | - | - |
| `treedb_template_v1_collection_1_indexes` | `post_insert` | treedb_command_wal_relaxed | template-v1 | 1 | 100000 | 11,024,695 | 110.2 | - | - |
| `treedb_template_v1_collection_1_indexes` | `offline_compact` | treedb_command_wal_relaxed | template-v1 | 1 | 100000 | 11,026,337 | 110.3 | - | - |
| `treedb_template_v1_collection_2_indexes` | `post_insert` | treedb_command_wal_relaxed | template-v1 | 2 | 100000 | 20,332,645 | 203.3 | 335303 | 2982.4 |
| `treedb_template_v1_collection_2_indexes` | `post_insert` | command_wal_relaxed | template-v1 | 2 | 100000 | 36,802,056 | 368.0 | 321130 | 3114.0 |
| `treedb_template_v1_collection_2_indexes` | `post_insert` | treedb_command_wal_relaxed | template-v1 | 2 | 100000 | 11,928,112 | 119.3 | - | - |
| `treedb_template_v1_collection_2_indexes` | `post_insert` | treedb_command_wal_relaxed | template-v1 | 2 | 100000 | 11,928,112 | 119.3 | - | - |
| `treedb_template_v1_collection_2_indexes` | `exhaustive_compact` | treedb_command_wal_relaxed | template-v1 | 2 | 100000 | 10,281,778 | 102.8 | - | - |
| `treedb_template_v1_collection_2_indexes` | `online_one_pass_maintenance` | command_wal_relaxed | template-v1 | 2 | 100000 | 36,836,715 | 368.4 | - | - |
| `treedb_template_v1_collection_2_indexes` | `offline_compact` | treedb_command_wal_relaxed | template-v1 | 2 | 100000 | 10,287,471 | 102.9 | - | - |
| `treedb_template_v1_collection_2_indexes` | `full_leafgen_pack_gc` | treedb_command_wal_relaxed | template-v1 | 2 | 100000 | 13,337,923 | 133.4 | - | - |
| `treedb_template_v1_raw` | `exhaustive_compact` | treedb_command_wal_relaxed | template-v1 | 0 | 100000 | 9,927,729 | 99.3 | - | - |
| `treedb_template_v1_raw` | `post_insert` | treedb_command_wal_relaxed | template-v1 | 0 | 100000 | 10,270,209 | 102.7 | - | - |
| `treedb_template_v1_raw` | `post_insert` | treedb_command_wal_relaxed | template-v1 | 0 | 100000 | 10,270,209 | 102.7 | - | - |
| `treedb_template_v1_raw` | `offline_compact` | treedb_command_wal_relaxed | template-v1 | 0 | 100000 | 10,269,956 | 102.7 | - | - |

## Reproduction Commands

Canonical entry point:

```bash
./scripts/bench_collections_canonical.sh
# or
make bench-collections-canonical
```

Exact command records from this run:

### build_helpers

make collection-load-fixture treemap-bin

### timed_matrix

go run ./cmd/collection_bench_matrix -out-dir /mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_2/timed_matrix -formats template-v1,bson,json -engine command_wal_relaxed -storage-cells index-vlog -tree-bench-pattern '^BenchmarkCollectionShapeInsertBatch$/^indexes_2$' -sqlite-bench-pattern '^(BenchmarkSQLiteShapeInsertBatchJSON|BenchmarkSQLiteShapeInsertBatchNativeColumns)$/^indexes_2$' -batch-size 16000 -benchtime 100000x -count 1 -leaf-segment-target-bytes 1048576 -leafgen-pack-frame-k 16 -profile-cells -profile-benchtime 100000x -profile-count 1

### offline_compact_matrix

BATCH=16000 COLLECTION_INDEXES='0 1 2' COMPACT_MODE=full DOCS=100000 PROFILE=command_wal_relaxed RUN_DIR=/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_2/offline_compact bash ./scripts/treedb_collection_compression_matrix.sh

### exhaustive_compact_matrix

BATCH=16000 COLLECTION_INDEXES='0 1 2' COMPACT_MODE=exhaustive DOCS=100000 PROFILE=command_wal_relaxed RUN_DIR=/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_2/exhaustive_compact bash ./scripts/treedb_collection_compression_matrix.sh

### full_leafgen_pack_gc_template_v1

/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report-src/bin/collection-load-fixture -json -dir /mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_2/full_leafgen_pack_gc/treedb_template_v1_collection_2_indexes -reset -docs 100000 -batch-size 16000 -format template-v1 -indexes 2 -profile command_wal_relaxed -progress=false -leaf-segment-target-bytes 1048576 -leafgen-pack-gc -leafgen-pack-force=true -leafgen-pack-max-generations 0 -leafgen-pack-frame-k 16 -index-vacuum offline

### full_leafgen_pack_gc_bson

/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report-src/bin/collection-load-fixture -json -dir /mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_2/full_leafgen_pack_gc/treedb_bson_collection_2_indexes -reset -docs 100000 -batch-size 16000 -format bson -indexes 2 -profile command_wal_relaxed -progress=false -leaf-segment-target-bytes 1048576 -leafgen-pack-gc -leafgen-pack-force=true -leafgen-pack-max-generations 0 -leafgen-pack-frame-k 16 -index-vacuum offline

### full_leafgen_pack_gc_json

/mnt/fast4tb/gomap-deep-journal.EElzpZMM/report-src/bin/collection-load-fixture -json -dir /mnt/fast4tb/gomap-deep-journal.EElzpZMM/report/collections_sqlite_canonical_1m/indexes_2/full_leafgen_pack_gc/treedb_json_collection_2_indexes -reset -docs 100000 -batch-size 16000 -format json -indexes 2 -profile command_wal_relaxed -progress=false -leaf-segment-target-bytes 1048576 -leafgen-pack-gc -leafgen-pack-force=true -leafgen-pack-max-generations 0 -leafgen-pack-frame-k 16 -index-vacuum offline

