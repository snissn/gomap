#!/usr/bin/env python3
"""Describe validated default stages and paired collection cells."""
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

lane = Path(sys.argv[1])
report = lane / "report"
evidence = lane / "evidence"
data = json.loads((evidence / "report-verified.json").read_text())
asset = "full_benchmark_report_2026-11-20"
index = (report / "RUNBOOK.md").read_text()
assert "- tier: pr" in index and "- indexes: 0 1 2" in index


def tsv(path):
    if not path.is_file():
        return []
    with path.open() as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def mongo_rows(prefix):
    return sum(len(tsv(p)) for p in sorted(report.glob(prefix + "/matrix.tsv")))


raw = sorted((report / "raw_engine_full_matrix").glob("*/benchprof_results.json"))
collections = sorted((report / "collections_sqlite_canonical_1m").glob("indexes_*/timed_matrix/matrix_index.tsv"))
collection_cells = sum(len(tsv(p)) for p in collections)
full = mongo_rows("mongo_gateway_full_sweep_1m_expanded")
modes = mongo_rows("mongo_client_mode_load_matrix_1m")
producer = mongo_rows("mongo_gateway_load_scaling_1m/producers_*")
scaling = mongo_rows("mongo_gateway_reader_writer_scaling_1m/indexes_*")
status = int((evidence / "deep.exit").read_text())
failed = [row for row in data["commands"] if row["code"]]
assert (status == 0) == (not failed)
if not failed:
    assert (len(raw), collection_cells, full, modes, producer, scaling) == (4, 12, 6, 27, 36, 72), (len(raw), collection_cells, full, modes, producer, scaling)

route = {}
for fmt in ("bson", "json"):
    run = report / "collections_sqlite_canonical_1m/indexes_0/timed_matrix"
    summaries = sorted(run.glob(f"treedb*_{fmt}_*/collections_report.json"))
    if not summaries:
        continue
    assert len(summaries) == 1
    result = json.loads(summaries[0].read_text())
    entry, = (r for s in result["sections"] for r in s["benchmarks"]
              if r["name"] == "BenchmarkCollectionShapeInsertBatch/indexes_0")
    m = entry["mean_metrics"]
    assert m["stored_docs"] == 100_000
    route[fmt] = [int(m[f"ordered_root_route_command_wal_publish_{field}_ops"])
                  for field in ("candidate", "used")]
    assert 0 < route[fmt][1] <= route[fmt][0]
if status == 0:
    assert set(route) == {"bson", "json"}

source = (evidence / "base").read_text().strip()
ready = len(data["commands"]) - len(failed)
start = (evidence / "report-host.txt").read_text().splitlines()[0].split("=", 1)[1]
end = (evidence / "deep.end").read_text().strip().split("=", 1)[1]
def utc_seconds(value):
    return datetime.fromisoformat(value.split(".")[0]).replace(tzinfo=timezone.utc)

elapsed = utc_seconds(end) - utc_seconds(start)
minutes, seconds = divmod(round(elapsed.total_seconds()), 60)
print(f"""# TreeDB canonical benchmark report, November 20, 2026

The default PR-tier `make deep-benchmark` ran on host185 against
[`{source[:9]}`](https://github.com/snissn/gomap/commit/{source}).
**{ready} of {len(data['commands'])} stages passed** in {minutes} min {seconds} s. The run used an Intel
i5-11400F (6 cores, 12 threads), Linux 6.8.0-138-generic, Go 1.26.3,
local NVMe ext4 on `/mnt/fast4tb`, and MongoDB 8.2.7 in local Docker.
Shared benchmark locks excluded other coordinated heavy jobs. Ordinary
host services remained active. No AWS infrastructure was used.

[Download the self-contained HTML report]({asset}/deep_report.html) ·
[Download the raw receipts]({asset}/receipts.tar.gz) ·
[SHA-256 checksums]({asset}/SHA256SUMS).

## Default report coverage

| Section | Retained coverage |
| --- | --- |
| Raw engine | {len(raw)} profiled WAL and between-test checkpoint combinations, 200,000 keys each |
| Canonical collections and SQLite | {collection_cells} timed matrix configurations across 0, 1 and 2 indexes, 100,000 documents each |
| Mongo API full sweep | {full} engine/configuration results, including load, reads, range reads, updates and concurrency sweeps |
| Mongo API client modes | {modes} engine/client/index results |
| Mongo API InsertMany producer scaling | {producer} engine/producer/index results, from 1 through 32 producers |
| Mongo API reader and writer scaling | {scaling} engine/direction/width/index results |

The canonical collection matrix used the maintained buffered legacy writer.
The Mongo API suite used the benchmark-only `bench_unsafe` profile with
the command WAL disabled and default full maintenance. `no_wal_fast`
also disables the command WAL and keeps read verification. See the
separate collection timing below for the native COW comparison and
[#5592](https://github.com/snissn/gomap/issues/5592) for journaled singleton YCSB.
[Mongo API benchmark profile details](../../cmd/mongo_gateway_bench/README.md).

""", end="")
if route.keys() == {"bson", "json"}:
    print(f"The zero-index BSON and JSON ingest results each verified 100,000 stored\n"
          f"documents and the expected ordered-root command-WAL producer route.\n"
          f"The timed counters were {route['bson'][1]} of {route['bson'][0]} candidate operations used for BSON\n"
          f"and {route['json'][1]} of {route['json'][0]} for JSON.\n")
if failed:
    for row in failed:
        print(f"- Exit {row['code']} after {row['elapsed_s']} s. `{row['argv']}`")
    print()
print("""## Native COW versus legacy collection inserts

Both arms used the canonical value-log configuration, `command_wal_relaxed`,
16,000 documents and 1,000 documents per batch. Each shape ran three
pairs with fresh processes and alternating arm order. Legacy includes
final buffered publication in the insert timer. Native uses public
`Collection.InsertBatch` and verified 16 COW publications for 16 batches.
The timed window excludes fixture generation, the final explicit checkpoint
and the 16,000-ID census. Checkpoint times below are separate.

| Format | Secondary indexes | Write owner | Median ns/doc | Median B/doc | Median allocs/doc | Median checkpoint (ms) |
| --- | ---: | --- | ---: | ---: | ---: | ---: |""")
rows = {(r["format"], r["indexes"], r["arm"]): r for r in data["cow_medians"]}
ratios = []
for fmt, n in (("bson", 0), ("json", 0), ("bson", 2)):
    for arm, label in (("legacy", "Legacy"), ("native", "Native COW")):
        row = rows[fmt, n, arm]
        print(f"| {fmt.upper()} | {n} | {label} | {row['ns_doc']:,.0f} | {row['bytes_doc']:,.0f} | "
              f"{row['allocs_doc']:g} | {row['checkpoint_ms']:.2f} |")
    ratios.append(rows[fmt, n, "native"]["ns_doc"] / rows[fmt, n, "legacy"]["ns_doc"])
print(f"""
Native COW took **{ratios[0]:.2f}×** legacy ns/doc for BSON with zero indexes,
**{ratios[1]:.2f}×** for JSON with zero indexes and **{ratios[2]:.2f}×** for BSON
with two indexes. The November 19 ratios were 1.33×, 1.41× and 2.12×.
These are separate host185 sessions with three samples per arm. The
matched native comparison keeps the 16,000-document fixture from the
earlier run. [November 19 collection report](cow_benchmark_2026-11-19.md#canonical-collection-inserts).

## Reproduce locally

From the pinned source with Go 1.26.3, a running local Docker engine
and fresh task-owned storage, use the default PR-tier target.

```sh
export GOWORK=off CGO_ENABLED=1 GOTOOLCHAIN=local GOENV=off
export TMPDIR="$BENCH_ROOT/tmp" GOTMPDIR="$BENCH_ROOT/tmp"
export GOCACHE="$BENCH_ROOT/gocache"
mkdir -p "$TMPDIR" "$GOCACHE"
export RUN_ROOT="$BENCH_ROOT/report"
export MONGO_IMAGE=mongo@sha256:7abfba0d07c9330373f8173981ea4d09cd8a82cdf0e86ccaf7008848d1d24f62
make deep-benchmark
```

The archive contains the expanded runbook, exact commands, profile
receipts, stage statuses, host samples and each interleaved COW sample.
The four full Go runtime traces are retained on host185.
The final HTML was rendered after all 20 stage statuses had been written.
The COW replay uses the maintained canonical benchmark pair and the
same environment for both owners. The recorded `run-cow.sh` shows the
environment and order. The report records this host and configuration.
""")
