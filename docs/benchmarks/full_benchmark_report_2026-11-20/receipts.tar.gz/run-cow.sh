#!/usr/bin/env bash
set -euo pipefail
lane=$(dirname "$(realpath "$0")")
source "$lane/go-report-env.sh"
cd "$lane/report-src"
out="$lane/cow"
mkdir "$out"
go test -c -o "$out/collections.test" ./TreeDB/collections > "$out/build.log" 2>&1
sha256sum "$out/collections.test" > "$out/binary.sha256"
export TREEDB_COLLECTION_BENCH_NATIVE_COW_COMPANION=true
export TREEDB_COLLECTION_BENCH_ENGINE=command_wal_relaxed
export TREEDB_COLLECTION_BENCH_BATCH_SIZE=1000
export TREEDB_COLLECTION_DATA_OUTER_LEAVES_IN_VLOG=true
export TREEDB_COLLECTION_INDEX_OUTER_LEAVES_IN_VLOG=true
export TREEDB_COLLECTION_REPORT_DISK_USAGE=true
export TREEDB_COLLECTION_REPORT_VLOG_REWRITE=false
export TREEDB_COLLECTION_REPORT_LEAFGEN_PACK_GC=false
export TREEDB_COLLECTION_REPORT_POST_MAINTENANCE_INDEX_VACUUM=false
export TREEDB_VLOG_GENERATION_LEAF_SEGMENT_TARGET_BYTES=1048576
export TREEDB_COLLECTION_LEAFGEN_PACK_FRAME_K=16
env | sort | rg '^TREEDB_' > "$out/env.txt"
printf '%s\n' 'go test -c -o "$out/collections.test" ./TreeDB/collections' > "$out/build.argv"
for shape in bson:0 json:0 bson:2; do
    format=${shape%:*}
    indices=${shape#*:}
    for step in 1:legacy 2:native 3:native 4:legacy 5:legacy 6:native; do
        arm=${step#*:}
        prefix="$out/$format-$indices-${step%:*}-$arm"
        benchmark=BenchmarkCollectionShapeInsertBatch
        if [[ "$arm" == native ]]; then
            benchmark+=NativeCOW
        fi
        argv=("$out/collections.test" '-test.run=^$' "-test.bench=^${benchmark}\$/^indexes_${indices}\$" '-test.benchmem' '-test.benchtime=16000x' '-test.count=1')
        printf '%q ' "TREEDB_COLLECTION_DOCUMENT_FORMAT=$format" "${argv[@]}" > "$prefix.argv"
        printf '\n' >> "$prefix.argv"
        date -u +%FT%T.%NZ > "$prefix.start"
        status=0
        TREEDB_COLLECTION_DOCUMENT_FORMAT="$format" "${argv[@]}" > "$prefix.log" 2>&1 || status=$?
        printf '%s\n' "$status" > "$prefix.exit"
        date -u +%FT%T.%NZ > "$prefix.end"
    done
done
date -u +end_utc=%FT%T.%NZ
