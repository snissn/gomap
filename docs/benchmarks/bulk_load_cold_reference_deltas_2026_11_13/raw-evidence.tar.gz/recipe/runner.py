#!/usr/bin/env python3
"""Pinned-source GoMap two-index load diagnosis; each slot owns a fresh DB."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import subprocess
import time

ROOT = Path(os.environ.get('GOMAP_BULK_OUT', str(Path(__file__).resolve().parents[1]))).resolve()
REPO = Path(os.environ.get('GOMAP_BULK_REPO', '/Users/michaelseiler/dev/snissn/gomap-bulk-load-speedup-20261112')).resolve()
GOROOT = '/Users/michaelseiler/.gvm/pkgsets/go1.25.5/global/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.10.darwin-arm64'
ENV = os.environ.copy()
ENV.update(GOROOT=GOROOT, GOTOOLCHAIN='local', GOWORK='off', CGO_ENABLED='1')
for key in list(ENV):
    if key in ('GOMAXPROCS', 'GOGC', 'GOMEMLIMIT', 'GODEBUG', 'GOFLAGS') or key.startswith('YCSB_'):
        ENV.pop(key, None)

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def command(case, stem, argv, timeout=300, extra_env=None):
    env = ENV.copy()
    env.update(extra_env or {})
    argv = [str(a) for a in argv]
    record = dict(argv=argv, cwd=str(REPO), started_utc=now(), extra_env=extra_env or {})
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    start = time.monotonic()
    with (case/(stem+'.out')).open('x') as out, (case/(stem+'.err')).open('x') as err:
        try:
            result = subprocess.run(argv, cwd=REPO, env=env, stdout=out, stderr=err, timeout=timeout)
            record['exit_code'] = result.returncode
        except BaseException as error:
            record['error'] = repr(error)
            raise
        finally:
            after = resource.getrusage(resource.RUSAGE_CHILDREN)
            record.update(ended_utc=now(), elapsed_seconds=time.monotonic()-start,
                          whole_process_user_cpu_s=after.ru_utime-before.ru_utime,
                          whole_process_system_cpu_s=after.ru_stime-before.ru_stime)
            save(case/(stem+'.command.json'), record)
    if result.returncode:
        raise RuntimeError(stem+' failed: '+(case/(stem+'.err')).read_text()[-4000:])
    return (case/(stem+'.out')).read_text()

def build():
    manifest = {}
    for name, source in [('mongo_gateway_bench','./cmd/mongo_gateway_bench'),
                         ('treedb-mongo-gateway','./TreeDB/mongo_gateway/server.go'),
                         ('census-final',str(ROOT/'recipe/census.go'))]:
        binary = ROOT/'bin'/name
        if binary.exists():
            raise FileExistsError(binary)
        command(ROOT/'setup', 'build-'+name, [GOROOT+'/bin/go','build','-o',binary,source], timeout=600)
        info = command(ROOT/'setup', 'build-info-'+name, [GOROOT+'/bin/go','version','-m',binary])
        manifest[name] = dict(sha256=sha(binary), build_info=info)
        print('BUILT '+name, flush=True)
    save(ROOT/'setup/binaries.json', manifest)

def validate(case, data, count=100000):
    argv = [str(ROOT/'bin/treedb-mongo-gateway-final'), '-addr','127.0.0.1:0','-dir',str(data),
            '-profile','command_wal_relaxed','-document-format','bson',
            '-max-find-scan-documents','500000','-max-cursor-retained-bytes','536870912']
    out = (case/'reopened.out').open('x')
    err = (case/'reopened.err').open('x')
    process = subprocess.Popen(argv,cwd=REPO,env=ENV,stdout=out,stderr=err,start_new_session=True)
    save(case/'reopened.launch.json',dict(argv=argv,pid=process.pid,started_utc=now()))
    try:
        uri = None
        for _ in range(600):
            m = re.search(r'listening on (mongodb://[^\s]+)', (case/'reopened.out').read_text())
            if m:
                uri = m[1]
                break
            if process.poll() is not None:
                raise RuntimeError('reopen failed: '+(case/'reopened.err').read_text())
            time.sleep(.1)
        if uri is None:
            raise RuntimeError('reopen readiness deadline')
        raw = command(case,'reopened-census',[ROOT/'bin/census-final','-uri',uri,
                      '-database','readme5407','-collection','bench','-documents',str(count),
                      '-shape','gateway','-secondary-indexes','2','-range-index=true'])
        census = json.loads(raw)
        assert census['success'] and census['observed_count'] == count
        assert census['index_status'] == 'declared_index_metadata_validated'
        assert len(census['queries']) == 8 and all(q['success'] and q['observed_count'] == q['expected_count'] for q in census['queries'])
        assert census['checked_calls'] and all(c['success'] for c in census['checked_calls'])
        return census
    finally:
        if process.poll() is None:
            process.send_signal(signal.SIGTERM)
        try:
            code = process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            raise
        finally:
            out.close()
            err.close()
        save(case/'reopened.stop.json',dict(exit_code=code,graceful=(code == 0),ended_utc=now()))
        assert code == 0

def run_slot(name, kind, producers=16, binary='mongo_gateway_bench', extra_env=None, reads=0, range_reads=0):
    case = ROOT/'runs'/name
    case.mkdir()
    data = case/'db'
    argv = [ROOT/'bin'/binary,'-target','treedb','-database','readme5407','-collection','bench',
            '-documents','100000','-batch-size','1000','-insert-producers',str(producers),
            '-prebuild-documents','-document-shape','gateway','-point-read-projection','full',
            '-client-mode','driver-command-raw','-secondary-indexes','2',
            '-mongo-max-pool-size','16','-mongo-min-pool-size','0','-mongo-max-connecting','16',
            '-timeout','20m','-format','json','-deletes','0','-concurrent-read-kinds','id',
            '-range-index','-reads',str(reads),'-range-reads',str(range_reads),'-updates','0',
            '-treedb-dir',data,'-keep-treedb-dir','-treedb-profile','command_wal_relaxed',
            '-treedb-document-format','bson','-treedb-read-state','settled',
            '-treedb-maintenance','checkpoint','-treedb-data-root-storage','compressed',
            '-treedb-index-state-root-storage','compressed','-treedb-index-root-storage','compressed']
    if kind != 'baseline':
        argv += ['-profile-dir',case/'profiles','-profile-block-rate','1' if kind == 'block' else '0',
                 '-profile-mutex-fraction','1' if kind == 'mutex' else '0']
        if kind == 'trace':
            argv += ['-profile-trace']
    save(case/'attempt.json',dict(name=name,kind=kind,producers=producers,started_utc=now(),
                                binary_sha256=sha(ROOT/'bin'/binary)))
    try:
        result = json.loads(command(case,'benchmark',['/usr/bin/time','-l',*argv],timeout=1260,extra_env=extra_env))
        save(case/'storage-snapshots.json', {k:result[k] for k in ('treedb_disk_after_load','treedb_disk_after_checkpoint')})
        assert all(result[k] for k in ('treedb_disk_after_load','treedb_disk_after_checkpoint'))
        phase = next(p for p in result['phases'] if p['name']=='load_insert_many')
        assert phase['operations']==100000 and phase['driver_calls']==100
        assert result['secondary_indexes']==2 and result['range_index'] is True
        if reads:
            assert any(p['operations'] == reads and p['name'] == 'id_find_one' for p in result['phases'])
        if range_reads:
            assert any(p['operations'] == range_reads and p['name'] == 'age_range_indexed_limit_10' for p in result['phases'])
        census = validate(case,data)
        identity = data.stat()
        assert data.parent==case and not data.is_symlink()
        shutil.rmtree(data)
        save(case/'data-release.json',dict(path=str(data),inode=identity.st_ino,removed=not data.exists(),
                                         reason='full reopened census and graceful reopened Close passed'))
        save(case/'result.json',dict(state='valid',kind=kind,phase=phase,census=census,ended_utc=now(),
                                    original_macro_close_return_observed=False))
        metrics = phase.get('treedb_metrics',{})
        print(name+' VALID '+str(round(phase['ops_per_sec'],1))+' docs/s '+str({k:metrics[k] for k in ('foreground_duration_ms','settled_drain_duration_ms','roots/publish') if k in metrics}),flush=True)
    except BaseException as error:
        save(case/'failure.json',dict(state='invalid',error=repr(error),ended_utc=now()))
        raise

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['build','initial','slot'])
    parser.add_argument('--name')
    parser.add_argument('--kind',default='baseline')
    parser.add_argument('--producers',type=int,default=16)
    parser.add_argument('--binary',default='mongo_gateway_bench')
    parser.add_argument('--reads',type=int,default=0)
    parser.add_argument('--range-reads',type=int,default=0)
    args=parser.parse_args()
    if args.action=='build': build()
    elif args.action=='initial':
        keep_awake=subprocess.Popen(['caffeinate','-i'])
        try:
            for name,kind in [('baseline-1','baseline'),('baseline-2','baseline'),('baseline-3','baseline'),
                              ('cpu-1','cpu'),('cpu-2','cpu'),('cpu-3','cpu'),('mutex-1','mutex'),('block-1','block')]:
                run_slot(name,kind)
        finally:
            keep_awake.terminate()
            keep_awake.wait()
    else: run_slot(args.name,args.kind,args.producers,args.binary,reads=args.reads,range_reads=args.range_reads)
