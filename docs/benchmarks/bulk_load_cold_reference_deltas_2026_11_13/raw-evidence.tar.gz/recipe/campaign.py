#!/usr/bin/env python3
"""Execute the frozen alternating campaign; retain every planned observation."""
import json
import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import runner as r

plan = json.loads((r.ROOT/'analysis/final-frozen-plan.json').read_text())
manifest = json.loads((r.ROOT/'setup/final-build-manifest.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r.REPO).decode().strip() == plan['candidate']
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=r.REPO).decode().strip()
for source, expected in plan['recipes'].items():
    assert r.sha(r.ROOT/'recipe'/source) == expected, source
for name, expected in manifest['products'].items():
    assert r.sha(r.ROOT/'bin'/name) == expected['sha256'], name
gates = json.loads((r.ROOT/'setup/timing-window.json').read_text())
assert gates['owned_builds_tests_running'] is False
r.save(r.ROOT/'analysis/campaign-start.json', dict(started_utc=r.now(),load_average=os.getloadavg(),
       campaign_sha256=r.sha(Path(__file__)),frozen_plan_sha256=r.sha(r.ROOT/'analysis/final-frozen-plan.json')))
awake = subprocess.Popen(['caffeinate','-i'])
try:
    for pair, order in enumerate(plan['order'], 1):
        for binary in order:
            variant = binary.removesuffix('-final')
            r.run_slot(f'final-load-p{pair}-{variant}', 'baseline', binary=binary)
    for pair, order in enumerate([['before-final','candidate-final'],['candidate-final','before-final']],1):
        for binary in order:
            variant = binary.removesuffix('-final')
            r.run_slot(f'final-cpu-p{pair}-{variant}', 'cpu', binary=binary)
    for pair, order in enumerate(plan['order'][:3],1):
        for binary in order:
            variant = binary.removesuffix('-final')
            r.run_slot(f'final-read-p{pair}-{variant}', 'baseline', binary=binary, reads=10000, range_reads=1000)
    for pair, order in enumerate(plan['order'][:3],1):
        for binary in order:
            variant = binary.removesuffix('-final')
            case = r.ROOT/'runs'/f'final-warm-p{pair}-{variant}'
            case.mkdir()
            r.command(case,'benchmark',[r.ROOT/'bin'/f'warm-{variant}-final.test','-test.run=^$',
                '-test.bench=^BenchmarkStandalonePublicIndexedUpdate/command_wal_relaxed/',
                '-test.benchtime=1000x','-test.count=1','-test.benchmem'],timeout=300)
            r.save(case/'result.json',dict(state='valid',ended_utc=r.now(),boundary='request-to-ACK; fixture and checked Close outside timer'))
            print(case.name+' VALID',flush=True)
    r.save(r.ROOT/'analysis/campaign-end.json',dict(ended_utc=r.now(),load_average=os.getloadavg(),state='complete'))
finally:
    awake.terminate()
    awake.wait()
