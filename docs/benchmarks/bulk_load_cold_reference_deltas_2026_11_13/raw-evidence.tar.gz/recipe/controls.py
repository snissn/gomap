#!/usr/bin/env python3
"""Bounded allocation and longer warm guardrails; retain the original short guard."""
import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runner as r

manifest=json.loads((r.ROOT/'setup/control-build-manifest.json').read_text())
for name,record in manifest['products'].items():
    assert r.sha(r.ROOT/'bin'/name)==record['sha256'],name
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=r.REPO).decode().strip()
assert json.loads((r.ROOT/'setup/control-timing-window.json').read_text())['owned_builds_tests_running'] is False
awake=subprocess.Popen(['caffeinate','-i'])
try:
    for pair,order in enumerate([['before','candidate'],['candidate','before'],['before','candidate']],1):
        for variant in order:
            name=f'control-allocation-p{pair}-{variant}'
            r.run_slot(name,'baseline',binary='allocation-'+variant)
            result=json.loads((r.ROOT/'runs'/name/'benchmark.out').read_text())
            metrics=result['phases'][0]['treedb_metrics']
            assert metrics['diagnostic_total_alloc_bytes']>0 and metrics['diagnostic_mallocs']>0
    for pair,order in enumerate([['before','candidate'],['candidate','before'],['before','candidate'],['candidate','before'],['before','candidate']],1):
        for variant in order:
            case=r.ROOT/'runs'/f'control-warm-long-p{pair}-{variant}'
            case.mkdir()
            r.command(case,'benchmark',[r.ROOT/'bin'/f'warm-long-{variant}.test','-test.run=^$',
              '-test.bench=^BenchmarkStandalonePublicIndexedUpdate/command_wal_relaxed/',
              '-test.benchtime=10000x','-test.count=1','-test.benchmem'],timeout=300)
            r.save(case/'result.json',dict(state='valid',boundary='10000 operations request-to-ACK; counters and checked Close outside timed interval'))
            print(case.name+' VALID',flush=True)
    r.save(r.ROOT/'analysis/controls-end.json',dict(ended_utc=r.now(),state='complete'))
finally:
    awake.terminate()
    awake.wait()
