#!/usr/bin/env python3
"""Build frozen, uninstrumented products and a stricter untimed validator."""
import json
import platform
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import runner as r

BASE = '2590d1e9e443c3f968303ce91b3c82933a714f12'
CANDIDATE = '45b33e8e202340a6543ba7ca563668fa711ed151'
SOURCE = 'TreeDB/db/ordered_root_publish.go'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=r.REPO).decode().strip()

assert git('rev-parse', 'HEAD') == CANDIDATE
assert not git('status', '--porcelain=v1')
changed = git('diff', '--name-only', BASE, CANDIDATE).splitlines()
runtime = [p for p in changed if p.endswith('.go') and not p.endswith('_test.go')]
assert runtime == [SOURCE], runtime
base_source = r.ROOT/'setup/base-ordered_root_publish.go'
with base_source.open('xb') as out:
    out.write(subprocess.check_output(['git', 'show', BASE+':'+SOURCE], cwd=r.REPO))
overlay = r.ROOT/'setup/baseline-overlay.json'
r.save(overlay, {'Replace': {str(r.REPO/SOURCE): str(base_source)}})

manifest = dict(base=BASE, candidate=CANDIDATE, candidate_tree=git('rev-parse', 'HEAD^{tree}'),
    runtime_changed=runtime, baseline_overlay_sha256=r.sha(overlay),
    baseline_source_sha256=r.sha(base_source), candidate_source_sha256=r.sha(r.REPO/SOURCE),
    recipes={p: r.sha(r.ROOT/'recipe'/p) for p in ['runner.py', 'census.go', 'build_final.py']},
    hardware=dict(platform=platform.platform()), products={})
for key, argv in {
    'hardware_model': ['sysctl', '-n', 'hw.model'],
    'cpu': ['sysctl', '-n', 'machdep.cpu.brand_string'],
    'memory_bytes': ['sysctl', '-n', 'hw.memsize'],
    'logical_cpus': ['sysctl', '-n', 'hw.ncpu'],
    'os': ['sw_vers'],
    'go': [r.GOROOT+'/bin/go', 'version'],
}.items():
    manifest['hardware'][key] = subprocess.check_output(argv, env=r.ENV).decode().strip()

products = [
    ('before-final', './cmd/mongo_gateway_bench', True, False),
    ('candidate-final', './cmd/mongo_gateway_bench', False, False),
    ('treedb-mongo-gateway-final', './TreeDB/mongo_gateway/server.go', True, False),
    ('census-final', str(r.ROOT/'recipe/census.go'), False, False),
    ('warm-before-final.test', './cmd/mongo_gateway_bench', True, True),
    ('warm-candidate-final.test', './cmd/mongo_gateway_bench', False, True),
]
for name, source, before, test in products:
    binary = r.ROOT/'bin'/name
    assert not binary.exists(), binary
    argv = [r.GOROOT+'/bin/go', 'test' if test else 'build']
    if test:
        argv += ['-c']
    if before:
        argv += ['-overlay', str(overlay)]
    argv += ['-o', str(binary), source]
    r.command(r.ROOT/'setup', 'build-'+name, argv, timeout=600)
    info = r.command(r.ROOT/'setup', 'build-info-'+name, [r.GOROOT+'/bin/go', 'version', '-m', binary])
    manifest['products'][name] = dict(sha256=r.sha(binary), source=source,
                                    baseline_overlay=before, build_info=info)
    print('BUILT '+name, flush=True)

selftest = json.loads(r.command(r.ROOT/'setup', 'census-final-selftest', [r.ROOT/'bin/census-final', '-self-test']))
assert selftest['success'] and selftest['self_test_controls'] >= 10, selftest
manifest['census_selftest'] = selftest
manifest['policies'] = {p: git('rev-parse', CANDIDATE+':'+p) for p in ['AGENTS.md', 'TreeDB/AGENTS.md', 'CONTRIBUTING.md']}
r.save(r.ROOT/'setup/final-build-manifest.json', manifest)
plan = json.loads((r.ROOT/'analysis/final-plan.json').read_text())
plan['candidate'] = CANDIDATE
plan['freeze_utc'] = r.now()
plan['build_manifest_sha256'] = r.sha(r.ROOT/'setup/final-build-manifest.json')
plan['recipes'] = manifest['recipes']
r.save(r.ROOT/'analysis/final-frozen-plan.json', plan)
print('FROZEN '+CANDIDATE, flush=True)
