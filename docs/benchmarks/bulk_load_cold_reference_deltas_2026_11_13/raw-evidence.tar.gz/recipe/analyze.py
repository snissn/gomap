#!/usr/bin/env python3
"""Summarize all frozen observations without excluding outliers."""
import json
from pathlib import Path
import re
import statistics as stats
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import runner as r

def median(values):
    return stats.median(values)

def change(before, after):
    return (after/before-1)*100

def load(path):
    return json.loads(path.read_text())

rows, warm = [], []
for case in sorted((r.ROOT/'runs').glob('final-*')):
    receipt = load(case/'result.json')
    assert receipt['state'] == 'valid'
    variant = case.name.rsplit('-',1)[1]
    pair = int(re.search(r'-p(\d+)-',case.name)[1])
    if '-warm-' in case.name:
        for match in re.finditer(r'^BenchmarkStandalonePublicIndexedUpdate/command_wal_relaxed/writers=(\d+)-\d+\s+(\d+)\s+([\d.]+) ns/op\s+([\d.]+) ACK/s\s+(\d+) B/op\s+(\d+) allocs/op', (case/'benchmark.out').read_text(), re.M):
            writers, n, ns, ack, b, a = match.groups()
            warm.append(dict(case=case.name,variant=variant,pair=pair,writers=int(writers),n=int(n),
                             ns_per_op=float(ns),ack_per_s=float(ack),bytes_per_op=int(b),allocs_per_op=int(a)))
        continue
    result = load(case/'benchmark.out')
    phase = next(p for p in result['phases'] if p['name']=='load_insert_many')
    delta, metrics = phase['treedb_stats_delta'], phase['treedb_metrics']
    row = dict(case=case.name,variant=variant,pair=pair,kind=receipt['kind'],
               total_ms=phase['duration_ms'],docs_per_s=phase['ops_per_sec'],
               foreground_ms=metrics['foreground_duration_ms'],drain_ms=metrics['settled_drain_duration_ms'],
               finalize_ms=int(delta['treedb.publish.ordered_root_delta_group.finalize_ns_total'])/1e6,
               finalize_calls=int(delta['treedb.publish.ordered_root_delta_group.finalize_calls_total']),
               crc_checks=int(delta['treedb.vlog.read.crc32_checks_total']),
               readat=int(delta['treedb.vlog.mmap_read.fallback_readat']),
               roots=metrics['roots/publish'],
               rss_bytes=int(re.search(r'(\d+)\s+maximum resident set size',(case/'benchmark.err').read_text())[1]),
               digest=receipt['census']['canonical_typed_state_sha256'],
               census_documents=receipt['census']['observed_count'],
               queries=len(receipt['census']['queries']),
               original_macro_close_checked=False)
    row['reads'] = {p['name']: {k:p[k] for k in ['operations','duration_ms','ops_per_sec','latency_micros']}
                    for p in result['phases'] if p['operations'] and p['name'] != 'load_insert_many'}
    row['storage'] = {}
    for boundary in ['treedb_disk_after_load','treedb_disk_after_checkpoint']:
        snapshot = result[boundary]
        paths = snapshot['paths']
        row['storage'][boundary] = dict(total_logical_bytes=snapshot['total_bytes'],
            wal_logical_bytes=paths.get('maindb/wal',0)+paths.get('dictdb/wal',0),
            wal_excluded_logical_bytes=snapshot['total_bytes']-paths.get('maindb/wal',0)-paths.get('dictdb/wal',0),
            leaf_vlog_logical_bytes=paths.get('maindb/leaf_vlog',0),
            index_logical_bytes=paths.get('maindb/index.db',0))
    rows.append(row)

assert len(rows)==20 and len(warm)==12
assert len({v['digest'] for v in rows})==1
assert all(v['census_documents']==100000 and v['queries']==8 and v['roots']==4 for v in rows)
primary = [row for row in rows if row['case'].startswith('final-load-')]
assert len(primary)==10
medians = {variant:{key:median([row[key] for row in primary if row['variant']==variant])
                   for key in ['total_ms','docs_per_s','foreground_ms','drain_ms','finalize_ms','rss_bytes']}
           for variant in ['before','candidate']}
paired = []
for pair in range(1,6):
    before = next(row for row in primary if row['pair']==pair and row['variant']=='before')
    after = next(row for row in primary if row['pair']==pair and row['variant']=='candidate')
    paired.append(dict(pair=pair,throughput_change_pct=change(before['docs_per_s'],after['docs_per_s']),
                       drain_reduction_pct=-change(before['drain_ms'],after['drain_ms']),
                       total_time_change_pct=change(before['total_ms'],after['total_ms'])))

read_summary = {}
for name in ['id_find_one','email_find_one','age_range_indexed_limit_10']:
    read_summary[name] = {}
    for variant in ['before','candidate']:
        samples=[row['reads'][name] for row in rows if row['case'].startswith('final-read-') and row['variant']==variant]
        read_summary[name][variant] = dict(median_ops_per_s=median([x['ops_per_sec'] for x in samples]),
                                          median_p95_us=median([x['latency_micros']['p95'] for x in samples]),
                                          median_p99_us=median([x['latency_micros']['p99'] for x in samples]))
    read_summary[name]['throughput_change_pct']=change(read_summary[name]['before']['median_ops_per_s'],read_summary[name]['candidate']['median_ops_per_s'])

warm_summary = {str(writers): {variant: {key:median([row[key] for row in warm if row['writers']==writers and row['variant']==variant])
                    for key in ['ns_per_op','ack_per_s','bytes_per_op','allocs_per_op']}
               for variant in ['before','candidate']} for writers in [1,8]}
for group in warm_summary.values():
    group['ns_per_op_change_pct']=change(group['before']['ns_per_op'],group['candidate']['ns_per_op'])
    group['bytes_per_op_change_pct']=change(group['before']['bytes_per_op'],group['candidate']['bytes_per_op'])

storage = {boundary: {variant:{key:median([row['storage'][boundary][key] for row in primary if row['variant']==variant])
                              for key in primary[0]['storage'][boundary]}
                     for variant in ['before','candidate']} for boundary in primary[0]['storage']}

summary = dict(source_candidate=load(r.ROOT/'analysis/final-frozen-plan.json')['candidate'],
    observations=rows,warm_observations=warm,load_medians=medians,load_paired_changes=paired,
    load_throughput_median_gain_pct=change(medians['before']['docs_per_s'],medians['candidate']['docs_per_s']),
    load_drain_median_reduction_pct=-change(medians['before']['drain_ms'],medians['candidate']['drain_ms']),
    rss_median_change_pct=change(medians['before']['rss_bytes'],medians['candidate']['rss_bytes']),
    read_summary=read_summary,warm_summary=warm_summary,storage_medians=storage,
    gate=dict(threshold='at least 15 percent median throughput gain OR drain reduction, every paired direction positive for qualifying metric',
              settled_drain_pass=all(x['drain_reduction_pct']>0 for x in paired) and -change(medians['before']['drain_ms'],medians['candidate']['drain_ms'])>=15,
              throughput_every_pair_positive=all(x['throughput_change_pct']>0 for x in paired),
              no_samples_excluded=True),
    limitations=['shared local Mac; no exclusive dedicated runner','phase total includes settled drain, excludes checkpoint; relaxed ACK foreground is a separate boundary',
                 'original macro Close return unobserved; standalone reopen/validation Close checked; separate direct original Close/reopen regression checked',
                 'unhinted query results and declared index metadata do not prove physical index activation',
                 'CPU and allocation profiles collected separately; allocation snapshots include setup/prebuild and sampling/GC lag',
                 'logical storage length is not allocated physical bytes'])
r.save(r.ROOT/'analysis/final-results.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k not in ['observations','warm_observations']},indent=2))
