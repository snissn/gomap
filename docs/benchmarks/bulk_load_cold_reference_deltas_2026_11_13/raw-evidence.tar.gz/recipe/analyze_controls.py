#!/usr/bin/env python3
"""Retain every follow-up sample and compare separately from the primary run."""
import json
from pathlib import Path
import re
import statistics
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runner as r

def pct(a,b):return (b/a-1)*100
alloc=[]
warm=[]
for case in sorted((r.ROOT/'runs').glob('control-*')):
    variant=case.name.rsplit('-',1)[1]
    pair=int(re.search(r'-p(\d+)-',case.name)[1])
    assert json.loads((case/'result.json').read_text())['state']=='valid'
    if 'allocation' in case.name:
        result=json.loads((case/'benchmark.out').read_text())
        phase=next(p for p in result['phases'] if p['name']=='load_insert_many')
        metrics=phase['treedb_metrics']
        alloc.append(dict(case=case.name,variant=variant,pair=pair,
            bytes=int(metrics['diagnostic_total_alloc_bytes']),objects=int(metrics['diagnostic_mallocs']),
            bytes_per_doc=metrics['diagnostic_total_alloc_bytes']/100000,
            allocs_per_doc=metrics['diagnostic_mallocs']/100000,
            digest=json.loads((case/'result.json').read_text())['census']['canonical_typed_state_sha256']))
        continue
    out=(case/'benchmark.out').read_text()
    for match in re.finditer(r'^BenchmarkStandalonePublicIndexedUpdate/command_wal_relaxed/writers=(\d+)-\d+\s+(\d+)\s+([\d.]+) ns/op\s+([\d.]+) ACK/s\s+(\d+) B/op\s+(\d+) allocs/op',out,re.M):
        w,n,ns,ack,b,a=match.groups()
        warm.append(dict(case=case.name,variant=variant,pair=pair,writers=int(w),n=int(n),
                         ns_per_op=float(ns),ack_per_s=float(ack),bytes_per_op=int(b),allocs_per_op=int(a)))
    counters={key:[int(n) for n in re.findall(r'timed '+re.escape(key)+r'=(\d+)',out)] for key in
              ['treedb.publish.ordered_root_delta_group.calls_total','treedb.publish.ordered_root_delta_group.finalize_calls_total']}
    # Go's non-verbose bench output truncates each BENCH log at ten lines.
    # The actual 10000-operation grouped-call counter is visible for both
    # writers. Only the one-operation calibration finalize counter is printed.
    assert len(counters['treedb.publish.ordered_root_delta_group.calls_total'])==4,counters
    assert len(counters['treedb.publish.ordered_root_delta_group.finalize_calls_total'])==2,counters
    for row in warm:
        if row['case']==case.name:row['grouped_counter_observations']=counters
assert len(alloc)==6 and len(warm)==20
med=statistics.median
alloc_summary={variant:{key:med([row[key] for row in alloc if row['variant']==variant]) for key in ['bytes','objects','bytes_per_doc','allocs_per_doc']} for variant in ['before','candidate']}
alloc_summary['bytes_change_pct']=pct(alloc_summary['before']['bytes'],alloc_summary['candidate']['bytes'])
alloc_summary['objects_change_pct']=pct(alloc_summary['before']['objects'],alloc_summary['candidate']['objects'])
warm_summary={str(w):{variant:{key:med([row[key] for row in warm if row['writers']==w and row['variant']==variant]) for key in ['ns_per_op','ack_per_s','bytes_per_op','allocs_per_op']} for variant in ['before','candidate']} for w in [1,8]}
for group in warm_summary.values():
    group['ns_per_op_change_pct']=pct(group['before']['ns_per_op'],group['candidate']['ns_per_op'])
    group['long_guard_pass']=group['ns_per_op_change_pct']<=5
report=dict(allocation_observations=alloc,warm_observations=warm,allocation_summary=alloc_summary,warm_summary=warm_summary,
            all_observed_grouped_call_counters_zero=all(all(v==0 for v in row['grouped_counter_observations']['treedb.publish.ordered_root_delta_group.calls_total']) for row in warm),
            finalize_counter_limit='Go BENCH log truncation hides the actual 10000-operation finalize counter; only calibration finalize counters are retained. Completed grouped-call counters are visible for every actual sample.',
            boundaries=dict(allocation='Process-wide TotalAlloc/Mallocs delta around foreground plus settled drain; excludes prebuild/checkpoint/post-phase Stats, includes concurrent background allocations',
                            warm='Request-to-ACK of 10000 real indexed updates, separately for1 and8 writers; excludes fixture and checked Close; counter loop after StopTimer',
                            grouped_counters='Aggregate completed grouped publications in bracket, not exact-route activation; no statement about later Close/checkpoint work'),
            prior_short_guard_retained=True,no_samples_excluded=True)
r.save(r.ROOT/'analysis/control-results.json',report)
print(json.dumps({k:v for k,v in report.items() if k not in ['allocation_observations','warm_observations']},indent=2))
