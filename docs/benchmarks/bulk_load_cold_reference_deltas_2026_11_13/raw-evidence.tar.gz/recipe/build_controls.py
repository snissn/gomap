#!/usr/bin/env python3
"""Observation-only overlays; production runtime and primary observations stay fixed."""
import json
from pathlib import Path
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runner as r

candidate = '45b33e8e202340a6543ba7ca563668fa711ed151'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r.REPO).decode().strip()==candidate
mainpath = 'cmd/mongo_gateway_bench/main.go'
main = (r.REPO/mainpath).read_text()
start = main.index('func runTreeDBProfiledPhaseWithDrain(')
end = main.index('\nfunc drainTreeDBCollectionsForPhase(',start)
body = main[start:end]
assert body.count('before := collectLiveTreeDBStats(target)')==1
body = body.replace('before := collectLiveTreeDBStats(target)',
    'before := collectLiveTreeDBStats(target)\n\tvar diagnosticBefore, diagnosticAfter runtime.MemStats\n\truntime.ReadMemStats(&diagnosticBefore)',1)
assert body.count('\n\tif err != nil {')==1
body = body.replace('\n\tif err != nil {','\n\truntime.ReadMemStats(&diagnosticAfter)\n\tif err != nil {',1)
body = body.replace('\n\treturn result, nil\n}',
    '\n\taddTreeDBPhaseMetric(&result, "diagnostic_total_alloc_bytes", float64(diagnosticAfter.TotalAlloc-diagnosticBefore.TotalAlloc))\n'
    '\taddTreeDBPhaseMetric(&result, "diagnostic_mallocs", float64(diagnosticAfter.Mallocs-diagnosticBefore.Mallocs))\n\treturn result, nil\n}',1)
main_overlay = r.ROOT/'setup/alloc-main.go'
with main_overlay.open('x') as f:f.write(main[:start]+body+main[end:])

warmpath = 'cmd/mongo_gateway_bench/standalone_public_bench_test.go'
warm = (r.REPO/warmpath).read_text()
old = '[]string{"treedb.command_wal.file_sync.calls_total", "treedb.command_wal.sync.count_total"}'
assert warm.count(old)==1
warm = warm.replace(old,'[]string{"treedb.command_wal.file_sync.calls_total", "treedb.command_wal.sync.count_total", "treedb.publish.ordered_root_delta_group.calls_total", "treedb.publish.ordered_root_delta_group.finalize_calls_total"}')
warm_overlay=r.ROOT/'setup/warm-diagnostic_test.go'
with warm_overlay.open('x') as f:f.write(warm)

manifest=dict(candidate=candidate,observations_only=True,primary_campaign_unchanged=True,
              harnesses={mainpath:r.sha(main_overlay),warmpath:r.sha(warm_overlay)},products={})
base_overlay = json.loads((r.ROOT/'setup/baseline-overlay.json').read_text())
for kind,source,changed,test in [('allocation','./cmd/mongo_gateway_bench',(mainpath,main_overlay),False),
                                ('warm-long','./cmd/mongo_gateway_bench',(warmpath,warm_overlay),True)]:
    for variant in ['before','candidate']:
        replacements = dict(base_overlay['Replace']) if variant=='before' else {}
        replacements[str(r.REPO/changed[0])]=str(changed[1])
        overlay=r.ROOT/'setup'/f'{kind}-{variant}-overlay.json'
        r.save(overlay,{'Replace':replacements})
        name=f'{kind}-{variant}'+('.test' if test else '')
        binary=r.ROOT/'bin'/name
        assert not binary.exists()
        argv=[r.GOROOT+'/bin/go','test' if test else 'build']
        if test:argv+=['-c']
        argv+=['-overlay',overlay,'-o',binary,source]
        r.command(r.ROOT/'setup','build-'+name,argv,timeout=600)
        manifest['products'][name]=dict(sha256=r.sha(binary),overlay_sha256=r.sha(overlay))
        print('BUILT '+name,flush=True)
r.save(r.ROOT/'setup/control-build-manifest.json',manifest)
