#!/usr/bin/python3
"""Read-only projection of the maintained twelve-arm packet; never launches a product.

The maintained lifecycle validators remain authoritative. This assembler checks their
accepted receipts, phase receipts/logs, resource terminal results and retained hashes.
It does not rerun the lifecycle protocol or turn observed random state into a proof.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import pathlib
import re
import statistics
import sys


def read(p):
    return json.loads(pathlib.Path(p).read_text())


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(p):
    h = hashlib.sha256()
    with pathlib.Path(p).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write(p, value):
    with pathlib.Path(p).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')


def file_record(p):
    p = pathlib.Path(p)
    return dict(path=str(p.resolve()), bytes=p.stat().st_size, sha256=digest(p))


def comparison_order():
    return [dict(class_name=cls, pair=pair, arm=arm, name=f'{cls}-pair{pair}-{arm}')
            for cls in ('relaxed', 'durable-B')
            for pair, arm in ((1, 'mongodb'), (1, 'gomap'), (2, 'gomap'), (2, 'mongodb'), (3, 'mongodb'), (3, 'gomap'))]


def packet_plan(root, prior_root=None):
    """Explicit two-prior/ten-continuation selection; never copies or promotes cells."""
    root = pathlib.Path(root).resolve()
    campaign, expected = read(root / 'campaign.json'), comparison_order()
    if prior_root is None:
        require(not (root / 'PRIOR-PACKET.json').exists(), 'continuation requires explicit --prior-packet')
        require(campaign['order'] == expected, 'declared matrix/order differs from fixed twelve arms')
        return dict(campaign=campaign, packets=[root], cells=[(root / 'cells' / r['name'], r) for r in expected], prior=None)
    prior_root = pathlib.Path(prior_root).resolve()
    require(prior_root != root, 'prior packet must be a separate original packet')
    prior_path = root / 'PRIOR-PACKET.json'
    prior, old = read(prior_path), read(prior_root / 'campaign.json')
    require(prior['prior_root'] == str(prior_root), 'prior root differs from explicit argument')
    require(old['order'] == expected and campaign['order'] == expected[2:], 'prior/continuation order differs')
    require(prior['adopted_valid_cells'] == expected[:2] and prior['remaining_order'] == expected[2:]
            and prior['rejected_preserved'] == expected[2], 'prior sample/rejected selection differs')
    authority_paths = [prior_root / n for n in ('campaign.json', 'SEALED.json', 'campaign-start.json', 'STOPPED.json')]
    authority_paths += [prior_root / 'cells' / r['name'] / 'COMPLETE.json' for r in expected[:2]]
    authority_paths += [prior_root / 'cells' / expected[2]['name'] / 'launcher/terminal.json']
    require(set(prior['authorities']) == {str(p) for p in authority_paths}, 'prior authority set differs')
    for path, sha in prior['authorities'].items():
        require(digest(path) == sha, 'prior authority changed: ' + path)
    require(campaign['bindings'].get(str(prior_path)) == digest(prior_path), 'prior disposition is not campaign-bound')
    require({k: v for k, v in old.items() if k not in ('order', 'bindings')} ==
            {k: v for k, v in campaign.items() if k not in ('order', 'bindings')}, 'continuation source/config/workload/budget differs')
    start, old_start = read(root / 'campaign-start.json'), read(prior_root / 'campaign-start.json')
    require(start.get('continuation') is True and start.get('original_start_path') == str(prior_root / 'campaign-start.json'), 'continuation origin authority missing')
    require({k: v for k, v in start.items() if k not in ('continuation', 'original_start_path')} == old_start
            and prior['original_origin'] == old_start['monotonic'], 'continuation reset origin/gate/source')
    old_supervisor = '/home/mikers/gomap-5335-perf-campaign-20261030/supervisor.py'
    helper = read(root / 'HELPER-BINDING.json')
    expected_bindings = {k: v for k, v in old['bindings'].items() if k != old_supervisor}
    require(old_supervisor in old['bindings'] and helper['path'] not in expected_bindings, 'observer-only substitution differs')
    expected_bindings.update({helper['path']: helper['sha256'], str(root / 'continuation.py'): digest(root / 'continuation.py'),
                             str(root / 'HELPER-BINDING.json'): digest(root / 'HELPER-BINDING.json'), str(prior_path): digest(prior_path)})
    require(campaign['bindings'] == expected_bindings, 'extra/missing/changed continuation artifact binding')
    require(read(root / 'accepted-controls.json') == read(prior_root / 'accepted-controls.json'), 'continuation changed accepted controls')
    rejected = prior_root / 'cells' / expected[2]['name']
    terminal = read(rejected / 'launcher/terminal.json')
    require(not (rejected / 'COMPLETE.json').exists() and (rejected / 'STARTED.json').is_file()
            and terminal.get('ok') is False and terminal.get('reason') == 'unexpected_descendants_after_main', 'prior rejected observer attempt differs or was promoted')
    stop = read(prior_root / 'STOPPED.json')
    require(stop.get('cell') == expected[2]['name'] and stop.get('status') == 'FAILED_STOP_NO_RETRY', 'prior stopped disposition differs')
    require(not any((prior_root / 'cells' / r['name'] / 'STARTED.json').exists() for r in expected[3:]), 'previously unstarted prior arm was dispatched')
    def normalized(x):
        if isinstance(x, dict): return {k: normalized(v) for k, v in x.items()}
        if isinstance(x, list): return [normalized(v) for v in x]
        if isinstance(x, str) and (x == str(root) or x.startswith(str(root) + '/')):
            return str(prior_root) + x[len(str(root)):]
        return x
    for row in expected[2:]:
        require(normalized(read(root / 'cells' / row['name'] / 'request.json')) ==
                read(prior_root / 'cells' / row['name'] / 'request.json'), 'continuation request/caps/environment changed: ' + row['name'])
    return dict(campaign=campaign, packets=[prior_root, root],
                cells=[(prior_root / 'cells' / r['name'], r) for r in expected[:2]] + [(root / 'cells' / r['name'], r) for r in expected[2:]],
                prior=dict(root=str(prior_root), receipt=file_record(prior_path), value=prior))


def attempt_status(cell, row, role='current'):
    terminal_path = cell / 'FINAL.json'
    if not terminal_path.is_file(): terminal_path = cell / 'launcher/terminal.json'
    terminal = read(terminal_path) if terminal_path.is_file() else None
    return dict(row, packet_root=str(cell.parent.parent), cell_path=str(cell), role=role,
                status='COMPLETION_RECEIPT_PRESENT' if (cell / 'COMPLETE.json').exists() else 'STARTED_INCOMPLETE' if (cell / 'STARTED.json').exists() else 'NOT_STARTED',
                supervisor=None if terminal is None else {k: terminal.get(k) for k in ('ok', 'reason', 'main', 'errors', 'survivors', 'direct_child_reaped', 'custody_uncertain')},
                receipts={n: file_record(cell / n) for n in ('STARTED.json', 'FINAL.json', 'COMPLETE.json', 'launcher/terminal.json') if (cell / n).is_file()})


def attempt_statuses(root, plan):
    expected = comparison_order()
    statuses = [attempt_status(cell, row, 'adopted_prior' if cell.parent.parent != root else 'current') for cell, row in plan['cells']]
    extras = []
    for packet in plan['packets']:
        declared = read(packet / 'campaign.json')['order']
        extras += [str(p) for p in (packet / 'cells').iterdir() if p.name not in {r['name'] for r in declared}]
    result = dict(attempts=statuses, undeclared_cells=sorted(extras), stopped=read(root / 'STOPPED.json') if (root / 'STOPPED.json').exists() else None)
    if plan['prior']:
        prior = pathlib.Path(plan['prior']['root'])
        rejected = attempt_status(prior / 'cells' / expected[2]['name'], expected[2], 'rejected_prior_not_sample')
        result.update(prior_packet=dict(plan['prior'], attempts=[attempt_status(prior / 'cells' / r['name'], r, 'prior_history') for r in expected],
                                       stopped=read(prior / 'STOPPED.json')),
                      rejected_attempts=[rejected], all_attempts=statuses[:2] + [rejected] + statuses[2:])
    else:
        result.update(rejected_attempts=[], all_attempts=statuses)
    return result


def verify_packet_inputs(root, campaign):
    """Verify each actual seal/gate separately, including rejected STARTED identity."""
    seal, start = read(root / 'SEALED.json'), read(root / 'campaign-start.json')
    for relative, sha in seal['files'].items():
        p = pathlib.Path(relative)
        require(not p.is_absolute() and '..' not in p.parts and digest(root / p) == sha, 'sealed input changed: ' + relative)
    gate = read(start['gate_path'])
    require(digest(start['gate_path']) == start['gate_sha256'] and gate['authorized'] is True and gate['predecessor_merged'] is True and gate['harness_landed'] is True, 'missing actual merged/runtime gate')
    require(gate['build_source_commit'] == campaign['source_commit'], 'gate source differs')
    for kind in ('review_receipt', 'ci_receipt', 'merge_receipt'):
        require(digest(gate[kind]['path']) == gate[kind]['sha256'], 'changed gate receipt: ' + kind)
    for row in campaign['order']:
        cell = root / 'cells' / row['name']
        if (cell / 'STARTED.json').exists():
            started = read(cell / 'STARTED.json')
            require(started['seal_sha256'] == digest(root / 'SEALED.json') and started['gate_sha256'] == start['gate_sha256'], 'attempt launch seal/gate differs')
    return gate


def successful_terminal(x):
    require(x.get('ok') is True and x.get('reason') == 'complete', 'supervisor did not accept completion')
    require(x.get('main', {}).get('exit') == 0, 'nonzero/missing supervisor main exit')
    require(x.get('errors') == [] and x.get('survivors') == [], 'resource/cleanup error or survivor')
    require(x.get('direct_child_reaped') is True and x.get('custody_uncertain') is False,
            'unreaped child or uncertain custody')
    require(x.get('same_job_scan_unreadable') == {}, 'incomplete same-job custody observation')


def seconds(text):
    units = dict(h=3600, m=60, s=1, ms=.001, us=.000001, ns=.000000001)
    units['µs'] = .000001
    require(re.fullmatch(r'(?:[0-9]+(?:\.[0-9]+)?(?:h|ms|m|s|µs|us|ns))+', text), 'invalid printed duration')
    return sum(float(n) * units[u] for n, u in re.findall(r'([0-9.]+)(ms|µs|us|ns|h|m|s)', text))


def elapsed(v, x):
    return (v.timestamp(x['end_utc']) - v.timestamp(x['start_utc'])) / 1e9


def collect_cell(cell, row, campaign, v):
    out = cell / 'output'
    target = 'treedb_mongo' if row['arm'] == 'gomap' else 'mongodb'
    d = out / target
    complete = read(cell / 'COMPLETE.json')
    require(all(complete.get(k) == val for k, val in row.items()), 'completion cell identity differs')
    request, started, terminal = (read(cell / n) for n in ('request.json', 'STARTED.json', 'FINAL.json'))
    require(started['request_sha256'] == digest(cell / 'request.json'), 'started request hash differs')
    successful_terminal(terminal)
    require(read(cell / 'launcher/terminal.json') == terminal, 'supervisor final/terminal differ')
    require(not any((out / n).exists() for n in ('failure.json', 'reference-incomplete.json')), 'failed/incomplete attempt')
    m = read(out / 'manifest.json')
    require(digest(out / 'manifest.json') == complete['manifest_sha256'], 'manifest hash differs')
    require(m['recordcount'] == campaign['counts']['load'] and m['operationcount'] == campaign['counts']['run']
            and m['threadcount'] == campaign['counts']['workers'] and m['run_repeats'] == 1, 'workload shape differs')
    for relative, expected in complete['files'].items():
        p = pathlib.Path(relative)
        require(not p.is_absolute() and '..' not in p.parts, 'unsafe completion artifact path')
        require(digest(cell / p) == expected, 'changed completion artifact: ' + relative)
    if row['arm'] == 'gomap':
        accepted = read(out / 'validation.json')
        require(accepted['status'] == 'validated-consumer-evidence' and accepted['errors'] == [], 'consumer not validated')
        lifecycle, runtime = read(d / 'lifecycle.json'), read(d / 'runtime.json')
        require(m['server_builds'][target]['source_commit'] == campaign['source_commit'], 'actual product source differs')
        require(lifecycle['source_commit'] == m['server_builds'][target]['source_commit'], 'lifecycle product source differs')
    else:
        completion = read(out / 'reference-complete.json')
        require(completion['campaign_id'] == m['campaign_id'] and completion['manifest_sha256'] == digest(out / 'manifest.json'), 'reference completion differs')
        accepted = json.loads((cell / 'launcher/stdout.txt').read_text().strip().splitlines()[-1])
        require(accepted['status'] == 'validated-reference-lifecycle-evidence' and accepted['deterministic_exact_values'] is True, 'reference not validated')
        lifecycle = {role: read(d / (role + '.close.json')) for role in ('server', 'reopened', 'fixture-write', 'fixture-reopened')}
        runtime = read(out / 'reference-runtime.json')
    require(complete['validation'] == accepted and complete['lifecycle'] == lifecycle and complete['runtime'] == runtime,
            'completion differs from actual maintained validation/runtime/lifecycle')
    expected_j = True if row['arm'] == 'mongodb' and row['class_name'] == 'durable-B' else None
    require(m['write_concern'] == dict(w=1, journal_requested=expected_j), 'write concern differs')
    if row['arm'] == 'gomap':
        require(m['profile'] == 'command_wal_' + ('durable' if row['class_name'] == 'durable-B' else 'relaxed'), 'profile differs')
    require(('common_load' in m) == (row['class_name'] == 'durable-B'), 'common-load class differs')
    phases = {}
    for stem, count in (('load', campaign['counts']['load']), ('run_1', campaign['counts']['run'])):
        raw = d / (stem + '.out')
        parsed = v.parse_log(raw)
        v.check_counts(parsed, count, 'load' if stem == 'load' else 'run', raw)
        v.phase_evidence(d, stem, target, m)
        launch, close, cleanup = (read(d / (stem + suffix)) for suffix in ('.launch.json', '.close.json', '.cleanup.json'))
        require(complete['phases'][stem] == dict(launch=launch, close=close, cleanup=cleanup), 'phase projection differs')
        require(all(cleanup['process'].get(k) == launch['process'].get(k) for k in ('pid', 'start_ticks', 'exe_sha256'))
                and cleanup['pidfd_pinned'] is True, 'phase cleanup identity differs')
        printed = re.findall(r'^Run finished, takes (.+)$', raw.read_text(), re.M)
        require(len(printed) == 1, 'ambiguous workload duration')
        phases[stem] = dict(rows=parsed, printed_workload_duration=printed[0], workload_seconds=seconds(printed[0]),
                            launch_seconds=elapsed(v, launch), db_close_seconds=close['db_close']['elapsed_ns'] / 1e9,
                            workload_close_seconds=close['workload_close']['elapsed_ns'] / 1e9,
                            close=close, launch=launch, cleanup=cleanup,
                            operation_errors=sum(x['count'] for x in parsed if x['operation'].endswith('_ERROR')))
    snapshots = {}
    for name in ('snapshot_loaded', 'snapshot_preclose', 'snapshot_reopened'):
        p = d / (name + '.json')
        expected = read(d / (name + '.close.json'))['artifacts_sha256'][name + '.json']
        require(complete['snapshots'][name]['sha256'] == expected and digest(p) == expected, 'typed snapshot bytes differ')
        snapshots[name] = dict(path=str(p.resolve()), sha256=expected, bytes=p.stat().st_size)
    sentinel = None
    if row['class_name'] == 'durable-B':
        sentinel = read(d / 'public-sentinel.json')
        require(sentinel == complete['sentinel'], 'sentinel projection differs')
        require(sentinel['campaign_id'] == m['campaign_id'] and sentinel['manifest_sha256'] == digest(out / 'manifest.json'), 'sentinel identity differs')
    else:
        require(complete['sentinel'] is None and not (d / 'public-sentinel.json').exists(), 'unexpected relaxed sentinel')
    maintenance = [dict(artifact=file_record(p), seconds=elapsed(v, x)) for p in sorted(d.glob('*.launch.json'))
                   if p.stem not in ('load.launch', 'run_1.launch') and 'start_utc' in (x := read(p)) and 'end_utc' in x]
    # Stream hash retained snapshots once above; preserve all direct raw logs/receipts,
    # without copying DB directories or decoding large typed-state documents again.
    artifacts = {str(p.resolve()): file_record(p) for base in (cell, out, d, cell / 'launcher')
                 for p in sorted(base.iterdir()) if p.is_file() and p.suffix in ('.json', '.out', '.err', '.txt')
                 and p.name not in {name + '.json' for name in snapshots}}
    return dict(row, manifest=m, request=request, validation=accepted, lifecycle=lifecycle, runtime=runtime,
                phases=phases, snapshots=snapshots, sentinel=sentinel,
                sentinel_seconds=elapsed(v, sentinel) if sentinel else None,
                maintenance_launch_intervals=maintenance, supervisor=terminal, artifacts=artifacts,
                state_scope=dict(random='observed-state-preservation-only', deterministic='separate maintained exact-value fixture',
                                 causal_ack_crash='separate scoped reviewed control receipts; not inferred from these timed runs'))


def total(sample, phase='run_1'):
    return next(x['ops_per_sec'] for x in sample['phases'][phase]['rows'] if x['operation'] == 'TOTAL')


def render(data):
    lines = ['# Twelve-arm comparison report', '', data['status'], '',
             'This is an offline projection of accepted maintained lifecycle evidence. All sample slots and rejected prior attempts are listed. '
             'Timing totals exclude client Close. Random runs establish observed state preservation; the separate deterministic fixture checks exact values. '
             'Scoped ACK/crash controls are separate evidence. No power-loss certification or quiet-host claim follows. '
             'Ratios below one remain negative performance observations; evidence completeness does not satisfy an unmet performance target.', '',
             f"Actual gateway source: `{data['campaign']['source_commit']}` / tree `{data['campaign']['source_tree']}`.", '']
    if data['attempts'].get('prior_packet'):
        lines += [f"Continuation: two samples retain their prior packet identities; ten use the continuation packet. All {len(data['attempts']['all_attempts'])} attempt slots include the rejected original G2, excluded from samples. Original STOPPED and all prior statuses remain in report.json.", '']
    lines += ['| Class | Pair | Mongo load ops/s | GoMap load ops/s | Mongo run ops/s | GoMap run ops/s | GoMap/Mongo |', '|---|---:|---:|---:|---:|---:|---:|']
    for p in data['pairs']:
        lines.append(f"| {p['class_name']} | {p['pair']} | {p['mongodb_load']:.1f} | {p['gomap_load']:.1f} | {p['mongodb']:.1f} | {p['gomap']:.1f} | {p['ratio']:.6f} |")
    lines += ['', '| Class | Mongo median ops/s (range) | GoMap median ops/s (range) | Median paired ratio |', '|---|---:|---:|---:|']
    for cls, x in data['summaries'].items():
        fields = [f"{x[a]['median']:.1f} ({x[a]['minimum']:.1f}–{x[a]['maximum']:.1f})" for a in ('mongodb', 'gomap')]
        lines.append(f"| {cls} | {fields[0]} | {fields[1]} | {x['median_paired_ratio']:.6f} |")
    lines += ['', '| Attempt | Operation | Count | Errors | Mean µs | p50 µs | p95 µs | p99 µs | p999 µs | Max µs |', '|---|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for s in data['samples']:
        rows = {x['operation']: x for x in s['phases']['run_1']['rows']}
        for op in ('READ', 'UPDATE'):
            x = rows[op]
            lines.append('| ' + ' | '.join(map(str, [s['name'], op, x['count'], rows.get(op + '_ERROR', {}).get('count', 0)] + [x[k] for k in ('avg_us', 'p50_us', 'p95_us', 'p99_us', 'p999_us', 'max_us')])) + ' |')
    lines += ['', '| Attempt | Load s | Run s | Load DB Close s | Run DB Close s | Load workload Close s | Run workload Close s | Sentinel s | Supervisor s |', '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for s in data['samples']:
        load, run = s['phases']['load'], s['phases']['run_1']
        vals = [load['workload_seconds'], run['workload_seconds'], load['db_close_seconds'], run['db_close_seconds'], load['workload_close_seconds'], run['workload_close_seconds'], s['sentinel_seconds'], s['supervisor']['elapsed']]
        lines.append('| ' + s['name'] + ' | ' + ' | '.join('n/a' if x is None else f'{x:.9f}' for x in vals) + ' |')
    lines += ['', '| Attempt | Actual server build | Requested write concern | Profile | Peak RSS bytes | Max watchdog gap s | Late observations |', '|---|---|---|---|---:|---:|---:|']
    for s in data['samples']:
        m, t = s['manifest'], s['supervisor']
        build = m['server_builds']['treedb_mongo' if s['arm'] == 'gomap' else 'mongodb']
        lines.append(f"| {s['name']} | `{json.dumps(build, sort_keys=True)}` | `{json.dumps(m['write_concern'])}` | {m.get('profile')} | {t['peak']['rss_bytes']} | {t['max_watchdog_gap_seconds']} | {t['late_observation_count']} |")
    lines += ['', 'All attempt statuses, actual runtime/configuration and client/fixture/source identities, full operation rows, launch/cleanup/Close records, '
              'maintenance intervals, supervisor custody/resource/noise observations, original snapshot hashes and raw artifact paths/hashes are retained in `report.json`. '
              'Observation cadence overruns and external processes remain disclosed; sampled maxima are not continuous measurement. '
              'Artifact paths refer to persistent local custody and do not assert external availability. No missing sample is substituted, retried or averaged away.', '']
    return '\n'.join(lines)


def assemble(root, output, scripts, fixture=False, prior_packet=None):
    require(prior_packet is None or all(not output.resolve().is_relative_to(p.resolve()) for p in (root, prior_packet)), 'continuation report output must remain outside both frozen packets')
    output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(scripts))
    import ycsb_compare_validate as v
    try:
        require(not (fixture and prior_packet), 'prior continuation cannot use retained-fixture-only bypass')
        plan = packet_plan(root, prior_packet)
        campaign, expected = plan['campaign'], comparison_order()
        status = attempt_statuses(root, plan)
        write(output / 'attempt-statuses.json', status)
        require(not status['undeclared_cells'] and status['stopped'] is None, 'undeclared attempt or stopped campaign')
        require(all(x['status'] == 'COMPLETION_RECEIPT_PRESENT' for x in status['attempts']), 'missing/unvalidated declared cell')
        packet_receipts = {}
        for packet in plan['packets']:
            for n in ('campaign.json', 'SEALED.json', 'campaign-start.json', 'accepted-controls.json', 'PRIOR-PACKET.json', 'STOPPED.json'):
                if (packet / n).is_file():
                    key = n if packet == root else str(packet / n)
                    packet_receipts[key] = dict(artifact=file_record(packet / n), value=read(packet / n))
        if not fixture:
            for packet in plan['packets']:
                gate = verify_packet_inputs(packet, read(packet / 'campaign.json'))
                packet_receipts[read(packet / 'campaign-start.json')['gate_path']] = dict(artifact=file_record(read(packet / 'campaign-start.json')['gate_path']), value=gate)
        samples = []
        for cell, row in plan['cells']:
            sample = collect_cell(cell, row, campaign, v)
            sample.update(packet_root=str(cell.parent.parent), cell_path=str(cell), adopted_prior=cell.parent.parent != root)
            samples.append(sample)
        if not fixture:
            for packet in plan['packets']:
                for path, sha in read(packet / 'campaign.json')['bindings'].items():
                    require(digest(path) == sha, 'changed campaign artifact: ' + path)
                    if pathlib.Path(path).suffix == '.json':
                        packet_receipts[path] = dict(artifact=file_record(path), value=read(path))
            builds = [x['value'] for x in packet_receipts.values() if isinstance(x['value'], dict)
                      and all(k in x['value'] for k in ('source_tree', 'exe_sha256', 'source_clean_after'))]
            require(len(builds) == 1 and builds[0]['source_clean_after'] is True
                    and builds[0]['source_commit'] == campaign['source_commit']
                    and builds[0]['source_tree'] == campaign['source_tree']
                    and builds[0]['exe_sha256'] == gate['gateway_sha256'], 'actual build/source/tree receipt differs')
            for sample in samples:
                if sample['arm'] == 'gomap':
                    build = sample['manifest']['server_builds']['treedb_mongo']
                    require(build['exe_sha256'] == gate['gateway_sha256'], 'actual gateway differs from merged runtime gate')
                    require(digest(pathlib.Path(build['source_dir']) / 'scripts/ycsb_compare_validate.py') == digest(scripts / 'ycsb_compare_validate.py'), 'parser differs from actual gateway source')
        pairs, summaries = [], {}
        for cls in ('relaxed', 'durable-B'):
            for pair in (1, 2, 3):
                s = {x['arm']: x for x in samples if x['class_name'] == cls and x['pair'] == pair}
                pairs.append(dict(class_name=cls, pair=pair, mongodb=total(s['mongodb']), gomap=total(s['gomap']),
                                  mongodb_load=total(s['mongodb'], 'load'), gomap_load=total(s['gomap'], 'load'), ratio=total(s['gomap']) / total(s['mongodb'])))
            ps = [p for p in pairs if p['class_name'] == cls]
            summaries[cls] = {arm: dict(values=(vals := [p[arm] for p in ps]), mean=statistics.mean(vals), median=statistics.median(vals), minimum=min(vals), maximum=max(vals), population_cv_percent=100 * statistics.pstdev(vals) / statistics.mean(vals)) for arm in ('mongodb', 'gomap')}
            summaries[cls]['median_paired_ratio'] = statistics.median(p['ratio'] for p in ps)
        result = dict(status='RETAINED FIXTURE ONLY — NOT FINAL QUALIFICATION' if fixture else 'COMPLETE OFFLINE PROJECTION — merge/review acceptance remains separate',
                      assembled_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), campaign=campaign, comparison_order=expected, attempts=status, packet_receipts=packet_receipts,
                      assembler=file_record(__file__), parser=file_record(scripts / 'ycsb_compare_validate.py'), samples=samples, pairs=pairs, summaries=summaries)
        write(output / 'report.json', result)
        with (output / 'REPORT.md').open('x') as f:
            f.write(render(result))
        write(output / 'COMPLETE.json', dict(status=result['status'], report=file_record(output / 'report.json'), markdown=file_record(output / 'REPORT.md')))
    except Exception as exc:
        if not (output / 'attempt-statuses.json').exists():
            write(output / 'attempt-statuses.json', dict(attempts=[], error=str(exc), unverified_packet=str(root), unverified_prior=None if prior_packet is None else str(prior_packet)))
        write(output / 'FAILED.json', dict(status='INCOMPLETE_OR_INVALID_NO_ACCEPTED_REPORT', error=str(exc), attempts=file_record(output / 'attempt-statuses.json')))
        raise


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('packet', type=pathlib.Path)
    ap.add_argument('output', type=pathlib.Path, help='fresh output directory; never overwrites')
    ap.add_argument('--scripts', required=True, type=pathlib.Path, help='exact maintained scripts directory; recorded by hash')
    ap.add_argument('--prior-packet', type=pathlib.Path, help='explicit original stopped packet; adopts only its exact first two valid cells')
    ap.add_argument('--retained-fixture-only', action='store_true', help='diagnostic old fixtures; skips final seal/merge gate, labels every report non-qualifying')
    args = ap.parse_args()
    assemble(args.packet.resolve(), args.output.resolve(), args.scripts.resolve(), args.retained_fixture_only, None if args.prior_packet is None else args.prior_packet.resolve())
