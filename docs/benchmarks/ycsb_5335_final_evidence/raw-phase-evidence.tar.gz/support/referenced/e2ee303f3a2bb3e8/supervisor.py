"""One-job Linux supervisor; no host lock/quiet admission or product policy.

PID/start-time parsing and external CPU observation adapted from retained v10
custody_primitives.py and process_observer_source.py; see REUSE.md. Single threaded.
"""
import ctypes
import dataclasses
import errno
import json
import os
from pathlib import Path
import resource
import signal
import time
import traceback


def exception_record(stage, exc):
    formatted = ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    return dict(stage=stage, error=repr(exc), type=type(exc).__module__ + '.' + type(exc).__qualname__,
                errno=getattr(exc, 'errno', None), strerror=getattr(exc, 'strerror', None),
                filename=getattr(exc, 'filename', None), filename2=getattr(exc, 'filename2', None),
                traceback=formatted[:65536], traceback_truncated=len(formatted) > 65536)


def snapshot():
    rows = {}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            raw = (p / 'stat').read_text()
            f = raw[raw.rindex(')') + 2:].split()
            rows[int(p.name)] = dict(pid=int(p.name), start_ticks=int(f[19]),
                parent=int(f[1]), group=int(f[2]), state=f[0],
                cpu_ticks=int(f[11]) + int(f[12]), waited_cpu_ticks=int(f[13]) + int(f[14]), rss_bytes=int(f[21]) * os.sysconf('SC_PAGE_SIZE'),
                command=raw[raw.index('(') + 1:raw.rindex(')')])
        except (FileNotFoundError, ProcessLookupError):
            pass
        except PermissionError:
            # External /proc restrictions are observational blind spots, not quiet admission.
            pass
    return rows


def token(row):
    return {'pid': row['pid'], 'start_ticks': row['start_ticks']}


def same(value, rows=None):
    row = (rows if rows is not None else snapshot()).get(value['pid'])
    return row is not None and row['start_ticks'] == value['start_ticks']


def pidfd_for(value):
    """Bind signal authority to kernel process identity, then verify start ticks.

    Opening a pidfd before checking the token closes the check/kill PID reuse race.
    A stale token never grants signal authority over the newly opened process.
    """
    try:
        fd = os.pidfd_open(value['pid'], 0)
    except ProcessLookupError:
        return None
    if not same(value):
        os.close(fd)
        return None
    return fd


def disk_usage(root):
    logical = allocated = 0
    stat = __import__('stat')
    root = Path(root)
    original = root.lstat()
    if not stat.S_ISDIR(original.st_mode):
        raise RuntimeError('task root is not a real directory: ' + str(root))
    vanished_count = 0
    vanished_examples = []

    def check_root():
        current = root.lstat()  # missing root is NEVER a tolerated child race
        if not stat.S_ISDIR(current.st_mode) or (current.st_dev, current.st_ino) != (original.st_dev, original.st_ino):
            raise RuntimeError('task root identity/type changed: ' + str(root))

    def vanished(fd, name, relative):
        nonlocal vanished_count
        # Only an actual second ENOENT proves absence. Replacement, EACCES,
        # EIO, symlink, ENOTDIR and all other states retain the original failure.
        try:
            os.stat(name, dir_fd=fd, follow_symlinks=False)
        except FileNotFoundError as exc:
            if exc.errno != errno.ENOENT:
                raise
            check_root()
            vanished_count += 1
            if len(vanished_examples) < 16:
                vanished_examples.append(relative)
            return True
        return False

    def walk(fd, relative):
        nonlocal logical, allocated
        with os.scandir(fd) as entries:
            for entry in entries:
                name = relative + '/' + entry.name if relative else entry.name
                try:
                    st = entry.stat(follow_symlinks=False)
                except FileNotFoundError as exc:
                    if exc.errno != errno.ENOENT:
                        raise
                    if vanished(fd, entry.name, name):
                        continue
                    raise
                if stat.S_ISLNK(st.st_mode):
                    raise RuntimeError('task tree symlink: ' + name)
                # A successful stat remains charged even if the item then vanishes.
                logical += st.st_size
                allocated += st.st_blocks * 512
                if stat.S_ISDIR(st.st_mode):
                    try:
                        child = os.open(entry.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                    except FileNotFoundError as exc:
                        if exc.errno != errno.ENOENT:
                            raise
                        if vanished(fd, entry.name, name):
                            continue
                        raise
                    try:
                        actual = os.fstat(child)
                        if (actual.st_dev, actual.st_ino) != (st.st_dev, st.st_ino):
                            raise RuntimeError('task child directory replaced: ' + name)
                        walk(child, name)
                    finally:
                        os.close(child)

    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        actual = os.fstat(fd)
        if (actual.st_dev, actual.st_ino) != (original.st_dev, original.st_ino):
            raise RuntimeError('task root replaced before open: ' + str(root))
        walk(fd, '')
        check_root()
        free = __import__('shutil').disk_usage(root).free
        check_root()
        return dict(logical=logical, allocated=allocated, free=free,
                    vanished_entries=vanished_count, vanished_examples=vanished_examples)
    finally:
        os.close(fd)


def read_cpu_identity(value):
    """Read one still-existing identity; parent must be sampled before child."""
    try:
        raw = Path('/proc', str(value['pid']), 'stat').read_text()
    except (FileNotFoundError, ProcessLookupError):
        return None
    fields = raw[raw.rindex(')') + 2:].split()
    if int(fields[19]) != value['start_ticks']:
        return None
    return dict(pid=value['pid'], start_ticks=value['start_ticks'], parent=int(fields[1]),
                own_ticks=int(fields[11]) + int(fields[12]),
                waited_ticks=int(fields[13]) + int(fields[14]))


def disjoint_cpu(owned, reaped, topology, reader=read_cpu_identity, hz=None):
    """Live own+waited CPU plus disjoint supervisor wait4 roots.

    Parent-first reads prevent counting a parent's newly waited child and a
    previously sampled child together. A child disappearing after the parent
    read is temporarily unobserved until the next parent read (sampling gap),
    never added twice. Supervisor-reaped inclusive subtrees are disjoint: a
    process can be waited by its parent OR this supervisor, not both. Living
    adopted descendants were not waited by their departed parent and add here.
    """
    hz = os.sysconf('SC_CLK_TCK') if hz is None else hz
    pending = {key: value for key, value in owned.items() if key not in reaped
               and topology.get(value['pid'], {}).get('start_ticks') == value['start_ticks']}
    ordered = []
    while pending:
        pids = {value['pid'] for value in pending.values()}
        ready = [key for key, value in pending.items()
                 if topology.get(value['pid'], {}).get('parent') not in pids]
        if not ready:
            raise RuntimeError('owned ancestry cycle')
        for key in ready:
            ordered.append(pending.pop(key))
    live_ticks = 0
    observed = []
    for value in ordered:
        row = reader(value)
        if row is not None:
            if row['own_ticks'] < 0 or row['waited_ticks'] < 0:
                raise RuntimeError('invalid CPU counters')
            live_ticks += row['own_ticks'] + row['waited_ticks']
            observed.append(row)
    waited_seconds = sum(record['cpu_seconds'] for record in reaped.values())
    return waited_seconds + live_ticks / hz, dict(
        supervisor_wait4_seconds=waited_seconds, live_own_and_waited_ticks=live_ticks,
        clock_ticks_per_second=hz, live_cpu_observations=observed,
        accounting='disjoint_supervisor_wait4_plus_parent_first_live_own_and_waited')


def machine():
    result = {'monotonic_ns': time.monotonic_ns(), 'loadavg': os.getloadavg()}
    for name in ('meminfo', 'vmstat', 'pressure/cpu', 'pressure/memory', 'pressure/io'):
        try:
            result[name] = Path('/proc', name).read_text()
        except OSError as exc:
            result[name] = {'unavailable': repr(exc)}
    return result


def write_json(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')


@dataclasses.dataclass(frozen=True)
class Limits:
    wall: float = 90
    cpu_soft: int = 60
    cpu_hard: int = 65
    file_bytes: int = 64 * 1024**2
    disk_bytes: int = 1024**3
    min_free: int = 1024**3
    rss_bytes: int = 2 * 1024**3
    poll: float = 0.01
    grace: float = 2
    reap: float = 3
    cpu: int = 0
    nice: int = 19


class Cancelled(Exception):
    pass


class Supervisor:
    def __init__(self, root, admission=None):
        self.root = Path(root)
        self.cancel = None
        self.in_command = False
        self.admission = admission
        self.libc = ctypes.CDLL(None, use_errno=True)
        if self.libc.prctl(36, 1, 0, 0, 0):  # PR_SET_CHILD_SUBREAPER
            raise OSError(ctypes.get_errno(), 'PR_SET_CHILD_SUBREAPER')
        self.prior_handlers = {}

    def __enter__(self):
        for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
            self.prior_handlers[sig] = signal.signal(sig, lambda s, f: setattr(self, 'cancel', s))
        return self

    def __exit__(self, *unused):
        for sig, handler in self.prior_handlers.items():
            signal.signal(sig, handler)

    def run(self, label, argv, cwd, env, limits=Limits(), runtime_probe=None, accepted_exit_codes=(0,)):
        if self.cancel:
            raise Cancelled(self.cancel)
        if not accepted_exit_codes or any(type(code) is not int for code in accepted_exit_codes):
            raise ValueError('explicit integer accepted exit codes required')
        if not 0 < limits.poll <= 0.1:
            raise ValueError('watchdog interval exceeds cap')
        base = self.root / label
        base.mkdir(mode=0o700)  # exclusive per-command consumption; no overwrite/retry
        before = snapshot()
        original_children = {(p, r['start_ticks']) for p, r in before.items() if r['parent'] == os.getpid()}
        owned, reaped, errors, pidfds = {}, {}, [], {}
        cpu_accounting = {}
        direct_reaped = None
        direct_wait_lost = False
        direct_token = None
        anchors = set()
        started = time.monotonic()
        reason = None
        peak = {'logical': 0, 'allocated': 0, 'rss_bytes': 0, 'cpu_seconds': 0}
        last_observation = started
        previous = {p: (r['start_ticks'], r['cpu_ticks']) for p, r in before.items()}
        external = {}
        last_tick = started
        max_watchdog_gap = 0
        late_observation_count = 0
        first_late_observation_elapsed = None
        last_late_observation_elapsed = None
        last_completed_observation = started
        runtime_observation = None
        disk_vanished_entries = 0
        disk_vanished_examples = []
        child = None
        supervisor_pid = os.getpid()
        start_record = dict(argv=argv, cwd=str(cwd), environment=env, limits=dataclasses.asdict(limits),
                            accepted_exit_codes=list(accepted_exit_codes), supervisor=token(before[os.getpid()]), machine=machine(), started=started)
        write_json(base / 'start.json', start_record)
        output = (base / 'stdout.txt').open('xb')
        errout = (base / 'stderr.txt').open('xb')
        observation = (base / 'external.jsonl').open('x')

        def retain_error(stage, exc):
            value = exception_record(stage, exc)
            if value not in errors:
                errors.append(value)

        def attempt(stage, fn, default=None):
            try:
                return fn()
            except BaseException as exc:
                retain_error(stage, exc)
                return default

        def safe_snapshot():
            return attempt('cleanup_snapshot', snapshot, {})

        def discover(rows):
            # Includes escaping descendants adopted by this subreaper, but excludes
            # unrelated children already present before this command.
            parents = {t['pid'] for t in owned.values() if same(t, rows)}
            while True:
                added = {p for p, r in rows.items() if r['parent'] in parents or
                         (r['parent'] == os.getpid() and (p, r['start_ticks']) not in original_children)}
                if added <= parents:
                    break
                parents |= added
            for p in parents:
                if p in rows:
                    value = token(rows[p])
                    k = (p, value['start_ticks'])
                    if k not in owned:
                        owned[k] = value  # observation never depends on pidfd availability
                        fd = attempt('pidfd_acquisition:' + str(p), lambda: pidfd_for(value))
                        if fd is not None:
                            pidfds[k] = fd

        def save_reap(pid, status, usage, value):
            key = (pid, value.get('start_ticks'))
            record = dict(token=value, status=status, exit=os.waitstatus_to_exitcode(status),
                          cpu_seconds=usage.ru_utime + usage.ru_stime)
            reaped[key] = record
            anchors.discard(key)
            return record

        def reap_direct():
            nonlocal direct_reaped, direct_wait_lost
            if child is None or direct_reaped is not None or direct_wait_lost:
                return
            try:
                pid, status, usage = os.wait4(child, os.WNOHANG)
                if pid:
                    direct_reaped = save_reap(pid, status, usage, direct_token or
                        dict(pid=child, start_ticks=None, authority='unreaped direct fork child'))
            except ChildProcessError as exc:
                direct_wait_lost = True  # raw PID authority must never survive lost custody
                retain_error('direct_child_wait_custody_lost', exc)

        def reap_children():
            reap_direct()  # no procfs/pidfd dependency
            for key, t in list(owned.items()):
                if key in reaped or t['pid'] == child:
                    continue
                try:
                    pid, status, usage = os.wait4(t['pid'], os.WNOHANG)
                    if pid:
                        save_reap(pid, status, usage, t)
                    else:
                        # wait4 returning0 establishes a live, unreaped direct/
                        # adopted child. Its PID cannot be reused until our wait.
                        anchors.add(key)
                except ChildProcessError:
                    pass  # still-live grandchild belongs to its parent until adoption

        def signal_owned(sig):
            # Fork-return child is independently anchored until OUR wait4.
            # Always do this before fallible observation or pidfd operations.
            attempt('reap_direct_before_signal', reap_direct)
            if child is not None and direct_reaped is None and not direct_wait_lost:
                try:
                    os.kill(child, sig)
                except ProcessLookupError:
                    pass
                except BaseException as exc:
                    retain_error('direct_child_signal', exc)
            rows = safe_snapshot()
            attempt('cleanup_discover', lambda: discover(rows))
            attempt('cleanup_reap', reap_children)
            for fd in list(pidfds.values()):
                try:
                    signal.pidfd_send_signal(fd, sig)
                except ProcessLookupError:
                    pass
                except BaseException as exc:
                    retain_error('pidfd_signal', exc)
            for key in list(anchors):
                if key not in reaped:
                    try:
                        os.kill(key[0], sig)
                    except ProcessLookupError:
                        pass
                    except BaseException as exc:
                        retain_error('adopted_child_signal', exc)

        def cleanup_active():
            if child is not None and direct_reaped is None and not direct_wait_lost:
                return True
            if any(k not in reaped for k in anchors):
                return True
            rows = safe_snapshot()
            return any(same(t, rows) for t in owned.values())

        def cleanup_round(sig):
            attempt('cleanup_signal_round', lambda: signal_owned(sig))
            attempt('cleanup_reap_round', reap_children)
            attempt('cleanup_cpu_round', lambda: charge_cpu(safe_snapshot()))

        def charge_cpu(rows):
            nonlocal cpu_accounting
            live = [r for r in rows.values() if (r['pid'], r['start_ticks']) in owned]
            cpu, cpu_accounting = disjoint_cpu(owned, reaped, rows)
            peak['cpu_seconds'] = max(peak['cpu_seconds'], cpu)
            return live, cpu

        self.in_command = True
        try:
            if self.admission:
                self.admission(before, set(owned))
            child = os.fork()
            if child == 0:
                try:
                    os.setsid()
                    # Direct child dies if supervisor is killed before cleanup.
                    if self.libc.prctl(1, signal.SIGKILL, 0, 0, 0) or os.getppid() != supervisor_pid:
                        os._exit(126)
                    if limits.cpu is not None:
                        os.sched_setaffinity(0, {limits.cpu})
                    os.nice(limits.nice)
                    resource.setrlimit(resource.RLIMIT_CPU, (limits.cpu_soft, limits.cpu_hard))
                    resource.setrlimit(resource.RLIMIT_FSIZE, (limits.file_bytes, limits.file_bytes))
                    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
                    os.dup2(output.fileno(), 1)
                    os.dup2(errout.fileno(), 2)
                    os.chdir(cwd)
                    os.execve(argv[0], argv, env)
                except BaseException as exc:
                    os.write(2, (json.dumps(exception_record('child_setup_exec', exc)) + '\n').encode())
                    os._exit(126)
            initial = snapshot()
            if child in initial:
                direct_token = token(initial[child])
            discover(initial)
            while True:
                now = time.monotonic()
                max_watchdog_gap = max(max_watchdog_gap, now - last_tick)
                last_tick = now
                rows = snapshot()
                discover(rows)
                reap_children()
                live, cpu = charge_cpu(rows)
                if runtime_probe and runtime_observation is None and child in rows:
                    runtime_observation = runtime_probe(child)
                if self.admission:
                    self.admission(rows, set(owned))
                rss = sum(r['rss_bytes'] for r in live)
                usage = disk_usage(self.root)
                disk_vanished_entries += usage.get('vanished_entries', 0)
                for example in usage.get('vanished_examples', []):
                    if example not in disk_vanished_examples and len(disk_vanished_examples) < 16:
                        disk_vanished_examples.append(example)
                for key in ('logical', 'allocated'):
                    peak[key] = max(peak[key], usage[key])
                peak['rss_bytes'] = max(peak['rss_bytes'], rss)
                peak['cpu_seconds'] = max(peak['cpu_seconds'], cpu)
                if now - last_observation >= 0.25:
                    for p, r in rows.items():
                        if (p, r['start_ticks']) not in owned and p != os.getpid():
                            prior = previous.get(p)
                            delta = max(0, r['cpu_ticks'] - prior[1]) if prior and prior[0] == r['start_ticks'] else 0
                            k = (p, r['start_ticks'])
                            value = external.setdefault(k, dict(token=token(r), command=r['command'], cpu_ticks=0))
                            value['cpu_ticks'] += delta
                        previous[p] = (r['start_ticks'], r['cpu_ticks'])
                    observation.write(json.dumps(dict(monotonic=now, processes=list(rows.values()), machine=machine())) + '\n')
                    observation.flush()
                    last_observation = now
                # Charge time spent in observation itself before publishing success.
                after_work = time.monotonic()
                max_watchdog_gap = max(max_watchdog_gap, after_work - last_tick)
                actual_interval = after_work - last_completed_observation
                max_watchdog_gap = max(max_watchdog_gap, actual_interval)
                if actual_interval > 0.1:
                    late_observation_count += 1
                    if first_late_observation_elapsed is None:
                        first_late_observation_elapsed = after_work - started
                    last_late_observation_elapsed = after_work - started
                last_completed_observation = after_work
                now = after_work
                main = direct_reaped
                if self.cancel:
                    reason = 'cancelled_signal_' + str(self.cancel)
                elif errors:
                    reason = 'custody_observation_error'
                elif now - started > limits.wall:
                    reason = 'wall_limit'
                elif cpu > limits.cpu_soft:
                    reason = 'aggregate_cpu_limit'
                elif rss > limits.rss_bytes:
                    reason = 'rss_watchdog_limit'
                elif max(usage['logical'], usage['allocated']) > limits.disk_bytes:
                    reason = 'disk_limit'
                elif usage['free'] < limits.min_free:
                    reason = 'filesystem_free_limit'
                elif main is not None:
                    descendants = [r for r in live if r['pid'] != child and r['state'] != 'Z']
                    reason = ('unexpected_descendants_after_main' if descendants else
                              'complete' if main['exit'] in accepted_exit_codes else 'nonzero_exit')
                if reason:
                    break
                time.sleep(limits.poll)
        except BaseException as exc:
            retain_error('run', exc)
            reason = 'supervisor_exception'
        finally:
            # Even main exit0 must close descendants before the next arm.
            if child:
                cleanup_round(signal.SIGTERM)
                deadline = time.monotonic() + limits.grace
                while time.monotonic() < deadline:
                    cleanup_round(signal.SIGTERM)
                    if not attempt('cleanup_active', cleanup_active, True):
                        break
                    attempt('cleanup_sleep', lambda: time.sleep(min(limits.poll, 0.05)))
                cleanup_round(signal.SIGKILL)
                deadline = time.monotonic() + limits.reap
                while time.monotonic() < deadline:
                    cleanup_round(signal.SIGKILL)
                    if not attempt('cleanup_active', cleanup_active, True):
                        break
                    attempt('cleanup_sleep', lambda: time.sleep(0.02))
            attempt('close_stdout', output.close)
            attempt('close_stderr', errout.close)
            attempt('close_observation', observation.close)
        rows = safe_snapshot()
        attempt('terminal_reap', reap_children)
        attempt('terminal_cpu', lambda: charge_cpu(rows))
        survivors = [t for t in owned.values() if same(t, rows)]
        if child is not None and direct_reaped is None:
            survivors.append(direct_token or dict(pid=child, start_ticks=None, authority='unreaped direct fork child'))
        if peak['cpu_seconds'] > limits.cpu_soft and reason == 'complete':
            reason = 'aggregate_cpu_limit'
        if self.cancel:
            reason = 'cancelled_signal_' + str(self.cancel)
        if runtime_probe and runtime_observation is None and reason == 'complete':
            reason = 'runtime_identity_not_observed'
        main = direct_reaped
        result = dict(label=label, reason=reason, elapsed=time.monotonic() - started, main=main,
            owned=list(owned.values()), reaped=list(reaped.values()), survivors=survivors,
            errors=errors, peak=peak, cpu_accounting=cpu_accounting, max_watchdog_gap_seconds=max_watchdog_gap,
            disk_vanished_entries=disk_vanished_entries, disk_vanished_examples=disk_vanished_examples,
            target_observation_interval_seconds=0.1, late_observation_count=late_observation_count,
            first_late_observation_elapsed_seconds=first_late_observation_elapsed,
            last_late_observation_elapsed_seconds=last_late_observation_elapsed,
            max_observation_overshoot_seconds=max(0, max_watchdog_gap - 0.1), observation_cadence_disposition='RECORD_ONLY',
            runtime_observation=runtime_observation,
            same_job_scan_unreadable=getattr(self.admission, 'unreadable', {}), direct_child_reaped=direct_reaped is not None if child else None,
            custody_uncertain=direct_wait_lost or any(e['stage'] == 'cleanup_snapshot' for e in errors),
            external=list(external.values()), machine_after=machine(),
            observer_limits='250ms snapshots; short-lived external processes and sub-tick CPU may be missed; no host/lease/quiet admission',
            ok=reason == 'complete' and not survivors and not errors and main is not None)
        for fd in pidfds.values():
            attempt('close_pidfd', lambda fd=fd: os.close(fd))
        if errors:
            result['ok'] = False
        write_json(base / 'terminal.json', result)
        self.in_command = False
        if not result['ok']:
            raise RuntimeError('bounded command failed: ' + label + ': ' + str(reason))
        return result
