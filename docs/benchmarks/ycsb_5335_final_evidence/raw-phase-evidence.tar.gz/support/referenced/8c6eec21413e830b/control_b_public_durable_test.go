package mongogateway

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	treedb "github.com/snissn/gomap/TreeDB"
	"github.com/snissn/gomap/TreeDB/internal/durabilitycut"
	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/event"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
	"go.mongodb.org/mongo-driver/v2/mongo/writeconcern"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func controlBOpen(t *testing.T, dir string) (*StandaloneServer, *mongo.Client, *mongo.Collection) {
	t.Helper()
	s, e := OpenStandaloneServer(StandaloneOptions{Dir: dir, Profile: treedb.ProfileCommandWALDurable})
	if e != nil {
		t.Fatal(e)
	}
	if !s.Backend.HasNativeSemanticBridge() {
		t.Fatal("missing COW native owner")
	}
	ln, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	go s.Serve(context.Background(), ln)
	monitor := &event.CommandMonitor{Started: func(_ context.Context, e *event.CommandStartedEvent) {
		if e.CommandName == "insert" || e.CommandName == "update" {
			wc := e.Command.Lookup("writeConcern").Document()
			if wc.Lookup("w").Int32() != 1 || wc.Lookup("j").Type != 0 {
				panic(fmt.Sprintf("wrong wire concern %s", wc))
			}
			t.Logf("WIRE %s writeConcern=%s BSON_bytes=%d", e.CommandName, wc, len(e.Command))
		}
	}}
	c, e := mongo.Connect(options.Client().ApplyURI("mongodb://" + ln.Addr().String() + "/?directConnection=true").SetWriteConcern(writeconcern.W1()).SetMonitor(monitor))
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() {
		if e := c.Disconnect(context.Background()); e != nil {
			t.Errorf("disconnect: %v", e)
		}
		e := s.Close()
		if strings.Contains(t.Name(), "SyncErrors") {
			if e == nil || !strings.Contains(e.Error(), "reopen required") {
				t.Errorf("expected poisoned close: %v", e)
			} else {
				t.Logf("EXPECTED POISONED CLOSE %v", e)
			}
		} else if e != nil {
			t.Errorf("close: %v", e)
		}
	})
	t.Logf("OWNER native=%v profile=%s pid=%d addr=%s dir=%s", s.Backend.HasNativeSemanticBridge(), s.Options.Profile, os.Getpid(), ln.Addr(), dir)
	return s, c, c.Database("controlb").Collection("rows")
}

func controlBMutation(t *testing.T, s *StandaloneServer, c *mongo.Collection, dir string, update, fail bool, id string) {
	t.Helper()
	beforeNext := s.Backend.CommandWALNextLSN()
	entered := make(chan struct{})
	release := make(chan struct{})
	var once sync.Once
	var releaseOnce sync.Once
	unblock := func() { releaseOnce.Do(func() { close(release) }) }
	defer unblock()
	var syncCompleted atomic.Bool
	root := filepath.Join(dir, "maindb")
	restore := durabilitycut.Install(func(e durabilitycut.Event) error {
		if e.Point == durabilitycut.BeforeDependencyFileSync || e.Point == durabilitycut.AfterDependencyFileSync {
			t.Logf("DEPENDENCY resource=%s point=%s root=%s path=%s retained=%v", e.Resource, e.Point, e.Root, e.Path, e.StablePath != nil)
		}
		if e.Resource == durabilitycut.ResourceCommandWAL && e.Root == root && e.Point == durabilitycut.AfterDependencyFileSync {
			syncCompleted.Store(true)
		}
		if e.Resource == durabilitycut.ResourceCommandWAL && e.Root == root && e.Point == durabilitycut.BeforeDependencyFileSync {
			once.Do(func() { close(entered) })
			<-release
			if fail {
				return errors.New("CONTROL_B_SYNC_FAILURE")
			}
		}
		return nil
	})
	joined := make(chan struct{})
	defer func() {
		unblock()
		select {
		case <-joined:
		case <-time.After(20 * time.Second):
			t.Error("writer failed to join after release")
		}
		restore()
	}()
	done := make(chan error, 1)
	go func() {
		defer close(joined)
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		if update {
			r, e := c.UpdateOne(ctx, bson.D{{Key: "_id", Value: id}}, bson.D{{Key: "$set", Value: bson.D{{Key: "n", Value: int32(2)}, {Key: "payload", Value: bytes.Repeat([]byte{0x72}, 128<<10)}}}})
			if e == nil && (r.MatchedCount != 1 || r.ModifiedCount != 1) {
				e = fmt.Errorf("counts=%+v", r)
			}
			done <- e
		} else {
			_, e := c.InsertOne(ctx, bson.D{{Key: "_id", Value: id}, {Key: "n", Value: int32(1)}, {Key: "payload", Value: bytes.Repeat([]byte{0x31}, 128<<10)}})
			done <- e
		}
	}()
	select {
	case <-entered:
	case e := <-done:
		t.Fatalf("returned before sync seam: %v", e)
	case <-time.After(15 * time.Second):
		t.Fatal("no required sync seam")
	}
	select {
	case e := <-done:
		t.Fatalf("ACK escaped held required sync: %v", e)
	case <-time.After(100 * time.Millisecond):
	}
	t.Logf("BLOCKED before required dependency sync update=%v fail=%v", update, fail)
	unblock()
	select {
	case e := <-done:
		if fail {
			if e == nil || !strings.Contains(e.Error(), "CONTROL_B_SYNC_FAILURE") {
				t.Fatalf("fault missing in public error: %v", e)
			}
			t.Logf("PUBLIC ERROR %v", e)
		} else if e != nil {
			t.Fatal(e)
		} else {
			if !syncCompleted.Load() {
				t.Fatal("ACK before observed physical sync completion")
			}
			endpoint := s.Backend.CommandWALNextLSN() - 1
			durable, e := strconv.ParseUint(s.Backend.Stats()["treedb.command_wal.durable_wal_lsn"], 10, 64)
			if e != nil || endpoint < beforeNext || durable < endpoint {
				t.Fatalf("bad ACK endpoint assigned=%d before=%d durable=%d err=%v", endpoint, beforeNext, durable, e)
			}
			t.Logf("ACK ENDPOINT id=%s update=%v assigned=%d durable=%d applied=%d", id, update, endpoint, durable, s.Backend.State().AppliedCommandLSN)
			t.Logf("ACK after released required dependency sync update=%v stats=%v", update, s.Stats())
		}
	case <-time.After(15 * time.Second):
		t.Fatal("request did not finish")
	}
}

func TestControlBPublicDurableCrash(t *testing.T) {
	if dir := os.Getenv("CONTROL_B_CHILD_DIR"); dir != "" {
		s, _, c := controlBOpen(t, dir)
		if e := c.Database().CreateCollection(context.Background(), "rows"); e != nil {
			t.Fatal(e)
		}
		if _, e := c.InsertOne(context.Background(), bson.D{{Key: "_id", Value: "pointerseed"}, {Key: "n", Value: int32(1)}, {Key: "payload", Value: bytes.Repeat([]byte{0x31}, 128<<10)}}); e != nil {
			t.Fatal(e)
		}
		if _, e := s.Collections.SyncForStandaloneWriteConcern(); e != nil {
			t.Fatal(e)
		}
		t.Logf("SETUP public createCollection + large BSON pointerseed + checked durable barrier stats=%v", s.Stats())
		controlBMutation(t, s, c, dir, true, false, "pointerseed")
		for _, id := range []string{"a", "b"} {
			controlBMutation(t, s, c, dir, false, false, id)
		}
		for _, id := range []string{"a", "b"} {
			controlBMutation(t, s, c, dir, true, false, id)
		}
		errs := make(chan error, 4)
		for i := 0; i < 4; i++ {
			go func(i int) {
				id := fmt.Sprintf("concurrent%d", i)
				ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
				defer cancel()
				_, e := c.InsertOne(ctx, bson.D{{Key: "_id", Value: id}, {Key: "n", Value: int32(1)}, {Key: "payload", Value: bytes.Repeat([]byte{0x31}, 128<<10)}})
				if e == nil {
					var r *mongo.UpdateResult
					r, e = c.UpdateOne(ctx, bson.D{{Key: "_id", Value: id}}, bson.D{{Key: "$set", Value: bson.D{{Key: "n", Value: int32(2)}, {Key: "payload", Value: bytes.Repeat([]byte{0x72}, 128<<10)}}}})
					if e == nil && (r.MatchedCount != 1 || r.ModifiedCount != 1) {
						e = fmt.Errorf("concurrent counts=%+v", r)
					}
				}
				errs <- e
			}(i)
		}
		for i := 0; i < 4; i++ {
			if e := <-errs; e != nil {
				t.Fatal(e)
			}
		}
		t.Log("CONCURRENT independent writers=4 acknowledged inserts=4 changing_updates=4")
		target, e := strconv.ParseUint(s.Stats()["treedb.command_wal.live_accepted_max_lsn"], 10, 64)
		if e != nil || target <= s.Backend.State().AppliedCommandLSN {
			t.Fatalf("no unapplied acknowledged WAL: target=%d err=%v stats=%v", target, e, s.Stats())
		}
		durable, e := strconv.ParseUint(s.Backend.Stats()["treedb.command_wal.durable_wal_lsn"], 10, 64)
		if e != nil || durable < target {
			t.Fatalf("precrash durable=%d target=%d err=%v", durable, target, e)
		}
		fmt.Printf("CONTROL_B_DURABLE %d\n", durable)
		fmt.Printf("CONTROL_B_TARGET %d\n", target)
		fmt.Printf("CONTROL_B_CRASH_ACK applied=%d next=%d stats=%v\n", s.Backend.State().AppliedCommandLSN, s.Backend.CommandWALNextLSN(), s.Stats())
		os.Exit(97)
	}
	dir := t.TempDir()
	if base := os.Getenv("CONTROL_B_RETAIN_DIR"); base != "" {
		dir = filepath.Join(base, "crash-db")
		if e := os.MkdirAll(dir, 0700); e != nil {
			t.Fatal(e)
		}
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestControlBPublicDurableCrash$", "-test.v")
	cmd.Env = append(os.Environ(), "CONTROL_B_CHILD_DIR="+dir, "TREEDB_DISABLE_VLOG_GENERATION_LOOP=1")
	out, e := cmd.CombinedOutput()
	t.Logf("CHILD %s", out)
	var exit *exec.ExitError
	if !errors.As(e, &exit) || exit.ExitCode() != 97 {
		t.Fatalf("child=%v", e)
	}
	var target uint64
	for _, line := range strings.Split(string(out), "\n") {
		if strings.HasPrefix(line, "CONTROL_B_TARGET ") {
			fmt.Sscanf(line, "CONTROL_B_TARGET %d", &target)
		}
	}
	if target == 0 {
		t.Fatal("missing crash target")
	}
	s, _, c := controlBOpen(t, dir)
	if s.Backend.State().AppliedCommandLSN < target {
		t.Fatalf("recovery did not advance applied to acknowledged target=%d", target)
	}
	for _, id := range []string{"a", "b", "pointerseed", "concurrent0", "concurrent1", "concurrent2", "concurrent3"} {
		var got struct {
			ID      string `bson:"_id"`
			N       int32  `bson:"n"`
			Payload []byte `bson:"payload"`
		}
		if e := c.FindOne(context.Background(), bson.D{{Key: "_id", Value: id}}).Decode(&got); e != nil || got.ID != id || got.N != 2 || !bytes.Equal(got.Payload, bytes.Repeat([]byte{0x72}, 128<<10)) {
			t.Fatalf("recovered=%+v err=%v", got, e)
		}
	}
	t.Logf("RECOVERED exact BSON values applied=%d stats=%v", s.Backend.State().AppliedCommandLSN, s.Stats())
}
func TestControlBPublicDurableSyncErrors(t *testing.T) {
	for _, update := range []bool{false, true} {
		t.Run(fmt.Sprint(update), func(t *testing.T) {
			dir := t.TempDir()
			s, _, c := controlBOpen(t, dir)
			if !update {
				if _, e := c.InsertOne(context.Background(), bson.D{{Key: "_id", Value: "seed"}, {Key: "n", Value: int32(0)}}); e != nil {
					t.Fatal(e)
				}
			}
			if update {
				if _, e := c.InsertOne(context.Background(), bson.D{{Key: "_id", Value: "a"}, {Key: "n", Value: int32(1)}, {Key: "payload", Value: bytes.Repeat([]byte{0x31}, 128<<10)}}); e != nil {
					t.Fatal(e)
				}
			}
			controlBMutation(t, s, c, dir, update, true, "a")
		})
	}
}
