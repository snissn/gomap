#!/usr/bin/python3
"""Root-reviewed exact 9354 coherent final two-target build; no product execution."""
import dataclasses,fcntl,hashlib,importlib.util,json,os,pathlib,shutil,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path('/home/mikers/gomap-5335-landing-20261030/worktree');COMMIT='9354d6cad01855908e0f69e9aec47fd2d925b928';TREE='ea369d25702aa0552bd6774c5dbe06dcd0b25f21'
GO=pathlib.Path('/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.10.linux-amd64/bin/go')
CACHE=ROOT/'gocache'
MODULES=pathlib.Path('/home/mikers/go/pkg/mod')
HELPER=pathlib.Path('/home/mikers/gomap-5335-direct-build-v4-recipe-20261030/inventory_stage.py')
SUPERVISOR=pathlib.Path('/home/mikers/gomap-5335-after-inventory-diagnosis-20261030/historical_close_bounded_v5.completion.py')
EMPTY=hashlib.sha256(b'').hexdigest()
EXPECTED={pathlib.Path('/usr/bin/x86_64-linux-gnu-gcc-11'):'821af3c74506283c179ca413bb33e6b528805a4dd8a5c09df125e5ad560a9e89',pathlib.Path('/usr/bin/python3.10'):'a2f33a6e006989270f4340528eb61f8f97366e00a5d1b602ac8672ea44fc56ae',GO:'9c2a37ae5b21ba1d5a004bb9ab4d0c64de6fc5778e9d30487adccea62678b8b5',SUPERVISOR:'0be0152981340e462e504f4553624b6d03d3e7e2b756fa4b9db2022e9be153ba',HELPER:'308b49b8be77ff9fcaa7fc07dcf738778744ee179422b23efcc87d8f9d4e4896',pathlib.Path('/usr/bin/bwrap'):'bf6cf3d4456665f5d80c14eb79a76e0ce87b39a0883e614a161658b4ec33492c'}
def digest(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def write(p,x):
 with pathlib.Path(p).open('x') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
def guard_source(source=SOURCE,commit=COMMIT,tree=TREE):
 if len(commit)!=40 or len(tree)!=40 or any(c not in "0123456789abcdef" for c in commit+tree):raise ValueError("UNBOUND source: ROOT must bind accepted exact commit/tree before any build or inventory")
 def git(*a):return subprocess.check_output(['/usr/bin/git','-C',str(source),*a],text=True).strip()
 if git('rev-parse','HEAD')!=commit or git('rev-parse','HEAD^{tree}')!=tree or git('status','--porcelain') or git('ls-files','--others','--ignored','--exclude-standard'):raise ValueError('source mismatch/dirty/ignored input')
def sandbox(root,cache,argv):return ['/usr/bin/bwrap','--ro-bind','/','/','--dev-bind','/dev/null','/dev/null','--bind',str(root),str(root),'--ro-bind',str(SOURCE),str(SOURCE),'--bind',str(cache),str(cache),'--']+argv
def controller():
 spec=importlib.util.spec_from_file_location('v5_final_gateway',SUPERVISOR);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m
def main():
 guard_source()
 for p,h in EXPECTED.items():
  if digest(p)!=h:raise ValueError('tool/helper changed: '+str(p))
 if not CACHE.is_dir() or CACHE.is_symlink() or not MODULES.is_dir() or MODULES.is_symlink():raise ValueError('cache not real directory')
 if shutil.disk_usage(ROOT).free<5*1024**3:raise ValueError('less than5GiB free')
 lock=open('/home/mikers/.gomap-5335-production-build.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 # ROOT must separately release and bind exact cache custody before invocation.
 # Cache is inside this task root and counted once; never copy cache/modules.
 for name in ('home','tmp','bin','metadata-gateway-before','metadata-gateway-after','metadata-fixture-before','metadata-fixture-after'):(ROOT/name).mkdir()
 env=dict(PATH='/usr/bin:/bin',HOME=str(ROOT/'home'),TMPDIR=str(ROOT/'tmp'),GOROOT=str(GO.parent.parent),GOCACHE=str(CACHE),GOPATH='/home/mikers/go',GOMODCACHE=str(MODULES),GOENV='off',GOFLAGS='',GOWORK='off',GOTOOLCHAIN='local',GOPROXY='off',GOSUMDB='off',GOMAXPROCS='1',GOMEMLIMIT='1GiB',GOGC='50',CGO_ENABLED='1',CC='/usr/bin/x86_64-linux-gnu-gcc-11',LC_ALL='C',TZ='UTC',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_NO_REPLACE_OBJECTS='1')
 targets=(('gateway','./TreeDB/mongo_gateway/server.go'),('fixture','./scripts/ycsb_correctness_fixture.go'))
 commands={role:[str(GO),'build','-p=1','-trimpath','-buildvcs=false','-o',str(ROOT/'bin'/role),target] for role,target in targets}
 v5=controller();limits=v5.Limits(wall=300,cpu_soft=180,cpu_hard=185,file_bytes=512*1024**2,disk_bytes=4*1024**3,min_free=5*1024**3,rss_bytes=2*1024**3,poll=.05,grace=5,reap=5,cpu=min(os.sched_getaffinity(0)),nice=10)
 write(ROOT/'binding.json',dict(source_commit=COMMIT,source_tree=TREE,source_patch_sha256=EMPTY,source_dir=str(SOURCE),adapter_sha256=digest(__file__),tools={str(p):digest(p) for p in EXPECTED},targets=dict(targets),commands=commands,environment=env,limits=dataclasses.asdict(limits),stage_count=8,stage_wall_ceiling_seconds=2400,cache_policy='ROOT-released cache atomically renamed into task root under global build lock; actual inode/provenance must be in CACHE-TRANSFER.json; no copy; full cache included once in unchanged4GiB task disk accounting; filesystem free-space guard applies',module_policy='shared module cache readonly via bwrap, GOPROXY/GOSUMDB off',scope='two explicit offline build targets only; no server, workload or final qualification'))
 with v5.Supervisor(ROOT) as supervisor:
  for role,target in targets:
   for name in ('before','after'):
    if name=='after':
     print('BUILD',role,json.dumps(commands[role]),flush=True);supervisor.run(role+'-build',sandbox(ROOT,CACHE,commands[role]),str(SOURCE),env,limits)
    meta=[sys.executable,'-B',str(HELPER),str(SOURCE),COMMIT,TREE,EMPTY,str(GO),target,str(ROOT/('metadata-'+role+'-'+name))]
    supervisor.run(role+'-inventory-'+name,sandbox(ROOT,CACHE,meta),str(SOURCE),env,limits)
   for name in ('source','deps','modules','toolchain'):
    if digest(ROOT/('metadata-'+role+'-before')/(name+'.json'))!=digest(ROOT/('metadata-'+role+'-after')/(name+'.json')):raise ValueError('input changed '+role+' '+name)
   supervisor.run(role+'-buildinfo',sandbox(ROOT,CACHE,[str(GO),'version','-m',str(ROOT/'bin'/role)]),str(SOURCE),env,limits)
 guard_source()
 input_maps={role:{phase:{name:dict(path=str(ROOT/('metadata-'+role+'-'+phase)/(name+'.json')),sha256=digest(ROOT/('metadata-'+role+'-'+phase)/(name+'.json'))) for name in ('source','deps','modules','toolchain')} for phase in ('before','after')} for role,_ in targets}
 stage_artifacts={role:{stage:{name:dict(path=str(ROOT/(role+'-'+stage)/name),sha256=digest(ROOT/(role+'-'+stage)/name)) for name in ('start.json','terminal.json','external.jsonl','stdout.txt','stderr.txt')} for stage in ('inventory-before','build','inventory-after','buildinfo')} for role,_ in targets}
 gateway=ROOT/'bin/gateway';fixture=ROOT/'bin/fixture'
 write(ROOT/'server-build.json',{'schema_version':1,'servers':{'treedb_mongo':{'schema_version':1,'version':'candidate','source_commit':COMMIT,'source_dir':str(SOURCE),'source_patch_sha256':EMPTY,'exe_sha256':digest(gateway),'expected_owner':'cow'}}})
 write(ROOT/'fixture-build.json',dict(schema_version=1,kind='typed_owner_checkpoint_fixture_build',source_commit=COMMIT,source_tree=TREE,source_dir=str(SOURCE),source_patch_sha256=EMPTY,target='./scripts/ycsb_correctness_fixture.go',binary=str(fixture),exe_sha256=digest(fixture),source_sha256=digest(SOURCE/'scripts/ycsb_correctness_fixture.go'),binding_sha256=digest(ROOT/'binding.json'),argv=commands['fixture'],input_maps=input_maps['fixture'],stage_artifacts=stage_artifacts['fixture'],scope='actual freshly built helper; transitive ycsbevidence JSON contract bound by selected inputs; not a server build or product run'))
 write(ROOT/'COMPLETE.json',dict(source_commit=COMMIT,source_tree=TREE,exe=str(gateway),exe_sha256=digest(gateway),fixture=str(fixture),fixture_exe_sha256=digest(fixture),binding_sha256=digest(ROOT/'binding.json'),server_build_sha256=digest(ROOT/'server-build.json'),fixture_build_sha256=digest(ROOT/'fixture-build.json'),input_maps=input_maps,stage_artifacts=stage_artifacts,source_clean_after=True,status='bounded exact-source gateway and typed fixture builds complete; no product executed'))
 print('COMPLETE',digest(gateway),digest(fixture),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  if not (ROOT/'FAILED.json').exists():write(ROOT/'FAILED.json',dict(error=repr(exc),status='FAILED_STOP_NO_RETRY'))
  raise
