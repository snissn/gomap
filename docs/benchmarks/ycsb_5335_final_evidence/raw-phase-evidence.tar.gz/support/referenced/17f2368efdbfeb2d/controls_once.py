#!/usr/bin/python3
"""Frozen original A/B controls on 792; existing v5 bounds, no product edits."""
import dataclasses, hashlib, importlib.util, json, os, pathlib, struct, subprocess, sys, time
R=pathlib.Path(__file__).resolve().parent
W=R/'worktree'; BUILD=R/'build-output'; LIVE=R/'live-output'
GO=pathlib.Path('/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.10.linux-amd64/bin/go')
CACHE=pathlib.Path('/home/mikers/gomap-5336-5337-main34-repair-qualification-20261030/gocache')
V5=pathlib.Path('/home/mikers/gomap-5335-historical-integration-artifacts-20261030/historical_close_bounded_v5.py')
OBSERVER=W/'scripts/ycsb_runtime_observer.py'
EXPECTED={'sources/control-a.go':'103dc743b1a1fd25bf6f81c080960944ab34154f69feea2f8dbd3f4f59782263','worktree/TreeDB/mongo_gateway/control_b_public_durable_test.go':'9d2dacb11e3f6fd4d99f3eb79a4986d46727c22ecfffa68ccfdca206d20535a0'}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def write(p,x):
 with pathlib.Path(p).open('x') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
def guard():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='79220385186080e77898fcb99c78a8ea15480241'
 assert subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True)==''
 assert subprocess.check_output(['git','status','--short'],cwd=W,text=True)=='?? TreeDB/mongo_gateway/control_b_public_durable_test.go\n'
 for p,h in EXPECTED.items():assert sha(R/p)==h,p
 for x in json.loads((R/'source-inventory.json').read_text())['tracked_present']:assert sha(W/x['path'])==x['sha256'],x['path']
 assert sha(V5)=='c0a211a6edb85f282257e384cb4d1d737fa7d46c0c05d1bd451a43345078f97b'
def sandbox(root,argv,cache=False):
 cmd=['/usr/bin/bwrap','--ro-bind','/','/','--dev-bind','/dev/null','/dev/null','--bind',str(root),str(root)]
 if cache:cmd+=['--bind',str(CACHE),str(CACHE)]
 return cmd+['--']+argv
def env(root,build=False):
 d=dict(PATH='/usr/bin:/bin',HOME='/home/mikers',TMPDIR=str(root/'tmp'),LC_ALL='C',TZ='UTC',GOTOOLCHAIN='local',GOENV='off',GOWORK='off',GOPROXY='off',GOSUMDB='off',CGO_ENABLED='1',CC='/usr/bin/x86_64-linux-gnu-gcc-11',GOMODCACHE='/home/mikers/go/pkg/mod',GOCACHE=str(CACHE),GOROOT=str(GO.parent.parent),GOPATH='/home/mikers/go',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_NO_REPLACE_OBJECTS='1')
 if build:d.update(GOMAXPROCS='1',GOMEMLIMIT='1GiB',GOGC='50')
 return d
def limits(v5,live=False,wall=300,cpu=180):
 return v5.Limits(wall=wall,cpu_soft=cpu,cpu_hard=cpu+5,file_bytes=(64 if live else 512)*1024**2,disk_bytes=(512*1024**2 if live else 4*1024**3),min_free=5*1024**3,rss_bytes=2*1024**3,poll=.01 if live else .05,grace=5,reap=5,cpu=min(os.sched_getaffinity(0)),nice=10)
def build_commands():
 flags=['-p=1','-trimpath','-buildvcs=false','-mod=readonly']
 return [('a',[str(GO),'build',*flags,'-o',str(BUILD/'bin/control-a'),str(R/'sources/control-a.go')]),('b',[str(GO),'test','-c',*flags,'-o',str(BUILD/'bin/control-b.test'),'./TreeDB/mongo_gateway'])]
def run_commands():
 return [('a-negative',[str(BUILD/'bin/control-a'),'child',str(LIVE/'a-negative-data'),'command_wal_relaxed'],{'CONTROL_A_FAIL_CLIENT':'1'},120,90,(2,)),('a-positive',[str(BUILD/'bin/control-a'),str(LIVE/'a-positive-data')],{},240,180,(0,)),('b',[str(BUILD/'bin/control-b.test'),'-test.run','^TestControlBPublicDurable','-test.v','-test.timeout','100s'],{'CONTROL_B_RETAIN_DIR':str(LIVE/'b-data')},120,90,(0,))]
def plan():
 v5=module('v5_ab_plan',V5)
 write(R/'PROTOCOL.json',dict(candidate='79220385186080e77898fcb99c78a8ea15480241',tree='ed39075798b6b5797854a6851ece3996d865a606',product_source_equivalent_to_c660='792 minus c660 is archive/index only',adapter_sha256=sha(__file__),supervisor_sha256=sha(V5),runtime_helper_sha256=sha(OBSERVER),inventory_sha256=sha(R/'source-inventory.json'),source_hashes=EXPECTED,build_commands=build_commands(),build_env=env(BUILD,True),build_limits=dataclasses.asdict(limits(v5)),live_commands=run_commands(),live_env=env(LIVE),live_limits=[dataclasses.asdict(limits(v5,True,x[3],x[4])) for x in run_commands()],sandbox='filesystem readonly except phase output and build-only shared cache; modules readonly; offline',build_guard_limits='shared cache growth excluded from task disk cap; filesystem free guard applies',runtime_observer='owned descendant pid/start/exe bound; actual nonempty env absence plus runtime.gomaxprocs live ELF-symbol reads; sampled only; no stop/ptrace; leader affinity/cgroup retained',scope='unchanged original A/B sources and predicates; no benchmarks; no postmutation B checkpoint; one invocation per arm; no retry; prior preparation failure retained'))
def builds():
 guard();v5=module('v5_ab_build',V5)
 with v5.Supervisor(BUILD) as s:
  for label,target,test in [('a',str(R/'sources/control-a.go'),False),('b','./TreeDB/mongo_gateway',True)]:
   argv=[str(GO),'list','-deps','-json','-mod=readonly']+(['-test'] if test else [])+[target]
   s.run('required-inputs-'+label,sandbox(BUILD,argv,True),str(W),env(BUILD,True),limits(v5))
   text=(BUILD/('required-inputs-'+label)/'stdout.txt').read_text();decoder=json.JSONDecoder();required={}
   while text.strip():
    text=text.lstrip();item,end=decoder.raw_decode(text);text=text[end:]
    assert not item.get('Error') and not item.get('DepsErrors'),item.get('ImportPath')
    directory=pathlib.Path(item['Dir'])
    for key in ('GoFiles','CgoFiles','CFiles','HFiles','SFiles','SysoFiles','EmbedFiles','TestGoFiles','XTestGoFiles','TestEmbedFiles','XTestEmbedFiles'):
     for rel in item.get(key,[]):
      path=directory/rel
      if rel.startswith('/'):path=pathlib.Path(rel)
      assert path.is_file(),str(path)
      required[str(path)]=sha(path)
   write(BUILD/'metadata'/('required-'+label+'.json'),required)
  for name,cmd in build_commands():
   print('BUILD',name,flush=True);s.run('build-'+name,sandbox(BUILD,cmd,True),str(W),env(BUILD,True),limits(v5))
   binary=BUILD/'bin'/('control-a' if name=='a' else 'control-b.test')
   s.run('buildinfo-'+name,sandbox(BUILD,[str(GO),'version','-m',str(binary)]),str(W),env(BUILD,True),limits(v5))
 guard();write(R/'BUILD-COMPLETE.json',dict(candidate='79220385186080e77898fcb99c78a8ea15480241',adapter_sha256=sha(__file__),protocol_sha256=sha(R/'PROTOCOL.json'),binaries={p.name:dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in (BUILD/'bin').iterdir()},preparation_failure='preserved build-a.log and build-results-preparation-failure.json; module packaging error; zero product invocations'))
def runs():
 guard();assert (R/'ROOT-LIVE-RELEASE.txt').is_file(),'Root exact-source/adapter release required'
 v5=module('v5_ab_live',V5);obs=module('runtime_ab',OBSERVER)
 binaries={};samples=[];seen=set()
 for p in (BUILD/'bin').iterdir():
  data=p.read_bytes();out=subprocess.check_output(['/usr/bin/nm',str(p)],text=True)
  addresses=[int(line.split()[0],16) for line in out.splitlines() if line.split()[-1:] == ['runtime.gomaxprocs']];assert len(addresses)==1
  h=sha(p);address=obs.gomax_symbol(data,h,addresses[0]);st=p.stat();binaries[str(p)]=(h,address,(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns))
 def observe(rows,owned):
  for pid,ticks in owned:
   if (pid,ticks) in seen or pid not in rows or rows[pid]['start_ticks']!=ticks:continue
   proc=pathlib.Path('/proc')/str(pid)
   try:
    target=os.readlink(proc/'exe')
    if target not in binaries:continue
    h,address,identity=binaries[target];start=obs.start_identity(pid);st=(proc/'exe').stat()
    if (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)!=identity:raise RuntimeError('owned child ELF changed')
    raw=(proc/'environ').read_bytes()
    if not raw:continue
    assert len(raw)<=obs.ENVIRONMENT_MAX_BYTES
    obs.validate_environment(raw.split(b'\0'),None)
    maps=(proc/'maps').read_text().splitlines()
    if not any(int(x.split()[0].split('-')[0],16)<=address< int(x.split()[0].split('-')[1],16) for x in maps):continue
    fd=os.open(proc/'mem',os.O_RDONLY|os.O_CLOEXEC)
    try:value=struct.unpack('<i',os.pread(fd,4,address))[0]
    finally:os.close(fd)
    if value==0:continue
    assert 0<value<=1024*1024
    # bwrap gives the child a distinct mount namespace. Retain its raw actual
    # cgroup/mount interfaces instead of pretending quota_snapshot's same-mount
    # namespace precondition holds or inferring an equal resource guarantee.
    record=dict(pid=pid,start_ticks=ticks,exe_sha256=h,exe=target,runtime_gomaxprocs=value,GOMAXPROCS_present=False,environment_bytes=len(raw),leader_affinity=sorted(os.sched_getaffinity(pid)),cgroup_membership=(proc/'cgroup').read_text(),mountinfo=(proc/'mountinfo').read_text(),cgroup_namespace=os.readlink(proc/'ns/cgroup'),mount_namespace=os.readlink(proc/'ns/mnt'),cpu_policy_limits='raw actual child interfaces; no derived equal-quota guarantee',sampled_utc=time.time())
    obs.recheck_identity(pid,proc,start,identity);samples.append(record);seen.add((pid,ticks))
    (LIVE/'runtime-samples.json').write_text(json.dumps(samples,indent=2)+'\n')
   except (FileNotFoundError,ProcessLookupError):continue
 with v5.Supervisor(LIVE,admission=observe) as s:
  for name,cmd,extra,wall,cpu,codes in run_commands():
   print('RUN',name,flush=True);childenv=dict(env(LIVE),**extra)
   s.run(name,sandbox(LIVE,cmd),str(W),childenv,limits(v5,True,wall,cpu),accepted_exit_codes=codes)
   log=(LIVE/name/'stdout.txt').read_text()+(LIVE/name/'stderr.txt').read_text()
   if name=='a-negative':assert 'duplicate' in log.lower() and log.count('"event":"load-client-joined"')==4 and 'sentinel-result' not in log and '"insert": "sentinels"' not in log
   elif name=='a-positive':assert log.count('"event":"exact-public-reopen-pass"')==2 and log.count('"event":"persistent-pointer-witness"')==4 and 'control-A-all-profiles-pass' in log
   else:assert 'PASS: TestControlBPublicDurableCrash' in log and 'PASS: TestControlBPublicDurableSyncErrors' in log
 guard();assert samples
 write(R/'RUN-COMPLETE.json',dict(candidate='79220385186080e77898fcb99c78a8ea15480241',adapter_sha256=sha(__file__),protocol_sha256=sha(R/'PROTOCOL.json'),runtime_samples=len(samples),scope='original scoped controls only; process-crash and physical command WAL seam; no power-loss certification; no new value-log sync-failure assertion; no timed comparison'))
if __name__=='__main__':
 {'plan':plan,'build':builds,'run':runs}[sys.argv[1]]()
