#!/usr/bin/python3
"""One-use bindings around accepted #5335 controllers; offline unless run-next."""
import argparse,copy,dataclasses,fcntl,hashlib,importlib.util,json,os,pathlib,shutil,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
BUILD=pathlib.Path('/home/mikers/gomap-5335-final113-build-20261030')
GOMAP_FIXTURE=BUILD/'bin/fixture'
SOURCE=pathlib.Path('/home/mikers/gomap-5335-landing-20261030/worktree');COMMIT='113b8805f6328c7677692e5a7d0c43630c5132f8';TREE='621f93562c197abed6f095e01c174e1b3adb9e87'
OLD=pathlib.Path('/home/mikers/gomap-5335-common-load-matched-attempt-20261030')
BOOT=pathlib.Path('/home/mikers/gomap-5335-close-consumer-build-20261029/reference-bootstrap-959cc5c491-preparation')
SUPERVISOR=pathlib.Path('/home/mikers/gomap-5335-perf-campaign-20261030/supervisor.py')
GO='/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.10.linux-amd64/bin/go'
EXPECTED={str(BUILD/'bin/gateway'):'61068e2a2a63438c6d3e0f3365c70b9b0c312c158204b133fbaa38ddd8e6486c',str(GOMAP_FIXTURE):'e6cb565c553e0c88e72a3d6effd56375eae7dba1b5daa6130ce2bfd7650dd22b',str(BUILD/'fixture-build.json'):'286e96c695e52c2645c0a0fab82b76eac586cbac91ed172c0832a69c746cec15',str(BOOT/'go-ycsb'):'2237d8aeec309b9b4b335b348234d9829594c9101043144a944d9f2868fbc95b',str(BOOT/'fixture'):'5db62e23c20a6cfe82b1e294a3a1156e9d62f2d369c855a89d4bbc9804984e2d',str(BOOT/'reference-control'):'58c79107ccc70dc07c5280debb6c47b911688ed4248b3bb6387855c8aa7e5176',str(BOOT/'mongod.elf'):'d767fb752139fbc8e0e667d7e0c6fe7cdf690e0aa94a51502a32bad8c54a3672','/usr/bin/docker':'87bb910f051879cdf2a4a38e01748cbebeb27f3de962122dfdcbd0a4fbeea4ff'}
IMAGE='mongo@sha256:7abfba0d07c9330373f8173981ea4d09cd8a82cdf0e86ccaf7008848d1d24f62'
APPLICABILITY=pathlib.Path('/home/mikers/gomap-5335-final113-source-20261030/SCOPED-CONTROL-APPLICABILITY.json');APPLICABILITY_SHA='9fafa0467bacb01d41e9286bc2f68cda55855f4b27218bf6a49187b765831f4a'
SCOPED_ACCEPT=pathlib.Path('/home/mikers/gomap-5335-final113-source-20261030/ROOT-PACKET-SCOPED-ACCEPT.json');SCOPED_ACCEPT_SHA='3ed5b6c3a4a0f2808805fc1b67ad0021188f2544ad84d39f8d624ae43f70f8bb'
ACTUAL_CONTROLS=pathlib.Path('/home/mikers/gomap-5335-final-ab-controls-20261030/reviewed-controls.json');ACTUAL_CONTROLS_SHA='c88c4f3514ade98668325f18b0de7a31162985ccd00c6b684a8952e4aaa67633'
def read(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(p,x):
 with pathlib.Path(p).open('x') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
def require(x,msg):
 if not x:raise ValueError(msg)
def git(*args):return subprocess.check_output(['/usr/bin/git','-C',str(SOURCE),*args],text=True).strip()
def source_guard():require(git('rev-parse','HEAD')==COMMIT and git('rev-parse','HEAD^{tree}')==TREE and not git('status','--porcelain') and not git('ls-files','--others','--ignored','--exclude-standard'),'frozen source mismatch/dirty')
def objects(commit):
 return {line.split('\t')[1]:line.split()[2] for line in git('ls-tree','-r',commit).splitlines() if not line.split('\t')[1].startswith('docs/') and not line.split('\t')[1].endswith('.md')}
def artifact_bindings():
 source_guard()
 require(sha(SUPERVISOR)=='2f5be93f1824b0128a3f48d60408490edd735d08ce2e5cd455d0be331138a334','accepted supervisor changed')
 for p,h in EXPECTED.items():require(sha(p)==h,'artifact changed: '+p)
 more=[SUPERVISOR,pathlib.Path(__file__),APPLICABILITY,SCOPED_ACCEPT,ACTUAL_CONTROLS,BUILD/'binding.json',BUILD/'COMPLETE.json',BUILD/'server-build.json',OLD/'run_gomap_B_once.py',OLD/'run_reference_B_once.py',pathlib.Path('/home/mikers/gomap-5335-close-consumer-build-20261029/reference-correctness-e574a46-20261030/support/client-build.json')]
 return dict(EXPECTED,**{str(p):sha(p) for p in more})
def rows():
 return [dict(class_name=cls,pair=pair,arm=arm,name=f'{cls}-pair{pair}-{arm}') for cls in ('relaxed','durable-B') for pair,arm in ((1,'mongodb'),(1,'gomap'),(2,'gomap'),(2,'mongodb'),(3,'mongodb'),(3,'gomap'))]
def policy(addr):return dict(comparison_class='durable-ack-differing-requests',address=addr,write_concern=dict(w=1,journal_requested=None),reviewed_control_a=dict(scope='bson-binary-and-pointer-bearing-prefix',reviewed=False,files={}),reviewed_control_b=dict(scope='public-bson-command-wal-ack-crash-replay',reviewed=False,files={}))
def limits(arm):
 return dict(wall=3600 if arm=='gomap' else 3660,cpu_soft=3600 if arm=='gomap' else 1800,cpu_hard=3610 if arm=='gomap' else 1810,file_bytes=8*1024**3,disk_bytes=32*1024**3,min_free=10*1024**3,rss_bytes=(24 if arm=='gomap' else 12)*1024**3,poll=.1,grace=30,reap=10,cpu=None,nice=0)
def gomap_env(cell,row):
 env=dict(PATH=str(pathlib.Path(GO).parent)+':/usr/bin:/bin',GOROOT=str(pathlib.Path(GO).parent.parent),HOME='/home/mikers',TMPDIR=str(cell),GOENV='off',LC_ALL='C',TZ='UTC',PYTHONDONTWRITEBYTECODE='1',BUILD='false',BUILD_GOYCSB='false',TARGETS='treedb_mongo',MONGODB_MODE='skip',OUT_DIR=str(cell/'output'),GOYCSB_DIR=str(BOOT/'producer-source'),GOYCSB_BIN=str(BOOT/'go-ycsb'),CLIENT_BUILD_MANIFEST='/home/mikers/gomap-5335-close-consumer-build-20261029/reference-correctness-e574a46-20261030/support/client-build.json',FIXTURE_BIN=str(GOMAP_FIXTURE),SERVER_BUILD_MANIFEST=str(BUILD/'server-build.json'),TREEDB_NATIVE_SERVER_BIN=str(SOURCE/'bin/unused-native-not-built'),TREEDB_MONGO_GATEWAY_BIN=str(BUILD/'bin/gateway'),TREEDB_PROFILE='command_wal_'+('durable' if row['class_name']=='durable-B' else 'relaxed'),TREEDB_NATIVE_DOCUMENT_FORMAT='bson',TREEDB_MONGO_DOCUMENT_FORMAT='bson',MONGODB_JOURNAL_REQUEST='unspecified',RECORDCOUNT='100000',OPERATIONCOUNT='10000',THREADCOUNT='16',RUN_REPEATS='1',PHASE_TIMEOUT_SECONDS='600',HELPER_TIMEOUT_SECONDS='180',CHILD_CLEANUP_TIMEOUT_SECONDS='10',TREEDB_MONGO_ADDR='127.0.0.1:27130')
 if row['class_name']=='durable-B':env['COMMON_LOAD_POLICY']=str(cell/'common-load-policy.json')
 return env
def construct():
 require(not (ROOT/'campaign.json').exists(),'packet already constructed; no overwrite')
 bindings=artifact_bindings();(ROOT/'cells').mkdir()
 for row in rows():
  cell=ROOT/'cells'/row['name'];cell.mkdir();out=cell/'output'
  if row['arm']=='gomap':
   request=dict(argv=['/bin/bash',str(SOURCE/'scripts/ycsb_compare_mongodb_treedb.sh')],environment=gomap_env(cell,row),cwd=str(SOURCE))
   if row['class_name']=='durable-B':write(cell/'common-load-policy.unsealed.json',policy('127.0.0.1:27130'))
  else:
   config=read(OLD/'comparison-B/pair1-mongodb-request.json');config['journal_requested']=True if row['class_name']=='durable-B' else None
   if row['class_name']=='durable-B':config['common_load']=policy('127.0.0.1:27018')
   else:config.pop('common_load',None)
   write(cell/'reference-preparation-request.unsealed.json',config)
   request=dict(argv=['/usr/bin/python3','-B',str(SOURCE/'scripts/ycsb_mongodb_reference.py'),'run',str(out),'--docker','/usr/bin/docker'],environment=dict(PATH='/usr/bin:/bin',HOME='/home/mikers',TMPDIR=str(cell),LC_ALL='C',TZ='UTC',PYTHONDONTWRITEBYTECODE='1'),cwd=str(SOURCE))
  request.update(row,limits=limits(row['arm']),status='UNSEALED: no runtime authority',scope='fresh final-source matched arm; preserved full raw lifecycle/error/runtime/state/Close evidence; no retry')
  write(cell/'request.unsealed.json',request)
 write(ROOT/'campaign.json',dict(schema_version=1,status='UNSEALED',source_commit=COMMIT,source_tree=TREE,image=IMAGE,bindings=bindings,order=rows(),global_wall_seconds=43920,counts=dict(load=100000,run=10000,workers=16,read=.95,update=.05,fields=10,field_bytes=100),setup=dict(relaxed='full j-omitted load and census; no common-load policy',durable_B='j-omitted common load/census; public same-owner j:true sentinel; timed Mongo j:true versus durable GoMap j omitted'),performance_runtime='GOMAXPROCS absent; inherited allowed affinity/quota; nice0; actual runtime observations required',scope='offline construction only, no service/client/Docker command invoked'))
 write(ROOT/'CONTROLS-REQUIRED.json',dict(status='UNSEALED',source_commit=COMMIT,reviewed_control_a=None,reviewed_control_b=None,actual_build_source_commit=None,scope='Supply original reviewed actual A/B file maps including source/review/result hashes; nulls fail closed. Control source must be bytewise equivalent or pass exact pinned coordinator-accepted source applicability; original identities remain actual.'))
 print('CONSTRUCTED twelve unsealed arm requests; zero runtime')
def control_bindings(controls):
 actual=controls.get('source_commit');require(isinstance(actual,str) and len(actual)==40,'missing actual control source')
 if objects(actual)!=objects(COMMIT):
  # Only this exact reviewed delta admits source-scoped reuse; gate() below
  # still requires full final gateway-to-landed non-document object equality.
  for p,h in ((APPLICABILITY,APPLICABILITY_SHA),(SCOPED_ACCEPT,SCOPED_ACCEPT_SHA),(ACTUAL_CONTROLS,ACTUAL_CONTROLS_SHA)):
   require(sha(p)==h,'changed scoped applicability/control receipt '+str(p))
  proof=read(APPLICABILITY);accepted=read(SCOPED_ACCEPT)
  require(accepted.get('status')=='ACCEPT_SCOPED' and accepted.get('reviewer')=='ROOT','unaccepted scoped source applicability')
  require(accepted.get('receipt')==dict(path=str(APPLICABILITY),sha256=APPLICABILITY_SHA),'scoped acceptance proof binding differs')
  require(accepted.get('source_commit')==COMMIT and accepted.get('source_tree')==TREE and proof.get('final_source_commit')==COMMIT and proof.get('final_source_tree')==TREE,'wrong scoped final source/tree')
  require(proof.get('status')=='PASS_SCOPED_SOURCE_PROOF_PENDING_COORDINATOR_ACCEPTANCE' and proof.get('actual_control_source_commit')==actual and controls==read(ACTUAL_CONTROLS),'wrong actual reviewed control source/map')
  baseline=proof['baseline_gateway_source_commit']
  def inputs(commit):
   return {line.split('\t')[1]:dict(mode=line.split()[0],object=line.split()[2]) for line in git('ls-tree','-r',commit).splitlines() if not line.split('\t')[1].startswith('docs/') and not line.split('\t')[1].endswith('.md')}
  before,after=inputs(baseline),inputs(COMMIT);require(inputs(actual)==before,'actual controls differ from reviewed baseline')
  changed=[dict(path=p,before=before.get(p),after=after.get(p)) for p in sorted(before.keys()|after.keys()) if before.get(p)!=after.get(p)]
  require(changed==proof['changed_nondoc_objects'],'extra/missing/mode/blob scoped source delta')
  delta=proof['production_delta'];require(sha(delta['path'])==delta['sha256'],'changed exact production delta')
  def blob_sha(commit,path):return hashlib.sha256(subprocess.check_output(['/usr/bin/git','-C',str(SOURCE),'show',commit+':'+path])).hexdigest()
  require(blob_sha(baseline,'TreeDB/collections/api.go')==proof['baseline_api_sha256'] and sha(SOURCE/'TreeDB/collections/api.go')==proof['final_api_sha256'],'wrong scoped API bytes')
  for route in proof['route_sources']:
   require(blob_sha(baseline,route['path'])==route['baseline_sha256'] and sha(SOURCE/route['path'])==route['final_sha256'],'changed scoped route '+route['path'])
 for key,scope in (('reviewed_control_a','bson-binary-and-pointer-bearing-prefix'),('reviewed_control_b','public-bson-command-wal-ack-crash-replay')):
  x=controls.get(key);require(isinstance(x,dict) and x.get('reviewed') is True and x.get('scope')==scope and len(x.get('files',{}))>=3,'missing/unaccepted '+key)
  for p,h in x['files'].items():require(pathlib.Path(p).is_absolute() and len(h)==64 and sha(p)==h,'changed control file '+p)
 return controls
def check_seal():
 campaign=read(ROOT/'campaign.json');seal=read(ROOT/'SEALED.json');require(sha(__file__)==campaign['bindings'][str(pathlib.Path(__file__))],'adapter changed')
 for p,h in campaign['bindings'].items():require(sha(p)==h,'binding changed '+p)
 for p,h in seal['files'].items():require(sha(ROOT/p)==h,'sealed packet changed '+p)
 source_guard();return campaign,seal
def seal(controls_path):
 require(not (ROOT/'SEALED.json').exists(),'already sealed; no reset');controls=control_bindings(read(controls_path));campaign=read(ROOT/'campaign.json');require(artifact_bindings()==campaign['bindings'],'prepared bindings changed');write(ROOT/'accepted-controls.json',controls)
 # Offline maintained API only: each child can inspect Git/Go buildinfo, never Docker/product.
 for row in campaign['order']:
  cell=ROOT/'cells'/row['name'];request=read(cell/'request.unsealed.json');request['status']='sealed request; runtime gate still required';write(cell/'request.json',request)
  if row['arm']=='gomap':
   if row['class_name']=='durable-B':
    p=read(cell/'common-load-policy.unsealed.json');p.update({k:controls[k] for k in ('reviewed_control_a','reviewed_control_b')});write(cell/'common-load-policy.json',p)
  else:
   config=read(cell/'reference-preparation-request.unsealed.json')
   if row['class_name']=='durable-B':config['common_load'].update({k:controls[k] for k in ('reviewed_control_a','reviewed_control_b')})
   write(cell/'reference-preparation-request.json',config)
   with (cell/'prepare.stdout').open('xb') as out,(cell/'prepare.stderr').open('xb') as err:
    subprocess.run(['/usr/bin/python3','-B',str(SOURCE/'scripts/ycsb_mongodb_reference_prepare.py'),str(cell/'reference-preparation-request.json'),str(cell/'output')],cwd=SOURCE,env=dict(PATH='/usr/bin:/bin',HOME='/home/mikers',LC_ALL='C',TZ='UTC',PYTHONDONTWRITEBYTECODE='1'),stdout=out,stderr=err,timeout=180,check=True)
 files={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file() and p.name not in ('SEALED.json','packet.lock') and '__pycache__' not in p.parts}
 write(ROOT/'SEALED.json',dict(status='SEALED: runtime still gated',files=files,controls_sha256=sha(ROOT/'accepted-controls.json'),source_commit=COMMIT));print('SEALED; no runtime')
def gate(value):
 require(value.get('authorized') is True and value.get('predecessor_merged') is True and value.get('harness_landed') is True,'runtime/merge gates missing')
 require(value.get('build_source_commit')==COMMIT and value.get('gateway_sha256')==EXPECTED[str(BUILD/'bin/gateway')],'gate source/ELF mismatch')
 final=value.get('landed_commit');require(isinstance(final,str) and len(final)==40 and objects(final)==objects(COMMIT),'all non-document tracked inputs not bytewise equivalent to landed head')
 subprocess.run(['/usr/bin/git','-C',str(SOURCE),'merge-base','--is-ancestor',final,'refs/remotes/origin/main'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 for key in ('review_receipt','ci_receipt','merge_receipt'):
  r=value[key];require(sha(r['path'])==r['sha256'],'gate receipt changed '+key)
 return value

def summarize(cell,row):
 out=cell/'output';directory=out/('treedb_mongo' if row['arm']=='gomap' else 'mongodb');files={}
 for p in directory.iterdir():
  if p.is_file() and (p.name.endswith(('.close.json','.launch.json','.cleanup.json','.out','.err')) or p.name in ('runtime.json','lifecycle.json','public-sentinel.json','owner-close.json')):files[str(p.relative_to(cell))]=sha(p)
 require(all((directory/(phase+suffix)).is_file() for phase in ('load','run_1') for suffix in ('.out','.err','.close.json','.launch.json')),'missing original phase evidence')
 if row['arm']=='gomap':
  validation=read(out/'validation.json');require(validation['status']=='validated-consumer-evidence','maintained consumer validation did not accept actual evidence')
  require((directory/'lifecycle.json').is_file() and (directory/'runtime.json').is_file(),'missing lifecycle/runtime result')
  lifecycle=read(directory/'lifecycle.json');runtime=read(directory/'runtime.json')
 else:
  require((out/'reference-complete.json').is_file() and not (out/'reference-incomplete.json').exists() and not (out/'failure.json').exists(),'reference failed/incomplete')
  validation=json.loads((cell/'launcher/stdout.txt').read_text().strip().splitlines()[-1]);require(validation['status']=='validated-reference-lifecycle-evidence','maintained reference validation did not accept actual evidence')
  lifecycle={name:read(directory/(name+'.close.json')) for name in ('server','reopened','fixture-write','fixture-reopened')};runtime=read(out/'reference-runtime.json')
 if row['class_name']=='durable-B':require((directory/'public-sentinel.json').is_file(),'missing actual common-load sentinel')
 phases={phase:dict(close=read(directory/(phase+'.close.json')),launch=read(directory/(phase+'.launch.json')),cleanup=read(directory/(phase+'.cleanup.json'))) for phase in ('load','run_1')}
 snapshots={name:dict(path=str(directory/(name+'.json')),sha256=read(directory/(name+'.close.json'))['artifacts_sha256'][name+'.json']) for name in ('snapshot_loaded','snapshot_preclose','snapshot_reopened')}
 return dict(row,validation=validation,files=files,manifest_sha256=sha(out/'manifest.json'),lifecycle=lifecycle,runtime=runtime,phases=phases,snapshots=snapshots,sentinel=read(directory/'public-sentinel.json') if row['class_name']=='durable-B' else None,scope='raw maintenance/timing scopes retained; typed random preservation only; reference Close is observed process shutdown')

def run_next(gate_path):
 with (ROOT/'packet.lock').open('a+') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB) # This packet only; no host lease/quiet gate.
  campaign,seal=check_seal();g=gate(read(gate_path));control_bindings(read(ROOT/'accepted-controls.json'))
  require(not (ROOT/'STOPPED.json').exists(),'prior failure; no retry')
  if not (ROOT/'campaign-start.json').exists():write(ROOT/'campaign-start.json',dict(boot_id=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),monotonic=time.monotonic(),gate_path=str(pathlib.Path(gate_path).resolve()),gate_sha256=sha(gate_path),source_commit=COMMIT))
  start=read(ROOT/'campaign-start.json');require(start['boot_id']==pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'boot changed; no budget reset');require(time.monotonic()+3780<=start['monotonic']+campaign['global_wall_seconds'],'global wall budget exhausted')
  for row in campaign['order']:
   cell=ROOT/'cells'/row['name']
   if (cell/'COMPLETE.json').exists():continue
   require(not (cell/'STARTED.json').exists(),'same-job arm already started; no duplicate/retry')
   r=read(cell/'request.json');write(cell/'STARTED.json',dict(pid=os.getpid(),start_ticks=int(pathlib.Path('/proc/self/stat').read_text().split(') ')[1].split()[19]),monotonic=time.monotonic(),request_sha256=sha(cell/'request.json'),seal_sha256=sha(ROOT/'SEALED.json'),gate_sha256=sha(gate_path)))
   spec=importlib.util.spec_from_file_location('accepted_perf_supervisor',SUPERVISOR);b=importlib.util.module_from_spec(spec);sys.modules[spec.name]=b;spec.loader.exec_module(b)
   try:
    with b.Supervisor(cell) as supervisor:result=supervisor.run('launcher',r['argv'],r['cwd'],r['environment'],b.Limits(**r['limits']))
    write(cell/'FINAL.json',result);summary=summarize(cell,row);write(cell/'COMPLETE.json',summary);print('COMPLETE',row['name'],flush=True)
   except BaseException as exc:
    write(ROOT/'STOPPED.json',dict(cell=row['name'],error=repr(exc),status='FAILED_STOP_NO_RETRY'));raise
   return
  print('ALL TWELVE COMPLETE')
def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=('construct','preflight','seal','run-next'));p.add_argument('input',nargs='?');a=p.parse_args()
 if a.mode=='construct':construct()
 elif a.mode=='preflight':
  campaign=read(ROOT/'campaign.json');require(artifact_bindings()==campaign['bindings'],'bindings changed');require(len(campaign['order'])==12 and len({r['name'] for r in campaign['order']})==12,'order/count');print('PASS: twelve unsealed requests and artifact/source bindings; runtime remains refused' if not (ROOT/'SEALED.json').exists() else 'PASS: artifact/source bindings; use explicit runtime gate')
 elif a.mode=='seal':seal(pathlib.Path(a.input))
 else:run_next(pathlib.Path(a.input))
if __name__=='__main__':main()
