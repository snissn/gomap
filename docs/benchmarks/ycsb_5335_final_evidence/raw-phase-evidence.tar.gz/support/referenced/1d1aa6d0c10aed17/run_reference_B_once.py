"""Bounded one-use reference invocation; no retry or cleanup of other owners."""
import sys,pathlib,json,os,hashlib
sys.path.insert(0,'/home/mikers/gomap-5335-perf-campaign-20261030')
import supervisor as b
ROOT=pathlib.Path(__file__).resolve().parent
H=pathlib.Path('/home/mikers/gomap-5335-common-load-comparison-20261030')
out=pathlib.Path(sys.argv[1]).resolve();control=ROOT/('B-'+out.name+'-controller');control.mkdir()
m=json.loads((out/'manifest.json').read_text());assert m['bounded_container'] is True and m['require_client_runtime_observation'] is True
argv=['/usr/bin/python3',str(H/'scripts/ycsb_mongodb_reference.py'),'run',str(out),'--docker','/usr/bin/docker']
env=dict(PATH='/usr/bin:/bin',HOME='/home/mikers',TMPDIR=str(control),LC_ALL='C',TZ='UTC',PYTHONDONTWRITEBYTECODE='1')
limits=b.Limits(wall=m['deadlines']['outer_seconds']+60,cpu_soft=1800,cpu_hard=1810,file_bytes=8*1024**3,disk_bytes=32*1024**3,min_free=10*1024**3,rss_bytes=12*1024**3,poll=.1,grace=30,reap=10,cpu=None,nice=0)
(control/'request.json').write_text(json.dumps(dict(argv=argv,environment=env,manifest_sha256=hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),scope='controller12GiB/1800CPU plus eachof4sequentialsinglemongod12GiB/449soft450hardCPU; noCPUquota/affinitychanges; no generic aggregatewatchdog; rawartifactdisk coversbinddata notDockerrootlayer'),indent=2)+'\n')
print(json.dumps(dict(event='actual-reference-start',output=str(out),campaign_id=m['campaign_id'],write_concern=m['write_concern'])),flush=True)
try:
 with b.Supervisor(ROOT) as s:result=s.run('B-'+out.name+'-supervision',argv,str(H),env,limits)
 (control/'FINAL.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(dict(event='actual-reference-complete',output=str(out),result=result['reason'])),flush=True)
except BaseException as error:
 (control/'FAILED.json').write_text(json.dumps(dict(status='failed-stop-no-retry',error=repr(error)))+'\n')
 raise
