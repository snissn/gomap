# PR5344 bounded review successor

**ACCEPT for the scoped source repair and completed local checks**, subject to coordinator-owned exact-head hosted CI/review/performance gates. No push or remote mutation performed.

Final candidate: `d70ad77e7cfb4996a5c4dc25a15d588c83542791`, tree `c9f902337e668350d288198bf517e8a43139f862`, parent `1a899e959f282bf7d01eb07cfc2cfdf0d29bc39e`. Isolated worktree: `/home/mikers/gomap-5344-review-successor-20261030/worktree`; final worktree clean. Eight files. Only production change is the three-line format rejection in TreeDB/collections/api.go:12082; the other seven files are tests and verification documentation. Root reviewed final source with no further feature expansion. FINAL.patch and FINAL-SOURCE-HASHES.json bind the full candidate.

## Three actionable findings

1. **Confirmed/fixed: trusted BSON on native JSON.** NativewireInsertBatchNoResultIDs bypassed the legacy trusted-BSON format check on the native role. It now rejects trustedValidBSON unless normalized document format is BSON, before any native preparation/publication. Error text matches the legacy contract. New maintained external public test covers six native/legacy x default-JSON/explicit-JSON/BSON cases. Native setup uses real treedb.Open, explicit cow_btree, actual Stats mode, NativeSemanticBackend, HasNativeSemanticBridge and manager native-role assertions. Existing seed remains byte-identical; rejected ID absent; row count and next command-WAL LSN unchanged; flagfalse ordinary inserts and flagtrue BSON remain accepted. All closes checked.
2. **Confirmed/fixed: late signal could hit restored handler.** The close test's timer could fire after close_server restored the previous/default handler. It now reads child close-start from the wait callback while deferral is active, signals the parent synchronously, then releases the blocked child. The fixture uses os.write/os.read so the signal handler cannot reenter Python's buffered stdout. No timer/scheduling assumption remains in this close test. The separate interrupt test retains its timer because it cancels/joins before restoring its handler; threading remains used.
3. **Confirmed/fixed: mode assertion before cleanup.** runNativeBSONLifecycle now registers closeOriginal before checking Stats mode. A mode-check failure therefore closes the successfully opened database. No product cleanup behavior changed.

## Four optional review comments

- **Addressed:** mocked run_profile integration covers actual verifier argv/exit and all seven checked readback fields, invalid JSON and nonzero verifier exit. The successful mock is green only with exact readback. No real load/100k campaign is run by these mocks.
- **Addressed:** new COW grouped fallback cases seed an existing row, conflict by ID or unique email, and retain the independent valid sibling. Six combinations across the three production profiles check member outcomes, exactly two fallback requests, rows/indexes, checkpoint and reopen.
- **Addressed by narrower name/claim:** TestCOWNativewireJSONSyncedACKProcessExitRecovery describes actual process-exit recovery after synced requests. Its child selector and maintained verification.md reference are updated. No independent pre-reply checkpoint-sync proof is claimed; historical receipts keep original names.
- **Addressed:** successful checkpoint-retry branch additionally reads pending/value after reopen. The close-failure branch retains its narrower expectation.

## Actual validation

The actual public-contract RED used exact1a production plus the maintained external test. Native default-JSON and explicit-JSON cases failed specifically because trusted JSON returned nil. Legacy default-JSON/JSON/BSON and native BSON passed. Raw test entry and exact failure lines are in test-output/red-format-external-fixed/stdout.txt. No compile/setup failure is counted as behavioral RED.

The same test bytes SHA256 `6c7e7bfc07b23b28305cab703188e622e9443a03b58f112c1fe6575d87df7698` passed all six cases with only the production guard added. Normal GREEN ran at5d10bfb5473c08d3a0bfc9af7b43a0e22d868989; finald70 differs solely by the three Python child-script literals correcting buffered signal-handler I/O. Production and Go test objects are identical. This subset equality is checked explicitly; no whole-candidate relabeling. Normal contract runtime1.389s; total command including compilation63.516s.

At exact finald70:

- Focused external format-contract race: all six cases PASS, no race report; test process2.619s, whole guarded command81.731s.
- Corrected Python suite: all10 methods PASS, including10 run_profile verifier subcases and deterministic signal-close lifecycle;0.245s test runtime.
- New COW existing-conflict fallback: six combinations PASS through checkpoint/reopen,3.30s.
- Renamed synced-ACK process-exit recovery fixture PASS,1.02s. Nativewire package's selected test runtime4.322s, total command35.222s.

Root-package test-only mode-cleanup and pending-readback additions were source-reviewed but deliberately not compiled/run locally after Root's scope refinement; they require final-head full CI. No full internal collections test variant or broad race suite is claimed. Coordinator-reported1a54CI passes/PRIMARY PASS belong to1a, not finald70. New-head CI remains required. All older cost FAILs remain retained; no gate, threshold, durability requirement or accepted failure was waived.

## Bounds, custody and actual cleanup

The unchanged historical_close_bounded_v5.py SHA c0a211a6edb85f282257e384cb4d1d737fa7d46c0c05d1bd451a43345078f97b supervised every command. Go1.26.10, offline readonly modules, p1/trimpath/buildvcs=false/mod=readonly/count1, GOMAXPROCS1/GOMEMLIMIT1GiB/GOGC50 disclosed. Task-specific fresh /home fallback was used because /mnt/fast4tb had zero available space. Source/module paths readonly in bwrap; only test-output and the explicitly owned build cache writable. Cache custody was granted by Root and released after terminal race success. No compiler/product process remains owned.

Corrected compiler job caps:300s wall,180/185s CPU,3GiB RSS,4GiB task output,512MiB file,5GiB free, CPU0/nice10,10ms watchdog, TERM5/KILL/reap5. The sole resource correction from2GiB to3GiB applied to bounded build/test execution, not performance acceptance. Shared cache growth is excluded from task disk cap; the filesystem-free guard applies. TEST-PLAN.json and raw start/terminal receipts retain exact commands/env/caps. Elapsed values are administrative, not benchmark evidence.

Root go.mod/go.sum are present. Bounded go-list resolved6,552 required dependency/test/embed inputs and required every file to exist before the corrected compilation. REQUIRED-INPUTS.json retains the initial inventory; REQUIRED-INPUTS-GREEN.json and REQUIRED-INPUT-DELTA.json bind the two expected changes (api guard and external test). All other required inputs were rehashed unchanged.

All completed validation commands have terminal reasoncomplete, no observer errors, no surviving identities, direct child reaped and certain custody. Their max watchdog gaps are below0.1s. The intentionally failing RED has expected exit1, but its behavioral interpretation comes from actual test-entry/output assertions, not the exit code alone. Compiler/setup failures and the Python failure are separately retained below. No universal ephemeral-child sampling or power-loss claim is made.

## Every unsuccessful attempt retained

- **Module preparation failure:** initial Git2.34 sparse setup treated --cone as a pattern and omitted root go.mod; command failed before compilation/test entry. Original raw/terminal retained at test-output/preparation-missing-root-module (original terminal label remainsred-format). Explicit init --cone then set corrected checkout, and root/module/embed existence was validated before the next Go command.
- **Internal test compile RSS STOPPED:** test-output/red-format,83.562s, RSS2,148,859,904B just above2GiB, no tests entered, no behavioral RED.
- **Internal test compile CPU STOPPED:** test-output/red-format-3gib,180.364s, aggregateCPU180.064s, RSS2,956,132,352B, no tests entered, no behavioral RED. Root then approved the external maintained public-contract test to avoid rebuilding unrelated internal tests. No wider local internal collections rerun followed.
- **External helper compile failure:** test-output/red-format-external exited before test entry due an err redeclaration introduced while making the fixture external. Exact failing source retained as RED-TRUSTED-BSON-TEST-external-compile-failure.go; fixed before the actual frozen RED.
- **Behavioral RED:** the two native JSON cases failed as specified above; retained unchanged.
- **Python fixture failure at5d10:** signal interrupting buffered ready-print caused handler print reentrancy. test-output/green-python retains trace/raw/terminal; PYTHON-FAILURE-SOURCE.py retains the exact source. Only three fixture script literals changed to low-level I/O. Corrected suite passed atd70. Production GREEN was not repeated.

No behavioral product control, benchmark, comparator or CI was retried toward a favorable acceptance result. No new A/B runtime was performed: the original final-source A/B packet remains separately bound to actual792203; its applicability across this production delta is a narrow route/source review owned by harness_finish/Root.

## Native handle format read

The new pre-producer-lock format read is from the native handle's immutable opening metadata. native_existing.go:23 copies captured metadata and:31 installs a value copy. Native scalar/vector/text index DDL does not write that handle's c.meta: CreateIndex(api.go:4491), dropIndexes(:4880), CreateVectorIndex(:4668), DropVectorIndex(:4755) and text_catalog.go:22/:169 dispatch before legacy assignments. native_index_ddl.go:847/:869/:885 calls mutateIndexFamilies;:246 captures current schema and:286/:304/:329/:346 constructs operation-private metadata, then publishes and returns logical.meta.copy(:565/:569). The file's p.meta assignment(:70) is a private nativeIndexMutation, not Collection metadata. No native-path c.meta/owner.meta assignment or mutable &c.meta alias was found. The copied scalar DocumentFormat remains unchanged by index-family DDL. No concurrent native DDL writer to this field was identified; no extra race campaign or source change was warranted.
