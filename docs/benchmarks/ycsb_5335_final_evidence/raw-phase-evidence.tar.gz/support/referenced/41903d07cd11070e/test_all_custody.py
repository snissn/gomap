"""Focused historical helper source custody controls, no product/archive execution."""
import hashlib,importlib.util,json,pathlib,unittest
from unittest.mock import patch
P=pathlib.Path;ROOT=P(__file__).parent
SOURCE=P('/home/mikers/gomap-5335-final-raw-packaging-20261030/package_final_raw.py')
spec=importlib.util.spec_from_file_location('packager',SOURCE);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
class ExactHelperCustody(unittest.TestCase):
 def setUp(self):self.cases=p.custody_cases();self.helper=p.historical_helper_cases()
 def call(self,c,auth=None,field=None,path=None,expected=None):
  a=c['authorities'][0] if auth is None else auth
  return p.custody_reference(path or c['original_path'],expected or c['expected_sha256'],a['path'],a['field'] if field is None else field,self.cases)
 def test_all_nine_actual_historical_helper_edges_export_exact_bytes(self):
  for c in self.helper:
   for auth in c['authorities']:
    with self.subTest(case=c['id'],field=auth['field']):
     target,raw,disposition=self.call(c,auth);self.assertEqual(p.digest(target),c['expected_sha256']);self.assertEqual(target.stat().st_size,c['retained_file']['bytes']);self.assertFalse(raw);self.assertFalse(disposition['qualifying']);self.assertEqual(disposition['kind'],'EXACT_HISTORICAL_HELPER_SOURCE');self.assertIn('does not accept the current helper',disposition['qualification'])
 def test_wrong_authority_rejected(self):
  c=self.helper[0]
  with self.assertRaisesRegex(ValueError,'unreviewed authority/field'):self.call(c,auth=dict(path=str(ROOT/'unreviewed.json'),field=c['authorities'][0]['field']))
 def test_wrong_field_rejected(self):
  with self.assertRaisesRegex(ValueError,'unreviewed authority/field'):self.call(self.helper[0],field='/references/0')
 def test_wrong_authority_hash_rejected(self):
  c=self.helper[0];auth=c['authorities'][0]['path'];original=p.digest
  with patch.object(p,'digest',side_effect=lambda path:'0'*64 if str(path)==auth else original(path)):
   with self.assertRaisesRegex(ValueError,'changed original custody authority'):self.call(c)
 def test_wrong_export_hash_rejected(self):
  c=self.helper[0];target=c['retained_file']['path'];original=p.digest
  with patch.object(p,'digest',side_effect=lambda path:'0'*64 if str(path)==target else original(path)):
   with self.assertRaisesRegex(ValueError,'changed exact retained custody bytes'):self.call(c)
 def test_wrong_export_size_rejected(self):
  c=self.helper[0];c['retained_file']['bytes']+=1;cases=[x for x in self.cases if x['id']!=c['id']]+[c]
  with self.assertRaisesRegex(ValueError,'changed exact retained custody bytes'):p.custody_reference(c['original_path'],c['expected_sha256'],c['authorities'][0]['path'],c['authorities'][0]['field'],cases)
 def test_unknown_old_hash_never_aliased_and_fails_digest(self):
  c=self.helper[0];target,raw,d=self.call(c,expected='1'*64);self.assertEqual(target,SOURCE);self.assertIsNone(d)
  with self.assertRaisesRegex(ValueError,'explicit reference digest differs'):p.check_reference_hash(target,'1'*64,{'sha256':p.digest(SOURCE)})
 def test_other_path_never_aliased_and_mismatch_rejects(self):
  c=self.helper[0];other=P(__file__);target,raw,d=self.call(c,path=other);self.assertEqual(target,other);self.assertIsNone(d)
  with self.assertRaisesRegex(ValueError,'explicit reference digest differs'):p.check_reference_hash(target,c['expected_sha256'],{'sha256':p.digest(other)})
 def test_current_actual_source_keeps_new_identity(self):
  c=self.helper[0];current=p.digest(SOURCE);target,raw,d=self.call(c,expected=current);self.assertEqual(target,SOURCE);self.assertIsNone(d);self.assertNotIn(current,[x['expected_sha256'] for x in self.helper]);p.check_reference_hash(target,current,{'sha256':current})
 def test_original_four_cases_remain_exact(self):
  base=[dict(c,authorities=[a for a in c['authorities'] if not a.get('historical_quote')]) for c in self.cases[:4]];self.assertEqual(base,json.loads(p.CUSTODY_RECEIPT.read_text())['cases']);self.assertEqual(len(self.cases),9);self.assertEqual(p.digest(p.CUSTODY_RECEIPT),p.CUSTODY_SHA256)
 def test_ordinary_malformed_json_still_rejects(self):
  fixture=ROOT/'ordinary-malformed.json';fixture.write_text('{malformed')
  with self.assertRaises(json.JSONDecodeError):p.read(fixture)
 def test_full_selected_receipt_graph_historical_edges_covered(self):
  graph=json.loads(P('/home/mikers/gomap-5335-final-helper-custody-completion-20261031/REFERENCE-GRAPH.json').read_text());covered=[];context=[]
  for edge in graph['edges']:
   if edge['schema']=='path_hash_map':
    self.assertEqual(edge['authority_sha256'],'bf6fbd3ef6a6b7a944e724d99867db1584b6e5a741c6bf1bf1c3b7475de62cae');self.assertEqual(edge['expected'],'e33d9c30de7de2ef1afe726eb2858c2a81ed2116664ba2bacfe3157ba7f59e04');context.append(edge);continue
   if edge['authority'].endswith('/ROOT-FINAL-HELPER-CUSTODY-ACCEPT.json'):
    self.assertEqual(edge['field'],'/references/0');self.assertEqual(edge['expected'],'0d7323ce79d5311d0e870c26e8ea3692c5379133fba33bc168b7b411a4e29187');context.append(edge);continue
   target,raw,d=p.custody_reference(SOURCE,edge['expected'],edge['authority'],edge['field'],self.cases)
   self.assertIsNotNone(d);self.assertFalse(d['qualifying']);self.assertEqual(p.digest(target),edge['expected']);covered.append(edge)
  self.assertEqual(len(covered),8);self.assertEqual(len(context),2)
  self.assertTrue(any(x['expected'].startswith('5c459') and x['field']=='/packager' for x in covered))
 def test_all_seven_actual_precheck_quote_fields(self):
  failure=json.loads((ROOT/'ALL-REFERENCE-CUSTODY-AUDIT.json').read_text())['failures'];tuples=[x for x in failure if x['kind']=='CUSTODY_TUPLE_REJECTED'];self.assertEqual(len(tuples),7)
  for x in tuples:
   with self.subTest(field=x['field']):
    target,raw,d=p.custody_reference(x['path'],x['expected'],x['authority'],x['field'],self.cases)
    self.assertIn('historical_quote_scope',d);self.assertTrue(d['original_authority']['historical_quote'])
    if x['expected'].startswith('63c018'):self.assertIsNone(target);self.assertFalse(d['qualifying']);self.assertFalse(raw)
    else:
     self.assertEqual(p.digest(target),x['expected'])
     self.assertEqual(raw,x['expected'].startswith('86cc54'))
     if raw:self.assertFalse(d['qualifying'])
 def test_quote_does_not_allow_adjacent_or_unknown_authority(self):
  c=self.cases[0];auth=next(x for x in c['authorities'] if x.get('historical_quote'))
  with self.assertRaisesRegex(ValueError,'unreviewed authority/field'):p.custody_reference(c['original_path'],c['expected_sha256'],auth['path'],'/reference_edges/383',self.cases)
  with self.assertRaisesRegex(ValueError,'unreviewed authority/field'):p.custody_reference(c['original_path'],c['expected_sha256'],ROOT/'unknown.json',auth['field'],self.cases)
 def test_no_duplicate_disposition_identity_or_authority(self):
  identities=[(x['original_path'],x['expected_sha256']) for x in self.cases];self.assertEqual(len(identities),len(set(identities)))
  for c in self.cases:
   keys=[(a['path'],a['field']) for a in c['authorities']];self.assertEqual(len(keys),len(set(keys)))
 def test_existing_continuation_and_current_reference_checks_unchanged(self):
  import ast
  def fs(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
  old,new=fs(ROOT/'package_final_raw.py.before'),fs(SOURCE)
  for key in old.keys()-{'custody_cases','custody_reference','historical_helper_cases'}:self.assertEqual(old[key],new[key],key)
if __name__=='__main__':unittest.main(verbosity=2)
