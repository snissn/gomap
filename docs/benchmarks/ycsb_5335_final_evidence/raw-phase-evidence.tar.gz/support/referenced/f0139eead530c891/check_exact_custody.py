#!/usr/bin/python3
"""Focused offline custody/negative controls; creates no campaign or archive."""
import copy, hashlib, importlib.util, json, pathlib, unittest
from unittest import mock
P=pathlib.Path
SOURCE=P('/home/mikers/gomap-5335-final-raw-packaging-20261030/package_final_raw.py')
s=importlib.util.spec_from_file_location('packager',SOURCE);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class ExactCustody(unittest.TestCase):
    def setUp(self): self.cases=m.custody_cases()
    def apply(self,cases,index=0,authority_index=0):
        c=cases[index];a=c['authorities'][authority_index]
        return m.custody_reference(P(c['original_path']),c['expected_sha256'],P(a['path']),a['field'],cases)
    def test_all_seven_exact_authority_fields(self):
        count=0
        for i,c in enumerate(self.cases):
            for j,a in enumerate(c['authorities']):
                with self.subTest(case=c['id'],field=a['field']):
                    target,raw,d=self.apply(self.cases,i,j);count+=1
                    self.assertEqual(d['original_authority'],a)
                    if c['kind']=='STALE_UNAVAILABLE_NON_QUALIFYING':
                        self.assertIsNone(target);self.assertFalse(d['qualifying']);self.assertEqual(c['expected_sha256'][:8],'63c018e3')
                    else:
                        self.assertEqual(m.digest(target),c['expected_sha256']);self.assertEqual(target.stat().st_size,c['retained_file']['bytes'])
                        self.assertEqual(raw,c['kind']=='EXACT_RAW_NEGATIVE_JSON')
        self.assertEqual(count,7)
    def test_retired_checkout_not_recreated_and_exact_copy_survives(self):
        self.assertFalse(P(self.cases[0]['original_path']).exists())
        t,_,_=self.apply(self.cases);self.assertNotEqual(str(t),self.cases[0]['original_path'])
    def test_historical_git_export_is_exact_and_separately_named(self):
        c=self.cases[1];t,_,d=self.apply(self.cases,1)
        self.assertEqual(m.digest(t),'058aa15fc390e85cb84e2f0cb8e5b36f55810fde5df743569b00b296c0cac877')
        self.assertEqual(d['git_provenance']['commit'],'1c0d123da2307ed4b59280d6a4e02aa14262acab');self.assertNotEqual(str(t),c['original_path'])
    def test_wrong_authority_hash_rejected(self):
        c=copy.deepcopy(self.cases);c[0]['authorities'][0]['sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'changed original custody authority'):self.apply(c)
    def test_unknown_authority_and_wrong_field_rejected(self):
        c=self.cases[0];a=c['authorities'][0]
        for receipt,field in ((a['path']+'.unknown',a['field']),(a['path'],a['field']+'/unknown')):
            with self.subTest(receipt=receipt,field=field),self.assertRaisesRegex(ValueError,'unreviewed authority/field'):
                m.custody_reference(P(c['original_path']),c['expected_sha256'],P(receipt),field,self.cases)
    def test_wrong_original_expected_hash_cannot_be_remapped(self):
        c=self.cases[0];a=c['authorities'][0];t,raw,d=m.custody_reference(P(c['original_path']),'0'*64,P(a['path']),a['field'],self.cases)
        self.assertEqual(str(t),c['original_path']);self.assertFalse(raw);self.assertIsNone(d)
        with self.assertRaises(FileNotFoundError):m.regular(t)
    def test_wrong_retained_hash_and_size_rejected(self):
        for field,value in (('sha256','0'*64),('bytes',1)):
            c=copy.deepcopy(self.cases);c[1]['retained_file'][field]=value
            with self.subTest(field=field),self.assertRaisesRegex(ValueError,'changed exact retained custody bytes'):self.apply(c,1)
    def test_altered_raw_negative_bytes_rejected(self):
        raw_path=self.cases[3]['retained_file']['path'];actual=m.digest
        with mock.patch.object(m,'digest',side_effect=lambda p:'0'*64 if str(p)==raw_path else actual(p)):
            with self.assertRaisesRegex(ValueError,'changed exact retained custody bytes'):self.apply(self.cases,3)
    def test_exact_malformed_fixture_is_raw_only(self):
        t,raw,d=self.apply(self.cases,3);self.assertTrue(raw);self.assertEqual(t.stat().st_size,18);self.assertFalse(d['qualifying'])
        with self.assertRaises(json.JSONDecodeError):m.read(t)
    def test_ordinary_malformed_json_has_no_exception(self):
        raw=self.cases[3];t,only,d=m.custody_reference(P(raw['original_path']),raw['expected_sha256'],P(raw['authorities'][0]['path']),'/not-the-reviewed-field',[])
        self.assertFalse(only);self.assertIsNone(d)
        with self.assertRaises(json.JSONDecodeError):m.read(t)
    def test_unknown_current_digest_mismatch_rejected(self):
        p=P('/home/mikers/gomap-current-proof.json')
        with self.assertRaisesRegex(ValueError,'explicit reference digest differs'):
            m.check_reference_hash(p,'a'*64,{'sha256':'b'*64})
        m.check_reference_hash(p,'a'*64,{'sha256':'a'*64})
    def test_changed_pinned_disposition_receipt_rejected(self):
        with mock.patch.object(m,'CUSTODY_SHA256','0'*64):
            with self.assertRaisesRegex(ValueError,'changed exact custody disposition receipt'):m.custody_cases()
if __name__=='__main__':unittest.main(verbosity=2)
