"""One-use common-client current-gateway correctness gates; no benchmark."""
import pathlib,sys,os,json,hashlib,socket
sys.path.insert(0,'/home/mikers/gomap-5335-perf-campaign-20261030')
import supervisor as b
ROOT=pathlib.Path(__file__).resolve().parent
H=pathlib.Path('/home/mikers/gomap-5335-common-load-comparison-20261030')
B=pathlib.Path('/home/mikers/gomap-5335-close-consumer-build-20261029/reference-bootstrap-959cc5c491-preparation')
V=pathlib.Path('/home/mikers/gomap-5335-direct-build-v4-attempt-20261030')
def run():
 r=ROOT/'comparison-B';assert r.is_dir()
 for cls,profile,journal in [(sys.argv[1], 'command_wal_'+('durable' if sys.argv[1]=='durable' else 'relaxed'), 'unspecified')]:
  assert cls in ('durable','relaxed');pair=int(sys.argv[2]);assert pair in (1,2,3)
  cell=r/f'pair{pair}-gomap';cell.mkdir();out=cell/'output';out.mkdir()
  env=dict(PATH='/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.10.linux-amd64/bin:/usr/bin:/bin',GOROOT='/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.10.linux-amd64',HOME='/home/mikers',TMPDIR=str(cell),GOENV='off',LC_ALL='C',TZ='UTC',PYTHONDONTWRITEBYTECODE='1',BUILD='false',BUILD_GOYCSB='false',TARGETS='treedb_mongo',MONGODB_MODE='skip',OUT_DIR=str(out),GOYCSB_DIR=str(B/'producer-source'),GOYCSB_BIN=str(B/'go-ycsb'),CLIENT_BUILD_MANIFEST=str(B/'support/client-build.json'),FIXTURE_BIN=str(B/'fixture'),SERVER_BUILD_MANIFEST=str(V/'manifests/candidate-server-build.json'),TREEDB_NATIVE_SERVER_BIN=str(V/'bin/candidate-native'),TREEDB_MONGO_GATEWAY_BIN=str(V/'bin/candidate-mongo'),TREEDB_PROFILE=profile,TREEDB_NATIVE_DOCUMENT_FORMAT='bson',TREEDB_MONGO_DOCUMENT_FORMAT='bson',MONGODB_JOURNAL_REQUEST=journal,COMMON_LOAD_POLICY=str(ROOT/'comparison-B'/f'pair{pair}-gomap-policy.json'),RECORDCOUNT='100000',OPERATIONCOUNT='10000',THREADCOUNT='16',RUN_REPEATS='1',PHASE_TIMEOUT_SECONDS='600',HELPER_TIMEOUT_SECONDS='180',CHILD_CLEANUP_TIMEOUT_SECONDS='10')
  (cell/'request.json').write_text(json.dumps(dict(environment=env,argv=['/bin/bash',str(H/'scripts/ycsb_compare_mongodb_treedb.sh')],scope='matched current-host performance; full pre-run census warms cache; fail stop/no retry'),indent=2)+'\n')
  print(json.dumps(dict(event='actual-gomap-matched-start',ack_class=cls,profile=profile,client_sha256=hashlib.sha256((B/'go-ycsb').read_bytes()).hexdigest())),flush=True)
  limits=b.Limits(wall=3600,cpu_soft=3600,cpu_hard=3610,file_bytes=8*1024**3,disk_bytes=32*1024**3,min_free=10*1024**3,rss_bytes=24*1024**3,poll=.1,grace=30,reap=10,cpu=None,nice=0)
  with b.Supervisor(cell) as supervisor:result=supervisor.run('launcher',['/bin/bash',str(H/'scripts/ycsb_compare_mongodb_treedb.sh')],str(H),env,limits)
  (cell/'FINAL.json').write_text(json.dumps(result,indent=2)+'\n')
  validation=json.loads((out/'validation.json').read_text());assert validation['status']=='validated-consumer-evidence'
  for phase in ('load','run_1'):
   launch=json.loads((out/'treedb_mongo'/f'{phase}.launch.json').read_text());assert launch['runtime_observation']['status']=='actual-child-runtime-observed'
  print(json.dumps(dict(event='actual-gomap-matched-pass',ack_class=cls,validation=validation)),flush=True)
if __name__=='__main__':run()
