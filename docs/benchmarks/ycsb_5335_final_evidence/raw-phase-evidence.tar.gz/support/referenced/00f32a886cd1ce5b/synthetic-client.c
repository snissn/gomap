#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(int argc,char **argv) {
 FILE *f=fopen(CLIENT_MARKER,"wx");if(!f)return 2;
 fputs("{\"argv\":[",f);
 for(int i=1;i<argc;i++) {
  if(i>1)fputc(',',f);fputc('"',f);
  for(unsigned char *p=(unsigned char*)argv[i];*p;p++) {
   if(*p=='"'||*p=='\\')fputc('\\',f);
   if(*p<32)fprintf(f,"\\u%04x",*p);else fputc(*p,f);
  }
  fputc('"',f);
 }
 fprintf(f,"],\"env_unset\":%s}",getenv("GOMAXPROCS")?"false":"true");
 if(fclose(f))return 3;
 if(HANG){signal(SIGTERM,SIG_IGN);sleep(30);return 4;}
 usleep(100000);return 37;
}