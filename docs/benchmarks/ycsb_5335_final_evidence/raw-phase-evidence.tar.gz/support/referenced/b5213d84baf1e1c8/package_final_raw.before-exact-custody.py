#!/usr/bin/python3
"""Offline selective final12 packager. No product, parser, bulk snapshot hash or upload."""
import argparse, gzip, hashlib, json, os, pathlib, re, stat, tarfile
P = pathlib.Path
SHA = re.compile(r'[0-9a-f]{64}\Z')
PRIVATE = {'.git', '.ssh', '.gnupg', '.codex', '.agents', '__pycache__', 'node_modules', 'gocache', 'home', 'tmp'}
DB = {'db', 'fixture-db', 'data', 'bin', 'WiredTiger', 'journal', 'diagnostic.data'}
TYPED = {'snapshot_loaded.json', 'snapshot_preclose.json', 'snapshot_reopened.json', 'fixture.expected.json', 'fixture.updated.json', 'fixture.updated.json.load.json', 'fixture.reopened.json'}
EXPECTED = [dict(class_name=c, pair=n, arm=a, name=f'{c}-pair{n}-{a}') for c in ('relaxed', 'durable-B') for n,a in ((1,'mongodb'),(1,'gomap'),(2,'gomap'),(2,'mongodb'),(3,'mongodb'),(3,'gomap'))]
PRIVATE_FILES = {'.bash_history','.zsh_history','credentials','credentials.json','id_rsa','id_ed25519','.netrc'}
ROOT_FILES = {'CONTROLS-REQUIRED.json','ROOT-PACKET-ACCEPT.json','check_bindings_offline.py','tiny_gateway_once.py','campaign.json','SEALED.json','accepted-controls.json','campaign-start.json','STOPPED.json','packet.py','PACKET-STATIC-CHECK.json','OFFLINE-BINDING-CONTROLS.json','PACKET-SUBSTITUTION.diff'}
SMALL_SUFFIX = {'.json','.jsonl','.out','.err','.txt','.log','.md','.py','.go','.sh','.patch','.diff','.tsv','.bin'}

def require(x,msg):
    if not x: raise ValueError(msg)
def read(p):
    regular(p); return json.loads(P(p).read_text())
def write(p,x):
    with P(p).open('x') as f: json.dump(x,f,indent=2,sort_keys=True,allow_nan=False); f.write('\n')
def digest(p):
    h=hashlib.sha256()
    with P(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def safe_name(n):
    x=pathlib.PurePosixPath(n)
    return n==x.as_posix() and not x.is_absolute() and '..' not in x.parts and all(s not in ('','.') for s in x.parts)
def private_path(p):
    # /home/mikers is the declared public task root, not a task-local home.
    parts=P(p).absolute().parts
    if parts[:3]==('/', 'home', 'mikers'): parts=parts[3:]
    return any(x in PRIVATE for x in parts)
def regular(p):
    p=P(p).absolute()
    require(not any(q.is_symlink() for q in (p,*p.parents)), 'symlink/escaping source: '+str(p))
    s=p.lstat(); require(stat.S_ISREG(s.st_mode),'nonregular source: '+str(p)); return s

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--packet',type=P,required=True); ap.add_argument('--report',type=P,required=True)
    ap.add_argument('--output',type=P,required=True); ap.add_argument('--assembler',type=P,required=True)
    ap.add_argument('--assembler-sha256',default='7f7ba89e80c55ea0619270cc9421e1ec91ed9791ee1440c0e1750e72c7dd04d5')
    ap.add_argument('--support-receipt',type=P,action='append',default=[])
    ap.add_argument('--max-raw-file-bytes',type=int,default=64*1024**2)
    args=ap.parse_args(); packet=args.packet.absolute(); report=args.report.absolute(); output=args.output.absolute()
    require(not output.exists(),'fresh output required'); require(not output.is_relative_to(packet) and not output.is_relative_to(report),'output must be outside frozen packet/report'); require(not any(q.is_symlink() for q in (packet,report,*packet.parents,*report.parents)),'input root symlink')
    for original in (packet/'campaign.json',report/'attempt-statuses.json',args.assembler): regular(original)
    campaign=read(packet/'campaign.json'); require(campaign['order']==EXPECTED,'exact declared12 order mismatch')
    require((report/'attempt-statuses.json').is_file(),'actual corrected assembler status output required')
    require(any((packet/'cells'/r['name']/'STARTED.json').exists() for r in EXPECTED),'no actual final attempt: refusing prospective/tiny-only archive')
    attempts=read(report/'attempt-statuses.json'); require([{k:x[k] for k in ('class_name','pair','arm','name')} for x in attempts['attempts']]==EXPECTED,'assembler attempt cardinality/order mismatch')
    require((report/'COMPLETE.json').exists() != (report/'FAILED.json').exists(),'exactly one assembler COMPLETE/FAILED required')
    require(digest(args.assembler)==args.assembler_sha256,'corrected assembler binding differs')
    require(not any(q.is_symlink() for q in output.parents),'output parent symlink'); output.mkdir(parents=True); generated=output/'generated'; generated.mkdir()
    selected={}; omissions=[]; missing=[]; authorities={}; visited=set(); statuses=[]; identities=[]; emission_absences=[]
    def authority(path,hash_value,receipt,kind):
        if isinstance(hash_value,str) and SHA.fullmatch(hash_value):
            authorities.setdefault(str(P(path).absolute()),[]).append(dict(sha256=hash_value,authority_path=str(P(receipt).absolute()),authority_sha256=digest(receipt),kind=kind))
    # Close hashes are authorities for typed payloads; never open their large bytes.
    for row in EXPECTED:
        cell=packet/'cells'/row['name']; target='treedb_mongo' if row['arm']=='gomap' else 'mongodb'; d=cell/'output'/target
        for receipt in sorted(d.glob('*.close.json')):
            regular(receipt); x=read(receipt)
            for name,h in x.get('artifacts_sha256',{}).items():
                require(safe_name(name),'unsafe producer artifact name'); authority(receipt.parent/name,h,receipt,'original producer Close artifact digest')
        state=next(x for x in attempts['attempts'] if x['name']==row['name'])
        manifest=read(cell/'output/manifest.json') if (cell/'output/manifest.json').is_file() else {}
        request=read(cell/'request.json') if (cell/'request.json').is_file() else {}
        identities.append(dict(row,fixture_request_path=request.get('environment',{}).get('FIXTURE_BIN'),actual_manifest_fixture=manifest.get('fixture'),actual_manifest_client=manifest.get('client'),actual_server_builds=manifest.get('server_builds'),write_concern=manifest.get('write_concern'),profile=manifest.get('profile')))
        statuses.append(dict(row,assembler_status=state,actual_receipts={n:(cell/n).is_file() for n in ('request.json','STARTED.json','FINAL.json','COMPLETE.json','launcher/terminal.json')}))
        required=['request.json']
        if state['status']=='COMPLETION_RECEIPT_PRESENT':
            required+=['STARTED.json','FINAL.json','COMPLETE.json','launcher/start.json','launcher/terminal.json','launcher/stdout.txt','launcher/stderr.txt','output/manifest.json']
            required += ['output/'+target+'/'+phase+suffix for phase in ('load','run_1') for suffix in ('.out','.err','.launch.json','.close.json','.cleanup.json')]
            required += ['output/'+target+'/'+n+'.close.json' for n in ('snapshot_loaded','snapshot_preclose','snapshot_reopened','fixture_write','fixture_verify')]
            if row['arm']=='gomap':
                for prefix in ('server','fixture-write'):
                    cp=d/(prefix+'.evidence')/'owner.checkpoint.json'
                    if not cp.is_file(): missing.append(dict(cell=row['name'],path=str(cp),reason='required current schema2 private owner checkpoint missing'))
                    else:
                        value=read(cp)
                        if type(value.get('schema_version')) is not int or value.get('schema_version')!=2 or 'backend_checkpoint' in value or not value.get('collections_checkpoint_storage',{}).get('success'): missing.append(dict(cell=row['name'],path=str(cp),reason='not successful schema2 owning manager checkpoint'))
            required += ['output/validation.json','output/'+target+'/runtime.json','output/'+target+'/lifecycle.json'] if row['arm']=='gomap' else ['output/reference-complete.json','output/reference-runtime.json']
            if row['class_name']=='durable-B': required+=['output/'+target+'/public-sentinel.json']
        for relative in required:
            if not (cell/relative).is_file(): missing.append(dict(cell=row['name'],path=str(cell/relative),reason='required for actual declared completion'))
        for phase in ('load','run_1'):
            optional=d/(phase+'.actual-command.json')
            if not optional.is_file(): emission_absences.append(dict(cell=row['name'],path=str(optional),reason='emission-specific actual-command witness absent; actual argv remains in original request/launch/manifest when emitted'))
        if row['class_name']=='relaxed': emission_absences.append(dict(cell=row['name'],path=str(d/'public-sentinel.json'),reason='relaxed class has no common-load sentinel by contract'))
        if row['class_name']=='relaxed' and (d/'public-sentinel.json').exists(): missing.append(dict(cell=row['name'],reason='unexpected relaxed sentinel'))
    for path,h in campaign['bindings'].items(): authority(path,h,packet/'campaign.json','sealed campaign artifact binding')
    controls=read(packet/'accepted-controls.json')
    for key in ('reviewed_control_a','reviewed_control_b'):
        for path,h in controls[key]['files'].items(): authority(path,h,packet/'accepted-controls.json','original actual reviewed control digest')
    def omit(p,reason,scope):
        p=P(p).absolute(); s=p.lstat() if p.exists() or p.is_symlink() else None
        omissions.append(dict(original_path=str(p),reason=reason,scope=scope,bytes=None if s is None or not stat.S_ISREG(s.st_mode) else s.st_size,device=None if s is None else s.st_dev,inode=None if s is None else s.st_ino,mtime_ns=None if s is None else s.st_mtime_ns,authorities=authorities.get(str(p),[]),authentication='authoritative content digest retained' if authorities.get(str(p)) else 'not content authenticated; stat-only directory/payload outside compact report revalidation scope',retention='original remains in local custody; no external availability claim'))
    def add(p,n,scope):
        p=P(p).absolute(); require(safe_name(n),'unsafe archive member'); require(n not in selected or selected[n]['original_path']==str(p),'duplicate archive name')
        if not p.exists(): missing.append(dict(path=str(p),scope=scope,reason='explicit referenced artifact absent')); return
        s=regular(p)
        if private_path(p) or p.name in PRIVATE_FILES: omit(p,'private/cache directory excluded without reading payload',scope); return
        if p.name in TYPED: omit(p,'full typed payload; original Close digest retained, no rehash',scope); return
        with p.open('rb') as f: magic=f.read(4)
        if magic==b'\x7fELF' or p.suffix in ('.wt','.db','.sst','.a','.o'):
            omit(p,'ELF/DB/compiler payload excluded; original build or custody digest required',scope); return
        if s.st_size>args.max_raw_file_bytes:
            omit(p,'above explicit compact-file cap; retained at original path',scope)
            if scope.startswith('derived owned-process'): missing.append(dict(path=str(p),reason='required owned process projection above compact cap; explicit disposition needed'))
            return
        selected[n]=dict(archive_path=n,original_path=str(p),bytes=s.st_size,sha256=digest(p),scope=scope,encoding='identity')
    def external_projection(p,n,terminal):
        # Publish complete owned rows only. Unrelated process command payloads
        # and full-host snapshots stay at their original path, explicitly omitted.
        regular(p)
        if not terminal.is_file():
            omit(p,'full-host observations omitted: no terminal owned-token membership authority',n)
            missing.append(dict(path=str(terminal),reason='cannot derive required owned-only resource projection without terminal membership')); return
        regular(terminal)
        expected_raw={a['sha256'] for a in authorities.get(str(p),[])}
        t=read(terminal); owned={(x['pid'],x['start_ticks']) for x in t['owned']}; out=generated/(hashlib.sha256(n.encode()).hexdigest()[:20]+'.owned.jsonl'); h=hashlib.sha256()
        fields={'pid','start_ticks','parent','group','state','cpu_ticks','waited_cpu_ticks','rss_bytes','command'}
        with p.open('rb') as source,out.open('xb') as dest:
            for line in source:
                h.update(line); x=json.loads(line); rows=[]
                for r in x['processes']:
                    if (r['pid'],r['start_ticks']) in owned:
                        require(isinstance(r.get('command'),str) and len(r['command'])<=64 and '\n' not in r['command'],'unexpected process command payload; do not publish')
                        rows.append({k:r[k] for k in fields if k in r})
                dest.write((json.dumps(dict(monotonic=x['monotonic'],processes=rows),sort_keys=True)+'\n').encode())
        require(not expected_raw or expected_raw=={h.hexdigest()},'owned-observation raw differs from retained binding')
        provenance=out.with_suffix('.provenance.json')
        write(provenance,dict(kind='owned_process_observation_projection',original_path=str(p),original_sha256=h.hexdigest(),projection_path=str(out),projection_sha256=digest(out),terminal=dict(path=str(terminal),sha256=digest(terminal)),scope='fresh packaging streaming digest of raw full-host bytes; terminal supplies actual owned-token membership, not the raw file digest'))
        authority(p,h.hexdigest(),provenance,'new packaging raw digest provenance, not an original supervisor content hash')
        add(provenance,n+'.provenance.json','derived projection provenance; actual raw digest and membership authority')
        omit(p,'full-host/private unrelated observations omitted; owned-row projection included',n)
        add(out,n+'.owned.jsonl','derived owned-process observation projection, original path/digest and terminal membership retained')
    def walk(base,prefix,scope):
        # Collect original compact Close authorities before handling adjacent
        # typed payloads, including retained tiny lifecycle controls.
        for receipt in sorted(base.glob('*.close.json')):
            regular(receipt)
            for name,h in read(receipt).get('artifacts_sha256',{}).items():
                require(safe_name(name),'unsafe producer artifact name'); authority(receipt.parent/name,h,receipt,'original producer Close artifact digest')
        for p in sorted(base.iterdir()):
            rel=p.relative_to(base).as_posix(); n=prefix+'/'+rel
            require(not p.is_symlink(),'symlink in scoped evidence: '+str(p))
            if p.is_dir():
                if p.name in PRIVATE or p.name in DB or p.name.endswith(('-db','-data')) or p.name.startswith('data-'):
                    omit(p,'DB/cache/private subtree excluded without recursive scan',scope)
                else: walk(p,n,scope)
            elif p.name=='external.jsonl': external_projection(p,n,p.parent/'terminal.json')
            elif p.suffix in SMALL_SUFFIX: add(p,n,scope)
            else: omit(p,'nonselected payload/unknown extension retained in place',scope)
    for name in sorted(ROOT_FILES):
        if (packet/name).is_file(): add(packet/name,'packet/'+name,'actual final packet controller/config/status')
    if (packet/'source-review').is_dir(): walk(packet/'source-review','packet/source-review','accepted actual source/build/applicability receipts')
    if (packet/'tiny-gateway-guards').is_dir(): walk(packet/'tiny-gateway-guards','packet/tiny-gateway-guards','retained tiny lifecycle controls, not final campaign performance samples')
    for child in sorted(packet.iterdir()):
        if child.name not in ROOT_FILES|{'source-review','cells','tiny-gateway-guards'}:
            omit(child,'nonselected packet-root entry/self-mutating output retained without recursive read','packet root explicit omission')
    for row in EXPECTED: walk(packet/'cells'/row['name'],'cells/'+row['name'],row['class_name']+'/'+str(row['pair'])+'/'+row['arm'])
    walk(report,'report','corrected assembler projection, including truthful incomplete/FAILED output')
    add(args.assembler,'support/assembler/assemble_report.py','actual corrected report assembler source')
    # Explicit reference graphs only: campaign bindings, actual control maps,
    # gate and its acceptance receipts, assembler references, selected build refs.
    seeds=[P(p) for p in campaign['bindings']]+[P(p) for k in ('reviewed_control_a','reviewed_control_b') for p in controls[k]['files']]+args.support_receipt
    if (packet/'campaign-start.json').exists(): seeds.append(P(read(packet/'campaign-start.json')['gate_path']))
    def references(x):
        out=[]
        if isinstance(x,dict):
            if isinstance(x.get('path'),str) and P(x['path']).is_absolute() and SHA.fullmatch(str(x.get('sha256',''))): out.append((P(x['path']),x['sha256']))
            for value in x.values(): out+=references(value)
        elif isinstance(x,list):
            for value in x: out+=references(value)
        return out
    queue=[(p,0) for p in seeds]
    while queue:
        p,depth=queue.pop(0); p=p.absolute()
        if str(p) in visited: continue
        visited.add(str(p))
        if private_path(p) or p.name in PRIVATE_FILES: omit(p,'private/cache reference not opened', 'external reference'); continue
        require(str(p).startswith(('/home/mikers/gomap-','/home/mikers/dev/snissn/gomap/','/usr/bin/')),'external reference outside declared public task/source roots: '+str(p))
        n='support/referenced/'+hashlib.sha256(str(p).encode()).hexdigest()[:16]+'/'+p.name
        if p.name=='external.jsonl': external_projection(p,n,p.parent/'terminal.json')
        else: add(p,n,'explicit source-bound external receipt/control/build reference')
        if p.name not in TYPED and p.suffix=='.json' and p.is_file() and p.stat().st_size<=args.max_raw_file_bytes and depth<5 and p.name not in ('source.json','deps.json','modules.json','toolchain.json','ALL-TRACKED-OBJECTS.json','NON-DOC-OBJECTS.json'):
            for target,h in references(read(p)):
                authority(target,h,p,'explicit build/review/report path+digest reference'); queue.append((target,depth+1))
    # A missing payload remains an explicit custody absence even when its prior
    # Close digest exists; never reopen a full payload to manufacture authority.
    for original in sorted(authorities):
        path=P(original)
        if path.name in TYPED and not path.exists():
            omit(path,'authoritatively named typed payload absent from retained custody','typed payload custody')
            missing.append(dict(path=original,reason='Close-authorized typed payload absent; retained digest is not present custody'))
    # Required omitted typed payloads need original Close authority; no stat-only
    # claim may silently become accepted complete evidence.
    for omission in omissions:
        current=authorities.get(omission['original_path'],[])
        if current:
            omission['authorities']=current; omission['authentication']='authoritative content digest retained'
    unresolved=[x for x in omissions if P(x['original_path']).name in TYPED and (not x['authorities'] or len({a['sha256'] for a in x['authorities']})!=1)]
    accepted=(report/'COMPLETE.json').exists() and not missing and not unresolved and not (packet/'STOPPED.json').exists()
    write(output/'omissions.json',dict(omissions=omissions,unresolved_required_typed_payloads=unresolved,emission_specific_absences=emission_absences))
    for name in ('package_final_raw.py','verify_final_raw.py'): add(P(__file__).parent/name,'support/packaging/'+name,'actual local selective packager/verifier source')
    add(output/'omissions.json','packet/omissions.json','explicit large/private/DB omissions and actual digest authorities')
    index=dict(schema_version=1,status='COMPLETE_SELECTIVE_RAW_DELIVERY' if accepted else 'INCOMPLETE_OR_FAILED_SELECTIVE_RAW_DELIVERY',measured_source_commit=campaign['source_commit'],measured_source_tree=campaign['source_tree'],campaign_order=EXPECTED,attempts=statuses,required_missing=missing,emission_specific_absences=emission_absences,omissions=omissions,unresolved_required_typed_payloads=unresolved,actual_per_arm_source_roles=identities,source_roles=dict(gomap='actual new gateway and typed schema2 fixture from each GoMap request/build binding',mongodb='actual original5db helper /58c reference control /2237 timed client retained, not relabeled new GoMap fixture',controls=dict(actual_source_commit=controls['source_commit'],scope='original792 public A/B controls plus accepted scoped applicability; historicalc660 schema1 private receipts remain historical, not owner-complete'),checkpoint='current successful GoMap proof must remain schema2/collections_checkpoint_storage; old backend_checkpoint is no alias'),documents=[],archive=dict(path='raw-phase-evidence.tar.gz',sha256=None,members=[selected[n] for n in sorted(selected)]),scope='Selective public raw/control/lifecycle packet, not full DB/ELF/typed snapshot archive, no external availability or performance acceptance claim')
    archive=output/index['archive']['path']
    with archive.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
        for entry in index['archive']['members']:
            p=P(entry['original_path']);s=regular(p);require(s.st_size==entry['bytes'] and digest(p)==entry['sha256'],'selected source changed before archive')
            info=tarfile.TarInfo(entry['archive_path']);info.size=s.st_size;info.mode=0o644;info.mtime=0;info.uid=info.gid=0
            with p.open('rb') as f:
                before=os.fstat(f.fileno()); require((before.st_dev,before.st_ino,before.st_size)==(s.st_dev,s.st_ino,s.st_size),'source replaced during open')
                class HashedReader:
                    def __init__(self,stream): self.stream=stream; self.hash=hashlib.sha256()
                    def read(self,n):
                        data=self.stream.read(n); self.hash.update(data); return data
                stream=HashedReader(f); tar.addfile(info,stream); after=os.fstat(f.fileno())
                require(stream.hash.hexdigest()==entry['sha256'] and (before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_size,after.st_mtime_ns,after.st_ctime_ns),'source changed during archive read')
    index['archive']['sha256']=digest(archive);index['archive']['bytes']=archive.stat().st_size
    write(output/'index.json',index)
    print(json.dumps(dict(status=index['status'],members=len(selected),archive_bytes=archive.stat().st_size,index_sha256=digest(output/'index.json'),archive_sha256=index['archive']['sha256'])))
if __name__=='__main__': main()
