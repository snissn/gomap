#!/usr/bin/python3
"""Verify compact bytes and arithmetic only. Never read omitted DB/ELF/typed payloads."""
import argparse, hashlib, json, math, pathlib, statistics, tarfile
import package_final_raw as p
P=pathlib.Path

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('directory',type=P);args=ap.parse_args();root=args.directory.absolute()
    p.regular(root/'index.json')
    index=p.read(root/'index.json');archive=root/index['archive']['path'];p.require(p.safe_name(index['archive']['path']),'unsafe archive path')
    p.regular(archive)
    p.require(p.digest(archive)==index['archive']['sha256'] and archive.stat().st_size==index['archive']['bytes'],'archive SHA/size mismatch')
    entries=index['archive']['members'];expected={e['archive_path']:e for e in entries}
    p.require(len(expected)==len(entries) and all(p.safe_name(n) for n in expected),'duplicate/unsafe indexed members')
    p.require(index['campaign_order']==p.EXPECTED and [{k:x[k] for k in ('class_name','pair','arm','name')} for x in index['attempts']]==p.EXPECTED,'12 declared attempts/order not retained')
    seen=set();report=None;attempts=None
    with tarfile.open(archive,'r:gz') as tar:
        for member in tar:
            p.require(member.name not in seen and member.name in expected and p.safe_name(member.name) and member.isreg() and not member.issym() and not member.islnk(),'unsafe/extra/duplicate/nonregular member')
            seen.add(member.name);e=expected[member.name];p.require(member.size==e['bytes'],'member length differs')
            source=P(e['original_path']);s=p.regular(source);p.require(s.st_size==e['bytes'],'source length differs')
            h=hashlib.sha256();count=0;captured=[] if member.name in ('report/report.json','report/attempt-statuses.json') else None
            with tar.extractfile(member) as original,source.open('rb') as current:
                for b in iter(lambda:original.read(1024*1024),b''):
                    p.require(current.read(len(b))==b,'source byte identity mismatch: '+member.name);h.update(b);count+=len(b)
                    if captured is not None:captured.append(b)
                p.require(current.read(1)==b'','source grew')
            p.require(count==e['bytes'] and h.hexdigest()==e['sha256'],'member bytes/hash mismatch')
            if member.name=='report/report.json':report=json.loads(b''.join(captured))
            if member.name=='report/attempt-statuses.json':attempts=json.loads(b''.join(captured))
    p.require(seen==set(expected),'archive/index cardinality differs')
    p.require(attempts is not None and [{k:x[k] for k in ('class_name','pair','arm','name')} for x in attempts['attempts']]==p.EXPECTED,'missing actual assembler statuses')
    for row in p.EXPECTED:
        status=next(x for x in attempts['attempts'] if x['name']==row['name']);prefix='cells/'+row['name']+'/'
        if status['status']=='COMPLETION_RECEIPT_PRESENT':
            target='treedb_mongo' if row['arm']=='gomap' else 'mongodb'
            for phase in ('load','run_1'):
                for suffix in ('.out','.err','.close.json','.launch.json','.cleanup.json'):p.require(prefix+'output/'+target+'/'+phase+suffix in expected,'missing required nested raw phase')
            for name in ('request.json','STARTED.json','FINAL.json','COMPLETE.json','launcher/start.json','launcher/terminal.json'):p.require(prefix+name in expected,'missing attempt receipt')
    if index['status']=='COMPLETE_SELECTIVE_RAW_DELIVERY':
        p.require(not index['required_missing'] and not index['unresolved_required_typed_payloads'],'accepted label hides missing evidence')
        p.require(all(x['status']=='COMPLETION_RECEIPT_PRESENT' for x in attempts['attempts']) and not attempts['stopped'] and not attempts['undeclared_cells'],'accepted package has incomplete/failed attempts')
        p.require(report is not None and report['campaign']['source_commit']==index['measured_source_commit'] and report['campaign']['source_tree']==index['measured_source_tree'],'actual report source mismatch')
        p.require([{k:x[k] for k in ('class_name','pair','arm','name')} for x in report['samples']]==p.EXPECTED,'report sample cardinality/order differs')
        p.require(len(report['pairs'])==6,'missing paired rates')
        for pair in report['pairs']:
            p.require(all(math.isfinite(pair[k]) and pair[k]>0 for k in ('mongodb','gomap','mongodb_load','gomap_load','ratio')),'invalid rates')
            p.require(abs(pair['gomap']/pair['mongodb']-pair['ratio'])<=1e-12,'pair ratio arithmetic mismatch')
        for cls in ('relaxed','durable-B'):
            rows=[x for x in report['pairs'] if x['class_name']==cls];p.require(sorted(x['pair'] for x in rows)==[1,2,3],'class pair cardinality differs')
            p.require(abs(statistics.median(x['ratio'] for x in rows)-report['summaries'][cls]['median_paired_ratio'])<=1e-12,'median paired ratio mismatch')
    # Authority receipts are compact and checked; deliberately omitted payloads
    # are never opened or rehashed. An absent original remains explicit custody.
    for omission in index['omissions']:
        for authority in omission['authorities']:
            original=P(authority['authority_path']);p.regular(original);p.require(p.digest(original)==authority['authority_sha256'],'changed omission digest authority')
    receipt=dict(status='PASS_SELECTIVE_ARCHIVE_VERIFICATION',delivery_status=index['status'],archive_sha256=p.digest(archive),index_sha256=p.digest(root/'index.json'),member_count=len(seen),member_bytes=sum(x['bytes'] for x in entries),actual_attempts=12,original_source_byte_identity=True,omitted_payloads_rehashed=0,limits='compact source bytes/archive/index/cardinality/report arithmetic only; maintained lifecycle/CI/merge acceptance remains separate; stat-only DB custody is not content authentication')
    p.write(root/'VERIFICATION.json',receipt);print(json.dumps(receipt,sort_keys=True))
if __name__=='__main__':main()
