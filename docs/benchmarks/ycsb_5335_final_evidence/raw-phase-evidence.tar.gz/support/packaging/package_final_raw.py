#!/usr/bin/python3
"""Offline selective final12 packager. No product, parser, bulk snapshot hash or upload."""
import argparse, gzip, hashlib, importlib.util, json, os, pathlib, re, stat, tarfile
P = pathlib.Path
SHA = re.compile(r'[0-9a-f]{64}\Z')
PRIVATE = {'.git', '.ssh', '.gnupg', '.codex', '.agents', '__pycache__', 'node_modules', 'gocache', 'home', 'tmp'}
DB = {'db', 'fixture-db', 'data', 'bin', 'WiredTiger', 'journal', 'diagnostic.data'}
TYPED = {'snapshot_loaded.json', 'snapshot_preclose.json', 'snapshot_reopened.json', 'fixture.expected.json', 'fixture.updated.json', 'fixture.updated.json.load.json', 'fixture.reopened.json'}
EXPECTED = [dict(class_name=c, pair=n, arm=a, name=f'{c}-pair{n}-{a}') for c in ('relaxed', 'durable-B') for n,a in ((1,'mongodb'),(1,'gomap'),(2,'gomap'),(2,'mongodb'),(3,'mongodb'),(3,'gomap'))]
PRIVATE_FILES = {'.bash_history','.zsh_history','credentials','credentials.json','id_rsa','id_ed25519','.netrc'}
ROOT_FILES = {'CONTROLS-REQUIRED.json','ROOT-PACKET-ACCEPT.json','check_bindings_offline.py','tiny_gateway_once.py','campaign.json','SEALED.json','accepted-controls.json','campaign-start.json','STOPPED.json','packet.py','PACKET-STATIC-CHECK.json','OFFLINE-BINDING-CONTROLS.json','PACKET-SUBSTITUTION.diff','PRIOR-PACKET.json','HELPER-BINDING.json','continuation.py'}
SMALL_SUFFIX = {'.json','.jsonl','.out','.err','.txt','.log','.md','.py','.go','.sh','.patch','.diff','.tsv','.bin'}
CUSTODY_RECEIPT = P('/home/mikers/gomap-5333-5335-completion-20261030/final8bea-packaging-precheck-20261031/EXACT-CUSTODY-DISPOSITIONS.json')
CUSTODY_SHA256 = '9460b07d2381fea46566f8f73e3fe46e581586b7015fa0f5a92a152ef379218d'

def require(x,msg):
    if not x: raise ValueError(msg)
def read(p):
    regular(p); return json.loads(P(p).read_text())
def write(p,x):
    with P(p).open('x') as f: json.dump(x,f,indent=2,sort_keys=True,allow_nan=False); f.write('\n')
def digest(p):
    h=hashlib.sha256()
    with P(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def safe_name(n):
    x=pathlib.PurePosixPath(n)
    return n==x.as_posix() and not x.is_absolute() and '..' not in x.parts and all(s not in ('','.') for s in x.parts)
def private_path(p):
    # /home/mikers is the declared public task root, not a task-local home.
    parts=P(p).absolute().parts
    if parts[:3]==('/', 'home', 'mikers'): parts=parts[3:]
    return any(x in PRIVATE for x in parts)
def regular(p):
    p=P(p).absolute()
    require(not any(q.is_symlink() for q in (p,*p.parents)), 'symlink/escaping source: '+str(p))
    s=p.lstat(); require(stat.S_ISREG(s.st_mode),'nonregular source: '+str(p)); return s

def historical_helper_cases():
    """Only five exact historical packager revisions and nine pinned receipt fields."""
    return [{'authorities': [{'field': '/references/3',
                       'path': '/home/mikers/gomap-5333-5335-completion-20261030/final8bea-packaging-precheck-20261031/ROOT-EXACT-CUSTODY-ACCEPT.json',
                       'sha256': '792ec12fe479f6c15f40fbfb880f4ad48ac9d06afac06d0d7033ef19e85f74a1'},
                      {'field': '/refs/0',
                       'path': '/home/mikers/gomap-5333-5335-completion-20261030/final8bea-packaging-precheck-20261031/FINAL-EXACT-CUSTODY-CONTROLS.json',
                       'sha256': '50d3f993baed7a54213dd4f4839c61c90471db2c4ef52418e9c51607d0baf8b7'},
                      {'field': '/packager',
                       'path': '/home/mikers/gomap-5333-5335-completion-20261030/final8bea-packaging-precheck-20261031/review/FINAL-REVIEW.json',
                       'sha256': '6c2c0d107f5cbd4d38541e3738522520a4ed9a55c9f55d39a3198425c1a77782'}],
      'expected_sha256': 'fdf102a767a8d3cb962c1ff8938107a5fe907f6258ce08178e289e577c449ee9',
      'id': 'historical-packager-before-continuation',
      'kind': 'EXACT_HISTORICAL_HELPER_SOURCE',
      'original_path': '/home/mikers/gomap-5335-final-raw-packaging-20261030/package_final_raw.py',
      'qualification': 'Exact historical helper bytes only; original acceptance revision remains historical '
                       'and does not accept the current helper.',
      'retained_file': {'bytes': 26323,
                        'path': '/home/mikers/gomap-5335-continuation-report-adaptation-20261031/package_final_raw.py.before',
                        'sha256': 'fdf102a767a8d3cb962c1ff8938107a5fe907f6258ce08178e289e577c449ee9'}},
     {'authorities': [{'field': '/owned_sources/1',
                       'path': '/home/mikers/gomap-5335-continuation-report-adaptation-20261031/FINAL-ADAPTATION-RECEIPT.json',
                       'sha256': '51577764c1001690e0862191d3004579412ad8f47264d247406f867300282ac3'},
                      {'field': '/sources_and_receipts/4',
                       'path': '/home/mikers/gomap-5333-5335-completion-20261030/continuation-report-independent-review-20261031/INDEPENDENT-REVIEW.json',
                       'sha256': '4a5547e1075405c377fb8e7ff4832e70c260cdc9060b80fceb4d817fd93c10cd'}],
      'expected_sha256': 'e33d9c30de7de2ef1afe726eb2858c2a81ed2116664ba2bacfe3157ba7f59e04',
      'id': 'historical-packager-before-helper-custody-repair',
      'kind': 'EXACT_HISTORICAL_HELPER_SOURCE',
      'original_path': '/home/mikers/gomap-5335-final-raw-packaging-20261030/package_final_raw.py',
      'qualification': 'Exact historical helper bytes only; original acceptance revision remains historical '
                       'and does not accept the current helper.',
      'retained_file': {'bytes': 28294,
                        'path': '/home/mikers/gomap-5335-final-helper-custody-repair-20261031/package_final_raw.py.before',
                        'sha256': 'e33d9c30de7de2ef1afe726eb2858c2a81ed2116664ba2bacfe3157ba7f59e04'}},
     {'id': 'historical-packager-before-exact-custody',
      'kind': 'EXACT_HISTORICAL_HELPER_SOURCE',
      'original_path': '/home/mikers/gomap-5335-final-raw-packaging-20261030/package_final_raw.py',
      'expected_sha256': '5c459804d6bc6e6d5ec0a4e44c1a2f785f022c5f59f37b18ae7c4a43613ede18',
      'retained_file': {'path': '/home/mikers/gomap-5333-5335-completion-20261030/final8bea-packaging-precheck-20261031/package_final_raw.before-exact-custody.py',
                        'sha256': '5c459804d6bc6e6d5ec0a4e44c1a2f785f022c5f59f37b18ae7c4a43613ede18',
                        'bytes': 22445},
      'authorities': [{'path': '/home/mikers/gomap-5333-5335-completion-20261030/final8bea-packaging-precheck-20261031/PRECHECK.json',
                       'sha256': '421b953e2e713e0a9dc2a17ae0b4c0962f9c1a4975bc4a6d7796ada955aa4ea8',
                       'field': '/packager'}],
      'qualification': 'Exact historical helper bytes only; original acceptance revision remains historical '
                       'and does not accept the current helper.'},
     {'id': 'historical-packager-first-helper-custody-repair',
      'kind': 'EXACT_HISTORICAL_HELPER_SOURCE',
      'original_path': '/home/mikers/gomap-5335-final-raw-packaging-20261030/package_final_raw.py',
      'expected_sha256': '0d7323ce79d5311d0e870c26e8ea3692c5379133fba33bc168b7b411a4e29187',
      'retained_file': {'path': '/home/mikers/gomap-5335-final-helper-custody-completion-20261031/package_final_raw.py.before',
                        'sha256': '0d7323ce79d5311d0e870c26e8ea3692c5379133fba33bc168b7b411a4e29187',
                        'bytes': 31572},
      'authorities': [{'path': '/home/mikers/gomap-5335-final-helper-custody-repair-20261031/FINAL-HELPER-CUSTODY-RECEIPT.json',
                       'sha256': '293a19308a95eefa8e9831c4bcec7b2ef9bcefc5eb0b834add1476953d5ec35c',
                       'field': '/source'},
                      {'path': '/home/mikers/gomap-5333-5335-completion-20261030/final-helper-custody-review-20261031/INDEPENDENT-REVIEW.json',
                       'sha256': 'ca37bb0b7d1626b08e1991c8e1748d2bc8dc3753d2e3ad23049e0402d6939364',
                       'field': '/references/5'}],
      'qualification': 'Exact historical helper bytes only; original acceptance revision remains historical '
                       'and does not accept the current helper.'},
     {'id': 'historical-packager-before-quoted-precheck-authorities',
      'kind': 'EXACT_HISTORICAL_HELPER_SOURCE',
      'original_path': '/home/mikers/gomap-5335-final-raw-packaging-20261030/package_final_raw.py',
      'expected_sha256': 'a031d90344eba37e7482efefcc8231aca52dc515c21bbbd96355a1b9ff1956f4',
      'retained_file': {'path': '/home/mikers/gomap-5335-final-all-custody-audit-20261031/package_final_raw.py.before',
                        'sha256': 'a031d90344eba37e7482efefcc8231aca52dc515c21bbbd96355a1b9ff1956f4',
                        'bytes': 33964},
      'authorities': [{'path': '/home/mikers/gomap-5335-final-helper-custody-completion-20261031/FINAL-COMPLETE-HELPER-CUSTODY-RECEIPT.json',
                       'sha256': '7c1f26b6b5afb81c109ca2ea87e74203cbb2504414c56893d1788dbee17e3157',
                       'field': '/source'}],
      'qualification': 'Exact historical helper bytes only; original acceptance revision remains historical '
                       'and does not accept the current helper.'}]


def custody_cases():
    regular(CUSTODY_RECEIPT)
    require(digest(CUSTODY_RECEIPT)==CUSTODY_SHA256,'changed exact custody disposition receipt')
    cases=read(CUSTODY_RECEIPT)['cases']
    # This immutable historical precheck quotes the same four already reviewed
    # payload identities. Add only its seven exact fields, never a general alias.
    quoted_fields={'historical-custody-portability-source': [367],
                   'retired-adaptive-final-source': [382,1309,1316],
                   'intentional-malformed-owner-negative': [842],
                   'superseded-unexecuted-adaptive-proposal': [1320,1324]}
    for case in cases:
        for index in quoted_fields[case['id']]:
            case['authorities'].append(dict(
                path='/home/mikers/gomap-5333-5335-completion-20261030/final8bea-packaging-precheck-20261031/PRECHECK.json',
                sha256='421b953e2e713e0a9dc2a17ae0b4c0962f9c1a4975bc4a6d7796ada955aa4ea8',
                field='/reference_edges/'+str(index), historical_quote=True))
    return cases + historical_helper_cases()

def check_reference_hash(path,expected,selected_entry):
    if expected and selected_entry:
        require(selected_entry['sha256']==expected,'explicit reference digest differs: '+str(path))

def custody_reference(path, expected, receipt, field, cases):
    """Only the nine hash-pinned source/raw cases; no general remapping."""
    path=P(path).absolute(); receipt=P(receipt).absolute()
    matches=[c for c in cases if c['original_path']==str(path) and c['expected_sha256']==expected]
    if not matches: return path,False,None
    require(len(matches)==1,'ambiguous exact custody disposition')
    case=matches[0]
    auth=[a for a in case['authorities'] if a['path']==str(receipt) and a['field']==field]
    require(len(auth)==1,'unreviewed authority/field for exact custody disposition')
    regular(receipt); require(digest(receipt)==auth[0]['sha256'],'changed original custody authority')
    node=read(receipt)
    for key in field.split('/')[1:]: node=node[int(key)] if isinstance(node,list) else node[key]
    require(node.get('path')==str(path) and node.get('sha256')==expected,'original custody field differs')
    result=dict(case_id=case['id'],kind=case['kind'],original_path=str(path),expected_sha256=expected,original_authority=auth[0])
    if auth[0].get('historical_quote'):
        result['historical_quote_scope']='Exact PRECHECK historical identity quote only; no current proof substitution.'
    if case['kind']=='STALE_UNAVAILABLE_NON_QUALIFYING':
        current=case['observed_current_file']; regular(path)
        require(path.stat().st_size==current['bytes'] and digest(path)==current['sha256'],'changed observed superseded-proposal path')
        result.update(observed_current_file=current,qualification=case['qualification'],qualifying=False)
        return None,False,result
    kept=case['retained_file']; target=P(kept['path']); regular(target)
    require(target.stat().st_size==kept['bytes'] and digest(target)==kept['sha256']==expected,'changed exact retained custody bytes')
    result.update(retained_file=kept,qualifying=case['kind'] not in ('EXACT_RAW_NEGATIVE_JSON','EXACT_HISTORICAL_HELPER_SOURCE'))
    if case['kind']=='EXACT_HISTORICAL_HELPER_SOURCE': result['qualification']=case['qualification']
    if 'git_provenance' in case: result['git_provenance']=case['git_provenance']
    return target,case['kind']=='EXACT_RAW_NEGATIVE_JSON',result

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--packet',type=P,required=True); ap.add_argument('--report',type=P,required=True)
    ap.add_argument('--output',type=P,required=True); ap.add_argument('--assembler',type=P,required=True)
    ap.add_argument('--assembler-sha256',required=True)
    ap.add_argument('--prior-packet',type=P,help='explicit original stopped packet, adopting only its exact first two samples')
    ap.add_argument('--support-receipt',type=P,action='append',default=[])
    ap.add_argument('--max-raw-file-bytes',type=int,default=64*1024**2)
    args=ap.parse_args(); packet=args.packet.absolute(); report=args.report.absolute(); output=args.output.absolute()
    require(not output.exists(),'fresh output required'); require(not output.is_relative_to(packet) and not output.is_relative_to(report),'output must be outside frozen packet/report'); require(not any(q.is_symlink() for q in (packet,report,*packet.parents,*report.parents)),'input root symlink')
    for original in (packet/'campaign.json',report/'attempt-statuses.json',args.assembler): regular(original)
    require(digest(args.assembler)==args.assembler_sha256,'corrected assembler binding differs')
    spec=importlib.util.spec_from_file_location('final_report_assembler',args.assembler)
    assembler=importlib.util.module_from_spec(spec);spec.loader.exec_module(assembler)
    plan=assembler.packet_plan(packet,args.prior_packet)
    campaign=plan['campaign']; cells=plan['cells']
    require(all(not output.is_relative_to(actual) for actual in plan['packets']),'output must remain outside both frozen packets')
    require(any((cell/'STARTED.json').exists() for cell,row in cells),'no actual final attempt: refusing prospective/tiny-only archive')
    attempts=read(report/'attempt-statuses.json')
    require(attempts==assembler.attempt_statuses(packet,plan),'assembler attempt identities/status/history differ from actual packets')
    require([{k:x[k] for k in ('class_name','pair','arm','name')} for x in attempts['attempts']]==EXPECTED,'assembler attempt cardinality/order mismatch')
    require((report/'COMPLETE.json').exists() != (report/'FAILED.json').exists(),'exactly one assembler COMPLETE/FAILED required')
    if (report/'COMPLETE.json').exists():
        require(not attempts['undeclared_cells'] and attempts['stopped'] is None and all(x['status']=='COMPLETION_RECEIPT_PRESENT' for x in attempts['attempts']),'accepted report lacks twelve actual selected completions')
        for actual in plan['packets']: assembler.verify_packet_inputs(actual,read(actual/'campaign.json'))
    require(not any(q.is_symlink() for q in output.parents),'output parent symlink'); output.mkdir(parents=True); generated=output/'generated'; generated.mkdir()
    selected={}; omissions=[]; missing=[]; authorities={}; visited=set(); statuses=[]; identities=[]; emission_absences=[]
    exact_cases=custody_cases(); custody_dispositions=[]
    def authority(path,hash_value,receipt,kind):
        if isinstance(hash_value,str) and SHA.fullmatch(hash_value):
            authorities.setdefault(str(P(path).absolute()),[]).append(dict(sha256=hash_value,authority_path=str(P(receipt).absolute()),authority_sha256=digest(receipt),kind=kind))
    # Close hashes are authorities for typed payloads; never open their large bytes.
    for cell,row in cells:
        target='treedb_mongo' if row['arm']=='gomap' else 'mongodb'; d=cell/'output'/target
        for receipt in sorted(d.glob('*.close.json')):
            regular(receipt); x=read(receipt)
            for name,h in x.get('artifacts_sha256',{}).items():
                require(safe_name(name),'unsafe producer artifact name'); authority(receipt.parent/name,h,receipt,'original producer Close artifact digest')
        state=next(x for x in attempts['attempts'] if x['name']==row['name'])
        manifest=read(cell/'output/manifest.json') if (cell/'output/manifest.json').is_file() else {}
        request=read(cell/'request.json') if (cell/'request.json').is_file() else {}
        identities.append(dict(row,packet_root=str(cell.parent.parent),cell_path=str(cell),fixture_request_path=request.get('environment',{}).get('FIXTURE_BIN'),actual_manifest_fixture=manifest.get('fixture'),actual_manifest_client=manifest.get('client'),actual_server_builds=manifest.get('server_builds'),write_concern=manifest.get('write_concern'),profile=manifest.get('profile')))
        statuses.append(dict(row,packet_root=str(cell.parent.parent),cell_path=str(cell),assembler_status=state,actual_receipts={n:(cell/n).is_file() for n in ('request.json','STARTED.json','FINAL.json','COMPLETE.json','launcher/terminal.json')}))
        required=['request.json']
        if state['status']=='COMPLETION_RECEIPT_PRESENT':
            required+=['STARTED.json','FINAL.json','COMPLETE.json','launcher/start.json','launcher/terminal.json','launcher/stdout.txt','launcher/stderr.txt','output/manifest.json']
            required += ['output/'+target+'/'+phase+suffix for phase in ('load','run_1') for suffix in ('.out','.err','.launch.json','.close.json','.cleanup.json')]
            required += ['output/'+target+'/'+n+'.close.json' for n in ('snapshot_loaded','snapshot_preclose','snapshot_reopened','fixture_write','fixture_verify')]
            if row['arm']=='gomap':
                for prefix in ('server','fixture-write'):
                    cp=d/(prefix+'.evidence')/'owner.checkpoint.json'
                    if not cp.is_file(): missing.append(dict(cell=row['name'],path=str(cp),reason='required current schema2 private owner checkpoint missing'))
                    else:
                        value=read(cp)
                        if type(value.get('schema_version')) is not int or value.get('schema_version')!=2 or 'backend_checkpoint' in value or not value.get('collections_checkpoint_storage',{}).get('success'): missing.append(dict(cell=row['name'],path=str(cp),reason='not successful schema2 owning manager checkpoint'))
            required += ['output/validation.json','output/'+target+'/runtime.json','output/'+target+'/lifecycle.json'] if row['arm']=='gomap' else ['output/reference-complete.json','output/reference-runtime.json']
            if row['class_name']=='durable-B': required+=['output/'+target+'/public-sentinel.json']
        for relative in required:
            if not (cell/relative).is_file(): missing.append(dict(cell=row['name'],path=str(cell/relative),reason='required for actual declared completion'))
        for phase in ('load','run_1'):
            optional=d/(phase+'.actual-command.json')
            if not optional.is_file(): emission_absences.append(dict(cell=row['name'],path=str(optional),reason='emission-specific actual-command witness absent; actual argv remains in original request/launch/manifest when emitted'))
        if row['class_name']=='relaxed': emission_absences.append(dict(cell=row['name'],path=str(d/'public-sentinel.json'),reason='relaxed class has no common-load sentinel by contract'))
        if row['class_name']=='relaxed' and (d/'public-sentinel.json').exists(): missing.append(dict(cell=row['name'],reason='unexpected relaxed sentinel'))
    for actual in plan['packets']:
        for path,h in read(actual/'campaign.json')['bindings'].items(): authority(path,h,actual/'campaign.json','sealed actual packet artifact binding')
    controls=read(packet/'accepted-controls.json')
    for key in ('reviewed_control_a','reviewed_control_b'):
        for path,h in controls[key]['files'].items(): authority(path,h,packet/'accepted-controls.json','original actual reviewed control digest')
    def omit(p,reason,scope):
        p=P(p).absolute(); s=p.lstat() if p.exists() or p.is_symlink() else None
        omissions.append(dict(original_path=str(p),reason=reason,scope=scope,bytes=None if s is None or not stat.S_ISREG(s.st_mode) else s.st_size,device=None if s is None else s.st_dev,inode=None if s is None else s.st_ino,mtime_ns=None if s is None else s.st_mtime_ns,authorities=authorities.get(str(p),[]),authentication='authoritative content digest retained' if authorities.get(str(p)) else 'not content authenticated; stat-only directory/payload outside compact report revalidation scope',retention='original remains in local custody; no external availability claim'))
    def add(p,n,scope):
        p=P(p).absolute(); require(safe_name(n),'unsafe archive member'); require(n not in selected or selected[n]['original_path']==str(p),'duplicate archive name')
        if not p.exists(): missing.append(dict(path=str(p),scope=scope,reason='explicit referenced artifact absent')); return
        s=regular(p)
        if private_path(p) or p.name in PRIVATE_FILES: omit(p,'private/cache directory excluded without reading payload',scope); return
        if p.name in TYPED: omit(p,'full typed payload; original Close digest retained, no rehash',scope); return
        with p.open('rb') as f: magic=f.read(4)
        if magic==b'\x7fELF' or p.suffix in ('.wt','.db','.sst','.a','.o'):
            omit(p,'ELF/DB/compiler payload excluded; original build or custody digest required',scope); return
        if s.st_size>args.max_raw_file_bytes:
            omit(p,'above explicit compact-file cap; retained at original path',scope)
            if scope.startswith('derived owned-process'): missing.append(dict(path=str(p),reason='required owned process projection above compact cap; explicit disposition needed'))
            return
        selected[n]=dict(archive_path=n,original_path=str(p),bytes=s.st_size,sha256=digest(p),scope=scope,encoding='identity')
    def external_projection(p,n,terminal):
        # Publish complete owned rows only. Unrelated process command payloads
        # and full-host snapshots stay at their original path, explicitly omitted.
        regular(p)
        if not terminal.is_file():
            omit(p,'full-host observations omitted: no terminal owned-token membership authority',n)
            missing.append(dict(path=str(terminal),reason='cannot derive required owned-only resource projection without terminal membership')); return
        regular(terminal)
        expected_raw={a['sha256'] for a in authorities.get(str(p),[])}
        t=read(terminal); owned={(x['pid'],x['start_ticks']) for x in t['owned']}; out=generated/(hashlib.sha256(n.encode()).hexdigest()[:20]+'.owned.jsonl'); h=hashlib.sha256()
        fields={'pid','start_ticks','parent','group','state','cpu_ticks','waited_cpu_ticks','rss_bytes','command'}
        with p.open('rb') as source,out.open('xb') as dest:
            for line in source:
                h.update(line); x=json.loads(line); rows=[]
                for r in x['processes']:
                    if (r['pid'],r['start_ticks']) in owned:
                        require(isinstance(r.get('command'),str) and len(r['command'])<=64 and '\n' not in r['command'],'unexpected process command payload; do not publish')
                        rows.append({k:r[k] for k in fields if k in r})
                dest.write((json.dumps(dict(monotonic=x['monotonic'],processes=rows),sort_keys=True)+'\n').encode())
        require(not expected_raw or expected_raw=={h.hexdigest()},'owned-observation raw differs from retained binding')
        provenance=out.with_suffix('.provenance.json')
        write(provenance,dict(kind='owned_process_observation_projection',original_path=str(p),original_sha256=h.hexdigest(),projection_path=str(out),projection_sha256=digest(out),terminal=dict(path=str(terminal),sha256=digest(terminal)),scope='fresh packaging streaming digest of raw full-host bytes; terminal supplies actual owned-token membership, not the raw file digest'))
        authority(p,h.hexdigest(),provenance,'new packaging raw digest provenance, not an original supervisor content hash')
        add(provenance,n+'.provenance.json','derived projection provenance; actual raw digest and membership authority')
        omit(p,'full-host/private unrelated observations omitted; owned-row projection included',n)
        add(out,n+'.owned.jsonl','derived owned-process observation projection, original path/digest and terminal membership retained')
    def walk(base,prefix,scope):
        # Collect original compact Close authorities before handling adjacent
        # typed payloads, including retained tiny lifecycle controls.
        for receipt in sorted(base.glob('*.close.json')):
            regular(receipt)
            for name,h in read(receipt).get('artifacts_sha256',{}).items():
                require(safe_name(name),'unsafe producer artifact name'); authority(receipt.parent/name,h,receipt,'original producer Close artifact digest')
        for p in sorted(base.iterdir()):
            rel=p.relative_to(base).as_posix(); n=prefix+'/'+rel
            require(not p.is_symlink(),'symlink in scoped evidence: '+str(p))
            if p.is_dir():
                if p.name in PRIVATE or p.name in DB or p.name.endswith(('-db','-data')) or p.name.startswith('data-'):
                    omit(p,'DB/cache/private subtree excluded without recursive scan',scope)
                else: walk(p,n,scope)
            elif p.name=='external.jsonl': external_projection(p,n,p.parent/'terminal.json')
            elif p.suffix in SMALL_SUFFIX: add(p,n,scope)
            else: omit(p,'nonselected payload/unknown extension retained in place',scope)
    for name in sorted(ROOT_FILES):
        if (packet/name).is_file(): add(packet/name,'packet/'+name,'actual final packet controller/config/status')
    if (packet/'source-review').is_dir(): walk(packet/'source-review','packet/source-review','accepted actual source/build/applicability receipts')
    if (packet/'tiny-gateway-guards').is_dir(): walk(packet/'tiny-gateway-guards','packet/tiny-gateway-guards','retained tiny lifecycle controls, not final campaign performance samples')
    for child in sorted(packet.iterdir()):
        if child.name not in ROOT_FILES|{'source-review','cells','tiny-gateway-guards'}:
            omit(child,'nonselected packet-root entry/self-mutating output retained without recursive read','packet root explicit omission')
    for cell,row in cells: walk(cell,'cells/'+row['name'],row['class_name']+'/'+str(row['pair'])+'/'+row['arm'])
    if plan['prior']:
        prior=P(plan['prior']['root'])
        for name in sorted(ROOT_FILES):
            if (prior/name).is_file(): add(prior/name,'prior/packet/'+name,'actual original stopped packet controller/config/status')
        rejected=prior/'cells'/EXPECTED[2]['name']
        walk(rejected,'prior/rejected/'+rejected.name,'rejected original observer attempt; never a performance sample')
        for row in EXPECTED[3:]:
            add(prior/'cells'/row['name']/'request.json','prior/unstarted/'+row['name']+'/request.json','original never-started request, not an attempt/sample')

    walk(report,'report','corrected assembler projection, including truthful incomplete/FAILED output')
    add(args.assembler,'support/assembler/assemble_report.py','actual corrected report assembler source')
    # Explicit reference graphs only: campaign bindings, actual control maps,
    # gate and its acceptance receipts, assembler references, selected build refs.
    seeds=[(P(p),h,actual/'campaign.json',None) for actual in plan['packets'] for p,h in read(actual/'campaign.json')['bindings'].items()]+[(P(p),h,packet/'accepted-controls.json',None) for k in ('reviewed_control_a','reviewed_control_b') for p,h in controls[k]['files'].items()]+[(p,None,p,None) for p in args.support_receipt]
    if (packet/'campaign-start.json').exists():
        gate=P(read(packet/'campaign-start.json')['gate_path']); seeds.append((gate,None,packet/'campaign-start.json',None))
    if plan['prior']:
        seeds += [(P(p),h,packet/'PRIOR-PACKET.json',None) for p,h in plan['prior']['value']['authorities'].items()]
    seeds.append((CUSTODY_RECEIPT,CUSTODY_SHA256,CUSTODY_RECEIPT,None))
    def references(x,field=''):
        out=[]
        if isinstance(x,dict):
            if isinstance(x.get('path'),str) and P(x['path']).is_absolute() and SHA.fullmatch(str(x.get('sha256',''))): out.append((P(x['path']),x['sha256'],field))
            for key,value in x.items(): out+=references(value,field+'/'+str(key))
        elif isinstance(x,list):
            for i,value in enumerate(x): out+=references(value,field+'/'+str(i))
        return out
    queue=[(p,0,h,receipt,field) for p,h,receipt,field in seeds]
    while queue:
        p,depth,expected,receipt,field=queue.pop(0); p=p.absolute()
        p,raw_only,disposition=custody_reference(p,expected,receipt,field,exact_cases)
        if disposition: custody_dispositions.append(disposition)
        if p is None: continue
        if disposition: authority(p,expected,CUSTODY_RECEIPT,'exact reviewed archival source custody; original reference retained in dispositions')
        # Check every compact authority edge, including already visited paths.
        n='support/referenced/'+hashlib.sha256(str(p).encode()).hexdigest()[:16]+'/'+p.name
        check_reference_hash(p,expected,selected.get(n))
        if str(p) in visited: continue
        visited.add(str(p))
        if private_path(p) or p.name in PRIVATE_FILES: omit(p,'private/cache reference not opened', 'external reference'); continue
        require(str(p).startswith(('/home/mikers/gomap-','/home/mikers/dev/snissn/gomap/','/usr/bin/')),'external reference outside declared public task/source roots: '+str(p))
        if p.name=='external.jsonl': external_projection(p,n,p.parent/'terminal.json')
        else: add(p,n,'explicit source-bound external receipt/control/build reference')
        check_reference_hash(p,expected,selected.get(n))
        if not raw_only and p!=CUSTODY_RECEIPT and p.name not in TYPED and p.suffix=='.json' and p.is_file() and p.stat().st_size<=args.max_raw_file_bytes and depth<5 and p.name not in ('source.json','deps.json','modules.json','toolchain.json','ALL-TRACKED-OBJECTS.json','NON-DOC-OBJECTS.json'):
            for target,h,target_field in references(read(p)):
                authority(target,h,p,'explicit build/review/report path+digest reference'); queue.append((target,depth+1,h,p,target_field))
    # A missing payload remains an explicit custody absence even when its prior
    # Close digest exists; never reopen a full payload to manufacture authority.
    for original in sorted(authorities):
        path=P(original)
        if path.name in TYPED and not path.exists():
            omit(path,'authoritatively named typed payload absent from retained custody','typed payload custody')
            missing.append(dict(path=original,reason='Close-authorized typed payload absent; retained digest is not present custody'))
    # Required omitted typed payloads need original Close authority; no stat-only
    # claim may silently become accepted complete evidence.
    for omission in omissions:
        current=authorities.get(omission['original_path'],[])
        if current:
            omission['authorities']=current; omission['authentication']='authoritative content digest retained'
    unresolved=[x for x in omissions if P(x['original_path']).name in TYPED and (not x['authorities'] or len({a['sha256'] for a in x['authorities']})!=1)]
    accepted=(report/'COMPLETE.json').exists() and not missing and not unresolved and not (packet/'STOPPED.json').exists()
    write(output/'omissions.json',dict(omissions=omissions,unresolved_required_typed_payloads=unresolved,emission_specific_absences=emission_absences))
    for name in ('package_final_raw.py','verify_final_raw.py'): add(P(__file__).parent/name,'support/packaging/'+name,'actual local selective packager/verifier source')
    add(output/'omissions.json','packet/omissions.json','explicit large/private/DB omissions and actual digest authorities')
    index=dict(schema_version=1,status='COMPLETE_SELECTIVE_RAW_DELIVERY' if accepted else 'INCOMPLETE_OR_FAILED_SELECTIVE_RAW_DELIVERY',measured_source_commit=campaign['source_commit'],measured_source_tree=campaign['source_tree'],campaign_order=EXPECTED,attempts=statuses,required_missing=missing,emission_specific_absences=emission_absences,omissions=omissions,unresolved_required_typed_payloads=unresolved,actual_per_arm_source_roles=identities,source_roles=dict(gomap='actual new gateway and typed schema2 fixture from each GoMap request/build binding',mongodb='actual original5db helper /58c reference control /2237 timed client retained, not relabeled new GoMap fixture',controls=dict(actual_source_commit=controls['source_commit'],scope='original792 public A/B controls plus accepted scoped applicability; historicalc660 schema1 private receipts remain historical, not owner-complete'),checkpoint='current successful GoMap proof must remain schema2/collections_checkpoint_storage; old backend_checkpoint is no alias'),documents=[],archive=dict(path='raw-phase-evidence.tar.gz',sha256=None,members=[selected[n] for n in sorted(selected)]),scope='Selective public raw/control/lifecycle packet, not full DB/ELF/typed snapshot archive, no external availability or performance acceptance claim')
    index['all_attempts']=attempts['all_attempts']
    index['rejected_attempts']=attempts['rejected_attempts']
    index['prior_packet_history']=attempts.get('prior_packet')
    index['actual_packet_order']=campaign['order']
    index['archival_custody']=dict(receipt=dict(path=str(CUSTODY_RECEIPT),sha256=CUSTODY_SHA256),dispositions=custody_dispositions,limits='Historical stale/unavailable proposal content is explicitly non-qualifying. Exact source relocation/export and raw negative-fixture treatment do not waive current campaign/source/lifecycle requirements.')
    archive=output/index['archive']['path']
    with archive.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
        for entry in index['archive']['members']:
            p=P(entry['original_path']);s=regular(p);require(s.st_size==entry['bytes'] and digest(p)==entry['sha256'],'selected source changed before archive')
            info=tarfile.TarInfo(entry['archive_path']);info.size=s.st_size;info.mode=0o644;info.mtime=0;info.uid=info.gid=0
            with p.open('rb') as f:
                before=os.fstat(f.fileno()); require((before.st_dev,before.st_ino,before.st_size)==(s.st_dev,s.st_ino,s.st_size),'source replaced during open')
                class HashedReader:
                    def __init__(self,stream): self.stream=stream; self.hash=hashlib.sha256()
                    def read(self,n):
                        data=self.stream.read(n); self.hash.update(data); return data
                stream=HashedReader(f); tar.addfile(info,stream); after=os.fstat(f.fileno())
                require(stream.hash.hexdigest()==entry['sha256'] and (before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_size,after.st_mtime_ns,after.st_ctime_ns),'source changed during archive read')
    index['archive']['sha256']=digest(archive);index['archive']['bytes']=archive.stat().st_size
    write(output/'index.json',index)
    print(json.dumps(dict(status=index['status'],members=len(selected),archive_bytes=archive.stat().st_size,index_sha256=digest(output/'index.json'),archive_sha256=index['archive']['sha256'])))
if __name__=='__main__': main()
