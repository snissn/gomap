# YCSB comparison

Status: validated-consumer-evidence

TOTAL excludes original client close; close timings remain in receipts.


