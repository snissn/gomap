#!/usr/bin/python3
"""Same-budget, remaining-ten continuation; never revisits the consumed packet."""
import argparse
import hashlib
import importlib.util
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
PRIOR = pathlib.Path('/home/mikers/gomap-5335-shell-helper-final-qualification-20261030')
ORIGINAL = PRIOR / 'packet.py'
ORIGINAL_SHA = '08c7a3b4db2b2851655f50ab5fd8491c35a4dbd0b9d997958ee02b0d097cddd2'
ORIGIN = 4983454.245382293


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def read(p):
    return json.loads(pathlib.Path(p).read_text())


def require(ok, why):
    if not ok:
        raise ValueError(why)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('construct', 'seal', 'run-next'))
    parser.add_argument('input')
    args = parser.parse_args()
    require(sha(ORIGINAL) == ORIGINAL_SHA, 'original controller changed')
    spec = importlib.util.spec_from_file_location('frozen_original_packet', ORIGINAL)
    b = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = b
    spec.loader.exec_module(b)
    declared = b.rows()
    require(len(declared) == 12, 'original twelve-arm declaration changed')
    require(read(PRIOR / 'STOPPED.json')['cell'] == declared[2]['name'], 'different prior stop')
    require(all((PRIOR / 'cells' / r['name'] / 'COMPLETE.json').is_file() for r in declared[:2]), 'prior accepted pair missing')
    require(not (PRIOR / 'cells' / declared[2]['name'] / 'COMPLETE.json').exists(), 'rejected arm was promoted')
    require(not any((PRIOR / 'cells' / r['name'] / 'STARTED.json').exists() for r in declared[3:]), 'previously unstarted arm was dispatched')
    start = read(PRIOR / 'campaign-start.json')
    require(start['monotonic'] == ORIGIN, 'original budget origin changed')
    if args.mode == 'construct':
        require(not (ROOT / 'HELPER-BINDING.json').exists(), 'one-use continuation already constructed')
        helper = pathlib.Path(args.input).resolve()
        require(helper.is_file() and helper != b.SUPERVISOR, 'isolated corrected helper required')
        b.write(ROOT / 'HELPER-BINDING.json', dict(path=str(helper), sha256=sha(helper)))
    helper = read(ROOT / 'HELPER-BINDING.json')
    require(sha(helper['path']) == helper['sha256'], 'corrected helper changed')
    old_supervisor = b.SUPERVISOR
    original_bindings = b.artifact_bindings

    def bindings():
        # Verify every original product/source/control binding using the immutable
        # original observer first, then substitute only the engineering helper.
        b.SUPERVISOR = old_supervisor
        try:
            result = original_bindings()
        finally:
            b.SUPERVISOR = pathlib.Path(helper['path'])
        result.pop(str(old_supervisor))
        result[str(b.SUPERVISOR)] = helper['sha256']
        result[str(pathlib.Path(__file__).resolve())] = sha(__file__)
        result[str(ROOT / 'HELPER-BINDING.json')] = sha(ROOT / 'HELPER-BINDING.json')
        result[str(ROOT / 'PRIOR-PACKET.json')] = sha(ROOT / 'PRIOR-PACKET.json')
        return result

    b.ROOT = ROOT
    b.SUPERVISOR = pathlib.Path(helper['path'])
    b.artifact_bindings = bindings
    b.rows = lambda: declared[2:]
    if args.mode == 'construct':
        authorities = [PRIOR / n for n in ('campaign.json', 'SEALED.json', 'campaign-start.json', 'STOPPED.json')]
        authorities += [PRIOR / 'cells' / r['name'] / 'COMPLETE.json' for r in declared[:2]]
        authorities += [PRIOR / 'cells' / declared[2]['name'] / 'launcher/terminal.json']
        b.write(ROOT / 'PRIOR-PACKET.json', dict(
            prior_root=str(PRIOR), authorities={str(p): sha(p) for p in authorities},
            adopted_valid_cells=declared[:2], rejected_preserved=declared[2],
            remaining_order=declared[2:], original_origin=ORIGIN,
            scope='Two prior accepted arms retain original identities. Rejected G2 is not qualified. One fresh G2 and nine previously unstarted arms use corrected observation only; no workload/product/runtime/cap changes or automatic retries.'))
        b.construct()
        b.write(ROOT / 'campaign-start.json', dict(start, continuation=True, original_start_path=str(PRIOR / 'campaign-start.json')))
    else:
        prior = read(ROOT / 'PRIOR-PACKET.json')
        for p, expected in prior['authorities'].items():
            require(sha(p) == expected, 'prior receipt changed: ' + p)
        require(read(ROOT / 'campaign-start.json')['monotonic'] == ORIGIN, 'continuation reset budget')
        if args.mode == 'seal':
            b.seal(pathlib.Path(args.input))
        else:
            require(any(not (ROOT / 'cells' / r['name'] / 'COMPLETE.json').exists() for r in declared[2:]), 'all remaining cells terminal; do not invoke again')
            b.run_next(pathlib.Path(args.input))


if __name__ == '__main__':
    main()
