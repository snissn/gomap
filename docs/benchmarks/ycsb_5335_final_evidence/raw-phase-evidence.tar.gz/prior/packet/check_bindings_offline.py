#!/usr/bin/python3
"""Focused packet controls; no product/build/Go execution or raw mutation."""
import pathlib,importlib.util,json,copy,ast,hashlib,sys
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('coherent_packet',R/'packet.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
original_read,original_sha,original_git=p.read,p.sha,p.git
checks={}
controls=p.read(p.ACTUAL_CONTROLS)
assert p.control_bindings(controls)==controls
checks['actual792_controls_accepted_by_exact_reviewed_delta']=True
assert controls['source_commit']=='79220385186080e77898fcb99c78a8ea15480241'
assert p.objects(controls['source_commit'])!=p.objects(p.COMMIT)
assert p.objects(controls['source_commit'])==p.objects('c660c3e34523a77f12da9b440c5b6b7def9359f1')
checks['actual_identity_preserved_and_full_equivalence_false']=True

def refuse(name,call,expected):
 try:call()
 except (ValueError,KeyError,TypeError,AttributeError) as exc:
  assert expected in str(exc),(name,str(exc),expected);checks[name]=str(exc)
 else:raise AssertionError('accepted '+name)

refuse('null_actual_source',lambda:p.control_bindings(dict(source_commit=None)),'missing actual control source')
x=copy.deepcopy(controls);x['reviewed_control_a']['reviewed']=False
refuse('unreviewed_control_map',lambda:p.control_bindings(x),'wrong actual reviewed control source/map')
p.read=lambda path:dict(original_read(path),status='PENDING') if pathlib.Path(path)==p.SCOPED_ACCEPT else original_read(path)
refuse('unreviewed_scoped_acceptance',lambda:p.control_bindings(controls),'unaccepted scoped source applicability');p.read=original_read
commit,tree=p.COMMIT,p.TREE;p.COMMIT='15e47e7c85bb14def3619d0bd4abd480d6662a24';p.TREE='971f5775f2e64b3f915459f1510ccdd50fa9eb69'
refuse('wrong_final_source',lambda:p.control_bindings(controls),'wrong scoped final source/tree');p.COMMIT,p.TREE=commit,tree
p.git=lambda *args:original_git(*args)+'\n100644 blob '+('a'*40)+'\tunexpected-owning-product.go' if args==('ls-tree','-r',p.COMMIT) else original_git(*args)
refuse('extra_owning_object',lambda:p.control_bindings(controls),'extra/missing/mode/blob scoped source delta');p.git=original_git
api_object=next(line.split()[2] for line in original_git('ls-tree','-r',p.COMMIT).splitlines() if line.endswith('\tTreeDB/collections/api.go'))
p.git=lambda *args:original_git(*args).replace('100644 blob '+api_object,'100755 blob '+api_object) if args==('ls-tree','-r',p.COMMIT) else original_git(*args)
refuse('changed_object_mode',lambda:p.control_bindings(controls),'extra/missing/mode/blob scoped source delta');p.git=original_git
# Exact successor-test pins are reviewed objects, never a generic test exemption.
for label,path in [('changed_boundary_test_object','TreeDB/collections/legacy_insert_outcome_test.go'),('changed_retirement_test_object','TreeDB/collections/legacy_insert_retirement_event_test.go'),('changed_manifest_object','.github/ci/ci_impact.json'),('changed_main47_durable_root_metadata_reuse_diagnostics_test','TreeDB/db/durable_root_metadata_reuse_diagnostics_test.go'),('changed_main47_durable_root_metadata_reuse_test','TreeDB/db/durable_root_metadata_reuse_test.go'),('changed_main47_catalog_meta_raft_integration_test','TreeDB/internal/raftplacement/catalog_meta_raft_integration_test.go')]:
 object_id=next(line.split()[2] for line in original_git('ls-tree','-r',p.COMMIT).splitlines() if line.endswith('\t'+path))
 p.git=lambda *args,object_id=object_id:original_git(*args).replace(object_id,'a'*40) if args==('ls-tree','-r',p.COMMIT) else original_git(*args)
 refuse(label,lambda:p.control_bindings(controls),'extra/missing/mode/blob scoped source delta');p.git=original_git
p.git=lambda *args:'\n'.join(line for line in original_git(*args).splitlines() if not line.endswith('\tTreeDB/collections/legacy_insert_retirement_event_test.go')) if args==('ls-tree','-r',p.COMMIT) else original_git(*args)
refuse('missing_retirement_test_object',lambda:p.control_bindings(controls),'extra/missing/mode/blob scoped source delta');p.git=original_git
for label,path,message in [('changed_proof',p.APPLICABILITY,'changed scoped applicability/control receipt'),('changed_api',p.SOURCE/'TreeDB/collections/api.go','wrong scoped API bytes'),('changed_route',p.SOURCE/'TreeDB/mongo_gateway/standalone.go','changed scoped route')]:
 p.sha=lambda value,path=path:'0'*64 if pathlib.Path(value)==path else original_sha(value)
 refuse(label,lambda:p.control_bindings(controls),message);p.sha=original_sha
raw=pathlib.Path(next(iter(controls['reviewed_control_a']['files'])))
p.sha=lambda value:'0'*64 if pathlib.Path(value)==raw else original_sha(value)
refuse('changed_original_control_file',lambda:p.control_bindings(controls),'changed control file');p.sha=original_sha
refuse('missing_runtime_merge_gate',lambda:p.gate({}),'runtime/merge gates missing')
refuse('wrong_gateway_runtime_gate',lambda:p.gate(dict(authorized=True,predecessor_merged=True,harness_landed=True,build_source_commit=p.COMMIT,gateway_sha256='0'*64)),'gate source/ELF mismatch')
# Exact AST equivalence of every established runtime/gate/cap/phase/seal function.
old=pathlib.Path('/home/mikers/gomap-5335-custody-final-qualification-20261030/packet.py')
def functions(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
a,b=functions(old),functions(R/'packet.py');assert a.keys()==b.keys() and [k for k in a if a[k]!=b[k]]==['gomap_env']
oldenv=next(n for n in ast.parse(old.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='gomap_env')
newenv=next(n for n in ast.parse((R/'packet.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='gomap_env')
for n in ast.walk(newenv):
 if isinstance(n,ast.keyword) and n.arg=='FIXTURE_BIN':n.value=ast.parse("str(BOOT/'fixture')",mode='eval').body
assert ast.dump(oldenv)==ast.dump(newenv)
checks['runtime_gate_order_caps_seal_phase_and_Close_AST_unchanged']=True
campaign=p.read(R/'campaign.json');assert campaign['order']==p.rows() and len(p.rows())==12
for row in p.rows():
 cell=R/'cells'/row['name'];request=p.read(cell/'request.unsealed.json');assert request['limits']==p.limits(row['arm']);assert 'GOMAXPROCS' not in request['environment'];assert not (cell/'STARTED.json').exists()
 if row['arm']=='gomap':
  assert request['environment']['RECORDCOUNT']=='100000' and request['environment']['OPERATIONCOUNT']=='10000' and request['environment']['THREADCOUNT']=='16'
  assert ('COMMON_LOAD_POLICY' in request['environment'])==(row['class_name']=='durable-B')
 else:
  config=p.read(cell/'reference-preparation-request.unsealed.json');assert config['journal_requested']==(True if row['class_name']=='durable-B' else None);assert ('common_load' in config)==(row['class_name']=='durable-B')
checks['actual12_order_class_policy_counts_caps_no_gomaxprocs_no_started']=True
p.source_guard();assert p.artifact_bindings()==campaign['bindings'];checks['actual_source_ELF_artifact_bindings']=True
with (R/'OFFLINE-BINDING-CONTROLS.json').open('x') as f:json.dump(dict(status='PASS',adapter_sha256=p.sha(R/'packet.py'),checks=checks,actual_control_source=controls['source_commit'],gateway_source=p.COMMIT,gateway_sha256=p.EXPECTED[str(p.BUILD/'bin/gateway')],scope='read-only actual sources/receipts plus synthetic in-memory negative controls; no build/product/Go execution'),f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(dict(status='PASS',checks=len(checks),adapter_sha256=p.sha(R/'packet.py'))))
