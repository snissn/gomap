#!/usr/bin/python3
"""Two bounded actual-producer/lifecycle guards; tiny rates are not performance."""
import importlib.util,json,pathlib,re,sys
import packet as p
ROOT=p.ROOT/'tiny-gateway-guards'
def main():
 profile=sys.argv[1];p.require(profile in ('durable','relaxed'),'profile');p.require(not (ROOT/'STOPPED.json').exists(),'earlier tiny failure; no retry');p.artifact_bindings()
 ROOT.mkdir(exist_ok=True);cell=ROOT/profile;cell.mkdir()
 row=dict(class_name='durable-B' if profile=='durable' else 'relaxed',pair=0,arm='gomap',name='tiny-'+profile)
 env=p.gomap_env(cell,row);env.pop('COMMON_LOAD_POLICY',None);env.update(RECORDCOUNT='64',OPERATIONCOUNT='128',THREADCOUNT='2',PHASE_TIMEOUT_SECONDS='60',HELPER_TIMEOUT_SECONDS='30')
 argv=['/bin/bash',str(p.SOURCE/'scripts/ycsb_compare_mongodb_treedb.sh')]
 limits=dict(wall=180,cpu_soft=90,cpu_hard=95,rss_bytes=2*1024**3,disk_bytes=512*1024**2,file_bytes=64*1024**2,min_free=5*1024**3,poll=.1,grace=10,reap=5,cpu=None,nice=0)
 p.write(cell/'request.json',dict(argv=argv,environment=env,limits=limits,source_commit=p.COMMIT,gateway_sha256=p.EXPECTED[str(p.BUILD/'bin/gateway')],scope='64load/128run2worker random observed-state plus separate64-ID4-worker exact fixture; no common-load sentinel and no performance claim'))
 spec=importlib.util.spec_from_file_location('accepted_tiny_supervisor',p.SUPERVISOR);b=importlib.util.module_from_spec(spec);sys.modules[spec.name]=b;spec.loader.exec_module(b)
 try:
  with b.Supervisor(cell) as supervisor:result=supervisor.run('launcher',argv,str(p.SOURCE),env,b.Limits(**limits))
  p.write(cell/'FINAL.json',result)
  directory=cell/'output/treedb_mongo';text=(directory/'run_1.out').read_text();counts={name:int(re.search(r'^'+name+r'\s+-.*?Count:\s*(\d+)',text,re.M).group(1)) for name in ('READ','UPDATE','TOTAL')};p.require(counts['TOTAL']==128 and counts['READ']>0 and counts['UPDATE']>0 and counts['READ']+counts['UPDATE']==128,'tiny random operation coverage incomplete; no retry')
  row['class_name']=profile;summary=p.summarize(cell,row);summary.update(actual_operation_counts=counts,scope='tiny correctness guard only; rates quarantined; deterministic expected union and random observed-state preservation distinct');p.write(cell/'COMPLETE.json',summary);print('PASS',profile,counts)
 except BaseException as exc:p.write(ROOT/'STOPPED.json',dict(profile=profile,status='FAILED_STOP_NO_RETRY',error=repr(exc)));raise
if __name__=='__main__':main()
