// Existing-public-API journal-fence inquiry. No gateway or crash-durability claim.
package main

import (
    "bytes"
    "encoding/json"
    "errors"
    "flag"
    "fmt"
    "os"
    "path/filepath"
    "runtime"
    "strings"
    "time"

    treedb "github.com/snissn/gomap/TreeDB"
    "github.com/snissn/gomap/TreeDB/collections"
    backenddb "github.com/snissn/gomap/TreeDB/db"
    "go.mongodb.org/mongo-driver/v2/bson"
)

const rows = 64
const collectionName = "journal_prefix_rows"
const sourceHead = "15601589437b3e41ede1f6cac73609dc331fba02"

type config struct {
    Profile string `json:"profile"`
    Boundary string `json:"boundary"`
    DBDir string `json:"dbdir"`
    Report string `json:"report"`
}

type snapshot struct {
    Public map[string]string `json:"public"`
    Backend map[string]string `json:"backend"`
    Manager map[string]string `json:"manager"`
    Unavailable []string `json:"unavailable"`
}

type closeResult struct {
    Owner string `json:"owner"`
    Resource string `json:"resource"`
    ElapsedNS int64 `json:"elapsed_ns"`
    Error string `json:"error,omitempty"`
}

type operation struct {
    Row int `json:"row"`
    InsertNS int64 `json:"insert_ns"`
    InsertSucceeded bool `json:"insert_succeeded"`
    ReturnedIDMatched bool `json:"returned_id_matched"`
    InsertError string `json:"insert_error,omitempty"`
    BoundaryAttempted bool `json:"boundary_attempted"`
    BoundaryNS int64 `json:"boundary_ns"`
    BoundarySucceeded bool `json:"boundary_succeeded"`
    BoundaryError string `json:"boundary_error,omitempty"`
    CheckpointPhysicalSync *bool `json:"checkpoint_physical_sync,omitempty"`
    BatchCreated bool `json:"batch_created"`
    WriteSyncNS int64 `json:"write_sync_ns"`
    WriteSyncSucceeded bool `json:"write_sync_succeeded"`
    WriteSyncError string `json:"write_sync_error,omitempty"`
    BatchClose *closeResult `json:"batch_close,omitempty"`
}

type report struct {
    Schema string `json:"schema"`
    Status string `json:"status"`
    Scope string `json:"scope"`
    SourceHead string `json:"expected_product_source_head"`
    Config config `json:"config"`
    RuntimeVersion string `json:"runtime_version"`
    GOMAXPROCS int `json:"gomaxprocs_observed"`
    NumCPU int `json:"num_cpu_observed"`
    Options map[string]any `json:"options_before_open"`
    Activation map[string]bool `json:"activation"`
    Stats map[string]snapshot `json:"stats"`
    Operations []operation `json:"operations"`
    InsertAttempts int `json:"insert_attempts"`
    InsertSuccesses int `json:"insert_successes"`
    BoundaryAttempts int `json:"boundary_attempts"`
    BoundarySuccesses int `json:"boundary_successes"`
    InsertTotalNS int64 `json:"insert_total_ns"`
    BoundaryTotalNS int64 `json:"boundary_total_ns"`
    LoopNS int64 `json:"loop_ns"`
    OriginalCensusRows int `json:"original_census_rows"`
    ReopenedCensusRows int `json:"reopened_census_rows"`
    FreshReopenAttempted bool `json:"fresh_reopen_attempted"`
    Cleanup []closeResult `json:"cleanup"`
    Error string `json:"error,omitempty"`
}

type owner struct {
    name string
    database *treedb.DB
    backend *backenddb.DB // Borrowed only; never closed separately.
    manager *collections.CollectionManager
    closed bool
}

func errorText(err error) string {
    if err == nil { return "" }
    return err.Error()
}

func options(c config) treedb.Options {
    opts := treedb.OptionsFor(treedb.Profile(c.Profile), c.DBDir)
    opts.MemtableMode = "cow_btree"
    opts.ValueLog.PointerThreshold = 1
    // Leave every maintenance/flush/GC/group option at its normal profile default.
    return opts
}

func openOwner(name string, c config) (*owner, error) {
    database, err := treedb.Open(options(c))
    if err != nil { return nil, err }
    o := &owner{name: name, database: database}
    o.backend, err = database.NativeSemanticBackend()
    if err != nil { return o, err }
    o.manager = collections.NewCollectionManager(o.backend)
    if !o.backend.HasNativeSemanticBridge() || !o.backend.CommandWALEnabled() ||
        !o.manager.UsesNativeCommandWALApply() ||
        database.ResolvedProfile() != treedb.Profile(c.Profile) ||
        database.Stats()["treedb.cache.memtable_mode"] != "cow_btree" {
        return o, errors.New("original public owner did not activate requested native COW command-WAL profile")
    }
    return o, nil
}

func (o *owner) close(r *report) error {
    if o == nil || o.closed { return nil }
    o.closed = true // No retries, including ambiguous or failed Close.
    var joined error
    if o.manager != nil {
        started := time.Now()
        err := o.manager.Close()
        r.Cleanup = append(r.Cleanup, closeResult{o.name, "collection_manager", time.Since(started).Nanoseconds(), errorText(err)})
        joined = errors.Join(joined, err)
    }
    if o.database != nil {
        started := time.Now()
        err := o.database.Close()
        r.Cleanup = append(r.Cleanup, closeResult{o.name, "original_public_db", time.Since(started).Nanoseconds(), errorText(err)})
        joined = errors.Join(joined, err)
    }
    return joined
}

func (o *owner) stats() (snapshot, error) {
    s := snapshot{Public: o.database.Stats(), Backend: o.backend.Stats(), Manager: o.manager.Stats(), Unavailable: make([]string, 0)}
    // A native manager need not populate classic write-domain statistics.
    if s.Manager == nil { s.Unavailable = append(s.Unavailable, "manager.Stats (no exposed nonzero write-domain counters)") }
    if s.Public == nil || s.Backend == nil {
        return s, errors.New("owner stats unavailable")
    }
    // Retain raw owner snapshots, including absent keys. Never use sampled C/W
    // counters as authorization or invent unavailable counters as zero.
    return s, nil
}

func rowID(row int) []byte { return []byte(fmt.Sprintf("row%03d", row)) }

func fixture(row int) ([]byte, error) {
    doc := bson.D{{Key: "_id", Value: int32(row)}}
    for field := 0; field < 10; field++ {
        doc = append(doc, bson.E{Key: fmt.Sprintf("field%d", field), Value: bson.Binary{
            Subtype: 0, Data: bytes.Repeat([]byte{byte(row), byte(field)}, 50),
        }})
    }
    return bson.Marshal(doc)
}

func checkDocument(raw []byte, expected int) error {
    var doc bson.D
    if err := bson.Unmarshal(raw, &doc); err != nil { return err }
    if len(doc) != 11 { return fmt.Errorf("row%d fields=%d want11", expected, len(doc)) }
    seen := make(map[string]bool, 11)
    for _, element := range doc {
        if seen[element.Key] { return fmt.Errorf("duplicate field %q", element.Key) }
        seen[element.Key] = true
        if element.Key == "_id" {
            id, ok := element.Value.(int32)
            if !ok || id != int32(expected) { return fmt.Errorf("row%d typed _id mismatch: %T %v", expected, element.Value, element.Value) }
            continue
        }
        field := -1
        for f := 0; f < 10; f++ {
            if element.Key == fmt.Sprintf("field%d", f) { field = f; break }
        }
        if field < 0 { return fmt.Errorf("unknown field %q", element.Key) }
        value, ok := element.Value.(bson.Binary)
        if !ok || value.Subtype != 0 || len(value.Data) != 100 ||
            !bytes.Equal(value.Data, bytes.Repeat([]byte{byte(expected), byte(field)}, 50)) {
            return fmt.Errorf("row%d field%d typed binary payload mismatch", expected, field)
        }
    }
    if !seen["_id"] { return errors.New("missing typed _id") }
    for field := 0; field < 10; field++ {
        if !seen[fmt.Sprintf("field%d", field)] { return fmt.Errorf("missing field%d", field) }
    }
    return nil
}

func census(c *collections.Collection) (int, error) {
    records, truncated, err := c.ScanDocuments(rows + 1)
    if err != nil { return 0, err }
    if truncated || len(records) != rows {
        return 0, fmt.Errorf("census rows=%d truncated=%t want64,false", len(records), truncated)
    }
    expectedIDs := make(map[string]int, rows)
    for row := 0; row < rows; row++ { expectedIDs[string(rowID(row))] = row }
    seen := make(map[int]bool, rows)
    checked := 0
    for _, record := range records {
        row, ok := expectedIDs[string(record.ID)]
        if !ok || seen[row] { return checked, fmt.Errorf("unexpected or duplicate collection ID %x", record.ID) }
        if err := checkDocument(record.Document, row); err != nil { return checked, err }
        seen[row] = true
        checked++
    }
    return checked, nil
}

func boundary(o *owner, kind string, op *operation) (resultErr error) {
    started := time.Now()
    defer func() {
        op.BoundaryNS = time.Since(started).Nanoseconds()
        op.BoundarySucceeded = resultErr == nil
        op.BoundaryError = errorText(resultErr)
    }()
    if kind == "checkpoint" {
        physical, err := o.manager.SyncForStandaloneWriteConcern()
        op.CheckpointPhysicalSync = &physical
        if err != nil { return err }
        if !physical { return errors.New("native checkpoint unexpectedly reported physicalSync=false") }
        return nil
    }
    // This batch belongs to the SAME original public DB as every native insert.
    // It remains empty: no Set/Delete/Replay, backend alias, or raw barrier.
    batch := o.database.NewBatch()
    if batch == nil { return errors.New("original DB refused empty batch") }
    op.BatchCreated = true
    writeStarted := time.Now()
    writeErr := batch.WriteSync()
    op.WriteSyncNS = time.Since(writeStarted).Nanoseconds()
    op.WriteSyncSucceeded = writeErr == nil
    op.WriteSyncError = errorText(writeErr)
    closeStarted := time.Now()
    closeErr := batch.Close()
    op.BatchClose = &closeResult{o.name, "empty_public_batch", time.Since(closeStarted).Nanoseconds(), errorText(closeErr)}
    return errors.Join(writeErr, closeErr)
}

func runLoop(o *owner, c *collections.Collection, cfg config, docs [][]byte, r *report) (resultErr error) {
    started := time.Now()
    defer func() { r.LoopNS = time.Since(started).Nanoseconds() }()
    for row := 0; row < rows; row++ {
        op := &r.Operations[row]
        op.Row = row
        id := rowID(row)
        r.InsertAttempts++
        insertStarted := time.Now()
        returned, err := c.Insert(id, docs[row])
        op.InsertNS = time.Since(insertStarted).Nanoseconds()
        r.InsertTotalNS += op.InsertNS
        op.InsertError = errorText(err)
        op.InsertSucceeded = err == nil
        if err != nil { return fmt.Errorf("insert row%d (no retry): %w", row, err) }
        r.InsertSuccesses++
        op.ReturnedIDMatched = bytes.Equal(returned, id)
        if !op.ReturnedIDMatched { return fmt.Errorf("insert row%d returned identity mismatch", row) }
        op.BoundaryAttempted = true
        r.BoundaryAttempts++
        err = boundary(o, cfg.Boundary, op)
        r.BoundaryTotalNS += op.BoundaryNS
        if err != nil { return fmt.Errorf("boundary row%d (no retry): %w", row, err) }
        r.BoundarySuccesses++
    }
    return nil
}

func execute(cfg config, r *report) (resultErr error) {
    opts := options(cfg)
    r.Options = map[string]any{
        "memtable_mode": opts.MemtableMode, "value_log_pointer_threshold": opts.ValueLog.PointerThreshold,
        "flush_threshold": opts.FlushThreshold, "background_checkpoint_interval_ns": int64(opts.BackgroundCheckpointInterval),
        "background_checkpoint_idle_duration_ns": int64(opts.BackgroundCheckpointIdleDuration), "max_wal_bytes": opts.MaxWALBytes,
        "maintenance_policy": "normal OptionsFor defaults; no diagnostic maintenance overrides",
    }
    docs := make([][]byte, rows)
    for row := 0; row < rows; row++ {
        var err error
        docs[row], err = fixture(row)
        if err != nil { return fmt.Errorf("fixture row%d: %w", row, err) }
        if err := checkDocument(docs[row], row); err != nil { return err }
    }
    original, err := openOwner("original", cfg)
    if original != nil { defer func() { resultErr = errors.Join(resultErr, original.close(r)) }() }
    if err != nil { return fmt.Errorf("open original: %w", err) }
    r.Activation["original"] = true
    r.Stats["initial"], err = original.stats()
    if err != nil { return err }
    created, err := original.manager.CreateCollection(&collections.CollectionMeta{
        Name: collectionName, Options: collections.CollectionOptions{DocumentFormat: collections.DocumentFormatBSON},
    })
    if err != nil { return fmt.Errorf("create no-index BSON collection: %w", err) }
    if created == nil || created.Options.DocumentFormat != collections.DocumentFormatBSON || len(created.Indexes) != 0 {
        return errors.New("created collection did not retain BSON/no-index shape")
    }
    collection, err := original.manager.OpenCollection(collectionName)
    if err != nil { return err }
    r.Stats["post_create"], err = original.stats()
    if err != nil { return err }
    loopErr := runLoop(original, collection, cfg, docs, r)
    var statsErr error
    r.Stats["post_loop"], statsErr = original.stats() // Outside loop, including failed loop.
    if err = errors.Join(loopErr, statsErr); err != nil { return err }
    r.OriginalCensusRows, err = census(collection)
    if err != nil { return fmt.Errorf("original census: %w", err) }
    if err = original.close(r); err != nil { return fmt.Errorf("original checked Close: %w", err) }
    // Fresh owner is opened only after the original manager AND DB closed.
    r.FreshReopenAttempted = true
    reopened, err := openOwner("fresh_reopen", cfg)
    if reopened != nil { defer func() { resultErr = errors.Join(resultErr, reopened.close(r)) }() }
    if err != nil { return fmt.Errorf("fresh owner open: %w", err) }
    r.Activation["fresh_reopen"] = true
    collection, err = reopened.manager.OpenCollection(collectionName)
    if err != nil { return err }
    r.ReopenedCensusRows, err = census(collection)
    if err != nil { return fmt.Errorf("fresh owner census: %w", err) }
    r.Stats["fresh_reopen_after_census"], err = reopened.stats()
    if err != nil { return err }
    if err = reopened.close(r); err != nil { return fmt.Errorf("fresh owner checked final Close: %w", err) }
    return nil
}

func validateConfig(cfg config) error {
    if cfg.Profile != string(treedb.ProfileCommandWALDurable) && cfg.Profile != string(treedb.ProfileCommandWALRelaxed) {
        return errors.New("-profile must explicitly be command_wal_durable or command_wal_relaxed")
    }
    if cfg.Boundary != "checkpoint" && cfg.Boundary != "fence" { return errors.New("-boundary must explicitly be checkpoint or fence") }
    if !filepath.IsAbs(cfg.DBDir) || !filepath.IsAbs(cfg.Report) { return errors.New("-dbdir and -report must be explicit absolute paths") }
    dbdir, reportPath := filepath.Clean(cfg.DBDir), filepath.Clean(cfg.Report)
    rel, err := filepath.Rel(dbdir, reportPath)
    if err != nil { return err }
    if rel != ".." && !strings.HasPrefix(rel, ".." + string(filepath.Separator)) { return errors.New("report must be outside database directory") }
    if _, err := os.Lstat(dbdir); !errors.Is(err, os.ErrNotExist) {
        if err == nil { return errors.New("database directory must not exist; no reuse or retry") }
        return err
    }
    return nil
}

func main() {
    var cfg config
    flag.StringVar(&cfg.Profile, "profile", "", "explicit command_wal_durable or command_wal_relaxed")
    flag.StringVar(&cfg.Boundary, "boundary", "", "explicit checkpoint or fence")
    flag.StringVar(&cfg.DBDir, "dbdir", "", "fresh, absent absolute database directory")
    flag.StringVar(&cfg.Report, "report", "", "new absolute JSON report file outside database directory")
    flag.Parse()
    r := &report{Schema: "native-journal-prefix-inquiry-v1", Status: "failed", Config: cfg,
        Scope: "64-row serial existing-public-API developmental discriminator; graceful reopen only, not crash durability, gateway ACK qualification, or public YCSB throughput",
        SourceHead: sourceHead, RuntimeVersion: runtime.Version(), GOMAXPROCS: runtime.GOMAXPROCS(0), NumCPU: runtime.NumCPU(),
        Activation: make(map[string]bool), Stats: make(map[string]snapshot), Operations: make([]operation, rows), Cleanup: make([]closeResult, 0),
    }
    for row := range r.Operations { r.Operations[row].Row = row }
    err := validateConfig(cfg)
    if flag.NArg() != 0 { err = errors.Join(err, errors.New("unexpected positional arguments")) }
    var output *os.File
    if err == nil {
        output, err = os.OpenFile(cfg.Report, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
    }
    if err == nil { err = execute(cfg, r) }
    if err == nil { r.Status = "completed-developmental-inquiry" }
    r.Error = errorText(err)
    if output != nil {
        encoder := json.NewEncoder(output)
        encoder.SetIndent("", "  ")
        encodeErr := encoder.Encode(r)
        closeErr := output.Close()
        err = errors.Join(err, encodeErr, closeErr)
        if encodeErr != nil || closeErr != nil {
            r.Status = "failed"
            r.Error = errorText(err)
        }
    }
    // Stdout also retains runtime failure and all attempted cleanup results.
    stdoutErr := json.NewEncoder(os.Stdout).Encode(r)
    err = errors.Join(err, stdoutErr)
    if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
}
