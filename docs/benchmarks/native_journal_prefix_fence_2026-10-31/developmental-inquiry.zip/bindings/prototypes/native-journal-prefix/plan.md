# Four-cell native journal-prefix inquiry: prospective execution packet

**Frozen for final exact-byte review; not executed.** The public campaign/artifact reads and external bounded naming validation have terminally released. `review/native-journal-prefix-quiet-reservation-01.json` reserves these four cells; independent final READY review and all helper-read releases remain required before prepare/run. The reviewed prototype, existing build and prior draft/prereview are preserved. No new build, guard or producer has run during freeze.

The fixed order is durable-checkpoint, relaxed-fence, durable-fence, relaxed-checkpoint. Each cell is one fresh process and absent DB/output, exactly64 serial one-document insert/boundary pairs, no repeats or replacement. Product stays clean baseline `15601589437b3e41ede1f6cac73609dc331fba02` / tree `b71fd9d90733708459d3506bcf152a490bbe0621`; this is not the integrated read candidate or external history-expiry repair. Fixture/OptionsFor/activation/timer/cleanup/census contracts are the immutable reviewed external `main.go` and P1-v2 body (`9c45322d58af158789c0a45f784aef2e4b412eb42319de047ae864f6b24da106`). No production mechanism is selected.

Normal build is retained at `build-01/build.json` SHA256 `809a1a7d3db22577b0effecce97cad20eb2e1d98b69b85815afa9e7b3e94c488`; ELF SHA256 `d040c9bd147bf4bef14a29ce3300be53daf9da2f53b755002f02e3e49f46489a`. Those identities come from the existing build packet, including actual build-tool completion, compiler/toolchain and buildinfo receipts. This authoring task read their small metadata, not the large ELF. Future preflight rehashes every bound input after the timing lane is released. No new build is requested by this packet.

`run.py` verifies the SHA256 of the reviewed point recipe (`926f23502de4c6baa5541438f751914f721c4d384899bcc7440ac99c9d63739c`) before safe absolute-path import. It reuses its digest/read/write/require/git/cpu_contract/acquire_launch_lease functions, without invoking that recipe's main or adopting its point benchmark configuration. The landed guard is `79a545a1d745e848f2aa859896fb962e07204b73`, tree `a9bd76e24d2172afc8cd2d43548f4d71d8e9af20`, unchanged guard SHA256 `b1f5308ce5de5bf1252a77694599f4be4fdf769803b4d7300c08b4901f8d9642`; plan binds its full maintained imported/helper/receipt closure and tool identities. `run` replaces itself with that guard in explicit synthetic mode. There is no new supervisor/controller or workload loop.

Preflight requires exact independent review (`status:READY`, final plan and runner SHA256), unchanged fully clean product/harness HEAD/tree, all input hashes, normal build binding, persistent ext4 mount/free floor, original affinity0..11 and maintained cgroup cpuset/quota validation. Isolated `/usr/bin/python3 -I -B` startup is required. Inherited runtime/profiling/loader/Python overrides and all `TREEDB_`/`GOMAP_` overrides are vetoed before child construction. Child environment is an explicit whitelist plus per-cell fast-mount TMPDIR. GOMAXPROCS remains absent; producer must observe GOMAXPROCS12 and NumCPU12, not forced by flags/environment. These are point observations plus original affinity/quota checks, not continuous verification.

The shared original `/mnt/fast4tb/gomap-host185-perf-custody.lock` device66305/inode54 is opened without following symlinks, identity-checked and exclusively flocked only in `run`, before cell construction. Its inherited original FD stays owned by the exec'd guard through terminal completion. Never create/replace/unlink that lease. The coordinator still owns quiet-host reservation and first-failure disposition; cooperative locking does not prove global host inactivity.

Each cell has the sole existing guard deadline120s, cleanup10 policy, .2s samples, owned-RSS24GiB and free-floor10GiB. There is no producer/test timeout or competing wrapper deadline inside this packet. The external tool must allow the maintained guard and its original cleanup to finish; if the tool yields a running session, retain every start/poll/completion receipt until actual terminal exit. No cancellation or external signal may be interpreted as success. Guard sampling can miss short peaks and its existing receipts explicitly deny whole-interval/unperturbed-timing verification.

The fresh namespace is `/mnt/fast4tb/gmp-jprefix-01`; authoring did not create, reserve or inspect it. `prepare` requires its absence, writes only reviewed start provenance after preflight, and does not acquire the lease or launch anything. `run` requires a fresh cell and every prior same-plan validated completion; it writes launch provenance, then execs the guard. A failed/unfinished cell cannot be consumed again or passed over. First preparation/construction/admission/operation/runtime/resource/lifecycle/tool failure halts this entire campaign; preserve failures and do not repair/retry within the frozen batch.

`finish` is a read/validation step that writes one exclusive completion result, including invalid results on validation failure. It requires actual tool exit0 at `CELL/tool-completion.json`, matching completed guard exit0/status/no errors/no signals, exact command/limits/root identity, sampled bounds and final live[] physical-stop observation. It uses maintained strict JSON, checks producer-file/stdout equality, exact64 successes and ordered row records, all fence WriteSync/batch Close records or native physical checkpoint records, actual runtime12, exact normal options and original/fresh activation, both exact64 owned typed-census attestations and ordered checked manager/DB closes. Per-operation/sum/loop/Close durations must be nonnegative int64, with consistent sums; boolean/float substitutes fail. Initial/post-create/post-loop/fresh raw owner snapshots are retained, nil native manager counters explicitly unavailable. Sampled C/W values are never treated as durability authority. Producer census is an immutable reviewed producer attestation; it is not an independent artifact containing all row values.

Use of externally supplied tool receipts necessarily depends on the coordinator honestly retaining the actual tool return; the recipe cannot cryptographically authenticate an invented receipt. Full start/poll/completion custody and independent artifact review remain mandatory. A completed developmental cell is not public ACK/crash/power-loss acceptance, historical strict-ingestion completion, stable gain or a production optimization. Close may checkpoint; graceful reopen cannot prove the fence alone was crash durable. Summed counters and subdurations are not wall fractions or promises of speedup; forced fences may still issue a sync on durable profiles.

## Commands after final freeze and explicit quiet-lane release

The coordinator obtains a new exact frozen READY review and verifies all helper-read releases before these commands. Flipping launch_ready or changing any bytes invalidates a prior plan hash; review the resulting final bytes. The old prereview cannot authorize execution. Commands below remain prospective until the actual final seal exists.

`REVIEW` below denotes the coordinator's actual absolute independent final review path (for example `/mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/review/native-journal-prefix-plan-review.json`). Pass its literal path as the second argument; do not use a prior source-only review.

```sh
/usr/bin/python3 -I -B /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/run.py prepare REVIEW
```

Execute each run as its own actual tool invocation, retain its completed tool JSON in the named cell, then invoke finish with its actual integer exit. Do not issue the next run until finish succeeded and the coordinator verified custody. The run commands internally select the exact profile/boundary/DB/report argv bound by `plan.json` and `launch.json`.

```sh
/usr/bin/python3 -I -B /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/run.py run REVIEW durable-checkpoint
/usr/bin/python3 -I -B /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/run.py finish REVIEW durable-checkpoint ACTUAL_EXIT /mnt/fast4tb/gmp-jprefix-01/durable-checkpoint/tool-completion.json

/usr/bin/python3 -I -B /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/run.py run REVIEW relaxed-fence
/usr/bin/python3 -I -B /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/run.py finish REVIEW relaxed-fence ACTUAL_EXIT /mnt/fast4tb/gmp-jprefix-01/relaxed-fence/tool-completion.json

/usr/bin/python3 -I -B /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/run.py run REVIEW durable-fence
/usr/bin/python3 -I -B /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/run.py finish REVIEW durable-fence ACTUAL_EXIT /mnt/fast4tb/gmp-jprefix-01/durable-fence/tool-completion.json

/usr/bin/python3 -I -B /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/run.py run REVIEW relaxed-checkpoint
/usr/bin/python3 -I -B /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/run.py finish REVIEW relaxed-checkpoint ACTUAL_EXIT /mnt/fast4tb/gmp-jprefix-01/relaxed-checkpoint/tool-completion.json
```

Never substitute literal zero for an unobserved actual exit. Preserve each full original tool return separately from child status and retain all yielded starts/polls. After four clean cells, the coordinator independently reviews artifacts and compares all outcomes/timers/raw counter deltas within each profile. A successful hypothesis may justify a future ticket revision; no production edit follows automatically.
