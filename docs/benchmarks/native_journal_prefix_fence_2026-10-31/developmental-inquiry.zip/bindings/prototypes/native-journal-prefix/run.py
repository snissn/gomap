"""Thin four-cell existing-API inquiry; run execs the landed maintained guard."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

PLAN = Path(__file__).with_name('plan.json')
HELPER = Path('/mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/review/integrated-maintained-point-run-01.py')
HELPER_SHA = '926f23502de4c6baa5541438f751914f721c4d384899bcc7440ac99c9d63739c'


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def preflight(plan, review, h):
    h.require(plan['launch_ready'] is True and plan['pending_freeze'] == [], 'unresolved freeze')
    h.require(h.digest(__file__) == plan['runner_sha256'], 'runner changed')
    h.require(Path(review).is_absolute(), 'absolute independent review receipt required')
    approval = h.read(review)
    h.require(approval['status'] == 'READY' and approval['plan_sha256'] == h.digest(PLAN)
              and approval['runner_sha256'] == h.digest(__file__), 'independent exact frozen review required')
    for name in plan['forbidden_environment']:
        h.require(name not in os.environ, 'inherited override: ' + name)
    for name in os.environ:
        h.require(not any(name.startswith(prefix) for prefix in plan['forbidden_environment_prefixes']), 'inherited storage/diagnostic override: ' + name)
    h.require(sorted(os.sched_getaffinity(0)) == list(range(12)), 'affinity differs')
    for tool in ('/usr/bin/git', '/usr/bin/findmnt', '/usr/bin/taskset'):
        h.require(plan['input_sha256'].get(tool) == h.digest(tool), 'bound preflight tool changed')
    mount = json.loads(subprocess.check_output(['/usr/bin/findmnt', '-J', '-T', '/mnt/fast4tb'], text=True, timeout=15))['filesystems'][0]
    h.require(mount['source'] == '/dev/nvme0n1p1' and mount['fstype'] == 'ext4', 'wrong persistent mount')
    fs = os.statvfs(Path(plan['output']).parent)
    h.require(fs.f_bavail * fs.f_frsize >= plan['caps']['free_bytes'] and os.access(Path(plan['output']).parent, os.W_OK), 'free floor/write access')
    for path, sha in plan['input_sha256'].items():
        h.require(type(sha) is str and h.digest(path) == sha, 'changed frozen input: ' + path)
    for source in (plan['harness'], plan['product']):
        root = source['source_directory']
        h.require(h.git(root, 'rev-parse', 'HEAD') == source['commit'] and h.git(root, 'rev-parse', 'HEAD^{tree}') == source['tree'], 'source identity changed')
        h.require(not h.git(root, 'status', '--porcelain=v1', '--untracked-files=all', '--ignored'), 'source not fully clean')
    h.require(plan['harness']['landed'] is True, 'guard must be landed')
    for rel, row in plan['helper_closure'].items():
        path = str(Path(plan['harness']['source_directory']) / rel)
        h.require(plan['input_sha256'].get(path) == row['sha256'] and
                  h.git(plan['harness']['source_directory'], 'rev-parse', 'HEAD:' + rel) == row['git_blob'], 'helper binding changed')
    h.require(set(plan['helper_closure']) >= set(plan['required_helpers']), 'incomplete guard closure')
    required = [str(HELPER), plan['producer'], plan['binary'], plan['guard'], plan['build_receipt'],
                plan['landed_guard_receipt'], sys.executable, '/usr/bin/python3', '/bin/bash', '/usr/bin/env',
                '/usr/bin/git', '/usr/bin/findmnt', '/usr/bin/taskset']
    h.require(all(path in plan['input_sha256'] for path in required), 'missing required input binding')
    build = h.read(plan['build_receipt'])
    h.require(build['source_commit'] == plan['product']['commit'] and build['source_tree'] == plan['product']['tree']
              and build['source_directory'] == plan['product']['source_directory'] and build['source_clean_before_after'] is True
              and build['prototype'] == plan['producer'] and build['prototype_sha256'] == plan['input_sha256'][plan['producer']]
              and build['binary'] == plan['binary'] and build['binary_sha256'] == plan['input_sha256'][plan['binary']]
              and type(build['actual_build_exit_code']) is int and build['actual_build_exit_code'] == 0
              and build['normal_no_race_no_overlay'] is True, 'normal build binding changed')
    sys.path.insert(0, plan['scripts_dir'])
    observer = load_module('frozen_jprefix_observer', Path(plan['scripts_dir']) / 'ycsb_runtime_observer.py')
    policy = {'leader_affinity': sorted(os.sched_getaffinity(0)), 'cgroup': observer.quota_snapshot(os.getpid())}
    h.cpu_contract(policy, observer)
    return {'mount': mount, 'available_bytes': fs.f_bavail * fs.f_frsize, 'cpu_policy': policy,
            'review_sha256': h.digest(review), 'loadavg': Path('/proc/loadavg').read_text()}


def producer_argv(plan, label):
    cell = Path(plan['output']) / label
    row = plan['cells'][label]
    return [plan['binary'], '-profile', row['profile'], '-boundary', row['boundary'],
            '-dbdir', str(cell / 'db'), '-report', str(cell / 'producer.json')]


def integer(value, h, label):
    h.require(type(value) is int and 0 <= value <= (1 << 63) - 1, 'invalid nonnegative int64: ' + label)
    return value


def validate_producer(p, plan, label, strict, h):
    cell, selected = Path(plan['output']) / label, plan['cells'][label]
    expected_config = dict(profile=selected['profile'], boundary=selected['boundary'], dbdir=str(cell / 'db'), report=str(cell / 'producer.json'))
    h.require(p['schema'] == 'native-journal-prefix-inquiry-v1' and p['status'] == 'completed-developmental-inquiry' and p.get('error', '') == '', 'producer failed')
    h.require(strict.same(p['config'], expected_config) and p['expected_product_source_head'] == plan['product']['commit'], 'producer identity/config differs')
    h.require(p['runtime_version'] == 'go1.26.10' and type(p['gomaxprocs_observed']) is int and p['gomaxprocs_observed'] == 12
              and type(p['num_cpu_observed']) is int and p['num_cpu_observed'] == 12, 'actual runtime differs')
    h.require(strict.same(p['options_before_open'], plan['options_before_open']), 'normal options/shape changed')
    h.require(strict.same(p['activation'], {'original': True, 'fresh_reopen': True}) and p['fresh_reopen_attempted'] is True, 'native activation/reopen missing')
    for name in ('insert_attempts', 'insert_successes', 'boundary_attempts', 'boundary_successes', 'original_census_rows', 'reopened_census_rows'):
        h.require(integer(p[name], h, name) == 64, 'incomplete exact64: ' + name)
    operations = p['operations']
    h.require(type(operations) is list and len(operations) == 64, 'require all64 operation records')
    for row, op in enumerate(operations):
        h.require(integer(op['row'], h, 'row') == row, 'row identity/order differs')
        for name in ('insert_succeeded', 'returned_id_matched', 'boundary_attempted', 'boundary_succeeded'):
            h.require(op[name] is True, 'unsuccessful operation: ' + name)
        for name in ('insert_error', 'boundary_error', 'write_sync_error'):
            h.require(op.get(name, '') == '', 'operation error: ' + name)
        for name in ('insert_ns', 'boundary_ns', 'write_sync_ns'):
            integer(op[name], h, name)
        if selected['boundary'] == 'fence':
            h.require(op['batch_created'] is True and op['write_sync_succeeded'] is True and 'checkpoint_physical_sync' not in op, 'missing/wrong fence')
            close = op['batch_close']
            h.require(close['owner'] == 'original' and close['resource'] == 'empty_public_batch' and close.get('error', '') == '', 'batch Close failed/missing')
            integer(close['elapsed_ns'], h, 'batch Close')
        else:
            h.require(op['checkpoint_physical_sync'] is True and op['batch_created'] is False and op['write_sync_succeeded'] is False
                      and op['write_sync_ns'] == 0 and 'batch_close' not in op, 'wrong native checkpoint shape')
    h.require(integer(p['insert_total_ns'], h, 'insert total') == sum(op['insert_ns'] for op in operations), 'insert timer sum differs')
    h.require(integer(p['boundary_total_ns'], h, 'boundary total') == sum(op['boundary_ns'] for op in operations), 'boundary timer sum differs')
    h.require(integer(p['loop_ns'], h, 'loop') >= p['insert_total_ns'] + p['boundary_total_ns'], 'combined loop cannot exclude measured operations')
    cleanup = p['cleanup']
    expected = [('original', 'collection_manager'), ('original', 'original_public_db'), ('fresh_reopen', 'collection_manager'), ('fresh_reopen', 'original_public_db')]
    h.require(type(cleanup) is list and [(item['owner'], item['resource']) for item in cleanup] == expected, 'exact checked original/fresh lifecycle missing')
    for item in cleanup:
        h.require(item.get('error', '') == '', 'manager/DB Close failed')
        integer(item['elapsed_ns'], h, 'owner Close')
    h.require(set(p['stats']) == {'initial', 'post_create', 'post_loop', 'fresh_reopen_after_census'}, 'snapshot phases differ')
    for phase, snap in p['stats'].items():
        for name in ('public', 'backend'):
            values = snap[name]
            h.require(type(values) is dict and values and all(type(k) is str and type(v) is str for k, v in values.items()), 'missing raw owner snapshot')
        h.require(snap['public']['treedb.cache.memtable_mode'] == 'cow_btree' and snap['public']['treedb.profile.resolved'] == selected['profile'], 'snapshot activation changed')
        h.require(type(snap['unavailable']) is list and all(type(x) is str for x in snap['unavailable']), 'invalid unavailable counters')
        manager = snap['manager']
        h.require(manager is None or (type(manager) is dict and all(type(k) is str and type(v) is str for k, v in manager.items())), 'invalid manager counters')
        h.require(manager is not None or snap['unavailable'], 'nil manager counters not declared unavailable')
    # The immutable producer performs the full typed64 census; its counters are
    # external attestations, not independent copies of all row payloads.


def finish(plan, label, actual_exit, tool_path, review, h):
    cell = Path(plan['output']) / label
    receipt = {'cell': label, 'status': 'invalid', 'guard_process_exit_code': actual_exit,
               'plan_sha256': h.digest(PLAN), 'runner_sha256': h.digest(__file__)}
    try:
        h.require(tool_path.is_absolute() and tool_path.resolve() == (cell / 'tool-completion.json').resolve(), 'retain actual completed tool JSON in cell')
        actual = h.read(tool_path)
        h.require(type(actual.get('exit_code')) is int and actual['exit_code'] == actual_exit == 0, 'actual guard tool failed/incomplete')
        receipt['actual_tool_sha256'] = h.digest(tool_path)
        receipt['postflight'] = preflight(plan, review, h)
        strict = load_module('frozen_jprefix_json', Path(plan['scripts_dir']) / 'ycsb_evidence_json.py')
        guard = strict.read(cell / 'guard/result.json')
        h.require(guard['synthetic'] is True and guard['status'] == 'guard-completed-pending-independent-artifact-review'
                  and type(guard['exit_code']) is int and guard['exit_code'] == 0 and guard['errors'] == [] and guard['cleanup_signals'] == [], 'guard failed/intervened')
        h.require(guard['whole_interval_verified'] is False and guard['unperturbed_timing_verified'] is False, 'guard scope changed')
        h.require(strict.same(guard['command'], producer_argv(plan, label)) and guard['cwd'] == str(cell)
                  and strict.same(guard['limits'], plan['guard_limits']), 'guard command/limits differ')
        root = strict.read(cell / 'guard/root.identity.json')
        h.require(strict.same(root['process'], guard['root_identity']), 'root identity differs')
        samples = [strict.loads(line) for line in (cell / 'guard/samples.jsonl').read_text().splitlines()]
        h.require(len(samples) >= 2 and samples[-1]['live'] == [], 'guard terminal physical-stop sample missing')
        for sample in samples:
            h.require(integer(sample['rss_bytes'], h, 'RSS') <= plan['caps']['rss_bytes'] and integer(sample['free_bytes'], h, 'free') >= plan['caps']['free_bytes'], 'sampled resource limit crossed')
            h.require(type(sample['elapsed_seconds']) in (int, float) and 0 <= sample['elapsed_seconds'] < 120, 'deadline crossed')
        h.require(integer(guard['max_rss_bytes'], h, 'max RSS') == max(x['rss_bytes'] for x in samples)
                  and integer(guard['min_free_bytes'], h, 'min free') == min(x['free_bytes'] for x in samples), 'resource summary differs')
        p = strict.read(cell / 'producer.json')
        h.require(strict.same(p, strict.loads((cell / 'guard/stdout.log').read_text())), 'producer file/stdout differ or incomplete')
        validate_producer(p, plan, label, strict, h)
        launch = strict.read(cell / 'launch.json')
        h.require(launch['plan_sha256'] == h.digest(PLAN) and strict.same(launch['producer_argv'], producer_argv(plan, label))
                  and strict.same(launch['environment'], dict(plan['environment'], TMPDIR=str(cell / 'tmp'))), 'launch binding differs')
        receipt['artifact_sha256'] = {str(path.relative_to(cell)): h.digest(path) for path in
            [cell / 'producer.json', cell / 'launch.json', cell / 'guard/result.json', cell / 'guard/execution-start.json',
             cell / 'guard/root.identity.json', cell / 'guard/samples.jsonl', cell / 'guard/stdout.log', cell / 'guard/stderr.log']}
        receipt['scope'] = plan['scope']
        receipt['status'] = 'validated-developmental-cell'
    except BaseException as error:
        receipt['error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        h.write(cell / 'completion.json', receipt)


def main():
    if sys.flags.isolated != 1 or not sys.dont_write_bytecode:
        raise ValueError('invoke /usr/bin/python3 -I -B')
    if hashlib.sha256(HELPER.read_bytes()).hexdigest() != HELPER_SHA:
        raise ValueError('reviewed thin helper changed before import')
    h = load_module('reviewed_point_recipe_helpers', HELPER)
    h.require(len(sys.argv) >= 3, 'prepare REVIEW | run REVIEW LABEL | finish REVIEW LABEL ACTUAL_EXIT TOOL_JSON')
    plan, mode, review = h.read(PLAN), sys.argv[1], sys.argv[2]
    out = Path(plan['output'])
    if mode == 'prepare':
        h.require(len(sys.argv) == 3 and not out.exists() and not out.is_symlink(), 'fresh namespace required')
        host = preflight(plan, review, h)
        out.mkdir()
        h.write(out / 'start.json', {'plan_sha256': h.digest(PLAN), 'preflight': host, 'scope': plan['scope']})
        return
    h.require(mode in ('run', 'finish') and len(sys.argv) >= 4, 'invalid action')
    label = sys.argv[3]
    h.require(label in plan['order'], 'unknown cell')
    h.require(h.read(out / 'start.json')['plan_sha256'] == h.digest(PLAN), 'frozen plan changed')
    cell = out / label
    if mode == 'run':
        h.require(len(sys.argv) == 4 and not cell.exists() and not cell.is_symlink(), 'consumed cell')
        for previous in plan['order'][:plan['order'].index(label)]:
            completed = h.read(out / previous / 'completion.json')
            h.require(completed['status'] == 'validated-developmental-cell' and completed['plan_sha256'] == h.digest(PLAN), 'prior failed/unfinished/different-plan cell')
        host = preflight(plan, review, h)
        lease_fd = h.acquire_launch_lease(plan)
        host['quiet_lease'] = dict(plan['quiet_lease'], inherited_guard_fd=lease_fd)
        cell.mkdir()
        (cell / 'tmp').mkdir()
        env = dict(plan['environment'], TMPDIR=str(cell / 'tmp'))
        producer = producer_argv(plan, label)
        argv = ['/usr/bin/python3', '-B', plan['guard'], '--scripts-dir', plan['scripts_dir'], '--synthetic',
                '--out', str(cell / 'guard'), '--cwd', str(cell), '--filesystem', '/mnt/fast4tb',
                '--deadline', '120', '--cleanup-seconds', '10', '--interval', '.2',
                '--rss-cap-bytes', '25769803776', '--free-floor-bytes', '10737418240', '--'] + producer
        h.write(cell / 'launch.json', {'plan_sha256': h.digest(PLAN), 'argv': argv, 'producer_argv': producer,
            'environment': env, 'preflight': host, 'execution': 'execvpe replaces recipe with maintained guard; original lease FD inherited until guard terminal exit'})
        os.chdir(cell)
        os.execvpe(argv[0], argv, env)
        return
    h.require(len(sys.argv) == 6 and not (cell / 'completion.json').exists(), 'immutable finish requires actual tool completion')
    finish(plan, label, int(sys.argv[4]), Path(sys.argv[5]), review, h)


if __name__ == '__main__':
    main()
