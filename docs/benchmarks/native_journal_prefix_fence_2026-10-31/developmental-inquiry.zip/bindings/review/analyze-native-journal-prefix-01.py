#!/usr/bin/python3
"""Analyze the fixed four existing-API inquiry cells without selecting samples."""
import datetime
import decimal
import hashlib
import json
import pathlib
import statistics

ROOT = pathlib.Path('/mnt/fast4tb/gmp-jprefix-01')
BASE = pathlib.Path('/mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58')
PLAN = BASE / 'prototypes/native-journal-prefix/plan.json'
plan = json.loads(PLAN.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
selected = ['treedb.cache.checkpoint.runs', 'treedb.cache.checkpoint.total_ms',
            'treedb.command_wal.group_commit.commits_total', 'treedb.command_wal.group_commit.groups_total',
            'treedb.command_wal.group_commit.forced_total', 'treedb.command_wal.group_commit.syncs_total',
            'treedb.command_wal.group_commit.wait_ns_total', 'treedb.command_wal.sync.count_total',
            'treedb.command_wal.sync.ns_total']
cells = {}
bindings = {str(PLAN): sha(PLAN), str(pathlib.Path(__file__)): sha(pathlib.Path(__file__))}
for label in plan['order']:
    cell = ROOT / label
    p = json.loads((cell/'producer.json').read_text())
    assert p['status'] == 'completed-developmental-inquiry' and len(p['operations']) == 64
    assert all(p[k] == 64 for k in ['insert_successes', 'boundary_successes', 'original_census_rows', 'reopened_census_rows'])
    g = json.loads((cell/'guard/result.json').read_text())
    assert g['exit_code'] == 0 and not g['errors'] and not g['cleanup_signals']
    deltas = {}
    for domain in ['public', 'backend']:
        before = p['stats']['post_create'][domain]
        after = p['stats']['post_loop'][domain]
        changes = {}
        for key in before.keys() & after.keys():
            if before[key] == after[key]:
                continue
            record = {'before': before[key], 'after': after[key]}
            try:
                a, b = decimal.Decimal(before[key]), decimal.Decimal(after[key])
                if a.is_finite() and b.is_finite():
                    record['numeric_difference'] = str(b-a)
            except decimal.InvalidOperation:
                pass
            changes[key] = record
        deltas[domain] = dict(sorted(changes.items()))
    counters = {}
    for key in selected:
        before = p['stats']['post_create']['public'][key]
        after = p['stats']['post_loop']['public'][key]
        counters[key] = {'before': before, 'after': after, 'difference': str(decimal.Decimal(after)-decimal.Decimal(before))}
    times = {}
    for metric in ['insert_ns', 'boundary_ns', 'write_sync_ns']:
        samples = [op[metric] for op in p['operations']]
        times[metric] = {'all64': samples, 'sum': sum(samples), 'median': statistics.median(samples), 'min': min(samples), 'max': max(samples)}
    assert times['insert_ns']['sum'] == p['insert_total_ns'] and times['boundary_ns']['sum'] == p['boundary_total_ns']
    cells[label] = {'config': p['config'], 'insert_total_ns': p['insert_total_ns'], 'boundary_total_ns': p['boundary_total_ns'], 'loop_ns': p['loop_ns'], 'loop_rows_per_sec_diagnostic_only': 64e9/p['loop_ns'], 'operation_timers': times, 'selected_post_create_to_post_loop_counters': counters, 'all_changed_snapshot_values': deltas, 'max_rss_bytes': g['max_rss_bytes'], 'min_free_bytes': g['min_free_bytes'], 'cleanup': p['cleanup']}
    for rel in ['producer.json', 'launch.json', 'completion.json', 'tool-completion.json', 'tool-chunks.json', 'finish-tool.json', 'finish-tool-chunks.json', 'guard/result.json']:
        q = cell / rel
        bindings[str(q)] = sha(q)
comparisons = {}
for profile in ['durable', 'relaxed']:
    fence, checkpoint = cells[profile+'-fence'], cells[profile+'-checkpoint']
    comparisons[profile] = {k: {'fence': fence[k], 'checkpoint': checkpoint[k], 'fence_over_checkpoint': fence[k]/checkpoint[k], 'difference_percent': (fence[k]/checkpoint[k]-1)*100} for k in ['insert_total_ns', 'boundary_total_ns', 'loop_ns', 'loop_rows_per_sec_diagnostic_only']}
report = {'status': 'ALL_FOUR_CELLS_ANALYZED_PENDING_INDEPENDENT_AUDIT', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': plan['scope'], 'order': plan['order'], 'source': plan['product'], 'cells': cells, 'within_profile_single_cell_comparisons': comparisons, 'input_sha256': bindings, 'limits': ['One cell per profile/boundary, no alternating repeat or steady-state/public YCSB speedup claim.', 'Every operation and complete original/fresh lifecycle outcome retained; no replacement, exclusion or retry.', 'Post-create/post-loop snapshots bracket insert plus boundary loops; counts and summed durations are not disjoint wall fractions or durability authority.', 'Public and backend snapshots may expose the same counters; never sum domains. Snapshot differences can be gauges/maxima and are not all monotonic counters.', 'Fence loop checkpoints zero does not prove crash durability. Original graceful Close may checkpoint outside the loop.', 'This validates reachability/usefulness only; gateway integration, partial-DDL/auth/index/dictionary closure, held sync/failure/Close/crash proof and strict100k qualification remain required.']}
q = ROOT/'analysis.json'
assert not q.exists()
q.write_text(json.dumps(report, indent=2)+'\n')
lines = ['# Existing native journal-fence inquiry', '', report['scope'], '', '| Cell | Insert sum, ms | Boundary sum, ms | Loop, ms | Diagnostic loop rows/s | Checkpoints | Command-WAL sync calls |', '|---|---:|---:|---:|---:|---:|---:|']
for label in plan['order']:
    c = cells[label]
    lines.append(f"| {label} | {c['insert_total_ns']/1e6:.6f} | {c['boundary_total_ns']/1e6:.6f} | {c['loop_ns']/1e6:.6f} | {c['loop_rows_per_sec_diagnostic_only']:.6f} | {c['selected_post_create_to_post_loop_counters']['treedb.cache.checkpoint.runs']['difference']} | {c['selected_post_create_to_post_loop_counters']['treedb.command_wal.sync.count_total']['difference']} |")
lines += ['', 'Both fence cells have zero loop checkpoint runs; both checkpoint cells have 64. Durable sync calls remain 128 in both cells; relaxed fence has 64 versus 128 checkpoint calls. These are bracketed observations, not an already-durable no-I/O optimization or crash proof.', '', *report['limits'], '', 'Analysis SHA256: '+sha(q)]
(ROOT/'analysis.md').write_text('\n'.join(lines)+'\n')
print((ROOT/'analysis.md').read_text())
print(json.dumps({'analysis_sha256': sha(q), 'comparisons': comparisons}, indent=2))
