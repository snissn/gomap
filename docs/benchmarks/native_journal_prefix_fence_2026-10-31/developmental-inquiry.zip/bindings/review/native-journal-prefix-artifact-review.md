# Native journal-prefix independent artifact review

VALID_FOR_DECLARED_DEVELOPMENTAL_SCOPE. No material findings. All 256 operations remain included; all reported coordinator metrics independently match.

Frozen plan `38547fab61f680a6a0d3c69d4767ae2f76b19b245b15d3ec8facfc851f84448c`, final seal `c94cf488c54fe681d74550cbe5d826804282c192206bb9c42ad81b8886395587`, coordinator analysis `b23f8287d8acc8420a9d5ad4d5889c4d213e712b4215a098bc63c7d9c5755a0e`. Prior 55-input exact source review reused; current plan, runner, producer, ELF, build and all completion/analysis bindings rehashed. No workload or DB access performed.

| Cell | Insert sum ms | Boundary sum ms | Loop ms | Checkpoints | WAL sync calls | WAL file-sync calls |
|---|---:|---:|---:|---:|---:|---:|---:|
| durable-checkpoint | 111.521076 | 2496.683418 | 2608.422818 | 64 | 128 | 192 |
| relaxed-fence | 3.310805 | 81.338773 | 84.708904 | 0 | 64 | 64 |
| durable-fence | 86.457681 | 31.014421 | 117.558885 | 0 | 128 | 128 |
| relaxed-checkpoint | 9.607861 | 2698.754851 | 2708.577378 | 64 | 128 | 192 |

All 64 outcomes per cell, exact returned identities, both 64-row typed full-census attestations, original/fresh native activation, normal options, observed 12 CPUs/GOMAXPROCS and 16 checked manager/DB Closes pass. All 128 fence empty-public-batch WriteSync/Close outcomes pass. Per-operation timers, WriteSync and Close times, raw post-create to post-loop differences and all added snapshot keys are retained in the JSON.

The terminal actual run/guard/finish exits are 0 for every cell. Exact synthetic guard command/limits match 120s, 0.2s, 24 GiB RSS, 10 GiB account-available free space and 10s cleanup. All sampled caps pass; terminal live arrays are empty, errors/signals absent. Initial `execution-start.status=failed` is the maintained guard initializer, superseded by the terminal result. Fixed order, fresh cell namespaces, no extra cells and all tool chunks are retained.

Within each profile, fence replaced 64 loop checkpoints with 0. The command-WAL sync count and file-sync call count are different counters, as the table shows. Namespace/value-log sync work and checkpoint cleanup also differ. Neither duplicated public/backend stats nor overlapping stage durations are added. Newly appearing derived stats have no assumed-zero baseline.

All 12 before/after/delta entries in the frozen terminology supplement independently match the raw-stat calculations. Supplement SHA256: `51b8a1cf39ce691cfe5f2797f26a0d84c8db5ee6f4fcb3c476ecfaeb52352dc7`. These are source-defined call counters, without syscall tracing or causal wall-time fractions.

The large loop-duration difference makes the existing journal-fence seam consequential for a separately reviewed general construction. This audit selects no production mechanism and establishes no stable speedup. Fence-cell graceful original Close can checkpoint outside the loop; the JSON separately retains those Close times. Typed census results are source-bound producer attestations, with no independent DB scan. Crash/power-loss durability, changed gateway ACK, held-sync/failure behavior, strict 100k ingestion and public YCSB performance remain unproved.

All source/artifact/ELF/hash reads are released after sealing this review.
