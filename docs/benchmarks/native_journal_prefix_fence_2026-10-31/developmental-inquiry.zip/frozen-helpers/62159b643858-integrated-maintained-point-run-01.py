"""Landed small-fixture point benchmark guardrail; existing Go benchmark output.

No workload changes or supervisor: run replaces this process with maintained guard.
"""
import hashlib
import fcntl
import stat
import importlib.util
import json
import math
import re
import os
from pathlib import Path
import subprocess
import sys

PLAN = Path(__file__).with_name('integrated-maintained-point-plan.json')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')


def git(root, *args):
    return subprocess.check_output(['/usr/bin/git', '-C', str(root), *args], text=True, timeout=30).strip()


def cpu_contract(policy, observer):
    require(policy['leader_affinity'] == list(range(12)), 'expected affinity 0..11')
    for row in policy['cgroup']['ancestors']:
        if row['cpu.max'] is not None:
            quota, period = row['cpu.max'].split()
            require(quota == 'max' or int(quota) >= 12 * int(period), 'CPU quota below12')
        value = row['cpuset_effective_cpus']
        require(type(value) is str, 'cpuset must be observer range string')
        observer.validate_cpulist(value)
        cpus = set()
        for item in value.split(','):
            ends = [int(x) for x in item.split('-')]
            cpus.update(range(ends[0], ends[-1] + 1))
        require(set(range(12)) <= cpus, 'cpuset excludes selected CPUs')


def preflight(plan, review):
    require(plan['launch_ready'] is True and plan['pending_freeze'] == [], 'unresolved freeze')
    require(digest(__file__) == plan['runner_sha256'], 'runner changed')
    approval = read(review)
    require(approval['status'] == 'READY' and approval['plan_sha256'] == digest(PLAN)
            and approval['runner_sha256'] == digest(__file__), 'independent exact-plan review required')
    for name in plan['forbidden_environment']:
        require(name not in os.environ, 'inherited override: ' + name)
    require(sorted(os.sched_getaffinity(0)) == list(range(12)), 'affinity differs')
    for tool in ('/usr/bin/git', '/usr/bin/findmnt', '/usr/bin/taskset'):
        require(plan['input_sha256'].get(tool) == digest(tool), 'preflight tool changed: ' + tool)
    mount = json.loads(subprocess.check_output(['/usr/bin/findmnt', '-J', '-T', '/mnt/fast4tb'], text=True, timeout=15))['filesystems'][0]
    require(mount['source'] == '/dev/nvme0n1p1' and mount['fstype'] == 'ext4', 'wrong persistent mount')
    v = os.statvfs(Path(plan['output']).parent)
    require(v.f_bavail * v.f_frsize >= plan['caps']['free_bytes'] and os.access(Path(plan['output']).parent, os.W_OK), 'free floor/write access')
    for path, sha in plan['input_sha256'].items():
        require(type(sha) is str and digest(path) == sha, 'frozen input changed: ' + path)
    harness = plan['harness']
    require(harness['landed'] is True, 'guard landing unresolved')
    for source in [harness] + list(plan['arms'].values()):
        root = source['source_directory']
        require(git(root, 'rev-parse', 'HEAD') == source['commit'] and git(root, 'rev-parse', 'HEAD^{tree}') == source['tree'], 'source identity changed')
        require(not git(root, 'status', '--porcelain=v1', '--untracked-files=all', '--ignored'), 'source not fully clean')
    required = [plan['producer'], plan['guard'], plan['landed_guard_receipt'], plan['go'],
                sys.executable, '/usr/bin/python3', '/bin/bash', '/usr/bin/env',
                '/usr/bin/git', '/usr/bin/findmnt', '/usr/bin/taskset']
    for arm in plan['arms'].values():
        required += [arm['binary'], arm['build_receipt']]
        build = read(arm['build_receipt'])
        require(build['source_commit'] == arm['commit'] and build['tree'] == arm['tree'] and build['cwd'] == arm['source_directory']
                and build['binary'] == arm['binary'] and build['binary_sha256'] == plan['input_sha256'].get(arm['binary'])
                and build['producer_sha256'] == plan['producer_sha256'] and build['build_exit_code'] == 0
                and build['clean_before_after'] is True, 'build binding changed')
    for path in required:
        require(path in plan['input_sha256'], 'missing closure input: ' + str(path))
    for rel, row in plan['helper_closure'].items():
        path = str(Path(harness['source_directory']) / rel)
        require(plan['input_sha256'].get(path) == row['sha256']
                and git(harness['source_directory'], 'rev-parse', 'HEAD:' + rel) == row['git_blob'], 'helper binding changed')
    require(set(plan['helper_closure']) >= set(plan['required_helpers']), 'incomplete helper closure')
    sys.path.insert(0, plan['scripts_dir'])
    spec = importlib.util.spec_from_file_location('frozen_observer', Path(plan['scripts_dir']) / 'ycsb_runtime_observer.py')
    observer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(observer)
    policy = {'leader_affinity': sorted(os.sched_getaffinity(0)), 'cgroup': observer.quota_snapshot(os.getpid())}
    cpu_contract(policy, observer)
    return {'mount': mount, 'available_bytes': v.f_bavail * v.f_frsize, 'cpu_policy': policy,
            'loadavg': Path('/proc/loadavg').read_text(), 'diskstats': Path('/proc/diskstats').read_text(),
            'review_sha256': digest(review)}


def acquire_launch_lease(plan):
    lease = plan['quiet_lease']
    fd = os.open(lease['path'], os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        identity = os.fstat(fd)
        require(stat.S_ISREG(identity.st_mode) and identity.st_dev == lease['device']
                and identity.st_ino == lease['inode'], 'wrong quiet lease identity')
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        current = os.stat(lease['path'], follow_symlinks=False)
        require((current.st_dev, current.st_ino) == (identity.st_dev, identity.st_ino), 'quiet lease replaced')
        os.set_inheritable(fd, True)
        return fd
    except BaseException:
        os.close(fd)
        raise


def main():
    require(sys.flags.isolated == 1 and sys.dont_write_bytecode, 'invoke /usr/bin/python3 -I -B')
    require(len(sys.argv) >= 3, 'prepare REVIEW | run REVIEW LABEL | finish REVIEW LABEL EXIT TOOL_JSON')
    plan = read(PLAN)
    mode, review = sys.argv[1:3]
    out = Path(plan['output'])
    if mode == 'prepare':
        require(len(sys.argv) == 3 and not out.exists() and not out.is_symlink(), 'fresh namespace required')
        host = preflight(plan, review)
        out.mkdir()
        (out / 'tmp').mkdir()
        write(out / 'start.json', {'plan_sha256': digest(PLAN), 'preflight': host, 'scope': plan['scope']})
        return
    require(mode in ('run', 'finish') and len(sys.argv) >= 4, 'invalid action')
    label = sys.argv[3]
    require(label in plan['order'], 'unknown label')
    require(read(out / 'start.json')['plan_sha256'] == digest(PLAN), 'changed frozen plan')
    cell, arm = out / label, plan['arms'][label[0]]
    if mode == 'run':
        require(len(sys.argv) == 4 and not cell.exists() and not cell.is_symlink(), 'consumed cell')
        for previous in plan['order'][:plan['order'].index(label)]:
            require(read(out / previous / 'completion.json')['status'] == 'validated-developmental-cell', 'prior failed/unfinished cell')
        host = preflight(plan, review)
        lease_fd = acquire_launch_lease(plan)
        host['quiet_lease'] = dict(plan['quiet_lease'], inherited_guard_fd=lease_fd)
        cell.mkdir()
        (cell / 'tmp').mkdir()
        env = dict(plan['environment'], TMPDIR=str(cell / 'tmp'))
        argv = ['/usr/bin/python3', '-B', plan['guard'], '--scripts-dir', plan['scripts_dir'], '--synthetic',
                '--out', str(cell / 'guard'), '--cwd', str(cell), '--filesystem', '/mnt/fast4tb',
                '--deadline', '120', '--cleanup-seconds', '10', '--interval', '.2',
                '--rss-cap-bytes', '25769803776', '--free-floor-bytes', '10737418240', '--', arm['binary'],
                '-test.run=^$', '-test.bench=' + plan['bench_selector'], '-test.benchtime=10000x',
                '-test.count=1', '-test.benchmem', '-test.timeout=2m']
        write(cell / 'launch.json', {'argv': argv, 'environment': env, 'preflight': host,
            'execution': 'execvpe replaces recipe with guard; coordinator retains actual completed tool result'})
        os.chdir(cell)
        os.execvpe(argv[0], argv, env)
        return
    require(len(sys.argv) == 6 and not (cell / 'completion.json').exists(), 'finish REVIEW LABEL ACTUAL_EXIT TOOL_JSON; immutable completion')
    receipt = {'cell': label, 'arm': label[0], 'guard_process_exit_code': int(sys.argv[4]), 'status': 'invalid'}
    try:
        tool = Path(sys.argv[5])
        require(tool.is_absolute() and tool.resolve() == (cell / 'tool-completion.json').resolve(), 'retain actual tool completion in cell')
        actual = read(tool)
        require(type(actual.get('exit_code')) is int and actual['exit_code'] == receipt['guard_process_exit_code'] == 0, 'actual guard process failed')
        receipt['actual_tool_sha256'] = digest(tool)
        receipt['postflight'] = preflight(plan, review)
        guard = read(cell / 'guard/result.json')
        require(guard['synthetic'] is True and guard['status'] == 'guard-completed-pending-independent-artifact-review'
                and guard['exit_code'] == 0 and guard['errors'] == [] and guard['cleanup_signals'] == [], 'guard failed/intervened')
        text = (cell / 'guard/stdout.log').read_text()
        stderr = (cell / 'guard/stderr.log').read_text()
        require(text.splitlines().count('PASS') == 1, 'missing/duplicate Go PASS')
        require(not re.search(r'(?m)^(?:FAIL|--- FAIL|panic:|fatal error:)', text + '\n' + stderr), 'Go failure marker')
        rows = []
        for line in text.splitlines():
            if not line.startswith('Benchmark'):
                continue
            match = re.fullmatch(r'(Benchmark\S+)\s+(\d+)\s+(.+)', line)
            require(match is not None, 'malformed benchmark metric row')
            name, count, tail = match.groups()
            require(int(count) == 10000, 'benchmark operation count differs')
            fields = tail.split()
            require(len(fields) == 8, 'unexpected benchmark metric columns')
            metrics = {}
            for value, unit in zip(fields[::2], fields[1::2]):
                require(unit not in metrics, 'duplicate metric unit')
                number = float(value)
                require(math.isfinite(number) and number >= 0, 'nonfinite/negative metric')
                metrics[unit] = number
            require(set(metrics) == {'ns/op', 'reads/s', 'B/op', 'allocs/op'}
                    and metrics['ns/op'] > 0 and metrics['reads/s'] > 0, 'benchmark metric units differ')
            rows.append({'name': name, 'count': int(count), 'metrics': metrics, 'raw': line})
        require([row['name'] for row in rows] == plan['expected_metric_names'],
                'require exactly clients1 then16 all-fields rows with actual runtime suffix-12')
        receipt['metrics'] = rows
        receipt['runtime_scope'] = 'actual Go benchmark name suffix at benchmark start; not continuous; no explicit cpu/GOMAXPROCS override'
        receipt['status'] = 'validated-developmental-cell'
    except BaseException as error:
        receipt['error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        write(cell / 'completion.json', receipt)


if __name__ == '__main__':
    main()
