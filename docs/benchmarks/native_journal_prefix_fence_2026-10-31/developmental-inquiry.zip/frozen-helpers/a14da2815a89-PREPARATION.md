# Native journal-prefix existing-API inquiry

Source-only preparation; no Go invocation, formatting, build, test, guard, database open, or workload has been executed. This directory contains one external Go main file. It changes no repository source. Product APIs were inspected in clean `baseline-integrated`, head `15601589437b3e41ede1f6cac73609dc331fba02`, tree `b71fd9d90733708459d3506bcf152a490bbe0621`. P1 body SHA256 is `9c45322d58af158789c0a45f784aef2e4b412eb42319de047ae864f6b24da106`.

The canonical build compiles the named external main file from the pinned product module root, reusing that root's maintained `go.mod`, `go.sum` and raft replacement. No external dependency graph, copied helper, overlay, generated codec, or standalone module is needed. Coordinator must bind those module files, actual source/compiler/normal ELF, runtime environment and argv in the eventual frozen manifest. The embedded expected head is a provenance label; it does not authenticate the checkout or ELF itself.

## Source behavior and scope

Each process performs exactly one selected profile/boundary cell: 64 serial one-document `Collection.Insert` operations into one no-index BSON collection. IDs are explicit unique collection keys `row000` through `row063`; BSON `_id` is int32(row). Each of ten fields is subtype-0 binary with exactly 100 bytes, repeating the two bytes row/field 50 times. This is a deterministic diagnostic fixture, not the original random alphabetic go-ycsb fixture or a gateway request/ACK comparison. Source uses the maintained mongo-driver/v2 BSON marshal/unmarshal codec and exported collection APIs.

Open is `treedb.Open(treedb.OptionsFor(profile, dir))`, overriding only `MemtableMode="cow_btree"` and persistent-value `ValueLog.PointerThreshold=1`. Unlike `indexedSliceOptions`, maintenance is not disabled or retuned. `NativeSemanticBackend` activates this original owner; its handle remains borrowed and is never separately closed. Native bridge, command WAL, native manager apply, resolved profile and COW mode must all activate. Creation must return BSON format and no indexes. Initial/post-create/post-loop snapshots retain original public DB, borrowed backend and manager stats outside the timed loop. Nil native manager Stats is recorded as unavailable: its existing classic write-domain counters may legitimately be absent. Missing raw keys are absent, not inferred zero. Backend snapshots expose canonical `treedb.command_wal.next_lsn` and `durable_wal_lsn`; public snapshots expose cache checkpoints and existing group counters. Statistics never authorize a durable cut.

`checkpoint` calls the existing manager `SyncForStandaloneWriteConcern` after each successful insert and requires native physicalSync=true. `fence` creates an empty batch from the SAME original public DB, calls `WriteSync`, then checks `Close` before proceeding, joining both errors. It never calls a raw/legacy backend barrier or constructs a second owner. Existing `command_wal_public_cached.go:writeCOW` routes that empty explicit sync through `syncPublicCommandWAL`. The forced fence may still sync an already-durable prefix; no no-I/O reuse is claimed.

The report retains every attempted insert and boundary result, separate insert/boundary elapsed durations, fence WriteSync/batch-Close subdivisions, success/attempt counts and the combined loop duration. Combined loop includes diagnostic bookkeeping, identity checks and timer overhead; sums of subdurations are not an exact wall-time partition. Fixtures, owner snapshots, censuses and final closes are outside that loop. No per-operation print, stats sampling, instrumentation, internal hooks or self-timed repetition is added. Unattempted rows retain explicit false attempt/success indicators and their original row numbers.

First operation/construction/lifecycle error stops that process without retry or substitution. On ordinary errors all opened manager/DB resources are closed once, both close errors are retained and joined with the original error; batch WriteSync and Close errors remain separately visible. The borrowed backend is never closed. On success, the original exact 64-row owned scan verifies every collection key, typed int32 `_id`, all ten typed binary values, subtype, lengths and bytes; truncation, extras, duplicate/missing keys or fields fail. After checked original manager and DB Close, a fresh public owner opens the same directory and repeats that full census, then checks its manager/DB final Close. No fresh owner overlaps the original. A failed original Close prevents reopen. This is graceful-reopen preservation: Close can checkpoint, so this cannot prove crash-safe prefix durability or certify a replacement explicit-journal ACK boundary.

CLI requires all four flags explicitly; profiles are only canonical durable/relaxed, boundary is only checkpoint/fence, DB directory must be absent, paths absolute, report outside DB and new (exclusive create). Runtime version, observed NumCPU/GOMAXPROCS and before-Open option values are recorded without forcing runtime parallelism. Normal JSON is emitted after cleanup both to the exclusive report and stdout; stdout also preserves report-write/Close failure and actual exit becomes nonzero. A guard kill/panic may leave an incomplete report and must be a failed cell; the producer adds no supervisor, signal handler or retry. Report/config/open failures cannot qualify a cell. Standard flag-parser errors use its normal nonzero exit and stderr.

## Exact prospective build and producer argv (not executed)

Run the build only after source review, outside timing. From `/mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/baseline-integrated`, with coordinator-created fresh build directory and the existing wrapper's fast-mount TMP/cache paths:

```sh
GOMAXPROCS=2 /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/native-build/run-go build -mod=readonly -p 2 -o /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/build/native-journal-prefix /mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/main.go
```

This uses the existing Go 1.26.10 wrapper, not `go run`. Preserve compiler/version/build receipts and freeze the resulting normal ELF hash. Build directory is prospective and has not been created. The build-only GOMAXPROCS=2 must not leak into execution.

Prospective producer argv, each to be wrapped by the coordinator's frozen LANDED maintained guard in synthetic mode, under the original host lease, after final independent plan review. No direct unguarded workload is authorized by these examples. The fresh short root `/mnt/fast4tb/gmp-jprefix-01` is an example for the coordinator to reserve/verify, not an allocation made here. Parent output directories must be created by that preparation; DB/report targets must not exist.

```sh
/mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/build/native-journal-prefix -profile command_wal_durable -boundary checkpoint -dbdir /mnt/fast4tb/gmp-jprefix-01/durable-checkpoint/db -report /mnt/fast4tb/gmp-jprefix-01/durable-checkpoint/producer.json
/mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/build/native-journal-prefix -profile command_wal_relaxed -boundary fence -dbdir /mnt/fast4tb/gmp-jprefix-01/relaxed-fence/db -report /mnt/fast4tb/gmp-jprefix-01/relaxed-fence/producer.json
/mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/build/native-journal-prefix -profile command_wal_durable -boundary fence -dbdir /mnt/fast4tb/gmp-jprefix-01/durable-fence/db -report /mnt/fast4tb/gmp-jprefix-01/durable-fence/producer.json
/mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58/prototypes/native-journal-prefix/build/native-journal-prefix -profile command_wal_relaxed -boundary checkpoint -dbdir /mnt/fast4tb/gmp-jprefix-01/relaxed-checkpoint/db -report /mnt/fast4tb/gmp-jprefix-01/relaxed-checkpoint/producer.json
```

The outer plan must preserve the ticket's four-cell order, first-failure halt, unforced GOMAXPROCS12/affinity0..11, normal environment (especially no maintenance-disable/debug/profiling overrides), 24GiB owned-RSS/10GiB free floor/200ms samples, sole 120s guard deadline plus 10s cleanup, actual tool exit and terminal physical-stop custody. The producer observes but does not police the host contract or serialize the four cells; that remains the existing guard/controller's role. Do not treat raw successful process exit as full guard/contract acceptance.

## Source provenance/API availability

- `TreeDB/profiles.go:OptionsFor`, `public.go:Open/NewBatch/Batch.WriteSync/Stats/Close/ResolvedProfile`; no missing public opener/fence API.
- `TreeDB/native_semantic.go:NativeSemanticBackend`: existing original-owner activation and borrowed lifetime.
- `TreeDB/native_command_wal_group_test.go` and `native_existing_indexed_safe_slice_test.go`: original public/native manager constructor pattern only; their disabled-maintenance and large-threshold tuning is excluded.
- `TreeDB/collections/api.go:CreateCollection/OpenCollection/Insert/ScanDocuments/SyncForStandaloneWriteConcern/Close/Stats`, `native_command_wal_apply.go:UsesNativeCommandWALApply`; owned ScanDocuments output, checked original lifecycle.
- `TreeDB/command_wal_public_cached.go:writeCOW`: empty same-owner public batch explicit WriteSync, with checked public batch Close.
- `TreeDB/db/command_wal_stats.go`, `caching/db.go`, `command_wal_group_commit.go`: existing owner counters, including unavailable-manager distinction; no new counters.

Independent source review and build are still required. This artifact can reject/advance a mechanism inquiry; it cannot qualify public throughput, prove power-loss/crash recovery, complete historical strict ingestion, or authorize production checkpoint/lock removal.

## Source-only preparation hashes

SHA256 values read after authoring (no compiler invoked):

| File relative to retained E root | SHA256 |
| --- | --- |
| `prototypes/native-journal-prefix/main.go` | `deec6097ff069188bbc92c6f0575e22fcef87b71dd2c74634d0fa4aaf18e9671` |
| `baseline-integrated/go.mod` | `2dcddbc32b8ff06dc73c6ed987b92988ed4a239e396d5a9e20119b2b97bf82c4` |
| `baseline-integrated/go.sum` | `d6dd36ca5b03d24e6598a25ce1cc0014e24fbc311c0b65f57aefe5fd146e2a25` |
| `baseline-integrated/TreeDB/profiles.go` | `60e637ca9ad0493f5ebac36bf49ed18bbc2b4fe04c93aadbca25004e675c9742` |
| `baseline-integrated/TreeDB/native_semantic.go` | `4f08933cdacf75978a453f4a39c098cdc4cb9374350425cbb2532004a66509da` |
| `baseline-integrated/TreeDB/public.go` | `237112a0a3807722db97edf547c8495801f4ee5e8d245a063b39c96d5e2691fb` |
| `baseline-integrated/TreeDB/command_wal_public_cached.go` | `913b5da6f428ceee652eca7275d3f16817f60ebb3d058da3971331973ff4e3f9` |
| `baseline-integrated/TreeDB/collections/api.go` | `9ca8f58c61d4f72e22f3949540a9f6aaab8ee99d52bc8776c4c1dd4a6ef9bad4` |
| `baseline-integrated/TreeDB/collections/native_command_wal_apply.go` | `401dd82e50cc3eedeb4b6056aae49f6534bae52f102fe2beb7718336516f6d3e` |
| `baseline-integrated/TreeDB/db/command_wal_stats.go` | `2527de12bc201bf1c2b4db0c0d3fe5ce3f130b59a1c4e228f5da409d0bec228c` |
| `native-build/run-go` | `e99023cc14fa99aa4b9eee74718943d94d309c7b6e7475a4f76754c66ab3a3ac` |

The wrapper names `/home/mikers/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.10.linux-amd64` as GOROOT and sets fast-mount TMPDIR/GOCACHE. Compiler, actual binary and buildinfo hashes remain coordinator prebuild/freeze obligations, not fabricated preparation results.
