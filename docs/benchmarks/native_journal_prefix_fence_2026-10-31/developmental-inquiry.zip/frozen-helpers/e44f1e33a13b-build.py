"""Build-only reviewed external P1 prototype; never executes producer."""
import datetime,fcntl,hashlib,json,os,stat,subprocess
from pathlib import Path
E=Path('/mnt/fast4tb/gomap-mongo-perf-graph-6a9s7h58')
OUT=Path(__file__).parent
ROOT=E/'baseline-integrated'
SOURCE=E/'prototypes/native-journal-prefix/main.go'
REVIEW=E/'review/native-journal-prefix-prototype-review.json'
GO=E/'native-build/run-go'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['/usr/bin/git','-C',str(ROOT),*args],text=True).strip()
assert sorted(p.name for p in OUT.iterdir())==['build.py']
assert digest(SOURCE)=='deec6097ff069188bbc92c6f0575e22fcef87b71dd2c74634d0fa4aaf18e9671'
review=json.loads(REVIEW.read_text());assert review['verdict']=='READY_FOR_BOUNDED_BUILD'
for path,row in review['bindings'].items():assert digest(E/path)==row['sha256'],path
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
assert head=='15601589437b3e41ede1f6cac73609dc331fba02' and tree=='b71fd9d90733708459d3506bcf152a490bbe0621'
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
fd=os.open('/mnt/fast4tb/gomap-host185-perf-custody.lock',os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC)
st=os.fstat(fd);assert stat.S_ISREG(st.st_mode) and (st.st_dev,st.st_ino)==(66305,54)
fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);os.set_inheritable(fd,True)
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
for key in ('GOGC','GOMEMLIMIT','GODEBUG','GOFLAGS','GOEXPERIMENT','LD_PRELOAD','LD_AUDIT'):assert key not in env,key
env['GOMAXPROCS']='2'
steps=[]
def call(label,args,timeout=600):
    before=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT/(label+'.stdout')).open('xb') as out,(OUT/(label+'.stderr')).open('xb') as err:
        result=subprocess.run([str(x) for x in args],cwd=ROOT,env=env,stdout=out,stderr=err,timeout=timeout)
    row={'label':label,'argv':[str(x) for x in args],'cwd':str(ROOT),'start_utc':before,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode}
    steps.append(row);(OUT/'execution.json').write_text(json.dumps({'steps':steps,'build_only':True},indent=2)+'\n')
    assert result.returncode==0,row
    return row
call('go-env',[GO,'env','-json','GOROOT','GOTOOLDIR','GOVERSION','GOOS','GOARCH','GOFLAGS','GOEXPERIMENT','CGO_ENABLED'],30)
tc=json.loads((OUT/'go-env.stdout').read_text());assert tc['GOVERSION']=='go1.26.10'
call('go-version',[GO,'version'],30);call('compiler-version',[GO,'tool','compile','-V'],30)
assert 'go1.26.10' in (OUT/'compiler-version.stdout').read_text()
(OUT/'source.patch').write_bytes(subprocess.check_output(['/usr/bin/git','-C',str(ROOT),'diff','--binary','HEAD']))
binary=OUT/'native-journal-prefix'
step=call('build',[GO,'build','-p','2','-mod=readonly','-o',binary,SOURCE])
call('buildinfo',[GO,'version','-m',binary],30)
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==tree
assert not git('status','--porcelain=v1','--untracked-files=all','--ignored')
assert digest(SOURCE)==review['bindings']['prototypes/native-journal-prefix/main.go']['sha256']
receipt={'schema_version':1,'scope':'normal build only; external reviewed prototype; no producer execution/test/public acceptance','source_commit':head,'source_tree':tree,'source_directory':str(ROOT),'source_clean_before_after':True,'source_patch_sha256':digest(OUT/'source.patch'),'prototype':str(SOURCE),'prototype_sha256':digest(SOURCE),'review':str(REVIEW),'review_sha256':digest(REVIEW),'normal_no_race_no_overlay':True,'binary':str(binary),'binary_sha256':digest(binary),'argv':step['argv'],'actual_build_exit_code':step['exit_code'],'toolchain':tc,'tool_sha256':{str(p):digest(p) for p in (GO,Path(tc['GOROOT'])/'bin/go',Path(tc['GOTOOLDIR'])/'compile',Path(__file__))},'build_environment':{'GOMAXPROCS':'2','LD_LIBRARY_PATH':'absent','runtime_use':'build only'},'buildinfo_sha256':digest(OUT/'buildinfo.stdout'),'all_actual_command_exits':[x['exit_code'] for x in steps],'embedded_vcs_claim':False,'executed':False}
(OUT/'build.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'state':'NORMAL_BUILD_PASS_NOT_EXECUTED','binary_sha256':receipt['binary_sha256'],'receipt_sha256':digest(OUT/'build.json')}),flush=True)
