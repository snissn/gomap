# Bounded retained-evidence harness pre-review

Decision: **ACCEPT scoped local Mac recipe**, conditional on freezing the actual producer, server, benchmark, helper and configuration before collection and rejecting incomplete/error-bearing samples. This acceptance covers honest local throughput observations, checked go-ycsb client Close, and observed-state preservation. It does not qualify the Linux-only #5335 protocol, certify durable-B anew, or recover a discarded original Close return.

Reviewed clean GoMap source: `2590d1e9e443c3f968303ce91b3c82933a714f12` in `/Users/michaelseiler/dev/snissn/gomap-readme-benchmarks-20261112`. Reviewed producer: clean detached `3c8148495b8d4490cf0ec30e9eb92d14a7a71bac` in `/tmp/gomap-readme-benchmarks-20261112/go-ycsb-source`. Read root AGENTS.md and codex-issue-graph-executor retained-evidence/adviser policy. Read-only adviser; no builds, benchmark runs, source edits or GitHub mutations performed.

## Maintained paths and boundaries

- **Unchanged Linux YCSB supervisor is blocked on native macOS.** `scripts/ycsb_mongodb_reference.md:39-61` requires image/build/runtime provenance, Linux procfs/pidfd custody, Linux/amd64 and exact supported ELF64 x86_64 ET_EXEC observer binding. `:142-156` accepts only the reviewed MongoDB8.2.7 mirror/origin source mapping. `:243-257` additionally requires a prior valid tiny lifecycle support packet and matching binaries. Offline prepare does not bootstrap Mac qualification. Do not edit these checks down or claim their validator passed.
- **Direct checked-Close producer is portable in the inspected route.** Upstream `cmd/go-ycsb/main.go:195-205` executes `finishCommand` and exits1 for joined cleanup failures. `cmd/go-ycsb/close_receipt.go:29-34,40-72` reads the four receipt variables, observes the original DB/workload Close, creates the receipt exclusively and joins command/Close/publication errors. `db/mongodb/db.go:42-43` returns actual driver Disconnect. These inspected implementations contain no Linux-only observation. Keep the same compiled Mac producer for both products and all arms.
- **Existing standalone gateway can provide checked native Mac Close.** Build entry is `go build -o ... ./TreeDB/mongo_gateway/server.go` (maintained launcher:190-191). `TreeDB/mongo_gateway/server.go:111,135-147` uses SIGTERM cancellation and joins original owner Close into exit status. Leave `YCSB_SERVER_RECEIPT_DIR` unset: `internal/ycsbevidence/process_other.go:7-11` rejects procfs evidence on non-Linux; `receipt.go:105-108,172-175` makes the unset observer inert while still calling original Close.
- **Existing typed fixture CLI is useful without Linux supervisor.** `scripts/ycsb_correctness_fixture.go:644-682` supports `snapshot` with loaded/preclose/reopened stages, selects `ycsb.usertable`, and requires explicit identities/profile/outputs. `:742-781` checks driver Close and records errors. `:827-851` emits full typed state and checks deterministic reopened state. Separate deterministic fixtures use their own database and must remain untimed. MongoDB reference profile is `mongodb_w1_default`; private owner checkpoint must not be enabled on Mac or mistaken for public Mongo semantics.
- **Client shape has an existing faithful maintained wrapper.** `mongo_gateway_fast_client_matrix.sh:14-41` selects200000 documents,2indexes,batch1000,16producers/readers,100000 concurrent reads, BSON gateway shape, prebuild, settled reads and command_wal_relaxed. Default TreeDB modes are driver, driver-command, driver-command-raw, raw-wire-tcp, native-wire-tcp and direct. Mongo has a separately labeled driver-unack row. Current TreeDB rejects driver-unack (`mongo_gateway_bench/main.go:730-734`); remove the stale TreeDB unack row from README instead of substituting another run.
- **Full sweep can use existing compare wrapper.** Explicit100000 documents,secondary0/1/2,BSON,driver-command-raw,command_wal_relaxed,range_index=true reproduces the requested shape. Include age_1 even for displayed secondary0 (`README.md:352-355`; `full_benchmark_report_2026-06-17.md:69-72`). Reader/writer sweep and all operation counts must be explicit in new local report; old June summary does not establish every original option.

## Exact direct YCSB command shape

Source authority: `scripts/ycsb_compare_mongodb_treedb.sh:407-417`; add explicit uniform distribution so reliance on a default is unnecessary. Invoke once for load, then once for run per fresh arm. Use a fresh database/server lifetime per pair/arm; do not count repeated runs on one loaded fixture as independent samples.

```sh
env -u GOMAXPROCS \
  YCSB_CLOSE_RECEIPT_PATH="$OUT/$PHASE.close.json" \
  YCSB_PHASE_ID="$FRESH_PHASE_ID" \
  YCSB_CLIENT_BUILD_ID="$FROZEN_CLIENT_BUILD_ID" \
  YCSB_PROFILE="$DECLARED_PROFILE" \
  "$GOYCSB_BIN" "$PHASE" mongodb \
  -p "mongodb.url=mongodb://$ADDR/ycsb?w=1$JOURNAL_SUFFIX" \
  -p recordcount=100000 -p operationcount=10000 -p threadcount=16 \
  -p fieldcount=10 -p fieldlength=100 \
  -p readallfields=true -p writeallfields=false \
  -p insertorder=hashed -p keyprefix=user -p zeropadding=1 -p insertstart=0 \
  -p requestdistribution=uniform \
  -p readproportion=0.95 -p updateproportion=0.05 \
  -p scanproportion=0 -p insertproportion=0 -p readmodifywriteproportion=0
```

Relaxed suffix empty on both products, GoMap command_wal_relaxed. Optional second explicitly labeled request/profile comparison: MongoDB suffix `&journal=true`, GoMap suffix empty under command_wal_durable. This is **not newly qualified durable-B**: no current Mac public crash controls/sentinel/source-route applicability packet has been executed. If a common j-absent load is selected, retain its different profile work and concern separately. `final_2026-10-30.md:73-112` explicitly warns that common requests do not imply common durability work. Old Linux durable-B stays historical and separate. Do not pool classes or compare to old host185 numbers as a causal performance change.

## Portable matrix invocation

Prerequisites: native Mac Go1.26.10/toolchain and CGO dependencies as required by the unchanged producer (`-tags libsqlite3` selected by coordinator), Bash, Docker CLI/working daemon, native arm64 MongoDB8.2.7 image pinned to its actual resolved image identity, loopback free ports, fresh task-owned writable directories. Docker Desktop runs MongoDB in a Linux VM; GoMap/client run on host macOS. Record that asymmetric boundary, Docker resource limits, image architecture/buildInfo/version and disk paths. Cached Mongo7 is not the declared8baseline.

```sh
OUT_DIR="$FRESH_SHAPE_OUT" MONGO_IMAGE="$PINNED_NATIVE_IMAGE" \
  scripts/mongo_gateway_fast_client_matrix.sh

OUT_DIR="$FRESH_SWEEP_OUT" MONGO_IMAGE="$PINNED_NATIVE_IMAGE" \
  DOCS_LIST=100000 INDEXES_LIST="0 1 2" BATCH_SIZE=1000 \
  INSERT_PRODUCERS=16 PREBUILD_DOCUMENTS=true RANGE_INDEX=true \
  TREEDB_PROFILE=command_wal_relaxed TREEDB_DOCUMENT_FORMATS=bson \
  TREEDB_CLIENT_MODES=driver-command-raw MONGO_CLIENT_MODES=driver-command-raw \
  TREEDB_MAINTENANCE=checkpoint TREEDB_READ_STATE=settled \
  READS=100000 RANGE_READS=10000 UPDATES=10000 DELETES=0 \
  CONCURRENT_READ_KINDS=id,email,range CONCURRENT_READER_SWEEP="1 16 32" \
  CONCURRENT_READS=10000 CONCURRENT_WRITER_SWEEP="1 16 32" \
  CONCURRENT_WRITES=10000 TIMEOUT=30m \
  scripts/mongo_gateway_compare.sh
```

Second command is a fully declared local full sweep, not proof of every June option. `command_wal_relaxed` defaults final maintenance to checkpoint in parser; full maintenance is refused for command-WAL (`main.go:940-944`). Checkpoint physical bytes differ from old compaction boundaries and must be named. The wrapper rebuilds only before timed loops (`compare.sh:1016-1017`), serializes cells (`:1053-1133`), and owns fresh Docker data/ports (`:603-630`). No timed work may overlap tool builds, other benchmark collection, Docker image pulls or artifact transfers. Active user apps stay running; disclose their noise and do not claim quiet-host isolation.

## Material validity gaps and cheapest retained validation

1. `mongo_gateway_bench/main.go:528-532` discards deferred original Close return. Maintenance=none and checkpoint both retain this gap (`:6351-6395`); only full offline maintenance checks Close (`:6442-6446`) and it is unavailable for these command-WAL rows. Successful exit does not prove original Close success. Do not claim otherwise; a later gateway checked Close cannot reconstruct the discarded return.
2. `main.go:4470-4497` command and raw-command insert only inspect RunCommand.Err; they do not explicitly validate n/writeErrors/writeConcernError. `:7333-7339` counts intended batch length after nil error. There is no complete post-load document census in this benchmark. Raw-operation errors and exact counts therefore need independent untimed evidence, not a nominal operation-total assertion.
3. Wrapper force-removes Docker and suppresses cleanup errors (`compare.sh:415-421,633-647`), and does not run same-dir reopen itself. Independently inspect owned containers absent and retain removal/error results; do not label wrapper cleanup graceful shutdown or checked Mongo server Close.
4. Cheapest focused addition is a **validation-only** public Mongo driver helper in the local evidence packet, frozen and independently reviewed before timed work. Enumerate every document with checked cursor/Disconnect; reject missing/duplicate/extra IDs; verify BSON types and expected generator fields; retain canonical full-state digest/count; verify declared indexes and representative indexed email/city/age queries. Expected fields come from `main.go:6961-7098` and account for selected update/delete phases. Count alone is insufficient. Reopen retained TreeDB dirs with standalone gateway on the same profile/format, public-enumerate and validate; do not invoke mongo_gateway_bench for reopen because its open path resets explicit dirs (`:1265-1266`). Mongo Docker persisted dirs can likewise reopen in a task-owned container. If no preclose full census exists, label postrun/reopened expected-shape validity, not preclose observed-state preservation.

For YCSB retain checked exit/stdout/stderr/original Close receipt,100000 successful load INSERTs,10000 successful run READ+UPDATEs,zero operation errors,full typed loaded/preclose/reopened key and10x100byte binary field census,matching preclose/reopened canonical state,successful original gateway SIGTERM exit and independently fresh reopen. Preserve every failed attempt under original identity. Do not treat receipt command success as proof of zero operation errors: also inspect emitted operation-error counters.

Freeze runtime/harness blob identities, full clean source heads, actual binary SHA256/buildinfo/toolchain/build flags, validation helper hash, exact commands/env/profiles/concerns, per-arm image/container/config identities and raw receipt destinations. Documentation-only descendants may retain evidence only while those identities remain unchanged. No merge authorization: HALT BEFORE MERGE.

## Reviewed blobs

GoMap HEAD2590d1e9:

```text
966476cc6bbda5c5b7c3240c3639d1fc05a684af TreeDB/mongo_gateway/server.go
57577b6cac528ba7491e0f361d7b52f126352942 cmd/mongo_gateway_bench/main.go
db03bdf0bfee725a0abe75ed4643db3661a98e60 internal/ycsbevidence/process_other.go
fa7abf2b2894c05dba7656a3bdd47c0bfbf71b4f scripts/mongo_gateway_compare.sh
8ba562af0e38c63d0b45b85362f66cf539d63c42 scripts/mongo_gateway_fast_client_matrix.sh
38a9d3b61e0f202cb405a83377f639ffa221cf34 scripts/ycsb_compare_live.py
9e6a894f265aee5880cf1a5a30cf84eef729e0cc scripts/ycsb_compare_mongodb_treedb.sh
10b9e9e5308c19f1a8b3c103c744e46e7ec8faf8 scripts/ycsb_compare_validate.py
ed340d9565a6ef892ca16816d809b44b498bdd2c scripts/ycsb_correctness_fixture.go
fb43fa7b6e3df02772823afc4fb9ade901bc463b scripts/ycsb_mongodb_reference.md
3ef4f53880ae30512462f3c63700ad3b7ed80e34 scripts/ycsb_mongodb_reference_prepare.py
```

go-ycsb HEAD3c814849:

```text
3e4e0e02bc08f9561a346b99b407590075a5b34b cmd/go-ycsb/client.go
9564ea441aae62ea89f4363b02794c51a8260fbf cmd/go-ycsb/close_receipt.go
917ff71eefc47c170b25137bd20571fad83589ad cmd/go-ycsb/main.go
6e5c74766a64ccf378482f66f2449a7e273ceaaf db/mongodb/db.go
```
