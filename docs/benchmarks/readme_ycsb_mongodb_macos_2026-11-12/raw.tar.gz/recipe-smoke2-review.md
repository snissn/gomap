# Focused smoke-2 recipe review

**ACCEPT for a fresh bounded smoke-2 attempt containing all 17 tiny cases**, conditional on rebuilding the validation helper and freezing its new binary together with these exact recipe sources before launch:

- `run.py` SHA-256 `552345927a26383602e44d4bb8b942b55b7ae65cf5a7fc94aac6d5b242620b42`.
- `census.go` SHA-256 `25e89309c5c9617f191766276457b50b7a6652c3a6d50813ae8358612a80e52c`.

Read-only review only: inspected the recipe diff, prior failed-census output, failure/disposition records, preserved first recipe/freeze, database presence, and product hint-validation implementation. No builds, executable helper tests, smokes, timed runs, GitHub operations, or product edits were performed by this reviewer.

The first smoke's shape-driver failure is correctly classified as a validation-recipe mismatch. Its retained census shows all 1000 expected typed documents, no missing/extra/duplicate IDs, valid declared `_id_`/email/city index metadata, a successful ID query, then an explicit BadValue on the requested email hint. The source `validateCompoundHint` requires a supported compound planner shape; the benchmark's public queries do not supply this hint. The revised helper therefore matches the producer's unhinted public form while retaining complete expected-result membership, typed-document and canonical-digest comparisons. Metadata validation remains independent. This is public query correctness on the declared indexed collection; it is not a physical index-activation proof. The renamed output field accurately reflects that limit.

`--attempt-label` is restricted to lowercase letters/digits/hyphens, fresh output creation refuses existing paths, and DB root naming now includes the output attempt name. This prevents smoke-2 from colliding with smoke-1 evidence or the retained failed database. The `docker rm -f -v` change remains confined to the already identity-checked owned container ID and additionally releases its anonymous volumes; the DB bind mount is separately governed by the owned-root release checks.

The failed attempt and earlier four YCSB smoke outcomes remain retained under `runs/smoke`; the old source/freeze remain under `recipe-history/smoke1`. `smoke1-disposition.json` records zero selected measurements and retains the failed database. This is an explicit recipe revision after a diagnosed setup/validation mismatch, not a silent retry to obtain favorable timings.

No consequential regression found in these changes. Retained collection is still gated on actual successful smoke-2 results for all 17 paths, unchanged frozen source/runtime inputs, and explicit reviewed disposition of any new failure. No performance, durable-equivalence, Linux-attestation, crash/power-loss, or every-write claim is granted by this review.
