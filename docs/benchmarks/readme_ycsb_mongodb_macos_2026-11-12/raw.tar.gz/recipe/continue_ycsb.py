#!/usr/bin/env python3
"""Execute only the five never-started slots after retained Mongo reopen failure.

No retry, source change, timing change, or substitution of a different profile.
Run only after the active shape suite has exited and its services are stopped.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--repo',type=Path,required=True)
    args = parser.parse_args()
    root, repo = args.root.resolve(), args.repo.resolve()
    spec = importlib.util.spec_from_file_location('original_recipe',root/'recipe/run.py')
    original = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original)
    original.ROOT, original.REPO, original.BIN = root, repo, root/'bin'
    original.FREEZE = original.strict_json((root/'freeze.json').read_text())
    original.FREEZE_HASH = digest(root/'freeze.json')
    original.IMAGE = original.FREEZE['mongodb_image_id']
    original.OUT = root/'runs/ycsb'
    original.verify_freeze()
    retained = {str(p.relative_to(root)):digest(p) for p in sorted(original.OUT.glob('*/result.json'))}
    failure = original.OUT/'ycsb-different-durable-requests-p1-mongodb/failure.json'
    original.require(len(retained) == 6 and failure.exists(), 'unexpected prior attempt inventory')
    original.require(all('/ycsb-relaxed-' in p for p in retained), 'unexpected prior valid samples')
    retained[str(failure.relative_to(root))] = digest(failure)
    schedule = [(1,'gomap'),(2,'gomap'),(2,'mongodb'),(3,'mongodb'),(3,'gomap')]
    for repeat,target in schedule:
        name = 'ycsb-different-durable-requests-p'+str(repeat)+'-'+target
        original.require(not (original.OUT/name).exists() and not (root/'db'/('ycsb-'+name)).exists(),
                         'continuation refuses any existing case or DB slot')
    plan = dict(adapter_sha256=digest(Path(__file__)),frozen_manifest_sha256=original.FREEZE_HASH,
                preserved_attempt_hashes=retained, schedule=[dict(repeat=r,target=t) for r,t in schedule],
                scope='only never-started fixed slots; failed p1 Mongo is never retried')
    original.save(root/'continuation-ycsb-plan.json',plan)
    outcomes = []
    for repeat,target in schedule:
        for name,expected in retained.items():
            original.require(digest(root/name) == expected, 'prior attempt changed')
        original.verify_freeze()
        try:
            original.run_case('ycsb','different-durable-requests',target,repeat,100000,10000,
                              ack='different-durable-requests')
            outcomes.append(dict(repeat=repeat,target=target,state='valid'))
        except Exception as error:
            # Original run_case has already persisted failure and attempted
            # every registered cleanup. Do not overlap a surviving service.
            original.require(all(s.get('stopped') is True for s in original.SERVICES),
                             'failed sample left an owned service unconfirmed absent; halt')
            outcomes.append(dict(repeat=repeat,target=target,state='invalid',error=repr(error)))
            print('INVALID fixed YCSB slot '+str(repeat)+' '+target,flush=True)
    for name,expected in retained.items():
        original.require(digest(root/name) == expected, 'prior attempt changed')
    original.save(root/'continuation-ycsb-result.json',dict(outcomes=outcomes,no_retries=True))


if __name__ == '__main__':
    main()
