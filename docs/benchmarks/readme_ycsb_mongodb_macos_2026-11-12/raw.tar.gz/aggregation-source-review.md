# Aggregation source review

Reviewed the local issue #5407 contract, frozen collector/helper source, and bounded examples of archived metadata. No benchmark, build, aggregation, or test was run during the active timed sweep. No new collection or retry is requested.

Initial aggregate.py SHA256 `169a66b6b255626fb8017a46e48ad8825f4cfbb057e0d1eaaedcb381de59d70a`: **REJECT for final report selection**. Consequential source gaps were:

1. Incomplete groups still received median summaries, and the incomplete durable request class still received a two-pair ratio distribution. The attempt ledger called the invalid retained attempt selected.
2. Shape/sweep phases were not checked against exact operation counts or their frozen configuration; across-repetition agreement alone could accept a consistently wrong phase inventory.
3. Glob-only receipt checks allowed a missing original command receipt to disappear. Required lifecycle, loaded/preclose census, deterministic fixture, and checked helper-close evidence were not all revalidated.
4. The imported parser/helper sources were not checked against the final freeze; original YCSB Close identity was only checked against the command's own recorded environment rather than the expected case/build/profile.

These are aggregation acceptance gaps, not a finding that the previously accepted collected samples failed validation.

At the coordinator's request, changed **only recipe/aggregate.py** to address these gaps. Revised SHA256: `fb8e48829ad7f786c3c1cc647a7fdc2a1e7bc8d749b73da15745350976fc4745`.

- Retains the exact 48 slots: 12 YCSB, 18 shape, 18 sweep. Requires case/slot identity, frozen manifest/source identity and exact per-slot counts/mode/indexes/ACK class.
- Summaries exist only for complete three-repetition groups. Incomplete groups are explicit and retain individual valid diagnostics with `summary_eligible=false`; no incomplete-group median is emitted. Paired ratios exist only for all three matched valid pairs; incomplete classes receive `ratio=null` and no two-pair diagnostic ratio.
- Ledger distinguishes `retained_attempt` from `valid_selected`. The original failed Mongo slot remains an excluded invalid attempt with disposition, without selected throughput.
- Pins the retained freeze hash and checks run.py/census.go identities before importing the frozen strict JSON/parser/Close validator. Checks original YCSB Close identities against the frozen client build, case-specific phase ID and expected profile, plus recorded workload properties and request URI ACK parameters.
- Requires suite-specific producer/census/fixture command inventories, normal lifecycle stop receipts, successful public readiness, raw stdout/stderr hashes, successful non-readiness commands, and checked graceful/absent service outcomes. Mongo lifecycle evidence binds the immutable image and container ID. Keeps Mongo benchmark's original discarded deferred Close limitation explicit.
- Rechecks each required full typed census, exact count/namespace/shape/index/query/checked-call inventories, raw/result census equality, and preclose/reopen digest equality. Checks deterministic fixture identities, 64-row reopen equality, 128 acknowledged/readback updates, original fixture Close outcomes and artifact hashes.
- Checks shape/sweep recorded argv and raw configuration, exact phase names/counts (including zero-count shape phases), finite nonnegative metrics, positive nonempty rates and ordered latency tails. YCSB duplicate rows, missing extrema and invalid extrema/tails fail.
- Records the aggregator hash, per-case evidence file hashes, exact 48-slot expectation, explicit incomplete groups and the per-run tail-summary interpretation. Checks attempt/validated/result consistency and stopped physical endpoint sums.

Frozen run.py remains `15349a7db52ef0edafee119ccce3f19366db982780787d7b9a3ccc947fddc5ba`; census.go remains `25e89309c5c9617f191766276457b50b7a6652c3a6d50813ae8358612a80e52c`. Neither was edited.

**Current gate:** source changes complete; execution acceptance remains pending until the coordinator declares timing complete. Then run syntax checking and the real aggregation once, repair only aggregation/schema mismatches against existing raw evidence, and verify 47 valid individual samples plus one invalid retained slot, 15 complete summaries plus one incomplete durable Mongo group, and a durable paired ratio of null. Do not retry measurements.

Use bounded negative controls on temporary copies or direct calls to this aggregator's functions, not a duplicate validation harness: delete a required command receipt; alter an original Close build/phase ID; alter a phase count/config; remove a checked census close/query; alter a raw-output hash; provide a nonfinite or unordered tail; verify incomplete-group/ratio suppression and invalid ledger selection. Controls must reject each corruption without modifying retained evidence. Re-run the same aggregator after controls only if its source changes.

## Relocation source correction

The coordinator identified that the first revision compared original absolute command/DB paths against the current extracted `--root`. Corrected this before execution: the original campaign root is derived from the frozen YCSB source location, and a deterministic lexical normalizer maps only the Mac `/tmp` alias to `/private/tmp`. Executable paths, command source cwd, gateway DB paths, Docker bind mounts, benchmark DB paths, DB-release paths, fixture paths and original YCSB Close receipt paths bind to that original identity. No existence, symlink resolution, binary read, source-directory read or original-host dependency is used for these recorded path checks. The current extraction root is used only to read retained evidence and produce relative case names.

Also reviewed `census.go:390-402`: the frozen helper permits listIndexes command-not-found code59 and explicitly records `unavailable_command_not_found: ...`, without a list-index cursor-close call. The aggregator now preserves that exact outcome rather than claiming metadata validation; all other census/query/checked-close checks remain required. Supported metadata still requires the exact declared index set. Index metadata status is retained per sample and complete group. The two small actual YCSB reopen examples inspected both report supported validated metadata; no full retained scan was performed during timing.

Latest aggregate.py SHA256: `7cf7ad2f4221a820c33ddb128eea128cd84c5e4cfe0e7b8d479e2c7a67b99ae2`. Frozen collector/helper hashes remain unchanged. Add one post-timing control: reaggregate an evidence-only copy from an unrelated extraction path and require byte-identical summary output, without original binaries or source directories. Syntax checks, execution, controls and operational acceptance remain pending the coordinator's timing-complete message.

## Post-timing validation and verdict

**ACCEPT for aggregation/report selection from this fixed retained campaign.** Validation ran only after the coordinator declared the sweep exited0 and all timed collection complete. No measurement was retried and no product, timed producer, frozen collector or census helper source changed.

Final aggregate.py SHA256: `507a0bc18127b083fd3fee8a85760e0bae4901a90110a79fc2b28133c674168e`.

Actual summary.json SHA256: `f248c85624af45745d3f17e40299f6e3eedc853377e434bf5a8ac5d2fcde06b9`.

`python3 -m py_compile recipe/aggregate.py` passed. Actual `python3 recipe/aggregate.py --root /tmp/gomap-readme-benchmarks-20261112` passed with all **48 retained slots accounted: 47 valid individual samples, one excluded invalid Mongo durable reopen attempt, 15 complete summaries and one explicit incomplete Mongo durable group**. There is no incomplete Mongo durable median, no two-pair diagnostic ratio, and the durable paired ratio is null. The valid three-repetition GoMap durable group remains available as a standalone group. The invalid retained attempt has `valid_selected=false`. There are79 total attempt ledger entries including historical smoke attempts.

The first actual execution caught one interpretation defect in the added unique-row check: go-ycsb emits periodic ten-second progress rows before the single final `Run finished, takes ...` summary. Aggregation now requires exactly one final marker, selects that final block, and requires unique complete rows within it. This preserves the frozen producer's original final TOTAL rates/timing and avoids treating progress rows as final results. The final source passed syntax and actual aggregation after this correction.

Fourteen bounded controls/assertions passed using the actual aggregator/frozen validator functions, existing raw evidence, and one temporary symlink copy of a selected case. Negative controls rejected a missing required command receipt; wrong original Close phase/build IDs; wrong phase operation count; wrong raw client configuration; nonfinite and unordered latency tails; a missing checked census client Close; a missing census query; a raw stdout hash mismatch; and a foreign original absolute path. Positive controls preserved the frozen code59 unavailable-metadata semantics and accepted the same selected-case evidence from an unrelated temporary location. Fixed inventory, incomplete-summary/ratio suppression, invalid-ledger exclusion and standalone GoMap durable selection were asserted from the actual summary.

Commands, outcomes, hashes and individual control results are retained in `derived/aggregation-validation.json`. Full archive extraction and byte-identical replay remain the coordinator's separate check; the bounded relocation control and source review did not depend on original binary/source directory existence.
