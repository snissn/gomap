# Independent revised-recipe recheck

Read-only review; no builds, smokes, timed runs, GitHub operations, or product edits.

Reviewed `run.py` SHA-256 `bde99e11d32dbc2c33b1117f299f722438c97ad25f3583cf71a25ec5c43ca0e1` and unchanged `census.go` SHA-256 `baed4796f0f20f5d5afd63db05062f80286bdbaa3994e4048ca214145a02dfe8`.

The earlier five findings are substantially addressed: command finalization handles interruption/spawn errors, owned services register before fallible setup, lifecycle attempts have unique receipts and best-effort cleanup, each case enforces recipe/helper/binary/manifest/source identity, all 17 selected small smoke paths are enumerated, and release no longer writes a valid result before deletion completes. Strict JSON and schema/identity/original-outcome receipt checks improve malformed-evidence rejection.

**Decision: REJECT this exact revision pending one consequential lifecycle fix.** At `run.py:258-268`, a Mongo service whose container has disappeared returns successful `stop()` with `not_present=true`, `absent=true`, and `graceful=false`. If this happens at the normal post-census lifecycle boundary, `run_case()` can continue to a valid result without the required observed graceful Mongo stop. Absence is sufficient for failure cleanup, but is not graceful lifecycle evidence. Distinguish normal lifecycle stop from abort cleanup, or require a normal stop to produce `graceful=true` as well as `absent=true`; retain failure accounting and owned cleanup even when that requirement fails. A previously observed successful stop may be reused only with its existing successful receipt.

After that fix is source-reviewed and bound to its final hash, the recipe can be accepted **for bounded smokes**, conditional on creation/inspection of the actual complete freeze manifest. Retained collection remains gated on actual successful smoke evidence for all 17 selected paths, source-bound final freeze, and explicit reassessment of any failed smoke; no smoke success is claimed here.

The accepted scope and limitations in `recipe-prereview.md` still apply, including unchanged producer timing, different durable requests, original Mongo benchmark cleanup return unobserved, census rather than every-write proof, and no Linux/crash/power-loss/COW qualification.

## Final scoped smoke acceptance

**ACCEPT for the 17 bounded tiny smoke cases**, on final `run.py` SHA-256 `10cf8796779425ba5579a6a754b25960d7fa82a33529c2956aa41d33b3d75ca4`, unchanged `census.go` SHA-256 `baed4796f0f20f5d5afd63db05062f80286bdbaa3994e4048ca214145a02dfe8`, and the actual reviewed `freeze.json` SHA-256 `3f0707a36a7bcf40b027898889c3ff495f5c40c620d90b2510bda0d67492d15e`, created `2026-11-12T21:05:48.521737+00:00`.

The final change makes normal `stop()` require `graceful=true` after cleanup; only failure cleanup passes `abort=True`. An absent Mongo container therefore invalidates a normal lifecycle boundary while still permitting abort cleanup. The freeze now binds both intended source commits/trees, the complete six-tool set, recipe/helper hashes, Mac build information, immutable Mongo image/platform, host context and Docker VM resources. The retained `lifecycle-self-test.json` reports successful failed-spawn, timeout, interruption-child-reaping and strict-nonfinite/duplicate-JSON controls; this reviewer inspected that report and did not execute the controls.

No remaining consequential source-review blocker was found for the bounded smoke stage. **This is not acceptance of retained benchmark evidence:** retained collection still requires actual successful results for all selected smoke paths under this unchanged freeze, or explicit review/disposition of failures before a revised candidate is frozen. All benchmark/runtime product sources remain outside the proposed change scope.
