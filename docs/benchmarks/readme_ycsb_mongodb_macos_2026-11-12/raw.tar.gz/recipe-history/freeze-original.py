#!/usr/bin/env python3
"""Capture immutable inputs before the local benchmark campaign."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/tmp/gomap-readme-benchmarks-20261112')
REPO = Path('/Users/michaelseiler/dev/snissn/gomap-readme-benchmarks-20261112')
GO = '/Users/michaelseiler/.gvm/gos/go1.25.5/bin/go'
ENV = os.environ.copy()
ENV.pop('GOROOT', None)
ENV.update(GOTOOLCHAIN='go1.26.10', GOWORK='off')

def run(argv):
    return subprocess.check_output([str(a) for a in argv], cwd=REPO, env=ENV, text=True).strip()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

sources = []
for path, names in ((REPO, ('TreeDB','internal','cmd','scripts','third_party','go.mod','go.sum')),
                    (ROOT/'go-ycsb-source', ('cmd','db','pkg','go.mod','go.sum'))):
    assert not run(['git','-C',path,'status','--porcelain'])
    existing = run(['git','-C',path,'ls-tree','--name-only','HEAD']).splitlines()
    sources.append(dict(path=str(path), commit=run(['git','-C',path,'rev-parse','HEAD']),
                        root_tree=run(['git','-C',path,'rev-parse','HEAD^{tree}']),
                        blobs={n:run(['git','-C',path,'rev-parse','HEAD:'+n]) for n in names if n in existing}))
image = json.loads(run(['docker','image','inspect','sha256:b8b32a56a1ddc4c278d68124a8f0203663018f62828cadaa995a6cd595f6c9a0']))[0]
info = json.loads(run(['docker','info','--format','{{json .}}']))
value = dict(schema_version=1, created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             stage='pre-smoke frozen inputs; unchanged identities required for retained collection',
             product_commit=sources[0]['commit'], ycsb_commit=sources[1]['commit'], sources=sources,
             binaries={p.name:digest(p) for p in sorted((ROOT/'bin').iterdir()) if p.is_file()},
             recipe_sources={n:digest(ROOT/'recipe'/n) for n in ('run.py','census.go')},
             mongodb_image_id=image['Id'], mongodb_repo_digests=image['RepoDigests'],
             mongodb_image_platform=dict(os=image['Os'], architecture=image['Architecture']),
             build_environment=dict(go_version=run([GO,'version']), go_env=json.loads(run([GO,'env','-json',
                                    'GOVERSION','GOROOT','GOTOOLDIR','GOOS','GOARCH','GOCACHE','GOMODCACHE','CGO_ENABLED'])),
                                    ycsb_tags='libsqlite3,sqlite_omit_load_extension',
                                    binaries_build_info={p.name:run([GO,'version','-m',p]) for p in sorted((ROOT/'bin').iterdir()) if p.is_file()}),
             host=dict(os=run(['sw_vers']), kernel=run(['uname','-a']),
                       model=run(['sysctl','-n','hw.model']), physical_cpus=int(run(['sysctl','-n','hw.physicalcpu'])),
                       logical_cpus=int(run(['sysctl','-n','hw.logicalcpu'])), memory_bytes=int(run(['sysctl','-n','hw.memsize'])),
                       disk=run(['df','-k',ROOT]), power=run(['pmset','-g','batt']),
                       background_processes=run(['ps','-axo','pid,comm,%cpu,%mem']),
                       gomaxprocs='unset for all benchmark processes; runtime value not independently observed'),
             docker={k:info[k] for k in ('ServerVersion','OperatingSystem','KernelVersion','Architecture','NCPU','MemTotal','ContainersRunning')})
with (ROOT/'freeze.json').open('x') as f:
    json.dump(value,f,indent=2,allow_nan=False)
    f.write('\n')
print(json.dumps({k:value[k] for k in ('product_commit','ycsb_commit','mongodb_image_id','binaries','recipe_sources')},indent=2))
