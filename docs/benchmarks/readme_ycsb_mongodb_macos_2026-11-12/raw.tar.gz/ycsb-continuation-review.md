# YCSB failed-cell disposition and continuation review

The six retained relaxed results can remain selected without rerunning them. All six result.json files currently report valid and bind the accepted original freeze/recipe. Their SHA-256 identities are:

| Case | result.json SHA-256 |
| --- | --- |
| relaxed p1 GoMap | `a3ae4222ea3b6f60226a49a9555386a2dce5f631b0a91ab8c5c1dd400666ab18` |
| relaxed p1 Mongo | `200d8bd42cf7feaf20fee300b86b0cb271f6572f446efd4c152b4488da76e782` |
| relaxed p2 GoMap | `be0077993a819099966ecb94c7114e02eeb272d6e3c594562cfb9f47edf21427` |
| relaxed p2 Mongo | `2a47b5939ca137a4cd63acaeb622f275fae5c0ebb2ad68597464cd66e33c429e` |
| relaxed p3 GoMap | `0e3cd83d9238c59251adc7ce2e10e12da007a05ffe1c63959fb547a1f2f0123c` |
| relaxed p3 Mongo | `fd44e973b00b4491d1ef3d7cc64f6dff5ecd7398dd212f58da2701070c249480` |

The first different-durable-requests Mongo cell remains invalid as a whole. Its retained original load/run commands exited zero and original command/DB/workload Close receipts succeeded. Its initial server stop reports graceful success and final absence. The reopened Mongo inspect records exit 133 and OOMKilled=false; retained diagnostic logs report ENOENT during directory sync of `/data/db/_tmp/spilldb` and WT_PANIC. Failure cleanup reports graceful=false and absent=true, and the failed DB remains present. No rate from this invalid cell may enter a selected median or ratio. This establishes an observed graceful-reopen failure in the selected local Mongo/Docker topology; it does not establish that j:true caused the failure or independently identify a root cause.

The coordinator reports sending SIGINT to the owned runner after observing the dead reopened server, stopping readiness retries. failure.json is invalid but has an empty error string because KeyboardInterrupt stringification is empty. A disposition should explicitly retain this interruption and the separately observed server failure rather than suggest the timed command itself failed.

Completing only the five never-started durable slots is a valid fixed-schedule continuation, in original order: p1 GoMap, p2 GoMap, p2 Mongo, p3 Mongo, p3 GoMap. Preserve all earlier artifacts and the failed p1 Mongo cell; do not retry that cell. The continuation must use the unchanged frozen run_case implementation, record its own source hash and fixed schedule against the original freeze, refuse occupied result/attempt/DB slots, and bind/check the six existing result hashes above. Execute sequentially after the current timed suite ends.

The adapter must propagate KeyboardInterrupt/SystemExit and halt if owned-service absence is not established. Catching ordinary failed samples may continue the fixed remaining schedule only after all registered owned services are confirmed absent; a graceful failure remains an invalid sample even when abort cleanup succeeds. Do not silently modify the timing, request/profile parameters, helper, producer, or original freeze.

Reporting the three-pair durable comparison as unavailable when any cell is invalid is appropriate. A separately labeled GoMap durable-profile standalone median is valid only if all its three original slots complete full acceptance; the report must preserve the differing-request context and all failed-attempt accounting. The three relaxed pairs retain their own scope. No crash/power-loss/durable-equivalence claim follows.

This review has inspected retained failure/result/cleanup records and diagnostic logs without running any benchmark/build/product command. Adapter source has not yet been supplied, so concrete continuation-source acceptance is pending that final read/hash review.

## Concrete continuation acceptance

**ACCEPT the five-slot continuation adapter** `recipe/continue_ycsb.py` SHA-256 `ca43f2908b4334ea5b882ead72044daaac7a53ee0d4a94990ece6ad8f457404e`, with unchanged `run.py` SHA-256 `15349a7db52ef0edafee119ccce3f19366db982780787d7b9a3ccc947fddc5ba` and original `freeze.json` SHA-256 `7c5900724fced59909a9f8a696307010f4d848d55308154c75ecd105d3c0ab74`.

The actual source imports the unchanged implementation, initializes the existing frozen globals/output root, verifies the freeze, requires the six existing relaxed results plus failed p1 Mongo cell, refuses every preexisting case/DB slot in the five-slot schedule, and records a separate source-hashed plan. It rechecks preserved hashes before each slot and after completion. It catches ordinary Exception only, requires all registered owned services stopped before continuing after a failure, and never retries a slot. The schedule exactly preserves the original order of the five remaining cells. Existing exclusive file creation prevents clobbering prior attempts or accidentally relaunching this adapter's plan.

The added original-cell `failure-disposition.json` correctly records the interruption, observed server exit/panic, failed-cell exclusion, no-retry policy, and limited causal claim. No consequential source-review blocker remains. Launch only after the active shape suite and its owned services finish; retain adapter stdout/stderr/exit and plan/outcomes alongside original attempts. This acceptance preserves the existing six valid samples; it does not pre-accept any future continued sample or authorize a complete durable paired median from an incomplete class.
