# Supported-path retained-collection gate

**ACCEPT to begin the fixed retained collection for the 16 supported workload paths, under the unchanged frozen recipe/runtime inputs below.** No performance threshold is imposed. This accepts collection readiness, not the validity of as-yet-uncollected results or any subsequent README numeric claim.

- `run.py` SHA-256 `15349a7db52ef0edafee119ccce3f19366db982780787d7b9a3ccc947fddc5ba`.
- `census.go` SHA-256 `25e89309c5c9617f191766276457b50b7a6652c3a6d50813ae8358612a80e52c`.
- `freeze.json` SHA-256 `7c5900724fced59909a9f8a696307010f4d848d55308154c75ecd105d3c0ab74`, created `2026-11-12T21:09:03.934154+00:00`.
- Product `2590d1e9e443c3f968303ce91b3c82933a714f12`; YCSB producer `3c8148495b8d4490cf0ec30e9eb92d14a7a71bac`; immutable Mongo image unchanged.

Read-only independent review: source diff and disposition inspection; retained JSON/raw-output inspection and hashing; no new product/benchmark/helper execution, builds, source edits, GitHub operations, or child agents.

## Direct-mode disposition

The `runs/smoke-unhinted/shape-direct-p1-gomap` attempt exited 1 with empty benchmark stdout. Its stderr explicitly rejects collection catalog index mutation under command_wal_v2; the error matches `TreeDB/collections/api.go:4509`. It produced no valid load/read throughput. `smoke2-disposition.json` correctly classifies this as an unsupported selected product path and selects zero measurements. The revised recipe removes only direct mode from selected smoke/shape loops, while preserving that failure and the original source/freeze under `recipe-history/smoke2`.

Publishing direct mode as N/A with this profile-specific reason is appropriate. Do not replace it with an older result or a different-storage-profile number. The earlier hint-validator failure remains a separately diagnosed validation mismatch. No product or timed producer repair was made.

## Actual final smoke evidence

Independently read all expected `runs/smoke-supported` outcomes: exact set of 16 results (four YCSB ACK/target combinations, five TreeDB client shapes, one Mongo shape, six sweep index/target combinations), no extra result and no failure.json. Every result is valid and binds the final manifest/recipe hashes. Every sample's data-release receipt reports DB removal, and each corresponding owned DB path is absent.

All retained public censuses report exactly 1000 documents with zero missing/extra/duplicate IDs and successful expected-result queries. Each applicable preclose/reopen typed-state hash comparison passed. Original YCSB load/run command/DB/workload Close receipts report attempted successful calls with empty errors. Timed smoke producer commands exited zero. The expected 24 external-service stop receipts report checked graceful success, final absence and no cleanup errors. TreeDB shape/sweep have one verification-gateway stop each; this does not observe the benchmark's discarded original deferred cleanup return.

Recomputed all six frozen executable hashes and all 188 retained subprocess stdout/stderr hash pairs in this final smoke attempt: all agree with the manifest/command records. Recipe and helper source hashes agree with the final freeze. These checks inspect bounded smoke evidence only and establish no large-scale performance result.

## Retained collection constraints

Use the fixed three repetitions and preserved request/profile/count/order contracts. Do not overlap task builds/tests or silently retry invalid samples. Retain each failure and explicitly reassess before any replacement or recipe revision. Every final numeric cell still requires actual retained raw output, exact counts, required census/lifecycle checks and deterministic aggregation. Carry through the original Mongo benchmark Close-return limitation, native-Mac versus Docker-VM boundary, different durable requests, and no Linux/crash/power-loss/COW/physical-index-activation qualification. Keep the eventual PR open and unmerged as instructed.
