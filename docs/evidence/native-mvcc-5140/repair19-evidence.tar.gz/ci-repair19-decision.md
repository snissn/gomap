# P1 CI repair19 decision

Original PR head bdd08a129ee202c582aaf4b37356b0cba9f14f5a, exact tree bed3920afec44abf68dfb5736a846255c2e04f27. All 50 checks finished: 41 success, 8 failed member jobs and failed aggregate. Exact check snapshot retained in ci-run1/checks.json; no merge readiness.

Hosted raw gate passes. PRIMARY gate fails (+5.3673846% median paired time, 391 to392 allocations, 228248 to228272 bytes; no DATA generation advance; quiet host). Verified artifact12095603288 SHA256461ed1ec58fcbfb919fed7b6b6a7190309131c876751c371ebbb55578a415fe6. Original baseline/candidate binaries reused for one128x memprofilerate1 diagnostic each; profiles identify137 extra History.Prepare arena allocations across fixture/calibration/work. Profiled timings are not acceptance evidence.

A bounded read-only gpt-6.1-sol/high adviser reviewed the actual path and recommended generic short-singleton custody in the original FIFO slot, retaining continuous logical MVCC recording, fixed custody and existing long/bulk/range ownership. Coordinator accepted; no key-namespace special case, active-transaction skip or threshold waiver. New fixed array size is budget charged and slot sizing adjusted. Recheck unchanged PRIMARY guard after source freeze.

NoWAL conditional_sync failed on Ubuntu/macOS/Windows and race4: existing pending collection work drains during transaction commit and creates a conservative later root barrier. Drain prior registered producers before opening backend snapshot, using original NoWAL drain or WAL barrier with immediate unlock before snapshot capture. Preserve commit-time drain, actual sync, later genuine conflict, failure precedence and no sequence rebasing. Sol adviser agreed; no test retry to hide conflict.

Test-only fixes: close newly enabled reverse iterator in old close-race fixture; permit platform unsupported vacuum while retaining logical-view assertions; explicitly WaitThrough after hard admission before model asserts durable state (admission only bounds pending debt). Initial focused normal/race checks for these3 pass. Full frozen repair evidence pending.

Adviser performed no edits/builds/tests. Coordinator sole P1 writer; P2/P3 receive coherent patch only after relevant verification. No hosted review requested.

Initial runtime repair diagnostic: normal focused history/backend/cache/collections/public suites PASS; no-WAL acknowledged-buffer conditional_sync now passes. Added inline wrap/cancel/input-reuse and backend opening-error/capture controls also PASS. Full frozen source evidence is next.
