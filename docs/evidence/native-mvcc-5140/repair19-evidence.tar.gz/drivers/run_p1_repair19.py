"""Run frozen repair19 gates sequentially; keep every command receipt."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'p1-gate19'
EVIDENCE = ROOT / 'evidence/p1'
BASE = '0149d78dba2574b09d7119d2631ec78a144e088d'
HEAD = '1fedf4de8f2b8945089dfc814242ca4cd28696f0'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['performance', 'correctness'])
    args = parser.parse_args()
    receipt_path = EVIDENCE / f'repair19-{args.mode}-receipts.json'
    if receipt_path.exists():
        raise SystemExit('refusing to overwrite retained run')
    if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() != HEAD:
        raise SystemExit('source identity mismatch')
    if subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True):
        raise SystemExit('source dirty')
    env = dict(os.environ)
    if args.mode == 'performance':
        raw_env = dict(env, BASELINE_HASH=BASE, CANDIDATE_HASH=HEAD,
                       OUT_DIR=str(EVIDENCE / 'raw-gate-19'), CPUSET='0', RUNS='8',
                       BENCHTIME='2s', BATCH_WRITE_BENCHTIME='1000x')
        jobs = [
            ('raw', ['bash', 'scripts/mvcc_raw_path_gate.sh'], raw_env),
            ('primary', ['python3', 'scripts/mvcc_primary_cost_gate.py', '--root', str(SOURCE),
                         '--output', str(EVIDENCE / 'primary-gate-19'), '--baseline', BASE, '--candidate', HEAD], env),
            ('cow-write', ['python3', str(ROOT / 'compare_p1.py'), '--before', str(ROOT / 'evidence/baseline/treedb.test'),
                           '--after', str(EVIDENCE / 'candidate19-public.test'), '--candidate-manifest', str(EVIDENCE / 'comparison-19-manifest.json'),
                           '--baseline-manifest', str(ROOT / 'evidence/baseline/manifest.json'), '--shape', 'cow-write',
                           '--out', str(EVIDENCE / 'comparison-19-cow-write')], env),
            ('enabled', ['python3', 'scripts/raw_cow_txn_capture.py', '--out', str(EVIDENCE / 'enabled-19'),
                         '--binary', str(EVIDENCE / 'candidate19-public.test'), '--binary-manifest', str(EVIDENCE / 'enabled19-binary-manifest.json')], env),
        ]
    else:
        packages = ['./TreeDB/internal/txnhistory', './TreeDB/internal/rootpublication',
                    './TreeDB/internal/commandwalapply', './TreeDB/internal/memtable', './TreeDB/internal/merging',
                    './TreeDB/tree', './TreeDB/db', './TreeDB/caching', './TreeDB/collections', './TreeDB', './TreeDB/docs']
        pattern = 'Test(History|RandomizedCoordinatorModel|TxnJournal|InheritedStaging|Owned|Reverse|ConditionalTxn|NoWALSyncBarrier|NoWALReadOnlyConditional|NoWALFastBoundaryDrainsAcknowledgedCollectionBuffers|Public(COWTxn|TxnNoOvertake|ConditionalTxn|CommandWALGroupCommit)|COW|.*VacuumDrainsPendingCollectionRoots|CommandWALStaging|.*Borrow.*Guard|ConditionalKVContract|VectorPrepareActualAppendCaptureBorrowCloseV1|StableResourceCaptureLeaseRetainSerializesWithRelease|CommandWALRawBarrierDrainReleasesLeasesForQueuedClose)'
        jobs = [(name, ['go', 'test', *flags, *packages, '-run', pattern, '-count=1', '-timeout=8m'], env)
                for name, flags in [('normal', []), ('race', ['-race']), ('safe', ['-tags=safe'])]]
        jobs.append(('recovery', ['go', 'test', './TreeDB/db', './TreeDB/internal/commandwalapply', './TreeDB',
                                  '-run', 'Test(CommandWAL|InheritedStaging|PublicCommandWAL|PublicCOWTxn(SyncReopen|AcceptedError|RegistrationFailure)|COWPublicEncodedMVCC)',
                                  '-count=1', '-timeout=8m'], env))
    receipts = []
    failed = False
    for name, argv, runenv in jobs:
        path = EVIDENCE / f'repair19-{args.mode}-{name}.txt'
        started = time.monotonic()
        print(f'START {name}', flush=True)
        with path.open('xb') as output:
            result = subprocess.run(argv, cwd=SOURCE, env=runenv, stdout=output, stderr=subprocess.STDOUT)
        receipt = {'name': name, 'argv': argv, 'cwd': str(SOURCE), 'candidate': HEAD,
                   'exit': result.returncode, 'elapsed_s': time.monotonic() - started,
                   'output': str(path), 'output_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        receipts.append(receipt)
        receipt_path.write_text(json.dumps(receipts, indent=2) + '\n')
        print(json.dumps(receipt), flush=True)
        failed |= result.returncode != 0
        if args.mode == 'correctness' and result.returncode:
            break
    raise SystemExit(1 if failed else 0)

if __name__ == '__main__':
    main()
