export PATH=/workspace/scratch/89fd9f1d8fd0/execution/toolchain/go/bin:$PATH
export GOTOOLCHAIN=local
export GOMAXPROCS=2
export GOFLAGS=-p=1
export CGO_ENABLED=1
export GOPATH=/workspace/scratch/89fd9f1d8fd0/execution/cache/go
export GOCACHE=/workspace/scratch/89fd9f1d8fd0/execution/cache/build
