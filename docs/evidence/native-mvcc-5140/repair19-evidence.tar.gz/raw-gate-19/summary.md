## TreeDB MVCC raw-path gate

- verdict: **PASS**
- measured threshold observation: **PASS**
- baseline: `0149d78dba2574b09d7119d2631ec78a144e088d`
- candidate: `1fedf4de8f2b8945089dfc814242ca4cd28696f0`
- samples: 8 per revision, benchmark-group-paired alternating AB/BA order
- timing acceptance: median paired candidate/base relative delta <= 5% (base/head medians remain reported for context)
- allocs/op threshold: candidate median must not increase
- B/op jitter threshold: candidate median may increase by at most the smaller of 1% or 64 B; zero-B baselines remain strict

| Package | Baseline SHA-256 | Candidate SHA-256 | Relation |
| --- | --- | --- | --- |
| db | `18874a95d351ad03cd1f6c12bd6b26274764bcfe251afd61eec4acb1ad7c4c1a` | `91dabaf1d5617143facf658467343d5a5f51822efb54fa7d5ff2da84c70b4cea` | DIFFERENT |
| caching | `143dfadf92757f448b036eabdd079b82c915cb9f9b11b97dcc050e08de7e55b1` | `36bb675e8c5e978034de44429be3032749f4dfaa56ffa53815bb89cfc207bb67` | DIFFERENT |
| treedb | `af9edeab5881acb744dee0de1e338b4c3918577d9d30f20314881152b39f3367` | `0139ee0edc4c334027333e931a6bd7da7ec39a52d1b76d3a54d6a7204bcdc413` | DIFFERENT |

| Benchmark | Binary | Base ns/op | Head ns/op | Median delta | Paired delta | Base B/op | Head B/op | B tolerance | Base allocs/op | Head allocs/op | Measured | Attribution | Acceptance |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- | --- |
| BenchmarkGetVersioned | db DIFFERENT | 532.500 | 538.850 | +1.19% | -0.78% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkConditionalTxnBaselineBatchWrite | db DIFFERENT | 45023.500 | 47180.000 | +4.79% | +2.15% | 31504.500 | 31501.500 | 64.000 | 104.000 | 103.000 | PASS | CANDIDATE | PASS |
| BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek | treedb DIFFERENT | 346.450 | 346.650 | +0.06% | -1.44% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkRepeatedIterator | caching DIFFERENT | 253.900 | 249.600 | -1.69% | -2.30% | 112.000 | 112.000 | 1.120 | 2.000 | 2.000 | PASS | CANDIDATE | PASS |
| BenchmarkPublicCommandWALDurableTinyBatchWriteSync/placement=inline/shape=dirty_batch/ops=1 | treedb DIFFERENT | 8097.000 | 8542.000 | +5.50% | +4.04% | 4471.500 | 4480.000 | 44.715 | 16.000 | 16.000 | PASS | CANDIDATE | PASS |
