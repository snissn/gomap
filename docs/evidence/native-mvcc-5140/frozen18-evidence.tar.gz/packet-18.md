# P1 #5140 final implementation handoff — frozen18

Implementation ownership is released to the coordinator. No P1 command is active, no further measurement or source repair is planned, and P2 owns the ordinary Go/build/test slot. Coordinator owns PR readiness, current-head CI, mature review, publication, fixes and merges.

## Source identity and ownership

- Worker tree: `/workspace/scratch/89fd9f1d8fd0/execution/p1`, branch `codex/native-mvcc-p1-5140`; HEAD remains baseline `0149d78dba2574b09d7119d2631ec78a144e088d` as requested.
- Exact staged tree: `bed3920afec44abf68dfb5736a846255c2e04f27`;65 owned staged paths, zero tracked unstaged changes. Three unrelated preexisting untracked evidence files remain preserved. `handoff-18.json` records the complete owned path list and final source/evidence hashes.
- Immutable measured local commit: `c23338b31cd1c3af42356d4d68a7a85a22498eb4`, ref `refs/codex/frozen-p1-18`, parent baseline. Worker made no local commit/alignment.
- Coordinator remote implementation: `bdd08a129ee202c582aaf4b37356b0cba9f14f5a`, same exact tree and parent; draft [PR5146](https://github.com/snissn/gomap/pull/5146). Durable earlier checkpoint `4f9d7bfca424df8c6f5c40f8116e4fa9376d3206` has that same tree. Local measured identity is unchanged. Remote state is coordinator-reported; this handoff does not assert merge readiness.
- Root/TreeDB AGENTS and CONTRIBUTING were applied. `policy-18.json` records hashes, re-enumerated files and footprint. No hard review cap. Formal external review requested/completed0/0; owner self-review and causal consultations are not mature hosted review. Coordinator reported current-head CI in flight; final outcomes remain coordinator-owned.

## Completed behavior and successor boundary

P1 implements public-owned raw COW transactions on the existing opening cut: staged reads/writes/deletes and forward/reverse iteration, full R∪W/miss/ABA/range predicates, coalesced dependencies with independently owned original iterator bounds, bounded DeleteRange, named open-iterator mutation errors and child/reused-wrapper invalidation. Ordinary producers and commits share final reserve/evict/validate→canonical append→complete cut/history install under the existing writer lease. Real raw guards are borrowed without drain; grouping registration precedes install and ACK await follows lease release; assigned errors poison before releasing ownership. Capability eligibility is static and fail-closed, including arbitrary NoWAL callback escape and private-backend/higher-level bypasses.

Backend/cache compatibility adapters share one bounded FIFO plus derived point index; active-start/recent/minimum/full-map pruning and owner-skip ID transport are deleted. History advances with ordinary supported producers even with no active transaction. Private public-owned backends suppress an unused duplicate oracle. Sorted newer chunks and ranges avoid old-history scans. Conservative barriers expose accepted-only capacity/replacement reasons and abort totals, separately from TooOld.

Frozen18 allocation/lifetime repair uses fixed private effect staging, by-value nonreused preparation tokens and final-FIFO-slot key custody, retaining one immutable key arena and its actual COW lease per command. Cancellation consumes shared staging before writer release; aliases clear before refund. Child transient leases release on Close; failed initialization and borrowed adapter admission preserve original custody; shared denial carriers remain immutable. All child Close errors aggregate while all owners close once. No pool/new allocator or per-item fsync.

Stable P2 seams are the existing complete cut logical sequence/backend basis and `COWPublicationReceipt` fields AssignedLSN/Assigned/Uncertain, LogicalSeq/LogicalInstalled, WALCompleted/WALStable and SealedLogicalSeq. Empty NoWAL Sync reports successful coverage lower bound, not exact generation/LSN. Physical successors preserve logical sequence; logical replacement barriers/rejections remain. P2 has already integrated boundary18; this worker made no subsequent product changes.

Canonical docs/reproduction: `TreeDB/docs/spec/raw-cow-transactions.md`, COW/conditional/verification contracts, API stability and concurrency/locking/durability/iteration docs; both benchmark READMEs and `scripts/raw_cow_txn_capture.py`. Transaction Snapshot callback/HasPrefixes convenience methods remain explicitly unsupported by adopted scope; native iterator prefix/reverse semantics are complete.

## Exact evidence and reproduction

All paths below are relative to `execution/evidence/p1` unless specified. Manifests retain exact commands, source/build/runtime binding and raw hashes; reproduce from those commands, not from prose approximations.

| Evidence | Final result |
|---|---|
| `red/public-red.log` | Original pristine base rejects all4 frozen new public tests as unsupported; no baseline speedup claim |
| `qualification-18.json`, `normal-18.txt` | Normal vet,9 affected packages PASS |
| `qualification-18.json`, `race-18.txt` | Same9 PASS; public109.049s, including concurrent denial/cancel and capacity ownership |
| `qualification-18.json`, `safe-18.txt` | Same9 PASS; public11.919s |
| `qualification-18.json`, `recovery-18.txt` | Affected WAL/guard/accepted-error/reopen gates PASS, db/apply/public |
| `ci-exits-18.json` | Inventory refresh/check and4 contract scripts PASS; only inventory footprint refreshed |
| `enabled-18/{manifest,summary}.json` |30 exact shapes×128x×3 fresh processes PASS; source/raw/binary/hash verified next call |
| `raw-gate-18/{summary.json,summary.md}` | Unchanged hard gate PASS all5;40rows+40PASS each side,8samples/shape |
| `comparison-18-cow-write/{manifest,summary}.json` | Original ordinary-write controls, all6processes/36rows verified; feature tradeoff below |
| `history-ablation-18/{build-manifest,capture-manifest,summary}.json` | Approved test-only causal ablation,6 balanced pairs/12processes/24rows; activation/drain verified; invalid transaction history diagnostic only |
| `relaxed-pointer-trace-18/{build-manifest,capture-manifest,summary}.json`, `report.md` | One marked trace pair; exact512 operation spans/samples each, calibration excluded, no retry |
| `self-review-18.md`, `policy-18.json` | Owner review/policy; all subsequent final normal/race/safe/recovery gates above now complete |

`comparison-18-manifest.json` SHA256 `7a8eae4d5dce125f1781d2686ea7f62dcc1762e725e39972952d2e146fb2ee73` binds2446 source/harness inputs and acceptance binaries. Public `bee18ec1ef9e513d1189138131f9d920a1fbb6aad8697d4d2b1d604dfe2891d0`; db `9df03d39d53395500768c8bd080127792ae0e0031c2b052da3ee58284fdfd13b`; caching `e20ae8130569791f4fac80e2f618119f761dda740674bf9c6b49ab2c51da0b3f`. Go1.26.0, GOMAXPROCS2, GOFLAGS=-p=1, CGO1, normalGC unless diagnostic manifest explicitly differs; source `execution/env.sh`.

## Performance disposition and remaining risks

Hard raw-gate18 passes unchanged thresholds: backend paired+3.0449%,104→104alloc,+29.5B; durable tiny−0.960%,16→16alloc,+2.5B;3read guards pass. Failed15 and17 remain retained; no threshold/alloc/byte rule was weakened or waived. Integer allocation parity does not prove no new key-allocation site (profile17 reports103→104 where uninstrumented gate medians104→104).

Ordinary selected-COW writes retain+2objects and inline+88B/WAL,+72B/NoWAL. Original paired mean changes inline durable/relaxed/NoWAL+3.78/+5.61/+6.74%; pointer+11.23/+13.62/+17.32%. Ablation verifies two objects and dynamic key-custody lease removal and a consistent aggregate pointer-history feature cost; it does not explain every original-baseline residual. Enabled validation scales with newer effects, not old occupancy; retained old2048 scan validation is roughly120–225ns, newer unrelated2048 chunks561–824ns forward/609–746ns reverse. Combined ordinary+txn hold counters are explicitly combined, not isolated transaction/sustained-Q evidence.

Original relaxed-pointer p99 remains worse and unexplained. The marked trace finds common long Dup stalls on both sides, plus real trainer/dictionary sync overlap, but p99-defining calls do not overlap training/GC and their Running time has no CPU attribution. No blanket no-regression/necessary-tail claim is made. Coordinator explicitly accepts minimized continuous-history/key-custody cost and these unexplained short-fixture tails as **an intermediate-landing risk**, with final graph qualification mandatory. No speculative product patch is justified by present evidence.

No known remaining P1 implementation gap is being deferred. The untouched-baseline retained-snapshot checkpoint→vacuum capacity/refresh/possible-Close failure remains P2-owned and is not claimed qualified; P1 preserves sequence/no-publication/old-view behavior on refusal and successful checkpoint old-txn commit. Final graph maintenance repair, later architecture stages, mature review/current-head CI and final graph performance qualification remain outstanding coordinator work.

## Retention and release

No active processes/commands or worker-owned Go slot. P1 source ownership now transfers to coordinator; worker awaits only bounded follow-up. All original acceptance binaries, compact raw logs/manifests, failed captures with invalid labels, profiles, traces and necessary source controls remain intact. P1 evidence occupies about2.4GiB and baseline evidence167MiB. Large retained raw-gate directories15/17/18 are about319/332/326MiB; ablation110MiB. Coordinator owns eventual pruning/archive after its publication/evidence needs. Worker released its exclusive retention hold; it did not delete acceptance artifacts or unrelated files. Only reproducible large parsed-trace dumps and duplicated per-operation JSON from the last diagnostic were removed after binding their hashes; compact traces, bounded summary and reproducible parser remain.
