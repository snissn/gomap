#!/usr/bin/env python3
"""One predeclared history ablation: six balanced pairs, two NoWAL layouts."""
import hashlib,json,math,os,re,statistics,subprocess,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('/workspace/scratch/89fd9f1d8fd0/execution/p1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(path,value):
 temporary=path.with_suffix('.tmp')
 with temporary.open('w') as f:f.write(json.dumps(value,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 temporary.replace(path)
def rows(raw):
 found={}
 for line in raw.decode().splitlines():
  if not line.startswith('BenchmarkCOWPublicDirtyCost/') or ' ns/op' not in line:continue
  v=line.split();name=re.sub(r'-\d+$','',v[0]);assert int(v[1])==512
  metrics={v[i+1]:float(v[i]) for i in range(2,len(v),2)};assert all(map(math.isfinite,metrics.values()))
  assert name not in found;found[name]=metrics
 return found
build=json.loads((OUT/'build-manifest.json').read_text())
assert build['protocol']['pairs']==6 and build['protocol']['retries']==0
assert os.environ.get('GOMAXPROCS')=='2' and not os.environ.get('GOGC') and not os.environ.get('GOMEMLIMIT')
for name,digest in build['sources'].items():assert sha(ROOT/name)==digest,name
for v in build['binaries'].values():assert sha(Path(v['path']))==v['sha256']
expected={'BenchmarkCOWPublicDirtyCost/no_wal_fast/cow_btree/'+layout+'/N=1024/IncrementalWrite' for layout in ['Inline64','Pointer4096']}
manifest={'classification':'causal diagnostic ablation only; invalid conditional history; not acceptance','build_manifest_sha256':sha(OUT/'build-manifest.json'),'driver_sha256':sha(Path(__file__)),'protocol':build['protocol'],'results':[]}
regex='^BenchmarkCOWPublicDirtyCost$/^no_wal_fast$/^cow_btree$/^(Inline64|Pointer4096)$/^N=1024$/^IncrementalWrite$'
for pair in range(1,7):
 for variant in (['normal','disabled'] if pair%2 else ['disabled','normal']):
  binary=Path(build['binaries'][variant]['path']);argv=[str(binary),'-test.run=^$','-test.bench='+regex,'-test.benchtime=512x','-test.count=1','-test.benchmem','-test.timeout=5m']
  start=time.monotonic();r=subprocess.run(argv,cwd=ROOT,env=dict(os.environ,GOMAXPROCS='2'),capture_output=True,timeout=330)
  prefix=OUT/f'pair-{pair:02d}-{variant}'
  for suffix,raw in [('stdout',r.stdout),('stderr',r.stderr)]:
   path=prefix.with_suffix('.'+suffix)
   with path.open('wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
   assert path.read_bytes()==raw
  parsed=rows(r.stdout);complete=r.returncode==0 and set(parsed)==expected and r.stdout.decode().rstrip().endswith('PASS')
  record={'pair':pair,'variant':variant,'argv':argv,'binary_sha256':sha(binary),'exit':r.returncode,'complete':complete,'elapsed_seconds':time.monotonic()-start,'rows':parsed,'stdout_inline':r.stdout.decode(),'stderr_inline':r.stderr.decode(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
  manifest['results'].append(record);save(OUT/'capture-manifest.json',manifest)
  if not complete:raise SystemExit('incomplete ablation capture; stopped without retry')
  for metrics in parsed.values():
   assert metrics['diagnostic_logical_seq']==513 and metrics['fixture_cow_publications_total']==513
   assert metrics['diagnostic_journal_effects']==(1536 if variant=='normal' else 0)
   assert metrics['diagnostic_index_points']==(1024 if variant=='normal' else 0)
   assert all(metrics[key]==0 for key in ['fixture_checkpoint_runs','fixture_command_wal_sync_count','fixture_command_wal_file_sync_calls','fixture_value_log_sync_calls','snapshot_rotations/op','warm_snapshot_rotations'])
for name in expected:
 for pair in range(1,7):
  a=next(r['rows'][name] for r in manifest['results'] if r['pair']==pair and r['variant']=='normal')
  b=next(r['rows'][name] for r in manifest['results'] if r['pair']==pair and r['variant']=='disabled')
  assert a['fixture_cow_external_leases']-b['fixture_cow_external_leases']==513
assert json.loads((OUT/'capture-manifest.json').read_text())==manifest
print(json.dumps({'manifest_sha256':sha(OUT/'capture-manifest.json'),'processes':len(manifest['results']),'rows':sum(len(r['rows']) for r in manifest['results']),'all_complete':True}))
