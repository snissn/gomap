## TreeDB MVCC raw-path gate

- verdict: **FAIL**
- measured threshold observation: **FAIL**
- baseline: `0149d78dba2574b09d7119d2631ec78a144e088d`
- candidate: `49d7edd9a2d4407827aa884ab8818ec22712a06a`
- samples: 8 per revision, benchmark-group-paired alternating AB/BA order
- timing acceptance: median paired candidate/base relative delta <= 5% (base/head medians remain reported for context)
- allocs/op threshold: candidate median must not increase
- B/op jitter threshold: candidate median may increase by at most the smaller of 1% or 64 B; zero-B baselines remain strict

| Package | Baseline SHA-256 | Candidate SHA-256 | Relation |
| --- | --- | --- | --- |
| db | `18874a95d351ad03cd1f6c12bd6b26274764bcfe251afd61eec4acb1ad7c4c1a` | `b67f101adb439ad6468f49231693b6728d7ead15e8b87670f83201949710e4ca` | DIFFERENT |
| caching | `143dfadf92757f448b036eabdd079b82c915cb9f9b11b97dcc050e08de7e55b1` | `296742d1fabd9758cadd86c287213543111067c704db53e45842fa17a9d8168d` | DIFFERENT |
| treedb | `af9edeab5881acb744dee0de1e338b4c3918577d9d30f20314881152b39f3367` | `c3f0ca4aa61e24d7ebe5ee8fd087b9a252e3e29458e1c9a3041155add836077c` | DIFFERENT |

| Benchmark | Binary | Base ns/op | Head ns/op | Median delta | Paired delta | Base B/op | Head B/op | B tolerance | Base allocs/op | Head allocs/op | Measured | Attribution | Acceptance |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- | --- |
| BenchmarkGetVersioned | db DIFFERENT | 505.000 | 513.900 | +1.76% | +0.22% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkConditionalTxnBaselineBatchWrite | db DIFFERENT | 42264.500 | 46187.000 | +9.28% | +1.13% | 31504.500 | 31646.000 | 64.000 | 104.000 | 105.000 | FAIL | CANDIDATE | FAIL |
| BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek | treedb DIFFERENT | 343.200 | 345.950 | +0.80% | +1.26% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkRepeatedIterator | caching DIFFERENT | 246.150 | 248.250 | +0.85% | +0.43% | 112.000 | 112.000 | 1.120 | 2.000 | 2.000 | PASS | CANDIDATE | PASS |
| BenchmarkPublicCommandWALDurableTinyBatchWriteSync/placement=inline/shape=dirty_batch/ops=1 | treedb DIFFERENT | 8206.000 | 8832.500 | +7.63% | +7.15% | 4475.500 | 4618.500 | 44.755 | 16.000 | 18.000 | FAIL | CANDIDATE | FAIL |
