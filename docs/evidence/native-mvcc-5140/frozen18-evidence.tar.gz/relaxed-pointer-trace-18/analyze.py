import re,json,collections
from pathlib import Path
OUT=Path(__file__).resolve().parent
HEADER=re.compile(r'^M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+)(.*)')
def events(path):
 h=None;lines=[]
 with path.open() as f:
  for line in f:
   m=HEADER.match(line)
   if m:
    if h:yield h,''.join(lines)
    h={'m':int(m[1]),'p':int(m[2]),'g':int(m[3]),'kind':m[4],'t':int(m[5]),'args':m[6].strip()};lines=[]
   else:lines.append(line)
  if h:yield h,''.join(lines)
def intersect(a,b,c,d):return max(0,min(b,d)-max(a,c))
def run(side):
 path=OUT/(side+'-parsed.txt');regions=collections.defaultdict(list);logs=collections.defaultdict(dict);pending={};train=set();labels={};first={};last={}
 for e,stack in events(path):
  g=e['g'];t=e['t'];a=e['args'];k=e['kind'];first.setdefault(g,t);last[g]=t
  if k=='RegionBegin' and 'cow-public-cost-operation' in a:pending[g]=t
  if k=='RegionEnd' and 'cow-public-cost-operation' in a:regions[g].append((pending.pop(g),t))
  if k=='Log' and 'cow-public-cost-latency' in a:
   m=re.search(r'i=(\d+) ns=(\d+)',a);logs[g][int(m[1])]=int(m[2])
  if 'compression.(*Trainer).train ' in stack and 'NotExist->Runnable' not in a:train.add(g)
  if k=='Label':labels[g]=a
 target,spans=next((g,v) for g,v in regions.items() if len(v)==512);assert len(logs[target])==512
 lo,hi=spans[0][0],spans[-1][1]
 # Preserve all benchmark state intervals, including off-timer ones, for clipping by region.
 state={};intervals=collections.defaultdict(list);ranges={};completed=[];interesting=[];training_events=[];syscalls=[]
 for e,stack in events(path):
  t=e['t'];a=e['args'];g=e['g'];k=e['kind']
  if k=='StateTransition' and (m:=re.search(r'GoID=(\d+) (\w+)->(\w+) Reason="([^"]*)"',a)):
   gid=int(m[1]);old,new,reason=m.groups()[1:]
   if gid in state:
    start,st,why,stk=state[gid];intervals[gid].append((start,t,st,why,stk))
   state[gid]=(t,new,reason,stack)
  if k=='RangeBegin':
   key=(re.search(r'Name="([^"]+)"',a)[1],re.search(r'Scope=(\S+)',a)[1]);ranges[key]=(t,g,stack)
  if k=='RangeEnd':
   key=(re.search(r'Name="([^"]+)"',a)[1],re.search(r'Scope=(\S+)',a)[1]);v=ranges.pop(key,None)
   if v:completed.append({'name':key[0],'scope':key[1],'start':v[0],'end':t,'g':v[1],'stack':v[2]})
  if lo<=t<=hi and g==target and k=='StateTransition':interesting.append({'time':t,'args':a,'stack':stack})
  if g in train and ('StateTransition'==k or 'Syscall' in k):training_events.append({'time':t,'g':g,'kind':k,'args':a,'stack':stack})
  if 'dictdb' in stack and lo<=t<=hi:syscalls.append({'time':t,'g':g,'kind':k,'args':a,'stack':stack})
 for gid,(start,st,why,stk) in state.items():intervals[gid].append((start,last.get(gid,hi),st,why,stk))
 result={'side':side,'benchmark_g':target,'calibration_region_counts':{g:len(v) for g,v in regions.items() if g!=target},'operation_count':len(spans),'latency_count':len(logs[target]),'loop_wall_ns':hi-lo,'timed_latency_sum_ns':sum(logs[target].values()),'trainer_gs':sorted(train),'trainer_spans':{g:[first[g],last[g]] for g in train},'dict_stack_events_during_loop':syscalls,'top_operations':[],'all_operations':[]}
 for i,(start,end) in enumerate(spans):
  active=[(max(start,a),min(end,b)) for a,b in [(first[g],last[g]) for g in train] if intersect(start,end,a,b)]
  states=collections.Counter();waits=[]
  for a,b,st,reason,stack in intervals[target]:
   n=intersect(start,end,a,b)
   if n:
    states[st]+=n
    if st!='Running':waits.append({'ns':n,'state':st,'reason':reason,'stack':stack})
  rr=[dict(r,overlap_ns=intersect(start,end,r['start'],r['end'])) for r in completed if intersect(start,end,r['start'],r['end'])]
  gcassist=sum(r['overlap_ns'] for r in rr if r['name']=='GC mark assist' and r['g']==target)
  stw=sum(r['overlap_ns'] for r in rr if r['name'].startswith('stop-the-world'))
  trainrunning=sum(intersect(start,end,a,b) for g in train for a,b,st,_,_ in intervals[g] if st=='Running')
  row={'i':i,'start':start,'end':end,'region_ns':end-start,'latency_ns':logs[target][i],'states_ns':dict(states),'foreground_gc_assist_ns':gcassist,'stw_ns':stw,'trainer_lifetime_overlap':bool(active),'trainer_running_ns':trainrunning,'waits':waits,'ranges':rr}
  result['all_operations'].append(row)
 result['top_operations']=sorted(result['all_operations'],key=lambda r:r['latency_ns'],reverse=True)[:10]
 result['loop_totals']={'states_ns':dict(sum((collections.Counter(r['states_ns']) for r in result['all_operations']),collections.Counter())),'foreground_gc_assist_ns':sum(r['foreground_gc_assist_ns'] for r in result['all_operations']),'stw_ns':sum(r['stw_ns'] for r in result['all_operations']),'trainer_running_ns':sum(r['trainer_running_ns'] for r in result['all_operations']),'ops_overlapping_trainer_lifetime':sum(r['trainer_lifetime_overlap'] for r in result['all_operations'])}
 (OUT/(side+'-training-events.json')).write_text(json.dumps(training_events,indent=2)+'\n')
 (OUT/(side+'-operation-attribution.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(side,'target',target,'trainer',sorted(train),'loop',hi-lo,'sum',result['timed_latency_sum_ns'],'dict_events',len(syscalls));print('totals',result['loop_totals'])
 for r in result['top_operations']:print('top',r['i'],r['latency_ns'],r['states_ns'],'assist',r['foreground_gc_assist_ns'],'stw',r['stw_ns'],'trainrun',r['trainer_running_ns'],[(x['state'],x['reason'],x['ns']) for x in r['waits']])
 return result
if __name__=='__main__':
 for side in ['baseline','candidate']:run(side)
