import hashlib,json,os,subprocess
from pathlib import Path
BASE=Path('/workspace/scratch/89fd9f1d8fd0'); OUT=Path(__file__).resolve().parent
FIELDS='GoFiles CgoFiles CFiles CXXFiles MFiles HFiles FFiles SFiles SwigFiles SwigCXXFiles SysoFiles EmbedFiles TestGoFiles XTestGoFiles TestEmbedFiles XTestEmbedFiles'.split()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj):
 t=p.with_suffix('.tmp')
 with t.open('w') as f: f.write(json.dumps(obj,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 t.replace(p)
def sources(root):
 raw=subprocess.check_output(['go','list','-buildvcs=false','-deps','-test','-json','./TreeDB'],cwd=root,text=True)
 dec=json.JSONDecoder(); paths={root/'go.mod',root/'go.sum'}
 for n in ['go.work','go.work.sum']:
  if (root/n).exists():paths.add(root/n)
 while raw.strip():
  raw=raw.lstrip();p,n=dec.raw_decode(raw);raw=raw[n:];d=Path(p.get('Dir','/')).resolve()
  if d.is_relative_to(root):
   for field in FIELDS:
    paths.update(x for name in p.get(field,[]) if (x:=(d/name).resolve()).is_relative_to(root))
 return {str(p.relative_to(root)):sha(p) for p in sorted(paths)}
def main():
 m={'classification':'ONE marked trace pair; instrumented diagnostic only; no acceptance or timing claim','original_baseline':'0149d78dba2574b09d7119d2631ec78a144e088d','frozen18_commit':'c23338b31cd1c3af42356d4d68a7a85a22498eb4','frozen18_tree':'bed3920afec44abf68dfb5736a846255c2e04f27','go':subprocess.check_output(['go','version'],text=True).strip(),'go_env':json.loads(subprocess.check_output(['go','env','-json','GOFLAGS','CGO_ENABLED','GOOS','GOARCH','GOWORK'],text=True)),'runtime_env':{k:os.environ.get(k,'<unset>') for k in ['GOMAXPROCS','GOGC','GOMEMLIMIT']},'shared_overlay_sha256':sha(OUT/'cow_public_cost_marked_test.go'),'harness_patch_sha256':sha(OUT/'harness.patch'),'driver_sha256':sha(Path(__file__)),'builds':[]}
 for side,root in [('baseline',BASE/'gomap'),('candidate',BASE/'execution/p1')]:
  original=sources(root); binary=OUT/(side+'.test'); overlay=OUT/(side+'-overlay.json')
  argv=['go','test','-buildvcs=false','-overlay='+str(overlay),'-c','-o',str(binary),'./TreeDB']
  r=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  for stream,data in [('stdout',r.stdout),('stderr',r.stderr)]: (OUT/(side+'-build.'+stream)).write_bytes(data)
  entry={'side':side,'root':str(root),'sources':original,'source_input_count':len(original),'build_argv':argv,'exit':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'overlay_map_sha256':sha(overlay)}
  m['builds'].append(entry);save(OUT/'build-manifest.json',m)
  if r.returncode:raise SystemExit(r.returncode)
  assert sources(root)==original,'source changed during build'
  entry.update(binary=str(binary),binary_sha256=sha(binary),go_version_m=subprocess.check_output(['go','version','-m',str(binary)],text=True))
  save(OUT/'build-manifest.json',m)
 print('build manifest',sha(OUT/'build-manifest.json'))
 for x in m['builds']:print(x['side'],x['source_input_count'],x['binary_sha256'])
if __name__=='__main__':main()
