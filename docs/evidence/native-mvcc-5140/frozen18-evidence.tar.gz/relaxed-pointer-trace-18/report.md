# Frozen18 relaxed-pointer tail: one marked diagnostic pair

The trace establishes substantial inherited syscall outliers and actual dictionary-training overlap, but **does not fully explain the original candidate p99 regression**. No product repair or additional capture was selected. Instrumented results cannot replace the original comparison or qualify performance.

The shared benchmark-only overlay is identical across baseline and candidate. Region begin/end surround the original `time.Now`/`time.Since` operation measurement;512 latency messages are emitted only after every timed write finishes. Exactly512 operation regions and512 samples belong to each selected benchmark goroutine (baseline31, candidate52). Separate one-operation calibration is excluded. Original production source/index, acceptance binaries, compression policy and operation shape were unchanged.

| Diagnostic side | Mean ns/op | Measured p99 | Timed Set sum | Foreground syscall state | Foreground runnable state |
|---|---:|---:|---:|---:|---:|
| Baseline |146898|375841ns|74.738ms|46.300ms|0.0438ms|
| Frozen18 |144019|548278ns|73.263ms|46.301ms|0.0397ms|

These are one instrumented sample per side, not an acceptance comparison. Go trace Running state is not a CPU profile: it includes time for which the OS might deschedule a thread without a Go scheduler transition.

## Six slowest measured operations

| Side | Ordinal | Latency | Largest observed syscall interval | Trainer alive during call |
|---|---:|---:|---:|---|
| Baseline |96|20.544ms|20.404ms Dup|no|
| Baseline |40|9.105ms|8.949ms Dup|yes|
| Baseline |480|7.981ms|7.882ms Dup|no|
| Baseline |224|4.610ms|4.530ms Dup|no|
| Baseline |203|3.329ms|0.015ms pread|no|
| Baseline |369|0.376ms|0.005ms write|no|
| Frozen18 |96|16.519ms|16.369ms Dup|no|
| Frozen18 |40|11.214ms|11.085ms Dup|yes|
| Frozen18 |224|7.979ms|7.904ms Dup|no|
| Frozen18 |480|6.948ms|6.848ms Dup|no|
| Frozen18 |190|0.850ms|0.007ms pread|no|
| Frozen18 |508|0.548ms|0.005ms write|no|

All four matching long-Dup ordinals follow the pre-existing foreground route `appendCommandWALIntentWithTiming -> captureCommandWALExternalDependencies -> CaptureStableExternalRIDFence -> NewStableValueLogResourceToken -> NewStableResourceToken -> initializeStableResourceToken -> duplicateStableSyncFile -> duplicateStableFile -> unix.Dup`. Baseline and candidate both execute it. No history validation, journal lease admission or transaction synchronization appears in the blocking stack. The repeated ordinal pattern suggests a resource-growth boundary, but the trace does not expose file-descriptor numbers or kernel internals, so a specific kernel mechanism is not asserted.

The sixth slowest operation defines p99 for512 samples. Baseline369 and candidate508 do not overlap the trainer lifetime. Neither contains a foreground GC-assist or STW interval; their traced Running components are358.976us and536.512us, while syscall components are17.984us and12.672us. There are no CPU sample events. Their remaining time therefore cannot be assigned to history, compression CPU, or OS descheduling from these traces. Candidate190 and baseline203 likewise have substantial unassigned Running time, with observed dictionary-read stacks but no CPU attribution.

## Actual dictionary overlap and limits

Default pointer compression trains from the seeded data. `Trainer.appendSample` starts a goroutine; `acceptProfile` immediately invokes `applyValueLogDictProfileForClass`. This publishes through a separate dictdb backend (`public.go` creates it with CommandWAL=false). `dictdb.Store.PutDictBytes` calls the dictionary writer.Sync and batch.WriteSync, followed by SetK/SetCurrent sync writes. Thus zero main-fixture command-WAL/value-log sync counters do not exclude dictionary-store sync work.

The training goroutine overlaps45 baseline and32 candidate marked calls, with9.537ms and8.904ms traced trainer Running time intersecting marked calls. The trace records105 baseline and102 candidate dictionary-stack state events on the trainer goroutine during the measured loop, plus8 foreground dictionary-read events per side. Both trainer goroutines include actual Fsync stacks. One long-Dup call (ordinal40) overlaps training; three do not. Mere overlap does not establish that training caused a foreground delay.

Summed STW intersections are124.096us baseline and101.888us candidate. Foreground GC-assist intersections are zero on both sides. No foreground Waiting intervals were observed within marked calls; syscall, Running and brief Runnable states account for the intervals. These measurements exclude seed/setup, stopped-timer `ReadMemStats`, final checks and Close. Whole-process trace totals must not be divided by512.

## Identity and reproduction

`build-manifest.json` binds the original2431 baseline/2445 candidate repo-local runtime/test/assembly/embed/module inputs, shared overlay, overlay maps, compiler/runtime environment and both marked binaries. `capture-manifest.json` binds exact argv, embedded stdout/stderr, raw files, trace and binary hashes. `summary.json` retains six slowest calls and aggregate stack/overlap counts. `parse-manifest.json` records successful trace decoding and sched/sync/syscall profile derivation.

Capture was one baseline→candidate512x pair, no retry. Both processes produced exactly one benchmark row, terminal PASS and successful zero-charge final Close. A separate call verified raw/hash/source/binary/overlay/tree identities. Raw source/index remains tree `bed3920afec44abf68dfb5736a846255c2e04f27`.

Original compact traces and parser remain. Large parsed dumps and duplicated per-operation JSON are reproducible intermediates, removed after their hashes were bound in summary.json. To reproduce analysis only: use `go tool trace -d=parsed` into `<side>-parsed.txt`, run `analyze.py`, then `summarize.py`; do not rerun capture.py.

Conclusion: retain the understood required history/key-custody feature cost and hard raw-gate18 PASS separately. This diagnostic narrows the large outliers to a shared existing resource-capture path and disproves a blanket dictionary-overlap explanation for the observed p99 calls. It does not justify a product patch, a no-regression claim, or acceptance of the original relaxed-pointer p99 result. Coordinator disposition is still required.
