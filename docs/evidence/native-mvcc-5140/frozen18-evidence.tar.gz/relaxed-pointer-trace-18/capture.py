import hashlib,json,os,re,subprocess
from pathlib import Path
from build import OUT,sha,save
BENCH='^BenchmarkCOWPublicDirtyCost$/^command_wal_relaxed$/^cow_btree$/^Pointer4096$/^N=1024$/^IncrementalWrite$'
ROW='BenchmarkCOWPublicDirtyCost/command_wal_relaxed/cow_btree/Pointer4096/N=1024/IncrementalWrite'
def main():
 path=OUT/'capture-manifest.json'
 if path.exists():raise SystemExit('NO RETRY: capture manifest exists')
 build=json.loads((OUT/'build-manifest.json').read_text())
 m={'classification':'single marked trace pair; instrumented only; no acceptance comparison','build_manifest_sha256':sha(OUT/'build-manifest.json'),'driver_sha256':sha(Path(__file__)),'runtime_env':{k:os.environ.get(k,'<unset>') for k in ['GOMAXPROCS','GOGC','GOMEMLIMIT']},'commands':[]}
 assert m['runtime_env']==build['runtime_env']
 save(path,m)
 for side in ['baseline','candidate']:
  b=next(x for x in build['builds'] if x['side']==side);binary=Path(b['binary']);trace=OUT/(side+'.trace')
  assert sha(binary)==b['binary_sha256']
  argv=[str(binary),'-test.run=^$','-test.bench='+BENCH,'-test.benchmem','-test.benchtime=512x','-test.count=1','-test.timeout=5m','-test.trace='+str(trace)]
  r=subprocess.run(argv,cwd=b['root'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  for stream,data in [('stdout',r.stdout),('stderr',r.stderr)]:
   p=OUT/(side+'.'+stream)
   with p.open('wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
   assert p.read_bytes()==data
  out=r.stdout.decode();err=r.stderr.decode();rows=re.findall(r'^(Benchmark\S+?)(?:-\d+)?\s+512\s+\S+\s+ns/op\b',out,re.M)
  entry={'side':side,'argv':argv,'exit':r.returncode,'binary_sha256':sha(binary),'stdout':out,'stderr':err,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'rows':rows,'complete':r.returncode==0 and rows==[ROW] and out.rstrip().endswith('PASS'),'trace':str(trace),'trace_sha256':sha(trace) if trace.exists() else None}
  m['commands'].append(entry);save(path,m)
  if not entry['complete']:raise SystemExit('invalid/incomplete trace attempt; no retry')
 print('capture_manifest_sha256',sha(path))
 for x in m['commands']:print(x['side'],x['trace_sha256'],x['rows'])
if __name__=='__main__':main()
