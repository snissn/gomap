import json,hashlib,collections
from pathlib import Path
OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def frames(stack):
 result=[]
 for line in stack.splitlines():
  if line.startswith('\t') and not line.startswith('\t\t'):
   name=line.strip().split(' @')[0]
   if name not in result: result.append(name)
 return result
m={'classification':'ONE instrumented marked trace pair; not performance acceptance; no repeated capture','capture_manifest_sha256':sha(OUT/'capture-manifest.json'),'build_manifest_sha256':sha(OUT/'build-manifest.json'),'analysis_script_sha256':sha(OUT/'analyze.py'),'summary_script_sha256':sha(Path(__file__)),'sides':[],'limits':['Trace supplies goroutine state intervals, not CPU samples or kernel/OS scheduler attribution while Go state is Running.','Region edges are outside original per-Set latency timestamps; state/range intersections use region bounds, so include small trace/timestamp overhead.','GC, running and trainer overlap times are not mutually exclusive; do not add them together.','Setup, one-operation calibration, stopped timers, final verification and Close are excluded by selecting exactly512 marked operations.','Original comparison18 uninstrumented p99 values remain valid observations, not explained away by this one pair.']}
for side in ['baseline','candidate']:
 raw=OUT/(side+'-operation-attribution.json');x=json.loads(raw.read_text());te=json.loads((OUT/(side+'-training-events.json')).read_text());ops=x['all_operations'];top=[]
 for op in x['top_operations'][:6]:
  waits=sorted(op['waits'],key=lambda w:w['ns'],reverse=True)
  top.append({k:op[k] for k in ['i','latency_ns','region_ns','states_ns','foreground_gc_assist_ns','stw_ns','trainer_lifetime_overlap','trainer_running_ns']}|{'largest_syscall_or_wait':({'ns':waits[0]['ns'],'state':waits[0]['state'],'frames':frames(waits[0]['stack'])[:16]} if waits else None)})
 fg=collections.Counter();trainer=collections.Counter();dictionary=collections.Counter()
 for op in ops:
  for w in op['waits']:
   fs=frames(w['stack']);fg[fs[0] if fs else '<none>']+=1
 for e in te:
  fs=frames(e['stack']);trainer[fs[0] if fs else '<none>']+=1
 for e in x['dict_stack_events_during_loop']:
  dictionary[str(e['g'])]+=1
 entry={k:x[k] for k in ['side','benchmark_g','calibration_region_counts','operation_count','latency_count','loop_wall_ns','timed_latency_sum_ns','trainer_gs','trainer_spans','loop_totals']}|{'six_slowest_operations':top,'foreground_nonrunning_interval_stack_counts':dict(fg),'trainer_transition_stack_counts':dict(trainer),'dict_stack_transition_counts_by_goroutine':dict(dictionary),'derived_hashes':{'parsed':sha(OUT/(side+'-parsed.txt')),'full_operation_attribution':sha(raw),'full_training_events':sha(OUT/(side+'-training-events.json'))}}
 m['sides'].append(entry)
(OUT/'summary.json').write_text(json.dumps(m,indent=2)+'\n')
print('summary sha256',sha(OUT/'summary.json'))
