## TreeDB MVCC raw-path gate

- verdict: **FAIL**
- measured threshold observation: **FAIL**
- baseline: `0149d78dba2574b09d7119d2631ec78a144e088d`
- candidate: `38ab3b743ae88e143d74c81e32c6acb4f02008c7`
- samples: 8 per revision, benchmark-group-paired alternating AB/BA order
- timing acceptance: median paired candidate/base relative delta <= 5% (base/head medians remain reported for context)
- allocs/op threshold: candidate median must not increase
- B/op jitter threshold: candidate median may increase by at most the smaller of 1% or 64 B; zero-B baselines remain strict

| Package | Baseline SHA-256 | Candidate SHA-256 | Relation |
| --- | --- | --- | --- |
| db | `18874a95d351ad03cd1f6c12bd6b26274764bcfe251afd61eec4acb1ad7c4c1a` | `fc650ad0cd617a9f228774a5fc88157b3c0f1093ac0b397091e6cc2e6dd16213` | DIFFERENT |
| caching | `143dfadf92757f448b036eabdd079b82c915cb9f9b11b97dcc050e08de7e55b1` | `b21ec6d87d6d132cd9273caabf330c0e01d6b7bbdb248284a1a99da0664ae53b` | DIFFERENT |
| treedb | `af9edeab5881acb744dee0de1e338b4c3918577d9d30f20314881152b39f3367` | `bc31d1fde9b170058794ceb49446981b4d11f315b9d656fee3bd25d02596e461` | DIFFERENT |

| Benchmark | Binary | Base ns/op | Head ns/op | Median delta | Paired delta | Base B/op | Head B/op | B tolerance | Base allocs/op | Head allocs/op | Measured | Attribution | Acceptance |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- | --- |
| BenchmarkGetVersioned | db DIFFERENT | 526.550 | 519.650 | -1.31% | +3.09% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkConditionalTxnBaselineBatchWrite | db DIFFERENT | 42911.000 | 44582.500 | +3.90% | +6.65% | 31504.500 | 31534.000 | 64.000 | 104.000 | 104.000 | FAIL | CANDIDATE | FAIL |
| BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek | treedb DIFFERENT | 340.700 | 338.700 | -0.59% | -0.38% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkRepeatedIterator | caching DIFFERENT | 247.550 | 248.850 | +0.53% | -0.35% | 112.000 | 112.000 | 1.120 | 2.000 | 2.000 | PASS | CANDIDATE | PASS |
| BenchmarkPublicCommandWALDurableTinyBatchWriteSync/placement=inline/shape=dirty_batch/ops=1 | treedb DIFFERENT | 8235.000 | 8280.000 | +0.55% | -0.18% | 4462.500 | 4478.500 | 44.625 | 16.000 | 16.000 | PASS | CANDIDATE | PASS |
