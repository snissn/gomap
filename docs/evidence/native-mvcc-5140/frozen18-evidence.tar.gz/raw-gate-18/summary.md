## TreeDB MVCC raw-path gate

- verdict: **PASS**
- measured threshold observation: **PASS**
- baseline: `0149d78dba2574b09d7119d2631ec78a144e088d`
- candidate: `c23338b31cd1c3af42356d4d68a7a85a22498eb4`
- samples: 8 per revision, benchmark-group-paired alternating AB/BA order
- timing acceptance: median paired candidate/base relative delta <= 5% (base/head medians remain reported for context)
- allocs/op threshold: candidate median must not increase
- B/op jitter threshold: candidate median may increase by at most the smaller of 1% or 64 B; zero-B baselines remain strict

| Package | Baseline SHA-256 | Candidate SHA-256 | Relation |
| --- | --- | --- | --- |
| db | `18874a95d351ad03cd1f6c12bd6b26274764bcfe251afd61eec4acb1ad7c4c1a` | `baf94bed78b0b7da49470c77a5f9ea002231fad243dfaf10131809389f1f85e3` | DIFFERENT |
| caching | `143dfadf92757f448b036eabdd079b82c915cb9f9b11b97dcc050e08de7e55b1` | `b9cd3a32cb714cb691b93d837b7e0e6fc49411bc3cf2d579d154bdcb8de117d0` | DIFFERENT |
| treedb | `af9edeab5881acb744dee0de1e338b4c3918577d9d30f20314881152b39f3367` | `b88f3a8a5149ff5f213c776c4606e2253f5f509eece1b8e48a2aac605152fc91` | DIFFERENT |

| Benchmark | Binary | Base ns/op | Head ns/op | Median delta | Paired delta | Base B/op | Head B/op | B tolerance | Base allocs/op | Head allocs/op | Measured | Attribution | Acceptance |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- | --- |
| BenchmarkGetVersioned | db DIFFERENT | 531.450 | 514.450 | -3.20% | -1.06% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkConditionalTxnBaselineBatchWrite | db DIFFERENT | 42701.000 | 43718.000 | +2.38% | +3.04% | 31504.000 | 31533.500 | 64.000 | 104.000 | 104.000 | PASS | CANDIDATE | PASS |
| BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek | treedb DIFFERENT | 346.850 | 342.000 | -1.40% | -0.78% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkRepeatedIterator | caching DIFFERENT | 250.950 | 249.150 | -0.72% | +0.07% | 112.000 | 112.000 | 1.120 | 2.000 | 2.000 | PASS | CANDIDATE | PASS |
| BenchmarkPublicCommandWALDurableTinyBatchWriteSync/placement=inline/shape=dirty_batch/ops=1 | treedb DIFFERENT | 8169.000 | 8198.000 | +0.36% | -0.96% | 4470.500 | 4473.000 | 44.705 | 16.000 | 16.000 | PASS | CANDIDATE | PASS |
