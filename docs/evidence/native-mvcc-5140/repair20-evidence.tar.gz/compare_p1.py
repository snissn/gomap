"""Run the predeclared, uninstrumented P1 public diagnostics sequentially."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def save_manifest(path, manifest):
    temporary = path.with_suffix('.json.tmp')
    with temporary.open('w') as output:
        output.write(json.dumps(manifest, indent=2) + '\n')
        output.flush()
        os.fsync(output.fileno())
    temporary.replace(path)


def benchmark_rows(path):
    content = path.read_text()
    rows = [line.split()[0] for line in content.splitlines()
            if line.startswith('Benchmark') and ' ns/op' in line]
    return rows, content.rstrip().endswith('PASS')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--before', required=True, type=Path)
    parser.add_argument('--after', required=True, type=Path)
    parser.add_argument('--candidate-manifest', required=True, type=Path)
    parser.add_argument('--baseline-manifest', type=Path)
    parser.add_argument('--shape', choices=['cow-write', 'legacy-conditional', 'backend-write', 'durable-tiny-write', 'all'], default='all')
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    binaries = {'before': args.before.resolve(), 'after': args.after.resolve()}
    candidate = json.loads(args.candidate_manifest.read_text())
    manifest = {
        'classification': 'bounded diagnostics; not sustained or final Q qualification',
        'driver_sha256': sha(Path(__file__)),
        'pairs': 3,
        'binary_sha256': {side: sha(path) for side, path in binaries.items()},
        'candidate_manifest': candidate,
        'baseline_manifest': json.loads(args.baseline_manifest.read_text()) if args.baseline_manifest else None,
        'GOMAXPROCS': '2',
        'GOGC': os.environ.get('GOGC', 'default'),
        'GOMEMLIMIT': os.environ.get('GOMEMLIMIT', 'default'),
        'results': [],
    }
    matrix = [
        ('cow-write', '^BenchmarkCOWPublicDirtyCost$/^(command_wal_durable|command_wal_relaxed|no_wal_fast)$/^cow_btree$/^(Inline64|Pointer4096)$/^N=1024$/^IncrementalWrite$', '512x'),
        ('legacy-conditional', '^BenchmarkPublicConditionalTxnCached(ReadSet(1|10)|ReusableReadSet(1|10)|BaselineGet(1|10)BatchWrite)$', '512x'),
        ('backend-write', '^BenchmarkConditionalTxnBaselineBatchWrite$', '1000x'),
        ('durable-tiny-write', '^BenchmarkPublicCommandWALDurableTinyBatchWriteSync$/^placement=inline$/^shape=dirty_batch$/^ops=1$', '128x'),
    ]
    env = dict(os.environ, GOMAXPROCS='2')
    for shape, regex, iterations in matrix:
        if args.shape == 'all' and shape in ('backend-write', 'durable-tiny-write'):
            continue  # Separate package binary; request this shape explicitly.
        if args.shape != 'all' and args.shape != shape:
            continue
        for pair in range(1, 4):
            before_rows = None
            for side, binary in binaries.items():
                argv = [str(binary), '-test.run=^$', '-test.bench='+regex,
                        '-test.benchmem', '-test.benchtime='+iterations,
                        '-test.count=1', '-test.timeout=5m']
                prefix = args.out / f'{shape}-{pair:02d}-{side}'
                start = time.monotonic()
                result = subprocess.run(argv, env=env, capture_output=True, timeout=330)
                for suffix, body in [('.stdout', result.stdout), ('.stderr', result.stderr)]:
                    with prefix.with_suffix(suffix).open('wb') as output:
                        output.write(body)
                        output.flush()
                        os.fsync(output.fileno())
                rows, terminal_pass = benchmark_rows(prefix.with_suffix('.stdout'))
                expected_count = 1 if shape in ('backend-write', 'durable-tiny-write') else 6
                complete = terminal_pass and len(rows) == expected_count and len(set(rows)) == expected_count
                if side == 'before':
                    before_rows = rows
                else:
                    complete = complete and rows == before_rows
                manifest['results'].append({'shape': shape, 'pair': pair, 'side': side,
                    'argv': argv, 'exit_code': result.returncode,
                    'whole_process_seconds': time.monotonic()-start,
                    'benchmark_rows': rows, 'terminal_pass': terminal_pass,
                    'complete': complete,
                    'stdout_inline': result.stdout.decode(),
                    'stderr_inline': result.stderr.decode(),
                    'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                    'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(),
                    'stdout': prefix.with_suffix('.stdout').name,
                    'stderr': prefix.with_suffix('.stderr').name})
                save_manifest(args.out/'manifest.json', manifest)
                if result.returncode:
                    raise SystemExit(f'{shape} pair {pair} {side} failed; logs retained, matrix stopped')
                if not complete:
                    raise SystemExit(f'{shape} pair {pair} {side}: incomplete/mismatched benchmark output; matrix stopped')
    saved = json.loads((args.out/'manifest.json').read_text())
    if saved != manifest:
        raise SystemExit('manifest readback mismatch')
    print(json.dumps({'manifest': str(args.out/'manifest.json'),
                      'sha256': sha(args.out/'manifest.json'),
                      'complete_results': len(manifest['results'])}))


if __name__ == '__main__':
    main()
