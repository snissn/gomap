"""Build and check the immutable review repair; no timed samples here."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'p1-gate20'
EVIDENCE = ROOT / 'evidence/p1'
HEAD = 'f42f532ad0e63cab3c99296ea27140ce22f59859'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE, text=True).strip()

assert git('rev-parse', 'HEAD') == HEAD
assert not git('status', '--porcelain')
receipt_path = EVIDENCE / 'repair20-build-check-receipts.json'
assert not receipt_path.exists()
receipts = []
binary = EVIDENCE / 'candidate20-public.test'
pattern = 'Test(History|COWTxn|PublicCOWTxn|PublicTxnNoOvertake|PublicConditionalTxn|ConditionalTxn|TxnJournal|ConditionalKVContract)'
jobs = [
    ('focused', ['go', 'test', './TreeDB/internal/txnhistory', './TreeDB/db', './TreeDB/caching', './TreeDB', './TreeDB/docs', '-run', pattern, '-count=1', '-timeout=180s']),
    ('fence-race', ['go', 'test', '-race', './TreeDB/db', '-run', '^TestConditionalTxnWaitsForVisibleHistoryCompletion$', '-count=1', '-timeout=90s']),
    ('build-public', ['go', 'test', '-buildvcs=false', '-c', '-o', str(binary), './TreeDB']),
]
for name, argv in jobs:
    output = EVIDENCE / f'repair20-{name}.txt'
    started = time.monotonic()
    print('START', name, flush=True)
    with output.open('xb') as log:
        result = subprocess.run(argv, cwd=SOURCE, stdout=log, stderr=subprocess.STDOUT)
    receipt = {'name': name, 'argv': argv, 'cwd': str(SOURCE), 'head': HEAD,
               'exit': result.returncode, 'elapsed_s': time.monotonic()-started,
               'output': str(output), 'sha256': sha(output)}
    receipts.append(receipt)
    receipt_path.write_text(json.dumps(receipts, indent=2)+'\n')
    print(json.dumps(receipt), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
spec = importlib.util.spec_from_file_location('capture20', SOURCE/'scripts/raw_cow_txn_capture.py')
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
deps = capture.runtime_sources(SOURCE)
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=SOURCE).split(b'\0')
sources = {p.decode(): sha(SOURCE/p.decode()) for p in tracked if p and (SOURCE/p.decode()).is_file()}
manifest = {
    'head': HEAD, 'frozen_commit': HEAD, 'staged_tree': git('rev-parse', 'HEAD^{tree}'),
    'sources': sources, 'public_runtime_dependencies': deps,
    'binaries': {'public': {'path': str(binary), 'sha256': sha(binary)}},
    'go': subprocess.check_output(['go', 'version'], text=True).strip(),
    'go_env': json.loads(subprocess.check_output(['go','env','-json','GOFLAGS','CGO_ENABLED','GOOS','GOARCH','GOWORK'], text=True)),
    'runtime_env': {k: os.environ.get(k,'<unset>') for k in ['GOMAXPROCS','GOGC','GOMEMLIMIT']},
}
path = EVIDENCE/'comparison-20-manifest.json'
assert not path.exists()
path.write_text(json.dumps(manifest, indent=2)+'\n')
(EVIDENCE/'enabled20-binary-manifest.json').write_text(json.dumps({
    'binary_sha256':sha(binary),'sources':deps,'build_manifest_sha256':sha(path)},indent=2)+'\n')
assert not git('status','--porcelain')
print(json.dumps({'candidate': HEAD, 'tree':manifest['staged_tree'], 'binary_sha256':sha(binary),
                  'tracked_sources':len(sources),'runtime_inputs':len(deps),'manifest_sha256':sha(path)}), flush=True)
