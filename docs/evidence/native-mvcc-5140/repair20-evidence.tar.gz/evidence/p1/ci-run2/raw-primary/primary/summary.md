## Public PRIMARY replacement cost

- Verdict: PASS
- Exact base/head: `0149d78dba2574b09d7119d2631ec78a144e088d` / `d64fba3d88fe15bd89bf086face1981a7d3f6b97`
- Eight alternating AB/BA pairs; 128 durable public replacements per sample.
- Median paired time delta: -0.013% (limit +5%).
- Gates: `{"allocations": true, "bytes": true, "candidate_primary_activation": true, "timing": true}`; quiet: True.
- Scope: this public replacement workload; not final graph qualification.
