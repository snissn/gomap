## TreeDB MVCC raw-path gate

- verdict: **PASS**
- measured threshold observation: **PASS**
- baseline: `0149d78dba2574b09d7119d2631ec78a144e088d`
- candidate: `d64fba3d88fe15bd89bf086face1981a7d3f6b97`
- samples: 8 per revision, benchmark-group-paired alternating AB/BA order
- timing acceptance: median paired candidate/base relative delta <= 5% (base/head medians remain reported for context)
- allocs/op threshold: candidate median must not increase
- B/op jitter threshold: candidate median may increase by at most the smaller of 1% or 64 B; zero-B baselines remain strict

| Package | Baseline SHA-256 | Candidate SHA-256 | Relation |
| --- | --- | --- | --- |
| db | `a693988cb42f8b44578f6f037511a00df79d8be1d14f5dd13f13d2d940029143` | `3f6a376f834b371bc4fcd6ff93ae8770ae55b28df53757de2e6fb6e954febf45` | DIFFERENT |
| caching | `6cb8af92122575cb49140ae081f27b7ff51a526e8d72602e3e1213f5d48ccd62` | `6d2afdb847102c52013fdf75b97265662fead7f712ec4b90970d03bf98649c57` | DIFFERENT |
| treedb | `0acfad58c4ae885b7bdad6bb701ecdcdf217f8792ec50a18892a9d4f5b197bee` | `74aa79e607f3e3e935d53c95db0268b8e4d1d6c845155842f6ca5241bec7ff5c` | DIFFERENT |

| Benchmark | Binary | Base ns/op | Head ns/op | Median delta | Paired delta | Base B/op | Head B/op | B tolerance | Base allocs/op | Head allocs/op | Measured | Attribution | Acceptance |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- | --- |
| BenchmarkGetVersioned | db DIFFERENT | 591.450 | 612.400 | +3.54% | +3.57% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkConditionalTxnBaselineBatchWrite | db DIFFERENT | 56188.500 | 56768.000 | +1.03% | +1.36% | 31502.500 | 31501.000 | 64.000 | 104.000 | 103.000 | PASS | CANDIDATE | PASS |
| BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek | treedb DIFFERENT | 343.300 | 343.600 | +0.09% | +0.07% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkRepeatedIterator | caching DIFFERENT | 390.850 | 388.250 | -0.67% | -0.59% | 112.000 | 112.000 | 1.120 | 2.000 | 2.000 | PASS | CANDIDATE | PASS |
| BenchmarkPublicCommandWALDurableTinyBatchWriteSync/placement=inline/shape=dirty_batch/ops=1 | treedb DIFFERENT | 295083.000 | 296239.500 | +0.39% | -0.17% | 4568.500 | 4569.000 | 45.685 | 17.000 | 17.000 | PASS | CANDIDATE | PASS |
