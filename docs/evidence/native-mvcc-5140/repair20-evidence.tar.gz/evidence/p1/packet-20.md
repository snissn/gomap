TreeDB's public COW cache rejects native conditional transactions, and its older adapters retain conflict evidence only while transactions are active. This adds one consistent raw transaction contract over retained COW views and ordinary producers.

Part of #5139; progresses #5140.

- Read from the retained opening COW cut plus owned staged writes; validate points, misses, blind writes and complete forward/reverse ranges against one bounded mutation history.
- Preserve separate canonical assignment, complete logical installation and durability completion. Keep publication exclusion through installation or terminal poison; release progress-critical ownership before waiting.
- Replace both active-transaction conflict maps with one shared FIFO/index. Own immutable keys through final eviction and reject expired history.
- Preserve custody on refused admission, own child iterator/predicate lifetimes, and cancel shared preparation before admitting the next writer.

The public capability is raw-only. Global accepted-prefix lifecycle, collections/composites, managed history and DATA activation and PRIMARY retirement remain #5141–#5145.


### Current repair and status

**Review candidate; repair20 published and current-head CI required.** Head `ea4f5bc6294245488526df6015f59e0b98b89674` has exact measured tree `98068799cc4ea5cf7ea733f2db00c64a68f74dfa` (local frozen commit `f42f532ad0e63cab3c99296ea27140ce22f59859`).

This coherent review repair preserves accepted conflict evidence until a new mutation is actually installed. Preparation reserves private capacity without evicting records or advancing the floor; cancellation/refused admission leaves accepted history unchanged. Singleton keys still use precharged inline storage without adding per-write allocations. The [accepted P1 blueprint amendment](https://github.com/snissn/gomap/issues/5139#issuecomment-6232809262) records this refinement.

Also fixes retained-record statistics, owned-backend cleanup on failed Open, capture preflight output creation, and readiness documentation. The reported optimistic publication gap is not present: the existing root-reuse fence remains held through history completion. A deterministic concurrent regression test exercises that boundary; no new production lock or ordering layer was introduced.

### Validation and performance

- Exact repair20 focused history/backend/cache/public/docs tests pass. The deterministic publication-fence test passes with the race detector. History cancellation/refusal has a valid failing-before/passing-after control across slot/byte exhaustion; history and caller checks pass.
- CI impact and contract checks pass; only the discovery fingerprint changed, with no CI-selection or workflow relaxation.
- Exact repair20 enabled capture: three fresh processes × 30 shapes × 128 operations, all complete. Raw samples, runtime sources and binary hashes independently checked after capture.
- Ordinary COW: three pairs × six profile/layout cells × 512 writes. Allocations match the original baseline in every cell (70/87/70/160/67/82); median B/op rises 0.32–3.00%. Median timing deltas are +33.13%, +19.97%, +1.27%, +9.42%, +39.53%, +7.60%, respectively. These short diagnostics do **not** establish performance parity or sustained qualification.
- Prior repair19 normal/race/safe checks across eleven packages, three-package command-WAL recovery, and raw/PRIMARY measurements remain explicitly bound to that earlier source. They are not relabeled as repair20 evidence. Repair20 changes received the focused checks above; current-head CI must validate its mandatory gates.
- Repair19 hosted ordinary CI aggregate, raw and PRIMARY passed (PRIMARY paired −0.0126%, 391→391 allocations). The separate vacuum job remained red: original public attempts all returned typed retry; its single retry completed all public attempts but exceeded legacy variability limits. No further blind retry, criterion change, or waiver was made. Repair20 needs a fresh full CI result and is not claimed to repair that vacuum instability.

The coordinator accepts the disclosed bounded ordinary-write overhead **for this intermediate P1 capability only**, extending the [repair19 disposition](https://github.com/snissn/gomap/pull/5146#issuecomment-6232543424): retained correctness evidence is necessary, allocation parity is preserved, and existing profiling/activation evidence identifies real publication/sync work. This is not a performance-improvement claim and does not waive raw/PRIMARY/vacuum gates or final integrated Q. The final graph must measure and resolve unacceptable overhead on its completed architecture; #5145 remains open. No dedicated qualification runner is exposed.

Repair20 public binary SHA256: `f748601bc18f543606b6518ee48867ad2420945b2bc770e814b1aff3abc74452`; enabled manifest `9bee4a864023a977d6a9f0a773ee5f23e83156d46e1ea909570f1b1518225e6f`; ordinary manifest `0161b11bb6513ddb88a261d1d91ddda1928c16059849fa21096a5c12bf27ee9e`. Local source-bound repair20 packet retained; archive publication follows in a non-PR evidence branch.

The verified [repair19 evidence archive](https://github.com/snissn/gomap/tree/a0343d2e84ec6a09c6017f96dc354c0410b0ebc6/docs/evidence/native-mvcc-5140) retains 121 files plus manifest, successes and failures, exact sources, raw/ordinary/enabled captures and environment-refused PRIMARY attempts. Archive SHA256: `7c5052b8ab22c76d882569f8065b263fa5d77925588c5cb4c33a5ecb4295833f`. Remote commit/tree/blob identity matches the locally verified archive. Evidence-only pushes use [skip ci]; implementation CI is unchanged.

[Execution state](https://github.com/snissn/gomap/issues/5139#issuecomment-6230274247).

<!-- This is an auto-generated comment: release notes by coderabbit.ai -->

## Summary by CodeRabbit

* **New Features**
  * Added conditional transactions for qualified copy-on-write databases, with forward and reverse iteration, staged reads and writes, and bounded range deletion.
  * Added conflict detection for changed reads and writes, including range-based changes and expired transaction history.
  * Added reverse iteration to copy-on-write views and snapshots.
* **Documentation**
  * Documented transaction behavior, eligibility, limits, and durability guarantees.

<!-- end of auto-generated comment: release notes by coderabbit.ai -->

## Review disposition

- Thread PRRT_kwDOIdn7C86tfS6S: Fixed in ea4f5bc6294245488526df6015f59e0b98b89674. Prepare now admits private key storage without evicting accepted records or advancing the floor. Install performs eviction only for an accepted capability; cancel/refused admission preserves the records, point index, floor and leases. The inline singleton path uses precharged preparation storage and retains allocation parity. TestHistoryRefusedOrCanceledPreparationPreservesAcceptedHistory fails on the previous implementation and passes across slot/byte exhaustion × cancellation/admission refusal; focused history and race checks pass. The original blueprint explicitly allowed reserve-time eviction, so issue #5140 and parent amendment https://github.com/snissn/gomap/issues/5139#issuecomment-6232809262 now record the accepted architectural refinement.
- Thread PRRT_kwDOIdn7C86tfWkT: Fixed in ea4f5bc6294245488526df6015f59e0b98b89674. External binary argument, manifest and source/binary hash validation precede output-directory creation. Missing-manifest and hash-mismatch controls both return exit 2 without creating the requested output directory. The actual source-bound external-binary capture then completed three fresh processes × 30 shapes on the frozen repair.
- Thread PRRT_kwDOIdn7C86tfWkU: Fixed in ea4f5bc6294245488526df6015f59e0b98b89674, including the sibling backend stats implementation. Both adapters report the retained history count from History.State under the oracle lock. The backend stats regression asserts two retained records after overwrite and after transaction cleanup; the exact repair's focused suites pass.
- Thread PRRT_kwDOIdn7C86tfWkW: Investigated and not reproduced: the existing rootReuseMu write fence remains held through completeOrderedPostActivation/history recording; releaseBuildLocks runs afterward. writeOptimistic captures its base under rootReuseMu.RLock. A new base therefore cannot observe the suggested gap, and an already captured old base must pass the existing sequence/root recheck under publication exclusion. ea4f5bc6294245488526df6015f59e0b98b89674 adds TestConditionalTxnWaitsForVisibleHistoryCompletion: pause after durable visible-root installation, verify the root-reuse fence remains locked, start the stale conditional writer and prove base capture remains blocked, then resume and assert ErrConcurrentModification with no target write. The test passes normally and under -race. No new production lock or ordering layer was added. An initial diagnostic attempted a snapshot synchronously while deliberately holding that fence and timed out there; it is retained as a test-harness diagnostic, not represented as a failing product regression.
- Thread PRRT_kwDOIdn7C86tfWkX: Fixed in ea4f5bc6294245488526df6015f59e0b98b89674. The readiness table lists qualified canonical COW conditional transactions as supported and keeps the legacy-cache fail-closed scope explicit. The changed contract documentation and exact repair's focused docs checks pass.
- Thread PRRT_kwDOIdn7C86tfWkZ: Fixed in ea4f5bc6294245488526df6015f59e0b98b89674. A failed BindPrivateCOWOwner now closes the backend, dictionary backend, and template DB, matching the ownership cleanup already used for cache.Open failure. The public focused checks pass.

Codex review request: https://github.com/snissn/gomap/pull/5146#issuecomment-6232976962
