import os,sys,json,subprocess,time,hashlib,signal
from pathlib import Path
B=Path('/home/mikers/benchmarks/mvcc-4871-repair-20261013')
E=B/'evidence/ordinary-5111-final-base-20261015/ci-read-custody-repair-20261015/lifecycle-platform-guard/perf'
E.mkdir(exist_ok=True)
BASEELF=B/'evidence/ordinary-5111-final-base-20261015/ci-perf-b3c7-20261015/baseline.test'
roots={'baseline':B/'ordinary-5111-b3c7-perf-baseline-20261015','candidate':B/'ordinary-5111-final-main-20261015'}
GR=B/'toolchains/go1.26.3-from-185-20261014'; GO=GR/'bin/go'
env=os.environ.copy();env.update(GOROOT=str(GR),GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',CGO_ENABLED='1',GOMAXPROCS='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def census(root):
 rows={}
 for p in root.rglob('*'):
  if p.is_file() and (p.suffix=='.go' or p.name in ('go.mod','go.sum')) and '.git' not in p.parts:
   rows[str(p.relative_to(root))]=sha(p)
 return rows
def state():
 return {k:{'HEAD':subprocess.check_output(['git','-C',str(v),'rev-parse','HEAD'],text=True).strip(),'index':sha(Path(subprocess.check_output(['git','-C',str(v),'rev-parse','--path-format=absolute','--git-path','index'],text=True).strip())),'census':census(v)} for k,v in roots.items()}
def run(name,cmd,cwd,limit=120):
 rec={'argv':list(map(str,cmd)),'cwd':str(cwd),'env':{k:env[k] for k in ('GOROOT','GOTOOLCHAIN','GOWORK','GOPROXY','GOSUMDB','CGO_ENABLED','GOMAXPROCS')},'timeout_s':limit}
 (E/(name+'.command.json')).write_text(json.dumps(rec,indent=2))
 t=time.monotonic()
 with (E/(name+'.raw')).open('wb') as f:
  p=subprocess.Popen(list(map(str,cmd)),cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);p.wait();rc=124
 rec.update(exit=rc,elapsed_s=time.monotonic()-t)
 (E/(name+'.receipt.json')).write_text(json.dumps(rec,indent=2))
 print(name,rc,rec['elapsed_s'],flush=True)
 if rc:sys.exit(rc)

HARNESS=E/'primary_generation_routing_v6_test.go'
OVERLAY=E/'baseline-primary-overlay.json'
if '--timing' not in sys.argv:
 HARNESS.write_bytes((roots['candidate']/'TreeDB/mvcc/primary_generation_routing_v6_test.go').read_bytes())
 OVERLAY.write_text(json.dumps({'Replace':{str(roots['baseline']/'TreeDB/mvcc/primary_generation_routing_v6_test.go'):str(HARNESS)}},indent=2))
 (E/'before.json').write_text(json.dumps(state(),sort_keys=True))
 run('quiet-preflight',['ps','-eo','pid,pcpu,args'],E,10)
 run('build-candidate',[GO,'test','-c','-p=1','-o',E/'candidate.test','./TreeDB/db'],roots['candidate'])
 previous=E.parent.parent/'primary-metadata-scratch-repair/perf'
 assert HARNESS.read_bytes()==(previous/'primary_generation_routing_v6_test.go').read_bytes()
 assert state()['baseline']==json.loads((previous/'before.json').read_text())['baseline']
 baselinePrimary=previous/'baseline-primary.test'
 (E/'baseline-reuse.json').write_text(json.dumps({'baseline_source':str(previous/'before.json'),'baseline_binary':str(previous/'baseline-primary.test'),'sha256':sha(baselinePrimary),'harness_sha256':sha(HARNESS)},indent=2))
 run('build-candidate-primary',[GO,'test','-c','-p=1','-tags=treedb_test','-trimpath','-buildvcs=false','-o',E/'candidate-primary.test','./TreeDB/mvcc'],roots['candidate'])
 binaries={'baseline':BASEELF,'candidate':E/'candidate.test','baseline-primary':baselinePrimary,'candidate-primary':E/'candidate-primary.test'}
 (E/'binaries.json').write_text(json.dumps({k:{'path':str(v),'sha256':sha(v)} for k,v in binaries.items()},indent=2))
 (E/'after-build.json').write_text(json.dumps(state(),sort_keys=True))
 assert (E/'before.json').read_bytes()==(E/'after-build.json').read_bytes()
 run('primary-public-lifecycle',['taskset','-c','0',E/'candidate-primary.test','-test.run=^TestCommitAtPrimaryOnlyRetainsActualDataGeneration$','-test.count=1','-test.timeout=90s','-test.v'],roots['candidate'])
 print('BUILDS AND PUBLIC PRIMARY CONTROL READY; TIMING REQUIRES --timing',flush=True)
 sys.exit(0)
assert json.loads((E/'before.json').read_text())==state(),'SOURCE DRIFT BEFORE TIMING'
expected=json.loads((E/'binaries.json').read_text())
for rec in expected.values():assert sha(Path(rec['path']))==rec['sha256']
run('timing-quiet-preflight',['ps','-eo','pid,pcpu,args'],E,10)
interference=[]
for line in (E/'timing-quiet-preflight.raw').read_text().splitlines()[1:]:
 fields=line.split(None,2)
 if len(fields)!=3:continue
 pid,cpu,args=fields
 if int(pid)==os.getpid():continue
 if float(cpu)>=2.0 or '/bin/go test' in args or '.test -test.' in args:
  interference.append(line)
(E/'quiet-decision.json').write_text(json.dumps({'interference':interference,'runner_pid':os.getpid(),'cpu_threshold_pct':2.0},indent=2))
assert not interference,'UNEXPECTED INTERFERENCE: '+repr(interference)
for bench,bt,primary in [('GetVersioned','500ms',False),('ConditionalTxnBaselineBatchWrite','1000x',False),('CommitAtPrimaryOnlyAfterDataGeneration','128x',True)]:
 for rnd,order in enumerate([['baseline','candidate'],['candidate','baseline'],['baseline','candidate']],1):
  for k in order:
   binary=Path(expected[k+('-primary' if primary else '')]['path'])
   run(f'{bench}-{rnd}-{k}',['taskset','-c','0',binary,'-test.run=^$','-test.bench=^Benchmark'+bench+'$','-test.benchtime='+bt,'-test.count=1','-test.benchmem','-test.timeout=90s'],roots[k])
(E/'after.json').write_text(json.dumps(state(),sort_keys=True))
assert (E/'before.json').read_bytes()==(E/'after.json').read_bytes(),'SOURCE DRIFT'
print('COMPLETE SOURCES UNCHANGED',flush=True)
