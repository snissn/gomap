# Frozen lifecycle/platform short public guard

Complete 43-path source overlay: ../lifecycle-platform-candidate/authored-source-manifest.json (SHA256 6cbc2613c25ef5b5bb8703a23ef7d3f4b9fe345fa7ec3e23c2ca9621259d9f92). Product HEAD b3c7ff702538e552e685ded554a79eb256a3380c; all 3763 candidate Go/module inputs, HEAD and index unchanged before/build/after. Baseline is exact 5bca; fixture overlays and baseline ELF reuse are recorded separately.

Pinned Go1.26.3, offline GOWORK=off/GOTOOLCHAIN=local, CPU0/GOMAXPROCS1. Two fresh candidate builds, then unchanged actual PRIMARY public generation/held-reader/reopen control PASS. Quiet preflight found no interfering process. Eighteen planned samples: three AB/BA/AB pairs per Get500ms, DATA1000x, PRIMARY128x. Every invocation exit0, no replacement/profile.

| Benchmark | Baseline ns/op | Candidate ns/op | Median ratio delta | B/op | Objects/op |
|---|---:|---:|---:|---:|---:|
| GetVersioned | 318.4 | 324.6 | +1.947% | 0.0 → 0.0 | 0.0 → 0.0 |
| ConditionalTxnBaselineBatchWrite | 21376.0 | 20636.0 | -3.462% | 31944.0 → 31503.0 | 127.0 → 104.0 |
| CommitAtPrimaryOnlyAfterDataGeneration | 143491.0 | 147527.0 | +2.813% | 279177.0 → 226888.0 | 474.0 → 392.0 |

All short guard criteria PASS (timing <=5%, no added bytes/objects). PRIMARY generation advances/op baseline2 to candidate0, intended routing proved by actual public lifecycle control. This is bounded viability, not full CI acceptance or a statistical speedup claim. Previous +5.146% PRIMARY RED remains retained; no old sample was replaced.

Focused lifecycle/platform normal/race evidence is separately frozen under ../lifecycle-platform-candidate. Remaining CI retention/fault/format/platform/caller groups remain listed there; Windows/macOS runtime outcomes are not inferred from Linux. No Git/index/source mutation or native execution occurred. Runtime released.

ELFs retained externally by exact paths/hashes in perf/binaries.json; evidence manifest excludes ELF payloads. Baseline PRIMARY binary is reused directly, not copied.
