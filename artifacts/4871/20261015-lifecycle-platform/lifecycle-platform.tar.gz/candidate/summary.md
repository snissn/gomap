# Frozen lifecycle/platform candidate
Source parent b3c7ff702538e552e685ded554a79eb256a3380c. The complete 43-path authored overlay includes all 10 untracked source/test files, not only the current lifecycle delta. See authored-source-manifest.json and receipt.json. Native and other worktrees were not edited.

The successful consumed publication now advances only its admission lineage scalar while pending removal is locked. Physical terminal completion, durable WaitThrough/ACK, and callback accounting remain after the original terminal join. A deterministic paused-original-retention-shrink control proves successor admission while WaitThrough remains blocked; wrong lineage/skips reject.

Queued/running remap is admitted under original File.closeMu before launch and joined before ordinary physical disposal. Captured original aliases/accounting survive to actual worker exit. Native close first admits its existing close-control, gates new remap admission, and yields until the already-admitted worker exits. Zero work remains unchanged. Strict deterministic worker barriers cover success and sticky physical failure; original Promote tests and actual Mongo concurrent-upsert test pass race.

Readonly owned ref-count fallback now uses the unconditional identity registry metadata owner, preserving owned countRecords. The actual treemap readonly audit asserts nonzero referenced segments/bytes. Windows namespace creation proof uses the maintained exact-handle stable-sync duplication and its admitted suffix charge. Fresh insufficient native mapping quantum is explicitly UnitTooLarge; residual insufficient quantum yields. Actual Windows/macOS execution remains an open hosted gate.

Retained index sync uses the exact retained handle and independently charged captured diagnostic path; it never reopens by that path or preserves a refunded pager alias. Both legacy and asserted real owned PRIMARY capture sync after DB.Close with exact events. The first normal owned-named fixture silently selected the legacy fallback; retain that raw as legacy-only. Corrected owned-activation enables PRIMARY and requires stablePagerCompletion before Close, and passes.

Focused results: six normal package invocations PASS; corrected owned activation PASS; remap/Promote and actual Mongo race invocations PASS. Per-invocation command, full raw output, source census, before/after identity and exact source copies are retained under controls. No timeout or replacement run.

Current performance is NOT qualified: previous compact metadata PRIMARY +5.146% remains RED. Next requested measurement is exactly the existing 18 samples: Get500ms, DATA1000x and PRIMARY128x, three AB/BA/AB pairs against retained exact5bca baseline, after root quiet grant. No timing/profile was run for this repair batch. Captured sync-path ownership adds real owned capacity and must be included.

Remaining 46-test hosted failure inventory is preserved in remaining-ci-groups.json with focused fixes distinguished from unresolved platform validation and retention/format/fault/caller groups. No remaining assertion was weakened and no retention/vacuum suite was expanded before this freeze.
