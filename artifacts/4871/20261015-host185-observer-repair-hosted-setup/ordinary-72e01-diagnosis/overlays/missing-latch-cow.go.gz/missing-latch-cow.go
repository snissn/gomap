package treedb_test

import (
	"bytes"
	"errors"
	"fmt"
	"path/filepath"
	"strings"
	"sync"
	"testing"

	treedb "github.com/snissn/gomap/TreeDB"
	backenddb "github.com/snissn/gomap/TreeDB/db"
	"github.com/snissn/gomap/TreeDB/internal/durabilitycut"
	"github.com/snissn/gomap/TreeDB/internal/powerlossoracle"
	"github.com/snissn/gomap/TreeDB/internal/powerlossreopen"
)

// This test materializes only bytes and names observed at completed production
// persistence boundaries. It is distinct from a subprocess exit: dirty kernel
// state and Close's later writes never enter the captured stable image.
func TestCOWPublicModeledStableImageCheckpointAndNoWALVolatileAck(t *testing.T) {
	for _, profile := range []treedb.Profile{treedb.ProfileCommandWALDurable, treedb.ProfileCommandWALRelaxed, treedb.ProfileNoWALFast} {
		t.Run(fmt.Sprint(profile), func(t *testing.T) {
			opts := treedb.OptionsFor(profile, t.TempDir())
			opts.MemtableMode = "cow_btree"
			opts.DisableSideStores = true
			opts.DisableBackgroundPrune = true
			opts.BackgroundCheckpointInterval = -1
			opts.ValueLog.PointerThreshold = 1
			opts.ValueLog.ForcePointers = true
			db, err := treedb.Open(opts)
			if err != nil {
				t.Fatal(err)
			}
			defer db.Close()
			if err = db.SetSync([]byte("seed"), []byte("stable")); err != nil {
				t.Fatal(err)
			}
			if err = db.Checkpoint(); err != nil {
				t.Fatal(err)
			}
			model, err := powerlossoracle.Capture(opts.Dir)
			if err != nil {
				t.Fatal(err)
			}
			var stable *powerlossoracle.Model
			metaEvents := 0
			var observerMu sync.Mutex
			active := true
			restore := durabilitycut.Install(func(event durabilitycut.Event) error {
				if !cowEventBelongsToDB(opts.Dir, event) {
					return nil
				}
				observerMu.Lock()
				defer observerMu.Unlock()
				if !active {
					return nil
				}
				if err := model.Observe(opts.Dir, event); err != nil {
					return err
				}
				if event.Point == durabilitycut.AfterMetaSync {
					stable = model.Clone()
					metaEvents++
				}
				return nil
			})
			observing := true
			deactivate := func() {
				observerMu.Lock()
				active = false
				observerMu.Unlock()
				restore()
				observing = false
			}
			defer func() {
				if observing {
					deactivate()
				}
			}()

			value := bytes.Repeat([]byte("persistent-pointer-"), 256)
			b := db.NewBatch()
			if err = b.Set([]byte("a"), value); err != nil {
				t.Fatal(err)
			}
			if err = b.Set([]byte("z"), []byte("group")); err != nil {
				t.Fatal(err)
			}
			if err = b.Delete([]byte("seed")); err != nil {
				t.Fatal(err)
			}
			if err = b.Write(); err != nil {
				t.Fatal(err)
			}
			_ = b.Close()
			observerMu.Lock()
			volatileCut := model.Clone()
			observerMu.Unlock()
			if err = db.Checkpoint(); err != nil {
				t.Fatal(err)
			}
			deactivate()
			if stable == nil || metaEvents == 0 {
				t.Fatal("actual COW checkpoint emitted no completed meta sync")
			}
			if profile == treedb.ProfileNoWALFast {
				result, reopened, closeReopened, err := powerlossreopen.Stable(volatileCut, opts, false)
				if err != nil || result.Rejected || reopened == nil {
					t.Fatalf("volatile image reopen: %+v %v", result, err)
				}
				if got, err := reopened.Get([]byte("a")); err != nil || len(got) != 0 {
					t.Fatalf("NoWAL volatile ACK became durable=(%q,%v)", got, err)
				}
				if got, err := reopened.Get([]byte("seed")); err != nil || string(got) != "stable" {
					t.Fatalf("stable baseline=(%q,%v)", got, err)
				}
				if err := closeReopened(); err != nil {
					t.Fatal(err)
				}
			}
			result, reopened, closeReopened, err := powerlossreopen.Stable(stable, opts, false)
			if err != nil || result.Rejected || reopened == nil {
				t.Fatalf("checkpoint image reopen: %+v %v", result, err)
			}
			if got, err := reopened.Get([]byte("a")); err != nil || !bytes.Equal(got, value) {
				t.Fatalf("pointer stable len=%d err=%v", len(got), err)
			}
			if got, err := reopened.Get([]byte("z")); err != nil || string(got) != "group" {
				t.Fatalf("group stable=(%q,%v)", got, err)
			}
			if got, err := reopened.Get([]byte("seed")); err != nil || len(got) != 0 {
				t.Fatalf("deleted stable=(%q,%v)", got, err)
			}
			if err := closeReopened(); err != nil {
				t.Fatal(err)
			}
		})
	}
}

// Interrupt the real COW producer/checkpoint at each observed persistence cut.
// Group acknowledgement and checkpoint interruption are recorded separately:
// an interrupted operation may recover all or none, but never a partial group.
func TestCOWPublicModeledInterruptedDependencyAndRootPublicationCuts(t *testing.T) {
	points := []durabilitycut.Point{
		durabilitycut.BeforeDependencyFileSync, durabilitycut.AfterDependencyFileSync,
		durabilitycut.BeforeNewFileDirectorySync, durabilitycut.AfterNewFileDirectorySync,
		durabilitycut.BeforeIndexDataSync, durabilitycut.AfterIndexDataSync,
		durabilitycut.BeforePublicationSealWrite, durabilitycut.AfterPublicationSealWrite,
		durabilitycut.BeforeMetaWrite, durabilitycut.AfterMetaWrite,
		durabilitycut.BeforeMetaSync, durabilitycut.AfterMetaSync,
	}
	for _, profile := range []treedb.Profile{treedb.ProfileCommandWALDurable, treedb.ProfileCommandWALRelaxed, treedb.ProfileNoWALFast} {
		for _, point := range points {
			t.Run(fmt.Sprintf("%s/%s", profile, point), func(t *testing.T) {
				opts := treedb.OptionsFor(profile, t.TempDir())
				opts.MemtableMode = "cow_btree"
				opts.MemtableShards = 2
				opts.DisableSideStores = true
				opts.DisableBackgroundPrune = true
				opts.BackgroundCheckpointInterval = -1
				opts.ValueLog.PointerThreshold = 1
				opts.ValueLog.ForcePointers = true
				// A real successor segment forces the producer's exact file-name
				// dependency boundary, rather than an invented directory-sync event.
				opts.ValueLog.Generational.Policy = backenddb.ValueLogGenerationHotWarmCold
				opts.ValueLog.Generational.HotSegmentTargetBytes = 4096
				db, err := treedb.Open(opts)
				if err != nil {
					t.Fatal(err)
				}
				defer db.Close()
				if err = db.SetSync([]byte("seed"), []byte("baseline")); err != nil {
					t.Fatal(err)
				}
				if err = db.Checkpoint(); err != nil {
					t.Fatal(err)
				}
				model, err := powerlossoracle.Capture(opts.Dir)
				if err != nil {
					t.Fatal(err)
				}
				var cut *powerlossoracle.Model
				cutErr := fmt.Errorf("modeled COW interruption at %s", point)
				wantResource := durabilitycut.ResourceMeta
				switch point {
				case durabilitycut.BeforeDependencyFileSync, durabilitycut.AfterDependencyFileSync:
					wantResource = durabilitycut.ResourceCommandWAL
					if profile == treedb.ProfileNoWALFast {
						wantResource = durabilitycut.ResourceAuxiliary
					}
				case durabilitycut.BeforeNewFileDirectorySync, durabilitycut.AfterNewFileDirectorySync:
					wantResource = durabilitycut.ResourceValueLog
				case durabilitycut.BeforeIndexDataSync, durabilitycut.AfterIndexDataSync:
					wantResource = durabilitycut.ResourceIndex
				case durabilitycut.BeforePublicationSealWrite, durabilitycut.AfterPublicationSealWrite:
					wantResource = durabilitycut.ResourceSeal
				}
				targetPrimary := filepath.Clean(filepath.Join(opts.Dir, "index.db.primary"))
				matchesCut := func(event durabilitycut.Event) bool {
					if !cowEventBelongsToDB(opts.Dir, event) || event.Point != point || event.Resource != wantResource {
						return false
					}
					return (wantResource != durabilitycut.ResourceMeta && wantResource != durabilitycut.ResourceSeal) || filepath.Clean(event.Path) == targetPrimary
				}
				var capturedPoint durabilitycut.Point
				var resource durabilitycut.Resource
				cutReturned := false
				var observerMu sync.Mutex
				active := true
				matchingCuts := 0
				restore := durabilitycut.Install(func(event durabilitycut.Event) error {
					if !cowEventBelongsToDB(opts.Dir, event) {
						return nil
					}
					observerMu.Lock()
					defer observerMu.Unlock()
					if !active {
						return nil
					}
					target := matchesCut(event)
					if cutReturned {
						// Keep the first completed cut immutable, including its
						// dependency image. Retry only the SAME interruption.
						if target {
							matchingCuts++
							return cutErr
						}
						return nil
					}
					if err := model.Observe(opts.Dir, event); err != nil {
						return err
					}
					if target {
						cut = model.Clone()
						capturedPoint, resource = event.Point, event.Resource
						matchingCuts++
						// Latch only after observation and capture succeed, just
						// before returning the injected cause to its producer.
						cutReturned = true
						return cutErr
					}
					return nil
				})
				observing := true
				deactivate := func() {
					observerMu.Lock()
					active = false
					observerMu.Unlock()
					restore()
					observing = false
				}
				defer func() {
					if observing {
						deactivate()
					}
				}()
				value := bytes.Repeat([]byte("new-segment-persistent-value/"), 1024)
				b := db.NewBatch()
				if err = b.Set([]byte("a"), value); err != nil {
					t.Fatal(err)
				}
				if err = b.Set([]byte("z"), value); err != nil {
					t.Fatal(err)
				}
				if err = b.Delete([]byte("seed")); err != nil {
					t.Fatal(err)
				}
				err = b.Write()
				acknowledged := err == nil
				_ = b.Close()
				if acknowledged {
					err = db.Checkpoint()
				}
				firstErr := err
				secondErr := db.Checkpoint()
				t.Logf("SAME handle original=%v second_admission=%v", firstErr, secondErr)
				if secondErr != nil { err = secondErr }
				deactivate()
				if cut != nil && (model.StableFingerprint() != cut.StableFingerprint() || fmt.Sprint(model.Trace()) != fmt.Sprint(cut.Trace())) { t.Fatal("first cut model mutated after latch") }
				if cut == nil {
					t.Fatalf("real COW route emitted no %s boundary (operation=%v)", point, err)
				}
				cutReturned = false // diagnostic: remove only successful-cut lineage
				capturedExactCut := cutReturned && capturedPoint == point && resource == wantResource
				// The original command-WAL flush or PRIMARY installation can
				// poison admission before this checkpoint reaches the publisher.
				// Its readiness gate returns only the typed recovery sentinel.
				// Accept it only after this observer captured the SAME exact cut
				// and returned cutErr; unrelated poison is never a cut witness.
				observedCutPoison := capturedExactCut && errors.Is(err, backenddb.ErrRecoveryRequired)
				if !capturedExactCut || err == nil || (!errors.Is(err, cutErr) && !observedCutPoison) {
					t.Fatalf("interruption classification err=%v captured=%t point=%s resource=%s matching_attempts=%d", err, capturedExactCut, capturedPoint, resource, matchingCuts)
				}
				result, reopened, closeReopened, reopenErr := powerlossreopen.Stable(cut, opts, false)
				if reopenErr != nil || result.Rejected || reopened == nil {
					t.Fatalf("stable cut rejected: %+v %v", result, reopenErr)
				}
				defer closeReopened()
				a, err := reopened.Get([]byte("a"))
				if err != nil {
					t.Fatal(err)
				}
				z, err := reopened.Get([]byte("z"))
				if err != nil {
					t.Fatal(err)
				}
				seed, err := reopened.Get([]byte("seed"))
				if err != nil {
					t.Fatal(err)
				}
				present := bytes.Equal(a, value) && bytes.Equal(z, value) && len(seed) == 0
				absent := len(a) == 0 && len(z) == 0 && string(seed) == "baseline"
				if !present && !absent {
					t.Fatalf("partial group after %s: a=%d z=%d seed=%q", point, len(a), len(z), seed)
				}
				if acknowledged && profile == treedb.ProfileCommandWALDurable && !present {
					t.Fatal("durable acknowledged group lost")
				}
				if acknowledged && profile == treedb.ProfileNoWALFast && point != durabilitycut.AfterMetaSync && !absent {
					t.Fatal("NoWAL interrupted pre-meta-sync group became stable")
				}
				if point == durabilitycut.AfterMetaSync && !present {
					t.Fatal("completed meta sync lost grouped command")
				}
				t.Logf("actual COW cut=%s resource=%s matching_attempts=%d group_acknowledged=%t recovered_group=%t", point, resource, matchingCuts, acknowledged, present)
			})
		}
	}
}

func cowEventBelongsToDB(dir string, event durabilitycut.Event) bool {
	eventRoot := event.Root
	if eventRoot == "" {
		eventRoot = event.Path
	}
	if eventRoot == "" {
		eventRoot = event.NewPath
	}
	if eventRoot == "" {
		eventRoot = event.OldPath
	}
	if eventRoot == "" && len(event.Paths) != 0 {
		eventRoot = event.Paths[0]
	}
	rel, err := filepath.Rel(dir, eventRoot)
	return err == nil && eventRoot != "" && !filepath.IsAbs(rel) && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator))
}
