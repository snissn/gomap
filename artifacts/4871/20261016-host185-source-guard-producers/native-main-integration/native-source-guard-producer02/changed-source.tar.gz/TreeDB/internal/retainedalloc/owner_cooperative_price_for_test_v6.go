package retainedalloc

import "unsafe"

// PendingMutationUnitForTestV6 describes one actual local Reserve row. Parent
// prefixes and concrete lease/participant children are separate, never zero.
type PendingMutationUnitForTestV6 struct{ Records, Bytes uint64 }
type PendingMutationPricesForTestV6 struct {
	OwnerBytes, StateBytes                               uint64
	Entry, Binding, Enrollment, Acknowledge, Observation PendingMutationUnitForTestV6
}

func CooperativeMutationPricesForTestV6() PendingMutationPricesForTestV6 {
	o, s := uint64(unsafe.Sizeof(Owner{})), uint64(unsafe.Sizeof(PendingMutationWork{}))
	return PendingMutationPricesForTestV6{
		OwnerBytes: o, StateBytes: s,
		Entry:       PendingMutationUnitForTestV6{1, 2*o + 2*s},
		Binding:     PendingMutationUnitForTestV6{1, 2 * uint64(unsafe.Sizeof(binding{}))},
		Enrollment:  PendingMutationUnitForTestV6{1, 2 * uint64(unsafe.Sizeof(EnrollmentWork{}))},
		Acknowledge: PendingMutationUnitForTestV6{1, 2*s + 2*o + uint64(unsafe.Sizeof(PendingMutationTraffic{}))},
		Observation: PendingMutationUnitForTestV6{1, 2*s + o},
	}
}
