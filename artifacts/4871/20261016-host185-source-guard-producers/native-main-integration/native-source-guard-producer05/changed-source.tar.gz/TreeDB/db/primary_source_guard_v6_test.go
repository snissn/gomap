package db

import (
	"bytes"
	"context"
	"testing"
)

// Neither public ordinary borrower adopts a COW enrollment. Their genuine
// physical edge, inline queue and registration must nevertheless outlive DB.Close.
func TestPrimarySourceOrdinaryBorrowerAfterDBCloseV6(t *testing.T) {
	for _, name := range []string{"snapshot", "recoverable-set"} {
		t.Run(name, func(t *testing.T) {
			d, err := Open(Options{Dir: t.TempDir(), ResolvedProfile: ProfileNoWALFast, Durability: DurabilityWALOffRelaxed, DisableBackgroundPrune: true})
			if err != nil {
				t.Fatal(err)
			}
			defer d.Close()
			if err = d.SetSync([]byte("key"), []byte("old")); err != nil {
				t.Fatal(err)
			}
			idx := d.idx.Load()
			a, registry := idx.primary, idx.registry
			if !a.CapsuleFormatV6() || !registry.SourceGuardsPending() {
				t.Fatal("real capsule source guard missing")
			}
			var snapshot *Snapshot
			var roots *RecoverableRootSet
			if name == "snapshot" {
				snapshot, err = d.AcquireSnapshot()
				if err != nil {
					t.Fatal(err)
				}
				defer snapshot.Close()
				if snapshot.primaryMetadata != nil || snapshot.primaryRoot == nil {
					t.Fatal("ordinary root/enrollment shape")
				}
			} else {
				roots, err = d.CaptureRecoverableRootSet(context.Background())
				if err != nil {
					t.Fatal(err)
				}
				defer roots.Release()
				if len(roots.primaryRefs) == 0 {
					t.Fatal("real recoverable slot/proof references missing")
				}
			}
			if err = d.SetSync([]byte("key"), []byte("new")); err != nil {
				t.Fatal(err)
			}
			// Ordinary snapshots retain their old logical view while the DB is open.
			// After DB.Close only the retained PRIMARY cleanup lifetime is supported.
			if snapshot != nil {
				if got, e := snapshot.Get([]byte("key")); e != nil || !bytes.Equal(got, []byte("old")) {
					t.Fatal("held old source changed", got, e)
				}
			}
			if err = d.Close(); err != nil {
				t.Fatal(err)
			}
			if a.MetadataOwner().PhysicalClosed() || !registry.SourceGuardsPending() {
				t.Fatal("DB close stole held ordinary source")
			}
			if snapshot != nil {
				if err = snapshot.Close(); err != nil {
					t.Fatal(err)
				}
			} else {
				if err = roots.ReleaseWithError(); err != nil {
					t.Fatal(err)
				}
			}
			if registry.SourceGuardsPending() || !a.MetadataOwner().PhysicalClosed() {
				t.Fatal("last ordinary queue left self-pinned generation")
			}
		})
	}
}
