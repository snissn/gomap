from pathlib import Path
import json,subprocess,hashlib,os,time,signal,re,statistics,sys
b=Path("/home/mikers/benchmarks/mvcc-4871-repair-20261013"); o=b/"ordinary-5111-final-main-20261015"; e=b/"evidence/ordinary-5111-final-base-20261015/qualification-current"; gr=b/"toolchains/go1.26.3-from-185-20261014"
env=os.environ.copy(); env.update(GOROOT=str(gr),GOTOOLCHAIN="local",GOWORK="off",GOPROXY="off",GOSUMDB="off",CGO_ENABLED="1",GOMAXPROCS="4")
assert not {k:v for k,v in env.items() if k.startswith(("TREEDB","GOMAP","GOGC","GOMEMLIMIT","GODEBUG"))}
def dump(n,x): (e/n).write_text(json.dumps(x,indent=2)+"\n")
def census():
 rows=[]
 for p in sorted(o.rglob("*")):
  if p.is_file() and (p.suffix==".go" or p.name in ["go.mod","go.sum"]) and ".git" not in p.parts and "artifacts" not in p.relative_to(o).parts:
   d=p.read_bytes(); rows.append(dict(path=str(p.relative_to(o)),sha256=hashlib.sha256(d).hexdigest(),bytes=len(d)))
 return rows
def state():
 index=Path(subprocess.check_output(["git","rev-parse","--git-path","index"],cwd=o,text=True).strip())
 if not index.is_absolute(): index=o/index
 return dict(head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=o,text=True).strip(),index_sha256=hashlib.sha256(index.read_bytes()).hexdigest(),staged=subprocess.check_output(["git","diff","--cached","--name-only"],cwd=o,text=True))
def run(name,args,timeout):
 dump(name+".command.json",dict(argv=args,cwd=str(o),env={k:env[k] for k in ["GOROOT","GOTOOLCHAIN","GOWORK","GOPROXY","GOSUMDB","CGO_ENABLED","GOMAXPROCS"]},outer_timeout=timeout))
 start=time.monotonic(); p=subprocess.Popen(args,cwd=o,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True); timed=False
 try: raw=p.communicate(timeout=timeout)[0]
 except subprocess.TimeoutExpired:
  timed=True; os.killpg(p.pid,signal.SIGKILL); raw=p.communicate()[0]
 (e/(name+".raw")).write_bytes(raw); rec=dict(exit=p.returncode,timeout=timed,elapsed_s=time.monotonic()-start,raw_sha256=hashlib.sha256(raw).hexdigest()); dump(name+".receipt.json",rec); print(name,json.dumps(rec),flush=True)
 if p.returncode or timed: print(raw.decode(errors="replace")[-5000:],flush=True); raise SystemExit(1)
 return raw

e.mkdir(exist_ok=True)
stage=sys.argv[1];package=sys.argv[2];regex=sys.argv[3] if len(sys.argv)>3 else None
e=e/stage;e.mkdir()
before=census();st=state();dump("source-before.json",before);dump("state-before.json",st)
args=[str(gr/"bin/go"),"test","-json","-count=1","-p=1","-timeout=110s",package]
if regex:args+=["-run",regex]
try:raw=run("normal",args,120)
finally:
 after=census();dump("source-after.json",after);dump("state-after.json",state())
 assert before==after and st==state()
if raw:
 events=[]
 for line in raw.decode(errors="replace").splitlines():
  try:events.append(json.loads(line))
  except ValueError:pass
 dump("summary.json",dict(top_level_pass=sum(x.get("Action")=="pass" and "Test"in x and "/"not in x["Test"] for x in events),failures=[x for x in events if x.get("Action")=="fail"],package_pass=[x for x in events if x.get("Action")=="pass" and "Test" not in x]))
 print((e/"summary.json").read_text(),flush=True)
