# b3c7 public-path regression diagnostic
Exact baseline 5bca87ffe6e1bfba2d693264d2dc82936adc234f; candidate b3c7ff702538e552e685ded554a79eb256a3380c plus inherited formatting-only test. Go 1.26.3, offline, CPU0/GOMAX1. Three AB/BA/AB pairs per unchanged public benchmark; all planned samples retained.

GetVersioned 500ms medians:319.2 ->442.0ns (+38.47%), zero bytes/objects. Separate candidate2s CPU capture:2.86s sampled; captureSnapshot26.92% cumulative, Snapshot.Close23.43%, mutexLock+Unlock19.93% flat. Overlapping cumulative values are not additive. Empty-log one-shot reads still retain/release Manager wrapper and count generation containing borrows with mutexes.

Batch.Write1000x medians:21298 ->22202ns (+4.24%),31943 ->34050B,127 ->132objects. Separate rate1 allocation capture includes process setup/checkpoints and is attribution only; its394008ns is not latency. Batch +5objects causal attribution remains open; whole-profile totals are not timed foreground bytes.

All raw samples, commands, binary identities, source censuses and separate profiles are retained here. These are diagnostic durations/toolchain, distinct from CI Go1.26.9/Get2s/Batch1000x. No acceptance or fix-performance claim.
