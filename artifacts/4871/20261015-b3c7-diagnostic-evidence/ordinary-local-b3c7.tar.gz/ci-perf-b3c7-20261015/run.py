import os,sys,json,subprocess,time,hashlib,signal
from pathlib import Path
B=Path('/home/mikers/benchmarks/mvcc-4871-repair-20261013')
E=B/'evidence/ordinary-5111-final-base-20261015/ci-perf-b3c7-20261015'
roots={'baseline':B/'ordinary-5111-b3c7-perf-baseline-20261015','candidate':B/'ordinary-5111-final-main-20261015'}
GR=B/'toolchains/go1.26.3-from-185-20261014'; GO=GR/'bin/go'
env=os.environ.copy();env.update(GOROOT=str(GR),GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',CGO_ENABLED='1',GOMAXPROCS='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def census(root):
 rows={}
 for p in root.rglob('*'):
  if p.is_file() and (p.suffix=='.go' or p.name in ('go.mod','go.sum')) and '.git' not in p.parts:
   rows[str(p.relative_to(root))]=sha(p)
 return rows
def state():
 return {k:{'HEAD':subprocess.check_output(['git','-C',str(v),'rev-parse','HEAD'],text=True).strip(),'index':sha(Path(subprocess.check_output(['git','-C',str(v),'rev-parse','--path-format=absolute','--git-path','index'],text=True).strip())),'census':census(v)} for k,v in roots.items()}
def run(name,cmd,cwd,limit=120):
 rec={'argv':list(map(str,cmd)),'cwd':str(cwd),'env':{k:env[k] for k in ('GOROOT','GOTOOLCHAIN','GOWORK','GOPROXY','GOSUMDB','CGO_ENABLED','GOMAXPROCS')},'timeout_s':limit}
 (E/(name+'.command.json')).write_text(json.dumps(rec,indent=2))
 t=time.monotonic()
 with (E/(name+'.raw')).open('wb') as f:
  p=subprocess.Popen(list(map(str,cmd)),cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);p.wait();rc=124
 rec.update(exit=rc,elapsed_s=time.monotonic()-t)
 (E/(name+'.receipt.json')).write_text(json.dumps(rec,indent=2))
 print(name,rc,rec['elapsed_s'],flush=True)
 if rc:sys.exit(rc)
(E/'before.json').write_text(json.dumps(state(),sort_keys=True))
run('quiet-preflight',['ps','-eo','pid,pcpu,args'],E,10)
for k,v in roots.items():
 run('build-'+k,[GO,'test','-c','-p=1','-o',E/(k+'.test'),'./TreeDB/db'],v)
(E/'binaries.json').write_text(json.dumps({k:{'path':str(E/(k+'.test')),'sha256':sha(E/(k+'.test'))} for k in roots},indent=2))
for bench,bt in [('GetVersioned','500ms'),('ConditionalTxnBaselineBatchWrite','1000x')]:
 for rnd,order in enumerate([['baseline','candidate'],['candidate','baseline'],['baseline','candidate']],1):
  for k in order:
   run(f'{bench}-{rnd}-{k}',['taskset','-c','0',E/(k+'.test'),'-test.run=^$','-test.bench=^Benchmark'+bench+'$','-test.benchtime='+bt,'-test.count=1','-test.benchmem','-test.timeout=90s'],roots[k])
run('GetVersioned-cpu',['taskset','-c','0',E/'candidate.test','-test.run=^$','-test.bench=^BenchmarkGetVersioned$','-test.benchtime=2s','-test.count=1','-test.cpuprofile='+str(E/'get.cpu.pprof'),'-test.timeout=90s'],roots['candidate'])
run('BatchWrite-alloc',['taskset','-c','0',E/'candidate.test','-test.run=^$','-test.bench=^BenchmarkConditionalTxnBaselineBatchWrite$','-test.benchtime=1000x','-test.count=1','-test.memprofile='+str(E/'batch.allocs.pprof'),'-test.memprofilerate=1','-test.timeout=90s'],roots['candidate'])
(E/'after.json').write_text(json.dumps(state(),sort_keys=True))
assert (E/'before.json').read_bytes()==(E/'after.json').read_bytes(),'SOURCE DRIFT'
print('COMPLETE SOURCES UNCHANGED',flush=True)
