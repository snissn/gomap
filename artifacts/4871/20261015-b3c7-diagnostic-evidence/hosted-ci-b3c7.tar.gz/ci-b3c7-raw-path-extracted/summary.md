## TreeDB MVCC raw-path gate

- verdict: **FAIL**
- measured threshold observation: **FAIL**
- baseline: `5bca87ffe6e1bfba2d693264d2dc82936adc234f`
- candidate: `b3c7ff702538e552e685ded554a79eb256a3380c`
- samples: 8 per revision, benchmark-group-paired alternating AB/BA order
- timing acceptance: median paired candidate/base relative delta <= 5% (base/head medians remain reported for context)
- allocs/op threshold: candidate median must not increase
- B/op jitter threshold: candidate median may increase by at most the smaller of 1% or 64 B; zero-B baselines remain strict

| Package | Baseline SHA-256 | Candidate SHA-256 | Relation |
| --- | --- | --- | --- |
| db | `943733dcfb972d319198a05d4ae13bcfc857e243339b106212421442e89193fe` | `a6db12ff64b22dd990340a65290ab60e71dcc9b2f981664eadc1dd7948abc344` | DIFFERENT |
| caching | `09a243b41aa0486cf78b4e98493204d3620c74bece6780c6c55ac44a2382ab12` | `68fe989a4acb2ad5fea8754522908adbf18af4f40b0d784c075b23755284fd69` | DIFFERENT |
| treedb | `4519a5d48cfabf9d68dead1ef4fdb0bd9ca673a99fdbe8451b181ec043824950` | `0091fbd3291cfba55b01732d4eea9116f31b4d9bcec344442fc7ff64c62ca86c` | DIFFERENT |

| Benchmark | Binary | Base ns/op | Head ns/op | Median delta | Paired delta | Base B/op | Head B/op | B tolerance | Base allocs/op | Head allocs/op | Measured | Attribution | Acceptance |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- | --- |
| BenchmarkGetVersioned | db DIFFERENT | 508.950 | 669.650 | +31.57% | +31.32% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | FAIL | CANDIDATE | FAIL |
| BenchmarkConditionalTxnBaselineBatchWrite | db DIFFERENT | 46588.500 | 50625.500 | +8.67% | +9.47% | 31944.500 | 34049.000 | 64.000 | 127.000 | 132.000 | FAIL | CANDIDATE | FAIL |
| BenchmarkSnapshotIteratorSeekNext/keys=1024/snapshot_seek | treedb DIFFERENT | 301.500 | 306.450 | +1.64% | +2.02% | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | PASS | CANDIDATE | PASS |
| BenchmarkRepeatedIterator | caching DIFFERENT | 318.500 | 315.050 | -1.08% | -0.55% | 112.000 | 112.000 | 1.120 | 2.000 | 2.000 | PASS | CANDIDATE | PASS |
| BenchmarkPublicCommandWALDurableTinyBatchWriteSync/placement=inline/shape=dirty_batch/ops=1 | treedb DIFFERENT | 398261.500 | 390336.500 | -1.99% | +0.30% | 4563.000 | 4561.500 | 45.630 | 17.000 | 17.000 | PASS | CANDIDATE | PASS |
