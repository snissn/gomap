---
name: "github-pr-mergeable"
description: "Drive one or more GitHub pull requests through mergeable readiness, and merge only when repo policy and user authorization permit: deep review, test/benchmark coverage, PR description quality, latest-head CI, AI review resolution, and optional merge execution."
---

# GitHub PR Mergeable Loop

Use this skill when the user asks to make PRs mergeable, stabilize PRs, resolve reviews, get CI green, prepare a PR stack for review, or ensure Codex-required review and optional reviewer feedback are handled.

Default assumption: make eligible PRs mergeable. Merge execution is allowed only when repo policy permits it and the user has authorized merge execution, either explicitly in the current request or through a repo/workstream rule that clearly delegates it. If repo policy requires human approval, prohibits self-merge, or says agents must not merge, stop at mergeable evidence and hand off.

## Policy Audit First

Before merge-related action, inspect repo-local policy when available:

- `AGENTS.md`;
- `CONTRIBUTING.md`;
- PR templates;
- branch protection or merge policy docs;
- tracker issues or roadmap docs named by the user.

Repo-local rules override this skill. If policy and user instructions conflict, follow the stricter/no-merge interpretation unless the user explicitly authorizes a documented exception.

Audit policy from the actual checkout/worktree for **each** adopted PR, not only the coordinator's current directory. Enumerate every tracked `AGENTS.md` at the PR head (for example, `git ls-tree -r --name-only <head> | grep -E '(^|/)AGENTS\.md$'` or the recursive GitHub tree API), map changed paths to all root and nested policy files whose directory scope contains them, and read those exact-head bytes. Include an `AGENTS.md` added or modified by the PR. Record any review-round cap, proportionality rule, scientific acceptance path, or stop condition before requesting a reviewer. A repository-local review stop is merge policy, not an optional suggestion.

## Operating Modes

- `readiness-only`: make the PR or stack objectively mergeable, but do not merge.
- `mergeable-with-human-approval`: make the PR or stack mergeable and clearly state that human approval/merge is required.
- `coordinator-merge`: make and merge PRs only when repo policy allows agent/coordinator merge and the user has authorized it.

If the mode is ambiguous, default to `readiness-only`.

## Definition Of Mergeable

A PR is mergeable only when current evidence proves:

- latest PR head has no merge conflicts;
- latest-head CI is passing or explicitly non-blocking with a documented reason;
- code has had an internal deep review for correctness, drift, complexity, and tests;
- tests cover the behavior changed by the PR;
- performance-sensitive changes include relevant benchmark evidence in the PR body or a PR comment, do **not** show an unaccepted material regression, and meet any explicit improvement/saturation gate unless the PR is explicitly instrumentation/safety-only or a linked blocker/waiver is recorded;
- Codex review, when required by the effective repository/workstream policy, has been requested only after the PR is mature enough to avoid review-credit churn, and after meaningful pushes where available;
- when Codex remains required, the latest-head review has completed cleanly as either an explicit no-findings issue comment or an approved/clean review tied to the exact head SHA, with no unresolved Codex threads, or a documented internal review fallback has accepted that exact candidate under the effective policy;
- when repository-local proportionality or scientific stop rules replace the default Codex gate, the PR records that policy, the bounded review disposition, and the acceptance evidence required by that policy; every existing thread is still fixed or explicitly rejected with rationale;
- any additional completed reviews have their actual findings, checks, and threads resolved; unavailable optional reviews or acknowledgement reactions alone do not block mergeability;
- AI review findings are fixed or explicitly rejected with rationale;
- review threads are commented on and marked resolved where the platform supports resolution;
- PR description accurately states scope, tests, benchmarks, risks, and remaining caveats.

Do not use stale green checks, stale reviews, or older benchmark numbers as proof for the latest head.

## Performance Regression Gate

For any PR that touches a hot path, storage/read/write path, cache, search, decode, query, serialization, materialization, benchmark harness, or persistent format, a material local regression is a **blocking mergeability failure** by default.

A regression includes worse `ns/op`, `ops/sec`, `B/op`, `allocs/op`, rebuild/storage overhead, latency sub-timers, or domain counters caused by the PR’s own code. When evidence shows a regression:

1. Mark the PR **not mergeable / performance-blocked** in the handoff or PR comment.
2. Profile and optimize the changed path before mergeability can be claimed; remove avoidable extra work, allocations, copies, I/O, locks, scans, or setup inside the measured boundary.
3. Rerun the identical before/after benchmark matrix on the latest head and update the PR evidence.
4. Claim mergeability only if the regression is eliminated, or if the remaining regression is proven correctness-required/unavoidable, minimized, explicitly documented with impact and profiles, and accepted by the coordinator/user.

Do not normalize regressions as “expected overhead” without this investigation and explicit acceptance.

## Insufficient Improvement Gate

For optimization PRs with explicit improvement, saturation, latency, throughput, allocation, or counter targets, **no regression is not enough**.

If latest-head evidence is neutral or misses the stated gate:

1. Mark the PR **not mergeable / gate-blocked** unless the issue is explicitly instrumentation-only or safety-only.
2. Profile the latest head to identify the next limiter and decide whether the same PR should continue iterating.
3. If the PR cannot reasonably meet the gate, update the tracker/PR with the measured blocker and open or link a follow-up issue that blocks downstream/final-gate completion.
4. Include a root-cause classification for the miss before choosing the next action: weak substrate, insufficient work shape, serial fan-in, coordination/locking, external sync/I/O, or benchmark noise.
5. Claim mergeability only after the gate passes, the PR is explicitly re-scoped, or the coordinator/user records an explicit waiver with evidence and impact.

Do not close performance stacks by documenting "insufficient improvement" as the default outcome. The default loop is iterate, fix, or mutate the graph with a real blocker.

## Inventory First

For each PR, gather:

```sh
gh pr view <PR> --repo <OWNER>/<REPO> \
  --json number,title,url,state,headRefName,baseRefName,headRefOid,mergeStateStatus,isDraft,reviewDecision,statusCheckRollup,comments,reviews

gh pr checks <PR> --repo <OWNER>/<REPO>

gh run list --repo <OWNER>/<REPO> --branch <HEAD_BRANCH> --limit 20
```

Also inspect local branch state when working in a checkout:

```sh
git status --short
git branch --show-current
git log --oneline --decorate -n 8
```

If the worktree is dirty, preserve unrelated user edits. Use a detached worktree per PR or stack branch when that keeps changes auditable.

For Codex review state, use the bundled classifier instead of inspecting only
the pull-request `reviews` array:

```sh
python3 "${CODEX_HOME:-${HOME}/.codex}/skills/github-pr-mergeable/scripts/codex_review_gate.py" \
  --repo <OWNER>/<REPO> --pr <PR> --check
```

The classifier inventories explicitly paginated issue comments, formal reviews,
and review threads without requiring version-specific `gh api --slurp` support.
Exit `0` means the Codex-specific gate is clean; exit `2` means its JSON result
names the pending request, findings, unresolved threads, retry exhaustion, or
PR-lifetime churn stop. A churn-stop result is an action boundary, not
permission to ignore threads. If repository policy supplies a bounded
alternative scientific acceptance path, evaluate and record that path
separately. CI and the other merge gates remain separate.

## Internal Deep Review

Before requesting external/AI review, do your own review:

- read the diff against the intended base;
- identify correctness risks, behavioral regressions, race/concurrency risks, persistence/reopen risks, and missing tests;
- verify public wording does not overstate what the code proves;
- check for unnecessary complexity, dead transitional code, duplicate abstractions, and drift from the tracker/issue;
- for performance-sensitive code, look for hot-loop allocations, extra memcopies, repeated setup/open/decode, broad locks, full-column/full-index scans, stale caches, or misleading benchmark labels.

If findings are real, fix them before treating the PR as review-ready.

## Tests

Every PR should have test evidence that matches its scope.

- Run focused tests for the changed package/path first.
- Run broader affected tests before final review.
- Add tests when coverage is missing; do not rely only on existing tests if the PR adds new behavior.
- For persistence/storage changes, include close/reopen and corruption/mismatch tests where relevant.
- For concurrency/cache/snapshot changes, include race or concurrent sanity tests where feasible.
- For public API changes, include end-to-end API tests, not just helper tests.

Report exact commands and outcomes in the PR body or comment.

## Benchmarks And Performance Evidence

If the PR touches a hot path, storage/read path, cache, search, decode, query, serialization, or materialization path, include benchmark evidence.

If a run will be retained as merge or acceptance evidence, MUST read and apply
[Retained Evidence Velocity](references/retained-evidence-velocity.md) before
scheduling expensive collection.

Benchmark comments/descriptions should include domain-appropriate metrics. For Go/Rust microbenchmarks this often includes:

- exact command;
- hardware/context if known;
- commit or branch;
- dataset shape;
- what is timed and what is excluded;
- `ns/op`;
- `ops/sec`;
- `B/op`;
- `allocs/op`;
- relevant domain counters such as rows/s, queries/s, bytes read, cache hits/misses, candidates/search, edges/search, or docs fetched.

Use markdown tables. Always include `ops/sec` when reporting `ns/op`. For other domains, use metrics that match the claimed improvement, such as wall time, per-unit latency, p95/p99, memory footprint, bundle size, browser responsiveness, GPU/CPU utilization, or per-stage timing.

Do not optimize unrelated upstream cost inside every PR, but do not accept local regressions from the PR’s own code. If performance drops after review fixes, identify the change that caused it, whether it was correctness-required, and whether local CPU/memcopy/allocation overhead can be removed. A PR with an unexplained or avoidable material regression is not mergeable even if CI and AI reviews are green. A PR with insufficient improvement against its explicit optimization gate is likewise not mergeable until it iterates, re-scopes, or links a blocker/waiver as described above.

## CI Discipline

Use latest-head evidence only.

- If GitHub is backed up, cancel stale CI runs that are not for the current head of active PR branches when safe.
- In stacked/chained PRs, cancel stale runs for superseded intermediate heads after a batch propagation; keep only latest-head CI for active PR heads.
- Ensure the latest commit for each relevant PR has active or completed CI.
- Do not treat green checks from an older head as proof.
- If a check is flaky or external, document the retry/result and current status.

Useful commands:

```sh
gh run list --repo <OWNER>/<REPO> --branch <HEAD_BRANCH> --json databaseId,headSha,status,conclusion,displayTitle,workflowName,createdAt
gh run cancel <RUN_ID> --repo <OWNER>/<REPO>
gh run watch <RUN_ID> --repo <OWNER>/<REPO>
```

Cancel only stale/non-head runs unless the user explicitly authorizes broader cleanup. Do not cancel the only active CI for a PR head unless you are about to push or have already pushed a newer head.

## Base Advancement Without PR Replacement

Keep the same PR while its base advances. Sync once before final review and
again only for an actual conflict, predecessor-contract change, or failing
merge-candidate test; do not continuously chase the default branch. Prefer a
repository merge queue or server-generated merge candidate when available.
Replace the PR only when its branch is genuinely irreparable under repository
policy. Any changed candidate head still requires fresh exact-head evidence.

## Coherent Repair Batches And Cross-Head Churn

Review history applies across the PR lifetime, but is advisory by default. A
repair commit does not erase earlier requests or finding-bearing heads; those
counts help detect churn without automatically blocking a new mature head.

Before every push or new review request, run one coherent repair batch:

1. Inventory all current local findings, latest-head check failures, review
   comments, unresolved threads, total PR-lifetime review requests, and
   distinct finding-bearing heads. After requesting multiple reviewers, wait
   for all to complete or for the configured bounded collection window to
   expire unless an urgent correctness issue requires immediate repair.
2. Apply any explicit repository/user hard cap and classify every finding as a
   claim/contract blocker, in-scope implementation defect, claim/authority
   mismatch, nonblocking hardening, incorrect finding, or unrelated failure.
3. Repair all accepted in-scope findings locally; comment on rejected or
   deferred findings and resolve their threads where appropriate.
4. Audit sibling invariants, run focused validation for the whole batch, and
   update the PR body/evidence.
5. Push once, then start one latest-head CI/review cycle. A batch may contain
   multiple local commits. New external information may start the next batch,
   but do not push and wait one finding at a time.

Keep the PR draft until its issue-wide implementation packet is complete. If
the same material blocker category returns on the second repair head, stop
before creating a third and return one named root-cause or architecture
question to the coordinator. This escalation does not weaken the final
exact-head review gate.

Absent an explicit hard cap, six total requests or three finding-bearing heads
produce a `review_churn_warning`, not a stop. Resolved minor, rejected, or
nonblocking findings must not automatically force an architecture reset. Once
threads are dispositioned and a new head is mature, the exact-head retry budget
governs whether another review may be requested.

Repositories or users may opt into hard PR-lifetime caps with
`--max-total-requests` and `--max-finding-heads`; both defaults are disabled.
Only an exhausted explicit hard cap may produce `review_churn_blocked`. In that
case, disposition current threads, update the PR/tracker, and obtain the
authorization required by that explicit policy before using
`--allow-after-churn`.

Provider latency, quota failure, or request-only exhaustion is reviewer
unavailability, not evidence of an unstable architecture. Record it separately
and follow the effective repository fallback. A clean exact-head result remains
terminal even when advisory or explicit historical thresholds were exceeded.

## Mature PR Before AI Review

Do not request Codex or other review-credit-consuming AI reviewers merely because a PR exists. Codex is the required final AI reviewer by default only when repository/workstream policy does not define a different proportional review or scientific acceptance gate; an internal review fallback is acceptable when hosted review cannot run. First make the PR mature enough that the requested review is likely to inspect the intended final shape:

- the issue-wide implementation packet is complete and coherent: production
  path/fallback, tests, required docs, and performance evidence;
- focused tests and required benchmarks have run, or the PR body states why a required benchmark is not yet applicable;
- the PR body or status comment includes current scope, tests, benchmark evidence, known risks, and non-goals;
- internal deep review has found no known blocking correctness, performance, CI, or scope issues;
- latest-head CI is running or already green for the head that should be reviewed.

If a later meaningful push changes code, benchmarks, or review-relevant behavior, restore this maturity gate before re-requesting AI review. Do not churn AI review credits across half-formed intermediate heads, speculative stack propagation, or PRs with known local blockers.

## AI Review Loop

After meaningful pushes and the maturity gate above, obtain the required exact-candidate review before claiming mergeability; use the internal fallback when hosted review cannot run.

Default assumption for ordinary code PRs without a contrary local rule: request hosted Codex when available and require its latest-head result or a qualifying internal review fallback. For scientific/analytic work, apply repository proportionality and review-stop rules before this default.

Use the repo’s established commands when known. Common pattern:

```sh
gh pr comment <PR> --repo <OWNER>/<REPO> --body "@codex review"
```

Before every Codex trigger, run `scripts/codex_review_gate.py`. Do not trigger
when it reports `clean`, `findings`, or `should_request=false`. A clean result
is terminal for the unchanged head; a later duplicate trigger does not make it
pending again. A later Codex findings review or unresolved Codex thread does
supersede the earlier clean result.

Default to one initial request and at most two retries for the same head, with at least ten minutes between triggers, subject only to an explicit stricter repository-local cap. After that, record Codex as unavailable for that head instead of spamming the PR; do not convert provider exhaustion into `review-scope-reset`. A user may explicitly raise the exact-head cap, but may not bypass re-inventory, a repository-local stop rule, or the stop-on-clean rule without explicit authorization for that exception.

If the configured Codex bot uses a different repo-specific trigger, follow the repo convention. If it is unavailable, record that evidence and use the internal review fallback below when permitted.

For each AI review that produces comments, checks, review threads, or findings,
add every artifact to the next coherent repair batch above. Verify suggested
patches, narrow claims or explicitly defer nonblocking hardening instead of
silently expanding scope, and re-request at most once for the mature batch when
both local and PR-lifetime review budgets permit it.

### Internal Review Fallback

An internal read-only subagent review (`INTERNAL_SUBAGENT_REVIEW`) or a separate
same-agent mock subagent review (`LOCAL_MOCK_SUBAGENT_REVIEW`) is an acceptable
fallback when hosted review or delegation cannot run. Both must inspect the
actual exact candidate, record findings and their disposition, and return
`ACCEPT` or `REJECT`. Label the actual mode and model; a mock review is a real
reviewer pass performed by the current agent, not an independent agent run.

Follow [the fallback contract](references/internal-review-fallback.md) for
evidence, model routing, renewal, and explicit target-repository exceptions.
A qualifying fallback `ACCEPT` satisfies the default internal review gate
without a hosted `clean` result. Record that acceptance separately from hosted
unavailability and preserve all other required merge gates.

### Final AI Review Completion Gate

Before posting final mergeability evidence or merging, re-inventory each requested AI reviewer against the exact latest head SHA:

- When hosted Codex is required by the effective policy, run the bundled classifier to classify its actual state; do not infer state from `reviews` alone. When a qualifying internal fallback or repository-local proportional scientific gate replaces the hosted result, record that policy and exact acceptance evidence instead.
- Codex commonly emits a clean result as an issue comment from
  `chatgpt-codex-connector[bot]` containing both `Codex Review: Didn't find any
  major issues` and `Reviewed commit: <sha>`. That exact-head comment is a
  completed clean artifact even when no formal review object exists. Stop
  requesting reviews for that head immediately.
- Codex emits findings as formal `COMMENTED` reviews and inline review threads.
  Any unresolved Codex thread blocks. If several artifacts exist for one head,
  the latest substantive Codex artifact wins; trigger comments are requests,
  not review artifacts.
- Match the `Reviewed commit` prefix or formal review `commit_id` to the full
  current head. Never use a clean artifact from an older head.
- If Codex acknowledged or started a latest-head review but the classifier has
  no exact-head artifact, treat the hosted request as **pending** until the
  bounded retry policy completes or concrete quota/service evidence establishes
  unavailability. Record fallback acceptance separately from that hosted state.
- Do not merge while a still-required hosted Codex latest-head review is pending, even if `mergeable=MERGEABLE`, `mergeStateStatus=CLEAN`, local validation passes, or earlier threads are resolved. A qualifying internal fallback `ACCEPT` or repository-local proportional scientific acceptance satisfies the default internal gate; an explicit hosted-only requirement still applies.
- If an optional reviewer has an active required status check under branch protection, treat that check as CI and wait for it or document why it is non-blocking. Do not treat a plain acknowledgement reaction from an optional reviewer as a pending merge blocker.
- A reaction alone is not a clean artifact. Require an explicit exact-head
  clean comment/review or qualifying fallback `ACCEPT`, plus zero unresolved
  Codex threads.
- If an optional review completes after the PR was merged and reports real findings, open or push a follow-up fix PR and resolve the late threads.

## Review Thread Resolution

Prefer GitHub review-thread APIs or the UI-equivalent through `gh api graphql` when needed. At minimum, inventory unresolved threads and ensure each has a clear disposition.

GraphQL inventory shape:

```graphql
query($owner:String!, $repo:String!, $number:Int!) {
  repository(owner:$owner, name:$repo) {
    pullRequest(number:$number) {
      reviewThreads(first:100) {
        nodes {
          id
          isResolved
          path
          line
          comments(first:20) {
            nodes {
              author { login }
              body
              url
            }
          }
        }
      }
    }
  }
}
```

For unresolved AI threads:

- fix the code or document why no code change is appropriate;
- reply in the PR/thread with the disposition;
- resolve the thread if resolved by code or rationale.

Do not leave dangling AI review threads when claiming mergeable.

## PR Description / Comment Requirements

Ensure the PR body or a final status comment includes:

- what changed;
- linked issue/tracker;
- path identity and scope boundary;
- tests run with exact commands;
- benchmark table if relevant;
- explicit improvement/saturation gate status for optimization PRs: pass, fail/fix-needed, re-scoped instrumentation/safety-only, linked blocker, or explicit waiver;
- CI status for latest head;
- hosted Codex status and any internal review fallback mode, exact candidate, and disposition;
- known caveats or intentionally deferred work;
- merge intent/status: mergeable handoff, pending human approval, merged by authorized coordinator, or intentionally not merged with reason.

For stacked PRs, also include base PR/branch, dependency order, and whether downstream PRs need rebasing after changes.

## Stacked PR Workflow

For a stack, work bottom-up for merge conflicts and CI, but keep wall time efficient:

- inventory the whole stack first;
- stabilize the lowest blocking PR;
- propagate fixes/rebases upward when necessary, but batch propagation instead of restacking after every tiny commit;
- while CI/reviews run on one PR, make non-conflicting progress on the next;
- after each base PR changes, re-check downstream mergeability and tests;
- keep each PR reviewable by avoiding unrelated cleanup.

Chained PRs need churn control. Avoid quadratic pain from repeatedly merging every base change into every descendant:

- Identify the dependency chain: `main -> PR A -> PR B -> PR C`, including branch names and head SHAs.
- Classify each change as stack-wide, local to one PR, or review-only/docs-only.
- For stack-wide fixes, batch related fixes on the lowest applicable PR, then merge/rebase upward once for the batch.
- For local fixes, keep them on the owning PR and do not churn unrelated downstream branches unless needed for conflicts, tests, or review.
- Limit the number of branches restacked at once. Prefer a small active window, such as the current base PR plus the next one or two dependent PRs, unless the user asks for full-stack propagation.
- Do not repeatedly trigger CI for every intermediate head if another propagation batch is imminent. Push a coherent batch, then let latest-head CI run.
- After propagation, cancel stale non-head CI runs for branches whose head changed.
- Preserve reviewability: if a propagation would turn a PR into a huge diff, consider splitting or pausing to ask whether to create a new chained PR.
- Keep PR descriptions updated with current base branch/PR, whether upstream changes were merged in, and whether downstream PRs still need propagation.

Preferred batch workflow:

1. Fix and test the lowest real blocker.
2. Run focused local validation.
3. Push that PR head.
4. If the fix affects descendants, merge/rebase it into a bounded downstream batch.
5. Push downstream batch heads.
6. Cancel stale non-head CI runs.
7. Request/re-request AI reviews only after each PR has the mature, coherent latest head that reviewers should inspect.
8. Watch CI/reviews while doing non-conflicting work on the next bounded batch.

Merge only when the selected operating mode is `coordinator-merge`, repo policy permits it, and the user has authorized it. Otherwise, do not merge directly; hand off mergeable evidence to the coordinator or human reviewer.

## Post-Merge Cleanup

After an authorized merge and only when the ticket or PR is resolved, clean up
the completed local stream:

- verify no dependent work still uses the branch or worktree, no uncommitted or
  unpushed work needs preservation, and no recovery/provenance rule requires it;
- remove the issue worktree with `git worktree remove <path>`, run `git worktree
  prune`, and delete the merged local branch;
- for a GitHub-backed repository, use `gh pr merge --delete-branch` during the
  merge or delete the remote topic branch afterward when repository policy
  permits it; never delete a default, protected, shared, or reused branch; and
- never remove the primary checkout, a dirty user-owned worktree, active
  descendant snapshots, or durable scientific artifacts. Record completed and
  deferred cleanup in the final report.

## Final Response

When reporting back, provide:

- PRs made mergeable;
- PRs still blocked and the exact blocker;
- latest-head CI status;
- AI review status;
- tests/benchmarks run;
- local branches/worktrees created and their cleanup status;
- any risks that remain.

Keep it evidence-backed and do not overclaim.
