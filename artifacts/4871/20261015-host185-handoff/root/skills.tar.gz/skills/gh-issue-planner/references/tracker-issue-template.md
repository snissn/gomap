# GitHub Tracker Issue Template

Use this as a structure guide. Keep sections that matter for the requested workstream and remove sections that do not. Milestones below are examples, not a required correctness-then-performance-then-docs sequence; each feature owns its performance and documentation exit gates.

## Contents

- [Title](#title)
- [Operating mode and graph preflight](#operating-mode-and-graph-preflight)
- [Body structure](#body-structure)
- [Quality checklist](#quality-checklist)

## Title

Use an action-oriented title:

```text
Land <capability/substrate> for <product/workstream>
```

Examples:

```text
Land browser WASM KZG optimization for no-local-helper uploads
Land shared cache invalidation for API read paths
```

## Operating Mode And Graph Preflight

Before using the body structure:

1. Confirm the request passed the skill's Issue Shape Preflight. A standalone issue must not use this template.
2. Confirm whether the request is inspect/review, structure sketch, local draft, or GitHub apply.
3. For umbrella or migration work, complete the preflight in [issue-graph-planning.md](issue-graph-planning.md).
4. Do not write to GitHub unless authorized directly or as necessary maintenance within an explicitly authorized execution scope.

## Body Structure

```markdown
## Goal

State the final concrete outcome. Include what “done” means.

## Why This Exists

Explain the observed gap, current bottleneck, or product mismatch. Use hard wording when the gap is real.

## Current Evidence

List current branches, PRs, commits, profiles, benchmark artifacts, issue links, and exact measured results.

Use tables for benchmark evidence:

| Benchmark | Baseline | Candidate | Delta | Notes |
| --- | ---: | ---: | ---: | --- |

Use the metrics that fit the workstream. Examples: wall time, per-unit latency, throughput, memory footprint, allocation count, storage footprint, rebuild time, browser responsiveness, or domain-specific counters.

## Current State

Describe how the code works today. Separate implementation facts from assumptions.
Name canonical docs/sections read at the base SHA, relevant caller/dispatch/hot-path
symbols, reusable optimized primitives, and any unresolved doc/code discrepancy.
Include consequential findings from the planner's bounded existing-code
simplification audit and the reuse/consolidation/removal decision, or briefly
state that no useful simplification was found. Keep this in the owning packet.
Include related landed and ongoing designs, their owners/current heads, and the
constraints or reusable work they contribute.

## Desired State

Describe the target architecture or workflow.

## Integration Seam, Reuse, And Redesign

Record the existing-design integration review before selecting graph slices.
Name the selected seam and source identity; justify contract fit, maturity,
robustness, and performance for the intended workload against credible alternatives.
Link the relevant sources/tests/measurements and label evidence gaps explicitly.

| Candidate/source | Contract and consumers | Robustness/performance evidence or gap | Reuse or redesign required | Decision |
| --- | --- | --- | --- | --- |
| Existing seam at base SHA | Actual callers and requirements | Verified evidence or bounded uncertainty | Functions/types/representations to reuse or change | Selection and reason |

Use a brief rationale instead of a table when the choice is straightforward.
Name reused code and the resulting public call path, including selection/fallback.
Compare direct extension with seam redesign/consolidation. Record required shared
contract changes, existing consumers to migrate, paths/options to retire, and
compatibility requirements, or why the current seam already fits. Put these changes
and their regression/integration/performance evidence in the owning feature packet;
carry node-specific details into each child.

## Assumptions And Reassessment

Keep this section for abstract outcomes or material uncertainty; omit it for
direct work with an established cause and solution.

- Name provisional assumptions and evidence that would invalidate them.
- Require coordinator reassessment of the architecture and remaining graph at
  named implementation/evidence boundaries where the next work could change,
  even if child tickets pass. Do not require a review after every push or child.
- Within authorized execution, let the coordinator revise or replace the
  remaining graph, creating/adopting necessary nodes and preserving the goal,
  acceptance criteria, guardrails, ownership, useful work, and history.
- Record consequential revisions and map remaining obligations to live owners.
  Keep strategic checks here; add child-specific checks only where useful.

## Feature Path, Allocation, And Documentation Contract

For each performance-sensitive feature, name the public path and existing optimized
implementation to extend, selection/fallback proof, allocation sites and frequency,
ownership/lifetime, and the allocation budget or evidence-based exit criterion.
Require minimization before completion, including retained-memory tradeoffs.

For new behavior without a pre-change equivalent, measure enabled incremental
cost and scaling, preserve old-path regression evidence, and compare equivalent
semantics when a reference exists. Do not compare less work to more work as proof
of improvement. Carry these requirements into each owning child.

Name the docs/specs/examples and generated sources to update in that feature's PR,
or explain why none change. Separate documentation ownership requires an explicit
completion gate and predecessor edge when downstream work consumes the contract.

## Issue Graph And Gate Ownership

For umbrella work, keep a compact authoritative ledger. Omit this section for a standalone issue.

| Issue/node | Role | Depends on | Blocks | Authoritative gate | Current disposition |
| --- | --- | --- | --- | --- | --- |
| child or existing issue | substrate, experiment, integration, residual, evidence, or history | explicit blockers | explicit successors | one owned gate | create, retain, narrow, supersede, close, or defer |

State conditional edges and eligibility evidence; scientific successors also need their own owner direction/assignment and merged predecessor authority. Do not duplicate one completion gate across multiple issues.

For each active node, name its primary deliverable (`pr`, `issue-update`, `decision`,
or `artifact`), target location, acceptance evidence/owner, and whether dependencies
require accepted outputs or merged PRs. Supporting outputs belong in that packet.
Investigation nodes name the question/hypothesis, bounded inquiry, decision outcomes,
and required ticket revisions. Verify issue updates live; a negative result may
complete an inquiry while its parent product goal remains open. Detail speculative
implementation only after the decision selects it.

## North-Star Gates

For performance or scaling trackers, define the gates that must pass before the tracker can close. Do not rely on merged child PRs alone.

| Gate | Current | Target | Required evidence | If the gate fails |
| --- | ---: | ---: | --- | --- |
| Example: effective CPU during target phase | current measured value | target threshold | exact benchmark/profile/counters | keep blocker open or create linked replacement child |

Rules:

- A final gate may decide not to change a default, but the tracker goal is
  complete only when its north-star gates pass. Linked follow-ups preserve unmet
  obligations; they do not satisfy them. An explicitly accepted narrower endpoint
  must be reported separately from achieving the original goal.
- Current-only measurements are not proof of improvement.
- "No regression" is not enough for an optimization milestone unless that milestone is explicitly instrumentation-only or safety-only.

## Gate Classification And Accepted Gaps

Classify important metrics so reported values do not become accidental goals.

| Metric | Class | Current/baseline | Target or boundary | Decision source | Revisit trigger |
| --- | --- | ---: | ---: | --- | --- |
| example footprint | north-star, milestone exit, guardrail, observational, or accepted gap | current evidence | target, guardrail, or `n/a` | issue/user/decision link | format finalization, scale change, regression, or reprioritization |

Accepted gaps remain visible but do not block completion. A guardrail breach is separate from the already accepted baseline and must be handled explicitly.

## Root-Cause Classification Gate

For performance/saturation trackers, require an early evidence gate that classifies why the current path misses the north-star target before broad implementation starts.

| Candidate limiter | Evidence to collect | Action if confirmed |
| --- | --- | --- |
| insufficient work shape | ops/span, task size distribution, queue/frontier shape | coalescing/work-shaping milestone |
| weak parallel substrate | synthetic high-work saturation harness, worker busy/idle, CPU/wall | worker-kernel/task-balance milestone |
| serial fan-in | reducer/publish/append/commit stage wall and mutex/block profiles | fan-in polish milestone |
| checkpoint coordination | flushMu wait, active background wait, frontier/queue ownership | checkpoint coordinator/frontier milestone |
| external durability/I/O | backend sync/fsync/value-log sync timing with CPU idle | I/O-specific blocker or accepted external limit |
| benchmark/harness artifact | mismatched commands, stale baseline, noisy host | rerun/fix harness before implementation claims |

Do not choose an implementation lane by assumption when the evidence can distinguish these classes. The graph may branch or reorder after this classification; update child issues and edges rather than pushing a fixed stale plan.

## Scope

List what belongs in this issue.

## Non-Goals And Boundary

List what must not be implemented here.

## Execution Ordering And Blocking

Describe the intended order and what blocks later milestones. Identify conditional branches, their activation evidence, and the final evidence owner.

## Coordination

Identify relevant landed and in-flight PRs, issues, branches, owners, and modules.
Record current state/head, overlapping paths, accepted/frozen boundaries, contracts
to consume, and whether to reuse, extend, depend, sequence, or keep lanes disjoint.
For a dependency, name the readiness gate and the action if the contract changes.
Preserve existing writers and map any superseded obligations to a live owner.

## Test-First And Performance Classification

Classify every PR-bearing milestone before implementation. Do not infer that all PRs need the same benchmark matrix.

| Milestone/PR | Behavior or invariant first proved by | Test-first mode or exception | Performance class | Required performance evidence |
| --- | --- | --- | --- | --- |
| example | named failing test or contract suite | red-green-refactor, characterization, or explicit exception | not relevant, possible, sensitive, or objective | rationale, focused check, full before/after, or north-star gate |

Performance classes:

| Class | Default evidence |
| --- | --- |
| Not performance-relevant | Concise rationale; no ceremonial benchmark. |
| Possibly performance-relevant | Focused benchmark, allocation check, profile, or equivalent guardrail on the affected path. |
| Performance-sensitive | Equivalent before/after measurements for throughput/latency, allocation, memory, and path counters; use the feature contract above when no pre-change equivalent exists. |
| Performance-objective | Performance-sensitive evidence plus a declared target, repeated measurements, profile-backed attribution when needed, and explicit failure action. |

Changes to hot paths, storage or wire layouts, encoding, concurrency, I/O, caching, query execution, ingestion, compaction, or bulk processing default to at least possibly performance-relevant unless the issue records a concrete rationale otherwise.

Hard numeric thresholds require a stable harness, fixture, repetition policy, and noise tolerance. If those do not exist yet, require reproducible human-reviewed evidence and make harness stabilization an owned prerequisite; do not invent precise automation gates.

## Retained-Evidence Velocity

For expensive retained runs, define the dependency chain `product -> reviewed/landed harness or schema -> artifact-only evidence` where repository policy permits. Require pre-review of provenance, concurrency/isolation, fail-closed validation, and wording; freeze exact product/runtime and harness/schema subtree/blob identities before collection. Prefer a dedicated high-capacity runner, persistent build cache, and durable storage, or record typed `INFRASTRUCTURE_UNAVAILABLE` plus the actual fallback.

Unrelated CI flakes do not invalidate retained evidence when classified with evidence; rerun only affected gates and still require current-head merge gates. Artifact-only descendants remain valid only under explicit product/runtime, harness/schema, and implementation-blob identity; any product or harness drift invalidates affected evidence.

## Branch And PR Policy

State the repo-specific policy discovered from `AGENTS.md`, `CONTRIBUTING.md`, PR templates, or equivalent files.

- [ ] Work must happen on a topic branch unless repo policy says otherwise.
- [ ] Direct pushes to protected/default branches are prohibited unless explicitly authorized by repo policy and the user.
- [ ] PRs must be mergeable before merge: latest-head CI, focused tests, benchmark evidence when relevant, and AI/code-review findings resolved or explicitly rejected with rationale.
- [ ] Codex or other review-credit-consuming AI reviews are requested only after the PR is mature enough to avoid review-credit churn: coherent code, focused tests, required benchmark evidence or rationale, current PR body/status evidence, no known local blockers, and latest-head CI running or green.
- [ ] Human approval or maintainer approval requirement is stated when required by repo policy.
- [ ] Self-merge policy is stated when relevant.

## Required PR Body Sections

- [ ] Linked tracker issue and milestone.
- [ ] Behavior or invariant under change.
- [ ] Start-phase failing-test evidence, including the expected failure reason, or an explicit test-first exception and alternative correctness evidence.
- [ ] Performance classification and metric rationale.
- [ ] Start-phase performance plan when the class requires one.
- [ ] Selected integration seam, reused code, and shared-seam redesign/consumer migration performed or a concise no-redesign rationale.
- [ ] Optimized production-path proof, allocation audit and minimized residual costs for performance-sensitive features.
- [ ] Affected documentation updates/validation or no-change rationale.
- [ ] Close-phase test evidence.
- [ ] Close-phase benchmark/profile evidence or the not-performance-relevant rationale.
- [ ] Performance regression assessment: any material regression is blocking until optimized away or explicitly accepted with evidence.
- [ ] Markdown benchmark table with domain-appropriate before/after metrics and relevant counters when the performance class requires it.
- [ ] Measurement boundary: what is timed and what is excluded.
- [ ] AI review status and unresolved thread summary.

## Per-PR Test And Performance Workflow

Start phase:

- [ ] Recheck relevant canonical docs and trace the production path and fallback callers at the assigned base.
- [ ] Recheck the chosen seam, reuse/redesign plan, and related-work ownership/contracts against the assigned base and live state.
- [ ] Name the externally meaningful behavior, invariant, or regression being changed.
- [ ] Add or update the smallest appropriate test and run it before implementation to capture a failure for the intended reason.
- [ ] If a meaningful red test is impractical, document the allowed exception and the characterization, contract, review, or other evidence that bounds behavior.
- [ ] Classify performance relevance and select metrics that match the affected path.
- [ ] Review or augment the focused benchmark before implementation when the class requires performance evidence.
- [ ] Record baseline commands, environment, repetition policy, and artifact paths when applicable.

Implementation phase:

- [ ] Implement through the strongest suitable existing seam and reusable primitives, including the planned shared-seam redesign, cleanup, and existing caller migration.
- [ ] Audit and remove avoidable hot-path allocations/copies; preserve ownership and bounded retention.
- [ ] Update affected contracts, usage/performance guides, examples, and generated-doc sources with the change.
- [ ] Refactor while the focused and affected suites remain green.
- [ ] Fix failures without weakening assertions, changing the intended behavior, or masking the original regression.
- [ ] Keep benchmarks scoped to the PR’s actual risk.

Close phase:

When performance is primary, apply [the shared sequencing](../SKILL.md#performance-sensitive-feature-contract):
focused changed-seam checks and bounded public-path comparisons/profiles establish
a stable, viable candidate before exhaustive qualification, unless changed risk or
repo policy requires earlier coverage. Required per-PR and final gates remain.

- [ ] Re-run focused tests.
- [ ] Re-run the evidence required by the performance classification.
- [ ] For performance-sensitive or performance-objective work, apply the feature-contract comparison (identical before/after commands for equivalent behavior) and report the relevant throughput or latency, `B/op`, `allocs/op`, peak/live memory, and domain counters; mark irrelevant axes `N/A` with rationale.
- [ ] Treat material regressions as blocking: profile, optimize, rerun, and do not merge unless eliminated or explicitly accepted as minimized/correctness-required.
- [ ] Complete broader affected, race, recovery, reopen, or integration tests as the risk requires before merge.
- [ ] Verify public-path selection, allocation minimization, and affected docs before feature completion.
- [ ] Verify existing consumers and the feature use the intended shared implementation, required migrations/retirements are complete, and related ownership/contracts remain respected.
- [ ] Follow repo-required review identities and the shared skill's maturity, stop, and quota-fallback rules; repeat only when changed evidence requires review.
- [ ] When hosted review or delegation cannot run, accept a documented internal subagent review or separate same-agent mock subagent reviewer pass at the exact candidate, with actual mode/model, findings, and `ACCEPT` or `REJECT`, unless explicit repo policy requires another reviewer identity or separately independent/hosted review.

## CI Backlog Directive

- [ ] Only when authorized and permitted, cancel superseded runs of the selected PR; preserve other lanes.
- [ ] Keep latest-head CI active for relevant PR branches.
- [ ] Do not use stale green checks from older heads as mergeability proof.

## Milestones

### M0. Baseline, Inventory, And Process

Purpose: establish facts before implementation.

- [ ] Record docs/code and existing-design preflight evidence, seam comparison, code reuse, and necessary redesign decisions.
- [ ] Inventory current code paths.
- [ ] Record baseline tests.
- [ ] Record baseline benchmarks when required by the milestone performance class.
- [ ] Identify ownership boundaries.

Required tests:

- [ ] Add focused test names here and identify the expected pre-implementation failure.

Required benchmarks:

- [ ] Add focused benchmark names and metrics here, or record the not-performance-relevant rationale.

### M1. First Implementation Seam

Purpose: extend or redesign the strongest suitable existing seam for the feature
and future PRs.

- [ ] Add explicit option/status/contract.
- [ ] Reuse maintained primitives and migrate affected existing consumers to the shared contract; retire obsolete paths only after caller audit.
- [ ] Fail closed on unsupported/mismatched state.
- [ ] Preserve existing behavior outside the selected path.

Milestone exit gate:

- [ ] The intended path/counter proves the seam is actually exercised, or this milestone is explicitly contract/instrumentation-only.
- [ ] If a required performance/scaling gate did not move, the issue is marked blocked/fix-needed and a measured next-bottleneck child is opened or linked before successors can claim readiness.

Required tests:

- [ ] Selection/status test.
- [ ] Fallback/error test.
- [ ] Compatibility test.

Required benchmarks:

- [ ] Benchmark the new seam only if it can affect hot paths.

### M2. Core Correctness Implementation

Purpose: implement the main behavior through the optimized production path, with
its allocation audit/minimization and documentation complete in this milestone.

- [ ] Implement the real path through existing architecture.
- [ ] Avoid fake parallel formats or private sidecars unless explicitly scoped.
- [ ] Add direct validation and race/concurrency tests where relevant.

Required tests:

- [ ] Correctness parity test.
- [ ] Persistence/reopen test if durable state is involved.
- [ ] Mutation/staleness test if writes are involved.

Required benchmarks:

- [ ] Hot path benchmark.
- [ ] Allocation benchmark.
- [ ] Accounting counters if applicable.

### M3. Performance And Scaling Follow-Through

Purpose: optional further scaling work on a measured bottleneck beyond completed
feature exit gates. Do not defer avoidable feature allocations or path integration here.

- [ ] Profile the implementation.
- [ ] Rank bottlenecks by measured cost.
- [ ] Fix local overhead without weakening correctness.
- [ ] Defer unrelated broad tuning into follow-up tickets.

Milestone exit gate:

- [ ] The primary metric reaches the target threshold or improves by the tracker-defined minimum.
- [ ] Required counters prove the intended implementation path ran, not just a fallback/smoke path.
- [ ] An evidence reviewer has checked command identity, before/after baseline, counters, profiles, and that the PR/issue does not overclaim.
- [ ] If the gate fails, successors remain blocked until the PR is fixed or a replacement blocker is linked and accepted.

Required tests:

- [ ] Regression tests for optimized code paths.
- [ ] Race tests for shared/cache/session state.

Required benchmarks:

- [ ] Before/after benchmark table.
- [ ] CPU profile summary.
- [ ] Allocation profile summary.

### M4. Documentation, Demos, And Closeout

Purpose: reconcile cross-feature guidance, demos, and final evidence. Feature
contract and performance-guide updates belong to their implementation milestones.

- [ ] Update docs or examples.
- [ ] Add commands for users/developers.
- [ ] Add final benchmark evidence.
- [ ] List remaining caveats.

Required tests:

- [ ] Docs/example command test if applicable.

Required benchmarks:

- [ ] Final representative benchmark table.

## Benchmarks And Evidence

Define the standard benchmark matrix. Include:

- [ ] Performance classification and why it applies.
- [ ] Exact command.
- [ ] Hardware/context.
- [ ] Dataset shape.
- [ ] Repetition count, summary statistic, and noise tolerance.
- [ ] What is timed.
- [ ] What is excluded from the timer.
- [ ] Runtime or latency metrics.
- [ ] Throughput metrics where relevant.
- [ ] Allocation efficiency (`B/op`, `allocs/op`) where relevant.
- [ ] Peak RSS, peak/live heap, retained heap, or another footprint metric where memory pressure is relevant.
- [ ] Relevant domain counters.
- [ ] Profile artifact paths when profiles are collected.

An instrumentation or benchmark-harness PR is judged on correctness, repeatability, attribution boundaries, and representativeness. It does not need to make the product faster merely because it emits performance data.

Regression gate: if the candidate is materially worse in runtime, throughput, latency, memory, allocations, storage/rebuild overhead, browser responsiveness, or relevant counters, the issue/PR remains incomplete until the team profiles and optimizes the changed path. A remaining regression needs explicit coordinator/user acceptance, a clear correctness or scope rationale, and updated evidence.

Insufficient-improvement gate: if the candidate is not materially worse but also does not meet the milestone's stated improvement/saturation target, the milestone is still incomplete for optimization work. The next action must be one of: fix and rerun, explicitly re-scope the milestone as instrumentation/safety only, or open/link a blocking follow-up for the newly measured bottleneck before downstream final-gate work proceeds.

## Tests

Group tests by behavior:

- [ ] Failing-test evidence or explicit test-first exception.
- [ ] Correctness.
- [ ] Persistence/reopen.
- [ ] Fallback/status.
- [ ] Mutation/staleness.
- [ ] Concurrency/race.
- [ ] Compatibility.
- [ ] No-document-fetch or hot-loop scope if relevant.

## Completion Criteria

State evidence required before closing the tracker:

- [ ] All required milestone packets are accepted; linked follow-ups preserve any remaining obligations.
- [ ] Required tests or non-PR acceptance checks pass.
- [ ] Required benchmarks are recorded.
- [ ] No unaccepted material performance regression remains.
- [ ] Accepted gaps are recorded as non-blocking with evidence and revisit triggers; any guardrail breach is resolved or explicitly accepted.
- [ ] Current evidence proves the goal, not just a subset.
- [ ] North-star gates are satisfied; an explicitly accepted narrower endpoint is distinguished from achieving the original goal.
- [ ] PRs are mergeable under the repo policy: latest-head CI green, required tests pass, benchmark evidence is posted when relevant, and AI/code-review findings are passing, resolved, or explicitly rejected with rationale.
- [ ] Affected architecture/contracts, performance/usage guides, examples, and generated docs are current and validated; no required update is deferred to closeout.
- [ ] Every performance-sensitive feature has optimized production-path proof and an allocation audit with avoidable overhead removed and residual costs inside the agreed budget or explicitly accepted.
- [ ] The selected seam and reused code are justified; required redesign, cleanup, and existing consumer migration are complete with shared-path integration and regression evidence.

## Deferred Follow-Ups

List related work intentionally not included in this issue.
```

## Quality Checklist

Before creating or editing the issue, verify:

- [ ] The requested operating mode is explicit and no GitHub write exceeds it.
- [ ] Umbrella or migration work has a reviewed graph preflight.
- [ ] Canonical docs were studied before graph design and checked against production code.
- [ ] Existing design was reviewed deeply enough to justify the strongest suitable seam using contract, maturity, robustness, and performance evidence.
- [ ] Related landed/in-flight work, owners, overlapping paths, consumed contracts, and readiness gates are reflected in the design.
- [ ] Code reuse and seam redesign/cleanup were explicitly considered; necessary changes and existing consumer migration belong to the owning feature packet.
- [ ] The issue distinguishes current state from desired state.
- [ ] The issue distinguishes implementation work from evidence work.
- [ ] Existing issues have explicit retain, narrow, supersede, close, or defer dispositions.
- [ ] Every blocking edge is explicit and every completion gate has one authoritative owner.
- [ ] North-stars, exit gates, guardrails, observational metrics, and accepted gaps are distinguished.
- [ ] Every PR-bearing milestone names its test-first behavior/invariant or a valid explicit exception.
- [ ] Every PR-bearing milestone classifies performance relevance and requests only context-appropriate evidence.
- [ ] Each milestone has checkboxes.
- [ ] Each milestone has acceptance checks; implementation packets have relevant tests.
- [ ] Performance-sensitive milestones have benchmark requirements.
- [ ] Non-goals are explicit.
- [ ] The issue avoids fake completion paths.
- [ ] The issue is useful as a work log after creation.
