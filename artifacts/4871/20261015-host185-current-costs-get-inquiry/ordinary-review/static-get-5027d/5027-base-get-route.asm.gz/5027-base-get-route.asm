TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:350		0x6a8a40		493b6610		CMPQ SP, 0x10(R14)						
  tree.go:350		0x6a8a44		0f86c00a0000		JBE 0x6a950a							
  tree.go:350		0x6a8a4a		55			PUSHQ BP							
  tree.go:350		0x6a8a4b		4889e5			MOVQ SP, BP							
  tree.go:350		0x6a8a4e		4883ec18		SUBQ $0x18, SP							
  tree.go:350		0x6a8a52		48894c2438		MOVQ CX, 0x38(SP)						
  tree.go:350		0x6a8a57		48897c2440		MOVQ DI, 0x40(SP)						
  tree.go:351		0x6a8a5c		8400			TESTB AL, 0(AX)							
  tree.go:351		0x6a8a5e		833d8b0c470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:351		0x6a8a65		7423			JE 0x6a8a8a							
  tree.go:351		0x6a8a67		488b10			MOVQ 0(AX), DX							
  tree.go:352		0x6a8a6a		4c8b4008		MOVQ 0x8(AX), R8						
  tree.go:354		0x6a8a6e		4c8b4818		MOVQ 0x18(AX), R9						
  tree.go:351		0x6a8a72		e809b8deff		CALL runtime.gcWriteBarrier5(SB)				
  tree.go:351		0x6a8a77		498913			MOVQ DX, 0(R11)							
  tree.go:352		0x6a8a7a		49895b08		MOVQ BX, 0x8(R11)						
  tree.go:352		0x6a8a7e		4d894310		MOVQ R8, 0x10(R11)						
  tree.go:354		0x6a8a82		49897b18		MOVQ DI, 0x18(R11)						
  tree.go:354		0x6a8a86		4d894b20		MOVQ R9, 0x20(R11)						
  tree.go:355		0x6a8a8a		4889442428		MOVQ AX, 0x28(SP)						
  tree.go:355		0x6a8a8f		4889742448		MOVQ SI, 0x48(SP)						
  tree.go:355		0x6a8a94		48897c2440		MOVQ DI, 0x40(SP)						
  tree.go:355		0x6a8a99		48894c2438		MOVQ CX, 0x38(SP)						
  tree.go:351		0x6a8a9e		48c70000000000		MOVQ $0x0, 0(AX)						
  tree.go:352		0x6a8aa5		48895808		MOVQ BX, 0x8(AX)						
  tree.go:353		0x6a8aa9		48c780d800000000000000	MOVQ $0x0, 0xd8(AX)						
  tree.go:354		0x6a8ab4		48894810		MOVQ CX, 0x10(AX)						
  tree.go:354		0x6a8ab8		48897818		MOVQ DI, 0x18(AX)						
  tree.go:355		0x6a8abc		0f1f4000		NOPL 0(AX)							
  tree.go:355		0x6a8ac0		4885c9			TESTQ CX, CX							
  tree.go:355		0x6a8ac3		7417			JE 0x6a8adc							
  tree.go:355		0x6a8ac5		488b5908		MOVQ 0x8(CX), BX						
  tree.go:355		0x6a8ac9		488b1510b93502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.14(SB), DX	
  tree.go:355		0x6a8ad0		4c8b02			MOVQ 0(DX), R8							
  tree.go:355		0x6a8ad3		448b4910		MOVL 0x10(CX), R9						
  tree.go:355		0x6a8ad7		e9d9090000		JMP 0x6a94b5							
  tree.go:355		0x6a8adc		4889ca			MOVQ CX, DX							
  tree.go:355		0x6a8adf		90			NOPL								
  tree.go:355		0x6a8ae0		4885c9			TESTQ CX, CX							
  tree.go:355		0x6a8ae3		7430			JE 0x6a8b15							
  tree.go:356		0x6a8ae5		48894820		MOVQ CX, 0x20(AX)						
  tree.go:356		0x6a8ae9		833d000c470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:356		0x6a8af0		7505			JNE 0x6a8af7							
  tree.go:355		0x6a8af2		4885d2			TESTQ DX, DX							
  tree.go:356		0x6a8af5		eb18			JMP 0x6a8b0f							
  tree.go:356		0x6a8af7		488b4828		MOVQ 0x28(AX), CX						
  tree.go:356		0x6a8afb		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:356		0x6a8b00		e81bb7deff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:356		0x6a8b05		49893b			MOVQ DI, 0(R11)							
  tree.go:356		0x6a8b08		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:355		0x6a8b0c		4885d2			TESTQ DX, DX							
  tree.go:356		0x6a8b0f		48897828		MOVQ DI, 0x28(AX)						
  tree.go:356		0x6a8b13		eb2d			JMP 0x6a8b42							
  tree.go:358		0x6a8b15		48c7402000000000	MOVQ $0x0, 0x20(AX)						
  tree.go:358		0x6a8b1d		833dcc0b470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:358		0x6a8b24		7505			JNE 0x6a8b2b							
  tree.go:355		0x6a8b26		4885d2			TESTQ DX, DX							
  tree.go:358		0x6a8b29		eb0f			JMP 0x6a8b3a							
  tree.go:358		0x6a8b2b		488b4828		MOVQ 0x28(AX), CX						
  tree.go:358		0x6a8b2f		e8ccb6deff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:358		0x6a8b34		49890b			MOVQ CX, 0(R11)							
  tree.go:355		0x6a8b37		4885d2			TESTQ DX, DX							
  tree.go:358		0x6a8b3a		48c7402800000000	MOVQ $0x0, 0x28(AX)						
  tree.go:360		0x6a8b42		7417			JE 0x6a8b5b							
  tree.go:360		0x6a8b44		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:360		0x6a8b48		488b0db1b83502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.15(SB), CX	
  tree.go:360		0x6a8b4f		4c8b01			MOVQ 0(CX), R8							
  tree.go:360		0x6a8b52		448b4a10		MOVL 0x10(DX), R9						
  tree.go:360		0x6a8b56		e904090000		JMP 0x6a945f							
  tree.go:355		0x6a8b5b		4889d1			MOVQ DX, CX							
  tree.go:355		0x6a8b5e		6690			NOPW								
  tree.go:360		0x6a8b60		4885d2			TESTQ DX, DX							
  tree.go:360		0x6a8b63		7430			JE 0x6a8b95							
  tree.go:361		0x6a8b65		48895030		MOVQ DX, 0x30(AX)						
  tree.go:361		0x6a8b69		833d800b470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:361		0x6a8b70		7505			JNE 0x6a8b77							
  tree.go:355		0x6a8b72		4885c9			TESTQ CX, CX							
  tree.go:361		0x6a8b75		eb18			JMP 0x6a8b8f							
  tree.go:361		0x6a8b77		488b5038		MOVQ 0x38(AX), DX						
  tree.go:361		0x6a8b7b		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:361		0x6a8b80		e89bb6deff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:361		0x6a8b85		49893b			MOVQ DI, 0(R11)							
  tree.go:361		0x6a8b88		49895308		MOVQ DX, 0x8(R11)						
  tree.go:355		0x6a8b8c		4885c9			TESTQ CX, CX							
  tree.go:361		0x6a8b8f		48897838		MOVQ DI, 0x38(AX)						
  tree.go:361		0x6a8b93		eb2d			JMP 0x6a8bc2							
  tree.go:363		0x6a8b95		48c7403000000000	MOVQ $0x0, 0x30(AX)						
  tree.go:363		0x6a8b9d		833d4c0b470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:363		0x6a8ba4		7505			JNE 0x6a8bab							
  tree.go:355		0x6a8ba6		4885c9			TESTQ CX, CX							
  tree.go:363		0x6a8ba9		eb0f			JMP 0x6a8bba							
  tree.go:363		0x6a8bab		488b5038		MOVQ 0x38(AX), DX						
  tree.go:363		0x6a8baf		e84cb6deff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:363		0x6a8bb4		498913			MOVQ DX, 0(R11)							
  tree.go:355		0x6a8bb7		4885c9			TESTQ CX, CX							
  tree.go:363		0x6a8bba		48c7403800000000	MOVQ $0x0, 0x38(AX)						
  tree.go:365		0x6a8bc2		7417			JE 0x6a8bdb							
  tree.go:365		0x6a8bc4		488b5908		MOVQ 0x8(CX), BX						
  tree.go:365		0x6a8bc8		488b1551b83502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.16(SB), DX	
  tree.go:365		0x6a8bcf		4c8b02			MOVQ 0(DX), R8							
  tree.go:365		0x6a8bd2		448b4910		MOVL 0x10(CX), R9						
  tree.go:365		0x6a8bd6		e92f080000		JMP 0x6a940a							
  tree.go:355		0x6a8bdb		4889ca			MOVQ CX, DX							
  tree.go:355		0x6a8bde		6690			NOPW								
  tree.go:365		0x6a8be0		4885c9			TESTQ CX, CX							
  tree.go:365		0x6a8be3		7430			JE 0x6a8c15							
  tree.go:366		0x6a8be5		48894840		MOVQ CX, 0x40(AX)						
  tree.go:366		0x6a8be9		833d000b470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:366		0x6a8bf0		7505			JNE 0x6a8bf7							
  tree.go:355		0x6a8bf2		4885d2			TESTQ DX, DX							
  tree.go:366		0x6a8bf5		eb18			JMP 0x6a8c0f							
  tree.go:366		0x6a8bf7		488b4848		MOVQ 0x48(AX), CX						
  tree.go:366		0x6a8bfb		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:366		0x6a8c00		e81bb6deff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:366		0x6a8c05		49893b			MOVQ DI, 0(R11)							
  tree.go:366		0x6a8c08		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:355		0x6a8c0c		4885d2			TESTQ DX, DX							
  tree.go:366		0x6a8c0f		48897848		MOVQ DI, 0x48(AX)						
  tree.go:366		0x6a8c13		eb2d			JMP 0x6a8c42							
  tree.go:368		0x6a8c15		48c7404000000000	MOVQ $0x0, 0x40(AX)						
  tree.go:368		0x6a8c1d		833dcc0a470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:368		0x6a8c24		7505			JNE 0x6a8c2b							
  tree.go:355		0x6a8c26		4885d2			TESTQ DX, DX							
  tree.go:368		0x6a8c29		eb0f			JMP 0x6a8c3a							
  tree.go:368		0x6a8c2b		488b4848		MOVQ 0x48(AX), CX						
  tree.go:368		0x6a8c2f		e8ccb5deff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:368		0x6a8c34		49890b			MOVQ CX, 0(R11)							
  tree.go:355		0x6a8c37		4885d2			TESTQ DX, DX							
  tree.go:368		0x6a8c3a		48c7404800000000	MOVQ $0x0, 0x48(AX)						
  tree.go:370		0x6a8c42		7417			JE 0x6a8c5b							
  tree.go:370		0x6a8c44		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:370		0x6a8c48		488b0df1b73502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.17(SB), CX	
  tree.go:370		0x6a8c4f		4c8b01			MOVQ 0(CX), R8							
  tree.go:370		0x6a8c52		448b4a10		MOVL 0x10(DX), R9						
  tree.go:370		0x6a8c56		e95a070000		JMP 0x6a93b5							
  tree.go:355		0x6a8c5b		4889d1			MOVQ DX, CX							
  tree.go:355		0x6a8c5e		6690			NOPW								
  tree.go:370		0x6a8c60		4885d2			TESTQ DX, DX							
  tree.go:370		0x6a8c63		7434			JE 0x6a8c99							
  tree.go:371		0x6a8c65		48899080000000		MOVQ DX, 0x80(AX)						
  tree.go:371		0x6a8c6c		833d7d0a470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:371		0x6a8c73		7505			JNE 0x6a8c7a							
  tree.go:355		0x6a8c75		4885c9			TESTQ CX, CX							
  tree.go:371		0x6a8c78		eb16			JMP 0x6a8c90							
  tree.go:371		0x6a8c7a		488b9088000000		MOVQ 0x88(AX), DX						
  tree.go:371		0x6a8c81		e89ab5deff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:371		0x6a8c86		49893b			MOVQ DI, 0(R11)							
  tree.go:371		0x6a8c89		49895308		MOVQ DX, 0x8(R11)						
  tree.go:355		0x6a8c8d		4885c9			TESTQ CX, CX							
  tree.go:371		0x6a8c90		4889b888000000		MOVQ DI, 0x88(AX)						
  tree.go:371		0x6a8c97		eb36			JMP 0x6a8ccf							
  tree.go:373		0x6a8c99		48c7808000000000000000	MOVQ $0x0, 0x80(AX)						
  tree.go:373		0x6a8ca4		833d450a470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:373		0x6a8cab		7505			JNE 0x6a8cb2							
  tree.go:355		0x6a8cad		4885c9			TESTQ CX, CX							
  tree.go:373		0x6a8cb0		eb12			JMP 0x6a8cc4							
  tree.go:373		0x6a8cb2		488b9088000000		MOVQ 0x88(AX), DX						
  tree.go:373		0x6a8cb9		e842b5deff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:373		0x6a8cbe		498913			MOVQ DX, 0(R11)							
  tree.go:355		0x6a8cc1		4885c9			TESTQ CX, CX							
  tree.go:373		0x6a8cc4		48c7808800000000000000	MOVQ $0x0, 0x88(AX)						
  tree.go:375		0x6a8ccf		7417			JE 0x6a8ce8							
  tree.go:375		0x6a8cd1		488b5908		MOVQ 0x8(CX), BX						
  tree.go:375		0x6a8cd5		488b1584b73502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.18(SB), DX	
  tree.go:375		0x6a8cdc		4c8b02			MOVQ 0(DX), R8							
  tree.go:375		0x6a8cdf		448b4910		MOVL 0x10(CX), R9						
  tree.go:375		0x6a8ce3		e977060000		JMP 0x6a935f							
  tree.go:355		0x6a8ce8		4889ca			MOVQ CX, DX							
  tree.go:375		0x6a8ceb		4885c9			TESTQ CX, CX							
  tree.go:375		0x6a8cee		7436			JE 0x6a8d26							
  tree.go:376		0x6a8cf0		48898890000000		MOVQ CX, 0x90(AX)						
  tree.go:376		0x6a8cf7		833df209470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:376		0x6a8cfe		6690			NOPW								
  tree.go:376		0x6a8d00		7505			JNE 0x6a8d07							
  tree.go:355		0x6a8d02		4885d2			TESTQ DX, DX							
  tree.go:376		0x6a8d05		eb16			JMP 0x6a8d1d							
  tree.go:376		0x6a8d07		488b8898000000		MOVQ 0x98(AX), CX						
  tree.go:376		0x6a8d0e		e80db5deff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:376		0x6a8d13		49893b			MOVQ DI, 0(R11)							
  tree.go:376		0x6a8d16		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:355		0x6a8d1a		4885d2			TESTQ DX, DX							
  tree.go:376		0x6a8d1d		4889b898000000		MOVQ DI, 0x98(AX)						
  tree.go:376		0x6a8d24		eb36			JMP 0x6a8d5c							
  tree.go:378		0x6a8d26		48c7809000000000000000	MOVQ $0x0, 0x90(AX)						
  tree.go:378		0x6a8d31		833db809470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:378		0x6a8d38		7505			JNE 0x6a8d3f							
  tree.go:355		0x6a8d3a		4885d2			TESTQ DX, DX							
  tree.go:378		0x6a8d3d		eb12			JMP 0x6a8d51							
  tree.go:378		0x6a8d3f		488b8898000000		MOVQ 0x98(AX), CX						
  tree.go:378		0x6a8d46		e8b5b4deff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:378		0x6a8d4b		49890b			MOVQ CX, 0(R11)							
  tree.go:355		0x6a8d4e		4885d2			TESTQ DX, DX							
  tree.go:378		0x6a8d51		48c7809800000000000000	MOVQ $0x0, 0x98(AX)						
  tree.go:380		0x6a8d5c		7417			JE 0x6a8d75							
  tree.go:380		0x6a8d5e		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:380		0x6a8d62		488b0d17b73502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.19(SB), CX	
  tree.go:380		0x6a8d69		4c8b01			MOVQ 0(CX), R8							
  tree.go:380		0x6a8d6c		448b4a10		MOVL 0x10(DX), R9						
  tree.go:380		0x6a8d70		e995050000		JMP 0x6a930a							
  tree.go:355		0x6a8d75		4889d1			MOVQ DX, CX							
  tree.go:380		0x6a8d78		4885d2			TESTQ DX, DX							
  tree.go:380		0x6a8d7b		7434			JE 0x6a8db1							
  tree.go:381		0x6a8d7d		488990a0000000		MOVQ DX, 0xa0(AX)						
  tree.go:381		0x6a8d84		833d6509470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:381		0x6a8d8b		7505			JNE 0x6a8d92							
  tree.go:355		0x6a8d8d		4885c9			TESTQ CX, CX							
  tree.go:381		0x6a8d90		eb16			JMP 0x6a8da8							
  tree.go:381		0x6a8d92		488b90a8000000		MOVQ 0xa8(AX), DX						
  tree.go:381		0x6a8d99		e882b4deff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:381		0x6a8d9e		49893b			MOVQ DI, 0(R11)							
  tree.go:381		0x6a8da1		49895308		MOVQ DX, 0x8(R11)						
  tree.go:355		0x6a8da5		4885c9			TESTQ CX, CX							
  tree.go:381		0x6a8da8		4889b8a8000000		MOVQ DI, 0xa8(AX)						
  tree.go:381		0x6a8daf		eb36			JMP 0x6a8de7							
  tree.go:383		0x6a8db1		48c780a000000000000000	MOVQ $0x0, 0xa0(AX)						
  tree.go:383		0x6a8dbc		833d2d09470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:383		0x6a8dc3		7505			JNE 0x6a8dca							
  tree.go:355		0x6a8dc5		4885c9			TESTQ CX, CX							
  tree.go:383		0x6a8dc8		eb12			JMP 0x6a8ddc							
  tree.go:383		0x6a8dca		488b90a8000000		MOVQ 0xa8(AX), DX						
  tree.go:383		0x6a8dd1		e82ab4deff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:383		0x6a8dd6		498913			MOVQ DX, 0(R11)							
  tree.go:355		0x6a8dd9		4885c9			TESTQ CX, CX							
  tree.go:383		0x6a8ddc		48c780a800000000000000	MOVQ $0x0, 0xa8(AX)						
  tree.go:385		0x6a8de7		741c			JE 0x6a8e05							
  tree.go:385		0x6a8de9		488b5908		MOVQ 0x8(CX), BX						
  tree.go:385		0x6a8ded		488b15acb63502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.20(SB), DX	
  tree.go:385		0x6a8df4		4c8b02			MOVQ 0(DX), R8							
  tree.go:385		0x6a8df7		448b4910		MOVL 0x10(CX), R9						
  tree.go:385		0x6a8dfb		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:385		0x6a8e00		e9b0040000		JMP 0x6a92b5							
  tree.go:355		0x6a8e05		4889ca			MOVQ CX, DX							
  tree.go:385		0x6a8e08		4885c9			TESTQ CX, CX							
  tree.go:385		0x6a8e0b		7435			JE 0x6a8e42							
  tree.go:386		0x6a8e0d		488988b0000000		MOVQ CX, 0xb0(AX)						
  tree.go:386		0x6a8e14		833dd508470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:386		0x6a8e1b		7505			JNE 0x6a8e22							
  tree.go:355		0x6a8e1d		4885d2			TESTQ DX, DX							
  tree.go:386		0x6a8e20		eb16			JMP 0x6a8e38							
  tree.go:386		0x6a8e22		488b88b8000000		MOVQ 0xb8(AX), CX						
  tree.go:386		0x6a8e29		e8f2b3deff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:386		0x6a8e2e		49893b			MOVQ DI, 0(R11)							
  tree.go:386		0x6a8e31		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:355		0x6a8e35		4885d2			TESTQ DX, DX							
  tree.go:386		0x6a8e38		4889b8b8000000		MOVQ DI, 0xb8(AX)						
  tree.go:386		0x6a8e3f		90			NOPL								
  tree.go:386		0x6a8e40		eb36			JMP 0x6a8e78							
  tree.go:388		0x6a8e42		48c780b000000000000000	MOVQ $0x0, 0xb0(AX)						
  tree.go:388		0x6a8e4d		833d9c08470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:388		0x6a8e54		7505			JNE 0x6a8e5b							
  tree.go:355		0x6a8e56		4885d2			TESTQ DX, DX							
  tree.go:388		0x6a8e59		eb12			JMP 0x6a8e6d							
  tree.go:388		0x6a8e5b		488b88b8000000		MOVQ 0xb8(AX), CX						
  tree.go:388		0x6a8e62		e899b3deff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:388		0x6a8e67		49890b			MOVQ CX, 0(R11)							
  tree.go:355		0x6a8e6a		4885d2			TESTQ DX, DX							
  tree.go:388		0x6a8e6d		48c780b800000000000000	MOVQ $0x0, 0xb8(AX)						
  tree.go:390		0x6a8e78		7417			JE 0x6a8e91							
  tree.go:390		0x6a8e7a		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:390		0x6a8e7e		488b0d3bb63502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.21(SB), CX	
  tree.go:390		0x6a8e85		4c8b01			MOVQ 0(CX), R8							
  tree.go:390		0x6a8e88		448b4a10		MOVL 0x10(DX), R9						
  tree.go:390		0x6a8e8c		e9ce030000		JMP 0x6a925f							
  tree.go:355		0x6a8e91		4889d1			MOVQ DX, CX							
  tree.go:390		0x6a8e94		4885d2			TESTQ DX, DX							
  tree.go:390		0x6a8e97		7434			JE 0x6a8ecd							
  tree.go:391		0x6a8e99		488990c0000000		MOVQ DX, 0xc0(AX)						
  tree.go:391		0x6a8ea0		833d4908470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:391		0x6a8ea7		7505			JNE 0x6a8eae							
  tree.go:355		0x6a8ea9		4885c9			TESTQ CX, CX							
  tree.go:391		0x6a8eac		eb16			JMP 0x6a8ec4							
  tree.go:391		0x6a8eae		488b90c8000000		MOVQ 0xc8(AX), DX						
  tree.go:391		0x6a8eb5		e866b3deff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:391		0x6a8eba		49893b			MOVQ DI, 0(R11)							
  tree.go:391		0x6a8ebd		49895308		MOVQ DX, 0x8(R11)						
  tree.go:355		0x6a8ec1		4885c9			TESTQ CX, CX							
  tree.go:391		0x6a8ec4		4889b8c8000000		MOVQ DI, 0xc8(AX)						
  tree.go:391		0x6a8ecb		eb37			JMP 0x6a8f04							
  tree.go:393		0x6a8ecd		48c780c000000000000000	MOVQ $0x0, 0xc0(AX)						
  tree.go:393		0x6a8ed8		833d1108470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:393		0x6a8edf		90			NOPL								
  tree.go:393		0x6a8ee0		7505			JNE 0x6a8ee7							
  tree.go:355		0x6a8ee2		4885c9			TESTQ CX, CX							
  tree.go:393		0x6a8ee5		eb12			JMP 0x6a8ef9							
  tree.go:393		0x6a8ee7		488b90c8000000		MOVQ 0xc8(AX), DX						
  tree.go:393		0x6a8eee		e80db3deff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:393		0x6a8ef3		498913			MOVQ DX, 0(R11)							
  tree.go:355		0x6a8ef6		4885c9			TESTQ CX, CX							
  tree.go:393		0x6a8ef9		48c780c800000000000000	MOVQ $0x0, 0xc8(AX)						
  tree.go:264		0x6a8f04		7417			JE 0x6a8f1d							
  tree.go:264		0x6a8f06		488b5908		MOVQ 0x8(CX), BX						
  tree.go:264		0x6a8f0a		488b15cfb53502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.22(SB), DX	
  tree.go:264		0x6a8f11		4c8b02			MOVQ 0(DX), R8							
  tree.go:264		0x6a8f14		448b4910		MOVL 0x10(CX), R9						
  tree.go:264		0x6a8f18		e9ed020000		JMP 0x6a920a							
  tree.go:355		0x6a8f1d		4889ca			MOVQ CX, DX							
  tree.go:264		0x6a8f20		4885c9			TESTQ CX, CX							
  tree.go:264		0x6a8f23		7507			JNE 0x6a8f2c							
  tree.go:264		0x6a8f25		b901000000		MOVL $0x1, CX							
  tree.go:395		0x6a8f2a		eb1f			JMP 0x6a8f4b							
  tree.go:265		0x6a8f2c		488b4918		MOVQ 0x18(CX), CX						
  tree.go:265		0x6a8f30		4889f8			MOVQ DI, AX							
  tree.go:265		0x6a8f33		ffd1			CALL CX								
  tree.go:355		0x6a8f35		488b542438		MOVQ 0x38(SP), DX						
  tree.go:416		0x6a8f3a		488b742448		MOVQ 0x48(SP), SI						
  tree.go:397		0x6a8f3f		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:395		0x6a8f44		89c1			MOVL AX, CX							
  tree.go:412		0x6a8f46		488b442428		MOVQ 0x28(SP), AX						
  tree.go:395		0x6a8f4b		84c9			TESTL CL, CL							
  tree.go:395		0x6a8f4d		7421			JE 0x6a8f70							
  tree.go:355		0x6a8f4f		4885d2			TESTQ DX, DX							
  tree.go:396		0x6a8f52		7417			JE 0x6a8f6b							
  tree.go:396		0x6a8f54		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:396		0x6a8f58		488b0da1b53502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.23(SB), CX	
  tree.go:396		0x6a8f5f		4c8b01			MOVQ 0(CX), R8							
  tree.go:396		0x6a8f62		448b4a10		MOVL 0x10(DX), R9						
  tree.go:396		0x6a8f66		e94a020000		JMP 0x6a91b5							
  tree.go:355		0x6a8f6b		4889d1			MOVQ DX, CX							
  tree.go:396		0x6a8f6e		eb50			JMP 0x6a8fc0							
  tree.go:412		0x6a8f70		48c7405000000000	MOVQ $0x0, 0x50(AX)						
  tree.go:412		0x6a8f78		833d7107470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:412		0x6a8f7f		90			NOPL								
  tree.go:412		0x6a8f80		741c			JE 0x6a8f9e							
  tree.go:412		0x6a8f82		488b4858		MOVQ 0x58(AX), CX						
  tree.go:413		0x6a8f86		488b5068		MOVQ 0x68(AX), DX						
  tree.go:414		0x6a8f8a		488b5878		MOVQ 0x78(AX), BX						
  tree.go:412		0x6a8f8e		e8adb2deff		CALL runtime.gcWriteBarrier3(SB)				
  tree.go:412		0x6a8f93		49890b			MOVQ CX, 0(R11)							
  tree.go:413		0x6a8f96		49895308		MOVQ DX, 0x8(R11)						
  tree.go:414		0x6a8f9a		49895b10		MOVQ BX, 0x10(R11)						
  tree.go:412		0x6a8f9e		440f117858		MOVUPS X15, 0x58(AX)						
  tree.go:413		0x6a8fa3		440f117868		MOVUPS X15, 0x68(AX)						
  tree.go:414		0x6a8fa8		48c7407800000000	MOVQ $0x0, 0x78(AX)						
  tree.go:416		0x6a8fb0		4889b0d0000000		MOVQ SI, 0xd0(AX)						
  tree.go:417		0x6a8fb7		4883c418		ADDQ $0x18, SP							
  tree.go:417		0x6a8fbb		5d			POPQ BP								
  tree.go:417		0x6a8fbc		c3			RET								
  tree.go:417		0x6a8fbd		0f1f00			NOPL 0(AX)							
  tree.go:396		0x6a8fc0		4885d2			TESTQ DX, DX							
  tree.go:396		0x6a8fc3		7430			JE 0x6a8ff5							
  tree.go:397		0x6a8fc5		48895050		MOVQ DX, 0x50(AX)						
  tree.go:397		0x6a8fc9		833d2007470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:397		0x6a8fd0		7505			JNE 0x6a8fd7							
  tree.go:355		0x6a8fd2		4885c9			TESTQ CX, CX							
  tree.go:397		0x6a8fd5		eb18			JMP 0x6a8fef							
  tree.go:397		0x6a8fd7		488b5058		MOVQ 0x58(AX), DX						
  tree.go:397		0x6a8fdb		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:397		0x6a8fe0		e83bb2deff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:397		0x6a8fe5		49893b			MOVQ DI, 0(R11)							
  tree.go:397		0x6a8fe8		49895308		MOVQ DX, 0x8(R11)						
  tree.go:355		0x6a8fec		4885c9			TESTQ CX, CX							
  tree.go:397		0x6a8fef		48897858		MOVQ DI, 0x58(AX)						
  tree.go:397		0x6a8ff3		eb2d			JMP 0x6a9022							
  tree.go:399		0x6a8ff5		48c7405000000000	MOVQ $0x0, 0x50(AX)						
  tree.go:399		0x6a8ffd		833dec06470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:399		0x6a9004		7505			JNE 0x6a900b							
  tree.go:355		0x6a9006		4885c9			TESTQ CX, CX							
  tree.go:399		0x6a9009		eb0f			JMP 0x6a901a							
  tree.go:399		0x6a900b		488b5058		MOVQ 0x58(AX), DX						
  tree.go:399		0x6a900f		e8ecb1deff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:399		0x6a9014		498913			MOVQ DX, 0(R11)							
  tree.go:355		0x6a9017		4885c9			TESTQ CX, CX							
  tree.go:399		0x6a901a		48c7405800000000	MOVQ $0x0, 0x58(AX)						
  tree.go:401		0x6a9022		7417			JE 0x6a903b							
  tree.go:401		0x6a9024		488b5908		MOVQ 0x8(CX), BX						
  tree.go:401		0x6a9028		488b15f1b43502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.24(SB), DX	
  tree.go:401		0x6a902f		4c8b02			MOVQ 0(DX), R8							
  tree.go:401		0x6a9032		448b4910		MOVL 0x10(CX), R9						
  tree.go:401		0x6a9036		e920010000		JMP 0x6a915b							
  tree.go:355		0x6a903b		4889ca			MOVQ CX, DX							
  tree.go:355		0x6a903e		6690			NOPW								
  tree.go:401		0x6a9040		4885c9			TESTQ CX, CX							
  tree.go:401		0x6a9043		7430			JE 0x6a9075							
  tree.go:402		0x6a9045		48894860		MOVQ CX, 0x60(AX)						
  tree.go:402		0x6a9049		833da006470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:402		0x6a9050		7505			JNE 0x6a9057							
  tree.go:355		0x6a9052		4885d2			TESTQ DX, DX							
  tree.go:402		0x6a9055		eb18			JMP 0x6a906f							
  tree.go:402		0x6a9057		488b4868		MOVQ 0x68(AX), CX						
  tree.go:402		0x6a905b		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:402		0x6a9060		e8bbb1deff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:402		0x6a9065		49893b			MOVQ DI, 0(R11)							
  tree.go:402		0x6a9068		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:355		0x6a906c		4885d2			TESTQ DX, DX							
  tree.go:402		0x6a906f		48897868		MOVQ DI, 0x68(AX)						
  tree.go:402		0x6a9073		eb2d			JMP 0x6a90a2							
  tree.go:404		0x6a9075		48c7406000000000	MOVQ $0x0, 0x60(AX)						
  tree.go:404		0x6a907d		833d6c06470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:404		0x6a9084		7505			JNE 0x6a908b							
  tree.go:355		0x6a9086		4885d2			TESTQ DX, DX							
  tree.go:404		0x6a9089		eb0f			JMP 0x6a909a							
  tree.go:404		0x6a908b		488b4868		MOVQ 0x68(AX), CX						
  tree.go:404		0x6a908f		e86cb1deff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:404		0x6a9094		49890b			MOVQ CX, 0(R11)							
  tree.go:355		0x6a9097		4885d2			TESTQ DX, DX							
  tree.go:404		0x6a909a		48c7406800000000	MOVQ $0x0, 0x68(AX)						
  tree.go:406		0x6a90a2		7413			JE 0x6a90b7							
  tree.go:406		0x6a90a4		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:406		0x6a90a8		488b0d91b43502		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.25(SB), CX	
  tree.go:406		0x6a90af		4c8b01			MOVQ 0(CX), R8							
  tree.go:406		0x6a90b2		8b5210			MOVL 0x10(DX), DX						
  tree.go:406		0x6a90b5		eb58			JMP 0x6a910f							
  tree.go:406		0x6a90b7		4885d2			TESTQ DX, DX							
  tree.go:406		0x6a90ba		7429			JE 0x6a90e5							
  tree.go:407		0x6a90bc		48895070		MOVQ DX, 0x70(AX)						
  tree.go:407		0x6a90c0		833d2906470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:407		0x6a90c7		7410			JE 0x6a90d9							
  tree.go:407		0x6a90c9		488b4878		MOVQ 0x78(AX), CX						
  tree.go:407		0x6a90cd		e84eb1deff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:407		0x6a90d2		49893b			MOVQ DI, 0(R11)							
  tree.go:407		0x6a90d5		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:407		0x6a90d9		48897878		MOVQ DI, 0x78(AX)						
  tree.go:407		0x6a90dd		0f1f00			NOPL 0(AX)							
  tree.go:407		0x6a90e0		e9cbfeffff		JMP 0x6a8fb0							
  tree.go:409		0x6a90e5		48c7407000000000	MOVQ $0x0, 0x70(AX)						
  tree.go:409		0x6a90ed		833dfc05470200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:409		0x6a90f4		740c			JE 0x6a9102							
  tree.go:409		0x6a90f6		488b4878		MOVQ 0x78(AX), CX						
  tree.go:409		0x6a90fa		e801b1deff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:409		0x6a90ff		49890b			MOVQ CX, 0(R11)							
  tree.go:409		0x6a9102		48c7407800000000	MOVQ $0x0, 0x78(AX)						
  tree.go:409		0x6a910a		e9a1feffff		JMP 0x6a8fb0							
  tree.go:406		0x6a910f		4989d1			MOVQ DX, R9							
  tree.go:406		0x6a9112		4c21c2			ANDQ R8, DX							
  tree.go:406		0x6a9115		48c1e204		SHLQ $0x4, DX							
  tree.go:406		0x6a9119		4c8b541108		MOVQ 0x8(CX)(DX*1), R10						
  tree.go:406		0x6a911e		6690			NOPW								
  tree.go:406		0x6a9120		4939da			CMPQ R10, BX							
  tree.go:406		0x6a9123		742c			JE 0x6a9151							
  tree.go:406		0x6a9125		498d5101		LEAQ 0x1(R9), DX						
  tree.go:406		0x6a9129		4d85d2			TESTQ R10, R10							
  tree.go:406		0x6a912c		75e1			JNE 0x6a910f							
  tree.go:406		0x6a912e		488d050bb43502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.25(SB), AX	
  tree.go:406		0x6a9135		e8867dd7ff		CALL runtime.typeAssert(SB)					
  tree.go:416		0x6a913a		488b742448		MOVQ 0x48(SP), SI						
  tree.go:407		0x6a913f		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:406		0x6a9144		4889c2			MOVQ AX, DX							
  tree.go:407		0x6a9147		488b442428		MOVQ 0x28(SP), AX						
  tree.go:406		0x6a914c		e966ffffff		JMP 0x6a90b7							
  tree.go:406		0x6a9151		488b541110		MOVQ 0x10(CX)(DX*1), DX						
  tree.go:406		0x6a9156		e95cffffff		JMP 0x6a90b7							
  tree.go:401		0x6a915b		4d89ca			MOVQ R9, R10							
  tree.go:401		0x6a915e		4d21c1			ANDQ R8, R9							
  tree.go:401		0x6a9161		49c1e104		SHLQ $0x4, R9							
  tree.go:401		0x6a9165		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:401		0x6a916a		4939db			CMPQ R11, BX							
  tree.go:401		0x6a916d		7436			JE 0x6a91a5							
  tree.go:401		0x6a916f		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:401		0x6a9173		4d85db			TESTQ R11, R11							
  tree.go:401		0x6a9176		75e3			JNE 0x6a915b							
  tree.go:401		0x6a9178		488d05a1b33502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.24(SB), AX	
  tree.go:401		0x6a917f		90			NOPL								
  tree.go:401		0x6a9180		e83b7dd7ff		CALL runtime.typeAssert(SB)					
  tree.go:355		0x6a9185		488b542438		MOVQ 0x38(SP), DX						
  tree.go:416		0x6a918a		488b742448		MOVQ 0x48(SP), SI						
  tree.go:402		0x6a918f		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:401		0x6a9194		4889c1			MOVQ AX, CX							
  tree.go:402		0x6a9197		488b442428		MOVQ 0x28(SP), AX						
  tree.go:402		0x6a919c		0f1f4000		NOPL 0(AX)							
  tree.go:401		0x6a91a0		e99bfeffff		JMP 0x6a9040							
  tree.go:401		0x6a91a5		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:355		0x6a91aa		4889ca			MOVQ CX, DX							
  tree.go:401		0x6a91ad		4c89c1			MOVQ R8, CX							
  tree.go:401		0x6a91b0		e98bfeffff		JMP 0x6a9040							
  tree.go:396		0x6a91b5		4d89ca			MOVQ R9, R10							
  tree.go:396		0x6a91b8		4d21c1			ANDQ R8, R9							
  tree.go:396		0x6a91bb		49c1e104		SHLQ $0x4, R9							
  tree.go:396		0x6a91bf		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:396		0x6a91c4		4939db			CMPQ R11, BX							
  tree.go:396		0x6a91c7		7431			JE 0x6a91fa							
  tree.go:396		0x6a91c9		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:396		0x6a91cd		4d85db			TESTQ R11, R11							
  tree.go:396		0x6a91d0		75e3			JNE 0x6a91b5							
  tree.go:396		0x6a91d2		488d0527b33502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.23(SB), AX	
  tree.go:396		0x6a91d9		e8e27cd7ff		CALL runtime.typeAssert(SB)					
  tree.go:355		0x6a91de		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:416		0x6a91e3		488b742448		MOVQ 0x48(SP), SI						
  tree.go:397		0x6a91e8		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:396		0x6a91ed		4889c2			MOVQ AX, DX							
  tree.go:397		0x6a91f0		488b442428		MOVQ 0x28(SP), AX						
  tree.go:396		0x6a91f5		e9c6fdffff		JMP 0x6a8fc0							
  tree.go:396		0x6a91fa		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:355		0x6a91ff		4889d1			MOVQ DX, CX							
  tree.go:396		0x6a9202		4c89c2			MOVQ R8, DX							
  tree.go:396		0x6a9205		e9b6fdffff		JMP 0x6a8fc0							
  tree.go:264		0x6a920a		4d89ca			MOVQ R9, R10							
  tree.go:264		0x6a920d		4d21c1			ANDQ R8, R9							
  tree.go:264		0x6a9210		49c1e104		SHLQ $0x4, R9							
  tree.go:264		0x6a9214		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:264		0x6a9219		4939db			CMPQ R11, BX							
  tree.go:264		0x6a921c		7431			JE 0x6a924f							
  tree.go:264		0x6a921e		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:264		0x6a9222		4d85db			TESTQ R11, R11							
  tree.go:264		0x6a9225		75e3			JNE 0x6a920a							
  tree.go:264		0x6a9227		488d05b2b23502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.22(SB), AX	
  tree.go:264		0x6a922e		e88d7cd7ff		CALL runtime.typeAssert(SB)					
  tree.go:355		0x6a9233		488b542438		MOVQ 0x38(SP), DX						
  tree.go:416		0x6a9238		488b742448		MOVQ 0x48(SP), SI						
  tree.go:265		0x6a923d		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:264		0x6a9242		4889c1			MOVQ AX, CX							
  tree.go:412		0x6a9245		488b442428		MOVQ 0x28(SP), AX						
  tree.go:264		0x6a924a		e9d1fcffff		JMP 0x6a8f20							
  tree.go:264		0x6a924f		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:355		0x6a9254		4889ca			MOVQ CX, DX							
  tree.go:264		0x6a9257		4c89c1			MOVQ R8, CX							
  tree.go:264		0x6a925a		e9c1fcffff		JMP 0x6a8f20							
  tree.go:390		0x6a925f		4d89ca			MOVQ R9, R10							
  tree.go:390		0x6a9262		4d21c1			ANDQ R8, R9							
  tree.go:390		0x6a9265		49c1e104		SHLQ $0x4, R9							
  tree.go:390		0x6a9269		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:390		0x6a926e		4939db			CMPQ R11, BX							
  tree.go:390		0x6a9271		7432			JE 0x6a92a5							
  tree.go:390		0x6a9273		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:390		0x6a9277		4d85db			TESTQ R11, R11							
  tree.go:390		0x6a927a		75e3			JNE 0x6a925f							
  tree.go:390		0x6a927c		488d053db23502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.21(SB), AX	
  tree.go:390		0x6a9283		e8387cd7ff		CALL runtime.typeAssert(SB)					
  tree.go:355		0x6a9288		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:416		0x6a928d		488b742448		MOVQ 0x48(SP), SI						
  tree.go:391		0x6a9292		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:390		0x6a9297		4889c2			MOVQ AX, DX							
  tree.go:391		0x6a929a		488b442428		MOVQ 0x28(SP), AX						
  tree.go:391		0x6a929f		90			NOPL								
  tree.go:390		0x6a92a0		e9effbffff		JMP 0x6a8e94							
  tree.go:390		0x6a92a5		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:355		0x6a92aa		4889d1			MOVQ DX, CX							
  tree.go:390		0x6a92ad		4c89c2			MOVQ R8, DX							
  tree.go:390		0x6a92b0		e9dffbffff		JMP 0x6a8e94							
  tree.go:385		0x6a92b5		4d89ca			MOVQ R9, R10							
  tree.go:385		0x6a92b8		4d21c1			ANDQ R8, R9							
  tree.go:385		0x6a92bb		49c1e104		SHLQ $0x4, R9							
  tree.go:385		0x6a92bf		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:385		0x6a92c4		4939db			CMPQ R11, BX							
  tree.go:385		0x6a92c7		7431			JE 0x6a92fa							
  tree.go:385		0x6a92c9		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:385		0x6a92cd		4d85db			TESTQ R11, R11							
  tree.go:385		0x6a92d0		75e3			JNE 0x6a92b5							
  tree.go:385		0x6a92d2		488d05c7b13502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.20(SB), AX	
  tree.go:385		0x6a92d9		e8e27bd7ff		CALL runtime.typeAssert(SB)					
  tree.go:355		0x6a92de		488b542438		MOVQ 0x38(SP), DX						
  tree.go:416		0x6a92e3		488b742448		MOVQ 0x48(SP), SI						
  tree.go:386		0x6a92e8		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:385		0x6a92ed		4889c1			MOVQ AX, CX							
  tree.go:386		0x6a92f0		488b442428		MOVQ 0x28(SP), AX						
  tree.go:385		0x6a92f5		e90efbffff		JMP 0x6a8e08							
  tree.go:385		0x6a92fa		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:355		0x6a92ff		4889ca			MOVQ CX, DX							
  tree.go:385		0x6a9302		4c89c1			MOVQ R8, CX							
  tree.go:385		0x6a9305		e9fefaffff		JMP 0x6a8e08							
  tree.go:380		0x6a930a		4d89ca			MOVQ R9, R10							
  tree.go:380		0x6a930d		4d21c1			ANDQ R8, R9							
  tree.go:380		0x6a9310		49c1e104		SHLQ $0x4, R9							
  tree.go:380		0x6a9314		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:380		0x6a9319		4939db			CMPQ R11, BX							
  tree.go:380		0x6a931c		7431			JE 0x6a934f							
  tree.go:380		0x6a931e		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:380		0x6a9322		4d85db			TESTQ R11, R11							
  tree.go:380		0x6a9325		75e3			JNE 0x6a930a							
  tree.go:380		0x6a9327		488d0552b13502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.19(SB), AX	
  tree.go:380		0x6a932e		e88d7bd7ff		CALL runtime.typeAssert(SB)					
  tree.go:355		0x6a9333		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:416		0x6a9338		488b742448		MOVQ 0x48(SP), SI						
  tree.go:381		0x6a933d		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:380		0x6a9342		4889c2			MOVQ AX, DX							
  tree.go:381		0x6a9345		488b442428		MOVQ 0x28(SP), AX						
  tree.go:380		0x6a934a		e929faffff		JMP 0x6a8d78							
  tree.go:380		0x6a934f		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:355		0x6a9354		4889d1			MOVQ DX, CX							
  tree.go:380		0x6a9357		4c89c2			MOVQ R8, DX							
  tree.go:380		0x6a935a		e919faffff		JMP 0x6a8d78							
  tree.go:375		0x6a935f		4d89ca			MOVQ R9, R10							
  tree.go:375		0x6a9362		4d21c1			ANDQ R8, R9							
  tree.go:375		0x6a9365		49c1e104		SHLQ $0x4, R9							
  tree.go:375		0x6a9369		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:375		0x6a936e		4939db			CMPQ R11, BX							
  tree.go:375		0x6a9371		7432			JE 0x6a93a5							
  tree.go:375		0x6a9373		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:375		0x6a9377		4d85db			TESTQ R11, R11							
  tree.go:375		0x6a937a		75e3			JNE 0x6a935f							
  tree.go:375		0x6a937c		488d05ddb03502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.18(SB), AX	
  tree.go:375		0x6a9383		e8387bd7ff		CALL runtime.typeAssert(SB)					
  tree.go:355		0x6a9388		488b542438		MOVQ 0x38(SP), DX						
  tree.go:416		0x6a938d		488b742448		MOVQ 0x48(SP), SI						
  tree.go:376		0x6a9392		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:375		0x6a9397		4889c1			MOVQ AX, CX							
  tree.go:376		0x6a939a		488b442428		MOVQ 0x28(SP), AX						
  tree.go:376		0x6a939f		90			NOPL								
  tree.go:375		0x6a93a0		e946f9ffff		JMP 0x6a8ceb							
  tree.go:375		0x6a93a5		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:355		0x6a93aa		4889ca			MOVQ CX, DX							
  tree.go:375		0x6a93ad		4c89c1			MOVQ R8, CX							
  tree.go:375		0x6a93b0		e936f9ffff		JMP 0x6a8ceb							
  tree.go:370		0x6a93b5		4d89ca			MOVQ R9, R10							
  tree.go:370		0x6a93b8		4d21c1			ANDQ R8, R9							
  tree.go:370		0x6a93bb		49c1e104		SHLQ $0x4, R9							
  tree.go:370		0x6a93bf		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:370		0x6a93c4		4939db			CMPQ R11, BX							
  tree.go:370		0x6a93c7		7431			JE 0x6a93fa							
  tree.go:370		0x6a93c9		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:370		0x6a93cd		4d85db			TESTQ R11, R11							
  tree.go:370		0x6a93d0		75e3			JNE 0x6a93b5							
  tree.go:370		0x6a93d2		488d0567b03502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.17(SB), AX	
  tree.go:370		0x6a93d9		e8e27ad7ff		CALL runtime.typeAssert(SB)					
  tree.go:355		0x6a93de		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:416		0x6a93e3		488b742448		MOVQ 0x48(SP), SI						
  tree.go:371		0x6a93e8		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:370		0x6a93ed		4889c2			MOVQ AX, DX							
  tree.go:371		0x6a93f0		488b442428		MOVQ 0x28(SP), AX						
  tree.go:370		0x6a93f5		e966f8ffff		JMP 0x6a8c60							
  tree.go:370		0x6a93fa		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:355		0x6a93ff		4889d1			MOVQ DX, CX							
  tree.go:370		0x6a9402		4c89c2			MOVQ R8, DX							
  tree.go:370		0x6a9405		e956f8ffff		JMP 0x6a8c60							
  tree.go:365		0x6a940a		4d89ca			MOVQ R9, R10							
  tree.go:365		0x6a940d		4d21c1			ANDQ R8, R9							
  tree.go:365		0x6a9410		49c1e104		SHLQ $0x4, R9							
  tree.go:365		0x6a9414		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:365		0x6a9419		4939db			CMPQ R11, BX							
  tree.go:365		0x6a941c		7431			JE 0x6a944f							
  tree.go:365		0x6a941e		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:365		0x6a9422		4d85db			TESTQ R11, R11							
  tree.go:365		0x6a9425		75e3			JNE 0x6a940a							
  tree.go:365		0x6a9427		488d05f2af3502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.16(SB), AX	
  tree.go:365		0x6a942e		e88d7ad7ff		CALL runtime.typeAssert(SB)					
  tree.go:355		0x6a9433		488b542438		MOVQ 0x38(SP), DX						
  tree.go:416		0x6a9438		488b742448		MOVQ 0x48(SP), SI						
  tree.go:366		0x6a943d		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:365		0x6a9442		4889c1			MOVQ AX, CX							
  tree.go:366		0x6a9445		488b442428		MOVQ 0x28(SP), AX						
  tree.go:365		0x6a944a		e991f7ffff		JMP 0x6a8be0							
  tree.go:365		0x6a944f		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:355		0x6a9454		4889ca			MOVQ CX, DX							
  tree.go:365		0x6a9457		4c89c1			MOVQ R8, CX							
  tree.go:365		0x6a945a		e981f7ffff		JMP 0x6a8be0							
  tree.go:360		0x6a945f		4d89ca			MOVQ R9, R10							
  tree.go:360		0x6a9462		4d21c1			ANDQ R8, R9							
  tree.go:360		0x6a9465		49c1e104		SHLQ $0x4, R9							
  tree.go:360		0x6a9469		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:360		0x6a946e		4939db			CMPQ R11, BX							
  tree.go:360		0x6a9471		7432			JE 0x6a94a5							
  tree.go:360		0x6a9473		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:360		0x6a9477		4d85db			TESTQ R11, R11							
  tree.go:360		0x6a947a		75e3			JNE 0x6a945f							
  tree.go:360		0x6a947c		488d057daf3502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.15(SB), AX	
  tree.go:360		0x6a9483		e8387ad7ff		CALL runtime.typeAssert(SB)					
  tree.go:355		0x6a9488		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:416		0x6a948d		488b742448		MOVQ 0x48(SP), SI						
  tree.go:361		0x6a9492		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:360		0x6a9497		4889c2			MOVQ AX, DX							
  tree.go:361		0x6a949a		488b442428		MOVQ 0x28(SP), AX						
  tree.go:361		0x6a949f		90			NOPL								
  tree.go:360		0x6a94a0		e9bbf6ffff		JMP 0x6a8b60							
  tree.go:360		0x6a94a5		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:355		0x6a94aa		4889d1			MOVQ DX, CX							
  tree.go:360		0x6a94ad		4c89c2			MOVQ R8, DX							
  tree.go:360		0x6a94b0		e9abf6ffff		JMP 0x6a8b60							
  tree.go:355		0x6a94b5		4d89ca			MOVQ R9, R10							
  tree.go:355		0x6a94b8		4d21c1			ANDQ R8, R9							
  tree.go:355		0x6a94bb		49c1e104		SHLQ $0x4, R9							
  tree.go:355		0x6a94bf		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:355		0x6a94c4		4939db			CMPQ R11, BX							
  tree.go:355		0x6a94c7		7431			JE 0x6a94fa							
  tree.go:355		0x6a94c9		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:355		0x6a94cd		4d85db			TESTQ R11, R11							
  tree.go:355		0x6a94d0		75e3			JNE 0x6a94b5							
  tree.go:355		0x6a94d2		488d0507af3502		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.14(SB), AX	
  tree.go:355		0x6a94d9		e8e279d7ff		CALL runtime.typeAssert(SB)					
  tree.go:355		0x6a94de		488b542438		MOVQ 0x38(SP), DX						
  tree.go:416		0x6a94e3		488b742448		MOVQ 0x48(SP), SI						
  tree.go:356		0x6a94e8		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:355		0x6a94ed		4889c1			MOVQ AX, CX							
  tree.go:356		0x6a94f0		488b442428		MOVQ 0x28(SP), AX						
  tree.go:355		0x6a94f5		e9e6f5ffff		JMP 0x6a8ae0							
  tree.go:355		0x6a94fa		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:355		0x6a94ff		4889ca			MOVQ CX, DX							
  tree.go:355		0x6a9502		4c89c1			MOVQ R8, CX							
  tree.go:355		0x6a9505		e9d6f5ffff		JMP 0x6a8ae0							
  tree.go:350		0x6a950a		4889442408		MOVQ AX, 0x8(SP)						
  tree.go:350		0x6a950f		48895c2410		MOVQ BX, 0x10(SP)						
  tree.go:350		0x6a9514		48894c2418		MOVQ CX, 0x18(SP)						
  tree.go:350		0x6a9519		48897c2420		MOVQ DI, 0x20(SP)						
  tree.go:350		0x6a951e		4889742428		MOVQ SI, 0x28(SP)						
  tree.go:350		0x6a9523		e8f891deff		CALL runtime.morestack_noctxt.abi0(SB)				
  tree.go:350		0x6a9528		488b442408		MOVQ 0x8(SP), AX						
  tree.go:350		0x6a952d		488b5c2410		MOVQ 0x10(SP), BX						
  tree.go:350		0x6a9532		488b4c2418		MOVQ 0x18(SP), CX						
  tree.go:350		0x6a9537		488b7c2420		MOVQ 0x20(SP), DI						
  tree.go:350		0x6a953c		488b742428		MOVQ 0x28(SP), SI						
  tree.go:350		0x6a9541		e9faf4ffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB)	

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).getEntry(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:585		0x6aa820		4c8da424f0fbffff		LEAQ 0xfffffbf0(SP), R12								
  tree.go:585		0x6aa828		4d3b6610			CMPQ R12, 0x10(R14)									
  tree.go:585		0x6aa82c		0f86e90a0000			JBE 0x6ab31b										
  tree.go:585		0x6aa832		55				PUSHQ BP										
  tree.go:585		0x6aa833		4889e5				MOVQ SP, BP										
  tree.go:585		0x6aa836		4881ec88040000			SUBQ $0x488, SP										
  tree.go:586		0x6aa83d		4889842400050000		MOVQ AX, 0x500(SP)									
  tree.go:586		0x6aa845		4c89942438050000		MOVQ R10, 0x538(SP)									
  tree.go:586		0x6aa84d		44889c2440050000		MOVB R11, 0x540(SP)									
  tree.go:586		0x6aa855		4889bc2418050000		MOVQ DI, 0x518(SP)									
  tree.go:586		0x6aa85d		48898c2410050000		MOVQ CX, 0x510(SP)									
  tree.go:586		0x6aa865		48899c2408050000		MOVQ BX, 0x508(SP)									
  tree.go:586		0x6aa86d		4c898c2430050000		MOVQ R9, 0x530(SP)									
  tree.go:586		0x6aa875		4889b42420050000		MOVQ SI, 0x520(SP)									
  tree.go:585		0x6aa87d		488d9424b0040000		LEAQ 0x4b0(SP), DX									
  tree.go:585		0x6aa885		440f113a			MOVUPS X15, 0(DX)									
  tree.go:585		0x6aa889		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:585		0x6aa88e		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:585		0x6aa893		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:585		0x6aa898		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:586		0x6aa89d		0f1f00				NOPL 0(AX)										
  tree.go:586		0x6aa8a0		e89bc4ffff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).pointDefinitelyAbsent(SB)		
  tree.go:586		0x6aa8a5		84c0				TESTL AL, AL										
  tree.go:586		0x6aa8a7		755d				JNE 0x6aa906										
  tree.go:589		0x6aa8a9		488b842400050000		MOVQ 0x500(SP), AX									
  tree.go:589		0x6aa8b1		4c8ba0d0000000			MOVQ 0xd0(AX), R12									
  tree.go:589		0x6aa8b8		4c8dac24b0010000		LEAQ 0x1b0(SP), R13									
  tree.go:589		0x6aa8c0		450f117d00			MOVUPS X15, 0(R13)									
  tree.go:589		0x6aa8c5		450f117d10			MOVUPS X15, 0x10(R13)									
  tree.go:589		0x6aa8ca		450f117d18			MOVUPS X15, 0x18(R13)									
  tree.go:589		0x6aa8cf		4c89a424b8010000		MOVQ R12, 0x1b8(SP)									
  tree.go:591		0x6aa8d7		4c8b6008			MOVQ 0x8(AX), R12									
  tree.go:591		0x6aa8db		0f1f440000			NOPL 0(AX)(AX*1)									
  tree.go:591		0x6aa8e0		4d85e4				TESTQ R12, R12										
  tree.go:591		0x6aa8e3		7412				JE 0x6aa8f7										
  pager.go:399		0x6aa8e5		90				NOPL											
  type.go:19		0x6aa8e6		458ba42498000000		MOVL 0x98(R12), R12									
  type.go:19		0x6aa8ee		4585e4				TESTL R12, R12										
  type.go:19		0x6aa8f1		410f95c4			SETNE R12										
  tree.go:592		0x6aa8f5		eb03				JMP 0x6aa8fa										
  tree.go:592		0x6aa8f7		4531e4				XORL R12, R12										
  tree.go:595		0x6aa8fa		4488a42487010000		MOVB R12, 0x187(SP)									
  tree.go:595		0x6aa902		31c9				XORL CX, CX										
  tree.go:595		0x6aa904		eb5a				JMP 0x6aa960										
  tree.go:587		0x6aa906		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:587		0x6aa90e		440f1139			MOVUPS X15, 0(CX)									
  tree.go:587		0x6aa912		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:587		0x6aa917		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:587		0x6aa91c		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:587		0x6aa921		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:587		0x6aa926		488b05e3423502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:587		0x6aa92d		488b1de4423502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:587		0x6aa934		4881c488040000			ADDQ $0x488, SP										
  tree.go:587		0x6aa93b		5d				POPQ BP											
  tree.go:587		0x6aa93c		c3				RET											
  tree.go:595		0x6aa93d		488b8c2498010000		MOVQ 0x198(SP), CX									
  tree.go:595		0x6aa945		48ffc1				INCQ CX											
  tree.go:612		0x6aa948		488b842400050000		MOVQ 0x500(SP), AX									
  tree.go:612		0x6aa950		440fb6a42487010000		MOVZX 0x187(SP), R12									
  tree.go:612		0x6aa959		0f1f8000000000			NOPL 0(AX)										
  tree.go:595		0x6aa960		4883f932			CMPQ CX, $0x32										
  tree.go:595		0x6aa964		0f8d49090000			JGE 0x6ab2b3										
  tree.go:595		0x6aa96a		48898c2498010000		MOVQ CX, 0x198(SP)									
  tree.go:596		0x6aa972		488d9c24d8010000		LEAQ 0x1d8(SP), BX									
  tree.go:596		0x6aa97a		41bd05000000			MOVL $0x5, R13										
  tree.go:596		0x6aa980		440f113b			MOVUPS X15, 0(BX)									
  tree.go:596		0x6aa984		440f117b10			MOVUPS X15, 0x10(BX)									
  tree.go:596		0x6aa989		440f117b20			MOVUPS X15, 0x20(BX)									
  tree.go:596		0x6aa98e		440f117b30			MOVUPS X15, 0x30(BX)									
  tree.go:596		0x6aa993		4883c340			ADDQ $0x40, BX										
  tree.go:596		0x6aa997		41ffcd				DECL R13										
  tree.go:596		0x6aa99a		75e4				JNE 0x6aa980										
  tree.go:596		0x6aa99c		440f117bf8			MOVUPS X15, -0x8(BX)									
  tree.go:586		0x6aa9a1		440fb6ac2440050000		MOVZX 0x540(SP), R13									
  tree.go:586		0x6aa9aa		4584ed				TESTL R13, R13										
  tree.go:597		0x6aa9ad		0f8402020000			JE 0x6aabb5										
  tree.go:597		0x6aa9b3		80bc24b001000001		CMPB 0x1b0(SP), $0x1									
  tree.go:597		0x6aa9bb		0f1f440000			NOPL 0(AX)(AX*1)									
  tree.go:597		0x6aa9c0		0f85ef010000			JNE 0x6aabb5										
  tree.go:598		0x6aa9c6		488b942438050000		MOVQ 0x538(SP), DX									
  tree.go:598		0x6aa9ce		4885d2				TESTQ DX, DX										
  tree.go:598		0x6aa9d1		0f845d050000			JE 0x6aaf34										
  tree.go:601		0x6aa9d7		4c8b12				MOVQ 0(DX), R10										
  tree.go:601		0x6aa9da		8b8424c0010000			MOVL 0x1c0(SP), AX									
  tree.go:601		0x6aa9e1		488b9c24c8010000		MOVQ 0x1c8(SP), BX									
  tree.go:601		0x6aa9e9		8b8c24d0010000			MOVL 0x1d0(SP), CX									
  tree.go:601		0x6aa9f0		0fb7bc24d4010000		MOVZX 0x1d4(SP), DI									
  tree.go:601		0x6aa9f8		488bb42498040000		MOVQ 0x498(SP), SI									
  tree.go:601		0x6aaa00		4531c0				XORL R8, R8										
  tree.go:601		0x6aaa03		4c8b8c24a8040000		MOVQ 0x4a8(SP), R9									
  tree.go:601		0x6aaa0b		41ffd2				CALL R10										
  tree.go:602		0x6aaa0e		4885ff				TESTQ DI, DI										
  tree.go:602		0x6aaa11		0f85ee040000			JNE 0x6aaf05										
  tree.go:602		0x6aaa17		660f1f840000000000		NOPW 0(AX)(AX*1)									
  tree.go:605		0x6aaa20		4881fb00100000			CMPQ BX, $0x1000									
  tree.go:605		0x6aaa27		0f85a1040000			JNE 0x6aaece										
  tree.go:605		0x6aaa2d		4881f900100000			CMPQ CX, $0x1000									
  tree.go:605		0x6aaa34		0f8594040000			JNE 0x6aaece										
  tree.go:605		0x6aaa3a		488b9424a8040000		MOVQ 0x4a8(SP), DX									
  tree.go:605		0x6aaa42		4881fa00100000			CMPQ DX, $0x1000									
  tree.go:605		0x6aaa49		0f82bf080000			JB 0x6ab30e										
  tree.go:605		0x6aaa4f		488bb42498040000		MOVQ 0x498(SP), SI									
  tree.go:605		0x6aaa57		660f1f840000000000		NOPW 0(AX)(AX*1)									
  tree.go:605		0x6aaa60		4839f0				CMPQ AX, SI										
  tree.go:605		0x6aaa63		0f8565040000			JNE 0x6aaece										
  tree.go:601		0x6aaa69		48898c24a8010000		MOVQ CX, 0x1a8(SP)									
  tree.go:601		0x6aaa71		48899c24a0010000		MOVQ BX, 0x1a0(SP)									
  tree.go:601		0x6aaa79		4889842428030000		MOVQ AX, 0x328(SP)									
  tree.go:608		0x6aaa81		488b842400050000		MOVQ 0x500(SP), AX									
  tree.go:608		0x6aaa89		e8d2eaffff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).shouldVerifyLeafRefChecksum(SB)	
  tree.go:608		0x6aaa8e		488d8c2430030000		LEAQ 0x330(SP), CX									
  tree.go:608		0x6aaa96		ba05000000			MOVL $0x5, DX										
  tree.go:608		0x6aaa9b		440f1139			MOVUPS X15, 0(CX)									
  tree.go:608		0x6aaa9f		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:608		0x6aaaa4		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:608		0x6aaaa9		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:608		0x6aaaae		4883c140			ADDQ $0x40, CX										
  tree.go:608		0x6aaab2		ffca				DECL DX											
  tree.go:608		0x6aaab4		75e5				JNE 0x6aaa9b										
  tree.go:608		0x6aaab6		440f1179f8			MOVUPS X15, -0x8(CX)									
  tree.go:608		0x6aaabb		8bbc24c0010000			MOVL 0x1c0(SP), DI									
  tree.go:608		0x6aaac2		488bb424c8010000		MOVQ 0x1c8(SP), SI									
  tree.go:608		0x6aaaca		448b8424d0010000		MOVL 0x1d0(SP), R8									
  tree.go:608		0x6aaad2		440fb78c24d4010000		MOVZX 0x1d4(SP), R9									
  tree.go:608		0x6aaadb		488b9c24a0010000		MOVQ 0x1a0(SP), BX									
  tree.go:608		0x6aaae3		488b8c24a8010000		MOVQ 0x1a8(SP), CX									
  tree.go:608		0x6aaaeb		4189c2				MOVL AX, R10										
  tree.go:608		0x6aaaee		4531db				XORL R11, R11										
  tree.go:608		0x6aaaf1		488b842428030000		MOVQ 0x328(SP), AX									
  tree.go:608		0x6aaaf9		e8a2edffff			CALL github.com/snissn/gomap/TreeDB/tree.validateLeafLogNode(SB)			
  tree.go:608		0x6aaafe		488d8c2430030000		LEAQ 0x330(SP), CX									
  tree.go:608		0x6aab06		4889e2				MOVQ SP, DX										
  tree.go:608		0x6aab09		be05000000			MOVL $0x5, SI										
  tree.go:608		0x6aab0e		440f1032			MOVUPS 0(DX), X14									
  tree.go:608		0x6aab12		440f1131			MOVUPS X14, 0(CX)									
  tree.go:608		0x6aab16		440f107210			MOVUPS 0x10(DX), X14									
  tree.go:608		0x6aab1b		440f117110			MOVUPS X14, 0x10(CX)									
  tree.go:608		0x6aab20		440f107220			MOVUPS 0x20(DX), X14									
  tree.go:608		0x6aab25		440f117120			MOVUPS X14, 0x20(CX)									
  tree.go:608		0x6aab2a		440f107230			MOVUPS 0x30(DX), X14									
  tree.go:608		0x6aab2f		440f117130			MOVUPS X14, 0x30(CX)									
  tree.go:608		0x6aab34		4883c240			ADDQ $0x40, DX										
  tree.go:608		0x6aab38		4883c140			ADDQ $0x40, CX										
  tree.go:608		0x6aab3c		0f1f4000			NOPL 0(AX)										
  tree.go:608		0x6aab40		ffce				DECL SI											
  tree.go:608		0x6aab42		75ca				JNE 0x6aab0e										
  tree.go:608		0x6aab44		440f1072f8			MOVUPS -0x8(DX), X14									
  tree.go:608		0x6aab49		440f1171f8			MOVUPS X14, -0x8(CX)									
  tree.go:608		0x6aab4e		488d8c24d8010000		LEAQ 0x1d8(SP), CX									
  tree.go:608		0x6aab56		488d942430030000		LEAQ 0x330(SP), DX									
  tree.go:608		0x6aab5e		be05000000			MOVL $0x5, SI										
  tree.go:608		0x6aab63		440f1032			MOVUPS 0(DX), X14									
  tree.go:608		0x6aab67		440f1131			MOVUPS X14, 0(CX)									
  tree.go:608		0x6aab6b		440f107210			MOVUPS 0x10(DX), X14									
  tree.go:608		0x6aab70		440f117110			MOVUPS X14, 0x10(CX)									
  tree.go:608		0x6aab75		440f107220			MOVUPS 0x20(DX), X14									
  tree.go:608		0x6aab7a		440f117120			MOVUPS X14, 0x20(CX)									
  tree.go:608		0x6aab7f		440f107230			MOVUPS 0x30(DX), X14									
  tree.go:608		0x6aab84		440f117130			MOVUPS X14, 0x30(CX)									
  tree.go:608		0x6aab89		4883c240			ADDQ $0x40, DX										
  tree.go:608		0x6aab8d		4883c140			ADDQ $0x40, CX										
  tree.go:608		0x6aab91		ffce				DECL SI											
  tree.go:608		0x6aab93		75ce				JNE 0x6aab63										
  tree.go:608		0x6aab95		440f1072f8			MOVUPS -0x8(DX), X14									
  tree.go:608		0x6aab9a		440f1171f8			MOVUPS X14, -0x8(CX)									
  tree.go:608		0x6aab9f		90				NOPL											
  tree.go:609		0x6aaba0		4885c0				TESTQ AX, AX										
  tree.go:609		0x6aaba3		0f85fc020000			JNE 0x6aaea5										
  tree.go:586		0x6aaba9		0fb6942440050000		MOVZX 0x540(SP), DX									
  tree.go:586		0x6aabb1		84d2				TESTL DL, DL										
  tree.go:609		0x6aabb3		eb5e				JMP 0x6aac13										
  tree.go:612		0x6aabb5		0fb68c24b0010000		MOVZX 0x1b0(SP), CX									
  tree.go:612		0x6aabbd		488bbc24b8010000		MOVQ 0x1b8(SP), DI									
  tree.go:612		0x6aabc5		8bb424c0010000			MOVL 0x1c0(SP), SI									
  tree.go:612		0x6aabcc		4c8b8424c8010000		MOVQ 0x1c8(SP), R8									
  tree.go:612		0x6aabd4		448b8c24d0010000		MOVL 0x1d0(SP), R9									
  tree.go:612		0x6aabdc		440fb79424d4010000		MOVZX 0x1d4(SP), R10									
  tree.go:612		0x6aabe5		c6042400			MOVB $0x0, 0(SP)									
  tree.go:612		0x6aabe9		488d9c24d8010000		LEAQ 0x1d8(SP), BX									
  tree.go:612		0x6aabf1		4589e3				MOVL R12, R11										
  tree.go:612		0x6aabf4		e8e7f4ffff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).loadChildRefViewInto(SB)		
  tree.go:612		0x6aabf9		0f1f8000000000			NOPL 0(AX)										
  tree.go:612		0x6aac00		4885c0				TESTQ AX, AX										
  tree.go:612		0x6aac03		0f8581060000			JNE 0x6ab28a										
  tree.go:586		0x6aac09		0fb6942440050000		MOVZX 0x540(SP), DX									
  tree.go:586		0x6aac11		84d2				TESTL DL, DL										
  tree.go:615		0x6aac13		745d				JE 0x6aac72										
  tree.go:616		0x6aac15		90				NOPL											
  node.go:183		0x6aac16		488bb42430050000		MOVQ 0x530(SP), SI									
  node.go:183		0x6aac1e		6690				NOPW											
  node.go:183		0x6aac20		4885f6				TESTQ SI, SI										
  node.go:183		0x6aac23		751f				JNE 0x6aac44										
  node.go:184		0x6aac25		440f11bc2400020000		MOVUPS X15, 0x200(SP)									
  node.go:184		0x6aac2e		48c78424f801000000000000	MOVQ $0x0, 0x1f8(SP)									
  node.go:187		0x6aac3a		4c8b842420050000		MOVQ 0x520(SP), R8									
  node.go:193		0x6aac42		eb24				JMP 0x6aac68										
  node.go:187		0x6aac44		48c784240002000000000000	MOVQ $0x0, 0x200(SP)									
  node.go:187		0x6aac50		4889b42408020000		MOVQ SI, 0x208(SP)									
  node.go:187		0x6aac58		4c8b842420050000		MOVQ 0x520(SP), R8									
  node.go:187		0x6aac60		4c898424f8010000		MOVQ R8, 0x1f8(SP)									
  node.go:194		0x6aac68		c684241002000001		MOVB $0x1, 0x210(SP)									
  tree.go:619		0x6aac70		eb10				JMP 0x6aac82										
  node.go:183		0x6aac72		488bb42430050000		MOVQ 0x530(SP), SI									
  node.go:187		0x6aac7a		4c8b842420050000		MOVQ 0x520(SP), R8									
  node.go:224		0x6aac82		0fb78424f2010000		MOVZX 0x1f2(SP), AX									
  tree.go:620		0x6aac8a		6683f803			CMPW AX, $0x3										
  tree.go:620		0x6aac8e		0f85d2030000			JNE 0x6ab066										
  tree.go:621		0x6aac94		4c8b8c2498010000		MOVQ 0x198(SP), R9									
  tree.go:621		0x6aac9c		0f1f4000			NOPL 0(AX)										
  tree.go:621		0x6aaca0		4d85c9				TESTQ R9, R9										
  tree.go:621		0x6aaca3		0f85cf000000			JNE 0x6aad78										
  tree.go:622		0x6aaca9		488d8424d8010000		LEAQ 0x1d8(SP), AX									
  tree.go:622		0x6aacb1		e88af1f3ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).InternalFenceBounds(SB)		
  tree.go:622		0x6aacb6		4d85d2				TESTQ R10, R10										
  tree.go:622		0x6aacb9		0f8578030000			JNE 0x6ab037										
  tree.go:622		0x6aacbf		90				NOPL											
  tree.go:622		0x6aacc0		4584c9				TESTL R9, R9										
  tree.go:624		0x6aacc3		0f848f000000			JE 0x6aad58										
  tree.go:625		0x6aacc9		4885db				TESTQ BX, BX										
  tree.go:625		0x6aaccc		745f				JE 0x6aad2d										
  tree.go:622		0x6aacce		4889b42488010000		MOVQ SI, 0x188(SP)									
  tree.go:622		0x6aacd6		4c89842490010000		MOVQ R8, 0x190(SP)									
  tree.go:622		0x6aacde		4889bc2420030000		MOVQ DI, 0x320(SP)									
  tree.go:625		0x6aace6		4889c7				MOVQ AX, DI										
  tree.go:625		0x6aace9		4889de				MOVQ BX, SI										
  tree.go:625		0x6aacec		4989c8				MOVQ CX, R8										
  tree.go:625		0x6aacef		488b842408050000		MOVQ 0x508(SP), AX									
  tree.go:625		0x6aacf7		488b9c2410050000		MOVQ 0x510(SP), BX									
  tree.go:625		0x6aacff		488b8c2418050000		MOVQ 0x518(SP), CX									
  tree.go:625		0x6aad07		e8b4d3ffff			CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)				
  tree.go:625		0x6aad0c		4885c0				TESTQ AX, AX										
  tree.go:625		0x6aad0f		0f8c8d020000			JL 0x6aafa2										
  tree.go:628		0x6aad15		488bb42488010000		MOVQ 0x188(SP), SI									
  tree.go:628		0x6aad1d		488bbc2420030000		MOVQ 0x320(SP), DI									
  tree.go:628		0x6aad25		4c8b842490010000		MOVQ 0x190(SP), R8									
  tree.go:628		0x6aad2d		4885f6				TESTQ SI, SI										
  tree.go:628		0x6aad30		7426				JE 0x6aad58										
  tree.go:628		0x6aad32		488b842408050000		MOVQ 0x508(SP), AX									
  tree.go:628		0x6aad3a		488b9c2410050000		MOVQ 0x510(SP), BX									
  tree.go:628		0x6aad42		488b8c2418050000		MOVQ 0x518(SP), CX									
  tree.go:628		0x6aad4a		e871d3ffff			CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)				
  tree.go:628		0x6aad4f		4885c0				TESTQ AX, AX										
  tree.go:628		0x6aad52		0f8d13020000			JGE 0x6aaf6b										
  tree.go:586		0x6aad58		0fb6942440050000		MOVZX 0x540(SP), DX									
  node.go:183		0x6aad60		488bb42430050000		MOVQ 0x530(SP), SI									
  node.go:187		0x6aad68		4c8b842420050000		MOVQ 0x520(SP), R8									
  tree.go:595		0x6aad70		4c8b8c2498010000		MOVQ 0x198(SP), R9									
  node.go:309		0x6aad78		90				NOPL											
  node.go:302		0x6aad79		6683bc24f201000003		CMPW 0x1f2(SP), $0x3									
  node.go:302		0x6aad82		753b				JNE 0x6aadbf										
  node.go:236		0x6aad84		4c8b9424e0010000		MOVQ 0x1e0(SP), R10									
  node.go:56		0x6aad8c		4983fa0c			CMPQ R10, $0xc										
  node.go:56		0x6aad90		0f8673050000			JBE 0x6ab309										
  node.go:56		0x6aad96		660f1f840000000000		NOPW 0(AX)(AX*1)									
  node.go:56		0x6aad9f		90				NOPL											
  node.go:56		0x6aada0		4983fa0d			CMPQ R10, $0xd										
  node.go:56		0x6aada4		0f865a050000			JBE 0x6ab304										
  node.go:236		0x6aadaa		4c8b9424d8010000		MOVQ 0x1d8(SP), R10									
  node.go:56		0x6aadb2		450fb7520c			MOVZX 0xc(R10), R10									
  node.go:305		0x6aadb7		6641f7c28000			TESTW $0x80, R10									
  tree.go:633		0x6aadbd		7555				JNE 0x6aae14										
  tree.go:640		0x6aadbf		488d8424d8010000		LEAQ 0x1d8(SP), AX									
  tree.go:640		0x6aadc7		488b9c2408050000		MOVQ 0x508(SP), BX									
  tree.go:640		0x6aadcf		488b8c2410050000		MOVQ 0x510(SP), CX									
  tree.go:640		0x6aadd7		488bbc2418050000		MOVQ 0x518(SP), DI									
  tree.go:640		0x6aaddf		90				NOPL											
  tree.go:640		0x6aade0		e85bfcf3ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID(SB)		
  tree.go:641		0x6aade5		4885c9				TESTQ CX, CX										
  tree.go:641		0x6aade8		0f85eb010000			JNE 0x6aafd9										
  tree.go:644		0x6aadee		4c8da424b0010000		LEAQ 0x1b0(SP), R12									
  tree.go:644		0x6aadf6		450f113c24			MOVUPS X15, 0(R12)									
  tree.go:644		0x6aadfb		450f117c2410			MOVUPS X15, 0x10(R12)									
  tree.go:644		0x6aae01		450f117c2418			MOVUPS X15, 0x18(R12)									
  tree.go:644		0x6aae07		48898424b8010000		MOVQ AX, 0x1b8(SP)									
  tree.go:644		0x6aae0f		e929fbffff			JMP 0x6aa93d										
  tree.go:634		0x6aae14		488d8424d8010000		LEAQ 0x1d8(SP), AX									
  tree.go:634		0x6aae1c		488b9c2408050000		MOVQ 0x508(SP), BX									
  tree.go:634		0x6aae24		488b8c2410050000		MOVQ 0x510(SP), CX									
  tree.go:634		0x6aae2c		488bbc2418050000		MOVQ 0x518(SP), DI									
  tree.go:634		0x6aae34		e8272af4ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildRef(SB)		
  tree.go:634		0x6aae39		88842430030000			MOVB AL, 0x330(SP)									
  tree.go:634		0x6aae40		48899c2438030000		MOVQ BX, 0x338(SP)									
  tree.go:634		0x6aae48		898c2440030000			MOVL CX, 0x340(SP)									
  tree.go:634		0x6aae4f		4889bc2448030000		MOVQ DI, 0x348(SP)									
  tree.go:634		0x6aae57		89b42450030000			MOVL SI, 0x350(SP)									
  tree.go:634		0x6aae5e		664489842454030000		MOVW R8, 0x354(SP)									
  tree.go:635		0x6aae67		4d85d2				TESTQ R10, R10										
  tree.go:635		0x6aae6a		0f8598010000			JNE 0x6ab008										
  tree.go:638		0x6aae70		4c8da424b0010000		LEAQ 0x1b0(SP), R12									
  tree.go:638		0x6aae78		4c8dac2430030000		LEAQ 0x330(SP), R13									
  tree.go:638		0x6aae80		450f107500			MOVUPS 0(R13), X14									
  tree.go:638		0x6aae85		450f113424			MOVUPS X14, 0(R12)									
  tree.go:638		0x6aae8a		450f107510			MOVUPS 0x10(R13), X14									
  tree.go:638		0x6aae8f		450f11742410			MOVUPS X14, 0x10(R12)									
  tree.go:638		0x6aae95		450f107518			MOVUPS 0x18(R13), X14									
  tree.go:638		0x6aae9a		450f11742418			MOVUPS X14, 0x18(R12)									
  tree.go:638		0x6aaea0		e998faffff			JMP 0x6aa93d										
  tree.go:610		0x6aaea5		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:610		0x6aaead		440f1139			MOVUPS X15, 0(CX)									
  tree.go:610		0x6aaeb1		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:610		0x6aaeb6		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:610		0x6aaebb		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:610		0x6aaec0		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:610		0x6aaec5		4881c488040000			ADDQ $0x488, SP										
  tree.go:610		0x6aaecc		5d				POPQ BP											
  tree.go:610		0x6aaecd		c3				RET											
  tree.go:606		0x6aaece		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:606		0x6aaed6		440f1139			MOVUPS X15, 0(CX)									
  tree.go:606		0x6aaeda		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:606		0x6aaedf		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:606		0x6aaee4		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:606		0x6aaee9		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:606		0x6aaeee		488b050b3d3502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrOwnedIteratorLeafReader(SB), AX		
  tree.go:606		0x6aaef5		488b1d0c3d3502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrOwnedIteratorLeafReader+8(SB), BX		
  tree.go:606		0x6aaefc		4881c488040000			ADDQ $0x488, SP										
  tree.go:606		0x6aaf03		5d				POPQ BP											
  tree.go:606		0x6aaf04		c3				RET											
  tree.go:603		0x6aaf05		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:603		0x6aaf0d		440f1139			MOVUPS X15, 0(CX)									
  tree.go:603		0x6aaf11		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:603		0x6aaf16		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:603		0x6aaf1b		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:603		0x6aaf20		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:603		0x6aaf25		4889f8				MOVQ DI, AX										
  tree.go:603		0x6aaf28		4889f3				MOVQ SI, BX										
  tree.go:603		0x6aaf2b		4881c488040000			ADDQ $0x488, SP										
  tree.go:603		0x6aaf32		5d				POPQ BP											
  tree.go:603		0x6aaf33		c3				RET											
  tree.go:599		0x6aaf34		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:599		0x6aaf3c		440f1139			MOVUPS X15, 0(CX)									
  tree.go:599		0x6aaf40		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:599		0x6aaf45		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:599		0x6aaf4a		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:599		0x6aaf4f		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:599		0x6aaf54		488b05a53c3502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrOwnedIteratorLeafReader(SB), AX		
  tree.go:599		0x6aaf5b		488b1da63c3502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrOwnedIteratorLeafReader+8(SB), BX		
  tree.go:599		0x6aaf62		4881c488040000			ADDQ $0x488, SP										
  tree.go:599		0x6aaf69		5d				POPQ BP											
  tree.go:599		0x6aaf6a		c3				RET											
  tree.go:629		0x6aaf6b		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:629		0x6aaf73		440f1139			MOVUPS X15, 0(CX)									
  tree.go:629		0x6aaf77		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:629		0x6aaf7c		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:629		0x6aaf81		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:629		0x6aaf86		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:629		0x6aaf8b		488b057e3c3502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:629		0x6aaf92		488b1d7f3c3502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:629		0x6aaf99		4881c488040000			ADDQ $0x488, SP										
  tree.go:629		0x6aafa0		5d				POPQ BP											
  tree.go:629		0x6aafa1		c3				RET											
  tree.go:626		0x6aafa2		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:626		0x6aafaa		440f1139			MOVUPS X15, 0(CX)									
  tree.go:626		0x6aafae		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:626		0x6aafb3		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:626		0x6aafb8		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:626		0x6aafbd		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:626		0x6aafc2		488b05473c3502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:626		0x6aafc9		488b1d483c3502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:626		0x6aafd0		4881c488040000			ADDQ $0x488, SP										
  tree.go:626		0x6aafd7		5d				POPQ BP											
  tree.go:626		0x6aafd8		c3				RET											
  tree.go:642		0x6aafd9		488d9424b0040000		LEAQ 0x4b0(SP), DX									
  tree.go:642		0x6aafe1		440f113a			MOVUPS X15, 0(DX)									
  tree.go:642		0x6aafe5		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:642		0x6aafea		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:642		0x6aafef		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:642		0x6aaff4		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:642		0x6aaff9		4889c8				MOVQ CX, AX										
  tree.go:642		0x6aaffc		4889fb				MOVQ DI, BX										
  tree.go:642		0x6aafff		4881c488040000			ADDQ $0x488, SP										
  tree.go:642		0x6ab006		5d				POPQ BP											
  tree.go:642		0x6ab007		c3				RET											
  tree.go:636		0x6ab008		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:636		0x6ab010		440f1139			MOVUPS X15, 0(CX)									
  tree.go:636		0x6ab014		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:636		0x6ab019		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:636		0x6ab01e		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:636		0x6ab023		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:636		0x6ab028		4c89d0				MOVQ R10, AX										
  tree.go:636		0x6ab02b		4c89db				MOVQ R11, BX										
  tree.go:636		0x6ab02e		4881c488040000			ADDQ $0x488, SP										
  tree.go:636		0x6ab035		5d				POPQ BP											
  tree.go:636		0x6ab036		c3				RET											
  tree.go:623		0x6ab037		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:623		0x6ab03f		440f1139			MOVUPS X15, 0(CX)									
  tree.go:623		0x6ab043		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:623		0x6ab048		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:623		0x6ab04d		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:623		0x6ab052		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:623		0x6ab057		4c89d0				MOVQ R10, AX										
  tree.go:623		0x6ab05a		4c89db				MOVQ R11, BX										
  tree.go:623		0x6ab05d		4881c488040000			ADDQ $0x488, SP										
  tree.go:623		0x6ab064		5d				POPQ BP											
  tree.go:623		0x6ab065		c3				RET											
  tree.go:647		0x6ab066		6683f804			CMPW AX, $0x4										
  tree.go:647		0x6ab06a		0f857a010000			JNE 0x6ab1ea										
  tree.go:648		0x6ab070		488d8424d8010000		LEAQ 0x1d8(SP), AX									
  tree.go:648		0x6ab078		488b9c2408050000		MOVQ 0x508(SP), BX									
  tree.go:648		0x6ab080		488b8c2410050000		MOVQ 0x510(SP), CX									
  tree.go:648		0x6ab088		488bbc2418050000		MOVQ 0x518(SP), DI									
  tree.go:648		0x6ab090		e88b5ef4ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchLeaf(SB)				
  tree.go:649		0x6ab095		4885c9				TESTQ CX, CX										
  tree.go:649		0x6ab098		0f851d010000			JNE 0x6ab1bb										
  tree.go:649		0x6ab09e		6690				NOPW											
  tree.go:648		0x6ab0a0		84db				TESTL BL, BL										
  tree.go:652		0x6ab0a2		0f84dc000000			JE 0x6ab184										
  tree.go:657		0x6ab0a8		89c3				MOVL AX, BX										
  tree.go:657		0x6ab0aa		488d8424d8010000		LEAQ 0x1d8(SP), AX									
  tree.go:657		0x6ab0b2		e84947f4ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafEntryViewWithRevision(SB)	
  tree.go:657		0x6ab0b7		488b542410			MOVQ 0x10(SP), DX									
  tree.go:657		0x6ab0bc		0f1f4000			NOPL 0(AX)										
  tree.go:658		0x6ab0c0		4885d2				TESTQ DX, DX										
  tree.go:658		0x6ab0c3		7431				JE 0x6ab0f6										
  tree.go:657		0x6ab0c5		488b5c2418			MOVQ 0x18(SP), BX									
  tree.go:659		0x6ab0ca		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:659		0x6ab0d2		440f1139			MOVUPS X15, 0(CX)									
  tree.go:659		0x6ab0d6		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:659		0x6ab0db		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:659		0x6ab0e0		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:659		0x6ab0e5		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:659		0x6ab0ea		4889d0				MOVQ DX, AX										
  tree.go:659		0x6ab0ed		4881c488040000			ADDQ $0x488, SP										
  tree.go:659		0x6ab0f4		5d				POPQ BP											
  tree.go:659		0x6ab0f5		c3				RET											
  tree.go:657		0x6ab0f6		0fb61424			MOVZX 0(SP), DX										
  tree.go:657		0x6ab0fa		4c8b642408			MOVQ 0x8(SP), R12									
  tree.go:667		0x6ab0ff		4c8dac24b0040000		LEAQ 0x4b0(SP), R13									
  tree.go:667		0x6ab107		450f117d00			MOVUPS X15, 0(R13)									
  tree.go:667		0x6ab10c		450f117d10			MOVUPS X15, 0x10(R13)									
  tree.go:667		0x6ab111		450f117d20			MOVUPS X15, 0x20(R13)									
  tree.go:667		0x6ab116		450f117d30			MOVUPS X15, 0x30(R13)									
  tree.go:667		0x6ab11b		450f117d40			MOVUPS X15, 0x40(R13)									
  tree.go:663		0x6ab120		48898424b0040000		MOVQ AX, 0x4b0(SP)									
  tree.go:663		0x6ab128		48899c24b8040000		MOVQ BX, 0x4b8(SP)									
  tree.go:663		0x6ab130		48898c24c0040000		MOVQ CX, 0x4c0(SP)									
  tree.go:664		0x6ab138		4889bc24c8040000		MOVQ DI, 0x4c8(SP)									
  tree.go:664		0x6ab140		4889b424d0040000		MOVQ SI, 0x4d0(SP)									
  tree.go:664		0x6ab148		4c898424d8040000		MOVQ R8, 0x4d8(SP)									
  tree.go:665		0x6ab150		4c898c24e0040000		MOVQ R9, 0x4e0(SP)									
  tree.go:665		0x6ab158		44899424e8040000		MOVL R10, 0x4e8(SP)									
  tree.go:665		0x6ab160		44899c24ec040000		MOVL R11, 0x4ec(SP)									
  tree.go:666		0x6ab168		889424f0040000			MOVB DL, 0x4f0(SP)									
  tree.go:667		0x6ab16f		4c89a424f8040000		MOVQ R12, 0x4f8(SP)									
  tree.go:662		0x6ab177		31c0				XORL AX, AX										
  tree.go:662		0x6ab179		31db				XORL BX, BX										
  tree.go:668		0x6ab17b		4881c488040000			ADDQ $0x488, SP										
  tree.go:668		0x6ab182		5d				POPQ BP											
  tree.go:668		0x6ab183		c3				RET											
  tree.go:653		0x6ab184		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:653		0x6ab18c		440f1139			MOVUPS X15, 0(CX)									
  tree.go:653		0x6ab190		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:653		0x6ab195		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:653		0x6ab19a		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:653		0x6ab19f		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:653		0x6ab1a4		488b05653a3502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:653		0x6ab1ab		488b1d663a3502			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:653		0x6ab1b2		4881c488040000			ADDQ $0x488, SP										
  tree.go:653		0x6ab1b9		5d				POPQ BP											
  tree.go:653		0x6ab1ba		c3				RET											
  tree.go:650		0x6ab1bb		488d9424b0040000		LEAQ 0x4b0(SP), DX									
  tree.go:650		0x6ab1c3		440f113a			MOVUPS X15, 0(DX)									
  tree.go:650		0x6ab1c7		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:650		0x6ab1cc		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:650		0x6ab1d1		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:650		0x6ab1d6		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:650		0x6ab1db		4889c8				MOVQ CX, AX										
  tree.go:650		0x6ab1de		4889fb				MOVQ DI, BX										
  tree.go:650		0x6ab1e1		4881c488040000			ADDQ $0x488, SP										
  tree.go:650		0x6ab1e8		5d				POPQ BP											
  tree.go:650		0x6ab1e9		c3				RET											
  tree.go:671		0x6ab1ea		440f11bc2478040000		MOVUPS X15, 0x478(SP)									
  tree.go:671		0x6ab1f3		e8085bd7ff			CALL runtime.convT16(SB)								
  tree.go:671		0x6ab1f8		488d0d01b42701			LEAQ 0x127b401(IP), CX									
  tree.go:671		0x6ab1ff		48898c2478040000		MOVQ CX, 0x478(SP)									
  tree.go:671		0x6ab207		4889842480040000		MOVQ AX, 0x480(SP)									
  errors.go:26		0x6ab20f		488d0504484701			LEAQ 0x1474804(IP), AX									
  errors.go:26		0x6ab216		bb14000000			MOVL $0x14, BX										
  errors.go:26		0x6ab21b		488d8c2478040000		LEAQ 0x478(SP), CX									
  errors.go:26		0x6ab223		bf01000000			MOVL $0x1, DI										
  errors.go:26		0x6ab228		4889fe				MOVQ DI, SI										
  errors.go:26		0x6ab22b		e8d076e5ff			CALL fmt.errorf(SB)									
  errors.go:26		0x6ab230		4885c0				TESTQ AX, AX										
  errors.go:26		0x6ab233		752c				JNE 0x6ab261										
  errors.go:31		0x6ab235		90				NOPL											
  errors.go:65		0x6ab236		488d05e3bf2f01			LEAQ 0x12fbfe3(IP), AX									
  errors.go:65		0x6ab23d		0f1f00				NOPL 0(AX)										
  errors.go:65		0x6ab240		e85b98d7ff			CALL runtime.newobject(SB)								
  errors.go:65		0x6ab245		48c7400814000000		MOVQ $0x14, 0x8(AX)									
  errors.go:65		0x6ab24d		488d0dc6474701			LEAQ 0x14747c6(IP), CX									
  errors.go:65		0x6ab254		488908				MOVQ CX, 0(AX)										
  tree.go:671		0x6ab257		4889c3				MOVQ AX, BX										
  tree.go:671		0x6ab25a		488d057f305a01			LEAQ go:itab.*errors.errorString,error(SB), AX						
  tree.go:671		0x6ab261		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:671		0x6ab269		440f1139			MOVUPS X15, 0(CX)									
  tree.go:671		0x6ab26d		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:671		0x6ab272		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:671		0x6ab277		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:671		0x6ab27c		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:671		0x6ab281		4881c488040000			ADDQ $0x488, SP										
  tree.go:671		0x6ab288		5d				POPQ BP											
  tree.go:671		0x6ab289		c3				RET											
  tree.go:613		0x6ab28a		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:613		0x6ab292		440f1139			MOVUPS X15, 0(CX)									
  tree.go:613		0x6ab296		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:613		0x6ab29b		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:613		0x6ab2a0		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:613		0x6ab2a5		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:613		0x6ab2aa		4881c488040000			ADDQ $0x488, SP										
  tree.go:613		0x6ab2b1		5d				POPQ BP											
  tree.go:613		0x6ab2b2		c3				RET											
  errors.go:65		0x6ab2b3		488d0566bf2f01			LEAQ 0x12fbf66(IP), AX									
  errors.go:65		0x6ab2ba		e8e197d7ff			CALL runtime.newobject(SB)								
  errors.go:65		0x6ab2bf		48c740080d000000		MOVQ $0xd, 0x8(AX)									
  errors.go:65		0x6ab2c7		488d0db5714601			LEAQ 0x14671b5(IP), CX									
  errors.go:65		0x6ab2ce		488908				MOVQ CX, 0(AX)										
  tree.go:674		0x6ab2d1		488d8c24b0040000		LEAQ 0x4b0(SP), CX									
  tree.go:674		0x6ab2d9		440f1139			MOVUPS X15, 0(CX)									
  tree.go:674		0x6ab2dd		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:674		0x6ab2e2		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:674		0x6ab2e7		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:674		0x6ab2ec		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:674		0x6ab2f1		4889c3				MOVQ AX, BX										
  tree.go:674		0x6ab2f4		488d05e52f5a01			LEAQ go:itab.*errors.errorString,error(SB), AX						
  tree.go:674		0x6ab2fb		4881c488040000			ADDQ $0x488, SP										
  tree.go:674		0x6ab302		5d				POPQ BP											
  tree.go:674		0x6ab303		c3				RET											
  node.go:56		0x6ab304		e8b792deff			CALL runtime.panicBounds(SB)								
  node.go:56		0x6ab309		e8b292deff			CALL runtime.panicBounds(SB)								
  tree.go:605		0x6ab30e		48c7c000100000			MOVQ $0x1000, AX									
  tree.go:605		0x6ab315		e8a692deff			CALL runtime.panicBounds(SB)								
  tree.go:605		0x6ab31a		90				NOPL											
  tree.go:585		0x6ab31b		4889442470			MOVQ AX, 0x70(SP)									
  tree.go:585		0x6ab320		48895c2478			MOVQ BX, 0x78(SP)									
  tree.go:585		0x6ab325		48898c2480000000		MOVQ CX, 0x80(SP)									
  tree.go:585		0x6ab32d		4889bc2488000000		MOVQ DI, 0x88(SP)									
  tree.go:585		0x6ab335		4889b42490000000		MOVQ SI, 0x90(SP)									
  tree.go:585		0x6ab33d		4c89842498000000		MOVQ R8, 0x98(SP)									
  tree.go:585		0x6ab345		4c898c24a0000000		MOVQ R9, 0xa0(SP)									
  tree.go:585		0x6ab34d		4c899424a8000000		MOVQ R10, 0xa8(SP)									
  tree.go:585		0x6ab355		44889c24b0000000		MOVB R11, 0xb0(SP)									
  tree.go:585		0x6ab35d		0f1f00				NOPL 0(AX)										
  tree.go:585		0x6ab360		e8bb73deff			CALL runtime.morestack_noctxt.abi0(SB)							
  tree.go:585		0x6ab365		488b442470			MOVQ 0x70(SP), AX									
  tree.go:585		0x6ab36a		488b5c2478			MOVQ 0x78(SP), BX									
  tree.go:585		0x6ab36f		488b8c2480000000		MOVQ 0x80(SP), CX									
  tree.go:585		0x6ab377		488bbc2488000000		MOVQ 0x88(SP), DI									
  tree.go:585		0x6ab37f		488bb42490000000		MOVQ 0x90(SP), SI									
  tree.go:585		0x6ab387		4c8b842498000000		MOVQ 0x98(SP), R8									
  tree.go:585		0x6ab38f		4c8b8c24a0000000		MOVQ 0xa0(SP), R9									
  tree.go:585		0x6ab397		4c8b9424a8000000		MOVQ 0xa8(SP), R10									
  tree.go:585		0x6ab39f		440fb69c24b0000000		MOVZX 0xb0(SP), R11									
  tree.go:585		0x6ab3a8		e973f4ffff			JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).getEntry(SB)				

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1033		0x6ad780		493b6610		CMPQ SP, 0x10(R14)								
  tree.go:1033		0x6ad784		0f86af020000		JBE 0x6ada39									
  tree.go:1033		0x6ad78a		55			PUSHQ BP									
  tree.go:1033		0x6ad78b		4889e5			MOVQ SP, BP									
  tree.go:1033		0x6ad78e		4883ec78		SUBQ $0x78, SP									
  tree.go:1035		0x6ad792		4889842488000000	MOVQ AX, 0x88(SP)								
  tree.go:1035		0x6ad79a		4c898c24b8000000	MOVQ R9, 0xb8(SP)								
  tree.go:1035		0x6ad7a2		4889b424a8000000	MOVQ SI, 0xa8(SP)								
  tree.go:1035		0x6ad7aa		48899c2490000000	MOVQ BX, 0x90(SP)								
  tree.go:1035		0x6ad7b2		4c898424b0000000	MOVQ R8, 0xb0(SP)								
  tree.go:1035		0x6ad7ba		4889bc24a0000000	MOVQ DI, 0xa0(SP)								
  tree.go:1035		0x6ad7c2		48898c2498000000	MOVQ CX, 0x98(SP)								
  tree.go:1034		0x6ad7ca		41ba01000000		MOVL $0x1, R10									
  tree.go:1034		0x6ad7d0		e8ebdbffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView(SB)	
  tree.go:1034		0x6ad7d5		488b1424		MOVQ 0(SP), DX									
  tree.go:1034		0x6ad7d9		0f1f8000000000		NOPL 0(AX)									
  tree.go:1035		0x6ad7e0		4885d2			TESTQ DX, DX									
  tree.go:1035		0x6ad7e3		0f8527020000		JNE 0x6ada10									
  tree.go:1034		0x6ad7e9		4584db			TESTL R11, R11									
  tree.go:1038		0x6ad7ec		7452			JE 0x6ad840									
  tree.go:1039		0x6ad7ee		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1039		0x6ad7f6		4989d9			MOVQ BX, R9									
  tree.go:1039		0x6ad7f9		4929d1			SUBQ DX, R9									
  tree.go:100		0x6ad7fc		803d94b1460200		CMPB github.com/snissn/gomap/TreeDB/tree.treeHotReadStatsEnabled(SB), $0x0	
  tree.go:100		0x6ad803		7424			JE 0x6ad829									
  tree.go:103		0x6ad805		90			NOPL										
  type.go:195		0x6ad806		ba01000000		MOVL $0x1, DX									
  type.go:195		0x6ad80b		4c8d1d06b74602		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineHitsTotal(SB), R11	
  type.go:195		0x6ad812		f0490fc113		LOCK XADDQ DX, 0(R11)								
  tree.go:104		0x6ad817		4d85c9			TESTQ R9, R9									
  tree.go:104		0x6ad81a		7e0d			JLE 0x6ad829									
  tree.go:105		0x6ad81c		90			NOPL										
  type.go:195		0x6ad81d		488d15fcb64602		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineBytesTotal(SB), DX	
  type.go:195		0x6ad824		f04c0fc10a		LOCK XADDQ R9, 0(DX)								
  tree.go:1040		0x6ad829		4c89d7			MOVQ R10, DI									
  tree.go:1040		0x6ad82c		31f6			XORL SI, SI									
  tree.go:1040		0x6ad82e		4531c0			XORL R8, R8									
  tree.go:1040		0x6ad831		4883c478		ADDQ $0x78, SP									
  tree.go:1040		0x6ad835		5d			POPQ BP										
  tree.go:1040		0x6ad836		c3			RET										
  tree.go:1040		0x6ad837		660f1f840000000000	NOPW 0(AX)(AX*1)								
  tree.go:1042		0x6ad840		41f6c102		TESTL $0x2, R9									
  tree.go:1042		0x6ad844		0f8597010000		JNE 0x6ad9e1									
  tree.go:1034		0x6ad84a		4c89542450		MOVQ R10, 0x50(SP)								
  tree.go:1045		0x6ad84f		41f6c101		TESTL $0x1, R9									
  tree.go:1045		0x6ad853		0f8523010000		JNE 0x6ad97c									
  tree.go:1045		0x6ad859		0f1f8000000000		NOPL 0(AX)									
  tree.go:1049		0x6ad860		4885c0			TESTQ AX, AX									
  tree.go:1049		0x6ad863		0f84d1000000		JE 0x6ad93a									
  tree.go:1053		0x6ad869		90			NOPL										
  tree.go:100		0x6ad86a		803d26b1460200		CMPB github.com/snissn/gomap/TreeDB/tree.treeHotReadStatsEnabled(SB), $0x0	
  tree.go:100		0x6ad871		742f			JE 0x6ad8a2									
  tree.go:103		0x6ad873		90			NOPL										
  type.go:195		0x6ad874		ba01000000		MOVL $0x1, DX									
  type.go:195		0x6ad879		4c8d0598b64602		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineHitsTotal(SB), R8	
  type.go:195		0x6ad880		f0490fc110		LOCK XADDQ DX, 0(R8)								
  tree.go:104		0x6ad885		4885db			TESTQ BX, BX									
  tree.go:104		0x6ad888		7411			JE 0x6ad89b									
  type.go:195		0x6ad88a		488d158fb64602		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineBytesTotal(SB), DX	
  type.go:195		0x6ad891		4889df			MOVQ BX, DI									
  type.go:195		0x6ad894		f0480fc11a		LOCK XADDQ BX, 0(DX)								
  tree.go:105		0x6ad899		eb0a			JMP 0x6ad8a5									
  tree.go:1054		0x6ad89b		4889df			MOVQ BX, DI									
  tree.go:1054		0x6ad89e		6690			NOPW										
  tree.go:104		0x6ad8a0		eb03			JMP 0x6ad8a5									
  tree.go:1054		0x6ad8a2		4889df			MOVQ BX, DI									
  tree.go:1054		0x6ad8a5		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1054		0x6ad8ad		488d1c3a		LEAQ 0(DX)(DI*1), BX								
  tree.go:1054		0x6ad8b1		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1054		0x6ad8b9		4839d9			CMPQ CX, BX									
  tree.go:1054		0x6ad8bc		720a			JB 0x6ad8c8									
  tree.go:1054		0x6ad8be		488bb424a8000000	MOVQ 0xa8(SP), SI								
  tree.go:1054		0x6ad8c6		eb33			JMP 0x6ad8fb									
  tree.go:1034		0x6ad8c8		48897c2460		MOVQ DI, 0x60(SP)								
  tree.go:1034		0x6ad8cd		4889442468		MOVQ AX, 0x68(SP)								
  tree.go:1054		0x6ad8d2		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1054		0x6ad8da		488d359f7f2701		LEAQ 0x1277f9f(IP), SI								
  tree.go:1054		0x6ad8e1		e85a14deff		CALL runtime.growslice(SB)							
  tree.go:1054		0x6ad8e6		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1054		0x6ad8ee		488b7c2460		MOVQ 0x60(SP), DI								
  tree.go:1054		0x6ad8f3		4889c6			MOVQ AX, SI									
  tree.go:1054		0x6ad8f6		488b442468		MOVQ 0x68(SP), AX								
  tree.go:1054		0x6ad8fb		48894c2460		MOVQ CX, 0x60(SP)								
  tree.go:1054		0x6ad900		48895c2458		MOVQ BX, 0x58(SP)								
  tree.go:1054		0x6ad905		4889742470		MOVQ SI, 0x70(SP)								
  tree.go:1054		0x6ad90a		4801f2			ADDQ SI, DX									
  tree.go:1054		0x6ad90d		4889c3			MOVQ AX, BX									
  tree.go:1054		0x6ad910		4889f9			MOVQ DI, CX									
  tree.go:1054		0x6ad913		4889d0			MOVQ DX, AX									
  tree.go:1054		0x6ad916		e84570deff		CALL runtime.memmove(SB)							
  tree.go:1054		0x6ad91b		488b442470		MOVQ 0x70(SP), AX								
  tree.go:1054		0x6ad920		488b5c2458		MOVQ 0x58(SP), BX								
  tree.go:1054		0x6ad925		488b4c2460		MOVQ 0x60(SP), CX								
  tree.go:1054		0x6ad92a		488b7c2450		MOVQ 0x50(SP), DI								
  tree.go:1054		0x6ad92f		31f6			XORL SI, SI									
  tree.go:1054		0x6ad931		4531c0			XORL R8, R8									
  tree.go:1054		0x6ad934		4883c478		ADDQ $0x78, SP									
  tree.go:1054		0x6ad938		5d			POPQ BP										
  tree.go:1054		0x6ad939		c3			RET										
  tree.go:1050		0x6ad93a		90			NOPL										
  tree.go:100		0x6ad93b		803d55b0460200		CMPB github.com/snissn/gomap/TreeDB/tree.treeHotReadStatsEnabled(SB), $0x0	
  tree.go:100		0x6ad942		7412			JE 0x6ad956									
  tree.go:103		0x6ad944		90			NOPL										
  type.go:195		0x6ad945		ba01000000		MOVL $0x1, DX									
  type.go:195		0x6ad94a		4c8d0dc7b54602		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineHitsTotal(SB), R9	
  type.go:195		0x6ad951		f0490fc111		LOCK XADDQ DX, 0(R9)								
  tree.go:1051		0x6ad956		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1051		0x6ad95e		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  tree.go:1051		0x6ad966		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1051		0x6ad96e		4c89d7			MOVQ R10, DI									
  tree.go:1051		0x6ad971		31f6			XORL SI, SI									
  tree.go:1051		0x6ad973		4531c0			XORL R8, R8									
  tree.go:1051		0x6ad976		4883c478		ADDQ $0x78, SP									
  tree.go:1051		0x6ad97a		5d			POPQ BP										
  tree.go:1051		0x6ad97b		c3			RET										
  tree.go:1046		0x6ad97c		488b9424a8000000	MOVQ 0xa8(SP), DX								
  tree.go:1046		0x6ad984		48891424		MOVQ DX, 0(SP)									
  tree.go:1046		0x6ad988		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1046		0x6ad990		4889542408		MOVQ DX, 0x8(SP)								
  tree.go:1046		0x6ad995		488b9424b8000000	MOVQ 0xb8(SP), DX								
  tree.go:1046		0x6ad99d		4889542410		MOVQ DX, 0x10(SP)								
  tree.go:1046		0x6ad9a2		488b842488000000	MOVQ 0x88(SP), AX								
  tree.go:1046		0x6ad9aa		488b9c2490000000	MOVQ 0x90(SP), BX								
  tree.go:1046		0x6ad9b2		488b8c2498000000	MOVQ 0x98(SP), CX								
  tree.go:1046		0x6ad9ba		4589c1			MOVL R8, R9									
  tree.go:1046		0x6ad9bd		4189f0			MOVL SI, R8									
  tree.go:1046		0x6ad9c0		4889fe			MOVQ DI, SI									
  tree.go:1046		0x6ad9c3		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  tree.go:1046		0x6ad9cb		e850f3ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).appendPointerValueForKey(SB)	
  tree.go:1047		0x6ad9d0		4989f0			MOVQ SI, R8									
  tree.go:1047		0x6ad9d3		4889fe			MOVQ DI, SI									
  tree.go:1047		0x6ad9d6		488b7c2450		MOVQ 0x50(SP), DI								
  tree.go:1047		0x6ad9db		4883c478		ADDQ $0x78, SP									
  tree.go:1047		0x6ad9df		5d			POPQ BP										
  tree.go:1047		0x6ad9e0		c3			RET										
  tree.go:1043		0x6ad9e1		488b3528123502		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), SI			
  tree.go:1043		0x6ad9e8		4c8b0529123502		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R8		
  tree.go:1043		0x6ad9ef		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1043		0x6ad9f7		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  tree.go:1043		0x6ad9ff		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1043		0x6ada07		4c89d7			MOVQ R10, DI									
  tree.go:1043		0x6ada0a		4883c478		ADDQ $0x78, SP									
  tree.go:1043		0x6ada0e		5d			POPQ BP										
  tree.go:1043		0x6ada0f		c3			RET										
  tree.go:1034		0x6ada10		4c8b442408		MOVQ 0x8(SP), R8								
  tree.go:1036		0x6ada15		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1036		0x6ada1d		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  tree.go:1036		0x6ada25		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1036		0x6ada2d		4c89d7			MOVQ R10, DI									
  tree.go:1036		0x6ada30		4889d6			MOVQ DX, SI									
  tree.go:1036		0x6ada33		4883c478		ADDQ $0x78, SP									
  tree.go:1036		0x6ada37		5d			POPQ BP										
  tree.go:1036		0x6ada38		c3			RET										
  tree.go:1033		0x6ada39		4889442408		MOVQ AX, 0x8(SP)								
  tree.go:1033		0x6ada3e		48895c2410		MOVQ BX, 0x10(SP)								
  tree.go:1033		0x6ada43		48894c2418		MOVQ CX, 0x18(SP)								
  tree.go:1033		0x6ada48		48897c2420		MOVQ DI, 0x20(SP)								
  tree.go:1033		0x6ada4d		4889742428		MOVQ SI, 0x28(SP)								
  tree.go:1033		0x6ada52		4c89442430		MOVQ R8, 0x30(SP)								
  tree.go:1033		0x6ada57		4c894c2438		MOVQ R9, 0x38(SP)								
  tree.go:1033		0x6ada5c		0f1f4000		NOPL 0(AX)									
  tree.go:1033		0x6ada60		e8bb4cdeff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1033		0x6ada65		488b442408		MOVQ 0x8(SP), AX								
  tree.go:1033		0x6ada6a		488b5c2410		MOVQ 0x10(SP), BX								
  tree.go:1033		0x6ada6f		488b4c2418		MOVQ 0x18(SP), CX								
  tree.go:1033		0x6ada74		488b7c2420		MOVQ 0x20(SP), DI								
  tree.go:1033		0x6ada79		488b742428		MOVQ 0x28(SP), SI								
  tree.go:1033		0x6ada7e		4c8b442430		MOVQ 0x30(SP), R8								
  tree.go:1033		0x6ada83		4c8b4c2438		MOVQ 0x38(SP), R9								
  tree.go:1033		0x6ada88		e9f3fcffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB)		

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyViewFallback(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1335		0x6afc40		4c8d6424d8		LEAQ -0x28(SP), R12								
  tree.go:1335		0x6afc45		4d3b6610		CMPQ R12, 0x10(R14)								
  tree.go:1335		0x6afc49		0f8624020000		JBE 0x6afe73									
  tree.go:1335		0x6afc4f		55			PUSHQ BP									
  tree.go:1335		0x6afc50		4889e5			MOVQ SP, BP									
  tree.go:1335		0x6afc53		4881eca0000000		SUBQ $0xa0, SP									
  tree.go:1335		0x6afc5a		48899c24b8000000	MOVQ BX, 0xb8(SP)								
  tree.go:1337		0x6afc62		48898424b0000000	MOVQ AX, 0xb0(SP)								
  tree.go:1337		0x6afc6a		4889b424d0000000	MOVQ SI, 0xd0(SP)								
  tree.go:1337		0x6afc72		48898c24c0000000	MOVQ CX, 0xc0(SP)								
  tree.go:1337		0x6afc7a		31d2			XORL DX, DX									
  tree.go:1337		0x6afc7c		31ff			XORL DI, DI									
  tree.go:1337		0x6afc7e		4531c0			XORL R8, R8									
  tree.go:1337		0x6afc81		eb3d			JMP 0x6afcc0									
  tree.go:1337		0x6afc83		488b9c2498000000	MOVQ 0x98(SP), BX								
  tree.go:1337		0x6afc8b		4883c318		ADDQ $0x18, BX									
  tree.go:1337		0x6afc8f		4c8b542460		MOVQ 0x60(SP), R10								
  tree.go:1337		0x6afc94		49ffc2			INCQ R10									
  tree.go:1337		0x6afc97		488b8c24c0000000	MOVQ 0xc0(SP), CX								
  tree.go:1352		0x6afc9f		488bb424d0000000	MOVQ 0xd0(SP), SI								
  tree.go:1337		0x6afca7		4889d7			MOVQ DX, DI									
  tree.go:1337		0x6afcaa		4989c0			MOVQ AX, R8									
  tree.go:1338		0x6afcad		488b8424b0000000	MOVQ 0xb0(SP), AX								
  tree.go:1337		0x6afcb5		4c89d2			MOVQ R10, DX									
  tree.go:1337		0x6afcb8		0f1f840000000000	NOPL 0(AX)(AX*1)								
  tree.go:1337		0x6afcc0		4839d1			CMPQ CX, DX									
  tree.go:1337		0x6afcc3		0f8e9d010000		JLE 0x6afe66									
  tree.go:1337		0x6afcc9		4889542460		MOVQ DX, 0x60(SP)								
  tree.go:1337		0x6afcce		4c89442478		MOVQ R8, 0x78(SP)								
  tree.go:1337		0x6afcd3		48897c2440		MOVQ DI, 0x40(SP)								
  tree.go:1337		0x6afcd8		48899c2498000000	MOVQ BX, 0x98(SP)								
  tree.go:1337		0x6afce0		488b13			MOVQ 0(BX), DX									
  tree.go:1337		0x6afce3		4889942480000000	MOVQ DX, 0x80(SP)								
  tree.go:1337		0x6afceb		488b4b08		MOVQ 0x8(BX), CX								
  tree.go:1337		0x6afcef		48894c2450		MOVQ CX, 0x50(SP)								
  tree.go:1337		0x6afcf4		4c8b5310		MOVQ 0x10(BX), R10								
  tree.go:1337		0x6afcf8		4c89542458		MOVQ R10, 0x58(SP)								
  tree.go:1338		0x6afcfd		4889d3			MOVQ DX, BX									
  tree.go:1338		0x6afd00		4c89c6			MOVQ R8, SI									
  tree.go:1338		0x6afd03		4531c0			XORL R8, R8									
  tree.go:1338		0x6afd06		4989f9			MOVQ DI, R9									
  tree.go:1338		0x6afd09		4c89d7			MOVQ R10, DI									
  tree.go:1338		0x6afd0c		e88fd7ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetAppend(SB)			
  tree.go:1338		0x6afd11		4889842490000000	MOVQ AX, 0x90(SP)								
  tree.go:1338		0x6afd19		48894c2470		MOVQ CX, 0x70(SP)								
  tree.go:1338		0x6afd1e		6690			NOPW										
  tree.go:1339		0x6afd20		48393de9ee3402		CMPQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), DI			
  tree.go:1339		0x6afd27		754b			JNE 0x6afd74									
  tree.go:1338		0x6afd29		4889b42488000000	MOVQ SI, 0x88(SP)								
  tree.go:1338		0x6afd31		48897c2468		MOVQ DI, 0x68(SP)								
  tree.go:1338		0x6afd36		48895c2448		MOVQ BX, 0x48(SP)								
  tree.go:1339		0x6afd3b		488b0dd6ee3402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), CX		
  tree.go:1339		0x6afd42		4889f8			MOVQ DI, AX									
  tree.go:1339		0x6afd45		4889f3			MOVQ SI, BX									
  tree.go:1339		0x6afd48		e8737dd6ff		CALL runtime.ifaceeq(SB)							
  tree.go:1339		0x6afd4d		84c0			TESTL AL, AL									
  tree.go:1339		0x6afd4f		0f85aa000000		JNE 0x6afdff									
  tree.go:1352		0x6afd55		488b842490000000	MOVQ 0x90(SP), AX								
  tree.go:1352		0x6afd5d		488b4c2470		MOVQ 0x70(SP), CX								
  tree.go:1349		0x6afd62		488b5c2448		MOVQ 0x48(SP), BX								
  tree.go:1346		0x6afd67		488bb42488000000	MOVQ 0x88(SP), SI								
  tree.go:1345		0x6afd6f		488b7c2468		MOVQ 0x68(SP), DI								
  tree.go:1345		0x6afd74		4885ff			TESTQ DI, DI									
  tree.go:1345		0x6afd77		0f85d1000000		JNE 0x6afe4e									
  tree.go:1345		0x6afd7d		0f1f00			NOPL 0(AX)									
  tree.go:1349		0x6afd80		4885db			TESTQ BX, BX									
  tree.go:1349		0x6afd83		7517			JNE 0x6afd9c									
  tree.go:1350		0x6afd85		4c8b1db4443502		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue(SB), R11		
  tree.go:1350		0x6afd8c		488b1db5443502		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+8(SB), BX	
  tree.go:1350		0x6afd93		4c8b25b6443502		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+16(SB), R12	
  tree.go:1350		0x6afd9a		eb06			JMP 0x6afda2									
  tree.go:1352		0x6afd9c		4989cc			MOVQ CX, R12									
  tree.go:1352		0x6afd9f		4989c3			MOVQ AX, R11									
  tree.go:1352		0x6afda2		488b9424d0000000	MOVQ 0xd0(SP), DX								
  tree.go:1352		0x6afdaa		4c8b2a			MOVQ 0(DX), R13									
  tree.go:1352		0x6afdad		488b442460		MOVQ 0x60(SP), AX								
  tree.go:1352		0x6afdb2		488b4c2450		MOVQ 0x50(SP), CX								
  tree.go:1352		0x6afdb7		488b7c2458		MOVQ 0x58(SP), DI								
  tree.go:1352		0x6afdbc		4c89de			MOVQ R11, SI									
  tree.go:1352		0x6afdbf		4989d8			MOVQ BX, R8									
  tree.go:1352		0x6afdc2		4d89e1			MOVQ R12, R9									
  tree.go:1352		0x6afdc5		41ba01000000		MOVL $0x1, R10									
  tree.go:1352		0x6afdcb		488b9c2480000000	MOVQ 0x80(SP), BX								
  tree.go:1352		0x6afdd3		41ffd5			CALL R13									
  tree.go:1352		0x6afdd6		4885c0			TESTQ AX, AX									
  tree.go:1352		0x6afdd9		756a			JNE 0x6afe45									
  tree.go:1355		0x6afddb		488b542470		MOVQ 0x70(SP), DX								
  tree.go:1355		0x6afde0		4881fa00001000		CMPQ DX, $0x100000								
  tree.go:1355		0x6afde7		7f0d			JG 0x6afdf6									
  tree.go:1355		0x6afde9		488b842490000000	MOVQ 0x90(SP), AX								
  tree.go:1356		0x6afdf1		e98dfeffff		JMP 0x6afc83									
  tree.go:1356		0x6afdf6		31d2			XORL DX, DX									
  tree.go:1356		0x6afdf8		31c0			XORL AX, AX									
  tree.go:1355		0x6afdfa		e984feffff		JMP 0x6afc83									
  tree.go:1340		0x6afdff		488b9424d0000000	MOVQ 0xd0(SP), DX								
  tree.go:1340		0x6afe07		4c8b1a			MOVQ 0(DX), R11									
  tree.go:1340		0x6afe0a		488b442460		MOVQ 0x60(SP), AX								
  tree.go:1340		0x6afe0f		488b9c2480000000	MOVQ 0x80(SP), BX								
  tree.go:1340		0x6afe17		488b4c2450		MOVQ 0x50(SP), CX								
  tree.go:1340		0x6afe1c		488b7c2458		MOVQ 0x58(SP), DI								
  tree.go:1340		0x6afe21		31f6			XORL SI, SI									
  tree.go:1340		0x6afe23		4531c0			XORL R8, R8									
  tree.go:1340		0x6afe26		4d89c1			MOVQ R8, R9									
  tree.go:1340		0x6afe29		4531d2			XORL R10, R10									
  tree.go:1340		0x6afe2c		41ffd3			CALL R11									
  tree.go:1340		0x6afe2f		4885c0			TESTQ AX, AX									
  tree.go:1340		0x6afe32		7529			JNE 0x6afe5d									
  tree.go:1337		0x6afe34		488b542440		MOVQ 0x40(SP), DX								
  tree.go:1337		0x6afe39		488b442478		MOVQ 0x78(SP), AX								
  tree.go:1337		0x6afe3e		6690			NOPW										
  tree.go:1343		0x6afe40		e93efeffff		JMP 0x6afc83									
  tree.go:1353		0x6afe45		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1353		0x6afe4c		5d			POPQ BP										
  tree.go:1353		0x6afe4d		c3			RET										
  tree.go:1346		0x6afe4e		4889f8			MOVQ DI, AX									
  tree.go:1346		0x6afe51		4889f3			MOVQ SI, BX									
  tree.go:1346		0x6afe54		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1346		0x6afe5b		5d			POPQ BP										
  tree.go:1346		0x6afe5c		c3			RET										
  tree.go:1341		0x6afe5d		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1341		0x6afe64		5d			POPQ BP										
  tree.go:1341		0x6afe65		c3			RET										
  tree.go:1361		0x6afe66		31c0			XORL AX, AX									
  tree.go:1361		0x6afe68		31db			XORL BX, BX									
  tree.go:1361		0x6afe6a		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1361		0x6afe71		5d			POPQ BP										
  tree.go:1361		0x6afe72		c3			RET										
  tree.go:1335		0x6afe73		4889442408		MOVQ AX, 0x8(SP)								
  tree.go:1335		0x6afe78		48895c2410		MOVQ BX, 0x10(SP)								
  tree.go:1335		0x6afe7d		48894c2418		MOVQ CX, 0x18(SP)								
  tree.go:1335		0x6afe82		48897c2420		MOVQ DI, 0x20(SP)								
  tree.go:1335		0x6afe87		4889742428		MOVQ SI, 0x28(SP)								
  tree.go:1335		0x6afe8c		e88f28deff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1335		0x6afe91		488b442408		MOVQ 0x8(SP), AX								
  tree.go:1335		0x6afe96		488b5c2410		MOVQ 0x10(SP), BX								
  tree.go:1335		0x6afe9b		488b4c2418		MOVQ 0x18(SP), CX								
  tree.go:1335		0x6afea0		488b7c2420		MOVQ 0x20(SP), DI								
  tree.go:1335		0x6afea5		488b742428		MOVQ 0x28(SP), SI								
  tree.go:1335		0x6afeaa		e991fdffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyViewFallback(SB)		

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyAppendFallback(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1364		0x6afec0		4c8d6424f0		LEAQ -0x10(SP), R12								
  tree.go:1364		0x6afec5		4d3b6610		CMPQ R12, 0x10(R14)								
  tree.go:1364		0x6afec9		0f86eb020000		JBE 0x6b01ba									
  tree.go:1364		0x6afecf		55			PUSHQ BP									
  tree.go:1364		0x6afed0		4889e5			MOVQ SP, BP									
  tree.go:1364		0x6afed3		4881ec88000000		SUBQ $0x88, SP									
  tree.go:1364		0x6afeda		48899c24b8000000	MOVQ BX, 0xb8(SP)								
  tree.go:1365		0x6afee2		48898424b0000000	MOVQ AX, 0xb0(SP)								
  tree.go:1365		0x6afeea		4c898424d8000000	MOVQ R8, 0xd8(SP)								
  tree.go:1365		0x6afef2		48898c24c0000000	MOVQ CX, 0xc0(SP)								
  tree.go:1365		0x6afefa		4889b424d0000000	MOVQ SI, 0xd0(SP)								
  tree.go:1365		0x6aff02		31d2			XORL DX, DX									
  tree.go:1365		0x6aff04		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  tree.go:1365		0x6aff0c		4c8b8c24a8000000	MOVQ 0xa8(SP), R9								
  tree.go:1365		0x6aff14		4c8b942498000000	MOVQ 0x98(SP), R10								
  tree.go:1365		0x6aff1c		eb37			JMP 0x6aff55									
  tree.go:1365		0x6aff1e		4c8b5c2478		MOVQ 0x78(SP), R11								
  tree.go:1365		0x6aff23		4983c318		ADDQ $0x18, R11									
  tree.go:1365		0x6aff27		4d8d6201		LEAQ 0x1(R10), R12								
  tree.go:1377		0x6aff2b		4889d6			MOVQ DX, SI									
  tree.go:1377		0x6aff2e		4c8b8424d8000000	MOVQ 0xd8(SP), R8								
  tree.go:1365		0x6aff36		4c89e2			MOVQ R12, DX									
  tree.go:1365		0x6aff39		4889df			MOVQ BX, DI									
  tree.go:1365		0x6aff3c		4989c9			MOVQ CX, R9									
  tree.go:1365		0x6aff3f		4989c2			MOVQ AX, R10									
  tree.go:1367		0x6aff42		488b8424b0000000	MOVQ 0xb0(SP), AX								
  tree.go:1365		0x6aff4a		488b8c24c0000000	MOVQ 0xc0(SP), CX								
  tree.go:1365		0x6aff52		4c89db			MOVQ R11, BX									
  tree.go:1365		0x6aff55		4839d1			CMPQ CX, DX									
  tree.go:1365		0x6aff58		0f8e31020000		JLE 0x6b018f									
  tree.go:1365		0x6aff5e		4889542448		MOVQ DX, 0x48(SP)								
  tree.go:1365		0x6aff63		4c894c2460		MOVQ R9, 0x60(SP)								
  tree.go:1365		0x6aff68		48897c2458		MOVQ DI, 0x58(SP)								
  tree.go:1365		0x6aff6d		4c89942480000000	MOVQ R10, 0x80(SP)								
  tree.go:1365		0x6aff75		48895c2478		MOVQ BX, 0x78(SP)								
  tree.go:1365		0x6aff7a		488b13			MOVQ 0(BX), DX									
  tree.go:1365		0x6aff7d		488b4b08		MOVQ 0x8(BX), CX								
  tree.go:1365		0x6aff81		4c8b5b10		MOVQ 0x10(BX), R11								
  tree.go:1367		0x6aff85		4889d3			MOVQ DX, BX									
  tree.go:1367		0x6aff88		4c89d6			MOVQ R10, SI									
  tree.go:1367		0x6aff8b		4989f8			MOVQ DI, R8									
  tree.go:1367		0x6aff8e		4c89df			MOVQ R11, DI									
  tree.go:1367		0x6aff91		e80ad5ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetAppend(SB)			
  tree.go:1367		0x6aff96		660f1f840000000000	NOPW 0(AX)(AX*1)								
  tree.go:1367		0x6aff9f		90			NOPL										
  tree.go:1368		0x6affa0		48393d69ec3402		CMPQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), DI			
  tree.go:1368		0x6affa7		0f85c1000000		JNE 0x6b006e									
  tree.go:1367		0x6affad		4889442468		MOVQ AX, 0x68(SP)								
  tree.go:1367		0x6affb2		4889742470		MOVQ SI, 0x70(SP)								
  tree.go:1367		0x6affb7		48897c2450		MOVQ DI, 0x50(SP)								
  tree.go:1367		0x6affbc		48894c2440		MOVQ CX, 0x40(SP)								
  tree.go:1367		0x6affc1		48895c2438		MOVQ BX, 0x38(SP)								
  tree.go:1368		0x6affc6		488b0d4bec3402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), CX		
  tree.go:1368		0x6affcd		4889f8			MOVQ DI, AX									
  tree.go:1368		0x6affd0		4889f3			MOVQ SI, BX									
  tree.go:1368		0x6affd3		e8e87ad6ff		CALL runtime.ifaceeq(SB)							
  tree.go:1368		0x6affd8		84c0			TESTL AL, AL									
  tree.go:1368		0x6affda		7479			JE 0x6b0055									
  tree.go:1369		0x6affdc		488b9424d8000000	MOVQ 0xd8(SP), DX								
  tree.go:1369		0x6affe4		4c8b542448		MOVQ 0x48(SP), R10								
  tree.go:1369		0x6affe9		4c39d2			CMPQ DX, R10									
  tree.go:1369		0x6affec		0f86c2010000		JBE 0x6b01b4									
  tree.go:1369		0x6afff2		4f8d1c52		LEAQ 0(R10)(R10*2), R11								
  tree.go:1369		0x6afff6		4c8ba424d0000000	MOVQ 0xd0(SP), R12								
  tree.go:1369		0x6afffe		4bc744dc0800000000	MOVQ $0x0, 0x8(R12)(R11*8)							
  tree.go:1369		0x6b0007		4bc744dc1000000000	MOVQ $0x0, 0x10(R12)(R11*8)							
  tree.go:1369		0x6b0010		833dd996460200		CMPL runtime.writeBarrier(SB), $0x0						
  tree.go:1369		0x6b0017		7412			JE 0x6b002b									
  tree.go:1369		0x6b0019		4f8b2cdc		MOVQ 0(R12)(R11*8), R13								
  tree.go:1369		0x6b001d		4c89d8			MOVQ R11, AX									
  tree.go:1369		0x6b0020		e8db41deff		CALL runtime.gcWriteBarrier1(SB)						
  tree.go:1369		0x6b0025		4d892b			MOVQ R13, 0(R11)								
  tree.go:1369		0x6b0028		4989c3			MOVQ AX, R11									
  tree.go:1369		0x6b002b		4bc704dc00000000	MOVQ $0x0, 0(R12)(R11*8)							
  tree.go:1377		0x6b0033		4c89e2			MOVQ R12, DX									
  tree.go:1377		0x6b0036		488bb424d8000000	MOVQ 0xd8(SP), SI								
  tree.go:1365		0x6b003e		488b4c2460		MOVQ 0x60(SP), CX								
  tree.go:1365		0x6b0043		488b5c2458		MOVQ 0x58(SP), BX								
  tree.go:1365		0x6b0048		488b842480000000	MOVQ 0x80(SP), AX								
  tree.go:1370		0x6b0050		e9c9feffff		JMP 0x6aff1e									
  tree.go:1380		0x6b0055		488b442468		MOVQ 0x68(SP), AX								
  tree.go:1365		0x6b005a		488b4c2440		MOVQ 0x40(SP), CX								
  tree.go:1376		0x6b005f		488b5c2438		MOVQ 0x38(SP), BX								
  tree.go:1373		0x6b0064		488b742470		MOVQ 0x70(SP), SI								
  tree.go:1372		0x6b0069		488b7c2450		MOVQ 0x50(SP), DI								
  tree.go:1372		0x6b006e		4885ff			TESTQ DI, DI									
  tree.go:1372		0x6b0071		0f85fd000000		JNE 0x6b0174									
  tree.go:1376		0x6b0077		488b542458		MOVQ 0x58(SP), DX								
  tree.go:1376		0x6b007c		0f1f4000		NOPL 0(AX)									
  tree.go:1376		0x6b0080		4839d3			CMPQ BX, DX									
  tree.go:1376		0x6b0083		756c			JNE 0x6b00f1									
  tree.go:1377		0x6b0085		488b9424d8000000	MOVQ 0xd8(SP), DX								
  tree.go:1377		0x6b008d		4c8b542448		MOVQ 0x48(SP), R10								
  tree.go:1377		0x6b0092		4c39d2			CMPQ DX, R10									
  tree.go:1377		0x6b0095		0f8614010000		JBE 0x6b01af									
  tree.go:1377		0x6b009b		4f8d1c52		LEAQ 0(R10)(R10*2), R11								
  tree.go:1377		0x6b009f		4c8b25a2413502		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+8(SB), R12	
  tree.go:1377		0x6b00a6		4c8b2da3413502		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+16(SB), R13	
  tree.go:1377		0x6b00ad		4c8b3d8c413502		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue(SB), R15		
  tree.go:1365		0x6b00b4		4889d6			MOVQ DX, SI									
  tree.go:1377		0x6b00b7		488b9424d0000000	MOVQ 0xd0(SP), DX								
  tree.go:1377		0x6b00bf		4e8964da08		MOVQ R12, 0x8(DX)(R11*8)							
  tree.go:1377		0x6b00c4		4e896cda10		MOVQ R13, 0x10(DX)(R11*8)							
  tree.go:1377		0x6b00c9		833d2096460200		CMPL runtime.writeBarrier(SB), $0x0						
  tree.go:1377		0x6b00d0		7416			JE 0x6b00e8									
  tree.go:1377		0x6b00d2		4e8b24da		MOVQ 0(DX)(R11*8), R12								
  tree.go:1377		0x6b00d6		4c89df			MOVQ R11, DI									
  tree.go:1377		0x6b00d9		e84241deff		CALL runtime.gcWriteBarrier2(SB)						
  tree.go:1377		0x6b00de		4d893b			MOVQ R15, 0(R11)								
  tree.go:1377		0x6b00e1		4d896308		MOVQ R12, 0x8(R11)								
  tree.go:1377		0x6b00e5		4989fb			MOVQ DI, R11									
  tree.go:1377		0x6b00e8		4e893cda		MOVQ R15, 0(DX)(R11*8)								
  tree.go:1378		0x6b00ec		e92dfeffff		JMP 0x6aff1e									
  tree.go:1380		0x6b00f1		0f82b3000000		JB 0x6b01aa									
  tree.go:1380		0x6b00f7		4989da			MOVQ BX, R10									
  tree.go:1380		0x6b00fa		4829d3			SUBQ DX, BX									
  tree.go:1380		0x6b00fd		4989db			MOVQ BX, R11									
  tree.go:1380		0x6b0100		48f7db			NEGQ BX										
  tree.go:1380		0x6b0103		48c1fb3f		SARQ $0x3f, BX									
  tree.go:1380		0x6b0107		4821da			ANDQ BX, DX									
  tree.go:1380		0x6b010a		4801c2			ADDQ AX, DX									
  tree.go:1380		0x6b010d		4c8ba424d8000000	MOVQ 0xd8(SP), R12								
  tree.go:1380		0x6b0115		4c8b6c2448		MOVQ 0x48(SP), R13								
  tree.go:1380		0x6b011a		660f1f440000		NOPW 0(AX)(AX*1)								
  tree.go:1380		0x6b0120		4d39ec			CMPQ R12, R13									
  tree.go:1380		0x6b0123		0f867c000000		JBE 0x6b01a5									
  tree.go:1380		0x6b0129		4f8d7c6d00		LEAQ 0(R13)(R13*2), R15								
  tree.go:1365		0x6b012e		4c89e3			MOVQ R12, BX									
  tree.go:1380		0x6b0131		4c8ba424d0000000	MOVQ 0xd0(SP), R12								
  tree.go:1380		0x6b0139		4f895cfc08		MOVQ R11, 0x8(R12)(R15*8)							
  tree.go:1380		0x6b013e		4f895cfc10		MOVQ R11, 0x10(R12)(R15*8)							
  tree.go:1380		0x6b0143		833da695460200		CMPL runtime.writeBarrier(SB), $0x0						
  tree.go:1380		0x6b014a		7413			JE 0x6b015f									
  tree.go:1380		0x6b014c		4f8b1cfc		MOVQ 0(R12)(R15*8), R11								
  tree.go:1380		0x6b0150		4c89de			MOVQ R11, SI									
  tree.go:1380		0x6b0153		e8c840deff		CALL runtime.gcWriteBarrier2(SB)						
  tree.go:1380		0x6b0158		498913			MOVQ DX, 0(R11)									
  tree.go:1380		0x6b015b		49897308		MOVQ SI, 0x8(R11)								
  tree.go:1380		0x6b015f		4b8914fc		MOVQ DX, 0(R12)(R15*8)								
  tree.go:1377		0x6b0163		4c89e2			MOVQ R12, DX									
  tree.go:1377		0x6b0166		4889de			MOVQ BX, SI									
  tree.go:1365		0x6b0169		4c89d3			MOVQ R10, BX									
  tree.go:1365		0x6b016c		4d89ea			MOVQ R13, R10									
  tree.go:1380		0x6b016f		e9aafdffff		JMP 0x6aff1e									
  tree.go:1373		0x6b0174		488b842480000000	MOVQ 0x80(SP), AX								
  tree.go:1373		0x6b017c		488b5c2458		MOVQ 0x58(SP), BX								
  tree.go:1373		0x6b0181		488b4c2460		MOVQ 0x60(SP), CX								
  tree.go:1373		0x6b0186		4881c488000000		ADDQ $0x88, SP									
  tree.go:1373		0x6b018d		5d			POPQ BP										
  tree.go:1373		0x6b018e		c3			RET										
  tree.go:1382		0x6b018f		4c89d0			MOVQ R10, AX									
  tree.go:1382		0x6b0192		4889fb			MOVQ DI, BX									
  tree.go:1382		0x6b0195		4c89c9			MOVQ R9, CX									
  tree.go:1382		0x6b0198		31ff			XORL DI, DI									
  tree.go:1382		0x6b019a		31f6			XORL SI, SI									
  tree.go:1382		0x6b019c		4881c488000000		ADDQ $0x88, SP									
  tree.go:1382		0x6b01a3		5d			POPQ BP										
  tree.go:1382		0x6b01a4		c3			RET										
  tree.go:1380		0x6b01a5		e81644deff		CALL runtime.panicBounds(SB)							
  tree.go:1380		0x6b01aa		e81144deff		CALL runtime.panicBounds(SB)							
  tree.go:1377		0x6b01af		e80c44deff		CALL runtime.panicBounds(SB)							
  tree.go:1369		0x6b01b4		e80744deff		CALL runtime.panicBounds(SB)							
  tree.go:1369		0x6b01b9		90			NOPL										
  tree.go:1364		0x6b01ba		4889442420		MOVQ AX, 0x20(SP)								
  tree.go:1364		0x6b01bf		48895c2428		MOVQ BX, 0x28(SP)								
  tree.go:1364		0x6b01c4		48894c2430		MOVQ CX, 0x30(SP)								
  tree.go:1364		0x6b01c9		48897c2438		MOVQ DI, 0x38(SP)								
  tree.go:1364		0x6b01ce		4889742440		MOVQ SI, 0x40(SP)								
  tree.go:1364		0x6b01d3		4c89442448		MOVQ R8, 0x48(SP)								
  tree.go:1364		0x6b01d8		4c894c2450		MOVQ R9, 0x50(SP)								
  tree.go:1364		0x6b01dd		0f1f00			NOPL 0(AX)									
  tree.go:1364		0x6b01e0		e83b25deff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1364		0x6b01e5		488b442420		MOVQ 0x20(SP), AX								
  tree.go:1364		0x6b01ea		488b5c2428		MOVQ 0x28(SP), BX								
  tree.go:1364		0x6b01ef		488b4c2430		MOVQ 0x30(SP), CX								
  tree.go:1364		0x6b01f4		488b7c2438		MOVQ 0x38(SP), DI								
  tree.go:1364		0x6b01f9		488b742440		MOVQ 0x40(SP), SI								
  tree.go:1364		0x6b01fe		4c8b442448		MOVQ 0x48(SP), R8								
  tree.go:1364		0x6b0203		4c8b4c2450		MOVQ 0x50(SP), R9								
  tree.go:1364		0x6b0208		e9b3fcffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyAppendFallback(SB)	

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).findLeafRefForGetMany(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1385		0x6b0220		4c8da42440feffff	LEAQ 0xfffffe40(SP), R12							
  tree.go:1385		0x6b0228		4d3b6610		CMPQ R12, 0x10(R14)								
  tree.go:1385		0x6b022c		0f86f4060000		JBE 0x6b0926									
  tree.go:1385		0x6b0232		55			PUSHQ BP									
  tree.go:1385		0x6b0233		4889e5			MOVQ SP, BP									
  tree.go:1385		0x6b0236		4881ec38020000		SUBQ $0x238, SP									
  tree.go:1385		0x6b023d		48899c2450020000	MOVQ BX, 0x250(SP)								
  tree.go:1385		0x6b0245		488d542448		LEAQ 0x48(SP), DX								
  tree.go:1385		0x6b024a		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1385		0x6b024e		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1385		0x6b0253		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1385		0x6b0258		0f1f840000000000	NOPL 0(AX)(AX*1)								
  tree.go:1386		0x6b0260		4885c0			TESTQ AX, AX									
  tree.go:1386		0x6b0263		0f84a3000000		JE 0x6b030c									
  tree.go:1386		0x6b0269		4889842448020000	MOVQ AX, 0x248(SP)								
  tree.go:1386		0x6b0271		4088b42468020000	MOVB SI, 0x268(SP)								
  tree.go:1386		0x6b0279		48899c2450020000	MOVQ BX, 0x250(SP)								
  tree.go:1386		0x6b0281		4889bc2460020000	MOVQ DI, 0x260(SP)								
  tree.go:1386		0x6b0289		48898c2458020000	MOVQ CX, 0x258(SP)								
  tree.go:1389		0x6b0291		e8aa6affff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).pointDefinitelyAbsent(SB)	
  tree.go:1389		0x6b0296		84c0			TESTL AL, AL									
  tree.go:1389		0x6b0298		7537			JNE 0x6b02d1									
  tree.go:1392		0x6b029a		488b842448020000	MOVQ 0x248(SP), AX								
  tree.go:1392		0x6b02a2		488b90d0000000		MOVQ 0xd0(AX), DX								
  tree.go:1392		0x6b02a9		4c8da42488000000	LEAQ 0x88(SP), R12								
  tree.go:1392		0x6b02b1		450f113c24		MOVUPS X15, 0(R12)								
  tree.go:1392		0x6b02b6		450f117c2410		MOVUPS X15, 0x10(R12)								
  tree.go:1392		0x6b02bc		450f117c2418		MOVUPS X15, 0x18(R12)								
  tree.go:1392		0x6b02c2		4889942490000000	MOVQ DX, 0x90(SP)								
  tree.go:1392		0x6b02ca		31c9			XORL CX, CX									
  tree.go:1393		0x6b02cc		e9af000000		JMP 0x6b0380									
  tree.go:1390		0x6b02d1		488d542448		LEAQ 0x48(SP), DX								
  tree.go:1390		0x6b02d6		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1390		0x6b02da		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1390		0x6b02df		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1390		0x6b02e4		4c8b1525e93402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), R10		
  tree.go:1390		0x6b02eb		4c8b1d26e93402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R11		
  tree.go:1390		0x6b02f2		31c0			XORL AX, AX									
  tree.go:1390		0x6b02f4		31db			XORL BX, BX									
  tree.go:1390		0x6b02f6		31c9			XORL CX, CX									
  tree.go:1390		0x6b02f8		4889df			MOVQ BX, DI									
  tree.go:1390		0x6b02fb		89ce			MOVL CX, SI									
  tree.go:1390		0x6b02fd		4531c0			XORL R8, R8									
  tree.go:1390		0x6b0300		4531c9			XORL R9, R9									
  tree.go:1390		0x6b0303		4881c438020000		ADDQ $0x238, SP									
  tree.go:1390		0x6b030a		5d			POPQ BP										
  tree.go:1390		0x6b030b		c3			RET										
  errors.go:65		0x6b030c		488d050d6f2f01		LEAQ 0x12f6f0d(IP), AX								
  errors.go:65		0x6b0313		e88847d7ff		CALL runtime.newobject(SB)							
  errors.go:65		0x6b0318		48c740080c000000	MOVQ $0xc, 0x8(AX)								
  errors.go:65		0x6b0320		488d0d5e0c4601		LEAQ 0x1460c5e(IP), CX								
  errors.go:65		0x6b0327		488908			MOVQ CX, 0(AX)									
  tree.go:1387		0x6b032a		488d4c2448		LEAQ 0x48(SP), CX								
  tree.go:1387		0x6b032f		440f1139		MOVUPS X15, 0(CX)								
  tree.go:1387		0x6b0333		440f117910		MOVUPS X15, 0x10(CX)								
  tree.go:1387		0x6b0338		440f117918		MOVUPS X15, 0x18(CX)								
  tree.go:1387		0x6b033d		31db			XORL BX, BX									
  tree.go:1387		0x6b033f		31c9			XORL CX, CX									
  tree.go:1387		0x6b0341		4889df			MOVQ BX, DI									
  tree.go:1387		0x6b0344		89ce			MOVL CX, SI									
  tree.go:1387		0x6b0346		4531c0			XORL R8, R8									
  tree.go:1387		0x6b0349		4531c9			XORL R9, R9									
  tree.go:1387		0x6b034c		4c8d158ddf5901		LEAQ go:itab.*errors.errorString,error(SB), R10					
  tree.go:1387		0x6b0353		4989c3			MOVQ AX, R11									
  tree.go:1387		0x6b0356		31c0			XORL AX, AX									
  tree.go:1387		0x6b0358		4881c438020000		ADDQ $0x238, SP									
  tree.go:1387		0x6b035f		5d			POPQ BP										
  tree.go:1387		0x6b0360		c3			RET										
  tree.go:1393		0x6b0361		488b8c2480000000	MOVQ 0x80(SP), CX								
  tree.go:1393		0x6b0369		48ffc1			INCQ CX										
  tree.go:1398		0x6b036c		488b842448020000	MOVQ 0x248(SP), AX								
  tree.go:1392		0x6b0374		4c8da42488000000	LEAQ 0x88(SP), R12								
  tree.go:1392		0x6b037c		0f1f4000		NOPL 0(AX)									
  tree.go:1393		0x6b0380		4883f932		CMPQ CX, $0x32									
  tree.go:1393		0x6b0384		0f8d3b050000		JGE 0x6b08c5									
  tree.go:1394		0x6b038a		80bc248800000001	CMPB 0x88(SP), $0x1								
  tree.go:1394		0x6b0392		0f84d7040000		JE 0x6b086f									
  tree.go:1393		0x6b0398		48898c2480000000	MOVQ CX, 0x80(SP)								
  tree.go:1397		0x6b03a0		488d9c24d8000000	LEAQ 0xd8(SP), BX								
  tree.go:1397		0x6b03a8		ba05000000		MOVL $0x5, DX									
  tree.go:1397		0x6b03ad		440f113b		MOVUPS X15, 0(BX)								
  tree.go:1397		0x6b03b1		440f117b10		MOVUPS X15, 0x10(BX)								
  tree.go:1397		0x6b03b6		440f117b20		MOVUPS X15, 0x20(BX)								
  tree.go:1397		0x6b03bb		440f117b30		MOVUPS X15, 0x30(BX)								
  tree.go:1397		0x6b03c0		4883c340		ADDQ $0x40, BX									
  tree.go:1397		0x6b03c4		ffca			DECL DX										
  tree.go:1397		0x6b03c6		75e5			JNE 0x6b03ad									
  tree.go:1397		0x6b03c8		440f117bf8		MOVUPS X15, -0x8(BX)								
  tree.go:1398		0x6b03cd		0fb68c2488000000	MOVZX 0x88(SP), CX								
  tree.go:1398		0x6b03d5		488bbc2490000000	MOVQ 0x90(SP), DI								
  tree.go:1398		0x6b03dd		8bb42498000000		MOVL 0x98(SP), SI								
  tree.go:1398		0x6b03e4		4c8b8424a0000000	MOVQ 0xa0(SP), R8								
  tree.go:1398		0x6b03ec		448b8c24a8000000	MOVL 0xa8(SP), R9								
  tree.go:1398		0x6b03f4		440fb79424ac000000	MOVZX 0xac(SP), R10								
  tree.go:1398		0x6b03fd		c6042400		MOVB $0x0, 0(SP)								
  tree.go:1398		0x6b0401		488d9c24d8000000	LEAQ 0xd8(SP), BX								
  tree.go:1398		0x6b0409		440fb69c2468020000	MOVZX 0x268(SP), R11								
  tree.go:1398		0x6b0412		e8c99cffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).loadChildRefViewInto(SB)	
  tree.go:1398		0x6b0417		660f1f840000000000	NOPW 0(AX)(AX*1)								
  tree.go:1398		0x6b0420		4885c0			TESTQ AX, AX									
  tree.go:1398		0x6b0423		0f8513040000		JNE 0x6b083c									
  node.go:224		0x6b0429		0fb78424f2000000	MOVZX 0xf2(SP), AX								
  tree.go:1401		0x6b0431		90			NOPL										
  tree.go:1402		0x6b0432		6683f803		CMPW AX, $0x3									
  tree.go:1402		0x6b0436		0f85ed020000		JNE 0x6b0729									
  tree.go:1403		0x6b043c		488b942480000000	MOVQ 0x80(SP), DX								
  tree.go:1403		0x6b0444		4885d2			TESTQ DX, DX									
  tree.go:1403		0x6b0447		0f85b0000000		JNE 0x6b04fd									
  tree.go:1404		0x6b044d		488d8424d8000000	LEAQ 0xd8(SP), AX								
  tree.go:1404		0x6b0455		e8e699f3ff		CALL github.com/snissn/gomap/TreeDB/node.(*Node).InternalFenceBounds(SB)	
  tree.go:1404		0x6b045a		660f1f440000		NOPW 0(AX)(AX*1)								
  tree.go:1404		0x6b0460		4d85d2			TESTQ R10, R10									
  tree.go:1404		0x6b0463		0f8593020000		JNE 0x6b06fc									
  tree.go:1404		0x6b0469		4584c9			TESTL R9, R9									
  tree.go:1406		0x6b046c		0f8483000000		JE 0x6b04f5									
  tree.go:1407		0x6b0472		4885db			TESTQ BX, BX									
  tree.go:1407		0x6b0475		7453			JE 0x6b04ca									
  tree.go:1404		0x6b0477		4c89442478		MOVQ R8, 0x78(SP)								
  tree.go:1404		0x6b047c		4889742470		MOVQ SI, 0x70(SP)								
  tree.go:1404		0x6b0481		4889bc2420020000	MOVQ DI, 0x220(SP)								
  tree.go:1407		0x6b0489		4889c7			MOVQ AX, DI									
  tree.go:1407		0x6b048c		4889de			MOVQ BX, SI									
  tree.go:1407		0x6b048f		4989c8			MOVQ CX, R8									
  tree.go:1407		0x6b0492		488b842450020000	MOVQ 0x250(SP), AX								
  tree.go:1407		0x6b049a		488b9c2458020000	MOVQ 0x258(SP), BX								
  tree.go:1407		0x6b04a2		488b8c2460020000	MOVQ 0x260(SP), CX								
  tree.go:1407		0x6b04aa		e8117cffff		CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)			
  tree.go:1407		0x6b04af		4885c0			TESTQ AX, AX									
  tree.go:1407		0x6b04b2		0f8ca9010000		JL 0x6b0661									
  tree.go:1410		0x6b04b8		488b742470		MOVQ 0x70(SP), SI								
  tree.go:1410		0x6b04bd		488bbc2420020000	MOVQ 0x220(SP), DI								
  tree.go:1410		0x6b04c5		4c8b442478		MOVQ 0x78(SP), R8								
  tree.go:1410		0x6b04ca		4885f6			TESTQ SI, SI									
  tree.go:1410		0x6b04cd		7426			JE 0x6b04f5									
  tree.go:1410		0x6b04cf		488b842450020000	MOVQ 0x250(SP), AX								
  tree.go:1410		0x6b04d7		488b9c2458020000	MOVQ 0x258(SP), BX								
  tree.go:1410		0x6b04df		488b8c2460020000	MOVQ 0x260(SP), CX								
  tree.go:1410		0x6b04e7		e8d47bffff		CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)			
  tree.go:1410		0x6b04ec		4885c0			TESTQ AX, AX									
  tree.go:1410		0x6b04ef		0f8d30010000		JGE 0x6b0625									
  tree.go:1393		0x6b04f5		488b942480000000	MOVQ 0x80(SP), DX								
  node.go:309		0x6b04fd		90			NOPL										
  node.go:302		0x6b04fe		6683bc24f200000003	CMPW 0xf2(SP), $0x3								
  node.go:302		0x6b0507		7534			JNE 0x6b053d									
  node.go:236		0x6b0509		488bb424e0000000	MOVQ 0xe0(SP), SI								
  node.go:56		0x6b0511		4883fe0c		CMPQ SI, $0xc									
  node.go:56		0x6b0515		0f8604040000		JBE 0x6b091f									
  node.go:56		0x6b051b		0f1f440000		NOPL 0(AX)(AX*1)								
  node.go:56		0x6b0520		4883fe0d		CMPQ SI, $0xd									
  node.go:56		0x6b0524		0f86f0030000		JBE 0x6b091a									
  node.go:236		0x6b052a		488bb424d8000000	MOVQ 0xd8(SP), SI								
  node.go:56		0x6b0532		0fb7760c		MOVZX 0xc(SI), SI								
  node.go:305		0x6b0536		66f7c68000		TESTW $0x80, SI									
  tree.go:1415		0x6b053b		7554			JNE 0x6b0591									
  tree.go:1422		0x6b053d		488d8424d8000000	LEAQ 0xd8(SP), AX								
  tree.go:1422		0x6b0545		488b9c2450020000	MOVQ 0x250(SP), BX								
  tree.go:1422		0x6b054d		488b8c2458020000	MOVQ 0x258(SP), CX								
  tree.go:1422		0x6b0555		488bbc2460020000	MOVQ 0x260(SP), DI								
  tree.go:1422		0x6b055d		0f1f00			NOPL 0(AX)									
  tree.go:1422		0x6b0560		e8dba4f3ff		CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID(SB)	
  tree.go:1423		0x6b0565		4885c9			TESTQ CX, CX									
  tree.go:1423		0x6b0568		0f852e010000		JNE 0x6b069c									
  tree.go:1426		0x6b056e		488d942488000000	LEAQ 0x88(SP), DX								
  tree.go:1426		0x6b0576		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1426		0x6b057a		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1426		0x6b057f		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1426		0x6b0584		4889842490000000	MOVQ AX, 0x90(SP)								
  tree.go:1426		0x6b058c		e9d0fdffff		JMP 0x6b0361									
  tree.go:1416		0x6b0591		488d8424d8000000	LEAQ 0xd8(SP), AX								
  tree.go:1416		0x6b0599		488b9c2450020000	MOVQ 0x250(SP), BX								
  tree.go:1416		0x6b05a1		488b8c2458020000	MOVQ 0x258(SP), CX								
  tree.go:1416		0x6b05a9		488bbc2460020000	MOVQ 0x260(SP), DI								
  tree.go:1416		0x6b05b1		e8aad2f3ff		CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildRef(SB)	
  tree.go:1416		0x6b05b6		888424b0000000		MOVB AL, 0xb0(SP)								
  tree.go:1416		0x6b05bd		48899c24b8000000	MOVQ BX, 0xb8(SP)								
  tree.go:1416		0x6b05c5		898c24c0000000		MOVL CX, 0xc0(SP)								
  tree.go:1416		0x6b05cc		4889bc24c8000000	MOVQ DI, 0xc8(SP)								
  tree.go:1416		0x6b05d4		89b424d0000000		MOVL SI, 0xd0(SP)								
  tree.go:1416		0x6b05db		6644898424d4000000	MOVW R8, 0xd4(SP)								
  tree.go:1417		0x6b05e4		4d85d2			TESTQ R10, R10									
  tree.go:1417		0x6b05e7		0f85e2000000		JNE 0x6b06cf									
  tree.go:1420		0x6b05ed		488d942488000000	LEAQ 0x88(SP), DX								
  tree.go:1420		0x6b05f5		4c8da424b0000000	LEAQ 0xb0(SP), R12								
  tree.go:1420		0x6b05fd		450f103424		MOVUPS 0(R12), X14								
  tree.go:1420		0x6b0602		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1420		0x6b0606		450f10742410		MOVUPS 0x10(R12), X14								
  tree.go:1420		0x6b060c		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1420		0x6b0611		450f10742418		MOVUPS 0x18(R12), X14								
  tree.go:1420		0x6b0617		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1420		0x6b061c		0f1f4000		NOPL 0(AX)									
  tree.go:1420		0x6b0620		e93cfdffff		JMP 0x6b0361									
  tree.go:1411		0x6b0625		488d542448		LEAQ 0x48(SP), DX								
  tree.go:1411		0x6b062a		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1411		0x6b062e		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1411		0x6b0633		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1411		0x6b0638		4c8b15d1e53402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), R10		
  tree.go:1411		0x6b063f		4c8b1dd2e53402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R11		
  tree.go:1411		0x6b0646		31c0			XORL AX, AX									
  tree.go:1411		0x6b0648		31db			XORL BX, BX									
  tree.go:1411		0x6b064a		31c9			XORL CX, CX									
  tree.go:1411		0x6b064c		4889df			MOVQ BX, DI									
  tree.go:1411		0x6b064f		89ce			MOVL CX, SI									
  tree.go:1411		0x6b0651		4531c0			XORL R8, R8									
  tree.go:1411		0x6b0654		4531c9			XORL R9, R9									
  tree.go:1411		0x6b0657		4881c438020000		ADDQ $0x238, SP									
  tree.go:1411		0x6b065e		5d			POPQ BP										
  tree.go:1411		0x6b065f		90			NOPL										
  tree.go:1411		0x6b0660		c3			RET										
  tree.go:1408		0x6b0661		488d542448		LEAQ 0x48(SP), DX								
  tree.go:1408		0x6b0666		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1408		0x6b066a		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1408		0x6b066f		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1408		0x6b0674		4c8b1595e53402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), R10		
  tree.go:1408		0x6b067b		4c8b1d96e53402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R11		
  tree.go:1408		0x6b0682		31c0			XORL AX, AX									
  tree.go:1408		0x6b0684		31db			XORL BX, BX									
  tree.go:1408		0x6b0686		31c9			XORL CX, CX									
  tree.go:1408		0x6b0688		4889df			MOVQ BX, DI									
  tree.go:1408		0x6b068b		89ce			MOVL CX, SI									
  tree.go:1408		0x6b068d		4531c0			XORL R8, R8									
  tree.go:1408		0x6b0690		4531c9			XORL R9, R9									
  tree.go:1408		0x6b0693		4881c438020000		ADDQ $0x238, SP									
  tree.go:1408		0x6b069a		5d			POPQ BP										
  tree.go:1408		0x6b069b		c3			RET										
  tree.go:1424		0x6b069c		488d542448		LEAQ 0x48(SP), DX								
  tree.go:1424		0x6b06a1		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1424		0x6b06a5		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1424		0x6b06aa		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1424		0x6b06af		31c0			XORL AX, AX									
  tree.go:1424		0x6b06b1		31db			XORL BX, BX									
  tree.go:1424		0x6b06b3		31f6			XORL SI, SI									
  tree.go:1424		0x6b06b5		4531c0			XORL R8, R8									
  tree.go:1424		0x6b06b8		4531c9			XORL R9, R9									
  tree.go:1424		0x6b06bb		4989ca			MOVQ CX, R10									
  tree.go:1424		0x6b06be		4989fb			MOVQ DI, R11									
  tree.go:1424		0x6b06c1		89f1			MOVL SI, CX									
  tree.go:1424		0x6b06c3		4889df			MOVQ BX, DI									
  tree.go:1424		0x6b06c6		4881c438020000		ADDQ $0x238, SP									
  tree.go:1424		0x6b06cd		5d			POPQ BP										
  tree.go:1424		0x6b06ce		c3			RET										
  tree.go:1418		0x6b06cf		488d542448		LEAQ 0x48(SP), DX								
  tree.go:1418		0x6b06d4		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1418		0x6b06d8		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1418		0x6b06dd		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1418		0x6b06e2		31c0			XORL AX, AX									
  tree.go:1418		0x6b06e4		31db			XORL BX, BX									
  tree.go:1418		0x6b06e6		31c9			XORL CX, CX									
  tree.go:1418		0x6b06e8		4889df			MOVQ BX, DI									
  tree.go:1418		0x6b06eb		89ce			MOVL CX, SI									
  tree.go:1418		0x6b06ed		4531c0			XORL R8, R8									
  tree.go:1418		0x6b06f0		4531c9			XORL R9, R9									
  tree.go:1418		0x6b06f3		4881c438020000		ADDQ $0x238, SP									
  tree.go:1418		0x6b06fa		5d			POPQ BP										
  tree.go:1418		0x6b06fb		c3			RET										
  tree.go:1405		0x6b06fc		488d542448		LEAQ 0x48(SP), DX								
  tree.go:1405		0x6b0701		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1405		0x6b0705		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1405		0x6b070a		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1405		0x6b070f		31c0			XORL AX, AX									
  tree.go:1405		0x6b0711		31db			XORL BX, BX									
  tree.go:1405		0x6b0713		31c9			XORL CX, CX									
  tree.go:1405		0x6b0715		4889df			MOVQ BX, DI									
  tree.go:1405		0x6b0718		89ce			MOVL CX, SI									
  tree.go:1405		0x6b071a		4531c0			XORL R8, R8									
  tree.go:1405		0x6b071d		4531c9			XORL R9, R9									
  tree.go:1405		0x6b0720		4881c438020000		ADDQ $0x238, SP									
  tree.go:1405		0x6b0727		5d			POPQ BP										
  tree.go:1405		0x6b0728		c3			RET										
  tree.go:1428		0x6b0729		6683f804		CMPW AX, $0x4									
  tree.go:1428		0x6b072d		0f84ae000000		JE 0x6b07e1									
  tree.go:1431		0x6b0733		440f11bc2428020000	MOVUPS X15, 0x228(SP)								
  tree.go:1431		0x6b073c		0f1f4000		NOPL 0(AX)									
  tree.go:1431		0x6b0740		e8bb05d7ff		CALL runtime.convT16(SB)							
  tree.go:1431		0x6b0745		488d0db45e2701		LEAQ 0x1275eb4(IP), CX								
  tree.go:1431		0x6b074c		48898c2428020000	MOVQ CX, 0x228(SP)								
  tree.go:1431		0x6b0754		4889842430020000	MOVQ AX, 0x230(SP)								
  errors.go:26		0x6b075c		488d05b7f24601		LEAQ 0x146f2b7(IP), AX								
  errors.go:26		0x6b0763		bb14000000		MOVL $0x14, BX									
  errors.go:26		0x6b0768		488d8c2428020000	LEAQ 0x228(SP), CX								
  errors.go:26		0x6b0770		bf01000000		MOVL $0x1, DI									
  errors.go:26		0x6b0775		4889fe			MOVQ DI, SI									
  errors.go:26		0x6b0778		e88321e5ff		CALL fmt.errorf(SB)								
  errors.go:26		0x6b077d		0f1f00			NOPL 0(AX)									
  errors.go:26		0x6b0780		4885c0			TESTQ AX, AX									
  errors.go:26		0x6b0783		7529			JNE 0x6b07ae									
  errors.go:31		0x6b0785		90			NOPL										
  errors.go:65		0x6b0786		488d05936a2f01		LEAQ 0x12f6a93(IP), AX								
  errors.go:65		0x6b078d		e80e43d7ff		CALL runtime.newobject(SB)							
  errors.go:65		0x6b0792		48c7400814000000	MOVQ $0x14, 0x8(AX)								
  errors.go:65		0x6b079a		488d0d79f24601		LEAQ 0x146f279(IP), CX								
  errors.go:65		0x6b07a1		488908			MOVQ CX, 0(AX)									
  tree.go:1431		0x6b07a4		4889c3			MOVQ AX, BX									
  tree.go:1431		0x6b07a7		488d0532db5901		LEAQ go:itab.*errors.errorString,error(SB), AX					
  tree.go:1431		0x6b07ae		488d542448		LEAQ 0x48(SP), DX								
  tree.go:1431		0x6b07b3		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1431		0x6b07b7		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1431		0x6b07bc		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1431		0x6b07c1		31c9			XORL CX, CX									
  tree.go:1431		0x6b07c3		31ff			XORL DI, DI									
  tree.go:1431		0x6b07c5		89ce			MOVL CX, SI									
  tree.go:1431		0x6b07c7		4531c0			XORL R8, R8									
  tree.go:1431		0x6b07ca		4531c9			XORL R9, R9									
  tree.go:1431		0x6b07cd		4989c2			MOVQ AX, R10									
  tree.go:1431		0x6b07d0		4989db			MOVQ BX, R11									
  tree.go:1431		0x6b07d3		31c0			XORL AX, AX									
  tree.go:1431		0x6b07d5		4889fb			MOVQ DI, BX									
  tree.go:1431		0x6b07d8		4881c438020000		ADDQ $0x238, SP									
  tree.go:1431		0x6b07df		5d			POPQ BP										
  tree.go:1431		0x6b07e0		c3			RET										
  tree.go:1429		0x6b07e1		488d542448		LEAQ 0x48(SP), DX								
  tree.go:1429		0x6b07e6		4c8da42488000000	LEAQ 0x88(SP), R12								
  tree.go:1429		0x6b07ee		450f103424		MOVUPS 0(R12), X14								
  tree.go:1429		0x6b07f3		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1429		0x6b07f7		450f10742410		MOVUPS 0x10(R12), X14								
  tree.go:1429		0x6b07fd		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1429		0x6b0802		450f10742418		MOVUPS 0x18(R12), X14								
  tree.go:1429		0x6b0808		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1429		0x6b080d		0fb6442448		MOVZX 0x48(SP), AX								
  tree.go:1429		0x6b0812		488b5c2450		MOVQ 0x50(SP), BX								
  tree.go:1429		0x6b0817		8b4c2458		MOVL 0x58(SP), CX								
  tree.go:1429		0x6b081b		488b7c2460		MOVQ 0x60(SP), DI								
  tree.go:1429		0x6b0820		8b742468		MOVL 0x68(SP), SI								
  tree.go:1429		0x6b0824		440fb744246c		MOVZX 0x6c(SP), R8								
  tree.go:1429		0x6b082a		4531c9			XORL R9, R9									
  tree.go:1429		0x6b082d		4531d2			XORL R10, R10									
  tree.go:1429		0x6b0830		4531db			XORL R11, R11									
  tree.go:1429		0x6b0833		4881c438020000		ADDQ $0x238, SP									
  tree.go:1429		0x6b083a		5d			POPQ BP										
  tree.go:1429		0x6b083b		c3			RET										
  tree.go:1399		0x6b083c		488d542448		LEAQ 0x48(SP), DX								
  tree.go:1399		0x6b0841		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1399		0x6b0845		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1399		0x6b084a		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1399		0x6b084f		31c9			XORL CX, CX									
  tree.go:1399		0x6b0851		31ff			XORL DI, DI									
  tree.go:1399		0x6b0853		89ce			MOVL CX, SI									
  tree.go:1399		0x6b0855		4531c0			XORL R8, R8									
  tree.go:1399		0x6b0858		4531c9			XORL R9, R9									
  tree.go:1399		0x6b085b		4989c2			MOVQ AX, R10									
  tree.go:1399		0x6b085e		4989db			MOVQ BX, R11									
  tree.go:1399		0x6b0861		31c0			XORL AX, AX									
  tree.go:1399		0x6b0863		4889fb			MOVQ DI, BX									
  tree.go:1399		0x6b0866		4881c438020000		ADDQ $0x238, SP									
  tree.go:1399		0x6b086d		5d			POPQ BP										
  tree.go:1399		0x6b086e		c3			RET										
  tree.go:1395		0x6b086f		488d542448		LEAQ 0x48(SP), DX								
  tree.go:1395		0x6b0874		450f103424		MOVUPS 0(R12), X14								
  tree.go:1395		0x6b0879		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1395		0x6b087d		450f10742410		MOVUPS 0x10(R12), X14								
  tree.go:1395		0x6b0883		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1395		0x6b0888		450f10742418		MOVUPS 0x18(R12), X14								
  tree.go:1395		0x6b088e		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1395		0x6b0893		0fb6442448		MOVZX 0x48(SP), AX								
  tree.go:1395		0x6b0898		488b5c2450		MOVQ 0x50(SP), BX								
  tree.go:1395		0x6b089d		8b4c2458		MOVL 0x58(SP), CX								
  tree.go:1395		0x6b08a1		488b7c2460		MOVQ 0x60(SP), DI								
  tree.go:1395		0x6b08a6		8b742468		MOVL 0x68(SP), SI								
  tree.go:1395		0x6b08aa		440fb744246c		MOVZX 0x6c(SP), R8								
  tree.go:1395		0x6b08b0		41b901000000		MOVL $0x1, R9									
  tree.go:1395		0x6b08b6		4531d2			XORL R10, R10									
  tree.go:1395		0x6b08b9		4531db			XORL R11, R11									
  tree.go:1395		0x6b08bc		4881c438020000		ADDQ $0x238, SP									
  tree.go:1395		0x6b08c3		5d			POPQ BP										
  tree.go:1395		0x6b08c4		c3			RET										
  errors.go:65		0x6b08c5		488d0554692f01		LEAQ 0x12f6954(IP), AX								
  errors.go:65		0x6b08cc		e8cf41d7ff		CALL runtime.newobject(SB)							
  errors.go:65		0x6b08d1		48c740080d000000	MOVQ $0xd, 0x8(AX)								
  errors.go:65		0x6b08d9		488d0da31b4601		LEAQ 0x1461ba3(IP), CX								
  errors.go:65		0x6b08e0		488908			MOVQ CX, 0(AX)									
  tree.go:1434		0x6b08e3		488d4c2448		LEAQ 0x48(SP), CX								
  tree.go:1434		0x6b08e8		440f1139		MOVUPS X15, 0(CX)								
  tree.go:1434		0x6b08ec		440f117910		MOVUPS X15, 0x10(CX)								
  tree.go:1434		0x6b08f1		440f117918		MOVUPS X15, 0x18(CX)								
  tree.go:1434		0x6b08f6		31db			XORL BX, BX									
  tree.go:1434		0x6b08f8		31c9			XORL CX, CX									
  tree.go:1434		0x6b08fa		4889df			MOVQ BX, DI									
  tree.go:1434		0x6b08fd		89ce			MOVL CX, SI									
  tree.go:1434		0x6b08ff		4531c0			XORL R8, R8									
  tree.go:1434		0x6b0902		4531c9			XORL R9, R9									
  tree.go:1434		0x6b0905		4c8d15d4d95901		LEAQ go:itab.*errors.errorString,error(SB), R10					
  tree.go:1434		0x6b090c		4989c3			MOVQ AX, R11									
  tree.go:1434		0x6b090f		31c0			XORL AX, AX									
  tree.go:1434		0x6b0911		4881c438020000		ADDQ $0x238, SP									
  tree.go:1434		0x6b0918		5d			POPQ BP										
  tree.go:1434		0x6b0919		c3			RET										
  node.go:56		0x6b091a		e8a13cdeff		CALL runtime.panicBounds(SB)							
  node.go:56		0x6b091f		90			NOPL										
  node.go:56		0x6b0920		e89b3cdeff		CALL runtime.panicBounds(SB)							
  node.go:56		0x6b0925		90			NOPL										
  tree.go:1385		0x6b0926		4889442408		MOVQ AX, 0x8(SP)								
  tree.go:1385		0x6b092b		48895c2410		MOVQ BX, 0x10(SP)								
  tree.go:1385		0x6b0930		48894c2418		MOVQ CX, 0x18(SP)								
  tree.go:1385		0x6b0935		48897c2420		MOVQ DI, 0x20(SP)								
  tree.go:1385		0x6b093a		4088742428		MOVB SI, 0x28(SP)								
  tree.go:1385		0x6b093f		90			NOPL										
  tree.go:1385		0x6b0940		e8db1ddeff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1385		0x6b0945		488b442408		MOVQ 0x8(SP), AX								
  tree.go:1385		0x6b094a		488b5c2410		MOVQ 0x10(SP), BX								
  tree.go:1385		0x6b094f		488b4c2418		MOVQ 0x18(SP), CX								
  tree.go:1385		0x6b0954		488b7c2420		MOVQ 0x20(SP), DI								
  tree.go:1385		0x6b0959		0fb6742428		MOVZX 0x28(SP), SI								
  tree.go:1385		0x6b095e		6690			NOPW										
  tree.go:1385		0x6b0960		e9bbf8ffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).findLeafRefForGetMany(SB)	

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:62	0x8495a0		4c8d6424d8		LEAQ -0x28(SP), R12											
  registry.go:62	0x8495a5		4d3b6610		CMPQ R12, 0x10(R14)											
  registry.go:62	0x8495a9		0f86f7020000		JBE 0x8498a6												
  registry.go:62	0x8495af		55			PUSHQ BP												
  registry.go:62	0x8495b0		4889e5			MOVQ SP, BP												
  registry.go:62	0x8495b3		4881eca0000000		SUBQ $0xa0, SP												
  registry.go:62	0x8495ba		66440fd6bc2498000000	MOVQ X15, 0x98(SP)											
  registry.go:62	0x8495c4		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:62	0x8495c9		48c744245000000000	MOVQ $0x0, 0x50(SP)											
  registry.go:62	0x8495d2		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  registry.go:62	0x8495db		0f1f440000		NOPL 0(AX)(AX*1)											
  registry.go:63	0x8495e0		4885c9			TESTQ CX, CX												
  registry.go:63	0x8495e3		7d13			JGE 0x8495f8												
  type.go:195		0x8495e5		ba01000000		MOVL $0x1, DX												
  type.go:195		0x8495ea		f0480fc19048040000	LOCK XADDQ DX, 0x448(AX)										
  registry.go:64	0x8495f3		83e20f			ANDL $0xf, DX												
  registry.go:64	0x8495f6		eb06			JMP 0x8495fe												
  registry.go:66	0x8495f8		83e10f			ANDL $0xf, CX												
  registry.go:75	0x8495fb		4889ca			MOVQ CX, DX												
  registry.go:63	0x8495fe		48898424b0000000	MOVQ AX, 0xb0(SP)											
  registry.go:63	0x849606		48899c24b8000000	MOVQ BX, 0xb8(SP)											
  registry.go:75	0x84960e		4889942480000000	MOVQ DX, 0x80(SP)											
  registry.go:75	0x849616		4889d1			MOVQ DX, CX												
  registry.go:75	0x849619		e8a2090000		CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryJoinFast(SB)				
  registry.go:75	0x84961e		6690			NOPW													
  registry.go:75	0x849620		4885c0			TESTQ AX, AX												
  registry.go:75	0x849623		7560			JNE 0x849685												
  registry.go:79	0x849625		90			NOPL													
  mutex.go:46		0x849626		90			NOPL													
  mutex.go:63		0x849627		31c0			XORL AX, AX												
  mutex.go:63		0x849629		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  mutex.go:63		0x849631		41b901000000		MOVL $0x1, R9												
  mutex.go:63		0x849637		f0450fb108		LOCK CMPXCHGL R9, 0(R8)											
  mutex.go:63		0x84963c		410f94c1		SETE R9													
  mutex.go:63		0x849640		4584c9			TESTL R9, R9												
  mutex.go:63		0x849643		7510			JNE 0x849655												
  mutex.go:70		0x849645		4c89c0			MOVQ R8, AX												
  mutex.go:70		0x849648		e8132ac5ff		CALL internal/sync.(*Mutex).lockSlow(SB)								
  registry.go:80	0x84964d		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  registry.go:80	0x849655		4c8d0d84020000		LEAQ github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint.deferwrap1(SB), R9	
  registry.go:80	0x84965c		4c898c2488000000	MOVQ R9, 0x88(SP)											
  registry.go:80	0x849664		4c89842490000000	MOVQ R8, 0x90(SP)											
  registry.go:80	0x84966c		4c8d8c2488000000	LEAQ 0x88(SP), R9											
  registry.go:80	0x849674		4c898c2498000000	MOVQ R9, 0x98(SP)											
  registry.go:80	0x84967c		c644244701		MOVB $0x1, 0x47(SP)											
  registry.go:80	0x849681		31c0			XORL AX, AX												
  registry.go:82	0x849683		eb2c			JMP 0x8496b1												
  registry.go:76	0x849685		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:76	0x84968a		488b9c2480000000	MOVQ 0x80(SP), BX											
  registry.go:76	0x849692		48895c2448		MOVQ BX, 0x48(SP)											
  registry.go:76	0x849697		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:76	0x84969e		5d			POPQ BP													
  registry.go:76	0x84969f		90			NOPL													
  registry.go:76	0x8496a0		c3			RET													
  registry.go:82	0x8496a1		488b442470		MOVQ 0x70(SP), AX											
  registry.go:82	0x8496a6		48ffc0			INCQ AX													
  registry.go:84	0x8496a9		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  registry.go:82	0x8496b1		4883f810		CMPQ AX, $0x10												
  registry.go:82	0x8496b5		7d67			JGE 0x84971e												
  registry.go:82	0x8496b7		4889442470		MOVQ AX, 0x70(SP)											
  registry.go:83	0x8496bc		488b942480000000	MOVQ 0x80(SP), DX											
  registry.go:83	0x8496c4		488d0c10		LEAQ 0(AX)(DX*1), CX											
  registry.go:83	0x8496c8		83e10f			ANDL $0xf, CX												
  registry.go:83	0x8496cb		48894c2460		MOVQ CX, 0x60(SP)											
  registry.go:84	0x8496d0		4c89c0			MOVQ R8, AX												
  registry.go:84	0x8496d3		488b9c24b8000000	MOVQ 0xb8(SP), BX											
  registry.go:84	0x8496db		0f1f440000		NOPL 0(AX)(AX*1)											
  registry.go:84	0x8496e0		e8db080000		CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryJoinFast(SB)				
  registry.go:84	0x8496e5		4885c0			TESTQ AX, AX												
  registry.go:84	0x8496e8		74b7			JE 0x8496a1												
  registry.go:85	0x8496ea		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:85	0x8496ef		488b442460		MOVQ 0x60(SP), AX											
  registry.go:85	0x8496f4		4889442448		MOVQ AX, 0x48(SP)											
  registry.go:85	0x8496f9		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:85	0x8496fe		488b942498000000	MOVQ 0x98(SP), DX											
  registry.go:85	0x849706		488b02			MOVQ 0(DX), AX												
  registry.go:85	0x849709		ffd0			CALL AX													
  registry.go:85	0x84970b		488b442450		MOVQ 0x50(SP), AX											
  registry.go:85	0x849710		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:85	0x849715		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:85	0x84971c		5d			POPQ BP													
  registry.go:85	0x84971d		c3			RET													
  registry.go:85	0x84971e		31c0			XORL AX, AX												
  registry.go:82	0x849720		eb10			JMP 0x849732												
  registry.go:88	0x849722		488b442468		MOVQ 0x68(SP), AX											
  registry.go:88	0x849727		48ffc0			INCQ AX													
  registry.go:90	0x84972a		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  registry.go:88	0x849732		4883f810		CMPQ AX, $0x10												
  registry.go:88	0x849736		7d66			JGE 0x84979e												
  registry.go:88	0x849738		4889442468		MOVQ AX, 0x68(SP)											
  registry.go:89	0x84973d		488b942480000000	MOVQ 0x80(SP), DX											
  registry.go:89	0x849745		488d0c10		LEAQ 0(AX)(DX*1), CX											
  registry.go:89	0x849749		83e10f			ANDL $0xf, CX												
  registry.go:89	0x84974c		48894c2458		MOVQ CX, 0x58(SP)											
  registry.go:90	0x849751		4c89c0			MOVQ R8, AX												
  registry.go:90	0x849754		488b9c24b8000000	MOVQ 0xb8(SP), BX											
  registry.go:90	0x84975c		0f1f4000		NOPL 0(AX)												
  registry.go:90	0x849760		e8fb080000		CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryClaimFast(SB)			
  registry.go:90	0x849765		4885c0			TESTQ AX, AX												
  registry.go:90	0x849768		74b8			JE 0x849722												
  registry.go:91	0x84976a		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:91	0x84976f		488b442458		MOVQ 0x58(SP), AX											
  registry.go:91	0x849774		4889442448		MOVQ AX, 0x48(SP)											
  registry.go:91	0x849779		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:91	0x84977e		488b942498000000	MOVQ 0x98(SP), DX											
  registry.go:91	0x849786		488b02			MOVQ 0(DX), AX												
  registry.go:91	0x849789		ffd0			CALL AX													
  registry.go:91	0x84978b		488b442450		MOVQ 0x50(SP), AX											
  registry.go:91	0x849790		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:91	0x849795		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:91	0x84979c		5d			POPQ BP													
  registry.go:91	0x84979d		c3			RET													
  registry.go:96	0x84979e		4d8b4828		MOVQ 0x28(R8), R9											
  registry.go:96	0x8497a2		4d85c9			TESTQ R9, R9												
  registry.go:96	0x8497a5		7416			JE 0x8497bd												
  registry.go:96	0x8497a7		498b4020		MOVQ 0x20(R8), AX											
  registry.go:97	0x8497ab		498d49ff		LEAQ -0x1(R9), CX											
  registry.go:97	0x8497af		4a8b44c8f8		MOVQ -0x8(AX)(R9*8), AX											
  registry.go:98	0x8497b4		49894828		MOVQ CX, 0x28(R8)											
  registry.go:103	0x8497b8		4889c3			MOVQ AX, BX												
  registry.go:98	0x8497bb		eb71			JMP 0x84982e												
  registry.go:100	0x8497bd		498b5810		MOVQ 0x10(R8), BX											
  registry.go:100	0x8497c1		498b4818		MOVQ 0x18(R8), CX											
  registry.go:101	0x8497c5		4c8d4b01		LEAQ 0x1(BX), R9											
  registry.go:100	0x8497c9		498b4008		MOVQ 0x8(R8), AX											
  registry.go:101	0x8497cd		4c39c9			CMPQ CX, R9												
  registry.go:101	0x8497d0		734f			JAE 0x849821												
  registry.go:100	0x8497d2		48895c2478		MOVQ BX, 0x78(SP)											
  registry.go:101	0x8497d7		4c89cb			MOVQ R9, BX												
  registry.go:101	0x8497da		bf01000000		MOVL $0x1, DI												
  registry.go:101	0x8497df		488d351ac20d01		LEAQ 0x10dc21a(IP), SI											
  registry.go:101	0x8497e6		e85555c4ff		CALL runtime.growslice(SB)										
  registry.go:101	0x8497eb		488b9424b0000000	MOVQ 0xb0(SP), DX											
  registry.go:101	0x8497f3		48894a18		MOVQ CX, 0x18(DX)											
  registry.go:101	0x8497f7		833df2fe2c0200		CMPL runtime.writeBarrier(SB), $0x0									
  registry.go:101	0x8497fe		6690			NOPW													
  registry.go:101	0x849800		7410			JE 0x849812												
  registry.go:101	0x849802		488b4a08		MOVQ 0x8(DX), CX											
  registry.go:101	0x849806		e815aac4ff		CALL runtime.gcWriteBarrier2(SB)									
  registry.go:101	0x84980b		498903			MOVQ AX, 0(R11)												
  registry.go:101	0x84980e		49894b08		MOVQ CX, 0x8(R11)											
  registry.go:101	0x849812		48894208		MOVQ AX, 0x8(DX)											
  registry.go:101	0x849816		4989d0			MOVQ DX, R8												
  registry.go:101	0x849819		4989d9			MOVQ BX, R9												
  registry.go:103	0x84981c		488b5c2478		MOVQ 0x78(SP), BX											
  registry.go:101	0x849821		4d894810		MOVQ R9, 0x10(R8)											
  registry.go:101	0x849825		4ac744c8f8ffffffff	MOVQ $-0x1, -0x8(AX)(R9*8)										
  registry.go:103	0x84982e		498b4010		MOVQ 0x10(R8), AX											
  registry.go:103	0x849832		4839c3			CMPQ BX, AX												
  registry.go:103	0x849835		7351			JAE 0x849888												
  registry.go:103	0x849837		498b4008		MOVQ 0x8(R8), AX											
  registry.go:103	0x84983b		488b8c24b8000000	MOVQ 0xb8(SP), CX											
  registry.go:103	0x849843		48890cd8		MOVQ CX, 0(AX)(BX*8)											
  registry.go:104	0x849847		49394838		CMPQ 0x38(R8), CX											
  registry.go:104	0x84984b		7604			JBE 0x849851												
  registry.go:105	0x84984d		49894838		MOVQ CX, 0x38(R8)											
  registry.go:107	0x849851		488d4301		LEAQ 0x1(BX), AX											
  registry.go:107	0x849855		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:107	0x84985a		48c7442448ffffffff	MOVQ $-0x1, 0x48(SP)											
  registry.go:107	0x849863		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:107	0x849868		488b942498000000	MOVQ 0x98(SP), DX											
  registry.go:107	0x849870		488b02			MOVQ 0(DX), AX												
  registry.go:107	0x849873		ffd0			CALL AX													
  registry.go:107	0x849875		488b442450		MOVQ 0x50(SP), AX											
  registry.go:107	0x84987a		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:107	0x84987f		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:107	0x849886		5d			POPQ BP													
  registry.go:107	0x849887		c3			RET													
  registry.go:103	0x849888		e833adc4ff		CALL runtime.panicBounds(SB)										
  registry.go:103	0x84988d		90			NOPL													
  registry.go:103	0x84988e		e88d77c0ff		CALL runtime.deferreturn(SB)										
  registry.go:103	0x849893		488b442450		MOVQ 0x50(SP), AX											
  registry.go:103	0x849898		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:103	0x84989d		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:103	0x8498a4		5d			POPQ BP													
  registry.go:103	0x8498a5		c3			RET													
  registry.go:62	0x8498a6		4889442408		MOVQ AX, 0x8(SP)											
  registry.go:62	0x8498ab		48895c2410		MOVQ BX, 0x10(SP)											
  registry.go:62	0x8498b0		48894c2418		MOVQ CX, 0x18(SP)											
  registry.go:62	0x8498b5		e8668ec4ff		CALL runtime.morestack_noctxt.abi0(SB)									
  registry.go:62	0x8498ba		488b442408		MOVQ 0x8(SP), AX											
  registry.go:62	0x8498bf		488b5c2410		MOVQ 0x10(SP), BX											
  registry.go:62	0x8498c4		488b4c2418		MOVQ 0x18(SP), CX											
  registry.go:62	0x8498c9		e9d2fcffff		JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint(SB)			

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint.deferwrap1(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:80	0x8498e0		493b6610		CMPQ SP, 0x10(R14)										
  registry.go:80	0x8498e4		7629			JBE 0x84990f											
  registry.go:80	0x8498e6		55			PUSHQ BP											
  registry.go:80	0x8498e7		4889e5			MOVQ SP, BP											
  registry.go:80	0x8498ea		4883ec10		SUBQ $0x10, SP											
  registry.go:80	0x8498ee		488b4208		MOVQ 0x8(DX), AX										
  mutex.go:65		0x8498f2		90			NOPL												
  mutex.go:194		0x8498f3		bbffffffff		MOVL $-0x1, BX											
  mutex.go:194		0x8498f8		f00fc118		LOCK XADDL BX, 0(AX)										
  mutex.go:194		0x8498fc		0f1f4000		NOPL 0(AX)											
  mutex.go:194		0x849900		ffcb			DECL BX												
  mutex.go:195		0x849902		7405			JE 0x849909											
  mutex.go:198		0x849904		e8372ac5ff		CALL internal/sync.(*Mutex).unlockSlow(SB)							
  registry.go:80	0x849909		4883c410		ADDQ $0x10, SP											
  registry.go:80	0x84990d		5d			POPQ BP												
  registry.go:80	0x84990e		c3			RET												
  registry.go:80	0x84990f		e86c8dc4ff		CALL runtime.morestack.abi0(SB)									
  registry.go:80	0x849914		ebca			JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:140	0x849ba0		493b6610		CMPQ SP, 0x10(R14)										
  registry.go:140	0x849ba4		0f86cd010000		JBE 0x849d77											
  registry.go:140	0x849baa		55			PUSHQ BP											
  registry.go:140	0x849bab		4889e5			MOVQ SP, BP											
  registry.go:140	0x849bae		4883ec70		SUBQ $0x70, SP											
  registry.go:140	0x849bb2		66440fd67c2468		MOVQ X15, 0x68(SP)										
  registry.go:140	0x849bb9		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:140	0x849bbe		6690			NOPW												
  registry.go:141	0x849bc0		4885db			TESTQ BX, BX											
  registry.go:141	0x849bc3		7d42			JGE 0x849c07											
  registry.go:142	0x849bc5		488d4b01		LEAQ 0x1(BX), CX										
  registry.go:142	0x849bc9		48f7d9			NEGQ CX												
  registry.go:143	0x849bcc		4883f910		CMPQ CX, $0x10											
  registry.go:143	0x849bd0		7d2f			JGE 0x849c01											
  registry.go:146	0x849bd2		8400			TESTB AL, 0(AX)											
  registry.go:146	0x849bd4		48c1e106		SHLQ $0x6, CX											
  type.go:94		0x849bd8		488d0401		LEAQ 0(CX)(AX*1), AX										
  type.go:94		0x849bdc		488d4050		LEAQ 0x50(AX), AX										
  type.go:94		0x849be0		b9ffffffff		MOVL $-0x1, CX											
  type.go:94		0x849be5		f00fc108		LOCK XADDL CX, 0(AX)										
  type.go:94		0x849be9		ffc9			DECL CX												
  registry.go:147	0x849beb		85c9			TESTL CX, CX											
  registry.go:147	0x849bed		7c06			JL 0x849bf5											
  registry.go:148	0x849bef		4883c470		ADDQ $0x70, SP											
  registry.go:148	0x849bf3		5d			POPQ BP												
  registry.go:148	0x849bf4		c3			RET												
  registry.go:151	0x849bf5		90			NOPL												
  type.go:83		0x849bf6		31c9			XORL CX, CX											
  type.go:83		0x849bf8		8708			XCHGL CX, 0(AX)											
  registry.go:152	0x849bfa		4883c470		ADDQ $0x70, SP											
  registry.go:152	0x849bfe		5d			POPQ BP												
  registry.go:152	0x849bff		90			NOPL												
  registry.go:152	0x849c00		c3			RET												
  registry.go:144	0x849c01		4883c470		ADDQ $0x70, SP											
  registry.go:144	0x849c05		5d			POPQ BP												
  registry.go:144	0x849c06		c3			RET												
  registry.go:141	0x849c07		4889842480000000	MOVQ AX, 0x80(SP)										
  registry.go:155	0x849c0f		90			NOPL												
  registry.go:141	0x849c10		4889c1			MOVQ AX, CX											
  mutex.go:63		0x849c13		31c0			XORL AX, AX											
  mutex.go:63		0x849c15		41b801000000		MOVL $0x1, R8											
  mutex.go:63		0x849c1b		f0440fb101		LOCK CMPXCHGL R8, 0(CX)										
  mutex.go:63		0x849c20		410f94c0		SETE R8												
  mutex.go:63		0x849c24		4584c0			TESTL R8, R8											
  mutex.go:63		0x849c27		7405			JE 0x849c2e											
  registry.go:141	0x849c29		4885db			TESTQ BX, BX											
  mutex.go:46		0x849c2c		eb26			JMP 0x849c54											
  registry.go:141	0x849c2e		48899c2488000000	MOVQ BX, 0x88(SP)										
  mutex.go:70		0x849c36		4889c8			MOVQ CX, AX											
  mutex.go:70		0x849c39		e82224c5ff		CALL internal/sync.(*Mutex).lockSlow(SB)							
  registry.go:141	0x849c3e		488b8c2488000000	MOVQ 0x88(SP), CX										
  registry.go:141	0x849c46		4885c9			TESTQ CX, CX											
  registry.go:161	0x849c49		4889cb			MOVQ CX, BX											
  registry.go:156	0x849c4c		488b8c2480000000	MOVQ 0x80(SP), CX										
  registry.go:156	0x849c54		4c8d0545010000		LEAQ github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister.deferwrap1(SB), R8	
  registry.go:156	0x849c5b		4c89442458		MOVQ R8, 0x58(SP)										
  registry.go:156	0x849c60		48894c2460		MOVQ CX, 0x60(SP)										
  registry.go:156	0x849c65		488d542458		LEAQ 0x58(SP), DX										
  registry.go:156	0x849c6a		4889542468		MOVQ DX, 0x68(SP)										
  registry.go:156	0x849c6f		c644244701		MOVB $0x1, 0x47(SP)										
  registry.go:158	0x849c74		0f8ee0000000		JLE 0x849d5a											
  registry.go:161	0x849c7a		4c8d43ff		LEAQ -0x1(BX), R8										
  registry.go:161	0x849c7e		6690			NOPW												
  registry.go:162	0x849c80		4c394110		CMPQ 0x10(CX), R8										
  registry.go:162	0x849c84		0f8ebe000000		JLE 0x849d48											
  registry.go:162	0x849c8a		4c8b4908		MOVQ 0x8(CX), R9										
  registry.go:165	0x849c8e		4d8b54d9f8		MOVQ -0x8(R9)(BX*8), R10									
  registry.go:166	0x849c93		4983faff		CMPQ R10, $-0x1											
  registry.go:166	0x849c97		0f8499000000		JE 0x849d36											
  registry.go:169	0x849c9d		49c744d9f8ffffffff	MOVQ $-0x1, -0x8(R9)(BX*8)									
  registry.go:170	0x849ca6		4c8b4930		MOVQ 0x30(CX), R9										
  registry.go:170	0x849caa		488b5928		MOVQ 0x28(CX), BX										
  registry.go:170	0x849cae		48ffc3			INCQ BX												
  registry.go:170	0x849cb1		488b4120		MOVQ 0x20(CX), AX										
  registry.go:170	0x849cb5		4939d9			CMPQ R9, BX											
  registry.go:170	0x849cb8		7354			JAE 0x849d0e											
  registry.go:161	0x849cba		4c89442450		MOVQ R8, 0x50(SP)										
  registry.go:165	0x849cbf		4c89542448		MOVQ R10, 0x48(SP)										
  registry.go:170	0x849cc4		4c89c9			MOVQ R9, CX											
  registry.go:170	0x849cc7		bf01000000		MOVL $0x1, DI											
  registry.go:170	0x849ccc		488d356dbd0d01		LEAQ 0x10dbd6d(IP), SI										
  registry.go:170	0x849cd3		e86850c4ff		CALL runtime.growslice(SB)									
  registry.go:170	0x849cd8		488b942480000000	MOVQ 0x80(SP), DX										
  registry.go:170	0x849ce0		48894a30		MOVQ CX, 0x30(DX)										
  registry.go:170	0x849ce4		833d05fa2c0200		CMPL runtime.writeBarrier(SB), $0x0								
  registry.go:170	0x849ceb		7410			JE 0x849cfd											
  registry.go:170	0x849ced		488b4a20		MOVQ 0x20(DX), CX										
  registry.go:170	0x849cf1		e82aa5c4ff		CALL runtime.gcWriteBarrier2(SB)								
  registry.go:170	0x849cf6		498903			MOVQ AX, 0(R11)											
  registry.go:170	0x849cf9		49894b08		MOVQ CX, 0x8(R11)										
  registry.go:170	0x849cfd		48894220		MOVQ AX, 0x20(DX)										
  registry.go:170	0x849d01		4889d1			MOVQ DX, CX											
  registry.go:170	0x849d04		4c8b442450		MOVQ 0x50(SP), R8										
  registry.go:171	0x849d09		4c8b542448		MOVQ 0x48(SP), R10										
  registry.go:170	0x849d0e		48895928		MOVQ BX, 0x28(CX)										
  registry.go:170	0x849d12		4c8944d8f8		MOVQ R8, -0x8(AX)(BX*8)										
  registry.go:171	0x849d17		4c395138		CMPQ 0x38(CX), R10										
  registry.go:171	0x849d1b		7504			JNE 0x849d21											
  registry.go:172	0x849d1d		c6414001		MOVB $0x1, 0x40(CX)										
  registry.go:174	0x849d21		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:174	0x849d26		488b542468		MOVQ 0x68(SP), DX										
  registry.go:174	0x849d2b		488b02			MOVQ 0(DX), AX											
  registry.go:174	0x849d2e		ffd0			CALL AX												
  registry.go:174	0x849d30		4883c470		ADDQ $0x70, SP											
  registry.go:174	0x849d34		5d			POPQ BP												
  registry.go:174	0x849d35		c3			RET												
  registry.go:167	0x849d36		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:167	0x849d3b		488b442458		MOVQ 0x58(SP), AX										
  registry.go:167	0x849d40		ffd0			CALL AX												
  registry.go:167	0x849d42		4883c470		ADDQ $0x70, SP											
  registry.go:167	0x849d46		5d			POPQ BP												
  registry.go:167	0x849d47		c3			RET												
  registry.go:163	0x849d48		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:163	0x849d4d		488b442458		MOVQ 0x58(SP), AX										
  registry.go:163	0x849d52		ffd0			CALL AX												
  registry.go:163	0x849d54		4883c470		ADDQ $0x70, SP											
  registry.go:163	0x849d58		5d			POPQ BP												
  registry.go:163	0x849d59		c3			RET												
  registry.go:159	0x849d5a		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:159	0x849d5f		488b442458		MOVQ 0x58(SP), AX										
  registry.go:159	0x849d64		ffd0			CALL AX												
  registry.go:159	0x849d66		4883c470		ADDQ $0x70, SP											
  registry.go:159	0x849d6a		5d			POPQ BP												
  registry.go:159	0x849d6b		c3			RET												
  registry.go:159	0x849d6c		e8af72c0ff		CALL runtime.deferreturn(SB)									
  registry.go:159	0x849d71		4883c470		ADDQ $0x70, SP											
  registry.go:159	0x849d75		5d			POPQ BP												
  registry.go:159	0x849d76		c3			RET												
  registry.go:140	0x849d77		4889442408		MOVQ AX, 0x8(SP)										
  registry.go:140	0x849d7c		48895c2410		MOVQ BX, 0x10(SP)										
  registry.go:140	0x849d81		e89a89c4ff		CALL runtime.morestack_noctxt.abi0(SB)								
  registry.go:140	0x849d86		488b442408		MOVQ 0x8(SP), AX										
  registry.go:140	0x849d8b		488b5c2410		MOVQ 0x10(SP), BX										
  registry.go:140	0x849d90		e90bfeffff		JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister(SB)			

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister.deferwrap1(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:156	0x849da0		493b6610		CMPQ SP, 0x10(R14)										
  registry.go:156	0x849da4		7629			JBE 0x849dcf											
  registry.go:156	0x849da6		55			PUSHQ BP											
  registry.go:156	0x849da7		4889e5			MOVQ SP, BP											
  registry.go:156	0x849daa		4883ec10		SUBQ $0x10, SP											
  registry.go:156	0x849dae		488b4208		MOVQ 0x8(DX), AX										
  mutex.go:65		0x849db2		90			NOPL												
  mutex.go:194		0x849db3		bbffffffff		MOVL $-0x1, BX											
  mutex.go:194		0x849db8		f00fc118		LOCK XADDL BX, 0(AX)										
  mutex.go:194		0x849dbc		0f1f4000		NOPL 0(AX)											
  mutex.go:194		0x849dc0		ffcb			DECL BX												
  mutex.go:195		0x849dc2		7405			JE 0x849dc9											
  mutex.go:198		0x849dc4		e87725c5ff		CALL internal/sync.(*Mutex).unlockSlow(SB)							
  registry.go:156	0x849dc9		4883c410		ADDQ $0x10, SP											
  registry.go:156	0x849dcd		5d			POPQ BP												
  registry.go:156	0x849dce		c3			RET												
  registry.go:156	0x849dcf		e8ac88c4ff		CALL runtime.morestack.abi0(SB)									
  registry.go:156	0x849dd4		ebca			JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/db/api.go
  api.go:553		0x952020		4c8d6424f8		LEAQ -0x8(SP), R12								
  api.go:553		0x952025		4d3b6610		CMPQ R12, 0x10(R14)								
  api.go:553		0x952029		0f869f010000		JBE 0x9521ce									
  api.go:553		0x95202f		55			PUSHQ BP									
  api.go:553		0x952030		4889e5			MOVQ SP, BP									
  api.go:553		0x952033		4883c480		ADDQ $-0x80, SP									
  api.go:553		0x952037		48899c2498000000	MOVQ BX, 0x98(SP)								
  api.go:553		0x95203f		4889b424b0000000	MOVQ SI, 0xb0(SP)								
  raw_kv_compat.go:7	0x952047		4885db			TESTQ BX, BX									
  raw_kv_compat.go:7	0x95204a		7515			JNE 0x952061									
  api.go:554		0x95204c		488b1d2df60a02		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey(SB), BX		
  api.go:554		0x952053		488b0d2ef60a02		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+8(SB), CX		
  api.go:554		0x95205a		488b3d2ff60a02		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+16(SB), DI		
  raw_kv_compat.go:7	0x952061		4889842490000000	MOVQ AX, 0x90(SP)								
  raw_kv_compat.go:7	0x952069		4c898c24c0000000	MOVQ R9, 0xc0(SP)								
  raw_kv_compat.go:7	0x952071		4c898424b8000000	MOVQ R8, 0xb8(SP)								
  raw_kv_compat.go:7	0x952079		4889b424b0000000	MOVQ SI, 0xb0(SP)								
  api.go:555		0x952081		4c8d1598010000		LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1(SB), R10	
  api.go:555		0x952088		4c89542458		MOVQ R10, 0x58(SP)								
  api.go:555		0x95208d		4889442460		MOVQ AX, 0x60(SP)								
  api.go:555		0x952092		48894c2470		MOVQ CX, 0x70(SP)								
  api.go:555		0x952097		48897c2478		MOVQ DI, 0x78(SP)								
  api.go:555		0x95209c		48895c2468		MOVQ BX, 0x68(SP)								
  api.go:566		0x9520a1		8400			TESTB AL, 0(AX)									
  type.go:181		0x9520a3		488bb878160000		MOVQ 0x1678(AX), DI								
  type.go:181		0x9520aa		48897c2438		MOVQ DI, 0x38(SP)								
  api.go:567		0x9520af		488b7c2458		MOVQ 0x58(SP), DI								
  api.go:567		0x9520b4		4889f0			MOVQ SI, AX									
  api.go:567		0x9520b7		4c89c3			MOVQ R8, BX									
  api.go:567		0x9520ba		4c89c9			MOVQ R9, CX									
  api.go:567		0x9520bd		488d542458		LEAQ 0x58(SP), DX								
  api.go:567		0x9520c2		ffd7			CALL DI										
  api.go:175		0x9520c4		4c8b8c2490000000	MOVQ 0x90(SP), R9								
  api.go:175		0x9520cc		4d85c9			TESTQ R9, R9									
  api.go:175		0x9520cf		0f84cb000000		JE 0x9521a0									
  api.go:175		0x9520d5		49833900		CMPQ 0(R9), $0x0								
  api.go:175		0x9520d9		0f84c1000000		JE 0x9521a0									
  api.go:567		0x9520df		48895c2420		MOVQ BX, 0x20(SP)								
  api.go:567		0x9520e4		4889442448		MOVQ AX, 0x48(SP)								
  api.go:567		0x9520e9		48897c2430		MOVQ DI, 0x30(SP)								
  api.go:567		0x9520ee		4889742440		MOVQ SI, 0x40(SP)								
  api.go:567		0x9520f3		48894c2428		MOVQ CX, 0x28(SP)								
  api.go:567		0x9520f8		4c89442450		MOVQ R8, 0x50(SP)								
  api.go:178		0x9520fd		488b0d2cc90a02		MOVQ github.com/snissn/gomap/TreeDB/internal/valuelog.ErrFileNotFound(SB), CX	
  api.go:178		0x952104		488b3d2dc90a02		MOVQ github.com/snissn/gomap/TreeDB/internal/valuelog.ErrFileNotFound+8(SB), DI	
  api.go:178		0x95210b		4889f0			MOVQ SI, AX									
  api.go:178		0x95210e		4c89c3			MOVQ R8, BX									
  api.go:178		0x952111		e86a91b4ff		CALL errors.Is(SB)								
  api.go:178		0x952116		84c0			TESTL AL, AL									
  api.go:568		0x952118		7520			JNE 0x95213a									
  api.go:574		0x95211a		488b742440		MOVQ 0x40(SP), SI								
  api.go:574		0x95211f		488b7c2430		MOVQ 0x30(SP), DI								
  api.go:574		0x952124		488b5c2420		MOVQ 0x20(SP), BX								
  api.go:574		0x952129		488b4c2428		MOVQ 0x28(SP), CX								
  api.go:574		0x95212e		4c8b442450		MOVQ 0x50(SP), R8								
  api.go:574		0x952133		488b442448		MOVQ 0x48(SP), AX								
  api.go:568		0x952138		eb66			JMP 0x9521a0									
  api.go:569		0x95213a		488b842490000000	MOVQ 0x90(SP), AX								
  api.go:569		0x952142		488b5c2438		MOVQ 0x38(SP), BX								
  api.go:569		0x952147		e854d1ffff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).refreshValueLogSetForReadRetry(SB)	
  api.go:569		0x95214c		4885c0			TESTQ AX, AX									
  api.go:569		0x95214f		7526			JNE 0x952177									
  api.go:572		0x952151		488b742458		MOVQ 0x58(SP), SI								
  api.go:572		0x952156		488b8424b0000000	MOVQ 0xb0(SP), AX								
  api.go:572		0x95215e		488b9c24b8000000	MOVQ 0xb8(SP), BX								
  api.go:572		0x952166		488b8c24c0000000	MOVQ 0xc0(SP), CX								
  api.go:572		0x95216e		488d542458		LEAQ 0x58(SP), DX								
  api.go:572		0x952173		ffd6			CALL SI										
  api.go:572		0x952175		eb29			JMP 0x9521a0									
  api.go:570		0x952177		488b8c24c0000000	MOVQ 0xc0(SP), CX								
  api.go:570		0x95217f		31ff			XORL DI, DI									
  api.go:570		0x952181		4889c6			MOVQ AX, SI									
  api.go:570		0x952184		4989d8			MOVQ BX, R8									
  api.go:570		0x952187		488b8424b0000000	MOVQ 0xb0(SP), AX								
  api.go:570		0x95218f		488b9c24b8000000	MOVQ 0xb8(SP), BX								
  api.go:570		0x952197		4883ec80		SUBQ $-0x80, SP									
  api.go:570		0x95219b		5d			POPQ BP										
  api.go:570		0x95219c		c3			RET										
  api.go:570		0x95219d		0f1f00			NOPL 0(AX)									
  api.go:574		0x9521a0		4885f6			TESTQ SI, SI									
  api.go:574		0x9521a3		741e			JE 0x9521c3									
  api.go:575		0x9521a5		488b8424b0000000	MOVQ 0xb0(SP), AX								
  api.go:575		0x9521ad		488b9c24b8000000	MOVQ 0xb8(SP), BX								
  api.go:575		0x9521b5		488b8c24c0000000	MOVQ 0xc0(SP), CX								
  api.go:575		0x9521bd		4883ec80		SUBQ $-0x80, SP									
  api.go:575		0x9521c1		5d			POPQ BP										
  api.go:575		0x9521c2		c3			RET										
  api.go:577		0x9521c3		31f6			XORL SI, SI									
  api.go:577		0x9521c5		4531c0			XORL R8, R8									
  api.go:577		0x9521c8		4883ec80		SUBQ $-0x80, SP									
  api.go:577		0x9521cc		5d			POPQ BP										
  api.go:577		0x9521cd		c3			RET										
  api.go:553		0x9521ce		4889442408		MOVQ AX, 0x8(SP)								
  api.go:553		0x9521d3		48895c2410		MOVQ BX, 0x10(SP)								
  api.go:553		0x9521d8		48894c2418		MOVQ CX, 0x18(SP)								
  api.go:553		0x9521dd		48897c2420		MOVQ DI, 0x20(SP)								
  api.go:553		0x9521e2		4889742428		MOVQ SI, 0x28(SP)								
  api.go:553		0x9521e7		4c89442430		MOVQ R8, 0x30(SP)								
  api.go:553		0x9521ec		4c894c2438		MOVQ R9, 0x38(SP)								
  api.go:553		0x9521f1		e82a05b4ff		CALL runtime.morestack_noctxt.abi0(SB)						
  api.go:553		0x9521f6		488b442408		MOVQ 0x8(SP), AX								
  api.go:553		0x9521fb		488b5c2410		MOVQ 0x10(SP), BX								
  api.go:553		0x952200		488b4c2418		MOVQ 0x18(SP), CX								
  api.go:553		0x952205		488b7c2420		MOVQ 0x20(SP), DI								
  api.go:553		0x95220a		488b742428		MOVQ 0x28(SP), SI								
  api.go:553		0x95220f		4c8b442430		MOVQ 0x30(SP), R8								
  api.go:553		0x952214		4c8b4c2438		MOVQ 0x38(SP), R9								
  api.go:553		0x952219		e902feffff		JMP github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend(SB)		

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1(SB) github.com/snissn/gomap/TreeDB/db/api.go
  api.go:555		0x952220		4c8d6424d8		LEAQ -0x28(SP), R12										
  api.go:555		0x952225		4d3b6610		CMPQ R12, 0x10(R14)										
  api.go:555		0x952229		0f86c7010000		JBE 0x9523f6											
  api.go:555		0x95222f		55			PUSHQ BP											
  api.go:555		0x952230		4889e5			MOVQ SP, BP											
  api.go:555		0x952233		4881eca0000000		SUBQ $0xa0, SP											
  api.go:555		0x95223a		66440fd6bc2498000000	MOVQ X15, 0x98(SP)										
  api.go:557		0x952244		48898c24c0000000	MOVQ CX, 0xc0(SP)										
  api.go:557		0x95224c		48899c24b8000000	MOVQ BX, 0xb8(SP)										
  api.go:557		0x952254		48898424b0000000	MOVQ AX, 0xb0(SP)										
  api.go:555		0x95225c		c644243f00		MOVB $0x0, 0x3f(SP)										
  api.go:555		0x952261		488b4208		MOVQ 0x8(DX), AX										
  api.go:555		0x952265		488b4a10		MOVQ 0x10(DX), CX										
  api.go:555		0x952269		48898c2480000000	MOVQ CX, 0x80(SP)										
  api.go:555		0x952271		488b4a18		MOVQ 0x18(DX), CX										
  api.go:555		0x952275		48894c2448		MOVQ CX, 0x48(SP)										
  api.go:555		0x95227a		488b4a20		MOVQ 0x20(DX), CX										
  api.go:555		0x95227e		48894c2450		MOVQ CX, 0x50(SP)										
  api.go:555		0x952283		48c744246800000000	MOVQ $0x0, 0x68(SP)										
  api.go:555		0x95228c		440f117c2470		MOVUPS X15, 0x70(SP)										
  api.go:555		0x952292		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  api.go:555		0x95229b		440f117c2458		MOVUPS X15, 0x58(SP)										
  api.go:556		0x9522a1		e89a711700		CALL github.com/snissn/gomap/TreeDB/db.(*DB).acquireOneShotReadOrErr(SB)			
  api.go:557		0x9522a6		4885db			TESTQ BX, BX											
  api.go:557		0x9522a9		7463			JE 0x95230e											
  api.go:558		0x9522ab		488b9424b0000000	MOVQ 0xb0(SP), DX										
  api.go:558		0x9522b3		4889542468		MOVQ DX, 0x68(SP)										
  api.go:558		0x9522b8		488b9424b8000000	MOVQ 0xb8(SP), DX										
  api.go:558		0x9522c0		4889542470		MOVQ DX, 0x70(SP)										
  api.go:558		0x9522c5		488b9424c0000000	MOVQ 0xc0(SP), DX										
  api.go:558		0x9522cd		4889542478		MOVQ DX, 0x78(SP)										
  api.go:558		0x9522d2		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  api.go:558		0x9522db		48895c2458		MOVQ BX, 0x58(SP)										
  api.go:558		0x9522e0		48894c2460		MOVQ CX, 0x60(SP)										
  api.go:558		0x9522e5		488b7c2440		MOVQ 0x40(SP), DI										
  api.go:558		0x9522ea		488b442468		MOVQ 0x68(SP), AX										
  api.go:558		0x9522ef		488b542470		MOVQ 0x70(SP), DX										
  api.go:558		0x9522f4		4c8b4c2478		MOVQ 0x78(SP), R9										
  api.go:558		0x9522f9		4889de			MOVQ BX, SI											
  api.go:558		0x9522fc		4989c8			MOVQ CX, R8											
  api.go:558		0x9522ff		4889d3			MOVQ DX, BX											
  api.go:558		0x952302		4c89c9			MOVQ R9, CX											
  api.go:558		0x952305		4881c4a0000000		ADDQ $0xa0, SP											
  api.go:558		0x95230c		5d			POPQ BP												
  api.go:558		0x95230d		c3			RET												
  api.go:560		0x95230e		488d150b010000		LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1.deferwrap1(SB), DX	
  api.go:560		0x952315		4889942488000000	MOVQ DX, 0x88(SP)										
  api.go:560		0x95231d		4889842490000000	MOVQ AX, 0x90(SP)										
  api.go:560		0x952325		488d942488000000	LEAQ 0x88(SP), DX										
  api.go:560		0x95232d		4889942498000000	MOVQ DX, 0x98(SP)										
  api.go:560		0x952335		c644243f01		MOVB $0x1, 0x3f(SP)										
  api.go:563		0x95233a		8400			TESTB AL, 0(AX)											
  api.go:563		0x95233c		4805a0000000		ADDQ $0xa0, AX											
  api.go:563		0x952342		488b9c2480000000	MOVQ 0x80(SP), BX										
  api.go:563		0x95234a		488b4c2448		MOVQ 0x48(SP), CX										
  api.go:563		0x95234f		488b7c2450		MOVQ 0x50(SP), DI										
  api.go:563		0x952354		488bb424b0000000	MOVQ 0xb0(SP), SI										
  api.go:563		0x95235c		4c8b8424b8000000	MOVQ 0xb8(SP), R8										
  api.go:563		0x952364		4c8b8c24c0000000	MOVQ 0xc0(SP), R9										
  api.go:563		0x95236c		e80fb4d5ff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB)				
  api.go:563		0x952371		4889442468		MOVQ AX, 0x68(SP)										
  api.go:563		0x952376		48895c2470		MOVQ BX, 0x70(SP)										
  api.go:563		0x95237b		48894c2478		MOVQ CX, 0x78(SP)										
  api.go:563		0x952380		48897c2440		MOVQ DI, 0x40(SP)										
  api.go:563		0x952385		4889742458		MOVQ SI, 0x58(SP)										
  api.go:563		0x95238a		4c89442460		MOVQ R8, 0x60(SP)										
  api.go:563		0x95238f		c644243f00		MOVB $0x0, 0x3f(SP)										
  api.go:563		0x952394		488b942498000000	MOVQ 0x98(SP), DX										
  api.go:563		0x95239c		4c8b12			MOVQ 0(DX), R10											
  api.go:563		0x95239f		90			NOPL												
  api.go:563		0x9523a0		41ffd2			CALL R10											
  api.go:563		0x9523a3		488b7c2440		MOVQ 0x40(SP), DI										
  api.go:563		0x9523a8		488b742458		MOVQ 0x58(SP), SI										
  api.go:563		0x9523ad		488b442468		MOVQ 0x68(SP), AX										
  api.go:563		0x9523b2		488b5c2470		MOVQ 0x70(SP), BX										
  api.go:563		0x9523b7		4c8b442460		MOVQ 0x60(SP), R8										
  api.go:563		0x9523bc		488b4c2478		MOVQ 0x78(SP), CX										
  api.go:563		0x9523c1		4881c4a0000000		ADDQ $0xa0, SP											
  api.go:563		0x9523c8		5d			POPQ BP												
  api.go:563		0x9523c9		c3			RET												
  api.go:563		0x9523ca		e851ecafff		CALL runtime.deferreturn(SB)									
  api.go:563		0x9523cf		488b442468		MOVQ 0x68(SP), AX										
  api.go:563		0x9523d4		488b5c2470		MOVQ 0x70(SP), BX										
  api.go:563		0x9523d9		488b4c2478		MOVQ 0x78(SP), CX										
  api.go:563		0x9523de		488b7c2440		MOVQ 0x40(SP), DI										
  api.go:563		0x9523e3		488b742458		MOVQ 0x58(SP), SI										
  api.go:563		0x9523e8		4c8b442460		MOVQ 0x60(SP), R8										
  api.go:563		0x9523ed		4881c4a0000000		ADDQ $0xa0, SP											
  api.go:563		0x9523f4		5d			POPQ BP												
  api.go:563		0x9523f5		c3			RET												
  api.go:555		0x9523f6		4889442408		MOVQ AX, 0x8(SP)										
  api.go:555		0x9523fb		48895c2410		MOVQ BX, 0x10(SP)										
  api.go:555		0x952400		48894c2418		MOVQ CX, 0x18(SP)										
  api.go:555		0x952405		e87602b4ff		CALL runtime.morestack.abi0(SB)									
  api.go:555		0x95240a		488b442408		MOVQ 0x8(SP), AX										
  api.go:555		0x95240f		488b5c2410		MOVQ 0x10(SP), BX										
  api.go:555		0x952414		488b4c2418		MOVQ 0x18(SP), CX										
  api.go:555		0x952419		e902feffff		JMP github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1(SB)			

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1.deferwrap1(SB) github.com/snissn/gomap/TreeDB/db/api.go
  api.go:560		0x952420		493b6610		CMPQ SP, 0x10(R14)									
  api.go:560		0x952424		7617			JBE 0x95243d										
  api.go:560		0x952426		55			PUSHQ BP										
  api.go:560		0x952427		4889e5			MOVQ SP, BP										
  api.go:560		0x95242a		4883ec08		SUBQ $0x8, SP										
  api.go:560		0x95242e		488b4208		MOVQ 0x8(DX), AX									
  api.go:560		0x952432		e869711700		CALL github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB)				
  api.go:560		0x952437		4883c408		ADDQ $0x8, SP										
  api.go:560		0x95243b		5d			POPQ BP											
  api.go:560		0x95243c		c3			RET											
  api.go:560		0x95243d		0f1f00			NOPL 0(AX)										
  api.go:560		0x952440		e83b02b4ff		CALL runtime.morestack.abi0(SB)								
  api.go:560		0x952445		ebd9			JMP github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/db/conditional_txn.go
  conditional_txn.go:193	0x9bc640		4c8da424f0feffff	LEAQ 0xfffffef0(SP), R12							
  conditional_txn.go:193	0x9bc648		4d3b6610		CMPQ R12, 0x10(R14)								
  conditional_txn.go:193	0x9bc64c		0f86fe040000		JBE 0x9bcb50									
  conditional_txn.go:193	0x9bc652		55			PUSHQ BP									
  conditional_txn.go:193	0x9bc653		4889e5			MOVQ SP, BP									
  conditional_txn.go:193	0x9bc656		4881ec88010000		SUBQ $0x188, SP									
  conditional_txn.go:193	0x9bc65d		48899c24a0010000	MOVQ BX, 0x1a0(SP)								
  conditional_txn.go:193	0x9bc665		4889b424b8010000	MOVQ SI, 0x1b8(SP)								
  conditional_txn.go:471	0x9bc66d		4885c0			TESTQ AX, AX									
  conditional_txn.go:471	0x9bc670		7442			JE 0x9bc6b4									
  conditional_txn.go:471	0x9bc672		80782800		CMPB 0x28(AX), $0x0								
  conditional_txn.go:471	0x9bc676		753c			JNE 0x9bc6b4									
  conditional_txn.go:471	0x9bc678		488b10			MOVQ 0(AX), DX									
  conditional_txn.go:471	0x9bc67b		0f1f440000		NOPL 0(AX)(AX*1)								
  conditional_txn.go:471	0x9bc680		4885d2			TESTQ DX, DX									
  conditional_txn.go:471	0x9bc683		742f			JE 0x9bc6b4									
  conditional_txn.go:471	0x9bc685		4883780800		CMPQ 0x8(AX), $0x0								
  conditional_txn.go:471	0x9bc68a		7428			JE 0x9bc6b4									
  conditional_txn.go:471	0x9bc68c		4883781000		CMPQ 0x10(AX), $0x0								
  conditional_txn.go:471	0x9bc691		7421			JE 0x9bc6b4									
  type.go:19			0x9bc693		8b9230510000		MOVL 0x5130(DX), DX								
  type.go:19			0x9bc699		85d2			TESTL DX, DX									
  conditional_txn.go:474	0x9bc69b		7410			JE 0x9bc6ad									
  conditional_txn.go:194	0x9bc69d		488b154c130402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), DX			
  conditional_txn.go:194	0x9bc6a4		4c8b154d130402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), R10			
  conditional_txn.go:194	0x9bc6ab		eb15			JMP 0x9bc6c2									
  conditional_txn.go:194	0x9bc6ad		31d2			XORL DX, DX									
  conditional_txn.go:194	0x9bc6af		4531d2			XORL R10, R10									
  conditional_txn.go:194	0x9bc6b2		eb0e			JMP 0x9bc6c2									
  conditional_txn.go:194	0x9bc6b4		488b1565130402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrConditionalTxnClosed(SB), DX		
  conditional_txn.go:194	0x9bc6bb		4c8b1566130402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrConditionalTxnClosed+8(SB), R10	
  conditional_txn.go:194	0x9bc6c2		4885d2			TESTQ DX, DX									
  conditional_txn.go:194	0x9bc6c5		0f856b040000		JNE 0x9bcb36									
  conditional_txn.go:471	0x9bc6cb		4c898c24c8010000	MOVQ R9, 0x1c8(SP)								
  conditional_txn.go:471	0x9bc6d3		4c898424c0010000	MOVQ R8, 0x1c0(SP)								
  conditional_txn.go:471	0x9bc6db		4889b424b8010000	MOVQ SI, 0x1b8(SP)								
  raw_kv_compat.go:7		0x9bc6e3		4885db			TESTQ BX, BX									
  raw_kv_compat.go:7		0x9bc6e6		7515			JNE 0x9bc6fd									
  conditional_txn.go:197	0x9bc6e8		488b1d914f0402		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey(SB), BX		
  conditional_txn.go:197	0x9bc6ef		488b0d924f0402		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+8(SB), CX		
  conditional_txn.go:197	0x9bc6f6		488b3d934f0402		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+16(SB), DI		
  conditional_txn.go:471	0x9bc6fd		4889842498010000	MOVQ AX, 0x198(SP)								
  conditional_txn.go:197	0x9bc705		4889bc2480000000	MOVQ DI, 0x80(SP)								
  conditional_txn.go:197	0x9bc70d		48894c2478		MOVQ CX, 0x78(SP)								
  conditional_txn.go:197	0x9bc712		48899c24b8000000	MOVQ BX, 0xb8(SP)								
  conditional_txn.go:198	0x9bc71a		488d942430010000	LEAQ 0x130(SP), DX								
  conditional_txn.go:198	0x9bc722		440f113a		MOVUPS X15, 0(DX)								
  conditional_txn.go:198	0x9bc726		440f117a10		MOVUPS X15, 0x10(DX)								
  conditional_txn.go:198	0x9bc72b		440f117a20		MOVUPS X15, 0x20(DX)								
  conditional_txn.go:198	0x9bc730		440f117a30		MOVUPS X15, 0x30(DX)								
  conditional_txn.go:198	0x9bc735		440f117a40		MOVUPS X15, 0x40(DX)								
  conditional_txn.go:198	0x9bc73a		440f117a48		MOVUPS X15, 0x48(DX)								
  conditional_txn.go:198	0x9bc73f		90			NOPL										
  conditional_txn.go:198	0x9bc740		e83b1b0000		CALL github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).findStagedWrite(SB)	
  conditional_txn.go:198	0x9bc745		488d942430010000	LEAQ 0x130(SP), DX								
  conditional_txn.go:198	0x9bc74d		4889e6			MOVQ SP, SI									
  conditional_txn.go:198	0x9bc750		440f1036		MOVUPS 0(SI), X14								
  conditional_txn.go:198	0x9bc754		440f1132		MOVUPS X14, 0(DX)								
  conditional_txn.go:198	0x9bc758		440f107610		MOVUPS 0x10(SI), X14								
  conditional_txn.go:198	0x9bc75d		440f117210		MOVUPS X14, 0x10(DX)								
  conditional_txn.go:198	0x9bc762		440f107620		MOVUPS 0x20(SI), X14								
  conditional_txn.go:198	0x9bc767		440f117220		MOVUPS X14, 0x20(DX)								
  conditional_txn.go:198	0x9bc76c		440f107630		MOVUPS 0x30(SI), X14								
  conditional_txn.go:198	0x9bc771		440f117230		MOVUPS X14, 0x30(DX)								
  conditional_txn.go:198	0x9bc776		440f107640		MOVUPS 0x40(SI), X14								
  conditional_txn.go:198	0x9bc77b		440f117240		MOVUPS X14, 0x40(DX)								
  conditional_txn.go:198	0x9bc780		440f107648		MOVUPS 0x48(SI), X14								
  conditional_txn.go:198	0x9bc785		440f117248		MOVUPS X14, 0x48(DX)								
  conditional_txn.go:198	0x9bc78a		4c8d8424c0000000	LEAQ 0xc0(SP), R8								
  conditional_txn.go:198	0x9bc792		440f1032		MOVUPS 0(DX), X14								
  conditional_txn.go:198	0x9bc796		450f1130		MOVUPS X14, 0(R8)								
  conditional_txn.go:198	0x9bc79a		440f107210		MOVUPS 0x10(DX), X14								
  conditional_txn.go:198	0x9bc79f		450f117010		MOVUPS X14, 0x10(R8)								
  conditional_txn.go:198	0x9bc7a4		440f107220		MOVUPS 0x20(DX), X14								
  conditional_txn.go:198	0x9bc7a9		450f117020		MOVUPS X14, 0x20(R8)								
  conditional_txn.go:198	0x9bc7ae		440f107230		MOVUPS 0x30(DX), X14								
  conditional_txn.go:198	0x9bc7b3		450f117030		MOVUPS X14, 0x30(R8)								
  conditional_txn.go:198	0x9bc7b8		440f107240		MOVUPS 0x40(DX), X14								
  conditional_txn.go:198	0x9bc7bd		450f117040		MOVUPS X14, 0x40(R8)								
  conditional_txn.go:198	0x9bc7c2		440f107248		MOVUPS 0x48(DX), X14								
  conditional_txn.go:198	0x9bc7c7		450f117048		MOVUPS X14, 0x48(R8)								
  conditional_txn.go:198	0x9bc7cc		84c0			TESTL AL, AL									
  conditional_txn.go:198	0x9bc7ce		0f8461010000		JE 0x9bc935									
  conditional_txn.go:199	0x9bc7d4		0fb69424c0000000	MOVZX 0xc0(SP), DX								
  conditional_txn.go:199	0x9bc7dc		0f1f4000		NOPL 0(AX)									
  conditional_txn.go:200	0x9bc7e0		84d2			TESTL DL, DL									
  conditional_txn.go:200	0x9bc7e2		0f850e010000		JNE 0x9bc8f6									
  conditional_txn.go:201	0x9bc7e8		80bc240801000000	CMPB 0x108(SP), $0x0								
  conditional_txn.go:201	0x9bc7f0		0f85c6000000		JNE 0x9bc8bc									
  conditional_txn.go:204	0x9bc7f6		488bbc24e8000000	MOVQ 0xe8(SP), DI								
  conditional_txn.go:204	0x9bc7fe		488b9424c0010000	MOVQ 0x1c0(SP), DX								
  conditional_txn.go:204	0x9bc806		488d1c3a		LEAQ 0(DX)(DI*1), BX								
  conditional_txn.go:204	0x9bc80a		4c8b8424e0000000	MOVQ 0xe0(SP), R8								
  conditional_txn.go:204	0x9bc812		488b8c24c8010000	MOVQ 0x1c8(SP), CX								
  conditional_txn.go:204	0x9bc81a		4839d9			CMPQ CX, BX									
  conditional_txn.go:204	0x9bc81d		720a			JB 0x9bc829									
  conditional_txn.go:204	0x9bc81f		488b8424b8010000	MOVQ 0x1b8(SP), AX								
  conditional_txn.go:204	0x9bc827		eb3f			JMP 0x9bc868									
  conditional_txn.go:204	0x9bc829		4c89842428010000	MOVQ R8, 0x128(SP)								
  conditional_txn.go:204	0x9bc831		4889bc24b0000000	MOVQ DI, 0xb0(SP)								
  conditional_txn.go:204	0x9bc839		488b8424b8010000	MOVQ 0x1b8(SP), AX								
  conditional_txn.go:204	0x9bc841		488d353890f600		LEAQ 0xf69038(IP), SI								
  conditional_txn.go:204	0x9bc848		e8f324adff		CALL runtime.growslice(SB)							
  conditional_txn.go:204	0x9bc84d		488b9424c0010000	MOVQ 0x1c0(SP), DX								
  conditional_txn.go:204	0x9bc855		4889e6			MOVQ SP, SI									
  conditional_txn.go:204	0x9bc858		488bbc24b0000000	MOVQ 0xb0(SP), DI								
  conditional_txn.go:204	0x9bc860		4c8b842428010000	MOVQ 0x128(SP), R8								
  conditional_txn.go:204	0x9bc868		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  conditional_txn.go:204	0x9bc870		48899c24a8000000	MOVQ BX, 0xa8(SP)								
  conditional_txn.go:204	0x9bc878		4889842428010000	MOVQ AX, 0x128(SP)								
  conditional_txn.go:204	0x9bc880		4801d0			ADDQ DX, AX									
  conditional_txn.go:204	0x9bc883		4c89c3			MOVQ R8, BX									
  conditional_txn.go:204	0x9bc886		4889f9			MOVQ DI, CX									
  conditional_txn.go:204	0x9bc889		e8d280adff		CALL runtime.memmove(SB)							
  conditional_txn.go:204	0x9bc88e		488bbc2410010000	MOVQ 0x110(SP), DI								
  conditional_txn.go:204	0x9bc896		488b842428010000	MOVQ 0x128(SP), AX								
  conditional_txn.go:204	0x9bc89e		488b9c24a8000000	MOVQ 0xa8(SP), BX								
  conditional_txn.go:204	0x9bc8a6		488b8c24b0000000	MOVQ 0xb0(SP), CX								
  conditional_txn.go:204	0x9bc8ae		31f6			XORL SI, SI									
  conditional_txn.go:204	0x9bc8b0		4531c0			XORL R8, R8									
  conditional_txn.go:204	0x9bc8b3		4881c488010000		ADDQ $0x188, SP									
  conditional_txn.go:204	0x9bc8ba		5d			POPQ BP										
  conditional_txn.go:204	0x9bc8bb		c3			RET										
  conditional_txn.go:202	0x9bc8bc		488b159d230402		MOVQ github.com/snissn/gomap/TreeDB/batch.ErrMissingValueReader(SB), DX		
  conditional_txn.go:202	0x9bc8c3		4c8b059e230402		MOVQ github.com/snissn/gomap/TreeDB/batch.ErrMissingValueReader+8(SB), R8	
  conditional_txn.go:202	0x9bc8ca		488bbc2410010000	MOVQ 0x110(SP), DI								
  conditional_txn.go:202	0x9bc8d2		488b8424b8010000	MOVQ 0x1b8(SP), AX								
  conditional_txn.go:202	0x9bc8da		488b9c24c0010000	MOVQ 0x1c0(SP), BX								
  conditional_txn.go:202	0x9bc8e2		488b8c24c8010000	MOVQ 0x1c8(SP), CX								
  conditional_txn.go:202	0x9bc8ea		4889d6			MOVQ DX, SI									
  conditional_txn.go:202	0x9bc8ed		4881c488010000		ADDQ $0x188, SP									
  conditional_txn.go:202	0x9bc8f4		5d			POPQ BP										
  conditional_txn.go:202	0x9bc8f5		c3			RET										
  conditional_txn.go:205	0x9bc8f6		80fa01			CMPL DL, $0x1									
  conditional_txn.go:205	0x9bc8f9		753a			JNE 0x9bc935									
  conditional_txn.go:206	0x9bc8fb		488b150e230402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), DX			
  conditional_txn.go:206	0x9bc902		4c8b050f230402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R8		
  conditional_txn.go:206	0x9bc909		488bbc2410010000	MOVQ 0x110(SP), DI								
  conditional_txn.go:206	0x9bc911		488b8424b8010000	MOVQ 0x1b8(SP), AX								
  conditional_txn.go:206	0x9bc919		488b9c24c0010000	MOVQ 0x1c0(SP), BX								
  conditional_txn.go:206	0x9bc921		488b8c24c8010000	MOVQ 0x1c8(SP), CX								
  conditional_txn.go:206	0x9bc929		4889d6			MOVQ DX, SI									
  conditional_txn.go:206	0x9bc92c		4881c488010000		ADDQ $0x188, SP									
  conditional_txn.go:206	0x9bc933		5d			POPQ BP										
  conditional_txn.go:206	0x9bc934		c3			RET										
  conditional_txn.go:209	0x9bc935		488b942498010000	MOVQ 0x198(SP), DX								
  conditional_txn.go:209	0x9bc93d		488b4208		MOVQ 0x8(DX), AX								
  conditional_txn.go:209	0x9bc941		488b9c24b8000000	MOVQ 0xb8(SP), BX								
  conditional_txn.go:209	0x9bc949		488b4c2478		MOVQ 0x78(SP), CX								
  conditional_txn.go:209	0x9bc94e		488bbc2480000000	MOVQ 0x80(SP), DI								
  conditional_txn.go:209	0x9bc956		488bb424b8010000	MOVQ 0x1b8(SP), SI								
  conditional_txn.go:209	0x9bc95e		4c8b8424c0010000	MOVQ 0x1c0(SP), R8								
  conditional_txn.go:209	0x9bc966		4c8b8c24c8010000	MOVQ 0x1c8(SP), R9								
  conditional_txn.go:209	0x9bc96e		e8cd830100		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend(SB)	
  conditional_txn.go:209	0x9bc973		4889b424a0000000	MOVQ SI, 0xa0(SP)								
  conditional_txn.go:209	0x9bc97b		4c89842420010000	MOVQ R8, 0x120(SP)								
  conditional_txn.go:209	0x9bc983		4889bc2488000000	MOVQ DI, 0x88(SP)								
  conditional_txn.go:209	0x9bc98b		4889842418010000	MOVQ AX, 0x118(SP)								
  conditional_txn.go:209	0x9bc993		48899c2490000000	MOVQ BX, 0x90(SP)								
  conditional_txn.go:209	0x9bc99b		48898c2498000000	MOVQ CX, 0x98(SP)								
  conditional_txn.go:210	0x9bc9a3		488b0d66220402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), CX			
  conditional_txn.go:210	0x9bc9aa		488b3d67220402		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), DI		
  conditional_txn.go:210	0x9bc9b1		4889f0			MOVQ SI, AX									
  conditional_txn.go:210	0x9bc9b4		4c89c3			MOVQ R8, BX									
  conditional_txn.go:210	0x9bc9b7		e8c4e8adff		CALL errors.Is(SB)								
  conditional_txn.go:210	0x9bc9bc		0f1f4000		NOPL 0(AX)									
  conditional_txn.go:210	0x9bc9c0		84c0			TESTL AL, AL									
  conditional_txn.go:210	0x9bc9c2		0f85d4000000		JNE 0x9bca9c									
  conditional_txn.go:216	0x9bc9c8		488bb424a0000000	MOVQ 0xa0(SP), SI								
  conditional_txn.go:216	0x9bc9d0		4885f6			TESTQ SI, SI									
  conditional_txn.go:216	0x9bc9d3		0f8592000000		JNE 0x9bca6b									
  conditional_txn.go:219	0x9bc9d9		488b842498010000	MOVQ 0x198(SP), AX								
  conditional_txn.go:219	0x9bc9e1		488b9c24b8000000	MOVQ 0xb8(SP), BX								
  conditional_txn.go:219	0x9bc9e9		488b4c2478		MOVQ 0x78(SP), CX								
  conditional_txn.go:219	0x9bc9ee		488bbc2480000000	MOVQ 0x80(SP), DI								
  conditional_txn.go:219	0x9bc9f6		488bb42488000000	MOVQ 0x88(SP), SI								
  conditional_txn.go:219	0x9bc9fe		41b801000000		MOVL $0x1, R8									
  conditional_txn.go:219	0x9bca04		e8f71b0000		CALL github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).recordRead(SB)		
  conditional_txn.go:219	0x9bca09		4885c0			TESTQ AX, AX									
  conditional_txn.go:219	0x9bca0c		742f			JE 0x9bca3d									
  conditional_txn.go:220	0x9bca0e		488b8c24c8010000	MOVQ 0x1c8(SP), CX								
  conditional_txn.go:220	0x9bca16		488bbc2488000000	MOVQ 0x88(SP), DI								
  conditional_txn.go:220	0x9bca1e		4889c6			MOVQ AX, SI									
  conditional_txn.go:220	0x9bca21		4989d8			MOVQ BX, R8									
  conditional_txn.go:220	0x9bca24		488b8424b8010000	MOVQ 0x1b8(SP), AX								
  conditional_txn.go:220	0x9bca2c		488b9c24c0010000	MOVQ 0x1c0(SP), BX								
  conditional_txn.go:220	0x9bca34		4881c488010000		ADDQ $0x188, SP									
  conditional_txn.go:220	0x9bca3b		5d			POPQ BP										
  conditional_txn.go:220	0x9bca3c		c3			RET										
  conditional_txn.go:222	0x9bca3d		488b842418010000	MOVQ 0x118(SP), AX								
  conditional_txn.go:222	0x9bca45		488b9c2490000000	MOVQ 0x90(SP), BX								
  conditional_txn.go:222	0x9bca4d		488b8c2498000000	MOVQ 0x98(SP), CX								
  conditional_txn.go:222	0x9bca55		488bbc2488000000	MOVQ 0x88(SP), DI								
  conditional_txn.go:222	0x9bca5d		31f6			XORL SI, SI									
  conditional_txn.go:222	0x9bca5f		4531c0			XORL R8, R8									
  conditional_txn.go:222	0x9bca62		4881c488010000		ADDQ $0x188, SP									
  conditional_txn.go:222	0x9bca69		5d			POPQ BP										
  conditional_txn.go:222	0x9bca6a		c3			RET										
  conditional_txn.go:217	0x9bca6b		488b8424b8010000	MOVQ 0x1b8(SP), AX								
  conditional_txn.go:217	0x9bca73		488b9c24c0010000	MOVQ 0x1c0(SP), BX								
  conditional_txn.go:217	0x9bca7b		488b8c24c8010000	MOVQ 0x1c8(SP), CX								
  conditional_txn.go:217	0x9bca83		488bbc2488000000	MOVQ 0x88(SP), DI								
  conditional_txn.go:217	0x9bca8b		4c8b842420010000	MOVQ 0x120(SP), R8								
  conditional_txn.go:217	0x9bca93		4881c488010000		ADDQ $0x188, SP									
  conditional_txn.go:217	0x9bca9a		5d			POPQ BP										
  conditional_txn.go:217	0x9bca9b		c3			RET										
  conditional_txn.go:211	0x9bca9c		488b842498010000	MOVQ 0x198(SP), AX								
  conditional_txn.go:211	0x9bcaa4		488b9c24b8000000	MOVQ 0xb8(SP), BX								
  conditional_txn.go:211	0x9bcaac		488b4c2478		MOVQ 0x78(SP), CX								
  conditional_txn.go:211	0x9bcab1		488bbc2480000000	MOVQ 0x80(SP), DI								
  conditional_txn.go:211	0x9bcab9		488bb42488000000	MOVQ 0x88(SP), SI								
  conditional_txn.go:211	0x9bcac1		4531c0			XORL R8, R8									
  conditional_txn.go:211	0x9bcac4		e8371b0000		CALL github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).recordRead(SB)		
  conditional_txn.go:211	0x9bcac9		4885c0			TESTQ AX, AX									
  conditional_txn.go:211	0x9bcacc		742f			JE 0x9bcafd									
  conditional_txn.go:212	0x9bcace		488b8c24c8010000	MOVQ 0x1c8(SP), CX								
  conditional_txn.go:212	0x9bcad6		488bbc2488000000	MOVQ 0x88(SP), DI								
  conditional_txn.go:212	0x9bcade		4889c6			MOVQ AX, SI									
  conditional_txn.go:212	0x9bcae1		4989d8			MOVQ BX, R8									
  conditional_txn.go:212	0x9bcae4		488b8424b8010000	MOVQ 0x1b8(SP), AX								
  conditional_txn.go:212	0x9bcaec		488b9c24c0010000	MOVQ 0x1c0(SP), BX								
  conditional_txn.go:212	0x9bcaf4		4881c488010000		ADDQ $0x188, SP									
  conditional_txn.go:212	0x9bcafb		5d			POPQ BP										
  conditional_txn.go:212	0x9bcafc		c3			RET										
  conditional_txn.go:214	0x9bcafd		488b8424b8010000	MOVQ 0x1b8(SP), AX								
  conditional_txn.go:214	0x9bcb05		488b9c24c0010000	MOVQ 0x1c0(SP), BX								
  conditional_txn.go:214	0x9bcb0d		488b8c24c8010000	MOVQ 0x1c8(SP), CX								
  conditional_txn.go:214	0x9bcb15		488bbc2488000000	MOVQ 0x88(SP), DI								
  conditional_txn.go:214	0x9bcb1d		488bb424a0000000	MOVQ 0xa0(SP), SI								
  conditional_txn.go:214	0x9bcb25		4c8b842420010000	MOVQ 0x120(SP), R8								
  conditional_txn.go:214	0x9bcb2d		4881c488010000		ADDQ $0x188, SP									
  conditional_txn.go:214	0x9bcb34		5d			POPQ BP										
  conditional_txn.go:214	0x9bcb35		c3			RET										
  conditional_txn.go:195	0x9bcb36		4889f0			MOVQ SI, AX									
  conditional_txn.go:195	0x9bcb39		4c89c3			MOVQ R8, BX									
  conditional_txn.go:195	0x9bcb3c		4c89c9			MOVQ R9, CX									
  conditional_txn.go:195	0x9bcb3f		31ff			XORL DI, DI									
  conditional_txn.go:195	0x9bcb41		4889d6			MOVQ DX, SI									
  conditional_txn.go:195	0x9bcb44		4d89d0			MOVQ R10, R8									
  conditional_txn.go:195	0x9bcb47		4881c488010000		ADDQ $0x188, SP									
  conditional_txn.go:195	0x9bcb4e		5d			POPQ BP										
  conditional_txn.go:195	0x9bcb4f		c3			RET										
  conditional_txn.go:193	0x9bcb50		4889442408		MOVQ AX, 0x8(SP)								
  conditional_txn.go:193	0x9bcb55		48895c2410		MOVQ BX, 0x10(SP)								
  conditional_txn.go:193	0x9bcb5a		48894c2418		MOVQ CX, 0x18(SP)								
  conditional_txn.go:193	0x9bcb5f		48897c2420		MOVQ DI, 0x20(SP)								
  conditional_txn.go:193	0x9bcb64		4889742428		MOVQ SI, 0x28(SP)								
  conditional_txn.go:193	0x9bcb69		4c89442430		MOVQ R8, 0x30(SP)								
  conditional_txn.go:193	0x9bcb6e		4c894c2438		MOVQ R9, 0x38(SP)								
  conditional_txn.go:193	0x9bcb73		e8a85badff		CALL runtime.morestack_noctxt.abi0(SB)						
  conditional_txn.go:193	0x9bcb78		488b442408		MOVQ 0x8(SP), AX								
  conditional_txn.go:193	0x9bcb7d		488b5c2410		MOVQ 0x10(SP), BX								
  conditional_txn.go:193	0x9bcb82		488b4c2418		MOVQ 0x18(SP), CX								
  conditional_txn.go:193	0x9bcb87		488b7c2420		MOVQ 0x20(SP), DI								
  conditional_txn.go:193	0x9bcb8c		488b742428		MOVQ 0x28(SP), SI								
  conditional_txn.go:193	0x9bcb91		4c8b442430		MOVQ 0x30(SP), R8								
  conditional_txn.go:193	0x9bcb96		4c8b4c2438		MOVQ 0x38(SP), R9								
  conditional_txn.go:193	0x9bcb9b		0f1f440000		NOPL 0(AX)(AX*1)								
  conditional_txn.go:193	0x9bcba0		e99bfaffff		JMP github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).GetVersionedAppend(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:4484			0x9d4d40		4c8d6424f0		LEAQ -0x10(SP), R12										
  db.go:4484			0x9d4d45		4d3b6610		CMPQ R12, 0x10(R14)										
  db.go:4484			0x9d4d49		0f86dd010000		JBE 0x9d4f2c											
  db.go:4484			0x9d4d4f		55			PUSHQ BP											
  db.go:4484			0x9d4d50		4889e5			MOVQ SP, BP											
  db.go:4484			0x9d4d53		4881ec88000000		SUBQ $0x88, SP											
  db.go:4484			0x9d4d5a		48899c24a0000000	MOVQ BX, 0xa0(SP)										
  db.go:4484			0x9d4d62		4889b424b8000000	MOVQ SI, 0xb8(SP)										
  db.go:4484			0x9d4d6a		66440fd6bc2480000000	MOVQ X15, 0x80(SP)										
  db.go:4484			0x9d4d74		c644243f00		MOVB $0x0, 0x3f(SP)										
  db.go:4484			0x9d4d79		48c744245800000000	MOVQ $0x0, 0x58(SP)										
  db.go:4484			0x9d4d82		440f117c2460		MOVUPS X15, 0x60(SP)										
  db.go:4484			0x9d4d88		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  db.go:4484			0x9d4d91		440f117c2448		MOVUPS X15, 0x48(SP)										
  db.go:4484			0x9d4d97		660f1f840000000000	NOPW 0(AX)(AX*1)										
  snapshot_read_lifetime.go:8	0x9d4da0		4885c0			TESTQ AX, AX											
  snapshot_read_lifetime.go:8	0x9d4da3		0f850a010000		JNE 0x9d4eb3											
  db.go:4485			0x9d4da9		488b15408c0202		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), DX					
  db.go:4485			0x9d4db0		4c8b15418c0202		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), R10					
  db.go:4485			0x9d4db7		660f1f840000000000	NOPW 0(AX)(AX*1)										
  db.go:4485			0x9d4dc0		4885d2			TESTQ DX, DX											
  db.go:4485			0x9d4dc3		0f85a2000000		JNE 0x9d4e6b											
  db.go:4488			0x9d4dc9		488d15b0010000		LEAQ github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend.deferwrap1(SB), DX	
  db.go:4488			0x9d4dd0		4889542470		MOVQ DX, 0x70(SP)										
  db.go:4488			0x9d4dd5		4889442478		MOVQ AX, 0x78(SP)										
  db.go:4488			0x9d4dda		488d542470		LEAQ 0x70(SP), DX										
  db.go:4488			0x9d4ddf		4889942480000000	MOVQ DX, 0x80(SP)										
  db.go:4488			0x9d4de7		c644243f01		MOVB $0x1, 0x3f(SP)										
  raw_kv_compat.go:7		0x9d4dec		4885db			TESTQ BX, BX											
  raw_kv_compat.go:7		0x9d4def		7515			JNE 0x9d4e06											
  db.go:4489			0x9d4df1		488b1d88c80202		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey(SB), BX				
  db.go:4489			0x9d4df8		488b0d89c80202		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+8(SB), CX				
  db.go:4489			0x9d4dff		488b3d8ac80202		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+16(SB), DI				
  db.go:4489			0x9d4e06		8400			TESTB AL, 0(AX)											
  db.go:4489			0x9d4e08		4805a0000000		ADDQ $0xa0, AX											
  db.go:4489			0x9d4e0e		e86d89cdff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB)				
  db.go:4489			0x9d4e13		4889442458		MOVQ AX, 0x58(SP)										
  db.go:4489			0x9d4e18		48895c2460		MOVQ BX, 0x60(SP)										
  db.go:4489			0x9d4e1d		48894c2468		MOVQ CX, 0x68(SP)										
  db.go:4489			0x9d4e22		48897c2440		MOVQ DI, 0x40(SP)										
  db.go:4489			0x9d4e27		4889742448		MOVQ SI, 0x48(SP)										
  db.go:4489			0x9d4e2c		4c89442450		MOVQ R8, 0x50(SP)										
  db.go:4489			0x9d4e31		c644243f00		MOVB $0x0, 0x3f(SP)										
  db.go:4489			0x9d4e36		488b942480000000	MOVQ 0x80(SP), DX										
  db.go:4489			0x9d4e3e		4c8b12			MOVQ 0(DX), R10											
  db.go:4489			0x9d4e41		41ffd2			CALL R10											
  db.go:4489			0x9d4e44		488b7c2440		MOVQ 0x40(SP), DI										
  db.go:4489			0x9d4e49		488b742448		MOVQ 0x48(SP), SI										
  db.go:4489			0x9d4e4e		488b442458		MOVQ 0x58(SP), AX										
  db.go:4489			0x9d4e53		488b5c2460		MOVQ 0x60(SP), BX										
  db.go:4489			0x9d4e58		4c8b442450		MOVQ 0x50(SP), R8										
  db.go:4489			0x9d4e5d		488b4c2468		MOVQ 0x68(SP), CX										
  db.go:4489			0x9d4e62		4881c488000000		ADDQ $0x88, SP											
  db.go:4489			0x9d4e69		5d			POPQ BP												
  db.go:4489			0x9d4e6a		c3			RET												
  db.go:4486			0x9d4e6b		4889742458		MOVQ SI, 0x58(SP)										
  db.go:4486			0x9d4e70		4c89442460		MOVQ R8, 0x60(SP)										
  db.go:4486			0x9d4e75		4c894c2468		MOVQ R9, 0x68(SP)										
  db.go:4486			0x9d4e7a		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  db.go:4486			0x9d4e83		4889542448		MOVQ DX, 0x48(SP)										
  db.go:4486			0x9d4e88		4c89542450		MOVQ R10, 0x50(SP)										
  db.go:4486			0x9d4e8d		488b7c2440		MOVQ 0x40(SP), DI										
  db.go:4486			0x9d4e92		488b442458		MOVQ 0x58(SP), AX										
  db.go:4486			0x9d4e97		488b5c2460		MOVQ 0x60(SP), BX										
  db.go:4486			0x9d4e9c		488b4c2468		MOVQ 0x68(SP), CX										
  db.go:4486			0x9d4ea1		4889d6			MOVQ DX, SI											
  db.go:4486			0x9d4ea4		4d89d0			MOVQ R10, R8											
  db.go:4486			0x9d4ea7		4881c488000000		ADDQ $0x88, SP											
  db.go:4486			0x9d4eae		5d			POPQ BP												
  db.go:4486			0x9d4eaf		c3			RET												
  type.go:181			0x9d4eb0		4c89d8			MOVQ R11, AX											
  snapshot_read_lifetime.go:12	0x9d4eb3		90			NOPL												
  type.go:181			0x9d4eb4		488b90b8010000		MOVQ 0x1b8(AX), DX										
  snapshot_read_lifetime.go:13	0x9d4ebb		480fbae23f		BTQ $0x3f, DX											
  snapshot_read_lifetime.go:13	0x9d4ec0		7227			JB 0x9d4ee9											
  snapshot_read_lifetime.go:16	0x9d4ec2		4c8d5201		LEAQ 0x1(DX), R10										
  snapshot_read_lifetime.go:8	0x9d4ec6		4989c3			MOVQ AX, R11											
  type.go:191			0x9d4ec9		4889d0			MOVQ DX, AX											
  type.go:191			0x9d4ecc		f04d0fb193b8010000	LOCK CMPXCHGQ R10, 0x1b8(R11)									
  type.go:191			0x9d4ed5		0f94c2			SETE DL												
  type.go:191			0x9d4ed8		84d2			TESTL DL, DL											
  snapshot_read_lifetime.go:16	0x9d4eda		74d4			JE 0x9d4eb0											
  db.go:4488			0x9d4edc		4c89d8			MOVQ R11, AX											
  db.go:4488			0x9d4edf		31d2			XORL DX, DX											
  db.go:4488			0x9d4ee1		4531d2			XORL R10, R10											
  db.go:4485			0x9d4ee4		e9d7feffff		JMP 0x9d4dc0											
  db.go:4485			0x9d4ee9		488b15008b0202		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), DX					
  db.go:4485			0x9d4ef0		4c8b15018b0202		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), R10					
  db.go:4485			0x9d4ef7		e9c4feffff		JMP 0x9d4dc0											
  db.go:4485			0x9d4efc		0f1f4000		NOPL 0(AX)											
  db.go:4485			0x9d4f00		e81bc1a7ff		CALL runtime.deferreturn(SB)									
  db.go:4485			0x9d4f05		488b442458		MOVQ 0x58(SP), AX										
  db.go:4485			0x9d4f0a		488b5c2460		MOVQ 0x60(SP), BX										
  db.go:4485			0x9d4f0f		488b4c2468		MOVQ 0x68(SP), CX										
  db.go:4485			0x9d4f14		488b7c2440		MOVQ 0x40(SP), DI										
  db.go:4485			0x9d4f19		488b742448		MOVQ 0x48(SP), SI										
  db.go:4485			0x9d4f1e		4c8b442450		MOVQ 0x50(SP), R8										
  db.go:4485			0x9d4f23		4881c488000000		ADDQ $0x88, SP											
  db.go:4485			0x9d4f2a		5d			POPQ BP												
  db.go:4485			0x9d4f2b		c3			RET												
  db.go:4484			0x9d4f2c		4889442408		MOVQ AX, 0x8(SP)										
  db.go:4484			0x9d4f31		48895c2410		MOVQ BX, 0x10(SP)										
  db.go:4484			0x9d4f36		48894c2418		MOVQ CX, 0x18(SP)										
  db.go:4484			0x9d4f3b		48897c2420		MOVQ DI, 0x20(SP)										
  db.go:4484			0x9d4f40		4889742428		MOVQ SI, 0x28(SP)										
  db.go:4484			0x9d4f45		4c89442430		MOVQ R8, 0x30(SP)										
  db.go:4484			0x9d4f4a		4c894c2438		MOVQ R9, 0x38(SP)										
  db.go:4484			0x9d4f4f		e8ccd7abff		CALL runtime.morestack_noctxt.abi0(SB)								
  db.go:4484			0x9d4f54		488b442408		MOVQ 0x8(SP), AX										
  db.go:4484			0x9d4f59		488b5c2410		MOVQ 0x10(SP), BX										
  db.go:4484			0x9d4f5e		488b4c2418		MOVQ 0x18(SP), CX										
  db.go:4484			0x9d4f63		488b7c2420		MOVQ 0x20(SP), DI										
  db.go:4484			0x9d4f68		488b742428		MOVQ 0x28(SP), SI										
  db.go:4484			0x9d4f6d		4c8b442430		MOVQ 0x30(SP), R8										
  db.go:4484			0x9d4f72		4c8b4c2438		MOVQ 0x38(SP), R9										
  db.go:4484			0x9d4f77		e9c4fdffff		JMP github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend(SB)			

TEXT github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend.deferwrap1(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:4488			0x9d4f80		493b6610		CMPQ SP, 0x10(R14)									
  db.go:4488			0x9d4f84		763e			JBE 0x9d4fc4										
  db.go:4488			0x9d4f86		55			PUSHQ BP										
  db.go:4488			0x9d4f87		4889e5			MOVQ SP, BP										
  db.go:4488			0x9d4f8a		4883ec08		SUBQ $0x8, SP										
  db.go:4488			0x9d4f8e		488b4208		MOVQ 0x8(DX), AX									
  snapshot_read_lifetime.go:23	0x9d4f92		4885c0			TESTQ AX, AX										
  snapshot_read_lifetime.go:23	0x9d4f95		7427			JE 0x9d4fbe										
  type.go:195			0x9d4f97		48c7c1ffffffff		MOVQ $-0x1, CX										
  type.go:195			0x9d4f9e		f0480fc188b8010000	LOCK XADDQ CX, 0x1b8(AX)								
  type.go:195			0x9d4fa7		48ffc9			DECQ CX											
  snapshot_read_lifetime.go:26	0x9d4faa		48ba0000000000000080	MOVQ $0x8000000000000000, DX								
  snapshot_read_lifetime.go:26	0x9d4fb4		4839ca			CMPQ DX, CX										
  snapshot_read_lifetime.go:26	0x9d4fb7		7505			JNE 0x9d4fbe										
  snapshot_read_lifetime.go:27	0x9d4fb9		e8c2f0feff		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseIfUnreferenced(SB)	
  db.go:4488			0x9d4fbe		4883c408		ADDQ $0x8, SP										
  db.go:4488			0x9d4fc2		5d			POPQ BP											
  db.go:4488			0x9d4fc3		c3			RET											
  db.go:4488			0x9d4fc4		e8b7d6abff		CALL runtime.morestack.abi0(SB)								
  db.go:4488			0x9d4fc9		ebb5			JMP github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).acquireOneShotReadOrErr(SB) github.com/snissn/gomap/TreeDB/db/pools.go
  pools.go:42		0xac9440		493b6610		CMPQ SP, 0x10(R14)										
  pools.go:42		0xac9444		0f8625010000		JBE 0xac956f											
  pools.go:42		0xac944a		55			PUSHQ BP											
  pools.go:42		0xac944b		4889e5			MOVQ SP, BP											
  pools.go:42		0xac944e		4883ec28		SUBQ $0x28, SP											
  pools.go:43		0xac9452		4885c0			TESTQ AX, AX											
  pools.go:43		0xac9455		0f84ee000000		JE 0xac9549											
  pools.go:43		0xac945b		4889442438		MOVQ AX, 0x38(SP)										
  pools.go:46		0xac9460		e8bb3cebff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).publicationPoisonedError(SB)			
  pools.go:46		0xac9465		4885c0			TESTQ AX, AX											
  pools.go:46		0xac9468		0f85cd000000		JNE 0xac953b											
  pools.go:49		0xac946e		488d056b19f401		LEAQ github.com/snissn/gomap/TreeDB/db.oneShotReadPool(SB), AX					
  pools.go:49		0xac9475		e886349dff		CALL sync.(*Pool).Get(SB)									
  pools.go:49		0xac947a		488d0d3fd3e900		LEAQ 0xe9d33f(IP), CX										
  pools.go:49		0xac9481		4839c8			CMPQ AX, CX											
  pools.go:49		0xac9484		0f85d5000000		JNE 0xac955f											
  pools.go:49		0xac948a		48895c2420		MOVQ BX, 0x20(SP)										
  pools.go:50		0xac948f		90			NOPL												
  type.go:94		0xac9490		ba01000000		MOVL $0x1, DX											
  type.go:94		0xac9495		488b442438		MOVQ 0x38(SP), AX										
  type.go:94		0xac949a		f00fc19088070000	LOCK XADDL DX, 0x788(AX)									
  type.go:94		0xac94a2		ffc2			INCL DX												
  rwmutex.go:72		0xac94a4		85d2			TESTL DX, DX											
  rwmutex.go:72		0xac94a6		7d19			JGE 0xac94c1											
  rwmutex.go:74		0xac94a8		480584070000		ADDQ $0x784, AX											
  rwmutex.go:74		0xac94ae		31db			XORL BX, BX											
  rwmutex.go:74		0xac94b0		31c9			XORL CX, CX											
  rwmutex.go:74		0xac94b2		e8094c9cff		CALL sync.runtime_SemacquireRWMutexR(SB)							
  pools.go:51		0xac94b7		488b442438		MOVQ 0x38(SP), AX										
  pools.go:51		0xac94bc		488b5c2420		MOVQ 0x20(SP), BX										
  pools.go:51		0xac94c1		8403			TESTB AL, 0(BX)											
  pools.go:51		0xac94c3		e8f889efff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotWithValueLogPublicationLockHeld(SB)	
  type.go:94		0xac94c8		bbffffffff		MOVL $-0x1, BX											
  type.go:94		0xac94cd		488b4c2438		MOVQ 0x38(SP), CX										
  type.go:94		0xac94d2		f00fc19988070000	LOCK XADDL BX, 0x788(CX)									
  type.go:94		0xac94da		ffcb			DECL BX												
  type.go:94		0xac94dc		0f1f4000		NOPL 0(AX)											
  rwmutex.go:120	0xac94e0		85db			TESTL BX, BX											
  rwmutex.go:120	0xac94e2		7d15			JGE 0xac94f9											
  pools.go:51		0xac94e4		8844241f		MOVB AL, 0x1f(SP)										
  pools.go:52		0xac94e8		488d8178070000		LEAQ 0x778(CX), AX										
  rwmutex.go:122	0xac94ef		e8cc409dff		CALL sync.(*RWMutex).rUnlockSlow(SB)								
  pools.go:51		0xac94f4		0fb644241f		MOVZX 0x1f(SP), AX										
  pools.go:51		0xac94f9		84c0			TESTL AL, AL											
  pools.go:53		0xac94fb		740f			JE 0xac950c											
  pools.go:57		0xac94fd		488b442420		MOVQ 0x20(SP), AX										
  pools.go:57		0xac9502		31db			XORL BX, BX											
  pools.go:57		0xac9504		31c9			XORL CX, CX											
  pools.go:57		0xac9506		4883c428		ADDQ $0x28, SP											
  pools.go:57		0xac950a		5d			POPQ BP												
  pools.go:57		0xac950b		c3			RET												
  pools.go:54		0xac950c		488d05cd18f401		LEAQ github.com/snissn/gomap/TreeDB/db.oneShotReadPool(SB), AX					
  pools.go:54		0xac9513		488d1da6d2e900		LEAQ 0xe9d2a6(IP), BX										
  pools.go:54		0xac951a		488b4c2420		MOVQ 0x20(SP), CX										
  pools.go:54		0xac951f		90			NOPL												
  pools.go:54		0xac9520		e81b339dff		CALL sync.(*Pool).Put(SB)									
  pools.go:55		0xac9525		488b1dc444f301		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), BX					
  pools.go:55		0xac952c		488b0dc544f301		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), CX					
  pools.go:55		0xac9533		31c0			XORL AX, AX											
  pools.go:55		0xac9535		4883c428		ADDQ $0x28, SP											
  pools.go:55		0xac9539		5d			POPQ BP												
  pools.go:55		0xac953a		c3			RET												
  pools.go:47		0xac953b		4889d9			MOVQ BX, CX											
  pools.go:47		0xac953e		4889c3			MOVQ AX, BX											
  pools.go:47		0xac9541		31c0			XORL AX, AX											
  pools.go:47		0xac9543		4883c428		ADDQ $0x28, SP											
  pools.go:47		0xac9547		5d			POPQ BP												
  pools.go:47		0xac9548		c3			RET												
  pools.go:44		0xac9549		488b1da044f301		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), BX					
  pools.go:44		0xac9550		488b0da144f301		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), CX					
  pools.go:44		0xac9557		31c0			XORL AX, AX											
  pools.go:44		0xac9559		4883c428		ADDQ $0x28, SP											
  pools.go:44		0xac955d		5d			POPQ BP												
  pools.go:44		0xac955e		c3			RET												
  pools.go:49		0xac955f		4889cb			MOVQ CX, BX											
  pools.go:49		0xac9562		488d0d1750e900		LEAQ 0xe95017(IP), CX										
  pools.go:49		0xac9569		e8927495ff		CALL runtime.panicdottypeE(SB)									
  pools.go:49		0xac956e		90			NOPL												
  pools.go:42		0xac956f		4889442408		MOVQ AX, 0x8(SP)										
  pools.go:42		0xac9574		e8a7919cff		CALL runtime.morestack_noctxt.abi0(SB)								
  pools.go:42		0xac9579		488b442408		MOVQ 0x8(SP), AX										
  pools.go:42		0xac957e		6690			NOPW												
  pools.go:42		0xac9580		e9bbfeffff		JMP github.com/snissn/gomap/TreeDB/db.(*DB).acquireOneShotReadOrErr(SB)				

TEXT github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB) github.com/snissn/gomap/TreeDB/db/pools.go
  pools.go:60		0xac95a0		493b6610		CMPQ SP, 0x10(R14)						
  pools.go:60		0xac95a4		0f8698000000		JBE 0xac9642							
  pools.go:60		0xac95aa		55			PUSHQ BP							
  pools.go:60		0xac95ab		4889e5			MOVQ SP, BP							
  pools.go:60		0xac95ae		4883ec38		SUBQ $0x38, SP							
  pools.go:69		0xac95b2		4889442448		MOVQ AX, 0x48(SP)						
  pools.go:63		0xac95b7		8400			TESTB AL, 0(AX)							
  pools.go:63		0xac95b9		e842a9efff		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).Close(SB)	
  pools.go:63		0xac95be		4889442428		MOVQ AX, 0x28(SP)						
  pools.go:63		0xac95c3		48895c2430		MOVQ BX, 0x30(SP)						
  pools.go:65		0xac95c8		488b442448		MOVQ 0x48(SP), AX						
  pools.go:65		0xac95cd		4805a0000000		ADDQ $0xa0, AX							
  pools.go:65		0xac95d3		31db			XORL BX, BX							
  pools.go:65		0xac95d5		31c9			XORL CX, CX							
  pools.go:65		0xac95d7		31ff			XORL DI, DI							
  pools.go:65		0xac95d9		31f6			XORL SI, SI							
  pools.go:65		0xac95db		0f1f440000		NOPL 0(AX)(AX*1)						
  pools.go:65		0xac95e0		e85bf4bdff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB)	
  pools.go:66		0xac95e5		833d0401050200		CMPL runtime.writeBarrier(SB), $0x0				
  pools.go:66		0xac95ec		7507			JNE 0xac95f5							
  pools.go:66		0xac95ee		488b4c2448		MOVQ 0x48(SP), CX						
  pools.go:66		0xac95f3		eb14			JMP 0xac9609							
  pools.go:66		0xac95f5		488b4c2448		MOVQ 0x48(SP), CX						
  pools.go:66		0xac95fa		488b91e0010000		MOVQ 0x1e0(CX), DX						
  pools.go:66		0xac9601		e8faab9cff		CALL runtime.gcWriteBarrier1(SB)				
  pools.go:66		0xac9606		498913			MOVQ DX, 0(R11)							
  pools.go:66		0xac9609		48c781e001000000000000	MOVQ $0x0, 0x1e0(CX)						
  pools.go:67		0xac9614		48c781e801000000000000	MOVQ $0x0, 0x1e8(CX)						
  pools.go:68		0xac961f		488d05ba17f401		LEAQ github.com/snissn/gomap/TreeDB/db.oneShotReadPool(SB), AX	
  pools.go:68		0xac9626		488d1d93d1e900		LEAQ 0xe9d193(IP), BX						
  pools.go:68		0xac962d		e80e329dff		CALL sync.(*Pool).Put(SB)					
  pools.go:69		0xac9632		488b442428		MOVQ 0x28(SP), AX						
  pools.go:69		0xac9637		488b5c2430		MOVQ 0x30(SP), BX						
  pools.go:69		0xac963c		4883c438		ADDQ $0x38, SP							
  pools.go:69		0xac9640		5d			POPQ BP								
  pools.go:69		0xac9641		c3			RET								
  pools.go:60		0xac9642		4889442408		MOVQ AX, 0x8(SP)						
  pools.go:60		0xac9647		e8d4909cff		CALL runtime.morestack_noctxt.abi0(SB)				
  pools.go:60		0xac964c		488b442408		MOVQ 0x8(SP), AX						
  pools.go:60		0xac9651		e94affffff		JMP github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned(SB) github.com/snissn/gomap/TreeDB/db/conditional_kv_contract_bench_test.go
  conditional_kv_contract_bench_test.go:12	0xc48400		4c8da424c8f8ffff	LEAQ 0xfffff8c8(SP), R12							
  conditional_kv_contract_bench_test.go:12	0xc48408		4d3b6610		CMPQ R12, 0x10(R14)								
  conditional_kv_contract_bench_test.go:12	0xc4840c		0f864d020000		JBE 0xc4865f									
  conditional_kv_contract_bench_test.go:12	0xc48412		55			PUSHQ BP									
  conditional_kv_contract_bench_test.go:12	0xc48413		4889e5			MOVQ SP, BP									
  conditional_kv_contract_bench_test.go:12	0xc48416		4881ecb0070000		SUBQ $0x7b0, SP									
  conditional_kv_contract_bench_test.go:12	0xc4841d		66440fd6bc24a8070000	MOVQ X15, 0x7a8(SP)								
  conditional_kv_contract_bench_test.go:14	0xc48427		48898424c0070000	MOVQ AX, 0x7c0(SP)								
  conditional_kv_contract_bench_test.go:12	0xc4842f		c684245707000000	MOVB $0x0, 0x757(SP)								
  conditional_kv_contract_bench_test.go:13	0xc48437		8400			TESTB AL, 0(AX)									
  conditional_kv_contract_bench_test.go:13	0xc48439		e842128fff		CALL testing.(*common).TempDir(SB)						
  conditional_kv_contract_bench_test.go:13	0xc4843e		4889e7			MOVQ SP, DI									
  conditional_kv_contract_bench_test.go:13	0xc48441		b9ea000000		MOVL $0xea, CX									
  conditional_kv_contract_bench_test.go:13	0xc48446		4889c2			MOVQ AX, DX									
  conditional_kv_contract_bench_test.go:13	0xc48449		31c0			XORL AX, AX									
  conditional_kv_contract_bench_test.go:13	0xc4844b		f348ab			REP; STOSQ AX, ES:0(DI)								
  conditional_kv_contract_bench_test.go:13	0xc4844e		4889542408		MOVQ DX, 0x8(SP)								
  conditional_kv_contract_bench_test.go:13	0xc48453		48895c2410		MOVQ BX, 0x10(SP)								
  conditional_kv_contract_bench_test.go:13	0xc48458		e803bfd7ff		CALL github.com/snissn/gomap/TreeDB/db.Open(SB)					
  conditional_kv_contract_bench_test.go:13	0xc4845d		4889842470070000	MOVQ AX, 0x770(SP)								
  conditional_kv_contract_bench_test.go:14	0xc48465		4885db			TESTQ BX, BX									
  conditional_kv_contract_bench_test.go:14	0xc48468		7450			JE 0xc484ba									
  conditional_kv_contract_bench_test.go:15	0xc4846a		440f11bc2498070000	MOVUPS X15, 0x798(SP)								
  conditional_kv_contract_bench_test.go:15	0xc48473		7404			JE 0xc48479									
  conditional_kv_contract_bench_test.go:15	0xc48475		488b5b08		MOVQ 0x8(BX), BX								
  conditional_kv_contract_bench_test.go:15	0xc48479		48899c2498070000	MOVQ BX, 0x798(SP)								
  conditional_kv_contract_bench_test.go:15	0xc48481		48898c24a0070000	MOVQ CX, 0x7a0(SP)								
  conditional_kv_contract_bench_test.go:15	0xc48489		488b8424c0070000	MOVQ 0x7c0(SP), AX								
  conditional_kv_contract_bench_test.go:15	0xc48491		488d1d6f40ec00		LEAQ 0xec406f(IP), BX								
  conditional_kv_contract_bench_test.go:15	0xc48498		b908000000		MOVL $0x8, CX									
  conditional_kv_contract_bench_test.go:15	0xc4849d		488dbc2498070000	LEAQ 0x798(SP), DI								
  conditional_kv_contract_bench_test.go:15	0xc484a5		be01000000		MOVL $0x1, SI									
  conditional_kv_contract_bench_test.go:15	0xc484aa		4989f0			MOVQ SI, R8									
  conditional_kv_contract_bench_test.go:15	0xc484ad		e88e048fff		CALL testing.(*common).Fatalf(SB)						
  conditional_kv_contract_bench_test.go:17	0xc484b2		488b842470070000	MOVQ 0x770(SP), AX								
  conditional_kv_contract_bench_test.go:17	0xc484ba		488d151f050000		LEAQ github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func1(SB), DX	
  conditional_kv_contract_bench_test.go:17	0xc484c1		4889942480070000	MOVQ DX, 0x780(SP)								
  conditional_kv_contract_bench_test.go:17	0xc484c9		4889842488070000	MOVQ AX, 0x788(SP)								
  conditional_kv_contract_bench_test.go:17	0xc484d1		488b9424c0070000	MOVQ 0x7c0(SP), DX								
  conditional_kv_contract_bench_test.go:17	0xc484d9		4889942490070000	MOVQ DX, 0x790(SP)								
  conditional_kv_contract_bench_test.go:17	0xc484e1		488d942480070000	LEAQ 0x780(SP), DX								
  conditional_kv_contract_bench_test.go:17	0xc484e9		48899424a8070000	MOVQ DX, 0x7a8(SP)								
  conditional_kv_contract_bench_test.go:17	0xc484f1		c684245707000001	MOVB $0x1, 0x757(SP)								
  conditional_kv_contract_bench_test.go:24	0xc484f9		488d0580d3cd00		LEAQ 0xcdd380(IP), AX								
  conditional_kv_contract_bench_test.go:24	0xc48500		bb64000000		MOVL $0x64, BX									
  conditional_kv_contract_bench_test.go:24	0xc48505		4889d9			MOVQ BX, CX									
  conditional_kv_contract_bench_test.go:24	0xc48508		e8536784ff		CALL runtime.makeslice(SB)							
  conditional_kv_contract_bench_test.go:24	0xc4850d		4889842478070000	MOVQ AX, 0x778(SP)								
  conditional_kv_contract_bench_test.go:25	0xc48515		b810270000		MOVL $0x2710, AX								
  conditional_kv_contract_bench_test.go:25	0xc4851a		e8c11c0000		CALL github.com/snissn/gomap/TreeDB/db.benchmarkConditionalTxnKeys(SB)		
  conditional_kv_contract_bench_test.go:25	0xc4851f		4889842468070000	MOVQ AX, 0x768(SP)								
  conditional_kv_contract_bench_test.go:25	0xc48527		48899c2458070000	MOVQ BX, 0x758(SP)								
  conditional_kv_contract_bench_test.go:25	0xc4852f		48898c2460070000	MOVQ CX, 0x760(SP)								
  conditional_kv_contract_bench_test.go:26	0xc48537		4889df			MOVQ BX, DI									
  conditional_kv_contract_bench_test.go:26	0xc4853a		4889ce			MOVQ CX, SI									
  conditional_kv_contract_bench_test.go:26	0xc4853d		4c8b842478070000	MOVQ 0x778(SP), R8								
  conditional_kv_contract_bench_test.go:26	0xc48545		41b964000000		MOVL $0x64, R9									
  conditional_kv_contract_bench_test.go:26	0xc4854b		4d89ca			MOVQ R9, R10									
  conditional_kv_contract_bench_test.go:26	0xc4854e		488b9c2470070000	MOVQ 0x770(SP), BX								
  conditional_kv_contract_bench_test.go:26	0xc48556		4889c1			MOVQ AX, CX									
  conditional_kv_contract_bench_test.go:26	0xc48559		488b8424c0070000	MOVQ 0x7c0(SP), AX								
  conditional_kv_contract_bench_test.go:26	0xc48561		e87a1d0000		CALL github.com/snissn/gomap/TreeDB/db.seedConditionalTxnBenchmarkData(SB)	
  conditional_kv_contract_bench_test.go:28	0xc48566		90			NOPL										
  benchmark.go:193				0xc48567		488b8424c0070000	MOVQ 0x7c0(SP), AX								
  benchmark.go:193				0xc4856f		c6805202000001		MOVB $0x1, 0x252(AX)								
  conditional_kv_contract_bench_test.go:29	0xc48576		e8a53e8eff		CALL testing.(*B).ResetTimer(SB)						
  conditional_kv_contract_bench_test.go:30	0xc4857b		488d059ed8df00		LEAQ 0xdfd89e(IP), AX								
  conditional_kv_contract_bench_test.go:30	0xc48582		e819c57dff		CALL runtime.newobject(SB)							
  conditional_kv_contract_bench_test.go:30	0xc48587		488d15f2000000		LEAQ github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func2(SB), DX	
  conditional_kv_contract_bench_test.go:30	0xc4858e		488910			MOVQ DX, 0(AX)									
  conditional_kv_contract_bench_test.go:30	0xc48591		48c7401064000000	MOVQ $0x64, 0x10(AX)								
  conditional_kv_contract_bench_test.go:30	0xc48599		48c7401864000000	MOVQ $0x64, 0x18(AX)								
  conditional_kv_contract_bench_test.go:30	0xc485a1		833d4811ed0100		CMPL runtime.writeBarrier(SB), $0x0						
  conditional_kv_contract_bench_test.go:30	0xc485a8		7522			JNE 0xc485cc									
  conditional_kv_contract_bench_test.go:30	0xc485aa		488b8c2478070000	MOVQ 0x778(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xc485b2		488b942470070000	MOVQ 0x770(SP), DX								
  conditional_kv_contract_bench_test.go:30	0xc485ba		488bb42468070000	MOVQ 0x768(SP), SI								
  conditional_kv_contract_bench_test.go:30	0xc485c2		488bbc24c0070000	MOVQ 0x7c0(SP), DI								
  conditional_kv_contract_bench_test.go:30	0xc485ca		eb34			JMP 0xc48600									
  conditional_kv_contract_bench_test.go:30	0xc485cc		e88fbc84ff		CALL runtime.gcWriteBarrier4(SB)						
  conditional_kv_contract_bench_test.go:30	0xc485d1		488b8c2478070000	MOVQ 0x778(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xc485d9		49890b			MOVQ CX, 0(R11)									
  conditional_kv_contract_bench_test.go:30	0xc485dc		488b942470070000	MOVQ 0x770(SP), DX								
  conditional_kv_contract_bench_test.go:30	0xc485e4		49895308		MOVQ DX, 0x8(R11)								
  conditional_kv_contract_bench_test.go:30	0xc485e8		488bb42468070000	MOVQ 0x768(SP), SI								
  conditional_kv_contract_bench_test.go:30	0xc485f0		49897310		MOVQ SI, 0x10(R11)								
  conditional_kv_contract_bench_test.go:30	0xc485f4		488bbc24c0070000	MOVQ 0x7c0(SP), DI								
  conditional_kv_contract_bench_test.go:30	0xc485fc		49897b18		MOVQ DI, 0x18(R11)								
  conditional_kv_contract_bench_test.go:30	0xc48600		48894808		MOVQ CX, 0x8(AX)								
  conditional_kv_contract_bench_test.go:30	0xc48604		48895020		MOVQ DX, 0x20(AX)								
  conditional_kv_contract_bench_test.go:30	0xc48608		488b8c2458070000	MOVQ 0x758(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xc48610		48894830		MOVQ CX, 0x30(AX)								
  conditional_kv_contract_bench_test.go:30	0xc48614		488b8c2460070000	MOVQ 0x760(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xc4861c		48894838		MOVQ CX, 0x38(AX)								
  conditional_kv_contract_bench_test.go:30	0xc48620		48897028		MOVQ SI, 0x28(AX)								
  conditional_kv_contract_bench_test.go:30	0xc48624		48897840		MOVQ DI, 0x40(AX)								
  conditional_kv_contract_bench_test.go:30	0xc48628		4889c3			MOVQ AX, BX									
  conditional_kv_contract_bench_test.go:30	0xc4862b		4889f8			MOVQ DI, AX									
  conditional_kv_contract_bench_test.go:30	0xc4862e		e88d738eff		CALL testing.(*B).RunParallel(SB)						
  conditional_kv_contract_bench_test.go:43	0xc48633		c684245707000000	MOVB $0x0, 0x757(SP)								
  conditional_kv_contract_bench_test.go:43	0xc4863b		488b9424a8070000	MOVQ 0x7a8(SP), DX								
  conditional_kv_contract_bench_test.go:43	0xc48643		488b0a			MOVQ 0(DX), CX									
  conditional_kv_contract_bench_test.go:43	0xc48646		ffd1			CALL CX										
  conditional_kv_contract_bench_test.go:43	0xc48648		4881c4b0070000		ADDQ $0x7b0, SP									
  conditional_kv_contract_bench_test.go:43	0xc4864f		5d			POPQ BP										
  conditional_kv_contract_bench_test.go:43	0xc48650		c3			RET										
  conditional_kv_contract_bench_test.go:43	0xc48651		e8ca8980ff		CALL runtime.deferreturn(SB)							
  conditional_kv_contract_bench_test.go:43	0xc48656		4881c4b0070000		ADDQ $0x7b0, SP									
  conditional_kv_contract_bench_test.go:43	0xc4865d		5d			POPQ BP										
  conditional_kv_contract_bench_test.go:43	0xc4865e		c3			RET										
  conditional_kv_contract_bench_test.go:12	0xc4865f		4889442408		MOVQ AX, 0x8(SP)								
  conditional_kv_contract_bench_test.go:12	0xc48664		e8b7a084ff		CALL runtime.morestack_noctxt.abi0(SB)						
  conditional_kv_contract_bench_test.go:12	0xc48669		488b442408		MOVQ 0x8(SP), AX								
  conditional_kv_contract_bench_test.go:12	0xc4866e		e98dfdffff		JMP github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned(SB)			

TEXT github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func2(SB) github.com/snissn/gomap/TreeDB/db/conditional_kv_contract_bench_test.go
  conditional_kv_contract_bench_test.go:30	0xc48680		4c8d642480		LEAQ -0x80(SP), R12							
  conditional_kv_contract_bench_test.go:30	0xc48685		4d3b6610		CMPQ R12, 0x10(R14)							
  conditional_kv_contract_bench_test.go:30	0xc48689		0f8625030000		JBE 0xc489b4								
  conditional_kv_contract_bench_test.go:30	0xc4868f		55			PUSHQ BP								
  conditional_kv_contract_bench_test.go:30	0xc48690		4889e5			MOVQ SP, BP								
  conditional_kv_contract_bench_test.go:30	0xc48693		4881ecf8000000		SUBQ $0xf8, SP								
  time.go:182					0xc4869a		4889842408010000	MOVQ AX, 0x108(SP)							
  conditional_kv_contract_bench_test.go:30	0xc486a2		488b4230		MOVQ 0x30(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xc486a6		4889442458		MOVQ AX, 0x58(SP)							
  conditional_kv_contract_bench_test.go:30	0xc486ab		488b4240		MOVQ 0x40(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xc486af		4889442470		MOVQ AX, 0x70(SP)							
  conditional_kv_contract_bench_test.go:30	0xc486b4		488b4210		MOVQ 0x10(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xc486b8		4889442440		MOVQ AX, 0x40(SP)							
  conditional_kv_contract_bench_test.go:30	0xc486bd		488b4228		MOVQ 0x28(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xc486c1		4889442460		MOVQ AX, 0x60(SP)							
  conditional_kv_contract_bench_test.go:30	0xc486c6		488b4220		MOVQ 0x20(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xc486ca		4889442468		MOVQ AX, 0x68(SP)							
  conditional_kv_contract_bench_test.go:31	0xc486cf		e82c5d87ff		CALL time.Now(SB)							
  time.go:189					0xc486d4		90			NOPL									
  time.go:182					0xc486d5		480fbae03f		BTQ $0x3f, AX								
  time.go:182					0xc486da		7316			JAE 0xc486f2								
  time.go:183					0xc486dc		488d0c00		LEAQ 0(AX)(AX*1), CX							
  time.go:183					0xc486e0		48c1e91f		SHRQ $0x1f, CX								
  time.go:183					0xc486e4		48ba807fb1d70d000000	MOVQ $0xdd7b17f80, DX							
  time.go:183					0xc486ee		488d1c11		LEAQ 0(CX)(DX*1), BX							
  time.go:1461					0xc486f2		4869cb00ca9a3b		IMULQ $0x3b9aca00, BX, CX						
  time.go:177					0xc486f9		25ffffff3f		ANDL $0x3fffffff, AX							
  time.go:1461					0xc486fe		4863d0			MOVSXD AX, DX								
  time.go:1461					0xc48701		4801d1			ADDQ DX, CX								
  time.go:1461					0xc48704		48ba00001a3deb03b2a1	MOVQ $0xa1b203eb3d1a0000, DX						
  time.go:1461					0xc4870e		4801d1			ADDQ DX, CX								
  time.go:1461					0xc48711		48894c2438		MOVQ CX, 0x38(SP)							
  rand.go:52					0xc48716		90			NOPL									
  rand.go:56					0xc48717		488d05a2b7dc00		LEAQ 0xdcb7a2(IP), AX							
  rand.go:56					0xc4871e		6690			NOPW									
  rand.go:56					0xc48720		e87bc37dff		CALL runtime.newobject(SB)						
  rand.go:56					0xc48725		48898424f0000000	MOVQ AX, 0xf0(SP)							
  rand.go:57					0xc4872d		488b5c2438		MOVQ 0x38(SP), BX							
  rand.go:57					0xc48732		e8890d8eff		CALL math/rand.(*rngSource).Seed(SB)					
  rand.go:79					0xc48737		488b0dc2a2db01		MOVQ github.com/snissn/gomap/TreeDB/db..typeAssert.158(SB), CX		
  rand.go:79					0xc4873e		488b11			MOVQ 0(CX), DX								
  rand.go:79					0xc48741		8b1d91920001		MOVL go:itab.*math/rand.rngSource,math/rand.Source+16(SB), BX		
  rand.go:79					0xc48747		eb03			JMP 0xc4874c								
  rand.go:79					0xc48749		4889f3			MOVQ SI, BX								
  rand.go:79					0xc4874c		4889de			MOVQ BX, SI								
  rand.go:79					0xc4874f		4821d3			ANDQ DX, BX								
  rand.go:79					0xc48752		48c1e304		SHLQ $0x4, BX								
  rand.go:79					0xc48756		488b7c0b08		MOVQ 0x8(BX)(CX*1), DI							
  rand.go:79					0xc4875b		4c8d05bef1d500		LEAQ 0xd5f1be(IP), R8							
  rand.go:79					0xc48762		4c39c7			CMPQ DI, R8								
  rand.go:79					0xc48765		741b			JE 0xc48782								
  rand.go:79					0xc48767		48ffc6			INCQ SI									
  rand.go:79					0xc4876a		4885ff			TESTQ DI, DI								
  rand.go:79					0xc4876d		75da			JNE 0xc48749								
  rand.go:79					0xc4876f		488d058aa2db01		LEAQ github.com/snissn/gomap/TreeDB/db..typeAssert.158(SB), AX		
  rand.go:79					0xc48776		4c89c3			MOVQ R8, BX								
  rand.go:79					0xc48779		e842877dff		CALL runtime.typeAssert(SB)						
  rand.go:79					0xc4877e		6690			NOPW									
  rand.go:79					0xc48780		eb05			JMP 0xc48787								
  rand.go:79					0xc48782		488b440b10		MOVQ 0x10(BX)(CX*1), AX							
  rand.go:80					0xc48787		488d942480000000	LEAQ 0x80(SP), DX							
  rand.go:80					0xc4878f		440f113a		MOVUPS X15, 0(DX)							
  rand.go:80					0xc48793		440f117a10		MOVUPS X15, 0x10(DX)							
  rand.go:80					0xc48798		440f117a20		MOVUPS X15, 0x20(DX)							
  rand.go:80					0xc4879d		488d1524920001		LEAQ go:itab.*math/rand.rngSource,math/rand.Source(SB), DX		
  rand.go:80					0xc487a4		4889942480000000	MOVQ DX, 0x80(SP)							
  rand.go:80					0xc487ac		488b9424f0000000	MOVQ 0xf0(SP), DX							
  rand.go:80					0xc487b4		4889942488000000	MOVQ DX, 0x88(SP)							
  rand.go:80					0xc487bc		4889842490000000	MOVQ AX, 0x90(SP)							
  rand.go:80					0xc487c4		4889942498000000	MOVQ DX, 0x98(SP)							
  conditional_kv_contract_bench_test.go:32	0xc487cc		488d05add0cd00		LEAQ 0xcdd0ad(IP), AX							
  conditional_kv_contract_bench_test.go:32	0xc487d3		31db			XORL BX, BX								
  conditional_kv_contract_bench_test.go:32	0xc487d5		488b4c2440		MOVQ 0x40(SP), CX							
  conditional_kv_contract_bench_test.go:32	0xc487da		e8816484ff		CALL runtime.makeslice(SB)						
  conditional_kv_contract_bench_test.go:32	0xc487df		4889442478		MOVQ AX, 0x78(SP)							
  conditional_kv_contract_bench_test.go:33	0xc487e4		eb05			JMP 0xc487eb								
  conditional_kv_contract_bench_test.go:34	0xc487e6		488b442478		MOVQ 0x78(SP), AX							
  benchmark.go:923				0xc487eb		488b8c2408010000	MOVQ 0x108(SP), CX							
  benchmark.go:923				0xc487f3		4883791000		CMPQ 0x10(CX), $0x0							
  benchmark.go:923				0xc487f8		753c			JNE 0xc48836								
  benchmark.go:924				0xc487fa		488b11			MOVQ 0(CX), DX								
  benchmark.go:924				0xc487fd		488b7108		MOVQ 0x8(CX), SI							
  type.go:195					0xc48801		4889f7			MOVQ SI, DI								
  type.go:195					0xc48804		f0480fc132		LOCK XADDQ SI, 0(DX)							
  benchmark.go:925				0xc48809		488b5118		MOVQ 0x18(CX), DX							
  type.go:195					0xc4880d		4801fe			ADDQ DI, SI								
  benchmark.go:925				0xc48810		4839f2			CMPQ DX, SI								
  benchmark.go:925				0xc48813		720a			JB 0xc4881f								
  benchmark.go:926				0xc48815		488b5108		MOVQ 0x8(CX), DX							
  benchmark.go:926				0xc48819		48895110		MOVQ DX, 0x10(CX)							
  benchmark.go:926				0xc4881d		eb17			JMP 0xc48836								
  benchmark.go:927				0xc4881f		488b7908		MOVQ 0x8(CX), DI							
  benchmark.go:927				0xc48823		4801fa			ADDQ DI, DX								
  benchmark.go:927				0xc48826		4839d6			CMPQ SI, DX								
  benchmark.go:927				0xc48829		0f8376010000		JAE 0xc489a5								
  benchmark.go:928				0xc4882f		4829f2			SUBQ SI, DX								
  benchmark.go:928				0xc48832		48895110		MOVQ DX, 0x10(CX)							
  benchmark.go:933				0xc48836		48ff4910		DECQ 0x10(CX)								
  conditional_kv_contract_bench_test.go:34	0xc4883a		488d842480000000	LEAQ 0x80(SP), AX							
  conditional_kv_contract_bench_test.go:34	0xc48842		bb10270000		MOVL $0x2710, BX							
  conditional_kv_contract_bench_test.go:34	0xc48847		e854fe8dff		CALL math/rand.(*Rand).Intn(SB)						
  conditional_kv_contract_bench_test.go:34	0xc4884c		488b4c2458		MOVQ 0x58(SP), CX							
  conditional_kv_contract_bench_test.go:34	0xc48851		4839c8			CMPQ AX, CX								
  conditional_kv_contract_bench_test.go:34	0xc48854		0f8354010000		JAE 0xc489ae								
  conditional_kv_contract_bench_test.go:34	0xc4885a		488d1440		LEAQ 0(AX)(AX*2), DX							
  conditional_kv_contract_bench_test.go:34	0xc4885e		4c8b542460		MOVQ 0x60(SP), R10							
  conditional_kv_contract_bench_test.go:34	0xc48863		498b1cd2		MOVQ 0(R10)(DX*8), BX							
  conditional_kv_contract_bench_test.go:34	0xc48867		498b4cd208		MOVQ 0x8(R10)(DX*8), CX							
  conditional_kv_contract_bench_test.go:34	0xc4886c		498b7cd210		MOVQ 0x10(R10)(DX*8), DI						
  conditional_kv_contract_bench_test.go:34	0xc48871		488b442468		MOVQ 0x68(SP), AX							
  conditional_kv_contract_bench_test.go:34	0xc48876		488b742478		MOVQ 0x78(SP), SI							
  conditional_kv_contract_bench_test.go:34	0xc4887b		4531c0			XORL R8, R8								
  conditional_kv_contract_bench_test.go:34	0xc4887e		4c8b4c2440		MOVQ 0x40(SP), R9							
  conditional_kv_contract_bench_test.go:34	0xc48883		e89897d0ff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend(SB)	
  conditional_kv_contract_bench_test.go:34	0xc48888		48897c2448		MOVQ DI, 0x48(SP)							
  conditional_kv_contract_bench_test.go:35	0xc4888d		4885f6			TESTQ SI, SI								
  conditional_kv_contract_bench_test.go:35	0xc48890		7456			JE 0xc488e8								
  conditional_kv_contract_bench_test.go:34	0xc48892		48895c2450		MOVQ BX, 0x50(SP)							
  conditional_kv_contract_bench_test.go:36	0xc48897		440f11bc24e0000000	MOVUPS X15, 0xe0(SP)							
  conditional_kv_contract_bench_test.go:36	0xc488a0		7404			JE 0xc488a6								
  conditional_kv_contract_bench_test.go:36	0xc488a2		488b7608		MOVQ 0x8(SI), SI							
  conditional_kv_contract_bench_test.go:36	0xc488a6		4889b424e0000000	MOVQ SI, 0xe0(SP)							
  conditional_kv_contract_bench_test.go:36	0xc488ae		4c898424e8000000	MOVQ R8, 0xe8(SP)							
  conditional_kv_contract_bench_test.go:36	0xc488b6		488b442470		MOVQ 0x70(SP), AX							
  conditional_kv_contract_bench_test.go:36	0xc488bb		8400			TESTB AL, 0(AX)								
  conditional_kv_contract_bench_test.go:36	0xc488bd		488d1ddeaaed00		LEAQ 0xedaade(IP), BX							
  conditional_kv_contract_bench_test.go:36	0xc488c4		b916000000		MOVL $0x16, CX								
  conditional_kv_contract_bench_test.go:36	0xc488c9		488dbc24e0000000	LEAQ 0xe0(SP), DI							
  conditional_kv_contract_bench_test.go:36	0xc488d1		be01000000		MOVL $0x1, SI								
  conditional_kv_contract_bench_test.go:36	0xc488d6		4989f0			MOVQ SI, R8								
  conditional_kv_contract_bench_test.go:36	0xc488d9		e862008fff		CALL testing.(*common).Fatalf(SB)					
  conditional_kv_contract_bench_test.go:38	0xc488de		488b5c2450		MOVQ 0x50(SP), BX							
  conditional_kv_contract_bench_test.go:38	0xc488e3		488b7c2448		MOVQ 0x48(SP), DI							
  conditional_kv_contract_bench_test.go:38	0xc488e8		488b4c2440		MOVQ 0x40(SP), CX							
  conditional_kv_contract_bench_test.go:38	0xc488ed		4839cb			CMPQ BX, CX								
  conditional_kv_contract_bench_test.go:38	0xc488f0		7509			JNE 0xc488fb								
  conditional_kv_contract_bench_test.go:38	0xc488f2		4885ff			TESTQ DI, DI								
  conditional_kv_contract_bench_test.go:38	0xc488f5		0f85ebfeffff		JNE 0xc487e6								
  conditional_kv_contract_bench_test.go:39	0xc488fb		488d8c24b0000000	LEAQ 0xb0(SP), CX							
  conditional_kv_contract_bench_test.go:39	0xc48903		440f1139		MOVUPS X15, 0(CX)							
  conditional_kv_contract_bench_test.go:39	0xc48907		440f117910		MOVUPS X15, 0x10(CX)							
  conditional_kv_contract_bench_test.go:39	0xc4890c		440f117920		MOVUPS X15, 0x20(CX)							
  conditional_kv_contract_bench_test.go:39	0xc48911		4889d8			MOVQ BX, AX								
  conditional_kv_contract_bench_test.go:39	0xc48914		e8271284ff		CALL runtime.convT64(SB)						
  conditional_kv_contract_bench_test.go:39	0xc48919		488d0d20d1cd00		LEAQ 0xcdd120(IP), CX							
  conditional_kv_contract_bench_test.go:39	0xc48920		48898c24b0000000	MOVQ CX, 0xb0(SP)							
  conditional_kv_contract_bench_test.go:39	0xc48928		48898424b8000000	MOVQ AX, 0xb8(SP)							
  conditional_kv_contract_bench_test.go:39	0xc48930		488b442448		MOVQ 0x48(SP), AX							
  conditional_kv_contract_bench_test.go:39	0xc48935		e8061284ff		CALL runtime.convT64(SB)						
  conditional_kv_contract_bench_test.go:39	0xc4893a		488d0dffdccd00		LEAQ 0xcddcff(IP), CX							
  conditional_kv_contract_bench_test.go:39	0xc48941		48898c24c0000000	MOVQ CX, 0xc0(SP)							
  conditional_kv_contract_bench_test.go:39	0xc48949		48898424c8000000	MOVQ AX, 0xc8(SP)							
  conditional_kv_contract_bench_test.go:39	0xc48951		488b442440		MOVQ 0x40(SP), AX							
  conditional_kv_contract_bench_test.go:39	0xc48956		e8e51184ff		CALL runtime.convT64(SB)						
  conditional_kv_contract_bench_test.go:39	0xc4895b		488d0dded0cd00		LEAQ 0xcdd0de(IP), CX							
  conditional_kv_contract_bench_test.go:39	0xc48962		48898c24d0000000	MOVQ CX, 0xd0(SP)							
  conditional_kv_contract_bench_test.go:39	0xc4896a		48898424d8000000	MOVQ AX, 0xd8(SP)							
  conditional_kv_contract_bench_test.go:39	0xc48972		488b442470		MOVQ 0x70(SP), AX							
  conditional_kv_contract_bench_test.go:39	0xc48977		8400			TESTB AL, 0(AX)								
  conditional_kv_contract_bench_test.go:39	0xc48979		488d1deedefa00		LEAQ 0xfadeee(IP), BX							
  conditional_kv_contract_bench_test.go:39	0xc48980		b946000000		MOVL $0x46, CX								
  conditional_kv_contract_bench_test.go:39	0xc48985		488dbc24b0000000	LEAQ 0xb0(SP), DI							
  conditional_kv_contract_bench_test.go:39	0xc4898d		be03000000		MOVL $0x3, SI								
  conditional_kv_contract_bench_test.go:39	0xc48992		4989f0			MOVQ SI, R8								
  conditional_kv_contract_bench_test.go:39	0xc48995		e8a6ff8eff		CALL testing.(*common).Fatalf(SB)					
  conditional_kv_contract_bench_test.go:34	0xc4899a		488b4c2440		MOVQ 0x40(SP), CX							
  conditional_kv_contract_bench_test.go:34	0xc4899f		90			NOPL									
  conditional_kv_contract_bench_test.go:39	0xc489a0		e941feffff		JMP 0xc487e6								
  conditional_kv_contract_bench_test.go:42	0xc489a5		4881c4f8000000		ADDQ $0xf8, SP								
  conditional_kv_contract_bench_test.go:42	0xc489ac		5d			POPQ BP									
  conditional_kv_contract_bench_test.go:42	0xc489ad		c3			RET									
  conditional_kv_contract_bench_test.go:34	0xc489ae		e80dbc84ff		CALL runtime.panicBounds(SB)						
  conditional_kv_contract_bench_test.go:34	0xc489b3		90			NOPL									
  conditional_kv_contract_bench_test.go:30	0xc489b4		4889442408		MOVQ AX, 0x8(SP)							
  conditional_kv_contract_bench_test.go:30	0xc489b9		e8c29c84ff		CALL runtime.morestack.abi0(SB)						
  conditional_kv_contract_bench_test.go:30	0xc489be		488b442408		MOVQ 0x8(SP), AX							
  conditional_kv_contract_bench_test.go:30	0xc489c3		e9b8fcffff		JMP github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func2(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func1(SB) github.com/snissn/gomap/TreeDB/db/conditional_kv_contract_bench_test.go
  conditional_kv_contract_bench_test.go:17	0xc489e0		493b6610		CMPQ SP, 0x10(R14)							
  conditional_kv_contract_bench_test.go:17	0xc489e4		7665			JBE 0xc48a4b								
  conditional_kv_contract_bench_test.go:17	0xc489e6		55			PUSHQ BP								
  conditional_kv_contract_bench_test.go:17	0xc489e7		4889e5			MOVQ SP, BP								
  conditional_kv_contract_bench_test.go:17	0xc489ea		4883ec48		SUBQ $0x48, SP								
  conditional_kv_contract_bench_test.go:17	0xc489ee		488b4208		MOVQ 0x8(DX), AX							
  conditional_kv_contract_bench_test.go:17	0xc489f2		488b4a10		MOVQ 0x10(DX), CX							
  conditional_kv_contract_bench_test.go:17	0xc489f6		48894c2430		MOVQ CX, 0x30(SP)							
  conditional_kv_contract_bench_test.go:18	0xc489fb		0f1f440000		NOPL 0(AX)(AX*1)							
  conditional_kv_contract_bench_test.go:18	0xc48a00		e8fb22d8ff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).Close(SB)			
  conditional_kv_contract_bench_test.go:18	0xc48a05		4885c0			TESTQ AX, AX								
  conditional_kv_contract_bench_test.go:18	0xc48a08		743b			JE 0xc48a45								
  conditional_kv_contract_bench_test.go:19	0xc48a0a		440f117c2438		MOVUPS X15, 0x38(SP)							
  conditional_kv_contract_bench_test.go:19	0xc48a10		7404			JE 0xc48a16								
  conditional_kv_contract_bench_test.go:19	0xc48a12		488b4008		MOVQ 0x8(AX), AX							
  conditional_kv_contract_bench_test.go:19	0xc48a16		4889442438		MOVQ AX, 0x38(SP)							
  conditional_kv_contract_bench_test.go:19	0xc48a1b		48895c2440		MOVQ BX, 0x40(SP)							
  conditional_kv_contract_bench_test.go:19	0xc48a20		488b442430		MOVQ 0x30(SP), AX							
  conditional_kv_contract_bench_test.go:19	0xc48a25		8400			TESTB AL, 0(AX)								
  conditional_kv_contract_bench_test.go:19	0xc48a27		488d1db047ec00		LEAQ 0xec47b0(IP), BX							
  conditional_kv_contract_bench_test.go:19	0xc48a2e		b909000000		MOVL $0x9, CX								
  conditional_kv_contract_bench_test.go:19	0xc48a33		488d7c2438		LEAQ 0x38(SP), DI							
  conditional_kv_contract_bench_test.go:19	0xc48a38		be01000000		MOVL $0x1, SI								
  conditional_kv_contract_bench_test.go:19	0xc48a3d		4989f0			MOVQ SI, R8								
  conditional_kv_contract_bench_test.go:19	0xc48a40		e8fbfe8eff		CALL testing.(*common).Fatalf(SB)					
  conditional_kv_contract_bench_test.go:21	0xc48a45		4883c448		ADDQ $0x48, SP								
  conditional_kv_contract_bench_test.go:21	0xc48a49		5d			POPQ BP									
  conditional_kv_contract_bench_test.go:21	0xc48a4a		c3			RET									
  conditional_kv_contract_bench_test.go:17	0xc48a4b		e8309c84ff		CALL runtime.morestack.abi0(SB)						
  conditional_kv_contract_bench_test.go:17	0xc48a50		eb8e			JMP github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close-fm(SB) <autogenerated>
  <autogenerated>:1	0xf47500		493b6610		CMPQ SP, 0x10(R14)							
  <autogenerated>:1	0xf47504		7617			JBE 0xf4751d								
  <autogenerated>:1	0xf47506		55			PUSHQ BP								
  <autogenerated>:1	0xf47507		4889e5			MOVQ SP, BP								
  <autogenerated>:1	0xf4750a		4883ec08		SUBQ $0x8, SP								
  <autogenerated>:1	0xf4750e		488b4208		MOVQ 0x8(DX), AX							
  <autogenerated>:1	0xf47512		e88920b8ff		CALL github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB)		
  <autogenerated>:1	0xf47517		4883c408		ADDQ $0x8, SP								
  <autogenerated>:1	0xf4751b		5d			POPQ BP									
  <autogenerated>:1	0xf4751c		c3			RET									
  <autogenerated>:1	0xf4751d		0f1f00			NOPL 0(AX)								
  <autogenerated>:1	0xf47520		e85bb154ff		CALL runtime.morestack.abi0(SB)						
  <autogenerated>:1	0xf47525		ebd9			JMP github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close-fm(SB)	
