TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:369		0x6d5f40		493b6610		CMPQ SP, 0x10(R14)						
  tree.go:369		0x6d5f44		0f86600b0000		JBE 0x6d6aaa							
  tree.go:369		0x6d5f4a		55			PUSHQ BP							
  tree.go:369		0x6d5f4b		4889e5			MOVQ SP, BP							
  tree.go:369		0x6d5f4e		4883ec18		SUBQ $0x18, SP							
  tree.go:369		0x6d5f52		48894c2438		MOVQ CX, 0x38(SP)						
  tree.go:369		0x6d5f57		48897c2440		MOVQ DI, 0x40(SP)						
  tree.go:370		0x6d5f5c		4889442428		MOVQ AX, 0x28(SP)						
  tree.go:370		0x6d5f61		4889742448		MOVQ SI, 0x48(SP)						
  tree.go:370		0x6d5f66		4885c9			TESTQ CX, CX							
  tree.go:370		0x6d5f69		0f8496000000		JE 0x6d6005							
  tree.go:374		0x6d5f6f		8400			TESTB AL, 0(AX)							
  tree.go:374		0x6d5f71		833da875850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:374		0x6d5f78		7417			JE 0x6d5f91							
  tree.go:374		0x6d5f7a		488b10			MOVQ 0(AX), DX							
  tree.go:375		0x6d5f7d		4c8b4008		MOVQ 0x8(AX), R8						
  tree.go:374		0x6d5f81		e8fae2dbff		CALL runtime.gcWriteBarrier3(SB)				
  tree.go:374		0x6d5f86		498913			MOVQ DX, 0(R11)							
  tree.go:375		0x6d5f89		49895b08		MOVQ BX, 0x8(R11)						
  tree.go:375		0x6d5f8d		4d894310		MOVQ R8, 0x10(R11)						
  tree.go:374		0x6d5f91		48c70000000000		MOVQ $0x0, 0(AX)						
  tree.go:375		0x6d5f98		48895808		MOVQ BX, 0x8(AX)						
  tree.go:376		0x6d5f9c		440f11b8d8000000	MOVUPS X15, 0xd8(AX)						
  tree.go:378		0x6d5fa4		c680e800000000		MOVB $0x0, 0xe8(AX)						
  tree.go:379		0x6d5fab		48894810		MOVQ CX, 0x10(AX)						
  tree.go:379		0x6d5faf		833d6a75850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:379		0x6d5fb6		7505			JNE 0x6d5fbd							
  tree.go:370		0x6d5fb8		4885c9			TESTQ CX, CX							
  tree.go:379		0x6d5fbb		eb13			JMP 0x6d5fd0							
  tree.go:379		0x6d5fbd		488b5018		MOVQ 0x18(AX), DX						
  tree.go:379		0x6d5fc1		e89ae2dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:379		0x6d5fc6		49893b			MOVQ DI, 0(R11)							
  tree.go:379		0x6d5fc9		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d5fcd		4885c9			TESTQ CX, CX							
  tree.go:370		0x6d5fd0		48897c2440		MOVQ DI, 0x40(SP)						
  tree.go:370		0x6d5fd5		48894c2438		MOVQ CX, 0x38(SP)						
  tree.go:379		0x6d5fda		48897818		MOVQ DI, 0x18(AX)						
  tree.go:380		0x6d5fde		6690			NOPW								
  tree.go:380		0x6d5fe0		7417			JE 0x6d5ff9							
  tree.go:380		0x6d5fe2		488b5908		MOVQ 0x8(CX), BX						
  tree.go:380		0x6d5fe6		488b15530c7402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.15(SB), DX	
  tree.go:380		0x6d5fed		4c8b02			MOVQ 0(DX), R8							
  tree.go:380		0x6d5ff0		448b4910		MOVL 0x10(CX), R9						
  tree.go:380		0x6d5ff4		e95c0a0000		JMP 0x6d6a55							
  tree.go:370		0x6d5ff9		4889ca			MOVQ CX, DX							
  tree.go:370		0x6d5ffc		0f1f4000		NOPL 0(AX)							
  tree.go:380		0x6d6000		e980000000		JMP 0x6d6085							
  tree.go:371		0x6d6005		8400			TESTB AL, 0(AX)							
  tree.go:371		0x6d6007		833d1275850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:371		0x6d600e		7433			JE 0x6d6043							
  tree.go:370		0x6d6010		48895c2430		MOVQ BX, 0x30(SP)						
  tree.go:371		0x6d6015		488b4808		MOVQ 0x8(AX), CX						
  tree.go:371		0x6d6019		e842e2dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:371		0x6d601e		49891b			MOVQ BX, 0(R11)							
  tree.go:371		0x6d6021		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:371		0x6d6025		4889c3			MOVQ AX, BX							
  tree.go:371		0x6d6028		488d05f1736301		LEAQ 0x16373f1(IP), AX						
  tree.go:371		0x6d602f		e82cf2d4ff		CALL runtime.wbZero(SB)						
  tree.go:371		0x6d6034		488b442428		MOVQ 0x28(SP), AX						
  tree.go:371		0x6d6039		488b5c2430		MOVQ 0x30(SP), BX						
  tree.go:371		0x6d603e		488b742448		MOVQ 0x48(SP), SI						
  tree.go:371		0x6d6043		4889c1			MOVQ AX, CX							
  tree.go:371		0x6d6046		ba03000000		MOVL $0x3, DX							
  tree.go:371		0x6d604b		440f1138		MOVUPS X15, 0(AX)						
  tree.go:371		0x6d604f		440f117810		MOVUPS X15, 0x10(AX)						
  tree.go:371		0x6d6054		440f117820		MOVUPS X15, 0x20(AX)						
  tree.go:371		0x6d6059		440f117830		MOVUPS X15, 0x30(AX)						
  tree.go:371		0x6d605e		4883c040		ADDQ $0x40, AX							
  tree.go:371		0x6d6062		ffca			DECL DX								
  tree.go:371		0x6d6064		75e5			JNE 0x6d604b							
  tree.go:371		0x6d6066		440f1138		MOVUPS X15, 0(AX)						
  tree.go:371		0x6d606a		440f117810		MOVUPS X15, 0x10(AX)						
  tree.go:371		0x6d606f		440f117820		MOVUPS X15, 0x20(AX)						
  tree.go:371		0x6d6074		48895908		MOVQ BX, 0x8(CX)						
  tree.go:371		0x6d6078		4889b1d0000000		MOVQ SI, 0xd0(CX)						
  tree.go:372		0x6d607f		4883c418		ADDQ $0x18, SP							
  tree.go:372		0x6d6083		5d			POPQ BP								
  tree.go:372		0x6d6084		c3			RET								
  tree.go:380		0x6d6085		4885c9			TESTQ CX, CX							
  tree.go:380		0x6d6088		742b			JE 0x6d60b5							
  tree.go:381		0x6d608a		48894820		MOVQ CX, 0x20(AX)						
  tree.go:381		0x6d608e		833d8b74850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:381		0x6d6095		7505			JNE 0x6d609c							
  tree.go:370		0x6d6097		4885d2			TESTQ DX, DX							
  tree.go:381		0x6d609a		eb13			JMP 0x6d60af							
  tree.go:381		0x6d609c		488b4828		MOVQ 0x28(AX), CX						
  tree.go:381		0x6d60a0		e8bbe1dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:381		0x6d60a5		49893b			MOVQ DI, 0(R11)							
  tree.go:381		0x6d60a8		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:370		0x6d60ac		4885d2			TESTQ DX, DX							
  tree.go:381		0x6d60af		48897828		MOVQ DI, 0x28(AX)						
  tree.go:381		0x6d60b3		eb2d			JMP 0x6d60e2							
  tree.go:383		0x6d60b5		48c7402000000000	MOVQ $0x0, 0x20(AX)						
  tree.go:383		0x6d60bd		833d5c74850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:383		0x6d60c4		7505			JNE 0x6d60cb							
  tree.go:370		0x6d60c6		4885d2			TESTQ DX, DX							
  tree.go:383		0x6d60c9		eb0f			JMP 0x6d60da							
  tree.go:383		0x6d60cb		488b4828		MOVQ 0x28(AX), CX						
  tree.go:383		0x6d60cf		e86ce1dbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:383		0x6d60d4		49890b			MOVQ CX, 0(R11)							
  tree.go:370		0x6d60d7		4885d2			TESTQ DX, DX							
  tree.go:383		0x6d60da		48c7402800000000	MOVQ $0x0, 0x28(AX)						
  tree.go:385		0x6d60e2		7417			JE 0x6d60fb							
  tree.go:385		0x6d60e4		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:385		0x6d60e8		488b0d710b7402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.16(SB), CX	
  tree.go:385		0x6d60ef		4c8b01			MOVQ 0(CX), R8							
  tree.go:385		0x6d60f2		448b4a10		MOVL 0x10(DX), R9						
  tree.go:385		0x6d60f6		e904090000		JMP 0x6d69ff							
  tree.go:370		0x6d60fb		4889d1			MOVQ DX, CX							
  tree.go:370		0x6d60fe		6690			NOPW								
  tree.go:385		0x6d6100		4885d2			TESTQ DX, DX							
  tree.go:385		0x6d6103		7430			JE 0x6d6135							
  tree.go:386		0x6d6105		48895030		MOVQ DX, 0x30(AX)						
  tree.go:386		0x6d6109		833d1074850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:386		0x6d6110		7505			JNE 0x6d6117							
  tree.go:370		0x6d6112		4885c9			TESTQ CX, CX							
  tree.go:386		0x6d6115		eb18			JMP 0x6d612f							
  tree.go:386		0x6d6117		488b5038		MOVQ 0x38(AX), DX						
  tree.go:386		0x6d611b		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:386		0x6d6120		e83be1dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:386		0x6d6125		49893b			MOVQ DI, 0(R11)							
  tree.go:386		0x6d6128		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d612c		4885c9			TESTQ CX, CX							
  tree.go:386		0x6d612f		48897838		MOVQ DI, 0x38(AX)						
  tree.go:386		0x6d6133		eb2d			JMP 0x6d6162							
  tree.go:388		0x6d6135		48c7403000000000	MOVQ $0x0, 0x30(AX)						
  tree.go:388		0x6d613d		833ddc73850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:388		0x6d6144		7505			JNE 0x6d614b							
  tree.go:370		0x6d6146		4885c9			TESTQ CX, CX							
  tree.go:388		0x6d6149		eb0f			JMP 0x6d615a							
  tree.go:388		0x6d614b		488b5038		MOVQ 0x38(AX), DX						
  tree.go:388		0x6d614f		e8ece0dbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:388		0x6d6154		498913			MOVQ DX, 0(R11)							
  tree.go:370		0x6d6157		4885c9			TESTQ CX, CX							
  tree.go:388		0x6d615a		48c7403800000000	MOVQ $0x0, 0x38(AX)						
  tree.go:390		0x6d6162		7417			JE 0x6d617b							
  tree.go:390		0x6d6164		488b5908		MOVQ 0x8(CX), BX						
  tree.go:390		0x6d6168		488b15110b7402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.17(SB), DX	
  tree.go:390		0x6d616f		4c8b02			MOVQ 0(DX), R8							
  tree.go:390		0x6d6172		448b4910		MOVL 0x10(CX), R9						
  tree.go:390		0x6d6176		e92f080000		JMP 0x6d69aa							
  tree.go:370		0x6d617b		4889ca			MOVQ CX, DX							
  tree.go:370		0x6d617e		6690			NOPW								
  tree.go:390		0x6d6180		4885c9			TESTQ CX, CX							
  tree.go:390		0x6d6183		7430			JE 0x6d61b5							
  tree.go:391		0x6d6185		48894840		MOVQ CX, 0x40(AX)						
  tree.go:391		0x6d6189		833d9073850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:391		0x6d6190		7505			JNE 0x6d6197							
  tree.go:370		0x6d6192		4885d2			TESTQ DX, DX							
  tree.go:391		0x6d6195		eb18			JMP 0x6d61af							
  tree.go:391		0x6d6197		488b4848		MOVQ 0x48(AX), CX						
  tree.go:391		0x6d619b		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:391		0x6d61a0		e8bbe0dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:391		0x6d61a5		49893b			MOVQ DI, 0(R11)							
  tree.go:391		0x6d61a8		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:370		0x6d61ac		4885d2			TESTQ DX, DX							
  tree.go:391		0x6d61af		48897848		MOVQ DI, 0x48(AX)						
  tree.go:391		0x6d61b3		eb2d			JMP 0x6d61e2							
  tree.go:393		0x6d61b5		48c7404000000000	MOVQ $0x0, 0x40(AX)						
  tree.go:393		0x6d61bd		833d5c73850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:393		0x6d61c4		7505			JNE 0x6d61cb							
  tree.go:370		0x6d61c6		4885d2			TESTQ DX, DX							
  tree.go:393		0x6d61c9		eb0f			JMP 0x6d61da							
  tree.go:393		0x6d61cb		488b4848		MOVQ 0x48(AX), CX						
  tree.go:393		0x6d61cf		e86ce0dbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:393		0x6d61d4		49890b			MOVQ CX, 0(R11)							
  tree.go:370		0x6d61d7		4885d2			TESTQ DX, DX							
  tree.go:393		0x6d61da		48c7404800000000	MOVQ $0x0, 0x48(AX)						
  tree.go:395		0x6d61e2		7417			JE 0x6d61fb							
  tree.go:395		0x6d61e4		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:395		0x6d61e8		488b0db10a7402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.18(SB), CX	
  tree.go:395		0x6d61ef		4c8b01			MOVQ 0(CX), R8							
  tree.go:395		0x6d61f2		448b4a10		MOVL 0x10(DX), R9						
  tree.go:395		0x6d61f6		e95a070000		JMP 0x6d6955							
  tree.go:370		0x6d61fb		4889d1			MOVQ DX, CX							
  tree.go:370		0x6d61fe		6690			NOPW								
  tree.go:395		0x6d6200		4885d2			TESTQ DX, DX							
  tree.go:395		0x6d6203		7434			JE 0x6d6239							
  tree.go:396		0x6d6205		48899080000000		MOVQ DX, 0x80(AX)						
  tree.go:396		0x6d620c		833d0d73850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:396		0x6d6213		7505			JNE 0x6d621a							
  tree.go:370		0x6d6215		4885c9			TESTQ CX, CX							
  tree.go:396		0x6d6218		eb16			JMP 0x6d6230							
  tree.go:396		0x6d621a		488b9088000000		MOVQ 0x88(AX), DX						
  tree.go:396		0x6d6221		e83ae0dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:396		0x6d6226		49893b			MOVQ DI, 0(R11)							
  tree.go:396		0x6d6229		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d622d		4885c9			TESTQ CX, CX							
  tree.go:396		0x6d6230		4889b888000000		MOVQ DI, 0x88(AX)						
  tree.go:396		0x6d6237		eb36			JMP 0x6d626f							
  tree.go:398		0x6d6239		48c7808000000000000000	MOVQ $0x0, 0x80(AX)						
  tree.go:398		0x6d6244		833dd572850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:398		0x6d624b		7505			JNE 0x6d6252							
  tree.go:370		0x6d624d		4885c9			TESTQ CX, CX							
  tree.go:398		0x6d6250		eb12			JMP 0x6d6264							
  tree.go:398		0x6d6252		488b9088000000		MOVQ 0x88(AX), DX						
  tree.go:398		0x6d6259		e8e2dfdbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:398		0x6d625e		498913			MOVQ DX, 0(R11)							
  tree.go:370		0x6d6261		4885c9			TESTQ CX, CX							
  tree.go:398		0x6d6264		48c7808800000000000000	MOVQ $0x0, 0x88(AX)						
  tree.go:400		0x6d626f		7417			JE 0x6d6288							
  tree.go:400		0x6d6271		488b5908		MOVQ 0x8(CX), BX						
  tree.go:400		0x6d6275		488b15440a7402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.19(SB), DX	
  tree.go:400		0x6d627c		4c8b02			MOVQ 0(DX), R8							
  tree.go:400		0x6d627f		448b4910		MOVL 0x10(CX), R9						
  tree.go:400		0x6d6283		e977060000		JMP 0x6d68ff							
  tree.go:370		0x6d6288		4889ca			MOVQ CX, DX							
  tree.go:400		0x6d628b		4885c9			TESTQ CX, CX							
  tree.go:400		0x6d628e		7436			JE 0x6d62c6							
  tree.go:401		0x6d6290		48898890000000		MOVQ CX, 0x90(AX)						
  tree.go:401		0x6d6297		833d8272850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:401		0x6d629e		6690			NOPW								
  tree.go:401		0x6d62a0		7505			JNE 0x6d62a7							
  tree.go:370		0x6d62a2		4885d2			TESTQ DX, DX							
  tree.go:401		0x6d62a5		eb16			JMP 0x6d62bd							
  tree.go:401		0x6d62a7		488b8898000000		MOVQ 0x98(AX), CX						
  tree.go:401		0x6d62ae		e8addfdbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:401		0x6d62b3		49893b			MOVQ DI, 0(R11)							
  tree.go:401		0x6d62b6		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:370		0x6d62ba		4885d2			TESTQ DX, DX							
  tree.go:401		0x6d62bd		4889b898000000		MOVQ DI, 0x98(AX)						
  tree.go:401		0x6d62c4		eb36			JMP 0x6d62fc							
  tree.go:403		0x6d62c6		48c7809000000000000000	MOVQ $0x0, 0x90(AX)						
  tree.go:403		0x6d62d1		833d4872850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:403		0x6d62d8		7505			JNE 0x6d62df							
  tree.go:370		0x6d62da		4885d2			TESTQ DX, DX							
  tree.go:403		0x6d62dd		eb12			JMP 0x6d62f1							
  tree.go:403		0x6d62df		488b8898000000		MOVQ 0x98(AX), CX						
  tree.go:403		0x6d62e6		e855dfdbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:403		0x6d62eb		49890b			MOVQ CX, 0(R11)							
  tree.go:370		0x6d62ee		4885d2			TESTQ DX, DX							
  tree.go:403		0x6d62f1		48c7809800000000000000	MOVQ $0x0, 0x98(AX)						
  tree.go:405		0x6d62fc		7417			JE 0x6d6315							
  tree.go:405		0x6d62fe		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:405		0x6d6302		488b0dd7097402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.20(SB), CX	
  tree.go:405		0x6d6309		4c8b01			MOVQ 0(CX), R8							
  tree.go:405		0x6d630c		448b4a10		MOVL 0x10(DX), R9						
  tree.go:405		0x6d6310		e995050000		JMP 0x6d68aa							
  tree.go:370		0x6d6315		4889d1			MOVQ DX, CX							
  tree.go:405		0x6d6318		4885d2			TESTQ DX, DX							
  tree.go:405		0x6d631b		7434			JE 0x6d6351							
  tree.go:406		0x6d631d		488990a0000000		MOVQ DX, 0xa0(AX)						
  tree.go:406		0x6d6324		833df571850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:406		0x6d632b		7505			JNE 0x6d6332							
  tree.go:370		0x6d632d		4885c9			TESTQ CX, CX							
  tree.go:406		0x6d6330		eb16			JMP 0x6d6348							
  tree.go:406		0x6d6332		488b90a8000000		MOVQ 0xa8(AX), DX						
  tree.go:406		0x6d6339		e822dfdbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:406		0x6d633e		49893b			MOVQ DI, 0(R11)							
  tree.go:406		0x6d6341		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d6345		4885c9			TESTQ CX, CX							
  tree.go:406		0x6d6348		4889b8a8000000		MOVQ DI, 0xa8(AX)						
  tree.go:406		0x6d634f		eb36			JMP 0x6d6387							
  tree.go:408		0x6d6351		48c780a000000000000000	MOVQ $0x0, 0xa0(AX)						
  tree.go:408		0x6d635c		833dbd71850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:408		0x6d6363		7505			JNE 0x6d636a							
  tree.go:370		0x6d6365		4885c9			TESTQ CX, CX							
  tree.go:408		0x6d6368		eb12			JMP 0x6d637c							
  tree.go:408		0x6d636a		488b90a8000000		MOVQ 0xa8(AX), DX						
  tree.go:408		0x6d6371		e8cadedbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:408		0x6d6376		498913			MOVQ DX, 0(R11)							
  tree.go:370		0x6d6379		4885c9			TESTQ CX, CX							
  tree.go:408		0x6d637c		48c780a800000000000000	MOVQ $0x0, 0xa8(AX)						
  tree.go:410		0x6d6387		741c			JE 0x6d63a5							
  tree.go:410		0x6d6389		488b5908		MOVQ 0x8(CX), BX						
  tree.go:410		0x6d638d		488b156c097402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.21(SB), DX	
  tree.go:410		0x6d6394		4c8b02			MOVQ 0(DX), R8							
  tree.go:410		0x6d6397		448b4910		MOVL 0x10(CX), R9						
  tree.go:410		0x6d639b		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:410		0x6d63a0		e9b0040000		JMP 0x6d6855							
  tree.go:370		0x6d63a5		4889ca			MOVQ CX, DX							
  tree.go:410		0x6d63a8		4885c9			TESTQ CX, CX							
  tree.go:410		0x6d63ab		7435			JE 0x6d63e2							
  tree.go:411		0x6d63ad		488988b0000000		MOVQ CX, 0xb0(AX)						
  tree.go:411		0x6d63b4		833d6571850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:411		0x6d63bb		7505			JNE 0x6d63c2							
  tree.go:370		0x6d63bd		4885d2			TESTQ DX, DX							
  tree.go:411		0x6d63c0		eb16			JMP 0x6d63d8							
  tree.go:411		0x6d63c2		488b88b8000000		MOVQ 0xb8(AX), CX						
  tree.go:411		0x6d63c9		e892dedbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:411		0x6d63ce		49893b			MOVQ DI, 0(R11)							
  tree.go:411		0x6d63d1		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:370		0x6d63d5		4885d2			TESTQ DX, DX							
  tree.go:411		0x6d63d8		4889b8b8000000		MOVQ DI, 0xb8(AX)						
  tree.go:411		0x6d63df		90			NOPL								
  tree.go:411		0x6d63e0		eb36			JMP 0x6d6418							
  tree.go:413		0x6d63e2		48c780b000000000000000	MOVQ $0x0, 0xb0(AX)						
  tree.go:413		0x6d63ed		833d2c71850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:413		0x6d63f4		7505			JNE 0x6d63fb							
  tree.go:370		0x6d63f6		4885d2			TESTQ DX, DX							
  tree.go:413		0x6d63f9		eb12			JMP 0x6d640d							
  tree.go:413		0x6d63fb		488b88b8000000		MOVQ 0xb8(AX), CX						
  tree.go:413		0x6d6402		e839dedbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:413		0x6d6407		49890b			MOVQ CX, 0(R11)							
  tree.go:370		0x6d640a		4885d2			TESTQ DX, DX							
  tree.go:413		0x6d640d		48c780b800000000000000	MOVQ $0x0, 0xb8(AX)						
  tree.go:415		0x6d6418		7417			JE 0x6d6431							
  tree.go:415		0x6d641a		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:415		0x6d641e		488b0dfb087402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.22(SB), CX	
  tree.go:415		0x6d6425		4c8b01			MOVQ 0(CX), R8							
  tree.go:415		0x6d6428		448b4a10		MOVL 0x10(DX), R9						
  tree.go:415		0x6d642c		e9ce030000		JMP 0x6d67ff							
  tree.go:370		0x6d6431		4889d1			MOVQ DX, CX							
  tree.go:415		0x6d6434		4885d2			TESTQ DX, DX							
  tree.go:415		0x6d6437		7434			JE 0x6d646d							
  tree.go:416		0x6d6439		488990c0000000		MOVQ DX, 0xc0(AX)						
  tree.go:416		0x6d6440		833dd970850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:416		0x6d6447		7505			JNE 0x6d644e							
  tree.go:370		0x6d6449		4885c9			TESTQ CX, CX							
  tree.go:416		0x6d644c		eb16			JMP 0x6d6464							
  tree.go:416		0x6d644e		488b90c8000000		MOVQ 0xc8(AX), DX						
  tree.go:416		0x6d6455		e806dedbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:416		0x6d645a		49893b			MOVQ DI, 0(R11)							
  tree.go:416		0x6d645d		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d6461		4885c9			TESTQ CX, CX							
  tree.go:416		0x6d6464		4889b8c8000000		MOVQ DI, 0xc8(AX)						
  tree.go:416		0x6d646b		eb37			JMP 0x6d64a4							
  tree.go:418		0x6d646d		48c780c000000000000000	MOVQ $0x0, 0xc0(AX)						
  tree.go:418		0x6d6478		833da170850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:418		0x6d647f		90			NOPL								
  tree.go:418		0x6d6480		7505			JNE 0x6d6487							
  tree.go:370		0x6d6482		4885c9			TESTQ CX, CX							
  tree.go:418		0x6d6485		eb12			JMP 0x6d6499							
  tree.go:418		0x6d6487		488b90c8000000		MOVQ 0xc8(AX), DX						
  tree.go:418		0x6d648e		e8addddbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:418		0x6d6493		498913			MOVQ DX, 0(R11)							
  tree.go:370		0x6d6496		4885c9			TESTQ CX, CX							
  tree.go:418		0x6d6499		48c780c800000000000000	MOVQ $0x0, 0xc8(AX)						
  tree.go:264		0x6d64a4		7417			JE 0x6d64bd							
  tree.go:264		0x6d64a6		488b5908		MOVQ 0x8(CX), BX						
  tree.go:264		0x6d64aa		488b158f087402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.23(SB), DX	
  tree.go:264		0x6d64b1		4c8b02			MOVQ 0(DX), R8							
  tree.go:264		0x6d64b4		448b4910		MOVL 0x10(CX), R9						
  tree.go:264		0x6d64b8		e9ed020000		JMP 0x6d67aa							
  tree.go:370		0x6d64bd		4889ca			MOVQ CX, DX							
  tree.go:264		0x6d64c0		4885c9			TESTQ CX, CX							
  tree.go:264		0x6d64c3		7507			JNE 0x6d64cc							
  tree.go:264		0x6d64c5		b901000000		MOVL $0x1, CX							
  tree.go:420		0x6d64ca		eb1f			JMP 0x6d64eb							
  tree.go:265		0x6d64cc		488b4918		MOVQ 0x18(CX), CX						
  tree.go:265		0x6d64d0		4889f8			MOVQ DI, AX							
  tree.go:265		0x6d64d3		ffd1			CALL CX								
  tree.go:370		0x6d64d5		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d64da		488b742448		MOVQ 0x48(SP), SI						
  tree.go:422		0x6d64df		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:420		0x6d64e4		89c1			MOVL AX, CX							
  tree.go:437		0x6d64e6		488b442428		MOVQ 0x28(SP), AX						
  tree.go:420		0x6d64eb		84c9			TESTL CL, CL							
  tree.go:420		0x6d64ed		7421			JE 0x6d6510							
  tree.go:370		0x6d64ef		4885d2			TESTQ DX, DX							
  tree.go:421		0x6d64f2		7417			JE 0x6d650b							
  tree.go:421		0x6d64f4		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:421		0x6d64f8		488b0d61087402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.24(SB), CX	
  tree.go:421		0x6d64ff		4c8b01			MOVQ 0(CX), R8							
  tree.go:421		0x6d6502		448b4a10		MOVL 0x10(DX), R9						
  tree.go:421		0x6d6506		e94a020000		JMP 0x6d6755							
  tree.go:370		0x6d650b		4889d1			MOVQ DX, CX							
  tree.go:421		0x6d650e		eb50			JMP 0x6d6560							
  tree.go:437		0x6d6510		48c7405000000000	MOVQ $0x0, 0x50(AX)						
  tree.go:437		0x6d6518		833d0170850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:437		0x6d651f		90			NOPL								
  tree.go:437		0x6d6520		741c			JE 0x6d653e							
  tree.go:437		0x6d6522		488b4858		MOVQ 0x58(AX), CX						
  tree.go:438		0x6d6526		488b5068		MOVQ 0x68(AX), DX						
  tree.go:439		0x6d652a		488b5878		MOVQ 0x78(AX), BX						
  tree.go:437		0x6d652e		e84ddddbff		CALL runtime.gcWriteBarrier3(SB)				
  tree.go:437		0x6d6533		49890b			MOVQ CX, 0(R11)							
  tree.go:438		0x6d6536		49895308		MOVQ DX, 0x8(R11)						
  tree.go:439		0x6d653a		49895b10		MOVQ BX, 0x10(R11)						
  tree.go:437		0x6d653e		440f117858		MOVUPS X15, 0x58(AX)						
  tree.go:438		0x6d6543		440f117868		MOVUPS X15, 0x68(AX)						
  tree.go:439		0x6d6548		48c7407800000000	MOVQ $0x0, 0x78(AX)						
  tree.go:441		0x6d6550		4889b0d0000000		MOVQ SI, 0xd0(AX)						
  tree.go:442		0x6d6557		4883c418		ADDQ $0x18, SP							
  tree.go:442		0x6d655b		5d			POPQ BP								
  tree.go:442		0x6d655c		c3			RET								
  tree.go:442		0x6d655d		0f1f00			NOPL 0(AX)							
  tree.go:421		0x6d6560		4885d2			TESTQ DX, DX							
  tree.go:421		0x6d6563		7430			JE 0x6d6595							
  tree.go:422		0x6d6565		48895050		MOVQ DX, 0x50(AX)						
  tree.go:422		0x6d6569		833db06f850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:422		0x6d6570		7505			JNE 0x6d6577							
  tree.go:370		0x6d6572		4885c9			TESTQ CX, CX							
  tree.go:422		0x6d6575		eb18			JMP 0x6d658f							
  tree.go:422		0x6d6577		488b5058		MOVQ 0x58(AX), DX						
  tree.go:422		0x6d657b		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:422		0x6d6580		e8dbdcdbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:422		0x6d6585		49893b			MOVQ DI, 0(R11)							
  tree.go:422		0x6d6588		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d658c		4885c9			TESTQ CX, CX							
  tree.go:422		0x6d658f		48897858		MOVQ DI, 0x58(AX)						
  tree.go:422		0x6d6593		eb2d			JMP 0x6d65c2							
  tree.go:424		0x6d6595		48c7405000000000	MOVQ $0x0, 0x50(AX)						
  tree.go:424		0x6d659d		833d7c6f850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:424		0x6d65a4		7505			JNE 0x6d65ab							
  tree.go:370		0x6d65a6		4885c9			TESTQ CX, CX							
  tree.go:424		0x6d65a9		eb0f			JMP 0x6d65ba							
  tree.go:424		0x6d65ab		488b5058		MOVQ 0x58(AX), DX						
  tree.go:424		0x6d65af		e88cdcdbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:424		0x6d65b4		498913			MOVQ DX, 0(R11)							
  tree.go:370		0x6d65b7		4885c9			TESTQ CX, CX							
  tree.go:424		0x6d65ba		48c7405800000000	MOVQ $0x0, 0x58(AX)						
  tree.go:426		0x6d65c2		7417			JE 0x6d65db							
  tree.go:426		0x6d65c4		488b5908		MOVQ 0x8(CX), BX						
  tree.go:426		0x6d65c8		488b15b1077402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.25(SB), DX	
  tree.go:426		0x6d65cf		4c8b02			MOVQ 0(DX), R8							
  tree.go:426		0x6d65d2		448b4910		MOVL 0x10(CX), R9						
  tree.go:426		0x6d65d6		e920010000		JMP 0x6d66fb							
  tree.go:370		0x6d65db		4889ca			MOVQ CX, DX							
  tree.go:370		0x6d65de		6690			NOPW								
  tree.go:426		0x6d65e0		4885c9			TESTQ CX, CX							
  tree.go:426		0x6d65e3		7430			JE 0x6d6615							
  tree.go:427		0x6d65e5		48894860		MOVQ CX, 0x60(AX)						
  tree.go:427		0x6d65e9		833d306f850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:427		0x6d65f0		7505			JNE 0x6d65f7							
  tree.go:370		0x6d65f2		4885d2			TESTQ DX, DX							
  tree.go:427		0x6d65f5		eb18			JMP 0x6d660f							
  tree.go:427		0x6d65f7		488b4868		MOVQ 0x68(AX), CX						
  tree.go:427		0x6d65fb		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:427		0x6d6600		e85bdcdbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:427		0x6d6605		49893b			MOVQ DI, 0(R11)							
  tree.go:427		0x6d6608		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:370		0x6d660c		4885d2			TESTQ DX, DX							
  tree.go:427		0x6d660f		48897868		MOVQ DI, 0x68(AX)						
  tree.go:427		0x6d6613		eb2d			JMP 0x6d6642							
  tree.go:429		0x6d6615		48c7406000000000	MOVQ $0x0, 0x60(AX)						
  tree.go:429		0x6d661d		833dfc6e850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:429		0x6d6624		7505			JNE 0x6d662b							
  tree.go:370		0x6d6626		4885d2			TESTQ DX, DX							
  tree.go:429		0x6d6629		eb0f			JMP 0x6d663a							
  tree.go:429		0x6d662b		488b4868		MOVQ 0x68(AX), CX						
  tree.go:429		0x6d662f		e80cdcdbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:429		0x6d6634		49890b			MOVQ CX, 0(R11)							
  tree.go:370		0x6d6637		4885d2			TESTQ DX, DX							
  tree.go:429		0x6d663a		48c7406800000000	MOVQ $0x0, 0x68(AX)						
  tree.go:431		0x6d6642		7413			JE 0x6d6657							
  tree.go:431		0x6d6644		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:431		0x6d6648		488b0d51077402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.26(SB), CX	
  tree.go:431		0x6d664f		4c8b01			MOVQ 0(CX), R8							
  tree.go:431		0x6d6652		8b5210			MOVL 0x10(DX), DX						
  tree.go:431		0x6d6655		eb58			JMP 0x6d66af							
  tree.go:431		0x6d6657		4885d2			TESTQ DX, DX							
  tree.go:431		0x6d665a		7429			JE 0x6d6685							
  tree.go:432		0x6d665c		48895070		MOVQ DX, 0x70(AX)						
  tree.go:432		0x6d6660		833db96e850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:432		0x6d6667		7410			JE 0x6d6679							
  tree.go:432		0x6d6669		488b4878		MOVQ 0x78(AX), CX						
  tree.go:432		0x6d666d		e8eedbdbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:432		0x6d6672		49893b			MOVQ DI, 0(R11)							
  tree.go:432		0x6d6675		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:432		0x6d6679		48897878		MOVQ DI, 0x78(AX)						
  tree.go:432		0x6d667d		0f1f00			NOPL 0(AX)							
  tree.go:432		0x6d6680		e9cbfeffff		JMP 0x6d6550							
  tree.go:434		0x6d6685		48c7407000000000	MOVQ $0x0, 0x70(AX)						
  tree.go:434		0x6d668d		833d8c6e850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:434		0x6d6694		740c			JE 0x6d66a2							
  tree.go:434		0x6d6696		488b4878		MOVQ 0x78(AX), CX						
  tree.go:434		0x6d669a		e8a1dbdbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:434		0x6d669f		49890b			MOVQ CX, 0(R11)							
  tree.go:434		0x6d66a2		48c7407800000000	MOVQ $0x0, 0x78(AX)						
  tree.go:434		0x6d66aa		e9a1feffff		JMP 0x6d6550							
  tree.go:431		0x6d66af		4989d1			MOVQ DX, R9							
  tree.go:431		0x6d66b2		4c21c2			ANDQ R8, DX							
  tree.go:431		0x6d66b5		48c1e204		SHLQ $0x4, DX							
  tree.go:431		0x6d66b9		4c8b541108		MOVQ 0x8(CX)(DX*1), R10						
  tree.go:431		0x6d66be		6690			NOPW								
  tree.go:431		0x6d66c0		4939da			CMPQ R10, BX							
  tree.go:431		0x6d66c3		742c			JE 0x6d66f1							
  tree.go:431		0x6d66c5		498d5101		LEAQ 0x1(R9), DX						
  tree.go:431		0x6d66c9		4d85d2			TESTQ R10, R10							
  tree.go:431		0x6d66cc		75e1			JNE 0x6d66af							
  tree.go:431		0x6d66ce		488d05cb067402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.26(SB), AX	
  tree.go:431		0x6d66d5		e8e6a7d4ff		CALL runtime.typeAssert(SB)					
  tree.go:441		0x6d66da		488b742448		MOVQ 0x48(SP), SI						
  tree.go:432		0x6d66df		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:431		0x6d66e4		4889c2			MOVQ AX, DX							
  tree.go:432		0x6d66e7		488b442428		MOVQ 0x28(SP), AX						
  tree.go:431		0x6d66ec		e966ffffff		JMP 0x6d6657							
  tree.go:431		0x6d66f1		488b541110		MOVQ 0x10(CX)(DX*1), DX						
  tree.go:431		0x6d66f6		e95cffffff		JMP 0x6d6657							
  tree.go:426		0x6d66fb		4d89ca			MOVQ R9, R10							
  tree.go:426		0x6d66fe		4d21c1			ANDQ R8, R9							
  tree.go:426		0x6d6701		49c1e104		SHLQ $0x4, R9							
  tree.go:426		0x6d6705		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:426		0x6d670a		4939db			CMPQ R11, BX							
  tree.go:426		0x6d670d		7436			JE 0x6d6745							
  tree.go:426		0x6d670f		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:426		0x6d6713		4d85db			TESTQ R11, R11							
  tree.go:426		0x6d6716		75e3			JNE 0x6d66fb							
  tree.go:426		0x6d6718		488d0561067402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.25(SB), AX	
  tree.go:426		0x6d671f		90			NOPL								
  tree.go:426		0x6d6720		e89ba7d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d6725		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d672a		488b742448		MOVQ 0x48(SP), SI						
  tree.go:427		0x6d672f		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:426		0x6d6734		4889c1			MOVQ AX, CX							
  tree.go:427		0x6d6737		488b442428		MOVQ 0x28(SP), AX						
  tree.go:427		0x6d673c		0f1f4000		NOPL 0(AX)							
  tree.go:426		0x6d6740		e99bfeffff		JMP 0x6d65e0							
  tree.go:426		0x6d6745		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d674a		4889ca			MOVQ CX, DX							
  tree.go:426		0x6d674d		4c89c1			MOVQ R8, CX							
  tree.go:426		0x6d6750		e98bfeffff		JMP 0x6d65e0							
  tree.go:421		0x6d6755		4d89ca			MOVQ R9, R10							
  tree.go:421		0x6d6758		4d21c1			ANDQ R8, R9							
  tree.go:421		0x6d675b		49c1e104		SHLQ $0x4, R9							
  tree.go:421		0x6d675f		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:421		0x6d6764		4939db			CMPQ R11, BX							
  tree.go:421		0x6d6767		7431			JE 0x6d679a							
  tree.go:421		0x6d6769		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:421		0x6d676d		4d85db			TESTQ R11, R11							
  tree.go:421		0x6d6770		75e3			JNE 0x6d6755							
  tree.go:421		0x6d6772		488d05e7057402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.24(SB), AX	
  tree.go:421		0x6d6779		e842a7d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d677e		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:441		0x6d6783		488b742448		MOVQ 0x48(SP), SI						
  tree.go:422		0x6d6788		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:421		0x6d678d		4889c2			MOVQ AX, DX							
  tree.go:422		0x6d6790		488b442428		MOVQ 0x28(SP), AX						
  tree.go:421		0x6d6795		e9c6fdffff		JMP 0x6d6560							
  tree.go:421		0x6d679a		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:370		0x6d679f		4889d1			MOVQ DX, CX							
  tree.go:421		0x6d67a2		4c89c2			MOVQ R8, DX							
  tree.go:421		0x6d67a5		e9b6fdffff		JMP 0x6d6560							
  tree.go:264		0x6d67aa		4d89ca			MOVQ R9, R10							
  tree.go:264		0x6d67ad		4d21c1			ANDQ R8, R9							
  tree.go:264		0x6d67b0		49c1e104		SHLQ $0x4, R9							
  tree.go:264		0x6d67b4		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:264		0x6d67b9		4939db			CMPQ R11, BX							
  tree.go:264		0x6d67bc		7431			JE 0x6d67ef							
  tree.go:264		0x6d67be		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:264		0x6d67c2		4d85db			TESTQ R11, R11							
  tree.go:264		0x6d67c5		75e3			JNE 0x6d67aa							
  tree.go:264		0x6d67c7		488d0572057402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.23(SB), AX	
  tree.go:264		0x6d67ce		e8eda6d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d67d3		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d67d8		488b742448		MOVQ 0x48(SP), SI						
  tree.go:265		0x6d67dd		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:264		0x6d67e2		4889c1			MOVQ AX, CX							
  tree.go:437		0x6d67e5		488b442428		MOVQ 0x28(SP), AX						
  tree.go:264		0x6d67ea		e9d1fcffff		JMP 0x6d64c0							
  tree.go:264		0x6d67ef		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d67f4		4889ca			MOVQ CX, DX							
  tree.go:264		0x6d67f7		4c89c1			MOVQ R8, CX							
  tree.go:264		0x6d67fa		e9c1fcffff		JMP 0x6d64c0							
  tree.go:415		0x6d67ff		4d89ca			MOVQ R9, R10							
  tree.go:415		0x6d6802		4d21c1			ANDQ R8, R9							
  tree.go:415		0x6d6805		49c1e104		SHLQ $0x4, R9							
  tree.go:415		0x6d6809		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:415		0x6d680e		4939db			CMPQ R11, BX							
  tree.go:415		0x6d6811		7432			JE 0x6d6845							
  tree.go:415		0x6d6813		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:415		0x6d6817		4d85db			TESTQ R11, R11							
  tree.go:415		0x6d681a		75e3			JNE 0x6d67ff							
  tree.go:415		0x6d681c		488d05fd047402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.22(SB), AX	
  tree.go:415		0x6d6823		e898a6d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d6828		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:441		0x6d682d		488b742448		MOVQ 0x48(SP), SI						
  tree.go:416		0x6d6832		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:415		0x6d6837		4889c2			MOVQ AX, DX							
  tree.go:416		0x6d683a		488b442428		MOVQ 0x28(SP), AX						
  tree.go:416		0x6d683f		90			NOPL								
  tree.go:415		0x6d6840		e9effbffff		JMP 0x6d6434							
  tree.go:415		0x6d6845		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:370		0x6d684a		4889d1			MOVQ DX, CX							
  tree.go:415		0x6d684d		4c89c2			MOVQ R8, DX							
  tree.go:415		0x6d6850		e9dffbffff		JMP 0x6d6434							
  tree.go:410		0x6d6855		4d89ca			MOVQ R9, R10							
  tree.go:410		0x6d6858		4d21c1			ANDQ R8, R9							
  tree.go:410		0x6d685b		49c1e104		SHLQ $0x4, R9							
  tree.go:410		0x6d685f		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:410		0x6d6864		4939db			CMPQ R11, BX							
  tree.go:410		0x6d6867		7431			JE 0x6d689a							
  tree.go:410		0x6d6869		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:410		0x6d686d		4d85db			TESTQ R11, R11							
  tree.go:410		0x6d6870		75e3			JNE 0x6d6855							
  tree.go:410		0x6d6872		488d0587047402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.21(SB), AX	
  tree.go:410		0x6d6879		e842a6d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d687e		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d6883		488b742448		MOVQ 0x48(SP), SI						
  tree.go:411		0x6d6888		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:410		0x6d688d		4889c1			MOVQ AX, CX							
  tree.go:411		0x6d6890		488b442428		MOVQ 0x28(SP), AX						
  tree.go:410		0x6d6895		e90efbffff		JMP 0x6d63a8							
  tree.go:410		0x6d689a		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d689f		4889ca			MOVQ CX, DX							
  tree.go:410		0x6d68a2		4c89c1			MOVQ R8, CX							
  tree.go:410		0x6d68a5		e9fefaffff		JMP 0x6d63a8							
  tree.go:405		0x6d68aa		4d89ca			MOVQ R9, R10							
  tree.go:405		0x6d68ad		4d21c1			ANDQ R8, R9							
  tree.go:405		0x6d68b0		49c1e104		SHLQ $0x4, R9							
  tree.go:405		0x6d68b4		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:405		0x6d68b9		4939db			CMPQ R11, BX							
  tree.go:405		0x6d68bc		7431			JE 0x6d68ef							
  tree.go:405		0x6d68be		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:405		0x6d68c2		4d85db			TESTQ R11, R11							
  tree.go:405		0x6d68c5		75e3			JNE 0x6d68aa							
  tree.go:405		0x6d68c7		488d0512047402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.20(SB), AX	
  tree.go:405		0x6d68ce		e8eda5d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d68d3		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:441		0x6d68d8		488b742448		MOVQ 0x48(SP), SI						
  tree.go:406		0x6d68dd		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:405		0x6d68e2		4889c2			MOVQ AX, DX							
  tree.go:406		0x6d68e5		488b442428		MOVQ 0x28(SP), AX						
  tree.go:405		0x6d68ea		e929faffff		JMP 0x6d6318							
  tree.go:405		0x6d68ef		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:370		0x6d68f4		4889d1			MOVQ DX, CX							
  tree.go:405		0x6d68f7		4c89c2			MOVQ R8, DX							
  tree.go:405		0x6d68fa		e919faffff		JMP 0x6d6318							
  tree.go:400		0x6d68ff		4d89ca			MOVQ R9, R10							
  tree.go:400		0x6d6902		4d21c1			ANDQ R8, R9							
  tree.go:400		0x6d6905		49c1e104		SHLQ $0x4, R9							
  tree.go:400		0x6d6909		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:400		0x6d690e		4939db			CMPQ R11, BX							
  tree.go:400		0x6d6911		7432			JE 0x6d6945							
  tree.go:400		0x6d6913		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:400		0x6d6917		4d85db			TESTQ R11, R11							
  tree.go:400		0x6d691a		75e3			JNE 0x6d68ff							
  tree.go:400		0x6d691c		488d059d037402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.19(SB), AX	
  tree.go:400		0x6d6923		e898a5d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d6928		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d692d		488b742448		MOVQ 0x48(SP), SI						
  tree.go:401		0x6d6932		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:400		0x6d6937		4889c1			MOVQ AX, CX							
  tree.go:401		0x6d693a		488b442428		MOVQ 0x28(SP), AX						
  tree.go:401		0x6d693f		90			NOPL								
  tree.go:400		0x6d6940		e946f9ffff		JMP 0x6d628b							
  tree.go:400		0x6d6945		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d694a		4889ca			MOVQ CX, DX							
  tree.go:400		0x6d694d		4c89c1			MOVQ R8, CX							
  tree.go:400		0x6d6950		e936f9ffff		JMP 0x6d628b							
  tree.go:395		0x6d6955		4d89ca			MOVQ R9, R10							
  tree.go:395		0x6d6958		4d21c1			ANDQ R8, R9							
  tree.go:395		0x6d695b		49c1e104		SHLQ $0x4, R9							
  tree.go:395		0x6d695f		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:395		0x6d6964		4939db			CMPQ R11, BX							
  tree.go:395		0x6d6967		7431			JE 0x6d699a							
  tree.go:395		0x6d6969		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:395		0x6d696d		4d85db			TESTQ R11, R11							
  tree.go:395		0x6d6970		75e3			JNE 0x6d6955							
  tree.go:395		0x6d6972		488d0527037402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.18(SB), AX	
  tree.go:395		0x6d6979		e842a5d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d697e		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:441		0x6d6983		488b742448		MOVQ 0x48(SP), SI						
  tree.go:396		0x6d6988		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:395		0x6d698d		4889c2			MOVQ AX, DX							
  tree.go:396		0x6d6990		488b442428		MOVQ 0x28(SP), AX						
  tree.go:395		0x6d6995		e966f8ffff		JMP 0x6d6200							
  tree.go:395		0x6d699a		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:370		0x6d699f		4889d1			MOVQ DX, CX							
  tree.go:395		0x6d69a2		4c89c2			MOVQ R8, DX							
  tree.go:395		0x6d69a5		e956f8ffff		JMP 0x6d6200							
  tree.go:390		0x6d69aa		4d89ca			MOVQ R9, R10							
  tree.go:390		0x6d69ad		4d21c1			ANDQ R8, R9							
  tree.go:390		0x6d69b0		49c1e104		SHLQ $0x4, R9							
  tree.go:390		0x6d69b4		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:390		0x6d69b9		4939db			CMPQ R11, BX							
  tree.go:390		0x6d69bc		7431			JE 0x6d69ef							
  tree.go:390		0x6d69be		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:390		0x6d69c2		4d85db			TESTQ R11, R11							
  tree.go:390		0x6d69c5		75e3			JNE 0x6d69aa							
  tree.go:390		0x6d69c7		488d05b2027402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.17(SB), AX	
  tree.go:390		0x6d69ce		e8eda4d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d69d3		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d69d8		488b742448		MOVQ 0x48(SP), SI						
  tree.go:391		0x6d69dd		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:390		0x6d69e2		4889c1			MOVQ AX, CX							
  tree.go:391		0x6d69e5		488b442428		MOVQ 0x28(SP), AX						
  tree.go:390		0x6d69ea		e991f7ffff		JMP 0x6d6180							
  tree.go:390		0x6d69ef		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d69f4		4889ca			MOVQ CX, DX							
  tree.go:390		0x6d69f7		4c89c1			MOVQ R8, CX							
  tree.go:390		0x6d69fa		e981f7ffff		JMP 0x6d6180							
  tree.go:385		0x6d69ff		4d89ca			MOVQ R9, R10							
  tree.go:385		0x6d6a02		4d21c1			ANDQ R8, R9							
  tree.go:385		0x6d6a05		49c1e104		SHLQ $0x4, R9							
  tree.go:385		0x6d6a09		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:385		0x6d6a0e		4939db			CMPQ R11, BX							
  tree.go:385		0x6d6a11		7432			JE 0x6d6a45							
  tree.go:385		0x6d6a13		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:385		0x6d6a17		4d85db			TESTQ R11, R11							
  tree.go:385		0x6d6a1a		75e3			JNE 0x6d69ff							
  tree.go:385		0x6d6a1c		488d053d027402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.16(SB), AX	
  tree.go:385		0x6d6a23		e898a4d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d6a28		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:441		0x6d6a2d		488b742448		MOVQ 0x48(SP), SI						
  tree.go:386		0x6d6a32		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:385		0x6d6a37		4889c2			MOVQ AX, DX							
  tree.go:386		0x6d6a3a		488b442428		MOVQ 0x28(SP), AX						
  tree.go:386		0x6d6a3f		90			NOPL								
  tree.go:385		0x6d6a40		e9bbf6ffff		JMP 0x6d6100							
  tree.go:385		0x6d6a45		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:370		0x6d6a4a		4889d1			MOVQ DX, CX							
  tree.go:385		0x6d6a4d		4c89c2			MOVQ R8, DX							
  tree.go:385		0x6d6a50		e9abf6ffff		JMP 0x6d6100							
  tree.go:380		0x6d6a55		4d89ca			MOVQ R9, R10							
  tree.go:380		0x6d6a58		4d21c1			ANDQ R8, R9							
  tree.go:380		0x6d6a5b		49c1e104		SHLQ $0x4, R9							
  tree.go:380		0x6d6a5f		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:380		0x6d6a64		4939db			CMPQ R11, BX							
  tree.go:380		0x6d6a67		7431			JE 0x6d6a9a							
  tree.go:380		0x6d6a69		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:380		0x6d6a6d		4d85db			TESTQ R11, R11							
  tree.go:380		0x6d6a70		75e3			JNE 0x6d6a55							
  tree.go:380		0x6d6a72		488d05c7017402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.15(SB), AX	
  tree.go:380		0x6d6a79		e842a4d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d6a7e		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d6a83		488b742448		MOVQ 0x48(SP), SI						
  tree.go:381		0x6d6a88		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:380		0x6d6a8d		4889c1			MOVQ AX, CX							
  tree.go:381		0x6d6a90		488b442428		MOVQ 0x28(SP), AX						
  tree.go:380		0x6d6a95		e9ebf5ffff		JMP 0x6d6085							
  tree.go:380		0x6d6a9a		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d6a9f		4889ca			MOVQ CX, DX							
  tree.go:380		0x6d6aa2		4c89c1			MOVQ R8, CX							
  tree.go:380		0x6d6aa5		e9dbf5ffff		JMP 0x6d6085							
  tree.go:369		0x6d6aaa		4889442408		MOVQ AX, 0x8(SP)						
  tree.go:369		0x6d6aaf		48895c2410		MOVQ BX, 0x10(SP)						
  tree.go:369		0x6d6ab4		48894c2418		MOVQ CX, 0x18(SP)						
  tree.go:369		0x6d6ab9		48897c2420		MOVQ DI, 0x20(SP)						
  tree.go:369		0x6d6abe		4889742428		MOVQ SI, 0x28(SP)						
  tree.go:369		0x6d6ac3		e898bcdbff		CALL runtime.morestack_noctxt.abi0(SB)				
  tree.go:369		0x6d6ac8		488b442408		MOVQ 0x8(SP), AX						
  tree.go:369		0x6d6acd		488b5c2410		MOVQ 0x10(SP), BX						
  tree.go:369		0x6d6ad2		488b4c2418		MOVQ 0x18(SP), CX						
  tree.go:369		0x6d6ad7		488b7c2420		MOVQ 0x20(SP), DI						
  tree.go:369		0x6d6adc		488b742428		MOVQ 0x28(SP), SI						
  tree.go:369		0x6d6ae1		e95af4ffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB)	

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).getEntry(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:620			0x6d7fc0		4c8da42450fcffff		LEAQ 0xfffffc50(SP), R12								
  tree.go:620			0x6d7fc8		4d3b6610			CMPQ R12, 0x10(R14)									
  tree.go:620			0x6d7fcc		0f867d0c0000			JBE 0x6d8c4f										
  tree.go:620			0x6d7fd2		55				PUSHQ BP										
  tree.go:620			0x6d7fd3		4889e5				MOVQ SP, BP										
  tree.go:620			0x6d7fd6		4881ec28040000			SUBQ $0x428, SP										
  tree.go:621			0x6d7fdd		48898424a0040000		MOVQ AX, 0x4a0(SP)									
  tree.go:621			0x6d7fe5		4c899424d8040000		MOVQ R10, 0x4d8(SP)									
  tree.go:621			0x6d7fed		44889c24e0040000		MOVB R11, 0x4e0(SP)									
  tree.go:621			0x6d7ff5		48898c24b0040000		MOVQ CX, 0x4b0(SP)									
  tree.go:621			0x6d7ffd		48899c24a8040000		MOVQ BX, 0x4a8(SP)									
  tree.go:621			0x6d8005		4889b424c0040000		MOVQ SI, 0x4c0(SP)									
  tree.go:621			0x6d800d		4c898c24d0040000		MOVQ R9, 0x4d0(SP)									
  tree.go:621			0x6d8015		4c898424c8040000		MOVQ R8, 0x4c8(SP)									
  tree.go:621			0x6d801d		4889bc24b8040000		MOVQ DI, 0x4b8(SP)									
  tree.go:620			0x6d8025		488d942450040000		LEAQ 0x450(SP), DX									
  tree.go:620			0x6d802d		440f113a			MOVUPS X15, 0(DX)									
  tree.go:620			0x6d8031		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:620			0x6d8036		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:620			0x6d803b		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:620			0x6d8040		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:621			0x6d8045		e89687ffff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).pointDefinitelyAbsent(SB)		
  tree.go:621			0x6d804a		84c0				TESTL AL, AL										
  tree.go:621			0x6d804c		7554				JNE 0x6d80a2										
  tree.go:624			0x6d804e		488b8424a0040000		MOVQ 0x4a0(SP), AX									
  tree.go:624			0x6d8056		488b90d0000000			MOVQ 0xd0(AX), DX									
  tree.go:624			0x6d805d		4c8da424f8000000		LEAQ 0xf8(SP), R12									
  tree.go:624			0x6d8065		450f113c24			MOVUPS X15, 0(R12)									
  tree.go:624			0x6d806a		450f117c2410			MOVUPS X15, 0x10(R12)									
  tree.go:624			0x6d8070		450f117c2418			MOVUPS X15, 0x18(R12)									
  tree.go:624			0x6d8076		4889942400010000		MOVQ DX, 0x100(SP)									
  tree.go:626			0x6d807e		488b5008			MOVQ 0x8(AX), DX									
  tree.go:626			0x6d8082		4885d2				TESTQ DX, DX										
  tree.go:626			0x6d8085		740e				JE 0x6d8095										
  pager.go:565			0x6d8087		90				NOPL											
  type.go:19			0x6d8088		8b92d0010000			MOVL 0x1d0(DX), DX									
  type.go:19			0x6d808e		85d2				TESTL DX, DX										
  type.go:19			0x6d8090		0f95c2				SETNE DL										
  tree.go:627			0x6d8093		eb02				JMP 0x6d8097										
  tree.go:627			0x6d8095		31d2				XORL DX, DX										
  tree.go:630			0x6d8097		889424d7000000			MOVB DL, 0xd7(SP)									
  tree.go:630			0x6d809e		31c9				XORL CX, CX										
  tree.go:630			0x6d80a0		eb52				JMP 0x6d80f4										
  tree.go:622			0x6d80a2		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:622			0x6d80aa		440f1139			MOVUPS X15, 0(CX)									
  tree.go:622			0x6d80ae		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:622			0x6d80b3		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:622			0x6d80b8		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:622			0x6d80bd		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:622			0x6d80c2		488b05278d7302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:622			0x6d80c9		488b1d288d7302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:622			0x6d80d0		4881c428040000			ADDQ $0x428, SP										
  tree.go:622			0x6d80d7		5d				POPQ BP											
  tree.go:622			0x6d80d8		c3				RET											
  tree.go:630			0x6d80d9		488b8c24f0000000		MOVQ 0xf0(SP), CX									
  tree.go:630			0x6d80e1		48ffc1				INCQ CX											
  tree.go:632			0x6d80e4		488b8424a0040000		MOVQ 0x4a0(SP), AX									
  tree.go:632			0x6d80ec		0fb69424d7000000		MOVZX 0xd7(SP), DX									
  tree.go:630			0x6d80f4		4883f932			CMPQ CX, $0x32										
  tree.go:630			0x6d80f8		0f8df50a0000			JGE 0x6d8bf3										
  tree.go:630			0x6d80fe		48898c24f0000000		MOVQ CX, 0xf0(SP)									
  tree.go:631			0x6d8106		488d9c2470010000		LEAQ 0x170(SP), BX									
  tree.go:631			0x6d810e		41bc05000000			MOVL $0x5, R12										
  tree.go:631			0x6d8114		440f113b			MOVUPS X15, 0(BX)									
  tree.go:631			0x6d8118		440f117b10			MOVUPS X15, 0x10(BX)									
  tree.go:631			0x6d811d		440f117b20			MOVUPS X15, 0x20(BX)									
  tree.go:631			0x6d8122		440f117b30			MOVUPS X15, 0x30(BX)									
  tree.go:631			0x6d8127		4883c340			ADDQ $0x40, BX										
  tree.go:631			0x6d812b		41ffcc				DECL R12										
  tree.go:631			0x6d812e		75e4				JNE 0x6d8114										
  tree.go:631			0x6d8130		440f117bf8			MOVUPS X15, -0x8(BX)									
  tree.go:632			0x6d8135		0fb68c24f8000000		MOVZX 0xf8(SP), CX									
  tree.go:632			0x6d813d		488bbc2400010000		MOVQ 0x100(SP), DI									
  tree.go:632			0x6d8145		8bb42408010000			MOVL 0x108(SP), SI									
  tree.go:632			0x6d814c		4c8b842410010000		MOVQ 0x110(SP), R8									
  tree.go:632			0x6d8154		448b8c2418010000		MOVL 0x118(SP), R9									
  tree.go:632			0x6d815c		440fb794241c010000		MOVZX 0x11c(SP), R10									
  tree.go:632			0x6d8165		4c8ba424c0040000		MOVQ 0x4c0(SP), R12									
  tree.go:632			0x6d816d		4c892424			MOVQ R12, 0(SP)										
  tree.go:632			0x6d8171		4c8ba424c8040000		MOVQ 0x4c8(SP), R12									
  tree.go:632			0x6d8179		4c89642408			MOVQ R12, 0x8(SP)									
  tree.go:632			0x6d817e		4c8ba424d0040000		MOVQ 0x4d0(SP), R12									
  tree.go:632			0x6d8186		4c89642410			MOVQ R12, 0x10(SP)									
  tree.go:632			0x6d818b		4c8ba42438040000		MOVQ 0x438(SP), R12									
  tree.go:632			0x6d8193		4c89642418			MOVQ R12, 0x18(SP)									
  tree.go:632			0x6d8198		4c8ba42440040000		MOVQ 0x440(SP), R12									
  tree.go:632			0x6d81a0		4c89642420			MOVQ R12, 0x20(SP)									
  tree.go:632			0x6d81a5		4c8ba42448040000		MOVQ 0x448(SP), R12									
  tree.go:632			0x6d81ad		4c89642428			MOVQ R12, 0x28(SP)									
  tree.go:632			0x6d81b2		4c8ba424d8040000		MOVQ 0x4d8(SP), R12									
  tree.go:632			0x6d81ba		4c89642430			MOVQ R12, 0x30(SP)									
  tree.go:632			0x6d81bf		440fb6a424e0040000		MOVZX 0x4e0(SP), R12									
  tree.go:632			0x6d81c8		4488642438			MOVB R12, 0x38(SP)									
  tree.go:632			0x6d81cd		488d9c2470010000		LEAQ 0x170(SP), BX									
  tree.go:632			0x6d81d5		4189d3				MOVL DX, R11										
  tree.go:632			0x6d81d8		e88396ffff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).loadReadRefInto(SB)			
  tree.go:632			0x6d81dd		0f1f00				NOPL 0(AX)										
  tree.go:632			0x6d81e0		4885c0				TESTQ AX, AX										
  tree.go:632			0x6d81e3		0f85e1090000			JNE 0x6d8bca										
  tree.go:621			0x6d81e9		440fb69c24e0040000		MOVZX 0x4e0(SP), R11									
  tree.go:621			0x6d81f2		4584db				TESTL R11, R11										
  tree.go:636			0x6d81f5		745b				JE 0x6d8252										
  tree.go:637			0x6d81f7		90				NOPL											
  node.go:183			0x6d81f8		488b9424d0040000		MOVQ 0x4d0(SP), DX									
  node.go:183			0x6d8200		4885d2				TESTQ DX, DX										
  node.go:183			0x6d8203		751f				JNE 0x6d8224										
  node.go:184			0x6d8205		440f11bc2498010000		MOVUPS X15, 0x198(SP)									
  node.go:184			0x6d820e		48c784249001000000000000	MOVQ $0x0, 0x190(SP)									
  tree.go:632			0x6d821a		4c8ba424c0040000		MOVQ 0x4c0(SP), R12									
  node.go:193			0x6d8222		eb24				JMP 0x6d8248										
  node.go:187			0x6d8224		48c784249801000000000000	MOVQ $0x0, 0x198(SP)									
  node.go:187			0x6d8230		48899424a0010000		MOVQ DX, 0x1a0(SP)									
  node.go:187			0x6d8238		4c8ba424c0040000		MOVQ 0x4c0(SP), R12									
  node.go:187			0x6d8240		4c89a42490010000		MOVQ R12, 0x190(SP)									
  node.go:194			0x6d8248		c68424a801000001		MOVB $0x1, 0x1a8(SP)									
  tree.go:640			0x6d8250		eb10				JMP 0x6d8262										
  tree.go:632			0x6d8252		488b9424d0040000		MOVQ 0x4d0(SP), DX									
  tree.go:632			0x6d825a		4c8ba424c0040000		MOVQ 0x4c0(SP), R12									
  node.go:224			0x6d8262		0fb784248a010000		MOVZX 0x18a(SP), AX									
  tree.go:655			0x6d826a		6683f803			CMPW AX, $0x3										
  tree.go:655			0x6d826e		0f8531020000			JNE 0x6d84a5										
  tree.go:656			0x6d8274		488bb424f0000000		MOVQ 0xf0(SP), SI									
  tree.go:656			0x6d827c		0f1f4000			NOPL 0(AX)										
  tree.go:656			0x6d8280		4885f6				TESTQ SI, SI										
  tree.go:656			0x6d8283		0f85d0000000			JNE 0x6d8359										
  tree.go:657			0x6d8289		488d842470010000		LEAQ 0x170(SP), AX									
  tree.go:657			0x6d8291		e84a28f1ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).InternalFenceBounds(SB)		
  tree.go:657			0x6d8296		4d85d2				TESTQ R10, R10										
  tree.go:657			0x6d8299		0f8506060000			JNE 0x6d88a5										
  tree.go:657			0x6d829f		90				NOPL											
  tree.go:657			0x6d82a0		4584c9				TESTL R9, R9										
  tree.go:659			0x6d82a3		0f848f000000			JE 0x6d8338										
  tree.go:660			0x6d82a9		4885db				TESTQ BX, BX										
  tree.go:660			0x6d82ac		745f				JE 0x6d830d										
  tree.go:657			0x6d82ae		4c898424e0000000		MOVQ R8, 0xe0(SP)									
  tree.go:657			0x6d82b6		4889b424d8000000		MOVQ SI, 0xd8(SP)									
  tree.go:657			0x6d82be		4889bc24b8020000		MOVQ DI, 0x2b8(SP)									
  tree.go:660			0x6d82c6		4889c7				MOVQ AX, DI										
  tree.go:660			0x6d82c9		4889de				MOVQ BX, SI										
  tree.go:660			0x6d82cc		4989c8				MOVQ CX, R8										
  tree.go:660			0x6d82cf		488b8424a8040000		MOVQ 0x4a8(SP), AX									
  tree.go:660			0x6d82d7		488b9c24b0040000		MOVQ 0x4b0(SP), BX									
  tree.go:660			0x6d82df		488b8c24b8040000		MOVQ 0x4b8(SP), CX									
  tree.go:660			0x6d82e7		e854d2ffff			CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)				
  tree.go:660			0x6d82ec		4885c0				TESTQ AX, AX										
  tree.go:660			0x6d82ef		0f8c1b050000			JL 0x6d8810										
  tree.go:663			0x6d82f5		488bb424d8000000		MOVQ 0xd8(SP), SI									
  tree.go:663			0x6d82fd		488bbc24b8020000		MOVQ 0x2b8(SP), DI									
  tree.go:663			0x6d8305		4c8b8424e0000000		MOVQ 0xe0(SP), R8									
  tree.go:663			0x6d830d		4885f6				TESTQ SI, SI										
  tree.go:663			0x6d8310		7426				JE 0x6d8338										
  tree.go:663			0x6d8312		488b8424a8040000		MOVQ 0x4a8(SP), AX									
  tree.go:663			0x6d831a		488b9c24b0040000		MOVQ 0x4b0(SP), BX									
  tree.go:663			0x6d8322		488b8c24b8040000		MOVQ 0x4b8(SP), CX									
  tree.go:663			0x6d832a		e811d2ffff			CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)				
  tree.go:663			0x6d832f		4885c0				TESTQ AX, AX										
  tree.go:663			0x6d8332		0f8da1040000			JGE 0x6d87d9										
  tree.go:632			0x6d8338		488b9424d0040000		MOVQ 0x4d0(SP), DX									
  tree.go:630			0x6d8340		488bb424f0000000		MOVQ 0xf0(SP), SI									
  tree.go:632			0x6d8348		440fb69c24e0040000		MOVZX 0x4e0(SP), R11									
  tree.go:632			0x6d8351		4c8ba424c0040000		MOVQ 0x4c0(SP), R12									
  node.go:309			0x6d8359		90				NOPL											
  node.go:302			0x6d835a		6683bc248a01000003		CMPW 0x18a(SP), $0x3									
  node.go:302			0x6d8363		753a				JNE 0x6d839f										
  node.go:236			0x6d8365		4c8b842478010000		MOVQ 0x178(SP), R8									
  node.go:56			0x6d836d		4983f80c			CMPQ R8, $0xc										
  node.go:56			0x6d8371		0f86d2080000			JBE 0x6d8c49										
  node.go:56			0x6d8377		660f1f840000000000		NOPW 0(AX)(AX*1)									
  node.go:56			0x6d8380		4983f80d			CMPQ R8, $0xd										
  node.go:56			0x6d8384		0f86ba080000			JBE 0x6d8c44										
  node.go:236			0x6d838a		4c8b842470010000		MOVQ 0x170(SP), R8									
  node.go:56			0x6d8392		450fb7400c			MOVZX 0xc(R8), R8									
  node.go:305			0x6d8397		6641f7c08000			TESTW $0x80, R8										
  tree.go:668			0x6d839d		7552				JNE 0x6d83f1										
  tree.go:675			0x6d839f		488d842470010000		LEAQ 0x170(SP), AX									
  tree.go:675			0x6d83a7		488b9c24a8040000		MOVQ 0x4a8(SP), BX									
  tree.go:675			0x6d83af		488b8c24b0040000		MOVQ 0x4b0(SP), CX									
  tree.go:675			0x6d83b7		488bbc24b8040000		MOVQ 0x4b8(SP), DI									
  tree.go:675			0x6d83bf		90				NOPL											
  tree.go:675			0x6d83c0		e81b33f1ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID(SB)		
  tree.go:676			0x6d83c5		4885c9				TESTQ CX, CX										
  tree.go:676			0x6d83c8		0f8579040000			JNE 0x6d8847										
  tree.go:679			0x6d83ce		488d9424f8000000		LEAQ 0xf8(SP), DX									
  tree.go:679			0x6d83d6		440f113a			MOVUPS X15, 0(DX)									
  tree.go:679			0x6d83da		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:679			0x6d83df		440f117a18			MOVUPS X15, 0x18(DX)									
  tree.go:679			0x6d83e4		4889842400010000		MOVQ AX, 0x100(SP)									
  tree.go:679			0x6d83ec		e9e8fcffff			JMP 0x6d80d9										
  tree.go:669			0x6d83f1		488d842470010000		LEAQ 0x170(SP), AX									
  tree.go:669			0x6d83f9		488b9c24a8040000		MOVQ 0x4a8(SP), BX									
  tree.go:669			0x6d8401		488b8c24b0040000		MOVQ 0x4b0(SP), CX									
  tree.go:669			0x6d8409		488bbc24b8040000		MOVQ 0x4b8(SP), DI									
  tree.go:669			0x6d8411		e8ea60f1ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildRef(SB)		
  tree.go:669			0x6d8416		88842448010000			MOVB AL, 0x148(SP)									
  tree.go:669			0x6d841d		48899c2450010000		MOVQ BX, 0x150(SP)									
  tree.go:669			0x6d8425		898c2458010000			MOVL CX, 0x158(SP)									
  tree.go:669			0x6d842c		4889bc2460010000		MOVQ DI, 0x160(SP)									
  tree.go:669			0x6d8434		89b42468010000			MOVL SI, 0x168(SP)									
  tree.go:669			0x6d843b		66448984246c010000		MOVW R8, 0x16c(SP)									
  tree.go:669			0x6d8444		488d9424f8000000		LEAQ 0xf8(SP), DX									
  tree.go:669			0x6d844c		488db42448010000		LEAQ 0x148(SP), SI									
  tree.go:669			0x6d8454		440f1036			MOVUPS 0(SI), X14									
  tree.go:669			0x6d8458		440f1132			MOVUPS X14, 0(DX)									
  tree.go:669			0x6d845c		440f107610			MOVUPS 0x10(SI), X14									
  tree.go:669			0x6d8461		440f117210			MOVUPS X14, 0x10(DX)									
  tree.go:669			0x6d8466		440f107618			MOVUPS 0x18(SI), X14									
  tree.go:669			0x6d846b		440f117218			MOVUPS X14, 0x18(DX)									
  tree.go:670			0x6d8470		4d85d2				TESTQ R10, R10										
  tree.go:670			0x6d8473		0f85fd030000			JNE 0x6d8876										
  tree.go:673			0x6d8479		488d9424f8000000		LEAQ 0xf8(SP), DX									
  tree.go:673			0x6d8481		440f1036			MOVUPS 0(SI), X14									
  tree.go:673			0x6d8485		440f1132			MOVUPS X14, 0(DX)									
  tree.go:673			0x6d8489		440f107610			MOVUPS 0x10(SI), X14									
  tree.go:673			0x6d848e		440f117210			MOVUPS X14, 0x10(DX)									
  tree.go:673			0x6d8493		440f107618			MOVUPS 0x18(SI), X14									
  tree.go:673			0x6d8498		440f117218			MOVUPS X14, 0x18(DX)									
  tree.go:673			0x6d849d		0f1f00				NOPL 0(AX)										
  tree.go:673			0x6d84a0		e934fcffff			JMP 0x6d80d9										
  tree.go:682			0x6d84a5		6683f804			CMPW AX, $0x4										
  tree.go:682			0x6d84a9		0f849d050000			JE 0x6d8a4c										
  tree.go:641			0x6d84af		6683f80b			CMPW AX, $0xb										
  tree.go:641			0x6d84b3		0f85f6040000			JNE 0x6d89af										
  tree.go:642			0x6d84b9		4c8bac24f0000000		MOVQ 0xf0(SP), R13									
  tree.go:642			0x6d84c1		4d85ed				TESTQ R13, R13										
  tree.go:642			0x6d84c4		0f85ae040000			JNE 0x6d8978										
  tree.go:646			0x6d84ca		488d942438030000		LEAQ 0x338(SP), DX									
  tree.go:646			0x6d84d2		440f113a			MOVUPS X15, 0(DX)									
  tree.go:646			0x6d84d6		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:646			0x6d84db		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:646			0x6d84e0		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:646			0x6d84e5		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:646			0x6d84ea		440f117a50			MOVUPS X15, 0x50(DX)									
  tree.go:646			0x6d84ef		440f117a60			MOVUPS X15, 0x60(DX)									
  node.go:209			0x6d84f4		488b8c2478010000		MOVQ 0x178(SP), CX									
  node.go:209			0x6d84fc		488bbc2480010000		MOVQ 0x180(SP), DI									
  node.go:209			0x6d8504		488b9c2470010000		MOVQ 0x170(SP), BX									
  tree.go:647			0x6d850c		488d942438030000		LEAQ 0x338(SP), DX									
  tree.go:647			0x6d8514		440f113a			MOVUPS X15, 0(DX)									
  tree.go:647			0x6d8518		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:647			0x6d851d		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:647			0x6d8522		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:647			0x6d8527		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:647			0x6d852c		440f117a50			MOVUPS X15, 0x50(DX)									
  tree.go:647			0x6d8531		440f117a60			MOVUPS X15, 0x60(DX)									
  tree.go:647			0x6d8536		488b942438040000		MOVQ 0x438(SP), DX									
  tree.go:647			0x6d853e		48891424			MOVQ DX, 0(SP)										
  tree.go:647			0x6d8542		488b942440040000		MOVQ 0x440(SP), DX									
  tree.go:647			0x6d854a		4889542408			MOVQ DX, 0x8(SP)									
  tree.go:647			0x6d854f		488b942448040000		MOVQ 0x448(SP), DX									
  tree.go:647			0x6d8557		4889542410			MOVQ DX, 0x10(SP)									
  tree.go:647			0x6d855c		488b8424a0040000		MOVQ 0x4a0(SP), AX									
  tree.go:647			0x6d8564		488bb424a8040000		MOVQ 0x4a8(SP), SI									
  tree.go:647			0x6d856c		4c8b8424b0040000		MOVQ 0x4b0(SP), R8									
  tree.go:647			0x6d8574		4c8b8c24b8040000		MOVQ 0x4b8(SP), R9									
  tree.go:647			0x6d857c		4c8b9424d8040000		MOVQ 0x4d8(SP), R10									
  tree.go:647			0x6d8584		e8b7a0ffff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).selectPrimaryOperand(SB)		
  tree.go:647			0x6d8589		888424a8030000			MOVB AL, 0x3a8(SP)									
  tree.go:647			0x6d8590		48899c24b0030000		MOVQ BX, 0x3b0(SP)									
  tree.go:647			0x6d8598		898c24b8030000			MOVL CX, 0x3b8(SP)									
  tree.go:647			0x6d859f		4889bc24c0030000		MOVQ DI, 0x3c0(SP)									
  tree.go:647			0x6d85a7		89b424c8030000			MOVL SI, 0x3c8(SP)									
  tree.go:647			0x6d85ae		6644898424cc030000		MOVW R8, 0x3cc(SP)									
  tree.go:647			0x6d85b7		488d9424f8000000		LEAQ 0xf8(SP), DX									
  tree.go:647			0x6d85bf		4c8da424a8030000		LEAQ 0x3a8(SP), R12									
  tree.go:647			0x6d85c7		450f103424			MOVUPS 0(R12), X14									
  tree.go:647			0x6d85cc		440f1132			MOVUPS X14, 0(DX)									
  tree.go:647			0x6d85d0		450f10742410			MOVUPS 0x10(R12), X14									
  tree.go:647			0x6d85d6		440f117210			MOVUPS X14, 0x10(DX)									
  tree.go:647			0x6d85db		450f10742418			MOVUPS 0x18(R12), X14									
  tree.go:647			0x6d85e1		440f117218			MOVUPS X14, 0x18(DX)									
  tree.go:647			0x6d85e6		4c8da42438030000		LEAQ 0x338(SP), R12									
  tree.go:647			0x6d85ee		4c8d6c2418			LEAQ 0x18(SP), R13									
  tree.go:647			0x6d85f3		450f107500			MOVUPS 0(R13), X14									
  tree.go:647			0x6d85f8		450f113424			MOVUPS X14, 0(R12)									
  tree.go:647			0x6d85fd		450f107510			MOVUPS 0x10(R13), X14									
  tree.go:647			0x6d8602		450f11742410			MOVUPS X14, 0x10(R12)									
  tree.go:647			0x6d8608		450f107520			MOVUPS 0x20(R13), X14									
  tree.go:647			0x6d860d		450f11742420			MOVUPS X14, 0x20(R12)									
  tree.go:647			0x6d8613		450f107530			MOVUPS 0x30(R13), X14									
  tree.go:647			0x6d8618		450f11742430			MOVUPS X14, 0x30(R12)									
  tree.go:647			0x6d861e		450f107540			MOVUPS 0x40(R13), X14									
  tree.go:647			0x6d8623		450f11742440			MOVUPS X14, 0x40(R12)									
  tree.go:647			0x6d8629		450f107550			MOVUPS 0x50(R13), X14									
  tree.go:647			0x6d862e		450f11742450			MOVUPS X14, 0x50(R12)									
  tree.go:647			0x6d8634		450f107560			MOVUPS 0x60(R13), X14									
  tree.go:647			0x6d8639		450f11742460			MOVUPS X14, 0x60(R12)									
  tree.go:647			0x6d863f		4c8dac2420010000		LEAQ 0x120(SP), R13									
  tree.go:647			0x6d8647		440f1032			MOVUPS 0(DX), X14									
  tree.go:647			0x6d864b		450f117500			MOVUPS X14, 0(R13)									
  tree.go:647			0x6d8650		440f107210			MOVUPS 0x10(DX), X14									
  tree.go:647			0x6d8655		450f117510			MOVUPS X14, 0x10(R13)									
  tree.go:647			0x6d865a		440f107218			MOVUPS 0x18(DX), X14									
  tree.go:647			0x6d865f		450f117518			MOVUPS X14, 0x18(R13)									
  tree.go:647			0x6d8664		488d9424a8030000		LEAQ 0x3a8(SP), DX									
  tree.go:647			0x6d866c		450f103424			MOVUPS 0(R12), X14									
  tree.go:647			0x6d8671		440f1132			MOVUPS X14, 0(DX)									
  tree.go:647			0x6d8675		450f10742410			MOVUPS 0x10(R12), X14									
  tree.go:647			0x6d867b		440f117210			MOVUPS X14, 0x10(DX)									
  tree.go:647			0x6d8680		450f10742420			MOVUPS 0x20(R12), X14									
  tree.go:647			0x6d8686		440f117220			MOVUPS X14, 0x20(DX)									
  tree.go:647			0x6d868b		450f10742430			MOVUPS 0x30(R12), X14									
  tree.go:647			0x6d8691		440f117230			MOVUPS X14, 0x30(DX)									
  tree.go:647			0x6d8696		450f10742440			MOVUPS 0x40(R12), X14									
  tree.go:647			0x6d869c		440f117240			MOVUPS X14, 0x40(DX)									
  tree.go:647			0x6d86a1		450f10742450			MOVUPS 0x50(R12), X14									
  tree.go:647			0x6d86a7		440f117250			MOVUPS X14, 0x50(DX)									
  tree.go:647			0x6d86ac		450f10742460			MOVUPS 0x60(R12), X14									
  tree.go:647			0x6d86b2		440f117260			MOVUPS X14, 0x60(DX)									
  tree.go:647			0x6d86b7		4c8da424f8000000		LEAQ 0xf8(SP), R12									
  tree.go:647			0x6d86bf		450f107500			MOVUPS 0(R13), X14									
  tree.go:647			0x6d86c4		450f113424			MOVUPS X14, 0(R12)									
  tree.go:647			0x6d86c9		450f107510			MOVUPS 0x10(R13), X14									
  tree.go:647			0x6d86ce		450f11742410			MOVUPS X14, 0x10(R12)									
  tree.go:647			0x6d86d4		450f107518			MOVUPS 0x18(R13), X14									
  tree.go:647			0x6d86d9		450f11742418			MOVUPS X14, 0x18(R12)									
  tree.go:647			0x6d86df		4c8da42438030000		LEAQ 0x338(SP), R12									
  tree.go:647			0x6d86e7		440f1032			MOVUPS 0(DX), X14									
  tree.go:647			0x6d86eb		450f113424			MOVUPS X14, 0(R12)									
  tree.go:647			0x6d86f0		440f107210			MOVUPS 0x10(DX), X14									
  tree.go:647			0x6d86f5		450f11742410			MOVUPS X14, 0x10(R12)									
  tree.go:647			0x6d86fb		440f107220			MOVUPS 0x20(DX), X14									
  tree.go:647			0x6d8700		450f11742420			MOVUPS X14, 0x20(R12)									
  tree.go:647			0x6d8706		440f107230			MOVUPS 0x30(DX), X14									
  tree.go:647			0x6d870b		450f11742430			MOVUPS X14, 0x30(R12)									
  tree.go:647			0x6d8711		440f107240			MOVUPS 0x40(DX), X14									
  tree.go:647			0x6d8716		450f11742440			MOVUPS X14, 0x40(R12)									
  tree.go:647			0x6d871c		440f107250			MOVUPS 0x50(DX), X14									
  tree.go:647			0x6d8721		450f11742450			MOVUPS X14, 0x50(R12)									
  tree.go:647			0x6d8727		440f107260			MOVUPS 0x60(DX), X14									
  tree.go:647			0x6d872c		450f11742460			MOVUPS X14, 0x60(R12)									
  tree.go:648			0x6d8732		4c8da424c8020000		LEAQ 0x2c8(SP), R12									
  tree.go:648			0x6d873a		440f1032			MOVUPS 0(DX), X14									
  tree.go:648			0x6d873e		450f113424			MOVUPS X14, 0(R12)									
  tree.go:648			0x6d8743		440f107210			MOVUPS 0x10(DX), X14									
  tree.go:648			0x6d8748		450f11742410			MOVUPS X14, 0x10(R12)									
  tree.go:648			0x6d874e		440f107220			MOVUPS 0x20(DX), X14									
  tree.go:648			0x6d8753		450f11742420			MOVUPS X14, 0x20(R12)									
  tree.go:648			0x6d8759		440f107230			MOVUPS 0x30(DX), X14									
  tree.go:648			0x6d875e		450f11742430			MOVUPS X14, 0x30(R12)									
  tree.go:648			0x6d8764		440f107240			MOVUPS 0x40(DX), X14									
  tree.go:648			0x6d8769		450f11742440			MOVUPS X14, 0x40(R12)									
  tree.go:648			0x6d876f		440f107250			MOVUPS 0x50(DX), X14									
  tree.go:648			0x6d8774		450f11742450			MOVUPS X14, 0x50(R12)									
  tree.go:648			0x6d877a		440f107260			MOVUPS 0x60(DX), X14									
  tree.go:648			0x6d877f		450f11742460			MOVUPS X14, 0x60(R12)									
  primary_directory_v1.go:43	0x6d8785		80bc243003000002		CMPB 0x330(SP), $0x2									
  primary_directory_v1.go:43	0x6d878d		753c				JNE 0x6d87cb										
  tree.go:647			0x6d878f		4c898c24e8000000		MOVQ R9, 0xe8(SP)									
  tree.go:647			0x6d8797		4c899424c0020000		MOVQ R10, 0x2c0(SP)									
  primary_directory_v1.go:43	0x6d879f		488d8424e0020000		LEAQ 0x2e0(SP), AX									
  primary_directory_v1.go:43	0x6d87a7		488d1d72798502			LEAQ runtime.zeroVal(SB), BX								
  primary_directory_v1.go:43	0x6d87ae		e86d25f2ff			CALL type:.eq.github.com/snissn/gomap/TreeDB/node.PrimaryOperand(SB)			
  primary_directory_v1.go:43	0x6d87b3		84c0				TESTL AL, AL										
  tree.go:648			0x6d87b5		0f8548010000			JNE 0x6d8903										
  tree.go:651			0x6d87bb		4c8b8c24e8000000		MOVQ 0xe8(SP), R9									
  tree.go:652			0x6d87c3		4c8b9424c0020000		MOVQ 0x2c0(SP), R10									
  tree.go:651			0x6d87cb		4d85c9				TESTQ R9, R9										
  tree.go:651			0x6d87ce		0f8405f9ffff			JE 0x6d80d9										
  tree.go:651			0x6d87d4		e9fb000000			JMP 0x6d88d4										
  tree.go:664			0x6d87d9		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:664			0x6d87e1		440f1139			MOVUPS X15, 0(CX)									
  tree.go:664			0x6d87e5		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:664			0x6d87ea		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:664			0x6d87ef		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:664			0x6d87f4		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:664			0x6d87f9		488b05f0857302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:664			0x6d8800		488b1df1857302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:664			0x6d8807		4881c428040000			ADDQ $0x428, SP										
  tree.go:664			0x6d880e		5d				POPQ BP											
  tree.go:664			0x6d880f		c3				RET											
  tree.go:661			0x6d8810		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:661			0x6d8818		440f1139			MOVUPS X15, 0(CX)									
  tree.go:661			0x6d881c		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:661			0x6d8821		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:661			0x6d8826		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:661			0x6d882b		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:661			0x6d8830		488b05b9857302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:661			0x6d8837		488b1dba857302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:661			0x6d883e		4881c428040000			ADDQ $0x428, SP										
  tree.go:661			0x6d8845		5d				POPQ BP											
  tree.go:661			0x6d8846		c3				RET											
  tree.go:677			0x6d8847		488d942450040000		LEAQ 0x450(SP), DX									
  tree.go:677			0x6d884f		440f113a			MOVUPS X15, 0(DX)									
  tree.go:677			0x6d8853		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:677			0x6d8858		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:677			0x6d885d		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:677			0x6d8862		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:677			0x6d8867		4889c8				MOVQ CX, AX										
  tree.go:677			0x6d886a		4889fb				MOVQ DI, BX										
  tree.go:677			0x6d886d		4881c428040000			ADDQ $0x428, SP										
  tree.go:677			0x6d8874		5d				POPQ BP											
  tree.go:677			0x6d8875		c3				RET											
  tree.go:671			0x6d8876		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:671			0x6d887e		440f1139			MOVUPS X15, 0(CX)									
  tree.go:671			0x6d8882		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:671			0x6d8887		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:671			0x6d888c		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:671			0x6d8891		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:671			0x6d8896		4c89d0				MOVQ R10, AX										
  tree.go:671			0x6d8899		4c89db				MOVQ R11, BX										
  tree.go:671			0x6d889c		4881c428040000			ADDQ $0x428, SP										
  tree.go:671			0x6d88a3		5d				POPQ BP											
  tree.go:671			0x6d88a4		c3				RET											
  tree.go:658			0x6d88a5		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:658			0x6d88ad		440f1139			MOVUPS X15, 0(CX)									
  tree.go:658			0x6d88b1		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:658			0x6d88b6		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:658			0x6d88bb		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:658			0x6d88c0		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:658			0x6d88c5		4c89d0				MOVQ R10, AX										
  tree.go:658			0x6d88c8		4c89db				MOVQ R11, BX										
  tree.go:658			0x6d88cb		4881c428040000			ADDQ $0x428, SP										
  tree.go:658			0x6d88d2		5d				POPQ BP											
  tree.go:658			0x6d88d3		c3				RET											
  tree.go:652			0x6d88d4		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:652			0x6d88dc		440f1139			MOVUPS X15, 0(CX)									
  tree.go:652			0x6d88e0		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:652			0x6d88e5		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:652			0x6d88ea		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:652			0x6d88ef		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:652			0x6d88f4		4c89c8				MOVQ R9, AX										
  tree.go:652			0x6d88f7		4c89d3				MOVQ R10, BX										
  tree.go:652			0x6d88fa		4881c428040000			ADDQ $0x428, SP										
  tree.go:652			0x6d8901		5d				POPQ BP											
  tree.go:652			0x6d8902		c3				RET											
  tree.go:649			0x6d8903		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:649			0x6d890b		440f1139			MOVUPS X15, 0(CX)									
  tree.go:649			0x6d890f		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:649			0x6d8914		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:649			0x6d8919		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:649			0x6d891e		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:649			0x6d8923		488b8c2438030000		MOVQ 0x338(SP), CX									
  tree.go:649			0x6d892b		488b942440030000		MOVQ 0x340(SP), DX									
  tree.go:649			0x6d8933		488bb42448030000		MOVQ 0x348(SP), SI									
  tree.go:649			0x6d893b		48898c2450040000		MOVQ CX, 0x450(SP)									
  tree.go:649			0x6d8943		4889942458040000		MOVQ DX, 0x458(SP)									
  tree.go:649			0x6d894b		4889b42460040000		MOVQ SI, 0x460(SP)									
  tree.go:649			0x6d8953		c684249004000002		MOVB $0x2, 0x490(SP)									
  tree.go:649			0x6d895b		488b8c2498030000		MOVQ 0x398(SP), CX									
  tree.go:649			0x6d8963		48898c2498040000		MOVQ CX, 0x498(SP)									
  tree.go:649			0x6d896b		31c0				XORL AX, AX										
  tree.go:649			0x6d896d		31db				XORL BX, BX										
  tree.go:649			0x6d896f		4881c428040000			ADDQ $0x428, SP										
  tree.go:649			0x6d8976		5d				POPQ BP											
  tree.go:649			0x6d8977		c3				RET											
  tree.go:643			0x6d8978		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:643			0x6d8980		440f1139			MOVUPS X15, 0(CX)									
  tree.go:643			0x6d8984		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:643			0x6d8989		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:643			0x6d898e		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:643			0x6d8993		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:643			0x6d8998		488b0531897302			MOVQ github.com/snissn/gomap/TreeDB/node.ErrPrimaryDirectory(SB), AX			
  tree.go:643			0x6d899f		488b1d32897302			MOVQ github.com/snissn/gomap/TreeDB/node.ErrPrimaryDirectory+8(SB), BX			
  tree.go:643			0x6d89a6		4881c428040000			ADDQ $0x428, SP										
  tree.go:643			0x6d89ad		5d				POPQ BP											
  tree.go:643			0x6d89ae		c3				RET											
  tree.go:706			0x6d89af		440f11bc2418040000		MOVUPS X15, 0x418(SP)									
  tree.go:706			0x6d89b8		e84383d4ff			CALL runtime.convT16(SB)								
  tree.go:706			0x6d89bd		488d0ddc644801			LEAQ 0x14864dc(IP), CX									
  tree.go:706			0x6d89c4		48898c2418040000		MOVQ CX, 0x418(SP)									
  tree.go:706			0x6d89cc		4889842420040000		MOVQ AX, 0x420(SP)									
  errors.go:26			0x6d89d4		488d0548286a01			LEAQ 0x16a2848(IP), AX									
  errors.go:26			0x6d89db		bb14000000			MOVL $0x14, BX										
  errors.go:26			0x6d89e0		488d8c2418040000		LEAQ 0x418(SP), CX									
  errors.go:26			0x6d89e8		bf01000000			MOVL $0x1, DI										
  errors.go:26			0x6d89ed		4889fe				MOVQ DI, SI										
  errors.go:26			0x6d89f0		e86ba5e2ff			CALL fmt.errorf(SB)									
  errors.go:26			0x6d89f5		4885c0				TESTQ AX, AX										
  errors.go:26			0x6d89f8		7529				JNE 0x6d8a23										
  errors.go:31			0x6d89fa		90				NOPL											
  errors.go:65			0x6d89fb		488d05decd5001			LEAQ 0x150cdde(IP), AX									
  errors.go:65			0x6d8a02		e899c0d4ff			CALL runtime.newobject(SB)								
  errors.go:65			0x6d8a07		48c7400814000000		MOVQ $0x14, 0x8(AX)									
  errors.go:65			0x6d8a0f		488d0d0d286a01			LEAQ 0x16a280d(IP), CX									
  errors.go:65			0x6d8a16		488908				MOVQ CX, 0(AX)										
  tree.go:706			0x6d8a19		4889c3				MOVQ AX, BX										
  tree.go:706			0x6d8a1c		488d059d537e01			LEAQ go:itab.*errors.errorString,error(SB), AX						
  tree.go:706			0x6d8a23		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:706			0x6d8a2b		440f1139			MOVUPS X15, 0(CX)									
  tree.go:706			0x6d8a2f		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:706			0x6d8a34		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:706			0x6d8a39		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:706			0x6d8a3e		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:706			0x6d8a43		4881c428040000			ADDQ $0x428, SP										
  tree.go:706			0x6d8a4a		5d				POPQ BP											
  tree.go:706			0x6d8a4b		c3				RET											
  tree.go:683			0x6d8a4c		488d842470010000		LEAQ 0x170(SP), AX									
  tree.go:683			0x6d8a54		488b9c24a8040000		MOVQ 0x4a8(SP), BX									
  tree.go:683			0x6d8a5c		488b8c24b0040000		MOVQ 0x4b0(SP), CX									
  tree.go:683			0x6d8a64		488bbc24b8040000		MOVQ 0x4b8(SP), DI									
  tree.go:683			0x6d8a6c		e84f91f1ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchLeaf(SB)				
  tree.go:684			0x6d8a71		4885c9				TESTQ CX, CX										
  tree.go:684			0x6d8a74		0f8521010000			JNE 0x6d8b9b										
  tree.go:684			0x6d8a7a		660f1f440000			NOPW 0(AX)(AX*1)									
  tree.go:683			0x6d8a80		84db				TESTL BL, BL										
  tree.go:687			0x6d8a82		0f84dc000000			JE 0x6d8b64										
  tree.go:692			0x6d8a88		89c3				MOVL AX, BX										
  tree.go:692			0x6d8a8a		488d842470010000		LEAQ 0x170(SP), AX									
  tree.go:692			0x6d8a92		e8097af1ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafEntryViewWithRevision(SB)	
  tree.go:692			0x6d8a97		488b542410			MOVQ 0x10(SP), DX									
  tree.go:692			0x6d8a9c		0f1f4000			NOPL 0(AX)										
  tree.go:693			0x6d8aa0		4885d2				TESTQ DX, DX										
  tree.go:693			0x6d8aa3		7431				JE 0x6d8ad6										
  tree.go:692			0x6d8aa5		488b5c2418			MOVQ 0x18(SP), BX									
  tree.go:694			0x6d8aaa		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:694			0x6d8ab2		440f1139			MOVUPS X15, 0(CX)									
  tree.go:694			0x6d8ab6		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:694			0x6d8abb		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:694			0x6d8ac0		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:694			0x6d8ac5		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:694			0x6d8aca		4889d0				MOVQ DX, AX										
  tree.go:694			0x6d8acd		4881c428040000			ADDQ $0x428, SP										
  tree.go:694			0x6d8ad4		5d				POPQ BP											
  tree.go:694			0x6d8ad5		c3				RET											
  tree.go:692			0x6d8ad6		0fb61424			MOVZX 0(SP), DX										
  tree.go:692			0x6d8ada		4c8b642408			MOVQ 0x8(SP), R12									
  tree.go:702			0x6d8adf		4c8dac2450040000		LEAQ 0x450(SP), R13									
  tree.go:702			0x6d8ae7		450f117d00			MOVUPS X15, 0(R13)									
  tree.go:702			0x6d8aec		450f117d10			MOVUPS X15, 0x10(R13)									
  tree.go:702			0x6d8af1		450f117d20			MOVUPS X15, 0x20(R13)									
  tree.go:702			0x6d8af6		450f117d30			MOVUPS X15, 0x30(R13)									
  tree.go:702			0x6d8afb		450f117d40			MOVUPS X15, 0x40(R13)									
  tree.go:698			0x6d8b00		4889842450040000		MOVQ AX, 0x450(SP)									
  tree.go:698			0x6d8b08		48899c2458040000		MOVQ BX, 0x458(SP)									
  tree.go:698			0x6d8b10		48898c2460040000		MOVQ CX, 0x460(SP)									
  tree.go:699			0x6d8b18		4889bc2468040000		MOVQ DI, 0x468(SP)									
  tree.go:699			0x6d8b20		4889b42470040000		MOVQ SI, 0x470(SP)									
  tree.go:699			0x6d8b28		4c89842478040000		MOVQ R8, 0x478(SP)									
  tree.go:700			0x6d8b30		4c898c2480040000		MOVQ R9, 0x480(SP)									
  tree.go:700			0x6d8b38		4489942488040000		MOVL R10, 0x488(SP)									
  tree.go:700			0x6d8b40		44899c248c040000		MOVL R11, 0x48c(SP)									
  tree.go:701			0x6d8b48		88942490040000			MOVB DL, 0x490(SP)									
  tree.go:702			0x6d8b4f		4c89a42498040000		MOVQ R12, 0x498(SP)									
  tree.go:697			0x6d8b57		31c0				XORL AX, AX										
  tree.go:697			0x6d8b59		31db				XORL BX, BX										
  tree.go:703			0x6d8b5b		4881c428040000			ADDQ $0x428, SP										
  tree.go:703			0x6d8b62		5d				POPQ BP											
  tree.go:703			0x6d8b63		c3				RET											
  tree.go:688			0x6d8b64		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:688			0x6d8b6c		440f1139			MOVUPS X15, 0(CX)									
  tree.go:688			0x6d8b70		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:688			0x6d8b75		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:688			0x6d8b7a		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:688			0x6d8b7f		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:688			0x6d8b84		488b0565827302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:688			0x6d8b8b		488b1d66827302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:688			0x6d8b92		4881c428040000			ADDQ $0x428, SP										
  tree.go:688			0x6d8b99		5d				POPQ BP											
  tree.go:688			0x6d8b9a		c3				RET											
  tree.go:685			0x6d8b9b		488d942450040000		LEAQ 0x450(SP), DX									
  tree.go:685			0x6d8ba3		440f113a			MOVUPS X15, 0(DX)									
  tree.go:685			0x6d8ba7		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:685			0x6d8bac		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:685			0x6d8bb1		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:685			0x6d8bb6		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:685			0x6d8bbb		4889c8				MOVQ CX, AX										
  tree.go:685			0x6d8bbe		4889fb				MOVQ DI, BX										
  tree.go:685			0x6d8bc1		4881c428040000			ADDQ $0x428, SP										
  tree.go:685			0x6d8bc8		5d				POPQ BP											
  tree.go:685			0x6d8bc9		c3				RET											
  tree.go:633			0x6d8bca		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:633			0x6d8bd2		440f1139			MOVUPS X15, 0(CX)									
  tree.go:633			0x6d8bd6		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:633			0x6d8bdb		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:633			0x6d8be0		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:633			0x6d8be5		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:633			0x6d8bea		4881c428040000			ADDQ $0x428, SP										
  tree.go:633			0x6d8bf1		5d				POPQ BP											
  tree.go:633			0x6d8bf2		c3				RET											
  errors.go:65			0x6d8bf3		488d05e6cb5001			LEAQ 0x150cbe6(IP), AX									
  errors.go:65			0x6d8bfa		e8a1bed4ff			CALL runtime.newobject(SB)								
  errors.go:65			0x6d8bff		48c740080d000000		MOVQ $0xd, 0x8(AX)									
  errors.go:65			0x6d8c07		488d0d3c456901			LEAQ 0x169453c(IP), CX									
  errors.go:65			0x6d8c0e		488908				MOVQ CX, 0(AX)										
  tree.go:709			0x6d8c11		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:709			0x6d8c19		440f1139			MOVUPS X15, 0(CX)									
  tree.go:709			0x6d8c1d		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:709			0x6d8c22		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:709			0x6d8c27		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:709			0x6d8c2c		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:709			0x6d8c31		4889c3				MOVQ AX, BX										
  tree.go:709			0x6d8c34		488d0585517e01			LEAQ go:itab.*errors.errorString,error(SB), AX						
  tree.go:709			0x6d8c3b		4881c428040000			ADDQ $0x428, SP										
  tree.go:709			0x6d8c42		5d				POPQ BP											
  tree.go:709			0x6d8c43		c3				RET											
  node.go:56			0x6d8c44		e8b7b9dbff			CALL runtime.panicBounds(SB)								
  node.go:56			0x6d8c49		e8b2b9dbff			CALL runtime.panicBounds(SB)								
  node.go:56			0x6d8c4e		90				NOPL											
  tree.go:620			0x6d8c4f		4889442470			MOVQ AX, 0x70(SP)									
  tree.go:620			0x6d8c54		48895c2478			MOVQ BX, 0x78(SP)									
  tree.go:620			0x6d8c59		48898c2480000000		MOVQ CX, 0x80(SP)									
  tree.go:620			0x6d8c61		4889bc2488000000		MOVQ DI, 0x88(SP)									
  tree.go:620			0x6d8c69		4889b42490000000		MOVQ SI, 0x90(SP)									
  tree.go:620			0x6d8c71		4c89842498000000		MOVQ R8, 0x98(SP)									
  tree.go:620			0x6d8c79		4c898c24a0000000		MOVQ R9, 0xa0(SP)									
  tree.go:620			0x6d8c81		4c899424a8000000		MOVQ R10, 0xa8(SP)									
  tree.go:620			0x6d8c89		44889c24b0000000		MOVB R11, 0xb0(SP)									
  tree.go:620			0x6d8c91		e8ca9adbff			CALL runtime.morestack_noctxt.abi0(SB)							
  tree.go:620			0x6d8c96		488b442470			MOVQ 0x70(SP), AX									
  tree.go:620			0x6d8c9b		488b5c2478			MOVQ 0x78(SP), BX									
  tree.go:620			0x6d8ca0		488b8c2480000000		MOVQ 0x80(SP), CX									
  tree.go:620			0x6d8ca8		488bbc2488000000		MOVQ 0x88(SP), DI									
  tree.go:620			0x6d8cb0		488bb42490000000		MOVQ 0x90(SP), SI									
  tree.go:620			0x6d8cb8		4c8b842498000000		MOVQ 0x98(SP), R8									
  tree.go:620			0x6d8cc0		4c8b8c24a0000000		MOVQ 0xa0(SP), R9									
  tree.go:620			0x6d8cc8		4c8b9424a8000000		MOVQ 0xa8(SP), R10									
  tree.go:620			0x6d8cd0		440fb69c24b0000000		MOVZX 0xb0(SP), R11									
  tree.go:620			0x6d8cd9		e9e2f2ffff			JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).getEntry(SB)				

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1082		0x6db5e0		493b6610		CMPQ SP, 0x10(R14)								
  tree.go:1082		0x6db5e4		0f86af020000		JBE 0x6db899									
  tree.go:1082		0x6db5ea		55			PUSHQ BP									
  tree.go:1082		0x6db5eb		4889e5			MOVQ SP, BP									
  tree.go:1082		0x6db5ee		4883ec78		SUBQ $0x78, SP									
  tree.go:1084		0x6db5f2		4889842488000000	MOVQ AX, 0x88(SP)								
  tree.go:1084		0x6db5fa		4c898c24b8000000	MOVQ R9, 0xb8(SP)								
  tree.go:1084		0x6db602		4889b424a8000000	MOVQ SI, 0xa8(SP)								
  tree.go:1084		0x6db60a		48899c2490000000	MOVQ BX, 0x90(SP)								
  tree.go:1084		0x6db612		4c898424b0000000	MOVQ R8, 0xb0(SP)								
  tree.go:1084		0x6db61a		4889bc24a0000000	MOVQ DI, 0xa0(SP)								
  tree.go:1084		0x6db622		48898c2498000000	MOVQ CX, 0x98(SP)								
  tree.go:1083		0x6db62a		41ba01000000		MOVL $0x1, R10									
  tree.go:1083		0x6db630		e8abd6ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView(SB)	
  tree.go:1083		0x6db635		488b1424		MOVQ 0(SP), DX									
  tree.go:1083		0x6db639		0f1f8000000000		NOPL 0(AX)									
  tree.go:1084		0x6db640		4885d2			TESTQ DX, DX									
  tree.go:1084		0x6db643		0f8527020000		JNE 0x6db870									
  tree.go:1083		0x6db649		4584db			TESTL R11, R11									
  tree.go:1087		0x6db64c		7452			JE 0x6db6a0									
  tree.go:1088		0x6db64e		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1088		0x6db656		4989d9			MOVQ BX, R9									
  tree.go:1088		0x6db659		4929d1			SUBQ DX, R9									
  tree.go:100		0x6db65c		803d5411850200		CMPB github.com/snissn/gomap/TreeDB/tree.treeHotReadStatsEnabled(SB), $0x0	
  tree.go:100		0x6db663		7424			JE 0x6db689									
  tree.go:103		0x6db665		90			NOPL										
  type.go:195		0x6db666		ba01000000		MOVL $0x1, DX									
  type.go:195		0x6db66b		4c8d1dc6168502		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineHitsTotal(SB), R11	
  type.go:195		0x6db672		f0490fc113		LOCK XADDQ DX, 0(R11)								
  tree.go:104		0x6db677		4d85c9			TESTQ R9, R9									
  tree.go:104		0x6db67a		7e0d			JLE 0x6db689									
  tree.go:105		0x6db67c		90			NOPL										
  type.go:195		0x6db67d		488d15bc168502		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineBytesTotal(SB), DX	
  type.go:195		0x6db684		f04c0fc10a		LOCK XADDQ R9, 0(DX)								
  tree.go:1089		0x6db689		4c89d7			MOVQ R10, DI									
  tree.go:1089		0x6db68c		31f6			XORL SI, SI									
  tree.go:1089		0x6db68e		4531c0			XORL R8, R8									
  tree.go:1089		0x6db691		4883c478		ADDQ $0x78, SP									
  tree.go:1089		0x6db695		5d			POPQ BP										
  tree.go:1089		0x6db696		c3			RET										
  tree.go:1089		0x6db697		660f1f840000000000	NOPW 0(AX)(AX*1)								
  tree.go:1091		0x6db6a0		41f6c102		TESTL $0x2, R9									
  tree.go:1091		0x6db6a4		0f8597010000		JNE 0x6db841									
  tree.go:1083		0x6db6aa		4c89542450		MOVQ R10, 0x50(SP)								
  tree.go:1094		0x6db6af		41f6c101		TESTL $0x1, R9									
  tree.go:1094		0x6db6b3		0f8523010000		JNE 0x6db7dc									
  tree.go:1094		0x6db6b9		0f1f8000000000		NOPL 0(AX)									
  tree.go:1098		0x6db6c0		4885c0			TESTQ AX, AX									
  tree.go:1098		0x6db6c3		0f84d1000000		JE 0x6db79a									
  tree.go:1102		0x6db6c9		90			NOPL										
  tree.go:100		0x6db6ca		803de610850200		CMPB github.com/snissn/gomap/TreeDB/tree.treeHotReadStatsEnabled(SB), $0x0	
  tree.go:100		0x6db6d1		742f			JE 0x6db702									
  tree.go:103		0x6db6d3		90			NOPL										
  type.go:195		0x6db6d4		ba01000000		MOVL $0x1, DX									
  type.go:195		0x6db6d9		4c8d0558168502		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineHitsTotal(SB), R8	
  type.go:195		0x6db6e0		f0490fc110		LOCK XADDQ DX, 0(R8)								
  tree.go:104		0x6db6e5		4885db			TESTQ BX, BX									
  tree.go:104		0x6db6e8		7411			JE 0x6db6fb									
  type.go:195		0x6db6ea		488d154f168502		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineBytesTotal(SB), DX	
  type.go:195		0x6db6f1		4889df			MOVQ BX, DI									
  type.go:195		0x6db6f4		f0480fc11a		LOCK XADDQ BX, 0(DX)								
  tree.go:105		0x6db6f9		eb0a			JMP 0x6db705									
  tree.go:1103		0x6db6fb		4889df			MOVQ BX, DI									
  tree.go:1103		0x6db6fe		6690			NOPW										
  tree.go:104		0x6db700		eb03			JMP 0x6db705									
  tree.go:1103		0x6db702		4889df			MOVQ BX, DI									
  tree.go:1103		0x6db705		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1103		0x6db70d		488d1c3a		LEAQ 0(DX)(DI*1), BX								
  tree.go:1103		0x6db711		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1103		0x6db719		4839d9			CMPQ CX, BX									
  tree.go:1103		0x6db71c		720a			JB 0x6db728									
  tree.go:1103		0x6db71e		488bb424a8000000	MOVQ 0xa8(SP), SI								
  tree.go:1103		0x6db726		eb33			JMP 0x6db75b									
  tree.go:1083		0x6db728		48897c2460		MOVQ DI, 0x60(SP)								
  tree.go:1083		0x6db72d		4889442468		MOVQ AX, 0x68(SP)								
  tree.go:1103		0x6db732		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1103		0x6db73a		488d35df294801		LEAQ 0x14829df(IP), SI								
  tree.go:1103		0x6db741		e83a36dbff		CALL runtime.growslice(SB)							
  tree.go:1103		0x6db746		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1103		0x6db74e		488b7c2460		MOVQ 0x60(SP), DI								
  tree.go:1103		0x6db753		4889c6			MOVQ AX, SI									
  tree.go:1103		0x6db756		488b442468		MOVQ 0x68(SP), AX								
  tree.go:1103		0x6db75b		48894c2460		MOVQ CX, 0x60(SP)								
  tree.go:1103		0x6db760		48895c2458		MOVQ BX, 0x58(SP)								
  tree.go:1103		0x6db765		4889742470		MOVQ SI, 0x70(SP)								
  tree.go:1103		0x6db76a		4801f2			ADDQ SI, DX									
  tree.go:1103		0x6db76d		4889c3			MOVQ AX, BX									
  tree.go:1103		0x6db770		4889f9			MOVQ DI, CX									
  tree.go:1103		0x6db773		4889d0			MOVQ DX, AX									
  tree.go:1103		0x6db776		e82592dbff		CALL runtime.memmove(SB)							
  tree.go:1103		0x6db77b		488b442470		MOVQ 0x70(SP), AX								
  tree.go:1103		0x6db780		488b5c2458		MOVQ 0x58(SP), BX								
  tree.go:1103		0x6db785		488b4c2460		MOVQ 0x60(SP), CX								
  tree.go:1103		0x6db78a		488b7c2450		MOVQ 0x50(SP), DI								
  tree.go:1103		0x6db78f		31f6			XORL SI, SI									
  tree.go:1103		0x6db791		4531c0			XORL R8, R8									
  tree.go:1103		0x6db794		4883c478		ADDQ $0x78, SP									
  tree.go:1103		0x6db798		5d			POPQ BP										
  tree.go:1103		0x6db799		c3			RET										
  tree.go:1099		0x6db79a		90			NOPL										
  tree.go:100		0x6db79b		803d1510850200		CMPB github.com/snissn/gomap/TreeDB/tree.treeHotReadStatsEnabled(SB), $0x0	
  tree.go:100		0x6db7a2		7412			JE 0x6db7b6									
  tree.go:103		0x6db7a4		90			NOPL										
  type.go:195		0x6db7a5		ba01000000		MOVL $0x1, DX									
  type.go:195		0x6db7aa		4c8d0d87158502		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineHitsTotal(SB), R9	
  type.go:195		0x6db7b1		f0490fc111		LOCK XADDQ DX, 0(R9)								
  tree.go:1100		0x6db7b6		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1100		0x6db7be		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  tree.go:1100		0x6db7c6		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1100		0x6db7ce		4c89d7			MOVQ R10, DI									
  tree.go:1100		0x6db7d1		31f6			XORL SI, SI									
  tree.go:1100		0x6db7d3		4531c0			XORL R8, R8									
  tree.go:1100		0x6db7d6		4883c478		ADDQ $0x78, SP									
  tree.go:1100		0x6db7da		5d			POPQ BP										
  tree.go:1100		0x6db7db		c3			RET										
  tree.go:1095		0x6db7dc		488b9424a8000000	MOVQ 0xa8(SP), DX								
  tree.go:1095		0x6db7e4		48891424		MOVQ DX, 0(SP)									
  tree.go:1095		0x6db7e8		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1095		0x6db7f0		4889542408		MOVQ DX, 0x8(SP)								
  tree.go:1095		0x6db7f5		488b9424b8000000	MOVQ 0xb8(SP), DX								
  tree.go:1095		0x6db7fd		4889542410		MOVQ DX, 0x10(SP)								
  tree.go:1095		0x6db802		488b842488000000	MOVQ 0x88(SP), AX								
  tree.go:1095		0x6db80a		488b9c2490000000	MOVQ 0x90(SP), BX								
  tree.go:1095		0x6db812		488b8c2498000000	MOVQ 0x98(SP), CX								
  tree.go:1095		0x6db81a		4589c1			MOVL R8, R9									
  tree.go:1095		0x6db81d		4189f0			MOVL SI, R8									
  tree.go:1095		0x6db820		4889fe			MOVQ DI, SI									
  tree.go:1095		0x6db823		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  tree.go:1095		0x6db82b		e850f3ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).appendPointerValueForKey(SB)	
  tree.go:1096		0x6db830		4989f0			MOVQ SI, R8									
  tree.go:1096		0x6db833		4889fe			MOVQ DI, SI									
  tree.go:1096		0x6db836		488b7c2450		MOVQ 0x50(SP), DI								
  tree.go:1096		0x6db83b		4883c478		ADDQ $0x78, SP									
  tree.go:1096		0x6db83f		5d			POPQ BP										
  tree.go:1096		0x6db840		c3			RET										
  tree.go:1092		0x6db841		488b35a8557302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), SI			
  tree.go:1092		0x6db848		4c8b05a9557302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R8		
  tree.go:1092		0x6db84f		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1092		0x6db857		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  tree.go:1092		0x6db85f		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1092		0x6db867		4c89d7			MOVQ R10, DI									
  tree.go:1092		0x6db86a		4883c478		ADDQ $0x78, SP									
  tree.go:1092		0x6db86e		5d			POPQ BP										
  tree.go:1092		0x6db86f		c3			RET										
  tree.go:1083		0x6db870		4c8b442408		MOVQ 0x8(SP), R8								
  tree.go:1085		0x6db875		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1085		0x6db87d		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  tree.go:1085		0x6db885		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1085		0x6db88d		4c89d7			MOVQ R10, DI									
  tree.go:1085		0x6db890		4889d6			MOVQ DX, SI									
  tree.go:1085		0x6db893		4883c478		ADDQ $0x78, SP									
  tree.go:1085		0x6db897		5d			POPQ BP										
  tree.go:1085		0x6db898		c3			RET										
  tree.go:1082		0x6db899		4889442408		MOVQ AX, 0x8(SP)								
  tree.go:1082		0x6db89e		48895c2410		MOVQ BX, 0x10(SP)								
  tree.go:1082		0x6db8a3		48894c2418		MOVQ CX, 0x18(SP)								
  tree.go:1082		0x6db8a8		48897c2420		MOVQ DI, 0x20(SP)								
  tree.go:1082		0x6db8ad		4889742428		MOVQ SI, 0x28(SP)								
  tree.go:1082		0x6db8b2		4c89442430		MOVQ R8, 0x30(SP)								
  tree.go:1082		0x6db8b7		4c894c2438		MOVQ R9, 0x38(SP)								
  tree.go:1082		0x6db8bc		0f1f4000		NOPL 0(AX)									
  tree.go:1082		0x6db8c0		e89b6edbff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1082		0x6db8c5		488b442408		MOVQ 0x8(SP), AX								
  tree.go:1082		0x6db8ca		488b5c2410		MOVQ 0x10(SP), BX								
  tree.go:1082		0x6db8cf		488b4c2418		MOVQ 0x18(SP), CX								
  tree.go:1082		0x6db8d4		488b7c2420		MOVQ 0x20(SP), DI								
  tree.go:1082		0x6db8d9		488b742428		MOVQ 0x28(SP), SI								
  tree.go:1082		0x6db8de		4c8b442430		MOVQ 0x30(SP), R8								
  tree.go:1082		0x6db8e3		4c8b4c2438		MOVQ 0x38(SP), R9								
  tree.go:1082		0x6db8e8		e9f3fcffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB)		

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyViewFallback(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1384		0x6ddaa0		4c8d6424d8		LEAQ -0x28(SP), R12								
  tree.go:1384		0x6ddaa5		4d3b6610		CMPQ R12, 0x10(R14)								
  tree.go:1384		0x6ddaa9		0f8624020000		JBE 0x6ddcd3									
  tree.go:1384		0x6ddaaf		55			PUSHQ BP									
  tree.go:1384		0x6ddab0		4889e5			MOVQ SP, BP									
  tree.go:1384		0x6ddab3		4881eca0000000		SUBQ $0xa0, SP									
  tree.go:1384		0x6ddaba		48899c24b8000000	MOVQ BX, 0xb8(SP)								
  tree.go:1386		0x6ddac2		48898424b0000000	MOVQ AX, 0xb0(SP)								
  tree.go:1386		0x6ddaca		4889b424d0000000	MOVQ SI, 0xd0(SP)								
  tree.go:1386		0x6ddad2		48898c24c0000000	MOVQ CX, 0xc0(SP)								
  tree.go:1386		0x6ddada		31d2			XORL DX, DX									
  tree.go:1386		0x6ddadc		31ff			XORL DI, DI									
  tree.go:1386		0x6ddade		4531c0			XORL R8, R8									
  tree.go:1386		0x6ddae1		eb3d			JMP 0x6ddb20									
  tree.go:1386		0x6ddae3		488b9c2498000000	MOVQ 0x98(SP), BX								
  tree.go:1386		0x6ddaeb		4883c318		ADDQ $0x18, BX									
  tree.go:1386		0x6ddaef		4c8b542460		MOVQ 0x60(SP), R10								
  tree.go:1386		0x6ddaf4		49ffc2			INCQ R10									
  tree.go:1386		0x6ddaf7		488b8c24c0000000	MOVQ 0xc0(SP), CX								
  tree.go:1401		0x6ddaff		488bb424d0000000	MOVQ 0xd0(SP), SI								
  tree.go:1386		0x6ddb07		4889d7			MOVQ DX, DI									
  tree.go:1386		0x6ddb0a		4989c0			MOVQ AX, R8									
  tree.go:1387		0x6ddb0d		488b8424b0000000	MOVQ 0xb0(SP), AX								
  tree.go:1386		0x6ddb15		4c89d2			MOVQ R10, DX									
  tree.go:1386		0x6ddb18		0f1f840000000000	NOPL 0(AX)(AX*1)								
  tree.go:1386		0x6ddb20		4839d1			CMPQ CX, DX									
  tree.go:1386		0x6ddb23		0f8e9d010000		JLE 0x6ddcc6									
  tree.go:1386		0x6ddb29		4889542460		MOVQ DX, 0x60(SP)								
  tree.go:1386		0x6ddb2e		4c89442478		MOVQ R8, 0x78(SP)								
  tree.go:1386		0x6ddb33		48897c2440		MOVQ DI, 0x40(SP)								
  tree.go:1386		0x6ddb38		48899c2498000000	MOVQ BX, 0x98(SP)								
  tree.go:1386		0x6ddb40		488b13			MOVQ 0(BX), DX									
  tree.go:1386		0x6ddb43		4889942480000000	MOVQ DX, 0x80(SP)								
  tree.go:1386		0x6ddb4b		488b4b08		MOVQ 0x8(BX), CX								
  tree.go:1386		0x6ddb4f		48894c2450		MOVQ CX, 0x50(SP)								
  tree.go:1386		0x6ddb54		4c8b5310		MOVQ 0x10(BX), R10								
  tree.go:1386		0x6ddb58		4c89542458		MOVQ R10, 0x58(SP)								
  tree.go:1387		0x6ddb5d		4889d3			MOVQ DX, BX									
  tree.go:1387		0x6ddb60		4c89c6			MOVQ R8, SI									
  tree.go:1387		0x6ddb63		4531c0			XORL R8, R8									
  tree.go:1387		0x6ddb66		4989f9			MOVQ DI, R9									
  tree.go:1387		0x6ddb69		4c89d7			MOVQ R10, DI									
  tree.go:1387		0x6ddb6c		e88fd7ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetAppend(SB)			
  tree.go:1387		0x6ddb71		4889842490000000	MOVQ AX, 0x90(SP)								
  tree.go:1387		0x6ddb79		48894c2470		MOVQ CX, 0x70(SP)								
  tree.go:1387		0x6ddb7e		6690			NOPW										
  tree.go:1388		0x6ddb80		48393d69327302		CMPQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), DI			
  tree.go:1388		0x6ddb87		754b			JNE 0x6ddbd4									
  tree.go:1387		0x6ddb89		4889b42488000000	MOVQ SI, 0x88(SP)								
  tree.go:1387		0x6ddb91		48897c2468		MOVQ DI, 0x68(SP)								
  tree.go:1387		0x6ddb96		48895c2448		MOVQ BX, 0x48(SP)								
  tree.go:1388		0x6ddb9b		488b0d56327302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), CX		
  tree.go:1388		0x6ddba2		4889f8			MOVQ DI, AX									
  tree.go:1388		0x6ddba5		4889f3			MOVQ SI, BX									
  tree.go:1388		0x6ddba8		e8139fd3ff		CALL runtime.ifaceeq(SB)							
  tree.go:1388		0x6ddbad		84c0			TESTL AL, AL									
  tree.go:1388		0x6ddbaf		0f85aa000000		JNE 0x6ddc5f									
  tree.go:1401		0x6ddbb5		488b842490000000	MOVQ 0x90(SP), AX								
  tree.go:1401		0x6ddbbd		488b4c2470		MOVQ 0x70(SP), CX								
  tree.go:1398		0x6ddbc2		488b5c2448		MOVQ 0x48(SP), BX								
  tree.go:1395		0x6ddbc7		488bb42488000000	MOVQ 0x88(SP), SI								
  tree.go:1394		0x6ddbcf		488b7c2468		MOVQ 0x68(SP), DI								
  tree.go:1394		0x6ddbd4		4885ff			TESTQ DI, DI									
  tree.go:1394		0x6ddbd7		0f85d1000000		JNE 0x6ddcae									
  tree.go:1394		0x6ddbdd		0f1f00			NOPL 0(AX)									
  tree.go:1398		0x6ddbe0		4885db			TESTQ BX, BX									
  tree.go:1398		0x6ddbe3		7517			JNE 0x6ddbfc									
  tree.go:1399		0x6ddbe5		4c8b1db48e7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue(SB), R11		
  tree.go:1399		0x6ddbec		488b1db58e7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+8(SB), BX	
  tree.go:1399		0x6ddbf3		4c8b25b68e7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+16(SB), R12	
  tree.go:1399		0x6ddbfa		eb06			JMP 0x6ddc02									
  tree.go:1401		0x6ddbfc		4989cc			MOVQ CX, R12									
  tree.go:1401		0x6ddbff		4989c3			MOVQ AX, R11									
  tree.go:1401		0x6ddc02		488b9424d0000000	MOVQ 0xd0(SP), DX								
  tree.go:1401		0x6ddc0a		4c8b2a			MOVQ 0(DX), R13									
  tree.go:1401		0x6ddc0d		488b442460		MOVQ 0x60(SP), AX								
  tree.go:1401		0x6ddc12		488b4c2450		MOVQ 0x50(SP), CX								
  tree.go:1401		0x6ddc17		488b7c2458		MOVQ 0x58(SP), DI								
  tree.go:1401		0x6ddc1c		4c89de			MOVQ R11, SI									
  tree.go:1401		0x6ddc1f		4989d8			MOVQ BX, R8									
  tree.go:1401		0x6ddc22		4d89e1			MOVQ R12, R9									
  tree.go:1401		0x6ddc25		41ba01000000		MOVL $0x1, R10									
  tree.go:1401		0x6ddc2b		488b9c2480000000	MOVQ 0x80(SP), BX								
  tree.go:1401		0x6ddc33		41ffd5			CALL R13									
  tree.go:1401		0x6ddc36		4885c0			TESTQ AX, AX									
  tree.go:1401		0x6ddc39		756a			JNE 0x6ddca5									
  tree.go:1404		0x6ddc3b		488b542470		MOVQ 0x70(SP), DX								
  tree.go:1404		0x6ddc40		4881fa00001000		CMPQ DX, $0x100000								
  tree.go:1404		0x6ddc47		7f0d			JG 0x6ddc56									
  tree.go:1404		0x6ddc49		488b842490000000	MOVQ 0x90(SP), AX								
  tree.go:1405		0x6ddc51		e98dfeffff		JMP 0x6ddae3									
  tree.go:1405		0x6ddc56		31d2			XORL DX, DX									
  tree.go:1405		0x6ddc58		31c0			XORL AX, AX									
  tree.go:1404		0x6ddc5a		e984feffff		JMP 0x6ddae3									
  tree.go:1389		0x6ddc5f		488b9424d0000000	MOVQ 0xd0(SP), DX								
  tree.go:1389		0x6ddc67		4c8b1a			MOVQ 0(DX), R11									
  tree.go:1389		0x6ddc6a		488b442460		MOVQ 0x60(SP), AX								
  tree.go:1389		0x6ddc6f		488b9c2480000000	MOVQ 0x80(SP), BX								
  tree.go:1389		0x6ddc77		488b4c2450		MOVQ 0x50(SP), CX								
  tree.go:1389		0x6ddc7c		488b7c2458		MOVQ 0x58(SP), DI								
  tree.go:1389		0x6ddc81		31f6			XORL SI, SI									
  tree.go:1389		0x6ddc83		4531c0			XORL R8, R8									
  tree.go:1389		0x6ddc86		4d89c1			MOVQ R8, R9									
  tree.go:1389		0x6ddc89		4531d2			XORL R10, R10									
  tree.go:1389		0x6ddc8c		41ffd3			CALL R11									
  tree.go:1389		0x6ddc8f		4885c0			TESTQ AX, AX									
  tree.go:1389		0x6ddc92		7529			JNE 0x6ddcbd									
  tree.go:1386		0x6ddc94		488b542440		MOVQ 0x40(SP), DX								
  tree.go:1386		0x6ddc99		488b442478		MOVQ 0x78(SP), AX								
  tree.go:1386		0x6ddc9e		6690			NOPW										
  tree.go:1392		0x6ddca0		e93efeffff		JMP 0x6ddae3									
  tree.go:1402		0x6ddca5		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1402		0x6ddcac		5d			POPQ BP										
  tree.go:1402		0x6ddcad		c3			RET										
  tree.go:1395		0x6ddcae		4889f8			MOVQ DI, AX									
  tree.go:1395		0x6ddcb1		4889f3			MOVQ SI, BX									
  tree.go:1395		0x6ddcb4		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1395		0x6ddcbb		5d			POPQ BP										
  tree.go:1395		0x6ddcbc		c3			RET										
  tree.go:1390		0x6ddcbd		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1390		0x6ddcc4		5d			POPQ BP										
  tree.go:1390		0x6ddcc5		c3			RET										
  tree.go:1410		0x6ddcc6		31c0			XORL AX, AX									
  tree.go:1410		0x6ddcc8		31db			XORL BX, BX									
  tree.go:1410		0x6ddcca		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1410		0x6ddcd1		5d			POPQ BP										
  tree.go:1410		0x6ddcd2		c3			RET										
  tree.go:1384		0x6ddcd3		4889442408		MOVQ AX, 0x8(SP)								
  tree.go:1384		0x6ddcd8		48895c2410		MOVQ BX, 0x10(SP)								
  tree.go:1384		0x6ddcdd		48894c2418		MOVQ CX, 0x18(SP)								
  tree.go:1384		0x6ddce2		48897c2420		MOVQ DI, 0x20(SP)								
  tree.go:1384		0x6ddce7		4889742428		MOVQ SI, 0x28(SP)								
  tree.go:1384		0x6ddcec		e86f4adbff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1384		0x6ddcf1		488b442408		MOVQ 0x8(SP), AX								
  tree.go:1384		0x6ddcf6		488b5c2410		MOVQ 0x10(SP), BX								
  tree.go:1384		0x6ddcfb		488b4c2418		MOVQ 0x18(SP), CX								
  tree.go:1384		0x6ddd00		488b7c2420		MOVQ 0x20(SP), DI								
  tree.go:1384		0x6ddd05		488b742428		MOVQ 0x28(SP), SI								
  tree.go:1384		0x6ddd0a		e991fdffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyViewFallback(SB)		

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyAppendFallback(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1413		0x6ddd20		4c8d6424f0		LEAQ -0x10(SP), R12								
  tree.go:1413		0x6ddd25		4d3b6610		CMPQ R12, 0x10(R14)								
  tree.go:1413		0x6ddd29		0f86eb020000		JBE 0x6de01a									
  tree.go:1413		0x6ddd2f		55			PUSHQ BP									
  tree.go:1413		0x6ddd30		4889e5			MOVQ SP, BP									
  tree.go:1413		0x6ddd33		4881ec88000000		SUBQ $0x88, SP									
  tree.go:1413		0x6ddd3a		48899c24b8000000	MOVQ BX, 0xb8(SP)								
  tree.go:1414		0x6ddd42		48898424b0000000	MOVQ AX, 0xb0(SP)								
  tree.go:1414		0x6ddd4a		4c898424d8000000	MOVQ R8, 0xd8(SP)								
  tree.go:1414		0x6ddd52		48898c24c0000000	MOVQ CX, 0xc0(SP)								
  tree.go:1414		0x6ddd5a		4889b424d0000000	MOVQ SI, 0xd0(SP)								
  tree.go:1414		0x6ddd62		31d2			XORL DX, DX									
  tree.go:1414		0x6ddd64		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  tree.go:1414		0x6ddd6c		4c8b8c24a8000000	MOVQ 0xa8(SP), R9								
  tree.go:1414		0x6ddd74		4c8b942498000000	MOVQ 0x98(SP), R10								
  tree.go:1414		0x6ddd7c		eb37			JMP 0x6dddb5									
  tree.go:1414		0x6ddd7e		4c8b5c2478		MOVQ 0x78(SP), R11								
  tree.go:1414		0x6ddd83		4983c318		ADDQ $0x18, R11									
  tree.go:1414		0x6ddd87		4d8d6201		LEAQ 0x1(R10), R12								
  tree.go:1426		0x6ddd8b		4889d6			MOVQ DX, SI									
  tree.go:1426		0x6ddd8e		4c8b8424d8000000	MOVQ 0xd8(SP), R8								
  tree.go:1414		0x6ddd96		4c89e2			MOVQ R12, DX									
  tree.go:1414		0x6ddd99		4889df			MOVQ BX, DI									
  tree.go:1414		0x6ddd9c		4989c9			MOVQ CX, R9									
  tree.go:1414		0x6ddd9f		4989c2			MOVQ AX, R10									
  tree.go:1416		0x6ddda2		488b8424b0000000	MOVQ 0xb0(SP), AX								
  tree.go:1414		0x6dddaa		488b8c24c0000000	MOVQ 0xc0(SP), CX								
  tree.go:1414		0x6dddb2		4c89db			MOVQ R11, BX									
  tree.go:1414		0x6dddb5		4839d1			CMPQ CX, DX									
  tree.go:1414		0x6dddb8		0f8e31020000		JLE 0x6ddfef									
  tree.go:1414		0x6dddbe		4889542448		MOVQ DX, 0x48(SP)								
  tree.go:1414		0x6dddc3		4c894c2460		MOVQ R9, 0x60(SP)								
  tree.go:1414		0x6dddc8		48897c2458		MOVQ DI, 0x58(SP)								
  tree.go:1414		0x6dddcd		4c89942480000000	MOVQ R10, 0x80(SP)								
  tree.go:1414		0x6dddd5		48895c2478		MOVQ BX, 0x78(SP)								
  tree.go:1414		0x6dddda		488b13			MOVQ 0(BX), DX									
  tree.go:1414		0x6ddddd		488b4b08		MOVQ 0x8(BX), CX								
  tree.go:1414		0x6ddde1		4c8b5b10		MOVQ 0x10(BX), R11								
  tree.go:1416		0x6ddde5		4889d3			MOVQ DX, BX									
  tree.go:1416		0x6ddde8		4c89d6			MOVQ R10, SI									
  tree.go:1416		0x6dddeb		4989f8			MOVQ DI, R8									
  tree.go:1416		0x6dddee		4c89df			MOVQ R11, DI									
  tree.go:1416		0x6dddf1		e80ad5ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetAppend(SB)			
  tree.go:1416		0x6dddf6		660f1f840000000000	NOPW 0(AX)(AX*1)								
  tree.go:1416		0x6dddff		90			NOPL										
  tree.go:1417		0x6dde00		48393de92f7302		CMPQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), DI			
  tree.go:1417		0x6dde07		0f85c1000000		JNE 0x6ddece									
  tree.go:1416		0x6dde0d		4889442468		MOVQ AX, 0x68(SP)								
  tree.go:1416		0x6dde12		4889742470		MOVQ SI, 0x70(SP)								
  tree.go:1416		0x6dde17		48897c2450		MOVQ DI, 0x50(SP)								
  tree.go:1416		0x6dde1c		48894c2440		MOVQ CX, 0x40(SP)								
  tree.go:1416		0x6dde21		48895c2438		MOVQ BX, 0x38(SP)								
  tree.go:1417		0x6dde26		488b0dcb2f7302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), CX		
  tree.go:1417		0x6dde2d		4889f8			MOVQ DI, AX									
  tree.go:1417		0x6dde30		4889f3			MOVQ SI, BX									
  tree.go:1417		0x6dde33		e8889cd3ff		CALL runtime.ifaceeq(SB)							
  tree.go:1417		0x6dde38		84c0			TESTL AL, AL									
  tree.go:1417		0x6dde3a		7479			JE 0x6ddeb5									
  tree.go:1418		0x6dde3c		488b9424d8000000	MOVQ 0xd8(SP), DX								
  tree.go:1418		0x6dde44		4c8b542448		MOVQ 0x48(SP), R10								
  tree.go:1418		0x6dde49		4c39d2			CMPQ DX, R10									
  tree.go:1418		0x6dde4c		0f86c2010000		JBE 0x6de014									
  tree.go:1418		0x6dde52		4f8d1c52		LEAQ 0(R10)(R10*2), R11								
  tree.go:1418		0x6dde56		4c8ba424d0000000	MOVQ 0xd0(SP), R12								
  tree.go:1418		0x6dde5e		4bc744dc0800000000	MOVQ $0x0, 0x8(R12)(R11*8)							
  tree.go:1418		0x6dde67		4bc744dc1000000000	MOVQ $0x0, 0x10(R12)(R11*8)							
  tree.go:1418		0x6dde70		833da9f6840200		CMPL runtime.writeBarrier(SB), $0x0						
  tree.go:1418		0x6dde77		7412			JE 0x6dde8b									
  tree.go:1418		0x6dde79		4f8b2cdc		MOVQ 0(R12)(R11*8), R13								
  tree.go:1418		0x6dde7d		4c89d8			MOVQ R11, AX									
  tree.go:1418		0x6dde80		e8bb63dbff		CALL runtime.gcWriteBarrier1(SB)						
  tree.go:1418		0x6dde85		4d892b			MOVQ R13, 0(R11)								
  tree.go:1418		0x6dde88		4989c3			MOVQ AX, R11									
  tree.go:1418		0x6dde8b		4bc704dc00000000	MOVQ $0x0, 0(R12)(R11*8)							
  tree.go:1426		0x6dde93		4c89e2			MOVQ R12, DX									
  tree.go:1426		0x6dde96		488bb424d8000000	MOVQ 0xd8(SP), SI								
  tree.go:1414		0x6dde9e		488b4c2460		MOVQ 0x60(SP), CX								
  tree.go:1414		0x6ddea3		488b5c2458		MOVQ 0x58(SP), BX								
  tree.go:1414		0x6ddea8		488b842480000000	MOVQ 0x80(SP), AX								
  tree.go:1419		0x6ddeb0		e9c9feffff		JMP 0x6ddd7e									
  tree.go:1429		0x6ddeb5		488b442468		MOVQ 0x68(SP), AX								
  tree.go:1414		0x6ddeba		488b4c2440		MOVQ 0x40(SP), CX								
  tree.go:1425		0x6ddebf		488b5c2438		MOVQ 0x38(SP), BX								
  tree.go:1422		0x6ddec4		488b742470		MOVQ 0x70(SP), SI								
  tree.go:1421		0x6ddec9		488b7c2450		MOVQ 0x50(SP), DI								
  tree.go:1421		0x6ddece		4885ff			TESTQ DI, DI									
  tree.go:1421		0x6dded1		0f85fd000000		JNE 0x6ddfd4									
  tree.go:1425		0x6dded7		488b542458		MOVQ 0x58(SP), DX								
  tree.go:1425		0x6ddedc		0f1f4000		NOPL 0(AX)									
  tree.go:1425		0x6ddee0		4839d3			CMPQ BX, DX									
  tree.go:1425		0x6ddee3		756c			JNE 0x6ddf51									
  tree.go:1426		0x6ddee5		488b9424d8000000	MOVQ 0xd8(SP), DX								
  tree.go:1426		0x6ddeed		4c8b542448		MOVQ 0x48(SP), R10								
  tree.go:1426		0x6ddef2		4c39d2			CMPQ DX, R10									
  tree.go:1426		0x6ddef5		0f8614010000		JBE 0x6de00f									
  tree.go:1426		0x6ddefb		4f8d1c52		LEAQ 0(R10)(R10*2), R11								
  tree.go:1426		0x6ddeff		4c8b25a28b7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+8(SB), R12	
  tree.go:1426		0x6ddf06		4c8b2da38b7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+16(SB), R13	
  tree.go:1426		0x6ddf0d		4c8b3d8c8b7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue(SB), R15		
  tree.go:1414		0x6ddf14		4889d6			MOVQ DX, SI									
  tree.go:1426		0x6ddf17		488b9424d0000000	MOVQ 0xd0(SP), DX								
  tree.go:1426		0x6ddf1f		4e8964da08		MOVQ R12, 0x8(DX)(R11*8)							
  tree.go:1426		0x6ddf24		4e896cda10		MOVQ R13, 0x10(DX)(R11*8)							
  tree.go:1426		0x6ddf29		833df0f5840200		CMPL runtime.writeBarrier(SB), $0x0						
  tree.go:1426		0x6ddf30		7416			JE 0x6ddf48									
  tree.go:1426		0x6ddf32		4e8b24da		MOVQ 0(DX)(R11*8), R12								
  tree.go:1426		0x6ddf36		4c89df			MOVQ R11, DI									
  tree.go:1426		0x6ddf39		e82263dbff		CALL runtime.gcWriteBarrier2(SB)						
  tree.go:1426		0x6ddf3e		4d893b			MOVQ R15, 0(R11)								
  tree.go:1426		0x6ddf41		4d896308		MOVQ R12, 0x8(R11)								
  tree.go:1426		0x6ddf45		4989fb			MOVQ DI, R11									
  tree.go:1426		0x6ddf48		4e893cda		MOVQ R15, 0(DX)(R11*8)								
  tree.go:1427		0x6ddf4c		e92dfeffff		JMP 0x6ddd7e									
  tree.go:1429		0x6ddf51		0f82b3000000		JB 0x6de00a									
  tree.go:1429		0x6ddf57		4989da			MOVQ BX, R10									
  tree.go:1429		0x6ddf5a		4829d3			SUBQ DX, BX									
  tree.go:1429		0x6ddf5d		4989db			MOVQ BX, R11									
  tree.go:1429		0x6ddf60		48f7db			NEGQ BX										
  tree.go:1429		0x6ddf63		48c1fb3f		SARQ $0x3f, BX									
  tree.go:1429		0x6ddf67		4821da			ANDQ BX, DX									
  tree.go:1429		0x6ddf6a		4801c2			ADDQ AX, DX									
  tree.go:1429		0x6ddf6d		4c8ba424d8000000	MOVQ 0xd8(SP), R12								
  tree.go:1429		0x6ddf75		4c8b6c2448		MOVQ 0x48(SP), R13								
  tree.go:1429		0x6ddf7a		660f1f440000		NOPW 0(AX)(AX*1)								
  tree.go:1429		0x6ddf80		4d39ec			CMPQ R12, R13									
  tree.go:1429		0x6ddf83		0f867c000000		JBE 0x6de005									
  tree.go:1429		0x6ddf89		4f8d7c6d00		LEAQ 0(R13)(R13*2), R15								
  tree.go:1414		0x6ddf8e		4c89e3			MOVQ R12, BX									
  tree.go:1429		0x6ddf91		4c8ba424d0000000	MOVQ 0xd0(SP), R12								
  tree.go:1429		0x6ddf99		4f895cfc08		MOVQ R11, 0x8(R12)(R15*8)							
  tree.go:1429		0x6ddf9e		4f895cfc10		MOVQ R11, 0x10(R12)(R15*8)							
  tree.go:1429		0x6ddfa3		833d76f5840200		CMPL runtime.writeBarrier(SB), $0x0						
  tree.go:1429		0x6ddfaa		7413			JE 0x6ddfbf									
  tree.go:1429		0x6ddfac		4f8b1cfc		MOVQ 0(R12)(R15*8), R11								
  tree.go:1429		0x6ddfb0		4c89de			MOVQ R11, SI									
  tree.go:1429		0x6ddfb3		e8a862dbff		CALL runtime.gcWriteBarrier2(SB)						
  tree.go:1429		0x6ddfb8		498913			MOVQ DX, 0(R11)									
  tree.go:1429		0x6ddfbb		49897308		MOVQ SI, 0x8(R11)								
  tree.go:1429		0x6ddfbf		4b8914fc		MOVQ DX, 0(R12)(R15*8)								
  tree.go:1426		0x6ddfc3		4c89e2			MOVQ R12, DX									
  tree.go:1426		0x6ddfc6		4889de			MOVQ BX, SI									
  tree.go:1414		0x6ddfc9		4c89d3			MOVQ R10, BX									
  tree.go:1414		0x6ddfcc		4d89ea			MOVQ R13, R10									
  tree.go:1429		0x6ddfcf		e9aafdffff		JMP 0x6ddd7e									
  tree.go:1422		0x6ddfd4		488b842480000000	MOVQ 0x80(SP), AX								
  tree.go:1422		0x6ddfdc		488b5c2458		MOVQ 0x58(SP), BX								
  tree.go:1422		0x6ddfe1		488b4c2460		MOVQ 0x60(SP), CX								
  tree.go:1422		0x6ddfe6		4881c488000000		ADDQ $0x88, SP									
  tree.go:1422		0x6ddfed		5d			POPQ BP										
  tree.go:1422		0x6ddfee		c3			RET										
  tree.go:1431		0x6ddfef		4c89d0			MOVQ R10, AX									
  tree.go:1431		0x6ddff2		4889fb			MOVQ DI, BX									
  tree.go:1431		0x6ddff5		4c89c9			MOVQ R9, CX									
  tree.go:1431		0x6ddff8		31ff			XORL DI, DI									
  tree.go:1431		0x6ddffa		31f6			XORL SI, SI									
  tree.go:1431		0x6ddffc		4881c488000000		ADDQ $0x88, SP									
  tree.go:1431		0x6de003		5d			POPQ BP										
  tree.go:1431		0x6de004		c3			RET										
  tree.go:1429		0x6de005		e8f665dbff		CALL runtime.panicBounds(SB)							
  tree.go:1429		0x6de00a		e8f165dbff		CALL runtime.panicBounds(SB)							
  tree.go:1426		0x6de00f		e8ec65dbff		CALL runtime.panicBounds(SB)							
  tree.go:1418		0x6de014		e8e765dbff		CALL runtime.panicBounds(SB)							
  tree.go:1418		0x6de019		90			NOPL										
  tree.go:1413		0x6de01a		4889442420		MOVQ AX, 0x20(SP)								
  tree.go:1413		0x6de01f		48895c2428		MOVQ BX, 0x28(SP)								
  tree.go:1413		0x6de024		48894c2430		MOVQ CX, 0x30(SP)								
  tree.go:1413		0x6de029		48897c2438		MOVQ DI, 0x38(SP)								
  tree.go:1413		0x6de02e		4889742440		MOVQ SI, 0x40(SP)								
  tree.go:1413		0x6de033		4c89442448		MOVQ R8, 0x48(SP)								
  tree.go:1413		0x6de038		4c894c2450		MOVQ R9, 0x50(SP)								
  tree.go:1413		0x6de03d		0f1f00			NOPL 0(AX)									
  tree.go:1413		0x6de040		e81b47dbff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1413		0x6de045		488b442420		MOVQ 0x20(SP), AX								
  tree.go:1413		0x6de04a		488b5c2428		MOVQ 0x28(SP), BX								
  tree.go:1413		0x6de04f		488b4c2430		MOVQ 0x30(SP), CX								
  tree.go:1413		0x6de054		488b7c2438		MOVQ 0x38(SP), DI								
  tree.go:1413		0x6de059		488b742440		MOVQ 0x40(SP), SI								
  tree.go:1413		0x6de05e		4c8b442448		MOVQ 0x48(SP), R8								
  tree.go:1413		0x6de063		4c8b4c2450		MOVQ 0x50(SP), R9								
  tree.go:1413		0x6de068		e9b3fcffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyAppendFallback(SB)	

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).findLeafRefForGetMany(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1434			0x6de080		4c8da42430fcffff	LEAQ 0xfffffc30(SP), R12							
  tree.go:1434			0x6de088		4d3b6610		CMPQ R12, 0x10(R14)								
  tree.go:1434			0x6de08c		0f86ad0a0000		JBE 0x6deb3f									
  tree.go:1434			0x6de092		55			PUSHQ BP									
  tree.go:1434			0x6de093		4889e5			MOVQ SP, BP									
  tree.go:1434			0x6de096		4881ec48040000		SUBQ $0x448, SP									
  tree.go:1434			0x6de09d		48899c2460040000	MOVQ BX, 0x460(SP)								
  tree.go:1434			0x6de0a5		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1434			0x6de0ad		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1434			0x6de0b1		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1434			0x6de0b6		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1434			0x6de0bb		0f1f440000		NOPL 0(AX)(AX*1)								
  tree.go:1435			0x6de0c0		4885c0			TESTQ AX, AX									
  tree.go:1435			0x6de0c3		0f84a6000000		JE 0x6de16f									
  tree.go:1435			0x6de0c9		4889842458040000	MOVQ AX, 0x458(SP)								
  tree.go:1435			0x6de0d1		4088b42478040000	MOVB SI, 0x478(SP)								
  tree.go:1435			0x6de0d9		4889bc2470040000	MOVQ DI, 0x470(SP)								
  tree.go:1435			0x6de0e1		48898c2468040000	MOVQ CX, 0x468(SP)								
  tree.go:1435			0x6de0e9		48899c2460040000	MOVQ BX, 0x460(SP)								
  tree.go:1438			0x6de0f1		e8ea26ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).pointDefinitelyAbsent(SB)	
  tree.go:1438			0x6de0f6		84c0			TESTL AL, AL									
  tree.go:1438			0x6de0f8		7537			JNE 0x6de131									
  tree.go:1441			0x6de0fa		488b842458040000	MOVQ 0x458(SP), AX								
  tree.go:1441			0x6de102		488b90d0000000		MOVQ 0xd0(AX), DX								
  tree.go:1441			0x6de109		4c8da42418010000	LEAQ 0x118(SP), R12								
  tree.go:1441			0x6de111		450f113c24		MOVUPS X15, 0(R12)								
  tree.go:1441			0x6de116		450f117c2410		MOVUPS X15, 0x10(R12)								
  tree.go:1441			0x6de11c		450f117c2418		MOVUPS X15, 0x18(R12)								
  tree.go:1441			0x6de122		4889942420010000	MOVQ DX, 0x120(SP)								
  tree.go:1441			0x6de12a		31c9			XORL CX, CX									
  tree.go:1442			0x6de12c		e9b1000000		JMP 0x6de1e2									
  tree.go:1439			0x6de131		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1439			0x6de139		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1439			0x6de13d		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1439			0x6de142		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1439			0x6de147		4c8b15a22c7302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), R10		
  tree.go:1439			0x6de14e		4c8b1da32c7302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R11		
  tree.go:1439			0x6de155		31c0			XORL AX, AX									
  tree.go:1439			0x6de157		31db			XORL BX, BX									
  tree.go:1439			0x6de159		31c9			XORL CX, CX									
  tree.go:1439			0x6de15b		4889df			MOVQ BX, DI									
  tree.go:1439			0x6de15e		89ce			MOVL CX, SI									
  tree.go:1439			0x6de160		4531c0			XORL R8, R8									
  tree.go:1439			0x6de163		4531c9			XORL R9, R9									
  tree.go:1439			0x6de166		4881c448040000		ADDQ $0x448, SP									
  tree.go:1439			0x6de16d		5d			POPQ BP										
  tree.go:1439			0x6de16e		c3			RET										
  errors.go:65			0x6de16f		488d056a765001		LEAQ 0x150766a(IP), AX								
  errors.go:65			0x6de176		e82569d4ff		CALL runtime.newobject(SB)							
  errors.go:65			0x6de17b		48c740080c000000	MOVQ $0xc, 0x8(AX)								
  errors.go:65			0x6de183		488d0dd8d96801		LEAQ 0x168d9d8(IP), CX								
  errors.go:65			0x6de18a		488908			MOVQ CX, 0(AX)									
  tree.go:1436			0x6de18d		488d8c24d0000000	LEAQ 0xd0(SP), CX								
  tree.go:1436			0x6de195		440f1139		MOVUPS X15, 0(CX)								
  tree.go:1436			0x6de199		440f117910		MOVUPS X15, 0x10(CX)								
  tree.go:1436			0x6de19e		440f117918		MOVUPS X15, 0x18(CX)								
  tree.go:1436			0x6de1a3		31db			XORL BX, BX									
  tree.go:1436			0x6de1a5		31c9			XORL CX, CX									
  tree.go:1436			0x6de1a7		4889df			MOVQ BX, DI									
  tree.go:1436			0x6de1aa		89ce			MOVL CX, SI									
  tree.go:1436			0x6de1ac		4531c0			XORL R8, R8									
  tree.go:1436			0x6de1af		4531c9			XORL R9, R9									
  tree.go:1436			0x6de1b2		4c8d1507fc7d01		LEAQ go:itab.*errors.errorString,error(SB), R10					
  tree.go:1436			0x6de1b9		4989c3			MOVQ AX, R11									
  tree.go:1436			0x6de1bc		31c0			XORL AX, AX									
  tree.go:1436			0x6de1be		4881c448040000		ADDQ $0x448, SP									
  tree.go:1436			0x6de1c5		5d			POPQ BP										
  tree.go:1436			0x6de1c6		c3			RET										
  tree.go:1442			0x6de1c7		488b8c2410010000	MOVQ 0x110(SP), CX								
  tree.go:1442			0x6de1cf		48ffc1			INCQ CX										
  tree.go:1447			0x6de1d2		488b842458040000	MOVQ 0x458(SP), AX								
  tree.go:1441			0x6de1da		4c8da42418010000	LEAQ 0x118(SP), R12								
  tree.go:1442			0x6de1e2		4883f932		CMPQ CX, $0x32									
  tree.go:1442			0x6de1e6		0f8df0080000		JGE 0x6deadc									
  tree.go:1443			0x6de1ec		80bc241801000001	CMPB 0x118(SP), $0x1								
  tree.go:1443			0x6de1f4		0f8477080000		JE 0x6dea71									
  tree.go:1442			0x6de1fa		48898c2410010000	MOVQ CX, 0x110(SP)								
  tree.go:1446			0x6de202		488d9c2490010000	LEAQ 0x190(SP), BX								
  tree.go:1446			0x6de20a		ba05000000		MOVL $0x5, DX									
  tree.go:1446			0x6de20f		440f113b		MOVUPS X15, 0(BX)								
  tree.go:1446			0x6de213		440f117b10		MOVUPS X15, 0x10(BX)								
  tree.go:1446			0x6de218		440f117b20		MOVUPS X15, 0x20(BX)								
  tree.go:1446			0x6de21d		440f117b30		MOVUPS X15, 0x30(BX)								
  tree.go:1446			0x6de222		4883c340		ADDQ $0x40, BX									
  tree.go:1446			0x6de226		ffca			DECL DX										
  tree.go:1446			0x6de228		75e5			JNE 0x6de20f									
  tree.go:1446			0x6de22a		440f117bf8		MOVUPS X15, -0x8(BX)								
  tree.go:1447			0x6de22f		0fb68c2418010000	MOVZX 0x118(SP), CX								
  tree.go:1447			0x6de237		488bbc2420010000	MOVQ 0x120(SP), DI								
  tree.go:1447			0x6de23f		8bb42428010000		MOVL 0x128(SP), SI								
  tree.go:1447			0x6de246		4c8b842430010000	MOVQ 0x130(SP), R8								
  tree.go:1447			0x6de24e		448b8c2438010000	MOVL 0x138(SP), R9								
  tree.go:1447			0x6de256		440fb794243c010000	MOVZX 0x13c(SP), R10								
  tree.go:1447			0x6de25f		c6042400		MOVB $0x0, 0(SP)								
  tree.go:1447			0x6de263		488d9c2490010000	LEAQ 0x190(SP), BX								
  tree.go:1447			0x6de26b		440fb69c2478040000	MOVZX 0x478(SP), R11								
  tree.go:1447			0x6de274		e80794ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).loadChildRefViewInto(SB)	
  tree.go:1447			0x6de279		0f1f8000000000		NOPL 0(AX)									
  tree.go:1447			0x6de280		4885c0			TESTQ AX, AX									
  tree.go:1447			0x6de283		0f85b2070000		JNE 0x6dea3b									
  node.go:224			0x6de289		0fb78424aa010000	MOVZX 0x1aa(SP), AX								
  tree.go:1450			0x6de291		90			NOPL										
  tree.go:1465			0x6de292		6683f803		CMPW AX, $0x3									
  tree.go:1465			0x6de296		0f8516020000		JNE 0x6de4b2									
  tree.go:1466			0x6de29c		488b942410010000	MOVQ 0x110(SP), DX								
  tree.go:1466			0x6de2a4		4885d2			TESTQ DX, DX									
  tree.go:1466			0x6de2a7		0f85c4000000		JNE 0x6de371									
  tree.go:1467			0x6de2ad		488d842490010000	LEAQ 0x190(SP), AX								
  tree.go:1467			0x6de2b5		e826c8f0ff		CALL github.com/snissn/gomap/TreeDB/node.(*Node).InternalFenceBounds(SB)	
  tree.go:1467			0x6de2ba		660f1f440000		NOPW 0(AX)(AX*1)								
  tree.go:1467			0x6de2c0		4d85d2			TESTQ R10, R10									
  tree.go:1467			0x6de2c3		0f8576050000		JNE 0x6de83f									
  tree.go:1467			0x6de2c9		4584c9			TESTL R9, R9									
  tree.go:1469			0x6de2cc		0f8497000000		JE 0x6de369									
  tree.go:1470			0x6de2d2		4885db			TESTQ BX, BX									
  tree.go:1470			0x6de2d5		745f			JE 0x6de336									
  tree.go:1467			0x6de2d7		4889bc24d8020000	MOVQ DI, 0x2d8(SP)								
  tree.go:1467			0x6de2df		4c89842400010000	MOVQ R8, 0x100(SP)								
  tree.go:1467			0x6de2e7		4889b424f8000000	MOVQ SI, 0xf8(SP)								
  tree.go:1470			0x6de2ef		4889c7			MOVQ AX, DI									
  tree.go:1470			0x6de2f2		4889de			MOVQ BX, SI									
  tree.go:1470			0x6de2f5		4989c8			MOVQ CX, R8									
  tree.go:1470			0x6de2f8		488b842460040000	MOVQ 0x460(SP), AX								
  tree.go:1470			0x6de300		488b9c2468040000	MOVQ 0x468(SP), BX								
  tree.go:1470			0x6de308		488b8c2470040000	MOVQ 0x470(SP), CX								
  tree.go:1470			0x6de310		e82b72ffff		CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)			
  tree.go:1470			0x6de315		4885c0			TESTQ AX, AX									
  tree.go:1470			0x6de318		0f8c7d040000		JL 0x6de79b									
  tree.go:1473			0x6de31e		488bb424f8000000	MOVQ 0xf8(SP), SI								
  tree.go:1473			0x6de326		488bbc24d8020000	MOVQ 0x2d8(SP), DI								
  tree.go:1473			0x6de32e		4c8b842400010000	MOVQ 0x100(SP), R8								
  tree.go:1473			0x6de336		4885f6			TESTQ SI, SI									
  tree.go:1473			0x6de339		742e			JE 0x6de369									
  tree.go:1473			0x6de33b		488b842460040000	MOVQ 0x460(SP), AX								
  tree.go:1473			0x6de343		488b9c2468040000	MOVQ 0x468(SP), BX								
  tree.go:1473			0x6de34b		488b8c2470040000	MOVQ 0x470(SP), CX								
  tree.go:1473			0x6de353		e8e871ffff		CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)			
  tree.go:1473			0x6de358		0f1f840000000000	NOPL 0(AX)(AX*1)								
  tree.go:1473			0x6de360		4885c0			TESTQ AX, AX									
  tree.go:1473			0x6de363		0f8df4030000		JGE 0x6de75d									
  tree.go:1442			0x6de369		488b942410010000	MOVQ 0x110(SP), DX								
  node.go:309			0x6de371		90			NOPL										
  node.go:302			0x6de372		6683bc24aa01000003	CMPW 0x1aa(SP), $0x3								
  node.go:302			0x6de37b		752f			JNE 0x6de3ac									
  node.go:236			0x6de37d		488bb42498010000	MOVQ 0x198(SP), SI								
  node.go:56			0x6de385		4883fe0c		CMPQ SI, $0xc									
  node.go:56			0x6de389		0f86aa070000		JBE 0x6deb39									
  node.go:56			0x6de38f		4883fe0d		CMPQ SI, $0xd									
  node.go:56			0x6de393		0f869b070000		JBE 0x6deb34									
  node.go:236			0x6de399		488bb42490010000	MOVQ 0x190(SP), SI								
  node.go:56			0x6de3a1		0fb7760c		MOVZX 0xc(SI), SI								
  node.go:305			0x6de3a5		66f7c68000		TESTW $0x80, SI									
  tree.go:1478			0x6de3aa		7551			JNE 0x6de3fd									
  tree.go:1485			0x6de3ac		488d842490010000	LEAQ 0x190(SP), AX								
  tree.go:1485			0x6de3b4		488b9c2460040000	MOVQ 0x460(SP), BX								
  tree.go:1485			0x6de3bc		488b8c2468040000	MOVQ 0x468(SP), CX								
  tree.go:1485			0x6de3c4		488bbc2470040000	MOVQ 0x470(SP), DI								
  tree.go:1485			0x6de3cc		e80fd3f0ff		CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID(SB)	
  tree.go:1486			0x6de3d1		4885c9			TESTQ CX, CX									
  tree.go:1486			0x6de3d4		0f85ff030000		JNE 0x6de7d9									
  tree.go:1489			0x6de3da		488d942418010000	LEAQ 0x118(SP), DX								
  tree.go:1489			0x6de3e2		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1489			0x6de3e6		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1489			0x6de3eb		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1489			0x6de3f0		4889842420010000	MOVQ AX, 0x120(SP)								
  tree.go:1489			0x6de3f8		e9cafdffff		JMP 0x6de1c7									
  tree.go:1479			0x6de3fd		488d842490010000	LEAQ 0x190(SP), AX								
  tree.go:1479			0x6de405		488b9c2460040000	MOVQ 0x460(SP), BX								
  tree.go:1479			0x6de40d		488b8c2468040000	MOVQ 0x468(SP), CX								
  tree.go:1479			0x6de415		488bbc2470040000	MOVQ 0x470(SP), DI								
  tree.go:1479			0x6de41d		0f1f00			NOPL 0(AX)									
  tree.go:1479			0x6de420		e8db00f1ff		CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildRef(SB)	
  tree.go:1479			0x6de425		88842440010000		MOVB AL, 0x140(SP)								
  tree.go:1479			0x6de42c		48899c2448010000	MOVQ BX, 0x148(SP)								
  tree.go:1479			0x6de434		898c2450010000		MOVL CX, 0x150(SP)								
  tree.go:1479			0x6de43b		4889bc2458010000	MOVQ DI, 0x158(SP)								
  tree.go:1479			0x6de443		89b42460010000		MOVL SI, 0x160(SP)								
  tree.go:1479			0x6de44a		664489842464010000	MOVW R8, 0x164(SP)								
  tree.go:1479			0x6de453		488d9424d8030000	LEAQ 0x3d8(SP), DX								
  tree.go:1479			0x6de45b		488db42440010000	LEAQ 0x140(SP), SI								
  tree.go:1479			0x6de463		440f1036		MOVUPS 0(SI), X14								
  tree.go:1479			0x6de467		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1479			0x6de46b		440f107610		MOVUPS 0x10(SI), X14								
  tree.go:1479			0x6de470		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1479			0x6de475		440f107618		MOVUPS 0x18(SI), X14								
  tree.go:1479			0x6de47a		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1479			0x6de47f		90			NOPL										
  tree.go:1480			0x6de480		4d85d2			TESTQ R10, R10									
  tree.go:1480			0x6de483		0f8586030000		JNE 0x6de80f									
  tree.go:1483			0x6de489		488d942418010000	LEAQ 0x118(SP), DX								
  tree.go:1483			0x6de491		440f1036		MOVUPS 0(SI), X14								
  tree.go:1483			0x6de495		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1483			0x6de499		440f107610		MOVUPS 0x10(SI), X14								
  tree.go:1483			0x6de49e		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1483			0x6de4a3		440f107618		MOVUPS 0x18(SI), X14								
  tree.go:1483			0x6de4a8		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1483			0x6de4ad		e915fdffff		JMP 0x6de1c7									
  tree.go:1491			0x6de4b2		6683f804		CMPW AX, $0x4									
  tree.go:1491			0x6de4b6		0f840f050000		JE 0x6de9cb									
  tree.go:1491			0x6de4bc		0f1f4000		NOPL 0(AX)									
  tree.go:1451			0x6de4c0		6683f80b		CMPW AX, $0xb									
  tree.go:1451			0x6de4c4		0f8557040000		JNE 0x6de921									
  tree.go:1452			0x6de4ca		488b942410010000	MOVQ 0x110(SP), DX								
  tree.go:1452			0x6de4d2		4885d2			TESTQ DX, DX									
  tree.go:1452			0x6de4d5		0f8508040000		JNE 0x6de8e3									
  node.go:209			0x6de4db		488b8c2498010000	MOVQ 0x198(SP), CX								
  node.go:209			0x6de4e3		488bbc24a0010000	MOVQ 0x1a0(SP), DI								
  node.go:209			0x6de4eb		488b9c2490010000	MOVQ 0x190(SP), BX								
  tree.go:1457			0x6de4f3		488d942468030000	LEAQ 0x368(SP), DX								
  tree.go:1457			0x6de4fb		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1457			0x6de4ff		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1457			0x6de504		440f117a20		MOVUPS X15, 0x20(DX)								
  tree.go:1457			0x6de509		440f117a30		MOVUPS X15, 0x30(DX)								
  tree.go:1457			0x6de50e		440f117a40		MOVUPS X15, 0x40(DX)								
  tree.go:1457			0x6de513		440f117a50		MOVUPS X15, 0x50(DX)								
  tree.go:1457			0x6de518		440f117a60		MOVUPS X15, 0x60(DX)								
  tree.go:1457			0x6de51d		440f113c24		MOVUPS X15, 0(SP)								
  tree.go:1457			0x6de522		48c744241000000000	MOVQ $0x0, 0x10(SP)								
  tree.go:1457			0x6de52b		488b842458040000	MOVQ 0x458(SP), AX								
  tree.go:1457			0x6de533		488bb42460040000	MOVQ 0x460(SP), SI								
  tree.go:1457			0x6de53b		4c8b842468040000	MOVQ 0x468(SP), R8								
  tree.go:1457			0x6de543		4c8b8c2470040000	MOVQ 0x470(SP), R9								
  tree.go:1457			0x6de54b		4531d2			XORL R10, R10									
  tree.go:1457			0x6de54e		4531db			XORL R11, R11									
  tree.go:1457			0x6de551		e8ea40ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).selectPrimaryOperand(SB)	
  tree.go:1457			0x6de556		88842468030000		MOVB AL, 0x368(SP)								
  tree.go:1457			0x6de55d		48899c2470030000	MOVQ BX, 0x370(SP)								
  tree.go:1457			0x6de565		898c2478030000		MOVL CX, 0x378(SP)								
  tree.go:1457			0x6de56c		4889bc2480030000	MOVQ DI, 0x380(SP)								
  tree.go:1457			0x6de574		89b42488030000		MOVL SI, 0x388(SP)								
  tree.go:1457			0x6de57b		66448984248c030000	MOVW R8, 0x38c(SP)								
  tree.go:1457			0x6de584		488d9424d8030000	LEAQ 0x3d8(SP), DX								
  tree.go:1457			0x6de58c		4c8da42468030000	LEAQ 0x368(SP), R12								
  tree.go:1457			0x6de594		450f103424		MOVUPS 0(R12), X14								
  tree.go:1457			0x6de599		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1457			0x6de59d		450f10742410		MOVUPS 0x10(R12), X14								
  tree.go:1457			0x6de5a3		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1457			0x6de5a8		450f10742418		MOVUPS 0x18(R12), X14								
  tree.go:1457			0x6de5ae		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1457			0x6de5b3		4c8da42468030000	LEAQ 0x368(SP), R12								
  tree.go:1457			0x6de5bb		4c8d6c2418		LEAQ 0x18(SP), R13								
  tree.go:1457			0x6de5c0		450f107500		MOVUPS 0(R13), X14								
  tree.go:1457			0x6de5c5		450f113424		MOVUPS X14, 0(R12)								
  tree.go:1457			0x6de5ca		450f107510		MOVUPS 0x10(R13), X14								
  tree.go:1457			0x6de5cf		450f11742410		MOVUPS X14, 0x10(R12)								
  tree.go:1457			0x6de5d5		450f107520		MOVUPS 0x20(R13), X14								
  tree.go:1457			0x6de5da		450f11742420		MOVUPS X14, 0x20(R12)								
  tree.go:1457			0x6de5e0		450f107530		MOVUPS 0x30(R13), X14								
  tree.go:1457			0x6de5e5		450f11742430		MOVUPS X14, 0x30(R12)								
  tree.go:1457			0x6de5eb		450f107540		MOVUPS 0x40(R13), X14								
  tree.go:1457			0x6de5f0		450f11742440		MOVUPS X14, 0x40(R12)								
  tree.go:1457			0x6de5f6		450f107550		MOVUPS 0x50(R13), X14								
  tree.go:1457			0x6de5fb		450f11742450		MOVUPS X14, 0x50(R12)								
  tree.go:1457			0x6de601		450f107560		MOVUPS 0x60(R13), X14								
  tree.go:1457			0x6de606		450f11742460		MOVUPS X14, 0x60(R12)								
  tree.go:1457			0x6de60c		4c8dac2468010000	LEAQ 0x168(SP), R13								
  tree.go:1457			0x6de614		440f1032		MOVUPS 0(DX), X14								
  tree.go:1457			0x6de618		450f117500		MOVUPS X14, 0(R13)								
  tree.go:1457			0x6de61d		440f107210		MOVUPS 0x10(DX), X14								
  tree.go:1457			0x6de622		450f117510		MOVUPS X14, 0x10(R13)								
  tree.go:1457			0x6de627		440f107218		MOVUPS 0x18(DX), X14								
  tree.go:1457			0x6de62c		450f117518		MOVUPS X14, 0x18(R13)								
  tree.go:1457			0x6de631		488d9424d8030000	LEAQ 0x3d8(SP), DX								
  tree.go:1457			0x6de639		450f103424		MOVUPS 0(R12), X14								
  tree.go:1457			0x6de63e		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1457			0x6de642		450f10742410		MOVUPS 0x10(R12), X14								
  tree.go:1457			0x6de648		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1457			0x6de64d		450f10742420		MOVUPS 0x20(R12), X14								
  tree.go:1457			0x6de653		440f117220		MOVUPS X14, 0x20(DX)								
  tree.go:1457			0x6de658		450f10742430		MOVUPS 0x30(R12), X14								
  tree.go:1457			0x6de65e		440f117230		MOVUPS X14, 0x30(DX)								
  tree.go:1457			0x6de663		450f10742440		MOVUPS 0x40(R12), X14								
  tree.go:1457			0x6de669		440f117240		MOVUPS X14, 0x40(DX)								
  tree.go:1457			0x6de66e		450f10742450		MOVUPS 0x50(R12), X14								
  tree.go:1457			0x6de674		440f117250		MOVUPS X14, 0x50(DX)								
  tree.go:1457			0x6de679		450f10742460		MOVUPS 0x60(R12), X14								
  tree.go:1457			0x6de67f		440f117260		MOVUPS X14, 0x60(DX)								
  tree.go:1457			0x6de684		4c8da42418010000	LEAQ 0x118(SP), R12								
  tree.go:1457			0x6de68c		450f107500		MOVUPS 0(R13), X14								
  tree.go:1457			0x6de691		450f113424		MOVUPS X14, 0(R12)								
  tree.go:1457			0x6de696		450f107510		MOVUPS 0x10(R13), X14								
  tree.go:1457			0x6de69b		450f11742410		MOVUPS X14, 0x10(R12)								
  tree.go:1457			0x6de6a1		450f107518		MOVUPS 0x18(R13), X14								
  tree.go:1457			0x6de6a6		450f11742418		MOVUPS X14, 0x18(R12)								
  tree.go:1458			0x6de6ac		4c8dac24e8020000	LEAQ 0x2e8(SP), R13								
  tree.go:1458			0x6de6b4		440f1032		MOVUPS 0(DX), X14								
  tree.go:1458			0x6de6b8		450f117500		MOVUPS X14, 0(R13)								
  tree.go:1458			0x6de6bd		440f107210		MOVUPS 0x10(DX), X14								
  tree.go:1458			0x6de6c2		450f117510		MOVUPS X14, 0x10(R13)								
  tree.go:1458			0x6de6c7		440f107220		MOVUPS 0x20(DX), X14								
  tree.go:1458			0x6de6cc		450f117520		MOVUPS X14, 0x20(R13)								
  tree.go:1458			0x6de6d1		440f107230		MOVUPS 0x30(DX), X14								
  tree.go:1458			0x6de6d6		450f117530		MOVUPS X14, 0x30(R13)								
  tree.go:1458			0x6de6db		440f107240		MOVUPS 0x40(DX), X14								
  tree.go:1458			0x6de6e0		450f117540		MOVUPS X14, 0x40(R13)								
  tree.go:1458			0x6de6e5		440f107250		MOVUPS 0x50(DX), X14								
  tree.go:1458			0x6de6ea		450f117550		MOVUPS X14, 0x50(R13)								
  tree.go:1458			0x6de6ef		440f107260		MOVUPS 0x60(DX), X14								
  tree.go:1458			0x6de6f4		450f117560		MOVUPS X14, 0x60(R13)								
  primary_directory_v1.go:43	0x6de6f9		80bc245003000002	CMPB 0x350(SP), $0x2								
  primary_directory_v1.go:43	0x6de701		7544			JNE 0x6de747									
  tree.go:1457			0x6de703		4c899424e0020000	MOVQ R10, 0x2e0(SP)								
  tree.go:1457			0x6de70b		4c898c2408010000	MOVQ R9, 0x108(SP)								
  primary_directory_v1.go:43	0x6de713		488d842400030000	LEAQ 0x300(SP), AX								
  primary_directory_v1.go:43	0x6de71b		488d1dfe198502		LEAQ runtime.zeroVal(SB), BX							
  primary_directory_v1.go:43	0x6de722		e8f9c5f1ff		CALL type:.eq.github.com/snissn/gomap/TreeDB/node.PrimaryOperand(SB)		
  primary_directory_v1.go:43	0x6de727		84c0			TESTL AL, AL									
  tree.go:1458			0x6de729		0f8576010000		JNE 0x6de8a5									
  tree.go:1461			0x6de72f		4c8b8c2408010000	MOVQ 0x108(SP), R9								
  tree.go:1462			0x6de737		4c8b9424e0020000	MOVQ 0x2e0(SP), R10								
  tree.go:1441			0x6de73f		4c8da42418010000	LEAQ 0x118(SP), R12								
  tree.go:1461			0x6de747		4d85c9			TESTQ R9, R9									
  tree.go:1461			0x6de74a		0f851f010000		JNE 0x6de86f									
  tree.go:1441			0x6de750		488d942418010000	LEAQ 0x118(SP), DX								
  tree.go:1464			0x6de758		e96afaffff		JMP 0x6de1c7									
  tree.go:1474			0x6de75d		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1474			0x6de765		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1474			0x6de769		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1474			0x6de76e		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1474			0x6de773		4c8b1576267302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), R10		
  tree.go:1474			0x6de77a		4c8b1d77267302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R11		
  tree.go:1474			0x6de781		31c0			XORL AX, AX									
  tree.go:1474			0x6de783		31db			XORL BX, BX									
  tree.go:1474			0x6de785		31c9			XORL CX, CX									
  tree.go:1474			0x6de787		4889df			MOVQ BX, DI									
  tree.go:1474			0x6de78a		89ce			MOVL CX, SI									
  tree.go:1474			0x6de78c		4531c0			XORL R8, R8									
  tree.go:1474			0x6de78f		4531c9			XORL R9, R9									
  tree.go:1474			0x6de792		4881c448040000		ADDQ $0x448, SP									
  tree.go:1474			0x6de799		5d			POPQ BP										
  tree.go:1474			0x6de79a		c3			RET										
  tree.go:1471			0x6de79b		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1471			0x6de7a3		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1471			0x6de7a7		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1471			0x6de7ac		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1471			0x6de7b1		4c8b1538267302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), R10		
  tree.go:1471			0x6de7b8		4c8b1d39267302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R11		
  tree.go:1471			0x6de7bf		31c0			XORL AX, AX									
  tree.go:1471			0x6de7c1		31db			XORL BX, BX									
  tree.go:1471			0x6de7c3		31c9			XORL CX, CX									
  tree.go:1471			0x6de7c5		4889df			MOVQ BX, DI									
  tree.go:1471			0x6de7c8		89ce			MOVL CX, SI									
  tree.go:1471			0x6de7ca		4531c0			XORL R8, R8									
  tree.go:1471			0x6de7cd		4531c9			XORL R9, R9									
  tree.go:1471			0x6de7d0		4881c448040000		ADDQ $0x448, SP									
  tree.go:1471			0x6de7d7		5d			POPQ BP										
  tree.go:1471			0x6de7d8		c3			RET										
  tree.go:1487			0x6de7d9		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1487			0x6de7e1		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1487			0x6de7e5		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1487			0x6de7ea		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1487			0x6de7ef		31c0			XORL AX, AX									
  tree.go:1487			0x6de7f1		31db			XORL BX, BX									
  tree.go:1487			0x6de7f3		31f6			XORL SI, SI									
  tree.go:1487			0x6de7f5		4531c0			XORL R8, R8									
  tree.go:1487			0x6de7f8		4531c9			XORL R9, R9									
  tree.go:1487			0x6de7fb		4989ca			MOVQ CX, R10									
  tree.go:1487			0x6de7fe		4989fb			MOVQ DI, R11									
  tree.go:1487			0x6de801		89f1			MOVL SI, CX									
  tree.go:1487			0x6de803		4889df			MOVQ BX, DI									
  tree.go:1487			0x6de806		4881c448040000		ADDQ $0x448, SP									
  tree.go:1487			0x6de80d		5d			POPQ BP										
  tree.go:1487			0x6de80e		c3			RET										
  tree.go:1481			0x6de80f		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1481			0x6de817		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1481			0x6de81b		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1481			0x6de820		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1481			0x6de825		31c0			XORL AX, AX									
  tree.go:1481			0x6de827		31db			XORL BX, BX									
  tree.go:1481			0x6de829		31c9			XORL CX, CX									
  tree.go:1481			0x6de82b		4889df			MOVQ BX, DI									
  tree.go:1481			0x6de82e		89ce			MOVL CX, SI									
  tree.go:1481			0x6de830		4531c0			XORL R8, R8									
  tree.go:1481			0x6de833		4531c9			XORL R9, R9									
  tree.go:1481			0x6de836		4881c448040000		ADDQ $0x448, SP									
  tree.go:1481			0x6de83d		5d			POPQ BP										
  tree.go:1481			0x6de83e		c3			RET										
  tree.go:1468			0x6de83f		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1468			0x6de847		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1468			0x6de84b		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1468			0x6de850		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1468			0x6de855		31c0			XORL AX, AX									
  tree.go:1468			0x6de857		31db			XORL BX, BX									
  tree.go:1468			0x6de859		31c9			XORL CX, CX									
  tree.go:1468			0x6de85b		4889df			MOVQ BX, DI									
  tree.go:1468			0x6de85e		89ce			MOVL CX, SI									
  tree.go:1468			0x6de860		4531c0			XORL R8, R8									
  tree.go:1468			0x6de863		4531c9			XORL R9, R9									
  tree.go:1468			0x6de866		4881c448040000		ADDQ $0x448, SP									
  tree.go:1468			0x6de86d		5d			POPQ BP										
  tree.go:1468			0x6de86e		c3			RET										
  tree.go:1462			0x6de86f		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1462			0x6de877		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1462			0x6de87b		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1462			0x6de880		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1462			0x6de885		31c0			XORL AX, AX									
  tree.go:1462			0x6de887		31db			XORL BX, BX									
  tree.go:1462			0x6de889		31c9			XORL CX, CX									
  tree.go:1462			0x6de88b		4889df			MOVQ BX, DI									
  tree.go:1462			0x6de88e		89ce			MOVL CX, SI									
  tree.go:1462			0x6de890		4531c0			XORL R8, R8									
  tree.go:1462			0x6de893		4d89d3			MOVQ R10, R11									
  tree.go:1462			0x6de896		4d89ca			MOVQ R9, R10									
  tree.go:1462			0x6de899		4531c9			XORL R9, R9									
  tree.go:1462			0x6de89c		4881c448040000		ADDQ $0x448, SP									
  tree.go:1462			0x6de8a3		5d			POPQ BP										
  tree.go:1462			0x6de8a4		c3			RET										
  tree.go:1459			0x6de8a5		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1459			0x6de8ad		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1459			0x6de8b1		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1459			0x6de8b6		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1459			0x6de8bb		4c8b152e257302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), R10		
  tree.go:1459			0x6de8c2		4c8b1d2f257302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R11		
  tree.go:1459			0x6de8c9		31c0			XORL AX, AX									
  tree.go:1459			0x6de8cb		31db			XORL BX, BX									
  tree.go:1459			0x6de8cd		31c9			XORL CX, CX									
  tree.go:1459			0x6de8cf		4889df			MOVQ BX, DI									
  tree.go:1459			0x6de8d2		89ce			MOVL CX, SI									
  tree.go:1459			0x6de8d4		4531c0			XORL R8, R8									
  tree.go:1459			0x6de8d7		4531c9			XORL R9, R9									
  tree.go:1459			0x6de8da		4881c448040000		ADDQ $0x448, SP									
  tree.go:1459			0x6de8e1		5d			POPQ BP										
  tree.go:1459			0x6de8e2		c3			RET										
  tree.go:1453			0x6de8e3		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1453			0x6de8eb		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1453			0x6de8ef		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1453			0x6de8f4		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1453			0x6de8f9		4c8b15d0297302		MOVQ github.com/snissn/gomap/TreeDB/node.ErrPrimaryDirectory(SB), R10		
  tree.go:1453			0x6de900		4c8b1dd1297302		MOVQ github.com/snissn/gomap/TreeDB/node.ErrPrimaryDirectory+8(SB), R11		
  tree.go:1453			0x6de907		31c0			XORL AX, AX									
  tree.go:1453			0x6de909		31db			XORL BX, BX									
  tree.go:1453			0x6de90b		31c9			XORL CX, CX									
  tree.go:1453			0x6de90d		4889df			MOVQ BX, DI									
  tree.go:1453			0x6de910		89ce			MOVL CX, SI									
  tree.go:1453			0x6de912		4531c0			XORL R8, R8									
  tree.go:1453			0x6de915		4531c9			XORL R9, R9									
  tree.go:1453			0x6de918		4881c448040000		ADDQ $0x448, SP									
  tree.go:1453			0x6de91f		5d			POPQ BP										
  tree.go:1453			0x6de920		c3			RET										
  tree.go:1494			0x6de921		440f11bc2458030000	MOVUPS X15, 0x358(SP)								
  tree.go:1494			0x6de92a		e8d123d4ff		CALL runtime.convT16(SB)							
  tree.go:1494			0x6de92f		488d0d6a054801		LEAQ 0x148056a(IP), CX								
  tree.go:1494			0x6de936		48898c2458030000	MOVQ CX, 0x358(SP)								
  tree.go:1494			0x6de93e		4889842460030000	MOVQ AX, 0x360(SP)								
  errors.go:26			0x6de946		488d05d6c86901		LEAQ 0x169c8d6(IP), AX								
  errors.go:26			0x6de94d		bb14000000		MOVL $0x14, BX									
  errors.go:26			0x6de952		488d8c2458030000	LEAQ 0x358(SP), CX								
  errors.go:26			0x6de95a		bf01000000		MOVL $0x1, DI									
  errors.go:26			0x6de95f		4889fe			MOVQ DI, SI									
  errors.go:26			0x6de962		e8f945e2ff		CALL fmt.errorf(SB)								
  errors.go:26			0x6de967		4885c0			TESTQ AX, AX									
  errors.go:26			0x6de96a		7529			JNE 0x6de995									
  errors.go:31			0x6de96c		90			NOPL										
  errors.go:65			0x6de96d		488d056c6e5001		LEAQ 0x1506e6c(IP), AX								
  errors.go:65			0x6de974		e82761d4ff		CALL runtime.newobject(SB)							
  errors.go:65			0x6de979		48c7400814000000	MOVQ $0x14, 0x8(AX)								
  errors.go:65			0x6de981		488d0d9bc86901		LEAQ 0x169c89b(IP), CX								
  errors.go:65			0x6de988		488908			MOVQ CX, 0(AX)									
  tree.go:1494			0x6de98b		4889c3			MOVQ AX, BX									
  tree.go:1494			0x6de98e		488d052bf47d01		LEAQ go:itab.*errors.errorString,error(SB), AX					
  tree.go:1494			0x6de995		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1494			0x6de99d		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1494			0x6de9a1		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1494			0x6de9a6		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1494			0x6de9ab		31c9			XORL CX, CX									
  tree.go:1494			0x6de9ad		31ff			XORL DI, DI									
  tree.go:1494			0x6de9af		89ce			MOVL CX, SI									
  tree.go:1494			0x6de9b1		4531c0			XORL R8, R8									
  tree.go:1494			0x6de9b4		4531c9			XORL R9, R9									
  tree.go:1494			0x6de9b7		4989c2			MOVQ AX, R10									
  tree.go:1494			0x6de9ba		4989db			MOVQ BX, R11									
  tree.go:1494			0x6de9bd		31c0			XORL AX, AX									
  tree.go:1494			0x6de9bf		4889fb			MOVQ DI, BX									
  tree.go:1494			0x6de9c2		4881c448040000		ADDQ $0x448, SP									
  tree.go:1494			0x6de9c9		5d			POPQ BP										
  tree.go:1494			0x6de9ca		c3			RET										
  tree.go:1492			0x6de9cb		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1492			0x6de9d3		4c8da42418010000	LEAQ 0x118(SP), R12								
  tree.go:1492			0x6de9db		450f103424		MOVUPS 0(R12), X14								
  tree.go:1492			0x6de9e0		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1492			0x6de9e4		450f10742410		MOVUPS 0x10(R12), X14								
  tree.go:1492			0x6de9ea		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1492			0x6de9ef		450f10742418		MOVUPS 0x18(R12), X14								
  tree.go:1492			0x6de9f5		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1492			0x6de9fa		0fb68424d0000000	MOVZX 0xd0(SP), AX								
  tree.go:1492			0x6dea02		488b9c24d8000000	MOVQ 0xd8(SP), BX								
  tree.go:1492			0x6dea0a		8b8c24e0000000		MOVL 0xe0(SP), CX								
  tree.go:1492			0x6dea11		488bbc24e8000000	MOVQ 0xe8(SP), DI								
  tree.go:1492			0x6dea19		8bb424f0000000		MOVL 0xf0(SP), SI								
  tree.go:1492			0x6dea20		440fb78424f4000000	MOVZX 0xf4(SP), R8								
  tree.go:1492			0x6dea29		4531c9			XORL R9, R9									
  tree.go:1492			0x6dea2c		4531d2			XORL R10, R10									
  tree.go:1492			0x6dea2f		4531db			XORL R11, R11									
  tree.go:1492			0x6dea32		4881c448040000		ADDQ $0x448, SP									
  tree.go:1492			0x6dea39		5d			POPQ BP										
  tree.go:1492			0x6dea3a		c3			RET										
  tree.go:1448			0x6dea3b		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1448			0x6dea43		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1448			0x6dea47		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1448			0x6dea4c		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1448			0x6dea51		31c9			XORL CX, CX									
  tree.go:1448			0x6dea53		31ff			XORL DI, DI									
  tree.go:1448			0x6dea55		89ce			MOVL CX, SI									
  tree.go:1448			0x6dea57		4531c0			XORL R8, R8									
  tree.go:1448			0x6dea5a		4531c9			XORL R9, R9									
  tree.go:1448			0x6dea5d		4989c2			MOVQ AX, R10									
  tree.go:1448			0x6dea60		4989db			MOVQ BX, R11									
  tree.go:1448			0x6dea63		31c0			XORL AX, AX									
  tree.go:1448			0x6dea65		4889fb			MOVQ DI, BX									
  tree.go:1448			0x6dea68		4881c448040000		ADDQ $0x448, SP									
  tree.go:1448			0x6dea6f		5d			POPQ BP										
  tree.go:1448			0x6dea70		c3			RET										
  tree.go:1444			0x6dea71		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1444			0x6dea79		450f103424		MOVUPS 0(R12), X14								
  tree.go:1444			0x6dea7e		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1444			0x6dea82		450f10742410		MOVUPS 0x10(R12), X14								
  tree.go:1444			0x6dea88		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1444			0x6dea8d		450f10742418		MOVUPS 0x18(R12), X14								
  tree.go:1444			0x6dea93		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1444			0x6dea98		0fb68424d0000000	MOVZX 0xd0(SP), AX								
  tree.go:1444			0x6deaa0		488b9c24d8000000	MOVQ 0xd8(SP), BX								
  tree.go:1444			0x6deaa8		8b8c24e0000000		MOVL 0xe0(SP), CX								
  tree.go:1444			0x6deaaf		488bbc24e8000000	MOVQ 0xe8(SP), DI								
  tree.go:1444			0x6deab7		8bb424f0000000		MOVL 0xf0(SP), SI								
  tree.go:1444			0x6deabe		440fb78424f4000000	MOVZX 0xf4(SP), R8								
  tree.go:1444			0x6deac7		41b901000000		MOVL $0x1, R9									
  tree.go:1444			0x6deacd		4531d2			XORL R10, R10									
  tree.go:1444			0x6dead0		4531db			XORL R11, R11									
  tree.go:1444			0x6dead3		4881c448040000		ADDQ $0x448, SP									
  tree.go:1444			0x6deada		5d			POPQ BP										
  tree.go:1444			0x6deadb		c3			RET										
  errors.go:65			0x6deadc		488d05fd6c5001		LEAQ 0x1506cfd(IP), AX								
  errors.go:65			0x6deae3		e8b85fd4ff		CALL runtime.newobject(SB)							
  errors.go:65			0x6deae8		48c740080d000000	MOVQ $0xd, 0x8(AX)								
  errors.go:65			0x6deaf0		488d0d53e66801		LEAQ 0x168e653(IP), CX								
  errors.go:65			0x6deaf7		488908			MOVQ CX, 0(AX)									
  tree.go:1497			0x6deafa		488d8c24d0000000	LEAQ 0xd0(SP), CX								
  tree.go:1497			0x6deb02		440f1139		MOVUPS X15, 0(CX)								
  tree.go:1497			0x6deb06		440f117910		MOVUPS X15, 0x10(CX)								
  tree.go:1497			0x6deb0b		440f117918		MOVUPS X15, 0x18(CX)								
  tree.go:1497			0x6deb10		31db			XORL BX, BX									
  tree.go:1497			0x6deb12		31c9			XORL CX, CX									
  tree.go:1497			0x6deb14		4889df			MOVQ BX, DI									
  tree.go:1497			0x6deb17		89ce			MOVL CX, SI									
  tree.go:1497			0x6deb19		4531c0			XORL R8, R8									
  tree.go:1497			0x6deb1c		4531c9			XORL R9, R9									
  tree.go:1497			0x6deb1f		4c8d159af27d01		LEAQ go:itab.*errors.errorString,error(SB), R10					
  tree.go:1497			0x6deb26		4989c3			MOVQ AX, R11									
  tree.go:1497			0x6deb29		31c0			XORL AX, AX									
  tree.go:1497			0x6deb2b		4881c448040000		ADDQ $0x448, SP									
  tree.go:1497			0x6deb32		5d			POPQ BP										
  tree.go:1497			0x6deb33		c3			RET										
  node.go:56			0x6deb34		e8c75adbff		CALL runtime.panicBounds(SB)							
  node.go:56			0x6deb39		e8c25adbff		CALL runtime.panicBounds(SB)							
  node.go:56			0x6deb3e		90			NOPL										
  tree.go:1434			0x6deb3f		4889442408		MOVQ AX, 0x8(SP)								
  tree.go:1434			0x6deb44		48895c2410		MOVQ BX, 0x10(SP)								
  tree.go:1434			0x6deb49		48894c2418		MOVQ CX, 0x18(SP)								
  tree.go:1434			0x6deb4e		48897c2420		MOVQ DI, 0x20(SP)								
  tree.go:1434			0x6deb53		4088742428		MOVB SI, 0x28(SP)								
  tree.go:1434			0x6deb58		e8033cdbff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1434			0x6deb5d		488b442408		MOVQ 0x8(SP), AX								
  tree.go:1434			0x6deb62		488b5c2410		MOVQ 0x10(SP), BX								
  tree.go:1434			0x6deb67		488b4c2418		MOVQ 0x18(SP), CX								
  tree.go:1434			0x6deb6c		488b7c2420		MOVQ 0x20(SP), DI								
  tree.go:1434			0x6deb71		0fb6742428		MOVZX 0x28(SP), SI								
  tree.go:1434			0x6deb76		e905f5ffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).findLeafRefForGetMany(SB)	

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:62	0x92bd60		4c8d6424d8		LEAQ -0x28(SP), R12											
  registry.go:62	0x92bd65		4d3b6610		CMPQ R12, 0x10(R14)											
  registry.go:62	0x92bd69		0f86f7020000		JBE 0x92c066												
  registry.go:62	0x92bd6f		55			PUSHQ BP												
  registry.go:62	0x92bd70		4889e5			MOVQ SP, BP												
  registry.go:62	0x92bd73		4881eca0000000		SUBQ $0xa0, SP												
  registry.go:62	0x92bd7a		66440fd6bc2498000000	MOVQ X15, 0x98(SP)											
  registry.go:62	0x92bd84		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:62	0x92bd89		48c744245000000000	MOVQ $0x0, 0x50(SP)											
  registry.go:62	0x92bd92		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  registry.go:62	0x92bd9b		0f1f440000		NOPL 0(AX)(AX*1)											
  registry.go:63	0x92bda0		4885c9			TESTQ CX, CX												
  registry.go:63	0x92bda3		7d13			JGE 0x92bdb8												
  type.go:195		0x92bda5		ba01000000		MOVL $0x1, DX												
  type.go:195		0x92bdaa		f0480fc19048040000	LOCK XADDQ DX, 0x448(AX)										
  registry.go:64	0x92bdb3		83e20f			ANDL $0xf, DX												
  registry.go:64	0x92bdb6		eb06			JMP 0x92bdbe												
  registry.go:66	0x92bdb8		83e10f			ANDL $0xf, CX												
  registry.go:75	0x92bdbb		4889ca			MOVQ CX, DX												
  registry.go:63	0x92bdbe		48898424b0000000	MOVQ AX, 0xb0(SP)											
  registry.go:63	0x92bdc6		48899c24b8000000	MOVQ BX, 0xb8(SP)											
  registry.go:75	0x92bdce		4889942480000000	MOVQ DX, 0x80(SP)											
  registry.go:75	0x92bdd6		4889d1			MOVQ DX, CX												
  registry.go:75	0x92bdd9		e8a2090000		CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryJoinFast(SB)				
  registry.go:75	0x92bdde		6690			NOPW													
  registry.go:75	0x92bde0		4885c0			TESTQ AX, AX												
  registry.go:75	0x92bde3		7560			JNE 0x92be45												
  registry.go:79	0x92bde5		90			NOPL													
  mutex.go:46		0x92bde6		90			NOPL													
  mutex.go:63		0x92bde7		31c0			XORL AX, AX												
  mutex.go:63		0x92bde9		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  mutex.go:63		0x92bdf1		41b901000000		MOVL $0x1, R9												
  mutex.go:63		0x92bdf7		f0450fb108		LOCK CMPXCHGL R9, 0(R8)											
  mutex.go:63		0x92bdfc		410f94c1		SETE R9													
  mutex.go:63		0x92be00		4584c9			TESTL R9, R9												
  mutex.go:63		0x92be03		7510			JNE 0x92be15												
  mutex.go:70		0x92be05		4c89c0			MOVQ R8, AX												
  mutex.go:70		0x92be08		e8d304b7ff		CALL internal/sync.(*Mutex).lockSlow(SB)								
  registry.go:80	0x92be0d		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  registry.go:80	0x92be15		4c8d0d84020000		LEAQ github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint.deferwrap1(SB), R9	
  registry.go:80	0x92be1c		4c898c2488000000	MOVQ R9, 0x88(SP)											
  registry.go:80	0x92be24		4c89842490000000	MOVQ R8, 0x90(SP)											
  registry.go:80	0x92be2c		4c8d8c2488000000	LEAQ 0x88(SP), R9											
  registry.go:80	0x92be34		4c898c2498000000	MOVQ R9, 0x98(SP)											
  registry.go:80	0x92be3c		c644244701		MOVB $0x1, 0x47(SP)											
  registry.go:80	0x92be41		31c0			XORL AX, AX												
  registry.go:82	0x92be43		eb2c			JMP 0x92be71												
  registry.go:76	0x92be45		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:76	0x92be4a		488b9c2480000000	MOVQ 0x80(SP), BX											
  registry.go:76	0x92be52		48895c2448		MOVQ BX, 0x48(SP)											
  registry.go:76	0x92be57		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:76	0x92be5e		5d			POPQ BP													
  registry.go:76	0x92be5f		90			NOPL													
  registry.go:76	0x92be60		c3			RET													
  registry.go:82	0x92be61		488b442470		MOVQ 0x70(SP), AX											
  registry.go:82	0x92be66		48ffc0			INCQ AX													
  registry.go:84	0x92be69		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  registry.go:82	0x92be71		4883f810		CMPQ AX, $0x10												
  registry.go:82	0x92be75		7d67			JGE 0x92bede												
  registry.go:82	0x92be77		4889442470		MOVQ AX, 0x70(SP)											
  registry.go:83	0x92be7c		488b942480000000	MOVQ 0x80(SP), DX											
  registry.go:83	0x92be84		488d0c10		LEAQ 0(AX)(DX*1), CX											
  registry.go:83	0x92be88		83e10f			ANDL $0xf, CX												
  registry.go:83	0x92be8b		48894c2460		MOVQ CX, 0x60(SP)											
  registry.go:84	0x92be90		4c89c0			MOVQ R8, AX												
  registry.go:84	0x92be93		488b9c24b8000000	MOVQ 0xb8(SP), BX											
  registry.go:84	0x92be9b		0f1f440000		NOPL 0(AX)(AX*1)											
  registry.go:84	0x92bea0		e8db080000		CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryJoinFast(SB)				
  registry.go:84	0x92bea5		4885c0			TESTQ AX, AX												
  registry.go:84	0x92bea8		74b7			JE 0x92be61												
  registry.go:85	0x92beaa		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:85	0x92beaf		488b442460		MOVQ 0x60(SP), AX											
  registry.go:85	0x92beb4		4889442448		MOVQ AX, 0x48(SP)											
  registry.go:85	0x92beb9		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:85	0x92bebe		488b942498000000	MOVQ 0x98(SP), DX											
  registry.go:85	0x92bec6		488b02			MOVQ 0(DX), AX												
  registry.go:85	0x92bec9		ffd0			CALL AX													
  registry.go:85	0x92becb		488b442450		MOVQ 0x50(SP), AX											
  registry.go:85	0x92bed0		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:85	0x92bed5		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:85	0x92bedc		5d			POPQ BP													
  registry.go:85	0x92bedd		c3			RET													
  registry.go:85	0x92bede		31c0			XORL AX, AX												
  registry.go:82	0x92bee0		eb10			JMP 0x92bef2												
  registry.go:88	0x92bee2		488b442468		MOVQ 0x68(SP), AX											
  registry.go:88	0x92bee7		48ffc0			INCQ AX													
  registry.go:90	0x92beea		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  registry.go:88	0x92bef2		4883f810		CMPQ AX, $0x10												
  registry.go:88	0x92bef6		7d66			JGE 0x92bf5e												
  registry.go:88	0x92bef8		4889442468		MOVQ AX, 0x68(SP)											
  registry.go:89	0x92befd		488b942480000000	MOVQ 0x80(SP), DX											
  registry.go:89	0x92bf05		488d0c10		LEAQ 0(AX)(DX*1), CX											
  registry.go:89	0x92bf09		83e10f			ANDL $0xf, CX												
  registry.go:89	0x92bf0c		48894c2458		MOVQ CX, 0x58(SP)											
  registry.go:90	0x92bf11		4c89c0			MOVQ R8, AX												
  registry.go:90	0x92bf14		488b9c24b8000000	MOVQ 0xb8(SP), BX											
  registry.go:90	0x92bf1c		0f1f4000		NOPL 0(AX)												
  registry.go:90	0x92bf20		e8fb080000		CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryClaimFast(SB)			
  registry.go:90	0x92bf25		4885c0			TESTQ AX, AX												
  registry.go:90	0x92bf28		74b8			JE 0x92bee2												
  registry.go:91	0x92bf2a		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:91	0x92bf2f		488b442458		MOVQ 0x58(SP), AX											
  registry.go:91	0x92bf34		4889442448		MOVQ AX, 0x48(SP)											
  registry.go:91	0x92bf39		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:91	0x92bf3e		488b942498000000	MOVQ 0x98(SP), DX											
  registry.go:91	0x92bf46		488b02			MOVQ 0(DX), AX												
  registry.go:91	0x92bf49		ffd0			CALL AX													
  registry.go:91	0x92bf4b		488b442450		MOVQ 0x50(SP), AX											
  registry.go:91	0x92bf50		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:91	0x92bf55		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:91	0x92bf5c		5d			POPQ BP													
  registry.go:91	0x92bf5d		c3			RET													
  registry.go:96	0x92bf5e		4d8b4828		MOVQ 0x28(R8), R9											
  registry.go:96	0x92bf62		4d85c9			TESTQ R9, R9												
  registry.go:96	0x92bf65		7416			JE 0x92bf7d												
  registry.go:96	0x92bf67		498b4020		MOVQ 0x20(R8), AX											
  registry.go:97	0x92bf6b		498d49ff		LEAQ -0x1(R9), CX											
  registry.go:97	0x92bf6f		4a8b44c8f8		MOVQ -0x8(AX)(R9*8), AX											
  registry.go:98	0x92bf74		49894828		MOVQ CX, 0x28(R8)											
  registry.go:103	0x92bf78		4889c3			MOVQ AX, BX												
  registry.go:98	0x92bf7b		eb71			JMP 0x92bfee												
  registry.go:100	0x92bf7d		498b5810		MOVQ 0x10(R8), BX											
  registry.go:100	0x92bf81		498b4818		MOVQ 0x18(R8), CX											
  registry.go:101	0x92bf85		4c8d4b01		LEAQ 0x1(BX), R9											
  registry.go:100	0x92bf89		498b4008		MOVQ 0x8(R8), AX											
  registry.go:101	0x92bf8d		4c39c9			CMPQ CX, R9												
  registry.go:101	0x92bf90		734f			JAE 0x92bfe1												
  registry.go:100	0x92bf92		48895c2478		MOVQ BX, 0x78(SP)											
  registry.go:101	0x92bf97		4c89cb			MOVQ R9, BX												
  registry.go:101	0x92bf9a		bf01000000		MOVL $0x1, DI												
  registry.go:101	0x92bf9f		488d35fa222301		LEAQ 0x12322fa(IP), SI											
  registry.go:101	0x92bfa6		e8d52db6ff		CALL runtime.growslice(SB)										
  registry.go:101	0x92bfab		488b9424b0000000	MOVQ 0xb0(SP), DX											
  registry.go:101	0x92bfb3		48894a18		MOVQ CX, 0x18(DX)											
  registry.go:101	0x92bfb7		833d6215600200		CMPL runtime.writeBarrier(SB), $0x0									
  registry.go:101	0x92bfbe		6690			NOPW													
  registry.go:101	0x92bfc0		7410			JE 0x92bfd2												
  registry.go:101	0x92bfc2		488b4a08		MOVQ 0x8(DX), CX											
  registry.go:101	0x92bfc6		e89582b6ff		CALL runtime.gcWriteBarrier2(SB)									
  registry.go:101	0x92bfcb		498903			MOVQ AX, 0(R11)												
  registry.go:101	0x92bfce		49894b08		MOVQ CX, 0x8(R11)											
  registry.go:101	0x92bfd2		48894208		MOVQ AX, 0x8(DX)											
  registry.go:101	0x92bfd6		4989d0			MOVQ DX, R8												
  registry.go:101	0x92bfd9		4989d9			MOVQ BX, R9												
  registry.go:103	0x92bfdc		488b5c2478		MOVQ 0x78(SP), BX											
  registry.go:101	0x92bfe1		4d894810		MOVQ R9, 0x10(R8)											
  registry.go:101	0x92bfe5		4ac744c8f8ffffffff	MOVQ $-0x1, -0x8(AX)(R9*8)										
  registry.go:103	0x92bfee		498b4010		MOVQ 0x10(R8), AX											
  registry.go:103	0x92bff2		4839c3			CMPQ BX, AX												
  registry.go:103	0x92bff5		7351			JAE 0x92c048												
  registry.go:103	0x92bff7		498b4008		MOVQ 0x8(R8), AX											
  registry.go:103	0x92bffb		488b8c24b8000000	MOVQ 0xb8(SP), CX											
  registry.go:103	0x92c003		48890cd8		MOVQ CX, 0(AX)(BX*8)											
  registry.go:104	0x92c007		49394838		CMPQ 0x38(R8), CX											
  registry.go:104	0x92c00b		7604			JBE 0x92c011												
  registry.go:105	0x92c00d		49894838		MOVQ CX, 0x38(R8)											
  registry.go:107	0x92c011		488d4301		LEAQ 0x1(BX), AX											
  registry.go:107	0x92c015		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:107	0x92c01a		48c7442448ffffffff	MOVQ $-0x1, 0x48(SP)											
  registry.go:107	0x92c023		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:107	0x92c028		488b942498000000	MOVQ 0x98(SP), DX											
  registry.go:107	0x92c030		488b02			MOVQ 0(DX), AX												
  registry.go:107	0x92c033		ffd0			CALL AX													
  registry.go:107	0x92c035		488b442450		MOVQ 0x50(SP), AX											
  registry.go:107	0x92c03a		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:107	0x92c03f		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:107	0x92c046		5d			POPQ BP													
  registry.go:107	0x92c047		c3			RET													
  registry.go:103	0x92c048		e8b385b6ff		CALL runtime.panicBounds(SB)										
  registry.go:103	0x92c04d		90			NOPL													
  registry.go:103	0x92c04e		e8cd4fb2ff		CALL runtime.deferreturn(SB)										
  registry.go:103	0x92c053		488b442450		MOVQ 0x50(SP), AX											
  registry.go:103	0x92c058		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:103	0x92c05d		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:103	0x92c064		5d			POPQ BP													
  registry.go:103	0x92c065		c3			RET													
  registry.go:62	0x92c066		4889442408		MOVQ AX, 0x8(SP)											
  registry.go:62	0x92c06b		48895c2410		MOVQ BX, 0x10(SP)											
  registry.go:62	0x92c070		48894c2418		MOVQ CX, 0x18(SP)											
  registry.go:62	0x92c075		e8e666b6ff		CALL runtime.morestack_noctxt.abi0(SB)									
  registry.go:62	0x92c07a		488b442408		MOVQ 0x8(SP), AX											
  registry.go:62	0x92c07f		488b5c2410		MOVQ 0x10(SP), BX											
  registry.go:62	0x92c084		488b4c2418		MOVQ 0x18(SP), CX											
  registry.go:62	0x92c089		e9d2fcffff		JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint(SB)			

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint.deferwrap1(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:80	0x92c0a0		493b6610		CMPQ SP, 0x10(R14)										
  registry.go:80	0x92c0a4		7629			JBE 0x92c0cf											
  registry.go:80	0x92c0a6		55			PUSHQ BP											
  registry.go:80	0x92c0a7		4889e5			MOVQ SP, BP											
  registry.go:80	0x92c0aa		4883ec10		SUBQ $0x10, SP											
  registry.go:80	0x92c0ae		488b4208		MOVQ 0x8(DX), AX										
  mutex.go:65		0x92c0b2		90			NOPL												
  mutex.go:194		0x92c0b3		bbffffffff		MOVL $-0x1, BX											
  mutex.go:194		0x92c0b8		f00fc118		LOCK XADDL BX, 0(AX)										
  mutex.go:194		0x92c0bc		0f1f4000		NOPL 0(AX)											
  mutex.go:194		0x92c0c0		ffcb			DECL BX												
  mutex.go:195		0x92c0c2		7405			JE 0x92c0c9											
  mutex.go:198		0x92c0c4		e8f704b7ff		CALL internal/sync.(*Mutex).unlockSlow(SB)							
  registry.go:80	0x92c0c9		4883c410		ADDQ $0x10, SP											
  registry.go:80	0x92c0cd		5d			POPQ BP												
  registry.go:80	0x92c0ce		c3			RET												
  registry.go:80	0x92c0cf		e8ec65b6ff		CALL runtime.morestack.abi0(SB)									
  registry.go:80	0x92c0d4		ebca			JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:140	0x92c360		493b6610		CMPQ SP, 0x10(R14)										
  registry.go:140	0x92c364		0f86cd010000		JBE 0x92c537											
  registry.go:140	0x92c36a		55			PUSHQ BP											
  registry.go:140	0x92c36b		4889e5			MOVQ SP, BP											
  registry.go:140	0x92c36e		4883ec70		SUBQ $0x70, SP											
  registry.go:140	0x92c372		66440fd67c2468		MOVQ X15, 0x68(SP)										
  registry.go:140	0x92c379		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:140	0x92c37e		6690			NOPW												
  registry.go:141	0x92c380		4885db			TESTQ BX, BX											
  registry.go:141	0x92c383		7d42			JGE 0x92c3c7											
  registry.go:142	0x92c385		488d4b01		LEAQ 0x1(BX), CX										
  registry.go:142	0x92c389		48f7d9			NEGQ CX												
  registry.go:143	0x92c38c		4883f910		CMPQ CX, $0x10											
  registry.go:143	0x92c390		7d2f			JGE 0x92c3c1											
  registry.go:146	0x92c392		8400			TESTB AL, 0(AX)											
  registry.go:146	0x92c394		48c1e106		SHLQ $0x6, CX											
  type.go:94		0x92c398		488d0401		LEAQ 0(CX)(AX*1), AX										
  type.go:94		0x92c39c		488d4050		LEAQ 0x50(AX), AX										
  type.go:94		0x92c3a0		b9ffffffff		MOVL $-0x1, CX											
  type.go:94		0x92c3a5		f00fc108		LOCK XADDL CX, 0(AX)										
  type.go:94		0x92c3a9		ffc9			DECL CX												
  registry.go:147	0x92c3ab		85c9			TESTL CX, CX											
  registry.go:147	0x92c3ad		7c06			JL 0x92c3b5											
  registry.go:148	0x92c3af		4883c470		ADDQ $0x70, SP											
  registry.go:148	0x92c3b3		5d			POPQ BP												
  registry.go:148	0x92c3b4		c3			RET												
  registry.go:151	0x92c3b5		90			NOPL												
  type.go:83		0x92c3b6		31c9			XORL CX, CX											
  type.go:83		0x92c3b8		8708			XCHGL CX, 0(AX)											
  registry.go:152	0x92c3ba		4883c470		ADDQ $0x70, SP											
  registry.go:152	0x92c3be		5d			POPQ BP												
  registry.go:152	0x92c3bf		90			NOPL												
  registry.go:152	0x92c3c0		c3			RET												
  registry.go:144	0x92c3c1		4883c470		ADDQ $0x70, SP											
  registry.go:144	0x92c3c5		5d			POPQ BP												
  registry.go:144	0x92c3c6		c3			RET												
  registry.go:141	0x92c3c7		4889842480000000	MOVQ AX, 0x80(SP)										
  registry.go:155	0x92c3cf		90			NOPL												
  registry.go:141	0x92c3d0		4889c1			MOVQ AX, CX											
  mutex.go:63		0x92c3d3		31c0			XORL AX, AX											
  mutex.go:63		0x92c3d5		41b801000000		MOVL $0x1, R8											
  mutex.go:63		0x92c3db		f0440fb101		LOCK CMPXCHGL R8, 0(CX)										
  mutex.go:63		0x92c3e0		410f94c0		SETE R8												
  mutex.go:63		0x92c3e4		4584c0			TESTL R8, R8											
  mutex.go:63		0x92c3e7		7405			JE 0x92c3ee											
  registry.go:141	0x92c3e9		4885db			TESTQ BX, BX											
  mutex.go:46		0x92c3ec		eb26			JMP 0x92c414											
  registry.go:141	0x92c3ee		48899c2488000000	MOVQ BX, 0x88(SP)										
  mutex.go:70		0x92c3f6		4889c8			MOVQ CX, AX											
  mutex.go:70		0x92c3f9		e8e2feb6ff		CALL internal/sync.(*Mutex).lockSlow(SB)							
  registry.go:141	0x92c3fe		488b8c2488000000	MOVQ 0x88(SP), CX										
  registry.go:141	0x92c406		4885c9			TESTQ CX, CX											
  registry.go:161	0x92c409		4889cb			MOVQ CX, BX											
  registry.go:156	0x92c40c		488b8c2480000000	MOVQ 0x80(SP), CX										
  registry.go:156	0x92c414		4c8d0545010000		LEAQ github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister.deferwrap1(SB), R8	
  registry.go:156	0x92c41b		4c89442458		MOVQ R8, 0x58(SP)										
  registry.go:156	0x92c420		48894c2460		MOVQ CX, 0x60(SP)										
  registry.go:156	0x92c425		488d542458		LEAQ 0x58(SP), DX										
  registry.go:156	0x92c42a		4889542468		MOVQ DX, 0x68(SP)										
  registry.go:156	0x92c42f		c644244701		MOVB $0x1, 0x47(SP)										
  registry.go:158	0x92c434		0f8ee0000000		JLE 0x92c51a											
  registry.go:161	0x92c43a		4c8d43ff		LEAQ -0x1(BX), R8										
  registry.go:161	0x92c43e		6690			NOPW												
  registry.go:162	0x92c440		4c394110		CMPQ 0x10(CX), R8										
  registry.go:162	0x92c444		0f8ebe000000		JLE 0x92c508											
  registry.go:162	0x92c44a		4c8b4908		MOVQ 0x8(CX), R9										
  registry.go:165	0x92c44e		4d8b54d9f8		MOVQ -0x8(R9)(BX*8), R10									
  registry.go:166	0x92c453		4983faff		CMPQ R10, $-0x1											
  registry.go:166	0x92c457		0f8499000000		JE 0x92c4f6											
  registry.go:169	0x92c45d		49c744d9f8ffffffff	MOVQ $-0x1, -0x8(R9)(BX*8)									
  registry.go:170	0x92c466		4c8b4930		MOVQ 0x30(CX), R9										
  registry.go:170	0x92c46a		488b5928		MOVQ 0x28(CX), BX										
  registry.go:170	0x92c46e		48ffc3			INCQ BX												
  registry.go:170	0x92c471		488b4120		MOVQ 0x20(CX), AX										
  registry.go:170	0x92c475		4939d9			CMPQ R9, BX											
  registry.go:170	0x92c478		7354			JAE 0x92c4ce											
  registry.go:161	0x92c47a		4c89442450		MOVQ R8, 0x50(SP)										
  registry.go:165	0x92c47f		4c89542448		MOVQ R10, 0x48(SP)										
  registry.go:170	0x92c484		4c89c9			MOVQ R9, CX											
  registry.go:170	0x92c487		bf01000000		MOVL $0x1, DI											
  registry.go:170	0x92c48c		488d354d1e2301		LEAQ 0x1231e4d(IP), SI										
  registry.go:170	0x92c493		e8e828b6ff		CALL runtime.growslice(SB)									
  registry.go:170	0x92c498		488b942480000000	MOVQ 0x80(SP), DX										
  registry.go:170	0x92c4a0		48894a30		MOVQ CX, 0x30(DX)										
  registry.go:170	0x92c4a4		833d7510600200		CMPL runtime.writeBarrier(SB), $0x0								
  registry.go:170	0x92c4ab		7410			JE 0x92c4bd											
  registry.go:170	0x92c4ad		488b4a20		MOVQ 0x20(DX), CX										
  registry.go:170	0x92c4b1		e8aa7db6ff		CALL runtime.gcWriteBarrier2(SB)								
  registry.go:170	0x92c4b6		498903			MOVQ AX, 0(R11)											
  registry.go:170	0x92c4b9		49894b08		MOVQ CX, 0x8(R11)										
  registry.go:170	0x92c4bd		48894220		MOVQ AX, 0x20(DX)										
  registry.go:170	0x92c4c1		4889d1			MOVQ DX, CX											
  registry.go:170	0x92c4c4		4c8b442450		MOVQ 0x50(SP), R8										
  registry.go:171	0x92c4c9		4c8b542448		MOVQ 0x48(SP), R10										
  registry.go:170	0x92c4ce		48895928		MOVQ BX, 0x28(CX)										
  registry.go:170	0x92c4d2		4c8944d8f8		MOVQ R8, -0x8(AX)(BX*8)										
  registry.go:171	0x92c4d7		4c395138		CMPQ 0x38(CX), R10										
  registry.go:171	0x92c4db		7504			JNE 0x92c4e1											
  registry.go:172	0x92c4dd		c6414001		MOVB $0x1, 0x40(CX)										
  registry.go:174	0x92c4e1		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:174	0x92c4e6		488b542468		MOVQ 0x68(SP), DX										
  registry.go:174	0x92c4eb		488b02			MOVQ 0(DX), AX											
  registry.go:174	0x92c4ee		ffd0			CALL AX												
  registry.go:174	0x92c4f0		4883c470		ADDQ $0x70, SP											
  registry.go:174	0x92c4f4		5d			POPQ BP												
  registry.go:174	0x92c4f5		c3			RET												
  registry.go:167	0x92c4f6		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:167	0x92c4fb		488b442458		MOVQ 0x58(SP), AX										
  registry.go:167	0x92c500		ffd0			CALL AX												
  registry.go:167	0x92c502		4883c470		ADDQ $0x70, SP											
  registry.go:167	0x92c506		5d			POPQ BP												
  registry.go:167	0x92c507		c3			RET												
  registry.go:163	0x92c508		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:163	0x92c50d		488b442458		MOVQ 0x58(SP), AX										
  registry.go:163	0x92c512		ffd0			CALL AX												
  registry.go:163	0x92c514		4883c470		ADDQ $0x70, SP											
  registry.go:163	0x92c518		5d			POPQ BP												
  registry.go:163	0x92c519		c3			RET												
  registry.go:159	0x92c51a		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:159	0x92c51f		488b442458		MOVQ 0x58(SP), AX										
  registry.go:159	0x92c524		ffd0			CALL AX												
  registry.go:159	0x92c526		4883c470		ADDQ $0x70, SP											
  registry.go:159	0x92c52a		5d			POPQ BP												
  registry.go:159	0x92c52b		c3			RET												
  registry.go:159	0x92c52c		e8ef4ab2ff		CALL runtime.deferreturn(SB)									
  registry.go:159	0x92c531		4883c470		ADDQ $0x70, SP											
  registry.go:159	0x92c535		5d			POPQ BP												
  registry.go:159	0x92c536		c3			RET												
  registry.go:140	0x92c537		4889442408		MOVQ AX, 0x8(SP)										
  registry.go:140	0x92c53c		48895c2410		MOVQ BX, 0x10(SP)										
  registry.go:140	0x92c541		e81a62b6ff		CALL runtime.morestack_noctxt.abi0(SB)								
  registry.go:140	0x92c546		488b442408		MOVQ 0x8(SP), AX										
  registry.go:140	0x92c54b		488b5c2410		MOVQ 0x10(SP), BX										
  registry.go:140	0x92c550		e90bfeffff		JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister(SB)			

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister.deferwrap1(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:156	0x92c560		493b6610		CMPQ SP, 0x10(R14)										
  registry.go:156	0x92c564		7629			JBE 0x92c58f											
  registry.go:156	0x92c566		55			PUSHQ BP											
  registry.go:156	0x92c567		4889e5			MOVQ SP, BP											
  registry.go:156	0x92c56a		4883ec10		SUBQ $0x10, SP											
  registry.go:156	0x92c56e		488b4208		MOVQ 0x8(DX), AX										
  mutex.go:65		0x92c572		90			NOPL												
  mutex.go:194		0x92c573		bbffffffff		MOVL $-0x1, BX											
  mutex.go:194		0x92c578		f00fc118		LOCK XADDL BX, 0(AX)										
  mutex.go:194		0x92c57c		0f1f4000		NOPL 0(AX)											
  mutex.go:194		0x92c580		ffcb			DECL BX												
  mutex.go:195		0x92c582		7405			JE 0x92c589											
  mutex.go:198		0x92c584		e83700b7ff		CALL internal/sync.(*Mutex).unlockSlow(SB)							
  registry.go:156	0x92c589		4883c410		ADDQ $0x10, SP											
  registry.go:156	0x92c58d		5d			POPQ BP												
  registry.go:156	0x92c58e		c3			RET												
  registry.go:156	0x92c58f		e82c61b6ff		CALL runtime.morestack.abi0(SB)									
  registry.go:156	0x92c594		ebca			JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/db/api.go
  api.go:558		0xa36320		493b6610		CMPQ SP, 0x10(R14)								
  api.go:558		0xa36324		0f8679010000		JBE 0xa364a3									
  api.go:558		0xa3632a		55			PUSHQ BP									
  api.go:558		0xa3632b		4889e5			MOVQ SP, BP									
  api.go:558		0xa3632e		4883ec78		SUBQ $0x78, SP									
  api.go:558		0xa36332		48899c2490000000	MOVQ BX, 0x90(SP)								
  api.go:558		0xa3633a		4889b424a8000000	MOVQ SI, 0xa8(SP)								
  raw_kv_compat.go:7	0xa36342		4885db			TESTQ BX, BX									
  raw_kv_compat.go:7	0xa36345		7515			JNE 0xa3635c									
  api.go:559		0xa36347		488b1d72d83d02		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey(SB), BX		
  api.go:559		0xa3634e		488b0d73d83d02		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+8(SB), CX		
  api.go:559		0xa36355		488b3d74d83d02		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+16(SB), DI		
  raw_kv_compat.go:7	0xa3635c		4889842488000000	MOVQ AX, 0x88(SP)								
  raw_kv_compat.go:7	0xa36364		4c898424b0000000	MOVQ R8, 0xb0(SP)								
  raw_kv_compat.go:7	0xa3636c		4889b424a8000000	MOVQ SI, 0xa8(SP)								
  raw_kv_compat.go:7	0xa36374		4c898c24b8000000	MOVQ R9, 0xb8(SP)								
  api.go:560		0xa3637c		4c8d157d010000		LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1(SB), R10	
  api.go:560		0xa36383		4c89542450		MOVQ R10, 0x50(SP)								
  api.go:560		0xa36388		4889442458		MOVQ AX, 0x58(SP)								
  api.go:560		0xa3638d		48894c2468		MOVQ CX, 0x68(SP)								
  api.go:560		0xa36392		48897c2470		MOVQ DI, 0x70(SP)								
  api.go:560		0xa36397		48895c2460		MOVQ BX, 0x60(SP)								
  api.go:571		0xa3639c		8400			TESTB AL, 0(AX)									
  type.go:181		0xa3639e		488bb8a0160000		MOVQ 0x16a0(AX), DI								
  type.go:181		0xa363a5		48897c2418		MOVQ DI, 0x18(SP)								
  api.go:572		0xa363aa		488b7c2450		MOVQ 0x50(SP), DI								
  api.go:572		0xa363af		4889f0			MOVQ SI, AX									
  api.go:572		0xa363b2		4c89c3			MOVQ R8, BX									
  api.go:572		0xa363b5		4c89c9			MOVQ R9, CX									
  api.go:572		0xa363b8		488d542450		LEAQ 0x50(SP), DX								
  api.go:572		0xa363bd		ffd7			CALL DI										
  api.go:572		0xa363bf		4889742438		MOVQ SI, 0x38(SP)								
  api.go:572		0xa363c4		4c89442448		MOVQ R8, 0x48(SP)								
  api.go:572		0xa363c9		4889442440		MOVQ AX, 0x40(SP)								
  api.go:572		0xa363ce		48897c2430		MOVQ DI, 0x30(SP)								
  api.go:572		0xa363d3		48895c2420		MOVQ BX, 0x20(SP)								
  api.go:572		0xa363d8		48894c2428		MOVQ CX, 0x28(SP)								
  api.go:573		0xa363dd		488b842488000000	MOVQ 0x88(SP), AX								
  api.go:573		0xa363e5		4889f3			MOVQ SI, BX									
  api.go:573		0xa363e8		4c89c1			MOVQ R8, CX									
  api.go:573		0xa363eb		e870d1ffff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).refreshOnValueLogFileNotFound(SB)	
  api.go:573		0xa363f0		84c0			TESTL AL, AL									
  api.go:573		0xa363f2		7520			JNE 0xa36414									
  api.go:579		0xa363f4		488b742438		MOVQ 0x38(SP), SI								
  api.go:579		0xa363f9		488b7c2430		MOVQ 0x30(SP), DI								
  api.go:579		0xa363fe		488b5c2420		MOVQ 0x20(SP), BX								
  api.go:579		0xa36403		488b4c2428		MOVQ 0x28(SP), CX								
  api.go:579		0xa36408		4c8b442448		MOVQ 0x48(SP), R8								
  api.go:579		0xa3640d		488b442440		MOVQ 0x40(SP), AX								
  api.go:573		0xa36412		eb3b			JMP 0xa3644f									
  api.go:574		0xa36414		488b842488000000	MOVQ 0x88(SP), AX								
  api.go:574		0xa3641c		488b5c2418		MOVQ 0x18(SP), BX								
  api.go:574		0xa36421		e83ad2ffff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).refreshValueLogSetForReadRetry(SB)	
  api.go:574		0xa36426		4885c0			TESTQ AX, AX									
  api.go:574		0xa36429		7552			JNE 0xa3647d									
  api.go:577		0xa3642b		488b742450		MOVQ 0x50(SP), SI								
  api.go:577		0xa36430		488b8424a8000000	MOVQ 0xa8(SP), AX								
  api.go:577		0xa36438		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  api.go:577		0xa36440		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  api.go:577		0xa36448		488d542450		LEAQ 0x50(SP), DX								
  api.go:577		0xa3644d		ffd6			CALL SI										
  api.go:579		0xa3644f		4885f6			TESTQ SI, SI									
  api.go:579		0xa36452		741e			JE 0xa36472									
  api.go:580		0xa36454		488b8424a8000000	MOVQ 0xa8(SP), AX								
  api.go:580		0xa3645c		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  api.go:580		0xa36464		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  api.go:580		0xa3646c		4883c478		ADDQ $0x78, SP									
  api.go:580		0xa36470		5d			POPQ BP										
  api.go:580		0xa36471		c3			RET										
  api.go:582		0xa36472		31f6			XORL SI, SI									
  api.go:582		0xa36474		4531c0			XORL R8, R8									
  api.go:582		0xa36477		4883c478		ADDQ $0x78, SP									
  api.go:582		0xa3647b		5d			POPQ BP										
  api.go:582		0xa3647c		c3			RET										
  api.go:575		0xa3647d		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  api.go:575		0xa36485		31ff			XORL DI, DI									
  api.go:575		0xa36487		4889c6			MOVQ AX, SI									
  api.go:575		0xa3648a		4989d8			MOVQ BX, R8									
  api.go:575		0xa3648d		488b8424a8000000	MOVQ 0xa8(SP), AX								
  api.go:575		0xa36495		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  api.go:575		0xa3649d		4883c478		ADDQ $0x78, SP									
  api.go:575		0xa364a1		5d			POPQ BP										
  api.go:575		0xa364a2		c3			RET										
  api.go:558		0xa364a3		4889442408		MOVQ AX, 0x8(SP)								
  api.go:558		0xa364a8		48895c2410		MOVQ BX, 0x10(SP)								
  api.go:558		0xa364ad		48894c2418		MOVQ CX, 0x18(SP)								
  api.go:558		0xa364b2		48897c2420		MOVQ DI, 0x20(SP)								
  api.go:558		0xa364b7		4889742428		MOVQ SI, 0x28(SP)								
  api.go:558		0xa364bc		4c89442430		MOVQ R8, 0x30(SP)								
  api.go:558		0xa364c1		4c894c2438		MOVQ R9, 0x38(SP)								
  api.go:558		0xa364c6		e895c2a5ff		CALL runtime.morestack_noctxt.abi0(SB)						
  api.go:558		0xa364cb		488b442408		MOVQ 0x8(SP), AX								
  api.go:558		0xa364d0		488b5c2410		MOVQ 0x10(SP), BX								
  api.go:558		0xa364d5		488b4c2418		MOVQ 0x18(SP), CX								
  api.go:558		0xa364da		488b7c2420		MOVQ 0x20(SP), DI								
  api.go:558		0xa364df		488b742428		MOVQ 0x28(SP), SI								
  api.go:558		0xa364e4		4c8b442430		MOVQ 0x30(SP), R8								
  api.go:558		0xa364e9		4c8b4c2438		MOVQ 0x38(SP), R9								
  api.go:558		0xa364ee		e92dfeffff		JMP github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend(SB)		

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1(SB) github.com/snissn/gomap/TreeDB/db/api.go
  api.go:560		0xa36500		4c8d6424d8		LEAQ -0x28(SP), R12										
  api.go:560		0xa36505		4d3b6610		CMPQ R12, 0x10(R14)										
  api.go:560		0xa36509		0f86c7010000		JBE 0xa366d6											
  api.go:560		0xa3650f		55			PUSHQ BP											
  api.go:560		0xa36510		4889e5			MOVQ SP, BP											
  api.go:560		0xa36513		4881eca0000000		SUBQ $0xa0, SP											
  api.go:560		0xa3651a		66440fd6bc2498000000	MOVQ X15, 0x98(SP)										
  api.go:562		0xa36524		48898c24c0000000	MOVQ CX, 0xc0(SP)										
  api.go:562		0xa3652c		48899c24b8000000	MOVQ BX, 0xb8(SP)										
  api.go:562		0xa36534		48898424b0000000	MOVQ AX, 0xb0(SP)										
  api.go:560		0xa3653c		c644243f00		MOVB $0x0, 0x3f(SP)										
  api.go:560		0xa36541		488b4208		MOVQ 0x8(DX), AX										
  api.go:560		0xa36545		488b4a10		MOVQ 0x10(DX), CX										
  api.go:560		0xa36549		48898c2480000000	MOVQ CX, 0x80(SP)										
  api.go:560		0xa36551		488b4a18		MOVQ 0x18(DX), CX										
  api.go:560		0xa36555		48894c2448		MOVQ CX, 0x48(SP)										
  api.go:560		0xa3655a		488b4a20		MOVQ 0x20(DX), CX										
  api.go:560		0xa3655e		48894c2450		MOVQ CX, 0x50(SP)										
  api.go:560		0xa36563		48c744246800000000	MOVQ $0x0, 0x68(SP)										
  api.go:560		0xa3656c		440f117c2470		MOVUPS X15, 0x70(SP)										
  api.go:560		0xa36572		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  api.go:560		0xa3657b		440f117c2458		MOVUPS X15, 0x58(SP)										
  api.go:561		0xa36581		e81a551c00		CALL github.com/snissn/gomap/TreeDB/db.(*DB).acquireOneShotReadOrErr(SB)			
  api.go:562		0xa36586		4885db			TESTQ BX, BX											
  api.go:562		0xa36589		7463			JE 0xa365ee											
  api.go:563		0xa3658b		488b9424b0000000	MOVQ 0xb0(SP), DX										
  api.go:563		0xa36593		4889542468		MOVQ DX, 0x68(SP)										
  api.go:563		0xa36598		488b9424b8000000	MOVQ 0xb8(SP), DX										
  api.go:563		0xa365a0		4889542470		MOVQ DX, 0x70(SP)										
  api.go:563		0xa365a5		488b9424c0000000	MOVQ 0xc0(SP), DX										
  api.go:563		0xa365ad		4889542478		MOVQ DX, 0x78(SP)										
  api.go:563		0xa365b2		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  api.go:563		0xa365bb		48895c2458		MOVQ BX, 0x58(SP)										
  api.go:563		0xa365c0		48894c2460		MOVQ CX, 0x60(SP)										
  api.go:563		0xa365c5		488b7c2440		MOVQ 0x40(SP), DI										
  api.go:563		0xa365ca		488b442468		MOVQ 0x68(SP), AX										
  api.go:563		0xa365cf		488b542470		MOVQ 0x70(SP), DX										
  api.go:563		0xa365d4		4c8b4c2478		MOVQ 0x78(SP), R9										
  api.go:563		0xa365d9		4889de			MOVQ BX, SI											
  api.go:563		0xa365dc		4989c8			MOVQ CX, R8											
  api.go:563		0xa365df		4889d3			MOVQ DX, BX											
  api.go:563		0xa365e2		4c89c9			MOVQ R9, CX											
  api.go:563		0xa365e5		4881c4a0000000		ADDQ $0xa0, SP											
  api.go:563		0xa365ec		5d			POPQ BP												
  api.go:563		0xa365ed		c3			RET												
  api.go:565		0xa365ee		488d150b010000		LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1.deferwrap1(SB), DX	
  api.go:565		0xa365f5		4889942488000000	MOVQ DX, 0x88(SP)										
  api.go:565		0xa365fd		4889842490000000	MOVQ AX, 0x90(SP)										
  api.go:565		0xa36605		488d942488000000	LEAQ 0x88(SP), DX										
  api.go:565		0xa3660d		4889942498000000	MOVQ DX, 0x98(SP)										
  api.go:565		0xa36615		c644243f01		MOVB $0x1, 0x3f(SP)										
  api.go:568		0xa3661a		8400			TESTB AL, 0(AX)											
  api.go:568		0xa3661c		4805c8030000		ADDQ $0x3c8, AX											
  api.go:568		0xa36622		488b9c2480000000	MOVQ 0x80(SP), BX										
  api.go:568		0xa3662a		488b4c2448		MOVQ 0x48(SP), CX										
  api.go:568		0xa3662f		488b7c2450		MOVQ 0x50(SP), DI										
  api.go:568		0xa36634		488bb424b0000000	MOVQ 0xb0(SP), SI										
  api.go:568		0xa3663c		4c8b8424b8000000	MOVQ 0xb8(SP), R8										
  api.go:568		0xa36644		4c8b8c24c0000000	MOVQ 0xc0(SP), R9										
  api.go:568		0xa3664c		e88f4fcaff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB)				
  api.go:568		0xa36651		4889442468		MOVQ AX, 0x68(SP)										
  api.go:568		0xa36656		48895c2470		MOVQ BX, 0x70(SP)										
  api.go:568		0xa3665b		48894c2478		MOVQ CX, 0x78(SP)										
  api.go:568		0xa36660		48897c2440		MOVQ DI, 0x40(SP)										
  api.go:568		0xa36665		4889742458		MOVQ SI, 0x58(SP)										
  api.go:568		0xa3666a		4c89442460		MOVQ R8, 0x60(SP)										
  api.go:568		0xa3666f		c644243f00		MOVB $0x0, 0x3f(SP)										
  api.go:568		0xa36674		488b942498000000	MOVQ 0x98(SP), DX										
  api.go:568		0xa3667c		4c8b12			MOVQ 0(DX), R10											
  api.go:568		0xa3667f		90			NOPL												
  api.go:568		0xa36680		41ffd2			CALL R10											
  api.go:568		0xa36683		488b7c2440		MOVQ 0x40(SP), DI										
  api.go:568		0xa36688		488b742458		MOVQ 0x58(SP), SI										
  api.go:568		0xa3668d		488b442468		MOVQ 0x68(SP), AX										
  api.go:568		0xa36692		488b5c2470		MOVQ 0x70(SP), BX										
  api.go:568		0xa36697		4c8b442460		MOVQ 0x60(SP), R8										
  api.go:568		0xa3669c		488b4c2478		MOVQ 0x78(SP), CX										
  api.go:568		0xa366a1		4881c4a0000000		ADDQ $0xa0, SP											
  api.go:568		0xa366a8		5d			POPQ BP												
  api.go:568		0xa366a9		c3			RET												
  api.go:568		0xa366aa		e871a9a1ff		CALL runtime.deferreturn(SB)									
  api.go:568		0xa366af		488b442468		MOVQ 0x68(SP), AX										
  api.go:568		0xa366b4		488b5c2470		MOVQ 0x70(SP), BX										
  api.go:568		0xa366b9		488b4c2478		MOVQ 0x78(SP), CX										
  api.go:568		0xa366be		488b7c2440		MOVQ 0x40(SP), DI										
  api.go:568		0xa366c3		488b742458		MOVQ 0x58(SP), SI										
  api.go:568		0xa366c8		4c8b442460		MOVQ 0x60(SP), R8										
  api.go:568		0xa366cd		4881c4a0000000		ADDQ $0xa0, SP											
  api.go:568		0xa366d4		5d			POPQ BP												
  api.go:568		0xa366d5		c3			RET												
  api.go:560		0xa366d6		4889442408		MOVQ AX, 0x8(SP)										
  api.go:560		0xa366db		48895c2410		MOVQ BX, 0x10(SP)										
  api.go:560		0xa366e0		48894c2418		MOVQ CX, 0x18(SP)										
  api.go:560		0xa366e5		e8d6bfa5ff		CALL runtime.morestack.abi0(SB)									
  api.go:560		0xa366ea		488b442408		MOVQ 0x8(SP), AX										
  api.go:560		0xa366ef		488b5c2410		MOVQ 0x10(SP), BX										
  api.go:560		0xa366f4		488b4c2418		MOVQ 0x18(SP), CX										
  api.go:560		0xa366f9		e902feffff		JMP github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1(SB)			

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1.deferwrap1(SB) github.com/snissn/gomap/TreeDB/db/api.go
  api.go:565		0xa36700		493b6610		CMPQ SP, 0x10(R14)									
  api.go:565		0xa36704		7617			JBE 0xa3671d										
  api.go:565		0xa36706		55			PUSHQ BP										
  api.go:565		0xa36707		4889e5			MOVQ SP, BP										
  api.go:565		0xa3670a		4883ec08		SUBQ $0x8, SP										
  api.go:565		0xa3670e		488b4208		MOVQ 0x8(DX), AX									
  api.go:565		0xa36712		e8e9541c00		CALL github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB)				
  api.go:565		0xa36717		4883c408		ADDQ $0x8, SP										
  api.go:565		0xa3671b		5d			POPQ BP											
  api.go:565		0xa3671c		c3			RET											
  api.go:565		0xa3671d		0f1f00			NOPL 0(AX)										
  api.go:565		0xa36720		e89bbfa5ff		CALL runtime.morestack.abi0(SB)								
  api.go:565		0xa36725		ebd9			JMP github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/db/conditional_txn.go
  conditional_txn.go:193	0xaa3e40		4c8da42448feffff	LEAQ 0xfffffe48(SP), R12							
  conditional_txn.go:193	0xaa3e48		4d3b6610		CMPQ R12, 0x10(R14)								
  conditional_txn.go:193	0xaa3e4c		0f8666050000		JBE 0xaa43b8									
  conditional_txn.go:193	0xaa3e52		55			PUSHQ BP									
  conditional_txn.go:193	0xaa3e53		4889e5			MOVQ SP, BP									
  conditional_txn.go:193	0xaa3e56		4881ec30020000		SUBQ $0x230, SP									
  conditional_txn.go:193	0xaa3e5d		48899c2448020000	MOVQ BX, 0x248(SP)								
  conditional_txn.go:193	0xaa3e65		4889b42460020000	MOVQ SI, 0x260(SP)								
  conditional_txn.go:471	0xaa3e6d		4885c0			TESTQ AX, AX									
  conditional_txn.go:471	0xaa3e70		7442			JE 0xaa3eb4									
  conditional_txn.go:471	0xaa3e72		80782800		CMPB 0x28(AX), $0x0								
  conditional_txn.go:471	0xaa3e76		753c			JNE 0xaa3eb4									
  conditional_txn.go:471	0xaa3e78		488b10			MOVQ 0(AX), DX									
  conditional_txn.go:471	0xaa3e7b		0f1f440000		NOPL 0(AX)(AX*1)								
  conditional_txn.go:471	0xaa3e80		4885d2			TESTQ DX, DX									
  conditional_txn.go:471	0xaa3e83		742f			JE 0xaa3eb4									
  conditional_txn.go:471	0xaa3e85		4883780800		CMPQ 0x8(AX), $0x0								
  conditional_txn.go:471	0xaa3e8a		7428			JE 0xaa3eb4									
  conditional_txn.go:471	0xaa3e8c		4883781000		CMPQ 0x10(AX), $0x0								
  conditional_txn.go:471	0xaa3e91		7421			JE 0xaa3eb4									
  type.go:19			0xaa3e93		8b92a0510000		MOVL 0x51a0(DX), DX								
  type.go:19			0xaa3e99		85d2			TESTL DX, DX									
  conditional_txn.go:474	0xaa3e9b		7410			JE 0xaa3ead									
  conditional_txn.go:194	0xaa3e9d		488b15acbc3602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), DX			
  conditional_txn.go:194	0xaa3ea4		4c8b15adbc3602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), R10			
  conditional_txn.go:194	0xaa3eab		eb15			JMP 0xaa3ec2									
  conditional_txn.go:194	0xaa3ead		31d2			XORL DX, DX									
  conditional_txn.go:194	0xaa3eaf		4531d2			XORL R10, R10									
  conditional_txn.go:194	0xaa3eb2		eb0e			JMP 0xaa3ec2									
  conditional_txn.go:194	0xaa3eb4		488b15c5bc3602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrConditionalTxnClosed(SB), DX		
  conditional_txn.go:194	0xaa3ebb		4c8b15c6bc3602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrConditionalTxnClosed+8(SB), R10	
  conditional_txn.go:194	0xaa3ec2		4885d2			TESTQ DX, DX									
  conditional_txn.go:194	0xaa3ec5		0f85d3040000		JNE 0xaa439e									
  conditional_txn.go:471	0xaa3ecb		4c898c2470020000	MOVQ R9, 0x270(SP)								
  conditional_txn.go:471	0xaa3ed3		4c89842468020000	MOVQ R8, 0x268(SP)								
  conditional_txn.go:471	0xaa3edb		4889b42460020000	MOVQ SI, 0x260(SP)								
  raw_kv_compat.go:7		0xaa3ee3		4885db			TESTQ BX, BX									
  raw_kv_compat.go:7		0xaa3ee6		7515			JNE 0xaa3efd									
  conditional_txn.go:197	0xaa3ee8		488b1dd1fc3602		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey(SB), BX		
  conditional_txn.go:197	0xaa3eef		488b0dd2fc3602		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+8(SB), CX		
  conditional_txn.go:197	0xaa3ef6		488b3dd3fc3602		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+16(SB), DI		
  conditional_txn.go:471	0xaa3efd		4889842440020000	MOVQ AX, 0x240(SP)								
  conditional_txn.go:197	0xaa3f05		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  conditional_txn.go:197	0xaa3f0d		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  conditional_txn.go:197	0xaa3f15		48899c24f0000000	MOVQ BX, 0xf0(SP)								
  conditional_txn.go:198	0xaa3f1d		488d9424a0010000	LEAQ 0x1a0(SP), DX								
  conditional_txn.go:198	0xaa3f25		440f113a		MOVUPS X15, 0(DX)								
  conditional_txn.go:198	0xaa3f29		440f117a10		MOVUPS X15, 0x10(DX)								
  conditional_txn.go:198	0xaa3f2e		440f117a20		MOVUPS X15, 0x20(DX)								
  conditional_txn.go:198	0xaa3f33		440f117a30		MOVUPS X15, 0x30(DX)								
  conditional_txn.go:198	0xaa3f38		440f117a40		MOVUPS X15, 0x40(DX)								
  conditional_txn.go:198	0xaa3f3d		440f117a50		MOVUPS X15, 0x50(DX)								
  conditional_txn.go:198	0xaa3f42		440f117a60		MOVUPS X15, 0x60(DX)								
  conditional_txn.go:198	0xaa3f47		440f117a70		MOVUPS X15, 0x70(DX)								
  conditional_txn.go:198	0xaa3f4c		440f11ba80000000	MOVUPS X15, 0x80(DX)								
  conditional_txn.go:198	0xaa3f54		e8e71b0000		CALL github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).findStagedWrite(SB)	
  conditional_txn.go:198	0xaa3f59		488d9424a0010000	LEAQ 0x1a0(SP), DX								
  conditional_txn.go:198	0xaa3f61		4889e6			MOVQ SP, SI									
  conditional_txn.go:198	0xaa3f64		440f1036		MOVUPS 0(SI), X14								
  conditional_txn.go:198	0xaa3f68		440f1132		MOVUPS X14, 0(DX)								
  conditional_txn.go:198	0xaa3f6c		440f107610		MOVUPS 0x10(SI), X14								
  conditional_txn.go:198	0xaa3f71		440f117210		MOVUPS X14, 0x10(DX)								
  conditional_txn.go:198	0xaa3f76		440f107620		MOVUPS 0x20(SI), X14								
  conditional_txn.go:198	0xaa3f7b		440f117220		MOVUPS X14, 0x20(DX)								
  conditional_txn.go:198	0xaa3f80		440f107630		MOVUPS 0x30(SI), X14								
  conditional_txn.go:198	0xaa3f85		440f117230		MOVUPS X14, 0x30(DX)								
  conditional_txn.go:198	0xaa3f8a		440f107640		MOVUPS 0x40(SI), X14								
  conditional_txn.go:198	0xaa3f8f		440f117240		MOVUPS X14, 0x40(DX)								
  conditional_txn.go:198	0xaa3f94		440f107650		MOVUPS 0x50(SI), X14								
  conditional_txn.go:198	0xaa3f99		440f117250		MOVUPS X14, 0x50(DX)								
  conditional_txn.go:198	0xaa3f9e		440f107660		MOVUPS 0x60(SI), X14								
  conditional_txn.go:198	0xaa3fa3		440f117260		MOVUPS X14, 0x60(DX)								
  conditional_txn.go:198	0xaa3fa8		440f107670		MOVUPS 0x70(SI), X14								
  conditional_txn.go:198	0xaa3fad		440f117270		MOVUPS X14, 0x70(DX)								
  conditional_txn.go:198	0xaa3fb2		440f10b680000000	MOVUPS 0x80(SI), X14								
  conditional_txn.go:198	0xaa3fba		440f11b280000000	MOVUPS X14, 0x80(DX)								
  conditional_txn.go:198	0xaa3fc2		4c8d8424f8000000	LEAQ 0xf8(SP), R8								
  conditional_txn.go:198	0xaa3fca		440f1032		MOVUPS 0(DX), X14								
  conditional_txn.go:198	0xaa3fce		450f1130		MOVUPS X14, 0(R8)								
  conditional_txn.go:198	0xaa3fd2		440f107210		MOVUPS 0x10(DX), X14								
  conditional_txn.go:198	0xaa3fd7		450f117010		MOVUPS X14, 0x10(R8)								
  conditional_txn.go:198	0xaa3fdc		440f107220		MOVUPS 0x20(DX), X14								
  conditional_txn.go:198	0xaa3fe1		450f117020		MOVUPS X14, 0x20(R8)								
  conditional_txn.go:198	0xaa3fe6		440f107230		MOVUPS 0x30(DX), X14								
  conditional_txn.go:198	0xaa3feb		450f117030		MOVUPS X14, 0x30(R8)								
  conditional_txn.go:198	0xaa3ff0		440f107240		MOVUPS 0x40(DX), X14								
  conditional_txn.go:198	0xaa3ff5		450f117040		MOVUPS X14, 0x40(R8)								
  conditional_txn.go:198	0xaa3ffa		440f107250		MOVUPS 0x50(DX), X14								
  conditional_txn.go:198	0xaa3fff		450f117050		MOVUPS X14, 0x50(R8)								
  conditional_txn.go:198	0xaa4004		440f107260		MOVUPS 0x60(DX), X14								
  conditional_txn.go:198	0xaa4009		450f117060		MOVUPS X14, 0x60(R8)								
  conditional_txn.go:198	0xaa400e		440f107270		MOVUPS 0x70(DX), X14								
  conditional_txn.go:198	0xaa4013		450f117070		MOVUPS X14, 0x70(R8)								
  conditional_txn.go:198	0xaa4018		440f10b280000000	MOVUPS 0x80(DX), X14								
  conditional_txn.go:198	0xaa4020		450f11b080000000	MOVUPS X14, 0x80(R8)								
  conditional_txn.go:198	0xaa4028		84c0			TESTL AL, AL									
  conditional_txn.go:198	0xaa402a		0f8465010000		JE 0xaa4195									
  conditional_txn.go:199	0xaa4030		0fb6942430010000	MOVZX 0x130(SP), DX								
  conditional_txn.go:199	0xaa4038		0f1f840000000000	NOPL 0(AX)(AX*1)								
  conditional_txn.go:200	0xaa4040		84d2			TESTL DL, DL									
  conditional_txn.go:200	0xaa4042		0f850e010000		JNE 0xaa4156									
  conditional_txn.go:201	0xaa4048		80bc247801000000	CMPB 0x178(SP), $0x0								
  conditional_txn.go:201	0xaa4050		0f85c6000000		JNE 0xaa411c									
  conditional_txn.go:204	0xaa4056		488bbc2458010000	MOVQ 0x158(SP), DI								
  conditional_txn.go:204	0xaa405e		488b942468020000	MOVQ 0x268(SP), DX								
  conditional_txn.go:204	0xaa4066		488d1c3a		LEAQ 0(DX)(DI*1), BX								
  conditional_txn.go:204	0xaa406a		4c8b842450010000	MOVQ 0x150(SP), R8								
  conditional_txn.go:204	0xaa4072		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:204	0xaa407a		4839d9			CMPQ CX, BX									
  conditional_txn.go:204	0xaa407d		720a			JB 0xaa4089									
  conditional_txn.go:204	0xaa407f		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:204	0xaa4087		eb3f			JMP 0xaa40c8									
  conditional_txn.go:204	0xaa4089		4c89842498010000	MOVQ R8, 0x198(SP)								
  conditional_txn.go:204	0xaa4091		4889bc24e8000000	MOVQ DI, 0xe8(SP)								
  conditional_txn.go:204	0xaa4099		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:204	0xaa40a1		488d3578a00b01		LEAQ 0x10ba078(IP), SI								
  conditional_txn.go:204	0xaa40a8		e8d3ac9eff		CALL runtime.growslice(SB)							
  conditional_txn.go:204	0xaa40ad		488b942468020000	MOVQ 0x268(SP), DX								
  conditional_txn.go:204	0xaa40b5		4889e6			MOVQ SP, SI									
  conditional_txn.go:204	0xaa40b8		488bbc24e8000000	MOVQ 0xe8(SP), DI								
  conditional_txn.go:204	0xaa40c0		4c8b842498010000	MOVQ 0x198(SP), R8								
  conditional_txn.go:204	0xaa40c8		48898c24e8000000	MOVQ CX, 0xe8(SP)								
  conditional_txn.go:204	0xaa40d0		48899c24e0000000	MOVQ BX, 0xe0(SP)								
  conditional_txn.go:204	0xaa40d8		4889842498010000	MOVQ AX, 0x198(SP)								
  conditional_txn.go:204	0xaa40e0		4801d0			ADDQ DX, AX									
  conditional_txn.go:204	0xaa40e3		4c89c3			MOVQ R8, BX									
  conditional_txn.go:204	0xaa40e6		4889f9			MOVQ DI, CX									
  conditional_txn.go:204	0xaa40e9		e8b2089fff		CALL runtime.memmove(SB)							
  conditional_txn.go:204	0xaa40ee		488bbc2480010000	MOVQ 0x180(SP), DI								
  conditional_txn.go:204	0xaa40f6		488b842498010000	MOVQ 0x198(SP), AX								
  conditional_txn.go:204	0xaa40fe		488b9c24e0000000	MOVQ 0xe0(SP), BX								
  conditional_txn.go:204	0xaa4106		488b8c24e8000000	MOVQ 0xe8(SP), CX								
  conditional_txn.go:204	0xaa410e		31f6			XORL SI, SI									
  conditional_txn.go:204	0xaa4110		4531c0			XORL R8, R8									
  conditional_txn.go:204	0xaa4113		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:204	0xaa411a		5d			POPQ BP										
  conditional_txn.go:204	0xaa411b		c3			RET										
  conditional_txn.go:202	0xaa411c		488b151dcd3602		MOVQ github.com/snissn/gomap/TreeDB/batch.ErrMissingValueReader(SB), DX		
  conditional_txn.go:202	0xaa4123		4c8b051ecd3602		MOVQ github.com/snissn/gomap/TreeDB/batch.ErrMissingValueReader+8(SB), R8	
  conditional_txn.go:202	0xaa412a		488bbc2480010000	MOVQ 0x180(SP), DI								
  conditional_txn.go:202	0xaa4132		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:202	0xaa413a		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:202	0xaa4142		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:202	0xaa414a		4889d6			MOVQ DX, SI									
  conditional_txn.go:202	0xaa414d		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:202	0xaa4154		5d			POPQ BP										
  conditional_txn.go:202	0xaa4155		c3			RET										
  conditional_txn.go:205	0xaa4156		80fa01			CMPL DL, $0x1									
  conditional_txn.go:205	0xaa4159		753a			JNE 0xaa4195									
  conditional_txn.go:206	0xaa415b		488b158ecc3602		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), DX			
  conditional_txn.go:206	0xaa4162		4c8b058fcc3602		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R8		
  conditional_txn.go:206	0xaa4169		488bbc2480010000	MOVQ 0x180(SP), DI								
  conditional_txn.go:206	0xaa4171		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:206	0xaa4179		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:206	0xaa4181		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:206	0xaa4189		4889d6			MOVQ DX, SI									
  conditional_txn.go:206	0xaa418c		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:206	0xaa4193		5d			POPQ BP										
  conditional_txn.go:206	0xaa4194		c3			RET										
  conditional_txn.go:209	0xaa4195		488b942440020000	MOVQ 0x240(SP), DX								
  conditional_txn.go:209	0xaa419d		488b4208		MOVQ 0x8(DX), AX								
  conditional_txn.go:209	0xaa41a1		488b9c24f0000000	MOVQ 0xf0(SP), BX								
  conditional_txn.go:209	0xaa41a9		488b8c24b0000000	MOVQ 0xb0(SP), CX								
  conditional_txn.go:209	0xaa41b1		488bbc24b8000000	MOVQ 0xb8(SP), DI								
  conditional_txn.go:209	0xaa41b9		488bb42460020000	MOVQ 0x260(SP), SI								
  conditional_txn.go:209	0xaa41c1		4c8b842468020000	MOVQ 0x268(SP), R8								
  conditional_txn.go:209	0xaa41c9		4c8b8c2470020000	MOVQ 0x270(SP), R9								
  conditional_txn.go:209	0xaa41d1		e8eabd0100		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend(SB)	
  conditional_txn.go:209	0xaa41d6		4889b424d8000000	MOVQ SI, 0xd8(SP)								
  conditional_txn.go:209	0xaa41de		4c89842490010000	MOVQ R8, 0x190(SP)								
  conditional_txn.go:209	0xaa41e6		4889bc24c0000000	MOVQ DI, 0xc0(SP)								
  conditional_txn.go:209	0xaa41ee		4889842488010000	MOVQ AX, 0x188(SP)								
  conditional_txn.go:209	0xaa41f6		48899c24c8000000	MOVQ BX, 0xc8(SP)								
  conditional_txn.go:209	0xaa41fe		48898c24d0000000	MOVQ CX, 0xd0(SP)								
  conditional_txn.go:210	0xaa4206		488b0de3cb3602		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), CX			
  conditional_txn.go:210	0xaa420d		488b3de4cb3602		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), DI		
  conditional_txn.go:210	0xaa4214		4889f0			MOVQ SI, AX									
  conditional_txn.go:210	0xaa4217		4c89c3			MOVQ R8, BX									
  conditional_txn.go:210	0xaa421a		e881729fff		CALL errors.Is(SB)								
  conditional_txn.go:210	0xaa421f		90			NOPL										
  conditional_txn.go:210	0xaa4220		84c0			TESTL AL, AL									
  conditional_txn.go:210	0xaa4222		0f85d9000000		JNE 0xaa4301									
  conditional_txn.go:216	0xaa4228		488bb424d8000000	MOVQ 0xd8(SP), SI								
  conditional_txn.go:216	0xaa4230		4885f6			TESTQ SI, SI									
  conditional_txn.go:216	0xaa4233		0f8596000000		JNE 0xaa42cf									
  conditional_txn.go:219	0xaa4239		488b842440020000	MOVQ 0x240(SP), AX								
  conditional_txn.go:219	0xaa4241		488b9c24f0000000	MOVQ 0xf0(SP), BX								
  conditional_txn.go:219	0xaa4249		488b8c24b0000000	MOVQ 0xb0(SP), CX								
  conditional_txn.go:219	0xaa4251		488bbc24b8000000	MOVQ 0xb8(SP), DI								
  conditional_txn.go:219	0xaa4259		488bb424c0000000	MOVQ 0xc0(SP), SI								
  conditional_txn.go:219	0xaa4261		41b801000000		MOVL $0x1, R8									
  conditional_txn.go:219	0xaa4267		e8341d0000		CALL github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).recordRead(SB)		
  conditional_txn.go:219	0xaa426c		4885c0			TESTQ AX, AX									
  conditional_txn.go:219	0xaa426f		7430			JE 0xaa42a1									
  conditional_txn.go:220	0xaa4271		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:220	0xaa4279		488bbc24c0000000	MOVQ 0xc0(SP), DI								
  conditional_txn.go:220	0xaa4281		4889c6			MOVQ AX, SI									
  conditional_txn.go:220	0xaa4284		4989d8			MOVQ BX, R8									
  conditional_txn.go:220	0xaa4287		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:220	0xaa428f		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:220	0xaa4297		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:220	0xaa429e		5d			POPQ BP										
  conditional_txn.go:220	0xaa429f		90			NOPL										
  conditional_txn.go:220	0xaa42a0		c3			RET										
  conditional_txn.go:222	0xaa42a1		488b842488010000	MOVQ 0x188(SP), AX								
  conditional_txn.go:222	0xaa42a9		488b9c24c8000000	MOVQ 0xc8(SP), BX								
  conditional_txn.go:222	0xaa42b1		488b8c24d0000000	MOVQ 0xd0(SP), CX								
  conditional_txn.go:222	0xaa42b9		488bbc24c0000000	MOVQ 0xc0(SP), DI								
  conditional_txn.go:222	0xaa42c1		31f6			XORL SI, SI									
  conditional_txn.go:222	0xaa42c3		4531c0			XORL R8, R8									
  conditional_txn.go:222	0xaa42c6		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:222	0xaa42cd		5d			POPQ BP										
  conditional_txn.go:222	0xaa42ce		c3			RET										
  conditional_txn.go:217	0xaa42cf		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:217	0xaa42d7		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:217	0xaa42df		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:217	0xaa42e7		488bbc24c0000000	MOVQ 0xc0(SP), DI								
  conditional_txn.go:217	0xaa42ef		4c8b842490010000	MOVQ 0x190(SP), R8								
  conditional_txn.go:217	0xaa42f7		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:217	0xaa42fe		5d			POPQ BP										
  conditional_txn.go:217	0xaa42ff		90			NOPL										
  conditional_txn.go:217	0xaa4300		c3			RET										
  conditional_txn.go:211	0xaa4301		488b842440020000	MOVQ 0x240(SP), AX								
  conditional_txn.go:211	0xaa4309		488b9c24f0000000	MOVQ 0xf0(SP), BX								
  conditional_txn.go:211	0xaa4311		488b8c24b0000000	MOVQ 0xb0(SP), CX								
  conditional_txn.go:211	0xaa4319		488bbc24b8000000	MOVQ 0xb8(SP), DI								
  conditional_txn.go:211	0xaa4321		488bb424c0000000	MOVQ 0xc0(SP), SI								
  conditional_txn.go:211	0xaa4329		4531c0			XORL R8, R8									
  conditional_txn.go:211	0xaa432c		e86f1c0000		CALL github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).recordRead(SB)		
  conditional_txn.go:211	0xaa4331		4885c0			TESTQ AX, AX									
  conditional_txn.go:211	0xaa4334		742f			JE 0xaa4365									
  conditional_txn.go:212	0xaa4336		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:212	0xaa433e		488bbc24c0000000	MOVQ 0xc0(SP), DI								
  conditional_txn.go:212	0xaa4346		4889c6			MOVQ AX, SI									
  conditional_txn.go:212	0xaa4349		4989d8			MOVQ BX, R8									
  conditional_txn.go:212	0xaa434c		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:212	0xaa4354		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:212	0xaa435c		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:212	0xaa4363		5d			POPQ BP										
  conditional_txn.go:212	0xaa4364		c3			RET										
  conditional_txn.go:214	0xaa4365		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:214	0xaa436d		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:214	0xaa4375		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:214	0xaa437d		488bbc24c0000000	MOVQ 0xc0(SP), DI								
  conditional_txn.go:214	0xaa4385		488bb424d8000000	MOVQ 0xd8(SP), SI								
  conditional_txn.go:214	0xaa438d		4c8b842490010000	MOVQ 0x190(SP), R8								
  conditional_txn.go:214	0xaa4395		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:214	0xaa439c		5d			POPQ BP										
  conditional_txn.go:214	0xaa439d		c3			RET										
  conditional_txn.go:195	0xaa439e		4889f0			MOVQ SI, AX									
  conditional_txn.go:195	0xaa43a1		4c89c3			MOVQ R8, BX									
  conditional_txn.go:195	0xaa43a4		4c89c9			MOVQ R9, CX									
  conditional_txn.go:195	0xaa43a7		31ff			XORL DI, DI									
  conditional_txn.go:195	0xaa43a9		4889d6			MOVQ DX, SI									
  conditional_txn.go:195	0xaa43ac		4d89d0			MOVQ R10, R8									
  conditional_txn.go:195	0xaa43af		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:195	0xaa43b6		5d			POPQ BP										
  conditional_txn.go:195	0xaa43b7		c3			RET										
  conditional_txn.go:193	0xaa43b8		4889442408		MOVQ AX, 0x8(SP)								
  conditional_txn.go:193	0xaa43bd		48895c2410		MOVQ BX, 0x10(SP)								
  conditional_txn.go:193	0xaa43c2		48894c2418		MOVQ CX, 0x18(SP)								
  conditional_txn.go:193	0xaa43c7		48897c2420		MOVQ DI, 0x20(SP)								
  conditional_txn.go:193	0xaa43cc		4889742428		MOVQ SI, 0x28(SP)								
  conditional_txn.go:193	0xaa43d1		4c89442430		MOVQ R8, 0x30(SP)								
  conditional_txn.go:193	0xaa43d6		4c894c2438		MOVQ R9, 0x38(SP)								
  conditional_txn.go:193	0xaa43db		0f1f440000		NOPL 0(AX)(AX*1)								
  conditional_txn.go:193	0xaa43e0		e87be39eff		CALL runtime.morestack_noctxt.abi0(SB)						
  conditional_txn.go:193	0xaa43e5		488b442408		MOVQ 0x8(SP), AX								
  conditional_txn.go:193	0xaa43ea		488b5c2410		MOVQ 0x10(SP), BX								
  conditional_txn.go:193	0xaa43ef		488b4c2418		MOVQ 0x18(SP), CX								
  conditional_txn.go:193	0xaa43f4		488b7c2420		MOVQ 0x20(SP), DI								
  conditional_txn.go:193	0xaa43f9		488b742428		MOVQ 0x28(SP), SI								
  conditional_txn.go:193	0xaa43fe		4c8b442430		MOVQ 0x30(SP), R8								
  conditional_txn.go:193	0xaa4403		4c8b4c2438		MOVQ 0x38(SP), R9								
  conditional_txn.go:193	0xaa4408		e933faffff		JMP github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).GetVersionedAppend(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:1768				0xaa9820		4c8da424b8feffff		LEAQ 0xfffffeb8(SP), R12													
  db.go:1768				0xaa9828		4d3b6610			CMPQ R12, 0x10(R14)														
  db.go:1768				0xaa982c		0f867d0d0000			JBE 0xaaa5af															
  db.go:1768				0xaa9832		55				PUSHQ BP															
  db.go:1768				0xaa9833		4889e5				MOVQ SP, BP															
  db.go:1768				0xaa9836		4881ecc0010000			SUBQ $0x1c0, SP															
  rwmutex.go:72				0xaa983d		48898424d0010000		MOVQ AX, 0x1d0(SP)														
  rwmutex.go:72				0xaa9845		48899c24d8010000		MOVQ BX, 0x1d8(SP)														
  rwmutex.go:72				0xaa984d		888c24e0010000			MOVB CL, 0x1e0(SP)														
  db.go:1768				0xaa9854		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1769				0xaa9859		90				NOPL																
  type.go:94				0xaa985a		ba01000000			MOVL $0x1, DX															
  type.go:94				0xaa985f		f00fc19078070000		LOCK XADDL DX, 0x778(AX)													
  type.go:94				0xaa9867		ffc2				INCL DX																
  rwmutex.go:72				0xaa9869		85d2				TESTL DX, DX															
  rwmutex.go:72				0xaa986b		7d17				JGE 0xaa9884															
  rwmutex.go:74				0xaa986d		480574070000			ADDQ $0x774, AX															
  rwmutex.go:74				0xaa9873		31db				XORL BX, BX															
  rwmutex.go:74				0xaa9875		31c9				XORL CX, CX															
  rwmutex.go:74				0xaa9877		e884489eff			CALL sync.runtime_SemacquireRWMutexR(SB)											
  db.go:1770				0xaa987c		488b8424d0010000		MOVQ 0x1d0(SP), AX														
  db.go:1770				0xaa9884		488d0df50d0000			LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.deferwrap1(SB), CX		
  db.go:1770				0xaa988b		48898c24b0010000		MOVQ CX, 0x1b0(SP)														
  db.go:1770				0xaa9893		488d8868070000			LEAQ 0x768(AX), CX														
  db.go:1770				0xaa989a		48898c24b8010000		MOVQ CX, 0x1b8(SP)														
  db.go:1770				0xaa98a2		488d8c24b0010000		LEAQ 0x1b0(SP), CX														
  db.go:1770				0xaa98aa		48898c2430010000		MOVQ CX, 0x130(SP)														
  db.go:1770				0xaa98b2		488d842418010000		LEAQ 0x118(SP), AX														
  db.go:1770				0xaa98ba		e841729aff			CALL runtime.deferprocStack(SB)													
  type.go:19				0xaa98bf		488b8c24d0010000		MOVQ 0x1d0(SP), CX														
  type.go:19				0xaa98c7		8b91a0510000			MOVL 0x51a0(CX), DX														
  type.go:19				0xaa98cd		85d2				TESTL DX, DX															
  db.go:1771				0xaa98cf		750a				JNE 0xaa98db															
  type.go:19				0xaa98d1		8b91e04d0000			MOVL 0x4de0(CX), DX														
  type.go:19				0xaa98d7		85d2				TESTL DX, DX															
  db.go:1771				0xaa98d9		7418				JE 0xaa98f3															
  db.go:1772				0xaa98db		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaa98e0		e83b779aff			CALL runtime.deferreturn(SB)													
  db.go:1772				0xaa98e5		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaa98ea		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaa98f1		5d				POPQ BP																
  db.go:1927				0xaa98f2		c3				RET																
  db.go:1774				0xaa98f3		488b9424d8010000		MOVQ 0x1d8(SP), DX														
  db.go:1774				0xaa98fb		4883ba20060000ff		CMPQ 0x620(DX), $-0x1														
  db.go:1774				0xaa9903		752f				JNE 0xaa9934															
  db.go:1652				0xaa9905		4889d3				MOVQ DX, BX															
  db.go:1653				0xaa9908		4889d6				MOVQ DX, SI															
  db.go:1653				0xaa990b		48c1ea21			SHRQ $0x21, DX															
  db.go:1653				0xaa990f		4831d6				XORQ DX, SI															
  db.go:1654				0xaa9912		48bacd8c55edd7af51ff		MOVQ $0xff51afd7ed558ccd, DX													
  db.go:1654				0xaa991c		480faff2			IMULQ DX, SI															
  db.go:1655				0xaa9920		4889f2				MOVQ SI, DX															
  db.go:1655				0xaa9923		48c1ee21			SHRQ $0x21, SI															
  db.go:1655				0xaa9927		4831f2				XORQ SI, DX															
  db.go:1656				0xaa992a		83e20f				ANDL $0xf, DX															
  db.go:1775				0xaa992d		48899320060000			MOVQ DX, 0x620(BX)														
  db.go:1777				0xaa9934		90				NOPL																
  db.go:3850				0xaa9935		48c784249800000000000000	MOVQ $0x0, 0x98(SP)														
  db.go:3851				0xaa9941		488d942498000000		LEAQ 0x98(SP), DX														
  db.go:3852				0xaa9949		4889d3				MOVQ DX, BX															
  db.go:3852				0xaa994c		48c1ea07			SHRQ $0x7, DX															
  db.go:3852				0xaa9950		4831da				XORQ BX, DX															
  db.go:3852				0xaa9953		48c1eb0d			SHRQ $0xd, BX															
  db.go:3852				0xaa9957		4831d3				XORQ DX, BX															
  db.go:3852				0xaa995a		0fb6d3				MOVZX BL, DX															
  type.go:94				0xaa995d		488d1c91			LEAQ 0(CX)(DX*4), BX														
  type.go:94				0xaa9961		488d5b38			LEAQ 0x38(BX), BX														
  db.go:1778				0xaa9965		90				NOPL																
  type.go:94				0xaa9966		be01000000			MOVL $0x1, SI															
  type.go:94				0xaa996b		f00fc133			LOCK XADDL SI, 0(BX)														
  db.go:1779				0xaa996f		90				NOPL																
  type.go:195				0xaa9970		bb01000000			MOVL $0x1, BX															
  type.go:195				0xaa9975		f0480fc19938040000		LOCK XADDQ BX, 0x438(CX)													
  db.go:1780				0xaa997e		488d1d9b0c0000			LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.func1(SB), BX		
  db.go:1780				0xaa9985		48899c2498010000		MOVQ BX, 0x198(SP)														
  db.go:1780				0xaa998d		48898c24a0010000		MOVQ CX, 0x1a0(SP)														
  db.go:1780				0xaa9995		48899424a8010000		MOVQ DX, 0x1a8(SP)														
  db.go:1780				0xaa999d		488d8c2498010000		LEAQ 0x198(SP), CX														
  db.go:1780				0xaa99a5		48898c2400010000		MOVQ CX, 0x100(SP)														
  db.go:1780				0xaa99ad		488d8424e8000000		LEAQ 0xe8(SP), AX														
  db.go:1780				0xaa99b5		e846719aff			CALL runtime.deferprocStack(SB)													
  type.go:19				0xaa99ba		488b9424d0010000		MOVQ 0x1d0(SP), DX														
  type.go:19				0xaa99c2		8bb2a0510000			MOVL 0x51a0(DX), SI														
  type.go:19				0xaa99c8		85f6				TESTL SI, SI															
  db.go:1786				0xaa99ca		0f85c9060000			JNE 0xaaa099															
  db.go:1790				0xaa99d0		90				NOPL																
  type.go:58				0xaa99d1		488b7230			MOVQ 0x30(DX), SI														
  db.go:1791				0xaa99d5		4885f6				TESTQ SI, SI															
  db.go:1791				0xaa99d8		0f84a3060000			JE 0xaaa081															
  db.go:1791				0xaa99de		488b7e08			MOVQ 0x8(SI), DI														
  db.go:1791				0xaa99e2		4885ff				TESTQ DI, DI															
  db.go:1791				0xaa99e5		0f8496060000			JE 0xaaa081															
  db.go:1791				0xaa99eb		4c8b4610			MOVQ 0x10(SI), R8														
  db.go:1791				0xaa99ef		4d85c0				TESTQ R8, R8															
  db.go:1791				0xaa99f2		0f8489060000			JE 0xaaa081															
  db.go:1797				0xaa99f8		498b5830			MOVQ 0x30(R8), BX														
  db.go:1796				0xaa99fc		4c8b4e18			MOVQ 0x18(SI), R9														
  db.go:1798				0xaa9a00		4885db				TESTQ BX, BX															
  db.go:1798				0xaa9a03		410f95c2			SETNE R10															
  rwmutex.go:72				0xaa9a07		440fb69c24e0010000		MOVZX 0x1e0(SP), R11														
  rwmutex.go:72				0xaa9a10		4584db				TESTL R11, R11															
  db.go:1799				0xaa9a13		0f84a0000000			JE 0xaa9ab9															
  db.go:1799				0xaa9a19		0f1f8000000000			NOPL 0(AX)															
  db.go:1798				0xaa9a20		4885db				TESTQ BX, BX															
  db.go:1799				0xaa9a23		0f8488000000			JE 0xaa9ab1															
  db.go:1800				0xaa9a29		4c8d542430			LEAQ 0x30(SP), R10														
  db.go:1800				0xaa9a2e		450f113a			MOVUPS X15, 0(R10)														
  db.go:1800				0xaa9a32		450f117a10			MOVUPS X15, 0x10(R10)														
  db.go:1800				0xaa9a37		450f117a20			MOVUPS X15, 0x20(R10)														
  manager.go:1302			0xaa9a3c		4c8da368020000			LEAQ 0x268(BX), R12														
  db.go:1800				0xaa9a43		450f103424			MOVUPS 0(R12), X14														
  db.go:1800				0xaa9a48		450f1132			MOVUPS X14, 0(R10)														
  db.go:1800				0xaa9a4c		450f10742410			MOVUPS 0x10(R12), X14														
  db.go:1800				0xaa9a52		450f117210			MOVUPS X14, 0x10(R10)														
  db.go:1800				0xaa9a57		450f10742420			MOVUPS 0x20(R12), X14														
  db.go:1800				0xaa9a5d		450f117220			MOVUPS X14, 0x20(R10)														
  manager.go:1302			0xaa9a62		80bb9802000000			CMPB 0x298(BX), $0x0														
  db.go:1800				0xaa9a69		4c8d642460			LEAQ 0x60(SP), R12														
  db.go:1800				0xaa9a6e		450f1032			MOVUPS 0(R10), X14														
  db.go:1800				0xaa9a72		450f113424			MOVUPS X14, 0(R12)														
  db.go:1800				0xaa9a77		450f107210			MOVUPS 0x10(R10), X14														
  db.go:1800				0xaa9a7c		450f11742410			MOVUPS X14, 0x10(R12)														
  db.go:1800				0xaa9a82		450f107220			MOVUPS 0x20(R10), X14														
  db.go:1800				0xaa9a87		450f11742420			MOVUPS X14, 0x20(R12)														
  db.go:1800				0xaa9a8d		7418				JE 0xaa9aa7															
  db.go:1800				0xaa9a8f		48837c246800			CMPQ 0x68(SP), $0x0														
  db.go:1800				0xaa9a95		750b				JNE 0xaa9aa2															
  rwmutex.go:72				0xaa9a97		4584db				TESTL R11, R11															
  rwmutex.go:72				0xaa9a9a		b800000000			MOVL $0x0, AX															
  rwmutex.go:72				0xaa9a9f		90				NOPL																
  db.go:1800				0xaa9aa0		eb1a				JMP 0xaa9abc															
  rwmutex.go:72				0xaa9aa2		4584db				TESTL R11, R11															
  db.go:1800				0xaa9aa5		eb03				JMP 0xaa9aaa															
  rwmutex.go:72				0xaa9aa7		4584db				TESTL R11, R11															
  db.go:1800				0xaa9aaa		b801000000			MOVL $0x1, AX															
  db.go:1800				0xaa9aaf		eb0b				JMP 0xaa9abc															
  rwmutex.go:72				0xaa9ab1		4584db				TESTL R11, R11															
  db.go:1804				0xaa9ab4		4489d0				MOVL R10, AX															
  db.go:1799				0xaa9ab7		eb03				JMP 0xaa9abc															
  db.go:1804				0xaa9ab9		4489d0				MOVL R10, AX															
  db.go:1804				0xaa9abc		7409				JE 0xaa9ac7															
  db.go:1804				0xaa9abe		6690				NOPW																
  db.go:1804				0xaa9ac0		84c0				TESTL AL, AL															
  db.go:1804				0xaa9ac2		7503				JNE 0xaa9ac7															
  db.go:1804				0xaa9ac4		4531c9				XORL R9, R9															
  type.go:58				0xaa9ac7		4889b42470010000		MOVQ SI, 0x170(SP)														
  db.go:1791				0xaa9acf		4889bc2468010000		MOVQ DI, 0x168(SP)														
  db.go:1791				0xaa9ad7		4c89842460010000		MOVQ R8, 0x160(SP)														
  db.go:1797				0xaa9adf		48899c2450010000		MOVQ BX, 0x150(SP)														
  db.go:1807				0xaa9ae7		4c898c2448010000		MOVQ R9, 0x148(SP)														
  db.go:1804				0xaa9aef		8844242e			MOVB AL, 0x2e(SP)														
  db.go:1807				0xaa9af3		c644242f00			MOVB $0x0, 0x2f(SP)														
  db.go:1807				0xaa9af8		0f1f840000000000		NOPL 0(AX)(AX*1)														
  db.go:1808				0xaa9b00		4d85c9				TESTQ R9, R9															
  db.go:1808				0xaa9b03		0f84a7000000			JE 0xaa9bb0															
  db.go:1809				0xaa9b09		4c89c8				MOVQ R9, AX															
  db.go:1809				0xaa9b0c		e88fc1d7ff			CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).RetainSnapshotWrapper(SB)					
  db.go:1809				0xaa9b11		84c0				TESTL AL, AL															
  db.go:1809				0xaa9b13		0f8450050000			JE 0xaaa069															
  db.go:1812				0xaa9b19		488d0dc00a0000			LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.func2(SB), CX		
  db.go:1812				0xaa9b20		48898c2478010000		MOVQ CX, 0x178(SP)														
  db.go:1812				0xaa9b28		488d4c242f			LEAQ 0x2f(SP), CX														
  db.go:1812				0xaa9b2d		48898c2480010000		MOVQ CX, 0x180(SP)														
  db.go:1812				0xaa9b35		488b8c24d8010000		MOVQ 0x1d8(SP), CX														
  db.go:1812				0xaa9b3d		48898c2488010000		MOVQ CX, 0x188(SP)														
  db.go:1812				0xaa9b45		488b8c2448010000		MOVQ 0x148(SP), CX														
  db.go:1812				0xaa9b4d		48898c2490010000		MOVQ CX, 0x190(SP)														
  db.go:1812				0xaa9b55		488d8c2478010000		LEAQ 0x178(SP), CX														
  db.go:1812				0xaa9b5d		48898c24d0000000		MOVQ CX, 0xd0(SP)														
  db.go:1812				0xaa9b65		488d8424b8000000		LEAQ 0xb8(SP), AX														
  db.go:1812				0xaa9b6d		e88e6f9aff			CALL runtime.deferprocStack(SB)													
  db.go:1804				0xaa9b72		0fb644242e			MOVZX 0x2e(SP), AX														
  db.go:1874				0xaa9b77		488b9424d0010000		MOVQ 0x1d0(SP), DX														
  db.go:1798				0xaa9b7f		488b9c2450010000		MOVQ 0x150(SP), BX														
  db.go:1881				0xaa9b87		488bb42470010000		MOVQ 0x170(SP), SI														
  db.go:1827				0xaa9b8f		488bbc2468010000		MOVQ 0x168(SP), DI														
  durable_primary_runtime_v5.go:882	0xaa9b97		4c8b842460010000		MOVQ 0x160(SP), R8														
  db.go:1808				0xaa9b9f		4c8b8c2448010000		MOVQ 0x148(SP), R9														
  rwmutex.go:72				0xaa9ba7		440fb69c24e0010000		MOVZX 0x1e0(SP), R11														
  db.go:1804				0xaa9bb0		84c0				TESTL AL, AL															
  db.go:1818				0xaa9bb2		7434				JE 0xaa9be8															
  db.go:1808				0xaa9bb4		4d85c9				TESTQ R9, R9															
  db.go:1819				0xaa9bb7		7417				JE 0xaa9bd0															
  db.go:1822				0xaa9bb9		90				NOPL																
  db.go:1798				0xaa9bba		4885db				TESTQ BX, BX															
  manager.go:2596			0xaa9bbd		7429				JE 0xaa9be8															
  type.go:128				0xaa9bbf		41ba01000000			MOVL $0x1, R10															
  type.go:128				0xaa9bc5		f04c0fc193a8020000		LOCK XADDQ R10, 0x2a8(BX)													
  manager.go:2597			0xaa9bce		eb18				JMP 0xaa9be8															
  db.go:1820				0xaa9bd0		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaa9bd5		e846749aff			CALL runtime.deferreturn(SB)													
  db.go:1820				0xaa9bda		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaa9bdf		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaa9be6		5d				POPQ BP																
  db.go:1927				0xaa9be7		c3				RET																
  db.go:1827				0xaa9be8		4c8b5748			MOVQ 0x48(DI), R10														
  db.go:1827				0xaa9bec		4d85d2				TESTQ R10, R10															
  db.go:1827				0xaa9bef		0f844b040000			JE 0xaaa040															
  durable_primary_runtime_v5.go:882	0xaa9bf5		4d8b20				MOVQ 0(R8), R12															
  durable_primary_runtime_v5.go:882	0xaa9bf8		4d85e4				TESTQ R12, R12															
  durable_primary_runtime_v5.go:882	0xaa9bfb		740b				JE 0xaa9c08															
  durable_primary_runtime_v5.go:882	0xaa9bfd		4d8b642418			MOVQ 0x18(R12), R12														
  durable_primary_runtime_v5.go:882	0xaa9c02		4d396008			CMPQ 0x8(R8), R12														
  durable_primary_runtime_v5.go:882	0xaa9c06		7704				JA 0xaa9c0c															
  durable_primary_runtime_v5.go:885	0xaa9c08		4d8b6008			MOVQ 0x8(R8), R12														
  db.go:1833				0xaa9c0c		488b9424d8010000		MOVQ 0x1d8(SP), DX														
  db.go:1833				0xaa9c14		488b8a20060000			MOVQ 0x620(DX), CX														
  db.go:1833				0xaa9c1b		4c89d0				MOVQ R10, AX															
  db.go:1833				0xaa9c1e		4c89e3				MOVQ R12, BX															
  db.go:1833				0xaa9c21		e83a21e8ff			CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint(SB)						
  db.go:1833				0xaa9c26		4889842490000000		MOVQ AX, 0x90(SP)														
  db.go:1833				0xaa9c2e		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1833				0xaa9c36		48899f20060000			MOVQ BX, 0x620(DI)														
  db.go:1835				0xaa9c3d		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1835				0xaa9c45		488b0a				MOVQ 0(DX), CX															
  db.go:1835				0xaa9c48		4885c9				TESTQ CX, CX															
  db.go:1835				0xaa9c4b		7434				JE 0xaa9c81															
  db.go:1836				0xaa9c4d		4889f8				MOVQ DI, AX															
  db.go:1836				0xaa9c50		488b9c2468010000		MOVQ 0x168(SP), BX														
  db.go:1836				0xaa9c58		e863951a00			CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).acquirePrimaryRoot(SB)							
  db.go:1836				0xaa9c5d		0f1f00				NOPL 0(AX)															
  db.go:1836				0xaa9c60		4885c0				TESTQ AX, AX															
  db.go:1836				0xaa9c63		0f856b030000			JNE 0xaa9fd4															
  db.go:1899				0xaa9c69		488b842490000000		MOVQ 0x90(SP), AX														
  db.go:1846				0xaa9c71		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1866				0xaa9c79		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1846				0xaa9c81		4c8b4238			MOVQ 0x38(DX), R8														
  db.go:1846				0xaa9c85		4d85c0				TESTQ R8, R8															
  db.go:1846				0xaa9c88		0f84d7020000			JE 0xaa9f65															
  db.go:1847				0xaa9c8e		498b4818			MOVQ 0x18(R8), CX														
  db.go:1847				0xaa9c92		4d8b4820			MOVQ 0x20(R8), R9														
  db.go:1847				0xaa9c96		498b5810			MOVQ 0x10(R8), BX														
  db.go:1847				0xaa9c9a		48898f60030000			MOVQ CX, 0x360(DI)														
  db.go:1847				0xaa9ca1		4c898f68030000			MOVQ R9, 0x368(DI)														
  db.go:1847				0xaa9ca8		833d7138480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1847				0xaa9caf		7413				JE 0xaa9cc4															
  db.go:1847				0xaa9cb1		4c8b8758030000			MOVQ 0x358(DI), R8														
  db.go:1847				0xaa9cb8		e8a3a59eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1847				0xaa9cbd		49891b				MOVQ BX, 0(R11)															
  db.go:1847				0xaa9cc0		4d894308			MOVQ R8, 0x8(R11)														
  db.go:1847				0xaa9cc4		48899f58030000			MOVQ BX, 0x358(DI)														
  db.go:1848				0xaa9ccb		4c8b4238			MOVQ 0x38(DX), R8														
  db.go:1848				0xaa9ccf		4d8b5040			MOVQ 0x40(R8), R10														
  db.go:1848				0xaa9cd3		4d85d2				TESTQ R10, R10															
  db.go:1848				0xaa9cd6		0f8409010000			JE 0xaa9de5															
  db.go:1849				0xaa9cdc		833d3d38480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1849				0xaa9ce3		7505				JNE 0xaa9cea															
  db.go:1848				0xaa9ce5		4d85d2				TESTQ R10, R10															
  db.go:1849				0xaa9ce8		eb16				JMP 0xaa9d00															
  db.go:1849				0xaa9cea		4c8b87a0030000			MOVQ 0x3a0(DI), R8														
  db.go:1849				0xaa9cf1		e86aa59eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1849				0xaa9cf6		4d8913				MOVQ R10, 0(R11)														
  db.go:1849				0xaa9cf9		4d894308			MOVQ R8, 0x8(R11)														
  db.go:1848				0xaa9cfd		4d85d2				TESTQ R10, R10															
  db.go:1849				0xaa9d00		4c8997a0030000			MOVQ R10, 0x3a0(DI)														
  leaf_generation_runtime.go:344	0xaa9d07		0f849c000000			JE 0xaa9da9															
  leaf_generation_runtime.go:347	0xaa9d0d		488b9c24d0010000		MOVQ 0x1d0(SP), BX														
  leaf_generation_runtime.go:347	0xaa9d15		4881c338050000			ADDQ $0x538, BX															
  leaf_generation_runtime.go:347	0xaa9d1c		4c89d0				MOVQ R10, AX															
  leaf_generation_runtime.go:347	0xaa9d1f		90				NOPL																
  leaf_generation_runtime.go:347	0xaa9d20		e81be90e00			CALL github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinSet).retain(SB)							
  leaf_generation_runtime.go:347	0xaa9d25		84c0				TESTL AL, AL															
  db.go:1850				0xaa9d27		7468				JE 0xaa9d91															
  db.go:1851				0xaa9d29		488b8424d8010000		MOVQ 0x1d8(SP), AX														
  db.go:1851				0xaa9d31		488b9060030000			MOVQ 0x360(AX), DX														
  db.go:1851				0xaa9d38		4c8b8068030000			MOVQ 0x368(AX), R8														
  db.go:1851				0xaa9d3f		4c8b8858030000			MOVQ 0x358(AX), R9														
  db.go:1851				0xaa9d46		48899078030000			MOVQ DX, 0x378(AX)														
  db.go:1851				0xaa9d4d		4c898080030000			MOVQ R8, 0x380(AX)														
  db.go:1851				0xaa9d54		833dc537480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1851				0xaa9d5b		7413				JE 0xaa9d70															
  db.go:1851				0xaa9d5d		488b9070030000			MOVQ 0x370(AX), DX														
  db.go:1851				0xaa9d64		e8f7a49eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1851				0xaa9d69		4d890b				MOVQ R9, 0(R11)															
  db.go:1851				0xaa9d6c		49895308			MOVQ DX, 0x8(R11)														
  db.go:1851				0xaa9d70		4c898870030000			MOVQ R9, 0x370(AX)														
  db.go:1899				0xaa9d77		488b842490000000		MOVQ 0x90(SP), AX														
  db.go:1876				0xaa9d7f		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1855				0xaa9d87		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1851				0xaa9d8f		eb43				JMP 0xaa9dd4															
  db.go:1899				0xaa9d91		488b842490000000		MOVQ 0x90(SP), AX														
  db.go:1876				0xaa9d99		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1853				0xaa9da1		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1853				0xaa9da9		440f11bf78030000		MOVUPS X15, 0x378(DI)														
  db.go:1853				0xaa9db1		833d6837480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1853				0xaa9db8		740f				JE 0xaa9dc9															
  db.go:1853				0xaa9dba		4c8b8770030000			MOVQ 0x370(DI), R8														
  db.go:1853				0xaa9dc1		e87aa49eff			CALL runtime.gcWriteBarrier1(SB)												
  db.go:1853				0xaa9dc6		4d8903				MOVQ R8, 0(R11)															
  db.go:1853				0xaa9dc9		48c7877003000000000000		MOVQ $0x0, 0x370(DI)														
  db.go:1855				0xaa9dd4		48c7879003000000000000		MOVQ $0x0, 0x390(DI)														
  db.go:1855				0xaa9ddf		90				NOPL																
  db.go:1855				0xaa9de0		e9e1020000			JMP 0xaaa0c6															
  db.go:1856				0xaa9de5		498b7030			MOVQ 0x30(R8), SI														
  db.go:1856				0xaa9de9		4d8b5028			MOVQ 0x28(R8), R10														
  db.go:1856				0xaa9ded		49397018			CMPQ 0x18(R8), SI														
  db.go:1856				0xaa9df1		0f85f9000000			JNE 0xaa9ef0															
  db.go:1856				0xaa9df7		660f1f840000000000		NOPW 0(AX)(AX*1)														
  db.go:1856				0xaa9e00		4885f6				TESTQ SI, SI															
  db.go:1856				0xaa9e03		0f84e7000000			JE 0xaa9ef0															
  db.go:1857				0xaa9e09		488b8f98030000			MOVQ 0x398(DI), CX														
  db.go:1857				0xaa9e10		4c8b8788030000			MOVQ 0x388(DI), R8														
  db.go:1857				0xaa9e17		4839f1				CMPQ CX, SI															
  db.go:1857				0xaa9e1a		7206				JB 0xaa9e22															
  db.go:1856				0xaa9e1c		4889f3				MOVQ SI, BX															
  db.go:1856				0xaa9e1f		90				NOPL																
  db.go:1857				0xaa9e20		eb3b				JMP 0xaa9e5d															
  db.go:1856				0xaa9e22		4889b424b0000000		MOVQ SI, 0xb0(SP)														
  db.go:1856				0xaa9e2a		4c89942458010000		MOVQ R10, 0x158(SP)														
  db.go:1857				0xaa9e32		4c89c0				MOVQ R8, AX															
  db.go:1857				0xaa9e35		4889f3				MOVQ SI, BX															
  db.go:1857				0xaa9e38		4889df				MOVQ BX, DI															
  db.go:1857				0xaa9e3b		488d35dee20601			LEAQ 0x106e2de(IP), SI														
  db.go:1857				0xaa9e42		e8394f9eff			CALL runtime.growslice(SB)													
  db.go:1857				0xaa9e47		4c8b942458010000		MOVQ 0x158(SP), R10														
  db.go:1857				0xaa9e4f		4989c0				MOVQ AX, R8															
  db.go:1857				0xaa9e52		4889de				MOVQ BX, SI															
  db.go:1857				0xaa9e55		488b9c24b0000000		MOVQ 0xb0(SP), BX														
  db.go:1857				0xaa9e5d		4889b424b0000000		MOVQ SI, 0xb0(SP)														
  db.go:1857				0xaa9e65		4c89842458010000		MOVQ R8, 0x158(SP)														
  db.go:1857				0xaa9e6d		48898c24a8000000		MOVQ CX, 0xa8(SP)														
  db.go:1857				0xaa9e75		488d05a4e20601			LEAQ 0x106e2a4(IP), AX														
  db.go:1857				0xaa9e7c		4889f1				MOVQ SI, CX															
  db.go:1857				0xaa9e7f		4c89d7				MOVQ R10, DI															
  db.go:1857				0xaa9e82		4889de				MOVQ BX, SI															
  db.go:1857				0xaa9e85		4c89c3				MOVQ R8, BX															
  db.go:1857				0xaa9e88		e8530a9eff			CALL runtime.typedslicecopy(SB)													
  db.go:1857				0xaa9e8d		488b9424b0000000		MOVQ 0xb0(SP), DX														
  db.go:1857				0xaa9e95		488b8424d8010000		MOVQ 0x1d8(SP), AX														
  db.go:1857				0xaa9e9d		48899090030000			MOVQ DX, 0x390(AX)														
  db.go:1857				0xaa9ea4		4c8b8424a8000000		MOVQ 0xa8(SP), R8														
  db.go:1857				0xaa9eac		4c898098030000			MOVQ R8, 0x398(AX)														
  db.go:1857				0xaa9eb3		833d6636480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1857				0xaa9eba		750a				JNE 0xaa9ec6															
  db.go:1857				0xaa9ebc		4c8b8c2458010000		MOVQ 0x158(SP), R9														
  db.go:1857				0xaa9ec4		eb1b				JMP 0xaa9ee1															
  db.go:1857				0xaa9ec6		4c8b8088030000			MOVQ 0x388(AX), R8														
  db.go:1857				0xaa9ecd		e88ea39eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1857				0xaa9ed2		4c8b8c2458010000		MOVQ 0x158(SP), R9														
  db.go:1857				0xaa9eda		4d890b				MOVQ R9, 0(R11)															
  db.go:1857				0xaa9edd		4d894308			MOVQ R8, 0x8(R11)														
  db.go:1857				0xaa9ee1		4c898888030000			MOVQ R9, 0x388(AX)														
  db.go:1858				0xaa9ee8		90				NOPL																
  leaf_generation_runtime.go:333	0xaa9ee9		31c9				XORL CX, CX															
  leaf_generation_runtime.go:240	0xaa9eeb		e958060000			JMP 0xaaa548															
  db.go:1861				0xaa9ef0		48c7879003000000000000		MOVQ $0x0, 0x390(DI)														
  leaf_generation_runtime.go:319	0xaa9efb		488b8424d0010000		MOVQ 0x1d0(SP), AX														
  leaf_generation_runtime.go:319	0xaa9f03		480538050000			ADDQ $0x538, AX															
  db.go:1862				0xaa9f09		90				NOPL																
  leaf_generation_runtime.go:319	0xaa9f0a		4c89cf				MOVQ R9, DI															
  leaf_generation_runtime.go:319	0xaa9f0d		e8eef30e00			CALL github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinTracker).pin(SB)							
  db.go:1863				0xaa9f12		488b8424d8010000		MOVQ 0x1d8(SP), AX														
  db.go:1863				0xaa9f1a		488b9060030000			MOVQ 0x360(AX), DX														
  db.go:1863				0xaa9f21		488bb068030000			MOVQ 0x368(AX), SI														
  db.go:1863				0xaa9f28		4c8b8058030000			MOVQ 0x358(AX), R8														
  db.go:1863				0xaa9f2f		48899078030000			MOVQ DX, 0x378(AX)														
  db.go:1863				0xaa9f36		4889b080030000			MOVQ SI, 0x380(AX)														
  db.go:1863				0xaa9f3d		833ddc35480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1863				0xaa9f44		7413				JE 0xaa9f59															
  db.go:1863				0xaa9f46		488b9070030000			MOVQ 0x370(AX), DX														
  db.go:1863				0xaa9f4d		e80ea39eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1863				0xaa9f52		4d8903				MOVQ R8, 0(R11)															
  db.go:1863				0xaa9f55		49895308			MOVQ DX, 0x8(R11)														
  db.go:1863				0xaa9f59		4c898070030000			MOVQ R8, 0x370(AX)														
  db.go:1863				0xaa9f60		e9c0050000			JMP 0xaaa525															
  db.go:1866				0xaa9f65		440f11bf60030000		MOVUPS X15, 0x360(DI)														
  db.go:1866				0xaa9f6d		833dac35480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1866				0xaa9f74		7425				JE 0xaa9f9b															
  db.go:1866				0xaa9f76		4c8b8758030000			MOVQ 0x358(DI), R8														
  db.go:1867				0xaa9f7d		4c8b8f70030000			MOVQ 0x370(DI), R9														
  db.go:1869				0xaa9f84		4c8b97a0030000			MOVQ 0x3a0(DI), R10														
  db.go:1866				0xaa9f8b		e8f0a29eff			CALL runtime.gcWriteBarrier3(SB)												
  db.go:1866				0xaa9f90		4d8903				MOVQ R8, 0(R11)															
  db.go:1867				0xaa9f93		4d894b08			MOVQ R9, 0x8(R11)														
  db.go:1869				0xaa9f97		4d895310			MOVQ R10, 0x10(R11)														
  db.go:1866				0xaa9f9b		48c7875803000000000000		MOVQ $0x0, 0x358(DI)														
  db.go:1867				0xaa9fa6		440f11bf78030000		MOVUPS X15, 0x378(DI)														
  db.go:1867				0xaa9fae		48c7877003000000000000		MOVQ $0x0, 0x370(DI)														
  db.go:1868				0xaa9fb9		48c7879003000000000000		MOVQ $0x0, 0x390(DI)														
  db.go:1869				0xaa9fc4		48c787a003000000000000		MOVQ $0x0, 0x3a0(DI)														
  db.go:1869				0xaa9fcf		e9f2000000			JMP 0xaaa0c6															
  db.go:1837				0xaa9fd4		488b9c2490000000		MOVQ 0x90(SP), BX														
  db.go:1837				0xaa9fdc		0f1f4000			NOPL 0(AX)															
  db.go:1837				0xaa9fe0		4885db				TESTQ BX, BX															
  db.go:1837				0xaa9fe3		7509				JNE 0xaa9fee															
  db.go:1804				0xaa9fe5		0fb64c242e			MOVZX 0x2e(SP), CX														
  db.go:1804				0xaa9fea		84c9				TESTL CL, CL															
  db.go:1837				0xaa9fec		eb18				JMP 0xaaa006															
  db.go:1838				0xaa9fee		488b8c2468010000		MOVQ 0x168(SP), CX														
  db.go:1838				0xaa9ff6		488b4148			MOVQ 0x48(CX), AX														
  db.go:1838				0xaa9ffa		e86123e8ff			CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister(SB)							
  db.go:1804				0xaa9fff		0fb64c242e			MOVZX 0x2e(SP), CX														
  db.go:1804				0xaaa004		84c9				TESTL CL, CL															
  db.go:1840				0xaaa006		741d				JE 0xaaa025															
  db.go:1808				0xaaa008		488b842448010000		MOVQ 0x148(SP), AX														
  db.go:1808				0xaaa010		4885c0				TESTQ AX, AX															
  db.go:1840				0xaaa013		7410				JE 0xaaa025															
  db.go:1841				0xaaa015		488b9c2450010000		MOVQ 0x150(SP), BX														
  db.go:1841				0xaaa01d		0f1f00				NOPL 0(AX)															
  db.go:1841				0xaaa020		e85b66d7ff			CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).Release(SB)							
  db.go:1843				0xaaa025		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaaa02a		e8f16f9aff			CALL runtime.deferreturn(SB)													
  db.go:1843				0xaaa02f		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa034		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa03b		5d				POPQ BP																
  db.go:1927				0xaaa03c		c3				RET																
  db.go:1927				0xaaa03d		0f1f00				NOPL 0(AX)															
  db.go:1804				0xaaa040		84c0				TESTL AL, AL															
  db.go:1828				0xaaa042		740d				JE 0xaaa051															
  db.go:1808				0xaaa044		4d85c9				TESTQ R9, R9															
  db.go:1828				0xaaa047		7408				JE 0xaaa051															
  db.go:1829				0xaaa049		4c89c8				MOVQ R9, AX															
  db.go:1829				0xaaa04c		e82f66d7ff			CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).Release(SB)							
  db.go:1831				0xaaa051		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaaa056		e8c56f9aff			CALL runtime.deferreturn(SB)													
  db.go:1831				0xaaa05b		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa060		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa067		5d				POPQ BP																
  db.go:1927				0xaaa068		c3				RET																
  db.go:1810				0xaaa069		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaaa06e		e8ad6f9aff			CALL runtime.deferreturn(SB)													
  db.go:1810				0xaaa073		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa078		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa07f		5d				POPQ BP																
  db.go:1927				0xaaa080		c3				RET																
  db.go:1792				0xaaa081		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaaa086		e8956f9aff			CALL runtime.deferreturn(SB)													
  db.go:1792				0xaaa08b		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa090		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa097		5d				POPQ BP																
  db.go:1927				0xaaa098		c3				RET																
  db.go:1787				0xaaa099		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1787				0xaaa09e		6690				NOPW																
  db.go:1927				0xaaa0a0		e87b6f9aff			CALL runtime.deferreturn(SB)													
  db.go:1787				0xaaa0a5		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa0aa		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa0b1		5d				POPQ BP																
  db.go:1927				0xaaa0b2		c3				RET																
  db.go:1927				0xaaa0b3		e8686f9aff			CALL runtime.deferreturn(SB)													
  db.go:1770				0xaaa0b8		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa0bd		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa0c4		5d				POPQ BP																
  db.go:1927				0xaaa0c5		c3				RET																
  db.go:1872				0xaaa0c6		90				NOPL																
  type.go:195				0xaaa0c7		41b801000000			MOVL $0x1, R8															
  type.go:195				0xaaa0cd		4c8b8c2468010000		MOVQ 0x168(SP), R9														
  type.go:195				0xaaa0d5		f04d0fc14168			LOCK XADDQ R8, 0x68(R9)														
  type.go:195				0xaaa0db		49ffc0				INCQ R8																
  index_gen.go:236			0xaaa0de		490fbaf03f			BTRQ $0x3f, R8															
  index_gen.go:236			0xaaa0e3		4d85c0				TESTQ R8, R8															
  index_gen.go:236			0xaaa0e6		0f8426040000			JE 0xaaa512															
  db.go:1873				0xaaa0ec		c687d002000001			MOVB $0x1, 0x2d0(DI)														
  db.go:1874				0xaaa0f3		833d2634480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1874				0xaaa0fa		7515				JNE 0xaaa111															
  db.go:1808				0xaaa0fc		4c8b842448010000		MOVQ 0x148(SP), R8														
  db.go:1808				0xaaa104		4d85c0				TESTQ R8, R8															
  db.go:1874				0xaaa107		4c8bac24d0010000		MOVQ 0x1d0(SP), R13														
  db.go:1874				0xaaa10f		eb56				JMP 0xaaa167															
  db.go:1874				0xaaa111		4c8b8728030000			MOVQ 0x328(DI), R8														
  db.go:1875				0xaaa118		4c8b9730030000			MOVQ 0x330(DI), R10														
  db.go:1876				0xaaa11f		4c8b9f38030000			MOVQ 0x338(DI), R11														
  db.go:1877				0xaaa126		4c8ba740030000			MOVQ 0x340(DI), R12														
  db.go:1876				0xaaa12d		4c89d9				MOVQ R11, CX															
  db.go:1874				0xaaa130		e8eba19eff			CALL runtime.gcWriteBarrier8(SB)												
  db.go:1874				0xaaa135		4c8bac24d0010000		MOVQ 0x1d0(SP), R13														
  db.go:1874				0xaaa13d		4d892b				MOVQ R13, 0(R11)														
  db.go:1874				0xaaa140		4d894308			MOVQ R8, 0x8(R11)														
  db.go:1875				0xaaa144		4d894b10			MOVQ R9, 0x10(R11)														
  db.go:1875				0xaaa148		4d895318			MOVQ R10, 0x18(R11)														
  db.go:1876				0xaaa14c		49895320			MOVQ DX, 0x20(R11)														
  db.go:1876				0xaaa150		49894b28			MOVQ CX, 0x28(R11)														
  db.go:1877				0xaaa154		4c8b842448010000		MOVQ 0x148(SP), R8														
  db.go:1877				0xaaa15c		4d894330			MOVQ R8, 0x30(R11)														
  db.go:1877				0xaaa160		4d896338			MOVQ R12, 0x38(R11)														
  db.go:1808				0xaaa164		4d85c0				TESTQ R8, R8															
  db.go:1874				0xaaa167		4c89af28030000			MOVQ R13, 0x328(DI)														
  db.go:1875				0xaaa16e		4c898f30030000			MOVQ R9, 0x330(DI)														
  db.go:1876				0xaaa175		48899738030000			MOVQ DX, 0x338(DI)														
  db.go:1877				0xaaa17c		4c898740030000			MOVQ R8, 0x340(DI)														
  db.go:1878				0xaaa183		0f958748030000			SETNE 0x348(DI)															
  db.go:1879				0xaaa18a		c644242f01			MOVB $0x1, 0x2f(SP)														
  db.go:1880				0xaaa18f		440fb644242e			MOVZX 0x2e(SP), R8														
  db.go:1880				0xaaa195		44888749030000			MOVB R8, 0x349(DI)														
  db.go:1881				0xaaa19c		4c8b942470010000		MOVQ 0x170(SP), R10														
  db.go:1881				0xaaa1a4		4d8b5a20			MOVQ 0x20(R10), R11														
  db.go:1881				0xaaa1a8		4c899f50030000			MOVQ R11, 0x350(DI)														
  rwmutex.go:72				0xaaa1af		440fb69c24e0010000		MOVZX 0x1e0(SP), R11														
  rwmutex.go:72				0xaaa1b8		4584db				TESTL R11, R11															
  db.go:1882				0xaaa1bb		745d				JE 0xaaa21a															
  db.go:1882				0xaaa1bd		0f1f00				NOPL 0(AX)															
  db.go:1804				0xaaa1c0		4584c0				TESTL R8, R8															
  db.go:1882				0xaaa1c3		7555				JNE 0xaaa21a															
  db.go:1886				0xaaa1c5		4d8b8568040000			MOVQ 0x468(R13), R8														
  value_reader.go:56			0xaaa1cc		48c787b003000000000000		MOVQ $0x0, 0x3b0(DI)														
  value_reader.go:56			0xaaa1d7		833d4233480200			CMPL runtime.writeBarrier(SB), $0x0												
  value_reader.go:56			0xaaa1de		6690				NOPW																
  value_reader.go:56			0xaaa1e0		7424				JE 0xaaa206															
  value_reader.go:56			0xaaa1e2		4c8ba7b8030000			MOVQ 0x3b8(DI), R12														
  value_reader.go:57			0xaaa1e9		4c8bafc0030000			MOVQ 0x3c0(DI), R13														
  rwmutex.go:72				0xaaa1f0		4489d9				MOVL R11, CX															
  value_reader.go:56			0xaaa1f3		e888a09eff			CALL runtime.gcWriteBarrier3(SB)												
  value_reader.go:56			0xaaa1f8		4d8923				MOVQ R12, 0(R11)														
  value_reader.go:57			0xaaa1fb		4d894308			MOVQ R8, 0x8(R11)														
  value_reader.go:57			0xaaa1ff		4d896b10			MOVQ R13, 0x10(R11)														
  rwmutex.go:72				0xaaa203		4189cb				MOVL CX, R11															
  value_reader.go:56			0xaaa206		48c787b803000000000000		MOVQ $0x0, 0x3b8(DI)														
  value_reader.go:57			0xaaa211		4c8987c0030000			MOVQ R8, 0x3c0(DI)														
  db.go:1886				0xaaa218		eb69				JMP 0xaaa283															
  db.go:1888				0xaaa21a		4d8b8568040000			MOVQ 0x468(R13), R8														
  value_reader.go:56			0xaaa221		4c8d25f87e4101			LEAQ go:itab.*github.com/snissn/gomap/TreeDB/internal/valuelog.Set,github.com/snissn/gomap/TreeDB/tree.SlabReader(SB), R12	
  value_reader.go:56			0xaaa228		4c89a7b0030000			MOVQ R12, 0x3b0(DI)														
  value_reader.go:56			0xaaa22f		833dea32480200			CMPL runtime.writeBarrier(SB), $0x0												
  value_reader.go:56			0xaaa236		750d				JNE 0xaaa245															
  rwmutex.go:72				0xaaa238		4489d9				MOVL R11, CX															
  value_reader.go:56			0xaaa23b		4c8bbc2450010000		MOVQ 0x150(SP), R15														
  value_reader.go:56			0xaaa243		eb2d				JMP 0xaaa272															
  value_reader.go:56			0xaaa245		4c8ba7b8030000			MOVQ 0x3b8(DI), R12														
  value_reader.go:57			0xaaa24c		4c8bafc0030000			MOVQ 0x3c0(DI), R13														
  rwmutex.go:72				0xaaa253		4489d9				MOVL R11, CX															
  value_reader.go:56			0xaaa256		e845a09eff			CALL runtime.gcWriteBarrier4(SB)												
  value_reader.go:56			0xaaa25b		4c8bbc2450010000		MOVQ 0x150(SP), R15														
  value_reader.go:56			0xaaa263		4d893b				MOVQ R15, 0(R11)														
  value_reader.go:56			0xaaa266		4d896308			MOVQ R12, 0x8(R11)														
  value_reader.go:57			0xaaa26a		4d894310			MOVQ R8, 0x10(R11)														
  value_reader.go:57			0xaaa26e		4d896b18			MOVQ R13, 0x18(R11)														
  value_reader.go:56			0xaaa272		4c89bfb8030000			MOVQ R15, 0x3b8(DI)														
  value_reader.go:57			0xaaa279		4c8987c0030000			MOVQ R8, 0x3c0(DI)														
  rwmutex.go:72				0xaaa280		4189cb				MOVL CX, R11															
  db.go:1890				0xaaa283		4c8b87c0050000			MOVQ 0x5c0(DI), R8														
  db.go:1890				0xaaa28a		4c898424b0000000		MOVQ R8, 0xb0(SP)														
  db.go:1890				0xaaa292		31c9				XORL CX, CX															
  db.go:1890				0xaaa294		eb6a				JMP 0xaaa300															
  db.go:1890				0xaaa296		48898c24a0000000		MOVQ CX, 0xa0(SP)														
  db.go:1892				0xaaa29e		488b97b8050000			MOVQ 0x5b8(DI), DX														
  db.go:1892				0xaaa2a5		4a8d042a			LEAQ 0(DX)(R13*1), AX														
  db.go:1892				0xaaa2a9		488d4008			LEAQ 0x8(AX), AX														
  db.go:1892				0xaaa2ad		31db				XORL BX, BX															
  db.go:1892				0xaaa2af		31c9				XORL CX, CX															
  db.go:1892				0xaaa2b1		31ff				XORL DI, DI															
  db.go:1892				0xaaa2b3		31f6				XORL SI, SI															
  db.go:1892				0xaaa2b5		e886bcc2ff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB)									
  db.go:1890				0xaaa2ba		488b8c24a0000000		MOVQ 0xa0(SP), CX														
  db.go:1890				0xaaa2c2		48ffc1				INCQ CX																
  db.go:1899				0xaaa2c5		488b842490000000		MOVQ 0x90(SP), AX														
  db.go:1902				0xaaa2cd		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1891				0xaaa2d5		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1890				0xaaa2dd		4c8b8424b0000000		MOVQ 0xb0(SP), R8														
  db.go:1901				0xaaa2e5		4c8b8c2468010000		MOVQ 0x168(SP), R9														
  db.go:1915				0xaaa2ed		4c8b942470010000		MOVQ 0x170(SP), R10														
  rwmutex.go:72				0xaaa2f5		440fb69c24e0010000		MOVZX 0x1e0(SP), R11														
  rwmutex.go:72				0xaaa2fe		6690				NOPW																
  db.go:1890				0xaaa300		4c39c1				CMPQ CX, R8															
  db.go:1890				0xaaa303		7d40				JGE 0xaaa345															
  db.go:1891				0xaaa305		4c8ba7c0050000			MOVQ 0x5c0(DI), R12														
  db.go:1891				0xaaa30c		4c39e1				CMPQ CX, R12															
  db.go:1891				0xaaa30f		0f83f8010000			JAE 0xaaa50d															
  db.go:1891				0xaaa315		4c8ba7b8050000			MOVQ 0x5b8(DI), R12														
  db.go:1891				0xaaa31c		4c69e9f8000000			IMULQ $0xf8, CX, R13														
  db.go:1891				0xaaa323		4bc7042c00000000		MOVQ $0x0, 0(R12)(R13*1)													
  db.go:1892				0xaaa32b		4c8ba7c0050000			MOVQ 0x5c0(DI), R12														
  db.go:1892				0xaaa332		4c39e1				CMPQ CX, R12															
  db.go:1892				0xaaa335		0f825bffffff			JB 0xaaa296															
  db.go:1892				0xaaa33b		0f1f440000			NOPL 0(AX)(AX*1)														
  db.go:1892				0xaaa340		e9c3010000			JMP 0xaaa508															
  db.go:1894				0xaaa345		4883bfc805000010		CMPQ 0x5c8(DI), $0x10														
  db.go:1894				0xaaa34d		7e35				JLE 0xaaa384															
  db.go:1895				0xaaa34f		440f11bfc0050000		MOVUPS X15, 0x5c0(DI)														
  db.go:1895				0xaaa357		833dc231480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1895				0xaaa35e		6690				NOPW																
  db.go:1895				0xaaa360		7415				JE 0xaaa377															
  db.go:1895				0xaaa362		4c8b87b8050000			MOVQ 0x5b8(DI), R8														
  rwmutex.go:72				0xaaa369		4489d9				MOVL R11, CX															
  db.go:1895				0xaaa36c		e8cf9e9eff			CALL runtime.gcWriteBarrier1(SB)												
  db.go:1895				0xaaa371		4d8903				MOVQ R8, 0(R11)															
  rwmutex.go:72				0xaaa374		4189cb				MOVL CX, R11															
  db.go:1895				0xaaa377		48c787b805000000000000		MOVQ $0x0, 0x5b8(DI)														
  db.go:1895				0xaaa382		eb0b				JMP 0xaaa38f															
  db.go:1897				0xaaa384		48c787c005000000000000		MOVQ $0x0, 0x5c0(DI)														
  db.go:1899				0xaaa38f		488987a8030000			MOVQ AX, 0x3a8(DI)														
  db.go:1901				0xaaa396		498b5930			MOVQ 0x30(R9), BX														
  db.go:1901				0xaaa39a		660f1f440000			NOPW 0(AX)(AX*1)														
  db.go:1901				0xaaa3a0		48399f10060000			CMPQ 0x610(DI), BX														
  db.go:1901				0xaaa3a7		7511				JNE 0xaaa3ba															
  db.go:1902				0xaaa3a9		4c8b8718060000			MOVQ 0x618(DI), R8														
  db.go:1902				0xaaa3b0		4c394210			CMPQ 0x10(DX), R8														
  db.go:1903				0xaaa3b4		0f8486000000			JE 0xaaa440															
  db.go:1904				0xaaa3ba		488d87c8030000			LEAQ 0x3c8(DI), AX														
  db.go:1904				0xaaa3c1		4881c7b0030000			ADDQ $0x3b0, DI															
  db.go:1904				0xaaa3c8		488b7210			MOVQ 0x10(DX), SI														
  db.go:1904				0xaaa3cc		488d0d8d794101			LEAQ go:itab.*github.com/snissn/gomap/TreeDB/db.valueReader,github.com/snissn/gomap/TreeDB/tree.SlabReader(SB), CX		
  db.go:1904				0xaaa3d3		e868bbc2ff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB)									
  db.go:1905				0xaaa3d8		488b942468010000		MOVQ 0x168(SP), DX														
  db.go:1905				0xaaa3e0		488b5230			MOVQ 0x30(DX), DX														
  db.go:1905				0xaaa3e4		833d3531480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1905				0xaaa3eb		750a				JNE 0xaaa3f7															
  db.go:1905				0xaaa3ed		488b8424d8010000		MOVQ 0x1d8(SP), AX														
  db.go:1905				0xaaa3f5		eb1b				JMP 0xaaa412															
  db.go:1905				0xaaa3f7		488b8424d8010000		MOVQ 0x1d8(SP), AX														
  db.go:1905				0xaaa3ff		488b8810060000			MOVQ 0x610(AX), CX														
  db.go:1905				0xaaa406		e8559e9eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1905				0xaaa40b		498913				MOVQ DX, 0(R11)															
  db.go:1905				0xaaa40e		49894b08			MOVQ CX, 0x8(R11)														
  db.go:1905				0xaaa412		48899010060000			MOVQ DX, 0x610(AX)														
  db.go:1906				0xaaa419		488b8c2460010000		MOVQ 0x160(SP), CX														
  db.go:1906				0xaaa421		488b4910			MOVQ 0x10(CX), CX														
  db.go:1906				0xaaa425		48898818060000			MOVQ CX, 0x618(AX)														
  negative_filter.go:55			0xaaa42c		4889c7				MOVQ AX, DI															
  db.go:1915				0xaaa42f		4c8b942470010000		MOVQ 0x170(SP), R10														
  rwmutex.go:72				0xaaa437		440fb69c24e0010000		MOVZX 0x1e0(SP), R11														
  db.go:1915				0xaaa440		498b0a				MOVQ 0(R10), CX															
  negative_filter.go:55			0xaaa443		833dd630480200			CMPL runtime.writeBarrier(SB), $0x0												
  negative_filter.go:55			0xaaa44a		7505				JNE 0xaaa451															
  rwmutex.go:72				0xaaa44c		4584db				TESTL R11, R11															
  negative_filter.go:55			0xaaa44f		eb20				JMP 0xaaa471															
  negative_filter.go:55			0xaaa451		488b97c8030000			MOVQ 0x3c8(DI), DX														
  rwmutex.go:72				0xaaa458		4489d8				MOVL R11, AX															
  rwmutex.go:72				0xaaa45b		0f1f440000			NOPL 0(AX)(AX*1)														
  negative_filter.go:55			0xaaa460		e8fb9d9eff			CALL runtime.gcWriteBarrier2(SB)												
  negative_filter.go:55			0xaaa465		49890b				MOVQ CX, 0(R11)															
  negative_filter.go:55			0xaaa468		49895308			MOVQ DX, 0x8(R11)														
  rwmutex.go:72				0xaaa46c		84c0				TESTL AL, AL															
  rwmutex.go:72				0xaaa46e		4189c3				MOVL AX, R11															
  negative_filter.go:55			0xaaa471		48898fc8030000			MOVQ CX, 0x3c8(DI)														
  db.go:1918				0xaaa478		753d				JNE 0xaaa4b7															
  db.go:1919				0xaaa47a		90				NOPL																
  mutex.go:63				0xaaa47b		31c0				XORL AX, AX															
  mutex.go:63				0xaaa47d		b901000000			MOVL $0x1, CX															
  mutex.go:63				0xaaa482		f00fb18ff0050000		LOCK CMPXCHGL CX, 0x5f0(DI)													
  mutex.go:63				0xaaa48a		0f94c1				SETE CL																
  mutex.go:63				0xaaa48d		84c9				TESTL CL, CL															
  mutex.go:63				0xaaa48f		7405				JE 0xaaa496															
  rwmutex.go:72				0xaaa491		4584db				TESTL R11, R11															
  mutex.go:46				0xaaa494		eb21				JMP 0xaaa4b7															
  mutex.go:46				0xaaa496		488d87f0050000			LEAQ 0x5f0(DI), AX														
  mutex.go:70				0xaaa49d		0f1f00				NOPL 0(AX)															
  mutex.go:70				0xaaa4a0		e83b1e9fff			CALL internal/sync.(*Mutex).lockSlow(SB)											
  rwmutex.go:72				0xaaa4a5		0fb68c24e0010000		MOVZX 0x1e0(SP), CX														
  rwmutex.go:72				0xaaa4ad		84c9				TESTL CL, CL															
  type.go:22				0xaaa4af		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1921				0xaaa4b7		90				NOPL																
  type.go:22				0xaaa4b8		b900000000			MOVL $0x0, CX															
  type.go:22				0xaaa4bd		878fd0050000			XCHGL CX, 0x5d0(DI)														
  db.go:1922				0xaaa4c3		90				NOPL																
  type.go:184				0xaaa4c4		b900000000			MOVL $0x0, CX															
  type.go:184				0xaaa4c9		48878fe8050000			XCHGQ CX, 0x5e8(DI)														
  db.go:1923				0xaaa4d0		751e				JNE 0xaaa4f0															
  db.go:1924				0xaaa4d2		90				NOPL																
  mutex.go:194				0xaaa4d3		bbffffffff			MOVL $-0x1, BX															
  mutex.go:194				0xaaa4d8		f00fc19ff0050000		LOCK XADDL BX, 0x5f0(DI)													
  mutex.go:194				0xaaa4e0		ffcb				DECL BX																
  mutex.go:195				0xaaa4e2		740c				JE 0xaaa4f0															
  mutex.go:65				0xaaa4e4		488d87f0050000			LEAQ 0x5f0(DI), AX														
  mutex.go:198				0xaaa4eb		e8d0209fff			CALL internal/sync.(*Mutex).unlockSlow(SB)											
  db.go:1926				0xaaa4f0		c644242d01			MOVB $0x1, 0x2d(SP)														
  db.go:1927				0xaaa4f5		e8266b9aff			CALL runtime.deferreturn(SB)													
  db.go:1926				0xaaa4fa		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa4ff		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa506		5d				POPQ BP																
  db.go:1927				0xaaa507		c3				RET																
  db.go:1892				0xaaa508		e8f3a09eff			CALL runtime.panicBounds(SB)													
  db.go:1891				0xaaa50d		e8eea09eff			CALL runtime.panicBounds(SB)													
  index_gen.go:237			0xaaa512		488d05873b0b01			LEAQ 0x10b3b87(IP), AX														
  index_gen.go:237			0xaaa519		488d1d207d4001			LEAQ 0x1407d20(IP), BX														
  index_gen.go:237			0xaaa520		e8bb1c9eff			CALL runtime.gopanic(SB)													
  db.go:1899				0xaaa525		488b842490000000		MOVQ 0x90(SP), AX														
  db.go:1876				0xaaa52d		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1873				0xaaa535		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1873				0xaaa53d		0f1f00				NOPL 0(AX)															
  db.go:1873				0xaaa540		e981fbffff			JMP 0xaaa0c6															
  leaf_generation_runtime.go:240	0xaaa545		48ffc1				INCQ CX																
  leaf_generation_runtime.go:240	0xaaa548		4839d1				CMPQ CX, DX															
  leaf_generation_runtime.go:240	0xaaa54b		7d17				JGE 0xaaa564															
  leaf_generation_runtime.go:240	0xaaa54d		4d8b04c9			MOVQ 0(R9)(CX*8), R8														
  leaf_generation_runtime.go:241	0xaaa551		4d85c0				TESTQ R8, R8															
  leaf_generation_runtime.go:241	0xaaa554		74ef				JE 0xaaa545															
  type.go:128				0xaaa556		41ba01000000			MOVL $0x1, R10															
  type.go:128				0xaaa55c		f04d0fc15008			LOCK XADDQ R10, 0x8(R8)														
  leaf_generation_runtime.go:244	0xaaa562		ebe1				JMP 0xaaa545															
  db.go:1859				0xaaa564		488b9060030000			MOVQ 0x360(AX), DX														
  db.go:1859				0xaaa56b		4c8b8068030000			MOVQ 0x368(AX), R8														
  db.go:1859				0xaaa572		4c8b8858030000			MOVQ 0x358(AX), R9														
  db.go:1859				0xaaa579		48899078030000			MOVQ DX, 0x378(AX)														
  db.go:1859				0xaaa580		4c898080030000			MOVQ R8, 0x380(AX)														
  db.go:1859				0xaaa587		833d922f480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1859				0xaaa58e		7413				JE 0xaaa5a3															
  db.go:1859				0xaaa590		488b9070030000			MOVQ 0x370(AX), DX														
  db.go:1859				0xaaa597		e8c49c9eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1859				0xaaa59c		4d890b				MOVQ R9, 0(R11)															
  db.go:1859				0xaaa59f		49895308			MOVQ DX, 0x8(R11)														
  db.go:1859				0xaaa5a3		4c898870030000			MOVQ R9, 0x370(AX)														
  db.go:1859				0xaaa5aa		e976ffffff			JMP 0xaaa525															
  db.go:1768				0xaaa5af		4889442408			MOVQ AX, 0x8(SP)														
  db.go:1768				0xaaa5b4		48895c2410			MOVQ BX, 0x10(SP)														
  db.go:1768				0xaaa5b9		884c2418			MOVB CL, 0x18(SP)														
  db.go:1768				0xaaa5bd		0f1f00				NOPL 0(AX)															
  db.go:1768				0xaaa5c0		e89b819eff			CALL runtime.morestack_noctxt.abi0(SB)												
  db.go:1768				0xaaa5c5		488b442408			MOVQ 0x8(SP), AX														
  db.go:1768				0xaaa5ca		488b5c2410			MOVQ 0x10(SP), BX														
  db.go:1768				0xaaa5cf		0fb64c2418			MOVZX 0x18(SP), CX														
  db.go:1768				0xaaa5d4		e947f2ffff			JMP github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld(SB)				

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.func2(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:1812		0xaaa5e0		493b6610		CMPQ SP, 0x10(R14)												
  db.go:1812		0xaaa5e4		762a			JBE 0xaaa610													
  db.go:1812		0xaaa5e6		55			PUSHQ BP													
  db.go:1812		0xaaa5e7		4889e5			MOVQ SP, BP													
  db.go:1812		0xaaa5ea		4883ec10		SUBQ $0x10, SP													
  db.go:1812		0xaaa5ee		488b4a08		MOVQ 0x8(DX), CX												
  db.go:1813		0xaaa5f2		803900			CMPB 0(CX), $0x0												
  db.go:1813		0xaaa5f5		7513			JNE 0xaaa60a													
  db.go:1812		0xaaa5f7		488b4210		MOVQ 0x10(DX), AX												
  db.go:1814		0xaaa5fb		8400			TESTB AL, 0(AX)													
  db.go:1812		0xaaa5fd		488b5a18		MOVQ 0x18(DX), BX												
  db.go:1814		0xaaa601		4883c058		ADDQ $0x58, AX													
  db.go:1814		0xaaa605		e816bbd7ff		CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*ManagerWrapperReleaseWork).ReleaseOriginal(SB)		
  db.go:1816		0xaaa60a		4883c410		ADDQ $0x10, SP													
  db.go:1816		0xaaa60e		5d			POPQ BP														
  db.go:1816		0xaaa60f		c3			RET														
  db.go:1812		0xaaa610		e8ab809eff		CALL runtime.morestack.abi0(SB)											
  db.go:1812		0xaaa615		ebc9			JMP github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.func2(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.func1(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:1780		0xaaa620		55			PUSHQ BP			
  db.go:1780		0xaaa621		4889e5			MOVQ SP, BP			
  db.go:1780		0xaaa624		488b4210		MOVQ 0x10(DX), AX		
  db.go:1780		0xaaa628		488b4a08		MOVQ 0x8(DX), CX		
  db.go:1783		0xaaa62c		90			NOPL				
  type.go:195		0xaaa62d		ba01000000		MOVL $0x1, DX			
  type.go:195		0xaaa632		f0480fc19138040000	LOCK XADDQ DX, 0x438(CX)	
  type.go:195		0xaaa63b		0f1f440000		NOPL 0(AX)(AX*1)		
  db.go:1784		0xaaa640		483d00010000		CMPQ AX, $0x100			
  db.go:1784		0xaaa646		7313			JAE 0xaaa65b			
  type.go:94		0xaaa648		488d0481		LEAQ 0(CX)(AX*4), AX		
  type.go:94		0xaaa64c		488d4038		LEAQ 0x38(AX), AX		
  type.go:94		0xaaa650		b9ffffffff		MOVL $-0x1, CX			
  type.go:94		0xaaa655		f00fc108		LOCK XADDL CX, 0(AX)		
  db.go:1785		0xaaa659		5d			POPQ BP				
  db.go:1785		0xaaa65a		c3			RET				
  db.go:1784		0xaaa65b		48c7c100010000		MOVQ $0x100, CX			
  db.go:1784		0xaaa662		e8999f9eff		CALL runtime.panicBounds(SB)	
  db.go:1784		0xaaa667		90			NOPL				

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.deferwrap1(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:1770		0xaaa680		493b6610		CMPQ SP, 0x10(R14)													
  db.go:1770		0xaaa684		7629			JBE 0xaaa6af														
  db.go:1770		0xaaa686		55			PUSHQ BP														
  db.go:1770		0xaaa687		4889e5			MOVQ SP, BP														
  db.go:1770		0xaaa68a		4883ec10		SUBQ $0x10, SP														
  db.go:1770		0xaaa68e		488b4208		MOVQ 0x8(DX), AX													
  type.go:94		0xaaa692		bbffffffff		MOVL $-0x1, BX														
  type.go:94		0xaaa697		f00fc15810		LOCK XADDL BX, 0x10(AX)													
  type.go:94		0xaaa69c		ffcb			DECL BX															
  type.go:94		0xaaa69e		6690			NOPW															
  rwmutex.go:120	0xaaa6a0		85db			TESTL BX, BX														
  rwmutex.go:120	0xaaa6a2		7d05			JGE 0xaaa6a9														
  rwmutex.go:122	0xaaa6a4		e897319fff		CALL sync.(*RWMutex).rUnlockSlow(SB)											
  db.go:1770		0xaaa6a9		4883c410		ADDQ $0x10, SP														
  db.go:1770		0xaaa6ad		5d			POPQ BP															
  db.go:1770		0xaaa6ae		c3			RET															
  db.go:1770		0xaaa6af		e80c809eff		CALL runtime.morestack.abi0(SB)												
  db.go:1770		0xaaa6b4		ebca			JMP github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:2234				0xaac2a0		493b6610		CMPQ SP, 0x10(R14)								
  db.go:2234				0xaac2a4		0f8690010000		JBE 0xaac43a									
  db.go:2234				0xaac2aa		55			PUSHQ BP									
  db.go:2234				0xaac2ab		4889e5			MOVQ SP, BP									
  db.go:2234				0xaac2ae		4883ec78		SUBQ $0x78, SP									
  db.go:2235				0xaac2b2		4885c0			TESTQ AX, AX									
  db.go:2235				0xaac2b5		0f8408010000		JE 0xaac3c3									
  db.go:2238				0xaac2bb		80784300		CMPB 0x43(AX), $0x0								
  db.go:2238				0xaac2bf		90			NOPL										
  db.go:2238				0xaac2c0		0f85e9000000		JNE 0xaac3af									
  db.go:2235				0xaac2c6		4889842488000000	MOVQ AX, 0x88(SP)								
  db.go:2235				0xaac2ce		889c2490000000		MOVB BL, 0x90(SP)								
  db.go:2235				0xaac2d5		84db			TESTL BL, BL									
  db.go:2241				0xaac2d7		7405			JE 0xaac2de									
  type.go:29				0xaac2d9		4889c1			MOVQ AX, CX									
  db.go:2241				0xaac2dc		eb37			JMP 0xaac315									
  db.go:2242				0xaac2de		90			NOPL										
  db.go:2235				0xaac2df		4889c1			MOVQ AX, CX									
  mutex.go:63				0xaac2e2		31c0			XORL AX, AX									
  mutex.go:63				0xaac2e4		ba01000000		MOVL $0x1, DX									
  mutex.go:63				0xaac2e9		f00fb191f0050000	LOCK CMPXCHGL DX, 0x5f0(CX)							
  mutex.go:63				0xaac2f1		0f94c2			SETE DL										
  mutex.go:63				0xaac2f4		84d2			TESTL DL, DL									
  mutex.go:63				0xaac2f6		751d			JNE 0xaac315									
  mutex.go:46				0xaac2f8		488d81f0050000		LEAQ 0x5f0(CX), AX								
  mutex.go:70				0xaac2ff		90			NOPL										
  mutex.go:70				0xaac300		e8dbff9eff		CALL internal/sync.(*Mutex).lockSlow(SB)					
  type.go:29				0xaac305		488b8c2488000000	MOVQ 0x88(SP), CX								
  db.go:2235				0xaac30d		0fb69c2490000000	MOVZX 0x90(SP), BX								
  type.go:29				0xaac315		31c0			XORL AX, AX									
  type.go:29				0xaac317		ba01000000		MOVL $0x1, DX									
  type.go:29				0xaac31c		f00fb191d0050000	LOCK CMPXCHGL DX, 0x5d0(CX)							
  type.go:29				0xaac324		0f94c2			SETE DL										
  type.go:29				0xaac327		84d2			TESTL DL, DL									
  db.go:2244				0xaac329		7457			JE 0xaac382									
  type.go:203				0xaac32b		488d91e8050000		LEAQ 0x5e8(CX), DX								
  db.go:2250				0xaac332		90			NOPL										
  type.go:203				0xaac333		48be0000000000000080	MOVQ $0x8000000000000000, SI							
  type.go:203				0xaac33d		f0480932		LOCK ORQ SI, 0(DX)								
  db.go:2235				0xaac341		84db			TESTL BL, BL									
  db.go:2251				0xaac343		0f8584000000		JNE 0xaac3cd									
  snapshot_iterator_lifetime.go:63	0xaac349		488b99f8050000		MOVQ 0x5f8(CX), BX								
  db.go:2252				0xaac350		90			NOPL										
  snapshot_iterator_lifetime.go:63	0xaac351		488d4c2418		LEAQ 0x18(SP), CX								
  snapshot_iterator_lifetime.go:63	0xaac356		440f1139		MOVUPS X15, 0(CX)								
  snapshot_iterator_lifetime.go:63	0xaac35a		440f117910		MOVUPS X15, 0x10(CX)								
  snapshot_iterator_lifetime.go:63	0xaac35f		440f117920		MOVUPS X15, 0x20(CX)								
  snapshot_iterator_lifetime.go:63	0xaac364		440f117930		MOVUPS X15, 0x30(CX)								
  snapshot_iterator_lifetime.go:63	0xaac369		440f117940		MOVUPS X15, 0x40(CX)								
  snapshot_iterator_lifetime.go:63	0xaac36e		440f117950		MOVUPS X15, 0x50(CX)								
  snapshot_iterator_lifetime.go:63	0xaac373		488d0586471201		LEAQ 0x1124786(IP), AX								
  snapshot_iterator_lifetime.go:63	0xaac37a		e8018e97ff		CALL runtime.mapIterStart(SB)							
  snapshot_iterator_lifetime.go:63	0xaac37f		90			NOPL										
  snapshot_iterator_lifetime.go:63	0xaac380		eb6f			JMP 0xaac3f1									
  db.go:2235				0xaac382		84db			TESTL BL, BL									
  db.go:2245				0xaac384		751f			JNE 0xaac3a5									
  db.go:2246				0xaac386		90			NOPL										
  mutex.go:194				0xaac387		bbffffffff		MOVL $-0x1, BX									
  mutex.go:194				0xaac38c		f00fc199f0050000	LOCK XADDL BX, 0x5f0(CX)							
  mutex.go:194				0xaac394		ffcb			DECL BX										
  mutex.go:195				0xaac396		740d			JE 0xaac3a5									
  mutex.go:65				0xaac398		488d81f0050000		LEAQ 0x5f0(CX), AX								
  mutex.go:198				0xaac39f		90			NOPL										
  mutex.go:198				0xaac3a0		e81b029fff		CALL internal/sync.(*Mutex).unlockSlow(SB)					
  db.go:2248				0xaac3a5		31c0			XORL AX, AX									
  db.go:2248				0xaac3a7		31db			XORL BX, BX									
  db.go:2248				0xaac3a9		4883c478		ADDQ $0x78, SP									
  db.go:2248				0xaac3ad		5d			POPQ BP										
  db.go:2248				0xaac3ae		c3			RET										
  db.go:2239				0xaac3af		488b05aa383602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrNativeMVCCSnapshotWork(SB), AX	
  db.go:2239				0xaac3b6		488b1dab383602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrNativeMVCCSnapshotWork+8(SB), BX	
  db.go:2239				0xaac3bd		4883c478		ADDQ $0x78, SP									
  db.go:2239				0xaac3c1		5d			POPQ BP										
  db.go:2239				0xaac3c2		c3			RET										
  db.go:2236				0xaac3c3		31c0			XORL AX, AX									
  db.go:2236				0xaac3c5		31db			XORL BX, BX									
  db.go:2236				0xaac3c7		4883c478		ADDQ $0x78, SP									
  db.go:2236				0xaac3cb		5d			POPQ BP										
  db.go:2236				0xaac3cc		c3			RET										
  db.go:2255				0xaac3cd		4889c8			MOVQ CX, AX									
  db.go:2255				0xaac3d0		e88b000000		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead(SB)	
  db.go:2255				0xaac3d5		4883c478		ADDQ $0x78, SP									
  db.go:2255				0xaac3d9		5d			POPQ BP										
  db.go:2255				0xaac3da		c3			RET										
  snapshot_iterator_lifetime.go:63	0xaac3db		488b09			MOVQ 0(CX), CX									
  snapshot_iterator_lifetime.go:64	0xaac3de		90			NOPL										
  type.go:22				0xaac3df		ba01000000		MOVL $0x1, DX									
  type.go:22				0xaac3e4		875118			XCHGL DX, 0x18(CX)								
  snapshot_iterator_lifetime.go:63	0xaac3e7		488d442418		LEAQ 0x18(SP), AX								
  snapshot_iterator_lifetime.go:63	0xaac3ec		e8ef8d97ff		CALL runtime.mapIterNext(SB)							
  snapshot_iterator_lifetime.go:63	0xaac3f1		488b4c2418		MOVQ 0x18(SP), CX								
  snapshot_iterator_lifetime.go:63	0xaac3f6		4885c9			TESTQ CX, CX									
  snapshot_iterator_lifetime.go:63	0xaac3f9		75e0			JNE 0xaac3db									
  db.go:2253				0xaac3fb		90			NOPL										
  mutex.go:194				0xaac3fc		bbffffffff		MOVL $-0x1, BX									
  mutex.go:194				0xaac401		488b842488000000	MOVQ 0x88(SP), AX								
  mutex.go:194				0xaac409		f00fc198f0050000	LOCK XADDL BX, 0x5f0(AX)							
  mutex.go:194				0xaac411		ffcb			DECL BX										
  mutex.go:195				0xaac413		7418			JE 0xaac42d									
  mutex.go:65				0xaac415		4805f0050000		ADDQ $0x5f0, AX									
  mutex.go:198				0xaac41b		0f1f440000		NOPL 0(AX)(AX*1)								
  mutex.go:198				0xaac420		e89b019fff		CALL internal/sync.(*Mutex).unlockSlow(SB)					
  db.go:2255				0xaac425		488b842488000000	MOVQ 0x88(SP), AX								
  db.go:2255				0xaac42d		4889c1			MOVQ AX, CX									
  db.go:2255				0xaac430		0fb69c2490000000	MOVZX 0x90(SP), BX								
  mutex.go:65				0xaac438		eb93			JMP 0xaac3cd									
  db.go:2234				0xaac43a		4889442408		MOVQ AX, 0x8(SP)								
  db.go:2234				0xaac43f		885c2410		MOVB BL, 0x10(SP)								
  db.go:2234				0xaac443		e818639eff		CALL runtime.morestack_noctxt.abi0(SB)						
  db.go:2234				0xaac448		488b442408		MOVQ 0x8(SP), AX								
  db.go:2234				0xaac44d		0fb65c2410		MOVZX 0x10(SP), BX								
  db.go:2234				0xaac452		e949feffff		JMP github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead(SB)			

TEXT github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:2262		0xaac460		4c8da424a8fdffff	LEAQ 0xfffffda8(SP), R12										
  db.go:2262		0xaac468		4d3b6610		CMPQ R12, 0x10(R14)											
  db.go:2262		0xaac46c		0f868a170000		JBE 0xaadbfc												
  db.go:2262		0xaac472		55			PUSHQ BP												
  db.go:2262		0xaac473		4889e5			MOVQ SP, BP												
  db.go:2262		0xaac476		4881ecd0020000		SUBQ $0x2d0, SP												
  db.go:2263		0xaac47d		80784300		CMPB 0x43(AX), $0x0											
  db.go:2263		0xaac481		0f85cd020000		JNE 0xaac754												
  db.go:2263		0xaac487		48898424e0020000	MOVQ AX, 0x2e0(SP)											
  db.go:2263		0xaac48f		889c24e8020000		MOVB BL, 0x2e8(SP)											
  db.go:2263		0xaac496		84db			TESTL BL, BL												
  db.go:2266		0xaac498		7405			JE 0xaac49f												
  db.go:2269		0xaac49a		4889c1			MOVQ AX, CX												
  db.go:2266		0xaac49d		eb36			JMP 0xaac4d5												
  db.go:2267		0xaac49f		90			NOPL													
  db.go:2263		0xaac4a0		4889c1			MOVQ AX, CX												
  mutex.go:63		0xaac4a3		31c0			XORL AX, AX												
  mutex.go:63		0xaac4a5		ba01000000		MOVL $0x1, DX												
  mutex.go:63		0xaac4aa		f00fb191f0050000	LOCK CMPXCHGL DX, 0x5f0(CX)										
  mutex.go:63		0xaac4b2		0f94c2			SETE DL													
  mutex.go:63		0xaac4b5		84d2			TESTL DL, DL												
  mutex.go:63		0xaac4b7		751c			JNE 0xaac4d5												
  mutex.go:46		0xaac4b9		488d81f0050000		LEAQ 0x5f0(CX), AX											
  mutex.go:70		0xaac4c0		e81bfe9eff		CALL internal/sync.(*Mutex).lockSlow(SB)								
  db.go:2269		0xaac4c5		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2263		0xaac4cd		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2269		0xaac4d5		488b91f8050000		MOVQ 0x5f8(CX), DX											
  db.go:2269		0xaac4dc		0f1f4000		NOPL 0(AX)												
  db.go:2269		0xaac4e0		4885d2			TESTQ DX, DX												
  db.go:2269		0xaac4e3		7405			JE 0xaac4ea												
  db.go:2269		0xaac4e5		488b12			MOVQ 0(DX), DX												
  db.go:2269		0xaac4e8		eb02			JMP 0xaac4ec												
  db.go:2269		0xaac4ea		31d2			XORL DX, DX												
  db.go:2269		0xaac4ec		4885d2			TESTQ DX, DX												
  db.go:2269		0xaac4ef		7407			JE 0xaac4f8												
  db.go:2269		0xaac4f1		ba01000000		MOVL $0x1, DX												
  db.go:2269		0xaac4f6		eb17			JMP 0xaac50f												
  type.go:181		0xaac4f8		488b91e8050000		MOVQ 0x5e8(CX), DX											
  db.go:2269		0xaac4ff		49b80000000000000080	MOVQ $0x8000000000000000, R8										
  db.go:2269		0xaac509		4c39c2			CMPQ DX, R8												
  db.go:2269		0xaac50c		0f95c2			SETNE DL												
  db.go:2269		0xaac50f		84d2			TESTL DL, DL												
  db.go:2269		0xaac511		7407			JE 0xaac51a												
  db.go:2269		0xaac513		ba01000000		MOVL $0x1, DX												
  db.go:2269		0xaac518		eb15			JMP 0xaac52f												
  type.go:29		0xaac51a		31c0			XORL AX, AX												
  type.go:29		0xaac51c		ba01000000		MOVL $0x1, DX												
  type.go:29		0xaac521		f00fb191e0050000	LOCK CMPXCHGL DX, 0x5e0(CX)										
  type.go:29		0xaac529		0f94c2			SETE DL													
  db.go:2269		0xaac52c		83f201			XORL $0x1, DX												
  db.go:2269		0xaac52f		84d2			TESTL DL, DL												
  db.go:2269		0xaac531		0f85ee010000		JNE 0xaac725												
  db.go:2275		0xaac537		488b9130030000		MOVQ 0x330(CX), DX											
  db.go:2275		0xaac53e		4c8b8128030000		MOVQ 0x328(CX), R8											
  db.go:2276		0xaac545		4c8b8940030000		MOVQ 0x340(CX), R9											
  db.go:2276		0xaac54c		440fb69148030000	MOVZX 0x348(CX), R10											
  db.go:2277		0xaac554		440fb699d0020000	MOVZX 0x2d0(CX), R11											
  db.go:2278		0xaac55c		c681d002000000		MOVB $0x0, 0x2d0(CX)											
  db.go:2279		0xaac563		4c8ba138060000		MOVQ 0x638(CX), R12											
  db.go:2280		0xaac56a		833daf0f480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2280		0xaac571		7418			JE 0xaac58b												
  db.go:2280		0xaac573		4c8ba938060000		MOVQ 0x638(CX), R13											
  db.go:2277		0xaac57a		4489d8			MOVL R11, AX												
  db.go:2277		0xaac57d		0f1f00			NOPL 0(AX)												
  db.go:2280		0xaac580		e8bb7c9eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2280		0xaac585		4d892b			MOVQ R13, 0(R11)											
  db.go:2277		0xaac588		4189c3			MOVL AX, R11												
  db.go:2280		0xaac58b		48c7813806000000000000	MOVQ $0x0, 0x638(CX)											
  db.go:2281		0xaac596		4c8ba908060000		MOVQ 0x608(CX), R13											
  db.go:2282		0xaac59d		833d7c0f480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2282		0xaac5a4		7504			JNE 0xaac5aa												
  db.go:2263		0xaac5a6		84db			TESTL BL, BL												
  db.go:2282		0xaac5a8		eb17			JMP 0xaac5c1												
  db.go:2282		0xaac5aa		4c8bb908060000		MOVQ 0x608(CX), R15											
  db.go:2277		0xaac5b1		4489d8			MOVL R11, AX												
  db.go:2282		0xaac5b4		e8877c9eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2282		0xaac5b9		4d893b			MOVQ R15, 0(R11)											
  db.go:2263		0xaac5bc		84db			TESTL BL, BL												
  db.go:2277		0xaac5be		4189c3			MOVL AX, R11												
  db.go:2275		0xaac5c1		4889942428010000	MOVQ DX, 0x128(SP)											
  db.go:2275		0xaac5c9		4c89842430010000	MOVQ R8, 0x130(SP)											
  db.go:2276		0xaac5d1		4c898c2420010000	MOVQ R9, 0x120(SP)											
  db.go:2279		0xaac5d9		4c89a42410010000	MOVQ R12, 0x110(SP)											
  db.go:2281		0xaac5e1		4c89ac2488010000	MOVQ R13, 0x188(SP)											
  db.go:2276		0xaac5e9		4488542447		MOVB R10, 0x47(SP)											
  db.go:2277		0xaac5ee		44885c2446		MOVB R11, 0x46(SP)											
  db.go:2282		0xaac5f3		48c7810806000000000000	MOVQ $0x0, 0x608(CX)											
  db.go:2283		0xaac5fe		c6810006000000		MOVB $0x0, 0x600(CX)											
  db.go:2284		0xaac605		7568			JNE 0xaac66f												
  db.go:2285		0xaac607		90			NOPL													
  mutex.go:194		0xaac608		41bfffffffff		MOVL $-0x1, R15												
  mutex.go:194		0xaac60e		f0440fc1b9f0050000	LOCK XADDL R15, 0x5f0(CX)										
  mutex.go:194		0xaac617		41ffcf			DECL R15												
  mutex.go:195		0xaac61a		7453			JE 0xaac66f												
  mutex.go:65		0xaac61c		488d81f0050000		LEAQ 0x5f0(CX), AX											
  mutex.go:198		0xaac623		4489fb			MOVL R15, BX												
  mutex.go:198		0xaac626		e895ff9eff		CALL internal/sync.(*Mutex).unlockSlow(SB)								
  db.go:2289		0xaac62b		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2386		0xaac633		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaac63b		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2387		0xaac643		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaac64b		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaac653		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaac659		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaac65f		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaac667		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2289		0xaac66f		4c8bb9b0020000		MOVQ 0x2b0(CX), R15											
  db.go:2288		0xaac676		488b81a8020000		MOVQ 0x2a8(CX), AX											
  db.go:2288		0xaac67d		488bb1a0020000		MOVQ 0x2a0(CX), SI											
  db.go:2289		0xaac684		4d85ff			TESTQ R15, R15												
  db.go:2289		0xaac687		0f8491000000		JE 0xaac71e												
  db.go:2289		0xaac68d		4885f6			TESTQ SI, SI												
  db.go:2289		0xaac690		740a			JE 0xaac69c												
  db.go:2289		0xaac692		31ff			XORL DI, DI												
  db.go:2289		0xaac694		4531ff			XORL R15, R15												
  db.go:2289		0xaac697		e9c5000000		JMP 0xaac761												
  db.go:2290		0xaac69c		498b3f			MOVQ 0(R15), DI												
  db.go:2291		0xaac69f		4883b90803000000	CMPQ 0x308(CX), $0x0											
  db.go:2291		0xaac6a7		7452			JE 0xaac6fb												
  db.go:2290		0xaac6a9		4889bc24c8010000	MOVQ DI, 0x1c8(SP)											
  db.go:2294		0xaac6b1		498b5710		MOVQ 0x10(R15), DX											
  db.go:2294		0xaac6b5		498b5f08		MOVQ 0x8(R15), BX											
  db.go:2294		0xaac6b9		4c8d8110030000		LEAQ 0x310(CX), R8											
  db.go:2294		0xaac6c0		4c89842408020000	MOVQ R8, 0x208(SP)											
  db.go:2294		0xaac6c8		4889f8			MOVQ DI, AX												
  db.go:2294		0xaac6cb		4889d1			MOVQ DX, CX												
  db.go:2294		0xaac6ce		4c89c7			MOVQ R8, DI												
  db.go:2294		0xaac6d1		31f6			XORL SI, SI												
  db.go:2294		0xaac6d3		e868dcc0ff		CALL github.com/snissn/gomap/TreeDB/internal/primaryarena.(*Arena).DropToReleaseQueue(SB)		
  db.go:2294		0xaac6d8		0f1f840000000000	NOPL 0(AX)(AX*1)											
  db.go:2295		0xaac6e0		4885db			TESTQ BX, BX												
  db.go:2295		0xaac6e3		0f85f7120000		JNE 0xaad9e0												
  db.go:2294		0xaac6e9		48898c2408010000	MOVQ CX, 0x108(SP)											
  db.go:2294		0xaac6f1		48895c2448		MOVQ BX, 0x48(SP)											
  db.go:2295		0xaac6f6		e9b6100000		JMP 0xaad7b1												
  arena.go:625		0xaac6fb		8407			TESTB AL, 0(DI)												
  db.go:2292		0xaac6fd		498b4f10		MOVQ 0x10(R15), CX											
  db.go:2292		0xaac701		498b5f08		MOVQ 0x8(R15), BX											
  arena.go:625		0xaac705		488d97b0800000		LEAQ 0x80b0(DI), DX											
  arena.go:625		0xaac70c		4889f8			MOVQ DI, AX												
  arena.go:625		0xaac70f		4889d7			MOVQ DX, DI												
  arena.go:625		0xaac712		31f6			XORL SI, SI												
  arena.go:625		0xaac714		e827dcc0ff		CALL github.com/snissn/gomap/TreeDB/internal/primaryarena.(*Arena).DropToReleaseQueue(SB)		
  db.go:2292		0xaac719		e9fc0d0000		JMP 0xaad51a												
  db.go:2292		0xaac71e		31ff			XORL DI, DI												
  db.go:2292		0xaac720		4531ff			XORL R15, R15												
  db.go:2289		0xaac723		eb3c			JMP 0xaac761												
  db.go:2263		0xaac725		84db			TESTL BL, BL												
  db.go:2270		0xaac727		751e			JNE 0xaac747												
  db.go:2271		0xaac729		90			NOPL													
  mutex.go:194		0xaac72a		bbffffffff		MOVL $-0x1, BX												
  mutex.go:194		0xaac72f		f00fc199f0050000	LOCK XADDL BX, 0x5f0(CX)										
  mutex.go:194		0xaac737		ffcb			DECL BX													
  mutex.go:195		0xaac739		740c			JE 0xaac747												
  mutex.go:65		0xaac73b		488d81f0050000		LEAQ 0x5f0(CX), AX											
  mutex.go:198		0xaac742		e879fe9eff		CALL internal/sync.(*Mutex).unlockSlow(SB)								
  db.go:2273		0xaac747		31c0			XORL AX, AX												
  db.go:2273		0xaac749		31db			XORL BX, BX												
  db.go:2273		0xaac74b		4881c4d0020000		ADDQ $0x2d0, SP												
  db.go:2273		0xaac752		5d			POPQ BP													
  db.go:2273		0xaac753		c3			RET													
  db.go:2264		0xaac754		31c0			XORL AX, AX												
  db.go:2264		0xaac756		31db			XORL BX, BX												
  db.go:2264		0xaac758		4881c4d0020000		ADDQ $0x2d0, SP												
  db.go:2264		0xaac75f		5d			POPQ BP													
  db.go:2264		0xaac760		c3			RET													
  db.go:2316		0xaac761		4889bc2450020000	MOVQ DI, 0x250(SP)											
  db.go:2316		0xaac769		4c89bc2458020000	MOVQ R15, 0x258(SP)											
  db.go:2316		0xaac771		4889b42460020000	MOVQ SI, 0x260(SP)											
  db.go:2316		0xaac779		4889842468020000	MOVQ AX, 0x268(SP)											
  join.go:22		0xaac781		488db42450020000	LEAQ 0x250(SP), SI											
  join.go:22		0xaac789		31c0			XORL AX, AX												
  join.go:22		0xaac78b		31ff			XORL DI, DI												
  join.go:22		0xaac78d		eb19			JMP 0xaac7a8												
  join.go:22		0xaac78f		4989f7			MOVQ SI, R15												
  join.go:22		0xaac792		4883c610		ADDQ $0x10, SI												
  join.go:22		0xaac796		48ffc0			INCQ AX													
  join.go:22		0xaac799		49833f00		CMPQ 0(R15), $0x0											
  join.go:23		0xaac79d		410f95c7		SETNE R15												
  join.go:23		0xaac7a1		450fb6ff		MOVZX R15, R15												
  join.go:23		0xaac7a5		4c01ff			ADDQ R15, DI												
  join.go:22		0xaac7a8		4883f802		CMPQ AX, $0x2												
  join.go:22		0xaac7ac		7ce1			JL 0xaac78f												
  join.go:27		0xaac7ae		4885ff			TESTQ DI, DI												
  join.go:27		0xaac7b1		7509			JNE 0xaac7bc												
  join.go:27		0xaac7b3		31c0			XORL AX, AX												
  join.go:27		0xaac7b5		31f6			XORL SI, SI												
  db.go:2316		0xaac7b7		e9bc010000		JMP 0xaac978												
  join.go:22		0xaac7bc		48897c2460		MOVQ DI, 0x60(SP)											
  join.go:31		0xaac7c1		488d0558001101		LEAQ 0x1110058(IP), AX											
  join.go:31		0xaac7c8		31db			XORL BX, BX												
  join.go:31		0xaac7ca		4889f9			MOVQ DI, CX												
  join.go:31		0xaac7cd		e8ce249eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaac7d2		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaac7da		488d057f8f1301		LEAQ 0x1138f7f(IP), AX											
  join.go:30		0xaac7e1		e8ba8297ff		CALL runtime.newobject(SB)										
  join.go:31		0xaac7e6		488b542460		MOVQ 0x60(SP), DX											
  join.go:31		0xaac7eb		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaac7ef		833d2a0d480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaac7f6		750a			JNE 0xaac802												
  join.go:31		0xaac7f8		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaac800		eb10			JMP 0xaac812												
  join.go:31		0xaac802		e8397a9eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaac807		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaac80f		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaac812		48898424a0010000	MOVQ AX, 0x1a0(SP)											
  join.go:31		0xaac81a		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaac81d		488d942450020000	LEAQ 0x250(SP), DX											
  join.go:33		0xaac825		31c9			XORL CX, CX												
  join.go:33		0xaac827		eb07			JMP 0xaac830												
  join.go:33		0xaac829		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaac82d		48ffc1			INCQ CX													
  join.go:33		0xaac830		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaac834		0f8deb000000		JGE 0xaac925												
  join.go:33		0xaac83a		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaac83d		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaac841		4d85c0			TESTQ R8, R8												
  join.go:34		0xaac844		74e3			JE 0xaac829												
  join.go:35		0xaac846		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaac84a		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaac84e		48ffc3			INCQ BX													
  join.go:35		0xaac851		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaac854		4939da			CMPQ R10, BX												
  join.go:35		0xaac857		0f8389000000		JAE 0xaac8e6												
  join.go:33		0xaac85d		4c898424a0000000	MOVQ R8, 0xa0(SP)											
  join.go:33		0xaac865		4c898c2460010000	MOVQ R9, 0x160(SP)											
  join.go:33		0xaac86d		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaac875		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:35		0xaac87d		4c89d8			MOVQ R11, AX												
  join.go:35		0xaac880		4c89d1			MOVQ R10, CX												
  join.go:35		0xaac883		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaac888		488d3591ff1001		LEAQ 0x110ff91(IP), SI											
  join.go:35		0xaac88f		e8ec249eff		CALL runtime.growslice(SB)										
  join.go:35		0xaac894		488b9424a0010000	MOVQ 0x1a0(SP), DX											
  join.go:35		0xaac89c		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaac8a0		833d790c480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaac8a7		740f			JE 0xaac8b8												
  join.go:35		0xaac8a9		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaac8ac		e8af799eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaac8b1		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaac8b4		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaac8b8		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaac8bb		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaac8c3		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaac8cb		4c8b8424a0000000	MOVQ 0xa0(SP), R8											
  join.go:35		0xaac8d3		4c8b8c2460010000	MOVQ 0x160(SP), R9											
  join.go:35		0xaac8db		4989c3			MOVQ AX, R11												
  join.go:35		0xaac8de		488b8424a0010000	MOVQ 0x1a0(SP), AX											
  join.go:35		0xaac8e6		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaac8ea		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaac8ee		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaac8f2		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaac8f6		833d230c480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaac8fd		7417			JE 0xaac916												
  join.go:35		0xaac8ff		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaac904		4c89db			MOVQ R11, BX												
  join.go:35		0xaac907		e854799eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaac90c		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaac90f		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaac913		4989db			MOVQ BX, R11												
  join.go:35		0xaac916		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaac91b		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:35		0xaac920		e904ffffff		JMP 0xaac829												
  db.go:2317		0xaac925		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2386		0xaac92d		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaac935		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2387		0xaac93d		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaac945		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaac94d		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaac953		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaac959		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaac961		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2347		0xaac969		488d05b0224101		LEAQ go:itab.*errors.joinError,error(SB), AX								
  db.go:2316		0xaac970		488bb424a0010000	MOVQ 0x1a0(SP), SI											
  db.go:2317		0xaac978		80b94903000000		CMPB 0x349(CX), $0x0											
  db.go:2317		0xaac97f		90			NOPL													
  db.go:2317		0xaac980		0f84a5000000		JE 0xaaca2b												
  db.go:2317		0xaac986		488bb938030000		MOVQ 0x338(CX), DI											
  db.go:2317		0xaac98d		4885ff			TESTQ DI, DI												
  db.go:2317		0xaac990		0f8495000000		JE 0xaaca2b												
  db.go:2317		0xaac996		488b7f30		MOVQ 0x30(DI), DI											
  db.go:2317		0xaac99a		660f1f440000		NOPW 0(AX)(AX*1)											
  db.go:2317		0xaac9a0		4885ff			TESTQ DI, DI												
  db.go:2317		0xaac9a3		0f8482000000		JE 0xaaca2b												
  db.go:2317		0xaac9a9		4c8bb940030000		MOVQ 0x340(CX), R15											
  db.go:2317		0xaac9b0		4d85ff			TESTQ R15, R15												
  db.go:2317		0xaac9b3		7476			JE 0xaaca2b												
  db.go:2316		0xaac9b5		4889b42480010000	MOVQ SI, 0x180(SP)											
  db.go:2316		0xaac9bd		48898424c0000000	MOVQ AX, 0xc0(SP)											
  db.go:2318		0xaac9c5		4c89f8			MOVQ R15, AX												
  db.go:2318		0xaac9c8		4889fb			MOVQ DI, BX												
  db.go:2318		0xaac9cb		e8b03cd7ff		CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).Release(SB)				
  db.go:2318		0xaac9d0		4885c0			TESTQ AX, AX												
  db.go:2318		0xaac9d3		7441			JE 0xaaca16												
  db.go:2319		0xaac9d5		488b9424c0000000	MOVQ 0xc0(SP), DX											
  db.go:2319		0xaac9dd		4889942430020000	MOVQ DX, 0x230(SP)											
  db.go:2319		0xaac9e5		488b942480010000	MOVQ 0x180(SP), DX											
  db.go:2319		0xaac9ed		4889942438020000	MOVQ DX, 0x238(SP)											
  db.go:2319		0xaac9f5		4889842440020000	MOVQ AX, 0x240(SP)											
  db.go:2319		0xaac9fd		48899c2448020000	MOVQ BX, 0x248(SP)											
  join.go:22		0xaaca05		488d942430020000	LEAQ 0x230(SP), DX											
  join.go:22		0xaaca0d		31c0			XORL AX, AX												
  join.go:22		0xaaca0f		31c9			XORL CX, CX												
  join.go:22		0xaaca11		e90c090000		JMP 0xaad322												
  join.go:22		0xaaca16		488b8424c0000000	MOVQ 0xc0(SP), AX											
  join.go:22		0xaaca1e		488b8c2480010000	MOVQ 0x180(SP), CX											
  db.go:2318		0xaaca26		e992080000		JMP 0xaad2bd												
  db.go:2329		0xaaca2b		4889b42480010000	MOVQ SI, 0x180(SP)											
  db.go:2329		0xaaca33		48898424c0000000	MOVQ AX, 0xc0(SP)											
  db.go:2329		0xaaca3b		488bb930030000		MOVQ 0x330(CX), DI											
  db.go:2329		0xaaca42		4885ff			TESTQ DI, DI												
  db.go:2329		0xaaca45		0f84f0000000		JE 0xaacb3b												
  db.go:2330		0xaaca4b		4c8bb9a8030000		MOVQ 0x3a8(CX), R15											
  db.go:2330		0xaaca52		4d85ff			TESTQ R15, R15												
  db.go:2330		0xaaca55		7462			JE 0xaacab9												
  db.go:2331		0xaaca57		488b4748		MOVQ 0x48(DI), AX											
  db.go:2331		0xaaca5b		4c89fb			MOVQ R15, BX												
  db.go:2331		0xaaca5e		6690			NOPW													
  db.go:2331		0xaaca60		e8fbf8e7ff		CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister(SB)				
  db.go:2351		0xaaca65		488b8424c0000000	MOVQ 0xc0(SP), AX											
  db.go:2333		0xaaca6d		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2386		0xaaca75		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaaca7d		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2368		0xaaca85		488bb42480010000	MOVQ 0x180(SP), SI											
  db.go:2387		0xaaca8d		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaaca95		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaaca9d		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaacaa3		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaacaa9		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaacab1		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2333		0xaacab9		488bb928030000		MOVQ 0x328(CX), DI											
  db.go:2333		0xaacac0		4885ff			TESTQ DI, DI												
  db.go:2333		0xaacac3		7476			JE 0xaacb3b												
  type.go:58		0xaacac5		488bbf90050000		MOVQ 0x590(DI), DI											
  db.go:2334		0xaacacc		4c8bb930030000		MOVQ 0x330(CX), R15											
  db.go:2334		0xaacad3		4c39ff			CMPQ DI, R15												
  db.go:2334		0xaacad6		7463			JE 0xaacb3b												
  db.go:2335		0xaacad8		488b8128030000		MOVQ 0x328(CX), AX											
  db.go:2335		0xaacadf		4c89fb			MOVQ R15, BX												
  db.go:2335		0xaacae2		e879840800		CALL github.com/snissn/gomap/TreeDB/db.(*DB).maybeReleaseRetiredIndex(SB)				
  db.go:2351		0xaacae7		488b8424c0000000	MOVQ 0xc0(SP), AX											
  db.go:2339		0xaacaef		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2386		0xaacaf7		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaacaff		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2368		0xaacb07		488bb42480010000	MOVQ 0x180(SP), SI											
  db.go:2387		0xaacb0f		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaacb17		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaacb1f		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaacb25		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaacb2b		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaacb33		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2339		0xaacb3b		4889c8			MOVQ CX, AX												
  db.go:2339		0xaacb3e		6690			NOPW													
  db.go:2339		0xaacb40		e87bf3ffff		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).releaseLeafGenerationPins(SB)			
  db.go:2340		0xaacb45		488b8424e0020000	MOVQ 0x2e0(SP), AX											
  db.go:2340		0xaacb4d		80b82806000000		CMPB 0x628(AX), $0x0											
  db.go:2340		0xaacb54		7425			JE 0xaacb7b												
  db.go:2340		0xaacb56		488bb030060000		MOVQ 0x630(AX), SI											
  db.go:2340		0xaacb5d		0f1f00			NOPL 0(AX)												
  db.go:2340		0xaacb60		4885f6			TESTQ SI, SI												
  db.go:2340		0xaacb63		7416			JE 0xaacb7b												
  db.go:2340		0xaacb65		80b82906000000		CMPB 0x629(AX), $0x0											
  db.go:2340		0xaacb6c		750d			JNE 0xaacb7b												
  db.go:2341		0xaacb6e		90			NOPL													
  type.go:128		0xaacb6f		49c7c0ffffffff		MOVQ $-0x1, R8												
  type.go:128		0xaacb76		f04c0fc106		LOCK XADDQ R8, 0(SI)											
  db.go:2343		0xaacb7b		80b82806000000		CMPB 0x628(AX), $0x0											
  db.go:2343		0xaacb82		7407			JE 0xaacb8b												
  db.go:2344		0xaacb84		c6802806000000		MOVB $0x0, 0x628(AX)											
  db.go:2346		0xaacb8b		833d8e09480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2346		0xaacb92		7414			JE 0xaacba8												
  db.go:2346		0xaacb94		488bb030060000		MOVQ 0x630(AX), SI											
  db.go:2346		0xaacb9b		0f1f440000		NOPL 0(AX)(AX*1)											
  db.go:2346		0xaacba0		e89b769eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2346		0xaacba5		498933			MOVQ SI, 0(R11)												
  db.go:2346		0xaacba8		48c7803006000000000000	MOVQ $0x0, 0x630(AX)											
  db.go:2347		0xaacbb3		488b942488010000	MOVQ 0x188(SP), DX											
  db.go:2347		0xaacbbb		0f1f440000		NOPL 0(AX)(AX*1)											
  db.go:2347		0xaacbc0		4885d2			TESTQ DX, DX												
  db.go:2347		0xaacbc3		740d			JE 0xaacbd2												
  db.go:2348		0xaacbc5		488b02			MOVQ 0(DX), AX												
  db.go:2348		0xaacbc8		ffd0			CALL AX													
  db.go:2350		0xaacbca		488b8424e0020000	MOVQ 0x2e0(SP), AX											
  db.go:2350		0xaacbd2		488b90b8020000		MOVQ 0x2b8(AX), DX											
  db.go:2350		0xaacbd9		0f1f8000000000		NOPL 0(AX)												
  db.go:2350		0xaacbe0		4885d2			TESTQ DX, DX												
  db.go:2350		0xaacbe3		0f84d9000000		JE 0xaaccc2												
  db.go:2351		0xaacbe9		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2351		0xaacbf1		4885c9			TESTQ CX, CX												
  db.go:2351		0xaacbf4		7430			JE 0xaacc26												
  db.go:2354		0xaacbf6		4889c3			MOVQ AX, BX												
  db.go:2354		0xaacbf9		488bbc2480010000	MOVQ 0x180(SP), DI											
  db.go:2354		0xaacc01		4889d0			MOVQ DX, AX												
  db.go:2354		0xaacc04		e897331500		CALL github.com/snissn/gomap/TreeDB/db.(*primaryArenaOwnerV5).retainFailedSnapshot(SB)			
  db.go:2368		0xaacc09		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2368		0xaacc11		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2368		0xaacc19		488bbc2480010000	MOVQ 0x180(SP), DI											
  db.go:2354		0xaacc21		e9af000000		JMP 0xaaccd5												
  db.go:2350		0xaacc26		4889942418010000	MOVQ DX, 0x118(SP)											
  db.go:2356		0xaacc2e		4889d0			MOVQ DX, AX												
  db.go:2356		0xaacc31		31db			XORL BX, BX												
  db.go:2356		0xaacc33		e888271500		CALL github.com/snissn/gomap/TreeDB/db.(*primaryArenaOwnerV5).releaseWithOutcome(SB)			
  db.go:2356		0xaacc38		84c0			TESTL AL, AL												
  db.go:2357		0xaacc3a		743b			JE 0xaacc77												
  db.go:2358		0xaacc3c		833ddd08480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2358		0xaacc43		750c			JNE 0xaacc51												
  db.go:2356		0xaacc45		84c0			TESTL AL, AL												
  db.go:2358		0xaacc47		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2358		0xaacc4f		eb19			JMP 0xaacc6a												
  db.go:2358		0xaacc51		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2358		0xaacc59		488bb2b8020000		MOVQ 0x2b8(DX), SI											
  db.go:2358		0xaacc60		e8db759eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2358		0xaacc65		498933			MOVQ SI, 0(R11)												
  db.go:2356		0xaacc68		84c0			TESTL AL, AL												
  db.go:2358		0xaacc6a		48c782b802000000000000	MOVQ $0x0, 0x2b8(DX)											
  db.go:2358		0xaacc75		eb09			JMP 0xaacc80												
  db.go:2362		0xaacc77		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2362		0xaacc7f		90			NOPL													
  db.go:2361		0xaacc80		7404			JE 0xaacc86												
  db.go:2356		0xaacc82		84db			TESTL BL, BL												
  db.go:2361		0xaacc84		744f			JE 0xaaccd5												
  db.go:2356		0xaacc86		4889bc24f8010000	MOVQ DI, 0x1f8(SP)											
  db.go:2356		0xaacc8e		48898c24f8000000	MOVQ CX, 0xf8(SP)											
  db.go:2362		0xaacc96		488b842418010000	MOVQ 0x118(SP), AX											
  db.go:2362		0xaacc9e		4889d3			MOVQ DX, BX												
  db.go:2362		0xaacca1		e8fa321500		CALL github.com/snissn/gomap/TreeDB/db.(*primaryArenaOwnerV5).retainFailedSnapshot(SB)			
  db.go:2362		0xaacca6		488b8c24f8000000	MOVQ 0xf8(SP), CX											
  db.go:2368		0xaaccae		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2368		0xaaccb6		488bbc24f8010000	MOVQ 0x1f8(SP), DI											
  db.go:2368		0xaaccbe		6690			NOPW													
  db.go:2362		0xaaccc0		eb13			JMP 0xaaccd5												
  db.go:2368		0xaaccc2		4889c2			MOVQ AX, DX												
  db.go:2368		0xaaccc5		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2368		0xaacccd		488bbc2480010000	MOVQ 0x180(SP), DI											
  db.go:2368		0xaaccd5		488b8208030000		MOVQ 0x308(DX), AX											
  db.go:2369		0xaaccdc		833d3d08480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2369		0xaacce3		7425			JE 0xaacd0a												
  db.go:2369		0xaacce5		488bb208030000		MOVQ 0x308(DX), SI											
  db.go:2370		0xaaccec		4c8b8210030000		MOVQ 0x310(DX), R8											
  db.go:2370		0xaaccf3		4c8b8a20030000		MOVQ 0x320(DX), R9											
  db.go:2369		0xaaccfa		e881759eff		CALL runtime.gcWriteBarrier3(SB)									
  db.go:2369		0xaaccff		498933			MOVQ SI, 0(R11)												
  db.go:2370		0xaacd02		4d894308		MOVQ R8, 0x8(R11)											
  db.go:2370		0xaacd06		4d894b10		MOVQ R9, 0x10(R11)											
  db.go:2368		0xaacd0a		4889842438010000	MOVQ AX, 0x138(SP)											
  db.go:2369		0xaacd12		48c7820803000000000000	MOVQ $0x0, 0x308(DX)											
  db.go:2370		0xaacd1d		440f11ba10030000	MOVUPS X15, 0x310(DX)											
  db.go:2370		0xaacd25		48c7822003000000000000	MOVQ $0x0, 0x320(DX)											
  db.go:2373		0xaacd30		4885c9			TESTQ CX, CX												
  db.go:2373		0xaacd33		7557			JNE 0xaacd8c												
  db.go:2373		0xaacd35		488bb228030000		MOVQ 0x328(DX), SI											
  db.go:2373		0xaacd3c		0f1f4000		NOPL 0(AX)												
  db.go:2373		0xaacd40		4885f6			TESTQ SI, SI												
  db.go:2373		0xaacd43		7447			JE 0xaacd8c												
  db.go:2368		0xaacd45		4889bc24f0010000	MOVQ DI, 0x1f0(SP)											
  db.go:2368		0xaacd4d		48898c24f0000000	MOVQ CX, 0xf0(SP)											
  db.go:2374		0xaacd55		488b86b0050000		MOVQ 0x5b0(SI), AX											
  db.go:2374		0xaacd5c		4889d3			MOVQ DX, BX												
  db.go:2374		0xaacd5f		0fb68c24e8020000	MOVZX 0x2e8(SP), CX											
  db.go:2374		0xaacd67		e8d4ef1400		CALL github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).putRead(SB)					
  db.go:2384		0xaacd6c		488b842438010000	MOVQ 0x138(SP), AX											
  db.go:2379		0xaacd74		488b8c24f0000000	MOVQ 0xf0(SP), CX											
  db.go:2380		0xaacd7c		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2379		0xaacd84		488bbc24f0010000	MOVQ 0x1f0(SP), DI											
  db.go:2376		0xaacd8c		488bb42410010000	MOVQ 0x110(SP), SI											
  db.go:2376		0xaacd94		4885f6			TESTQ SI, SI												
  db.go:2376		0xaacd97		7424			JE 0xaacdbd												
  db.go:2377		0xaacd99		4889f0			MOVQ SI, AX												
  db.go:2377		0xaacd9c		4889cb			MOVQ CX, BX												
  db.go:2377		0xaacd9f		4889f9			MOVQ DI, CX												
  db.go:2377		0xaacda2		e819ba1a00		CALL github.com/snissn/gomap/TreeDB/db.(*stablePagerOwnedOperations).snapshotFinalized(SB)		
  db.go:2380		0xaacda7		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2379		0xaacdaf		4889c1			MOVQ AX, CX												
  db.go:2379		0xaacdb2		4889df			MOVQ BX, DI												
  db.go:2384		0xaacdb5		488b842438010000	MOVQ 0x138(SP), AX											
  db.go:2379		0xaacdbd		48898c24c0000000	MOVQ CX, 0xc0(SP)											
  db.go:2379		0xaacdc5		4889bc2480010000	MOVQ DI, 0x180(SP)											
  db.go:2379		0xaacdcd		4885c9			TESTQ CX, CX												
  db.go:2379		0xaacdd0		755d			JNE 0xaace2f												
  db.go:2276		0xaacdd2		0fb6742447		MOVZX 0x47(SP), SI											
  db.go:2276		0xaacdd7		4084f6			TESTL SI, SI												
  db.go:2379		0xaacdda		7453			JE 0xaace2f												
  db.go:2380		0xaacddc		833d3d07480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2380		0xaacde3		740f			JE 0xaacdf4												
  db.go:2380		0xaacde5		488bb240030000		MOVQ 0x340(DX), SI											
  db.go:2380		0xaacdec		e84f749eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2380		0xaacdf1		498933			MOVQ SI, 0(R11)												
  db.go:2380		0xaacdf4		48c7824003000000000000	MOVQ $0x0, 0x340(DX)											
  db.go:2381		0xaacdff		c6824803000000		MOVB $0x0, 0x348(DX)											
  db.go:2382		0xaace06		488d4258		LEAQ 0x58(DX), AX											
  db.go:2382		0xaace0a		488b9c2420010000	MOVQ 0x120(SP), BX											
  db.go:2382		0xaace12		e80993d7ff		CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*ManagerWrapperReleaseWork).ReleaseOriginal(SB)	
  db.go:2384		0xaace17		488b842438010000	MOVQ 0x138(SP), AX											
  db.go:2384		0xaace1f		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2384		0xaace27		488bbc2480010000	MOVQ 0x180(SP), DI											
  db.go:2384		0xaace2f		4889cb			MOVQ CX, BX												
  db.go:2384		0xaace32		4889f9			MOVQ DI, CX												
  db.go:2384		0xaace35		e886f0b4ff		CALL github.com/snissn/gomap/TreeDB/internal/retainedalloc.(*Enrollment).CloseAfterCleanup(SB)		
  db.go:2277		0xaace3a		0fb6542446		MOVZX 0x46(SP), DX											
  db.go:2277		0xaace3f		90			NOPL													
  db.go:2277		0xaace40		84d2			TESTL DL, DL												
  db.go:2385		0xaace42		0f84de000000		JE 0xaacf26												
  db.go:2386		0xaace48		488b842428010000	MOVQ 0x128(SP), AX											
  db.go:2386		0xaace50		488b9c24e0020000	MOVQ 0x2e0(SP), BX											
  db.go:2386		0xaace58		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2386		0xaace60		488bbc2480010000	MOVQ 0x180(SP), DI											
  db.go:2386		0xaace68		e833750800		CALL github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrowCompletionV6(SB)			
  db.go:2386		0xaace6d		48899c2488000000	MOVQ BX, 0x88(SP)											
  db.go:2386		0xaace75		4889842440010000	MOVQ AX, 0x140(SP)											
  db.go:2386		0xaace7d		0f1f00			NOPL 0(AX)												
  db.go:2387		0xaace80		4885c9			TESTQ CX, CX												
  db.go:2387		0xaace83		7460			JE 0xaacee5												
  db.go:2387		0xaace85		488b942430010000	MOVQ 0x130(SP), DX											
  db.go:2387		0xaace8d		4885d2			TESTQ DX, DX												
  db.go:2387		0xaace90		7453			JE 0xaacee5												
  db.go:2386		0xaace92		4889bc2448010000	MOVQ DI, 0x148(SP)											
  db.go:2386		0xaace9a		48898c2480000000	MOVQ CX, 0x80(SP)											
  db.go:2388		0xaacea2		488b8c2428010000	MOVQ 0x128(SP), CX											
  db.go:2388		0xaaceaa		8401			TESTB AL, 0(CX)												
  db.go:2388		0xaaceac		4881c120010000		ADDQ $0x120, CX												
  db.go:2388		0xaaceb3		4889d0			MOVQ DX, AX												
  db.go:2388		0xaaceb6		488d1de3104101		LEAQ go:itab.*github.com/snissn/gomap/TreeDB/db.originalDBCleanupFailure,error(SB), BX			
  db.go:2388		0xaacebd		0f1f00			NOPL 0(AX)												
  db.go:2388		0xaacec0		e8dbac0000		CALL github.com/snissn/gomap/TreeDB/db.(*DB).retainOriginalCleanupError(SB)				
  db.go:2393		0xaacec5		488b842440010000	MOVQ 0x140(SP), AX											
  db.go:2390		0xaacecd		488b8c2480000000	MOVQ 0x80(SP), CX											
  db.go:2392		0xaaced5		488b9c2488000000	MOVQ 0x88(SP), BX											
  db.go:2390		0xaacedd		488bbc2448010000	MOVQ 0x148(SP), DI											
  db.go:2390		0xaacee5		488b9424c0000000	MOVQ 0xc0(SP), DX											
  db.go:2390		0xaaceed		4889942410020000	MOVQ DX, 0x210(SP)											
  db.go:2390		0xaacef5		488b942480010000	MOVQ 0x180(SP), DX											
  db.go:2390		0xaacefd		4889942418020000	MOVQ DX, 0x218(SP)											
  db.go:2390		0xaacf05		48898c2420020000	MOVQ CX, 0x220(SP)											
  db.go:2390		0xaacf0d		4889bc2428020000	MOVQ DI, 0x228(SP)											
  join.go:22		0xaacf15		488d942410020000	LEAQ 0x210(SP), DX											
  join.go:22		0xaacf1d		31c9			XORL CX, CX												
  join.go:22		0xaacf1f		31f6			XORL SI, SI												
  join.go:22		0xaacf21		e99a010000		JMP 0xaad0c0												
  db.go:2263		0xaacf26		0fb69424e8020000	MOVZX 0x2e8(SP), DX											
  db.go:2263		0xaacf2e		84d2			TESTL DL, DL												
  db.go:2399		0xaacf30		488b842480010000	MOVQ 0x180(SP), AX											
  db.go:2399		0xaacf38		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2399		0xaacf40		4889842480010000	MOVQ AX, 0x180(SP)											
  db.go:2399		0xaacf48		48898c24c0000000	MOVQ CX, 0xc0(SP)											
  db.go:2399		0xaacf50		740d			JE 0xaacf5f												
  db.go:2402		0xaacf52		4889c3			MOVQ AX, BX												
  db.go:2402		0xaacf55		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  db.go:2399		0xaacf5d		eb52			JMP 0xaacfb1												
  db.go:2400		0xaacf5f		90			NOPL													
  db.go:2399		0xaacf60		4889c3			MOVQ AX, BX												
  mutex.go:63		0xaacf63		31c0			XORL AX, AX												
  mutex.go:63		0xaacf65		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  mutex.go:63		0xaacf6d		bf01000000		MOVL $0x1, DI												
  mutex.go:63		0xaacf72		f00fb1bef0050000	LOCK CMPXCHGL DI, 0x5f0(SI)										
  mutex.go:63		0xaacf7a		400f94c7		SETE DI													
  mutex.go:63		0xaacf7e		6690			NOPW													
  mutex.go:63		0xaacf80		4084ff			TESTL DI, DI												
  mutex.go:63		0xaacf83		752c			JNE 0xaacfb1												
  mutex.go:46		0xaacf85		488d86f0050000		LEAQ 0x5f0(SI), AX											
  mutex.go:70		0xaacf8c		e84ff39eff		CALL internal/sync.(*Mutex).lockSlow(SB)								
  db.go:2402		0xaacf91		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2263		0xaacf99		0fb69424e8020000	MOVZX 0x2e8(SP), DX											
  db.go:2402		0xaacfa1		488b9c2480010000	MOVQ 0x180(SP), BX											
  db.go:2402		0xaacfa9		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  db.go:2402		0xaacfb1		c6865106000001		MOVB $0x1, 0x651(SI)											
  db.go:2402		0xaacfb8		48898e58060000		MOVQ CX, 0x658(SI)											
  db.go:2402		0xaacfbf		833d5a05480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2402		0xaacfc6		7413			JE 0xaacfdb												
  db.go:2402		0xaacfc8		488bbe60060000		MOVQ 0x660(SI), DI											
  db.go:2402		0xaacfcf		e88c729eff		CALL runtime.gcWriteBarrier2(SB)									
  db.go:2402		0xaacfd4		49891b			MOVQ BX, 0(R11)												
  db.go:2402		0xaacfd7		49897b08		MOVQ DI, 0x8(R11)											
  db.go:2402		0xaacfdb		48899e60060000		MOVQ BX, 0x660(SI)											
  db.go:2403		0xaacfe2		488bbe40060000		MOVQ 0x640(SI), DI											
  db.go:2403		0xaacfe9		488b8648060000		MOVQ 0x648(SI), AX											
  db.go:2404		0xaacff0		48c7864006000000000000	MOVQ $0x0, 0x640(SI)											
  db.go:2404		0xaacffb		833d1e05480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2404		0xaad002		7504			JNE 0xaad008												
  db.go:2263		0xaad004		84d2			TESTL DL, DL												
  db.go:2404		0xaad006		eb11			JMP 0xaad019												
  db.go:2404		0xaad008		4c8b8648060000		MOVQ 0x648(SI), R8											
  db.go:2404		0xaad00f		e82c729eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2404		0xaad014		4d8903			MOVQ R8, 0(R11)												
  db.go:2263		0xaad017		84d2			TESTL DL, DL												
  db.go:2404		0xaad019		48c7864806000000000000	MOVQ $0x0, 0x648(SI)											
  db.go:2405		0xaad024		7550			JNE 0xaad076												
  db.go:2406		0xaad026		90			NOPL													
  mutex.go:194		0xaad027		baffffffff		MOVL $-0x1, DX												
  mutex.go:194		0xaad02c		f00fc196f0050000	LOCK XADDL DX, 0x5f0(SI)										
  mutex.go:194		0xaad034		ffca			DECL DX													
  mutex.go:195		0xaad036		743e			JE 0xaad076												
  db.go:2403		0xaad038		4889bc24c8000000	MOVQ DI, 0xc8(SP)											
  db.go:2403		0xaad040		48898424c0010000	MOVQ AX, 0x1c0(SP)											
  mutex.go:65		0xaad048		488d86f0050000		LEAQ 0x5f0(SI), AX											
  mutex.go:198		0xaad04f		89d3			MOVL DX, BX												
  mutex.go:198		0xaad051		e86af59eff		CALL internal/sync.(*Mutex).unlockSlow(SB)								
  db.go:2409		0xaad056		488b8424c0010000	MOVQ 0x1c0(SP), AX											
  db.go:2411		0xaad05e		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2411		0xaad066		488b9c2480010000	MOVQ 0x180(SP), BX											
  db.go:2408		0xaad06e		488bbc24c8000000	MOVQ 0xc8(SP), DI											
  db.go:2408		0xaad076		4885ff			TESTQ DI, DI												
  db.go:2408		0xaad079		741f			JE 0xaad09a												
  db.go:2409		0xaad07b		488b5718		MOVQ 0x18(DI), DX											
  db.go:2399		0xaad07f		4889de			MOVQ BX, SI												
  db.go:2409		0xaad082		4889cb			MOVQ CX, BX												
  db.go:2409		0xaad085		4889f1			MOVQ SI, CX												
  db.go:2409		0xaad088		ffd2			CALL DX													
  db.go:2411		0xaad08a		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2411		0xaad092		488b9c2480010000	MOVQ 0x180(SP), BX											
  db.go:2411		0xaad09a		4889c8			MOVQ CX, AX												
  db.go:2411		0xaad09d		4881c4d0020000		ADDQ $0x2d0, SP												
  db.go:2411		0xaad0a4		5d			POPQ BP													
  db.go:2411		0xaad0a5		c3			RET													
  join.go:22		0xaad0a6		4889d7			MOVQ DX, DI												
  join.go:22		0xaad0a9		4883c210		ADDQ $0x10, DX												
  join.go:22		0xaad0ad		48ffc1			INCQ CX													
  join.go:22		0xaad0b0		48833f00		CMPQ 0(DI), $0x0											
  join.go:23		0xaad0b4		400f95c7		SETNE DI												
  join.go:23		0xaad0b8		400fb6ff		MOVZX DI, DI												
  join.go:23		0xaad0bc		4801fe			ADDQ DI, SI												
  join.go:23		0xaad0bf		90			NOPL													
  join.go:22		0xaad0c0		4883f902		CMPQ CX, $0x2												
  join.go:22		0xaad0c4		7ce0			JL 0xaad0a6												
  join.go:27		0xaad0c6		4885f6			TESTQ SI, SI												
  join.go:27		0xaad0c9		7471			JE 0xaad13c												
  join.go:22		0xaad0cb		4889742450		MOVQ SI, 0x50(SP)											
  join.go:31		0xaad0d0		488d0549f71001		LEAQ 0x110f749(IP), AX											
  join.go:31		0xaad0d7		31db			XORL BX, BX												
  join.go:31		0xaad0d9		4889f1			MOVQ SI, CX												
  join.go:31		0xaad0dc		0f1f4000		NOPL 0(AX)												
  join.go:31		0xaad0e0		e8bb1b9eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaad0e5		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaad0ed		488d056c861301		LEAQ 0x113866c(IP), AX											
  join.go:30		0xaad0f4		e8a77997ff		CALL runtime.newobject(SB)										
  join.go:31		0xaad0f9		488b542450		MOVQ 0x50(SP), DX											
  join.go:31		0xaad0fe		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaad102		833d1704480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaad109		750a			JNE 0xaad115												
  join.go:31		0xaad10b		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad113		eb10			JMP 0xaad125												
  join.go:31		0xaad115		e826719eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaad11a		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad122		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaad125		4889842490010000	MOVQ AX, 0x190(SP)											
  join.go:31		0xaad12d		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaad130		488d942410020000	LEAQ 0x210(SP), DX											
  join.go:33		0xaad138		31c9			XORL CX, CX												
  join.go:33		0xaad13a		eb64			JMP 0xaad1a0												
  join.go:33		0xaad13c		31c9			XORL CX, CX												
  join.go:33		0xaad13e		31d2			XORL DX, DX												
  db.go:2392		0xaad140		4885db			TESTQ BX, BX												
  db.go:2392		0xaad143		750d			JNE 0xaad152												
  db.go:2263		0xaad145		0fb6b424e8020000	MOVZX 0x2e8(SP), SI											
  db.go:2263		0xaad14d		4084f6			TESTL SI, SI												
  db.go:2392		0xaad150		eb37			JMP 0xaad189												
  db.go:2390		0xaad152		48899424e8010000	MOVQ DX, 0x1e8(SP)											
  db.go:2390		0xaad15a		48898c24e8000000	MOVQ CX, 0xe8(SP)											
  db.go:2393		0xaad162		e819e2b4ff		CALL github.com/snissn/gomap/TreeDB/internal/retainedalloc.(*Owner).RemovePending(SB)			
  db.go:2263		0xaad167		0fb68c24e8020000	MOVZX 0x2e8(SP), CX											
  db.go:2263		0xaad16f		84c9			TESTL CL, CL												
  db.go:2399		0xaad171		488b8c24e8000000	MOVQ 0xe8(SP), CX											
  db.go:2399		0xaad179		488b9424e8010000	MOVQ 0x1e8(SP), DX											
  db.go:2263		0xaad181		0fb6b424e8020000	MOVZX 0x2e8(SP), SI											
  db.go:2399		0xaad189		4889d0			MOVQ DX, AX												
  db.go:2263		0xaad18c		89f2			MOVL SI, DX												
  db.go:2263		0xaad18e		e9adfdffff		JMP 0xaacf40												
  join.go:33		0xaad193		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaad197		48ffc1			INCQ CX													
  join.go:33		0xaad19a		660f1f440000		NOPW 0(AX)(AX*1)											
  join.go:33		0xaad1a0		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaad1a4		0f8def000000		JGE 0xaad299												
  join.go:33		0xaad1aa		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaad1ad		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaad1b1		4d85c0			TESTQ R8, R8												
  join.go:34		0xaad1b4		74dd			JE 0xaad193												
  join.go:35		0xaad1b6		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaad1ba		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaad1be		48ffc3			INCQ BX													
  join.go:35		0xaad1c1		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaad1c4		4939da			CMPQ R10, BX												
  join.go:35		0xaad1c7		0f838d000000		JAE 0xaad25a												
  join.go:33		0xaad1cd		4c898c2450010000	MOVQ R9, 0x150(SP)											
  join.go:33		0xaad1d5		4c89842490000000	MOVQ R8, 0x90(SP)											
  join.go:33		0xaad1dd		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaad1e5		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:35		0xaad1ed		4c89d8			MOVQ R11, AX												
  join.go:35		0xaad1f0		4c89d1			MOVQ R10, CX												
  join.go:35		0xaad1f3		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaad1f8		488d3521f61001		LEAQ 0x110f621(IP), SI											
  join.go:35		0xaad1ff		90			NOPL													
  join.go:35		0xaad200		e87b1b9eff		CALL runtime.growslice(SB)										
  join.go:35		0xaad205		488b942490010000	MOVQ 0x190(SP), DX											
  join.go:35		0xaad20d		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaad211		833d0803480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad218		7412			JE 0xaad22c												
  join.go:35		0xaad21a		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaad21d		0f1f00			NOPL 0(AX)												
  join.go:35		0xaad220		e83b709eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad225		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaad228		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad22c		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaad22f		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaad237		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaad23f		4c8b842490000000	MOVQ 0x90(SP), R8											
  join.go:35		0xaad247		4c8b8c2450010000	MOVQ 0x150(SP), R9											
  join.go:35		0xaad24f		4989c3			MOVQ AX, R11												
  join.go:35		0xaad252		488b842490010000	MOVQ 0x190(SP), AX											
  join.go:35		0xaad25a		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaad25e		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaad262		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaad266		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaad26a		833daf02480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad271		741c			JE 0xaad28f												
  join.go:35		0xaad273		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaad278		4c89db			MOVQ R11, BX												
  join.go:35		0xaad27b		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:35		0xaad280		e8db6f9eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad285		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaad288		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad28c		4989db			MOVQ BX, R11												
  join.go:35		0xaad28f		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaad294		e9fafeffff		JMP 0xaad193												
  db.go:2393		0xaad299		488b842440010000	MOVQ 0x140(SP), AX											
  db.go:2392		0xaad2a1		488b9c2488000000	MOVQ 0x88(SP), BX											
  db.go:2392		0xaad2a9		488d0d70194101		LEAQ go:itab.*errors.joinError,error(SB), CX								
  db.go:2390		0xaad2b0		488b942490010000	MOVQ 0x190(SP), DX											
  db.go:2390		0xaad2b8		e983feffff		JMP 0xaad140												
  db.go:2386		0xaad2bd		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaad2c5		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2387		0xaad2cd		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaad2d5		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaad2dd		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaad2e3		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaad2e9		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaad2f1		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2329		0xaad2f9		4889ce			MOVQ CX, SI												
  db.go:2329		0xaad2fc		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2329		0xaad304		e922f7ffff		JMP 0xaaca2b												
  join.go:22		0xaad309		4889d6			MOVQ DX, SI												
  join.go:22		0xaad30c		4883c210		ADDQ $0x10, DX												
  join.go:22		0xaad310		48ffc0			INCQ AX													
  join.go:22		0xaad313		48833e00		CMPQ 0(SI), $0x0											
  join.go:23		0xaad317		400f95c6		SETNE SI												
  join.go:23		0xaad31b		400fb6f6		MOVZX SI, SI												
  join.go:23		0xaad31f		4801f1			ADDQ SI, CX												
  join.go:22		0xaad322		4883f802		CMPQ AX, $0x2												
  join.go:22		0xaad326		7ce1			JL 0xaad309												
  join.go:27		0xaad328		4885c9			TESTQ CX, CX												
  join.go:27		0xaad32b		7509			JNE 0xaad336												
  join.go:27		0xaad32d		31c0			XORL AX, AX												
  join.go:27		0xaad32f		31c9			XORL CX, CX												
  db.go:2319		0xaad331		e972010000		JMP 0xaad4a8												
  join.go:22		0xaad336		48894c2458		MOVQ CX, 0x58(SP)											
  join.go:31		0xaad33b		488d05def41001		LEAQ 0x110f4de(IP), AX											
  join.go:31		0xaad342		31db			XORL BX, BX												
  join.go:31		0xaad344		e857199eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaad349		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaad351		488d0508841301		LEAQ 0x1138408(IP), AX											
  join.go:30		0xaad358		e8437797ff		CALL runtime.newobject(SB)										
  join.go:31		0xaad35d		488b542458		MOVQ 0x58(SP), DX											
  join.go:31		0xaad362		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaad366		833db301480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaad36d		750a			JNE 0xaad379												
  join.go:31		0xaad36f		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad377		eb10			JMP 0xaad389												
  join.go:31		0xaad379		e8c26e9eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaad37e		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad386		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaad389		4889842498010000	MOVQ AX, 0x198(SP)											
  join.go:31		0xaad391		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaad394		488d942430020000	LEAQ 0x230(SP), DX											
  join.go:33		0xaad39c		31c9			XORL CX, CX												
  join.go:33		0xaad39e		6690			NOPW													
  join.go:33		0xaad3a0		eb07			JMP 0xaad3a9												
  join.go:33		0xaad3a2		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaad3a6		48ffc1			INCQ CX													
  join.go:33		0xaad3a9		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaad3ad		0f8de6000000		JGE 0xaad499												
  join.go:33		0xaad3b3		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaad3b6		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaad3ba		4d85c0			TESTQ R8, R8												
  join.go:34		0xaad3bd		74e3			JE 0xaad3a2												
  join.go:35		0xaad3bf		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaad3c3		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaad3c7		48ffc3			INCQ BX													
  join.go:35		0xaad3ca		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaad3cd		4939da			CMPQ R10, BX												
  join.go:35		0xaad3d0		0f8389000000		JAE 0xaad45f												
  join.go:33		0xaad3d6		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaad3de		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:33		0xaad3e6		4c898c2458010000	MOVQ R9, 0x158(SP)											
  join.go:33		0xaad3ee		4c89842498000000	MOVQ R8, 0x98(SP)											
  join.go:35		0xaad3f6		4c89d8			MOVQ R11, AX												
  join.go:35		0xaad3f9		4c89d1			MOVQ R10, CX												
  join.go:35		0xaad3fc		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaad401		488d3518f41001		LEAQ 0x110f418(IP), SI											
  join.go:35		0xaad408		e873199eff		CALL runtime.growslice(SB)										
  join.go:35		0xaad40d		488b942498010000	MOVQ 0x198(SP), DX											
  join.go:35		0xaad415		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaad419		833d0001480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad420		740f			JE 0xaad431												
  join.go:35		0xaad422		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaad425		e8366e9eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad42a		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaad42d		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad431		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaad434		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaad43c		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaad444		4c8b842498000000	MOVQ 0x98(SP), R8											
  join.go:35		0xaad44c		4c8b8c2458010000	MOVQ 0x158(SP), R9											
  join.go:35		0xaad454		4989c3			MOVQ AX, R11												
  join.go:35		0xaad457		488b842498010000	MOVQ 0x198(SP), AX											
  join.go:35		0xaad45f		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaad463		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaad467		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaad46b		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaad46f		833daa00480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad476		7417			JE 0xaad48f												
  join.go:35		0xaad478		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaad47d		4c89db			MOVQ R11, BX												
  join.go:35		0xaad480		e8db6d9eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad485		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaad488		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad48c		4989db			MOVQ BX, R11												
  join.go:35		0xaad48f		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaad494		e909ffffff		JMP 0xaad3a2												
  join.go:35		0xaad499		488d0580174101		LEAQ go:itab.*errors.joinError,error(SB), AX								
  db.go:2319		0xaad4a0		488b8c2498010000	MOVQ 0x198(SP), CX											
  db.go:2324		0xaad4a8		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2324		0xaad4b0		4883ba2803000000	CMPQ 0x328(DX), $0x0											
  db.go:2324		0xaad4b8		0f84fffdffff		JE 0xaad2bd												
  db.go:2319		0xaad4be		48898c24e0010000	MOVQ CX, 0x1e0(SP)											
  db.go:2319		0xaad4c6		48898424e0000000	MOVQ AX, 0xe0(SP)											
  db.go:2325		0xaad4ce		488b8240030000		MOVQ 0x340(DX), AX											
  db.go:2325		0xaad4d5		e8e6ddd7ff		CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).CleanupError(SB)			
  db.go:2325		0xaad4da		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2325		0xaad4e2		488b8928030000		MOVQ 0x328(CX), CX											
  db.go:2325		0xaad4e9		4889c2			MOVQ AX, DX												
  db.go:2325		0xaad4ec		4889c8			MOVQ CX, AX												
  db.go:2325		0xaad4ef		4889de			MOVQ BX, SI												
  db.go:2325		0xaad4f2		4889d3			MOVQ DX, BX												
  db.go:2325		0xaad4f5		4889f1			MOVQ SI, CX												
  db.go:2325		0xaad4f8		e8a3a60000		CALL github.com/snissn/gomap/TreeDB/db.(*DB).retainOriginalCleanupError(SB)				
  db.go:2325		0xaad4fd		488b8424e0000000	MOVQ 0xe0(SP), AX											
  db.go:2325		0xaad505		488b8c24e0010000	MOVQ 0x1e0(SP), CX											
  db.go:2329		0xaad50d		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2325		0xaad515		e9a3fdffff		JMP 0xaad2bd												
  db.go:2311		0xaad51a		488d942470020000	LEAQ 0x270(SP), DX											
  db.go:2311		0xaad522		440f113a		MOVUPS X15, 0(DX)											
  db.go:2311		0xaad526		440f117a10		MOVUPS X15, 0x10(DX)											
  db.go:2311		0xaad52b		48899c2480020000	MOVQ BX, 0x280(SP)											
  db.go:2311		0xaad533		48898c2488020000	MOVQ CX, 0x288(SP)											
  join.go:22		0xaad53b		31c0			XORL AX, AX												
  join.go:22		0xaad53d		31f6			XORL SI, SI												
  join.go:22		0xaad53f		90			NOPL													
  join.go:22		0xaad540		eb1e			JMP 0xaad560												
  join.go:22		0xaad542		4889d7			MOVQ DX, DI												
  join.go:22		0xaad545		4883c210		ADDQ $0x10, DX												
  join.go:22		0xaad549		48ffc0			INCQ AX													
  join.go:22		0xaad54c		48833f00		CMPQ 0(DI), $0x0											
  join.go:23		0xaad550		400f95c7		SETNE DI												
  join.go:23		0xaad554		400fb6ff		MOVZX DI, DI												
  join.go:23		0xaad558		4801fe			ADDQ DI, SI												
  join.go:23		0xaad55b		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:22		0xaad560		4883f802		CMPQ AX, $0x2												
  join.go:22		0xaad564		7cdc			JL 0xaad542												
  join.go:27		0xaad566		4885f6			TESTQ SI, SI												
  join.go:27		0xaad569		7509			JNE 0xaad574												
  join.go:27		0xaad56b		31c0			XORL AX, AX												
  join.go:27		0xaad56d		31d2			XORL DX, DX												
  db.go:2311		0xaad56f		e9a4010000		JMP 0xaad718												
  db.go:2311		0xaad574		48898c24d8010000	MOVQ CX, 0x1d8(SP)											
  db.go:2311		0xaad57c		48899c24d8000000	MOVQ BX, 0xd8(SP)											
  join.go:22		0xaad584		4889742468		MOVQ SI, 0x68(SP)											
  join.go:31		0xaad589		488d0590f21001		LEAQ 0x110f290(IP), AX											
  join.go:31		0xaad590		31db			XORL BX, BX												
  join.go:31		0xaad592		4889f1			MOVQ SI, CX												
  join.go:31		0xaad595		e806179eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaad59a		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaad5a2		488d05b7811301		LEAQ 0x11381b7(IP), AX											
  join.go:30		0xaad5a9		e8f27497ff		CALL runtime.newobject(SB)										
  join.go:31		0xaad5ae		488b542468		MOVQ 0x68(SP), DX											
  join.go:31		0xaad5b3		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaad5b7		833d62ff470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaad5be		6690			NOPW													
  join.go:31		0xaad5c0		750a			JNE 0xaad5cc												
  join.go:31		0xaad5c2		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad5ca		eb10			JMP 0xaad5dc												
  join.go:31		0xaad5cc		e86f6c9eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaad5d1		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad5d9		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaad5dc		48898424a8010000	MOVQ AX, 0x1a8(SP)											
  join.go:31		0xaad5e4		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaad5e7		488d942470020000	LEAQ 0x270(SP), DX											
  join.go:33		0xaad5ef		31c9			XORL CX, CX												
  join.go:33		0xaad5f1		eb0d			JMP 0xaad600												
  join.go:33		0xaad5f3		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaad5f7		48ffc1			INCQ CX													
  join.go:33		0xaad5fa		660f1f440000		NOPW 0(AX)(AX*1)											
  join.go:33		0xaad600		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaad604		0f8def000000		JGE 0xaad6f9												
  join.go:33		0xaad60a		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaad60d		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaad611		4d85c0			TESTQ R8, R8												
  join.go:34		0xaad614		74dd			JE 0xaad5f3												
  join.go:35		0xaad616		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaad61a		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaad61e		48ffc3			INCQ BX													
  join.go:35		0xaad621		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaad624		4939da			CMPQ R10, BX												
  join.go:35		0xaad627		0f838d000000		JAE 0xaad6ba												
  join.go:33		0xaad62d		4c898c2468010000	MOVQ R9, 0x168(SP)											
  join.go:33		0xaad635		4c898424a8000000	MOVQ R8, 0xa8(SP)											
  join.go:33		0xaad63d		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaad645		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:35		0xaad64d		4c89d8			MOVQ R11, AX												
  join.go:35		0xaad650		4c89d1			MOVQ R10, CX												
  join.go:35		0xaad653		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaad658		488d35c1f11001		LEAQ 0x110f1c1(IP), SI											
  join.go:35		0xaad65f		90			NOPL													
  join.go:35		0xaad660		e81b179eff		CALL runtime.growslice(SB)										
  join.go:35		0xaad665		488b9424a8010000	MOVQ 0x1a8(SP), DX											
  join.go:35		0xaad66d		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaad671		833da8fe470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad678		7412			JE 0xaad68c												
  join.go:35		0xaad67a		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaad67d		0f1f00			NOPL 0(AX)												
  join.go:35		0xaad680		e8db6b9eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad685		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaad688		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad68c		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaad68f		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaad697		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaad69f		4c8b8424a8000000	MOVQ 0xa8(SP), R8											
  join.go:35		0xaad6a7		4c8b8c2468010000	MOVQ 0x168(SP), R9											
  join.go:35		0xaad6af		4989c3			MOVQ AX, R11												
  join.go:35		0xaad6b2		488b8424a8010000	MOVQ 0x1a8(SP), AX											
  join.go:35		0xaad6ba		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaad6be		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaad6c2		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaad6c6		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaad6ca		833d4ffe470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad6d1		741c			JE 0xaad6ef												
  join.go:35		0xaad6d3		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaad6d8		4c89db			MOVQ R11, BX												
  join.go:35		0xaad6db		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:35		0xaad6e0		e87b6b9eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad6e5		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaad6e8		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad6ec		4989db			MOVQ BX, R11												
  join.go:35		0xaad6ef		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaad6f4		e9fafeffff		JMP 0xaad5f3												
  db.go:2316		0xaad6f9		488b8c24d8010000	MOVQ 0x1d8(SP), CX											
  db.go:2312		0xaad701		488b9c24d8000000	MOVQ 0xd8(SP), BX											
  db.go:2312		0xaad709		488d0510154101		LEAQ go:itab.*errors.joinError,error(SB), AX								
  db.go:2311		0xaad710		488b9424a8010000	MOVQ 0x1a8(SP), DX											
  db.go:2312		0xaad718		4885db			TESTQ BX, BX												
  db.go:2312		0xaad71b		740a			JE 0xaad727												
  db.go:2317		0xaad71d		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  db.go:2312		0xaad725		eb35			JMP 0xaad75c												
  db.go:2313		0xaad727		833df2fd470200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2313		0xaad72e		750a			JNE 0xaad73a												
  db.go:2313		0xaad730		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  db.go:2313		0xaad738		eb17			JMP 0xaad751												
  db.go:2313		0xaad73a		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  db.go:2313		0xaad742		488bbeb0020000		MOVQ 0x2b0(SI), DI											
  db.go:2313		0xaad749		e8f26a9eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2313		0xaad74e		49893b			MOVQ DI, 0(R11)												
  db.go:2313		0xaad751		48c786b002000000000000	MOVQ $0x0, 0x2b0(SI)											
  db.go:2387		0xaad75c		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaad764		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaad76c		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaad772		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaad778		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaad780		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2316		0xaad788		4889de			MOVQ BX, SI												
  db.go:2316		0xaad78b		4889c7			MOVQ AX, DI												
  db.go:2316		0xaad78e		4889c8			MOVQ CX, AX												
  db.go:2316		0xaad791		4989d7			MOVQ DX, R15												
  db.go:2317		0xaad794		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2386		0xaad79c		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaad7a4		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2374		0xaad7ac		e9b0efffff		JMP 0xaac761												
  db.go:2297		0xaad7b1		488b8424c8010000	MOVQ 0x1c8(SP), AX											
  db.go:2297		0xaad7b9		488b9c2408020000	MOVQ 0x208(SP), BX											
  db.go:2297		0xaad7c1		31c9			XORL CX, CX												
  db.go:2297		0xaad7c3		e8d8d0c0ff		CALL github.com/snissn/gomap/TreeDB/internal/primaryarena.(*Arena).ReleaseQueueStep(SB)			
  db.go:2298		0xaad7c8		4885c9			TESTQ CX, CX												
  db.go:2298		0xaad7cb		751a			JNE 0xaad7e7												
  db.go:2297		0xaad7cd		84c0			TESTL AL, AL												
  db.go:2298		0xaad7cf		7416			JE 0xaad7e7												
  db.go:2297		0xaad7d1		84db			TESTL BL, BL												
  db.go:2302		0xaad7d3		75dc			JNE 0xaad7b1												
  db.go:2302		0xaad7d5		488b442448		MOVQ 0x48(SP), AX											
  db.go:2302		0xaad7da		488b8c2408010000	MOVQ 0x108(SP), CX											
  db.go:2303		0xaad7e2		e9ed010000		JMP 0xaad9d4												
  db.go:2299		0xaad7e7		488d9424b0020000	LEAQ 0x2b0(SP), DX											
  db.go:2299		0xaad7ef		440f113a		MOVUPS X15, 0(DX)											
  db.go:2299		0xaad7f3		440f117a10		MOVUPS X15, 0x10(DX)											
  db.go:2299		0xaad7f8		48898c24b0020000	MOVQ CX, 0x2b0(SP)											
  db.go:2299		0xaad800		4889bc24b8020000	MOVQ DI, 0x2b8(SP)											
  db.go:2299		0xaad808		488b3541383602		MOVQ github.com/snissn/gomap/TreeDB/internal/rootpublication.ErrResourceOwnership(SB), SI		
  db.go:2299		0xaad80f		488b3d42383602		MOVQ github.com/snissn/gomap/TreeDB/internal/rootpublication.ErrResourceOwnership+8(SB), DI		
  db.go:2299		0xaad816		4889b424c0020000	MOVQ SI, 0x2c0(SP)											
  db.go:2299		0xaad81e		4889bc24c8020000	MOVQ DI, 0x2c8(SP)											
  join.go:22		0xaad826		31c0			XORL AX, AX												
  join.go:22		0xaad828		31c9			XORL CX, CX												
  join.go:22		0xaad82a		eb19			JMP 0xaad845												
  join.go:22		0xaad82c		4889d6			MOVQ DX, SI												
  join.go:22		0xaad82f		4883c210		ADDQ $0x10, DX												
  join.go:22		0xaad833		48ffc0			INCQ AX													
  join.go:22		0xaad836		48833e00		CMPQ 0(SI), $0x0											
  join.go:23		0xaad83a		400f95c6		SETNE SI												
  join.go:23		0xaad83e		400fb6f6		MOVZX SI, SI												
  join.go:23		0xaad842		4801f1			ADDQ SI, CX												
  join.go:22		0xaad845		4883f802		CMPQ AX, $0x2												
  join.go:22		0xaad849		7ce1			JL 0xaad82c												
  join.go:27		0xaad84b		4885c9			TESTQ CX, CX												
  join.go:27		0xaad84e		7509			JNE 0xaad859												
  join.go:27		0xaad850		31c0			XORL AX, AX												
  join.go:27		0xaad852		31c9			XORL CX, CX												
  db.go:2299		0xaad854		e97b010000		JMP 0xaad9d4												
  join.go:22		0xaad859		48894c2478		MOVQ CX, 0x78(SP)											
  join.go:31		0xaad85e		488d05bbef1001		LEAQ 0x110efbb(IP), AX											
  join.go:31		0xaad865		31db			XORL BX, BX												
  join.go:31		0xaad867		e834149eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaad86c		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaad874		488d05e57e1301		LEAQ 0x1137ee5(IP), AX											
  join.go:30		0xaad87b		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:30		0xaad880		e81b7297ff		CALL runtime.newobject(SB)										
  join.go:31		0xaad885		488b542478		MOVQ 0x78(SP), DX											
  join.go:31		0xaad88a		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaad88e		833d8bfc470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaad895		750b			JNE 0xaad8a2												
  join.go:31		0xaad897		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad89f		90			NOPL													
  join.go:31		0xaad8a0		eb10			JMP 0xaad8b2												
  join.go:31		0xaad8a2		e899699eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaad8a7		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad8af		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaad8b2		48898424b8010000	MOVQ AX, 0x1b8(SP)											
  join.go:31		0xaad8ba		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaad8bd		488d9424b0020000	LEAQ 0x2b0(SP), DX											
  join.go:33		0xaad8c5		31c9			XORL CX, CX												
  join.go:33		0xaad8c7		eb07			JMP 0xaad8d0												
  join.go:33		0xaad8c9		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaad8cd		48ffc1			INCQ CX													
  join.go:33		0xaad8d0		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaad8d4		0f8deb000000		JGE 0xaad9c5												
  join.go:33		0xaad8da		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaad8dd		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaad8e1		4d85c0			TESTQ R8, R8												
  join.go:34		0xaad8e4		74e3			JE 0xaad8c9												
  join.go:35		0xaad8e6		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaad8ea		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaad8ee		48ffc3			INCQ BX													
  join.go:35		0xaad8f1		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaad8f4		4939da			CMPQ R10, BX												
  join.go:35		0xaad8f7		0f8389000000		JAE 0xaad986												
  join.go:33		0xaad8fd		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaad905		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:33		0xaad90d		4c898c2478010000	MOVQ R9, 0x178(SP)											
  join.go:33		0xaad915		4c898424b8000000	MOVQ R8, 0xb8(SP)											
  join.go:35		0xaad91d		4c89d8			MOVQ R11, AX												
  join.go:35		0xaad920		4c89d1			MOVQ R10, CX												
  join.go:35		0xaad923		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaad928		488d35f1ee1001		LEAQ 0x110eef1(IP), SI											
  join.go:35		0xaad92f		e84c149eff		CALL runtime.growslice(SB)										
  join.go:35		0xaad934		488b9424b8010000	MOVQ 0x1b8(SP), DX											
  join.go:35		0xaad93c		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaad940		833dd9fb470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad947		740f			JE 0xaad958												
  join.go:35		0xaad949		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaad94c		e80f699eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad951		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaad954		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad958		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaad95b		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaad963		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaad96b		4c8b8424b8000000	MOVQ 0xb8(SP), R8											
  join.go:35		0xaad973		4c8b8c2478010000	MOVQ 0x178(SP), R9											
  join.go:35		0xaad97b		4989c3			MOVQ AX, R11												
  join.go:35		0xaad97e		488b8424b8010000	MOVQ 0x1b8(SP), AX											
  join.go:35		0xaad986		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaad98a		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaad98e		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaad992		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaad996		833d83fb470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad99d		7417			JE 0xaad9b6												
  join.go:35		0xaad99f		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaad9a4		4c89db			MOVQ R11, BX												
  join.go:35		0xaad9a7		e8b4689eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad9ac		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaad9af		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad9b3		4989db			MOVQ BX, R11												
  join.go:35		0xaad9b6		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaad9bb		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:35		0xaad9c0		e904ffffff		JMP 0xaad8c9												
  join.go:35		0xaad9c5		488d0554124101		LEAQ go:itab.*errors.joinError,error(SB), AX								
  db.go:2299		0xaad9cc		488b8c24b8010000	MOVQ 0x1b8(SP), CX											
  db.go:2307		0xaad9d4		4889c3			MOVQ AX, BX												
  db.go:2307		0xaad9d7		660f1f840000000000	NOPW 0(AX)(AX*1)											
  db.go:2307		0xaad9e0		4885db			TESTQ BX, BX												
  db.go:2307		0xaad9e3		0f8431fbffff		JE 0xaad51a												
  db.go:2307		0xaad9e9		48898c24d0010000	MOVQ CX, 0x1d0(SP)											
  db.go:2307		0xaad9f1		48899c24d0000000	MOVQ BX, 0xd0(SP)											
  db.go:2308		0xaad9f9		488b8424c8010000	MOVQ 0x1c8(SP), AX											
  db.go:2308		0xaada01		488b9c2408020000	MOVQ 0x208(SP), BX											
  db.go:2308		0xaada09		e8929cc1ff		CALL github.com/snissn/gomap/TreeDB/internal/primaryarena.(*Arena).PreserveOrdinaryReleaseQueue(SB)	
  db.go:2308		0xaada0e		488b8c24d0000000	MOVQ 0xd0(SP), CX											
  db.go:2308		0xaada16		48898c2490020000	MOVQ CX, 0x290(SP)											
  db.go:2308		0xaada1e		488b8c24d0010000	MOVQ 0x1d0(SP), CX											
  db.go:2308		0xaada26		48898c2498020000	MOVQ CX, 0x298(SP)											
  db.go:2308		0xaada2e		48898424a0020000	MOVQ AX, 0x2a0(SP)											
  db.go:2308		0xaada36		48899c24a8020000	MOVQ BX, 0x2a8(SP)											
  join.go:22		0xaada3e		488d8c2490020000	LEAQ 0x290(SP), CX											
  join.go:22		0xaada46		31c0			XORL AX, AX												
  join.go:22		0xaada48		31d2			XORL DX, DX												
  join.go:22		0xaada4a		eb19			JMP 0xaada65												
  join.go:22		0xaada4c		4889ce			MOVQ CX, SI												
  join.go:22		0xaada4f		4883c110		ADDQ $0x10, CX												
  join.go:22		0xaada53		48ffc0			INCQ AX													
  join.go:22		0xaada56		48833e00		CMPQ 0(SI), $0x0											
  join.go:23		0xaada5a		400f95c6		SETNE SI												
  join.go:23		0xaada5e		400fb6f6		MOVZX SI, SI												
  join.go:23		0xaada62		4801f2			ADDQ SI, DX												
  join.go:22		0xaada65		4883f802		CMPQ AX, $0x2												
  join.go:22		0xaada69		7ce1			JL 0xaada4c												
  join.go:27		0xaada6b		4885d2			TESTQ DX, DX												
  join.go:27		0xaada6e		7509			JNE 0xaada79												
  join.go:27		0xaada70		31c0			XORL AX, AX												
  join.go:27		0xaada72		31c9			XORL CX, CX												
  db.go:2308		0xaada74		e97b010000		JMP 0xaadbf4												
  join.go:22		0xaada79		4889542470		MOVQ DX, 0x70(SP)											
  join.go:31		0xaada7e		488d059bed1001		LEAQ 0x110ed9b(IP), AX											
  join.go:31		0xaada85		31db			XORL BX, BX												
  join.go:31		0xaada87		4889d1			MOVQ DX, CX												
  join.go:31		0xaada8a		e811129eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaada8f		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaada97		488d05c27c1301		LEAQ 0x1137cc2(IP), AX											
  join.go:30		0xaada9e		6690			NOPW													
  join.go:30		0xaadaa0		e8fb6f97ff		CALL runtime.newobject(SB)										
  join.go:31		0xaadaa5		488b542470		MOVQ 0x70(SP), DX											
  join.go:31		0xaadaaa		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaadaae		833d6bfa470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaadab5		750b			JNE 0xaadac2												
  join.go:31		0xaadab7		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaadabf		90			NOPL													
  join.go:31		0xaadac0		eb10			JMP 0xaadad2												
  join.go:31		0xaadac2		e879679eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaadac7		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaadacf		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaadad2		48898424b0010000	MOVQ AX, 0x1b0(SP)											
  join.go:31		0xaadada		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaadadd		488d942490020000	LEAQ 0x290(SP), DX											
  join.go:33		0xaadae5		31c9			XORL CX, CX												
  join.go:33		0xaadae7		eb07			JMP 0xaadaf0												
  join.go:33		0xaadae9		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaadaed		48ffc1			INCQ CX													
  join.go:33		0xaadaf0		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaadaf4		0f8deb000000		JGE 0xaadbe5												
  join.go:33		0xaadafa		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaadafd		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaadb01		4d85c0			TESTQ R8, R8												
  join.go:34		0xaadb04		74e3			JE 0xaadae9												
  join.go:35		0xaadb06		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaadb0a		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaadb0e		48ffc3			INCQ BX													
  join.go:35		0xaadb11		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaadb14		4939da			CMPQ R10, BX												
  join.go:35		0xaadb17		0f8389000000		JAE 0xaadba6												
  join.go:33		0xaadb1d		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaadb25		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:33		0xaadb2d		4c898424b0000000	MOVQ R8, 0xb0(SP)											
  join.go:33		0xaadb35		4c898c2470010000	MOVQ R9, 0x170(SP)											
  join.go:35		0xaadb3d		4c89d8			MOVQ R11, AX												
  join.go:35		0xaadb40		4c89d1			MOVQ R10, CX												
  join.go:35		0xaadb43		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaadb48		488d35d1ec1001		LEAQ 0x110ecd1(IP), SI											
  join.go:35		0xaadb4f		e82c129eff		CALL runtime.growslice(SB)										
  join.go:35		0xaadb54		488b9424b0010000	MOVQ 0x1b0(SP), DX											
  join.go:35		0xaadb5c		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaadb60		833db9f9470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaadb67		740f			JE 0xaadb78												
  join.go:35		0xaadb69		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaadb6c		e8ef669eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaadb71		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaadb74		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaadb78		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaadb7b		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaadb83		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaadb8b		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  join.go:35		0xaadb93		4c8b8c2470010000	MOVQ 0x170(SP), R9											
  join.go:35		0xaadb9b		4989c3			MOVQ AX, R11												
  join.go:35		0xaadb9e		488b8424b0010000	MOVQ 0x1b0(SP), AX											
  join.go:35		0xaadba6		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaadbaa		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaadbae		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaadbb2		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaadbb6		833d63f9470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaadbbd		7417			JE 0xaadbd6												
  join.go:35		0xaadbbf		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaadbc4		4c89db			MOVQ R11, BX												
  join.go:35		0xaadbc7		e894669eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaadbcc		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaadbcf		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaadbd3		4989db			MOVQ BX, R11												
  join.go:35		0xaadbd6		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaadbdb		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:35		0xaadbe0		e904ffffff		JMP 0xaadae9												
  join.go:35		0xaadbe5		488d0534104101		LEAQ go:itab.*errors.joinError,error(SB), AX								
  db.go:2308		0xaadbec		488b8c24b0010000	MOVQ 0x1b0(SP), CX											
  db.go:2308		0xaadbf4		4889c3			MOVQ AX, BX												
  db.go:2308		0xaadbf7		e91ef9ffff		JMP 0xaad51a												
  db.go:2262		0xaadbfc		4889442408		MOVQ AX, 0x8(SP)											
  db.go:2262		0xaadc01		885c2410		MOVB BL, 0x10(SP)											
  db.go:2262		0xaadc05		e8564b9eff		CALL runtime.morestack_noctxt.abi0(SB)									
  db.go:2262		0xaadc0a		488b442408		MOVQ 0x8(SP), AX											
  db.go:2262		0xaadc0f		0fb65c2410		MOVZX 0x10(SP), BX											
  db.go:2262		0xaadc14		e947e8ffff		JMP github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead(SB)					

TEXT github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:5044			0xabffc0		4c8d6424f0		LEAQ -0x10(SP), R12										
  db.go:5044			0xabffc5		4d3b6610		CMPQ R12, 0x10(R14)										
  db.go:5044			0xabffc9		0f86dd010000		JBE 0xac01ac											
  db.go:5044			0xabffcf		55			PUSHQ BP											
  db.go:5044			0xabffd0		4889e5			MOVQ SP, BP											
  db.go:5044			0xabffd3		4881ec88000000		SUBQ $0x88, SP											
  db.go:5044			0xabffda		48899c24a0000000	MOVQ BX, 0xa0(SP)										
  db.go:5044			0xabffe2		4889b424b8000000	MOVQ SI, 0xb8(SP)										
  db.go:5044			0xabffea		66440fd6bc2480000000	MOVQ X15, 0x80(SP)										
  db.go:5044			0xabfff4		c644243f00		MOVB $0x0, 0x3f(SP)										
  db.go:5044			0xabfff9		48c744245800000000	MOVQ $0x0, 0x58(SP)										
  db.go:5044			0xac0002		440f117c2460		MOVUPS X15, 0x60(SP)										
  db.go:5044			0xac0008		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  db.go:5044			0xac0011		440f117c2448		MOVUPS X15, 0x48(SP)										
  db.go:5044			0xac0017		660f1f840000000000	NOPW 0(AX)(AX*1)										
  snapshot_read_lifetime.go:8	0xac0020		4885c0			TESTQ AX, AX											
  snapshot_read_lifetime.go:8	0xac0023		0f850a010000		JNE 0xac0133											
  db.go:5045			0xac0029		488b1520fb3402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), DX					
  db.go:5045			0xac0030		4c8b1521fb3402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), R10					
  db.go:5045			0xac0037		660f1f840000000000	NOPW 0(AX)(AX*1)										
  db.go:5045			0xac0040		4885d2			TESTQ DX, DX											
  db.go:5045			0xac0043		0f85a2000000		JNE 0xac00eb											
  db.go:5048			0xac0049		488d15b0010000		LEAQ github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend.deferwrap1(SB), DX	
  db.go:5048			0xac0050		4889542470		MOVQ DX, 0x70(SP)										
  db.go:5048			0xac0055		4889442478		MOVQ AX, 0x78(SP)										
  db.go:5048			0xac005a		488d542470		LEAQ 0x70(SP), DX										
  db.go:5048			0xac005f		4889942480000000	MOVQ DX, 0x80(SP)										
  db.go:5048			0xac0067		c644243f01		MOVB $0x1, 0x3f(SP)										
  raw_kv_compat.go:7		0xac006c		4885db			TESTQ BX, BX											
  raw_kv_compat.go:7		0xac006f		7515			JNE 0xac0086											
  db.go:5049			0xac0071		488b1d483b3502		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey(SB), BX				
  db.go:5049			0xac0078		488b0d493b3502		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+8(SB), CX				
  db.go:5049			0xac007f		488b3d4a3b3502		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+16(SB), DI				
  db.go:5049			0xac0086		8400			TESTB AL, 0(AX)											
  db.go:5049			0xac0088		4805c8030000		ADDQ $0x3c8, AX											
  db.go:5049			0xac008e		e84db5c1ff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB)				
  db.go:5049			0xac0093		4889442458		MOVQ AX, 0x58(SP)										
  db.go:5049			0xac0098		48895c2460		MOVQ BX, 0x60(SP)										
  db.go:5049			0xac009d		48894c2468		MOVQ CX, 0x68(SP)										
  db.go:5049			0xac00a2		48897c2440		MOVQ DI, 0x40(SP)										
  db.go:5049			0xac00a7		4889742448		MOVQ SI, 0x48(SP)										
  db.go:5049			0xac00ac		4c89442450		MOVQ R8, 0x50(SP)										
  db.go:5049			0xac00b1		c644243f00		MOVB $0x0, 0x3f(SP)										
  db.go:5049			0xac00b6		488b942480000000	MOVQ 0x80(SP), DX										
  db.go:5049			0xac00be		4c8b12			MOVQ 0(DX), R10											
  db.go:5049			0xac00c1		41ffd2			CALL R10											
  db.go:5049			0xac00c4		488b7c2440		MOVQ 0x40(SP), DI										
  db.go:5049			0xac00c9		488b742448		MOVQ 0x48(SP), SI										
  db.go:5049			0xac00ce		488b442458		MOVQ 0x58(SP), AX										
  db.go:5049			0xac00d3		488b5c2460		MOVQ 0x60(SP), BX										
  db.go:5049			0xac00d8		4c8b442450		MOVQ 0x50(SP), R8										
  db.go:5049			0xac00dd		488b4c2468		MOVQ 0x68(SP), CX										
  db.go:5049			0xac00e2		4881c488000000		ADDQ $0x88, SP											
  db.go:5049			0xac00e9		5d			POPQ BP												
  db.go:5049			0xac00ea		c3			RET												
  db.go:5046			0xac00eb		4889742458		MOVQ SI, 0x58(SP)										
  db.go:5046			0xac00f0		4c89442460		MOVQ R8, 0x60(SP)										
  db.go:5046			0xac00f5		4c894c2468		MOVQ R9, 0x68(SP)										
  db.go:5046			0xac00fa		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  db.go:5046			0xac0103		4889542448		MOVQ DX, 0x48(SP)										
  db.go:5046			0xac0108		4c89542450		MOVQ R10, 0x50(SP)										
  db.go:5046			0xac010d		488b7c2440		MOVQ 0x40(SP), DI										
  db.go:5046			0xac0112		488b442458		MOVQ 0x58(SP), AX										
  db.go:5046			0xac0117		488b5c2460		MOVQ 0x60(SP), BX										
  db.go:5046			0xac011c		488b4c2468		MOVQ 0x68(SP), CX										
  db.go:5046			0xac0121		4889d6			MOVQ DX, SI											
  db.go:5046			0xac0124		4d89d0			MOVQ R10, R8											
  db.go:5046			0xac0127		4881c488000000		ADDQ $0x88, SP											
  db.go:5046			0xac012e		5d			POPQ BP												
  db.go:5046			0xac012f		c3			RET												
  type.go:181			0xac0130		4c89d8			MOVQ R11, AX											
  snapshot_read_lifetime.go:12	0xac0133		90			NOPL												
  type.go:181			0xac0134		488b90e8050000		MOVQ 0x5e8(AX), DX										
  snapshot_read_lifetime.go:13	0xac013b		480fbae23f		BTQ $0x3f, DX											
  snapshot_read_lifetime.go:13	0xac0140		7227			JB 0xac0169											
  snapshot_read_lifetime.go:16	0xac0142		4c8d5201		LEAQ 0x1(DX), R10										
  snapshot_read_lifetime.go:8	0xac0146		4989c3			MOVQ AX, R11											
  type.go:191			0xac0149		4889d0			MOVQ DX, AX											
  type.go:191			0xac014c		f04d0fb193e8050000	LOCK CMPXCHGQ R10, 0x5e8(R11)									
  type.go:191			0xac0155		0f94c2			SETE DL												
  type.go:191			0xac0158		84d2			TESTL DL, DL											
  snapshot_read_lifetime.go:16	0xac015a		74d4			JE 0xac0130											
  db.go:5048			0xac015c		4c89d8			MOVQ R11, AX											
  db.go:5048			0xac015f		31d2			XORL DX, DX											
  db.go:5048			0xac0161		4531d2			XORL R10, R10											
  db.go:5045			0xac0164		e9d7feffff		JMP 0xac0040											
  db.go:5045			0xac0169		488b15e0f93402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), DX					
  db.go:5045			0xac0170		4c8b15e1f93402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), R10					
  db.go:5045			0xac0177		e9c4feffff		JMP 0xac0040											
  db.go:5045			0xac017c		0f1f4000		NOPL 0(AX)											
  db.go:5045			0xac0180		e89b0e99ff		CALL runtime.deferreturn(SB)									
  db.go:5045			0xac0185		488b442458		MOVQ 0x58(SP), AX										
  db.go:5045			0xac018a		488b5c2460		MOVQ 0x60(SP), BX										
  db.go:5045			0xac018f		488b4c2468		MOVQ 0x68(SP), CX										
  db.go:5045			0xac0194		488b7c2440		MOVQ 0x40(SP), DI										
  db.go:5045			0xac0199		488b742448		MOVQ 0x48(SP), SI										
  db.go:5045			0xac019e		4c8b442450		MOVQ 0x50(SP), R8										
  db.go:5045			0xac01a3		4881c488000000		ADDQ $0x88, SP											
  db.go:5045			0xac01aa		5d			POPQ BP												
  db.go:5045			0xac01ab		c3			RET												
  db.go:5044			0xac01ac		4889442408		MOVQ AX, 0x8(SP)										
  db.go:5044			0xac01b1		48895c2410		MOVQ BX, 0x10(SP)										
  db.go:5044			0xac01b6		48894c2418		MOVQ CX, 0x18(SP)										
  db.go:5044			0xac01bb		48897c2420		MOVQ DI, 0x20(SP)										
  db.go:5044			0xac01c0		4889742428		MOVQ SI, 0x28(SP)										
  db.go:5044			0xac01c5		4c89442430		MOVQ R8, 0x30(SP)										
  db.go:5044			0xac01ca		4c894c2438		MOVQ R9, 0x38(SP)										
  db.go:5044			0xac01cf		e88c259dff		CALL runtime.morestack_noctxt.abi0(SB)								
  db.go:5044			0xac01d4		488b442408		MOVQ 0x8(SP), AX										
  db.go:5044			0xac01d9		488b5c2410		MOVQ 0x10(SP), BX										
  db.go:5044			0xac01de		488b4c2418		MOVQ 0x18(SP), CX										
  db.go:5044			0xac01e3		488b7c2420		MOVQ 0x20(SP), DI										
  db.go:5044			0xac01e8		488b742428		MOVQ 0x28(SP), SI										
  db.go:5044			0xac01ed		4c8b442430		MOVQ 0x30(SP), R8										
  db.go:5044			0xac01f2		4c8b4c2438		MOVQ 0x38(SP), R9										
  db.go:5044			0xac01f7		e9c4fdffff		JMP github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend(SB)			

TEXT github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend.deferwrap1(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:5048		0xac0200		493b6610		CMPQ SP, 0x10(R14)									
  db.go:5048		0xac0204		7617			JBE 0xac021d										
  db.go:5048		0xac0206		55			PUSHQ BP										
  db.go:5048		0xac0207		4889e5			MOVQ SP, BP										
  db.go:5048		0xac020a		4883ec08		SUBQ $0x8, SP										
  db.go:5048		0xac020e		488b4208		MOVQ 0x8(DX), AX									
  db.go:5048		0xac0212		e8e93a1900		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).endRead(SB)				
  db.go:5048		0xac0217		4883c408		ADDQ $0x8, SP										
  db.go:5048		0xac021b		5d			POPQ BP											
  db.go:5048		0xac021c		c3			RET											
  db.go:5048		0xac021d		0f1f00			NOPL 0(AX)										
  db.go:5048		0xac0220		e89b249dff		CALL runtime.morestack.abi0(SB)								
  db.go:5048		0xac0225		ebd9			JMP github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrowCompletionV6(SB) github.com/snissn/gomap/TreeDB/db/index_gen.go
  index_gen.go:251	0xb343a0		493b6610		CMPQ SP, 0x10(R14)									
  index_gen.go:251	0xb343a4		0f867e020000		JBE 0xb34628										
  index_gen.go:251	0xb343aa		55			PUSHQ BP										
  index_gen.go:251	0xb343ab		4889e5			MOVQ SP, BP										
  index_gen.go:251	0xb343ae		4883ec48		SUBQ $0x48, SP										
  index_gen.go:251	0xb343b2		48894c2468		MOVQ CX, 0x68(SP)									
  index_gen.go:251	0xb343b7		48897c2470		MOVQ DI, 0x70(SP)									
  index_gen.go:251	0xb343bc		0f1f4000		NOPL 0(AX)										
  index_gen.go:253	0xb343c0		4885c9			TESTQ CX, CX										
  index_gen.go:253	0xb343c3		740c			JE 0xb343d1										
  index_gen.go:253	0xb343c5		49b8ffffffffffffff7f	MOVQ $0x7fffffffffffffff, R8								
  index_gen.go:253	0xb343cf		eb38			JMP 0xb34409										
  index_gen.go:254	0xb343d1		90			NOPL											
  index_gen.go:242	0xb343d2		90			NOPL											
  type.go:195		0xb343d3		48c7c2ffffffff		MOVQ $-0x1, DX										
  type.go:195		0xb343da		f0480fc15068		LOCK XADDQ DX, 0x68(AX)									
  type.go:195		0xb343e0		48ffca			DECQ DX											
  index_gen.go:243	0xb343e3		4889d6			MOVQ DX, SI										
  index_gen.go:243	0xb343e6		480fbaf23f		BTRQ $0x3f, DX										
  index_gen.go:243	0xb343eb		49b8ffffffffffffff7f	MOVQ $0x7fffffffffffffff, R8								
  index_gen.go:243	0xb343f5		4939d0			CMPQ R8, DX										
  index_gen.go:243	0xb343f8		0f8416020000		JE 0xb34614										
  index_gen.go:255	0xb343fe		480fbae63f		BTQ $0x3f, SI										
  index_gen.go:255	0xb34403		0f83ea010000		JAE 0xb345f3										
  index_gen.go:253	0xb34409		4889442458		MOVQ AX, 0x58(SP)									
  index_gen.go:253	0xb3440e		48895c2460		MOVQ BX, 0x60(SP)									
  index_gen.go:262	0xb34413		90			NOPL											
  mutex.go:46		0xb34414		488d505c		LEAQ 0x5c(AX), DX									
  mutex.go:46		0xb34418		4889542430		MOVQ DX, 0x30(SP)									
  index_gen.go:253	0xb3441d		4889c6			MOVQ AX, SI										
  mutex.go:63		0xb34420		31c0			XORL AX, AX										
  mutex.go:63		0xb34422		41b901000000		MOVL $0x1, R9										
  mutex.go:63		0xb34428		f0440fb14e5c		LOCK CMPXCHGL R9, 0x5c(SI)								
  mutex.go:63		0xb3442e		410f94c1		SETE R9											
  mutex.go:63		0xb34432		4584c9			TESTL R9, R9										
  mutex.go:63		0xb34435		7405			JE 0xb3443c										
  index_gen.go:253	0xb34437		4885c9			TESTQ CX, CX										
  mutex.go:46		0xb3443a		eb38			JMP 0xb34474										
  index_gen.go:253	0xb3443c		48894c2468		MOVQ CX, 0x68(SP)									
  index_gen.go:253	0xb34441		48897c2470		MOVQ DI, 0x70(SP)									
  mutex.go:70		0xb34446		4889d0			MOVQ DX, AX										
  mutex.go:70		0xb34449		e8927e96ff		CALL internal/sync.(*Mutex).lockSlow(SB)						
  index_gen.go:253	0xb3444e		488b4c2468		MOVQ 0x68(SP), CX									
  index_gen.go:253	0xb34453		4885c9			TESTQ CX, CX										
  mutex.go:198		0xb34456		488b542430		MOVQ 0x30(SP), DX									
  index_gen.go:268	0xb3445b		488b5c2460		MOVQ 0x60(SP), BX									
  index_gen.go:264	0xb34460		488b742458		MOVQ 0x58(SP), SI									
  index_gen.go:267	0xb34465		488b7c2470		MOVQ 0x70(SP), DI									
  index_gen.go:267	0xb3446a		49b8ffffffffffffff7f	MOVQ $0x7fffffffffffffff, R8								
  index_gen.go:264	0xb34474		7405			JE 0xb3447b										
  index_gen.go:253	0xb34476		4889c8			MOVQ CX, AX										
  index_gen.go:264	0xb34479		eb25			JMP 0xb344a0										
  index_gen.go:264	0xb3447b		807e7100		CMPB 0x71(SI), $0x0									
  index_gen.go:264	0xb3447f		90			NOPL											
  index_gen.go:264	0xb34480		7416			JE 0xb34498										
  index_gen.go:265	0xb34482		488bbe98000000		MOVQ 0x98(SI), DI									
  index_gen.go:265	0xb34489		4c8b8e90000000		MOVQ 0x90(SI), R9									
  index_gen.go:253	0xb34490		4889c8			MOVQ CX, AX										
  index_gen.go:267	0xb34493		4c89c9			MOVQ R9, CX										
  index_gen.go:265	0xb34496		eb08			JMP 0xb344a0										
  index_gen.go:253	0xb34498		4889c8			MOVQ CX, AX										
  index_gen.go:253	0xb3449b		0f1f440000		NOPL 0(AX)(AX*1)									
  index_gen.go:267	0xb344a0		4885c9			TESTQ CX, CX										
  index_gen.go:267	0xb344a3		0f84e2000000		JE 0xb3458b										
  index_gen.go:268	0xb344a9		4885db			TESTQ BX, BX										
  index_gen.go:268	0xb344ac		7449			JE 0xb344f7										
  index_gen.go:253	0xb344ae		4885c0			TESTQ AX, AX										
  index_gen.go:271	0xb344b1		750d			JNE 0xb344c0										
  index_gen.go:272	0xb344b3		90			NOPL											
  type.go:195		0xb344b4		41b801000000		MOVL $0x1, R8										
  type.go:195		0xb344ba		f04c0fc14668		LOCK XADDQ R8, 0x68(SI)									
  index_gen.go:274	0xb344c0		4c8b4678		MOVQ 0x78(SI), R8									
  index_gen.go:274	0xb344c4		833d55903f0200		CMPL runtime.writeBarrier(SB), $0x0							
  index_gen.go:274	0xb344cb		741f			JE 0xb344ec										
  index_gen.go:274	0xb344cd		4c8b8bc8020000		MOVQ 0x2c8(BX), R9									
  index_gen.go:275	0xb344d4		4c8b5678		MOVQ 0x78(SI), R10									
  index_gen.go:274	0xb344d8		e8c3fd95ff		CALL runtime.gcWriteBarrier4(SB)							
  index_gen.go:274	0xb344dd		4d8903			MOVQ R8, 0(R11)										
  index_gen.go:274	0xb344e0		4d894b08		MOVQ R9, 0x8(R11)									
  index_gen.go:275	0xb344e4		49895b10		MOVQ BX, 0x10(R11)									
  index_gen.go:275	0xb344e8		4d895318		MOVQ R10, 0x18(R11)									
  index_gen.go:274	0xb344ec		4c8983c8020000		MOVQ R8, 0x2c8(BX)									
  index_gen.go:275	0xb344f3		48895e78		MOVQ BX, 0x78(SI)									
  index_gen.go:267	0xb344f7		48897c2440		MOVQ DI, 0x40(SP)									
  index_gen.go:267	0xb344fc		48894c2428		MOVQ CX, 0x28(SP)									
  index_gen.go:277	0xb34501		488b4608		MOVQ 0x8(SI), AX									
  index_gen.go:277	0xb34505		4885c0			TESTQ AX, AX										
  index_gen.go:277	0xb34508		741e			JE 0xb34528										
  index_gen.go:278	0xb3450a		e8f177acff		CALL github.com/snissn/gomap/TreeDB/internal/retainedalloc.(*Owner).CleanupFailed(SB)	
  index_gen.go:284	0xb3450f		488b4c2428		MOVQ 0x28(SP), CX									
  mutex.go:198		0xb34514		488b542430		MOVQ 0x30(SP), DX									
  index_gen.go:268	0xb34519		488b5c2460		MOVQ 0x60(SP), BX									
  mutex.go:194		0xb3451e		488b742458		MOVQ 0x58(SP), SI									
  index_gen.go:284	0xb34523		488b7c2440		MOVQ 0x40(SP), DI									
  index_gen.go:280	0xb34528		90			NOPL											
  mutex.go:65		0xb34529		90			NOPL											
  mutex.go:194		0xb3452a		41b8ffffffff		MOVL $-0x1, R8										
  mutex.go:194		0xb34530		f0440fc1465c		LOCK XADDL R8, 0x5c(SI)									
  mutex.go:194		0xb34536		41ffc8			DECL R8											
  mutex.go:195		0xb34539		7507			JNE 0xb34542										
  index_gen.go:268	0xb3453b		4885db			TESTQ BX, BX										
  index_gen.go:268	0xb3453e		6690			NOPW											
  mutex.go:195		0xb34540		eb22			JMP 0xb34564										
  mutex.go:198		0xb34542		4889d0			MOVQ DX, AX										
  mutex.go:198		0xb34545		4489c3			MOVL R8, BX										
  mutex.go:198		0xb34548		e8738096ff		CALL internal/sync.(*Mutex).unlockSlow(SB)						
  index_gen.go:268	0xb3454d		488b4c2460		MOVQ 0x60(SP), CX									
  index_gen.go:268	0xb34552		4885c9			TESTQ CX, CX										
  index_gen.go:284	0xb34555		488b4c2428		MOVQ 0x28(SP), CX									
  index_gen.go:282	0xb3455a		488b742458		MOVQ 0x58(SP), SI									
  index_gen.go:284	0xb3455f		488b7c2440		MOVQ 0x40(SP), DI									
  index_gen.go:281	0xb34564		741b			JE 0xb34581										
  index_gen.go:282	0xb34566		488d8620010000		LEAQ 0x120(SI), AX									
  index_gen.go:282	0xb3456d		bb02000000		MOVL $0x2, BX										
  index_gen.go:282	0xb34572		e86931f8ff		CALL github.com/snissn/gomap/TreeDB/db.(*originalDBCleanupFailure).retainCause(SB)	
  index_gen.go:284	0xb34577		488b4c2428		MOVQ 0x28(SP), CX									
  index_gen.go:284	0xb3457c		488b7c2440		MOVQ 0x40(SP), DI									
  index_gen.go:284	0xb34581		31c0			XORL AX, AX										
  index_gen.go:284	0xb34583		31db			XORL BX, BX										
  index_gen.go:284	0xb34585		4883c448		ADDQ $0x48, SP										
  index_gen.go:284	0xb34589		5d			POPQ BP											
  index_gen.go:284	0xb3458a		c3			RET											
  index_gen.go:253	0xb3458b		4885c0			TESTQ AX, AX										
  index_gen.go:286	0xb3458e		741c			JE 0xb345ac										
  index_gen.go:287	0xb34590		90			NOPL											
  index_gen.go:242	0xb34591		90			NOPL											
  type.go:195		0xb34592		48c7c1ffffffff		MOVQ $-0x1, CX										
  type.go:195		0xb34599		f0480fc14e68		LOCK XADDQ CX, 0x68(SI)									
  type.go:195		0xb3459f		48ffc9			DECQ CX											
  index_gen.go:243	0xb345a2		480fbaf13f		BTRQ $0x3f, CX										
  index_gen.go:243	0xb345a7		4939c8			CMPQ R8, CX										
  index_gen.go:243	0xb345aa		7455			JE 0xb34601										
  index_gen.go:289	0xb345ac		4889f0			MOVQ SI, AX										
  index_gen.go:289	0xb345af		e86c030000		CALL github.com/snissn/gomap/TreeDB/db.(*indexGen).detachGenerationMetadataLockedV6(SB)	
  index_gen.go:290	0xb345b4		90			NOPL											
  mutex.go:65		0xb345b5		90			NOPL											
  mutex.go:194		0xb345b6		b9ffffffff		MOVL $-0x1, CX										
  mutex.go:194		0xb345bb		488b542458		MOVQ 0x58(SP), DX									
  mutex.go:194		0xb345c0		f00fc14a5c		LOCK XADDL CX, 0x5c(DX)									
  mutex.go:194		0xb345c5		ffc9			DECL CX											
  mutex.go:195		0xb345c7		7420			JE 0xb345e9										
  index_gen.go:289	0xb345c9		4889442438		MOVQ AX, 0x38(SP)									
  index_gen.go:289	0xb345ce		48895c2420		MOVQ BX, 0x20(SP)									
  mutex.go:198		0xb345d3		488b442430		MOVQ 0x30(SP), AX									
  mutex.go:198		0xb345d8		89cb			MOVL CX, BX										
  mutex.go:198		0xb345da		e8e17f96ff		CALL internal/sync.(*Mutex).unlockSlow(SB)						
  index_gen.go:291	0xb345df		488b442438		MOVQ 0x38(SP), AX									
  index_gen.go:291	0xb345e4		488b5c2420		MOVQ 0x20(SP), BX									
  index_gen.go:291	0xb345e9		31c9			XORL CX, CX										
  index_gen.go:291	0xb345eb		31ff			XORL DI, DI										
  index_gen.go:291	0xb345ed		4883c448		ADDQ $0x48, SP										
  index_gen.go:291	0xb345f1		5d			POPQ BP											
  index_gen.go:291	0xb345f2		c3			RET											
  index_gen.go:258	0xb345f3		31c0			XORL AX, AX										
  index_gen.go:258	0xb345f5		31db			XORL BX, BX										
  index_gen.go:258	0xb345f7		31c9			XORL CX, CX										
  index_gen.go:258	0xb345f9		31ff			XORL DI, DI										
  index_gen.go:258	0xb345fb		4883c448		ADDQ $0x48, SP										
  index_gen.go:258	0xb345ff		5d			POPQ BP											
  index_gen.go:258	0xb34600		c3			RET											
  index_gen.go:244	0xb34601		488d05989a0201		LEAQ 0x1029a98(IP), AX									
  index_gen.go:244	0xb34608		488d1d31dd3701		LEAQ 0x137dd31(IP), BX									
  index_gen.go:244	0xb3460f		e8cc7b95ff		CALL runtime.gopanic(SB)								
  index_gen.go:244	0xb34614		488d05859a0201		LEAQ 0x1029a85(IP), AX									
  index_gen.go:244	0xb3461b		488d1d1edd3701		LEAQ 0x137dd1e(IP), BX									
  index_gen.go:244	0xb34622		e8b97b95ff		CALL runtime.gopanic(SB)								
  index_gen.go:244	0xb34627		90			NOPL											
  index_gen.go:251	0xb34628		4889442408		MOVQ AX, 0x8(SP)									
  index_gen.go:251	0xb3462d		48895c2410		MOVQ BX, 0x10(SP)									
  index_gen.go:251	0xb34632		48894c2418		MOVQ CX, 0x18(SP)									
  index_gen.go:251	0xb34637		48897c2420		MOVQ DI, 0x20(SP)									
  index_gen.go:251	0xb3463c		0f1f4000		NOPL 0(AX)										
  index_gen.go:251	0xb34640		e81be195ff		CALL runtime.morestack_noctxt.abi0(SB)							
  index_gen.go:251	0xb34645		488b442408		MOVQ 0x8(SP), AX									
  index_gen.go:251	0xb3464a		488b5c2410		MOVQ 0x10(SP), BX									
  index_gen.go:251	0xb3464f		488b4c2418		MOVQ 0x18(SP), CX									
  index_gen.go:251	0xb34654		488b7c2420		MOVQ 0x20(SP), DI									
  index_gen.go:251	0xb34659		e942fdffff		JMP github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrowCompletionV6(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrow(SB) github.com/snissn/gomap/TreeDB/db/index_gen.go
  index_gen.go:294	0xb34660		493b6610		CMPQ SP, 0x10(R14)									
  index_gen.go:294	0xb34664		762a			JBE 0xb34690										
  index_gen.go:294	0xb34666		55			PUSHQ BP										
  index_gen.go:294	0xb34667		4889e5			MOVQ SP, BP										
  index_gen.go:294	0xb3466a		4883ec20		SUBQ $0x20, SP										
  index_gen.go:294	0xb3466e		48894c2440		MOVQ CX, 0x40(SP)									
  index_gen.go:294	0xb34673		48897c2448		MOVQ DI, 0x48(SP)									
  index_gen.go:295	0xb34678		e823fdffff		CALL github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrowCompletionV6(SB)	
  index_gen.go:295	0xb3467d		0f1f00			NOPL 0(AX)										
  index_gen.go:297	0xb34680		4885db			TESTQ BX, BX										
  index_gen.go:297	0xb34683		7405			JE 0xb3468a										
  index_gen.go:298	0xb34685		e8f66cacff		CALL github.com/snissn/gomap/TreeDB/internal/retainedalloc.(*Owner).RemovePending(SB)	
  index_gen.go:300	0xb3468a		4883c420		ADDQ $0x20, SP										
  index_gen.go:300	0xb3468e		5d			POPQ BP											
  index_gen.go:300	0xb3468f		c3			RET											
  index_gen.go:294	0xb34690		4889442408		MOVQ AX, 0x8(SP)									
  index_gen.go:294	0xb34695		48895c2410		MOVQ BX, 0x10(SP)									
  index_gen.go:294	0xb3469a		48894c2418		MOVQ CX, 0x18(SP)									
  index_gen.go:294	0xb3469f		48897c2420		MOVQ DI, 0x20(SP)									
  index_gen.go:294	0xb346a4		e8b7e095ff		CALL runtime.morestack_noctxt.abi0(SB)							
  index_gen.go:294	0xb346a9		488b442408		MOVQ 0x8(SP), AX									
  index_gen.go:294	0xb346ae		488b5c2410		MOVQ 0x10(SP), BX									
  index_gen.go:294	0xb346b3		488b4c2418		MOVQ 0x18(SP), CX									
  index_gen.go:294	0xb346b8		488b7c2420		MOVQ 0x20(SP), DI									
  index_gen.go:294	0xb346bd		eba1			JMP github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrow(SB)		

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).acquireOneShotReadOrErr(SB) github.com/snissn/gomap/TreeDB/db/pools.go
  pools.go:45		0xbfbaa0		493b6610		CMPQ SP, 0x10(R14)											
  pools.go:45		0xbfbaa4		0f8625010000		JBE 0xbfbbcf												
  pools.go:45		0xbfbaaa		55			PUSHQ BP												
  pools.go:45		0xbfbaab		4889e5			MOVQ SP, BP												
  pools.go:45		0xbfbaae		4883ec28		SUBQ $0x28, SP												
  pools.go:46		0xbfbab2		4885c0			TESTQ AX, AX												
  pools.go:46		0xbfbab5		0f84ee000000		JE 0xbfbba9												
  pools.go:46		0xbfbabb		4889442438		MOVQ AX, 0x38(SP)											
  pools.go:49		0xbfbac0		e81b71e6ff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).publicationPoisonedError(SB)				
  pools.go:49		0xbfbac5		4885c0			TESTQ AX, AX												
  pools.go:49		0xbfbac8		0f85cd000000		JNE 0xbfbb9b												
  pools.go:52		0xbfbace		488d05eb1e2202		LEAQ github.com/snissn/gomap/TreeDB/db.oneShotReadPool(SB), AX						
  pools.go:52		0xbfbad5		e8a6108aff		CALL sync.(*Pool).Get(SB)										
  pools.go:52		0xbfbada		488d0d3f5dfa00		LEAQ 0xfa5d3f(IP), CX											
  pools.go:52		0xbfbae1		4839c8			CMPQ AX, CX												
  pools.go:52		0xbfbae4		0f85d5000000		JNE 0xbfbbbf												
  pools.go:52		0xbfbaea		48895c2420		MOVQ BX, 0x20(SP)											
  pools.go:53		0xbfbaef		90			NOPL													
  type.go:94		0xbfbaf0		ba01000000		MOVL $0x1, DX												
  type.go:94		0xbfbaf5		488b442438		MOVQ 0x38(SP), AX											
  type.go:94		0xbfbafa		f00fc190a8070000	LOCK XADDL DX, 0x7a8(AX)										
  type.go:94		0xbfbb02		ffc2			INCL DX													
  rwmutex.go:72		0xbfbb04		85d2			TESTL DX, DX												
  rwmutex.go:72		0xbfbb06		7d19			JGE 0xbfbb21												
  rwmutex.go:74		0xbfbb08		4805a4070000		ADDQ $0x7a4, AX												
  rwmutex.go:74		0xbfbb0e		31db			XORL BX, BX												
  rwmutex.go:74		0xbfbb10		31c9			XORL CX, CX												
  rwmutex.go:74		0xbfbb12		e8e92589ff		CALL sync.runtime_SemacquireRWMutexR(SB)								
  pools.go:54		0xbfbb17		488b442438		MOVQ 0x38(SP), AX											
  pools.go:54		0xbfbb1c		488b5c2420		MOVQ 0x20(SP), BX											
  pools.go:54		0xbfbb21		8403			TESTB AL, 0(BX)												
  pools.go:54		0xbfbb23		b901000000		MOVL $0x1, CX												
  pools.go:54		0xbfbb28		e8f3dceaff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld(SB)	
  type.go:94		0xbfbb2d		bbffffffff		MOVL $-0x1, BX												
  type.go:94		0xbfbb32		488b542438		MOVQ 0x38(SP), DX											
  type.go:94		0xbfbb37		f00fc19aa8070000	LOCK XADDL BX, 0x7a8(DX)										
  type.go:94		0xbfbb3f		ffcb			DECL BX													
  rwmutex.go:120	0xbfbb41		85db			TESTL BX, BX												
  rwmutex.go:120	0xbfbb43		7d15			JGE 0xbfbb5a												
  pools.go:54		0xbfbb45		8844241f		MOVB AL, 0x1f(SP)											
  pools.go:55		0xbfbb49		488d8298070000		LEAQ 0x798(DX), AX											
  rwmutex.go:122	0xbfbb50		e8eb1c8aff		CALL sync.(*RWMutex).rUnlockSlow(SB)									
  pools.go:54		0xbfbb55		0fb644241f		MOVZX 0x1f(SP), AX											
  pools.go:54		0xbfbb5a		84c0			TESTL AL, AL												
  pools.go:56		0xbfbb5c		740f			JE 0xbfbb6d												
  pools.go:60		0xbfbb5e		488b442420		MOVQ 0x20(SP), AX											
  pools.go:60		0xbfbb63		31db			XORL BX, BX												
  pools.go:60		0xbfbb65		31c9			XORL CX, CX												
  pools.go:60		0xbfbb67		4883c428		ADDQ $0x28, SP												
  pools.go:60		0xbfbb6b		5d			POPQ BP													
  pools.go:60		0xbfbb6c		c3			RET													
  pools.go:57		0xbfbb6d		488d054c1e2202		LEAQ github.com/snissn/gomap/TreeDB/db.oneShotReadPool(SB), AX						
  pools.go:57		0xbfbb74		488d1da55cfa00		LEAQ 0xfa5ca5(IP), BX											
  pools.go:57		0xbfbb7b		488b4c2420		MOVQ 0x20(SP), CX											
  pools.go:57		0xbfbb80		e83b0f8aff		CALL sync.(*Pool).Put(SB)										
  pools.go:58		0xbfbb85		488b1dc43f2102		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), BX						
  pools.go:58		0xbfbb8c		488b0dc53f2102		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), CX						
  pools.go:58		0xbfbb93		31c0			XORL AX, AX												
  pools.go:58		0xbfbb95		4883c428		ADDQ $0x28, SP												
  pools.go:58		0xbfbb99		5d			POPQ BP													
  pools.go:58		0xbfbb9a		c3			RET													
  pools.go:50		0xbfbb9b		4889d9			MOVQ BX, CX												
  pools.go:50		0xbfbb9e		4889c3			MOVQ AX, BX												
  pools.go:50		0xbfbba1		31c0			XORL AX, AX												
  pools.go:50		0xbfbba3		4883c428		ADDQ $0x28, SP												
  pools.go:50		0xbfbba7		5d			POPQ BP													
  pools.go:50		0xbfbba8		c3			RET													
  pools.go:47		0xbfbba9		488b1da03f2102		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), BX						
  pools.go:47		0xbfbbb0		488b0da13f2102		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), CX						
  pools.go:47		0xbfbbb7		31c0			XORL AX, AX												
  pools.go:47		0xbfbbb9		4883c428		ADDQ $0x28, SP												
  pools.go:47		0xbfbbbd		5d			POPQ BP													
  pools.go:47		0xbfbbbe		c3			RET													
  pools.go:52		0xbfbbbf		4889cb			MOVQ CX, BX												
  pools.go:52		0xbfbbc2		488d0d77d2f900		LEAQ 0xf9d277(IP), CX											
  pools.go:52		0xbfbbc9		e8324e82ff		CALL runtime.panicdottypeE(SB)										
  pools.go:52		0xbfbbce		90			NOPL													
  pools.go:45		0xbfbbcf		4889442408		MOVQ AX, 0x8(SP)											
  pools.go:45		0xbfbbd4		e8876b89ff		CALL runtime.morestack_noctxt.abi0(SB)									
  pools.go:45		0xbfbbd9		488b442408		MOVQ 0x8(SP), AX											
  pools.go:45		0xbfbbde		6690			NOPW													
  pools.go:45		0xbfbbe0		e9bbfeffff		JMP github.com/snissn/gomap/TreeDB/db.(*DB).acquireOneShotReadOrErr(SB)					

TEXT github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB) github.com/snissn/gomap/TreeDB/db/pools.go
  pools.go:63		0xbfbc00		493b6610		CMPQ SP, 0x10(R14)							
  pools.go:63		0xbfbc04		7657			JBE 0xbfbc5d								
  pools.go:63		0xbfbc06		55			PUSHQ BP								
  pools.go:63		0xbfbc07		4889e5			MOVQ SP, BP								
  pools.go:63		0xbfbc0a		4883ec28		SUBQ $0x28, SP								
  pools.go:67		0xbfbc0e		4889442438		MOVQ AX, 0x38(SP)							
  pools.go:66		0xbfbc13		8400			TESTB AL, 0(AX)								
  pools.go:66		0xbfbc15		bb01000000		MOVL $0x1, BX								
  pools.go:66		0xbfbc1a		e88106ebff		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead(SB)	
  pools.go:66		0xbfbc1f		90			NOPL									
  pools.go:67		0xbfbc20		4885c0			TESTQ AX, AX								
  pools.go:67		0xbfbc23		7406			JE 0xbfbc2b								
  pools.go:70		0xbfbc25		4883c428		ADDQ $0x28, SP								
  pools.go:70		0xbfbc29		5d			POPQ BP									
  pools.go:70		0xbfbc2a		c3			RET									
  pools.go:66		0xbfbc2b		48895c2420		MOVQ BX, 0x20(SP)							
  pools.go:66		0xbfbc30		4889442418		MOVQ AX, 0x18(SP)							
  pools.go:76		0xbfbc35		488d05841d2202		LEAQ github.com/snissn/gomap/TreeDB/db.oneShotReadPool(SB), AX		
  pools.go:76		0xbfbc3c		488d1ddd5bfa00		LEAQ 0xfa5bdd(IP), BX							
  pools.go:76		0xbfbc43		488b4c2438		MOVQ 0x38(SP), CX							
  pools.go:76		0xbfbc48		e8730e8aff		CALL sync.(*Pool).Put(SB)						
  pools.go:77		0xbfbc4d		488b442418		MOVQ 0x18(SP), AX							
  pools.go:77		0xbfbc52		488b5c2420		MOVQ 0x20(SP), BX							
  pools.go:77		0xbfbc57		4883c428		ADDQ $0x28, SP								
  pools.go:77		0xbfbc5b		5d			POPQ BP									
  pools.go:77		0xbfbc5c		c3			RET									
  pools.go:63		0xbfbc5d		4889442408		MOVQ AX, 0x8(SP)							
  pools.go:63		0xbfbc62		e8f96a89ff		CALL runtime.morestack_noctxt.abi0(SB)					
  pools.go:63		0xbfbc67		488b442408		MOVQ 0x8(SP), AX							
  pools.go:63		0xbfbc6c		eb92			JMP github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB)		

TEXT github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).putRead(SB) github.com/snissn/gomap/TreeDB/db/pools.go
  pools.go:97		0xbfbd40		493b6610		CMPQ SP, 0x10(R14)							
  pools.go:97		0xbfbd44		0f8677030000		JBE 0xbfc0c1								
  pools.go:97		0xbfbd4a		55			PUSHQ BP								
  pools.go:97		0xbfbd4b		4889e5			MOVQ SP, BP								
  pools.go:97		0xbfbd4e		4883ec38		SUBQ $0x38, SP								
  pools.go:98		0xbfbd52		4885db			TESTQ BX, BX								
  pools.go:98		0xbfbd55		0f8460030000		JE 0xbfc0bb								
  pools.go:98		0xbfbd5b		48895c2450		MOVQ BX, 0x50(SP)							
  pools.go:98		0xbfbd60		884c2458		MOVB CL, 0x58(SP)							
  pools.go:103		0xbfbd64		488d83c8030000		LEAQ 0x3c8(BX), AX							
  pools.go:103		0xbfbd6b		31db			XORL BX, BX								
  pools.go:103		0xbfbd6d		31c9			XORL CX, CX								
  pools.go:103		0xbfbd6f		31ff			XORL DI, DI								
  pools.go:103		0xbfbd71		31f6			XORL SI, SI								
  pools.go:103		0xbfbd73		e8c8a1adff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB)		
  pools.go:104		0xbfbd78		833da117330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:104		0xbfbd7f		90			NOPL									
  pools.go:104		0xbfbd80		7507			JNE 0xbfbd89								
  pools.go:104		0xbfbd82		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:104		0xbfbd87		eb14			JMP 0xbfbd9d								
  pools.go:104		0xbfbd89		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:104		0xbfbd8e		488b8b10060000		MOVQ 0x610(BX), CX							
  pools.go:104		0xbfbd95		e8a68489ff		CALL runtime.gcWriteBarrier1(SB)					
  pools.go:104		0xbfbd9a		49890b			MOVQ CX, 0(R11)								
  pools.go:104		0xbfbd9d		48c7831006000000000000	MOVQ $0x0, 0x610(BX)							
  pools.go:105		0xbfbda8		48c7831806000000000000	MOVQ $0x0, 0x618(BX)							
  pools.go:98		0xbfbdb3		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:98		0xbfbdb8		0f1f840000000000	NOPL 0(AX)(AX*1)							
  pools.go:98		0xbfbdc0		84c9			TESTL CL, CL								
  pools.go:106		0xbfbdc2		0f8522010000		JNE 0xbfbeea								
  pools.go:107		0xbfbdc8		488b93c0050000		MOVQ 0x5c0(BX), DX							
  pools.go:107		0xbfbdcf		4885d2			TESTQ DX, DX								
  pools.go:107		0xbfbdd2		7420			JE 0xbfbdf4								
  pools.go:107		0xbfbdd4		4869caf8000000		IMULQ $0xf8, DX, CX							
  pools.go:107		0xbfbddb		488b83b8050000		MOVQ 0x5b8(BX), AX							
  pools.go:107		0xbfbde2		4889cb			MOVQ CX, BX								
  pools.go:107		0xbfbde5		e856ed88ff		CALL runtime.memclrHasPointers(SB)					
  pools.go:98		0xbfbdea		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:108		0xbfbdef		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:108		0xbfbdf4		440f11bbc0050000	MOVUPS X15, 0x5c0(BX)							
  pools.go:108		0xbfbdfc		833d1d17330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:108		0xbfbe03		740f			JE 0xbfbe14								
  pools.go:108		0xbfbe05		488b93b8050000		MOVQ 0x5b8(BX), DX							
  pools.go:108		0xbfbe0c		e82f8489ff		CALL runtime.gcWriteBarrier1(SB)					
  pools.go:108		0xbfbe11		498913			MOVQ DX, 0(R11)								
  pools.go:108		0xbfbe14		48c783b805000000000000	MOVQ $0x0, 0x5b8(BX)							
  pools.go:111		0xbfbe1f		4883bbc004000000	CMPQ 0x4c0(BX), $0x0							
  pools.go:111		0xbfbe27		7466			JE 0xbfbe8f								
  pools.go:112		0xbfbe29		488d93c0040000		LEAQ 0x4c0(BX), DX							
  pools.go:112		0xbfbe30		833de916330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:112		0xbfbe37		7423			JE 0xbfbe5c								
  pools.go:112		0xbfbe39		4889542430		MOVQ DX, 0x30(SP)							
  pools.go:112		0xbfbe3e		488d053bb20201		LEAQ 0x102b23b(IP), AX							
  pools.go:112		0xbfbe45		4889d3			MOVQ DX, BX								
  pools.go:112		0xbfbe48		e8139482ff		CALL runtime.wbZero(SB)							
  pools.go:98		0xbfbe4d		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:112		0xbfbe52		488b542430		MOVQ 0x30(SP), DX							
  pools.go:116		0xbfbe57		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:112		0xbfbe5c		be03000000		MOVL $0x3, SI								
  pools.go:112		0xbfbe61		440f113a		MOVUPS X15, 0(DX)							
  pools.go:112		0xbfbe65		440f117a10		MOVUPS X15, 0x10(DX)							
  pools.go:112		0xbfbe6a		440f117a20		MOVUPS X15, 0x20(DX)							
  pools.go:112		0xbfbe6f		440f117a30		MOVUPS X15, 0x30(DX)							
  pools.go:112		0xbfbe74		4883c240		ADDQ $0x40, DX								
  pools.go:112		0xbfbe78		ffce			DECL SI									
  pools.go:112		0xbfbe7a		75e5			JNE 0xbfbe61								
  pools.go:112		0xbfbe7c		440f113a		MOVUPS X15, 0(DX)							
  pools.go:112		0xbfbe80		440f117a10		MOVUPS X15, 0x10(DX)							
  pools.go:112		0xbfbe85		440f117a20		MOVUPS X15, 0x20(DX)							
  pools.go:112		0xbfbe8a		440f117a28		MOVUPS X15, 0x28(DX)							
  pools.go:116		0xbfbe8f		488d9378020000		LEAQ 0x278(BX), DX							
  pools.go:116		0xbfbe96		833d8316330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:116		0xbfbe9d		7435			JE 0xbfbed4								
  pools.go:116		0xbfbe9f		4889542428		MOVQ DX, 0x28(SP)							
  pools.go:117		0xbfbea4		488b8ba8020000		MOVQ 0x2a8(BX), CX							
  pools.go:116		0xbfbeab		e8908389ff		CALL runtime.gcWriteBarrier1(SB)					
  pools.go:117		0xbfbeb0		49890b			MOVQ CX, 0(R11)								
  pools.go:116		0xbfbeb3		488d0566bb0701		LEAQ 0x107bb66(IP), AX							
  pools.go:116		0xbfbeba		4889d3			MOVQ DX, BX								
  pools.go:116		0xbfbebd		0f1f00			NOPL 0(AX)								
  pools.go:116		0xbfbec0		e89b9382ff		CALL runtime.wbZero(SB)							
  pools.go:98		0xbfbec5		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:116		0xbfbeca		488b542428		MOVQ 0x28(SP), DX							
  pools.go:117		0xbfbecf		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:116		0xbfbed4		440f113a		MOVUPS X15, 0(DX)							
  pools.go:116		0xbfbed8		440f117a10		MOVUPS X15, 0x10(DX)							
  pools.go:116		0xbfbedd		440f117a18		MOVUPS X15, 0x18(DX)							
  pools.go:117		0xbfbee2		440f11bba0020000	MOVUPS X15, 0x2a0(BX)							
  pools.go:119		0xbfbeea		833d2f16330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:119		0xbfbef1		7430			JE 0xbfbf23								
  pools.go:119		0xbfbef3		488b9328030000		MOVQ 0x328(BX), DX							
  pools.go:120		0xbfbefa		488bb330030000		MOVQ 0x330(BX), SI							
  pools.go:121		0xbfbf01		488bbb38030000		MOVQ 0x338(BX), DI							
  pools.go:122		0xbfbf08		4c8b8340030000		MOVQ 0x340(BX), R8							
  pools.go:119		0xbfbf0f		e88c8389ff		CALL runtime.gcWriteBarrier4(SB)					
  pools.go:119		0xbfbf14		498913			MOVQ DX, 0(R11)								
  pools.go:120		0xbfbf17		49897308		MOVQ SI, 0x8(R11)							
  pools.go:121		0xbfbf1b		49897b10		MOVQ DI, 0x10(R11)							
  pools.go:122		0xbfbf1f		4d894318		MOVQ R8, 0x18(R11)							
  pools.go:119		0xbfbf23		440f11bb28030000	MOVUPS X15, 0x328(BX)							
  pools.go:121		0xbfbf2b		440f11bb38030000	MOVUPS X15, 0x338(BX)							
  pools.go:123		0xbfbf33		c6834903000000		MOVB $0x0, 0x349(BX)							
  pools.go:124		0xbfbf3a		440f11bb60030000	MOVUPS X15, 0x360(BX)							
  pools.go:124		0xbfbf42		833dd715330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:124		0xbfbf49		741a			JE 0xbfbf65								
  pools.go:124		0xbfbf4b		488b9358030000		MOVQ 0x358(BX), DX							
  pools.go:125		0xbfbf52		488bb370030000		MOVQ 0x370(BX), SI							
  pools.go:124		0xbfbf59		e8028389ff		CALL runtime.gcWriteBarrier2(SB)					
  pools.go:124		0xbfbf5e		498913			MOVQ DX, 0(R11)								
  pools.go:125		0xbfbf61		49897308		MOVQ SI, 0x8(R11)							
  pools.go:124		0xbfbf65		48c7835803000000000000	MOVQ $0x0, 0x358(BX)							
  pools.go:125		0xbfbf70		440f11bb78030000	MOVUPS X15, 0x378(BX)							
  pools.go:125		0xbfbf78		48c7837003000000000000	MOVQ $0x0, 0x370(BX)							
  pools.go:126		0xbfbf83		488b9398030000		MOVQ 0x398(BX), DX							
  pools.go:126		0xbfbf8a		4885d2			TESTQ DX, DX								
  pools.go:126		0xbfbf8d		7420			JE 0xbfbfaf								
  pools.go:126		0xbfbf8f		488b8388030000		MOVQ 0x388(BX), AX							
  pools.go:127		0xbfbf96		48c1e203		SHLQ $0x3, DX								
  pools.go:127		0xbfbf9a		4889d3			MOVQ DX, BX								
  pools.go:127		0xbfbf9d		0f1f00			NOPL 0(AX)								
  pools.go:127		0xbfbfa0		e89beb88ff		CALL runtime.memclrHasPointers(SB)					
  pools.go:98		0xbfbfa5		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:129		0xbfbfaa		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:129		0xbfbfaf		48c7839003000000000000	MOVQ $0x0, 0x390(BX)							
  pools.go:130		0xbfbfba		833d5f15330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:130		0xbfbfc1		7504			JNE 0xbfbfc7								
  pools.go:98		0xbfbfc3		84c9			TESTL CL, CL								
  pools.go:130		0xbfbfc5		eb2b			JMP 0xbfbff2								
  pools.go:130		0xbfbfc7		488b93a0030000		MOVQ 0x3a0(BX), DX							
  pools.go:131		0xbfbfce		488bb3b8030000		MOVQ 0x3b8(BX), SI							
  pools.go:131		0xbfbfd5		488bbbc0030000		MOVQ 0x3c0(BX), DI							
  pools.go:131		0xbfbfdc		0f1f4000		NOPL 0(AX)								
  pools.go:130		0xbfbfe0		e89b8289ff		CALL runtime.gcWriteBarrier3(SB)					
  pools.go:130		0xbfbfe5		498913			MOVQ DX, 0(R11)								
  pools.go:131		0xbfbfe8		49897308		MOVQ SI, 0x8(R11)							
  pools.go:131		0xbfbfec		49897b10		MOVQ DI, 0x10(R11)							
  pools.go:98		0xbfbff0		84c9			TESTL CL, CL								
  pools.go:130		0xbfbff2		48c783a003000000000000	MOVQ $0x0, 0x3a0(BX)							
  pools.go:131		0xbfbffd		440f11bbb0030000	MOVUPS X15, 0x3b0(BX)							
  pools.go:131		0xbfc005		48c783c003000000000000	MOVQ $0x0, 0x3c0(BX)							
  pools.go:132		0xbfc010		48c783a803000000000000	MOVQ $0x0, 0x3a8(BX)							
  pools.go:133		0xbfc01b		754c			JNE 0xbfc069								
  pools.go:134		0xbfc01d		90			NOPL									
  mutex.go:63		0xbfc01e		31c0			XORL AX, AX								
  mutex.go:63		0xbfc020		ba01000000		MOVL $0x1, DX								
  mutex.go:63		0xbfc025		f00fb193f0050000	LOCK CMPXCHGL DX, 0x5f0(BX)						
  mutex.go:63		0xbfc02d		0f94c2			SETE DL									
  mutex.go:63		0xbfc030		84d2			TESTL DL, DL								
  mutex.go:63		0xbfc032		7516			JNE 0xbfc04a								
  mutex.go:46		0xbfc034		488d83f0050000		LEAQ 0x5f0(BX), AX							
  mutex.go:46		0xbfc03b		0f1f440000		NOPL 0(AX)(AX*1)							
  mutex.go:70		0xbfc040		e89b028aff		CALL internal/sync.(*Mutex).lockSlow(SB)				
  pools.go:135		0xbfc045		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:135		0xbfc04a		488b9bf8050000		MOVQ 0x5f8(BX), BX							
  pools.go:135		0xbfc051		488d05a84afd00		LEAQ 0xfd4aa8(IP), AX							
  pools.go:135		0xbfc058		e8c39182ff		CALL runtime.mapclear(SB)						
  pools.go:98		0xbfc05d		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:98		0xbfc062		84c9			TESTL CL, CL								
  type.go:184		0xbfc064		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:137		0xbfc069		90			NOPL									
  type.go:184		0xbfc06a		48b90000000000000080	MOVQ $0x8000000000000000, CX						
  type.go:184		0xbfc074		48878be8050000		XCHGQ CX, 0x5e8(BX)							
  pools.go:138		0xbfc07b		90			NOPL									
  type.go:22		0xbfc07c		b901000000		MOVL $0x1, CX								
  type.go:22		0xbfc081		878bd0050000		XCHGL CX, 0x5d0(BX)							
  pools.go:139		0xbfc087		90			NOPL									
  type.go:22		0xbfc088		b900000000		MOVL $0x0, CX								
  type.go:22		0xbfc08d		878be0050000		XCHGL CX, 0x5e0(BX)							
  pools.go:140		0xbfc093		7520			JNE 0xbfc0b5								
  pools.go:141		0xbfc095		90			NOPL									
  mutex.go:194		0xbfc096		b9ffffffff		MOVL $-0x1, CX								
  mutex.go:194		0xbfc09b		f00fc18bf0050000	LOCK XADDL CX, 0x5f0(BX)						
  mutex.go:194		0xbfc0a3		ffc9			DECL CX									
  mutex.go:195		0xbfc0a5		740e			JE 0xbfc0b5								
  mutex.go:65		0xbfc0a7		488d83f0050000		LEAQ 0x5f0(BX), AX							
  mutex.go:198		0xbfc0ae		89cb			MOVL CX, BX								
  mutex.go:198		0xbfc0b0		e80b058aff		CALL internal/sync.(*Mutex).unlockSlow(SB)				
  pools.go:144		0xbfc0b5		4883c438		ADDQ $0x38, SP								
  pools.go:144		0xbfc0b9		5d			POPQ BP									
  pools.go:144		0xbfc0ba		c3			RET									
  pools.go:99		0xbfc0bb		4883c438		ADDQ $0x38, SP								
  pools.go:99		0xbfc0bf		5d			POPQ BP									
  pools.go:99		0xbfc0c0		c3			RET									
  pools.go:97		0xbfc0c1		4889442408		MOVQ AX, 0x8(SP)							
  pools.go:97		0xbfc0c6		48895c2410		MOVQ BX, 0x10(SP)							
  pools.go:97		0xbfc0cb		884c2418		MOVB CL, 0x18(SP)							
  pools.go:97		0xbfc0cf		e88c6689ff		CALL runtime.morestack_noctxt.abi0(SB)					
  pools.go:97		0xbfc0d4		488b442408		MOVQ 0x8(SP), AX							
  pools.go:97		0xbfc0d9		488b5c2410		MOVQ 0x10(SP), BX							
  pools.go:97		0xbfc0de		0fb64c2418		MOVZX 0x18(SP), CX							
  pools.go:97		0xbfc0e3		e958fcffff		JMP github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).putRead(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned(SB) github.com/snissn/gomap/TreeDB/db/conditional_kv_contract_bench_test.go
  conditional_kv_contract_bench_test.go:12	0xdd2820		4c8da424c8f8ffff	LEAQ 0xfffff8c8(SP), R12							
  conditional_kv_contract_bench_test.go:12	0xdd2828		4d3b6610		CMPQ R12, 0x10(R14)								
  conditional_kv_contract_bench_test.go:12	0xdd282c		0f864d020000		JBE 0xdd2a7f									
  conditional_kv_contract_bench_test.go:12	0xdd2832		55			PUSHQ BP									
  conditional_kv_contract_bench_test.go:12	0xdd2833		4889e5			MOVQ SP, BP									
  conditional_kv_contract_bench_test.go:12	0xdd2836		4881ecb0070000		SUBQ $0x7b0, SP									
  conditional_kv_contract_bench_test.go:12	0xdd283d		66440fd6bc24a8070000	MOVQ X15, 0x7a8(SP)								
  conditional_kv_contract_bench_test.go:14	0xdd2847		48898424c0070000	MOVQ AX, 0x7c0(SP)								
  conditional_kv_contract_bench_test.go:12	0xdd284f		c684245707000000	MOVB $0x0, 0x757(SP)								
  conditional_kv_contract_bench_test.go:13	0xdd2857		8400			TESTB AL, 0(AX)									
  conditional_kv_contract_bench_test.go:13	0xdd2859		e8827576ff		CALL testing.(*common).TempDir(SB)						
  conditional_kv_contract_bench_test.go:13	0xdd285e		4889e7			MOVQ SP, DI									
  conditional_kv_contract_bench_test.go:13	0xdd2861		b9ea000000		MOVL $0xea, CX									
  conditional_kv_contract_bench_test.go:13	0xdd2866		4889c2			MOVQ AX, DX									
  conditional_kv_contract_bench_test.go:13	0xdd2869		31c0			XORL AX, AX									
  conditional_kv_contract_bench_test.go:13	0xdd286b		f348ab			REP; STOSQ AX, ES:0(DI)								
  conditional_kv_contract_bench_test.go:13	0xdd286e		4889542408		MOVQ DX, 0x8(SP)								
  conditional_kv_contract_bench_test.go:13	0xdd2873		48895c2410		MOVQ BX, 0x10(SP)								
  conditional_kv_contract_bench_test.go:13	0xdd2878		e8a3b3cdff		CALL github.com/snissn/gomap/TreeDB/db.Open(SB)					
  conditional_kv_contract_bench_test.go:13	0xdd287d		4889842470070000	MOVQ AX, 0x770(SP)								
  conditional_kv_contract_bench_test.go:14	0xdd2885		4885db			TESTQ BX, BX									
  conditional_kv_contract_bench_test.go:14	0xdd2888		7450			JE 0xdd28da									
  conditional_kv_contract_bench_test.go:15	0xdd288a		440f11bc2498070000	MOVUPS X15, 0x798(SP)								
  conditional_kv_contract_bench_test.go:15	0xdd2893		7404			JE 0xdd2899									
  conditional_kv_contract_bench_test.go:15	0xdd2895		488b5b08		MOVQ 0x8(BX), BX								
  conditional_kv_contract_bench_test.go:15	0xdd2899		48899c2498070000	MOVQ BX, 0x798(SP)								
  conditional_kv_contract_bench_test.go:15	0xdd28a1		48898c24a0070000	MOVQ CX, 0x7a0(SP)								
  conditional_kv_contract_bench_test.go:15	0xdd28a9		488b8424c0070000	MOVQ 0x7c0(SP), AX								
  conditional_kv_contract_bench_test.go:15	0xdd28b1		488d1d6c44f900		LEAQ 0xf9446c(IP), BX								
  conditional_kv_contract_bench_test.go:15	0xdd28b8		b908000000		MOVL $0x8, CX									
  conditional_kv_contract_bench_test.go:15	0xdd28bd		488dbc2498070000	LEAQ 0x798(SP), DI								
  conditional_kv_contract_bench_test.go:15	0xdd28c5		be01000000		MOVL $0x1, SI									
  conditional_kv_contract_bench_test.go:15	0xdd28ca		4989f0			MOVQ SI, R8									
  conditional_kv_contract_bench_test.go:15	0xdd28cd		e8ce6776ff		CALL testing.(*common).Fatalf(SB)						
  conditional_kv_contract_bench_test.go:17	0xdd28d2		488b842470070000	MOVQ 0x770(SP), AX								
  conditional_kv_contract_bench_test.go:17	0xdd28da		488d151f050000		LEAQ github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func1(SB), DX	
  conditional_kv_contract_bench_test.go:17	0xdd28e1		4889942480070000	MOVQ DX, 0x780(SP)								
  conditional_kv_contract_bench_test.go:17	0xdd28e9		4889842488070000	MOVQ AX, 0x788(SP)								
  conditional_kv_contract_bench_test.go:17	0xdd28f1		488b9424c0070000	MOVQ 0x7c0(SP), DX								
  conditional_kv_contract_bench_test.go:17	0xdd28f9		4889942490070000	MOVQ DX, 0x790(SP)								
  conditional_kv_contract_bench_test.go:17	0xdd2901		488d942480070000	LEAQ 0x780(SP), DX								
  conditional_kv_contract_bench_test.go:17	0xdd2909		48899424a8070000	MOVQ DX, 0x7a8(SP)								
  conditional_kv_contract_bench_test.go:17	0xdd2911		c684245707000001	MOVB $0x1, 0x757(SP)								
  conditional_kv_contract_bench_test.go:24	0xdd2919		488d0500b8d800		LEAQ 0xd8b800(IP), AX								
  conditional_kv_contract_bench_test.go:24	0xdd2920		bb64000000		MOVL $0x64, BX									
  conditional_kv_contract_bench_test.go:24	0xdd2925		4889d9			MOVQ BX, CX									
  conditional_kv_contract_bench_test.go:24	0xdd2928		e873c36bff		CALL runtime.makeslice(SB)							
  conditional_kv_contract_bench_test.go:24	0xdd292d		4889842478070000	MOVQ AX, 0x778(SP)								
  conditional_kv_contract_bench_test.go:25	0xdd2935		b810270000		MOVL $0x2710, AX								
  conditional_kv_contract_bench_test.go:25	0xdd293a		e8011d0000		CALL github.com/snissn/gomap/TreeDB/db.benchmarkConditionalTxnKeys(SB)		
  conditional_kv_contract_bench_test.go:25	0xdd293f		4889842468070000	MOVQ AX, 0x768(SP)								
  conditional_kv_contract_bench_test.go:25	0xdd2947		48899c2458070000	MOVQ BX, 0x758(SP)								
  conditional_kv_contract_bench_test.go:25	0xdd294f		48898c2460070000	MOVQ CX, 0x760(SP)								
  conditional_kv_contract_bench_test.go:26	0xdd2957		4889df			MOVQ BX, DI									
  conditional_kv_contract_bench_test.go:26	0xdd295a		4889ce			MOVQ CX, SI									
  conditional_kv_contract_bench_test.go:26	0xdd295d		4c8b842478070000	MOVQ 0x778(SP), R8								
  conditional_kv_contract_bench_test.go:26	0xdd2965		41b964000000		MOVL $0x64, R9									
  conditional_kv_contract_bench_test.go:26	0xdd296b		4d89ca			MOVQ R9, R10									
  conditional_kv_contract_bench_test.go:26	0xdd296e		488b9c2470070000	MOVQ 0x770(SP), BX								
  conditional_kv_contract_bench_test.go:26	0xdd2976		4889c1			MOVQ AX, CX									
  conditional_kv_contract_bench_test.go:26	0xdd2979		488b8424c0070000	MOVQ 0x7c0(SP), AX								
  conditional_kv_contract_bench_test.go:26	0xdd2981		e8ba1d0000		CALL github.com/snissn/gomap/TreeDB/db.seedConditionalTxnBenchmarkData(SB)	
  conditional_kv_contract_bench_test.go:28	0xdd2986		90			NOPL										
  benchmark.go:193				0xdd2987		488b8424c0070000	MOVQ 0x7c0(SP), AX								
  benchmark.go:193				0xdd298f		c6805202000001		MOVB $0x1, 0x252(AX)								
  conditional_kv_contract_bench_test.go:29	0xdd2996		e8e5a175ff		CALL testing.(*B).ResetTimer(SB)						
  conditional_kv_contract_bench_test.go:30	0xdd299b		488d053eb3eb00		LEAQ 0xebb33e(IP), AX								
  conditional_kv_contract_bench_test.go:30	0xdd29a2		e8f92065ff		CALL runtime.newobject(SB)							
  conditional_kv_contract_bench_test.go:30	0xdd29a7		488d15f2000000		LEAQ github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func2(SB), DX	
  conditional_kv_contract_bench_test.go:30	0xdd29ae		488910			MOVQ DX, 0(AX)									
  conditional_kv_contract_bench_test.go:30	0xdd29b1		48c7401064000000	MOVQ $0x64, 0x10(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd29b9		48c7401864000000	MOVQ $0x64, 0x18(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd29c1		833d58ab150200		CMPL runtime.writeBarrier(SB), $0x0						
  conditional_kv_contract_bench_test.go:30	0xdd29c8		7522			JNE 0xdd29ec									
  conditional_kv_contract_bench_test.go:30	0xdd29ca		488b8c2478070000	MOVQ 0x778(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xdd29d2		488b942470070000	MOVQ 0x770(SP), DX								
  conditional_kv_contract_bench_test.go:30	0xdd29da		488bb42468070000	MOVQ 0x768(SP), SI								
  conditional_kv_contract_bench_test.go:30	0xdd29e2		488bbc24c0070000	MOVQ 0x7c0(SP), DI								
  conditional_kv_contract_bench_test.go:30	0xdd29ea		eb34			JMP 0xdd2a20									
  conditional_kv_contract_bench_test.go:30	0xdd29ec		e8af186cff		CALL runtime.gcWriteBarrier4(SB)						
  conditional_kv_contract_bench_test.go:30	0xdd29f1		488b8c2478070000	MOVQ 0x778(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xdd29f9		49890b			MOVQ CX, 0(R11)									
  conditional_kv_contract_bench_test.go:30	0xdd29fc		488b942470070000	MOVQ 0x770(SP), DX								
  conditional_kv_contract_bench_test.go:30	0xdd2a04		49895308		MOVQ DX, 0x8(R11)								
  conditional_kv_contract_bench_test.go:30	0xdd2a08		488bb42468070000	MOVQ 0x768(SP), SI								
  conditional_kv_contract_bench_test.go:30	0xdd2a10		49897310		MOVQ SI, 0x10(R11)								
  conditional_kv_contract_bench_test.go:30	0xdd2a14		488bbc24c0070000	MOVQ 0x7c0(SP), DI								
  conditional_kv_contract_bench_test.go:30	0xdd2a1c		49897b18		MOVQ DI, 0x18(R11)								
  conditional_kv_contract_bench_test.go:30	0xdd2a20		48894808		MOVQ CX, 0x8(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd2a24		48895020		MOVQ DX, 0x20(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd2a28		488b8c2458070000	MOVQ 0x758(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xdd2a30		48894830		MOVQ CX, 0x30(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd2a34		488b8c2460070000	MOVQ 0x760(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xdd2a3c		48894838		MOVQ CX, 0x38(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd2a40		48897028		MOVQ SI, 0x28(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd2a44		48897840		MOVQ DI, 0x40(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd2a48		4889c3			MOVQ AX, BX									
  conditional_kv_contract_bench_test.go:30	0xdd2a4b		4889f8			MOVQ DI, AX									
  conditional_kv_contract_bench_test.go:30	0xdd2a4e		e8cdd675ff		CALL testing.(*B).RunParallel(SB)						
  conditional_kv_contract_bench_test.go:43	0xdd2a53		c684245707000000	MOVB $0x0, 0x757(SP)								
  conditional_kv_contract_bench_test.go:43	0xdd2a5b		488b9424a8070000	MOVQ 0x7a8(SP), DX								
  conditional_kv_contract_bench_test.go:43	0xdd2a63		488b0a			MOVQ 0(DX), CX									
  conditional_kv_contract_bench_test.go:43	0xdd2a66		ffd1			CALL CX										
  conditional_kv_contract_bench_test.go:43	0xdd2a68		4881c4b0070000		ADDQ $0x7b0, SP									
  conditional_kv_contract_bench_test.go:43	0xdd2a6f		5d			POPQ BP										
  conditional_kv_contract_bench_test.go:43	0xdd2a70		c3			RET										
  conditional_kv_contract_bench_test.go:43	0xdd2a71		e8aae567ff		CALL runtime.deferreturn(SB)							
  conditional_kv_contract_bench_test.go:43	0xdd2a76		4881c4b0070000		ADDQ $0x7b0, SP									
  conditional_kv_contract_bench_test.go:43	0xdd2a7d		5d			POPQ BP										
  conditional_kv_contract_bench_test.go:43	0xdd2a7e		c3			RET										
  conditional_kv_contract_bench_test.go:12	0xdd2a7f		4889442408		MOVQ AX, 0x8(SP)								
  conditional_kv_contract_bench_test.go:12	0xdd2a84		e8d7fc6bff		CALL runtime.morestack_noctxt.abi0(SB)						
  conditional_kv_contract_bench_test.go:12	0xdd2a89		488b442408		MOVQ 0x8(SP), AX								
  conditional_kv_contract_bench_test.go:12	0xdd2a8e		e98dfdffff		JMP github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned(SB)			

TEXT github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func2(SB) github.com/snissn/gomap/TreeDB/db/conditional_kv_contract_bench_test.go
  conditional_kv_contract_bench_test.go:30	0xdd2aa0		4c8d642480		LEAQ -0x80(SP), R12							
  conditional_kv_contract_bench_test.go:30	0xdd2aa5		4d3b6610		CMPQ R12, 0x10(R14)							
  conditional_kv_contract_bench_test.go:30	0xdd2aa9		0f8625030000		JBE 0xdd2dd4								
  conditional_kv_contract_bench_test.go:30	0xdd2aaf		55			PUSHQ BP								
  conditional_kv_contract_bench_test.go:30	0xdd2ab0		4889e5			MOVQ SP, BP								
  conditional_kv_contract_bench_test.go:30	0xdd2ab3		4881ecf8000000		SUBQ $0xf8, SP								
  time.go:182					0xdd2aba		4889842408010000	MOVQ AX, 0x108(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2ac2		488b4230		MOVQ 0x30(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2ac6		4889442458		MOVQ AX, 0x58(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2acb		488b4240		MOVQ 0x40(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2acf		4889442470		MOVQ AX, 0x70(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2ad4		488b4210		MOVQ 0x10(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2ad8		4889442440		MOVQ AX, 0x40(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2add		488b4228		MOVQ 0x28(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2ae1		4889442460		MOVQ AX, 0x60(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2ae6		488b4220		MOVQ 0x20(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2aea		4889442468		MOVQ AX, 0x68(SP)							
  conditional_kv_contract_bench_test.go:31	0xdd2aef		e86cbd6eff		CALL time.Now(SB)							
  time.go:189					0xdd2af4		90			NOPL									
  time.go:182					0xdd2af5		480fbae03f		BTQ $0x3f, AX								
  time.go:182					0xdd2afa		7316			JAE 0xdd2b12								
  time.go:183					0xdd2afc		488d0c00		LEAQ 0(AX)(AX*1), CX							
  time.go:183					0xdd2b00		48c1e91f		SHRQ $0x1f, CX								
  time.go:183					0xdd2b04		48ba807fb1d70d000000	MOVQ $0xdd7b17f80, DX							
  time.go:183					0xdd2b0e		488d1c11		LEAQ 0(CX)(DX*1), BX							
  time.go:1461					0xdd2b12		4869cb00ca9a3b		IMULQ $0x3b9aca00, BX, CX						
  time.go:177					0xdd2b19		25ffffff3f		ANDL $0x3fffffff, AX							
  time.go:1461					0xdd2b1e		4863d0			MOVSXD AX, DX								
  time.go:1461					0xdd2b21		4801d1			ADDQ DX, CX								
  time.go:1461					0xdd2b24		48ba00001a3deb03b2a1	MOVQ $0xa1b203eb3d1a0000, DX						
  time.go:1461					0xdd2b2e		4801d1			ADDQ DX, CX								
  time.go:1461					0xdd2b31		48894c2438		MOVQ CX, 0x38(SP)							
  rand.go:52					0xdd2b36		90			NOPL									
  rand.go:56					0xdd2b37		488d05223fe800		LEAQ 0xe83f22(IP), AX							
  rand.go:56					0xdd2b3e		6690			NOPW									
  rand.go:56					0xdd2b40		e85b1f65ff		CALL runtime.newobject(SB)						
  rand.go:56					0xdd2b45		48898424f0000000	MOVQ AX, 0xf0(SP)							
  rand.go:57					0xdd2b4d		488b5c2438		MOVQ 0x38(SP), BX							
  rand.go:57					0xdd2b52		e8c97075ff		CALL math/rand.(*rngSource).Seed(SB)					
  rand.go:79					0xdd2b57		488b0d02260402		MOVQ github.com/snissn/gomap/TreeDB/db..typeAssert.174(SB), CX		
  rand.go:79					0xdd2b5e		488b11			MOVQ 0(CX), DX								
  rand.go:79					0xdd2b61		8b1d51f00e01		MOVL go:itab.*math/rand.rngSource,math/rand.Source+16(SB), BX		
  rand.go:79					0xdd2b67		eb03			JMP 0xdd2b6c								
  rand.go:79					0xdd2b69		4889f3			MOVQ SI, BX								
  rand.go:79					0xdd2b6c		4889de			MOVQ BX, SI								
  rand.go:79					0xdd2b6f		4821d3			ANDQ DX, BX								
  rand.go:79					0xdd2b72		48c1e304		SHLQ $0x4, BX								
  rand.go:79					0xdd2b76		488b7c0b08		MOVQ 0x8(BX)(CX*1), DI							
  rand.go:79					0xdd2b7b		4c8d055e33e100		LEAQ 0xe1335e(IP), R8							
  rand.go:79					0xdd2b82		4c39c7			CMPQ DI, R8								
  rand.go:79					0xdd2b85		741b			JE 0xdd2ba2								
  rand.go:79					0xdd2b87		48ffc6			INCQ SI									
  rand.go:79					0xdd2b8a		4885ff			TESTQ DI, DI								
  rand.go:79					0xdd2b8d		75da			JNE 0xdd2b69								
  rand.go:79					0xdd2b8f		488d05ca250402		LEAQ github.com/snissn/gomap/TreeDB/db..typeAssert.174(SB), AX		
  rand.go:79					0xdd2b96		4c89c3			MOVQ R8, BX								
  rand.go:79					0xdd2b99		e822e364ff		CALL runtime.typeAssert(SB)						
  rand.go:79					0xdd2b9e		6690			NOPW									
  rand.go:79					0xdd2ba0		eb05			JMP 0xdd2ba7								
  rand.go:79					0xdd2ba2		488b440b10		MOVQ 0x10(BX)(CX*1), AX							
  rand.go:80					0xdd2ba7		488d942480000000	LEAQ 0x80(SP), DX							
  rand.go:80					0xdd2baf		440f113a		MOVUPS X15, 0(DX)							
  rand.go:80					0xdd2bb3		440f117a10		MOVUPS X15, 0x10(DX)							
  rand.go:80					0xdd2bb8		440f117a20		MOVUPS X15, 0x20(DX)							
  rand.go:80					0xdd2bbd		488d15e4ef0e01		LEAQ go:itab.*math/rand.rngSource,math/rand.Source(SB), DX		
  rand.go:80					0xdd2bc4		4889942480000000	MOVQ DX, 0x80(SP)							
  rand.go:80					0xdd2bcc		488b9424f0000000	MOVQ 0xf0(SP), DX							
  rand.go:80					0xdd2bd4		4889942488000000	MOVQ DX, 0x88(SP)							
  rand.go:80					0xdd2bdc		4889842490000000	MOVQ AX, 0x90(SP)							
  rand.go:80					0xdd2be4		4889942498000000	MOVQ DX, 0x98(SP)							
  conditional_kv_contract_bench_test.go:32	0xdd2bec		488d052db5d800		LEAQ 0xd8b52d(IP), AX							
  conditional_kv_contract_bench_test.go:32	0xdd2bf3		31db			XORL BX, BX								
  conditional_kv_contract_bench_test.go:32	0xdd2bf5		488b4c2440		MOVQ 0x40(SP), CX							
  conditional_kv_contract_bench_test.go:32	0xdd2bfa		e8a1c06bff		CALL runtime.makeslice(SB)						
  conditional_kv_contract_bench_test.go:32	0xdd2bff		4889442478		MOVQ AX, 0x78(SP)							
  conditional_kv_contract_bench_test.go:33	0xdd2c04		eb05			JMP 0xdd2c0b								
  conditional_kv_contract_bench_test.go:34	0xdd2c06		488b442478		MOVQ 0x78(SP), AX							
  benchmark.go:923				0xdd2c0b		488b8c2408010000	MOVQ 0x108(SP), CX							
  benchmark.go:923				0xdd2c13		4883791000		CMPQ 0x10(CX), $0x0							
  benchmark.go:923				0xdd2c18		753c			JNE 0xdd2c56								
  benchmark.go:924				0xdd2c1a		488b11			MOVQ 0(CX), DX								
  benchmark.go:924				0xdd2c1d		488b7108		MOVQ 0x8(CX), SI							
  type.go:195					0xdd2c21		4889f7			MOVQ SI, DI								
  type.go:195					0xdd2c24		f0480fc132		LOCK XADDQ SI, 0(DX)							
  benchmark.go:925				0xdd2c29		488b5118		MOVQ 0x18(CX), DX							
  type.go:195					0xdd2c2d		4801fe			ADDQ DI, SI								
  benchmark.go:925				0xdd2c30		4839f2			CMPQ DX, SI								
  benchmark.go:925				0xdd2c33		720a			JB 0xdd2c3f								
  benchmark.go:926				0xdd2c35		488b5108		MOVQ 0x8(CX), DX							
  benchmark.go:926				0xdd2c39		48895110		MOVQ DX, 0x10(CX)							
  benchmark.go:926				0xdd2c3d		eb17			JMP 0xdd2c56								
  benchmark.go:927				0xdd2c3f		488b7908		MOVQ 0x8(CX), DI							
  benchmark.go:927				0xdd2c43		4801fa			ADDQ DI, DX								
  benchmark.go:927				0xdd2c46		4839d6			CMPQ SI, DX								
  benchmark.go:927				0xdd2c49		0f8376010000		JAE 0xdd2dc5								
  benchmark.go:928				0xdd2c4f		4829f2			SUBQ SI, DX								
  benchmark.go:928				0xdd2c52		48895110		MOVQ DX, 0x10(CX)							
  benchmark.go:933				0xdd2c56		48ff4910		DECQ 0x10(CX)								
  conditional_kv_contract_bench_test.go:34	0xdd2c5a		488d842480000000	LEAQ 0x80(SP), AX							
  conditional_kv_contract_bench_test.go:34	0xdd2c62		bb10270000		MOVL $0x2710, BX							
  conditional_kv_contract_bench_test.go:34	0xdd2c67		e8946175ff		CALL math/rand.(*Rand).Intn(SB)						
  conditional_kv_contract_bench_test.go:34	0xdd2c6c		488b4c2458		MOVQ 0x58(SP), CX							
  conditional_kv_contract_bench_test.go:34	0xdd2c71		4839c8			CMPQ AX, CX								
  conditional_kv_contract_bench_test.go:34	0xdd2c74		0f8354010000		JAE 0xdd2dce								
  conditional_kv_contract_bench_test.go:34	0xdd2c7a		488d1440		LEAQ 0(AX)(AX*2), DX							
  conditional_kv_contract_bench_test.go:34	0xdd2c7e		4c8b542460		MOVQ 0x60(SP), R10							
  conditional_kv_contract_bench_test.go:34	0xdd2c83		498b1cd2		MOVQ 0(R10)(DX*8), BX							
  conditional_kv_contract_bench_test.go:34	0xdd2c87		498b4cd208		MOVQ 0x8(R10)(DX*8), CX							
  conditional_kv_contract_bench_test.go:34	0xdd2c8c		498b7cd210		MOVQ 0x10(R10)(DX*8), DI						
  conditional_kv_contract_bench_test.go:34	0xdd2c91		488b442468		MOVQ 0x68(SP), AX							
  conditional_kv_contract_bench_test.go:34	0xdd2c96		488b742478		MOVQ 0x78(SP), SI							
  conditional_kv_contract_bench_test.go:34	0xdd2c9b		4531c0			XORL R8, R8								
  conditional_kv_contract_bench_test.go:34	0xdd2c9e		4c8b4c2440		MOVQ 0x40(SP), R9							
  conditional_kv_contract_bench_test.go:34	0xdd2ca3		e87836c6ff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend(SB)	
  conditional_kv_contract_bench_test.go:34	0xdd2ca8		48897c2448		MOVQ DI, 0x48(SP)							
  conditional_kv_contract_bench_test.go:35	0xdd2cad		4885f6			TESTQ SI, SI								
  conditional_kv_contract_bench_test.go:35	0xdd2cb0		7456			JE 0xdd2d08								
  conditional_kv_contract_bench_test.go:34	0xdd2cb2		48895c2450		MOVQ BX, 0x50(SP)							
  conditional_kv_contract_bench_test.go:36	0xdd2cb7		440f11bc24e0000000	MOVUPS X15, 0xe0(SP)							
  conditional_kv_contract_bench_test.go:36	0xdd2cc0		7404			JE 0xdd2cc6								
  conditional_kv_contract_bench_test.go:36	0xdd2cc2		488b7608		MOVQ 0x8(SI), SI							
  conditional_kv_contract_bench_test.go:36	0xdd2cc6		4889b424e0000000	MOVQ SI, 0xe0(SP)							
  conditional_kv_contract_bench_test.go:36	0xdd2cce		4c898424e8000000	MOVQ R8, 0xe8(SP)							
  conditional_kv_contract_bench_test.go:36	0xdd2cd6		488b442470		MOVQ 0x70(SP), AX							
  conditional_kv_contract_bench_test.go:36	0xdd2cdb		8400			TESTB AL, 0(AX)								
  conditional_kv_contract_bench_test.go:36	0xdd2cdd		488d1d3fc1fa00		LEAQ 0xfac13f(IP), BX							
  conditional_kv_contract_bench_test.go:36	0xdd2ce4		b916000000		MOVL $0x16, CX								
  conditional_kv_contract_bench_test.go:36	0xdd2ce9		488dbc24e0000000	LEAQ 0xe0(SP), DI							
  conditional_kv_contract_bench_test.go:36	0xdd2cf1		be01000000		MOVL $0x1, SI								
  conditional_kv_contract_bench_test.go:36	0xdd2cf6		4989f0			MOVQ SI, R8								
  conditional_kv_contract_bench_test.go:36	0xdd2cf9		e8a26376ff		CALL testing.(*common).Fatalf(SB)					
  conditional_kv_contract_bench_test.go:38	0xdd2cfe		488b5c2450		MOVQ 0x50(SP), BX							
  conditional_kv_contract_bench_test.go:38	0xdd2d03		488b7c2448		MOVQ 0x48(SP), DI							
  conditional_kv_contract_bench_test.go:38	0xdd2d08		488b4c2440		MOVQ 0x40(SP), CX							
  conditional_kv_contract_bench_test.go:38	0xdd2d0d		4839cb			CMPQ BX, CX								
  conditional_kv_contract_bench_test.go:38	0xdd2d10		7509			JNE 0xdd2d1b								
  conditional_kv_contract_bench_test.go:38	0xdd2d12		4885ff			TESTQ DI, DI								
  conditional_kv_contract_bench_test.go:38	0xdd2d15		0f85ebfeffff		JNE 0xdd2c06								
  conditional_kv_contract_bench_test.go:39	0xdd2d1b		488d8c24b0000000	LEAQ 0xb0(SP), CX							
  conditional_kv_contract_bench_test.go:39	0xdd2d23		440f1139		MOVUPS X15, 0(CX)							
  conditional_kv_contract_bench_test.go:39	0xdd2d27		440f117910		MOVUPS X15, 0x10(CX)							
  conditional_kv_contract_bench_test.go:39	0xdd2d2c		440f117920		MOVUPS X15, 0x20(CX)							
  conditional_kv_contract_bench_test.go:39	0xdd2d31		4889d8			MOVQ BX, AX								
  conditional_kv_contract_bench_test.go:39	0xdd2d34		e8476e6bff		CALL runtime.convT64(SB)						
  conditional_kv_contract_bench_test.go:39	0xdd2d39		488d0da0b5d800		LEAQ 0xd8b5a0(IP), CX							
  conditional_kv_contract_bench_test.go:39	0xdd2d40		48898c24b0000000	MOVQ CX, 0xb0(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d48		48898424b8000000	MOVQ AX, 0xb8(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d50		488b442448		MOVQ 0x48(SP), AX							
  conditional_kv_contract_bench_test.go:39	0xdd2d55		e8266e6bff		CALL runtime.convT64(SB)						
  conditional_kv_contract_bench_test.go:39	0xdd2d5a		488d0d7fc1d800		LEAQ 0xd8c17f(IP), CX							
  conditional_kv_contract_bench_test.go:39	0xdd2d61		48898c24c0000000	MOVQ CX, 0xc0(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d69		48898424c8000000	MOVQ AX, 0xc8(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d71		488b442440		MOVQ 0x40(SP), AX							
  conditional_kv_contract_bench_test.go:39	0xdd2d76		e8056e6bff		CALL runtime.convT64(SB)						
  conditional_kv_contract_bench_test.go:39	0xdd2d7b		488d0d5eb5d800		LEAQ 0xd8b55e(IP), CX							
  conditional_kv_contract_bench_test.go:39	0xdd2d82		48898c24d0000000	MOVQ CX, 0xd0(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d8a		48898424d8000000	MOVQ AX, 0xd8(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d92		488b442470		MOVQ 0x70(SP), AX							
  conditional_kv_contract_bench_test.go:39	0xdd2d97		8400			TESTB AL, 0(AX)								
  conditional_kv_contract_bench_test.go:39	0xdd2d99		488d1d2cd20801		LEAQ 0x108d22c(IP), BX							
  conditional_kv_contract_bench_test.go:39	0xdd2da0		b946000000		MOVL $0x46, CX								
  conditional_kv_contract_bench_test.go:39	0xdd2da5		488dbc24b0000000	LEAQ 0xb0(SP), DI							
  conditional_kv_contract_bench_test.go:39	0xdd2dad		be03000000		MOVL $0x3, SI								
  conditional_kv_contract_bench_test.go:39	0xdd2db2		4989f0			MOVQ SI, R8								
  conditional_kv_contract_bench_test.go:39	0xdd2db5		e8e66276ff		CALL testing.(*common).Fatalf(SB)					
  conditional_kv_contract_bench_test.go:34	0xdd2dba		488b4c2440		MOVQ 0x40(SP), CX							
  conditional_kv_contract_bench_test.go:34	0xdd2dbf		90			NOPL									
  conditional_kv_contract_bench_test.go:39	0xdd2dc0		e941feffff		JMP 0xdd2c06								
  conditional_kv_contract_bench_test.go:42	0xdd2dc5		4881c4f8000000		ADDQ $0xf8, SP								
  conditional_kv_contract_bench_test.go:42	0xdd2dcc		5d			POPQ BP									
  conditional_kv_contract_bench_test.go:42	0xdd2dcd		c3			RET									
  conditional_kv_contract_bench_test.go:34	0xdd2dce		e82d186cff		CALL runtime.panicBounds(SB)						
  conditional_kv_contract_bench_test.go:34	0xdd2dd3		90			NOPL									
  conditional_kv_contract_bench_test.go:30	0xdd2dd4		4889442408		MOVQ AX, 0x8(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2dd9		e8e2f86bff		CALL runtime.morestack.abi0(SB)						
  conditional_kv_contract_bench_test.go:30	0xdd2dde		488b442408		MOVQ 0x8(SP), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2de3		e9b8fcffff		JMP github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func2(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func1(SB) github.com/snissn/gomap/TreeDB/db/conditional_kv_contract_bench_test.go
  conditional_kv_contract_bench_test.go:17	0xdd2e00		493b6610		CMPQ SP, 0x10(R14)							
  conditional_kv_contract_bench_test.go:17	0xdd2e04		7665			JBE 0xdd2e6b								
  conditional_kv_contract_bench_test.go:17	0xdd2e06		55			PUSHQ BP								
  conditional_kv_contract_bench_test.go:17	0xdd2e07		4889e5			MOVQ SP, BP								
  conditional_kv_contract_bench_test.go:17	0xdd2e0a		4883ec48		SUBQ $0x48, SP								
  conditional_kv_contract_bench_test.go:17	0xdd2e0e		488b4208		MOVQ 0x8(DX), AX							
  conditional_kv_contract_bench_test.go:17	0xdd2e12		488b4a10		MOVQ 0x10(DX), CX							
  conditional_kv_contract_bench_test.go:17	0xdd2e16		48894c2430		MOVQ CX, 0x30(SP)							
  conditional_kv_contract_bench_test.go:18	0xdd2e1b		0f1f440000		NOPL 0(AX)(AX*1)							
  conditional_kv_contract_bench_test.go:18	0xdd2e20		e87b20ceff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).Close(SB)			
  conditional_kv_contract_bench_test.go:18	0xdd2e25		4885c0			TESTQ AX, AX								
  conditional_kv_contract_bench_test.go:18	0xdd2e28		743b			JE 0xdd2e65								
  conditional_kv_contract_bench_test.go:19	0xdd2e2a		440f117c2438		MOVUPS X15, 0x38(SP)							
  conditional_kv_contract_bench_test.go:19	0xdd2e30		7404			JE 0xdd2e36								
  conditional_kv_contract_bench_test.go:19	0xdd2e32		488b4008		MOVQ 0x8(AX), AX							
  conditional_kv_contract_bench_test.go:19	0xdd2e36		4889442438		MOVQ AX, 0x38(SP)							
  conditional_kv_contract_bench_test.go:19	0xdd2e3b		48895c2440		MOVQ BX, 0x40(SP)							
  conditional_kv_contract_bench_test.go:19	0xdd2e40		488b442430		MOVQ 0x30(SP), AX							
  conditional_kv_contract_bench_test.go:19	0xdd2e45		8400			TESTB AL, 0(AX)								
  conditional_kv_contract_bench_test.go:19	0xdd2e47		488d1d9d4cf900		LEAQ 0xf94c9d(IP), BX							
  conditional_kv_contract_bench_test.go:19	0xdd2e4e		b909000000		MOVL $0x9, CX								
  conditional_kv_contract_bench_test.go:19	0xdd2e53		488d7c2438		LEAQ 0x38(SP), DI							
  conditional_kv_contract_bench_test.go:19	0xdd2e58		be01000000		MOVL $0x1, SI								
  conditional_kv_contract_bench_test.go:19	0xdd2e5d		4989f0			MOVQ SI, R8								
  conditional_kv_contract_bench_test.go:19	0xdd2e60		e83b6276ff		CALL testing.(*common).Fatalf(SB)					
  conditional_kv_contract_bench_test.go:21	0xdd2e65		4883c448		ADDQ $0x48, SP								
  conditional_kv_contract_bench_test.go:21	0xdd2e69		5d			POPQ BP									
  conditional_kv_contract_bench_test.go:21	0xdd2e6a		c3			RET									
  conditional_kv_contract_bench_test.go:17	0xdd2e6b		e850f86bff		CALL runtime.morestack.abi0(SB)						
  conditional_kv_contract_bench_test.go:17	0xdd2e70		eb8e			JMP github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close-fm(SB) <autogenerated>
  <autogenerated>:1	0x1166f20		493b6610		CMPQ SP, 0x10(R14)							
  <autogenerated>:1	0x1166f24		7617			JBE 0x1166f3d								
  <autogenerated>:1	0x1166f26		55			PUSHQ BP								
  <autogenerated>:1	0x1166f27		4889e5			MOVQ SP, BP								
  <autogenerated>:1	0x1166f2a		4883ec08		SUBQ $0x8, SP								
  <autogenerated>:1	0x1166f2e		488b4208		MOVQ 0x8(DX), AX							
  <autogenerated>:1	0x1166f32		e8c94ca9ff		CALL github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB)		
  <autogenerated>:1	0x1166f37		4883c408		ADDQ $0x8, SP								
  <autogenerated>:1	0x1166f3b		5d			POPQ BP									
  <autogenerated>:1	0x1166f3c		c3			RET									
  <autogenerated>:1	0x1166f3d		0f1f00			NOPL 0(AX)								
  <autogenerated>:1	0x1166f40		e87bb732ff		CALL runtime.morestack.abi0(SB)						
  <autogenerated>:1	0x1166f45		ebd9			JMP github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close-fm(SB)	
