TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:369		0x6d5f00		493b6610		CMPQ SP, 0x10(R14)						
  tree.go:369		0x6d5f04		0f86600b0000		JBE 0x6d6a6a							
  tree.go:369		0x6d5f0a		55			PUSHQ BP							
  tree.go:369		0x6d5f0b		4889e5			MOVQ SP, BP							
  tree.go:369		0x6d5f0e		4883ec18		SUBQ $0x18, SP							
  tree.go:369		0x6d5f12		48894c2438		MOVQ CX, 0x38(SP)						
  tree.go:369		0x6d5f17		48897c2440		MOVQ DI, 0x40(SP)						
  tree.go:370		0x6d5f1c		4889442428		MOVQ AX, 0x28(SP)						
  tree.go:370		0x6d5f21		4889742448		MOVQ SI, 0x48(SP)						
  tree.go:370		0x6d5f26		4885c9			TESTQ CX, CX							
  tree.go:370		0x6d5f29		0f8496000000		JE 0x6d5fc5							
  tree.go:374		0x6d5f2f		8400			TESTB AL, 0(AX)							
  tree.go:374		0x6d5f31		833de875850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:374		0x6d5f38		7417			JE 0x6d5f51							
  tree.go:374		0x6d5f3a		488b10			MOVQ 0(AX), DX							
  tree.go:375		0x6d5f3d		4c8b4008		MOVQ 0x8(AX), R8						
  tree.go:374		0x6d5f41		e83ae3dbff		CALL runtime.gcWriteBarrier3(SB)				
  tree.go:374		0x6d5f46		498913			MOVQ DX, 0(R11)							
  tree.go:375		0x6d5f49		49895b08		MOVQ BX, 0x8(R11)						
  tree.go:375		0x6d5f4d		4d894310		MOVQ R8, 0x10(R11)						
  tree.go:374		0x6d5f51		48c70000000000		MOVQ $0x0, 0(AX)						
  tree.go:375		0x6d5f58		48895808		MOVQ BX, 0x8(AX)						
  tree.go:376		0x6d5f5c		440f11b8d8000000	MOVUPS X15, 0xd8(AX)						
  tree.go:378		0x6d5f64		c680e800000000		MOVB $0x0, 0xe8(AX)						
  tree.go:379		0x6d5f6b		48894810		MOVQ CX, 0x10(AX)						
  tree.go:379		0x6d5f6f		833daa75850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:379		0x6d5f76		7505			JNE 0x6d5f7d							
  tree.go:370		0x6d5f78		4885c9			TESTQ CX, CX							
  tree.go:379		0x6d5f7b		eb13			JMP 0x6d5f90							
  tree.go:379		0x6d5f7d		488b5018		MOVQ 0x18(AX), DX						
  tree.go:379		0x6d5f81		e8dae2dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:379		0x6d5f86		49893b			MOVQ DI, 0(R11)							
  tree.go:379		0x6d5f89		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d5f8d		4885c9			TESTQ CX, CX							
  tree.go:370		0x6d5f90		48897c2440		MOVQ DI, 0x40(SP)						
  tree.go:370		0x6d5f95		48894c2438		MOVQ CX, 0x38(SP)						
  tree.go:379		0x6d5f9a		48897818		MOVQ DI, 0x18(AX)						
  tree.go:380		0x6d5f9e		6690			NOPW								
  tree.go:380		0x6d5fa0		7417			JE 0x6d5fb9							
  tree.go:380		0x6d5fa2		488b5908		MOVQ 0x8(CX), BX						
  tree.go:380		0x6d5fa6		488b15930c7402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.15(SB), DX	
  tree.go:380		0x6d5fad		4c8b02			MOVQ 0(DX), R8							
  tree.go:380		0x6d5fb0		448b4910		MOVL 0x10(CX), R9						
  tree.go:380		0x6d5fb4		e95c0a0000		JMP 0x6d6a15							
  tree.go:370		0x6d5fb9		4889ca			MOVQ CX, DX							
  tree.go:370		0x6d5fbc		0f1f4000		NOPL 0(AX)							
  tree.go:380		0x6d5fc0		e980000000		JMP 0x6d6045							
  tree.go:371		0x6d5fc5		8400			TESTB AL, 0(AX)							
  tree.go:371		0x6d5fc7		833d5275850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:371		0x6d5fce		7433			JE 0x6d6003							
  tree.go:370		0x6d5fd0		48895c2430		MOVQ BX, 0x30(SP)						
  tree.go:371		0x6d5fd5		488b4808		MOVQ 0x8(AX), CX						
  tree.go:371		0x6d5fd9		e882e2dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:371		0x6d5fde		49891b			MOVQ BX, 0(R11)							
  tree.go:371		0x6d5fe1		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:371		0x6d5fe5		4889c3			MOVQ AX, BX							
  tree.go:371		0x6d5fe8		488d0531746301		LEAQ 0x1637431(IP), AX						
  tree.go:371		0x6d5fef		e86cf2d4ff		CALL runtime.wbZero(SB)						
  tree.go:371		0x6d5ff4		488b442428		MOVQ 0x28(SP), AX						
  tree.go:371		0x6d5ff9		488b5c2430		MOVQ 0x30(SP), BX						
  tree.go:371		0x6d5ffe		488b742448		MOVQ 0x48(SP), SI						
  tree.go:371		0x6d6003		4889c1			MOVQ AX, CX							
  tree.go:371		0x6d6006		ba03000000		MOVL $0x3, DX							
  tree.go:371		0x6d600b		440f1138		MOVUPS X15, 0(AX)						
  tree.go:371		0x6d600f		440f117810		MOVUPS X15, 0x10(AX)						
  tree.go:371		0x6d6014		440f117820		MOVUPS X15, 0x20(AX)						
  tree.go:371		0x6d6019		440f117830		MOVUPS X15, 0x30(AX)						
  tree.go:371		0x6d601e		4883c040		ADDQ $0x40, AX							
  tree.go:371		0x6d6022		ffca			DECL DX								
  tree.go:371		0x6d6024		75e5			JNE 0x6d600b							
  tree.go:371		0x6d6026		440f1138		MOVUPS X15, 0(AX)						
  tree.go:371		0x6d602a		440f117810		MOVUPS X15, 0x10(AX)						
  tree.go:371		0x6d602f		440f117820		MOVUPS X15, 0x20(AX)						
  tree.go:371		0x6d6034		48895908		MOVQ BX, 0x8(CX)						
  tree.go:371		0x6d6038		4889b1d0000000		MOVQ SI, 0xd0(CX)						
  tree.go:372		0x6d603f		4883c418		ADDQ $0x18, SP							
  tree.go:372		0x6d6043		5d			POPQ BP								
  tree.go:372		0x6d6044		c3			RET								
  tree.go:380		0x6d6045		4885c9			TESTQ CX, CX							
  tree.go:380		0x6d6048		742b			JE 0x6d6075							
  tree.go:381		0x6d604a		48894820		MOVQ CX, 0x20(AX)						
  tree.go:381		0x6d604e		833dcb74850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:381		0x6d6055		7505			JNE 0x6d605c							
  tree.go:370		0x6d6057		4885d2			TESTQ DX, DX							
  tree.go:381		0x6d605a		eb13			JMP 0x6d606f							
  tree.go:381		0x6d605c		488b4828		MOVQ 0x28(AX), CX						
  tree.go:381		0x6d6060		e8fbe1dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:381		0x6d6065		49893b			MOVQ DI, 0(R11)							
  tree.go:381		0x6d6068		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:370		0x6d606c		4885d2			TESTQ DX, DX							
  tree.go:381		0x6d606f		48897828		MOVQ DI, 0x28(AX)						
  tree.go:381		0x6d6073		eb2d			JMP 0x6d60a2							
  tree.go:383		0x6d6075		48c7402000000000	MOVQ $0x0, 0x20(AX)						
  tree.go:383		0x6d607d		833d9c74850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:383		0x6d6084		7505			JNE 0x6d608b							
  tree.go:370		0x6d6086		4885d2			TESTQ DX, DX							
  tree.go:383		0x6d6089		eb0f			JMP 0x6d609a							
  tree.go:383		0x6d608b		488b4828		MOVQ 0x28(AX), CX						
  tree.go:383		0x6d608f		e8ace1dbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:383		0x6d6094		49890b			MOVQ CX, 0(R11)							
  tree.go:370		0x6d6097		4885d2			TESTQ DX, DX							
  tree.go:383		0x6d609a		48c7402800000000	MOVQ $0x0, 0x28(AX)						
  tree.go:385		0x6d60a2		7417			JE 0x6d60bb							
  tree.go:385		0x6d60a4		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:385		0x6d60a8		488b0db10b7402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.16(SB), CX	
  tree.go:385		0x6d60af		4c8b01			MOVQ 0(CX), R8							
  tree.go:385		0x6d60b2		448b4a10		MOVL 0x10(DX), R9						
  tree.go:385		0x6d60b6		e904090000		JMP 0x6d69bf							
  tree.go:370		0x6d60bb		4889d1			MOVQ DX, CX							
  tree.go:370		0x6d60be		6690			NOPW								
  tree.go:385		0x6d60c0		4885d2			TESTQ DX, DX							
  tree.go:385		0x6d60c3		7430			JE 0x6d60f5							
  tree.go:386		0x6d60c5		48895030		MOVQ DX, 0x30(AX)						
  tree.go:386		0x6d60c9		833d5074850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:386		0x6d60d0		7505			JNE 0x6d60d7							
  tree.go:370		0x6d60d2		4885c9			TESTQ CX, CX							
  tree.go:386		0x6d60d5		eb18			JMP 0x6d60ef							
  tree.go:386		0x6d60d7		488b5038		MOVQ 0x38(AX), DX						
  tree.go:386		0x6d60db		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:386		0x6d60e0		e87be1dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:386		0x6d60e5		49893b			MOVQ DI, 0(R11)							
  tree.go:386		0x6d60e8		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d60ec		4885c9			TESTQ CX, CX							
  tree.go:386		0x6d60ef		48897838		MOVQ DI, 0x38(AX)						
  tree.go:386		0x6d60f3		eb2d			JMP 0x6d6122							
  tree.go:388		0x6d60f5		48c7403000000000	MOVQ $0x0, 0x30(AX)						
  tree.go:388		0x6d60fd		833d1c74850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:388		0x6d6104		7505			JNE 0x6d610b							
  tree.go:370		0x6d6106		4885c9			TESTQ CX, CX							
  tree.go:388		0x6d6109		eb0f			JMP 0x6d611a							
  tree.go:388		0x6d610b		488b5038		MOVQ 0x38(AX), DX						
  tree.go:388		0x6d610f		e82ce1dbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:388		0x6d6114		498913			MOVQ DX, 0(R11)							
  tree.go:370		0x6d6117		4885c9			TESTQ CX, CX							
  tree.go:388		0x6d611a		48c7403800000000	MOVQ $0x0, 0x38(AX)						
  tree.go:390		0x6d6122		7417			JE 0x6d613b							
  tree.go:390		0x6d6124		488b5908		MOVQ 0x8(CX), BX						
  tree.go:390		0x6d6128		488b15510b7402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.17(SB), DX	
  tree.go:390		0x6d612f		4c8b02			MOVQ 0(DX), R8							
  tree.go:390		0x6d6132		448b4910		MOVL 0x10(CX), R9						
  tree.go:390		0x6d6136		e92f080000		JMP 0x6d696a							
  tree.go:370		0x6d613b		4889ca			MOVQ CX, DX							
  tree.go:370		0x6d613e		6690			NOPW								
  tree.go:390		0x6d6140		4885c9			TESTQ CX, CX							
  tree.go:390		0x6d6143		7430			JE 0x6d6175							
  tree.go:391		0x6d6145		48894840		MOVQ CX, 0x40(AX)						
  tree.go:391		0x6d6149		833dd073850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:391		0x6d6150		7505			JNE 0x6d6157							
  tree.go:370		0x6d6152		4885d2			TESTQ DX, DX							
  tree.go:391		0x6d6155		eb18			JMP 0x6d616f							
  tree.go:391		0x6d6157		488b4848		MOVQ 0x48(AX), CX						
  tree.go:391		0x6d615b		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:391		0x6d6160		e8fbe0dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:391		0x6d6165		49893b			MOVQ DI, 0(R11)							
  tree.go:391		0x6d6168		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:370		0x6d616c		4885d2			TESTQ DX, DX							
  tree.go:391		0x6d616f		48897848		MOVQ DI, 0x48(AX)						
  tree.go:391		0x6d6173		eb2d			JMP 0x6d61a2							
  tree.go:393		0x6d6175		48c7404000000000	MOVQ $0x0, 0x40(AX)						
  tree.go:393		0x6d617d		833d9c73850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:393		0x6d6184		7505			JNE 0x6d618b							
  tree.go:370		0x6d6186		4885d2			TESTQ DX, DX							
  tree.go:393		0x6d6189		eb0f			JMP 0x6d619a							
  tree.go:393		0x6d618b		488b4848		MOVQ 0x48(AX), CX						
  tree.go:393		0x6d618f		e8ace0dbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:393		0x6d6194		49890b			MOVQ CX, 0(R11)							
  tree.go:370		0x6d6197		4885d2			TESTQ DX, DX							
  tree.go:393		0x6d619a		48c7404800000000	MOVQ $0x0, 0x48(AX)						
  tree.go:395		0x6d61a2		7417			JE 0x6d61bb							
  tree.go:395		0x6d61a4		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:395		0x6d61a8		488b0df10a7402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.18(SB), CX	
  tree.go:395		0x6d61af		4c8b01			MOVQ 0(CX), R8							
  tree.go:395		0x6d61b2		448b4a10		MOVL 0x10(DX), R9						
  tree.go:395		0x6d61b6		e95a070000		JMP 0x6d6915							
  tree.go:370		0x6d61bb		4889d1			MOVQ DX, CX							
  tree.go:370		0x6d61be		6690			NOPW								
  tree.go:395		0x6d61c0		4885d2			TESTQ DX, DX							
  tree.go:395		0x6d61c3		7434			JE 0x6d61f9							
  tree.go:396		0x6d61c5		48899080000000		MOVQ DX, 0x80(AX)						
  tree.go:396		0x6d61cc		833d4d73850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:396		0x6d61d3		7505			JNE 0x6d61da							
  tree.go:370		0x6d61d5		4885c9			TESTQ CX, CX							
  tree.go:396		0x6d61d8		eb16			JMP 0x6d61f0							
  tree.go:396		0x6d61da		488b9088000000		MOVQ 0x88(AX), DX						
  tree.go:396		0x6d61e1		e87ae0dbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:396		0x6d61e6		49893b			MOVQ DI, 0(R11)							
  tree.go:396		0x6d61e9		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d61ed		4885c9			TESTQ CX, CX							
  tree.go:396		0x6d61f0		4889b888000000		MOVQ DI, 0x88(AX)						
  tree.go:396		0x6d61f7		eb36			JMP 0x6d622f							
  tree.go:398		0x6d61f9		48c7808000000000000000	MOVQ $0x0, 0x80(AX)						
  tree.go:398		0x6d6204		833d1573850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:398		0x6d620b		7505			JNE 0x6d6212							
  tree.go:370		0x6d620d		4885c9			TESTQ CX, CX							
  tree.go:398		0x6d6210		eb12			JMP 0x6d6224							
  tree.go:398		0x6d6212		488b9088000000		MOVQ 0x88(AX), DX						
  tree.go:398		0x6d6219		e822e0dbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:398		0x6d621e		498913			MOVQ DX, 0(R11)							
  tree.go:370		0x6d6221		4885c9			TESTQ CX, CX							
  tree.go:398		0x6d6224		48c7808800000000000000	MOVQ $0x0, 0x88(AX)						
  tree.go:400		0x6d622f		7417			JE 0x6d6248							
  tree.go:400		0x6d6231		488b5908		MOVQ 0x8(CX), BX						
  tree.go:400		0x6d6235		488b15840a7402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.19(SB), DX	
  tree.go:400		0x6d623c		4c8b02			MOVQ 0(DX), R8							
  tree.go:400		0x6d623f		448b4910		MOVL 0x10(CX), R9						
  tree.go:400		0x6d6243		e977060000		JMP 0x6d68bf							
  tree.go:370		0x6d6248		4889ca			MOVQ CX, DX							
  tree.go:400		0x6d624b		4885c9			TESTQ CX, CX							
  tree.go:400		0x6d624e		7436			JE 0x6d6286							
  tree.go:401		0x6d6250		48898890000000		MOVQ CX, 0x90(AX)						
  tree.go:401		0x6d6257		833dc272850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:401		0x6d625e		6690			NOPW								
  tree.go:401		0x6d6260		7505			JNE 0x6d6267							
  tree.go:370		0x6d6262		4885d2			TESTQ DX, DX							
  tree.go:401		0x6d6265		eb16			JMP 0x6d627d							
  tree.go:401		0x6d6267		488b8898000000		MOVQ 0x98(AX), CX						
  tree.go:401		0x6d626e		e8eddfdbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:401		0x6d6273		49893b			MOVQ DI, 0(R11)							
  tree.go:401		0x6d6276		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:370		0x6d627a		4885d2			TESTQ DX, DX							
  tree.go:401		0x6d627d		4889b898000000		MOVQ DI, 0x98(AX)						
  tree.go:401		0x6d6284		eb36			JMP 0x6d62bc							
  tree.go:403		0x6d6286		48c7809000000000000000	MOVQ $0x0, 0x90(AX)						
  tree.go:403		0x6d6291		833d8872850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:403		0x6d6298		7505			JNE 0x6d629f							
  tree.go:370		0x6d629a		4885d2			TESTQ DX, DX							
  tree.go:403		0x6d629d		eb12			JMP 0x6d62b1							
  tree.go:403		0x6d629f		488b8898000000		MOVQ 0x98(AX), CX						
  tree.go:403		0x6d62a6		e895dfdbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:403		0x6d62ab		49890b			MOVQ CX, 0(R11)							
  tree.go:370		0x6d62ae		4885d2			TESTQ DX, DX							
  tree.go:403		0x6d62b1		48c7809800000000000000	MOVQ $0x0, 0x98(AX)						
  tree.go:405		0x6d62bc		7417			JE 0x6d62d5							
  tree.go:405		0x6d62be		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:405		0x6d62c2		488b0d170a7402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.20(SB), CX	
  tree.go:405		0x6d62c9		4c8b01			MOVQ 0(CX), R8							
  tree.go:405		0x6d62cc		448b4a10		MOVL 0x10(DX), R9						
  tree.go:405		0x6d62d0		e995050000		JMP 0x6d686a							
  tree.go:370		0x6d62d5		4889d1			MOVQ DX, CX							
  tree.go:405		0x6d62d8		4885d2			TESTQ DX, DX							
  tree.go:405		0x6d62db		7434			JE 0x6d6311							
  tree.go:406		0x6d62dd		488990a0000000		MOVQ DX, 0xa0(AX)						
  tree.go:406		0x6d62e4		833d3572850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:406		0x6d62eb		7505			JNE 0x6d62f2							
  tree.go:370		0x6d62ed		4885c9			TESTQ CX, CX							
  tree.go:406		0x6d62f0		eb16			JMP 0x6d6308							
  tree.go:406		0x6d62f2		488b90a8000000		MOVQ 0xa8(AX), DX						
  tree.go:406		0x6d62f9		e862dfdbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:406		0x6d62fe		49893b			MOVQ DI, 0(R11)							
  tree.go:406		0x6d6301		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d6305		4885c9			TESTQ CX, CX							
  tree.go:406		0x6d6308		4889b8a8000000		MOVQ DI, 0xa8(AX)						
  tree.go:406		0x6d630f		eb36			JMP 0x6d6347							
  tree.go:408		0x6d6311		48c780a000000000000000	MOVQ $0x0, 0xa0(AX)						
  tree.go:408		0x6d631c		833dfd71850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:408		0x6d6323		7505			JNE 0x6d632a							
  tree.go:370		0x6d6325		4885c9			TESTQ CX, CX							
  tree.go:408		0x6d6328		eb12			JMP 0x6d633c							
  tree.go:408		0x6d632a		488b90a8000000		MOVQ 0xa8(AX), DX						
  tree.go:408		0x6d6331		e80adfdbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:408		0x6d6336		498913			MOVQ DX, 0(R11)							
  tree.go:370		0x6d6339		4885c9			TESTQ CX, CX							
  tree.go:408		0x6d633c		48c780a800000000000000	MOVQ $0x0, 0xa8(AX)						
  tree.go:410		0x6d6347		741c			JE 0x6d6365							
  tree.go:410		0x6d6349		488b5908		MOVQ 0x8(CX), BX						
  tree.go:410		0x6d634d		488b15ac097402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.21(SB), DX	
  tree.go:410		0x6d6354		4c8b02			MOVQ 0(DX), R8							
  tree.go:410		0x6d6357		448b4910		MOVL 0x10(CX), R9						
  tree.go:410		0x6d635b		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:410		0x6d6360		e9b0040000		JMP 0x6d6815							
  tree.go:370		0x6d6365		4889ca			MOVQ CX, DX							
  tree.go:410		0x6d6368		4885c9			TESTQ CX, CX							
  tree.go:410		0x6d636b		7435			JE 0x6d63a2							
  tree.go:411		0x6d636d		488988b0000000		MOVQ CX, 0xb0(AX)						
  tree.go:411		0x6d6374		833da571850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:411		0x6d637b		7505			JNE 0x6d6382							
  tree.go:370		0x6d637d		4885d2			TESTQ DX, DX							
  tree.go:411		0x6d6380		eb16			JMP 0x6d6398							
  tree.go:411		0x6d6382		488b88b8000000		MOVQ 0xb8(AX), CX						
  tree.go:411		0x6d6389		e8d2dedbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:411		0x6d638e		49893b			MOVQ DI, 0(R11)							
  tree.go:411		0x6d6391		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:370		0x6d6395		4885d2			TESTQ DX, DX							
  tree.go:411		0x6d6398		4889b8b8000000		MOVQ DI, 0xb8(AX)						
  tree.go:411		0x6d639f		90			NOPL								
  tree.go:411		0x6d63a0		eb36			JMP 0x6d63d8							
  tree.go:413		0x6d63a2		48c780b000000000000000	MOVQ $0x0, 0xb0(AX)						
  tree.go:413		0x6d63ad		833d6c71850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:413		0x6d63b4		7505			JNE 0x6d63bb							
  tree.go:370		0x6d63b6		4885d2			TESTQ DX, DX							
  tree.go:413		0x6d63b9		eb12			JMP 0x6d63cd							
  tree.go:413		0x6d63bb		488b88b8000000		MOVQ 0xb8(AX), CX						
  tree.go:413		0x6d63c2		e879dedbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:413		0x6d63c7		49890b			MOVQ CX, 0(R11)							
  tree.go:370		0x6d63ca		4885d2			TESTQ DX, DX							
  tree.go:413		0x6d63cd		48c780b800000000000000	MOVQ $0x0, 0xb8(AX)						
  tree.go:415		0x6d63d8		7417			JE 0x6d63f1							
  tree.go:415		0x6d63da		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:415		0x6d63de		488b0d3b097402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.22(SB), CX	
  tree.go:415		0x6d63e5		4c8b01			MOVQ 0(CX), R8							
  tree.go:415		0x6d63e8		448b4a10		MOVL 0x10(DX), R9						
  tree.go:415		0x6d63ec		e9ce030000		JMP 0x6d67bf							
  tree.go:370		0x6d63f1		4889d1			MOVQ DX, CX							
  tree.go:415		0x6d63f4		4885d2			TESTQ DX, DX							
  tree.go:415		0x6d63f7		7434			JE 0x6d642d							
  tree.go:416		0x6d63f9		488990c0000000		MOVQ DX, 0xc0(AX)						
  tree.go:416		0x6d6400		833d1971850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:416		0x6d6407		7505			JNE 0x6d640e							
  tree.go:370		0x6d6409		4885c9			TESTQ CX, CX							
  tree.go:416		0x6d640c		eb16			JMP 0x6d6424							
  tree.go:416		0x6d640e		488b90c8000000		MOVQ 0xc8(AX), DX						
  tree.go:416		0x6d6415		e846dedbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:416		0x6d641a		49893b			MOVQ DI, 0(R11)							
  tree.go:416		0x6d641d		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d6421		4885c9			TESTQ CX, CX							
  tree.go:416		0x6d6424		4889b8c8000000		MOVQ DI, 0xc8(AX)						
  tree.go:416		0x6d642b		eb37			JMP 0x6d6464							
  tree.go:418		0x6d642d		48c780c000000000000000	MOVQ $0x0, 0xc0(AX)						
  tree.go:418		0x6d6438		833de170850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:418		0x6d643f		90			NOPL								
  tree.go:418		0x6d6440		7505			JNE 0x6d6447							
  tree.go:370		0x6d6442		4885c9			TESTQ CX, CX							
  tree.go:418		0x6d6445		eb12			JMP 0x6d6459							
  tree.go:418		0x6d6447		488b90c8000000		MOVQ 0xc8(AX), DX						
  tree.go:418		0x6d644e		e8eddddbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:418		0x6d6453		498913			MOVQ DX, 0(R11)							
  tree.go:370		0x6d6456		4885c9			TESTQ CX, CX							
  tree.go:418		0x6d6459		48c780c800000000000000	MOVQ $0x0, 0xc8(AX)						
  tree.go:264		0x6d6464		7417			JE 0x6d647d							
  tree.go:264		0x6d6466		488b5908		MOVQ 0x8(CX), BX						
  tree.go:264		0x6d646a		488b15cf087402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.23(SB), DX	
  tree.go:264		0x6d6471		4c8b02			MOVQ 0(DX), R8							
  tree.go:264		0x6d6474		448b4910		MOVL 0x10(CX), R9						
  tree.go:264		0x6d6478		e9ed020000		JMP 0x6d676a							
  tree.go:370		0x6d647d		4889ca			MOVQ CX, DX							
  tree.go:264		0x6d6480		4885c9			TESTQ CX, CX							
  tree.go:264		0x6d6483		7507			JNE 0x6d648c							
  tree.go:264		0x6d6485		b901000000		MOVL $0x1, CX							
  tree.go:420		0x6d648a		eb1f			JMP 0x6d64ab							
  tree.go:265		0x6d648c		488b4918		MOVQ 0x18(CX), CX						
  tree.go:265		0x6d6490		4889f8			MOVQ DI, AX							
  tree.go:265		0x6d6493		ffd1			CALL CX								
  tree.go:370		0x6d6495		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d649a		488b742448		MOVQ 0x48(SP), SI						
  tree.go:422		0x6d649f		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:420		0x6d64a4		89c1			MOVL AX, CX							
  tree.go:437		0x6d64a6		488b442428		MOVQ 0x28(SP), AX						
  tree.go:420		0x6d64ab		84c9			TESTL CL, CL							
  tree.go:420		0x6d64ad		7421			JE 0x6d64d0							
  tree.go:370		0x6d64af		4885d2			TESTQ DX, DX							
  tree.go:421		0x6d64b2		7417			JE 0x6d64cb							
  tree.go:421		0x6d64b4		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:421		0x6d64b8		488b0da1087402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.24(SB), CX	
  tree.go:421		0x6d64bf		4c8b01			MOVQ 0(CX), R8							
  tree.go:421		0x6d64c2		448b4a10		MOVL 0x10(DX), R9						
  tree.go:421		0x6d64c6		e94a020000		JMP 0x6d6715							
  tree.go:370		0x6d64cb		4889d1			MOVQ DX, CX							
  tree.go:421		0x6d64ce		eb50			JMP 0x6d6520							
  tree.go:437		0x6d64d0		48c7405000000000	MOVQ $0x0, 0x50(AX)						
  tree.go:437		0x6d64d8		833d4170850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:437		0x6d64df		90			NOPL								
  tree.go:437		0x6d64e0		741c			JE 0x6d64fe							
  tree.go:437		0x6d64e2		488b4858		MOVQ 0x58(AX), CX						
  tree.go:438		0x6d64e6		488b5068		MOVQ 0x68(AX), DX						
  tree.go:439		0x6d64ea		488b5878		MOVQ 0x78(AX), BX						
  tree.go:437		0x6d64ee		e88ddddbff		CALL runtime.gcWriteBarrier3(SB)				
  tree.go:437		0x6d64f3		49890b			MOVQ CX, 0(R11)							
  tree.go:438		0x6d64f6		49895308		MOVQ DX, 0x8(R11)						
  tree.go:439		0x6d64fa		49895b10		MOVQ BX, 0x10(R11)						
  tree.go:437		0x6d64fe		440f117858		MOVUPS X15, 0x58(AX)						
  tree.go:438		0x6d6503		440f117868		MOVUPS X15, 0x68(AX)						
  tree.go:439		0x6d6508		48c7407800000000	MOVQ $0x0, 0x78(AX)						
  tree.go:441		0x6d6510		4889b0d0000000		MOVQ SI, 0xd0(AX)						
  tree.go:442		0x6d6517		4883c418		ADDQ $0x18, SP							
  tree.go:442		0x6d651b		5d			POPQ BP								
  tree.go:442		0x6d651c		c3			RET								
  tree.go:442		0x6d651d		0f1f00			NOPL 0(AX)							
  tree.go:421		0x6d6520		4885d2			TESTQ DX, DX							
  tree.go:421		0x6d6523		7430			JE 0x6d6555							
  tree.go:422		0x6d6525		48895050		MOVQ DX, 0x50(AX)						
  tree.go:422		0x6d6529		833df06f850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:422		0x6d6530		7505			JNE 0x6d6537							
  tree.go:370		0x6d6532		4885c9			TESTQ CX, CX							
  tree.go:422		0x6d6535		eb18			JMP 0x6d654f							
  tree.go:422		0x6d6537		488b5058		MOVQ 0x58(AX), DX						
  tree.go:422		0x6d653b		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:422		0x6d6540		e81bdddbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:422		0x6d6545		49893b			MOVQ DI, 0(R11)							
  tree.go:422		0x6d6548		49895308		MOVQ DX, 0x8(R11)						
  tree.go:370		0x6d654c		4885c9			TESTQ CX, CX							
  tree.go:422		0x6d654f		48897858		MOVQ DI, 0x58(AX)						
  tree.go:422		0x6d6553		eb2d			JMP 0x6d6582							
  tree.go:424		0x6d6555		48c7405000000000	MOVQ $0x0, 0x50(AX)						
  tree.go:424		0x6d655d		833dbc6f850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:424		0x6d6564		7505			JNE 0x6d656b							
  tree.go:370		0x6d6566		4885c9			TESTQ CX, CX							
  tree.go:424		0x6d6569		eb0f			JMP 0x6d657a							
  tree.go:424		0x6d656b		488b5058		MOVQ 0x58(AX), DX						
  tree.go:424		0x6d656f		e8ccdcdbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:424		0x6d6574		498913			MOVQ DX, 0(R11)							
  tree.go:370		0x6d6577		4885c9			TESTQ CX, CX							
  tree.go:424		0x6d657a		48c7405800000000	MOVQ $0x0, 0x58(AX)						
  tree.go:426		0x6d6582		7417			JE 0x6d659b							
  tree.go:426		0x6d6584		488b5908		MOVQ 0x8(CX), BX						
  tree.go:426		0x6d6588		488b15f1077402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.25(SB), DX	
  tree.go:426		0x6d658f		4c8b02			MOVQ 0(DX), R8							
  tree.go:426		0x6d6592		448b4910		MOVL 0x10(CX), R9						
  tree.go:426		0x6d6596		e920010000		JMP 0x6d66bb							
  tree.go:370		0x6d659b		4889ca			MOVQ CX, DX							
  tree.go:370		0x6d659e		6690			NOPW								
  tree.go:426		0x6d65a0		4885c9			TESTQ CX, CX							
  tree.go:426		0x6d65a3		7430			JE 0x6d65d5							
  tree.go:427		0x6d65a5		48894860		MOVQ CX, 0x60(AX)						
  tree.go:427		0x6d65a9		833d706f850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:427		0x6d65b0		7505			JNE 0x6d65b7							
  tree.go:370		0x6d65b2		4885d2			TESTQ DX, DX							
  tree.go:427		0x6d65b5		eb18			JMP 0x6d65cf							
  tree.go:427		0x6d65b7		488b4868		MOVQ 0x68(AX), CX						
  tree.go:427		0x6d65bb		0f1f440000		NOPL 0(AX)(AX*1)						
  tree.go:427		0x6d65c0		e89bdcdbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:427		0x6d65c5		49893b			MOVQ DI, 0(R11)							
  tree.go:427		0x6d65c8		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:370		0x6d65cc		4885d2			TESTQ DX, DX							
  tree.go:427		0x6d65cf		48897868		MOVQ DI, 0x68(AX)						
  tree.go:427		0x6d65d3		eb2d			JMP 0x6d6602							
  tree.go:429		0x6d65d5		48c7406000000000	MOVQ $0x0, 0x60(AX)						
  tree.go:429		0x6d65dd		833d3c6f850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:429		0x6d65e4		7505			JNE 0x6d65eb							
  tree.go:370		0x6d65e6		4885d2			TESTQ DX, DX							
  tree.go:429		0x6d65e9		eb0f			JMP 0x6d65fa							
  tree.go:429		0x6d65eb		488b4868		MOVQ 0x68(AX), CX						
  tree.go:429		0x6d65ef		e84cdcdbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:429		0x6d65f4		49890b			MOVQ CX, 0(R11)							
  tree.go:370		0x6d65f7		4885d2			TESTQ DX, DX							
  tree.go:429		0x6d65fa		48c7406800000000	MOVQ $0x0, 0x68(AX)						
  tree.go:431		0x6d6602		7413			JE 0x6d6617							
  tree.go:431		0x6d6604		488b5a08		MOVQ 0x8(DX), BX						
  tree.go:431		0x6d6608		488b0d91077402		MOVQ github.com/snissn/gomap/TreeDB/tree..typeAssert.26(SB), CX	
  tree.go:431		0x6d660f		4c8b01			MOVQ 0(CX), R8							
  tree.go:431		0x6d6612		8b5210			MOVL 0x10(DX), DX						
  tree.go:431		0x6d6615		eb58			JMP 0x6d666f							
  tree.go:431		0x6d6617		4885d2			TESTQ DX, DX							
  tree.go:431		0x6d661a		7429			JE 0x6d6645							
  tree.go:432		0x6d661c		48895070		MOVQ DX, 0x70(AX)						
  tree.go:432		0x6d6620		833df96e850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:432		0x6d6627		7410			JE 0x6d6639							
  tree.go:432		0x6d6629		488b4878		MOVQ 0x78(AX), CX						
  tree.go:432		0x6d662d		e82edcdbff		CALL runtime.gcWriteBarrier2(SB)				
  tree.go:432		0x6d6632		49893b			MOVQ DI, 0(R11)							
  tree.go:432		0x6d6635		49894b08		MOVQ CX, 0x8(R11)						
  tree.go:432		0x6d6639		48897878		MOVQ DI, 0x78(AX)						
  tree.go:432		0x6d663d		0f1f00			NOPL 0(AX)							
  tree.go:432		0x6d6640		e9cbfeffff		JMP 0x6d6510							
  tree.go:434		0x6d6645		48c7407000000000	MOVQ $0x0, 0x70(AX)						
  tree.go:434		0x6d664d		833dcc6e850200		CMPL runtime.writeBarrier(SB), $0x0				
  tree.go:434		0x6d6654		740c			JE 0x6d6662							
  tree.go:434		0x6d6656		488b4878		MOVQ 0x78(AX), CX						
  tree.go:434		0x6d665a		e8e1dbdbff		CALL runtime.gcWriteBarrier1(SB)				
  tree.go:434		0x6d665f		49890b			MOVQ CX, 0(R11)							
  tree.go:434		0x6d6662		48c7407800000000	MOVQ $0x0, 0x78(AX)						
  tree.go:434		0x6d666a		e9a1feffff		JMP 0x6d6510							
  tree.go:431		0x6d666f		4989d1			MOVQ DX, R9							
  tree.go:431		0x6d6672		4c21c2			ANDQ R8, DX							
  tree.go:431		0x6d6675		48c1e204		SHLQ $0x4, DX							
  tree.go:431		0x6d6679		4c8b541108		MOVQ 0x8(CX)(DX*1), R10						
  tree.go:431		0x6d667e		6690			NOPW								
  tree.go:431		0x6d6680		4939da			CMPQ R10, BX							
  tree.go:431		0x6d6683		742c			JE 0x6d66b1							
  tree.go:431		0x6d6685		498d5101		LEAQ 0x1(R9), DX						
  tree.go:431		0x6d6689		4d85d2			TESTQ R10, R10							
  tree.go:431		0x6d668c		75e1			JNE 0x6d666f							
  tree.go:431		0x6d668e		488d050b077402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.26(SB), AX	
  tree.go:431		0x6d6695		e826a8d4ff		CALL runtime.typeAssert(SB)					
  tree.go:441		0x6d669a		488b742448		MOVQ 0x48(SP), SI						
  tree.go:432		0x6d669f		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:431		0x6d66a4		4889c2			MOVQ AX, DX							
  tree.go:432		0x6d66a7		488b442428		MOVQ 0x28(SP), AX						
  tree.go:431		0x6d66ac		e966ffffff		JMP 0x6d6617							
  tree.go:431		0x6d66b1		488b541110		MOVQ 0x10(CX)(DX*1), DX						
  tree.go:431		0x6d66b6		e95cffffff		JMP 0x6d6617							
  tree.go:426		0x6d66bb		4d89ca			MOVQ R9, R10							
  tree.go:426		0x6d66be		4d21c1			ANDQ R8, R9							
  tree.go:426		0x6d66c1		49c1e104		SHLQ $0x4, R9							
  tree.go:426		0x6d66c5		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:426		0x6d66ca		4939db			CMPQ R11, BX							
  tree.go:426		0x6d66cd		7436			JE 0x6d6705							
  tree.go:426		0x6d66cf		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:426		0x6d66d3		4d85db			TESTQ R11, R11							
  tree.go:426		0x6d66d6		75e3			JNE 0x6d66bb							
  tree.go:426		0x6d66d8		488d05a1067402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.25(SB), AX	
  tree.go:426		0x6d66df		90			NOPL								
  tree.go:426		0x6d66e0		e8dba7d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d66e5		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d66ea		488b742448		MOVQ 0x48(SP), SI						
  tree.go:427		0x6d66ef		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:426		0x6d66f4		4889c1			MOVQ AX, CX							
  tree.go:427		0x6d66f7		488b442428		MOVQ 0x28(SP), AX						
  tree.go:427		0x6d66fc		0f1f4000		NOPL 0(AX)							
  tree.go:426		0x6d6700		e99bfeffff		JMP 0x6d65a0							
  tree.go:426		0x6d6705		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d670a		4889ca			MOVQ CX, DX							
  tree.go:426		0x6d670d		4c89c1			MOVQ R8, CX							
  tree.go:426		0x6d6710		e98bfeffff		JMP 0x6d65a0							
  tree.go:421		0x6d6715		4d89ca			MOVQ R9, R10							
  tree.go:421		0x6d6718		4d21c1			ANDQ R8, R9							
  tree.go:421		0x6d671b		49c1e104		SHLQ $0x4, R9							
  tree.go:421		0x6d671f		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:421		0x6d6724		4939db			CMPQ R11, BX							
  tree.go:421		0x6d6727		7431			JE 0x6d675a							
  tree.go:421		0x6d6729		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:421		0x6d672d		4d85db			TESTQ R11, R11							
  tree.go:421		0x6d6730		75e3			JNE 0x6d6715							
  tree.go:421		0x6d6732		488d0527067402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.24(SB), AX	
  tree.go:421		0x6d6739		e882a7d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d673e		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:441		0x6d6743		488b742448		MOVQ 0x48(SP), SI						
  tree.go:422		0x6d6748		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:421		0x6d674d		4889c2			MOVQ AX, DX							
  tree.go:422		0x6d6750		488b442428		MOVQ 0x28(SP), AX						
  tree.go:421		0x6d6755		e9c6fdffff		JMP 0x6d6520							
  tree.go:421		0x6d675a		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:370		0x6d675f		4889d1			MOVQ DX, CX							
  tree.go:421		0x6d6762		4c89c2			MOVQ R8, DX							
  tree.go:421		0x6d6765		e9b6fdffff		JMP 0x6d6520							
  tree.go:264		0x6d676a		4d89ca			MOVQ R9, R10							
  tree.go:264		0x6d676d		4d21c1			ANDQ R8, R9							
  tree.go:264		0x6d6770		49c1e104		SHLQ $0x4, R9							
  tree.go:264		0x6d6774		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:264		0x6d6779		4939db			CMPQ R11, BX							
  tree.go:264		0x6d677c		7431			JE 0x6d67af							
  tree.go:264		0x6d677e		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:264		0x6d6782		4d85db			TESTQ R11, R11							
  tree.go:264		0x6d6785		75e3			JNE 0x6d676a							
  tree.go:264		0x6d6787		488d05b2057402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.23(SB), AX	
  tree.go:264		0x6d678e		e82da7d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d6793		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d6798		488b742448		MOVQ 0x48(SP), SI						
  tree.go:265		0x6d679d		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:264		0x6d67a2		4889c1			MOVQ AX, CX							
  tree.go:437		0x6d67a5		488b442428		MOVQ 0x28(SP), AX						
  tree.go:264		0x6d67aa		e9d1fcffff		JMP 0x6d6480							
  tree.go:264		0x6d67af		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d67b4		4889ca			MOVQ CX, DX							
  tree.go:264		0x6d67b7		4c89c1			MOVQ R8, CX							
  tree.go:264		0x6d67ba		e9c1fcffff		JMP 0x6d6480							
  tree.go:415		0x6d67bf		4d89ca			MOVQ R9, R10							
  tree.go:415		0x6d67c2		4d21c1			ANDQ R8, R9							
  tree.go:415		0x6d67c5		49c1e104		SHLQ $0x4, R9							
  tree.go:415		0x6d67c9		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:415		0x6d67ce		4939db			CMPQ R11, BX							
  tree.go:415		0x6d67d1		7432			JE 0x6d6805							
  tree.go:415		0x6d67d3		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:415		0x6d67d7		4d85db			TESTQ R11, R11							
  tree.go:415		0x6d67da		75e3			JNE 0x6d67bf							
  tree.go:415		0x6d67dc		488d053d057402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.22(SB), AX	
  tree.go:415		0x6d67e3		e8d8a6d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d67e8		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:441		0x6d67ed		488b742448		MOVQ 0x48(SP), SI						
  tree.go:416		0x6d67f2		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:415		0x6d67f7		4889c2			MOVQ AX, DX							
  tree.go:416		0x6d67fa		488b442428		MOVQ 0x28(SP), AX						
  tree.go:416		0x6d67ff		90			NOPL								
  tree.go:415		0x6d6800		e9effbffff		JMP 0x6d63f4							
  tree.go:415		0x6d6805		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:370		0x6d680a		4889d1			MOVQ DX, CX							
  tree.go:415		0x6d680d		4c89c2			MOVQ R8, DX							
  tree.go:415		0x6d6810		e9dffbffff		JMP 0x6d63f4							
  tree.go:410		0x6d6815		4d89ca			MOVQ R9, R10							
  tree.go:410		0x6d6818		4d21c1			ANDQ R8, R9							
  tree.go:410		0x6d681b		49c1e104		SHLQ $0x4, R9							
  tree.go:410		0x6d681f		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:410		0x6d6824		4939db			CMPQ R11, BX							
  tree.go:410		0x6d6827		7431			JE 0x6d685a							
  tree.go:410		0x6d6829		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:410		0x6d682d		4d85db			TESTQ R11, R11							
  tree.go:410		0x6d6830		75e3			JNE 0x6d6815							
  tree.go:410		0x6d6832		488d05c7047402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.21(SB), AX	
  tree.go:410		0x6d6839		e882a6d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d683e		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d6843		488b742448		MOVQ 0x48(SP), SI						
  tree.go:411		0x6d6848		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:410		0x6d684d		4889c1			MOVQ AX, CX							
  tree.go:411		0x6d6850		488b442428		MOVQ 0x28(SP), AX						
  tree.go:410		0x6d6855		e90efbffff		JMP 0x6d6368							
  tree.go:410		0x6d685a		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d685f		4889ca			MOVQ CX, DX							
  tree.go:410		0x6d6862		4c89c1			MOVQ R8, CX							
  tree.go:410		0x6d6865		e9fefaffff		JMP 0x6d6368							
  tree.go:405		0x6d686a		4d89ca			MOVQ R9, R10							
  tree.go:405		0x6d686d		4d21c1			ANDQ R8, R9							
  tree.go:405		0x6d6870		49c1e104		SHLQ $0x4, R9							
  tree.go:405		0x6d6874		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:405		0x6d6879		4939db			CMPQ R11, BX							
  tree.go:405		0x6d687c		7431			JE 0x6d68af							
  tree.go:405		0x6d687e		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:405		0x6d6882		4d85db			TESTQ R11, R11							
  tree.go:405		0x6d6885		75e3			JNE 0x6d686a							
  tree.go:405		0x6d6887		488d0552047402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.20(SB), AX	
  tree.go:405		0x6d688e		e82da6d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d6893		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:441		0x6d6898		488b742448		MOVQ 0x48(SP), SI						
  tree.go:406		0x6d689d		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:405		0x6d68a2		4889c2			MOVQ AX, DX							
  tree.go:406		0x6d68a5		488b442428		MOVQ 0x28(SP), AX						
  tree.go:405		0x6d68aa		e929faffff		JMP 0x6d62d8							
  tree.go:405		0x6d68af		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:370		0x6d68b4		4889d1			MOVQ DX, CX							
  tree.go:405		0x6d68b7		4c89c2			MOVQ R8, DX							
  tree.go:405		0x6d68ba		e919faffff		JMP 0x6d62d8							
  tree.go:400		0x6d68bf		4d89ca			MOVQ R9, R10							
  tree.go:400		0x6d68c2		4d21c1			ANDQ R8, R9							
  tree.go:400		0x6d68c5		49c1e104		SHLQ $0x4, R9							
  tree.go:400		0x6d68c9		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:400		0x6d68ce		4939db			CMPQ R11, BX							
  tree.go:400		0x6d68d1		7432			JE 0x6d6905							
  tree.go:400		0x6d68d3		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:400		0x6d68d7		4d85db			TESTQ R11, R11							
  tree.go:400		0x6d68da		75e3			JNE 0x6d68bf							
  tree.go:400		0x6d68dc		488d05dd037402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.19(SB), AX	
  tree.go:400		0x6d68e3		e8d8a5d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d68e8		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d68ed		488b742448		MOVQ 0x48(SP), SI						
  tree.go:401		0x6d68f2		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:400		0x6d68f7		4889c1			MOVQ AX, CX							
  tree.go:401		0x6d68fa		488b442428		MOVQ 0x28(SP), AX						
  tree.go:401		0x6d68ff		90			NOPL								
  tree.go:400		0x6d6900		e946f9ffff		JMP 0x6d624b							
  tree.go:400		0x6d6905		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d690a		4889ca			MOVQ CX, DX							
  tree.go:400		0x6d690d		4c89c1			MOVQ R8, CX							
  tree.go:400		0x6d6910		e936f9ffff		JMP 0x6d624b							
  tree.go:395		0x6d6915		4d89ca			MOVQ R9, R10							
  tree.go:395		0x6d6918		4d21c1			ANDQ R8, R9							
  tree.go:395		0x6d691b		49c1e104		SHLQ $0x4, R9							
  tree.go:395		0x6d691f		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:395		0x6d6924		4939db			CMPQ R11, BX							
  tree.go:395		0x6d6927		7431			JE 0x6d695a							
  tree.go:395		0x6d6929		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:395		0x6d692d		4d85db			TESTQ R11, R11							
  tree.go:395		0x6d6930		75e3			JNE 0x6d6915							
  tree.go:395		0x6d6932		488d0567037402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.18(SB), AX	
  tree.go:395		0x6d6939		e882a5d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d693e		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:441		0x6d6943		488b742448		MOVQ 0x48(SP), SI						
  tree.go:396		0x6d6948		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:395		0x6d694d		4889c2			MOVQ AX, DX							
  tree.go:396		0x6d6950		488b442428		MOVQ 0x28(SP), AX						
  tree.go:395		0x6d6955		e966f8ffff		JMP 0x6d61c0							
  tree.go:395		0x6d695a		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:370		0x6d695f		4889d1			MOVQ DX, CX							
  tree.go:395		0x6d6962		4c89c2			MOVQ R8, DX							
  tree.go:395		0x6d6965		e956f8ffff		JMP 0x6d61c0							
  tree.go:390		0x6d696a		4d89ca			MOVQ R9, R10							
  tree.go:390		0x6d696d		4d21c1			ANDQ R8, R9							
  tree.go:390		0x6d6970		49c1e104		SHLQ $0x4, R9							
  tree.go:390		0x6d6974		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:390		0x6d6979		4939db			CMPQ R11, BX							
  tree.go:390		0x6d697c		7431			JE 0x6d69af							
  tree.go:390		0x6d697e		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:390		0x6d6982		4d85db			TESTQ R11, R11							
  tree.go:390		0x6d6985		75e3			JNE 0x6d696a							
  tree.go:390		0x6d6987		488d05f2027402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.17(SB), AX	
  tree.go:390		0x6d698e		e82da5d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d6993		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d6998		488b742448		MOVQ 0x48(SP), SI						
  tree.go:391		0x6d699d		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:390		0x6d69a2		4889c1			MOVQ AX, CX							
  tree.go:391		0x6d69a5		488b442428		MOVQ 0x28(SP), AX						
  tree.go:390		0x6d69aa		e991f7ffff		JMP 0x6d6140							
  tree.go:390		0x6d69af		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d69b4		4889ca			MOVQ CX, DX							
  tree.go:390		0x6d69b7		4c89c1			MOVQ R8, CX							
  tree.go:390		0x6d69ba		e981f7ffff		JMP 0x6d6140							
  tree.go:385		0x6d69bf		4d89ca			MOVQ R9, R10							
  tree.go:385		0x6d69c2		4d21c1			ANDQ R8, R9							
  tree.go:385		0x6d69c5		49c1e104		SHLQ $0x4, R9							
  tree.go:385		0x6d69c9		4e8b5c0908		MOVQ 0x8(CX)(R9*1), R11						
  tree.go:385		0x6d69ce		4939db			CMPQ R11, BX							
  tree.go:385		0x6d69d1		7432			JE 0x6d6a05							
  tree.go:385		0x6d69d3		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:385		0x6d69d7		4d85db			TESTQ R11, R11							
  tree.go:385		0x6d69da		75e3			JNE 0x6d69bf							
  tree.go:385		0x6d69dc		488d057d027402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.16(SB), AX	
  tree.go:385		0x6d69e3		e8d8a4d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d69e8		488b4c2438		MOVQ 0x38(SP), CX						
  tree.go:441		0x6d69ed		488b742448		MOVQ 0x48(SP), SI						
  tree.go:386		0x6d69f2		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:385		0x6d69f7		4889c2			MOVQ AX, DX							
  tree.go:386		0x6d69fa		488b442428		MOVQ 0x28(SP), AX						
  tree.go:386		0x6d69ff		90			NOPL								
  tree.go:385		0x6d6a00		e9bbf6ffff		JMP 0x6d60c0							
  tree.go:385		0x6d6a05		4e8b440910		MOVQ 0x10(CX)(R9*1), R8						
  tree.go:370		0x6d6a0a		4889d1			MOVQ DX, CX							
  tree.go:385		0x6d6a0d		4c89c2			MOVQ R8, DX							
  tree.go:385		0x6d6a10		e9abf6ffff		JMP 0x6d60c0							
  tree.go:380		0x6d6a15		4d89ca			MOVQ R9, R10							
  tree.go:380		0x6d6a18		4d21c1			ANDQ R8, R9							
  tree.go:380		0x6d6a1b		49c1e104		SHLQ $0x4, R9							
  tree.go:380		0x6d6a1f		4e8b5c0a08		MOVQ 0x8(DX)(R9*1), R11						
  tree.go:380		0x6d6a24		4939db			CMPQ R11, BX							
  tree.go:380		0x6d6a27		7431			JE 0x6d6a5a							
  tree.go:380		0x6d6a29		4d8d4a01		LEAQ 0x1(R10), R9						
  tree.go:380		0x6d6a2d		4d85db			TESTQ R11, R11							
  tree.go:380		0x6d6a30		75e3			JNE 0x6d6a15							
  tree.go:380		0x6d6a32		488d0507027402		LEAQ github.com/snissn/gomap/TreeDB/tree..typeAssert.15(SB), AX	
  tree.go:380		0x6d6a39		e882a4d4ff		CALL runtime.typeAssert(SB)					
  tree.go:370		0x6d6a3e		488b542438		MOVQ 0x38(SP), DX						
  tree.go:441		0x6d6a43		488b742448		MOVQ 0x48(SP), SI						
  tree.go:381		0x6d6a48		488b7c2440		MOVQ 0x40(SP), DI						
  tree.go:380		0x6d6a4d		4889c1			MOVQ AX, CX							
  tree.go:381		0x6d6a50		488b442428		MOVQ 0x28(SP), AX						
  tree.go:380		0x6d6a55		e9ebf5ffff		JMP 0x6d6045							
  tree.go:380		0x6d6a5a		4e8b440a10		MOVQ 0x10(DX)(R9*1), R8						
  tree.go:370		0x6d6a5f		4889ca			MOVQ CX, DX							
  tree.go:380		0x6d6a62		4c89c1			MOVQ R8, CX							
  tree.go:380		0x6d6a65		e9dbf5ffff		JMP 0x6d6045							
  tree.go:369		0x6d6a6a		4889442408		MOVQ AX, 0x8(SP)						
  tree.go:369		0x6d6a6f		48895c2410		MOVQ BX, 0x10(SP)						
  tree.go:369		0x6d6a74		48894c2418		MOVQ CX, 0x18(SP)						
  tree.go:369		0x6d6a79		48897c2420		MOVQ DI, 0x20(SP)						
  tree.go:369		0x6d6a7e		4889742428		MOVQ SI, 0x28(SP)						
  tree.go:369		0x6d6a83		e8d8bcdbff		CALL runtime.morestack_noctxt.abi0(SB)				
  tree.go:369		0x6d6a88		488b442408		MOVQ 0x8(SP), AX						
  tree.go:369		0x6d6a8d		488b5c2410		MOVQ 0x10(SP), BX						
  tree.go:369		0x6d6a92		488b4c2418		MOVQ 0x18(SP), CX						
  tree.go:369		0x6d6a97		488b7c2420		MOVQ 0x20(SP), DI						
  tree.go:369		0x6d6a9c		488b742428		MOVQ 0x28(SP), SI						
  tree.go:369		0x6d6aa1		e95af4ffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB)	

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).getEntry(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:620			0x6d7f80		4c8da42450fcffff		LEAQ 0xfffffc50(SP), R12								
  tree.go:620			0x6d7f88		4d3b6610			CMPQ R12, 0x10(R14)									
  tree.go:620			0x6d7f8c		0f867d0c0000			JBE 0x6d8c0f										
  tree.go:620			0x6d7f92		55				PUSHQ BP										
  tree.go:620			0x6d7f93		4889e5				MOVQ SP, BP										
  tree.go:620			0x6d7f96		4881ec28040000			SUBQ $0x428, SP										
  tree.go:621			0x6d7f9d		48898424a0040000		MOVQ AX, 0x4a0(SP)									
  tree.go:621			0x6d7fa5		4c899424d8040000		MOVQ R10, 0x4d8(SP)									
  tree.go:621			0x6d7fad		44889c24e0040000		MOVB R11, 0x4e0(SP)									
  tree.go:621			0x6d7fb5		48898c24b0040000		MOVQ CX, 0x4b0(SP)									
  tree.go:621			0x6d7fbd		48899c24a8040000		MOVQ BX, 0x4a8(SP)									
  tree.go:621			0x6d7fc5		4889b424c0040000		MOVQ SI, 0x4c0(SP)									
  tree.go:621			0x6d7fcd		4c898c24d0040000		MOVQ R9, 0x4d0(SP)									
  tree.go:621			0x6d7fd5		4c898424c8040000		MOVQ R8, 0x4c8(SP)									
  tree.go:621			0x6d7fdd		4889bc24b8040000		MOVQ DI, 0x4b8(SP)									
  tree.go:620			0x6d7fe5		488d942450040000		LEAQ 0x450(SP), DX									
  tree.go:620			0x6d7fed		440f113a			MOVUPS X15, 0(DX)									
  tree.go:620			0x6d7ff1		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:620			0x6d7ff6		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:620			0x6d7ffb		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:620			0x6d8000		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:621			0x6d8005		e89687ffff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).pointDefinitelyAbsent(SB)		
  tree.go:621			0x6d800a		84c0				TESTL AL, AL										
  tree.go:621			0x6d800c		7554				JNE 0x6d8062										
  tree.go:624			0x6d800e		488b8424a0040000		MOVQ 0x4a0(SP), AX									
  tree.go:624			0x6d8016		488b90d0000000			MOVQ 0xd0(AX), DX									
  tree.go:624			0x6d801d		4c8da424f8000000		LEAQ 0xf8(SP), R12									
  tree.go:624			0x6d8025		450f113c24			MOVUPS X15, 0(R12)									
  tree.go:624			0x6d802a		450f117c2410			MOVUPS X15, 0x10(R12)									
  tree.go:624			0x6d8030		450f117c2418			MOVUPS X15, 0x18(R12)									
  tree.go:624			0x6d8036		4889942400010000		MOVQ DX, 0x100(SP)									
  tree.go:626			0x6d803e		488b5008			MOVQ 0x8(AX), DX									
  tree.go:626			0x6d8042		4885d2				TESTQ DX, DX										
  tree.go:626			0x6d8045		740e				JE 0x6d8055										
  pager.go:565			0x6d8047		90				NOPL											
  type.go:19			0x6d8048		8b92d0010000			MOVL 0x1d0(DX), DX									
  type.go:19			0x6d804e		85d2				TESTL DX, DX										
  type.go:19			0x6d8050		0f95c2				SETNE DL										
  tree.go:627			0x6d8053		eb02				JMP 0x6d8057										
  tree.go:627			0x6d8055		31d2				XORL DX, DX										
  tree.go:630			0x6d8057		889424d7000000			MOVB DL, 0xd7(SP)									
  tree.go:630			0x6d805e		31c9				XORL CX, CX										
  tree.go:630			0x6d8060		eb52				JMP 0x6d80b4										
  tree.go:622			0x6d8062		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:622			0x6d806a		440f1139			MOVUPS X15, 0(CX)									
  tree.go:622			0x6d806e		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:622			0x6d8073		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:622			0x6d8078		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:622			0x6d807d		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:622			0x6d8082		488b05678d7302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:622			0x6d8089		488b1d688d7302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:622			0x6d8090		4881c428040000			ADDQ $0x428, SP										
  tree.go:622			0x6d8097		5d				POPQ BP											
  tree.go:622			0x6d8098		c3				RET											
  tree.go:630			0x6d8099		488b8c24f0000000		MOVQ 0xf0(SP), CX									
  tree.go:630			0x6d80a1		48ffc1				INCQ CX											
  tree.go:632			0x6d80a4		488b8424a0040000		MOVQ 0x4a0(SP), AX									
  tree.go:632			0x6d80ac		0fb69424d7000000		MOVZX 0xd7(SP), DX									
  tree.go:630			0x6d80b4		4883f932			CMPQ CX, $0x32										
  tree.go:630			0x6d80b8		0f8df50a0000			JGE 0x6d8bb3										
  tree.go:630			0x6d80be		48898c24f0000000		MOVQ CX, 0xf0(SP)									
  tree.go:631			0x6d80c6		488d9c2470010000		LEAQ 0x170(SP), BX									
  tree.go:631			0x6d80ce		41bc05000000			MOVL $0x5, R12										
  tree.go:631			0x6d80d4		440f113b			MOVUPS X15, 0(BX)									
  tree.go:631			0x6d80d8		440f117b10			MOVUPS X15, 0x10(BX)									
  tree.go:631			0x6d80dd		440f117b20			MOVUPS X15, 0x20(BX)									
  tree.go:631			0x6d80e2		440f117b30			MOVUPS X15, 0x30(BX)									
  tree.go:631			0x6d80e7		4883c340			ADDQ $0x40, BX										
  tree.go:631			0x6d80eb		41ffcc				DECL R12										
  tree.go:631			0x6d80ee		75e4				JNE 0x6d80d4										
  tree.go:631			0x6d80f0		440f117bf8			MOVUPS X15, -0x8(BX)									
  tree.go:632			0x6d80f5		0fb68c24f8000000		MOVZX 0xf8(SP), CX									
  tree.go:632			0x6d80fd		488bbc2400010000		MOVQ 0x100(SP), DI									
  tree.go:632			0x6d8105		8bb42408010000			MOVL 0x108(SP), SI									
  tree.go:632			0x6d810c		4c8b842410010000		MOVQ 0x110(SP), R8									
  tree.go:632			0x6d8114		448b8c2418010000		MOVL 0x118(SP), R9									
  tree.go:632			0x6d811c		440fb794241c010000		MOVZX 0x11c(SP), R10									
  tree.go:632			0x6d8125		4c8ba424c0040000		MOVQ 0x4c0(SP), R12									
  tree.go:632			0x6d812d		4c892424			MOVQ R12, 0(SP)										
  tree.go:632			0x6d8131		4c8ba424c8040000		MOVQ 0x4c8(SP), R12									
  tree.go:632			0x6d8139		4c89642408			MOVQ R12, 0x8(SP)									
  tree.go:632			0x6d813e		4c8ba424d0040000		MOVQ 0x4d0(SP), R12									
  tree.go:632			0x6d8146		4c89642410			MOVQ R12, 0x10(SP)									
  tree.go:632			0x6d814b		4c8ba42438040000		MOVQ 0x438(SP), R12									
  tree.go:632			0x6d8153		4c89642418			MOVQ R12, 0x18(SP)									
  tree.go:632			0x6d8158		4c8ba42440040000		MOVQ 0x440(SP), R12									
  tree.go:632			0x6d8160		4c89642420			MOVQ R12, 0x20(SP)									
  tree.go:632			0x6d8165		4c8ba42448040000		MOVQ 0x448(SP), R12									
  tree.go:632			0x6d816d		4c89642428			MOVQ R12, 0x28(SP)									
  tree.go:632			0x6d8172		4c8ba424d8040000		MOVQ 0x4d8(SP), R12									
  tree.go:632			0x6d817a		4c89642430			MOVQ R12, 0x30(SP)									
  tree.go:632			0x6d817f		440fb6a424e0040000		MOVZX 0x4e0(SP), R12									
  tree.go:632			0x6d8188		4488642438			MOVB R12, 0x38(SP)									
  tree.go:632			0x6d818d		488d9c2470010000		LEAQ 0x170(SP), BX									
  tree.go:632			0x6d8195		4189d3				MOVL DX, R11										
  tree.go:632			0x6d8198		e86396ffff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).loadReadRefInto(SB)			
  tree.go:632			0x6d819d		0f1f00				NOPL 0(AX)										
  tree.go:632			0x6d81a0		4885c0				TESTQ AX, AX										
  tree.go:632			0x6d81a3		0f85e1090000			JNE 0x6d8b8a										
  tree.go:621			0x6d81a9		440fb69c24e0040000		MOVZX 0x4e0(SP), R11									
  tree.go:621			0x6d81b2		4584db				TESTL R11, R11										
  tree.go:636			0x6d81b5		745b				JE 0x6d8212										
  tree.go:637			0x6d81b7		90				NOPL											
  node.go:183			0x6d81b8		488b9424d0040000		MOVQ 0x4d0(SP), DX									
  node.go:183			0x6d81c0		4885d2				TESTQ DX, DX										
  node.go:183			0x6d81c3		751f				JNE 0x6d81e4										
  node.go:184			0x6d81c5		440f11bc2498010000		MOVUPS X15, 0x198(SP)									
  node.go:184			0x6d81ce		48c784249001000000000000	MOVQ $0x0, 0x190(SP)									
  tree.go:632			0x6d81da		4c8ba424c0040000		MOVQ 0x4c0(SP), R12									
  node.go:193			0x6d81e2		eb24				JMP 0x6d8208										
  node.go:187			0x6d81e4		48c784249801000000000000	MOVQ $0x0, 0x198(SP)									
  node.go:187			0x6d81f0		48899424a0010000		MOVQ DX, 0x1a0(SP)									
  node.go:187			0x6d81f8		4c8ba424c0040000		MOVQ 0x4c0(SP), R12									
  node.go:187			0x6d8200		4c89a42490010000		MOVQ R12, 0x190(SP)									
  node.go:194			0x6d8208		c68424a801000001		MOVB $0x1, 0x1a8(SP)									
  tree.go:640			0x6d8210		eb10				JMP 0x6d8222										
  tree.go:632			0x6d8212		488b9424d0040000		MOVQ 0x4d0(SP), DX									
  tree.go:632			0x6d821a		4c8ba424c0040000		MOVQ 0x4c0(SP), R12									
  node.go:224			0x6d8222		0fb784248a010000		MOVZX 0x18a(SP), AX									
  tree.go:655			0x6d822a		6683f803			CMPW AX, $0x3										
  tree.go:655			0x6d822e		0f8531020000			JNE 0x6d8465										
  tree.go:656			0x6d8234		488bb424f0000000		MOVQ 0xf0(SP), SI									
  tree.go:656			0x6d823c		0f1f4000			NOPL 0(AX)										
  tree.go:656			0x6d8240		4885f6				TESTQ SI, SI										
  tree.go:656			0x6d8243		0f85d0000000			JNE 0x6d8319										
  tree.go:657			0x6d8249		488d842470010000		LEAQ 0x170(SP), AX									
  tree.go:657			0x6d8251		e88a28f1ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).InternalFenceBounds(SB)		
  tree.go:657			0x6d8256		4d85d2				TESTQ R10, R10										
  tree.go:657			0x6d8259		0f8506060000			JNE 0x6d8865										
  tree.go:657			0x6d825f		90				NOPL											
  tree.go:657			0x6d8260		4584c9				TESTL R9, R9										
  tree.go:659			0x6d8263		0f848f000000			JE 0x6d82f8										
  tree.go:660			0x6d8269		4885db				TESTQ BX, BX										
  tree.go:660			0x6d826c		745f				JE 0x6d82cd										
  tree.go:657			0x6d826e		4c898424e0000000		MOVQ R8, 0xe0(SP)									
  tree.go:657			0x6d8276		4889b424d8000000		MOVQ SI, 0xd8(SP)									
  tree.go:657			0x6d827e		4889bc24b8020000		MOVQ DI, 0x2b8(SP)									
  tree.go:660			0x6d8286		4889c7				MOVQ AX, DI										
  tree.go:660			0x6d8289		4889de				MOVQ BX, SI										
  tree.go:660			0x6d828c		4989c8				MOVQ CX, R8										
  tree.go:660			0x6d828f		488b8424a8040000		MOVQ 0x4a8(SP), AX									
  tree.go:660			0x6d8297		488b9c24b0040000		MOVQ 0x4b0(SP), BX									
  tree.go:660			0x6d829f		488b8c24b8040000		MOVQ 0x4b8(SP), CX									
  tree.go:660			0x6d82a7		e854d2ffff			CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)				
  tree.go:660			0x6d82ac		4885c0				TESTQ AX, AX										
  tree.go:660			0x6d82af		0f8c1b050000			JL 0x6d87d0										
  tree.go:663			0x6d82b5		488bb424d8000000		MOVQ 0xd8(SP), SI									
  tree.go:663			0x6d82bd		488bbc24b8020000		MOVQ 0x2b8(SP), DI									
  tree.go:663			0x6d82c5		4c8b8424e0000000		MOVQ 0xe0(SP), R8									
  tree.go:663			0x6d82cd		4885f6				TESTQ SI, SI										
  tree.go:663			0x6d82d0		7426				JE 0x6d82f8										
  tree.go:663			0x6d82d2		488b8424a8040000		MOVQ 0x4a8(SP), AX									
  tree.go:663			0x6d82da		488b9c24b0040000		MOVQ 0x4b0(SP), BX									
  tree.go:663			0x6d82e2		488b8c24b8040000		MOVQ 0x4b8(SP), CX									
  tree.go:663			0x6d82ea		e811d2ffff			CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)				
  tree.go:663			0x6d82ef		4885c0				TESTQ AX, AX										
  tree.go:663			0x6d82f2		0f8da1040000			JGE 0x6d8799										
  tree.go:632			0x6d82f8		488b9424d0040000		MOVQ 0x4d0(SP), DX									
  tree.go:630			0x6d8300		488bb424f0000000		MOVQ 0xf0(SP), SI									
  tree.go:632			0x6d8308		440fb69c24e0040000		MOVZX 0x4e0(SP), R11									
  tree.go:632			0x6d8311		4c8ba424c0040000		MOVQ 0x4c0(SP), R12									
  node.go:309			0x6d8319		90				NOPL											
  node.go:302			0x6d831a		6683bc248a01000003		CMPW 0x18a(SP), $0x3									
  node.go:302			0x6d8323		753a				JNE 0x6d835f										
  node.go:236			0x6d8325		4c8b842478010000		MOVQ 0x178(SP), R8									
  node.go:56			0x6d832d		4983f80c			CMPQ R8, $0xc										
  node.go:56			0x6d8331		0f86d2080000			JBE 0x6d8c09										
  node.go:56			0x6d8337		660f1f840000000000		NOPW 0(AX)(AX*1)									
  node.go:56			0x6d8340		4983f80d			CMPQ R8, $0xd										
  node.go:56			0x6d8344		0f86ba080000			JBE 0x6d8c04										
  node.go:236			0x6d834a		4c8b842470010000		MOVQ 0x170(SP), R8									
  node.go:56			0x6d8352		450fb7400c			MOVZX 0xc(R8), R8									
  node.go:305			0x6d8357		6641f7c08000			TESTW $0x80, R8										
  tree.go:668			0x6d835d		7552				JNE 0x6d83b1										
  tree.go:675			0x6d835f		488d842470010000		LEAQ 0x170(SP), AX									
  tree.go:675			0x6d8367		488b9c24a8040000		MOVQ 0x4a8(SP), BX									
  tree.go:675			0x6d836f		488b8c24b0040000		MOVQ 0x4b0(SP), CX									
  tree.go:675			0x6d8377		488bbc24b8040000		MOVQ 0x4b8(SP), DI									
  tree.go:675			0x6d837f		90				NOPL											
  tree.go:675			0x6d8380		e85b33f1ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID(SB)		
  tree.go:676			0x6d8385		4885c9				TESTQ CX, CX										
  tree.go:676			0x6d8388		0f8579040000			JNE 0x6d8807										
  tree.go:679			0x6d838e		488d9424f8000000		LEAQ 0xf8(SP), DX									
  tree.go:679			0x6d8396		440f113a			MOVUPS X15, 0(DX)									
  tree.go:679			0x6d839a		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:679			0x6d839f		440f117a18			MOVUPS X15, 0x18(DX)									
  tree.go:679			0x6d83a4		4889842400010000		MOVQ AX, 0x100(SP)									
  tree.go:679			0x6d83ac		e9e8fcffff			JMP 0x6d8099										
  tree.go:669			0x6d83b1		488d842470010000		LEAQ 0x170(SP), AX									
  tree.go:669			0x6d83b9		488b9c24a8040000		MOVQ 0x4a8(SP), BX									
  tree.go:669			0x6d83c1		488b8c24b0040000		MOVQ 0x4b0(SP), CX									
  tree.go:669			0x6d83c9		488bbc24b8040000		MOVQ 0x4b8(SP), DI									
  tree.go:669			0x6d83d1		e82a61f1ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildRef(SB)		
  tree.go:669			0x6d83d6		88842448010000			MOVB AL, 0x148(SP)									
  tree.go:669			0x6d83dd		48899c2450010000		MOVQ BX, 0x150(SP)									
  tree.go:669			0x6d83e5		898c2458010000			MOVL CX, 0x158(SP)									
  tree.go:669			0x6d83ec		4889bc2460010000		MOVQ DI, 0x160(SP)									
  tree.go:669			0x6d83f4		89b42468010000			MOVL SI, 0x168(SP)									
  tree.go:669			0x6d83fb		66448984246c010000		MOVW R8, 0x16c(SP)									
  tree.go:669			0x6d8404		488d9424f8000000		LEAQ 0xf8(SP), DX									
  tree.go:669			0x6d840c		488db42448010000		LEAQ 0x148(SP), SI									
  tree.go:669			0x6d8414		440f1036			MOVUPS 0(SI), X14									
  tree.go:669			0x6d8418		440f1132			MOVUPS X14, 0(DX)									
  tree.go:669			0x6d841c		440f107610			MOVUPS 0x10(SI), X14									
  tree.go:669			0x6d8421		440f117210			MOVUPS X14, 0x10(DX)									
  tree.go:669			0x6d8426		440f107618			MOVUPS 0x18(SI), X14									
  tree.go:669			0x6d842b		440f117218			MOVUPS X14, 0x18(DX)									
  tree.go:670			0x6d8430		4d85d2				TESTQ R10, R10										
  tree.go:670			0x6d8433		0f85fd030000			JNE 0x6d8836										
  tree.go:673			0x6d8439		488d9424f8000000		LEAQ 0xf8(SP), DX									
  tree.go:673			0x6d8441		440f1036			MOVUPS 0(SI), X14									
  tree.go:673			0x6d8445		440f1132			MOVUPS X14, 0(DX)									
  tree.go:673			0x6d8449		440f107610			MOVUPS 0x10(SI), X14									
  tree.go:673			0x6d844e		440f117210			MOVUPS X14, 0x10(DX)									
  tree.go:673			0x6d8453		440f107618			MOVUPS 0x18(SI), X14									
  tree.go:673			0x6d8458		440f117218			MOVUPS X14, 0x18(DX)									
  tree.go:673			0x6d845d		0f1f00				NOPL 0(AX)										
  tree.go:673			0x6d8460		e934fcffff			JMP 0x6d8099										
  tree.go:682			0x6d8465		6683f804			CMPW AX, $0x4										
  tree.go:682			0x6d8469		0f849d050000			JE 0x6d8a0c										
  tree.go:641			0x6d846f		6683f80b			CMPW AX, $0xb										
  tree.go:641			0x6d8473		0f85f6040000			JNE 0x6d896f										
  tree.go:642			0x6d8479		4c8bac24f0000000		MOVQ 0xf0(SP), R13									
  tree.go:642			0x6d8481		4d85ed				TESTQ R13, R13										
  tree.go:642			0x6d8484		0f85ae040000			JNE 0x6d8938										
  tree.go:646			0x6d848a		488d942438030000		LEAQ 0x338(SP), DX									
  tree.go:646			0x6d8492		440f113a			MOVUPS X15, 0(DX)									
  tree.go:646			0x6d8496		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:646			0x6d849b		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:646			0x6d84a0		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:646			0x6d84a5		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:646			0x6d84aa		440f117a50			MOVUPS X15, 0x50(DX)									
  tree.go:646			0x6d84af		440f117a60			MOVUPS X15, 0x60(DX)									
  node.go:209			0x6d84b4		488b8c2478010000		MOVQ 0x178(SP), CX									
  node.go:209			0x6d84bc		488bbc2480010000		MOVQ 0x180(SP), DI									
  node.go:209			0x6d84c4		488b9c2470010000		MOVQ 0x170(SP), BX									
  tree.go:647			0x6d84cc		488d942438030000		LEAQ 0x338(SP), DX									
  tree.go:647			0x6d84d4		440f113a			MOVUPS X15, 0(DX)									
  tree.go:647			0x6d84d8		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:647			0x6d84dd		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:647			0x6d84e2		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:647			0x6d84e7		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:647			0x6d84ec		440f117a50			MOVUPS X15, 0x50(DX)									
  tree.go:647			0x6d84f1		440f117a60			MOVUPS X15, 0x60(DX)									
  tree.go:647			0x6d84f6		488b942438040000		MOVQ 0x438(SP), DX									
  tree.go:647			0x6d84fe		48891424			MOVQ DX, 0(SP)										
  tree.go:647			0x6d8502		488b942440040000		MOVQ 0x440(SP), DX									
  tree.go:647			0x6d850a		4889542408			MOVQ DX, 0x8(SP)									
  tree.go:647			0x6d850f		488b942448040000		MOVQ 0x448(SP), DX									
  tree.go:647			0x6d8517		4889542410			MOVQ DX, 0x10(SP)									
  tree.go:647			0x6d851c		488b8424a0040000		MOVQ 0x4a0(SP), AX									
  tree.go:647			0x6d8524		488bb424a8040000		MOVQ 0x4a8(SP), SI									
  tree.go:647			0x6d852c		4c8b8424b0040000		MOVQ 0x4b0(SP), R8									
  tree.go:647			0x6d8534		4c8b8c24b8040000		MOVQ 0x4b8(SP), R9									
  tree.go:647			0x6d853c		4c8b9424d8040000		MOVQ 0x4d8(SP), R10									
  tree.go:647			0x6d8544		e897a0ffff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).selectPrimaryOperand(SB)		
  tree.go:647			0x6d8549		888424a8030000			MOVB AL, 0x3a8(SP)									
  tree.go:647			0x6d8550		48899c24b0030000		MOVQ BX, 0x3b0(SP)									
  tree.go:647			0x6d8558		898c24b8030000			MOVL CX, 0x3b8(SP)									
  tree.go:647			0x6d855f		4889bc24c0030000		MOVQ DI, 0x3c0(SP)									
  tree.go:647			0x6d8567		89b424c8030000			MOVL SI, 0x3c8(SP)									
  tree.go:647			0x6d856e		6644898424cc030000		MOVW R8, 0x3cc(SP)									
  tree.go:647			0x6d8577		488d9424f8000000		LEAQ 0xf8(SP), DX									
  tree.go:647			0x6d857f		4c8da424a8030000		LEAQ 0x3a8(SP), R12									
  tree.go:647			0x6d8587		450f103424			MOVUPS 0(R12), X14									
  tree.go:647			0x6d858c		440f1132			MOVUPS X14, 0(DX)									
  tree.go:647			0x6d8590		450f10742410			MOVUPS 0x10(R12), X14									
  tree.go:647			0x6d8596		440f117210			MOVUPS X14, 0x10(DX)									
  tree.go:647			0x6d859b		450f10742418			MOVUPS 0x18(R12), X14									
  tree.go:647			0x6d85a1		440f117218			MOVUPS X14, 0x18(DX)									
  tree.go:647			0x6d85a6		4c8da42438030000		LEAQ 0x338(SP), R12									
  tree.go:647			0x6d85ae		4c8d6c2418			LEAQ 0x18(SP), R13									
  tree.go:647			0x6d85b3		450f107500			MOVUPS 0(R13), X14									
  tree.go:647			0x6d85b8		450f113424			MOVUPS X14, 0(R12)									
  tree.go:647			0x6d85bd		450f107510			MOVUPS 0x10(R13), X14									
  tree.go:647			0x6d85c2		450f11742410			MOVUPS X14, 0x10(R12)									
  tree.go:647			0x6d85c8		450f107520			MOVUPS 0x20(R13), X14									
  tree.go:647			0x6d85cd		450f11742420			MOVUPS X14, 0x20(R12)									
  tree.go:647			0x6d85d3		450f107530			MOVUPS 0x30(R13), X14									
  tree.go:647			0x6d85d8		450f11742430			MOVUPS X14, 0x30(R12)									
  tree.go:647			0x6d85de		450f107540			MOVUPS 0x40(R13), X14									
  tree.go:647			0x6d85e3		450f11742440			MOVUPS X14, 0x40(R12)									
  tree.go:647			0x6d85e9		450f107550			MOVUPS 0x50(R13), X14									
  tree.go:647			0x6d85ee		450f11742450			MOVUPS X14, 0x50(R12)									
  tree.go:647			0x6d85f4		450f107560			MOVUPS 0x60(R13), X14									
  tree.go:647			0x6d85f9		450f11742460			MOVUPS X14, 0x60(R12)									
  tree.go:647			0x6d85ff		4c8dac2420010000		LEAQ 0x120(SP), R13									
  tree.go:647			0x6d8607		440f1032			MOVUPS 0(DX), X14									
  tree.go:647			0x6d860b		450f117500			MOVUPS X14, 0(R13)									
  tree.go:647			0x6d8610		440f107210			MOVUPS 0x10(DX), X14									
  tree.go:647			0x6d8615		450f117510			MOVUPS X14, 0x10(R13)									
  tree.go:647			0x6d861a		440f107218			MOVUPS 0x18(DX), X14									
  tree.go:647			0x6d861f		450f117518			MOVUPS X14, 0x18(R13)									
  tree.go:647			0x6d8624		488d9424a8030000		LEAQ 0x3a8(SP), DX									
  tree.go:647			0x6d862c		450f103424			MOVUPS 0(R12), X14									
  tree.go:647			0x6d8631		440f1132			MOVUPS X14, 0(DX)									
  tree.go:647			0x6d8635		450f10742410			MOVUPS 0x10(R12), X14									
  tree.go:647			0x6d863b		440f117210			MOVUPS X14, 0x10(DX)									
  tree.go:647			0x6d8640		450f10742420			MOVUPS 0x20(R12), X14									
  tree.go:647			0x6d8646		440f117220			MOVUPS X14, 0x20(DX)									
  tree.go:647			0x6d864b		450f10742430			MOVUPS 0x30(R12), X14									
  tree.go:647			0x6d8651		440f117230			MOVUPS X14, 0x30(DX)									
  tree.go:647			0x6d8656		450f10742440			MOVUPS 0x40(R12), X14									
  tree.go:647			0x6d865c		440f117240			MOVUPS X14, 0x40(DX)									
  tree.go:647			0x6d8661		450f10742450			MOVUPS 0x50(R12), X14									
  tree.go:647			0x6d8667		440f117250			MOVUPS X14, 0x50(DX)									
  tree.go:647			0x6d866c		450f10742460			MOVUPS 0x60(R12), X14									
  tree.go:647			0x6d8672		440f117260			MOVUPS X14, 0x60(DX)									
  tree.go:647			0x6d8677		4c8da424f8000000		LEAQ 0xf8(SP), R12									
  tree.go:647			0x6d867f		450f107500			MOVUPS 0(R13), X14									
  tree.go:647			0x6d8684		450f113424			MOVUPS X14, 0(R12)									
  tree.go:647			0x6d8689		450f107510			MOVUPS 0x10(R13), X14									
  tree.go:647			0x6d868e		450f11742410			MOVUPS X14, 0x10(R12)									
  tree.go:647			0x6d8694		450f107518			MOVUPS 0x18(R13), X14									
  tree.go:647			0x6d8699		450f11742418			MOVUPS X14, 0x18(R12)									
  tree.go:647			0x6d869f		4c8da42438030000		LEAQ 0x338(SP), R12									
  tree.go:647			0x6d86a7		440f1032			MOVUPS 0(DX), X14									
  tree.go:647			0x6d86ab		450f113424			MOVUPS X14, 0(R12)									
  tree.go:647			0x6d86b0		440f107210			MOVUPS 0x10(DX), X14									
  tree.go:647			0x6d86b5		450f11742410			MOVUPS X14, 0x10(R12)									
  tree.go:647			0x6d86bb		440f107220			MOVUPS 0x20(DX), X14									
  tree.go:647			0x6d86c0		450f11742420			MOVUPS X14, 0x20(R12)									
  tree.go:647			0x6d86c6		440f107230			MOVUPS 0x30(DX), X14									
  tree.go:647			0x6d86cb		450f11742430			MOVUPS X14, 0x30(R12)									
  tree.go:647			0x6d86d1		440f107240			MOVUPS 0x40(DX), X14									
  tree.go:647			0x6d86d6		450f11742440			MOVUPS X14, 0x40(R12)									
  tree.go:647			0x6d86dc		440f107250			MOVUPS 0x50(DX), X14									
  tree.go:647			0x6d86e1		450f11742450			MOVUPS X14, 0x50(R12)									
  tree.go:647			0x6d86e7		440f107260			MOVUPS 0x60(DX), X14									
  tree.go:647			0x6d86ec		450f11742460			MOVUPS X14, 0x60(R12)									
  tree.go:648			0x6d86f2		4c8da424c8020000		LEAQ 0x2c8(SP), R12									
  tree.go:648			0x6d86fa		440f1032			MOVUPS 0(DX), X14									
  tree.go:648			0x6d86fe		450f113424			MOVUPS X14, 0(R12)									
  tree.go:648			0x6d8703		440f107210			MOVUPS 0x10(DX), X14									
  tree.go:648			0x6d8708		450f11742410			MOVUPS X14, 0x10(R12)									
  tree.go:648			0x6d870e		440f107220			MOVUPS 0x20(DX), X14									
  tree.go:648			0x6d8713		450f11742420			MOVUPS X14, 0x20(R12)									
  tree.go:648			0x6d8719		440f107230			MOVUPS 0x30(DX), X14									
  tree.go:648			0x6d871e		450f11742430			MOVUPS X14, 0x30(R12)									
  tree.go:648			0x6d8724		440f107240			MOVUPS 0x40(DX), X14									
  tree.go:648			0x6d8729		450f11742440			MOVUPS X14, 0x40(R12)									
  tree.go:648			0x6d872f		440f107250			MOVUPS 0x50(DX), X14									
  tree.go:648			0x6d8734		450f11742450			MOVUPS X14, 0x50(R12)									
  tree.go:648			0x6d873a		440f107260			MOVUPS 0x60(DX), X14									
  tree.go:648			0x6d873f		450f11742460			MOVUPS X14, 0x60(R12)									
  primary_directory_v1.go:43	0x6d8745		80bc243003000002		CMPB 0x330(SP), $0x2									
  primary_directory_v1.go:43	0x6d874d		753c				JNE 0x6d878b										
  tree.go:647			0x6d874f		4c898c24e8000000		MOVQ R9, 0xe8(SP)									
  tree.go:647			0x6d8757		4c899424c0020000		MOVQ R10, 0x2c0(SP)									
  primary_directory_v1.go:43	0x6d875f		488d8424e0020000		LEAQ 0x2e0(SP), AX									
  primary_directory_v1.go:43	0x6d8767		488d1db2798502			LEAQ runtime.zeroVal(SB), BX								
  primary_directory_v1.go:43	0x6d876e		e8ad25f2ff			CALL type:.eq.github.com/snissn/gomap/TreeDB/node.PrimaryOperand(SB)			
  primary_directory_v1.go:43	0x6d8773		84c0				TESTL AL, AL										
  tree.go:648			0x6d8775		0f8548010000			JNE 0x6d88c3										
  tree.go:651			0x6d877b		4c8b8c24e8000000		MOVQ 0xe8(SP), R9									
  tree.go:652			0x6d8783		4c8b9424c0020000		MOVQ 0x2c0(SP), R10									
  tree.go:651			0x6d878b		4d85c9				TESTQ R9, R9										
  tree.go:651			0x6d878e		0f8405f9ffff			JE 0x6d8099										
  tree.go:651			0x6d8794		e9fb000000			JMP 0x6d8894										
  tree.go:664			0x6d8799		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:664			0x6d87a1		440f1139			MOVUPS X15, 0(CX)									
  tree.go:664			0x6d87a5		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:664			0x6d87aa		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:664			0x6d87af		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:664			0x6d87b4		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:664			0x6d87b9		488b0530867302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:664			0x6d87c0		488b1d31867302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:664			0x6d87c7		4881c428040000			ADDQ $0x428, SP										
  tree.go:664			0x6d87ce		5d				POPQ BP											
  tree.go:664			0x6d87cf		c3				RET											
  tree.go:661			0x6d87d0		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:661			0x6d87d8		440f1139			MOVUPS X15, 0(CX)									
  tree.go:661			0x6d87dc		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:661			0x6d87e1		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:661			0x6d87e6		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:661			0x6d87eb		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:661			0x6d87f0		488b05f9857302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:661			0x6d87f7		488b1dfa857302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:661			0x6d87fe		4881c428040000			ADDQ $0x428, SP										
  tree.go:661			0x6d8805		5d				POPQ BP											
  tree.go:661			0x6d8806		c3				RET											
  tree.go:677			0x6d8807		488d942450040000		LEAQ 0x450(SP), DX									
  tree.go:677			0x6d880f		440f113a			MOVUPS X15, 0(DX)									
  tree.go:677			0x6d8813		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:677			0x6d8818		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:677			0x6d881d		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:677			0x6d8822		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:677			0x6d8827		4889c8				MOVQ CX, AX										
  tree.go:677			0x6d882a		4889fb				MOVQ DI, BX										
  tree.go:677			0x6d882d		4881c428040000			ADDQ $0x428, SP										
  tree.go:677			0x6d8834		5d				POPQ BP											
  tree.go:677			0x6d8835		c3				RET											
  tree.go:671			0x6d8836		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:671			0x6d883e		440f1139			MOVUPS X15, 0(CX)									
  tree.go:671			0x6d8842		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:671			0x6d8847		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:671			0x6d884c		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:671			0x6d8851		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:671			0x6d8856		4c89d0				MOVQ R10, AX										
  tree.go:671			0x6d8859		4c89db				MOVQ R11, BX										
  tree.go:671			0x6d885c		4881c428040000			ADDQ $0x428, SP										
  tree.go:671			0x6d8863		5d				POPQ BP											
  tree.go:671			0x6d8864		c3				RET											
  tree.go:658			0x6d8865		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:658			0x6d886d		440f1139			MOVUPS X15, 0(CX)									
  tree.go:658			0x6d8871		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:658			0x6d8876		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:658			0x6d887b		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:658			0x6d8880		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:658			0x6d8885		4c89d0				MOVQ R10, AX										
  tree.go:658			0x6d8888		4c89db				MOVQ R11, BX										
  tree.go:658			0x6d888b		4881c428040000			ADDQ $0x428, SP										
  tree.go:658			0x6d8892		5d				POPQ BP											
  tree.go:658			0x6d8893		c3				RET											
  tree.go:652			0x6d8894		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:652			0x6d889c		440f1139			MOVUPS X15, 0(CX)									
  tree.go:652			0x6d88a0		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:652			0x6d88a5		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:652			0x6d88aa		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:652			0x6d88af		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:652			0x6d88b4		4c89c8				MOVQ R9, AX										
  tree.go:652			0x6d88b7		4c89d3				MOVQ R10, BX										
  tree.go:652			0x6d88ba		4881c428040000			ADDQ $0x428, SP										
  tree.go:652			0x6d88c1		5d				POPQ BP											
  tree.go:652			0x6d88c2		c3				RET											
  tree.go:649			0x6d88c3		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:649			0x6d88cb		440f1139			MOVUPS X15, 0(CX)									
  tree.go:649			0x6d88cf		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:649			0x6d88d4		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:649			0x6d88d9		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:649			0x6d88de		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:649			0x6d88e3		488b8c2438030000		MOVQ 0x338(SP), CX									
  tree.go:649			0x6d88eb		488b942440030000		MOVQ 0x340(SP), DX									
  tree.go:649			0x6d88f3		488bb42448030000		MOVQ 0x348(SP), SI									
  tree.go:649			0x6d88fb		48898c2450040000		MOVQ CX, 0x450(SP)									
  tree.go:649			0x6d8903		4889942458040000		MOVQ DX, 0x458(SP)									
  tree.go:649			0x6d890b		4889b42460040000		MOVQ SI, 0x460(SP)									
  tree.go:649			0x6d8913		c684249004000002		MOVB $0x2, 0x490(SP)									
  tree.go:649			0x6d891b		488b8c2498030000		MOVQ 0x398(SP), CX									
  tree.go:649			0x6d8923		48898c2498040000		MOVQ CX, 0x498(SP)									
  tree.go:649			0x6d892b		31c0				XORL AX, AX										
  tree.go:649			0x6d892d		31db				XORL BX, BX										
  tree.go:649			0x6d892f		4881c428040000			ADDQ $0x428, SP										
  tree.go:649			0x6d8936		5d				POPQ BP											
  tree.go:649			0x6d8937		c3				RET											
  tree.go:643			0x6d8938		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:643			0x6d8940		440f1139			MOVUPS X15, 0(CX)									
  tree.go:643			0x6d8944		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:643			0x6d8949		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:643			0x6d894e		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:643			0x6d8953		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:643			0x6d8958		488b0571897302			MOVQ github.com/snissn/gomap/TreeDB/node.ErrPrimaryDirectory(SB), AX			
  tree.go:643			0x6d895f		488b1d72897302			MOVQ github.com/snissn/gomap/TreeDB/node.ErrPrimaryDirectory+8(SB), BX			
  tree.go:643			0x6d8966		4881c428040000			ADDQ $0x428, SP										
  tree.go:643			0x6d896d		5d				POPQ BP											
  tree.go:643			0x6d896e		c3				RET											
  tree.go:706			0x6d896f		440f11bc2418040000		MOVUPS X15, 0x418(SP)									
  tree.go:706			0x6d8978		e88383d4ff			CALL runtime.convT16(SB)								
  tree.go:706			0x6d897d		488d0d1c654801			LEAQ 0x148651c(IP), CX									
  tree.go:706			0x6d8984		48898c2418040000		MOVQ CX, 0x418(SP)									
  tree.go:706			0x6d898c		4889842420040000		MOVQ AX, 0x420(SP)									
  errors.go:26			0x6d8994		488d0588286a01			LEAQ 0x16a2888(IP), AX									
  errors.go:26			0x6d899b		bb14000000			MOVL $0x14, BX										
  errors.go:26			0x6d89a0		488d8c2418040000		LEAQ 0x418(SP), CX									
  errors.go:26			0x6d89a8		bf01000000			MOVL $0x1, DI										
  errors.go:26			0x6d89ad		4889fe				MOVQ DI, SI										
  errors.go:26			0x6d89b0		e8aba5e2ff			CALL fmt.errorf(SB)									
  errors.go:26			0x6d89b5		4885c0				TESTQ AX, AX										
  errors.go:26			0x6d89b8		7529				JNE 0x6d89e3										
  errors.go:31			0x6d89ba		90				NOPL											
  errors.go:65			0x6d89bb		488d051ece5001			LEAQ 0x150ce1e(IP), AX									
  errors.go:65			0x6d89c2		e8d9c0d4ff			CALL runtime.newobject(SB)								
  errors.go:65			0x6d89c7		48c7400814000000		MOVQ $0x14, 0x8(AX)									
  errors.go:65			0x6d89cf		488d0d4d286a01			LEAQ 0x16a284d(IP), CX									
  errors.go:65			0x6d89d6		488908				MOVQ CX, 0(AX)										
  tree.go:706			0x6d89d9		4889c3				MOVQ AX, BX										
  tree.go:706			0x6d89dc		488d05dd537e01			LEAQ go:itab.*errors.errorString,error(SB), AX						
  tree.go:706			0x6d89e3		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:706			0x6d89eb		440f1139			MOVUPS X15, 0(CX)									
  tree.go:706			0x6d89ef		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:706			0x6d89f4		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:706			0x6d89f9		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:706			0x6d89fe		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:706			0x6d8a03		4881c428040000			ADDQ $0x428, SP										
  tree.go:706			0x6d8a0a		5d				POPQ BP											
  tree.go:706			0x6d8a0b		c3				RET											
  tree.go:683			0x6d8a0c		488d842470010000		LEAQ 0x170(SP), AX									
  tree.go:683			0x6d8a14		488b9c24a8040000		MOVQ 0x4a8(SP), BX									
  tree.go:683			0x6d8a1c		488b8c24b0040000		MOVQ 0x4b0(SP), CX									
  tree.go:683			0x6d8a24		488bbc24b8040000		MOVQ 0x4b8(SP), DI									
  tree.go:683			0x6d8a2c		e88f91f1ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchLeaf(SB)				
  tree.go:684			0x6d8a31		4885c9				TESTQ CX, CX										
  tree.go:684			0x6d8a34		0f8521010000			JNE 0x6d8b5b										
  tree.go:684			0x6d8a3a		660f1f440000			NOPW 0(AX)(AX*1)									
  tree.go:683			0x6d8a40		84db				TESTL BL, BL										
  tree.go:687			0x6d8a42		0f84dc000000			JE 0x6d8b24										
  tree.go:692			0x6d8a48		89c3				MOVL AX, BX										
  tree.go:692			0x6d8a4a		488d842470010000		LEAQ 0x170(SP), AX									
  tree.go:692			0x6d8a52		e8497af1ff			CALL github.com/snissn/gomap/TreeDB/node.(*Node).GetLeafEntryViewWithRevision(SB)	
  tree.go:692			0x6d8a57		488b542410			MOVQ 0x10(SP), DX									
  tree.go:692			0x6d8a5c		0f1f4000			NOPL 0(AX)										
  tree.go:693			0x6d8a60		4885d2				TESTQ DX, DX										
  tree.go:693			0x6d8a63		7431				JE 0x6d8a96										
  tree.go:692			0x6d8a65		488b5c2418			MOVQ 0x18(SP), BX									
  tree.go:694			0x6d8a6a		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:694			0x6d8a72		440f1139			MOVUPS X15, 0(CX)									
  tree.go:694			0x6d8a76		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:694			0x6d8a7b		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:694			0x6d8a80		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:694			0x6d8a85		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:694			0x6d8a8a		4889d0				MOVQ DX, AX										
  tree.go:694			0x6d8a8d		4881c428040000			ADDQ $0x428, SP										
  tree.go:694			0x6d8a94		5d				POPQ BP											
  tree.go:694			0x6d8a95		c3				RET											
  tree.go:692			0x6d8a96		0fb61424			MOVZX 0(SP), DX										
  tree.go:692			0x6d8a9a		4c8b642408			MOVQ 0x8(SP), R12									
  tree.go:702			0x6d8a9f		4c8dac2450040000		LEAQ 0x450(SP), R13									
  tree.go:702			0x6d8aa7		450f117d00			MOVUPS X15, 0(R13)									
  tree.go:702			0x6d8aac		450f117d10			MOVUPS X15, 0x10(R13)									
  tree.go:702			0x6d8ab1		450f117d20			MOVUPS X15, 0x20(R13)									
  tree.go:702			0x6d8ab6		450f117d30			MOVUPS X15, 0x30(R13)									
  tree.go:702			0x6d8abb		450f117d40			MOVUPS X15, 0x40(R13)									
  tree.go:698			0x6d8ac0		4889842450040000		MOVQ AX, 0x450(SP)									
  tree.go:698			0x6d8ac8		48899c2458040000		MOVQ BX, 0x458(SP)									
  tree.go:698			0x6d8ad0		48898c2460040000		MOVQ CX, 0x460(SP)									
  tree.go:699			0x6d8ad8		4889bc2468040000		MOVQ DI, 0x468(SP)									
  tree.go:699			0x6d8ae0		4889b42470040000		MOVQ SI, 0x470(SP)									
  tree.go:699			0x6d8ae8		4c89842478040000		MOVQ R8, 0x478(SP)									
  tree.go:700			0x6d8af0		4c898c2480040000		MOVQ R9, 0x480(SP)									
  tree.go:700			0x6d8af8		4489942488040000		MOVL R10, 0x488(SP)									
  tree.go:700			0x6d8b00		44899c248c040000		MOVL R11, 0x48c(SP)									
  tree.go:701			0x6d8b08		88942490040000			MOVB DL, 0x490(SP)									
  tree.go:702			0x6d8b0f		4c89a42498040000		MOVQ R12, 0x498(SP)									
  tree.go:697			0x6d8b17		31c0				XORL AX, AX										
  tree.go:697			0x6d8b19		31db				XORL BX, BX										
  tree.go:703			0x6d8b1b		4881c428040000			ADDQ $0x428, SP										
  tree.go:703			0x6d8b22		5d				POPQ BP											
  tree.go:703			0x6d8b23		c3				RET											
  tree.go:688			0x6d8b24		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:688			0x6d8b2c		440f1139			MOVUPS X15, 0(CX)									
  tree.go:688			0x6d8b30		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:688			0x6d8b35		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:688			0x6d8b3a		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:688			0x6d8b3f		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:688			0x6d8b44		488b05a5827302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), AX				
  tree.go:688			0x6d8b4b		488b1da6827302			MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), BX			
  tree.go:688			0x6d8b52		4881c428040000			ADDQ $0x428, SP										
  tree.go:688			0x6d8b59		5d				POPQ BP											
  tree.go:688			0x6d8b5a		c3				RET											
  tree.go:685			0x6d8b5b		488d942450040000		LEAQ 0x450(SP), DX									
  tree.go:685			0x6d8b63		440f113a			MOVUPS X15, 0(DX)									
  tree.go:685			0x6d8b67		440f117a10			MOVUPS X15, 0x10(DX)									
  tree.go:685			0x6d8b6c		440f117a20			MOVUPS X15, 0x20(DX)									
  tree.go:685			0x6d8b71		440f117a30			MOVUPS X15, 0x30(DX)									
  tree.go:685			0x6d8b76		440f117a40			MOVUPS X15, 0x40(DX)									
  tree.go:685			0x6d8b7b		4889c8				MOVQ CX, AX										
  tree.go:685			0x6d8b7e		4889fb				MOVQ DI, BX										
  tree.go:685			0x6d8b81		4881c428040000			ADDQ $0x428, SP										
  tree.go:685			0x6d8b88		5d				POPQ BP											
  tree.go:685			0x6d8b89		c3				RET											
  tree.go:633			0x6d8b8a		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:633			0x6d8b92		440f1139			MOVUPS X15, 0(CX)									
  tree.go:633			0x6d8b96		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:633			0x6d8b9b		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:633			0x6d8ba0		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:633			0x6d8ba5		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:633			0x6d8baa		4881c428040000			ADDQ $0x428, SP										
  tree.go:633			0x6d8bb1		5d				POPQ BP											
  tree.go:633			0x6d8bb2		c3				RET											
  errors.go:65			0x6d8bb3		488d0526cc5001			LEAQ 0x150cc26(IP), AX									
  errors.go:65			0x6d8bba		e8e1bed4ff			CALL runtime.newobject(SB)								
  errors.go:65			0x6d8bbf		48c740080d000000		MOVQ $0xd, 0x8(AX)									
  errors.go:65			0x6d8bc7		488d0d7c456901			LEAQ 0x169457c(IP), CX									
  errors.go:65			0x6d8bce		488908				MOVQ CX, 0(AX)										
  tree.go:709			0x6d8bd1		488d8c2450040000		LEAQ 0x450(SP), CX									
  tree.go:709			0x6d8bd9		440f1139			MOVUPS X15, 0(CX)									
  tree.go:709			0x6d8bdd		440f117910			MOVUPS X15, 0x10(CX)									
  tree.go:709			0x6d8be2		440f117920			MOVUPS X15, 0x20(CX)									
  tree.go:709			0x6d8be7		440f117930			MOVUPS X15, 0x30(CX)									
  tree.go:709			0x6d8bec		440f117940			MOVUPS X15, 0x40(CX)									
  tree.go:709			0x6d8bf1		4889c3				MOVQ AX, BX										
  tree.go:709			0x6d8bf4		488d05c5517e01			LEAQ go:itab.*errors.errorString,error(SB), AX						
  tree.go:709			0x6d8bfb		4881c428040000			ADDQ $0x428, SP										
  tree.go:709			0x6d8c02		5d				POPQ BP											
  tree.go:709			0x6d8c03		c3				RET											
  node.go:56			0x6d8c04		e8f7b9dbff			CALL runtime.panicBounds(SB)								
  node.go:56			0x6d8c09		e8f2b9dbff			CALL runtime.panicBounds(SB)								
  node.go:56			0x6d8c0e		90				NOPL											
  tree.go:620			0x6d8c0f		4889442470			MOVQ AX, 0x70(SP)									
  tree.go:620			0x6d8c14		48895c2478			MOVQ BX, 0x78(SP)									
  tree.go:620			0x6d8c19		48898c2480000000		MOVQ CX, 0x80(SP)									
  tree.go:620			0x6d8c21		4889bc2488000000		MOVQ DI, 0x88(SP)									
  tree.go:620			0x6d8c29		4889b42490000000		MOVQ SI, 0x90(SP)									
  tree.go:620			0x6d8c31		4c89842498000000		MOVQ R8, 0x98(SP)									
  tree.go:620			0x6d8c39		4c898c24a0000000		MOVQ R9, 0xa0(SP)									
  tree.go:620			0x6d8c41		4c899424a8000000		MOVQ R10, 0xa8(SP)									
  tree.go:620			0x6d8c49		44889c24b0000000		MOVB R11, 0xb0(SP)									
  tree.go:620			0x6d8c51		e80a9bdbff			CALL runtime.morestack_noctxt.abi0(SB)							
  tree.go:620			0x6d8c56		488b442470			MOVQ 0x70(SP), AX									
  tree.go:620			0x6d8c5b		488b5c2478			MOVQ 0x78(SP), BX									
  tree.go:620			0x6d8c60		488b8c2480000000		MOVQ 0x80(SP), CX									
  tree.go:620			0x6d8c68		488bbc2488000000		MOVQ 0x88(SP), DI									
  tree.go:620			0x6d8c70		488bb42490000000		MOVQ 0x90(SP), SI									
  tree.go:620			0x6d8c78		4c8b842498000000		MOVQ 0x98(SP), R8									
  tree.go:620			0x6d8c80		4c8b8c24a0000000		MOVQ 0xa0(SP), R9									
  tree.go:620			0x6d8c88		4c8b9424a8000000		MOVQ 0xa8(SP), R10									
  tree.go:620			0x6d8c90		440fb69c24b0000000		MOVZX 0xb0(SP), R11									
  tree.go:620			0x6d8c99		e9e2f2ffff			JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).getEntry(SB)				

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1082		0x6db5a0		493b6610		CMPQ SP, 0x10(R14)								
  tree.go:1082		0x6db5a4		0f86af020000		JBE 0x6db859									
  tree.go:1082		0x6db5aa		55			PUSHQ BP									
  tree.go:1082		0x6db5ab		4889e5			MOVQ SP, BP									
  tree.go:1082		0x6db5ae		4883ec78		SUBQ $0x78, SP									
  tree.go:1084		0x6db5b2		4889842488000000	MOVQ AX, 0x88(SP)								
  tree.go:1084		0x6db5ba		4c898c24b8000000	MOVQ R9, 0xb8(SP)								
  tree.go:1084		0x6db5c2		4889b424a8000000	MOVQ SI, 0xa8(SP)								
  tree.go:1084		0x6db5ca		48899c2490000000	MOVQ BX, 0x90(SP)								
  tree.go:1084		0x6db5d2		4c898424b0000000	MOVQ R8, 0xb0(SP)								
  tree.go:1084		0x6db5da		4889bc24a0000000	MOVQ DI, 0xa0(SP)								
  tree.go:1084		0x6db5e2		48898c2498000000	MOVQ CX, 0x98(SP)								
  tree.go:1083		0x6db5ea		41ba01000000		MOVL $0x1, R10									
  tree.go:1083		0x6db5f0		e8abd6ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).lookupLeafValueView(SB)	
  tree.go:1083		0x6db5f5		488b1424		MOVQ 0(SP), DX									
  tree.go:1083		0x6db5f9		0f1f8000000000		NOPL 0(AX)									
  tree.go:1084		0x6db600		4885d2			TESTQ DX, DX									
  tree.go:1084		0x6db603		0f8527020000		JNE 0x6db830									
  tree.go:1083		0x6db609		4584db			TESTL R11, R11									
  tree.go:1087		0x6db60c		7452			JE 0x6db660									
  tree.go:1088		0x6db60e		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1088		0x6db616		4989d9			MOVQ BX, R9									
  tree.go:1088		0x6db619		4929d1			SUBQ DX, R9									
  tree.go:100		0x6db61c		803d9411850200		CMPB github.com/snissn/gomap/TreeDB/tree.treeHotReadStatsEnabled(SB), $0x0	
  tree.go:100		0x6db623		7424			JE 0x6db649									
  tree.go:103		0x6db625		90			NOPL										
  type.go:195		0x6db626		ba01000000		MOVL $0x1, DX									
  type.go:195		0x6db62b		4c8d1d06178502		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineHitsTotal(SB), R11	
  type.go:195		0x6db632		f0490fc113		LOCK XADDQ DX, 0(R11)								
  tree.go:104		0x6db637		4d85c9			TESTQ R9, R9									
  tree.go:104		0x6db63a		7e0d			JLE 0x6db649									
  tree.go:105		0x6db63c		90			NOPL										
  type.go:195		0x6db63d		488d15fc168502		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineBytesTotal(SB), DX	
  type.go:195		0x6db644		f04c0fc10a		LOCK XADDQ R9, 0(DX)								
  tree.go:1089		0x6db649		4c89d7			MOVQ R10, DI									
  tree.go:1089		0x6db64c		31f6			XORL SI, SI									
  tree.go:1089		0x6db64e		4531c0			XORL R8, R8									
  tree.go:1089		0x6db651		4883c478		ADDQ $0x78, SP									
  tree.go:1089		0x6db655		5d			POPQ BP										
  tree.go:1089		0x6db656		c3			RET										
  tree.go:1089		0x6db657		660f1f840000000000	NOPW 0(AX)(AX*1)								
  tree.go:1091		0x6db660		41f6c102		TESTL $0x2, R9									
  tree.go:1091		0x6db664		0f8597010000		JNE 0x6db801									
  tree.go:1083		0x6db66a		4c89542450		MOVQ R10, 0x50(SP)								
  tree.go:1094		0x6db66f		41f6c101		TESTL $0x1, R9									
  tree.go:1094		0x6db673		0f8523010000		JNE 0x6db79c									
  tree.go:1094		0x6db679		0f1f8000000000		NOPL 0(AX)									
  tree.go:1098		0x6db680		4885c0			TESTQ AX, AX									
  tree.go:1098		0x6db683		0f84d1000000		JE 0x6db75a									
  tree.go:1102		0x6db689		90			NOPL										
  tree.go:100		0x6db68a		803d2611850200		CMPB github.com/snissn/gomap/TreeDB/tree.treeHotReadStatsEnabled(SB), $0x0	
  tree.go:100		0x6db691		742f			JE 0x6db6c2									
  tree.go:103		0x6db693		90			NOPL										
  type.go:195		0x6db694		ba01000000		MOVL $0x1, DX									
  type.go:195		0x6db699		4c8d0598168502		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineHitsTotal(SB), R8	
  type.go:195		0x6db6a0		f0490fc110		LOCK XADDQ DX, 0(R8)								
  tree.go:104		0x6db6a5		4885db			TESTQ BX, BX									
  tree.go:104		0x6db6a8		7411			JE 0x6db6bb									
  type.go:195		0x6db6aa		488d158f168502		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineBytesTotal(SB), DX	
  type.go:195		0x6db6b1		4889df			MOVQ BX, DI									
  type.go:195		0x6db6b4		f0480fc11a		LOCK XADDQ BX, 0(DX)								
  tree.go:105		0x6db6b9		eb0a			JMP 0x6db6c5									
  tree.go:1103		0x6db6bb		4889df			MOVQ BX, DI									
  tree.go:1103		0x6db6be		6690			NOPW										
  tree.go:104		0x6db6c0		eb03			JMP 0x6db6c5									
  tree.go:1103		0x6db6c2		4889df			MOVQ BX, DI									
  tree.go:1103		0x6db6c5		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1103		0x6db6cd		488d1c3a		LEAQ 0(DX)(DI*1), BX								
  tree.go:1103		0x6db6d1		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1103		0x6db6d9		4839d9			CMPQ CX, BX									
  tree.go:1103		0x6db6dc		720a			JB 0x6db6e8									
  tree.go:1103		0x6db6de		488bb424a8000000	MOVQ 0xa8(SP), SI								
  tree.go:1103		0x6db6e6		eb33			JMP 0x6db71b									
  tree.go:1083		0x6db6e8		48897c2460		MOVQ DI, 0x60(SP)								
  tree.go:1083		0x6db6ed		4889442468		MOVQ AX, 0x68(SP)								
  tree.go:1103		0x6db6f2		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1103		0x6db6fa		488d351f2a4801		LEAQ 0x1482a1f(IP), SI								
  tree.go:1103		0x6db701		e87a36dbff		CALL runtime.growslice(SB)							
  tree.go:1103		0x6db706		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1103		0x6db70e		488b7c2460		MOVQ 0x60(SP), DI								
  tree.go:1103		0x6db713		4889c6			MOVQ AX, SI									
  tree.go:1103		0x6db716		488b442468		MOVQ 0x68(SP), AX								
  tree.go:1103		0x6db71b		48894c2460		MOVQ CX, 0x60(SP)								
  tree.go:1103		0x6db720		48895c2458		MOVQ BX, 0x58(SP)								
  tree.go:1103		0x6db725		4889742470		MOVQ SI, 0x70(SP)								
  tree.go:1103		0x6db72a		4801f2			ADDQ SI, DX									
  tree.go:1103		0x6db72d		4889c3			MOVQ AX, BX									
  tree.go:1103		0x6db730		4889f9			MOVQ DI, CX									
  tree.go:1103		0x6db733		4889d0			MOVQ DX, AX									
  tree.go:1103		0x6db736		e86592dbff		CALL runtime.memmove(SB)							
  tree.go:1103		0x6db73b		488b442470		MOVQ 0x70(SP), AX								
  tree.go:1103		0x6db740		488b5c2458		MOVQ 0x58(SP), BX								
  tree.go:1103		0x6db745		488b4c2460		MOVQ 0x60(SP), CX								
  tree.go:1103		0x6db74a		488b7c2450		MOVQ 0x50(SP), DI								
  tree.go:1103		0x6db74f		31f6			XORL SI, SI									
  tree.go:1103		0x6db751		4531c0			XORL R8, R8									
  tree.go:1103		0x6db754		4883c478		ADDQ $0x78, SP									
  tree.go:1103		0x6db758		5d			POPQ BP										
  tree.go:1103		0x6db759		c3			RET										
  tree.go:1099		0x6db75a		90			NOPL										
  tree.go:100		0x6db75b		803d5510850200		CMPB github.com/snissn/gomap/TreeDB/tree.treeHotReadStatsEnabled(SB), $0x0	
  tree.go:100		0x6db762		7412			JE 0x6db776									
  tree.go:103		0x6db764		90			NOPL										
  type.go:195		0x6db765		ba01000000		MOVL $0x1, DX									
  type.go:195		0x6db76a		4c8d0dc7158502		LEAQ github.com/snissn/gomap/TreeDB/tree.treeGetAppendInlineHitsTotal(SB), R9	
  type.go:195		0x6db771		f0490fc111		LOCK XADDQ DX, 0(R9)								
  tree.go:1100		0x6db776		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1100		0x6db77e		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  tree.go:1100		0x6db786		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1100		0x6db78e		4c89d7			MOVQ R10, DI									
  tree.go:1100		0x6db791		31f6			XORL SI, SI									
  tree.go:1100		0x6db793		4531c0			XORL R8, R8									
  tree.go:1100		0x6db796		4883c478		ADDQ $0x78, SP									
  tree.go:1100		0x6db79a		5d			POPQ BP										
  tree.go:1100		0x6db79b		c3			RET										
  tree.go:1095		0x6db79c		488b9424a8000000	MOVQ 0xa8(SP), DX								
  tree.go:1095		0x6db7a4		48891424		MOVQ DX, 0(SP)									
  tree.go:1095		0x6db7a8		488b9424b0000000	MOVQ 0xb0(SP), DX								
  tree.go:1095		0x6db7b0		4889542408		MOVQ DX, 0x8(SP)								
  tree.go:1095		0x6db7b5		488b9424b8000000	MOVQ 0xb8(SP), DX								
  tree.go:1095		0x6db7bd		4889542410		MOVQ DX, 0x10(SP)								
  tree.go:1095		0x6db7c2		488b842488000000	MOVQ 0x88(SP), AX								
  tree.go:1095		0x6db7ca		488b9c2490000000	MOVQ 0x90(SP), BX								
  tree.go:1095		0x6db7d2		488b8c2498000000	MOVQ 0x98(SP), CX								
  tree.go:1095		0x6db7da		4589c1			MOVL R8, R9									
  tree.go:1095		0x6db7dd		4189f0			MOVL SI, R8									
  tree.go:1095		0x6db7e0		4889fe			MOVQ DI, SI									
  tree.go:1095		0x6db7e3		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  tree.go:1095		0x6db7eb		e850f3ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).appendPointerValueForKey(SB)	
  tree.go:1096		0x6db7f0		4989f0			MOVQ SI, R8									
  tree.go:1096		0x6db7f3		4889fe			MOVQ DI, SI									
  tree.go:1096		0x6db7f6		488b7c2450		MOVQ 0x50(SP), DI								
  tree.go:1096		0x6db7fb		4883c478		ADDQ $0x78, SP									
  tree.go:1096		0x6db7ff		5d			POPQ BP										
  tree.go:1096		0x6db800		c3			RET										
  tree.go:1092		0x6db801		488b35e8557302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), SI			
  tree.go:1092		0x6db808		4c8b05e9557302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R8		
  tree.go:1092		0x6db80f		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1092		0x6db817		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  tree.go:1092		0x6db81f		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1092		0x6db827		4c89d7			MOVQ R10, DI									
  tree.go:1092		0x6db82a		4883c478		ADDQ $0x78, SP									
  tree.go:1092		0x6db82e		5d			POPQ BP										
  tree.go:1092		0x6db82f		c3			RET										
  tree.go:1083		0x6db830		4c8b442408		MOVQ 0x8(SP), R8								
  tree.go:1085		0x6db835		488b8424a8000000	MOVQ 0xa8(SP), AX								
  tree.go:1085		0x6db83d		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  tree.go:1085		0x6db845		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  tree.go:1085		0x6db84d		4c89d7			MOVQ R10, DI									
  tree.go:1085		0x6db850		4889d6			MOVQ DX, SI									
  tree.go:1085		0x6db853		4883c478		ADDQ $0x78, SP									
  tree.go:1085		0x6db857		5d			POPQ BP										
  tree.go:1085		0x6db858		c3			RET										
  tree.go:1082		0x6db859		4889442408		MOVQ AX, 0x8(SP)								
  tree.go:1082		0x6db85e		48895c2410		MOVQ BX, 0x10(SP)								
  tree.go:1082		0x6db863		48894c2418		MOVQ CX, 0x18(SP)								
  tree.go:1082		0x6db868		48897c2420		MOVQ DI, 0x20(SP)								
  tree.go:1082		0x6db86d		4889742428		MOVQ SI, 0x28(SP)								
  tree.go:1082		0x6db872		4c89442430		MOVQ R8, 0x30(SP)								
  tree.go:1082		0x6db877		4c894c2438		MOVQ R9, 0x38(SP)								
  tree.go:1082		0x6db87c		0f1f4000		NOPL 0(AX)									
  tree.go:1082		0x6db880		e8db6edbff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1082		0x6db885		488b442408		MOVQ 0x8(SP), AX								
  tree.go:1082		0x6db88a		488b5c2410		MOVQ 0x10(SP), BX								
  tree.go:1082		0x6db88f		488b4c2418		MOVQ 0x18(SP), CX								
  tree.go:1082		0x6db894		488b7c2420		MOVQ 0x20(SP), DI								
  tree.go:1082		0x6db899		488b742428		MOVQ 0x28(SP), SI								
  tree.go:1082		0x6db89e		4c8b442430		MOVQ 0x30(SP), R8								
  tree.go:1082		0x6db8a3		4c8b4c2438		MOVQ 0x38(SP), R9								
  tree.go:1082		0x6db8a8		e9f3fcffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB)		

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyViewFallback(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1384		0x6dda60		4c8d6424d8		LEAQ -0x28(SP), R12								
  tree.go:1384		0x6dda65		4d3b6610		CMPQ R12, 0x10(R14)								
  tree.go:1384		0x6dda69		0f8624020000		JBE 0x6ddc93									
  tree.go:1384		0x6dda6f		55			PUSHQ BP									
  tree.go:1384		0x6dda70		4889e5			MOVQ SP, BP									
  tree.go:1384		0x6dda73		4881eca0000000		SUBQ $0xa0, SP									
  tree.go:1384		0x6dda7a		48899c24b8000000	MOVQ BX, 0xb8(SP)								
  tree.go:1386		0x6dda82		48898424b0000000	MOVQ AX, 0xb0(SP)								
  tree.go:1386		0x6dda8a		4889b424d0000000	MOVQ SI, 0xd0(SP)								
  tree.go:1386		0x6dda92		48898c24c0000000	MOVQ CX, 0xc0(SP)								
  tree.go:1386		0x6dda9a		31d2			XORL DX, DX									
  tree.go:1386		0x6dda9c		31ff			XORL DI, DI									
  tree.go:1386		0x6dda9e		4531c0			XORL R8, R8									
  tree.go:1386		0x6ddaa1		eb3d			JMP 0x6ddae0									
  tree.go:1386		0x6ddaa3		488b9c2498000000	MOVQ 0x98(SP), BX								
  tree.go:1386		0x6ddaab		4883c318		ADDQ $0x18, BX									
  tree.go:1386		0x6ddaaf		4c8b542460		MOVQ 0x60(SP), R10								
  tree.go:1386		0x6ddab4		49ffc2			INCQ R10									
  tree.go:1386		0x6ddab7		488b8c24c0000000	MOVQ 0xc0(SP), CX								
  tree.go:1401		0x6ddabf		488bb424d0000000	MOVQ 0xd0(SP), SI								
  tree.go:1386		0x6ddac7		4889d7			MOVQ DX, DI									
  tree.go:1386		0x6ddaca		4989c0			MOVQ AX, R8									
  tree.go:1387		0x6ddacd		488b8424b0000000	MOVQ 0xb0(SP), AX								
  tree.go:1386		0x6ddad5		4c89d2			MOVQ R10, DX									
  tree.go:1386		0x6ddad8		0f1f840000000000	NOPL 0(AX)(AX*1)								
  tree.go:1386		0x6ddae0		4839d1			CMPQ CX, DX									
  tree.go:1386		0x6ddae3		0f8e9d010000		JLE 0x6ddc86									
  tree.go:1386		0x6ddae9		4889542460		MOVQ DX, 0x60(SP)								
  tree.go:1386		0x6ddaee		4c89442478		MOVQ R8, 0x78(SP)								
  tree.go:1386		0x6ddaf3		48897c2440		MOVQ DI, 0x40(SP)								
  tree.go:1386		0x6ddaf8		48899c2498000000	MOVQ BX, 0x98(SP)								
  tree.go:1386		0x6ddb00		488b13			MOVQ 0(BX), DX									
  tree.go:1386		0x6ddb03		4889942480000000	MOVQ DX, 0x80(SP)								
  tree.go:1386		0x6ddb0b		488b4b08		MOVQ 0x8(BX), CX								
  tree.go:1386		0x6ddb0f		48894c2450		MOVQ CX, 0x50(SP)								
  tree.go:1386		0x6ddb14		4c8b5310		MOVQ 0x10(BX), R10								
  tree.go:1386		0x6ddb18		4c89542458		MOVQ R10, 0x58(SP)								
  tree.go:1387		0x6ddb1d		4889d3			MOVQ DX, BX									
  tree.go:1387		0x6ddb20		4c89c6			MOVQ R8, SI									
  tree.go:1387		0x6ddb23		4531c0			XORL R8, R8									
  tree.go:1387		0x6ddb26		4989f9			MOVQ DI, R9									
  tree.go:1387		0x6ddb29		4c89d7			MOVQ R10, DI									
  tree.go:1387		0x6ddb2c		e88fd7ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetAppend(SB)			
  tree.go:1387		0x6ddb31		4889842490000000	MOVQ AX, 0x90(SP)								
  tree.go:1387		0x6ddb39		48894c2470		MOVQ CX, 0x70(SP)								
  tree.go:1387		0x6ddb3e		6690			NOPW										
  tree.go:1388		0x6ddb40		48393da9327302		CMPQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), DI			
  tree.go:1388		0x6ddb47		754b			JNE 0x6ddb94									
  tree.go:1387		0x6ddb49		4889b42488000000	MOVQ SI, 0x88(SP)								
  tree.go:1387		0x6ddb51		48897c2468		MOVQ DI, 0x68(SP)								
  tree.go:1387		0x6ddb56		48895c2448		MOVQ BX, 0x48(SP)								
  tree.go:1388		0x6ddb5b		488b0d96327302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), CX		
  tree.go:1388		0x6ddb62		4889f8			MOVQ DI, AX									
  tree.go:1388		0x6ddb65		4889f3			MOVQ SI, BX									
  tree.go:1388		0x6ddb68		e8539fd3ff		CALL runtime.ifaceeq(SB)							
  tree.go:1388		0x6ddb6d		84c0			TESTL AL, AL									
  tree.go:1388		0x6ddb6f		0f85aa000000		JNE 0x6ddc1f									
  tree.go:1401		0x6ddb75		488b842490000000	MOVQ 0x90(SP), AX								
  tree.go:1401		0x6ddb7d		488b4c2470		MOVQ 0x70(SP), CX								
  tree.go:1398		0x6ddb82		488b5c2448		MOVQ 0x48(SP), BX								
  tree.go:1395		0x6ddb87		488bb42488000000	MOVQ 0x88(SP), SI								
  tree.go:1394		0x6ddb8f		488b7c2468		MOVQ 0x68(SP), DI								
  tree.go:1394		0x6ddb94		4885ff			TESTQ DI, DI									
  tree.go:1394		0x6ddb97		0f85d1000000		JNE 0x6ddc6e									
  tree.go:1394		0x6ddb9d		0f1f00			NOPL 0(AX)									
  tree.go:1398		0x6ddba0		4885db			TESTQ BX, BX									
  tree.go:1398		0x6ddba3		7517			JNE 0x6ddbbc									
  tree.go:1399		0x6ddba5		4c8b1df48e7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue(SB), R11		
  tree.go:1399		0x6ddbac		488b1df58e7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+8(SB), BX	
  tree.go:1399		0x6ddbb3		4c8b25f68e7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+16(SB), R12	
  tree.go:1399		0x6ddbba		eb06			JMP 0x6ddbc2									
  tree.go:1401		0x6ddbbc		4989cc			MOVQ CX, R12									
  tree.go:1401		0x6ddbbf		4989c3			MOVQ AX, R11									
  tree.go:1401		0x6ddbc2		488b9424d0000000	MOVQ 0xd0(SP), DX								
  tree.go:1401		0x6ddbca		4c8b2a			MOVQ 0(DX), R13									
  tree.go:1401		0x6ddbcd		488b442460		MOVQ 0x60(SP), AX								
  tree.go:1401		0x6ddbd2		488b4c2450		MOVQ 0x50(SP), CX								
  tree.go:1401		0x6ddbd7		488b7c2458		MOVQ 0x58(SP), DI								
  tree.go:1401		0x6ddbdc		4c89de			MOVQ R11, SI									
  tree.go:1401		0x6ddbdf		4989d8			MOVQ BX, R8									
  tree.go:1401		0x6ddbe2		4d89e1			MOVQ R12, R9									
  tree.go:1401		0x6ddbe5		41ba01000000		MOVL $0x1, R10									
  tree.go:1401		0x6ddbeb		488b9c2480000000	MOVQ 0x80(SP), BX								
  tree.go:1401		0x6ddbf3		41ffd5			CALL R13									
  tree.go:1401		0x6ddbf6		4885c0			TESTQ AX, AX									
  tree.go:1401		0x6ddbf9		756a			JNE 0x6ddc65									
  tree.go:1404		0x6ddbfb		488b542470		MOVQ 0x70(SP), DX								
  tree.go:1404		0x6ddc00		4881fa00001000		CMPQ DX, $0x100000								
  tree.go:1404		0x6ddc07		7f0d			JG 0x6ddc16									
  tree.go:1404		0x6ddc09		488b842490000000	MOVQ 0x90(SP), AX								
  tree.go:1405		0x6ddc11		e98dfeffff		JMP 0x6ddaa3									
  tree.go:1405		0x6ddc16		31d2			XORL DX, DX									
  tree.go:1405		0x6ddc18		31c0			XORL AX, AX									
  tree.go:1404		0x6ddc1a		e984feffff		JMP 0x6ddaa3									
  tree.go:1389		0x6ddc1f		488b9424d0000000	MOVQ 0xd0(SP), DX								
  tree.go:1389		0x6ddc27		4c8b1a			MOVQ 0(DX), R11									
  tree.go:1389		0x6ddc2a		488b442460		MOVQ 0x60(SP), AX								
  tree.go:1389		0x6ddc2f		488b9c2480000000	MOVQ 0x80(SP), BX								
  tree.go:1389		0x6ddc37		488b4c2450		MOVQ 0x50(SP), CX								
  tree.go:1389		0x6ddc3c		488b7c2458		MOVQ 0x58(SP), DI								
  tree.go:1389		0x6ddc41		31f6			XORL SI, SI									
  tree.go:1389		0x6ddc43		4531c0			XORL R8, R8									
  tree.go:1389		0x6ddc46		4d89c1			MOVQ R8, R9									
  tree.go:1389		0x6ddc49		4531d2			XORL R10, R10									
  tree.go:1389		0x6ddc4c		41ffd3			CALL R11									
  tree.go:1389		0x6ddc4f		4885c0			TESTQ AX, AX									
  tree.go:1389		0x6ddc52		7529			JNE 0x6ddc7d									
  tree.go:1386		0x6ddc54		488b542440		MOVQ 0x40(SP), DX								
  tree.go:1386		0x6ddc59		488b442478		MOVQ 0x78(SP), AX								
  tree.go:1386		0x6ddc5e		6690			NOPW										
  tree.go:1392		0x6ddc60		e93efeffff		JMP 0x6ddaa3									
  tree.go:1402		0x6ddc65		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1402		0x6ddc6c		5d			POPQ BP										
  tree.go:1402		0x6ddc6d		c3			RET										
  tree.go:1395		0x6ddc6e		4889f8			MOVQ DI, AX									
  tree.go:1395		0x6ddc71		4889f3			MOVQ SI, BX									
  tree.go:1395		0x6ddc74		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1395		0x6ddc7b		5d			POPQ BP										
  tree.go:1395		0x6ddc7c		c3			RET										
  tree.go:1390		0x6ddc7d		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1390		0x6ddc84		5d			POPQ BP										
  tree.go:1390		0x6ddc85		c3			RET										
  tree.go:1410		0x6ddc86		31c0			XORL AX, AX									
  tree.go:1410		0x6ddc88		31db			XORL BX, BX									
  tree.go:1410		0x6ddc8a		4881c4a0000000		ADDQ $0xa0, SP									
  tree.go:1410		0x6ddc91		5d			POPQ BP										
  tree.go:1410		0x6ddc92		c3			RET										
  tree.go:1384		0x6ddc93		4889442408		MOVQ AX, 0x8(SP)								
  tree.go:1384		0x6ddc98		48895c2410		MOVQ BX, 0x10(SP)								
  tree.go:1384		0x6ddc9d		48894c2418		MOVQ CX, 0x18(SP)								
  tree.go:1384		0x6ddca2		48897c2420		MOVQ DI, 0x20(SP)								
  tree.go:1384		0x6ddca7		4889742428		MOVQ SI, 0x28(SP)								
  tree.go:1384		0x6ddcac		e8af4adbff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1384		0x6ddcb1		488b442408		MOVQ 0x8(SP), AX								
  tree.go:1384		0x6ddcb6		488b5c2410		MOVQ 0x10(SP), BX								
  tree.go:1384		0x6ddcbb		488b4c2418		MOVQ 0x18(SP), CX								
  tree.go:1384		0x6ddcc0		488b7c2420		MOVQ 0x20(SP), DI								
  tree.go:1384		0x6ddcc5		488b742428		MOVQ 0x28(SP), SI								
  tree.go:1384		0x6ddcca		e991fdffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyViewFallback(SB)		

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyAppendFallback(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1413		0x6ddce0		4c8d6424f0		LEAQ -0x10(SP), R12								
  tree.go:1413		0x6ddce5		4d3b6610		CMPQ R12, 0x10(R14)								
  tree.go:1413		0x6ddce9		0f86eb020000		JBE 0x6ddfda									
  tree.go:1413		0x6ddcef		55			PUSHQ BP									
  tree.go:1413		0x6ddcf0		4889e5			MOVQ SP, BP									
  tree.go:1413		0x6ddcf3		4881ec88000000		SUBQ $0x88, SP									
  tree.go:1413		0x6ddcfa		48899c24b8000000	MOVQ BX, 0xb8(SP)								
  tree.go:1414		0x6ddd02		48898424b0000000	MOVQ AX, 0xb0(SP)								
  tree.go:1414		0x6ddd0a		4c898424d8000000	MOVQ R8, 0xd8(SP)								
  tree.go:1414		0x6ddd12		48898c24c0000000	MOVQ CX, 0xc0(SP)								
  tree.go:1414		0x6ddd1a		4889b424d0000000	MOVQ SI, 0xd0(SP)								
  tree.go:1414		0x6ddd22		31d2			XORL DX, DX									
  tree.go:1414		0x6ddd24		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  tree.go:1414		0x6ddd2c		4c8b8c24a8000000	MOVQ 0xa8(SP), R9								
  tree.go:1414		0x6ddd34		4c8b942498000000	MOVQ 0x98(SP), R10								
  tree.go:1414		0x6ddd3c		eb37			JMP 0x6ddd75									
  tree.go:1414		0x6ddd3e		4c8b5c2478		MOVQ 0x78(SP), R11								
  tree.go:1414		0x6ddd43		4983c318		ADDQ $0x18, R11									
  tree.go:1414		0x6ddd47		4d8d6201		LEAQ 0x1(R10), R12								
  tree.go:1426		0x6ddd4b		4889d6			MOVQ DX, SI									
  tree.go:1426		0x6ddd4e		4c8b8424d8000000	MOVQ 0xd8(SP), R8								
  tree.go:1414		0x6ddd56		4c89e2			MOVQ R12, DX									
  tree.go:1414		0x6ddd59		4889df			MOVQ BX, DI									
  tree.go:1414		0x6ddd5c		4989c9			MOVQ CX, R9									
  tree.go:1414		0x6ddd5f		4989c2			MOVQ AX, R10									
  tree.go:1416		0x6ddd62		488b8424b0000000	MOVQ 0xb0(SP), AX								
  tree.go:1414		0x6ddd6a		488b8c24c0000000	MOVQ 0xc0(SP), CX								
  tree.go:1414		0x6ddd72		4c89db			MOVQ R11, BX									
  tree.go:1414		0x6ddd75		4839d1			CMPQ CX, DX									
  tree.go:1414		0x6ddd78		0f8e31020000		JLE 0x6ddfaf									
  tree.go:1414		0x6ddd7e		4889542448		MOVQ DX, 0x48(SP)								
  tree.go:1414		0x6ddd83		4c894c2460		MOVQ R9, 0x60(SP)								
  tree.go:1414		0x6ddd88		48897c2458		MOVQ DI, 0x58(SP)								
  tree.go:1414		0x6ddd8d		4c89942480000000	MOVQ R10, 0x80(SP)								
  tree.go:1414		0x6ddd95		48895c2478		MOVQ BX, 0x78(SP)								
  tree.go:1414		0x6ddd9a		488b13			MOVQ 0(BX), DX									
  tree.go:1414		0x6ddd9d		488b4b08		MOVQ 0x8(BX), CX								
  tree.go:1414		0x6ddda1		4c8b5b10		MOVQ 0x10(BX), R11								
  tree.go:1416		0x6ddda5		4889d3			MOVQ DX, BX									
  tree.go:1416		0x6ddda8		4c89d6			MOVQ R10, SI									
  tree.go:1416		0x6dddab		4989f8			MOVQ DI, R8									
  tree.go:1416		0x6dddae		4c89df			MOVQ R11, DI									
  tree.go:1416		0x6dddb1		e80ad5ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetAppend(SB)			
  tree.go:1416		0x6dddb6		660f1f840000000000	NOPW 0(AX)(AX*1)								
  tree.go:1416		0x6dddbf		90			NOPL										
  tree.go:1417		0x6dddc0		48393d29307302		CMPQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), DI			
  tree.go:1417		0x6dddc7		0f85c1000000		JNE 0x6dde8e									
  tree.go:1416		0x6dddcd		4889442468		MOVQ AX, 0x68(SP)								
  tree.go:1416		0x6dddd2		4889742470		MOVQ SI, 0x70(SP)								
  tree.go:1416		0x6dddd7		48897c2450		MOVQ DI, 0x50(SP)								
  tree.go:1416		0x6ddddc		48894c2440		MOVQ CX, 0x40(SP)								
  tree.go:1416		0x6ddde1		48895c2438		MOVQ BX, 0x38(SP)								
  tree.go:1417		0x6ddde6		488b0d0b307302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), CX		
  tree.go:1417		0x6ddded		4889f8			MOVQ DI, AX									
  tree.go:1417		0x6dddf0		4889f3			MOVQ SI, BX									
  tree.go:1417		0x6dddf3		e8c89cd3ff		CALL runtime.ifaceeq(SB)							
  tree.go:1417		0x6dddf8		84c0			TESTL AL, AL									
  tree.go:1417		0x6dddfa		7479			JE 0x6dde75									
  tree.go:1418		0x6dddfc		488b9424d8000000	MOVQ 0xd8(SP), DX								
  tree.go:1418		0x6dde04		4c8b542448		MOVQ 0x48(SP), R10								
  tree.go:1418		0x6dde09		4c39d2			CMPQ DX, R10									
  tree.go:1418		0x6dde0c		0f86c2010000		JBE 0x6ddfd4									
  tree.go:1418		0x6dde12		4f8d1c52		LEAQ 0(R10)(R10*2), R11								
  tree.go:1418		0x6dde16		4c8ba424d0000000	MOVQ 0xd0(SP), R12								
  tree.go:1418		0x6dde1e		4bc744dc0800000000	MOVQ $0x0, 0x8(R12)(R11*8)							
  tree.go:1418		0x6dde27		4bc744dc1000000000	MOVQ $0x0, 0x10(R12)(R11*8)							
  tree.go:1418		0x6dde30		833de9f6840200		CMPL runtime.writeBarrier(SB), $0x0						
  tree.go:1418		0x6dde37		7412			JE 0x6dde4b									
  tree.go:1418		0x6dde39		4f8b2cdc		MOVQ 0(R12)(R11*8), R13								
  tree.go:1418		0x6dde3d		4c89d8			MOVQ R11, AX									
  tree.go:1418		0x6dde40		e8fb63dbff		CALL runtime.gcWriteBarrier1(SB)						
  tree.go:1418		0x6dde45		4d892b			MOVQ R13, 0(R11)								
  tree.go:1418		0x6dde48		4989c3			MOVQ AX, R11									
  tree.go:1418		0x6dde4b		4bc704dc00000000	MOVQ $0x0, 0(R12)(R11*8)							
  tree.go:1426		0x6dde53		4c89e2			MOVQ R12, DX									
  tree.go:1426		0x6dde56		488bb424d8000000	MOVQ 0xd8(SP), SI								
  tree.go:1414		0x6dde5e		488b4c2460		MOVQ 0x60(SP), CX								
  tree.go:1414		0x6dde63		488b5c2458		MOVQ 0x58(SP), BX								
  tree.go:1414		0x6dde68		488b842480000000	MOVQ 0x80(SP), AX								
  tree.go:1419		0x6dde70		e9c9feffff		JMP 0x6ddd3e									
  tree.go:1429		0x6dde75		488b442468		MOVQ 0x68(SP), AX								
  tree.go:1414		0x6dde7a		488b4c2440		MOVQ 0x40(SP), CX								
  tree.go:1425		0x6dde7f		488b5c2438		MOVQ 0x38(SP), BX								
  tree.go:1422		0x6dde84		488b742470		MOVQ 0x70(SP), SI								
  tree.go:1421		0x6dde89		488b7c2450		MOVQ 0x50(SP), DI								
  tree.go:1421		0x6dde8e		4885ff			TESTQ DI, DI									
  tree.go:1421		0x6dde91		0f85fd000000		JNE 0x6ddf94									
  tree.go:1425		0x6dde97		488b542458		MOVQ 0x58(SP), DX								
  tree.go:1425		0x6dde9c		0f1f4000		NOPL 0(AX)									
  tree.go:1425		0x6ddea0		4839d3			CMPQ BX, DX									
  tree.go:1425		0x6ddea3		756c			JNE 0x6ddf11									
  tree.go:1426		0x6ddea5		488b9424d8000000	MOVQ 0xd8(SP), DX								
  tree.go:1426		0x6ddead		4c8b542448		MOVQ 0x48(SP), R10								
  tree.go:1426		0x6ddeb2		4c39d2			CMPQ DX, R10									
  tree.go:1426		0x6ddeb5		0f8614010000		JBE 0x6ddfcf									
  tree.go:1426		0x6ddebb		4f8d1c52		LEAQ 0(R10)(R10*2), R11								
  tree.go:1426		0x6ddebf		4c8b25e28b7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+8(SB), R12	
  tree.go:1426		0x6ddec6		4c8b2de38b7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue+16(SB), R13	
  tree.go:1426		0x6ddecd		4c8b3dcc8b7302		MOVQ github.com/snissn/gomap/TreeDB/tree.treeGetManyEmptyValue(SB), R15		
  tree.go:1414		0x6dded4		4889d6			MOVQ DX, SI									
  tree.go:1426		0x6dded7		488b9424d0000000	MOVQ 0xd0(SP), DX								
  tree.go:1426		0x6ddedf		4e8964da08		MOVQ R12, 0x8(DX)(R11*8)							
  tree.go:1426		0x6ddee4		4e896cda10		MOVQ R13, 0x10(DX)(R11*8)							
  tree.go:1426		0x6ddee9		833d30f6840200		CMPL runtime.writeBarrier(SB), $0x0						
  tree.go:1426		0x6ddef0		7416			JE 0x6ddf08									
  tree.go:1426		0x6ddef2		4e8b24da		MOVQ 0(DX)(R11*8), R12								
  tree.go:1426		0x6ddef6		4c89df			MOVQ R11, DI									
  tree.go:1426		0x6ddef9		e86263dbff		CALL runtime.gcWriteBarrier2(SB)						
  tree.go:1426		0x6ddefe		4d893b			MOVQ R15, 0(R11)								
  tree.go:1426		0x6ddf01		4d896308		MOVQ R12, 0x8(R11)								
  tree.go:1426		0x6ddf05		4989fb			MOVQ DI, R11									
  tree.go:1426		0x6ddf08		4e893cda		MOVQ R15, 0(DX)(R11*8)								
  tree.go:1427		0x6ddf0c		e92dfeffff		JMP 0x6ddd3e									
  tree.go:1429		0x6ddf11		0f82b3000000		JB 0x6ddfca									
  tree.go:1429		0x6ddf17		4989da			MOVQ BX, R10									
  tree.go:1429		0x6ddf1a		4829d3			SUBQ DX, BX									
  tree.go:1429		0x6ddf1d		4989db			MOVQ BX, R11									
  tree.go:1429		0x6ddf20		48f7db			NEGQ BX										
  tree.go:1429		0x6ddf23		48c1fb3f		SARQ $0x3f, BX									
  tree.go:1429		0x6ddf27		4821da			ANDQ BX, DX									
  tree.go:1429		0x6ddf2a		4801c2			ADDQ AX, DX									
  tree.go:1429		0x6ddf2d		4c8ba424d8000000	MOVQ 0xd8(SP), R12								
  tree.go:1429		0x6ddf35		4c8b6c2448		MOVQ 0x48(SP), R13								
  tree.go:1429		0x6ddf3a		660f1f440000		NOPW 0(AX)(AX*1)								
  tree.go:1429		0x6ddf40		4d39ec			CMPQ R12, R13									
  tree.go:1429		0x6ddf43		0f867c000000		JBE 0x6ddfc5									
  tree.go:1429		0x6ddf49		4f8d7c6d00		LEAQ 0(R13)(R13*2), R15								
  tree.go:1414		0x6ddf4e		4c89e3			MOVQ R12, BX									
  tree.go:1429		0x6ddf51		4c8ba424d0000000	MOVQ 0xd0(SP), R12								
  tree.go:1429		0x6ddf59		4f895cfc08		MOVQ R11, 0x8(R12)(R15*8)							
  tree.go:1429		0x6ddf5e		4f895cfc10		MOVQ R11, 0x10(R12)(R15*8)							
  tree.go:1429		0x6ddf63		833db6f5840200		CMPL runtime.writeBarrier(SB), $0x0						
  tree.go:1429		0x6ddf6a		7413			JE 0x6ddf7f									
  tree.go:1429		0x6ddf6c		4f8b1cfc		MOVQ 0(R12)(R15*8), R11								
  tree.go:1429		0x6ddf70		4c89de			MOVQ R11, SI									
  tree.go:1429		0x6ddf73		e8e862dbff		CALL runtime.gcWriteBarrier2(SB)						
  tree.go:1429		0x6ddf78		498913			MOVQ DX, 0(R11)									
  tree.go:1429		0x6ddf7b		49897308		MOVQ SI, 0x8(R11)								
  tree.go:1429		0x6ddf7f		4b8914fc		MOVQ DX, 0(R12)(R15*8)								
  tree.go:1426		0x6ddf83		4c89e2			MOVQ R12, DX									
  tree.go:1426		0x6ddf86		4889de			MOVQ BX, SI									
  tree.go:1414		0x6ddf89		4c89d3			MOVQ R10, BX									
  tree.go:1414		0x6ddf8c		4d89ea			MOVQ R13, R10									
  tree.go:1429		0x6ddf8f		e9aafdffff		JMP 0x6ddd3e									
  tree.go:1422		0x6ddf94		488b842480000000	MOVQ 0x80(SP), AX								
  tree.go:1422		0x6ddf9c		488b5c2458		MOVQ 0x58(SP), BX								
  tree.go:1422		0x6ddfa1		488b4c2460		MOVQ 0x60(SP), CX								
  tree.go:1422		0x6ddfa6		4881c488000000		ADDQ $0x88, SP									
  tree.go:1422		0x6ddfad		5d			POPQ BP										
  tree.go:1422		0x6ddfae		c3			RET										
  tree.go:1431		0x6ddfaf		4c89d0			MOVQ R10, AX									
  tree.go:1431		0x6ddfb2		4889fb			MOVQ DI, BX									
  tree.go:1431		0x6ddfb5		4c89c9			MOVQ R9, CX									
  tree.go:1431		0x6ddfb8		31ff			XORL DI, DI									
  tree.go:1431		0x6ddfba		31f6			XORL SI, SI									
  tree.go:1431		0x6ddfbc		4881c488000000		ADDQ $0x88, SP									
  tree.go:1431		0x6ddfc3		5d			POPQ BP										
  tree.go:1431		0x6ddfc4		c3			RET										
  tree.go:1429		0x6ddfc5		e83666dbff		CALL runtime.panicBounds(SB)							
  tree.go:1429		0x6ddfca		e83166dbff		CALL runtime.panicBounds(SB)							
  tree.go:1426		0x6ddfcf		e82c66dbff		CALL runtime.panicBounds(SB)							
  tree.go:1418		0x6ddfd4		e82766dbff		CALL runtime.panicBounds(SB)							
  tree.go:1418		0x6ddfd9		90			NOPL										
  tree.go:1413		0x6ddfda		4889442420		MOVQ AX, 0x20(SP)								
  tree.go:1413		0x6ddfdf		48895c2428		MOVQ BX, 0x28(SP)								
  tree.go:1413		0x6ddfe4		48894c2430		MOVQ CX, 0x30(SP)								
  tree.go:1413		0x6ddfe9		48897c2438		MOVQ DI, 0x38(SP)								
  tree.go:1413		0x6ddfee		4889742440		MOVQ SI, 0x40(SP)								
  tree.go:1413		0x6ddff3		4c89442448		MOVQ R8, 0x48(SP)								
  tree.go:1413		0x6ddff8		4c894c2450		MOVQ R9, 0x50(SP)								
  tree.go:1413		0x6ddffd		0f1f00			NOPL 0(AX)									
  tree.go:1413		0x6de000		e85b47dbff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1413		0x6de005		488b442420		MOVQ 0x20(SP), AX								
  tree.go:1413		0x6de00a		488b5c2428		MOVQ 0x28(SP), BX								
  tree.go:1413		0x6de00f		488b4c2430		MOVQ 0x30(SP), CX								
  tree.go:1413		0x6de014		488b7c2438		MOVQ 0x38(SP), DI								
  tree.go:1413		0x6de019		488b742440		MOVQ 0x40(SP), SI								
  tree.go:1413		0x6de01e		4c8b442448		MOVQ 0x48(SP), R8								
  tree.go:1413		0x6de023		4c8b4c2450		MOVQ 0x50(SP), R9								
  tree.go:1413		0x6de028		e9b3fcffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).getManyAppendFallback(SB)	

TEXT github.com/snissn/gomap/TreeDB/tree.(*Tree).findLeafRefForGetMany(SB) github.com/snissn/gomap/TreeDB/tree/tree.go
  tree.go:1434			0x6de040		4c8da42430fcffff	LEAQ 0xfffffc30(SP), R12							
  tree.go:1434			0x6de048		4d3b6610		CMPQ R12, 0x10(R14)								
  tree.go:1434			0x6de04c		0f86ad0a0000		JBE 0x6deaff									
  tree.go:1434			0x6de052		55			PUSHQ BP									
  tree.go:1434			0x6de053		4889e5			MOVQ SP, BP									
  tree.go:1434			0x6de056		4881ec48040000		SUBQ $0x448, SP									
  tree.go:1434			0x6de05d		48899c2460040000	MOVQ BX, 0x460(SP)								
  tree.go:1434			0x6de065		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1434			0x6de06d		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1434			0x6de071		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1434			0x6de076		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1434			0x6de07b		0f1f440000		NOPL 0(AX)(AX*1)								
  tree.go:1435			0x6de080		4885c0			TESTQ AX, AX									
  tree.go:1435			0x6de083		0f84a6000000		JE 0x6de12f									
  tree.go:1435			0x6de089		4889842458040000	MOVQ AX, 0x458(SP)								
  tree.go:1435			0x6de091		4088b42478040000	MOVB SI, 0x478(SP)								
  tree.go:1435			0x6de099		4889bc2470040000	MOVQ DI, 0x470(SP)								
  tree.go:1435			0x6de0a1		48898c2468040000	MOVQ CX, 0x468(SP)								
  tree.go:1435			0x6de0a9		48899c2460040000	MOVQ BX, 0x460(SP)								
  tree.go:1438			0x6de0b1		e8ea26ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).pointDefinitelyAbsent(SB)	
  tree.go:1438			0x6de0b6		84c0			TESTL AL, AL									
  tree.go:1438			0x6de0b8		7537			JNE 0x6de0f1									
  tree.go:1441			0x6de0ba		488b842458040000	MOVQ 0x458(SP), AX								
  tree.go:1441			0x6de0c2		488b90d0000000		MOVQ 0xd0(AX), DX								
  tree.go:1441			0x6de0c9		4c8da42418010000	LEAQ 0x118(SP), R12								
  tree.go:1441			0x6de0d1		450f113c24		MOVUPS X15, 0(R12)								
  tree.go:1441			0x6de0d6		450f117c2410		MOVUPS X15, 0x10(R12)								
  tree.go:1441			0x6de0dc		450f117c2418		MOVUPS X15, 0x18(R12)								
  tree.go:1441			0x6de0e2		4889942420010000	MOVQ DX, 0x120(SP)								
  tree.go:1441			0x6de0ea		31c9			XORL CX, CX									
  tree.go:1442			0x6de0ec		e9b1000000		JMP 0x6de1a2									
  tree.go:1439			0x6de0f1		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1439			0x6de0f9		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1439			0x6de0fd		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1439			0x6de102		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1439			0x6de107		4c8b15e22c7302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), R10		
  tree.go:1439			0x6de10e		4c8b1de32c7302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R11		
  tree.go:1439			0x6de115		31c0			XORL AX, AX									
  tree.go:1439			0x6de117		31db			XORL BX, BX									
  tree.go:1439			0x6de119		31c9			XORL CX, CX									
  tree.go:1439			0x6de11b		4889df			MOVQ BX, DI									
  tree.go:1439			0x6de11e		89ce			MOVL CX, SI									
  tree.go:1439			0x6de120		4531c0			XORL R8, R8									
  tree.go:1439			0x6de123		4531c9			XORL R9, R9									
  tree.go:1439			0x6de126		4881c448040000		ADDQ $0x448, SP									
  tree.go:1439			0x6de12d		5d			POPQ BP										
  tree.go:1439			0x6de12e		c3			RET										
  errors.go:65			0x6de12f		488d05aa765001		LEAQ 0x15076aa(IP), AX								
  errors.go:65			0x6de136		e86569d4ff		CALL runtime.newobject(SB)							
  errors.go:65			0x6de13b		48c740080c000000	MOVQ $0xc, 0x8(AX)								
  errors.go:65			0x6de143		488d0d18da6801		LEAQ 0x168da18(IP), CX								
  errors.go:65			0x6de14a		488908			MOVQ CX, 0(AX)									
  tree.go:1436			0x6de14d		488d8c24d0000000	LEAQ 0xd0(SP), CX								
  tree.go:1436			0x6de155		440f1139		MOVUPS X15, 0(CX)								
  tree.go:1436			0x6de159		440f117910		MOVUPS X15, 0x10(CX)								
  tree.go:1436			0x6de15e		440f117918		MOVUPS X15, 0x18(CX)								
  tree.go:1436			0x6de163		31db			XORL BX, BX									
  tree.go:1436			0x6de165		31c9			XORL CX, CX									
  tree.go:1436			0x6de167		4889df			MOVQ BX, DI									
  tree.go:1436			0x6de16a		89ce			MOVL CX, SI									
  tree.go:1436			0x6de16c		4531c0			XORL R8, R8									
  tree.go:1436			0x6de16f		4531c9			XORL R9, R9									
  tree.go:1436			0x6de172		4c8d1547fc7d01		LEAQ go:itab.*errors.errorString,error(SB), R10					
  tree.go:1436			0x6de179		4989c3			MOVQ AX, R11									
  tree.go:1436			0x6de17c		31c0			XORL AX, AX									
  tree.go:1436			0x6de17e		4881c448040000		ADDQ $0x448, SP									
  tree.go:1436			0x6de185		5d			POPQ BP										
  tree.go:1436			0x6de186		c3			RET										
  tree.go:1442			0x6de187		488b8c2410010000	MOVQ 0x110(SP), CX								
  tree.go:1442			0x6de18f		48ffc1			INCQ CX										
  tree.go:1447			0x6de192		488b842458040000	MOVQ 0x458(SP), AX								
  tree.go:1441			0x6de19a		4c8da42418010000	LEAQ 0x118(SP), R12								
  tree.go:1442			0x6de1a2		4883f932		CMPQ CX, $0x32									
  tree.go:1442			0x6de1a6		0f8df0080000		JGE 0x6dea9c									
  tree.go:1443			0x6de1ac		80bc241801000001	CMPB 0x118(SP), $0x1								
  tree.go:1443			0x6de1b4		0f8477080000		JE 0x6dea31									
  tree.go:1442			0x6de1ba		48898c2410010000	MOVQ CX, 0x110(SP)								
  tree.go:1446			0x6de1c2		488d9c2490010000	LEAQ 0x190(SP), BX								
  tree.go:1446			0x6de1ca		ba05000000		MOVL $0x5, DX									
  tree.go:1446			0x6de1cf		440f113b		MOVUPS X15, 0(BX)								
  tree.go:1446			0x6de1d3		440f117b10		MOVUPS X15, 0x10(BX)								
  tree.go:1446			0x6de1d8		440f117b20		MOVUPS X15, 0x20(BX)								
  tree.go:1446			0x6de1dd		440f117b30		MOVUPS X15, 0x30(BX)								
  tree.go:1446			0x6de1e2		4883c340		ADDQ $0x40, BX									
  tree.go:1446			0x6de1e6		ffca			DECL DX										
  tree.go:1446			0x6de1e8		75e5			JNE 0x6de1cf									
  tree.go:1446			0x6de1ea		440f117bf8		MOVUPS X15, -0x8(BX)								
  tree.go:1447			0x6de1ef		0fb68c2418010000	MOVZX 0x118(SP), CX								
  tree.go:1447			0x6de1f7		488bbc2420010000	MOVQ 0x120(SP), DI								
  tree.go:1447			0x6de1ff		8bb42428010000		MOVL 0x128(SP), SI								
  tree.go:1447			0x6de206		4c8b842430010000	MOVQ 0x130(SP), R8								
  tree.go:1447			0x6de20e		448b8c2438010000	MOVL 0x138(SP), R9								
  tree.go:1447			0x6de216		440fb794243c010000	MOVZX 0x13c(SP), R10								
  tree.go:1447			0x6de21f		c6042400		MOVB $0x0, 0(SP)								
  tree.go:1447			0x6de223		488d9c2490010000	LEAQ 0x190(SP), BX								
  tree.go:1447			0x6de22b		440fb69c2478040000	MOVZX 0x478(SP), R11								
  tree.go:1447			0x6de234		e80794ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).loadChildRefViewInto(SB)	
  tree.go:1447			0x6de239		0f1f8000000000		NOPL 0(AX)									
  tree.go:1447			0x6de240		4885c0			TESTQ AX, AX									
  tree.go:1447			0x6de243		0f85b2070000		JNE 0x6de9fb									
  node.go:224			0x6de249		0fb78424aa010000	MOVZX 0x1aa(SP), AX								
  tree.go:1450			0x6de251		90			NOPL										
  tree.go:1465			0x6de252		6683f803		CMPW AX, $0x3									
  tree.go:1465			0x6de256		0f8516020000		JNE 0x6de472									
  tree.go:1466			0x6de25c		488b942410010000	MOVQ 0x110(SP), DX								
  tree.go:1466			0x6de264		4885d2			TESTQ DX, DX									
  tree.go:1466			0x6de267		0f85c4000000		JNE 0x6de331									
  tree.go:1467			0x6de26d		488d842490010000	LEAQ 0x190(SP), AX								
  tree.go:1467			0x6de275		e866c8f0ff		CALL github.com/snissn/gomap/TreeDB/node.(*Node).InternalFenceBounds(SB)	
  tree.go:1467			0x6de27a		660f1f440000		NOPW 0(AX)(AX*1)								
  tree.go:1467			0x6de280		4d85d2			TESTQ R10, R10									
  tree.go:1467			0x6de283		0f8576050000		JNE 0x6de7ff									
  tree.go:1467			0x6de289		4584c9			TESTL R9, R9									
  tree.go:1469			0x6de28c		0f8497000000		JE 0x6de329									
  tree.go:1470			0x6de292		4885db			TESTQ BX, BX									
  tree.go:1470			0x6de295		745f			JE 0x6de2f6									
  tree.go:1467			0x6de297		4889bc24d8020000	MOVQ DI, 0x2d8(SP)								
  tree.go:1467			0x6de29f		4c89842400010000	MOVQ R8, 0x100(SP)								
  tree.go:1467			0x6de2a7		4889b424f8000000	MOVQ SI, 0xf8(SP)								
  tree.go:1470			0x6de2af		4889c7			MOVQ AX, DI									
  tree.go:1470			0x6de2b2		4889de			MOVQ BX, SI									
  tree.go:1470			0x6de2b5		4989c8			MOVQ CX, R8									
  tree.go:1470			0x6de2b8		488b842460040000	MOVQ 0x460(SP), AX								
  tree.go:1470			0x6de2c0		488b9c2468040000	MOVQ 0x468(SP), BX								
  tree.go:1470			0x6de2c8		488b8c2470040000	MOVQ 0x470(SP), CX								
  tree.go:1470			0x6de2d0		e82b72ffff		CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)			
  tree.go:1470			0x6de2d5		4885c0			TESTQ AX, AX									
  tree.go:1470			0x6de2d8		0f8c7d040000		JL 0x6de75b									
  tree.go:1473			0x6de2de		488bb424f8000000	MOVQ 0xf8(SP), SI								
  tree.go:1473			0x6de2e6		488bbc24d8020000	MOVQ 0x2d8(SP), DI								
  tree.go:1473			0x6de2ee		4c8b842400010000	MOVQ 0x100(SP), R8								
  tree.go:1473			0x6de2f6		4885f6			TESTQ SI, SI									
  tree.go:1473			0x6de2f9		742e			JE 0x6de329									
  tree.go:1473			0x6de2fb		488b842460040000	MOVQ 0x460(SP), AX								
  tree.go:1473			0x6de303		488b9c2468040000	MOVQ 0x468(SP), BX								
  tree.go:1473			0x6de30b		488b8c2470040000	MOVQ 0x470(SP), CX								
  tree.go:1473			0x6de313		e8e871ffff		CALL github.com/snissn/gomap/TreeDB/tree.compareTreeKey(SB)			
  tree.go:1473			0x6de318		0f1f840000000000	NOPL 0(AX)(AX*1)								
  tree.go:1473			0x6de320		4885c0			TESTQ AX, AX									
  tree.go:1473			0x6de323		0f8df4030000		JGE 0x6de71d									
  tree.go:1442			0x6de329		488b942410010000	MOVQ 0x110(SP), DX								
  node.go:309			0x6de331		90			NOPL										
  node.go:302			0x6de332		6683bc24aa01000003	CMPW 0x1aa(SP), $0x3								
  node.go:302			0x6de33b		752f			JNE 0x6de36c									
  node.go:236			0x6de33d		488bb42498010000	MOVQ 0x198(SP), SI								
  node.go:56			0x6de345		4883fe0c		CMPQ SI, $0xc									
  node.go:56			0x6de349		0f86aa070000		JBE 0x6deaf9									
  node.go:56			0x6de34f		4883fe0d		CMPQ SI, $0xd									
  node.go:56			0x6de353		0f869b070000		JBE 0x6deaf4									
  node.go:236			0x6de359		488bb42490010000	MOVQ 0x190(SP), SI								
  node.go:56			0x6de361		0fb7760c		MOVZX 0xc(SI), SI								
  node.go:305			0x6de365		66f7c68000		TESTW $0x80, SI									
  tree.go:1478			0x6de36a		7551			JNE 0x6de3bd									
  tree.go:1485			0x6de36c		488d842490010000	LEAQ 0x190(SP), AX								
  tree.go:1485			0x6de374		488b9c2460040000	MOVQ 0x460(SP), BX								
  tree.go:1485			0x6de37c		488b8c2468040000	MOVQ 0x468(SP), CX								
  tree.go:1485			0x6de384		488bbc2470040000	MOVQ 0x470(SP), DI								
  tree.go:1485			0x6de38c		e84fd3f0ff		CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildID(SB)	
  tree.go:1486			0x6de391		4885c9			TESTQ CX, CX									
  tree.go:1486			0x6de394		0f85ff030000		JNE 0x6de799									
  tree.go:1489			0x6de39a		488d942418010000	LEAQ 0x118(SP), DX								
  tree.go:1489			0x6de3a2		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1489			0x6de3a6		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1489			0x6de3ab		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1489			0x6de3b0		4889842420010000	MOVQ AX, 0x120(SP)								
  tree.go:1489			0x6de3b8		e9cafdffff		JMP 0x6de187									
  tree.go:1479			0x6de3bd		488d842490010000	LEAQ 0x190(SP), AX								
  tree.go:1479			0x6de3c5		488b9c2460040000	MOVQ 0x460(SP), BX								
  tree.go:1479			0x6de3cd		488b8c2468040000	MOVQ 0x468(SP), CX								
  tree.go:1479			0x6de3d5		488bbc2470040000	MOVQ 0x470(SP), DI								
  tree.go:1479			0x6de3dd		0f1f00			NOPL 0(AX)									
  tree.go:1479			0x6de3e0		e81b01f1ff		CALL github.com/snissn/gomap/TreeDB/node.(*Node).SearchInternalChildRef(SB)	
  tree.go:1479			0x6de3e5		88842440010000		MOVB AL, 0x140(SP)								
  tree.go:1479			0x6de3ec		48899c2448010000	MOVQ BX, 0x148(SP)								
  tree.go:1479			0x6de3f4		898c2450010000		MOVL CX, 0x150(SP)								
  tree.go:1479			0x6de3fb		4889bc2458010000	MOVQ DI, 0x158(SP)								
  tree.go:1479			0x6de403		89b42460010000		MOVL SI, 0x160(SP)								
  tree.go:1479			0x6de40a		664489842464010000	MOVW R8, 0x164(SP)								
  tree.go:1479			0x6de413		488d9424d8030000	LEAQ 0x3d8(SP), DX								
  tree.go:1479			0x6de41b		488db42440010000	LEAQ 0x140(SP), SI								
  tree.go:1479			0x6de423		440f1036		MOVUPS 0(SI), X14								
  tree.go:1479			0x6de427		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1479			0x6de42b		440f107610		MOVUPS 0x10(SI), X14								
  tree.go:1479			0x6de430		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1479			0x6de435		440f107618		MOVUPS 0x18(SI), X14								
  tree.go:1479			0x6de43a		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1479			0x6de43f		90			NOPL										
  tree.go:1480			0x6de440		4d85d2			TESTQ R10, R10									
  tree.go:1480			0x6de443		0f8586030000		JNE 0x6de7cf									
  tree.go:1483			0x6de449		488d942418010000	LEAQ 0x118(SP), DX								
  tree.go:1483			0x6de451		440f1036		MOVUPS 0(SI), X14								
  tree.go:1483			0x6de455		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1483			0x6de459		440f107610		MOVUPS 0x10(SI), X14								
  tree.go:1483			0x6de45e		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1483			0x6de463		440f107618		MOVUPS 0x18(SI), X14								
  tree.go:1483			0x6de468		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1483			0x6de46d		e915fdffff		JMP 0x6de187									
  tree.go:1491			0x6de472		6683f804		CMPW AX, $0x4									
  tree.go:1491			0x6de476		0f840f050000		JE 0x6de98b									
  tree.go:1491			0x6de47c		0f1f4000		NOPL 0(AX)									
  tree.go:1451			0x6de480		6683f80b		CMPW AX, $0xb									
  tree.go:1451			0x6de484		0f8557040000		JNE 0x6de8e1									
  tree.go:1452			0x6de48a		488b942410010000	MOVQ 0x110(SP), DX								
  tree.go:1452			0x6de492		4885d2			TESTQ DX, DX									
  tree.go:1452			0x6de495		0f8508040000		JNE 0x6de8a3									
  node.go:209			0x6de49b		488b8c2498010000	MOVQ 0x198(SP), CX								
  node.go:209			0x6de4a3		488bbc24a0010000	MOVQ 0x1a0(SP), DI								
  node.go:209			0x6de4ab		488b9c2490010000	MOVQ 0x190(SP), BX								
  tree.go:1457			0x6de4b3		488d942468030000	LEAQ 0x368(SP), DX								
  tree.go:1457			0x6de4bb		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1457			0x6de4bf		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1457			0x6de4c4		440f117a20		MOVUPS X15, 0x20(DX)								
  tree.go:1457			0x6de4c9		440f117a30		MOVUPS X15, 0x30(DX)								
  tree.go:1457			0x6de4ce		440f117a40		MOVUPS X15, 0x40(DX)								
  tree.go:1457			0x6de4d3		440f117a50		MOVUPS X15, 0x50(DX)								
  tree.go:1457			0x6de4d8		440f117a60		MOVUPS X15, 0x60(DX)								
  tree.go:1457			0x6de4dd		440f113c24		MOVUPS X15, 0(SP)								
  tree.go:1457			0x6de4e2		48c744241000000000	MOVQ $0x0, 0x10(SP)								
  tree.go:1457			0x6de4eb		488b842458040000	MOVQ 0x458(SP), AX								
  tree.go:1457			0x6de4f3		488bb42460040000	MOVQ 0x460(SP), SI								
  tree.go:1457			0x6de4fb		4c8b842468040000	MOVQ 0x468(SP), R8								
  tree.go:1457			0x6de503		4c8b8c2470040000	MOVQ 0x470(SP), R9								
  tree.go:1457			0x6de50b		4531d2			XORL R10, R10									
  tree.go:1457			0x6de50e		4531db			XORL R11, R11									
  tree.go:1457			0x6de511		e8ca40ffff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).selectPrimaryOperand(SB)	
  tree.go:1457			0x6de516		88842468030000		MOVB AL, 0x368(SP)								
  tree.go:1457			0x6de51d		48899c2470030000	MOVQ BX, 0x370(SP)								
  tree.go:1457			0x6de525		898c2478030000		MOVL CX, 0x378(SP)								
  tree.go:1457			0x6de52c		4889bc2480030000	MOVQ DI, 0x380(SP)								
  tree.go:1457			0x6de534		89b42488030000		MOVL SI, 0x388(SP)								
  tree.go:1457			0x6de53b		66448984248c030000	MOVW R8, 0x38c(SP)								
  tree.go:1457			0x6de544		488d9424d8030000	LEAQ 0x3d8(SP), DX								
  tree.go:1457			0x6de54c		4c8da42468030000	LEAQ 0x368(SP), R12								
  tree.go:1457			0x6de554		450f103424		MOVUPS 0(R12), X14								
  tree.go:1457			0x6de559		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1457			0x6de55d		450f10742410		MOVUPS 0x10(R12), X14								
  tree.go:1457			0x6de563		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1457			0x6de568		450f10742418		MOVUPS 0x18(R12), X14								
  tree.go:1457			0x6de56e		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1457			0x6de573		4c8da42468030000	LEAQ 0x368(SP), R12								
  tree.go:1457			0x6de57b		4c8d6c2418		LEAQ 0x18(SP), R13								
  tree.go:1457			0x6de580		450f107500		MOVUPS 0(R13), X14								
  tree.go:1457			0x6de585		450f113424		MOVUPS X14, 0(R12)								
  tree.go:1457			0x6de58a		450f107510		MOVUPS 0x10(R13), X14								
  tree.go:1457			0x6de58f		450f11742410		MOVUPS X14, 0x10(R12)								
  tree.go:1457			0x6de595		450f107520		MOVUPS 0x20(R13), X14								
  tree.go:1457			0x6de59a		450f11742420		MOVUPS X14, 0x20(R12)								
  tree.go:1457			0x6de5a0		450f107530		MOVUPS 0x30(R13), X14								
  tree.go:1457			0x6de5a5		450f11742430		MOVUPS X14, 0x30(R12)								
  tree.go:1457			0x6de5ab		450f107540		MOVUPS 0x40(R13), X14								
  tree.go:1457			0x6de5b0		450f11742440		MOVUPS X14, 0x40(R12)								
  tree.go:1457			0x6de5b6		450f107550		MOVUPS 0x50(R13), X14								
  tree.go:1457			0x6de5bb		450f11742450		MOVUPS X14, 0x50(R12)								
  tree.go:1457			0x6de5c1		450f107560		MOVUPS 0x60(R13), X14								
  tree.go:1457			0x6de5c6		450f11742460		MOVUPS X14, 0x60(R12)								
  tree.go:1457			0x6de5cc		4c8dac2468010000	LEAQ 0x168(SP), R13								
  tree.go:1457			0x6de5d4		440f1032		MOVUPS 0(DX), X14								
  tree.go:1457			0x6de5d8		450f117500		MOVUPS X14, 0(R13)								
  tree.go:1457			0x6de5dd		440f107210		MOVUPS 0x10(DX), X14								
  tree.go:1457			0x6de5e2		450f117510		MOVUPS X14, 0x10(R13)								
  tree.go:1457			0x6de5e7		440f107218		MOVUPS 0x18(DX), X14								
  tree.go:1457			0x6de5ec		450f117518		MOVUPS X14, 0x18(R13)								
  tree.go:1457			0x6de5f1		488d9424d8030000	LEAQ 0x3d8(SP), DX								
  tree.go:1457			0x6de5f9		450f103424		MOVUPS 0(R12), X14								
  tree.go:1457			0x6de5fe		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1457			0x6de602		450f10742410		MOVUPS 0x10(R12), X14								
  tree.go:1457			0x6de608		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1457			0x6de60d		450f10742420		MOVUPS 0x20(R12), X14								
  tree.go:1457			0x6de613		440f117220		MOVUPS X14, 0x20(DX)								
  tree.go:1457			0x6de618		450f10742430		MOVUPS 0x30(R12), X14								
  tree.go:1457			0x6de61e		440f117230		MOVUPS X14, 0x30(DX)								
  tree.go:1457			0x6de623		450f10742440		MOVUPS 0x40(R12), X14								
  tree.go:1457			0x6de629		440f117240		MOVUPS X14, 0x40(DX)								
  tree.go:1457			0x6de62e		450f10742450		MOVUPS 0x50(R12), X14								
  tree.go:1457			0x6de634		440f117250		MOVUPS X14, 0x50(DX)								
  tree.go:1457			0x6de639		450f10742460		MOVUPS 0x60(R12), X14								
  tree.go:1457			0x6de63f		440f117260		MOVUPS X14, 0x60(DX)								
  tree.go:1457			0x6de644		4c8da42418010000	LEAQ 0x118(SP), R12								
  tree.go:1457			0x6de64c		450f107500		MOVUPS 0(R13), X14								
  tree.go:1457			0x6de651		450f113424		MOVUPS X14, 0(R12)								
  tree.go:1457			0x6de656		450f107510		MOVUPS 0x10(R13), X14								
  tree.go:1457			0x6de65b		450f11742410		MOVUPS X14, 0x10(R12)								
  tree.go:1457			0x6de661		450f107518		MOVUPS 0x18(R13), X14								
  tree.go:1457			0x6de666		450f11742418		MOVUPS X14, 0x18(R12)								
  tree.go:1458			0x6de66c		4c8dac24e8020000	LEAQ 0x2e8(SP), R13								
  tree.go:1458			0x6de674		440f1032		MOVUPS 0(DX), X14								
  tree.go:1458			0x6de678		450f117500		MOVUPS X14, 0(R13)								
  tree.go:1458			0x6de67d		440f107210		MOVUPS 0x10(DX), X14								
  tree.go:1458			0x6de682		450f117510		MOVUPS X14, 0x10(R13)								
  tree.go:1458			0x6de687		440f107220		MOVUPS 0x20(DX), X14								
  tree.go:1458			0x6de68c		450f117520		MOVUPS X14, 0x20(R13)								
  tree.go:1458			0x6de691		440f107230		MOVUPS 0x30(DX), X14								
  tree.go:1458			0x6de696		450f117530		MOVUPS X14, 0x30(R13)								
  tree.go:1458			0x6de69b		440f107240		MOVUPS 0x40(DX), X14								
  tree.go:1458			0x6de6a0		450f117540		MOVUPS X14, 0x40(R13)								
  tree.go:1458			0x6de6a5		440f107250		MOVUPS 0x50(DX), X14								
  tree.go:1458			0x6de6aa		450f117550		MOVUPS X14, 0x50(R13)								
  tree.go:1458			0x6de6af		440f107260		MOVUPS 0x60(DX), X14								
  tree.go:1458			0x6de6b4		450f117560		MOVUPS X14, 0x60(R13)								
  primary_directory_v1.go:43	0x6de6b9		80bc245003000002	CMPB 0x350(SP), $0x2								
  primary_directory_v1.go:43	0x6de6c1		7544			JNE 0x6de707									
  tree.go:1457			0x6de6c3		4c899424e0020000	MOVQ R10, 0x2e0(SP)								
  tree.go:1457			0x6de6cb		4c898c2408010000	MOVQ R9, 0x108(SP)								
  primary_directory_v1.go:43	0x6de6d3		488d842400030000	LEAQ 0x300(SP), AX								
  primary_directory_v1.go:43	0x6de6db		488d1d3e1a8502		LEAQ runtime.zeroVal(SB), BX							
  primary_directory_v1.go:43	0x6de6e2		e839c6f1ff		CALL type:.eq.github.com/snissn/gomap/TreeDB/node.PrimaryOperand(SB)		
  primary_directory_v1.go:43	0x6de6e7		84c0			TESTL AL, AL									
  tree.go:1458			0x6de6e9		0f8576010000		JNE 0x6de865									
  tree.go:1461			0x6de6ef		4c8b8c2408010000	MOVQ 0x108(SP), R9								
  tree.go:1462			0x6de6f7		4c8b9424e0020000	MOVQ 0x2e0(SP), R10								
  tree.go:1441			0x6de6ff		4c8da42418010000	LEAQ 0x118(SP), R12								
  tree.go:1461			0x6de707		4d85c9			TESTQ R9, R9									
  tree.go:1461			0x6de70a		0f851f010000		JNE 0x6de82f									
  tree.go:1441			0x6de710		488d942418010000	LEAQ 0x118(SP), DX								
  tree.go:1464			0x6de718		e96afaffff		JMP 0x6de187									
  tree.go:1474			0x6de71d		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1474			0x6de725		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1474			0x6de729		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1474			0x6de72e		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1474			0x6de733		4c8b15b6267302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), R10		
  tree.go:1474			0x6de73a		4c8b1db7267302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R11		
  tree.go:1474			0x6de741		31c0			XORL AX, AX									
  tree.go:1474			0x6de743		31db			XORL BX, BX									
  tree.go:1474			0x6de745		31c9			XORL CX, CX									
  tree.go:1474			0x6de747		4889df			MOVQ BX, DI									
  tree.go:1474			0x6de74a		89ce			MOVL CX, SI									
  tree.go:1474			0x6de74c		4531c0			XORL R8, R8									
  tree.go:1474			0x6de74f		4531c9			XORL R9, R9									
  tree.go:1474			0x6de752		4881c448040000		ADDQ $0x448, SP									
  tree.go:1474			0x6de759		5d			POPQ BP										
  tree.go:1474			0x6de75a		c3			RET										
  tree.go:1471			0x6de75b		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1471			0x6de763		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1471			0x6de767		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1471			0x6de76c		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1471			0x6de771		4c8b1578267302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), R10		
  tree.go:1471			0x6de778		4c8b1d79267302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R11		
  tree.go:1471			0x6de77f		31c0			XORL AX, AX									
  tree.go:1471			0x6de781		31db			XORL BX, BX									
  tree.go:1471			0x6de783		31c9			XORL CX, CX									
  tree.go:1471			0x6de785		4889df			MOVQ BX, DI									
  tree.go:1471			0x6de788		89ce			MOVL CX, SI									
  tree.go:1471			0x6de78a		4531c0			XORL R8, R8									
  tree.go:1471			0x6de78d		4531c9			XORL R9, R9									
  tree.go:1471			0x6de790		4881c448040000		ADDQ $0x448, SP									
  tree.go:1471			0x6de797		5d			POPQ BP										
  tree.go:1471			0x6de798		c3			RET										
  tree.go:1487			0x6de799		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1487			0x6de7a1		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1487			0x6de7a5		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1487			0x6de7aa		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1487			0x6de7af		31c0			XORL AX, AX									
  tree.go:1487			0x6de7b1		31db			XORL BX, BX									
  tree.go:1487			0x6de7b3		31f6			XORL SI, SI									
  tree.go:1487			0x6de7b5		4531c0			XORL R8, R8									
  tree.go:1487			0x6de7b8		4531c9			XORL R9, R9									
  tree.go:1487			0x6de7bb		4989ca			MOVQ CX, R10									
  tree.go:1487			0x6de7be		4989fb			MOVQ DI, R11									
  tree.go:1487			0x6de7c1		89f1			MOVL SI, CX									
  tree.go:1487			0x6de7c3		4889df			MOVQ BX, DI									
  tree.go:1487			0x6de7c6		4881c448040000		ADDQ $0x448, SP									
  tree.go:1487			0x6de7cd		5d			POPQ BP										
  tree.go:1487			0x6de7ce		c3			RET										
  tree.go:1481			0x6de7cf		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1481			0x6de7d7		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1481			0x6de7db		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1481			0x6de7e0		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1481			0x6de7e5		31c0			XORL AX, AX									
  tree.go:1481			0x6de7e7		31db			XORL BX, BX									
  tree.go:1481			0x6de7e9		31c9			XORL CX, CX									
  tree.go:1481			0x6de7eb		4889df			MOVQ BX, DI									
  tree.go:1481			0x6de7ee		89ce			MOVL CX, SI									
  tree.go:1481			0x6de7f0		4531c0			XORL R8, R8									
  tree.go:1481			0x6de7f3		4531c9			XORL R9, R9									
  tree.go:1481			0x6de7f6		4881c448040000		ADDQ $0x448, SP									
  tree.go:1481			0x6de7fd		5d			POPQ BP										
  tree.go:1481			0x6de7fe		c3			RET										
  tree.go:1468			0x6de7ff		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1468			0x6de807		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1468			0x6de80b		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1468			0x6de810		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1468			0x6de815		31c0			XORL AX, AX									
  tree.go:1468			0x6de817		31db			XORL BX, BX									
  tree.go:1468			0x6de819		31c9			XORL CX, CX									
  tree.go:1468			0x6de81b		4889df			MOVQ BX, DI									
  tree.go:1468			0x6de81e		89ce			MOVL CX, SI									
  tree.go:1468			0x6de820		4531c0			XORL R8, R8									
  tree.go:1468			0x6de823		4531c9			XORL R9, R9									
  tree.go:1468			0x6de826		4881c448040000		ADDQ $0x448, SP									
  tree.go:1468			0x6de82d		5d			POPQ BP										
  tree.go:1468			0x6de82e		c3			RET										
  tree.go:1462			0x6de82f		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1462			0x6de837		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1462			0x6de83b		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1462			0x6de840		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1462			0x6de845		31c0			XORL AX, AX									
  tree.go:1462			0x6de847		31db			XORL BX, BX									
  tree.go:1462			0x6de849		31c9			XORL CX, CX									
  tree.go:1462			0x6de84b		4889df			MOVQ BX, DI									
  tree.go:1462			0x6de84e		89ce			MOVL CX, SI									
  tree.go:1462			0x6de850		4531c0			XORL R8, R8									
  tree.go:1462			0x6de853		4d89d3			MOVQ R10, R11									
  tree.go:1462			0x6de856		4d89ca			MOVQ R9, R10									
  tree.go:1462			0x6de859		4531c9			XORL R9, R9									
  tree.go:1462			0x6de85c		4881c448040000		ADDQ $0x448, SP									
  tree.go:1462			0x6de863		5d			POPQ BP										
  tree.go:1462			0x6de864		c3			RET										
  tree.go:1459			0x6de865		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1459			0x6de86d		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1459			0x6de871		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1459			0x6de876		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1459			0x6de87b		4c8b156e257302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), R10		
  tree.go:1459			0x6de882		4c8b1d6f257302		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R11		
  tree.go:1459			0x6de889		31c0			XORL AX, AX									
  tree.go:1459			0x6de88b		31db			XORL BX, BX									
  tree.go:1459			0x6de88d		31c9			XORL CX, CX									
  tree.go:1459			0x6de88f		4889df			MOVQ BX, DI									
  tree.go:1459			0x6de892		89ce			MOVL CX, SI									
  tree.go:1459			0x6de894		4531c0			XORL R8, R8									
  tree.go:1459			0x6de897		4531c9			XORL R9, R9									
  tree.go:1459			0x6de89a		4881c448040000		ADDQ $0x448, SP									
  tree.go:1459			0x6de8a1		5d			POPQ BP										
  tree.go:1459			0x6de8a2		c3			RET										
  tree.go:1453			0x6de8a3		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1453			0x6de8ab		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1453			0x6de8af		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1453			0x6de8b4		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1453			0x6de8b9		4c8b15102a7302		MOVQ github.com/snissn/gomap/TreeDB/node.ErrPrimaryDirectory(SB), R10		
  tree.go:1453			0x6de8c0		4c8b1d112a7302		MOVQ github.com/snissn/gomap/TreeDB/node.ErrPrimaryDirectory+8(SB), R11		
  tree.go:1453			0x6de8c7		31c0			XORL AX, AX									
  tree.go:1453			0x6de8c9		31db			XORL BX, BX									
  tree.go:1453			0x6de8cb		31c9			XORL CX, CX									
  tree.go:1453			0x6de8cd		4889df			MOVQ BX, DI									
  tree.go:1453			0x6de8d0		89ce			MOVL CX, SI									
  tree.go:1453			0x6de8d2		4531c0			XORL R8, R8									
  tree.go:1453			0x6de8d5		4531c9			XORL R9, R9									
  tree.go:1453			0x6de8d8		4881c448040000		ADDQ $0x448, SP									
  tree.go:1453			0x6de8df		5d			POPQ BP										
  tree.go:1453			0x6de8e0		c3			RET										
  tree.go:1494			0x6de8e1		440f11bc2458030000	MOVUPS X15, 0x358(SP)								
  tree.go:1494			0x6de8ea		e81124d4ff		CALL runtime.convT16(SB)							
  tree.go:1494			0x6de8ef		488d0daa054801		LEAQ 0x14805aa(IP), CX								
  tree.go:1494			0x6de8f6		48898c2458030000	MOVQ CX, 0x358(SP)								
  tree.go:1494			0x6de8fe		4889842460030000	MOVQ AX, 0x360(SP)								
  errors.go:26			0x6de906		488d0516c96901		LEAQ 0x169c916(IP), AX								
  errors.go:26			0x6de90d		bb14000000		MOVL $0x14, BX									
  errors.go:26			0x6de912		488d8c2458030000	LEAQ 0x358(SP), CX								
  errors.go:26			0x6de91a		bf01000000		MOVL $0x1, DI									
  errors.go:26			0x6de91f		4889fe			MOVQ DI, SI									
  errors.go:26			0x6de922		e83946e2ff		CALL fmt.errorf(SB)								
  errors.go:26			0x6de927		4885c0			TESTQ AX, AX									
  errors.go:26			0x6de92a		7529			JNE 0x6de955									
  errors.go:31			0x6de92c		90			NOPL										
  errors.go:65			0x6de92d		488d05ac6e5001		LEAQ 0x1506eac(IP), AX								
  errors.go:65			0x6de934		e86761d4ff		CALL runtime.newobject(SB)							
  errors.go:65			0x6de939		48c7400814000000	MOVQ $0x14, 0x8(AX)								
  errors.go:65			0x6de941		488d0ddbc86901		LEAQ 0x169c8db(IP), CX								
  errors.go:65			0x6de948		488908			MOVQ CX, 0(AX)									
  tree.go:1494			0x6de94b		4889c3			MOVQ AX, BX									
  tree.go:1494			0x6de94e		488d056bf47d01		LEAQ go:itab.*errors.errorString,error(SB), AX					
  tree.go:1494			0x6de955		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1494			0x6de95d		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1494			0x6de961		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1494			0x6de966		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1494			0x6de96b		31c9			XORL CX, CX									
  tree.go:1494			0x6de96d		31ff			XORL DI, DI									
  tree.go:1494			0x6de96f		89ce			MOVL CX, SI									
  tree.go:1494			0x6de971		4531c0			XORL R8, R8									
  tree.go:1494			0x6de974		4531c9			XORL R9, R9									
  tree.go:1494			0x6de977		4989c2			MOVQ AX, R10									
  tree.go:1494			0x6de97a		4989db			MOVQ BX, R11									
  tree.go:1494			0x6de97d		31c0			XORL AX, AX									
  tree.go:1494			0x6de97f		4889fb			MOVQ DI, BX									
  tree.go:1494			0x6de982		4881c448040000		ADDQ $0x448, SP									
  tree.go:1494			0x6de989		5d			POPQ BP										
  tree.go:1494			0x6de98a		c3			RET										
  tree.go:1492			0x6de98b		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1492			0x6de993		4c8da42418010000	LEAQ 0x118(SP), R12								
  tree.go:1492			0x6de99b		450f103424		MOVUPS 0(R12), X14								
  tree.go:1492			0x6de9a0		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1492			0x6de9a4		450f10742410		MOVUPS 0x10(R12), X14								
  tree.go:1492			0x6de9aa		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1492			0x6de9af		450f10742418		MOVUPS 0x18(R12), X14								
  tree.go:1492			0x6de9b5		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1492			0x6de9ba		0fb68424d0000000	MOVZX 0xd0(SP), AX								
  tree.go:1492			0x6de9c2		488b9c24d8000000	MOVQ 0xd8(SP), BX								
  tree.go:1492			0x6de9ca		8b8c24e0000000		MOVL 0xe0(SP), CX								
  tree.go:1492			0x6de9d1		488bbc24e8000000	MOVQ 0xe8(SP), DI								
  tree.go:1492			0x6de9d9		8bb424f0000000		MOVL 0xf0(SP), SI								
  tree.go:1492			0x6de9e0		440fb78424f4000000	MOVZX 0xf4(SP), R8								
  tree.go:1492			0x6de9e9		4531c9			XORL R9, R9									
  tree.go:1492			0x6de9ec		4531d2			XORL R10, R10									
  tree.go:1492			0x6de9ef		4531db			XORL R11, R11									
  tree.go:1492			0x6de9f2		4881c448040000		ADDQ $0x448, SP									
  tree.go:1492			0x6de9f9		5d			POPQ BP										
  tree.go:1492			0x6de9fa		c3			RET										
  tree.go:1448			0x6de9fb		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1448			0x6dea03		440f113a		MOVUPS X15, 0(DX)								
  tree.go:1448			0x6dea07		440f117a10		MOVUPS X15, 0x10(DX)								
  tree.go:1448			0x6dea0c		440f117a18		MOVUPS X15, 0x18(DX)								
  tree.go:1448			0x6dea11		31c9			XORL CX, CX									
  tree.go:1448			0x6dea13		31ff			XORL DI, DI									
  tree.go:1448			0x6dea15		89ce			MOVL CX, SI									
  tree.go:1448			0x6dea17		4531c0			XORL R8, R8									
  tree.go:1448			0x6dea1a		4531c9			XORL R9, R9									
  tree.go:1448			0x6dea1d		4989c2			MOVQ AX, R10									
  tree.go:1448			0x6dea20		4989db			MOVQ BX, R11									
  tree.go:1448			0x6dea23		31c0			XORL AX, AX									
  tree.go:1448			0x6dea25		4889fb			MOVQ DI, BX									
  tree.go:1448			0x6dea28		4881c448040000		ADDQ $0x448, SP									
  tree.go:1448			0x6dea2f		5d			POPQ BP										
  tree.go:1448			0x6dea30		c3			RET										
  tree.go:1444			0x6dea31		488d9424d0000000	LEAQ 0xd0(SP), DX								
  tree.go:1444			0x6dea39		450f103424		MOVUPS 0(R12), X14								
  tree.go:1444			0x6dea3e		440f1132		MOVUPS X14, 0(DX)								
  tree.go:1444			0x6dea42		450f10742410		MOVUPS 0x10(R12), X14								
  tree.go:1444			0x6dea48		440f117210		MOVUPS X14, 0x10(DX)								
  tree.go:1444			0x6dea4d		450f10742418		MOVUPS 0x18(R12), X14								
  tree.go:1444			0x6dea53		440f117218		MOVUPS X14, 0x18(DX)								
  tree.go:1444			0x6dea58		0fb68424d0000000	MOVZX 0xd0(SP), AX								
  tree.go:1444			0x6dea60		488b9c24d8000000	MOVQ 0xd8(SP), BX								
  tree.go:1444			0x6dea68		8b8c24e0000000		MOVL 0xe0(SP), CX								
  tree.go:1444			0x6dea6f		488bbc24e8000000	MOVQ 0xe8(SP), DI								
  tree.go:1444			0x6dea77		8bb424f0000000		MOVL 0xf0(SP), SI								
  tree.go:1444			0x6dea7e		440fb78424f4000000	MOVZX 0xf4(SP), R8								
  tree.go:1444			0x6dea87		41b901000000		MOVL $0x1, R9									
  tree.go:1444			0x6dea8d		4531d2			XORL R10, R10									
  tree.go:1444			0x6dea90		4531db			XORL R11, R11									
  tree.go:1444			0x6dea93		4881c448040000		ADDQ $0x448, SP									
  tree.go:1444			0x6dea9a		5d			POPQ BP										
  tree.go:1444			0x6dea9b		c3			RET										
  errors.go:65			0x6dea9c		488d053d6d5001		LEAQ 0x1506d3d(IP), AX								
  errors.go:65			0x6deaa3		e8f85fd4ff		CALL runtime.newobject(SB)							
  errors.go:65			0x6deaa8		48c740080d000000	MOVQ $0xd, 0x8(AX)								
  errors.go:65			0x6deab0		488d0d93e66801		LEAQ 0x168e693(IP), CX								
  errors.go:65			0x6deab7		488908			MOVQ CX, 0(AX)									
  tree.go:1497			0x6deaba		488d8c24d0000000	LEAQ 0xd0(SP), CX								
  tree.go:1497			0x6deac2		440f1139		MOVUPS X15, 0(CX)								
  tree.go:1497			0x6deac6		440f117910		MOVUPS X15, 0x10(CX)								
  tree.go:1497			0x6deacb		440f117918		MOVUPS X15, 0x18(CX)								
  tree.go:1497			0x6dead0		31db			XORL BX, BX									
  tree.go:1497			0x6dead2		31c9			XORL CX, CX									
  tree.go:1497			0x6dead4		4889df			MOVQ BX, DI									
  tree.go:1497			0x6dead7		89ce			MOVL CX, SI									
  tree.go:1497			0x6dead9		4531c0			XORL R8, R8									
  tree.go:1497			0x6deadc		4531c9			XORL R9, R9									
  tree.go:1497			0x6deadf		4c8d15daf27d01		LEAQ go:itab.*errors.errorString,error(SB), R10					
  tree.go:1497			0x6deae6		4989c3			MOVQ AX, R11									
  tree.go:1497			0x6deae9		31c0			XORL AX, AX									
  tree.go:1497			0x6deaeb		4881c448040000		ADDQ $0x448, SP									
  tree.go:1497			0x6deaf2		5d			POPQ BP										
  tree.go:1497			0x6deaf3		c3			RET										
  node.go:56			0x6deaf4		e8075bdbff		CALL runtime.panicBounds(SB)							
  node.go:56			0x6deaf9		e8025bdbff		CALL runtime.panicBounds(SB)							
  node.go:56			0x6deafe		90			NOPL										
  tree.go:1434			0x6deaff		4889442408		MOVQ AX, 0x8(SP)								
  tree.go:1434			0x6deb04		48895c2410		MOVQ BX, 0x10(SP)								
  tree.go:1434			0x6deb09		48894c2418		MOVQ CX, 0x18(SP)								
  tree.go:1434			0x6deb0e		48897c2420		MOVQ DI, 0x20(SP)								
  tree.go:1434			0x6deb13		4088742428		MOVB SI, 0x28(SP)								
  tree.go:1434			0x6deb18		e8433cdbff		CALL runtime.morestack_noctxt.abi0(SB)						
  tree.go:1434			0x6deb1d		488b442408		MOVQ 0x8(SP), AX								
  tree.go:1434			0x6deb22		488b5c2410		MOVQ 0x10(SP), BX								
  tree.go:1434			0x6deb27		488b4c2418		MOVQ 0x18(SP), CX								
  tree.go:1434			0x6deb2c		488b7c2420		MOVQ 0x20(SP), DI								
  tree.go:1434			0x6deb31		0fb6742428		MOVZX 0x28(SP), SI								
  tree.go:1434			0x6deb36		e905f5ffff		JMP github.com/snissn/gomap/TreeDB/tree.(*Tree).findLeafRefForGetMany(SB)	

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:62	0x92bd20		4c8d6424d8		LEAQ -0x28(SP), R12											
  registry.go:62	0x92bd25		4d3b6610		CMPQ R12, 0x10(R14)											
  registry.go:62	0x92bd29		0f86f7020000		JBE 0x92c026												
  registry.go:62	0x92bd2f		55			PUSHQ BP												
  registry.go:62	0x92bd30		4889e5			MOVQ SP, BP												
  registry.go:62	0x92bd33		4881eca0000000		SUBQ $0xa0, SP												
  registry.go:62	0x92bd3a		66440fd6bc2498000000	MOVQ X15, 0x98(SP)											
  registry.go:62	0x92bd44		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:62	0x92bd49		48c744245000000000	MOVQ $0x0, 0x50(SP)											
  registry.go:62	0x92bd52		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  registry.go:62	0x92bd5b		0f1f440000		NOPL 0(AX)(AX*1)											
  registry.go:63	0x92bd60		4885c9			TESTQ CX, CX												
  registry.go:63	0x92bd63		7d13			JGE 0x92bd78												
  type.go:195		0x92bd65		ba01000000		MOVL $0x1, DX												
  type.go:195		0x92bd6a		f0480fc19048040000	LOCK XADDQ DX, 0x448(AX)										
  registry.go:64	0x92bd73		83e20f			ANDL $0xf, DX												
  registry.go:64	0x92bd76		eb06			JMP 0x92bd7e												
  registry.go:66	0x92bd78		83e10f			ANDL $0xf, CX												
  registry.go:75	0x92bd7b		4889ca			MOVQ CX, DX												
  registry.go:63	0x92bd7e		48898424b0000000	MOVQ AX, 0xb0(SP)											
  registry.go:63	0x92bd86		48899c24b8000000	MOVQ BX, 0xb8(SP)											
  registry.go:75	0x92bd8e		4889942480000000	MOVQ DX, 0x80(SP)											
  registry.go:75	0x92bd96		4889d1			MOVQ DX, CX												
  registry.go:75	0x92bd99		e8a2090000		CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryJoinFast(SB)				
  registry.go:75	0x92bd9e		6690			NOPW													
  registry.go:75	0x92bda0		4885c0			TESTQ AX, AX												
  registry.go:75	0x92bda3		7560			JNE 0x92be05												
  registry.go:79	0x92bda5		90			NOPL													
  mutex.go:46		0x92bda6		90			NOPL													
  mutex.go:63		0x92bda7		31c0			XORL AX, AX												
  mutex.go:63		0x92bda9		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  mutex.go:63		0x92bdb1		41b901000000		MOVL $0x1, R9												
  mutex.go:63		0x92bdb7		f0450fb108		LOCK CMPXCHGL R9, 0(R8)											
  mutex.go:63		0x92bdbc		410f94c1		SETE R9													
  mutex.go:63		0x92bdc0		4584c9			TESTL R9, R9												
  mutex.go:63		0x92bdc3		7510			JNE 0x92bdd5												
  mutex.go:70		0x92bdc5		4c89c0			MOVQ R8, AX												
  mutex.go:70		0x92bdc8		e81305b7ff		CALL internal/sync.(*Mutex).lockSlow(SB)								
  registry.go:80	0x92bdcd		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  registry.go:80	0x92bdd5		4c8d0d84020000		LEAQ github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint.deferwrap1(SB), R9	
  registry.go:80	0x92bddc		4c898c2488000000	MOVQ R9, 0x88(SP)											
  registry.go:80	0x92bde4		4c89842490000000	MOVQ R8, 0x90(SP)											
  registry.go:80	0x92bdec		4c8d8c2488000000	LEAQ 0x88(SP), R9											
  registry.go:80	0x92bdf4		4c898c2498000000	MOVQ R9, 0x98(SP)											
  registry.go:80	0x92bdfc		c644244701		MOVB $0x1, 0x47(SP)											
  registry.go:80	0x92be01		31c0			XORL AX, AX												
  registry.go:82	0x92be03		eb2c			JMP 0x92be31												
  registry.go:76	0x92be05		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:76	0x92be0a		488b9c2480000000	MOVQ 0x80(SP), BX											
  registry.go:76	0x92be12		48895c2448		MOVQ BX, 0x48(SP)											
  registry.go:76	0x92be17		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:76	0x92be1e		5d			POPQ BP													
  registry.go:76	0x92be1f		90			NOPL													
  registry.go:76	0x92be20		c3			RET													
  registry.go:82	0x92be21		488b442470		MOVQ 0x70(SP), AX											
  registry.go:82	0x92be26		48ffc0			INCQ AX													
  registry.go:84	0x92be29		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  registry.go:82	0x92be31		4883f810		CMPQ AX, $0x10												
  registry.go:82	0x92be35		7d67			JGE 0x92be9e												
  registry.go:82	0x92be37		4889442470		MOVQ AX, 0x70(SP)											
  registry.go:83	0x92be3c		488b942480000000	MOVQ 0x80(SP), DX											
  registry.go:83	0x92be44		488d0c10		LEAQ 0(AX)(DX*1), CX											
  registry.go:83	0x92be48		83e10f			ANDL $0xf, CX												
  registry.go:83	0x92be4b		48894c2460		MOVQ CX, 0x60(SP)											
  registry.go:84	0x92be50		4c89c0			MOVQ R8, AX												
  registry.go:84	0x92be53		488b9c24b8000000	MOVQ 0xb8(SP), BX											
  registry.go:84	0x92be5b		0f1f440000		NOPL 0(AX)(AX*1)											
  registry.go:84	0x92be60		e8db080000		CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryJoinFast(SB)				
  registry.go:84	0x92be65		4885c0			TESTQ AX, AX												
  registry.go:84	0x92be68		74b7			JE 0x92be21												
  registry.go:85	0x92be6a		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:85	0x92be6f		488b442460		MOVQ 0x60(SP), AX											
  registry.go:85	0x92be74		4889442448		MOVQ AX, 0x48(SP)											
  registry.go:85	0x92be79		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:85	0x92be7e		488b942498000000	MOVQ 0x98(SP), DX											
  registry.go:85	0x92be86		488b02			MOVQ 0(DX), AX												
  registry.go:85	0x92be89		ffd0			CALL AX													
  registry.go:85	0x92be8b		488b442450		MOVQ 0x50(SP), AX											
  registry.go:85	0x92be90		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:85	0x92be95		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:85	0x92be9c		5d			POPQ BP													
  registry.go:85	0x92be9d		c3			RET													
  registry.go:85	0x92be9e		31c0			XORL AX, AX												
  registry.go:82	0x92bea0		eb10			JMP 0x92beb2												
  registry.go:88	0x92bea2		488b442468		MOVQ 0x68(SP), AX											
  registry.go:88	0x92bea7		48ffc0			INCQ AX													
  registry.go:90	0x92beaa		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  registry.go:88	0x92beb2		4883f810		CMPQ AX, $0x10												
  registry.go:88	0x92beb6		7d66			JGE 0x92bf1e												
  registry.go:88	0x92beb8		4889442468		MOVQ AX, 0x68(SP)											
  registry.go:89	0x92bebd		488b942480000000	MOVQ 0x80(SP), DX											
  registry.go:89	0x92bec5		488d0c10		LEAQ 0(AX)(DX*1), CX											
  registry.go:89	0x92bec9		83e10f			ANDL $0xf, CX												
  registry.go:89	0x92becc		48894c2458		MOVQ CX, 0x58(SP)											
  registry.go:90	0x92bed1		4c89c0			MOVQ R8, AX												
  registry.go:90	0x92bed4		488b9c24b8000000	MOVQ 0xb8(SP), BX											
  registry.go:90	0x92bedc		0f1f4000		NOPL 0(AX)												
  registry.go:90	0x92bee0		e8fb080000		CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).tryClaimFast(SB)			
  registry.go:90	0x92bee5		4885c0			TESTQ AX, AX												
  registry.go:90	0x92bee8		74b8			JE 0x92bea2												
  registry.go:91	0x92beea		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:91	0x92beef		488b442458		MOVQ 0x58(SP), AX											
  registry.go:91	0x92bef4		4889442448		MOVQ AX, 0x48(SP)											
  registry.go:91	0x92bef9		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:91	0x92befe		488b942498000000	MOVQ 0x98(SP), DX											
  registry.go:91	0x92bf06		488b02			MOVQ 0(DX), AX												
  registry.go:91	0x92bf09		ffd0			CALL AX													
  registry.go:91	0x92bf0b		488b442450		MOVQ 0x50(SP), AX											
  registry.go:91	0x92bf10		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:91	0x92bf15		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:91	0x92bf1c		5d			POPQ BP													
  registry.go:91	0x92bf1d		c3			RET													
  registry.go:96	0x92bf1e		4d8b4828		MOVQ 0x28(R8), R9											
  registry.go:96	0x92bf22		4d85c9			TESTQ R9, R9												
  registry.go:96	0x92bf25		7416			JE 0x92bf3d												
  registry.go:96	0x92bf27		498b4020		MOVQ 0x20(R8), AX											
  registry.go:97	0x92bf2b		498d49ff		LEAQ -0x1(R9), CX											
  registry.go:97	0x92bf2f		4a8b44c8f8		MOVQ -0x8(AX)(R9*8), AX											
  registry.go:98	0x92bf34		49894828		MOVQ CX, 0x28(R8)											
  registry.go:103	0x92bf38		4889c3			MOVQ AX, BX												
  registry.go:98	0x92bf3b		eb71			JMP 0x92bfae												
  registry.go:100	0x92bf3d		498b5810		MOVQ 0x10(R8), BX											
  registry.go:100	0x92bf41		498b4818		MOVQ 0x18(R8), CX											
  registry.go:101	0x92bf45		4c8d4b01		LEAQ 0x1(BX), R9											
  registry.go:100	0x92bf49		498b4008		MOVQ 0x8(R8), AX											
  registry.go:101	0x92bf4d		4c39c9			CMPQ CX, R9												
  registry.go:101	0x92bf50		734f			JAE 0x92bfa1												
  registry.go:100	0x92bf52		48895c2478		MOVQ BX, 0x78(SP)											
  registry.go:101	0x92bf57		4c89cb			MOVQ R9, BX												
  registry.go:101	0x92bf5a		bf01000000		MOVL $0x1, DI												
  registry.go:101	0x92bf5f		488d353a232301		LEAQ 0x123233a(IP), SI											
  registry.go:101	0x92bf66		e8152eb6ff		CALL runtime.growslice(SB)										
  registry.go:101	0x92bf6b		488b9424b0000000	MOVQ 0xb0(SP), DX											
  registry.go:101	0x92bf73		48894a18		MOVQ CX, 0x18(DX)											
  registry.go:101	0x92bf77		833da215600200		CMPL runtime.writeBarrier(SB), $0x0									
  registry.go:101	0x92bf7e		6690			NOPW													
  registry.go:101	0x92bf80		7410			JE 0x92bf92												
  registry.go:101	0x92bf82		488b4a08		MOVQ 0x8(DX), CX											
  registry.go:101	0x92bf86		e8d582b6ff		CALL runtime.gcWriteBarrier2(SB)									
  registry.go:101	0x92bf8b		498903			MOVQ AX, 0(R11)												
  registry.go:101	0x92bf8e		49894b08		MOVQ CX, 0x8(R11)											
  registry.go:101	0x92bf92		48894208		MOVQ AX, 0x8(DX)											
  registry.go:101	0x92bf96		4989d0			MOVQ DX, R8												
  registry.go:101	0x92bf99		4989d9			MOVQ BX, R9												
  registry.go:103	0x92bf9c		488b5c2478		MOVQ 0x78(SP), BX											
  registry.go:101	0x92bfa1		4d894810		MOVQ R9, 0x10(R8)											
  registry.go:101	0x92bfa5		4ac744c8f8ffffffff	MOVQ $-0x1, -0x8(AX)(R9*8)										
  registry.go:103	0x92bfae		498b4010		MOVQ 0x10(R8), AX											
  registry.go:103	0x92bfb2		4839c3			CMPQ BX, AX												
  registry.go:103	0x92bfb5		7351			JAE 0x92c008												
  registry.go:103	0x92bfb7		498b4008		MOVQ 0x8(R8), AX											
  registry.go:103	0x92bfbb		488b8c24b8000000	MOVQ 0xb8(SP), CX											
  registry.go:103	0x92bfc3		48890cd8		MOVQ CX, 0(AX)(BX*8)											
  registry.go:104	0x92bfc7		49394838		CMPQ 0x38(R8), CX											
  registry.go:104	0x92bfcb		7604			JBE 0x92bfd1												
  registry.go:105	0x92bfcd		49894838		MOVQ CX, 0x38(R8)											
  registry.go:107	0x92bfd1		488d4301		LEAQ 0x1(BX), AX											
  registry.go:107	0x92bfd5		4889442450		MOVQ AX, 0x50(SP)											
  registry.go:107	0x92bfda		48c7442448ffffffff	MOVQ $-0x1, 0x48(SP)											
  registry.go:107	0x92bfe3		c644244700		MOVB $0x0, 0x47(SP)											
  registry.go:107	0x92bfe8		488b942498000000	MOVQ 0x98(SP), DX											
  registry.go:107	0x92bff0		488b02			MOVQ 0(DX), AX												
  registry.go:107	0x92bff3		ffd0			CALL AX													
  registry.go:107	0x92bff5		488b442450		MOVQ 0x50(SP), AX											
  registry.go:107	0x92bffa		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:107	0x92bfff		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:107	0x92c006		5d			POPQ BP													
  registry.go:107	0x92c007		c3			RET													
  registry.go:103	0x92c008		e8f385b6ff		CALL runtime.panicBounds(SB)										
  registry.go:103	0x92c00d		90			NOPL													
  registry.go:103	0x92c00e		e80d50b2ff		CALL runtime.deferreturn(SB)										
  registry.go:103	0x92c013		488b442450		MOVQ 0x50(SP), AX											
  registry.go:103	0x92c018		488b5c2448		MOVQ 0x48(SP), BX											
  registry.go:103	0x92c01d		4881c4a0000000		ADDQ $0xa0, SP												
  registry.go:103	0x92c024		5d			POPQ BP													
  registry.go:103	0x92c025		c3			RET													
  registry.go:62	0x92c026		4889442408		MOVQ AX, 0x8(SP)											
  registry.go:62	0x92c02b		48895c2410		MOVQ BX, 0x10(SP)											
  registry.go:62	0x92c030		48894c2418		MOVQ CX, 0x18(SP)											
  registry.go:62	0x92c035		e82667b6ff		CALL runtime.morestack_noctxt.abi0(SB)									
  registry.go:62	0x92c03a		488b442408		MOVQ 0x8(SP), AX											
  registry.go:62	0x92c03f		488b5c2410		MOVQ 0x10(SP), BX											
  registry.go:62	0x92c044		488b4c2418		MOVQ 0x18(SP), CX											
  registry.go:62	0x92c049		e9d2fcffff		JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint(SB)			

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint.deferwrap1(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:80	0x92c060		493b6610		CMPQ SP, 0x10(R14)										
  registry.go:80	0x92c064		7629			JBE 0x92c08f											
  registry.go:80	0x92c066		55			PUSHQ BP											
  registry.go:80	0x92c067		4889e5			MOVQ SP, BP											
  registry.go:80	0x92c06a		4883ec10		SUBQ $0x10, SP											
  registry.go:80	0x92c06e		488b4208		MOVQ 0x8(DX), AX										
  mutex.go:65		0x92c072		90			NOPL												
  mutex.go:194		0x92c073		bbffffffff		MOVL $-0x1, BX											
  mutex.go:194		0x92c078		f00fc118		LOCK XADDL BX, 0(AX)										
  mutex.go:194		0x92c07c		0f1f4000		NOPL 0(AX)											
  mutex.go:194		0x92c080		ffcb			DECL BX												
  mutex.go:195		0x92c082		7405			JE 0x92c089											
  mutex.go:198		0x92c084		e83705b7ff		CALL internal/sync.(*Mutex).unlockSlow(SB)							
  registry.go:80	0x92c089		4883c410		ADDQ $0x10, SP											
  registry.go:80	0x92c08d		5d			POPQ BP												
  registry.go:80	0x92c08e		c3			RET												
  registry.go:80	0x92c08f		e82c66b6ff		CALL runtime.morestack.abi0(SB)									
  registry.go:80	0x92c094		ebca			JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:140	0x92c320		493b6610		CMPQ SP, 0x10(R14)										
  registry.go:140	0x92c324		0f86cd010000		JBE 0x92c4f7											
  registry.go:140	0x92c32a		55			PUSHQ BP											
  registry.go:140	0x92c32b		4889e5			MOVQ SP, BP											
  registry.go:140	0x92c32e		4883ec70		SUBQ $0x70, SP											
  registry.go:140	0x92c332		66440fd67c2468		MOVQ X15, 0x68(SP)										
  registry.go:140	0x92c339		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:140	0x92c33e		6690			NOPW												
  registry.go:141	0x92c340		4885db			TESTQ BX, BX											
  registry.go:141	0x92c343		7d42			JGE 0x92c387											
  registry.go:142	0x92c345		488d4b01		LEAQ 0x1(BX), CX										
  registry.go:142	0x92c349		48f7d9			NEGQ CX												
  registry.go:143	0x92c34c		4883f910		CMPQ CX, $0x10											
  registry.go:143	0x92c350		7d2f			JGE 0x92c381											
  registry.go:146	0x92c352		8400			TESTB AL, 0(AX)											
  registry.go:146	0x92c354		48c1e106		SHLQ $0x6, CX											
  type.go:94		0x92c358		488d0401		LEAQ 0(CX)(AX*1), AX										
  type.go:94		0x92c35c		488d4050		LEAQ 0x50(AX), AX										
  type.go:94		0x92c360		b9ffffffff		MOVL $-0x1, CX											
  type.go:94		0x92c365		f00fc108		LOCK XADDL CX, 0(AX)										
  type.go:94		0x92c369		ffc9			DECL CX												
  registry.go:147	0x92c36b		85c9			TESTL CX, CX											
  registry.go:147	0x92c36d		7c06			JL 0x92c375											
  registry.go:148	0x92c36f		4883c470		ADDQ $0x70, SP											
  registry.go:148	0x92c373		5d			POPQ BP												
  registry.go:148	0x92c374		c3			RET												
  registry.go:151	0x92c375		90			NOPL												
  type.go:83		0x92c376		31c9			XORL CX, CX											
  type.go:83		0x92c378		8708			XCHGL CX, 0(AX)											
  registry.go:152	0x92c37a		4883c470		ADDQ $0x70, SP											
  registry.go:152	0x92c37e		5d			POPQ BP												
  registry.go:152	0x92c37f		90			NOPL												
  registry.go:152	0x92c380		c3			RET												
  registry.go:144	0x92c381		4883c470		ADDQ $0x70, SP											
  registry.go:144	0x92c385		5d			POPQ BP												
  registry.go:144	0x92c386		c3			RET												
  registry.go:141	0x92c387		4889842480000000	MOVQ AX, 0x80(SP)										
  registry.go:155	0x92c38f		90			NOPL												
  registry.go:141	0x92c390		4889c1			MOVQ AX, CX											
  mutex.go:63		0x92c393		31c0			XORL AX, AX											
  mutex.go:63		0x92c395		41b801000000		MOVL $0x1, R8											
  mutex.go:63		0x92c39b		f0440fb101		LOCK CMPXCHGL R8, 0(CX)										
  mutex.go:63		0x92c3a0		410f94c0		SETE R8												
  mutex.go:63		0x92c3a4		4584c0			TESTL R8, R8											
  mutex.go:63		0x92c3a7		7405			JE 0x92c3ae											
  registry.go:141	0x92c3a9		4885db			TESTQ BX, BX											
  mutex.go:46		0x92c3ac		eb26			JMP 0x92c3d4											
  registry.go:141	0x92c3ae		48899c2488000000	MOVQ BX, 0x88(SP)										
  mutex.go:70		0x92c3b6		4889c8			MOVQ CX, AX											
  mutex.go:70		0x92c3b9		e822ffb6ff		CALL internal/sync.(*Mutex).lockSlow(SB)							
  registry.go:141	0x92c3be		488b8c2488000000	MOVQ 0x88(SP), CX										
  registry.go:141	0x92c3c6		4885c9			TESTQ CX, CX											
  registry.go:161	0x92c3c9		4889cb			MOVQ CX, BX											
  registry.go:156	0x92c3cc		488b8c2480000000	MOVQ 0x80(SP), CX										
  registry.go:156	0x92c3d4		4c8d0545010000		LEAQ github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister.deferwrap1(SB), R8	
  registry.go:156	0x92c3db		4c89442458		MOVQ R8, 0x58(SP)										
  registry.go:156	0x92c3e0		48894c2460		MOVQ CX, 0x60(SP)										
  registry.go:156	0x92c3e5		488d542458		LEAQ 0x58(SP), DX										
  registry.go:156	0x92c3ea		4889542468		MOVQ DX, 0x68(SP)										
  registry.go:156	0x92c3ef		c644244701		MOVB $0x1, 0x47(SP)										
  registry.go:158	0x92c3f4		0f8ee0000000		JLE 0x92c4da											
  registry.go:161	0x92c3fa		4c8d43ff		LEAQ -0x1(BX), R8										
  registry.go:161	0x92c3fe		6690			NOPW												
  registry.go:162	0x92c400		4c394110		CMPQ 0x10(CX), R8										
  registry.go:162	0x92c404		0f8ebe000000		JLE 0x92c4c8											
  registry.go:162	0x92c40a		4c8b4908		MOVQ 0x8(CX), R9										
  registry.go:165	0x92c40e		4d8b54d9f8		MOVQ -0x8(R9)(BX*8), R10									
  registry.go:166	0x92c413		4983faff		CMPQ R10, $-0x1											
  registry.go:166	0x92c417		0f8499000000		JE 0x92c4b6											
  registry.go:169	0x92c41d		49c744d9f8ffffffff	MOVQ $-0x1, -0x8(R9)(BX*8)									
  registry.go:170	0x92c426		4c8b4930		MOVQ 0x30(CX), R9										
  registry.go:170	0x92c42a		488b5928		MOVQ 0x28(CX), BX										
  registry.go:170	0x92c42e		48ffc3			INCQ BX												
  registry.go:170	0x92c431		488b4120		MOVQ 0x20(CX), AX										
  registry.go:170	0x92c435		4939d9			CMPQ R9, BX											
  registry.go:170	0x92c438		7354			JAE 0x92c48e											
  registry.go:161	0x92c43a		4c89442450		MOVQ R8, 0x50(SP)										
  registry.go:165	0x92c43f		4c89542448		MOVQ R10, 0x48(SP)										
  registry.go:170	0x92c444		4c89c9			MOVQ R9, CX											
  registry.go:170	0x92c447		bf01000000		MOVL $0x1, DI											
  registry.go:170	0x92c44c		488d358d1e2301		LEAQ 0x1231e8d(IP), SI										
  registry.go:170	0x92c453		e82829b6ff		CALL runtime.growslice(SB)									
  registry.go:170	0x92c458		488b942480000000	MOVQ 0x80(SP), DX										
  registry.go:170	0x92c460		48894a30		MOVQ CX, 0x30(DX)										
  registry.go:170	0x92c464		833db510600200		CMPL runtime.writeBarrier(SB), $0x0								
  registry.go:170	0x92c46b		7410			JE 0x92c47d											
  registry.go:170	0x92c46d		488b4a20		MOVQ 0x20(DX), CX										
  registry.go:170	0x92c471		e8ea7db6ff		CALL runtime.gcWriteBarrier2(SB)								
  registry.go:170	0x92c476		498903			MOVQ AX, 0(R11)											
  registry.go:170	0x92c479		49894b08		MOVQ CX, 0x8(R11)										
  registry.go:170	0x92c47d		48894220		MOVQ AX, 0x20(DX)										
  registry.go:170	0x92c481		4889d1			MOVQ DX, CX											
  registry.go:170	0x92c484		4c8b442450		MOVQ 0x50(SP), R8										
  registry.go:171	0x92c489		4c8b542448		MOVQ 0x48(SP), R10										
  registry.go:170	0x92c48e		48895928		MOVQ BX, 0x28(CX)										
  registry.go:170	0x92c492		4c8944d8f8		MOVQ R8, -0x8(AX)(BX*8)										
  registry.go:171	0x92c497		4c395138		CMPQ 0x38(CX), R10										
  registry.go:171	0x92c49b		7504			JNE 0x92c4a1											
  registry.go:172	0x92c49d		c6414001		MOVB $0x1, 0x40(CX)										
  registry.go:174	0x92c4a1		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:174	0x92c4a6		488b542468		MOVQ 0x68(SP), DX										
  registry.go:174	0x92c4ab		488b02			MOVQ 0(DX), AX											
  registry.go:174	0x92c4ae		ffd0			CALL AX												
  registry.go:174	0x92c4b0		4883c470		ADDQ $0x70, SP											
  registry.go:174	0x92c4b4		5d			POPQ BP												
  registry.go:174	0x92c4b5		c3			RET												
  registry.go:167	0x92c4b6		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:167	0x92c4bb		488b442458		MOVQ 0x58(SP), AX										
  registry.go:167	0x92c4c0		ffd0			CALL AX												
  registry.go:167	0x92c4c2		4883c470		ADDQ $0x70, SP											
  registry.go:167	0x92c4c6		5d			POPQ BP												
  registry.go:167	0x92c4c7		c3			RET												
  registry.go:163	0x92c4c8		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:163	0x92c4cd		488b442458		MOVQ 0x58(SP), AX										
  registry.go:163	0x92c4d2		ffd0			CALL AX												
  registry.go:163	0x92c4d4		4883c470		ADDQ $0x70, SP											
  registry.go:163	0x92c4d8		5d			POPQ BP												
  registry.go:163	0x92c4d9		c3			RET												
  registry.go:159	0x92c4da		c644244700		MOVB $0x0, 0x47(SP)										
  registry.go:159	0x92c4df		488b442458		MOVQ 0x58(SP), AX										
  registry.go:159	0x92c4e4		ffd0			CALL AX												
  registry.go:159	0x92c4e6		4883c470		ADDQ $0x70, SP											
  registry.go:159	0x92c4ea		5d			POPQ BP												
  registry.go:159	0x92c4eb		c3			RET												
  registry.go:159	0x92c4ec		e82f4bb2ff		CALL runtime.deferreturn(SB)									
  registry.go:159	0x92c4f1		4883c470		ADDQ $0x70, SP											
  registry.go:159	0x92c4f5		5d			POPQ BP												
  registry.go:159	0x92c4f6		c3			RET												
  registry.go:140	0x92c4f7		4889442408		MOVQ AX, 0x8(SP)										
  registry.go:140	0x92c4fc		48895c2410		MOVQ BX, 0x10(SP)										
  registry.go:140	0x92c501		e85a62b6ff		CALL runtime.morestack_noctxt.abi0(SB)								
  registry.go:140	0x92c506		488b442408		MOVQ 0x8(SP), AX										
  registry.go:140	0x92c50b		488b5c2410		MOVQ 0x10(SP), BX										
  registry.go:140	0x92c510		e90bfeffff		JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister(SB)			

TEXT github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister.deferwrap1(SB) github.com/snissn/gomap/TreeDB/lifecycle/registry.go
  registry.go:156	0x92c520		493b6610		CMPQ SP, 0x10(R14)										
  registry.go:156	0x92c524		7629			JBE 0x92c54f											
  registry.go:156	0x92c526		55			PUSHQ BP											
  registry.go:156	0x92c527		4889e5			MOVQ SP, BP											
  registry.go:156	0x92c52a		4883ec10		SUBQ $0x10, SP											
  registry.go:156	0x92c52e		488b4208		MOVQ 0x8(DX), AX										
  mutex.go:65		0x92c532		90			NOPL												
  mutex.go:194		0x92c533		bbffffffff		MOVL $-0x1, BX											
  mutex.go:194		0x92c538		f00fc118		LOCK XADDL BX, 0(AX)										
  mutex.go:194		0x92c53c		0f1f4000		NOPL 0(AX)											
  mutex.go:194		0x92c540		ffcb			DECL BX												
  mutex.go:195		0x92c542		7405			JE 0x92c549											
  mutex.go:198		0x92c544		e87700b7ff		CALL internal/sync.(*Mutex).unlockSlow(SB)							
  registry.go:156	0x92c549		4883c410		ADDQ $0x10, SP											
  registry.go:156	0x92c54d		5d			POPQ BP												
  registry.go:156	0x92c54e		c3			RET												
  registry.go:156	0x92c54f		e86c61b6ff		CALL runtime.morestack.abi0(SB)									
  registry.go:156	0x92c554		ebca			JMP github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/db/api.go
  api.go:558		0xa362e0		493b6610		CMPQ SP, 0x10(R14)								
  api.go:558		0xa362e4		0f8679010000		JBE 0xa36463									
  api.go:558		0xa362ea		55			PUSHQ BP									
  api.go:558		0xa362eb		4889e5			MOVQ SP, BP									
  api.go:558		0xa362ee		4883ec78		SUBQ $0x78, SP									
  api.go:558		0xa362f2		48899c2490000000	MOVQ BX, 0x90(SP)								
  api.go:558		0xa362fa		4889b424a8000000	MOVQ SI, 0xa8(SP)								
  raw_kv_compat.go:7	0xa36302		4885db			TESTQ BX, BX									
  raw_kv_compat.go:7	0xa36305		7515			JNE 0xa3631c									
  api.go:559		0xa36307		488b1db2d83d02		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey(SB), BX		
  api.go:559		0xa3630e		488b0db3d83d02		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+8(SB), CX		
  api.go:559		0xa36315		488b3db4d83d02		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+16(SB), DI		
  raw_kv_compat.go:7	0xa3631c		4889842488000000	MOVQ AX, 0x88(SP)								
  raw_kv_compat.go:7	0xa36324		4c898424b0000000	MOVQ R8, 0xb0(SP)								
  raw_kv_compat.go:7	0xa3632c		4889b424a8000000	MOVQ SI, 0xa8(SP)								
  raw_kv_compat.go:7	0xa36334		4c898c24b8000000	MOVQ R9, 0xb8(SP)								
  api.go:560		0xa3633c		4c8d157d010000		LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1(SB), R10	
  api.go:560		0xa36343		4c89542450		MOVQ R10, 0x50(SP)								
  api.go:560		0xa36348		4889442458		MOVQ AX, 0x58(SP)								
  api.go:560		0xa3634d		48894c2468		MOVQ CX, 0x68(SP)								
  api.go:560		0xa36352		48897c2470		MOVQ DI, 0x70(SP)								
  api.go:560		0xa36357		48895c2460		MOVQ BX, 0x60(SP)								
  api.go:571		0xa3635c		8400			TESTB AL, 0(AX)									
  type.go:181		0xa3635e		488bb8a0160000		MOVQ 0x16a0(AX), DI								
  type.go:181		0xa36365		48897c2418		MOVQ DI, 0x18(SP)								
  api.go:572		0xa3636a		488b7c2450		MOVQ 0x50(SP), DI								
  api.go:572		0xa3636f		4889f0			MOVQ SI, AX									
  api.go:572		0xa36372		4c89c3			MOVQ R8, BX									
  api.go:572		0xa36375		4c89c9			MOVQ R9, CX									
  api.go:572		0xa36378		488d542450		LEAQ 0x50(SP), DX								
  api.go:572		0xa3637d		ffd7			CALL DI										
  api.go:572		0xa3637f		4889742438		MOVQ SI, 0x38(SP)								
  api.go:572		0xa36384		4c89442448		MOVQ R8, 0x48(SP)								
  api.go:572		0xa36389		4889442440		MOVQ AX, 0x40(SP)								
  api.go:572		0xa3638e		48897c2430		MOVQ DI, 0x30(SP)								
  api.go:572		0xa36393		48895c2420		MOVQ BX, 0x20(SP)								
  api.go:572		0xa36398		48894c2428		MOVQ CX, 0x28(SP)								
  api.go:573		0xa3639d		488b842488000000	MOVQ 0x88(SP), AX								
  api.go:573		0xa363a5		4889f3			MOVQ SI, BX									
  api.go:573		0xa363a8		4c89c1			MOVQ R8, CX									
  api.go:573		0xa363ab		e870d1ffff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).refreshOnValueLogFileNotFound(SB)	
  api.go:573		0xa363b0		84c0			TESTL AL, AL									
  api.go:573		0xa363b2		7520			JNE 0xa363d4									
  api.go:579		0xa363b4		488b742438		MOVQ 0x38(SP), SI								
  api.go:579		0xa363b9		488b7c2430		MOVQ 0x30(SP), DI								
  api.go:579		0xa363be		488b5c2420		MOVQ 0x20(SP), BX								
  api.go:579		0xa363c3		488b4c2428		MOVQ 0x28(SP), CX								
  api.go:579		0xa363c8		4c8b442448		MOVQ 0x48(SP), R8								
  api.go:579		0xa363cd		488b442440		MOVQ 0x40(SP), AX								
  api.go:573		0xa363d2		eb3b			JMP 0xa3640f									
  api.go:574		0xa363d4		488b842488000000	MOVQ 0x88(SP), AX								
  api.go:574		0xa363dc		488b5c2418		MOVQ 0x18(SP), BX								
  api.go:574		0xa363e1		e83ad2ffff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).refreshValueLogSetForReadRetry(SB)	
  api.go:574		0xa363e6		4885c0			TESTQ AX, AX									
  api.go:574		0xa363e9		7552			JNE 0xa3643d									
  api.go:577		0xa363eb		488b742450		MOVQ 0x50(SP), SI								
  api.go:577		0xa363f0		488b8424a8000000	MOVQ 0xa8(SP), AX								
  api.go:577		0xa363f8		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  api.go:577		0xa36400		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  api.go:577		0xa36408		488d542450		LEAQ 0x50(SP), DX								
  api.go:577		0xa3640d		ffd6			CALL SI										
  api.go:579		0xa3640f		4885f6			TESTQ SI, SI									
  api.go:579		0xa36412		741e			JE 0xa36432									
  api.go:580		0xa36414		488b8424a8000000	MOVQ 0xa8(SP), AX								
  api.go:580		0xa3641c		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  api.go:580		0xa36424		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  api.go:580		0xa3642c		4883c478		ADDQ $0x78, SP									
  api.go:580		0xa36430		5d			POPQ BP										
  api.go:580		0xa36431		c3			RET										
  api.go:582		0xa36432		31f6			XORL SI, SI									
  api.go:582		0xa36434		4531c0			XORL R8, R8									
  api.go:582		0xa36437		4883c478		ADDQ $0x78, SP									
  api.go:582		0xa3643b		5d			POPQ BP										
  api.go:582		0xa3643c		c3			RET										
  api.go:575		0xa3643d		488b8c24b8000000	MOVQ 0xb8(SP), CX								
  api.go:575		0xa36445		31ff			XORL DI, DI									
  api.go:575		0xa36447		4889c6			MOVQ AX, SI									
  api.go:575		0xa3644a		4989d8			MOVQ BX, R8									
  api.go:575		0xa3644d		488b8424a8000000	MOVQ 0xa8(SP), AX								
  api.go:575		0xa36455		488b9c24b0000000	MOVQ 0xb0(SP), BX								
  api.go:575		0xa3645d		4883c478		ADDQ $0x78, SP									
  api.go:575		0xa36461		5d			POPQ BP										
  api.go:575		0xa36462		c3			RET										
  api.go:558		0xa36463		4889442408		MOVQ AX, 0x8(SP)								
  api.go:558		0xa36468		48895c2410		MOVQ BX, 0x10(SP)								
  api.go:558		0xa3646d		48894c2418		MOVQ CX, 0x18(SP)								
  api.go:558		0xa36472		48897c2420		MOVQ DI, 0x20(SP)								
  api.go:558		0xa36477		4889742428		MOVQ SI, 0x28(SP)								
  api.go:558		0xa3647c		4c89442430		MOVQ R8, 0x30(SP)								
  api.go:558		0xa36481		4c894c2438		MOVQ R9, 0x38(SP)								
  api.go:558		0xa36486		e8d5c2a5ff		CALL runtime.morestack_noctxt.abi0(SB)						
  api.go:558		0xa3648b		488b442408		MOVQ 0x8(SP), AX								
  api.go:558		0xa36490		488b5c2410		MOVQ 0x10(SP), BX								
  api.go:558		0xa36495		488b4c2418		MOVQ 0x18(SP), CX								
  api.go:558		0xa3649a		488b7c2420		MOVQ 0x20(SP), DI								
  api.go:558		0xa3649f		488b742428		MOVQ 0x28(SP), SI								
  api.go:558		0xa364a4		4c8b442430		MOVQ 0x30(SP), R8								
  api.go:558		0xa364a9		4c8b4c2438		MOVQ 0x38(SP), R9								
  api.go:558		0xa364ae		e92dfeffff		JMP github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend(SB)		

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1(SB) github.com/snissn/gomap/TreeDB/db/api.go
  api.go:560		0xa364c0		4c8d6424d8		LEAQ -0x28(SP), R12										
  api.go:560		0xa364c5		4d3b6610		CMPQ R12, 0x10(R14)										
  api.go:560		0xa364c9		0f86c7010000		JBE 0xa36696											
  api.go:560		0xa364cf		55			PUSHQ BP											
  api.go:560		0xa364d0		4889e5			MOVQ SP, BP											
  api.go:560		0xa364d3		4881eca0000000		SUBQ $0xa0, SP											
  api.go:560		0xa364da		66440fd6bc2498000000	MOVQ X15, 0x98(SP)										
  api.go:562		0xa364e4		48898c24c0000000	MOVQ CX, 0xc0(SP)										
  api.go:562		0xa364ec		48899c24b8000000	MOVQ BX, 0xb8(SP)										
  api.go:562		0xa364f4		48898424b0000000	MOVQ AX, 0xb0(SP)										
  api.go:560		0xa364fc		c644243f00		MOVB $0x0, 0x3f(SP)										
  api.go:560		0xa36501		488b4208		MOVQ 0x8(DX), AX										
  api.go:560		0xa36505		488b4a10		MOVQ 0x10(DX), CX										
  api.go:560		0xa36509		48898c2480000000	MOVQ CX, 0x80(SP)										
  api.go:560		0xa36511		488b4a18		MOVQ 0x18(DX), CX										
  api.go:560		0xa36515		48894c2448		MOVQ CX, 0x48(SP)										
  api.go:560		0xa3651a		488b4a20		MOVQ 0x20(DX), CX										
  api.go:560		0xa3651e		48894c2450		MOVQ CX, 0x50(SP)										
  api.go:560		0xa36523		48c744246800000000	MOVQ $0x0, 0x68(SP)										
  api.go:560		0xa3652c		440f117c2470		MOVUPS X15, 0x70(SP)										
  api.go:560		0xa36532		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  api.go:560		0xa3653b		440f117c2458		MOVUPS X15, 0x58(SP)										
  api.go:561		0xa36541		e81a551c00		CALL github.com/snissn/gomap/TreeDB/db.(*DB).acquireOneShotReadOrErr(SB)			
  api.go:562		0xa36546		4885db			TESTQ BX, BX											
  api.go:562		0xa36549		7463			JE 0xa365ae											
  api.go:563		0xa3654b		488b9424b0000000	MOVQ 0xb0(SP), DX										
  api.go:563		0xa36553		4889542468		MOVQ DX, 0x68(SP)										
  api.go:563		0xa36558		488b9424b8000000	MOVQ 0xb8(SP), DX										
  api.go:563		0xa36560		4889542470		MOVQ DX, 0x70(SP)										
  api.go:563		0xa36565		488b9424c0000000	MOVQ 0xc0(SP), DX										
  api.go:563		0xa3656d		4889542478		MOVQ DX, 0x78(SP)										
  api.go:563		0xa36572		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  api.go:563		0xa3657b		48895c2458		MOVQ BX, 0x58(SP)										
  api.go:563		0xa36580		48894c2460		MOVQ CX, 0x60(SP)										
  api.go:563		0xa36585		488b7c2440		MOVQ 0x40(SP), DI										
  api.go:563		0xa3658a		488b442468		MOVQ 0x68(SP), AX										
  api.go:563		0xa3658f		488b542470		MOVQ 0x70(SP), DX										
  api.go:563		0xa36594		4c8b4c2478		MOVQ 0x78(SP), R9										
  api.go:563		0xa36599		4889de			MOVQ BX, SI											
  api.go:563		0xa3659c		4989c8			MOVQ CX, R8											
  api.go:563		0xa3659f		4889d3			MOVQ DX, BX											
  api.go:563		0xa365a2		4c89c9			MOVQ R9, CX											
  api.go:563		0xa365a5		4881c4a0000000		ADDQ $0xa0, SP											
  api.go:563		0xa365ac		5d			POPQ BP												
  api.go:563		0xa365ad		c3			RET												
  api.go:565		0xa365ae		488d150b010000		LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1.deferwrap1(SB), DX	
  api.go:565		0xa365b5		4889942488000000	MOVQ DX, 0x88(SP)										
  api.go:565		0xa365bd		4889842490000000	MOVQ AX, 0x90(SP)										
  api.go:565		0xa365c5		488d942488000000	LEAQ 0x88(SP), DX										
  api.go:565		0xa365cd		4889942498000000	MOVQ DX, 0x98(SP)										
  api.go:565		0xa365d5		c644243f01		MOVB $0x1, 0x3f(SP)										
  api.go:568		0xa365da		8400			TESTB AL, 0(AX)											
  api.go:568		0xa365dc		4805c8030000		ADDQ $0x3c8, AX											
  api.go:568		0xa365e2		488b9c2480000000	MOVQ 0x80(SP), BX										
  api.go:568		0xa365ea		488b4c2448		MOVQ 0x48(SP), CX										
  api.go:568		0xa365ef		488b7c2450		MOVQ 0x50(SP), DI										
  api.go:568		0xa365f4		488bb424b0000000	MOVQ 0xb0(SP), SI										
  api.go:568		0xa365fc		4c8b8424b8000000	MOVQ 0xb8(SP), R8										
  api.go:568		0xa36604		4c8b8c24c0000000	MOVQ 0xc0(SP), R9										
  api.go:568		0xa3660c		e88f4fcaff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB)				
  api.go:568		0xa36611		4889442468		MOVQ AX, 0x68(SP)										
  api.go:568		0xa36616		48895c2470		MOVQ BX, 0x70(SP)										
  api.go:568		0xa3661b		48894c2478		MOVQ CX, 0x78(SP)										
  api.go:568		0xa36620		48897c2440		MOVQ DI, 0x40(SP)										
  api.go:568		0xa36625		4889742458		MOVQ SI, 0x58(SP)										
  api.go:568		0xa3662a		4c89442460		MOVQ R8, 0x60(SP)										
  api.go:568		0xa3662f		c644243f00		MOVB $0x0, 0x3f(SP)										
  api.go:568		0xa36634		488b942498000000	MOVQ 0x98(SP), DX										
  api.go:568		0xa3663c		4c8b12			MOVQ 0(DX), R10											
  api.go:568		0xa3663f		90			NOPL												
  api.go:568		0xa36640		41ffd2			CALL R10											
  api.go:568		0xa36643		488b7c2440		MOVQ 0x40(SP), DI										
  api.go:568		0xa36648		488b742458		MOVQ 0x58(SP), SI										
  api.go:568		0xa3664d		488b442468		MOVQ 0x68(SP), AX										
  api.go:568		0xa36652		488b5c2470		MOVQ 0x70(SP), BX										
  api.go:568		0xa36657		4c8b442460		MOVQ 0x60(SP), R8										
  api.go:568		0xa3665c		488b4c2478		MOVQ 0x78(SP), CX										
  api.go:568		0xa36661		4881c4a0000000		ADDQ $0xa0, SP											
  api.go:568		0xa36668		5d			POPQ BP												
  api.go:568		0xa36669		c3			RET												
  api.go:568		0xa3666a		e8b1a9a1ff		CALL runtime.deferreturn(SB)									
  api.go:568		0xa3666f		488b442468		MOVQ 0x68(SP), AX										
  api.go:568		0xa36674		488b5c2470		MOVQ 0x70(SP), BX										
  api.go:568		0xa36679		488b4c2478		MOVQ 0x78(SP), CX										
  api.go:568		0xa3667e		488b7c2440		MOVQ 0x40(SP), DI										
  api.go:568		0xa36683		488b742458		MOVQ 0x58(SP), SI										
  api.go:568		0xa36688		4c8b442460		MOVQ 0x60(SP), R8										
  api.go:568		0xa3668d		4881c4a0000000		ADDQ $0xa0, SP											
  api.go:568		0xa36694		5d			POPQ BP												
  api.go:568		0xa36695		c3			RET												
  api.go:560		0xa36696		4889442408		MOVQ AX, 0x8(SP)										
  api.go:560		0xa3669b		48895c2410		MOVQ BX, 0x10(SP)										
  api.go:560		0xa366a0		48894c2418		MOVQ CX, 0x18(SP)										
  api.go:560		0xa366a5		e816c0a5ff		CALL runtime.morestack.abi0(SB)									
  api.go:560		0xa366aa		488b442408		MOVQ 0x8(SP), AX										
  api.go:560		0xa366af		488b5c2410		MOVQ 0x10(SP), BX										
  api.go:560		0xa366b4		488b4c2418		MOVQ 0x18(SP), CX										
  api.go:560		0xa366b9		e902feffff		JMP github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1(SB)			

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1.deferwrap1(SB) github.com/snissn/gomap/TreeDB/db/api.go
  api.go:565		0xa366c0		493b6610		CMPQ SP, 0x10(R14)									
  api.go:565		0xa366c4		7617			JBE 0xa366dd										
  api.go:565		0xa366c6		55			PUSHQ BP										
  api.go:565		0xa366c7		4889e5			MOVQ SP, BP										
  api.go:565		0xa366ca		4883ec08		SUBQ $0x8, SP										
  api.go:565		0xa366ce		488b4208		MOVQ 0x8(DX), AX									
  api.go:565		0xa366d2		e8e9541c00		CALL github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB)				
  api.go:565		0xa366d7		4883c408		ADDQ $0x8, SP										
  api.go:565		0xa366db		5d			POPQ BP											
  api.go:565		0xa366dc		c3			RET											
  api.go:565		0xa366dd		0f1f00			NOPL 0(AX)										
  api.go:565		0xa366e0		e8dbbfa5ff		CALL runtime.morestack.abi0(SB)								
  api.go:565		0xa366e5		ebd9			JMP github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend.func1.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/db/conditional_txn.go
  conditional_txn.go:193	0xaa3e00		4c8da42448feffff	LEAQ 0xfffffe48(SP), R12							
  conditional_txn.go:193	0xaa3e08		4d3b6610		CMPQ R12, 0x10(R14)								
  conditional_txn.go:193	0xaa3e0c		0f8666050000		JBE 0xaa4378									
  conditional_txn.go:193	0xaa3e12		55			PUSHQ BP									
  conditional_txn.go:193	0xaa3e13		4889e5			MOVQ SP, BP									
  conditional_txn.go:193	0xaa3e16		4881ec30020000		SUBQ $0x230, SP									
  conditional_txn.go:193	0xaa3e1d		48899c2448020000	MOVQ BX, 0x248(SP)								
  conditional_txn.go:193	0xaa3e25		4889b42460020000	MOVQ SI, 0x260(SP)								
  conditional_txn.go:471	0xaa3e2d		4885c0			TESTQ AX, AX									
  conditional_txn.go:471	0xaa3e30		7442			JE 0xaa3e74									
  conditional_txn.go:471	0xaa3e32		80782800		CMPB 0x28(AX), $0x0								
  conditional_txn.go:471	0xaa3e36		753c			JNE 0xaa3e74									
  conditional_txn.go:471	0xaa3e38		488b10			MOVQ 0(AX), DX									
  conditional_txn.go:471	0xaa3e3b		0f1f440000		NOPL 0(AX)(AX*1)								
  conditional_txn.go:471	0xaa3e40		4885d2			TESTQ DX, DX									
  conditional_txn.go:471	0xaa3e43		742f			JE 0xaa3e74									
  conditional_txn.go:471	0xaa3e45		4883780800		CMPQ 0x8(AX), $0x0								
  conditional_txn.go:471	0xaa3e4a		7428			JE 0xaa3e74									
  conditional_txn.go:471	0xaa3e4c		4883781000		CMPQ 0x10(AX), $0x0								
  conditional_txn.go:471	0xaa3e51		7421			JE 0xaa3e74									
  type.go:19			0xaa3e53		8b92a0510000		MOVL 0x51a0(DX), DX								
  type.go:19			0xaa3e59		85d2			TESTL DX, DX									
  conditional_txn.go:474	0xaa3e5b		7410			JE 0xaa3e6d									
  conditional_txn.go:194	0xaa3e5d		488b15ecbc3602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), DX			
  conditional_txn.go:194	0xaa3e64		4c8b15edbc3602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), R10			
  conditional_txn.go:194	0xaa3e6b		eb15			JMP 0xaa3e82									
  conditional_txn.go:194	0xaa3e6d		31d2			XORL DX, DX									
  conditional_txn.go:194	0xaa3e6f		4531d2			XORL R10, R10									
  conditional_txn.go:194	0xaa3e72		eb0e			JMP 0xaa3e82									
  conditional_txn.go:194	0xaa3e74		488b1505bd3602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrConditionalTxnClosed(SB), DX		
  conditional_txn.go:194	0xaa3e7b		4c8b1506bd3602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrConditionalTxnClosed+8(SB), R10	
  conditional_txn.go:194	0xaa3e82		4885d2			TESTQ DX, DX									
  conditional_txn.go:194	0xaa3e85		0f85d3040000		JNE 0xaa435e									
  conditional_txn.go:471	0xaa3e8b		4c898c2470020000	MOVQ R9, 0x270(SP)								
  conditional_txn.go:471	0xaa3e93		4c89842468020000	MOVQ R8, 0x268(SP)								
  conditional_txn.go:471	0xaa3e9b		4889b42460020000	MOVQ SI, 0x260(SP)								
  raw_kv_compat.go:7		0xaa3ea3		4885db			TESTQ BX, BX									
  raw_kv_compat.go:7		0xaa3ea6		7515			JNE 0xaa3ebd									
  conditional_txn.go:197	0xaa3ea8		488b1d11fd3602		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey(SB), BX		
  conditional_txn.go:197	0xaa3eaf		488b0d12fd3602		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+8(SB), CX		
  conditional_txn.go:197	0xaa3eb6		488b3d13fd3602		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+16(SB), DI		
  conditional_txn.go:471	0xaa3ebd		4889842440020000	MOVQ AX, 0x240(SP)								
  conditional_txn.go:197	0xaa3ec5		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  conditional_txn.go:197	0xaa3ecd		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  conditional_txn.go:197	0xaa3ed5		48899c24f0000000	MOVQ BX, 0xf0(SP)								
  conditional_txn.go:198	0xaa3edd		488d9424a0010000	LEAQ 0x1a0(SP), DX								
  conditional_txn.go:198	0xaa3ee5		440f113a		MOVUPS X15, 0(DX)								
  conditional_txn.go:198	0xaa3ee9		440f117a10		MOVUPS X15, 0x10(DX)								
  conditional_txn.go:198	0xaa3eee		440f117a20		MOVUPS X15, 0x20(DX)								
  conditional_txn.go:198	0xaa3ef3		440f117a30		MOVUPS X15, 0x30(DX)								
  conditional_txn.go:198	0xaa3ef8		440f117a40		MOVUPS X15, 0x40(DX)								
  conditional_txn.go:198	0xaa3efd		440f117a50		MOVUPS X15, 0x50(DX)								
  conditional_txn.go:198	0xaa3f02		440f117a60		MOVUPS X15, 0x60(DX)								
  conditional_txn.go:198	0xaa3f07		440f117a70		MOVUPS X15, 0x70(DX)								
  conditional_txn.go:198	0xaa3f0c		440f11ba80000000	MOVUPS X15, 0x80(DX)								
  conditional_txn.go:198	0xaa3f14		e8e71b0000		CALL github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).findStagedWrite(SB)	
  conditional_txn.go:198	0xaa3f19		488d9424a0010000	LEAQ 0x1a0(SP), DX								
  conditional_txn.go:198	0xaa3f21		4889e6			MOVQ SP, SI									
  conditional_txn.go:198	0xaa3f24		440f1036		MOVUPS 0(SI), X14								
  conditional_txn.go:198	0xaa3f28		440f1132		MOVUPS X14, 0(DX)								
  conditional_txn.go:198	0xaa3f2c		440f107610		MOVUPS 0x10(SI), X14								
  conditional_txn.go:198	0xaa3f31		440f117210		MOVUPS X14, 0x10(DX)								
  conditional_txn.go:198	0xaa3f36		440f107620		MOVUPS 0x20(SI), X14								
  conditional_txn.go:198	0xaa3f3b		440f117220		MOVUPS X14, 0x20(DX)								
  conditional_txn.go:198	0xaa3f40		440f107630		MOVUPS 0x30(SI), X14								
  conditional_txn.go:198	0xaa3f45		440f117230		MOVUPS X14, 0x30(DX)								
  conditional_txn.go:198	0xaa3f4a		440f107640		MOVUPS 0x40(SI), X14								
  conditional_txn.go:198	0xaa3f4f		440f117240		MOVUPS X14, 0x40(DX)								
  conditional_txn.go:198	0xaa3f54		440f107650		MOVUPS 0x50(SI), X14								
  conditional_txn.go:198	0xaa3f59		440f117250		MOVUPS X14, 0x50(DX)								
  conditional_txn.go:198	0xaa3f5e		440f107660		MOVUPS 0x60(SI), X14								
  conditional_txn.go:198	0xaa3f63		440f117260		MOVUPS X14, 0x60(DX)								
  conditional_txn.go:198	0xaa3f68		440f107670		MOVUPS 0x70(SI), X14								
  conditional_txn.go:198	0xaa3f6d		440f117270		MOVUPS X14, 0x70(DX)								
  conditional_txn.go:198	0xaa3f72		440f10b680000000	MOVUPS 0x80(SI), X14								
  conditional_txn.go:198	0xaa3f7a		440f11b280000000	MOVUPS X14, 0x80(DX)								
  conditional_txn.go:198	0xaa3f82		4c8d8424f8000000	LEAQ 0xf8(SP), R8								
  conditional_txn.go:198	0xaa3f8a		440f1032		MOVUPS 0(DX), X14								
  conditional_txn.go:198	0xaa3f8e		450f1130		MOVUPS X14, 0(R8)								
  conditional_txn.go:198	0xaa3f92		440f107210		MOVUPS 0x10(DX), X14								
  conditional_txn.go:198	0xaa3f97		450f117010		MOVUPS X14, 0x10(R8)								
  conditional_txn.go:198	0xaa3f9c		440f107220		MOVUPS 0x20(DX), X14								
  conditional_txn.go:198	0xaa3fa1		450f117020		MOVUPS X14, 0x20(R8)								
  conditional_txn.go:198	0xaa3fa6		440f107230		MOVUPS 0x30(DX), X14								
  conditional_txn.go:198	0xaa3fab		450f117030		MOVUPS X14, 0x30(R8)								
  conditional_txn.go:198	0xaa3fb0		440f107240		MOVUPS 0x40(DX), X14								
  conditional_txn.go:198	0xaa3fb5		450f117040		MOVUPS X14, 0x40(R8)								
  conditional_txn.go:198	0xaa3fba		440f107250		MOVUPS 0x50(DX), X14								
  conditional_txn.go:198	0xaa3fbf		450f117050		MOVUPS X14, 0x50(R8)								
  conditional_txn.go:198	0xaa3fc4		440f107260		MOVUPS 0x60(DX), X14								
  conditional_txn.go:198	0xaa3fc9		450f117060		MOVUPS X14, 0x60(R8)								
  conditional_txn.go:198	0xaa3fce		440f107270		MOVUPS 0x70(DX), X14								
  conditional_txn.go:198	0xaa3fd3		450f117070		MOVUPS X14, 0x70(R8)								
  conditional_txn.go:198	0xaa3fd8		440f10b280000000	MOVUPS 0x80(DX), X14								
  conditional_txn.go:198	0xaa3fe0		450f11b080000000	MOVUPS X14, 0x80(R8)								
  conditional_txn.go:198	0xaa3fe8		84c0			TESTL AL, AL									
  conditional_txn.go:198	0xaa3fea		0f8465010000		JE 0xaa4155									
  conditional_txn.go:199	0xaa3ff0		0fb6942430010000	MOVZX 0x130(SP), DX								
  conditional_txn.go:199	0xaa3ff8		0f1f840000000000	NOPL 0(AX)(AX*1)								
  conditional_txn.go:200	0xaa4000		84d2			TESTL DL, DL									
  conditional_txn.go:200	0xaa4002		0f850e010000		JNE 0xaa4116									
  conditional_txn.go:201	0xaa4008		80bc247801000000	CMPB 0x178(SP), $0x0								
  conditional_txn.go:201	0xaa4010		0f85c6000000		JNE 0xaa40dc									
  conditional_txn.go:204	0xaa4016		488bbc2458010000	MOVQ 0x158(SP), DI								
  conditional_txn.go:204	0xaa401e		488b942468020000	MOVQ 0x268(SP), DX								
  conditional_txn.go:204	0xaa4026		488d1c3a		LEAQ 0(DX)(DI*1), BX								
  conditional_txn.go:204	0xaa402a		4c8b842450010000	MOVQ 0x150(SP), R8								
  conditional_txn.go:204	0xaa4032		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:204	0xaa403a		4839d9			CMPQ CX, BX									
  conditional_txn.go:204	0xaa403d		720a			JB 0xaa4049									
  conditional_txn.go:204	0xaa403f		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:204	0xaa4047		eb3f			JMP 0xaa4088									
  conditional_txn.go:204	0xaa4049		4c89842498010000	MOVQ R8, 0x198(SP)								
  conditional_txn.go:204	0xaa4051		4889bc24e8000000	MOVQ DI, 0xe8(SP)								
  conditional_txn.go:204	0xaa4059		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:204	0xaa4061		488d35b8a00b01		LEAQ 0x10ba0b8(IP), SI								
  conditional_txn.go:204	0xaa4068		e813ad9eff		CALL runtime.growslice(SB)							
  conditional_txn.go:204	0xaa406d		488b942468020000	MOVQ 0x268(SP), DX								
  conditional_txn.go:204	0xaa4075		4889e6			MOVQ SP, SI									
  conditional_txn.go:204	0xaa4078		488bbc24e8000000	MOVQ 0xe8(SP), DI								
  conditional_txn.go:204	0xaa4080		4c8b842498010000	MOVQ 0x198(SP), R8								
  conditional_txn.go:204	0xaa4088		48898c24e8000000	MOVQ CX, 0xe8(SP)								
  conditional_txn.go:204	0xaa4090		48899c24e0000000	MOVQ BX, 0xe0(SP)								
  conditional_txn.go:204	0xaa4098		4889842498010000	MOVQ AX, 0x198(SP)								
  conditional_txn.go:204	0xaa40a0		4801d0			ADDQ DX, AX									
  conditional_txn.go:204	0xaa40a3		4c89c3			MOVQ R8, BX									
  conditional_txn.go:204	0xaa40a6		4889f9			MOVQ DI, CX									
  conditional_txn.go:204	0xaa40a9		e8f2089fff		CALL runtime.memmove(SB)							
  conditional_txn.go:204	0xaa40ae		488bbc2480010000	MOVQ 0x180(SP), DI								
  conditional_txn.go:204	0xaa40b6		488b842498010000	MOVQ 0x198(SP), AX								
  conditional_txn.go:204	0xaa40be		488b9c24e0000000	MOVQ 0xe0(SP), BX								
  conditional_txn.go:204	0xaa40c6		488b8c24e8000000	MOVQ 0xe8(SP), CX								
  conditional_txn.go:204	0xaa40ce		31f6			XORL SI, SI									
  conditional_txn.go:204	0xaa40d0		4531c0			XORL R8, R8									
  conditional_txn.go:204	0xaa40d3		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:204	0xaa40da		5d			POPQ BP										
  conditional_txn.go:204	0xaa40db		c3			RET										
  conditional_txn.go:202	0xaa40dc		488b155dcd3602		MOVQ github.com/snissn/gomap/TreeDB/batch.ErrMissingValueReader(SB), DX		
  conditional_txn.go:202	0xaa40e3		4c8b055ecd3602		MOVQ github.com/snissn/gomap/TreeDB/batch.ErrMissingValueReader+8(SB), R8	
  conditional_txn.go:202	0xaa40ea		488bbc2480010000	MOVQ 0x180(SP), DI								
  conditional_txn.go:202	0xaa40f2		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:202	0xaa40fa		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:202	0xaa4102		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:202	0xaa410a		4889d6			MOVQ DX, SI									
  conditional_txn.go:202	0xaa410d		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:202	0xaa4114		5d			POPQ BP										
  conditional_txn.go:202	0xaa4115		c3			RET										
  conditional_txn.go:205	0xaa4116		80fa01			CMPL DL, $0x1									
  conditional_txn.go:205	0xaa4119		753a			JNE 0xaa4155									
  conditional_txn.go:206	0xaa411b		488b15cecc3602		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), DX			
  conditional_txn.go:206	0xaa4122		4c8b05cfcc3602		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), R8		
  conditional_txn.go:206	0xaa4129		488bbc2480010000	MOVQ 0x180(SP), DI								
  conditional_txn.go:206	0xaa4131		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:206	0xaa4139		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:206	0xaa4141		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:206	0xaa4149		4889d6			MOVQ DX, SI									
  conditional_txn.go:206	0xaa414c		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:206	0xaa4153		5d			POPQ BP										
  conditional_txn.go:206	0xaa4154		c3			RET										
  conditional_txn.go:209	0xaa4155		488b942440020000	MOVQ 0x240(SP), DX								
  conditional_txn.go:209	0xaa415d		488b4208		MOVQ 0x8(DX), AX								
  conditional_txn.go:209	0xaa4161		488b9c24f0000000	MOVQ 0xf0(SP), BX								
  conditional_txn.go:209	0xaa4169		488b8c24b0000000	MOVQ 0xb0(SP), CX								
  conditional_txn.go:209	0xaa4171		488bbc24b8000000	MOVQ 0xb8(SP), DI								
  conditional_txn.go:209	0xaa4179		488bb42460020000	MOVQ 0x260(SP), SI								
  conditional_txn.go:209	0xaa4181		4c8b842468020000	MOVQ 0x268(SP), R8								
  conditional_txn.go:209	0xaa4189		4c8b8c2470020000	MOVQ 0x270(SP), R9								
  conditional_txn.go:209	0xaa4191		e8eabd0100		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend(SB)	
  conditional_txn.go:209	0xaa4196		4889b424d8000000	MOVQ SI, 0xd8(SP)								
  conditional_txn.go:209	0xaa419e		4c89842490010000	MOVQ R8, 0x190(SP)								
  conditional_txn.go:209	0xaa41a6		4889bc24c0000000	MOVQ DI, 0xc0(SP)								
  conditional_txn.go:209	0xaa41ae		4889842488010000	MOVQ AX, 0x188(SP)								
  conditional_txn.go:209	0xaa41b6		48899c24c8000000	MOVQ BX, 0xc8(SP)								
  conditional_txn.go:209	0xaa41be		48898c24d0000000	MOVQ CX, 0xd0(SP)								
  conditional_txn.go:210	0xaa41c6		488b0d23cc3602		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound(SB), CX			
  conditional_txn.go:210	0xaa41cd		488b3d24cc3602		MOVQ github.com/snissn/gomap/TreeDB/tree.ErrKeyNotFound+8(SB), DI		
  conditional_txn.go:210	0xaa41d4		4889f0			MOVQ SI, AX									
  conditional_txn.go:210	0xaa41d7		4c89c3			MOVQ R8, BX									
  conditional_txn.go:210	0xaa41da		e8c1729fff		CALL errors.Is(SB)								
  conditional_txn.go:210	0xaa41df		90			NOPL										
  conditional_txn.go:210	0xaa41e0		84c0			TESTL AL, AL									
  conditional_txn.go:210	0xaa41e2		0f85d9000000		JNE 0xaa42c1									
  conditional_txn.go:216	0xaa41e8		488bb424d8000000	MOVQ 0xd8(SP), SI								
  conditional_txn.go:216	0xaa41f0		4885f6			TESTQ SI, SI									
  conditional_txn.go:216	0xaa41f3		0f8596000000		JNE 0xaa428f									
  conditional_txn.go:219	0xaa41f9		488b842440020000	MOVQ 0x240(SP), AX								
  conditional_txn.go:219	0xaa4201		488b9c24f0000000	MOVQ 0xf0(SP), BX								
  conditional_txn.go:219	0xaa4209		488b8c24b0000000	MOVQ 0xb0(SP), CX								
  conditional_txn.go:219	0xaa4211		488bbc24b8000000	MOVQ 0xb8(SP), DI								
  conditional_txn.go:219	0xaa4219		488bb424c0000000	MOVQ 0xc0(SP), SI								
  conditional_txn.go:219	0xaa4221		41b801000000		MOVL $0x1, R8									
  conditional_txn.go:219	0xaa4227		e8341d0000		CALL github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).recordRead(SB)		
  conditional_txn.go:219	0xaa422c		4885c0			TESTQ AX, AX									
  conditional_txn.go:219	0xaa422f		7430			JE 0xaa4261									
  conditional_txn.go:220	0xaa4231		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:220	0xaa4239		488bbc24c0000000	MOVQ 0xc0(SP), DI								
  conditional_txn.go:220	0xaa4241		4889c6			MOVQ AX, SI									
  conditional_txn.go:220	0xaa4244		4989d8			MOVQ BX, R8									
  conditional_txn.go:220	0xaa4247		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:220	0xaa424f		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:220	0xaa4257		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:220	0xaa425e		5d			POPQ BP										
  conditional_txn.go:220	0xaa425f		90			NOPL										
  conditional_txn.go:220	0xaa4260		c3			RET										
  conditional_txn.go:222	0xaa4261		488b842488010000	MOVQ 0x188(SP), AX								
  conditional_txn.go:222	0xaa4269		488b9c24c8000000	MOVQ 0xc8(SP), BX								
  conditional_txn.go:222	0xaa4271		488b8c24d0000000	MOVQ 0xd0(SP), CX								
  conditional_txn.go:222	0xaa4279		488bbc24c0000000	MOVQ 0xc0(SP), DI								
  conditional_txn.go:222	0xaa4281		31f6			XORL SI, SI									
  conditional_txn.go:222	0xaa4283		4531c0			XORL R8, R8									
  conditional_txn.go:222	0xaa4286		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:222	0xaa428d		5d			POPQ BP										
  conditional_txn.go:222	0xaa428e		c3			RET										
  conditional_txn.go:217	0xaa428f		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:217	0xaa4297		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:217	0xaa429f		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:217	0xaa42a7		488bbc24c0000000	MOVQ 0xc0(SP), DI								
  conditional_txn.go:217	0xaa42af		4c8b842490010000	MOVQ 0x190(SP), R8								
  conditional_txn.go:217	0xaa42b7		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:217	0xaa42be		5d			POPQ BP										
  conditional_txn.go:217	0xaa42bf		90			NOPL										
  conditional_txn.go:217	0xaa42c0		c3			RET										
  conditional_txn.go:211	0xaa42c1		488b842440020000	MOVQ 0x240(SP), AX								
  conditional_txn.go:211	0xaa42c9		488b9c24f0000000	MOVQ 0xf0(SP), BX								
  conditional_txn.go:211	0xaa42d1		488b8c24b0000000	MOVQ 0xb0(SP), CX								
  conditional_txn.go:211	0xaa42d9		488bbc24b8000000	MOVQ 0xb8(SP), DI								
  conditional_txn.go:211	0xaa42e1		488bb424c0000000	MOVQ 0xc0(SP), SI								
  conditional_txn.go:211	0xaa42e9		4531c0			XORL R8, R8									
  conditional_txn.go:211	0xaa42ec		e86f1c0000		CALL github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).recordRead(SB)		
  conditional_txn.go:211	0xaa42f1		4885c0			TESTQ AX, AX									
  conditional_txn.go:211	0xaa42f4		742f			JE 0xaa4325									
  conditional_txn.go:212	0xaa42f6		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:212	0xaa42fe		488bbc24c0000000	MOVQ 0xc0(SP), DI								
  conditional_txn.go:212	0xaa4306		4889c6			MOVQ AX, SI									
  conditional_txn.go:212	0xaa4309		4989d8			MOVQ BX, R8									
  conditional_txn.go:212	0xaa430c		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:212	0xaa4314		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:212	0xaa431c		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:212	0xaa4323		5d			POPQ BP										
  conditional_txn.go:212	0xaa4324		c3			RET										
  conditional_txn.go:214	0xaa4325		488b842460020000	MOVQ 0x260(SP), AX								
  conditional_txn.go:214	0xaa432d		488b9c2468020000	MOVQ 0x268(SP), BX								
  conditional_txn.go:214	0xaa4335		488b8c2470020000	MOVQ 0x270(SP), CX								
  conditional_txn.go:214	0xaa433d		488bbc24c0000000	MOVQ 0xc0(SP), DI								
  conditional_txn.go:214	0xaa4345		488bb424d8000000	MOVQ 0xd8(SP), SI								
  conditional_txn.go:214	0xaa434d		4c8b842490010000	MOVQ 0x190(SP), R8								
  conditional_txn.go:214	0xaa4355		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:214	0xaa435c		5d			POPQ BP										
  conditional_txn.go:214	0xaa435d		c3			RET										
  conditional_txn.go:195	0xaa435e		4889f0			MOVQ SI, AX									
  conditional_txn.go:195	0xaa4361		4c89c3			MOVQ R8, BX									
  conditional_txn.go:195	0xaa4364		4c89c9			MOVQ R9, CX									
  conditional_txn.go:195	0xaa4367		31ff			XORL DI, DI									
  conditional_txn.go:195	0xaa4369		4889d6			MOVQ DX, SI									
  conditional_txn.go:195	0xaa436c		4d89d0			MOVQ R10, R8									
  conditional_txn.go:195	0xaa436f		4881c430020000		ADDQ $0x230, SP									
  conditional_txn.go:195	0xaa4376		5d			POPQ BP										
  conditional_txn.go:195	0xaa4377		c3			RET										
  conditional_txn.go:193	0xaa4378		4889442408		MOVQ AX, 0x8(SP)								
  conditional_txn.go:193	0xaa437d		48895c2410		MOVQ BX, 0x10(SP)								
  conditional_txn.go:193	0xaa4382		48894c2418		MOVQ CX, 0x18(SP)								
  conditional_txn.go:193	0xaa4387		48897c2420		MOVQ DI, 0x20(SP)								
  conditional_txn.go:193	0xaa438c		4889742428		MOVQ SI, 0x28(SP)								
  conditional_txn.go:193	0xaa4391		4c89442430		MOVQ R8, 0x30(SP)								
  conditional_txn.go:193	0xaa4396		4c894c2438		MOVQ R9, 0x38(SP)								
  conditional_txn.go:193	0xaa439b		0f1f440000		NOPL 0(AX)(AX*1)								
  conditional_txn.go:193	0xaa43a0		e8bbe39eff		CALL runtime.morestack_noctxt.abi0(SB)						
  conditional_txn.go:193	0xaa43a5		488b442408		MOVQ 0x8(SP), AX								
  conditional_txn.go:193	0xaa43aa		488b5c2410		MOVQ 0x10(SP), BX								
  conditional_txn.go:193	0xaa43af		488b4c2418		MOVQ 0x18(SP), CX								
  conditional_txn.go:193	0xaa43b4		488b7c2420		MOVQ 0x20(SP), DI								
  conditional_txn.go:193	0xaa43b9		488b742428		MOVQ 0x28(SP), SI								
  conditional_txn.go:193	0xaa43be		4c8b442430		MOVQ 0x30(SP), R8								
  conditional_txn.go:193	0xaa43c3		4c8b4c2438		MOVQ 0x38(SP), R9								
  conditional_txn.go:193	0xaa43c8		e933faffff		JMP github.com/snissn/gomap/TreeDB/db.(*ConditionalTxn).GetVersionedAppend(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:1768				0xaa97e0		4c8da424b8feffff		LEAQ 0xfffffeb8(SP), R12													
  db.go:1768				0xaa97e8		4d3b6610			CMPQ R12, 0x10(R14)														
  db.go:1768				0xaa97ec		0f867d0d0000			JBE 0xaaa56f															
  db.go:1768				0xaa97f2		55				PUSHQ BP															
  db.go:1768				0xaa97f3		4889e5				MOVQ SP, BP															
  db.go:1768				0xaa97f6		4881ecc0010000			SUBQ $0x1c0, SP															
  rwmutex.go:72				0xaa97fd		48898424d0010000		MOVQ AX, 0x1d0(SP)														
  rwmutex.go:72				0xaa9805		48899c24d8010000		MOVQ BX, 0x1d8(SP)														
  rwmutex.go:72				0xaa980d		888c24e0010000			MOVB CL, 0x1e0(SP)														
  db.go:1768				0xaa9814		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1769				0xaa9819		90				NOPL																
  type.go:94				0xaa981a		ba01000000			MOVL $0x1, DX															
  type.go:94				0xaa981f		f00fc19078070000		LOCK XADDL DX, 0x778(AX)													
  type.go:94				0xaa9827		ffc2				INCL DX																
  rwmutex.go:72				0xaa9829		85d2				TESTL DX, DX															
  rwmutex.go:72				0xaa982b		7d17				JGE 0xaa9844															
  rwmutex.go:74				0xaa982d		480574070000			ADDQ $0x774, AX															
  rwmutex.go:74				0xaa9833		31db				XORL BX, BX															
  rwmutex.go:74				0xaa9835		31c9				XORL CX, CX															
  rwmutex.go:74				0xaa9837		e8c4489eff			CALL sync.runtime_SemacquireRWMutexR(SB)											
  db.go:1770				0xaa983c		488b8424d0010000		MOVQ 0x1d0(SP), AX														
  db.go:1770				0xaa9844		488d0df50d0000			LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.deferwrap1(SB), CX		
  db.go:1770				0xaa984b		48898c24b0010000		MOVQ CX, 0x1b0(SP)														
  db.go:1770				0xaa9853		488d8868070000			LEAQ 0x768(AX), CX														
  db.go:1770				0xaa985a		48898c24b8010000		MOVQ CX, 0x1b8(SP)														
  db.go:1770				0xaa9862		488d8c24b0010000		LEAQ 0x1b0(SP), CX														
  db.go:1770				0xaa986a		48898c2430010000		MOVQ CX, 0x130(SP)														
  db.go:1770				0xaa9872		488d842418010000		LEAQ 0x118(SP), AX														
  db.go:1770				0xaa987a		e881729aff			CALL runtime.deferprocStack(SB)													
  type.go:19				0xaa987f		488b8c24d0010000		MOVQ 0x1d0(SP), CX														
  type.go:19				0xaa9887		8b91a0510000			MOVL 0x51a0(CX), DX														
  type.go:19				0xaa988d		85d2				TESTL DX, DX															
  db.go:1771				0xaa988f		750a				JNE 0xaa989b															
  type.go:19				0xaa9891		8b91e04d0000			MOVL 0x4de0(CX), DX														
  type.go:19				0xaa9897		85d2				TESTL DX, DX															
  db.go:1771				0xaa9899		7418				JE 0xaa98b3															
  db.go:1772				0xaa989b		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaa98a0		e87b779aff			CALL runtime.deferreturn(SB)													
  db.go:1772				0xaa98a5		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaa98aa		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaa98b1		5d				POPQ BP																
  db.go:1927				0xaa98b2		c3				RET																
  db.go:1774				0xaa98b3		488b9424d8010000		MOVQ 0x1d8(SP), DX														
  db.go:1774				0xaa98bb		4883ba20060000ff		CMPQ 0x620(DX), $-0x1														
  db.go:1774				0xaa98c3		752f				JNE 0xaa98f4															
  db.go:1652				0xaa98c5		4889d3				MOVQ DX, BX															
  db.go:1653				0xaa98c8		4889d6				MOVQ DX, SI															
  db.go:1653				0xaa98cb		48c1ea21			SHRQ $0x21, DX															
  db.go:1653				0xaa98cf		4831d6				XORQ DX, SI															
  db.go:1654				0xaa98d2		48bacd8c55edd7af51ff		MOVQ $0xff51afd7ed558ccd, DX													
  db.go:1654				0xaa98dc		480faff2			IMULQ DX, SI															
  db.go:1655				0xaa98e0		4889f2				MOVQ SI, DX															
  db.go:1655				0xaa98e3		48c1ee21			SHRQ $0x21, SI															
  db.go:1655				0xaa98e7		4831f2				XORQ SI, DX															
  db.go:1656				0xaa98ea		83e20f				ANDL $0xf, DX															
  db.go:1775				0xaa98ed		48899320060000			MOVQ DX, 0x620(BX)														
  db.go:1777				0xaa98f4		90				NOPL																
  db.go:3850				0xaa98f5		48c784249800000000000000	MOVQ $0x0, 0x98(SP)														
  db.go:3851				0xaa9901		488d942498000000		LEAQ 0x98(SP), DX														
  db.go:3852				0xaa9909		4889d3				MOVQ DX, BX															
  db.go:3852				0xaa990c		48c1ea07			SHRQ $0x7, DX															
  db.go:3852				0xaa9910		4831da				XORQ BX, DX															
  db.go:3852				0xaa9913		48c1eb0d			SHRQ $0xd, BX															
  db.go:3852				0xaa9917		4831d3				XORQ DX, BX															
  db.go:3852				0xaa991a		0fb6d3				MOVZX BL, DX															
  type.go:94				0xaa991d		488d1c91			LEAQ 0(CX)(DX*4), BX														
  type.go:94				0xaa9921		488d5b38			LEAQ 0x38(BX), BX														
  db.go:1778				0xaa9925		90				NOPL																
  type.go:94				0xaa9926		be01000000			MOVL $0x1, SI															
  type.go:94				0xaa992b		f00fc133			LOCK XADDL SI, 0(BX)														
  db.go:1779				0xaa992f		90				NOPL																
  type.go:195				0xaa9930		bb01000000			MOVL $0x1, BX															
  type.go:195				0xaa9935		f0480fc19938040000		LOCK XADDQ BX, 0x438(CX)													
  db.go:1780				0xaa993e		488d1d9b0c0000			LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.func1(SB), BX		
  db.go:1780				0xaa9945		48899c2498010000		MOVQ BX, 0x198(SP)														
  db.go:1780				0xaa994d		48898c24a0010000		MOVQ CX, 0x1a0(SP)														
  db.go:1780				0xaa9955		48899424a8010000		MOVQ DX, 0x1a8(SP)														
  db.go:1780				0xaa995d		488d8c2498010000		LEAQ 0x198(SP), CX														
  db.go:1780				0xaa9965		48898c2400010000		MOVQ CX, 0x100(SP)														
  db.go:1780				0xaa996d		488d8424e8000000		LEAQ 0xe8(SP), AX														
  db.go:1780				0xaa9975		e886719aff			CALL runtime.deferprocStack(SB)													
  type.go:19				0xaa997a		488b9424d0010000		MOVQ 0x1d0(SP), DX														
  type.go:19				0xaa9982		8bb2a0510000			MOVL 0x51a0(DX), SI														
  type.go:19				0xaa9988		85f6				TESTL SI, SI															
  db.go:1786				0xaa998a		0f85c9060000			JNE 0xaaa059															
  db.go:1790				0xaa9990		90				NOPL																
  type.go:58				0xaa9991		488b7230			MOVQ 0x30(DX), SI														
  db.go:1791				0xaa9995		4885f6				TESTQ SI, SI															
  db.go:1791				0xaa9998		0f84a3060000			JE 0xaaa041															
  db.go:1791				0xaa999e		488b7e08			MOVQ 0x8(SI), DI														
  db.go:1791				0xaa99a2		4885ff				TESTQ DI, DI															
  db.go:1791				0xaa99a5		0f8496060000			JE 0xaaa041															
  db.go:1791				0xaa99ab		4c8b4610			MOVQ 0x10(SI), R8														
  db.go:1791				0xaa99af		4d85c0				TESTQ R8, R8															
  db.go:1791				0xaa99b2		0f8489060000			JE 0xaaa041															
  db.go:1797				0xaa99b8		498b5830			MOVQ 0x30(R8), BX														
  db.go:1796				0xaa99bc		4c8b4e18			MOVQ 0x18(SI), R9														
  db.go:1798				0xaa99c0		4885db				TESTQ BX, BX															
  db.go:1798				0xaa99c3		410f95c2			SETNE R10															
  rwmutex.go:72				0xaa99c7		440fb69c24e0010000		MOVZX 0x1e0(SP), R11														
  rwmutex.go:72				0xaa99d0		4584db				TESTL R11, R11															
  db.go:1799				0xaa99d3		0f84a0000000			JE 0xaa9a79															
  db.go:1799				0xaa99d9		0f1f8000000000			NOPL 0(AX)															
  db.go:1798				0xaa99e0		4885db				TESTQ BX, BX															
  db.go:1799				0xaa99e3		0f8488000000			JE 0xaa9a71															
  db.go:1800				0xaa99e9		4c8d542430			LEAQ 0x30(SP), R10														
  db.go:1800				0xaa99ee		450f113a			MOVUPS X15, 0(R10)														
  db.go:1800				0xaa99f2		450f117a10			MOVUPS X15, 0x10(R10)														
  db.go:1800				0xaa99f7		450f117a20			MOVUPS X15, 0x20(R10)														
  manager.go:1302			0xaa99fc		4c8da368020000			LEAQ 0x268(BX), R12														
  db.go:1800				0xaa9a03		450f103424			MOVUPS 0(R12), X14														
  db.go:1800				0xaa9a08		450f1132			MOVUPS X14, 0(R10)														
  db.go:1800				0xaa9a0c		450f10742410			MOVUPS 0x10(R12), X14														
  db.go:1800				0xaa9a12		450f117210			MOVUPS X14, 0x10(R10)														
  db.go:1800				0xaa9a17		450f10742420			MOVUPS 0x20(R12), X14														
  db.go:1800				0xaa9a1d		450f117220			MOVUPS X14, 0x20(R10)														
  manager.go:1302			0xaa9a22		80bb9802000000			CMPB 0x298(BX), $0x0														
  db.go:1800				0xaa9a29		4c8d642460			LEAQ 0x60(SP), R12														
  db.go:1800				0xaa9a2e		450f1032			MOVUPS 0(R10), X14														
  db.go:1800				0xaa9a32		450f113424			MOVUPS X14, 0(R12)														
  db.go:1800				0xaa9a37		450f107210			MOVUPS 0x10(R10), X14														
  db.go:1800				0xaa9a3c		450f11742410			MOVUPS X14, 0x10(R12)														
  db.go:1800				0xaa9a42		450f107220			MOVUPS 0x20(R10), X14														
  db.go:1800				0xaa9a47		450f11742420			MOVUPS X14, 0x20(R12)														
  db.go:1800				0xaa9a4d		7418				JE 0xaa9a67															
  db.go:1800				0xaa9a4f		48837c246800			CMPQ 0x68(SP), $0x0														
  db.go:1800				0xaa9a55		750b				JNE 0xaa9a62															
  rwmutex.go:72				0xaa9a57		4584db				TESTL R11, R11															
  rwmutex.go:72				0xaa9a5a		b800000000			MOVL $0x0, AX															
  rwmutex.go:72				0xaa9a5f		90				NOPL																
  db.go:1800				0xaa9a60		eb1a				JMP 0xaa9a7c															
  rwmutex.go:72				0xaa9a62		4584db				TESTL R11, R11															
  db.go:1800				0xaa9a65		eb03				JMP 0xaa9a6a															
  rwmutex.go:72				0xaa9a67		4584db				TESTL R11, R11															
  db.go:1800				0xaa9a6a		b801000000			MOVL $0x1, AX															
  db.go:1800				0xaa9a6f		eb0b				JMP 0xaa9a7c															
  rwmutex.go:72				0xaa9a71		4584db				TESTL R11, R11															
  db.go:1804				0xaa9a74		4489d0				MOVL R10, AX															
  db.go:1799				0xaa9a77		eb03				JMP 0xaa9a7c															
  db.go:1804				0xaa9a79		4489d0				MOVL R10, AX															
  db.go:1804				0xaa9a7c		7409				JE 0xaa9a87															
  db.go:1804				0xaa9a7e		6690				NOPW																
  db.go:1804				0xaa9a80		84c0				TESTL AL, AL															
  db.go:1804				0xaa9a82		7503				JNE 0xaa9a87															
  db.go:1804				0xaa9a84		4531c9				XORL R9, R9															
  type.go:58				0xaa9a87		4889b42470010000		MOVQ SI, 0x170(SP)														
  db.go:1791				0xaa9a8f		4889bc2468010000		MOVQ DI, 0x168(SP)														
  db.go:1791				0xaa9a97		4c89842460010000		MOVQ R8, 0x160(SP)														
  db.go:1797				0xaa9a9f		48899c2450010000		MOVQ BX, 0x150(SP)														
  db.go:1807				0xaa9aa7		4c898c2448010000		MOVQ R9, 0x148(SP)														
  db.go:1804				0xaa9aaf		8844242e			MOVB AL, 0x2e(SP)														
  db.go:1807				0xaa9ab3		c644242f00			MOVB $0x0, 0x2f(SP)														
  db.go:1807				0xaa9ab8		0f1f840000000000		NOPL 0(AX)(AX*1)														
  db.go:1808				0xaa9ac0		4d85c9				TESTQ R9, R9															
  db.go:1808				0xaa9ac3		0f84a7000000			JE 0xaa9b70															
  db.go:1809				0xaa9ac9		4c89c8				MOVQ R9, AX															
  db.go:1809				0xaa9acc		e88fc1d7ff			CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).RetainSnapshotWrapper(SB)					
  db.go:1809				0xaa9ad1		84c0				TESTL AL, AL															
  db.go:1809				0xaa9ad3		0f8450050000			JE 0xaaa029															
  db.go:1812				0xaa9ad9		488d0dc00a0000			LEAQ github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.func2(SB), CX		
  db.go:1812				0xaa9ae0		48898c2478010000		MOVQ CX, 0x178(SP)														
  db.go:1812				0xaa9ae8		488d4c242f			LEAQ 0x2f(SP), CX														
  db.go:1812				0xaa9aed		48898c2480010000		MOVQ CX, 0x180(SP)														
  db.go:1812				0xaa9af5		488b8c24d8010000		MOVQ 0x1d8(SP), CX														
  db.go:1812				0xaa9afd		48898c2488010000		MOVQ CX, 0x188(SP)														
  db.go:1812				0xaa9b05		488b8c2448010000		MOVQ 0x148(SP), CX														
  db.go:1812				0xaa9b0d		48898c2490010000		MOVQ CX, 0x190(SP)														
  db.go:1812				0xaa9b15		488d8c2478010000		LEAQ 0x178(SP), CX														
  db.go:1812				0xaa9b1d		48898c24d0000000		MOVQ CX, 0xd0(SP)														
  db.go:1812				0xaa9b25		488d8424b8000000		LEAQ 0xb8(SP), AX														
  db.go:1812				0xaa9b2d		e8ce6f9aff			CALL runtime.deferprocStack(SB)													
  db.go:1804				0xaa9b32		0fb644242e			MOVZX 0x2e(SP), AX														
  db.go:1874				0xaa9b37		488b9424d0010000		MOVQ 0x1d0(SP), DX														
  db.go:1798				0xaa9b3f		488b9c2450010000		MOVQ 0x150(SP), BX														
  db.go:1881				0xaa9b47		488bb42470010000		MOVQ 0x170(SP), SI														
  db.go:1827				0xaa9b4f		488bbc2468010000		MOVQ 0x168(SP), DI														
  durable_primary_runtime_v5.go:882	0xaa9b57		4c8b842460010000		MOVQ 0x160(SP), R8														
  db.go:1808				0xaa9b5f		4c8b8c2448010000		MOVQ 0x148(SP), R9														
  rwmutex.go:72				0xaa9b67		440fb69c24e0010000		MOVZX 0x1e0(SP), R11														
  db.go:1804				0xaa9b70		84c0				TESTL AL, AL															
  db.go:1818				0xaa9b72		7434				JE 0xaa9ba8															
  db.go:1808				0xaa9b74		4d85c9				TESTQ R9, R9															
  db.go:1819				0xaa9b77		7417				JE 0xaa9b90															
  db.go:1822				0xaa9b79		90				NOPL																
  db.go:1798				0xaa9b7a		4885db				TESTQ BX, BX															
  manager.go:2596			0xaa9b7d		7429				JE 0xaa9ba8															
  type.go:128				0xaa9b7f		41ba01000000			MOVL $0x1, R10															
  type.go:128				0xaa9b85		f04c0fc193a8020000		LOCK XADDQ R10, 0x2a8(BX)													
  manager.go:2597			0xaa9b8e		eb18				JMP 0xaa9ba8															
  db.go:1820				0xaa9b90		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaa9b95		e886749aff			CALL runtime.deferreturn(SB)													
  db.go:1820				0xaa9b9a		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaa9b9f		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaa9ba6		5d				POPQ BP																
  db.go:1927				0xaa9ba7		c3				RET																
  db.go:1827				0xaa9ba8		4c8b5748			MOVQ 0x48(DI), R10														
  db.go:1827				0xaa9bac		4d85d2				TESTQ R10, R10															
  db.go:1827				0xaa9baf		0f844b040000			JE 0xaaa000															
  durable_primary_runtime_v5.go:882	0xaa9bb5		4d8b20				MOVQ 0(R8), R12															
  durable_primary_runtime_v5.go:882	0xaa9bb8		4d85e4				TESTQ R12, R12															
  durable_primary_runtime_v5.go:882	0xaa9bbb		740b				JE 0xaa9bc8															
  durable_primary_runtime_v5.go:882	0xaa9bbd		4d8b642418			MOVQ 0x18(R12), R12														
  durable_primary_runtime_v5.go:882	0xaa9bc2		4d396008			CMPQ 0x8(R8), R12														
  durable_primary_runtime_v5.go:882	0xaa9bc6		7704				JA 0xaa9bcc															
  durable_primary_runtime_v5.go:885	0xaa9bc8		4d8b6008			MOVQ 0x8(R8), R12														
  db.go:1833				0xaa9bcc		488b9424d8010000		MOVQ 0x1d8(SP), DX														
  db.go:1833				0xaa9bd4		488b8a20060000			MOVQ 0x620(DX), CX														
  db.go:1833				0xaa9bdb		4c89d0				MOVQ R10, AX															
  db.go:1833				0xaa9bde		4c89e3				MOVQ R12, BX															
  db.go:1833				0xaa9be1		e83a21e8ff			CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).RegisterWithHint(SB)						
  db.go:1833				0xaa9be6		4889842490000000		MOVQ AX, 0x90(SP)														
  db.go:1833				0xaa9bee		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1833				0xaa9bf6		48899f20060000			MOVQ BX, 0x620(DI)														
  db.go:1835				0xaa9bfd		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1835				0xaa9c05		488b0a				MOVQ 0(DX), CX															
  db.go:1835				0xaa9c08		4885c9				TESTQ CX, CX															
  db.go:1835				0xaa9c0b		7434				JE 0xaa9c41															
  db.go:1836				0xaa9c0d		4889f8				MOVQ DI, AX															
  db.go:1836				0xaa9c10		488b9c2468010000		MOVQ 0x168(SP), BX														
  db.go:1836				0xaa9c18		e863951a00			CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).acquirePrimaryRoot(SB)							
  db.go:1836				0xaa9c1d		0f1f00				NOPL 0(AX)															
  db.go:1836				0xaa9c20		4885c0				TESTQ AX, AX															
  db.go:1836				0xaa9c23		0f856b030000			JNE 0xaa9f94															
  db.go:1899				0xaa9c29		488b842490000000		MOVQ 0x90(SP), AX														
  db.go:1846				0xaa9c31		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1866				0xaa9c39		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1846				0xaa9c41		4c8b4238			MOVQ 0x38(DX), R8														
  db.go:1846				0xaa9c45		4d85c0				TESTQ R8, R8															
  db.go:1846				0xaa9c48		0f84d7020000			JE 0xaa9f25															
  db.go:1847				0xaa9c4e		498b4818			MOVQ 0x18(R8), CX														
  db.go:1847				0xaa9c52		4d8b4820			MOVQ 0x20(R8), R9														
  db.go:1847				0xaa9c56		498b5810			MOVQ 0x10(R8), BX														
  db.go:1847				0xaa9c5a		48898f60030000			MOVQ CX, 0x360(DI)														
  db.go:1847				0xaa9c61		4c898f68030000			MOVQ R9, 0x368(DI)														
  db.go:1847				0xaa9c68		833db138480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1847				0xaa9c6f		7413				JE 0xaa9c84															
  db.go:1847				0xaa9c71		4c8b8758030000			MOVQ 0x358(DI), R8														
  db.go:1847				0xaa9c78		e8e3a59eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1847				0xaa9c7d		49891b				MOVQ BX, 0(R11)															
  db.go:1847				0xaa9c80		4d894308			MOVQ R8, 0x8(R11)														
  db.go:1847				0xaa9c84		48899f58030000			MOVQ BX, 0x358(DI)														
  db.go:1848				0xaa9c8b		4c8b4238			MOVQ 0x38(DX), R8														
  db.go:1848				0xaa9c8f		4d8b5040			MOVQ 0x40(R8), R10														
  db.go:1848				0xaa9c93		4d85d2				TESTQ R10, R10															
  db.go:1848				0xaa9c96		0f8409010000			JE 0xaa9da5															
  db.go:1849				0xaa9c9c		833d7d38480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1849				0xaa9ca3		7505				JNE 0xaa9caa															
  db.go:1848				0xaa9ca5		4d85d2				TESTQ R10, R10															
  db.go:1849				0xaa9ca8		eb16				JMP 0xaa9cc0															
  db.go:1849				0xaa9caa		4c8b87a0030000			MOVQ 0x3a0(DI), R8														
  db.go:1849				0xaa9cb1		e8aaa59eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1849				0xaa9cb6		4d8913				MOVQ R10, 0(R11)														
  db.go:1849				0xaa9cb9		4d894308			MOVQ R8, 0x8(R11)														
  db.go:1848				0xaa9cbd		4d85d2				TESTQ R10, R10															
  db.go:1849				0xaa9cc0		4c8997a0030000			MOVQ R10, 0x3a0(DI)														
  leaf_generation_runtime.go:344	0xaa9cc7		0f849c000000			JE 0xaa9d69															
  leaf_generation_runtime.go:347	0xaa9ccd		488b9c24d0010000		MOVQ 0x1d0(SP), BX														
  leaf_generation_runtime.go:347	0xaa9cd5		4881c338050000			ADDQ $0x538, BX															
  leaf_generation_runtime.go:347	0xaa9cdc		4c89d0				MOVQ R10, AX															
  leaf_generation_runtime.go:347	0xaa9cdf		90				NOPL																
  leaf_generation_runtime.go:347	0xaa9ce0		e81be90e00			CALL github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinSet).retain(SB)							
  leaf_generation_runtime.go:347	0xaa9ce5		84c0				TESTL AL, AL															
  db.go:1850				0xaa9ce7		7468				JE 0xaa9d51															
  db.go:1851				0xaa9ce9		488b8424d8010000		MOVQ 0x1d8(SP), AX														
  db.go:1851				0xaa9cf1		488b9060030000			MOVQ 0x360(AX), DX														
  db.go:1851				0xaa9cf8		4c8b8068030000			MOVQ 0x368(AX), R8														
  db.go:1851				0xaa9cff		4c8b8858030000			MOVQ 0x358(AX), R9														
  db.go:1851				0xaa9d06		48899078030000			MOVQ DX, 0x378(AX)														
  db.go:1851				0xaa9d0d		4c898080030000			MOVQ R8, 0x380(AX)														
  db.go:1851				0xaa9d14		833d0538480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1851				0xaa9d1b		7413				JE 0xaa9d30															
  db.go:1851				0xaa9d1d		488b9070030000			MOVQ 0x370(AX), DX														
  db.go:1851				0xaa9d24		e837a59eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1851				0xaa9d29		4d890b				MOVQ R9, 0(R11)															
  db.go:1851				0xaa9d2c		49895308			MOVQ DX, 0x8(R11)														
  db.go:1851				0xaa9d30		4c898870030000			MOVQ R9, 0x370(AX)														
  db.go:1899				0xaa9d37		488b842490000000		MOVQ 0x90(SP), AX														
  db.go:1876				0xaa9d3f		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1855				0xaa9d47		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1851				0xaa9d4f		eb43				JMP 0xaa9d94															
  db.go:1899				0xaa9d51		488b842490000000		MOVQ 0x90(SP), AX														
  db.go:1876				0xaa9d59		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1853				0xaa9d61		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1853				0xaa9d69		440f11bf78030000		MOVUPS X15, 0x378(DI)														
  db.go:1853				0xaa9d71		833da837480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1853				0xaa9d78		740f				JE 0xaa9d89															
  db.go:1853				0xaa9d7a		4c8b8770030000			MOVQ 0x370(DI), R8														
  db.go:1853				0xaa9d81		e8baa49eff			CALL runtime.gcWriteBarrier1(SB)												
  db.go:1853				0xaa9d86		4d8903				MOVQ R8, 0(R11)															
  db.go:1853				0xaa9d89		48c7877003000000000000		MOVQ $0x0, 0x370(DI)														
  db.go:1855				0xaa9d94		48c7879003000000000000		MOVQ $0x0, 0x390(DI)														
  db.go:1855				0xaa9d9f		90				NOPL																
  db.go:1855				0xaa9da0		e9e1020000			JMP 0xaaa086															
  db.go:1856				0xaa9da5		498b7030			MOVQ 0x30(R8), SI														
  db.go:1856				0xaa9da9		4d8b5028			MOVQ 0x28(R8), R10														
  db.go:1856				0xaa9dad		49397018			CMPQ 0x18(R8), SI														
  db.go:1856				0xaa9db1		0f85f9000000			JNE 0xaa9eb0															
  db.go:1856				0xaa9db7		660f1f840000000000		NOPW 0(AX)(AX*1)														
  db.go:1856				0xaa9dc0		4885f6				TESTQ SI, SI															
  db.go:1856				0xaa9dc3		0f84e7000000			JE 0xaa9eb0															
  db.go:1857				0xaa9dc9		488b8f98030000			MOVQ 0x398(DI), CX														
  db.go:1857				0xaa9dd0		4c8b8788030000			MOVQ 0x388(DI), R8														
  db.go:1857				0xaa9dd7		4839f1				CMPQ CX, SI															
  db.go:1857				0xaa9dda		7206				JB 0xaa9de2															
  db.go:1856				0xaa9ddc		4889f3				MOVQ SI, BX															
  db.go:1856				0xaa9ddf		90				NOPL																
  db.go:1857				0xaa9de0		eb3b				JMP 0xaa9e1d															
  db.go:1856				0xaa9de2		4889b424b0000000		MOVQ SI, 0xb0(SP)														
  db.go:1856				0xaa9dea		4c89942458010000		MOVQ R10, 0x158(SP)														
  db.go:1857				0xaa9df2		4c89c0				MOVQ R8, AX															
  db.go:1857				0xaa9df5		4889f3				MOVQ SI, BX															
  db.go:1857				0xaa9df8		4889df				MOVQ BX, DI															
  db.go:1857				0xaa9dfb		488d351ee30601			LEAQ 0x106e31e(IP), SI														
  db.go:1857				0xaa9e02		e8794f9eff			CALL runtime.growslice(SB)													
  db.go:1857				0xaa9e07		4c8b942458010000		MOVQ 0x158(SP), R10														
  db.go:1857				0xaa9e0f		4989c0				MOVQ AX, R8															
  db.go:1857				0xaa9e12		4889de				MOVQ BX, SI															
  db.go:1857				0xaa9e15		488b9c24b0000000		MOVQ 0xb0(SP), BX														
  db.go:1857				0xaa9e1d		4889b424b0000000		MOVQ SI, 0xb0(SP)														
  db.go:1857				0xaa9e25		4c89842458010000		MOVQ R8, 0x158(SP)														
  db.go:1857				0xaa9e2d		48898c24a8000000		MOVQ CX, 0xa8(SP)														
  db.go:1857				0xaa9e35		488d05e4e20601			LEAQ 0x106e2e4(IP), AX														
  db.go:1857				0xaa9e3c		4889f1				MOVQ SI, CX															
  db.go:1857				0xaa9e3f		4c89d7				MOVQ R10, DI															
  db.go:1857				0xaa9e42		4889de				MOVQ BX, SI															
  db.go:1857				0xaa9e45		4c89c3				MOVQ R8, BX															
  db.go:1857				0xaa9e48		e8930a9eff			CALL runtime.typedslicecopy(SB)													
  db.go:1857				0xaa9e4d		488b9424b0000000		MOVQ 0xb0(SP), DX														
  db.go:1857				0xaa9e55		488b8424d8010000		MOVQ 0x1d8(SP), AX														
  db.go:1857				0xaa9e5d		48899090030000			MOVQ DX, 0x390(AX)														
  db.go:1857				0xaa9e64		4c8b8424a8000000		MOVQ 0xa8(SP), R8														
  db.go:1857				0xaa9e6c		4c898098030000			MOVQ R8, 0x398(AX)														
  db.go:1857				0xaa9e73		833da636480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1857				0xaa9e7a		750a				JNE 0xaa9e86															
  db.go:1857				0xaa9e7c		4c8b8c2458010000		MOVQ 0x158(SP), R9														
  db.go:1857				0xaa9e84		eb1b				JMP 0xaa9ea1															
  db.go:1857				0xaa9e86		4c8b8088030000			MOVQ 0x388(AX), R8														
  db.go:1857				0xaa9e8d		e8cea39eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1857				0xaa9e92		4c8b8c2458010000		MOVQ 0x158(SP), R9														
  db.go:1857				0xaa9e9a		4d890b				MOVQ R9, 0(R11)															
  db.go:1857				0xaa9e9d		4d894308			MOVQ R8, 0x8(R11)														
  db.go:1857				0xaa9ea1		4c898888030000			MOVQ R9, 0x388(AX)														
  db.go:1858				0xaa9ea8		90				NOPL																
  leaf_generation_runtime.go:333	0xaa9ea9		31c9				XORL CX, CX															
  leaf_generation_runtime.go:240	0xaa9eab		e958060000			JMP 0xaaa508															
  db.go:1861				0xaa9eb0		48c7879003000000000000		MOVQ $0x0, 0x390(DI)														
  leaf_generation_runtime.go:319	0xaa9ebb		488b8424d0010000		MOVQ 0x1d0(SP), AX														
  leaf_generation_runtime.go:319	0xaa9ec3		480538050000			ADDQ $0x538, AX															
  db.go:1862				0xaa9ec9		90				NOPL																
  leaf_generation_runtime.go:319	0xaa9eca		4c89cf				MOVQ R9, DI															
  leaf_generation_runtime.go:319	0xaa9ecd		e8eef30e00			CALL github.com/snissn/gomap/TreeDB/db.(*leafGenerationPinTracker).pin(SB)							
  db.go:1863				0xaa9ed2		488b8424d8010000		MOVQ 0x1d8(SP), AX														
  db.go:1863				0xaa9eda		488b9060030000			MOVQ 0x360(AX), DX														
  db.go:1863				0xaa9ee1		488bb068030000			MOVQ 0x368(AX), SI														
  db.go:1863				0xaa9ee8		4c8b8058030000			MOVQ 0x358(AX), R8														
  db.go:1863				0xaa9eef		48899078030000			MOVQ DX, 0x378(AX)														
  db.go:1863				0xaa9ef6		4889b080030000			MOVQ SI, 0x380(AX)														
  db.go:1863				0xaa9efd		833d1c36480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1863				0xaa9f04		7413				JE 0xaa9f19															
  db.go:1863				0xaa9f06		488b9070030000			MOVQ 0x370(AX), DX														
  db.go:1863				0xaa9f0d		e84ea39eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1863				0xaa9f12		4d8903				MOVQ R8, 0(R11)															
  db.go:1863				0xaa9f15		49895308			MOVQ DX, 0x8(R11)														
  db.go:1863				0xaa9f19		4c898070030000			MOVQ R8, 0x370(AX)														
  db.go:1863				0xaa9f20		e9c0050000			JMP 0xaaa4e5															
  db.go:1866				0xaa9f25		440f11bf60030000		MOVUPS X15, 0x360(DI)														
  db.go:1866				0xaa9f2d		833dec35480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1866				0xaa9f34		7425				JE 0xaa9f5b															
  db.go:1866				0xaa9f36		4c8b8758030000			MOVQ 0x358(DI), R8														
  db.go:1867				0xaa9f3d		4c8b8f70030000			MOVQ 0x370(DI), R9														
  db.go:1869				0xaa9f44		4c8b97a0030000			MOVQ 0x3a0(DI), R10														
  db.go:1866				0xaa9f4b		e830a39eff			CALL runtime.gcWriteBarrier3(SB)												
  db.go:1866				0xaa9f50		4d8903				MOVQ R8, 0(R11)															
  db.go:1867				0xaa9f53		4d894b08			MOVQ R9, 0x8(R11)														
  db.go:1869				0xaa9f57		4d895310			MOVQ R10, 0x10(R11)														
  db.go:1866				0xaa9f5b		48c7875803000000000000		MOVQ $0x0, 0x358(DI)														
  db.go:1867				0xaa9f66		440f11bf78030000		MOVUPS X15, 0x378(DI)														
  db.go:1867				0xaa9f6e		48c7877003000000000000		MOVQ $0x0, 0x370(DI)														
  db.go:1868				0xaa9f79		48c7879003000000000000		MOVQ $0x0, 0x390(DI)														
  db.go:1869				0xaa9f84		48c787a003000000000000		MOVQ $0x0, 0x3a0(DI)														
  db.go:1869				0xaa9f8f		e9f2000000			JMP 0xaaa086															
  db.go:1837				0xaa9f94		488b9c2490000000		MOVQ 0x90(SP), BX														
  db.go:1837				0xaa9f9c		0f1f4000			NOPL 0(AX)															
  db.go:1837				0xaa9fa0		4885db				TESTQ BX, BX															
  db.go:1837				0xaa9fa3		7509				JNE 0xaa9fae															
  db.go:1804				0xaa9fa5		0fb64c242e			MOVZX 0x2e(SP), CX														
  db.go:1804				0xaa9faa		84c9				TESTL CL, CL															
  db.go:1837				0xaa9fac		eb18				JMP 0xaa9fc6															
  db.go:1838				0xaa9fae		488b8c2468010000		MOVQ 0x168(SP), CX														
  db.go:1838				0xaa9fb6		488b4148			MOVQ 0x48(CX), AX														
  db.go:1838				0xaa9fba		e86123e8ff			CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister(SB)							
  db.go:1804				0xaa9fbf		0fb64c242e			MOVZX 0x2e(SP), CX														
  db.go:1804				0xaa9fc4		84c9				TESTL CL, CL															
  db.go:1840				0xaa9fc6		741d				JE 0xaa9fe5															
  db.go:1808				0xaa9fc8		488b842448010000		MOVQ 0x148(SP), AX														
  db.go:1808				0xaa9fd0		4885c0				TESTQ AX, AX															
  db.go:1840				0xaa9fd3		7410				JE 0xaa9fe5															
  db.go:1841				0xaa9fd5		488b9c2450010000		MOVQ 0x150(SP), BX														
  db.go:1841				0xaa9fdd		0f1f00				NOPL 0(AX)															
  db.go:1841				0xaa9fe0		e85b66d7ff			CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).Release(SB)							
  db.go:1843				0xaa9fe5		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaa9fea		e831709aff			CALL runtime.deferreturn(SB)													
  db.go:1843				0xaa9fef		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaa9ff4		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaa9ffb		5d				POPQ BP																
  db.go:1927				0xaa9ffc		c3				RET																
  db.go:1927				0xaa9ffd		0f1f00				NOPL 0(AX)															
  db.go:1804				0xaaa000		84c0				TESTL AL, AL															
  db.go:1828				0xaaa002		740d				JE 0xaaa011															
  db.go:1808				0xaaa004		4d85c9				TESTQ R9, R9															
  db.go:1828				0xaaa007		7408				JE 0xaaa011															
  db.go:1829				0xaaa009		4c89c8				MOVQ R9, AX															
  db.go:1829				0xaaa00c		e82f66d7ff			CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).Release(SB)							
  db.go:1831				0xaaa011		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaaa016		e805709aff			CALL runtime.deferreturn(SB)													
  db.go:1831				0xaaa01b		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa020		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa027		5d				POPQ BP																
  db.go:1927				0xaaa028		c3				RET																
  db.go:1810				0xaaa029		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaaa02e		e8ed6f9aff			CALL runtime.deferreturn(SB)													
  db.go:1810				0xaaa033		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa038		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa03f		5d				POPQ BP																
  db.go:1927				0xaaa040		c3				RET																
  db.go:1792				0xaaa041		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1927				0xaaa046		e8d56f9aff			CALL runtime.deferreturn(SB)													
  db.go:1792				0xaaa04b		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa050		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa057		5d				POPQ BP																
  db.go:1927				0xaaa058		c3				RET																
  db.go:1787				0xaaa059		c644242d00			MOVB $0x0, 0x2d(SP)														
  db.go:1787				0xaaa05e		6690				NOPW																
  db.go:1927				0xaaa060		e8bb6f9aff			CALL runtime.deferreturn(SB)													
  db.go:1787				0xaaa065		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa06a		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa071		5d				POPQ BP																
  db.go:1927				0xaaa072		c3				RET																
  db.go:1927				0xaaa073		e8a86f9aff			CALL runtime.deferreturn(SB)													
  db.go:1770				0xaaa078		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa07d		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa084		5d				POPQ BP																
  db.go:1927				0xaaa085		c3				RET																
  db.go:1872				0xaaa086		90				NOPL																
  type.go:195				0xaaa087		41b801000000			MOVL $0x1, R8															
  type.go:195				0xaaa08d		4c8b8c2468010000		MOVQ 0x168(SP), R9														
  type.go:195				0xaaa095		f04d0fc14168			LOCK XADDQ R8, 0x68(R9)														
  type.go:195				0xaaa09b		49ffc0				INCQ R8																
  index_gen.go:236			0xaaa09e		490fbaf03f			BTRQ $0x3f, R8															
  index_gen.go:236			0xaaa0a3		4d85c0				TESTQ R8, R8															
  index_gen.go:236			0xaaa0a6		0f8426040000			JE 0xaaa4d2															
  db.go:1873				0xaaa0ac		c687d002000001			MOVB $0x1, 0x2d0(DI)														
  db.go:1874				0xaaa0b3		833d6634480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1874				0xaaa0ba		7515				JNE 0xaaa0d1															
  db.go:1808				0xaaa0bc		4c8b842448010000		MOVQ 0x148(SP), R8														
  db.go:1808				0xaaa0c4		4d85c0				TESTQ R8, R8															
  db.go:1874				0xaaa0c7		4c8bac24d0010000		MOVQ 0x1d0(SP), R13														
  db.go:1874				0xaaa0cf		eb56				JMP 0xaaa127															
  db.go:1874				0xaaa0d1		4c8b8728030000			MOVQ 0x328(DI), R8														
  db.go:1875				0xaaa0d8		4c8b9730030000			MOVQ 0x330(DI), R10														
  db.go:1876				0xaaa0df		4c8b9f38030000			MOVQ 0x338(DI), R11														
  db.go:1877				0xaaa0e6		4c8ba740030000			MOVQ 0x340(DI), R12														
  db.go:1876				0xaaa0ed		4c89d9				MOVQ R11, CX															
  db.go:1874				0xaaa0f0		e82ba29eff			CALL runtime.gcWriteBarrier8(SB)												
  db.go:1874				0xaaa0f5		4c8bac24d0010000		MOVQ 0x1d0(SP), R13														
  db.go:1874				0xaaa0fd		4d892b				MOVQ R13, 0(R11)														
  db.go:1874				0xaaa100		4d894308			MOVQ R8, 0x8(R11)														
  db.go:1875				0xaaa104		4d894b10			MOVQ R9, 0x10(R11)														
  db.go:1875				0xaaa108		4d895318			MOVQ R10, 0x18(R11)														
  db.go:1876				0xaaa10c		49895320			MOVQ DX, 0x20(R11)														
  db.go:1876				0xaaa110		49894b28			MOVQ CX, 0x28(R11)														
  db.go:1877				0xaaa114		4c8b842448010000		MOVQ 0x148(SP), R8														
  db.go:1877				0xaaa11c		4d894330			MOVQ R8, 0x30(R11)														
  db.go:1877				0xaaa120		4d896338			MOVQ R12, 0x38(R11)														
  db.go:1808				0xaaa124		4d85c0				TESTQ R8, R8															
  db.go:1874				0xaaa127		4c89af28030000			MOVQ R13, 0x328(DI)														
  db.go:1875				0xaaa12e		4c898f30030000			MOVQ R9, 0x330(DI)														
  db.go:1876				0xaaa135		48899738030000			MOVQ DX, 0x338(DI)														
  db.go:1877				0xaaa13c		4c898740030000			MOVQ R8, 0x340(DI)														
  db.go:1878				0xaaa143		0f958748030000			SETNE 0x348(DI)															
  db.go:1879				0xaaa14a		c644242f01			MOVB $0x1, 0x2f(SP)														
  db.go:1880				0xaaa14f		440fb644242e			MOVZX 0x2e(SP), R8														
  db.go:1880				0xaaa155		44888749030000			MOVB R8, 0x349(DI)														
  db.go:1881				0xaaa15c		4c8b942470010000		MOVQ 0x170(SP), R10														
  db.go:1881				0xaaa164		4d8b5a20			MOVQ 0x20(R10), R11														
  db.go:1881				0xaaa168		4c899f50030000			MOVQ R11, 0x350(DI)														
  rwmutex.go:72				0xaaa16f		440fb69c24e0010000		MOVZX 0x1e0(SP), R11														
  rwmutex.go:72				0xaaa178		4584db				TESTL R11, R11															
  db.go:1882				0xaaa17b		745d				JE 0xaaa1da															
  db.go:1882				0xaaa17d		0f1f00				NOPL 0(AX)															
  db.go:1804				0xaaa180		4584c0				TESTL R8, R8															
  db.go:1882				0xaaa183		7555				JNE 0xaaa1da															
  db.go:1886				0xaaa185		4d8b8568040000			MOVQ 0x468(R13), R8														
  value_reader.go:56			0xaaa18c		48c787b003000000000000		MOVQ $0x0, 0x3b0(DI)														
  value_reader.go:56			0xaaa197		833d8233480200			CMPL runtime.writeBarrier(SB), $0x0												
  value_reader.go:56			0xaaa19e		6690				NOPW																
  value_reader.go:56			0xaaa1a0		7424				JE 0xaaa1c6															
  value_reader.go:56			0xaaa1a2		4c8ba7b8030000			MOVQ 0x3b8(DI), R12														
  value_reader.go:57			0xaaa1a9		4c8bafc0030000			MOVQ 0x3c0(DI), R13														
  rwmutex.go:72				0xaaa1b0		4489d9				MOVL R11, CX															
  value_reader.go:56			0xaaa1b3		e8c8a09eff			CALL runtime.gcWriteBarrier3(SB)												
  value_reader.go:56			0xaaa1b8		4d8923				MOVQ R12, 0(R11)														
  value_reader.go:57			0xaaa1bb		4d894308			MOVQ R8, 0x8(R11)														
  value_reader.go:57			0xaaa1bf		4d896b10			MOVQ R13, 0x10(R11)														
  rwmutex.go:72				0xaaa1c3		4189cb				MOVL CX, R11															
  value_reader.go:56			0xaaa1c6		48c787b803000000000000		MOVQ $0x0, 0x3b8(DI)														
  value_reader.go:57			0xaaa1d1		4c8987c0030000			MOVQ R8, 0x3c0(DI)														
  db.go:1886				0xaaa1d8		eb69				JMP 0xaaa243															
  db.go:1888				0xaaa1da		4d8b8568040000			MOVQ 0x468(R13), R8														
  value_reader.go:56			0xaaa1e1		4c8d25387f4101			LEAQ go:itab.*github.com/snissn/gomap/TreeDB/internal/valuelog.Set,github.com/snissn/gomap/TreeDB/tree.SlabReader(SB), R12	
  value_reader.go:56			0xaaa1e8		4c89a7b0030000			MOVQ R12, 0x3b0(DI)														
  value_reader.go:56			0xaaa1ef		833d2a33480200			CMPL runtime.writeBarrier(SB), $0x0												
  value_reader.go:56			0xaaa1f6		750d				JNE 0xaaa205															
  rwmutex.go:72				0xaaa1f8		4489d9				MOVL R11, CX															
  value_reader.go:56			0xaaa1fb		4c8bbc2450010000		MOVQ 0x150(SP), R15														
  value_reader.go:56			0xaaa203		eb2d				JMP 0xaaa232															
  value_reader.go:56			0xaaa205		4c8ba7b8030000			MOVQ 0x3b8(DI), R12														
  value_reader.go:57			0xaaa20c		4c8bafc0030000			MOVQ 0x3c0(DI), R13														
  rwmutex.go:72				0xaaa213		4489d9				MOVL R11, CX															
  value_reader.go:56			0xaaa216		e885a09eff			CALL runtime.gcWriteBarrier4(SB)												
  value_reader.go:56			0xaaa21b		4c8bbc2450010000		MOVQ 0x150(SP), R15														
  value_reader.go:56			0xaaa223		4d893b				MOVQ R15, 0(R11)														
  value_reader.go:56			0xaaa226		4d896308			MOVQ R12, 0x8(R11)														
  value_reader.go:57			0xaaa22a		4d894310			MOVQ R8, 0x10(R11)														
  value_reader.go:57			0xaaa22e		4d896b18			MOVQ R13, 0x18(R11)														
  value_reader.go:56			0xaaa232		4c89bfb8030000			MOVQ R15, 0x3b8(DI)														
  value_reader.go:57			0xaaa239		4c8987c0030000			MOVQ R8, 0x3c0(DI)														
  rwmutex.go:72				0xaaa240		4189cb				MOVL CX, R11															
  db.go:1890				0xaaa243		4c8b87c0050000			MOVQ 0x5c0(DI), R8														
  db.go:1890				0xaaa24a		4c898424b0000000		MOVQ R8, 0xb0(SP)														
  db.go:1890				0xaaa252		31c9				XORL CX, CX															
  db.go:1890				0xaaa254		eb6a				JMP 0xaaa2c0															
  db.go:1890				0xaaa256		48898c24a0000000		MOVQ CX, 0xa0(SP)														
  db.go:1892				0xaaa25e		488b97b8050000			MOVQ 0x5b8(DI), DX														
  db.go:1892				0xaaa265		4a8d042a			LEAQ 0(DX)(R13*1), AX														
  db.go:1892				0xaaa269		488d4008			LEAQ 0x8(AX), AX														
  db.go:1892				0xaaa26d		31db				XORL BX, BX															
  db.go:1892				0xaaa26f		31c9				XORL CX, CX															
  db.go:1892				0xaaa271		31ff				XORL DI, DI															
  db.go:1892				0xaaa273		31f6				XORL SI, SI															
  db.go:1892				0xaaa275		e886bcc2ff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB)									
  db.go:1890				0xaaa27a		488b8c24a0000000		MOVQ 0xa0(SP), CX														
  db.go:1890				0xaaa282		48ffc1				INCQ CX																
  db.go:1899				0xaaa285		488b842490000000		MOVQ 0x90(SP), AX														
  db.go:1902				0xaaa28d		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1891				0xaaa295		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1890				0xaaa29d		4c8b8424b0000000		MOVQ 0xb0(SP), R8														
  db.go:1901				0xaaa2a5		4c8b8c2468010000		MOVQ 0x168(SP), R9														
  db.go:1915				0xaaa2ad		4c8b942470010000		MOVQ 0x170(SP), R10														
  rwmutex.go:72				0xaaa2b5		440fb69c24e0010000		MOVZX 0x1e0(SP), R11														
  rwmutex.go:72				0xaaa2be		6690				NOPW																
  db.go:1890				0xaaa2c0		4c39c1				CMPQ CX, R8															
  db.go:1890				0xaaa2c3		7d40				JGE 0xaaa305															
  db.go:1891				0xaaa2c5		4c8ba7c0050000			MOVQ 0x5c0(DI), R12														
  db.go:1891				0xaaa2cc		4c39e1				CMPQ CX, R12															
  db.go:1891				0xaaa2cf		0f83f8010000			JAE 0xaaa4cd															
  db.go:1891				0xaaa2d5		4c8ba7b8050000			MOVQ 0x5b8(DI), R12														
  db.go:1891				0xaaa2dc		4c69e9f8000000			IMULQ $0xf8, CX, R13														
  db.go:1891				0xaaa2e3		4bc7042c00000000		MOVQ $0x0, 0(R12)(R13*1)													
  db.go:1892				0xaaa2eb		4c8ba7c0050000			MOVQ 0x5c0(DI), R12														
  db.go:1892				0xaaa2f2		4c39e1				CMPQ CX, R12															
  db.go:1892				0xaaa2f5		0f825bffffff			JB 0xaaa256															
  db.go:1892				0xaaa2fb		0f1f440000			NOPL 0(AX)(AX*1)														
  db.go:1892				0xaaa300		e9c3010000			JMP 0xaaa4c8															
  db.go:1894				0xaaa305		4883bfc805000010		CMPQ 0x5c8(DI), $0x10														
  db.go:1894				0xaaa30d		7e35				JLE 0xaaa344															
  db.go:1895				0xaaa30f		440f11bfc0050000		MOVUPS X15, 0x5c0(DI)														
  db.go:1895				0xaaa317		833d0232480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1895				0xaaa31e		6690				NOPW																
  db.go:1895				0xaaa320		7415				JE 0xaaa337															
  db.go:1895				0xaaa322		4c8b87b8050000			MOVQ 0x5b8(DI), R8														
  rwmutex.go:72				0xaaa329		4489d9				MOVL R11, CX															
  db.go:1895				0xaaa32c		e80f9f9eff			CALL runtime.gcWriteBarrier1(SB)												
  db.go:1895				0xaaa331		4d8903				MOVQ R8, 0(R11)															
  rwmutex.go:72				0xaaa334		4189cb				MOVL CX, R11															
  db.go:1895				0xaaa337		48c787b805000000000000		MOVQ $0x0, 0x5b8(DI)														
  db.go:1895				0xaaa342		eb0b				JMP 0xaaa34f															
  db.go:1897				0xaaa344		48c787c005000000000000		MOVQ $0x0, 0x5c0(DI)														
  db.go:1899				0xaaa34f		488987a8030000			MOVQ AX, 0x3a8(DI)														
  db.go:1901				0xaaa356		498b5930			MOVQ 0x30(R9), BX														
  db.go:1901				0xaaa35a		660f1f440000			NOPW 0(AX)(AX*1)														
  db.go:1901				0xaaa360		48399f10060000			CMPQ 0x610(DI), BX														
  db.go:1901				0xaaa367		7511				JNE 0xaaa37a															
  db.go:1902				0xaaa369		4c8b8718060000			MOVQ 0x618(DI), R8														
  db.go:1902				0xaaa370		4c394210			CMPQ 0x10(DX), R8														
  db.go:1903				0xaaa374		0f8486000000			JE 0xaaa400															
  db.go:1904				0xaaa37a		488d87c8030000			LEAQ 0x3c8(DI), AX														
  db.go:1904				0xaaa381		4881c7b0030000			ADDQ $0x3b0, DI															
  db.go:1904				0xaaa388		488b7210			MOVQ 0x10(DX), SI														
  db.go:1904				0xaaa38c		488d0dcd794101			LEAQ go:itab.*github.com/snissn/gomap/TreeDB/db.valueReader,github.com/snissn/gomap/TreeDB/tree.SlabReader(SB), CX		
  db.go:1904				0xaaa393		e868bbc2ff			CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB)									
  db.go:1905				0xaaa398		488b942468010000		MOVQ 0x168(SP), DX														
  db.go:1905				0xaaa3a0		488b5230			MOVQ 0x30(DX), DX														
  db.go:1905				0xaaa3a4		833d7531480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1905				0xaaa3ab		750a				JNE 0xaaa3b7															
  db.go:1905				0xaaa3ad		488b8424d8010000		MOVQ 0x1d8(SP), AX														
  db.go:1905				0xaaa3b5		eb1b				JMP 0xaaa3d2															
  db.go:1905				0xaaa3b7		488b8424d8010000		MOVQ 0x1d8(SP), AX														
  db.go:1905				0xaaa3bf		488b8810060000			MOVQ 0x610(AX), CX														
  db.go:1905				0xaaa3c6		e8959e9eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1905				0xaaa3cb		498913				MOVQ DX, 0(R11)															
  db.go:1905				0xaaa3ce		49894b08			MOVQ CX, 0x8(R11)														
  db.go:1905				0xaaa3d2		48899010060000			MOVQ DX, 0x610(AX)														
  db.go:1906				0xaaa3d9		488b8c2460010000		MOVQ 0x160(SP), CX														
  db.go:1906				0xaaa3e1		488b4910			MOVQ 0x10(CX), CX														
  db.go:1906				0xaaa3e5		48898818060000			MOVQ CX, 0x618(AX)														
  negative_filter.go:55			0xaaa3ec		4889c7				MOVQ AX, DI															
  db.go:1915				0xaaa3ef		4c8b942470010000		MOVQ 0x170(SP), R10														
  rwmutex.go:72				0xaaa3f7		440fb69c24e0010000		MOVZX 0x1e0(SP), R11														
  db.go:1915				0xaaa400		498b0a				MOVQ 0(R10), CX															
  negative_filter.go:55			0xaaa403		833d1631480200			CMPL runtime.writeBarrier(SB), $0x0												
  negative_filter.go:55			0xaaa40a		7505				JNE 0xaaa411															
  rwmutex.go:72				0xaaa40c		4584db				TESTL R11, R11															
  negative_filter.go:55			0xaaa40f		eb20				JMP 0xaaa431															
  negative_filter.go:55			0xaaa411		488b97c8030000			MOVQ 0x3c8(DI), DX														
  rwmutex.go:72				0xaaa418		4489d8				MOVL R11, AX															
  rwmutex.go:72				0xaaa41b		0f1f440000			NOPL 0(AX)(AX*1)														
  negative_filter.go:55			0xaaa420		e83b9e9eff			CALL runtime.gcWriteBarrier2(SB)												
  negative_filter.go:55			0xaaa425		49890b				MOVQ CX, 0(R11)															
  negative_filter.go:55			0xaaa428		49895308			MOVQ DX, 0x8(R11)														
  rwmutex.go:72				0xaaa42c		84c0				TESTL AL, AL															
  rwmutex.go:72				0xaaa42e		4189c3				MOVL AX, R11															
  negative_filter.go:55			0xaaa431		48898fc8030000			MOVQ CX, 0x3c8(DI)														
  db.go:1918				0xaaa438		753d				JNE 0xaaa477															
  db.go:1919				0xaaa43a		90				NOPL																
  mutex.go:63				0xaaa43b		31c0				XORL AX, AX															
  mutex.go:63				0xaaa43d		b901000000			MOVL $0x1, CX															
  mutex.go:63				0xaaa442		f00fb18ff0050000		LOCK CMPXCHGL CX, 0x5f0(DI)													
  mutex.go:63				0xaaa44a		0f94c1				SETE CL																
  mutex.go:63				0xaaa44d		84c9				TESTL CL, CL															
  mutex.go:63				0xaaa44f		7405				JE 0xaaa456															
  rwmutex.go:72				0xaaa451		4584db				TESTL R11, R11															
  mutex.go:46				0xaaa454		eb21				JMP 0xaaa477															
  mutex.go:46				0xaaa456		488d87f0050000			LEAQ 0x5f0(DI), AX														
  mutex.go:70				0xaaa45d		0f1f00				NOPL 0(AX)															
  mutex.go:70				0xaaa460		e87b1e9fff			CALL internal/sync.(*Mutex).lockSlow(SB)											
  rwmutex.go:72				0xaaa465		0fb68c24e0010000		MOVZX 0x1e0(SP), CX														
  rwmutex.go:72				0xaaa46d		84c9				TESTL CL, CL															
  type.go:22				0xaaa46f		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1921				0xaaa477		90				NOPL																
  type.go:22				0xaaa478		b900000000			MOVL $0x0, CX															
  type.go:22				0xaaa47d		878fd0050000			XCHGL CX, 0x5d0(DI)														
  db.go:1922				0xaaa483		90				NOPL																
  type.go:184				0xaaa484		b900000000			MOVL $0x0, CX															
  type.go:184				0xaaa489		48878fe8050000			XCHGQ CX, 0x5e8(DI)														
  db.go:1923				0xaaa490		751e				JNE 0xaaa4b0															
  db.go:1924				0xaaa492		90				NOPL																
  mutex.go:194				0xaaa493		bbffffffff			MOVL $-0x1, BX															
  mutex.go:194				0xaaa498		f00fc19ff0050000		LOCK XADDL BX, 0x5f0(DI)													
  mutex.go:194				0xaaa4a0		ffcb				DECL BX																
  mutex.go:195				0xaaa4a2		740c				JE 0xaaa4b0															
  mutex.go:65				0xaaa4a4		488d87f0050000			LEAQ 0x5f0(DI), AX														
  mutex.go:198				0xaaa4ab		e810219fff			CALL internal/sync.(*Mutex).unlockSlow(SB)											
  db.go:1926				0xaaa4b0		c644242d01			MOVB $0x1, 0x2d(SP)														
  db.go:1927				0xaaa4b5		e8666b9aff			CALL runtime.deferreturn(SB)													
  db.go:1926				0xaaa4ba		0fb644242d			MOVZX 0x2d(SP), AX														
  db.go:1927				0xaaa4bf		4881c4c0010000			ADDQ $0x1c0, SP															
  db.go:1927				0xaaa4c6		5d				POPQ BP																
  db.go:1927				0xaaa4c7		c3				RET																
  db.go:1892				0xaaa4c8		e833a19eff			CALL runtime.panicBounds(SB)													
  db.go:1891				0xaaa4cd		e82ea19eff			CALL runtime.panicBounds(SB)													
  index_gen.go:237			0xaaa4d2		488d05c73b0b01			LEAQ 0x10b3bc7(IP), AX														
  index_gen.go:237			0xaaa4d9		488d1d607d4001			LEAQ 0x1407d60(IP), BX														
  index_gen.go:237			0xaaa4e0		e8fb1c9eff			CALL runtime.gopanic(SB)													
  db.go:1899				0xaaa4e5		488b842490000000		MOVQ 0x90(SP), AX														
  db.go:1876				0xaaa4ed		488b942460010000		MOVQ 0x160(SP), DX														
  db.go:1873				0xaaa4f5		488bbc24d8010000		MOVQ 0x1d8(SP), DI														
  db.go:1873				0xaaa4fd		0f1f00				NOPL 0(AX)															
  db.go:1873				0xaaa500		e981fbffff			JMP 0xaaa086															
  leaf_generation_runtime.go:240	0xaaa505		48ffc1				INCQ CX																
  leaf_generation_runtime.go:240	0xaaa508		4839d1				CMPQ CX, DX															
  leaf_generation_runtime.go:240	0xaaa50b		7d17				JGE 0xaaa524															
  leaf_generation_runtime.go:240	0xaaa50d		4d8b04c9			MOVQ 0(R9)(CX*8), R8														
  leaf_generation_runtime.go:241	0xaaa511		4d85c0				TESTQ R8, R8															
  leaf_generation_runtime.go:241	0xaaa514		74ef				JE 0xaaa505															
  type.go:128				0xaaa516		41ba01000000			MOVL $0x1, R10															
  type.go:128				0xaaa51c		f04d0fc15008			LOCK XADDQ R10, 0x8(R8)														
  leaf_generation_runtime.go:244	0xaaa522		ebe1				JMP 0xaaa505															
  db.go:1859				0xaaa524		488b9060030000			MOVQ 0x360(AX), DX														
  db.go:1859				0xaaa52b		4c8b8068030000			MOVQ 0x368(AX), R8														
  db.go:1859				0xaaa532		4c8b8858030000			MOVQ 0x358(AX), R9														
  db.go:1859				0xaaa539		48899078030000			MOVQ DX, 0x378(AX)														
  db.go:1859				0xaaa540		4c898080030000			MOVQ R8, 0x380(AX)														
  db.go:1859				0xaaa547		833dd22f480200			CMPL runtime.writeBarrier(SB), $0x0												
  db.go:1859				0xaaa54e		7413				JE 0xaaa563															
  db.go:1859				0xaaa550		488b9070030000			MOVQ 0x370(AX), DX														
  db.go:1859				0xaaa557		e8049d9eff			CALL runtime.gcWriteBarrier2(SB)												
  db.go:1859				0xaaa55c		4d890b				MOVQ R9, 0(R11)															
  db.go:1859				0xaaa55f		49895308			MOVQ DX, 0x8(R11)														
  db.go:1859				0xaaa563		4c898870030000			MOVQ R9, 0x370(AX)														
  db.go:1859				0xaaa56a		e976ffffff			JMP 0xaaa4e5															
  db.go:1768				0xaaa56f		4889442408			MOVQ AX, 0x8(SP)														
  db.go:1768				0xaaa574		48895c2410			MOVQ BX, 0x10(SP)														
  db.go:1768				0xaaa579		884c2418			MOVB CL, 0x18(SP)														
  db.go:1768				0xaaa57d		0f1f00				NOPL 0(AX)															
  db.go:1768				0xaaa580		e8db819eff			CALL runtime.morestack_noctxt.abi0(SB)												
  db.go:1768				0xaaa585		488b442408			MOVQ 0x8(SP), AX														
  db.go:1768				0xaaa58a		488b5c2410			MOVQ 0x10(SP), BX														
  db.go:1768				0xaaa58f		0fb64c2418			MOVZX 0x18(SP), CX														
  db.go:1768				0xaaa594		e947f2ffff			JMP github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld(SB)				

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.func2(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:1812		0xaaa5a0		493b6610		CMPQ SP, 0x10(R14)												
  db.go:1812		0xaaa5a4		762a			JBE 0xaaa5d0													
  db.go:1812		0xaaa5a6		55			PUSHQ BP													
  db.go:1812		0xaaa5a7		4889e5			MOVQ SP, BP													
  db.go:1812		0xaaa5aa		4883ec10		SUBQ $0x10, SP													
  db.go:1812		0xaaa5ae		488b4a08		MOVQ 0x8(DX), CX												
  db.go:1813		0xaaa5b2		803900			CMPB 0(CX), $0x0												
  db.go:1813		0xaaa5b5		7513			JNE 0xaaa5ca													
  db.go:1812		0xaaa5b7		488b4210		MOVQ 0x10(DX), AX												
  db.go:1814		0xaaa5bb		8400			TESTB AL, 0(AX)													
  db.go:1812		0xaaa5bd		488b5a18		MOVQ 0x18(DX), BX												
  db.go:1814		0xaaa5c1		4883c058		ADDQ $0x58, AX													
  db.go:1814		0xaaa5c5		e816bbd7ff		CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*ManagerWrapperReleaseWork).ReleaseOriginal(SB)		
  db.go:1816		0xaaa5ca		4883c410		ADDQ $0x10, SP													
  db.go:1816		0xaaa5ce		5d			POPQ BP														
  db.go:1816		0xaaa5cf		c3			RET														
  db.go:1812		0xaaa5d0		e8eb809eff		CALL runtime.morestack.abi0(SB)											
  db.go:1812		0xaaa5d5		ebc9			JMP github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.func2(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.func1(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:1780		0xaaa5e0		55			PUSHQ BP			
  db.go:1780		0xaaa5e1		4889e5			MOVQ SP, BP			
  db.go:1780		0xaaa5e4		488b4210		MOVQ 0x10(DX), AX		
  db.go:1780		0xaaa5e8		488b4a08		MOVQ 0x8(DX), CX		
  db.go:1783		0xaaa5ec		90			NOPL				
  type.go:195		0xaaa5ed		ba01000000		MOVL $0x1, DX			
  type.go:195		0xaaa5f2		f0480fc19138040000	LOCK XADDQ DX, 0x438(CX)	
  type.go:195		0xaaa5fb		0f1f440000		NOPL 0(AX)(AX*1)		
  db.go:1784		0xaaa600		483d00010000		CMPQ AX, $0x100			
  db.go:1784		0xaaa606		7313			JAE 0xaaa61b			
  type.go:94		0xaaa608		488d0481		LEAQ 0(CX)(AX*4), AX		
  type.go:94		0xaaa60c		488d4038		LEAQ 0x38(AX), AX		
  type.go:94		0xaaa610		b9ffffffff		MOVL $-0x1, CX			
  type.go:94		0xaaa615		f00fc108		LOCK XADDL CX, 0(AX)		
  db.go:1785		0xaaa619		5d			POPQ BP				
  db.go:1785		0xaaa61a		c3			RET				
  db.go:1784		0xaaa61b		48c7c100010000		MOVQ $0x100, CX			
  db.go:1784		0xaaa622		e8d99f9eff		CALL runtime.panicBounds(SB)	
  db.go:1784		0xaaa627		90			NOPL				

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.deferwrap1(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:1770		0xaaa640		493b6610		CMPQ SP, 0x10(R14)													
  db.go:1770		0xaaa644		7629			JBE 0xaaa66f														
  db.go:1770		0xaaa646		55			PUSHQ BP														
  db.go:1770		0xaaa647		4889e5			MOVQ SP, BP														
  db.go:1770		0xaaa64a		4883ec10		SUBQ $0x10, SP														
  db.go:1770		0xaaa64e		488b4208		MOVQ 0x8(DX), AX													
  type.go:94		0xaaa652		bbffffffff		MOVL $-0x1, BX														
  type.go:94		0xaaa657		f00fc15810		LOCK XADDL BX, 0x10(AX)													
  type.go:94		0xaaa65c		ffcb			DECL BX															
  type.go:94		0xaaa65e		6690			NOPW															
  rwmutex.go:120	0xaaa660		85db			TESTL BX, BX														
  rwmutex.go:120	0xaaa662		7d05			JGE 0xaaa669														
  rwmutex.go:122	0xaaa664		e8d7319fff		CALL sync.(*RWMutex).rUnlockSlow(SB)											
  db.go:1770		0xaaa669		4883c410		ADDQ $0x10, SP														
  db.go:1770		0xaaa66d		5d			POPQ BP															
  db.go:1770		0xaaa66e		c3			RET															
  db.go:1770		0xaaa66f		e84c809eff		CALL runtime.morestack.abi0(SB)												
  db.go:1770		0xaaa674		ebca			JMP github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:2234				0xaac260		493b6610		CMPQ SP, 0x10(R14)								
  db.go:2234				0xaac264		0f8690010000		JBE 0xaac3fa									
  db.go:2234				0xaac26a		55			PUSHQ BP									
  db.go:2234				0xaac26b		4889e5			MOVQ SP, BP									
  db.go:2234				0xaac26e		4883ec78		SUBQ $0x78, SP									
  db.go:2235				0xaac272		4885c0			TESTQ AX, AX									
  db.go:2235				0xaac275		0f8408010000		JE 0xaac383									
  db.go:2238				0xaac27b		80784300		CMPB 0x43(AX), $0x0								
  db.go:2238				0xaac27f		90			NOPL										
  db.go:2238				0xaac280		0f85e9000000		JNE 0xaac36f									
  db.go:2235				0xaac286		4889842488000000	MOVQ AX, 0x88(SP)								
  db.go:2235				0xaac28e		889c2490000000		MOVB BL, 0x90(SP)								
  db.go:2235				0xaac295		84db			TESTL BL, BL									
  db.go:2241				0xaac297		7405			JE 0xaac29e									
  type.go:29				0xaac299		4889c1			MOVQ AX, CX									
  db.go:2241				0xaac29c		eb37			JMP 0xaac2d5									
  db.go:2242				0xaac29e		90			NOPL										
  db.go:2235				0xaac29f		4889c1			MOVQ AX, CX									
  mutex.go:63				0xaac2a2		31c0			XORL AX, AX									
  mutex.go:63				0xaac2a4		ba01000000		MOVL $0x1, DX									
  mutex.go:63				0xaac2a9		f00fb191f0050000	LOCK CMPXCHGL DX, 0x5f0(CX)							
  mutex.go:63				0xaac2b1		0f94c2			SETE DL										
  mutex.go:63				0xaac2b4		84d2			TESTL DL, DL									
  mutex.go:63				0xaac2b6		751d			JNE 0xaac2d5									
  mutex.go:46				0xaac2b8		488d81f0050000		LEAQ 0x5f0(CX), AX								
  mutex.go:70				0xaac2bf		90			NOPL										
  mutex.go:70				0xaac2c0		e81b009fff		CALL internal/sync.(*Mutex).lockSlow(SB)					
  type.go:29				0xaac2c5		488b8c2488000000	MOVQ 0x88(SP), CX								
  db.go:2235				0xaac2cd		0fb69c2490000000	MOVZX 0x90(SP), BX								
  type.go:29				0xaac2d5		31c0			XORL AX, AX									
  type.go:29				0xaac2d7		ba01000000		MOVL $0x1, DX									
  type.go:29				0xaac2dc		f00fb191d0050000	LOCK CMPXCHGL DX, 0x5d0(CX)							
  type.go:29				0xaac2e4		0f94c2			SETE DL										
  type.go:29				0xaac2e7		84d2			TESTL DL, DL									
  db.go:2244				0xaac2e9		7457			JE 0xaac342									
  type.go:203				0xaac2eb		488d91e8050000		LEAQ 0x5e8(CX), DX								
  db.go:2250				0xaac2f2		90			NOPL										
  type.go:203				0xaac2f3		48be0000000000000080	MOVQ $0x8000000000000000, SI							
  type.go:203				0xaac2fd		f0480932		LOCK ORQ SI, 0(DX)								
  db.go:2235				0xaac301		84db			TESTL BL, BL									
  db.go:2251				0xaac303		0f8584000000		JNE 0xaac38d									
  snapshot_iterator_lifetime.go:63	0xaac309		488b99f8050000		MOVQ 0x5f8(CX), BX								
  db.go:2252				0xaac310		90			NOPL										
  snapshot_iterator_lifetime.go:63	0xaac311		488d4c2418		LEAQ 0x18(SP), CX								
  snapshot_iterator_lifetime.go:63	0xaac316		440f1139		MOVUPS X15, 0(CX)								
  snapshot_iterator_lifetime.go:63	0xaac31a		440f117910		MOVUPS X15, 0x10(CX)								
  snapshot_iterator_lifetime.go:63	0xaac31f		440f117920		MOVUPS X15, 0x20(CX)								
  snapshot_iterator_lifetime.go:63	0xaac324		440f117930		MOVUPS X15, 0x30(CX)								
  snapshot_iterator_lifetime.go:63	0xaac329		440f117940		MOVUPS X15, 0x40(CX)								
  snapshot_iterator_lifetime.go:63	0xaac32e		440f117950		MOVUPS X15, 0x50(CX)								
  snapshot_iterator_lifetime.go:63	0xaac333		488d05c6471201		LEAQ 0x11247c6(IP), AX								
  snapshot_iterator_lifetime.go:63	0xaac33a		e8418e97ff		CALL runtime.mapIterStart(SB)							
  snapshot_iterator_lifetime.go:63	0xaac33f		90			NOPL										
  snapshot_iterator_lifetime.go:63	0xaac340		eb6f			JMP 0xaac3b1									
  db.go:2235				0xaac342		84db			TESTL BL, BL									
  db.go:2245				0xaac344		751f			JNE 0xaac365									
  db.go:2246				0xaac346		90			NOPL										
  mutex.go:194				0xaac347		bbffffffff		MOVL $-0x1, BX									
  mutex.go:194				0xaac34c		f00fc199f0050000	LOCK XADDL BX, 0x5f0(CX)							
  mutex.go:194				0xaac354		ffcb			DECL BX										
  mutex.go:195				0xaac356		740d			JE 0xaac365									
  mutex.go:65				0xaac358		488d81f0050000		LEAQ 0x5f0(CX), AX								
  mutex.go:198				0xaac35f		90			NOPL										
  mutex.go:198				0xaac360		e85b029fff		CALL internal/sync.(*Mutex).unlockSlow(SB)					
  db.go:2248				0xaac365		31c0			XORL AX, AX									
  db.go:2248				0xaac367		31db			XORL BX, BX									
  db.go:2248				0xaac369		4883c478		ADDQ $0x78, SP									
  db.go:2248				0xaac36d		5d			POPQ BP										
  db.go:2248				0xaac36e		c3			RET										
  db.go:2239				0xaac36f		488b05ea383602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrNativeMVCCSnapshotWork(SB), AX	
  db.go:2239				0xaac376		488b1deb383602		MOVQ github.com/snissn/gomap/TreeDB/db.ErrNativeMVCCSnapshotWork+8(SB), BX	
  db.go:2239				0xaac37d		4883c478		ADDQ $0x78, SP									
  db.go:2239				0xaac381		5d			POPQ BP										
  db.go:2239				0xaac382		c3			RET										
  db.go:2236				0xaac383		31c0			XORL AX, AX									
  db.go:2236				0xaac385		31db			XORL BX, BX									
  db.go:2236				0xaac387		4883c478		ADDQ $0x78, SP									
  db.go:2236				0xaac38b		5d			POPQ BP										
  db.go:2236				0xaac38c		c3			RET										
  db.go:2255				0xaac38d		4889c8			MOVQ CX, AX									
  db.go:2255				0xaac390		e88b000000		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead(SB)	
  db.go:2255				0xaac395		4883c478		ADDQ $0x78, SP									
  db.go:2255				0xaac399		5d			POPQ BP										
  db.go:2255				0xaac39a		c3			RET										
  snapshot_iterator_lifetime.go:63	0xaac39b		488b09			MOVQ 0(CX), CX									
  snapshot_iterator_lifetime.go:64	0xaac39e		90			NOPL										
  type.go:22				0xaac39f		ba01000000		MOVL $0x1, DX									
  type.go:22				0xaac3a4		875118			XCHGL DX, 0x18(CX)								
  snapshot_iterator_lifetime.go:63	0xaac3a7		488d442418		LEAQ 0x18(SP), AX								
  snapshot_iterator_lifetime.go:63	0xaac3ac		e82f8e97ff		CALL runtime.mapIterNext(SB)							
  snapshot_iterator_lifetime.go:63	0xaac3b1		488b4c2418		MOVQ 0x18(SP), CX								
  snapshot_iterator_lifetime.go:63	0xaac3b6		4885c9			TESTQ CX, CX									
  snapshot_iterator_lifetime.go:63	0xaac3b9		75e0			JNE 0xaac39b									
  db.go:2253				0xaac3bb		90			NOPL										
  mutex.go:194				0xaac3bc		bbffffffff		MOVL $-0x1, BX									
  mutex.go:194				0xaac3c1		488b842488000000	MOVQ 0x88(SP), AX								
  mutex.go:194				0xaac3c9		f00fc198f0050000	LOCK XADDL BX, 0x5f0(AX)							
  mutex.go:194				0xaac3d1		ffcb			DECL BX										
  mutex.go:195				0xaac3d3		7418			JE 0xaac3ed									
  mutex.go:65				0xaac3d5		4805f0050000		ADDQ $0x5f0, AX									
  mutex.go:198				0xaac3db		0f1f440000		NOPL 0(AX)(AX*1)								
  mutex.go:198				0xaac3e0		e8db019fff		CALL internal/sync.(*Mutex).unlockSlow(SB)					
  db.go:2255				0xaac3e5		488b842488000000	MOVQ 0x88(SP), AX								
  db.go:2255				0xaac3ed		4889c1			MOVQ AX, CX									
  db.go:2255				0xaac3f0		0fb69c2490000000	MOVZX 0x90(SP), BX								
  mutex.go:65				0xaac3f8		eb93			JMP 0xaac38d									
  db.go:2234				0xaac3fa		4889442408		MOVQ AX, 0x8(SP)								
  db.go:2234				0xaac3ff		885c2410		MOVB BL, 0x10(SP)								
  db.go:2234				0xaac403		e858639eff		CALL runtime.morestack_noctxt.abi0(SB)						
  db.go:2234				0xaac408		488b442408		MOVQ 0x8(SP), AX								
  db.go:2234				0xaac40d		0fb65c2410		MOVZX 0x10(SP), BX								
  db.go:2234				0xaac412		e949feffff		JMP github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead(SB)			

TEXT github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:2262		0xaac420		4c8da424a8fdffff	LEAQ 0xfffffda8(SP), R12										
  db.go:2262		0xaac428		4d3b6610		CMPQ R12, 0x10(R14)											
  db.go:2262		0xaac42c		0f868a170000		JBE 0xaadbbc												
  db.go:2262		0xaac432		55			PUSHQ BP												
  db.go:2262		0xaac433		4889e5			MOVQ SP, BP												
  db.go:2262		0xaac436		4881ecd0020000		SUBQ $0x2d0, SP												
  db.go:2263		0xaac43d		80784300		CMPB 0x43(AX), $0x0											
  db.go:2263		0xaac441		0f85cd020000		JNE 0xaac714												
  db.go:2263		0xaac447		48898424e0020000	MOVQ AX, 0x2e0(SP)											
  db.go:2263		0xaac44f		889c24e8020000		MOVB BL, 0x2e8(SP)											
  db.go:2263		0xaac456		84db			TESTL BL, BL												
  db.go:2266		0xaac458		7405			JE 0xaac45f												
  db.go:2269		0xaac45a		4889c1			MOVQ AX, CX												
  db.go:2266		0xaac45d		eb36			JMP 0xaac495												
  db.go:2267		0xaac45f		90			NOPL													
  db.go:2263		0xaac460		4889c1			MOVQ AX, CX												
  mutex.go:63		0xaac463		31c0			XORL AX, AX												
  mutex.go:63		0xaac465		ba01000000		MOVL $0x1, DX												
  mutex.go:63		0xaac46a		f00fb191f0050000	LOCK CMPXCHGL DX, 0x5f0(CX)										
  mutex.go:63		0xaac472		0f94c2			SETE DL													
  mutex.go:63		0xaac475		84d2			TESTL DL, DL												
  mutex.go:63		0xaac477		751c			JNE 0xaac495												
  mutex.go:46		0xaac479		488d81f0050000		LEAQ 0x5f0(CX), AX											
  mutex.go:70		0xaac480		e85bfe9eff		CALL internal/sync.(*Mutex).lockSlow(SB)								
  db.go:2269		0xaac485		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2263		0xaac48d		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2269		0xaac495		488b91f8050000		MOVQ 0x5f8(CX), DX											
  db.go:2269		0xaac49c		0f1f4000		NOPL 0(AX)												
  db.go:2269		0xaac4a0		4885d2			TESTQ DX, DX												
  db.go:2269		0xaac4a3		7405			JE 0xaac4aa												
  db.go:2269		0xaac4a5		488b12			MOVQ 0(DX), DX												
  db.go:2269		0xaac4a8		eb02			JMP 0xaac4ac												
  db.go:2269		0xaac4aa		31d2			XORL DX, DX												
  db.go:2269		0xaac4ac		4885d2			TESTQ DX, DX												
  db.go:2269		0xaac4af		7407			JE 0xaac4b8												
  db.go:2269		0xaac4b1		ba01000000		MOVL $0x1, DX												
  db.go:2269		0xaac4b6		eb17			JMP 0xaac4cf												
  type.go:181		0xaac4b8		488b91e8050000		MOVQ 0x5e8(CX), DX											
  db.go:2269		0xaac4bf		49b80000000000000080	MOVQ $0x8000000000000000, R8										
  db.go:2269		0xaac4c9		4c39c2			CMPQ DX, R8												
  db.go:2269		0xaac4cc		0f95c2			SETNE DL												
  db.go:2269		0xaac4cf		84d2			TESTL DL, DL												
  db.go:2269		0xaac4d1		7407			JE 0xaac4da												
  db.go:2269		0xaac4d3		ba01000000		MOVL $0x1, DX												
  db.go:2269		0xaac4d8		eb15			JMP 0xaac4ef												
  type.go:29		0xaac4da		31c0			XORL AX, AX												
  type.go:29		0xaac4dc		ba01000000		MOVL $0x1, DX												
  type.go:29		0xaac4e1		f00fb191e0050000	LOCK CMPXCHGL DX, 0x5e0(CX)										
  type.go:29		0xaac4e9		0f94c2			SETE DL													
  db.go:2269		0xaac4ec		83f201			XORL $0x1, DX												
  db.go:2269		0xaac4ef		84d2			TESTL DL, DL												
  db.go:2269		0xaac4f1		0f85ee010000		JNE 0xaac6e5												
  db.go:2275		0xaac4f7		488b9130030000		MOVQ 0x330(CX), DX											
  db.go:2275		0xaac4fe		4c8b8128030000		MOVQ 0x328(CX), R8											
  db.go:2276		0xaac505		4c8b8940030000		MOVQ 0x340(CX), R9											
  db.go:2276		0xaac50c		440fb69148030000	MOVZX 0x348(CX), R10											
  db.go:2277		0xaac514		440fb699d0020000	MOVZX 0x2d0(CX), R11											
  db.go:2278		0xaac51c		c681d002000000		MOVB $0x0, 0x2d0(CX)											
  db.go:2279		0xaac523		4c8ba138060000		MOVQ 0x638(CX), R12											
  db.go:2280		0xaac52a		833def0f480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2280		0xaac531		7418			JE 0xaac54b												
  db.go:2280		0xaac533		4c8ba938060000		MOVQ 0x638(CX), R13											
  db.go:2277		0xaac53a		4489d8			MOVL R11, AX												
  db.go:2277		0xaac53d		0f1f00			NOPL 0(AX)												
  db.go:2280		0xaac540		e8fb7c9eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2280		0xaac545		4d892b			MOVQ R13, 0(R11)											
  db.go:2277		0xaac548		4189c3			MOVL AX, R11												
  db.go:2280		0xaac54b		48c7813806000000000000	MOVQ $0x0, 0x638(CX)											
  db.go:2281		0xaac556		4c8ba908060000		MOVQ 0x608(CX), R13											
  db.go:2282		0xaac55d		833dbc0f480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2282		0xaac564		7504			JNE 0xaac56a												
  db.go:2263		0xaac566		84db			TESTL BL, BL												
  db.go:2282		0xaac568		eb17			JMP 0xaac581												
  db.go:2282		0xaac56a		4c8bb908060000		MOVQ 0x608(CX), R15											
  db.go:2277		0xaac571		4489d8			MOVL R11, AX												
  db.go:2282		0xaac574		e8c77c9eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2282		0xaac579		4d893b			MOVQ R15, 0(R11)											
  db.go:2263		0xaac57c		84db			TESTL BL, BL												
  db.go:2277		0xaac57e		4189c3			MOVL AX, R11												
  db.go:2275		0xaac581		4889942428010000	MOVQ DX, 0x128(SP)											
  db.go:2275		0xaac589		4c89842430010000	MOVQ R8, 0x130(SP)											
  db.go:2276		0xaac591		4c898c2420010000	MOVQ R9, 0x120(SP)											
  db.go:2279		0xaac599		4c89a42410010000	MOVQ R12, 0x110(SP)											
  db.go:2281		0xaac5a1		4c89ac2488010000	MOVQ R13, 0x188(SP)											
  db.go:2276		0xaac5a9		4488542447		MOVB R10, 0x47(SP)											
  db.go:2277		0xaac5ae		44885c2446		MOVB R11, 0x46(SP)											
  db.go:2282		0xaac5b3		48c7810806000000000000	MOVQ $0x0, 0x608(CX)											
  db.go:2283		0xaac5be		c6810006000000		MOVB $0x0, 0x600(CX)											
  db.go:2284		0xaac5c5		7568			JNE 0xaac62f												
  db.go:2285		0xaac5c7		90			NOPL													
  mutex.go:194		0xaac5c8		41bfffffffff		MOVL $-0x1, R15												
  mutex.go:194		0xaac5ce		f0440fc1b9f0050000	LOCK XADDL R15, 0x5f0(CX)										
  mutex.go:194		0xaac5d7		41ffcf			DECL R15												
  mutex.go:195		0xaac5da		7453			JE 0xaac62f												
  mutex.go:65		0xaac5dc		488d81f0050000		LEAQ 0x5f0(CX), AX											
  mutex.go:198		0xaac5e3		4489fb			MOVL R15, BX												
  mutex.go:198		0xaac5e6		e8d5ff9eff		CALL internal/sync.(*Mutex).unlockSlow(SB)								
  db.go:2289		0xaac5eb		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2386		0xaac5f3		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaac5fb		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2387		0xaac603		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaac60b		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaac613		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaac619		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaac61f		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaac627		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2289		0xaac62f		4c8bb9b0020000		MOVQ 0x2b0(CX), R15											
  db.go:2288		0xaac636		488b81a8020000		MOVQ 0x2a8(CX), AX											
  db.go:2288		0xaac63d		488bb1a0020000		MOVQ 0x2a0(CX), SI											
  db.go:2289		0xaac644		4d85ff			TESTQ R15, R15												
  db.go:2289		0xaac647		0f8491000000		JE 0xaac6de												
  db.go:2289		0xaac64d		4885f6			TESTQ SI, SI												
  db.go:2289		0xaac650		740a			JE 0xaac65c												
  db.go:2289		0xaac652		31ff			XORL DI, DI												
  db.go:2289		0xaac654		4531ff			XORL R15, R15												
  db.go:2289		0xaac657		e9c5000000		JMP 0xaac721												
  db.go:2290		0xaac65c		498b3f			MOVQ 0(R15), DI												
  db.go:2291		0xaac65f		4883b90803000000	CMPQ 0x308(CX), $0x0											
  db.go:2291		0xaac667		7452			JE 0xaac6bb												
  db.go:2290		0xaac669		4889bc24c8010000	MOVQ DI, 0x1c8(SP)											
  db.go:2294		0xaac671		498b5710		MOVQ 0x10(R15), DX											
  db.go:2294		0xaac675		498b5f08		MOVQ 0x8(R15), BX											
  db.go:2294		0xaac679		4c8d8110030000		LEAQ 0x310(CX), R8											
  db.go:2294		0xaac680		4c89842408020000	MOVQ R8, 0x208(SP)											
  db.go:2294		0xaac688		4889f8			MOVQ DI, AX												
  db.go:2294		0xaac68b		4889d1			MOVQ DX, CX												
  db.go:2294		0xaac68e		4c89c7			MOVQ R8, DI												
  db.go:2294		0xaac691		31f6			XORL SI, SI												
  db.go:2294		0xaac693		e8a8dcc0ff		CALL github.com/snissn/gomap/TreeDB/internal/primaryarena.(*Arena).DropToReleaseQueue(SB)		
  db.go:2294		0xaac698		0f1f840000000000	NOPL 0(AX)(AX*1)											
  db.go:2295		0xaac6a0		4885db			TESTQ BX, BX												
  db.go:2295		0xaac6a3		0f85f7120000		JNE 0xaad9a0												
  db.go:2294		0xaac6a9		48898c2408010000	MOVQ CX, 0x108(SP)											
  db.go:2294		0xaac6b1		48895c2448		MOVQ BX, 0x48(SP)											
  db.go:2295		0xaac6b6		e9b6100000		JMP 0xaad771												
  arena.go:625		0xaac6bb		8407			TESTB AL, 0(DI)												
  db.go:2292		0xaac6bd		498b4f10		MOVQ 0x10(R15), CX											
  db.go:2292		0xaac6c1		498b5f08		MOVQ 0x8(R15), BX											
  arena.go:625		0xaac6c5		488d97b0800000		LEAQ 0x80b0(DI), DX											
  arena.go:625		0xaac6cc		4889f8			MOVQ DI, AX												
  arena.go:625		0xaac6cf		4889d7			MOVQ DX, DI												
  arena.go:625		0xaac6d2		31f6			XORL SI, SI												
  arena.go:625		0xaac6d4		e867dcc0ff		CALL github.com/snissn/gomap/TreeDB/internal/primaryarena.(*Arena).DropToReleaseQueue(SB)		
  db.go:2292		0xaac6d9		e9fc0d0000		JMP 0xaad4da												
  db.go:2292		0xaac6de		31ff			XORL DI, DI												
  db.go:2292		0xaac6e0		4531ff			XORL R15, R15												
  db.go:2289		0xaac6e3		eb3c			JMP 0xaac721												
  db.go:2263		0xaac6e5		84db			TESTL BL, BL												
  db.go:2270		0xaac6e7		751e			JNE 0xaac707												
  db.go:2271		0xaac6e9		90			NOPL													
  mutex.go:194		0xaac6ea		bbffffffff		MOVL $-0x1, BX												
  mutex.go:194		0xaac6ef		f00fc199f0050000	LOCK XADDL BX, 0x5f0(CX)										
  mutex.go:194		0xaac6f7		ffcb			DECL BX													
  mutex.go:195		0xaac6f9		740c			JE 0xaac707												
  mutex.go:65		0xaac6fb		488d81f0050000		LEAQ 0x5f0(CX), AX											
  mutex.go:198		0xaac702		e8b9fe9eff		CALL internal/sync.(*Mutex).unlockSlow(SB)								
  db.go:2273		0xaac707		31c0			XORL AX, AX												
  db.go:2273		0xaac709		31db			XORL BX, BX												
  db.go:2273		0xaac70b		4881c4d0020000		ADDQ $0x2d0, SP												
  db.go:2273		0xaac712		5d			POPQ BP													
  db.go:2273		0xaac713		c3			RET													
  db.go:2264		0xaac714		31c0			XORL AX, AX												
  db.go:2264		0xaac716		31db			XORL BX, BX												
  db.go:2264		0xaac718		4881c4d0020000		ADDQ $0x2d0, SP												
  db.go:2264		0xaac71f		5d			POPQ BP													
  db.go:2264		0xaac720		c3			RET													
  db.go:2316		0xaac721		4889bc2450020000	MOVQ DI, 0x250(SP)											
  db.go:2316		0xaac729		4c89bc2458020000	MOVQ R15, 0x258(SP)											
  db.go:2316		0xaac731		4889b42460020000	MOVQ SI, 0x260(SP)											
  db.go:2316		0xaac739		4889842468020000	MOVQ AX, 0x268(SP)											
  join.go:22		0xaac741		488db42450020000	LEAQ 0x250(SP), SI											
  join.go:22		0xaac749		31c0			XORL AX, AX												
  join.go:22		0xaac74b		31ff			XORL DI, DI												
  join.go:22		0xaac74d		eb19			JMP 0xaac768												
  join.go:22		0xaac74f		4989f7			MOVQ SI, R15												
  join.go:22		0xaac752		4883c610		ADDQ $0x10, SI												
  join.go:22		0xaac756		48ffc0			INCQ AX													
  join.go:22		0xaac759		49833f00		CMPQ 0(R15), $0x0											
  join.go:23		0xaac75d		410f95c7		SETNE R15												
  join.go:23		0xaac761		450fb6ff		MOVZX R15, R15												
  join.go:23		0xaac765		4c01ff			ADDQ R15, DI												
  join.go:22		0xaac768		4883f802		CMPQ AX, $0x2												
  join.go:22		0xaac76c		7ce1			JL 0xaac74f												
  join.go:27		0xaac76e		4885ff			TESTQ DI, DI												
  join.go:27		0xaac771		7509			JNE 0xaac77c												
  join.go:27		0xaac773		31c0			XORL AX, AX												
  join.go:27		0xaac775		31f6			XORL SI, SI												
  db.go:2316		0xaac777		e9bc010000		JMP 0xaac938												
  join.go:22		0xaac77c		48897c2460		MOVQ DI, 0x60(SP)											
  join.go:31		0xaac781		488d0598001101		LEAQ 0x1110098(IP), AX											
  join.go:31		0xaac788		31db			XORL BX, BX												
  join.go:31		0xaac78a		4889f9			MOVQ DI, CX												
  join.go:31		0xaac78d		e80e259eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaac792		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaac79a		488d05bf8f1301		LEAQ 0x1138fbf(IP), AX											
  join.go:30		0xaac7a1		e8fa8297ff		CALL runtime.newobject(SB)										
  join.go:31		0xaac7a6		488b542460		MOVQ 0x60(SP), DX											
  join.go:31		0xaac7ab		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaac7af		833d6a0d480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaac7b6		750a			JNE 0xaac7c2												
  join.go:31		0xaac7b8		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaac7c0		eb10			JMP 0xaac7d2												
  join.go:31		0xaac7c2		e8797a9eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaac7c7		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaac7cf		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaac7d2		48898424a0010000	MOVQ AX, 0x1a0(SP)											
  join.go:31		0xaac7da		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaac7dd		488d942450020000	LEAQ 0x250(SP), DX											
  join.go:33		0xaac7e5		31c9			XORL CX, CX												
  join.go:33		0xaac7e7		eb07			JMP 0xaac7f0												
  join.go:33		0xaac7e9		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaac7ed		48ffc1			INCQ CX													
  join.go:33		0xaac7f0		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaac7f4		0f8deb000000		JGE 0xaac8e5												
  join.go:33		0xaac7fa		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaac7fd		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaac801		4d85c0			TESTQ R8, R8												
  join.go:34		0xaac804		74e3			JE 0xaac7e9												
  join.go:35		0xaac806		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaac80a		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaac80e		48ffc3			INCQ BX													
  join.go:35		0xaac811		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaac814		4939da			CMPQ R10, BX												
  join.go:35		0xaac817		0f8389000000		JAE 0xaac8a6												
  join.go:33		0xaac81d		4c898424a0000000	MOVQ R8, 0xa0(SP)											
  join.go:33		0xaac825		4c898c2460010000	MOVQ R9, 0x160(SP)											
  join.go:33		0xaac82d		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaac835		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:35		0xaac83d		4c89d8			MOVQ R11, AX												
  join.go:35		0xaac840		4c89d1			MOVQ R10, CX												
  join.go:35		0xaac843		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaac848		488d35d1ff1001		LEAQ 0x110ffd1(IP), SI											
  join.go:35		0xaac84f		e82c259eff		CALL runtime.growslice(SB)										
  join.go:35		0xaac854		488b9424a0010000	MOVQ 0x1a0(SP), DX											
  join.go:35		0xaac85c		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaac860		833db90c480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaac867		740f			JE 0xaac878												
  join.go:35		0xaac869		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaac86c		e8ef799eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaac871		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaac874		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaac878		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaac87b		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaac883		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaac88b		4c8b8424a0000000	MOVQ 0xa0(SP), R8											
  join.go:35		0xaac893		4c8b8c2460010000	MOVQ 0x160(SP), R9											
  join.go:35		0xaac89b		4989c3			MOVQ AX, R11												
  join.go:35		0xaac89e		488b8424a0010000	MOVQ 0x1a0(SP), AX											
  join.go:35		0xaac8a6		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaac8aa		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaac8ae		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaac8b2		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaac8b6		833d630c480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaac8bd		7417			JE 0xaac8d6												
  join.go:35		0xaac8bf		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaac8c4		4c89db			MOVQ R11, BX												
  join.go:35		0xaac8c7		e894799eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaac8cc		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaac8cf		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaac8d3		4989db			MOVQ BX, R11												
  join.go:35		0xaac8d6		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaac8db		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:35		0xaac8e0		e904ffffff		JMP 0xaac7e9												
  db.go:2317		0xaac8e5		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2386		0xaac8ed		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaac8f5		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2387		0xaac8fd		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaac905		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaac90d		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaac913		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaac919		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaac921		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2347		0xaac929		488d05f0224101		LEAQ go:itab.*errors.joinError,error(SB), AX								
  db.go:2316		0xaac930		488bb424a0010000	MOVQ 0x1a0(SP), SI											
  db.go:2317		0xaac938		80b94903000000		CMPB 0x349(CX), $0x0											
  db.go:2317		0xaac93f		90			NOPL													
  db.go:2317		0xaac940		0f84a5000000		JE 0xaac9eb												
  db.go:2317		0xaac946		488bb938030000		MOVQ 0x338(CX), DI											
  db.go:2317		0xaac94d		4885ff			TESTQ DI, DI												
  db.go:2317		0xaac950		0f8495000000		JE 0xaac9eb												
  db.go:2317		0xaac956		488b7f30		MOVQ 0x30(DI), DI											
  db.go:2317		0xaac95a		660f1f440000		NOPW 0(AX)(AX*1)											
  db.go:2317		0xaac960		4885ff			TESTQ DI, DI												
  db.go:2317		0xaac963		0f8482000000		JE 0xaac9eb												
  db.go:2317		0xaac969		4c8bb940030000		MOVQ 0x340(CX), R15											
  db.go:2317		0xaac970		4d85ff			TESTQ R15, R15												
  db.go:2317		0xaac973		7476			JE 0xaac9eb												
  db.go:2316		0xaac975		4889b42480010000	MOVQ SI, 0x180(SP)											
  db.go:2316		0xaac97d		48898424c0000000	MOVQ AX, 0xc0(SP)											
  db.go:2318		0xaac985		4c89f8			MOVQ R15, AX												
  db.go:2318		0xaac988		4889fb			MOVQ DI, BX												
  db.go:2318		0xaac98b		e8b03cd7ff		CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).Release(SB)				
  db.go:2318		0xaac990		4885c0			TESTQ AX, AX												
  db.go:2318		0xaac993		7441			JE 0xaac9d6												
  db.go:2319		0xaac995		488b9424c0000000	MOVQ 0xc0(SP), DX											
  db.go:2319		0xaac99d		4889942430020000	MOVQ DX, 0x230(SP)											
  db.go:2319		0xaac9a5		488b942480010000	MOVQ 0x180(SP), DX											
  db.go:2319		0xaac9ad		4889942438020000	MOVQ DX, 0x238(SP)											
  db.go:2319		0xaac9b5		4889842440020000	MOVQ AX, 0x240(SP)											
  db.go:2319		0xaac9bd		48899c2448020000	MOVQ BX, 0x248(SP)											
  join.go:22		0xaac9c5		488d942430020000	LEAQ 0x230(SP), DX											
  join.go:22		0xaac9cd		31c0			XORL AX, AX												
  join.go:22		0xaac9cf		31c9			XORL CX, CX												
  join.go:22		0xaac9d1		e90c090000		JMP 0xaad2e2												
  join.go:22		0xaac9d6		488b8424c0000000	MOVQ 0xc0(SP), AX											
  join.go:22		0xaac9de		488b8c2480010000	MOVQ 0x180(SP), CX											
  db.go:2318		0xaac9e6		e992080000		JMP 0xaad27d												
  db.go:2329		0xaac9eb		4889b42480010000	MOVQ SI, 0x180(SP)											
  db.go:2329		0xaac9f3		48898424c0000000	MOVQ AX, 0xc0(SP)											
  db.go:2329		0xaac9fb		488bb930030000		MOVQ 0x330(CX), DI											
  db.go:2329		0xaaca02		4885ff			TESTQ DI, DI												
  db.go:2329		0xaaca05		0f84f0000000		JE 0xaacafb												
  db.go:2330		0xaaca0b		4c8bb9a8030000		MOVQ 0x3a8(CX), R15											
  db.go:2330		0xaaca12		4d85ff			TESTQ R15, R15												
  db.go:2330		0xaaca15		7462			JE 0xaaca79												
  db.go:2331		0xaaca17		488b4748		MOVQ 0x48(DI), AX											
  db.go:2331		0xaaca1b		4c89fb			MOVQ R15, BX												
  db.go:2331		0xaaca1e		6690			NOPW													
  db.go:2331		0xaaca20		e8fbf8e7ff		CALL github.com/snissn/gomap/TreeDB/lifecycle.(*ReaderRegistry).Unregister(SB)				
  db.go:2351		0xaaca25		488b8424c0000000	MOVQ 0xc0(SP), AX											
  db.go:2333		0xaaca2d		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2386		0xaaca35		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaaca3d		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2368		0xaaca45		488bb42480010000	MOVQ 0x180(SP), SI											
  db.go:2387		0xaaca4d		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaaca55		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaaca5d		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaaca63		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaaca69		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaaca71		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2333		0xaaca79		488bb928030000		MOVQ 0x328(CX), DI											
  db.go:2333		0xaaca80		4885ff			TESTQ DI, DI												
  db.go:2333		0xaaca83		7476			JE 0xaacafb												
  type.go:58		0xaaca85		488bbf90050000		MOVQ 0x590(DI), DI											
  db.go:2334		0xaaca8c		4c8bb930030000		MOVQ 0x330(CX), R15											
  db.go:2334		0xaaca93		4c39ff			CMPQ DI, R15												
  db.go:2334		0xaaca96		7463			JE 0xaacafb												
  db.go:2335		0xaaca98		488b8128030000		MOVQ 0x328(CX), AX											
  db.go:2335		0xaaca9f		4c89fb			MOVQ R15, BX												
  db.go:2335		0xaacaa2		e879840800		CALL github.com/snissn/gomap/TreeDB/db.(*DB).maybeReleaseRetiredIndex(SB)				
  db.go:2351		0xaacaa7		488b8424c0000000	MOVQ 0xc0(SP), AX											
  db.go:2339		0xaacaaf		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2386		0xaacab7		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaacabf		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2368		0xaacac7		488bb42480010000	MOVQ 0x180(SP), SI											
  db.go:2387		0xaacacf		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaacad7		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaacadf		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaacae5		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaacaeb		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaacaf3		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2339		0xaacafb		4889c8			MOVQ CX, AX												
  db.go:2339		0xaacafe		6690			NOPW													
  db.go:2339		0xaacb00		e87bf3ffff		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).releaseLeafGenerationPins(SB)			
  db.go:2340		0xaacb05		488b8424e0020000	MOVQ 0x2e0(SP), AX											
  db.go:2340		0xaacb0d		80b82806000000		CMPB 0x628(AX), $0x0											
  db.go:2340		0xaacb14		7425			JE 0xaacb3b												
  db.go:2340		0xaacb16		488bb030060000		MOVQ 0x630(AX), SI											
  db.go:2340		0xaacb1d		0f1f00			NOPL 0(AX)												
  db.go:2340		0xaacb20		4885f6			TESTQ SI, SI												
  db.go:2340		0xaacb23		7416			JE 0xaacb3b												
  db.go:2340		0xaacb25		80b82906000000		CMPB 0x629(AX), $0x0											
  db.go:2340		0xaacb2c		750d			JNE 0xaacb3b												
  db.go:2341		0xaacb2e		90			NOPL													
  type.go:128		0xaacb2f		49c7c0ffffffff		MOVQ $-0x1, R8												
  type.go:128		0xaacb36		f04c0fc106		LOCK XADDQ R8, 0(SI)											
  db.go:2343		0xaacb3b		80b82806000000		CMPB 0x628(AX), $0x0											
  db.go:2343		0xaacb42		7407			JE 0xaacb4b												
  db.go:2344		0xaacb44		c6802806000000		MOVB $0x0, 0x628(AX)											
  db.go:2346		0xaacb4b		833dce09480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2346		0xaacb52		7414			JE 0xaacb68												
  db.go:2346		0xaacb54		488bb030060000		MOVQ 0x630(AX), SI											
  db.go:2346		0xaacb5b		0f1f440000		NOPL 0(AX)(AX*1)											
  db.go:2346		0xaacb60		e8db769eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2346		0xaacb65		498933			MOVQ SI, 0(R11)												
  db.go:2346		0xaacb68		48c7803006000000000000	MOVQ $0x0, 0x630(AX)											
  db.go:2347		0xaacb73		488b942488010000	MOVQ 0x188(SP), DX											
  db.go:2347		0xaacb7b		0f1f440000		NOPL 0(AX)(AX*1)											
  db.go:2347		0xaacb80		4885d2			TESTQ DX, DX												
  db.go:2347		0xaacb83		740d			JE 0xaacb92												
  db.go:2348		0xaacb85		488b02			MOVQ 0(DX), AX												
  db.go:2348		0xaacb88		ffd0			CALL AX													
  db.go:2350		0xaacb8a		488b8424e0020000	MOVQ 0x2e0(SP), AX											
  db.go:2350		0xaacb92		488b90b8020000		MOVQ 0x2b8(AX), DX											
  db.go:2350		0xaacb99		0f1f8000000000		NOPL 0(AX)												
  db.go:2350		0xaacba0		4885d2			TESTQ DX, DX												
  db.go:2350		0xaacba3		0f84d9000000		JE 0xaacc82												
  db.go:2351		0xaacba9		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2351		0xaacbb1		4885c9			TESTQ CX, CX												
  db.go:2351		0xaacbb4		7430			JE 0xaacbe6												
  db.go:2354		0xaacbb6		4889c3			MOVQ AX, BX												
  db.go:2354		0xaacbb9		488bbc2480010000	MOVQ 0x180(SP), DI											
  db.go:2354		0xaacbc1		4889d0			MOVQ DX, AX												
  db.go:2354		0xaacbc4		e897331500		CALL github.com/snissn/gomap/TreeDB/db.(*primaryArenaOwnerV5).retainFailedSnapshot(SB)			
  db.go:2368		0xaacbc9		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2368		0xaacbd1		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2368		0xaacbd9		488bbc2480010000	MOVQ 0x180(SP), DI											
  db.go:2354		0xaacbe1		e9af000000		JMP 0xaacc95												
  db.go:2350		0xaacbe6		4889942418010000	MOVQ DX, 0x118(SP)											
  db.go:2356		0xaacbee		4889d0			MOVQ DX, AX												
  db.go:2356		0xaacbf1		31db			XORL BX, BX												
  db.go:2356		0xaacbf3		e888271500		CALL github.com/snissn/gomap/TreeDB/db.(*primaryArenaOwnerV5).releaseWithOutcome(SB)			
  db.go:2356		0xaacbf8		84c0			TESTL AL, AL												
  db.go:2357		0xaacbfa		743b			JE 0xaacc37												
  db.go:2358		0xaacbfc		833d1d09480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2358		0xaacc03		750c			JNE 0xaacc11												
  db.go:2356		0xaacc05		84c0			TESTL AL, AL												
  db.go:2358		0xaacc07		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2358		0xaacc0f		eb19			JMP 0xaacc2a												
  db.go:2358		0xaacc11		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2358		0xaacc19		488bb2b8020000		MOVQ 0x2b8(DX), SI											
  db.go:2358		0xaacc20		e81b769eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2358		0xaacc25		498933			MOVQ SI, 0(R11)												
  db.go:2356		0xaacc28		84c0			TESTL AL, AL												
  db.go:2358		0xaacc2a		48c782b802000000000000	MOVQ $0x0, 0x2b8(DX)											
  db.go:2358		0xaacc35		eb09			JMP 0xaacc40												
  db.go:2362		0xaacc37		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2362		0xaacc3f		90			NOPL													
  db.go:2361		0xaacc40		7404			JE 0xaacc46												
  db.go:2356		0xaacc42		84db			TESTL BL, BL												
  db.go:2361		0xaacc44		744f			JE 0xaacc95												
  db.go:2356		0xaacc46		4889bc24f8010000	MOVQ DI, 0x1f8(SP)											
  db.go:2356		0xaacc4e		48898c24f8000000	MOVQ CX, 0xf8(SP)											
  db.go:2362		0xaacc56		488b842418010000	MOVQ 0x118(SP), AX											
  db.go:2362		0xaacc5e		4889d3			MOVQ DX, BX												
  db.go:2362		0xaacc61		e8fa321500		CALL github.com/snissn/gomap/TreeDB/db.(*primaryArenaOwnerV5).retainFailedSnapshot(SB)			
  db.go:2362		0xaacc66		488b8c24f8000000	MOVQ 0xf8(SP), CX											
  db.go:2368		0xaacc6e		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2368		0xaacc76		488bbc24f8010000	MOVQ 0x1f8(SP), DI											
  db.go:2368		0xaacc7e		6690			NOPW													
  db.go:2362		0xaacc80		eb13			JMP 0xaacc95												
  db.go:2368		0xaacc82		4889c2			MOVQ AX, DX												
  db.go:2368		0xaacc85		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2368		0xaacc8d		488bbc2480010000	MOVQ 0x180(SP), DI											
  db.go:2368		0xaacc95		488b8208030000		MOVQ 0x308(DX), AX											
  db.go:2369		0xaacc9c		833d7d08480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2369		0xaacca3		7425			JE 0xaaccca												
  db.go:2369		0xaacca5		488bb208030000		MOVQ 0x308(DX), SI											
  db.go:2370		0xaaccac		4c8b8210030000		MOVQ 0x310(DX), R8											
  db.go:2370		0xaaccb3		4c8b8a20030000		MOVQ 0x320(DX), R9											
  db.go:2369		0xaaccba		e8c1759eff		CALL runtime.gcWriteBarrier3(SB)									
  db.go:2369		0xaaccbf		498933			MOVQ SI, 0(R11)												
  db.go:2370		0xaaccc2		4d894308		MOVQ R8, 0x8(R11)											
  db.go:2370		0xaaccc6		4d894b10		MOVQ R9, 0x10(R11)											
  db.go:2368		0xaaccca		4889842438010000	MOVQ AX, 0x138(SP)											
  db.go:2369		0xaaccd2		48c7820803000000000000	MOVQ $0x0, 0x308(DX)											
  db.go:2370		0xaaccdd		440f11ba10030000	MOVUPS X15, 0x310(DX)											
  db.go:2370		0xaacce5		48c7822003000000000000	MOVQ $0x0, 0x320(DX)											
  db.go:2373		0xaaccf0		4885c9			TESTQ CX, CX												
  db.go:2373		0xaaccf3		7557			JNE 0xaacd4c												
  db.go:2373		0xaaccf5		488bb228030000		MOVQ 0x328(DX), SI											
  db.go:2373		0xaaccfc		0f1f4000		NOPL 0(AX)												
  db.go:2373		0xaacd00		4885f6			TESTQ SI, SI												
  db.go:2373		0xaacd03		7447			JE 0xaacd4c												
  db.go:2368		0xaacd05		4889bc24f0010000	MOVQ DI, 0x1f0(SP)											
  db.go:2368		0xaacd0d		48898c24f0000000	MOVQ CX, 0xf0(SP)											
  db.go:2374		0xaacd15		488b86b0050000		MOVQ 0x5b0(SI), AX											
  db.go:2374		0xaacd1c		4889d3			MOVQ DX, BX												
  db.go:2374		0xaacd1f		0fb68c24e8020000	MOVZX 0x2e8(SP), CX											
  db.go:2374		0xaacd27		e8d4ef1400		CALL github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).putRead(SB)					
  db.go:2384		0xaacd2c		488b842438010000	MOVQ 0x138(SP), AX											
  db.go:2379		0xaacd34		488b8c24f0000000	MOVQ 0xf0(SP), CX											
  db.go:2380		0xaacd3c		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2379		0xaacd44		488bbc24f0010000	MOVQ 0x1f0(SP), DI											
  db.go:2376		0xaacd4c		488bb42410010000	MOVQ 0x110(SP), SI											
  db.go:2376		0xaacd54		4885f6			TESTQ SI, SI												
  db.go:2376		0xaacd57		7424			JE 0xaacd7d												
  db.go:2377		0xaacd59		4889f0			MOVQ SI, AX												
  db.go:2377		0xaacd5c		4889cb			MOVQ CX, BX												
  db.go:2377		0xaacd5f		4889f9			MOVQ DI, CX												
  db.go:2377		0xaacd62		e819ba1a00		CALL github.com/snissn/gomap/TreeDB/db.(*stablePagerOwnedOperations).snapshotFinalized(SB)		
  db.go:2380		0xaacd67		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2379		0xaacd6f		4889c1			MOVQ AX, CX												
  db.go:2379		0xaacd72		4889df			MOVQ BX, DI												
  db.go:2384		0xaacd75		488b842438010000	MOVQ 0x138(SP), AX											
  db.go:2379		0xaacd7d		48898c24c0000000	MOVQ CX, 0xc0(SP)											
  db.go:2379		0xaacd85		4889bc2480010000	MOVQ DI, 0x180(SP)											
  db.go:2379		0xaacd8d		4885c9			TESTQ CX, CX												
  db.go:2379		0xaacd90		755d			JNE 0xaacdef												
  db.go:2276		0xaacd92		0fb6742447		MOVZX 0x47(SP), SI											
  db.go:2276		0xaacd97		4084f6			TESTL SI, SI												
  db.go:2379		0xaacd9a		7453			JE 0xaacdef												
  db.go:2380		0xaacd9c		833d7d07480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2380		0xaacda3		740f			JE 0xaacdb4												
  db.go:2380		0xaacda5		488bb240030000		MOVQ 0x340(DX), SI											
  db.go:2380		0xaacdac		e88f749eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2380		0xaacdb1		498933			MOVQ SI, 0(R11)												
  db.go:2380		0xaacdb4		48c7824003000000000000	MOVQ $0x0, 0x340(DX)											
  db.go:2381		0xaacdbf		c6824803000000		MOVB $0x0, 0x348(DX)											
  db.go:2382		0xaacdc6		488d4258		LEAQ 0x58(DX), AX											
  db.go:2382		0xaacdca		488b9c2420010000	MOVQ 0x120(SP), BX											
  db.go:2382		0xaacdd2		e80993d7ff		CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*ManagerWrapperReleaseWork).ReleaseOriginal(SB)	
  db.go:2384		0xaacdd7		488b842438010000	MOVQ 0x138(SP), AX											
  db.go:2384		0xaacddf		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2384		0xaacde7		488bbc2480010000	MOVQ 0x180(SP), DI											
  db.go:2384		0xaacdef		4889cb			MOVQ CX, BX												
  db.go:2384		0xaacdf2		4889f9			MOVQ DI, CX												
  db.go:2384		0xaacdf5		e8c6f0b4ff		CALL github.com/snissn/gomap/TreeDB/internal/retainedalloc.(*Enrollment).CloseAfterCleanup(SB)		
  db.go:2277		0xaacdfa		0fb6542446		MOVZX 0x46(SP), DX											
  db.go:2277		0xaacdff		90			NOPL													
  db.go:2277		0xaace00		84d2			TESTL DL, DL												
  db.go:2385		0xaace02		0f84de000000		JE 0xaacee6												
  db.go:2386		0xaace08		488b842428010000	MOVQ 0x128(SP), AX											
  db.go:2386		0xaace10		488b9c24e0020000	MOVQ 0x2e0(SP), BX											
  db.go:2386		0xaace18		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2386		0xaace20		488bbc2480010000	MOVQ 0x180(SP), DI											
  db.go:2386		0xaace28		e833750800		CALL github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrowCompletionV6(SB)			
  db.go:2386		0xaace2d		48899c2488000000	MOVQ BX, 0x88(SP)											
  db.go:2386		0xaace35		4889842440010000	MOVQ AX, 0x140(SP)											
  db.go:2386		0xaace3d		0f1f00			NOPL 0(AX)												
  db.go:2387		0xaace40		4885c9			TESTQ CX, CX												
  db.go:2387		0xaace43		7460			JE 0xaacea5												
  db.go:2387		0xaace45		488b942430010000	MOVQ 0x130(SP), DX											
  db.go:2387		0xaace4d		4885d2			TESTQ DX, DX												
  db.go:2387		0xaace50		7453			JE 0xaacea5												
  db.go:2386		0xaace52		4889bc2448010000	MOVQ DI, 0x148(SP)											
  db.go:2386		0xaace5a		48898c2480000000	MOVQ CX, 0x80(SP)											
  db.go:2388		0xaace62		488b8c2428010000	MOVQ 0x128(SP), CX											
  db.go:2388		0xaace6a		8401			TESTB AL, 0(CX)												
  db.go:2388		0xaace6c		4881c120010000		ADDQ $0x120, CX												
  db.go:2388		0xaace73		4889d0			MOVQ DX, AX												
  db.go:2388		0xaace76		488d1d23114101		LEAQ go:itab.*github.com/snissn/gomap/TreeDB/db.originalDBCleanupFailure,error(SB), BX			
  db.go:2388		0xaace7d		0f1f00			NOPL 0(AX)												
  db.go:2388		0xaace80		e8dbac0000		CALL github.com/snissn/gomap/TreeDB/db.(*DB).retainOriginalCleanupError(SB)				
  db.go:2393		0xaace85		488b842440010000	MOVQ 0x140(SP), AX											
  db.go:2390		0xaace8d		488b8c2480000000	MOVQ 0x80(SP), CX											
  db.go:2392		0xaace95		488b9c2488000000	MOVQ 0x88(SP), BX											
  db.go:2390		0xaace9d		488bbc2448010000	MOVQ 0x148(SP), DI											
  db.go:2390		0xaacea5		488b9424c0000000	MOVQ 0xc0(SP), DX											
  db.go:2390		0xaacead		4889942410020000	MOVQ DX, 0x210(SP)											
  db.go:2390		0xaaceb5		488b942480010000	MOVQ 0x180(SP), DX											
  db.go:2390		0xaacebd		4889942418020000	MOVQ DX, 0x218(SP)											
  db.go:2390		0xaacec5		48898c2420020000	MOVQ CX, 0x220(SP)											
  db.go:2390		0xaacecd		4889bc2428020000	MOVQ DI, 0x228(SP)											
  join.go:22		0xaaced5		488d942410020000	LEAQ 0x210(SP), DX											
  join.go:22		0xaacedd		31c9			XORL CX, CX												
  join.go:22		0xaacedf		31f6			XORL SI, SI												
  join.go:22		0xaacee1		e99a010000		JMP 0xaad080												
  db.go:2263		0xaacee6		0fb69424e8020000	MOVZX 0x2e8(SP), DX											
  db.go:2263		0xaaceee		84d2			TESTL DL, DL												
  db.go:2399		0xaacef0		488b842480010000	MOVQ 0x180(SP), AX											
  db.go:2399		0xaacef8		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2399		0xaacf00		4889842480010000	MOVQ AX, 0x180(SP)											
  db.go:2399		0xaacf08		48898c24c0000000	MOVQ CX, 0xc0(SP)											
  db.go:2399		0xaacf10		740d			JE 0xaacf1f												
  db.go:2402		0xaacf12		4889c3			MOVQ AX, BX												
  db.go:2402		0xaacf15		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  db.go:2399		0xaacf1d		eb52			JMP 0xaacf71												
  db.go:2400		0xaacf1f		90			NOPL													
  db.go:2399		0xaacf20		4889c3			MOVQ AX, BX												
  mutex.go:63		0xaacf23		31c0			XORL AX, AX												
  mutex.go:63		0xaacf25		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  mutex.go:63		0xaacf2d		bf01000000		MOVL $0x1, DI												
  mutex.go:63		0xaacf32		f00fb1bef0050000	LOCK CMPXCHGL DI, 0x5f0(SI)										
  mutex.go:63		0xaacf3a		400f94c7		SETE DI													
  mutex.go:63		0xaacf3e		6690			NOPW													
  mutex.go:63		0xaacf40		4084ff			TESTL DI, DI												
  mutex.go:63		0xaacf43		752c			JNE 0xaacf71												
  mutex.go:46		0xaacf45		488d86f0050000		LEAQ 0x5f0(SI), AX											
  mutex.go:70		0xaacf4c		e88ff39eff		CALL internal/sync.(*Mutex).lockSlow(SB)								
  db.go:2402		0xaacf51		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2263		0xaacf59		0fb69424e8020000	MOVZX 0x2e8(SP), DX											
  db.go:2402		0xaacf61		488b9c2480010000	MOVQ 0x180(SP), BX											
  db.go:2402		0xaacf69		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  db.go:2402		0xaacf71		c6865106000001		MOVB $0x1, 0x651(SI)											
  db.go:2402		0xaacf78		48898e58060000		MOVQ CX, 0x658(SI)											
  db.go:2402		0xaacf7f		833d9a05480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2402		0xaacf86		7413			JE 0xaacf9b												
  db.go:2402		0xaacf88		488bbe60060000		MOVQ 0x660(SI), DI											
  db.go:2402		0xaacf8f		e8cc729eff		CALL runtime.gcWriteBarrier2(SB)									
  db.go:2402		0xaacf94		49891b			MOVQ BX, 0(R11)												
  db.go:2402		0xaacf97		49897b08		MOVQ DI, 0x8(R11)											
  db.go:2402		0xaacf9b		48899e60060000		MOVQ BX, 0x660(SI)											
  db.go:2403		0xaacfa2		488bbe40060000		MOVQ 0x640(SI), DI											
  db.go:2403		0xaacfa9		488b8648060000		MOVQ 0x648(SI), AX											
  db.go:2404		0xaacfb0		48c7864006000000000000	MOVQ $0x0, 0x640(SI)											
  db.go:2404		0xaacfbb		833d5e05480200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2404		0xaacfc2		7504			JNE 0xaacfc8												
  db.go:2263		0xaacfc4		84d2			TESTL DL, DL												
  db.go:2404		0xaacfc6		eb11			JMP 0xaacfd9												
  db.go:2404		0xaacfc8		4c8b8648060000		MOVQ 0x648(SI), R8											
  db.go:2404		0xaacfcf		e86c729eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2404		0xaacfd4		4d8903			MOVQ R8, 0(R11)												
  db.go:2263		0xaacfd7		84d2			TESTL DL, DL												
  db.go:2404		0xaacfd9		48c7864806000000000000	MOVQ $0x0, 0x648(SI)											
  db.go:2405		0xaacfe4		7550			JNE 0xaad036												
  db.go:2406		0xaacfe6		90			NOPL													
  mutex.go:194		0xaacfe7		baffffffff		MOVL $-0x1, DX												
  mutex.go:194		0xaacfec		f00fc196f0050000	LOCK XADDL DX, 0x5f0(SI)										
  mutex.go:194		0xaacff4		ffca			DECL DX													
  mutex.go:195		0xaacff6		743e			JE 0xaad036												
  db.go:2403		0xaacff8		4889bc24c8000000	MOVQ DI, 0xc8(SP)											
  db.go:2403		0xaad000		48898424c0010000	MOVQ AX, 0x1c0(SP)											
  mutex.go:65		0xaad008		488d86f0050000		LEAQ 0x5f0(SI), AX											
  mutex.go:198		0xaad00f		89d3			MOVL DX, BX												
  mutex.go:198		0xaad011		e8aaf59eff		CALL internal/sync.(*Mutex).unlockSlow(SB)								
  db.go:2409		0xaad016		488b8424c0010000	MOVQ 0x1c0(SP), AX											
  db.go:2411		0xaad01e		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2411		0xaad026		488b9c2480010000	MOVQ 0x180(SP), BX											
  db.go:2408		0xaad02e		488bbc24c8000000	MOVQ 0xc8(SP), DI											
  db.go:2408		0xaad036		4885ff			TESTQ DI, DI												
  db.go:2408		0xaad039		741f			JE 0xaad05a												
  db.go:2409		0xaad03b		488b5718		MOVQ 0x18(DI), DX											
  db.go:2399		0xaad03f		4889de			MOVQ BX, SI												
  db.go:2409		0xaad042		4889cb			MOVQ CX, BX												
  db.go:2409		0xaad045		4889f1			MOVQ SI, CX												
  db.go:2409		0xaad048		ffd2			CALL DX													
  db.go:2411		0xaad04a		488b8c24c0000000	MOVQ 0xc0(SP), CX											
  db.go:2411		0xaad052		488b9c2480010000	MOVQ 0x180(SP), BX											
  db.go:2411		0xaad05a		4889c8			MOVQ CX, AX												
  db.go:2411		0xaad05d		4881c4d0020000		ADDQ $0x2d0, SP												
  db.go:2411		0xaad064		5d			POPQ BP													
  db.go:2411		0xaad065		c3			RET													
  join.go:22		0xaad066		4889d7			MOVQ DX, DI												
  join.go:22		0xaad069		4883c210		ADDQ $0x10, DX												
  join.go:22		0xaad06d		48ffc1			INCQ CX													
  join.go:22		0xaad070		48833f00		CMPQ 0(DI), $0x0											
  join.go:23		0xaad074		400f95c7		SETNE DI												
  join.go:23		0xaad078		400fb6ff		MOVZX DI, DI												
  join.go:23		0xaad07c		4801fe			ADDQ DI, SI												
  join.go:23		0xaad07f		90			NOPL													
  join.go:22		0xaad080		4883f902		CMPQ CX, $0x2												
  join.go:22		0xaad084		7ce0			JL 0xaad066												
  join.go:27		0xaad086		4885f6			TESTQ SI, SI												
  join.go:27		0xaad089		7471			JE 0xaad0fc												
  join.go:22		0xaad08b		4889742450		MOVQ SI, 0x50(SP)											
  join.go:31		0xaad090		488d0589f71001		LEAQ 0x110f789(IP), AX											
  join.go:31		0xaad097		31db			XORL BX, BX												
  join.go:31		0xaad099		4889f1			MOVQ SI, CX												
  join.go:31		0xaad09c		0f1f4000		NOPL 0(AX)												
  join.go:31		0xaad0a0		e8fb1b9eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaad0a5		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaad0ad		488d05ac861301		LEAQ 0x11386ac(IP), AX											
  join.go:30		0xaad0b4		e8e77997ff		CALL runtime.newobject(SB)										
  join.go:31		0xaad0b9		488b542450		MOVQ 0x50(SP), DX											
  join.go:31		0xaad0be		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaad0c2		833d5704480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaad0c9		750a			JNE 0xaad0d5												
  join.go:31		0xaad0cb		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad0d3		eb10			JMP 0xaad0e5												
  join.go:31		0xaad0d5		e866719eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaad0da		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad0e2		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaad0e5		4889842490010000	MOVQ AX, 0x190(SP)											
  join.go:31		0xaad0ed		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaad0f0		488d942410020000	LEAQ 0x210(SP), DX											
  join.go:33		0xaad0f8		31c9			XORL CX, CX												
  join.go:33		0xaad0fa		eb64			JMP 0xaad160												
  join.go:33		0xaad0fc		31c9			XORL CX, CX												
  join.go:33		0xaad0fe		31d2			XORL DX, DX												
  db.go:2392		0xaad100		4885db			TESTQ BX, BX												
  db.go:2392		0xaad103		750d			JNE 0xaad112												
  db.go:2263		0xaad105		0fb6b424e8020000	MOVZX 0x2e8(SP), SI											
  db.go:2263		0xaad10d		4084f6			TESTL SI, SI												
  db.go:2392		0xaad110		eb37			JMP 0xaad149												
  db.go:2390		0xaad112		48899424e8010000	MOVQ DX, 0x1e8(SP)											
  db.go:2390		0xaad11a		48898c24e8000000	MOVQ CX, 0xe8(SP)											
  db.go:2393		0xaad122		e859e2b4ff		CALL github.com/snissn/gomap/TreeDB/internal/retainedalloc.(*Owner).RemovePending(SB)			
  db.go:2263		0xaad127		0fb68c24e8020000	MOVZX 0x2e8(SP), CX											
  db.go:2263		0xaad12f		84c9			TESTL CL, CL												
  db.go:2399		0xaad131		488b8c24e8000000	MOVQ 0xe8(SP), CX											
  db.go:2399		0xaad139		488b9424e8010000	MOVQ 0x1e8(SP), DX											
  db.go:2263		0xaad141		0fb6b424e8020000	MOVZX 0x2e8(SP), SI											
  db.go:2399		0xaad149		4889d0			MOVQ DX, AX												
  db.go:2263		0xaad14c		89f2			MOVL SI, DX												
  db.go:2263		0xaad14e		e9adfdffff		JMP 0xaacf00												
  join.go:33		0xaad153		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaad157		48ffc1			INCQ CX													
  join.go:33		0xaad15a		660f1f440000		NOPW 0(AX)(AX*1)											
  join.go:33		0xaad160		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaad164		0f8def000000		JGE 0xaad259												
  join.go:33		0xaad16a		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaad16d		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaad171		4d85c0			TESTQ R8, R8												
  join.go:34		0xaad174		74dd			JE 0xaad153												
  join.go:35		0xaad176		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaad17a		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaad17e		48ffc3			INCQ BX													
  join.go:35		0xaad181		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaad184		4939da			CMPQ R10, BX												
  join.go:35		0xaad187		0f838d000000		JAE 0xaad21a												
  join.go:33		0xaad18d		4c898c2450010000	MOVQ R9, 0x150(SP)											
  join.go:33		0xaad195		4c89842490000000	MOVQ R8, 0x90(SP)											
  join.go:33		0xaad19d		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaad1a5		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:35		0xaad1ad		4c89d8			MOVQ R11, AX												
  join.go:35		0xaad1b0		4c89d1			MOVQ R10, CX												
  join.go:35		0xaad1b3		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaad1b8		488d3561f61001		LEAQ 0x110f661(IP), SI											
  join.go:35		0xaad1bf		90			NOPL													
  join.go:35		0xaad1c0		e8bb1b9eff		CALL runtime.growslice(SB)										
  join.go:35		0xaad1c5		488b942490010000	MOVQ 0x190(SP), DX											
  join.go:35		0xaad1cd		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaad1d1		833d4803480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad1d8		7412			JE 0xaad1ec												
  join.go:35		0xaad1da		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaad1dd		0f1f00			NOPL 0(AX)												
  join.go:35		0xaad1e0		e87b709eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad1e5		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaad1e8		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad1ec		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaad1ef		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaad1f7		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaad1ff		4c8b842490000000	MOVQ 0x90(SP), R8											
  join.go:35		0xaad207		4c8b8c2450010000	MOVQ 0x150(SP), R9											
  join.go:35		0xaad20f		4989c3			MOVQ AX, R11												
  join.go:35		0xaad212		488b842490010000	MOVQ 0x190(SP), AX											
  join.go:35		0xaad21a		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaad21e		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaad222		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaad226		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaad22a		833def02480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad231		741c			JE 0xaad24f												
  join.go:35		0xaad233		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaad238		4c89db			MOVQ R11, BX												
  join.go:35		0xaad23b		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:35		0xaad240		e81b709eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad245		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaad248		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad24c		4989db			MOVQ BX, R11												
  join.go:35		0xaad24f		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaad254		e9fafeffff		JMP 0xaad153												
  db.go:2393		0xaad259		488b842440010000	MOVQ 0x140(SP), AX											
  db.go:2392		0xaad261		488b9c2488000000	MOVQ 0x88(SP), BX											
  db.go:2392		0xaad269		488d0db0194101		LEAQ go:itab.*errors.joinError,error(SB), CX								
  db.go:2390		0xaad270		488b942490010000	MOVQ 0x190(SP), DX											
  db.go:2390		0xaad278		e983feffff		JMP 0xaad100												
  db.go:2386		0xaad27d		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaad285		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2387		0xaad28d		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaad295		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaad29d		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaad2a3		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaad2a9		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaad2b1		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2329		0xaad2b9		4889ce			MOVQ CX, SI												
  db.go:2329		0xaad2bc		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2329		0xaad2c4		e922f7ffff		JMP 0xaac9eb												
  join.go:22		0xaad2c9		4889d6			MOVQ DX, SI												
  join.go:22		0xaad2cc		4883c210		ADDQ $0x10, DX												
  join.go:22		0xaad2d0		48ffc0			INCQ AX													
  join.go:22		0xaad2d3		48833e00		CMPQ 0(SI), $0x0											
  join.go:23		0xaad2d7		400f95c6		SETNE SI												
  join.go:23		0xaad2db		400fb6f6		MOVZX SI, SI												
  join.go:23		0xaad2df		4801f1			ADDQ SI, CX												
  join.go:22		0xaad2e2		4883f802		CMPQ AX, $0x2												
  join.go:22		0xaad2e6		7ce1			JL 0xaad2c9												
  join.go:27		0xaad2e8		4885c9			TESTQ CX, CX												
  join.go:27		0xaad2eb		7509			JNE 0xaad2f6												
  join.go:27		0xaad2ed		31c0			XORL AX, AX												
  join.go:27		0xaad2ef		31c9			XORL CX, CX												
  db.go:2319		0xaad2f1		e972010000		JMP 0xaad468												
  join.go:22		0xaad2f6		48894c2458		MOVQ CX, 0x58(SP)											
  join.go:31		0xaad2fb		488d051ef51001		LEAQ 0x110f51e(IP), AX											
  join.go:31		0xaad302		31db			XORL BX, BX												
  join.go:31		0xaad304		e897199eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaad309		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaad311		488d0548841301		LEAQ 0x1138448(IP), AX											
  join.go:30		0xaad318		e8837797ff		CALL runtime.newobject(SB)										
  join.go:31		0xaad31d		488b542458		MOVQ 0x58(SP), DX											
  join.go:31		0xaad322		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaad326		833df301480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaad32d		750a			JNE 0xaad339												
  join.go:31		0xaad32f		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad337		eb10			JMP 0xaad349												
  join.go:31		0xaad339		e8026f9eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaad33e		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad346		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaad349		4889842498010000	MOVQ AX, 0x198(SP)											
  join.go:31		0xaad351		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaad354		488d942430020000	LEAQ 0x230(SP), DX											
  join.go:33		0xaad35c		31c9			XORL CX, CX												
  join.go:33		0xaad35e		6690			NOPW													
  join.go:33		0xaad360		eb07			JMP 0xaad369												
  join.go:33		0xaad362		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaad366		48ffc1			INCQ CX													
  join.go:33		0xaad369		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaad36d		0f8de6000000		JGE 0xaad459												
  join.go:33		0xaad373		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaad376		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaad37a		4d85c0			TESTQ R8, R8												
  join.go:34		0xaad37d		74e3			JE 0xaad362												
  join.go:35		0xaad37f		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaad383		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaad387		48ffc3			INCQ BX													
  join.go:35		0xaad38a		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaad38d		4939da			CMPQ R10, BX												
  join.go:35		0xaad390		0f8389000000		JAE 0xaad41f												
  join.go:33		0xaad396		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaad39e		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:33		0xaad3a6		4c898c2458010000	MOVQ R9, 0x158(SP)											
  join.go:33		0xaad3ae		4c89842498000000	MOVQ R8, 0x98(SP)											
  join.go:35		0xaad3b6		4c89d8			MOVQ R11, AX												
  join.go:35		0xaad3b9		4c89d1			MOVQ R10, CX												
  join.go:35		0xaad3bc		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaad3c1		488d3558f41001		LEAQ 0x110f458(IP), SI											
  join.go:35		0xaad3c8		e8b3199eff		CALL runtime.growslice(SB)										
  join.go:35		0xaad3cd		488b942498010000	MOVQ 0x198(SP), DX											
  join.go:35		0xaad3d5		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaad3d9		833d4001480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad3e0		740f			JE 0xaad3f1												
  join.go:35		0xaad3e2		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaad3e5		e8766e9eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad3ea		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaad3ed		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad3f1		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaad3f4		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaad3fc		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaad404		4c8b842498000000	MOVQ 0x98(SP), R8											
  join.go:35		0xaad40c		4c8b8c2458010000	MOVQ 0x158(SP), R9											
  join.go:35		0xaad414		4989c3			MOVQ AX, R11												
  join.go:35		0xaad417		488b842498010000	MOVQ 0x198(SP), AX											
  join.go:35		0xaad41f		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaad423		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaad427		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaad42b		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaad42f		833dea00480200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad436		7417			JE 0xaad44f												
  join.go:35		0xaad438		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaad43d		4c89db			MOVQ R11, BX												
  join.go:35		0xaad440		e81b6e9eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad445		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaad448		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad44c		4989db			MOVQ BX, R11												
  join.go:35		0xaad44f		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaad454		e909ffffff		JMP 0xaad362												
  join.go:35		0xaad459		488d05c0174101		LEAQ go:itab.*errors.joinError,error(SB), AX								
  db.go:2319		0xaad460		488b8c2498010000	MOVQ 0x198(SP), CX											
  db.go:2324		0xaad468		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2324		0xaad470		4883ba2803000000	CMPQ 0x328(DX), $0x0											
  db.go:2324		0xaad478		0f84fffdffff		JE 0xaad27d												
  db.go:2319		0xaad47e		48898c24e0010000	MOVQ CX, 0x1e0(SP)											
  db.go:2319		0xaad486		48898424e0000000	MOVQ AX, 0xe0(SP)											
  db.go:2325		0xaad48e		488b8240030000		MOVQ 0x340(DX), AX											
  db.go:2325		0xaad495		e8e6ddd7ff		CALL github.com/snissn/gomap/TreeDB/internal/valuelog.(*Manager).CleanupError(SB)			
  db.go:2325		0xaad49a		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2325		0xaad4a2		488b8928030000		MOVQ 0x328(CX), CX											
  db.go:2325		0xaad4a9		4889c2			MOVQ AX, DX												
  db.go:2325		0xaad4ac		4889c8			MOVQ CX, AX												
  db.go:2325		0xaad4af		4889de			MOVQ BX, SI												
  db.go:2325		0xaad4b2		4889d3			MOVQ DX, BX												
  db.go:2325		0xaad4b5		4889f1			MOVQ SI, CX												
  db.go:2325		0xaad4b8		e8a3a60000		CALL github.com/snissn/gomap/TreeDB/db.(*DB).retainOriginalCleanupError(SB)				
  db.go:2325		0xaad4bd		488b8424e0000000	MOVQ 0xe0(SP), AX											
  db.go:2325		0xaad4c5		488b8c24e0010000	MOVQ 0x1e0(SP), CX											
  db.go:2329		0xaad4cd		488b9424e0020000	MOVQ 0x2e0(SP), DX											
  db.go:2325		0xaad4d5		e9a3fdffff		JMP 0xaad27d												
  db.go:2311		0xaad4da		488d942470020000	LEAQ 0x270(SP), DX											
  db.go:2311		0xaad4e2		440f113a		MOVUPS X15, 0(DX)											
  db.go:2311		0xaad4e6		440f117a10		MOVUPS X15, 0x10(DX)											
  db.go:2311		0xaad4eb		48899c2480020000	MOVQ BX, 0x280(SP)											
  db.go:2311		0xaad4f3		48898c2488020000	MOVQ CX, 0x288(SP)											
  join.go:22		0xaad4fb		31c0			XORL AX, AX												
  join.go:22		0xaad4fd		31f6			XORL SI, SI												
  join.go:22		0xaad4ff		90			NOPL													
  join.go:22		0xaad500		eb1e			JMP 0xaad520												
  join.go:22		0xaad502		4889d7			MOVQ DX, DI												
  join.go:22		0xaad505		4883c210		ADDQ $0x10, DX												
  join.go:22		0xaad509		48ffc0			INCQ AX													
  join.go:22		0xaad50c		48833f00		CMPQ 0(DI), $0x0											
  join.go:23		0xaad510		400f95c7		SETNE DI												
  join.go:23		0xaad514		400fb6ff		MOVZX DI, DI												
  join.go:23		0xaad518		4801fe			ADDQ DI, SI												
  join.go:23		0xaad51b		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:22		0xaad520		4883f802		CMPQ AX, $0x2												
  join.go:22		0xaad524		7cdc			JL 0xaad502												
  join.go:27		0xaad526		4885f6			TESTQ SI, SI												
  join.go:27		0xaad529		7509			JNE 0xaad534												
  join.go:27		0xaad52b		31c0			XORL AX, AX												
  join.go:27		0xaad52d		31d2			XORL DX, DX												
  db.go:2311		0xaad52f		e9a4010000		JMP 0xaad6d8												
  db.go:2311		0xaad534		48898c24d8010000	MOVQ CX, 0x1d8(SP)											
  db.go:2311		0xaad53c		48899c24d8000000	MOVQ BX, 0xd8(SP)											
  join.go:22		0xaad544		4889742468		MOVQ SI, 0x68(SP)											
  join.go:31		0xaad549		488d05d0f21001		LEAQ 0x110f2d0(IP), AX											
  join.go:31		0xaad550		31db			XORL BX, BX												
  join.go:31		0xaad552		4889f1			MOVQ SI, CX												
  join.go:31		0xaad555		e846179eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaad55a		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaad562		488d05f7811301		LEAQ 0x11381f7(IP), AX											
  join.go:30		0xaad569		e8327597ff		CALL runtime.newobject(SB)										
  join.go:31		0xaad56e		488b542468		MOVQ 0x68(SP), DX											
  join.go:31		0xaad573		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaad577		833da2ff470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaad57e		6690			NOPW													
  join.go:31		0xaad580		750a			JNE 0xaad58c												
  join.go:31		0xaad582		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad58a		eb10			JMP 0xaad59c												
  join.go:31		0xaad58c		e8af6c9eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaad591		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad599		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaad59c		48898424a8010000	MOVQ AX, 0x1a8(SP)											
  join.go:31		0xaad5a4		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaad5a7		488d942470020000	LEAQ 0x270(SP), DX											
  join.go:33		0xaad5af		31c9			XORL CX, CX												
  join.go:33		0xaad5b1		eb0d			JMP 0xaad5c0												
  join.go:33		0xaad5b3		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaad5b7		48ffc1			INCQ CX													
  join.go:33		0xaad5ba		660f1f440000		NOPW 0(AX)(AX*1)											
  join.go:33		0xaad5c0		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaad5c4		0f8def000000		JGE 0xaad6b9												
  join.go:33		0xaad5ca		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaad5cd		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaad5d1		4d85c0			TESTQ R8, R8												
  join.go:34		0xaad5d4		74dd			JE 0xaad5b3												
  join.go:35		0xaad5d6		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaad5da		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaad5de		48ffc3			INCQ BX													
  join.go:35		0xaad5e1		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaad5e4		4939da			CMPQ R10, BX												
  join.go:35		0xaad5e7		0f838d000000		JAE 0xaad67a												
  join.go:33		0xaad5ed		4c898c2468010000	MOVQ R9, 0x168(SP)											
  join.go:33		0xaad5f5		4c898424a8000000	MOVQ R8, 0xa8(SP)											
  join.go:33		0xaad5fd		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaad605		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:35		0xaad60d		4c89d8			MOVQ R11, AX												
  join.go:35		0xaad610		4c89d1			MOVQ R10, CX												
  join.go:35		0xaad613		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaad618		488d3501f21001		LEAQ 0x110f201(IP), SI											
  join.go:35		0xaad61f		90			NOPL													
  join.go:35		0xaad620		e85b179eff		CALL runtime.growslice(SB)										
  join.go:35		0xaad625		488b9424a8010000	MOVQ 0x1a8(SP), DX											
  join.go:35		0xaad62d		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaad631		833de8fe470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad638		7412			JE 0xaad64c												
  join.go:35		0xaad63a		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaad63d		0f1f00			NOPL 0(AX)												
  join.go:35		0xaad640		e81b6c9eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad645		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaad648		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad64c		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaad64f		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaad657		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaad65f		4c8b8424a8000000	MOVQ 0xa8(SP), R8											
  join.go:35		0xaad667		4c8b8c2468010000	MOVQ 0x168(SP), R9											
  join.go:35		0xaad66f		4989c3			MOVQ AX, R11												
  join.go:35		0xaad672		488b8424a8010000	MOVQ 0x1a8(SP), AX											
  join.go:35		0xaad67a		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaad67e		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaad682		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaad686		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaad68a		833d8ffe470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad691		741c			JE 0xaad6af												
  join.go:35		0xaad693		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaad698		4c89db			MOVQ R11, BX												
  join.go:35		0xaad69b		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:35		0xaad6a0		e8bb6b9eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad6a5		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaad6a8		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad6ac		4989db			MOVQ BX, R11												
  join.go:35		0xaad6af		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaad6b4		e9fafeffff		JMP 0xaad5b3												
  db.go:2316		0xaad6b9		488b8c24d8010000	MOVQ 0x1d8(SP), CX											
  db.go:2312		0xaad6c1		488b9c24d8000000	MOVQ 0xd8(SP), BX											
  db.go:2312		0xaad6c9		488d0550154101		LEAQ go:itab.*errors.joinError,error(SB), AX								
  db.go:2311		0xaad6d0		488b9424a8010000	MOVQ 0x1a8(SP), DX											
  db.go:2312		0xaad6d8		4885db			TESTQ BX, BX												
  db.go:2312		0xaad6db		740a			JE 0xaad6e7												
  db.go:2317		0xaad6dd		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  db.go:2312		0xaad6e5		eb35			JMP 0xaad71c												
  db.go:2313		0xaad6e7		833d32fe470200		CMPL runtime.writeBarrier(SB), $0x0									
  db.go:2313		0xaad6ee		750a			JNE 0xaad6fa												
  db.go:2313		0xaad6f0		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  db.go:2313		0xaad6f8		eb17			JMP 0xaad711												
  db.go:2313		0xaad6fa		488bb424e0020000	MOVQ 0x2e0(SP), SI											
  db.go:2313		0xaad702		488bbeb0020000		MOVQ 0x2b0(SI), DI											
  db.go:2313		0xaad709		e8326b9eff		CALL runtime.gcWriteBarrier1(SB)									
  db.go:2313		0xaad70e		49893b			MOVQ DI, 0(R11)												
  db.go:2313		0xaad711		48c786b002000000000000	MOVQ $0x0, 0x2b0(SI)											
  db.go:2387		0xaad71c		4c8b842430010000	MOVQ 0x130(SP), R8											
  db.go:2382		0xaad724		4c8b8c2420010000	MOVQ 0x120(SP), R9											
  db.go:2276		0xaad72c		440fb6542447		MOVZX 0x47(SP), R10											
  db.go:2277		0xaad732		440fb65c2446		MOVZX 0x46(SP), R11											
  db.go:2376		0xaad738		4c8ba42410010000	MOVQ 0x110(SP), R12											
  db.go:2347		0xaad740		4c8bac2488010000	MOVQ 0x188(SP), R13											
  db.go:2316		0xaad748		4889de			MOVQ BX, SI												
  db.go:2316		0xaad74b		4889c7			MOVQ AX, DI												
  db.go:2316		0xaad74e		4889c8			MOVQ CX, AX												
  db.go:2316		0xaad751		4989d7			MOVQ DX, R15												
  db.go:2317		0xaad754		488b8c24e0020000	MOVQ 0x2e0(SP), CX											
  db.go:2386		0xaad75c		488b942428010000	MOVQ 0x128(SP), DX											
  db.go:2374		0xaad764		0fb69c24e8020000	MOVZX 0x2e8(SP), BX											
  db.go:2374		0xaad76c		e9b0efffff		JMP 0xaac721												
  db.go:2297		0xaad771		488b8424c8010000	MOVQ 0x1c8(SP), AX											
  db.go:2297		0xaad779		488b9c2408020000	MOVQ 0x208(SP), BX											
  db.go:2297		0xaad781		31c9			XORL CX, CX												
  db.go:2297		0xaad783		e818d1c0ff		CALL github.com/snissn/gomap/TreeDB/internal/primaryarena.(*Arena).ReleaseQueueStep(SB)			
  db.go:2298		0xaad788		4885c9			TESTQ CX, CX												
  db.go:2298		0xaad78b		751a			JNE 0xaad7a7												
  db.go:2297		0xaad78d		84c0			TESTL AL, AL												
  db.go:2298		0xaad78f		7416			JE 0xaad7a7												
  db.go:2297		0xaad791		84db			TESTL BL, BL												
  db.go:2302		0xaad793		75dc			JNE 0xaad771												
  db.go:2302		0xaad795		488b442448		MOVQ 0x48(SP), AX											
  db.go:2302		0xaad79a		488b8c2408010000	MOVQ 0x108(SP), CX											
  db.go:2303		0xaad7a2		e9ed010000		JMP 0xaad994												
  db.go:2299		0xaad7a7		488d9424b0020000	LEAQ 0x2b0(SP), DX											
  db.go:2299		0xaad7af		440f113a		MOVUPS X15, 0(DX)											
  db.go:2299		0xaad7b3		440f117a10		MOVUPS X15, 0x10(DX)											
  db.go:2299		0xaad7b8		48898c24b0020000	MOVQ CX, 0x2b0(SP)											
  db.go:2299		0xaad7c0		4889bc24b8020000	MOVQ DI, 0x2b8(SP)											
  db.go:2299		0xaad7c8		488b3581383602		MOVQ github.com/snissn/gomap/TreeDB/internal/rootpublication.ErrResourceOwnership(SB), SI		
  db.go:2299		0xaad7cf		488b3d82383602		MOVQ github.com/snissn/gomap/TreeDB/internal/rootpublication.ErrResourceOwnership+8(SB), DI		
  db.go:2299		0xaad7d6		4889b424c0020000	MOVQ SI, 0x2c0(SP)											
  db.go:2299		0xaad7de		4889bc24c8020000	MOVQ DI, 0x2c8(SP)											
  join.go:22		0xaad7e6		31c0			XORL AX, AX												
  join.go:22		0xaad7e8		31c9			XORL CX, CX												
  join.go:22		0xaad7ea		eb19			JMP 0xaad805												
  join.go:22		0xaad7ec		4889d6			MOVQ DX, SI												
  join.go:22		0xaad7ef		4883c210		ADDQ $0x10, DX												
  join.go:22		0xaad7f3		48ffc0			INCQ AX													
  join.go:22		0xaad7f6		48833e00		CMPQ 0(SI), $0x0											
  join.go:23		0xaad7fa		400f95c6		SETNE SI												
  join.go:23		0xaad7fe		400fb6f6		MOVZX SI, SI												
  join.go:23		0xaad802		4801f1			ADDQ SI, CX												
  join.go:22		0xaad805		4883f802		CMPQ AX, $0x2												
  join.go:22		0xaad809		7ce1			JL 0xaad7ec												
  join.go:27		0xaad80b		4885c9			TESTQ CX, CX												
  join.go:27		0xaad80e		7509			JNE 0xaad819												
  join.go:27		0xaad810		31c0			XORL AX, AX												
  join.go:27		0xaad812		31c9			XORL CX, CX												
  db.go:2299		0xaad814		e97b010000		JMP 0xaad994												
  join.go:22		0xaad819		48894c2478		MOVQ CX, 0x78(SP)											
  join.go:31		0xaad81e		488d05fbef1001		LEAQ 0x110effb(IP), AX											
  join.go:31		0xaad825		31db			XORL BX, BX												
  join.go:31		0xaad827		e874149eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaad82c		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaad834		488d05257f1301		LEAQ 0x1137f25(IP), AX											
  join.go:30		0xaad83b		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:30		0xaad840		e85b7297ff		CALL runtime.newobject(SB)										
  join.go:31		0xaad845		488b542478		MOVQ 0x78(SP), DX											
  join.go:31		0xaad84a		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaad84e		833dcbfc470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaad855		750b			JNE 0xaad862												
  join.go:31		0xaad857		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad85f		90			NOPL													
  join.go:31		0xaad860		eb10			JMP 0xaad872												
  join.go:31		0xaad862		e8d9699eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaad867		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaad86f		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaad872		48898424b8010000	MOVQ AX, 0x1b8(SP)											
  join.go:31		0xaad87a		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaad87d		488d9424b0020000	LEAQ 0x2b0(SP), DX											
  join.go:33		0xaad885		31c9			XORL CX, CX												
  join.go:33		0xaad887		eb07			JMP 0xaad890												
  join.go:33		0xaad889		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaad88d		48ffc1			INCQ CX													
  join.go:33		0xaad890		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaad894		0f8deb000000		JGE 0xaad985												
  join.go:33		0xaad89a		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaad89d		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaad8a1		4d85c0			TESTQ R8, R8												
  join.go:34		0xaad8a4		74e3			JE 0xaad889												
  join.go:35		0xaad8a6		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaad8aa		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaad8ae		48ffc3			INCQ BX													
  join.go:35		0xaad8b1		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaad8b4		4939da			CMPQ R10, BX												
  join.go:35		0xaad8b7		0f8389000000		JAE 0xaad946												
  join.go:33		0xaad8bd		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaad8c5		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:33		0xaad8cd		4c898c2478010000	MOVQ R9, 0x178(SP)											
  join.go:33		0xaad8d5		4c898424b8000000	MOVQ R8, 0xb8(SP)											
  join.go:35		0xaad8dd		4c89d8			MOVQ R11, AX												
  join.go:35		0xaad8e0		4c89d1			MOVQ R10, CX												
  join.go:35		0xaad8e3		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaad8e8		488d3531ef1001		LEAQ 0x110ef31(IP), SI											
  join.go:35		0xaad8ef		e88c149eff		CALL runtime.growslice(SB)										
  join.go:35		0xaad8f4		488b9424b8010000	MOVQ 0x1b8(SP), DX											
  join.go:35		0xaad8fc		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaad900		833d19fc470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad907		740f			JE 0xaad918												
  join.go:35		0xaad909		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaad90c		e84f699eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad911		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaad914		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad918		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaad91b		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaad923		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaad92b		4c8b8424b8000000	MOVQ 0xb8(SP), R8											
  join.go:35		0xaad933		4c8b8c2478010000	MOVQ 0x178(SP), R9											
  join.go:35		0xaad93b		4989c3			MOVQ AX, R11												
  join.go:35		0xaad93e		488b8424b8010000	MOVQ 0x1b8(SP), AX											
  join.go:35		0xaad946		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaad94a		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaad94e		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaad952		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaad956		833dc3fb470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaad95d		7417			JE 0xaad976												
  join.go:35		0xaad95f		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaad964		4c89db			MOVQ R11, BX												
  join.go:35		0xaad967		e8f4689eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaad96c		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaad96f		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaad973		4989db			MOVQ BX, R11												
  join.go:35		0xaad976		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaad97b		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:35		0xaad980		e904ffffff		JMP 0xaad889												
  join.go:35		0xaad985		488d0594124101		LEAQ go:itab.*errors.joinError,error(SB), AX								
  db.go:2299		0xaad98c		488b8c24b8010000	MOVQ 0x1b8(SP), CX											
  db.go:2307		0xaad994		4889c3			MOVQ AX, BX												
  db.go:2307		0xaad997		660f1f840000000000	NOPW 0(AX)(AX*1)											
  db.go:2307		0xaad9a0		4885db			TESTQ BX, BX												
  db.go:2307		0xaad9a3		0f8431fbffff		JE 0xaad4da												
  db.go:2307		0xaad9a9		48898c24d0010000	MOVQ CX, 0x1d0(SP)											
  db.go:2307		0xaad9b1		48899c24d0000000	MOVQ BX, 0xd0(SP)											
  db.go:2308		0xaad9b9		488b8424c8010000	MOVQ 0x1c8(SP), AX											
  db.go:2308		0xaad9c1		488b9c2408020000	MOVQ 0x208(SP), BX											
  db.go:2308		0xaad9c9		e8d29cc1ff		CALL github.com/snissn/gomap/TreeDB/internal/primaryarena.(*Arena).PreserveOrdinaryReleaseQueue(SB)	
  db.go:2308		0xaad9ce		488b8c24d0000000	MOVQ 0xd0(SP), CX											
  db.go:2308		0xaad9d6		48898c2490020000	MOVQ CX, 0x290(SP)											
  db.go:2308		0xaad9de		488b8c24d0010000	MOVQ 0x1d0(SP), CX											
  db.go:2308		0xaad9e6		48898c2498020000	MOVQ CX, 0x298(SP)											
  db.go:2308		0xaad9ee		48898424a0020000	MOVQ AX, 0x2a0(SP)											
  db.go:2308		0xaad9f6		48899c24a8020000	MOVQ BX, 0x2a8(SP)											
  join.go:22		0xaad9fe		488d8c2490020000	LEAQ 0x290(SP), CX											
  join.go:22		0xaada06		31c0			XORL AX, AX												
  join.go:22		0xaada08		31d2			XORL DX, DX												
  join.go:22		0xaada0a		eb19			JMP 0xaada25												
  join.go:22		0xaada0c		4889ce			MOVQ CX, SI												
  join.go:22		0xaada0f		4883c110		ADDQ $0x10, CX												
  join.go:22		0xaada13		48ffc0			INCQ AX													
  join.go:22		0xaada16		48833e00		CMPQ 0(SI), $0x0											
  join.go:23		0xaada1a		400f95c6		SETNE SI												
  join.go:23		0xaada1e		400fb6f6		MOVZX SI, SI												
  join.go:23		0xaada22		4801f2			ADDQ SI, DX												
  join.go:22		0xaada25		4883f802		CMPQ AX, $0x2												
  join.go:22		0xaada29		7ce1			JL 0xaada0c												
  join.go:27		0xaada2b		4885d2			TESTQ DX, DX												
  join.go:27		0xaada2e		7509			JNE 0xaada39												
  join.go:27		0xaada30		31c0			XORL AX, AX												
  join.go:27		0xaada32		31c9			XORL CX, CX												
  db.go:2308		0xaada34		e97b010000		JMP 0xaadbb4												
  join.go:22		0xaada39		4889542470		MOVQ DX, 0x70(SP)											
  join.go:31		0xaada3e		488d05dbed1001		LEAQ 0x110eddb(IP), AX											
  join.go:31		0xaada45		31db			XORL BX, BX												
  join.go:31		0xaada47		4889d1			MOVQ DX, CX												
  join.go:31		0xaada4a		e851129eff		CALL runtime.makeslice(SB)										
  join.go:31		0xaada4f		4889842400020000	MOVQ AX, 0x200(SP)											
  join.go:30		0xaada57		488d05027d1301		LEAQ 0x1137d02(IP), AX											
  join.go:30		0xaada5e		6690			NOPW													
  join.go:30		0xaada60		e83b7097ff		CALL runtime.newobject(SB)										
  join.go:31		0xaada65		488b542470		MOVQ 0x70(SP), DX											
  join.go:31		0xaada6a		48895010		MOVQ DX, 0x10(AX)											
  join.go:31		0xaada6e		833dabfa470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:31		0xaada75		750b			JNE 0xaada82												
  join.go:31		0xaada77		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaada7f		90			NOPL													
  join.go:31		0xaada80		eb10			JMP 0xaada92												
  join.go:31		0xaada82		e8b9679eff		CALL runtime.gcWriteBarrier1(SB)									
  join.go:31		0xaada87		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:31		0xaada8f		498913			MOVQ DX, 0(R11)												
  join.go:30		0xaada92		48898424b0010000	MOVQ AX, 0x1b0(SP)											
  join.go:31		0xaada9a		488910			MOVQ DX, 0(AX)												
  join.go:33		0xaada9d		488d942490020000	LEAQ 0x290(SP), DX											
  join.go:33		0xaadaa5		31c9			XORL CX, CX												
  join.go:33		0xaadaa7		eb07			JMP 0xaadab0												
  join.go:33		0xaadaa9		4883c210		ADDQ $0x10, DX												
  join.go:33		0xaadaad		48ffc1			INCQ CX													
  join.go:33		0xaadab0		4883f902		CMPQ CX, $0x2												
  join.go:33		0xaadab4		0f8deb000000		JGE 0xaadba5												
  join.go:33		0xaadaba		4c8b02			MOVQ 0(DX), R8												
  join.go:33		0xaadabd		4c8b4a08		MOVQ 0x8(DX), R9											
  join.go:34		0xaadac1		4d85c0			TESTQ R8, R8												
  join.go:34		0xaadac4		74e3			JE 0xaadaa9												
  join.go:35		0xaadac6		4c8b5010		MOVQ 0x10(AX), R10											
  join.go:35		0xaadaca		488b5808		MOVQ 0x8(AX), BX											
  join.go:35		0xaadace		48ffc3			INCQ BX													
  join.go:35		0xaadad1		4c8b18			MOVQ 0(AX), R11												
  join.go:35		0xaadad4		4939da			CMPQ R10, BX												
  join.go:35		0xaadad7		0f8389000000		JAE 0xaadb66												
  join.go:33		0xaadadd		48898c2400010000	MOVQ CX, 0x100(SP)											
  join.go:33		0xaadae5		4889942400020000	MOVQ DX, 0x200(SP)											
  join.go:33		0xaadaed		4c898424b0000000	MOVQ R8, 0xb0(SP)											
  join.go:33		0xaadaf5		4c898c2470010000	MOVQ R9, 0x170(SP)											
  join.go:35		0xaadafd		4c89d8			MOVQ R11, AX												
  join.go:35		0xaadb00		4c89d1			MOVQ R10, CX												
  join.go:35		0xaadb03		bf01000000		MOVL $0x1, DI												
  join.go:35		0xaadb08		488d3511ed1001		LEAQ 0x110ed11(IP), SI											
  join.go:35		0xaadb0f		e86c129eff		CALL runtime.growslice(SB)										
  join.go:35		0xaadb14		488b9424b0010000	MOVQ 0x1b0(SP), DX											
  join.go:35		0xaadb1c		48894a10		MOVQ CX, 0x10(DX)											
  join.go:35		0xaadb20		833df9f9470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaadb27		740f			JE 0xaadb38												
  join.go:35		0xaadb29		4c8b02			MOVQ 0(DX), R8												
  join.go:35		0xaadb2c		e82f679eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaadb31		498903			MOVQ AX, 0(R11)												
  join.go:35		0xaadb34		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaadb38		488902			MOVQ AX, 0(DX)												
  join.go:33		0xaadb3b		488b8c2400010000	MOVQ 0x100(SP), CX											
  join.go:33		0xaadb43		488b942400020000	MOVQ 0x200(SP), DX											
  join.go:35		0xaadb4b		4c8b8424b0000000	MOVQ 0xb0(SP), R8											
  join.go:35		0xaadb53		4c8b8c2470010000	MOVQ 0x170(SP), R9											
  join.go:35		0xaadb5b		4989c3			MOVQ AX, R11												
  join.go:35		0xaadb5e		488b8424b0010000	MOVQ 0x1b0(SP), AX											
  join.go:35		0xaadb66		48895808		MOVQ BX, 0x8(AX)											
  join.go:35		0xaadb6a		4c8d53ff		LEAQ -0x1(BX), R10											
  join.go:35		0xaadb6e		49c1e204		SHLQ $0x4, R10												
  join.go:35		0xaadb72		4f890413		MOVQ R8, 0(R11)(R10*1)											
  join.go:35		0xaadb76		833da3f9470200		CMPL runtime.writeBarrier(SB), $0x0									
  join.go:35		0xaadb7d		7417			JE 0xaadb96												
  join.go:35		0xaadb7f		4f8b441308		MOVQ 0x8(R11)(R10*1), R8										
  join.go:35		0xaadb84		4c89db			MOVQ R11, BX												
  join.go:35		0xaadb87		e8d4669eff		CALL runtime.gcWriteBarrier2(SB)									
  join.go:35		0xaadb8c		4d890b			MOVQ R9, 0(R11)												
  join.go:35		0xaadb8f		4d894308		MOVQ R8, 0x8(R11)											
  join.go:35		0xaadb93		4989db			MOVQ BX, R11												
  join.go:35		0xaadb96		4f894c1308		MOVQ R9, 0x8(R11)(R10*1)										
  join.go:35		0xaadb9b		0f1f440000		NOPL 0(AX)(AX*1)											
  join.go:35		0xaadba0		e904ffffff		JMP 0xaadaa9												
  join.go:35		0xaadba5		488d0574104101		LEAQ go:itab.*errors.joinError,error(SB), AX								
  db.go:2308		0xaadbac		488b8c24b0010000	MOVQ 0x1b0(SP), CX											
  db.go:2308		0xaadbb4		4889c3			MOVQ AX, BX												
  db.go:2308		0xaadbb7		e91ef9ffff		JMP 0xaad4da												
  db.go:2262		0xaadbbc		4889442408		MOVQ AX, 0x8(SP)											
  db.go:2262		0xaadbc1		885c2410		MOVB BL, 0x10(SP)											
  db.go:2262		0xaadbc5		e8964b9eff		CALL runtime.morestack_noctxt.abi0(SB)									
  db.go:2262		0xaadbca		488b442408		MOVQ 0x8(SP), AX											
  db.go:2262		0xaadbcf		0fb65c2410		MOVZX 0x10(SP), BX											
  db.go:2262		0xaadbd4		e947e8ffff		JMP github.com/snissn/gomap/TreeDB/db.(*Snapshot).finalizeCloseRead(SB)					

TEXT github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:5044			0xabff80		4c8d6424f0		LEAQ -0x10(SP), R12										
  db.go:5044			0xabff85		4d3b6610		CMPQ R12, 0x10(R14)										
  db.go:5044			0xabff89		0f86dd010000		JBE 0xac016c											
  db.go:5044			0xabff8f		55			PUSHQ BP											
  db.go:5044			0xabff90		4889e5			MOVQ SP, BP											
  db.go:5044			0xabff93		4881ec88000000		SUBQ $0x88, SP											
  db.go:5044			0xabff9a		48899c24a0000000	MOVQ BX, 0xa0(SP)										
  db.go:5044			0xabffa2		4889b424b8000000	MOVQ SI, 0xb8(SP)										
  db.go:5044			0xabffaa		66440fd6bc2480000000	MOVQ X15, 0x80(SP)										
  db.go:5044			0xabffb4		c644243f00		MOVB $0x0, 0x3f(SP)										
  db.go:5044			0xabffb9		48c744245800000000	MOVQ $0x0, 0x58(SP)										
  db.go:5044			0xabffc2		440f117c2460		MOVUPS X15, 0x60(SP)										
  db.go:5044			0xabffc8		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  db.go:5044			0xabffd1		440f117c2448		MOVUPS X15, 0x48(SP)										
  db.go:5044			0xabffd7		660f1f840000000000	NOPW 0(AX)(AX*1)										
  snapshot_read_lifetime.go:8	0xabffe0		4885c0			TESTQ AX, AX											
  snapshot_read_lifetime.go:8	0xabffe3		0f850a010000		JNE 0xac00f3											
  db.go:5045			0xabffe9		488b1560fb3402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), DX					
  db.go:5045			0xabfff0		4c8b1561fb3402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), R10					
  db.go:5045			0xabfff7		660f1f840000000000	NOPW 0(AX)(AX*1)										
  db.go:5045			0xac0000		4885d2			TESTQ DX, DX											
  db.go:5045			0xac0003		0f85a2000000		JNE 0xac00ab											
  db.go:5048			0xac0009		488d15b0010000		LEAQ github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend.deferwrap1(SB), DX	
  db.go:5048			0xac0010		4889542470		MOVQ DX, 0x70(SP)										
  db.go:5048			0xac0015		4889442478		MOVQ AX, 0x78(SP)										
  db.go:5048			0xac001a		488d542470		LEAQ 0x70(SP), DX										
  db.go:5048			0xac001f		4889942480000000	MOVQ DX, 0x80(SP)										
  db.go:5048			0xac0027		c644243f01		MOVB $0x1, 0x3f(SP)										
  raw_kv_compat.go:7		0xac002c		4885db			TESTQ BX, BX											
  raw_kv_compat.go:7		0xac002f		7515			JNE 0xac0046											
  db.go:5049			0xac0031		488b1d883b3502		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey(SB), BX				
  db.go:5049			0xac0038		488b0d893b3502		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+8(SB), CX				
  db.go:5049			0xac003f		488b3d8a3b3502		MOVQ github.com/snissn/gomap/TreeDB/db.rawKVEmptyPointKey+16(SB), DI				
  db.go:5049			0xac0046		8400			TESTB AL, 0(AX)											
  db.go:5049			0xac0048		4805c8030000		ADDQ $0x3c8, AX											
  db.go:5049			0xac004e		e84db5c1ff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).GetVersionedAppend(SB)				
  db.go:5049			0xac0053		4889442458		MOVQ AX, 0x58(SP)										
  db.go:5049			0xac0058		48895c2460		MOVQ BX, 0x60(SP)										
  db.go:5049			0xac005d		48894c2468		MOVQ CX, 0x68(SP)										
  db.go:5049			0xac0062		48897c2440		MOVQ DI, 0x40(SP)										
  db.go:5049			0xac0067		4889742448		MOVQ SI, 0x48(SP)										
  db.go:5049			0xac006c		4c89442450		MOVQ R8, 0x50(SP)										
  db.go:5049			0xac0071		c644243f00		MOVB $0x0, 0x3f(SP)										
  db.go:5049			0xac0076		488b942480000000	MOVQ 0x80(SP), DX										
  db.go:5049			0xac007e		4c8b12			MOVQ 0(DX), R10											
  db.go:5049			0xac0081		41ffd2			CALL R10											
  db.go:5049			0xac0084		488b7c2440		MOVQ 0x40(SP), DI										
  db.go:5049			0xac0089		488b742448		MOVQ 0x48(SP), SI										
  db.go:5049			0xac008e		488b442458		MOVQ 0x58(SP), AX										
  db.go:5049			0xac0093		488b5c2460		MOVQ 0x60(SP), BX										
  db.go:5049			0xac0098		4c8b442450		MOVQ 0x50(SP), R8										
  db.go:5049			0xac009d		488b4c2468		MOVQ 0x68(SP), CX										
  db.go:5049			0xac00a2		4881c488000000		ADDQ $0x88, SP											
  db.go:5049			0xac00a9		5d			POPQ BP												
  db.go:5049			0xac00aa		c3			RET												
  db.go:5046			0xac00ab		4889742458		MOVQ SI, 0x58(SP)										
  db.go:5046			0xac00b0		4c89442460		MOVQ R8, 0x60(SP)										
  db.go:5046			0xac00b5		4c894c2468		MOVQ R9, 0x68(SP)										
  db.go:5046			0xac00ba		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  db.go:5046			0xac00c3		4889542448		MOVQ DX, 0x48(SP)										
  db.go:5046			0xac00c8		4c89542450		MOVQ R10, 0x50(SP)										
  db.go:5046			0xac00cd		488b7c2440		MOVQ 0x40(SP), DI										
  db.go:5046			0xac00d2		488b442458		MOVQ 0x58(SP), AX										
  db.go:5046			0xac00d7		488b5c2460		MOVQ 0x60(SP), BX										
  db.go:5046			0xac00dc		488b4c2468		MOVQ 0x68(SP), CX										
  db.go:5046			0xac00e1		4889d6			MOVQ DX, SI											
  db.go:5046			0xac00e4		4d89d0			MOVQ R10, R8											
  db.go:5046			0xac00e7		4881c488000000		ADDQ $0x88, SP											
  db.go:5046			0xac00ee		5d			POPQ BP												
  db.go:5046			0xac00ef		c3			RET												
  type.go:181			0xac00f0		4c89d8			MOVQ R11, AX											
  snapshot_read_lifetime.go:12	0xac00f3		90			NOPL												
  type.go:181			0xac00f4		488b90e8050000		MOVQ 0x5e8(AX), DX										
  snapshot_read_lifetime.go:13	0xac00fb		480fbae23f		BTQ $0x3f, DX											
  snapshot_read_lifetime.go:13	0xac0100		7227			JB 0xac0129											
  snapshot_read_lifetime.go:16	0xac0102		4c8d5201		LEAQ 0x1(DX), R10										
  snapshot_read_lifetime.go:8	0xac0106		4989c3			MOVQ AX, R11											
  type.go:191			0xac0109		4889d0			MOVQ DX, AX											
  type.go:191			0xac010c		f04d0fb193e8050000	LOCK CMPXCHGQ R10, 0x5e8(R11)									
  type.go:191			0xac0115		0f94c2			SETE DL												
  type.go:191			0xac0118		84d2			TESTL DL, DL											
  snapshot_read_lifetime.go:16	0xac011a		74d4			JE 0xac00f0											
  db.go:5048			0xac011c		4c89d8			MOVQ R11, AX											
  db.go:5048			0xac011f		31d2			XORL DX, DX											
  db.go:5048			0xac0121		4531d2			XORL R10, R10											
  db.go:5045			0xac0124		e9d7feffff		JMP 0xac0000											
  db.go:5045			0xac0129		488b1520fa3402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), DX					
  db.go:5045			0xac0130		4c8b1521fa3402		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), R10					
  db.go:5045			0xac0137		e9c4feffff		JMP 0xac0000											
  db.go:5045			0xac013c		0f1f4000		NOPL 0(AX)											
  db.go:5045			0xac0140		e8db0e99ff		CALL runtime.deferreturn(SB)									
  db.go:5045			0xac0145		488b442458		MOVQ 0x58(SP), AX										
  db.go:5045			0xac014a		488b5c2460		MOVQ 0x60(SP), BX										
  db.go:5045			0xac014f		488b4c2468		MOVQ 0x68(SP), CX										
  db.go:5045			0xac0154		488b7c2440		MOVQ 0x40(SP), DI										
  db.go:5045			0xac0159		488b742448		MOVQ 0x48(SP), SI										
  db.go:5045			0xac015e		4c8b442450		MOVQ 0x50(SP), R8										
  db.go:5045			0xac0163		4881c488000000		ADDQ $0x88, SP											
  db.go:5045			0xac016a		5d			POPQ BP												
  db.go:5045			0xac016b		c3			RET												
  db.go:5044			0xac016c		4889442408		MOVQ AX, 0x8(SP)										
  db.go:5044			0xac0171		48895c2410		MOVQ BX, 0x10(SP)										
  db.go:5044			0xac0176		48894c2418		MOVQ CX, 0x18(SP)										
  db.go:5044			0xac017b		48897c2420		MOVQ DI, 0x20(SP)										
  db.go:5044			0xac0180		4889742428		MOVQ SI, 0x28(SP)										
  db.go:5044			0xac0185		4c89442430		MOVQ R8, 0x30(SP)										
  db.go:5044			0xac018a		4c894c2438		MOVQ R9, 0x38(SP)										
  db.go:5044			0xac018f		e8cc259dff		CALL runtime.morestack_noctxt.abi0(SB)								
  db.go:5044			0xac0194		488b442408		MOVQ 0x8(SP), AX										
  db.go:5044			0xac0199		488b5c2410		MOVQ 0x10(SP), BX										
  db.go:5044			0xac019e		488b4c2418		MOVQ 0x18(SP), CX										
  db.go:5044			0xac01a3		488b7c2420		MOVQ 0x20(SP), DI										
  db.go:5044			0xac01a8		488b742428		MOVQ 0x28(SP), SI										
  db.go:5044			0xac01ad		4c8b442430		MOVQ 0x30(SP), R8										
  db.go:5044			0xac01b2		4c8b4c2438		MOVQ 0x38(SP), R9										
  db.go:5044			0xac01b7		e9c4fdffff		JMP github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend(SB)			

TEXT github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend.deferwrap1(SB) github.com/snissn/gomap/TreeDB/db/db.go
  db.go:5048		0xac01c0		493b6610		CMPQ SP, 0x10(R14)									
  db.go:5048		0xac01c4		7617			JBE 0xac01dd										
  db.go:5048		0xac01c6		55			PUSHQ BP										
  db.go:5048		0xac01c7		4889e5			MOVQ SP, BP										
  db.go:5048		0xac01ca		4883ec08		SUBQ $0x8, SP										
  db.go:5048		0xac01ce		488b4208		MOVQ 0x8(DX), AX									
  db.go:5048		0xac01d2		e8e93a1900		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).endRead(SB)				
  db.go:5048		0xac01d7		4883c408		ADDQ $0x8, SP										
  db.go:5048		0xac01db		5d			POPQ BP											
  db.go:5048		0xac01dc		c3			RET											
  db.go:5048		0xac01dd		0f1f00			NOPL 0(AX)										
  db.go:5048		0xac01e0		e8db249dff		CALL runtime.morestack.abi0(SB)								
  db.go:5048		0xac01e5		ebd9			JMP github.com/snissn/gomap/TreeDB/db.(*Snapshot).GetVersionedAppend.deferwrap1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrowCompletionV6(SB) github.com/snissn/gomap/TreeDB/db/index_gen.go
  index_gen.go:251	0xb34360		493b6610		CMPQ SP, 0x10(R14)									
  index_gen.go:251	0xb34364		0f867e020000		JBE 0xb345e8										
  index_gen.go:251	0xb3436a		55			PUSHQ BP										
  index_gen.go:251	0xb3436b		4889e5			MOVQ SP, BP										
  index_gen.go:251	0xb3436e		4883ec48		SUBQ $0x48, SP										
  index_gen.go:251	0xb34372		48894c2468		MOVQ CX, 0x68(SP)									
  index_gen.go:251	0xb34377		48897c2470		MOVQ DI, 0x70(SP)									
  index_gen.go:251	0xb3437c		0f1f4000		NOPL 0(AX)										
  index_gen.go:253	0xb34380		4885c9			TESTQ CX, CX										
  index_gen.go:253	0xb34383		740c			JE 0xb34391										
  index_gen.go:253	0xb34385		49b8ffffffffffffff7f	MOVQ $0x7fffffffffffffff, R8								
  index_gen.go:253	0xb3438f		eb38			JMP 0xb343c9										
  index_gen.go:254	0xb34391		90			NOPL											
  index_gen.go:242	0xb34392		90			NOPL											
  type.go:195		0xb34393		48c7c2ffffffff		MOVQ $-0x1, DX										
  type.go:195		0xb3439a		f0480fc15068		LOCK XADDQ DX, 0x68(AX)									
  type.go:195		0xb343a0		48ffca			DECQ DX											
  index_gen.go:243	0xb343a3		4889d6			MOVQ DX, SI										
  index_gen.go:243	0xb343a6		480fbaf23f		BTRQ $0x3f, DX										
  index_gen.go:243	0xb343ab		49b8ffffffffffffff7f	MOVQ $0x7fffffffffffffff, R8								
  index_gen.go:243	0xb343b5		4939d0			CMPQ R8, DX										
  index_gen.go:243	0xb343b8		0f8416020000		JE 0xb345d4										
  index_gen.go:255	0xb343be		480fbae63f		BTQ $0x3f, SI										
  index_gen.go:255	0xb343c3		0f83ea010000		JAE 0xb345b3										
  index_gen.go:253	0xb343c9		4889442458		MOVQ AX, 0x58(SP)									
  index_gen.go:253	0xb343ce		48895c2460		MOVQ BX, 0x60(SP)									
  index_gen.go:262	0xb343d3		90			NOPL											
  mutex.go:46		0xb343d4		488d505c		LEAQ 0x5c(AX), DX									
  mutex.go:46		0xb343d8		4889542430		MOVQ DX, 0x30(SP)									
  index_gen.go:253	0xb343dd		4889c6			MOVQ AX, SI										
  mutex.go:63		0xb343e0		31c0			XORL AX, AX										
  mutex.go:63		0xb343e2		41b901000000		MOVL $0x1, R9										
  mutex.go:63		0xb343e8		f0440fb14e5c		LOCK CMPXCHGL R9, 0x5c(SI)								
  mutex.go:63		0xb343ee		410f94c1		SETE R9											
  mutex.go:63		0xb343f2		4584c9			TESTL R9, R9										
  mutex.go:63		0xb343f5		7405			JE 0xb343fc										
  index_gen.go:253	0xb343f7		4885c9			TESTQ CX, CX										
  mutex.go:46		0xb343fa		eb38			JMP 0xb34434										
  index_gen.go:253	0xb343fc		48894c2468		MOVQ CX, 0x68(SP)									
  index_gen.go:253	0xb34401		48897c2470		MOVQ DI, 0x70(SP)									
  mutex.go:70		0xb34406		4889d0			MOVQ DX, AX										
  mutex.go:70		0xb34409		e8d27e96ff		CALL internal/sync.(*Mutex).lockSlow(SB)						
  index_gen.go:253	0xb3440e		488b4c2468		MOVQ 0x68(SP), CX									
  index_gen.go:253	0xb34413		4885c9			TESTQ CX, CX										
  mutex.go:198		0xb34416		488b542430		MOVQ 0x30(SP), DX									
  index_gen.go:268	0xb3441b		488b5c2460		MOVQ 0x60(SP), BX									
  index_gen.go:264	0xb34420		488b742458		MOVQ 0x58(SP), SI									
  index_gen.go:267	0xb34425		488b7c2470		MOVQ 0x70(SP), DI									
  index_gen.go:267	0xb3442a		49b8ffffffffffffff7f	MOVQ $0x7fffffffffffffff, R8								
  index_gen.go:264	0xb34434		7405			JE 0xb3443b										
  index_gen.go:253	0xb34436		4889c8			MOVQ CX, AX										
  index_gen.go:264	0xb34439		eb25			JMP 0xb34460										
  index_gen.go:264	0xb3443b		807e7100		CMPB 0x71(SI), $0x0									
  index_gen.go:264	0xb3443f		90			NOPL											
  index_gen.go:264	0xb34440		7416			JE 0xb34458										
  index_gen.go:265	0xb34442		488bbe98000000		MOVQ 0x98(SI), DI									
  index_gen.go:265	0xb34449		4c8b8e90000000		MOVQ 0x90(SI), R9									
  index_gen.go:253	0xb34450		4889c8			MOVQ CX, AX										
  index_gen.go:267	0xb34453		4c89c9			MOVQ R9, CX										
  index_gen.go:265	0xb34456		eb08			JMP 0xb34460										
  index_gen.go:253	0xb34458		4889c8			MOVQ CX, AX										
  index_gen.go:253	0xb3445b		0f1f440000		NOPL 0(AX)(AX*1)									
  index_gen.go:267	0xb34460		4885c9			TESTQ CX, CX										
  index_gen.go:267	0xb34463		0f84e2000000		JE 0xb3454b										
  index_gen.go:268	0xb34469		4885db			TESTQ BX, BX										
  index_gen.go:268	0xb3446c		7449			JE 0xb344b7										
  index_gen.go:253	0xb3446e		4885c0			TESTQ AX, AX										
  index_gen.go:271	0xb34471		750d			JNE 0xb34480										
  index_gen.go:272	0xb34473		90			NOPL											
  type.go:195		0xb34474		41b801000000		MOVL $0x1, R8										
  type.go:195		0xb3447a		f04c0fc14668		LOCK XADDQ R8, 0x68(SI)									
  index_gen.go:274	0xb34480		4c8b4678		MOVQ 0x78(SI), R8									
  index_gen.go:274	0xb34484		833d95903f0200		CMPL runtime.writeBarrier(SB), $0x0							
  index_gen.go:274	0xb3448b		741f			JE 0xb344ac										
  index_gen.go:274	0xb3448d		4c8b8bc8020000		MOVQ 0x2c8(BX), R9									
  index_gen.go:275	0xb34494		4c8b5678		MOVQ 0x78(SI), R10									
  index_gen.go:274	0xb34498		e803fe95ff		CALL runtime.gcWriteBarrier4(SB)							
  index_gen.go:274	0xb3449d		4d8903			MOVQ R8, 0(R11)										
  index_gen.go:274	0xb344a0		4d894b08		MOVQ R9, 0x8(R11)									
  index_gen.go:275	0xb344a4		49895b10		MOVQ BX, 0x10(R11)									
  index_gen.go:275	0xb344a8		4d895318		MOVQ R10, 0x18(R11)									
  index_gen.go:274	0xb344ac		4c8983c8020000		MOVQ R8, 0x2c8(BX)									
  index_gen.go:275	0xb344b3		48895e78		MOVQ BX, 0x78(SI)									
  index_gen.go:267	0xb344b7		48897c2440		MOVQ DI, 0x40(SP)									
  index_gen.go:267	0xb344bc		48894c2428		MOVQ CX, 0x28(SP)									
  index_gen.go:277	0xb344c1		488b4608		MOVQ 0x8(SI), AX									
  index_gen.go:277	0xb344c5		4885c0			TESTQ AX, AX										
  index_gen.go:277	0xb344c8		741e			JE 0xb344e8										
  index_gen.go:278	0xb344ca		e83178acff		CALL github.com/snissn/gomap/TreeDB/internal/retainedalloc.(*Owner).CleanupFailed(SB)	
  index_gen.go:284	0xb344cf		488b4c2428		MOVQ 0x28(SP), CX									
  mutex.go:198		0xb344d4		488b542430		MOVQ 0x30(SP), DX									
  index_gen.go:268	0xb344d9		488b5c2460		MOVQ 0x60(SP), BX									
  mutex.go:194		0xb344de		488b742458		MOVQ 0x58(SP), SI									
  index_gen.go:284	0xb344e3		488b7c2440		MOVQ 0x40(SP), DI									
  index_gen.go:280	0xb344e8		90			NOPL											
  mutex.go:65		0xb344e9		90			NOPL											
  mutex.go:194		0xb344ea		41b8ffffffff		MOVL $-0x1, R8										
  mutex.go:194		0xb344f0		f0440fc1465c		LOCK XADDL R8, 0x5c(SI)									
  mutex.go:194		0xb344f6		41ffc8			DECL R8											
  mutex.go:195		0xb344f9		7507			JNE 0xb34502										
  index_gen.go:268	0xb344fb		4885db			TESTQ BX, BX										
  index_gen.go:268	0xb344fe		6690			NOPW											
  mutex.go:195		0xb34500		eb22			JMP 0xb34524										
  mutex.go:198		0xb34502		4889d0			MOVQ DX, AX										
  mutex.go:198		0xb34505		4489c3			MOVL R8, BX										
  mutex.go:198		0xb34508		e8b38096ff		CALL internal/sync.(*Mutex).unlockSlow(SB)						
  index_gen.go:268	0xb3450d		488b4c2460		MOVQ 0x60(SP), CX									
  index_gen.go:268	0xb34512		4885c9			TESTQ CX, CX										
  index_gen.go:284	0xb34515		488b4c2428		MOVQ 0x28(SP), CX									
  index_gen.go:282	0xb3451a		488b742458		MOVQ 0x58(SP), SI									
  index_gen.go:284	0xb3451f		488b7c2440		MOVQ 0x40(SP), DI									
  index_gen.go:281	0xb34524		741b			JE 0xb34541										
  index_gen.go:282	0xb34526		488d8620010000		LEAQ 0x120(SI), AX									
  index_gen.go:282	0xb3452d		bb02000000		MOVL $0x2, BX										
  index_gen.go:282	0xb34532		e86931f8ff		CALL github.com/snissn/gomap/TreeDB/db.(*originalDBCleanupFailure).retainCause(SB)	
  index_gen.go:284	0xb34537		488b4c2428		MOVQ 0x28(SP), CX									
  index_gen.go:284	0xb3453c		488b7c2440		MOVQ 0x40(SP), DI									
  index_gen.go:284	0xb34541		31c0			XORL AX, AX										
  index_gen.go:284	0xb34543		31db			XORL BX, BX										
  index_gen.go:284	0xb34545		4883c448		ADDQ $0x48, SP										
  index_gen.go:284	0xb34549		5d			POPQ BP											
  index_gen.go:284	0xb3454a		c3			RET											
  index_gen.go:253	0xb3454b		4885c0			TESTQ AX, AX										
  index_gen.go:286	0xb3454e		741c			JE 0xb3456c										
  index_gen.go:287	0xb34550		90			NOPL											
  index_gen.go:242	0xb34551		90			NOPL											
  type.go:195		0xb34552		48c7c1ffffffff		MOVQ $-0x1, CX										
  type.go:195		0xb34559		f0480fc14e68		LOCK XADDQ CX, 0x68(SI)									
  type.go:195		0xb3455f		48ffc9			DECQ CX											
  index_gen.go:243	0xb34562		480fbaf13f		BTRQ $0x3f, CX										
  index_gen.go:243	0xb34567		4939c8			CMPQ R8, CX										
  index_gen.go:243	0xb3456a		7455			JE 0xb345c1										
  index_gen.go:289	0xb3456c		4889f0			MOVQ SI, AX										
  index_gen.go:289	0xb3456f		e86c030000		CALL github.com/snissn/gomap/TreeDB/db.(*indexGen).detachGenerationMetadataLockedV6(SB)	
  index_gen.go:290	0xb34574		90			NOPL											
  mutex.go:65		0xb34575		90			NOPL											
  mutex.go:194		0xb34576		b9ffffffff		MOVL $-0x1, CX										
  mutex.go:194		0xb3457b		488b542458		MOVQ 0x58(SP), DX									
  mutex.go:194		0xb34580		f00fc14a5c		LOCK XADDL CX, 0x5c(DX)									
  mutex.go:194		0xb34585		ffc9			DECL CX											
  mutex.go:195		0xb34587		7420			JE 0xb345a9										
  index_gen.go:289	0xb34589		4889442438		MOVQ AX, 0x38(SP)									
  index_gen.go:289	0xb3458e		48895c2420		MOVQ BX, 0x20(SP)									
  mutex.go:198		0xb34593		488b442430		MOVQ 0x30(SP), AX									
  mutex.go:198		0xb34598		89cb			MOVL CX, BX										
  mutex.go:198		0xb3459a		e8218096ff		CALL internal/sync.(*Mutex).unlockSlow(SB)						
  index_gen.go:291	0xb3459f		488b442438		MOVQ 0x38(SP), AX									
  index_gen.go:291	0xb345a4		488b5c2420		MOVQ 0x20(SP), BX									
  index_gen.go:291	0xb345a9		31c9			XORL CX, CX										
  index_gen.go:291	0xb345ab		31ff			XORL DI, DI										
  index_gen.go:291	0xb345ad		4883c448		ADDQ $0x48, SP										
  index_gen.go:291	0xb345b1		5d			POPQ BP											
  index_gen.go:291	0xb345b2		c3			RET											
  index_gen.go:258	0xb345b3		31c0			XORL AX, AX										
  index_gen.go:258	0xb345b5		31db			XORL BX, BX										
  index_gen.go:258	0xb345b7		31c9			XORL CX, CX										
  index_gen.go:258	0xb345b9		31ff			XORL DI, DI										
  index_gen.go:258	0xb345bb		4883c448		ADDQ $0x48, SP										
  index_gen.go:258	0xb345bf		5d			POPQ BP											
  index_gen.go:258	0xb345c0		c3			RET											
  index_gen.go:244	0xb345c1		488d05d89a0201		LEAQ 0x1029ad8(IP), AX									
  index_gen.go:244	0xb345c8		488d1d71dd3701		LEAQ 0x137dd71(IP), BX									
  index_gen.go:244	0xb345cf		e80c7c95ff		CALL runtime.gopanic(SB)								
  index_gen.go:244	0xb345d4		488d05c59a0201		LEAQ 0x1029ac5(IP), AX									
  index_gen.go:244	0xb345db		488d1d5edd3701		LEAQ 0x137dd5e(IP), BX									
  index_gen.go:244	0xb345e2		e8f97b95ff		CALL runtime.gopanic(SB)								
  index_gen.go:244	0xb345e7		90			NOPL											
  index_gen.go:251	0xb345e8		4889442408		MOVQ AX, 0x8(SP)									
  index_gen.go:251	0xb345ed		48895c2410		MOVQ BX, 0x10(SP)									
  index_gen.go:251	0xb345f2		48894c2418		MOVQ CX, 0x18(SP)									
  index_gen.go:251	0xb345f7		48897c2420		MOVQ DI, 0x20(SP)									
  index_gen.go:251	0xb345fc		0f1f4000		NOPL 0(AX)										
  index_gen.go:251	0xb34600		e85be195ff		CALL runtime.morestack_noctxt.abi0(SB)							
  index_gen.go:251	0xb34605		488b442408		MOVQ 0x8(SP), AX									
  index_gen.go:251	0xb3460a		488b5c2410		MOVQ 0x10(SP), BX									
  index_gen.go:251	0xb3460f		488b4c2418		MOVQ 0x18(SP), CX									
  index_gen.go:251	0xb34614		488b7c2420		MOVQ 0x20(SP), DI									
  index_gen.go:251	0xb34619		e942fdffff		JMP github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrowCompletionV6(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrow(SB) github.com/snissn/gomap/TreeDB/db/index_gen.go
  index_gen.go:294	0xb34620		493b6610		CMPQ SP, 0x10(R14)									
  index_gen.go:294	0xb34624		762a			JBE 0xb34650										
  index_gen.go:294	0xb34626		55			PUSHQ BP										
  index_gen.go:294	0xb34627		4889e5			MOVQ SP, BP										
  index_gen.go:294	0xb3462a		4883ec20		SUBQ $0x20, SP										
  index_gen.go:294	0xb3462e		48894c2440		MOVQ CX, 0x40(SP)									
  index_gen.go:294	0xb34633		48897c2448		MOVQ DI, 0x48(SP)									
  index_gen.go:295	0xb34638		e823fdffff		CALL github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrowCompletionV6(SB)	
  index_gen.go:295	0xb3463d		0f1f00			NOPL 0(AX)										
  index_gen.go:297	0xb34640		4885db			TESTQ BX, BX										
  index_gen.go:297	0xb34643		7405			JE 0xb3464a										
  index_gen.go:298	0xb34645		e8366dacff		CALL github.com/snissn/gomap/TreeDB/internal/retainedalloc.(*Owner).RemovePending(SB)	
  index_gen.go:300	0xb3464a		4883c420		ADDQ $0x20, SP										
  index_gen.go:300	0xb3464e		5d			POPQ BP											
  index_gen.go:300	0xb3464f		c3			RET											
  index_gen.go:294	0xb34650		4889442408		MOVQ AX, 0x8(SP)									
  index_gen.go:294	0xb34655		48895c2410		MOVQ BX, 0x10(SP)									
  index_gen.go:294	0xb3465a		48894c2418		MOVQ CX, 0x18(SP)									
  index_gen.go:294	0xb3465f		48897c2420		MOVQ DI, 0x20(SP)									
  index_gen.go:294	0xb34664		e8f7e095ff		CALL runtime.morestack_noctxt.abi0(SB)							
  index_gen.go:294	0xb34669		488b442408		MOVQ 0x8(SP), AX									
  index_gen.go:294	0xb3466e		488b5c2410		MOVQ 0x10(SP), BX									
  index_gen.go:294	0xb34673		488b4c2418		MOVQ 0x18(SP), CX									
  index_gen.go:294	0xb34678		488b7c2420		MOVQ 0x20(SP), DI									
  index_gen.go:294	0xb3467d		eba1			JMP github.com/snissn/gomap/TreeDB/db.(*indexGen).releaseWrapperBorrow(SB)		

TEXT github.com/snissn/gomap/TreeDB/db.(*DB).acquireOneShotReadOrErr(SB) github.com/snissn/gomap/TreeDB/db/pools.go
  pools.go:45		0xbfba60		493b6610		CMPQ SP, 0x10(R14)											
  pools.go:45		0xbfba64		0f8625010000		JBE 0xbfbb8f												
  pools.go:45		0xbfba6a		55			PUSHQ BP												
  pools.go:45		0xbfba6b		4889e5			MOVQ SP, BP												
  pools.go:45		0xbfba6e		4883ec28		SUBQ $0x28, SP												
  pools.go:46		0xbfba72		4885c0			TESTQ AX, AX												
  pools.go:46		0xbfba75		0f84ee000000		JE 0xbfbb69												
  pools.go:46		0xbfba7b		4889442438		MOVQ AX, 0x38(SP)											
  pools.go:49		0xbfba80		e81b71e6ff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).publicationPoisonedError(SB)				
  pools.go:49		0xbfba85		4885c0			TESTQ AX, AX												
  pools.go:49		0xbfba88		0f85cd000000		JNE 0xbfbb5b												
  pools.go:52		0xbfba8e		488d052b1f2202		LEAQ github.com/snissn/gomap/TreeDB/db.oneShotReadPool(SB), AX						
  pools.go:52		0xbfba95		e8e6108aff		CALL sync.(*Pool).Get(SB)										
  pools.go:52		0xbfba9a		488d0d7f5dfa00		LEAQ 0xfa5d7f(IP), CX											
  pools.go:52		0xbfbaa1		4839c8			CMPQ AX, CX												
  pools.go:52		0xbfbaa4		0f85d5000000		JNE 0xbfbb7f												
  pools.go:52		0xbfbaaa		48895c2420		MOVQ BX, 0x20(SP)											
  pools.go:53		0xbfbaaf		90			NOPL													
  type.go:94		0xbfbab0		ba01000000		MOVL $0x1, DX												
  type.go:94		0xbfbab5		488b442438		MOVQ 0x38(SP), AX											
  type.go:94		0xbfbaba		f00fc190a8070000	LOCK XADDL DX, 0x7a8(AX)										
  type.go:94		0xbfbac2		ffc2			INCL DX													
  rwmutex.go:72		0xbfbac4		85d2			TESTL DX, DX												
  rwmutex.go:72		0xbfbac6		7d19			JGE 0xbfbae1												
  rwmutex.go:74		0xbfbac8		4805a4070000		ADDQ $0x7a4, AX												
  rwmutex.go:74		0xbfbace		31db			XORL BX, BX												
  rwmutex.go:74		0xbfbad0		31c9			XORL CX, CX												
  rwmutex.go:74		0xbfbad2		e8292689ff		CALL sync.runtime_SemacquireRWMutexR(SB)								
  pools.go:54		0xbfbad7		488b442438		MOVQ 0x38(SP), AX											
  pools.go:54		0xbfbadc		488b5c2420		MOVQ 0x20(SP), BX											
  pools.go:54		0xbfbae1		8403			TESTB AL, 0(BX)												
  pools.go:54		0xbfbae3		b901000000		MOVL $0x1, CX												
  pools.go:54		0xbfbae8		e8f3dceaff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).captureSnapshotForReadWithValueLogPublicationLockHeld(SB)	
  type.go:94		0xbfbaed		bbffffffff		MOVL $-0x1, BX												
  type.go:94		0xbfbaf2		488b542438		MOVQ 0x38(SP), DX											
  type.go:94		0xbfbaf7		f00fc19aa8070000	LOCK XADDL BX, 0x7a8(DX)										
  type.go:94		0xbfbaff		ffcb			DECL BX													
  rwmutex.go:120	0xbfbb01		85db			TESTL BX, BX												
  rwmutex.go:120	0xbfbb03		7d15			JGE 0xbfbb1a												
  pools.go:54		0xbfbb05		8844241f		MOVB AL, 0x1f(SP)											
  pools.go:55		0xbfbb09		488d8298070000		LEAQ 0x798(DX), AX											
  rwmutex.go:122	0xbfbb10		e82b1d8aff		CALL sync.(*RWMutex).rUnlockSlow(SB)									
  pools.go:54		0xbfbb15		0fb644241f		MOVZX 0x1f(SP), AX											
  pools.go:54		0xbfbb1a		84c0			TESTL AL, AL												
  pools.go:56		0xbfbb1c		740f			JE 0xbfbb2d												
  pools.go:60		0xbfbb1e		488b442420		MOVQ 0x20(SP), AX											
  pools.go:60		0xbfbb23		31db			XORL BX, BX												
  pools.go:60		0xbfbb25		31c9			XORL CX, CX												
  pools.go:60		0xbfbb27		4883c428		ADDQ $0x28, SP												
  pools.go:60		0xbfbb2b		5d			POPQ BP													
  pools.go:60		0xbfbb2c		c3			RET													
  pools.go:57		0xbfbb2d		488d058c1e2202		LEAQ github.com/snissn/gomap/TreeDB/db.oneShotReadPool(SB), AX						
  pools.go:57		0xbfbb34		488d1de55cfa00		LEAQ 0xfa5ce5(IP), BX											
  pools.go:57		0xbfbb3b		488b4c2420		MOVQ 0x20(SP), CX											
  pools.go:57		0xbfbb40		e87b0f8aff		CALL sync.(*Pool).Put(SB)										
  pools.go:58		0xbfbb45		488b1d04402102		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), BX						
  pools.go:58		0xbfbb4c		488b0d05402102		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), CX						
  pools.go:58		0xbfbb53		31c0			XORL AX, AX												
  pools.go:58		0xbfbb55		4883c428		ADDQ $0x28, SP												
  pools.go:58		0xbfbb59		5d			POPQ BP													
  pools.go:58		0xbfbb5a		c3			RET													
  pools.go:50		0xbfbb5b		4889d9			MOVQ BX, CX												
  pools.go:50		0xbfbb5e		4889c3			MOVQ AX, BX												
  pools.go:50		0xbfbb61		31c0			XORL AX, AX												
  pools.go:50		0xbfbb63		4883c428		ADDQ $0x28, SP												
  pools.go:50		0xbfbb67		5d			POPQ BP													
  pools.go:50		0xbfbb68		c3			RET													
  pools.go:47		0xbfbb69		488b1de03f2102		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed(SB), BX						
  pools.go:47		0xbfbb70		488b0de13f2102		MOVQ github.com/snissn/gomap/TreeDB/db.ErrClosed+8(SB), CX						
  pools.go:47		0xbfbb77		31c0			XORL AX, AX												
  pools.go:47		0xbfbb79		4883c428		ADDQ $0x28, SP												
  pools.go:47		0xbfbb7d		5d			POPQ BP													
  pools.go:47		0xbfbb7e		c3			RET													
  pools.go:52		0xbfbb7f		4889cb			MOVQ CX, BX												
  pools.go:52		0xbfbb82		488d0db7d2f900		LEAQ 0xf9d2b7(IP), CX											
  pools.go:52		0xbfbb89		e8724e82ff		CALL runtime.panicdottypeE(SB)										
  pools.go:52		0xbfbb8e		90			NOPL													
  pools.go:45		0xbfbb8f		4889442408		MOVQ AX, 0x8(SP)											
  pools.go:45		0xbfbb94		e8c76b89ff		CALL runtime.morestack_noctxt.abi0(SB)									
  pools.go:45		0xbfbb99		488b442408		MOVQ 0x8(SP), AX											
  pools.go:45		0xbfbb9e		6690			NOPW													
  pools.go:45		0xbfbba0		e9bbfeffff		JMP github.com/snissn/gomap/TreeDB/db.(*DB).acquireOneShotReadOrErr(SB)					

TEXT github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB) github.com/snissn/gomap/TreeDB/db/pools.go
  pools.go:63		0xbfbbc0		493b6610		CMPQ SP, 0x10(R14)							
  pools.go:63		0xbfbbc4		7657			JBE 0xbfbc1d								
  pools.go:63		0xbfbbc6		55			PUSHQ BP								
  pools.go:63		0xbfbbc7		4889e5			MOVQ SP, BP								
  pools.go:63		0xbfbbca		4883ec28		SUBQ $0x28, SP								
  pools.go:67		0xbfbbce		4889442438		MOVQ AX, 0x38(SP)							
  pools.go:66		0xbfbbd3		8400			TESTB AL, 0(AX)								
  pools.go:66		0xbfbbd5		bb01000000		MOVL $0x1, BX								
  pools.go:66		0xbfbbda		e88106ebff		CALL github.com/snissn/gomap/TreeDB/db.(*Snapshot).closeRead(SB)	
  pools.go:66		0xbfbbdf		90			NOPL									
  pools.go:67		0xbfbbe0		4885c0			TESTQ AX, AX								
  pools.go:67		0xbfbbe3		7406			JE 0xbfbbeb								
  pools.go:70		0xbfbbe5		4883c428		ADDQ $0x28, SP								
  pools.go:70		0xbfbbe9		5d			POPQ BP									
  pools.go:70		0xbfbbea		c3			RET									
  pools.go:66		0xbfbbeb		48895c2420		MOVQ BX, 0x20(SP)							
  pools.go:66		0xbfbbf0		4889442418		MOVQ AX, 0x18(SP)							
  pools.go:76		0xbfbbf5		488d05c41d2202		LEAQ github.com/snissn/gomap/TreeDB/db.oneShotReadPool(SB), AX		
  pools.go:76		0xbfbbfc		488d1d1d5cfa00		LEAQ 0xfa5c1d(IP), BX							
  pools.go:76		0xbfbc03		488b4c2438		MOVQ 0x38(SP), CX							
  pools.go:76		0xbfbc08		e8b30e8aff		CALL sync.(*Pool).Put(SB)						
  pools.go:77		0xbfbc0d		488b442418		MOVQ 0x18(SP), AX							
  pools.go:77		0xbfbc12		488b5c2420		MOVQ 0x20(SP), BX							
  pools.go:77		0xbfbc17		4883c428		ADDQ $0x28, SP								
  pools.go:77		0xbfbc1b		5d			POPQ BP									
  pools.go:77		0xbfbc1c		c3			RET									
  pools.go:63		0xbfbc1d		4889442408		MOVQ AX, 0x8(SP)							
  pools.go:63		0xbfbc22		e8396b89ff		CALL runtime.morestack_noctxt.abi0(SB)					
  pools.go:63		0xbfbc27		488b442408		MOVQ 0x8(SP), AX							
  pools.go:63		0xbfbc2c		eb92			JMP github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB)		

TEXT github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).putRead(SB) github.com/snissn/gomap/TreeDB/db/pools.go
  pools.go:97		0xbfbd00		493b6610		CMPQ SP, 0x10(R14)							
  pools.go:97		0xbfbd04		0f8677030000		JBE 0xbfc081								
  pools.go:97		0xbfbd0a		55			PUSHQ BP								
  pools.go:97		0xbfbd0b		4889e5			MOVQ SP, BP								
  pools.go:97		0xbfbd0e		4883ec38		SUBQ $0x38, SP								
  pools.go:98		0xbfbd12		4885db			TESTQ BX, BX								
  pools.go:98		0xbfbd15		0f8460030000		JE 0xbfc07b								
  pools.go:98		0xbfbd1b		48895c2450		MOVQ BX, 0x50(SP)							
  pools.go:98		0xbfbd20		884c2458		MOVB CL, 0x58(SP)							
  pools.go:103		0xbfbd24		488d83c8030000		LEAQ 0x3c8(BX), AX							
  pools.go:103		0xbfbd2b		31db			XORL BX, BX								
  pools.go:103		0xbfbd2d		31c9			XORL CX, CX								
  pools.go:103		0xbfbd2f		31ff			XORL DI, DI								
  pools.go:103		0xbfbd31		31f6			XORL SI, SI								
  pools.go:103		0xbfbd33		e8c8a1adff		CALL github.com/snissn/gomap/TreeDB/tree.(*Tree).Reset(SB)		
  pools.go:104		0xbfbd38		833de117330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:104		0xbfbd3f		90			NOPL									
  pools.go:104		0xbfbd40		7507			JNE 0xbfbd49								
  pools.go:104		0xbfbd42		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:104		0xbfbd47		eb14			JMP 0xbfbd5d								
  pools.go:104		0xbfbd49		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:104		0xbfbd4e		488b8b10060000		MOVQ 0x610(BX), CX							
  pools.go:104		0xbfbd55		e8e68489ff		CALL runtime.gcWriteBarrier1(SB)					
  pools.go:104		0xbfbd5a		49890b			MOVQ CX, 0(R11)								
  pools.go:104		0xbfbd5d		48c7831006000000000000	MOVQ $0x0, 0x610(BX)							
  pools.go:105		0xbfbd68		48c7831806000000000000	MOVQ $0x0, 0x618(BX)							
  pools.go:98		0xbfbd73		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:98		0xbfbd78		0f1f840000000000	NOPL 0(AX)(AX*1)							
  pools.go:98		0xbfbd80		84c9			TESTL CL, CL								
  pools.go:106		0xbfbd82		0f8522010000		JNE 0xbfbeaa								
  pools.go:107		0xbfbd88		488b93c0050000		MOVQ 0x5c0(BX), DX							
  pools.go:107		0xbfbd8f		4885d2			TESTQ DX, DX								
  pools.go:107		0xbfbd92		7420			JE 0xbfbdb4								
  pools.go:107		0xbfbd94		4869caf8000000		IMULQ $0xf8, DX, CX							
  pools.go:107		0xbfbd9b		488b83b8050000		MOVQ 0x5b8(BX), AX							
  pools.go:107		0xbfbda2		4889cb			MOVQ CX, BX								
  pools.go:107		0xbfbda5		e896ed88ff		CALL runtime.memclrHasPointers(SB)					
  pools.go:98		0xbfbdaa		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:108		0xbfbdaf		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:108		0xbfbdb4		440f11bbc0050000	MOVUPS X15, 0x5c0(BX)							
  pools.go:108		0xbfbdbc		833d5d17330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:108		0xbfbdc3		740f			JE 0xbfbdd4								
  pools.go:108		0xbfbdc5		488b93b8050000		MOVQ 0x5b8(BX), DX							
  pools.go:108		0xbfbdcc		e86f8489ff		CALL runtime.gcWriteBarrier1(SB)					
  pools.go:108		0xbfbdd1		498913			MOVQ DX, 0(R11)								
  pools.go:108		0xbfbdd4		48c783b805000000000000	MOVQ $0x0, 0x5b8(BX)							
  pools.go:111		0xbfbddf		4883bbc004000000	CMPQ 0x4c0(BX), $0x0							
  pools.go:111		0xbfbde7		7466			JE 0xbfbe4f								
  pools.go:112		0xbfbde9		488d93c0040000		LEAQ 0x4c0(BX), DX							
  pools.go:112		0xbfbdf0		833d2917330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:112		0xbfbdf7		7423			JE 0xbfbe1c								
  pools.go:112		0xbfbdf9		4889542430		MOVQ DX, 0x30(SP)							
  pools.go:112		0xbfbdfe		488d057bb20201		LEAQ 0x102b27b(IP), AX							
  pools.go:112		0xbfbe05		4889d3			MOVQ DX, BX								
  pools.go:112		0xbfbe08		e8539482ff		CALL runtime.wbZero(SB)							
  pools.go:98		0xbfbe0d		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:112		0xbfbe12		488b542430		MOVQ 0x30(SP), DX							
  pools.go:116		0xbfbe17		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:112		0xbfbe1c		be03000000		MOVL $0x3, SI								
  pools.go:112		0xbfbe21		440f113a		MOVUPS X15, 0(DX)							
  pools.go:112		0xbfbe25		440f117a10		MOVUPS X15, 0x10(DX)							
  pools.go:112		0xbfbe2a		440f117a20		MOVUPS X15, 0x20(DX)							
  pools.go:112		0xbfbe2f		440f117a30		MOVUPS X15, 0x30(DX)							
  pools.go:112		0xbfbe34		4883c240		ADDQ $0x40, DX								
  pools.go:112		0xbfbe38		ffce			DECL SI									
  pools.go:112		0xbfbe3a		75e5			JNE 0xbfbe21								
  pools.go:112		0xbfbe3c		440f113a		MOVUPS X15, 0(DX)							
  pools.go:112		0xbfbe40		440f117a10		MOVUPS X15, 0x10(DX)							
  pools.go:112		0xbfbe45		440f117a20		MOVUPS X15, 0x20(DX)							
  pools.go:112		0xbfbe4a		440f117a28		MOVUPS X15, 0x28(DX)							
  pools.go:116		0xbfbe4f		488d9378020000		LEAQ 0x278(BX), DX							
  pools.go:116		0xbfbe56		833dc316330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:116		0xbfbe5d		7435			JE 0xbfbe94								
  pools.go:116		0xbfbe5f		4889542428		MOVQ DX, 0x28(SP)							
  pools.go:117		0xbfbe64		488b8ba8020000		MOVQ 0x2a8(BX), CX							
  pools.go:116		0xbfbe6b		e8d08389ff		CALL runtime.gcWriteBarrier1(SB)					
  pools.go:117		0xbfbe70		49890b			MOVQ CX, 0(R11)								
  pools.go:116		0xbfbe73		488d05a6bb0701		LEAQ 0x107bba6(IP), AX							
  pools.go:116		0xbfbe7a		4889d3			MOVQ DX, BX								
  pools.go:116		0xbfbe7d		0f1f00			NOPL 0(AX)								
  pools.go:116		0xbfbe80		e8db9382ff		CALL runtime.wbZero(SB)							
  pools.go:98		0xbfbe85		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:116		0xbfbe8a		488b542428		MOVQ 0x28(SP), DX							
  pools.go:117		0xbfbe8f		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:116		0xbfbe94		440f113a		MOVUPS X15, 0(DX)							
  pools.go:116		0xbfbe98		440f117a10		MOVUPS X15, 0x10(DX)							
  pools.go:116		0xbfbe9d		440f117a18		MOVUPS X15, 0x18(DX)							
  pools.go:117		0xbfbea2		440f11bba0020000	MOVUPS X15, 0x2a0(BX)							
  pools.go:119		0xbfbeaa		833d6f16330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:119		0xbfbeb1		7430			JE 0xbfbee3								
  pools.go:119		0xbfbeb3		488b9328030000		MOVQ 0x328(BX), DX							
  pools.go:120		0xbfbeba		488bb330030000		MOVQ 0x330(BX), SI							
  pools.go:121		0xbfbec1		488bbb38030000		MOVQ 0x338(BX), DI							
  pools.go:122		0xbfbec8		4c8b8340030000		MOVQ 0x340(BX), R8							
  pools.go:119		0xbfbecf		e8cc8389ff		CALL runtime.gcWriteBarrier4(SB)					
  pools.go:119		0xbfbed4		498913			MOVQ DX, 0(R11)								
  pools.go:120		0xbfbed7		49897308		MOVQ SI, 0x8(R11)							
  pools.go:121		0xbfbedb		49897b10		MOVQ DI, 0x10(R11)							
  pools.go:122		0xbfbedf		4d894318		MOVQ R8, 0x18(R11)							
  pools.go:119		0xbfbee3		440f11bb28030000	MOVUPS X15, 0x328(BX)							
  pools.go:121		0xbfbeeb		440f11bb38030000	MOVUPS X15, 0x338(BX)							
  pools.go:123		0xbfbef3		c6834903000000		MOVB $0x0, 0x349(BX)							
  pools.go:124		0xbfbefa		440f11bb60030000	MOVUPS X15, 0x360(BX)							
  pools.go:124		0xbfbf02		833d1716330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:124		0xbfbf09		741a			JE 0xbfbf25								
  pools.go:124		0xbfbf0b		488b9358030000		MOVQ 0x358(BX), DX							
  pools.go:125		0xbfbf12		488bb370030000		MOVQ 0x370(BX), SI							
  pools.go:124		0xbfbf19		e8428389ff		CALL runtime.gcWriteBarrier2(SB)					
  pools.go:124		0xbfbf1e		498913			MOVQ DX, 0(R11)								
  pools.go:125		0xbfbf21		49897308		MOVQ SI, 0x8(R11)							
  pools.go:124		0xbfbf25		48c7835803000000000000	MOVQ $0x0, 0x358(BX)							
  pools.go:125		0xbfbf30		440f11bb78030000	MOVUPS X15, 0x378(BX)							
  pools.go:125		0xbfbf38		48c7837003000000000000	MOVQ $0x0, 0x370(BX)							
  pools.go:126		0xbfbf43		488b9398030000		MOVQ 0x398(BX), DX							
  pools.go:126		0xbfbf4a		4885d2			TESTQ DX, DX								
  pools.go:126		0xbfbf4d		7420			JE 0xbfbf6f								
  pools.go:126		0xbfbf4f		488b8388030000		MOVQ 0x388(BX), AX							
  pools.go:127		0xbfbf56		48c1e203		SHLQ $0x3, DX								
  pools.go:127		0xbfbf5a		4889d3			MOVQ DX, BX								
  pools.go:127		0xbfbf5d		0f1f00			NOPL 0(AX)								
  pools.go:127		0xbfbf60		e8dbeb88ff		CALL runtime.memclrHasPointers(SB)					
  pools.go:98		0xbfbf65		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:129		0xbfbf6a		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:129		0xbfbf6f		48c7839003000000000000	MOVQ $0x0, 0x390(BX)							
  pools.go:130		0xbfbf7a		833d9f15330200		CMPL runtime.writeBarrier(SB), $0x0					
  pools.go:130		0xbfbf81		7504			JNE 0xbfbf87								
  pools.go:98		0xbfbf83		84c9			TESTL CL, CL								
  pools.go:130		0xbfbf85		eb2b			JMP 0xbfbfb2								
  pools.go:130		0xbfbf87		488b93a0030000		MOVQ 0x3a0(BX), DX							
  pools.go:131		0xbfbf8e		488bb3b8030000		MOVQ 0x3b8(BX), SI							
  pools.go:131		0xbfbf95		488bbbc0030000		MOVQ 0x3c0(BX), DI							
  pools.go:131		0xbfbf9c		0f1f4000		NOPL 0(AX)								
  pools.go:130		0xbfbfa0		e8db8289ff		CALL runtime.gcWriteBarrier3(SB)					
  pools.go:130		0xbfbfa5		498913			MOVQ DX, 0(R11)								
  pools.go:131		0xbfbfa8		49897308		MOVQ SI, 0x8(R11)							
  pools.go:131		0xbfbfac		49897b10		MOVQ DI, 0x10(R11)							
  pools.go:98		0xbfbfb0		84c9			TESTL CL, CL								
  pools.go:130		0xbfbfb2		48c783a003000000000000	MOVQ $0x0, 0x3a0(BX)							
  pools.go:131		0xbfbfbd		440f11bbb0030000	MOVUPS X15, 0x3b0(BX)							
  pools.go:131		0xbfbfc5		48c783c003000000000000	MOVQ $0x0, 0x3c0(BX)							
  pools.go:132		0xbfbfd0		48c783a803000000000000	MOVQ $0x0, 0x3a8(BX)							
  pools.go:133		0xbfbfdb		754c			JNE 0xbfc029								
  pools.go:134		0xbfbfdd		90			NOPL									
  mutex.go:63		0xbfbfde		31c0			XORL AX, AX								
  mutex.go:63		0xbfbfe0		ba01000000		MOVL $0x1, DX								
  mutex.go:63		0xbfbfe5		f00fb193f0050000	LOCK CMPXCHGL DX, 0x5f0(BX)						
  mutex.go:63		0xbfbfed		0f94c2			SETE DL									
  mutex.go:63		0xbfbff0		84d2			TESTL DL, DL								
  mutex.go:63		0xbfbff2		7516			JNE 0xbfc00a								
  mutex.go:46		0xbfbff4		488d83f0050000		LEAQ 0x5f0(BX), AX							
  mutex.go:46		0xbfbffb		0f1f440000		NOPL 0(AX)(AX*1)							
  mutex.go:70		0xbfc000		e8db028aff		CALL internal/sync.(*Mutex).lockSlow(SB)				
  pools.go:135		0xbfc005		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:135		0xbfc00a		488b9bf8050000		MOVQ 0x5f8(BX), BX							
  pools.go:135		0xbfc011		488d05e84afd00		LEAQ 0xfd4ae8(IP), AX							
  pools.go:135		0xbfc018		e8039282ff		CALL runtime.mapclear(SB)						
  pools.go:98		0xbfc01d		0fb64c2458		MOVZX 0x58(SP), CX							
  pools.go:98		0xbfc022		84c9			TESTL CL, CL								
  type.go:184		0xbfc024		488b5c2450		MOVQ 0x50(SP), BX							
  pools.go:137		0xbfc029		90			NOPL									
  type.go:184		0xbfc02a		48b90000000000000080	MOVQ $0x8000000000000000, CX						
  type.go:184		0xbfc034		48878be8050000		XCHGQ CX, 0x5e8(BX)							
  pools.go:138		0xbfc03b		90			NOPL									
  type.go:22		0xbfc03c		b901000000		MOVL $0x1, CX								
  type.go:22		0xbfc041		878bd0050000		XCHGL CX, 0x5d0(BX)							
  pools.go:139		0xbfc047		90			NOPL									
  type.go:22		0xbfc048		b900000000		MOVL $0x0, CX								
  type.go:22		0xbfc04d		878be0050000		XCHGL CX, 0x5e0(BX)							
  pools.go:140		0xbfc053		7520			JNE 0xbfc075								
  pools.go:141		0xbfc055		90			NOPL									
  mutex.go:194		0xbfc056		b9ffffffff		MOVL $-0x1, CX								
  mutex.go:194		0xbfc05b		f00fc18bf0050000	LOCK XADDL CX, 0x5f0(BX)						
  mutex.go:194		0xbfc063		ffc9			DECL CX									
  mutex.go:195		0xbfc065		740e			JE 0xbfc075								
  mutex.go:65		0xbfc067		488d83f0050000		LEAQ 0x5f0(BX), AX							
  mutex.go:198		0xbfc06e		89cb			MOVL CX, BX								
  mutex.go:198		0xbfc070		e84b058aff		CALL internal/sync.(*Mutex).unlockSlow(SB)				
  pools.go:144		0xbfc075		4883c438		ADDQ $0x38, SP								
  pools.go:144		0xbfc079		5d			POPQ BP									
  pools.go:144		0xbfc07a		c3			RET									
  pools.go:99		0xbfc07b		4883c438		ADDQ $0x38, SP								
  pools.go:99		0xbfc07f		5d			POPQ BP									
  pools.go:99		0xbfc080		c3			RET									
  pools.go:97		0xbfc081		4889442408		MOVQ AX, 0x8(SP)							
  pools.go:97		0xbfc086		48895c2410		MOVQ BX, 0x10(SP)							
  pools.go:97		0xbfc08b		884c2418		MOVB CL, 0x18(SP)							
  pools.go:97		0xbfc08f		e8cc6689ff		CALL runtime.morestack_noctxt.abi0(SB)					
  pools.go:97		0xbfc094		488b442408		MOVQ 0x8(SP), AX							
  pools.go:97		0xbfc099		488b5c2410		MOVQ 0x10(SP), BX							
  pools.go:97		0xbfc09e		0fb64c2418		MOVZX 0x18(SP), CX							
  pools.go:97		0xbfc0a3		e958fcffff		JMP github.com/snissn/gomap/TreeDB/db.(*SnapshotPool).putRead(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned(SB) github.com/snissn/gomap/TreeDB/db/conditional_kv_contract_bench_test.go
  conditional_kv_contract_bench_test.go:12	0xdd27e0		4c8da424c8f8ffff	LEAQ 0xfffff8c8(SP), R12							
  conditional_kv_contract_bench_test.go:12	0xdd27e8		4d3b6610		CMPQ R12, 0x10(R14)								
  conditional_kv_contract_bench_test.go:12	0xdd27ec		0f864d020000		JBE 0xdd2a3f									
  conditional_kv_contract_bench_test.go:12	0xdd27f2		55			PUSHQ BP									
  conditional_kv_contract_bench_test.go:12	0xdd27f3		4889e5			MOVQ SP, BP									
  conditional_kv_contract_bench_test.go:12	0xdd27f6		4881ecb0070000		SUBQ $0x7b0, SP									
  conditional_kv_contract_bench_test.go:12	0xdd27fd		66440fd6bc24a8070000	MOVQ X15, 0x7a8(SP)								
  conditional_kv_contract_bench_test.go:14	0xdd2807		48898424c0070000	MOVQ AX, 0x7c0(SP)								
  conditional_kv_contract_bench_test.go:12	0xdd280f		c684245707000000	MOVB $0x0, 0x757(SP)								
  conditional_kv_contract_bench_test.go:13	0xdd2817		8400			TESTB AL, 0(AX)									
  conditional_kv_contract_bench_test.go:13	0xdd2819		e8c27576ff		CALL testing.(*common).TempDir(SB)						
  conditional_kv_contract_bench_test.go:13	0xdd281e		4889e7			MOVQ SP, DI									
  conditional_kv_contract_bench_test.go:13	0xdd2821		b9ea000000		MOVL $0xea, CX									
  conditional_kv_contract_bench_test.go:13	0xdd2826		4889c2			MOVQ AX, DX									
  conditional_kv_contract_bench_test.go:13	0xdd2829		31c0			XORL AX, AX									
  conditional_kv_contract_bench_test.go:13	0xdd282b		f348ab			REP; STOSQ AX, ES:0(DI)								
  conditional_kv_contract_bench_test.go:13	0xdd282e		4889542408		MOVQ DX, 0x8(SP)								
  conditional_kv_contract_bench_test.go:13	0xdd2833		48895c2410		MOVQ BX, 0x10(SP)								
  conditional_kv_contract_bench_test.go:13	0xdd2838		e8a3b3cdff		CALL github.com/snissn/gomap/TreeDB/db.Open(SB)					
  conditional_kv_contract_bench_test.go:13	0xdd283d		4889842470070000	MOVQ AX, 0x770(SP)								
  conditional_kv_contract_bench_test.go:14	0xdd2845		4885db			TESTQ BX, BX									
  conditional_kv_contract_bench_test.go:14	0xdd2848		7450			JE 0xdd289a									
  conditional_kv_contract_bench_test.go:15	0xdd284a		440f11bc2498070000	MOVUPS X15, 0x798(SP)								
  conditional_kv_contract_bench_test.go:15	0xdd2853		7404			JE 0xdd2859									
  conditional_kv_contract_bench_test.go:15	0xdd2855		488b5b08		MOVQ 0x8(BX), BX								
  conditional_kv_contract_bench_test.go:15	0xdd2859		48899c2498070000	MOVQ BX, 0x798(SP)								
  conditional_kv_contract_bench_test.go:15	0xdd2861		48898c24a0070000	MOVQ CX, 0x7a0(SP)								
  conditional_kv_contract_bench_test.go:15	0xdd2869		488b8424c0070000	MOVQ 0x7c0(SP), AX								
  conditional_kv_contract_bench_test.go:15	0xdd2871		488d1dac44f900		LEAQ 0xf944ac(IP), BX								
  conditional_kv_contract_bench_test.go:15	0xdd2878		b908000000		MOVL $0x8, CX									
  conditional_kv_contract_bench_test.go:15	0xdd287d		488dbc2498070000	LEAQ 0x798(SP), DI								
  conditional_kv_contract_bench_test.go:15	0xdd2885		be01000000		MOVL $0x1, SI									
  conditional_kv_contract_bench_test.go:15	0xdd288a		4989f0			MOVQ SI, R8									
  conditional_kv_contract_bench_test.go:15	0xdd288d		e80e6876ff		CALL testing.(*common).Fatalf(SB)						
  conditional_kv_contract_bench_test.go:17	0xdd2892		488b842470070000	MOVQ 0x770(SP), AX								
  conditional_kv_contract_bench_test.go:17	0xdd289a		488d151f050000		LEAQ github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func1(SB), DX	
  conditional_kv_contract_bench_test.go:17	0xdd28a1		4889942480070000	MOVQ DX, 0x780(SP)								
  conditional_kv_contract_bench_test.go:17	0xdd28a9		4889842488070000	MOVQ AX, 0x788(SP)								
  conditional_kv_contract_bench_test.go:17	0xdd28b1		488b9424c0070000	MOVQ 0x7c0(SP), DX								
  conditional_kv_contract_bench_test.go:17	0xdd28b9		4889942490070000	MOVQ DX, 0x790(SP)								
  conditional_kv_contract_bench_test.go:17	0xdd28c1		488d942480070000	LEAQ 0x780(SP), DX								
  conditional_kv_contract_bench_test.go:17	0xdd28c9		48899424a8070000	MOVQ DX, 0x7a8(SP)								
  conditional_kv_contract_bench_test.go:17	0xdd28d1		c684245707000001	MOVB $0x1, 0x757(SP)								
  conditional_kv_contract_bench_test.go:24	0xdd28d9		488d0540b8d800		LEAQ 0xd8b840(IP), AX								
  conditional_kv_contract_bench_test.go:24	0xdd28e0		bb64000000		MOVL $0x64, BX									
  conditional_kv_contract_bench_test.go:24	0xdd28e5		4889d9			MOVQ BX, CX									
  conditional_kv_contract_bench_test.go:24	0xdd28e8		e8b3c36bff		CALL runtime.makeslice(SB)							
  conditional_kv_contract_bench_test.go:24	0xdd28ed		4889842478070000	MOVQ AX, 0x778(SP)								
  conditional_kv_contract_bench_test.go:25	0xdd28f5		b810270000		MOVL $0x2710, AX								
  conditional_kv_contract_bench_test.go:25	0xdd28fa		e8011d0000		CALL github.com/snissn/gomap/TreeDB/db.benchmarkConditionalTxnKeys(SB)		
  conditional_kv_contract_bench_test.go:25	0xdd28ff		4889842468070000	MOVQ AX, 0x768(SP)								
  conditional_kv_contract_bench_test.go:25	0xdd2907		48899c2458070000	MOVQ BX, 0x758(SP)								
  conditional_kv_contract_bench_test.go:25	0xdd290f		48898c2460070000	MOVQ CX, 0x760(SP)								
  conditional_kv_contract_bench_test.go:26	0xdd2917		4889df			MOVQ BX, DI									
  conditional_kv_contract_bench_test.go:26	0xdd291a		4889ce			MOVQ CX, SI									
  conditional_kv_contract_bench_test.go:26	0xdd291d		4c8b842478070000	MOVQ 0x778(SP), R8								
  conditional_kv_contract_bench_test.go:26	0xdd2925		41b964000000		MOVL $0x64, R9									
  conditional_kv_contract_bench_test.go:26	0xdd292b		4d89ca			MOVQ R9, R10									
  conditional_kv_contract_bench_test.go:26	0xdd292e		488b9c2470070000	MOVQ 0x770(SP), BX								
  conditional_kv_contract_bench_test.go:26	0xdd2936		4889c1			MOVQ AX, CX									
  conditional_kv_contract_bench_test.go:26	0xdd2939		488b8424c0070000	MOVQ 0x7c0(SP), AX								
  conditional_kv_contract_bench_test.go:26	0xdd2941		e8ba1d0000		CALL github.com/snissn/gomap/TreeDB/db.seedConditionalTxnBenchmarkData(SB)	
  conditional_kv_contract_bench_test.go:28	0xdd2946		90			NOPL										
  benchmark.go:193				0xdd2947		488b8424c0070000	MOVQ 0x7c0(SP), AX								
  benchmark.go:193				0xdd294f		c6805202000001		MOVB $0x1, 0x252(AX)								
  conditional_kv_contract_bench_test.go:29	0xdd2956		e825a275ff		CALL testing.(*B).ResetTimer(SB)						
  conditional_kv_contract_bench_test.go:30	0xdd295b		488d057eb3eb00		LEAQ 0xebb37e(IP), AX								
  conditional_kv_contract_bench_test.go:30	0xdd2962		e8392165ff		CALL runtime.newobject(SB)							
  conditional_kv_contract_bench_test.go:30	0xdd2967		488d15f2000000		LEAQ github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func2(SB), DX	
  conditional_kv_contract_bench_test.go:30	0xdd296e		488910			MOVQ DX, 0(AX)									
  conditional_kv_contract_bench_test.go:30	0xdd2971		48c7401064000000	MOVQ $0x64, 0x10(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd2979		48c7401864000000	MOVQ $0x64, 0x18(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd2981		833d98ab150200		CMPL runtime.writeBarrier(SB), $0x0						
  conditional_kv_contract_bench_test.go:30	0xdd2988		7522			JNE 0xdd29ac									
  conditional_kv_contract_bench_test.go:30	0xdd298a		488b8c2478070000	MOVQ 0x778(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xdd2992		488b942470070000	MOVQ 0x770(SP), DX								
  conditional_kv_contract_bench_test.go:30	0xdd299a		488bb42468070000	MOVQ 0x768(SP), SI								
  conditional_kv_contract_bench_test.go:30	0xdd29a2		488bbc24c0070000	MOVQ 0x7c0(SP), DI								
  conditional_kv_contract_bench_test.go:30	0xdd29aa		eb34			JMP 0xdd29e0									
  conditional_kv_contract_bench_test.go:30	0xdd29ac		e8ef186cff		CALL runtime.gcWriteBarrier4(SB)						
  conditional_kv_contract_bench_test.go:30	0xdd29b1		488b8c2478070000	MOVQ 0x778(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xdd29b9		49890b			MOVQ CX, 0(R11)									
  conditional_kv_contract_bench_test.go:30	0xdd29bc		488b942470070000	MOVQ 0x770(SP), DX								
  conditional_kv_contract_bench_test.go:30	0xdd29c4		49895308		MOVQ DX, 0x8(R11)								
  conditional_kv_contract_bench_test.go:30	0xdd29c8		488bb42468070000	MOVQ 0x768(SP), SI								
  conditional_kv_contract_bench_test.go:30	0xdd29d0		49897310		MOVQ SI, 0x10(R11)								
  conditional_kv_contract_bench_test.go:30	0xdd29d4		488bbc24c0070000	MOVQ 0x7c0(SP), DI								
  conditional_kv_contract_bench_test.go:30	0xdd29dc		49897b18		MOVQ DI, 0x18(R11)								
  conditional_kv_contract_bench_test.go:30	0xdd29e0		48894808		MOVQ CX, 0x8(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd29e4		48895020		MOVQ DX, 0x20(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd29e8		488b8c2458070000	MOVQ 0x758(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xdd29f0		48894830		MOVQ CX, 0x30(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd29f4		488b8c2460070000	MOVQ 0x760(SP), CX								
  conditional_kv_contract_bench_test.go:30	0xdd29fc		48894838		MOVQ CX, 0x38(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd2a00		48897028		MOVQ SI, 0x28(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd2a04		48897840		MOVQ DI, 0x40(AX)								
  conditional_kv_contract_bench_test.go:30	0xdd2a08		4889c3			MOVQ AX, BX									
  conditional_kv_contract_bench_test.go:30	0xdd2a0b		4889f8			MOVQ DI, AX									
  conditional_kv_contract_bench_test.go:30	0xdd2a0e		e80dd775ff		CALL testing.(*B).RunParallel(SB)						
  conditional_kv_contract_bench_test.go:43	0xdd2a13		c684245707000000	MOVB $0x0, 0x757(SP)								
  conditional_kv_contract_bench_test.go:43	0xdd2a1b		488b9424a8070000	MOVQ 0x7a8(SP), DX								
  conditional_kv_contract_bench_test.go:43	0xdd2a23		488b0a			MOVQ 0(DX), CX									
  conditional_kv_contract_bench_test.go:43	0xdd2a26		ffd1			CALL CX										
  conditional_kv_contract_bench_test.go:43	0xdd2a28		4881c4b0070000		ADDQ $0x7b0, SP									
  conditional_kv_contract_bench_test.go:43	0xdd2a2f		5d			POPQ BP										
  conditional_kv_contract_bench_test.go:43	0xdd2a30		c3			RET										
  conditional_kv_contract_bench_test.go:43	0xdd2a31		e8eae567ff		CALL runtime.deferreturn(SB)							
  conditional_kv_contract_bench_test.go:43	0xdd2a36		4881c4b0070000		ADDQ $0x7b0, SP									
  conditional_kv_contract_bench_test.go:43	0xdd2a3d		5d			POPQ BP										
  conditional_kv_contract_bench_test.go:43	0xdd2a3e		c3			RET										
  conditional_kv_contract_bench_test.go:12	0xdd2a3f		4889442408		MOVQ AX, 0x8(SP)								
  conditional_kv_contract_bench_test.go:12	0xdd2a44		e817fd6bff		CALL runtime.morestack_noctxt.abi0(SB)						
  conditional_kv_contract_bench_test.go:12	0xdd2a49		488b442408		MOVQ 0x8(SP), AX								
  conditional_kv_contract_bench_test.go:12	0xdd2a4e		e98dfdffff		JMP github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned(SB)			

TEXT github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func2(SB) github.com/snissn/gomap/TreeDB/db/conditional_kv_contract_bench_test.go
  conditional_kv_contract_bench_test.go:30	0xdd2a60		4c8d642480		LEAQ -0x80(SP), R12							
  conditional_kv_contract_bench_test.go:30	0xdd2a65		4d3b6610		CMPQ R12, 0x10(R14)							
  conditional_kv_contract_bench_test.go:30	0xdd2a69		0f8625030000		JBE 0xdd2d94								
  conditional_kv_contract_bench_test.go:30	0xdd2a6f		55			PUSHQ BP								
  conditional_kv_contract_bench_test.go:30	0xdd2a70		4889e5			MOVQ SP, BP								
  conditional_kv_contract_bench_test.go:30	0xdd2a73		4881ecf8000000		SUBQ $0xf8, SP								
  time.go:182					0xdd2a7a		4889842408010000	MOVQ AX, 0x108(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2a82		488b4230		MOVQ 0x30(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2a86		4889442458		MOVQ AX, 0x58(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2a8b		488b4240		MOVQ 0x40(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2a8f		4889442470		MOVQ AX, 0x70(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2a94		488b4210		MOVQ 0x10(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2a98		4889442440		MOVQ AX, 0x40(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2a9d		488b4228		MOVQ 0x28(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2aa1		4889442460		MOVQ AX, 0x60(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2aa6		488b4220		MOVQ 0x20(DX), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2aaa		4889442468		MOVQ AX, 0x68(SP)							
  conditional_kv_contract_bench_test.go:31	0xdd2aaf		e8acbd6eff		CALL time.Now(SB)							
  time.go:189					0xdd2ab4		90			NOPL									
  time.go:182					0xdd2ab5		480fbae03f		BTQ $0x3f, AX								
  time.go:182					0xdd2aba		7316			JAE 0xdd2ad2								
  time.go:183					0xdd2abc		488d0c00		LEAQ 0(AX)(AX*1), CX							
  time.go:183					0xdd2ac0		48c1e91f		SHRQ $0x1f, CX								
  time.go:183					0xdd2ac4		48ba807fb1d70d000000	MOVQ $0xdd7b17f80, DX							
  time.go:183					0xdd2ace		488d1c11		LEAQ 0(CX)(DX*1), BX							
  time.go:1461					0xdd2ad2		4869cb00ca9a3b		IMULQ $0x3b9aca00, BX, CX						
  time.go:177					0xdd2ad9		25ffffff3f		ANDL $0x3fffffff, AX							
  time.go:1461					0xdd2ade		4863d0			MOVSXD AX, DX								
  time.go:1461					0xdd2ae1		4801d1			ADDQ DX, CX								
  time.go:1461					0xdd2ae4		48ba00001a3deb03b2a1	MOVQ $0xa1b203eb3d1a0000, DX						
  time.go:1461					0xdd2aee		4801d1			ADDQ DX, CX								
  time.go:1461					0xdd2af1		48894c2438		MOVQ CX, 0x38(SP)							
  rand.go:52					0xdd2af6		90			NOPL									
  rand.go:56					0xdd2af7		488d05623fe800		LEAQ 0xe83f62(IP), AX							
  rand.go:56					0xdd2afe		6690			NOPW									
  rand.go:56					0xdd2b00		e89b1f65ff		CALL runtime.newobject(SB)						
  rand.go:56					0xdd2b05		48898424f0000000	MOVQ AX, 0xf0(SP)							
  rand.go:57					0xdd2b0d		488b5c2438		MOVQ 0x38(SP), BX							
  rand.go:57					0xdd2b12		e8097175ff		CALL math/rand.(*rngSource).Seed(SB)					
  rand.go:79					0xdd2b17		488b0d42260402		MOVQ github.com/snissn/gomap/TreeDB/db..typeAssert.174(SB), CX		
  rand.go:79					0xdd2b1e		488b11			MOVQ 0(CX), DX								
  rand.go:79					0xdd2b21		8b1d91f00e01		MOVL go:itab.*math/rand.rngSource,math/rand.Source+16(SB), BX		
  rand.go:79					0xdd2b27		eb03			JMP 0xdd2b2c								
  rand.go:79					0xdd2b29		4889f3			MOVQ SI, BX								
  rand.go:79					0xdd2b2c		4889de			MOVQ BX, SI								
  rand.go:79					0xdd2b2f		4821d3			ANDQ DX, BX								
  rand.go:79					0xdd2b32		48c1e304		SHLQ $0x4, BX								
  rand.go:79					0xdd2b36		488b7c0b08		MOVQ 0x8(BX)(CX*1), DI							
  rand.go:79					0xdd2b3b		4c8d059e33e100		LEAQ 0xe1339e(IP), R8							
  rand.go:79					0xdd2b42		4c39c7			CMPQ DI, R8								
  rand.go:79					0xdd2b45		741b			JE 0xdd2b62								
  rand.go:79					0xdd2b47		48ffc6			INCQ SI									
  rand.go:79					0xdd2b4a		4885ff			TESTQ DI, DI								
  rand.go:79					0xdd2b4d		75da			JNE 0xdd2b29								
  rand.go:79					0xdd2b4f		488d050a260402		LEAQ github.com/snissn/gomap/TreeDB/db..typeAssert.174(SB), AX		
  rand.go:79					0xdd2b56		4c89c3			MOVQ R8, BX								
  rand.go:79					0xdd2b59		e862e364ff		CALL runtime.typeAssert(SB)						
  rand.go:79					0xdd2b5e		6690			NOPW									
  rand.go:79					0xdd2b60		eb05			JMP 0xdd2b67								
  rand.go:79					0xdd2b62		488b440b10		MOVQ 0x10(BX)(CX*1), AX							
  rand.go:80					0xdd2b67		488d942480000000	LEAQ 0x80(SP), DX							
  rand.go:80					0xdd2b6f		440f113a		MOVUPS X15, 0(DX)							
  rand.go:80					0xdd2b73		440f117a10		MOVUPS X15, 0x10(DX)							
  rand.go:80					0xdd2b78		440f117a20		MOVUPS X15, 0x20(DX)							
  rand.go:80					0xdd2b7d		488d1524f00e01		LEAQ go:itab.*math/rand.rngSource,math/rand.Source(SB), DX		
  rand.go:80					0xdd2b84		4889942480000000	MOVQ DX, 0x80(SP)							
  rand.go:80					0xdd2b8c		488b9424f0000000	MOVQ 0xf0(SP), DX							
  rand.go:80					0xdd2b94		4889942488000000	MOVQ DX, 0x88(SP)							
  rand.go:80					0xdd2b9c		4889842490000000	MOVQ AX, 0x90(SP)							
  rand.go:80					0xdd2ba4		4889942498000000	MOVQ DX, 0x98(SP)							
  conditional_kv_contract_bench_test.go:32	0xdd2bac		488d056db5d800		LEAQ 0xd8b56d(IP), AX							
  conditional_kv_contract_bench_test.go:32	0xdd2bb3		31db			XORL BX, BX								
  conditional_kv_contract_bench_test.go:32	0xdd2bb5		488b4c2440		MOVQ 0x40(SP), CX							
  conditional_kv_contract_bench_test.go:32	0xdd2bba		e8e1c06bff		CALL runtime.makeslice(SB)						
  conditional_kv_contract_bench_test.go:32	0xdd2bbf		4889442478		MOVQ AX, 0x78(SP)							
  conditional_kv_contract_bench_test.go:33	0xdd2bc4		eb05			JMP 0xdd2bcb								
  conditional_kv_contract_bench_test.go:34	0xdd2bc6		488b442478		MOVQ 0x78(SP), AX							
  benchmark.go:923				0xdd2bcb		488b8c2408010000	MOVQ 0x108(SP), CX							
  benchmark.go:923				0xdd2bd3		4883791000		CMPQ 0x10(CX), $0x0							
  benchmark.go:923				0xdd2bd8		753c			JNE 0xdd2c16								
  benchmark.go:924				0xdd2bda		488b11			MOVQ 0(CX), DX								
  benchmark.go:924				0xdd2bdd		488b7108		MOVQ 0x8(CX), SI							
  type.go:195					0xdd2be1		4889f7			MOVQ SI, DI								
  type.go:195					0xdd2be4		f0480fc132		LOCK XADDQ SI, 0(DX)							
  benchmark.go:925				0xdd2be9		488b5118		MOVQ 0x18(CX), DX							
  type.go:195					0xdd2bed		4801fe			ADDQ DI, SI								
  benchmark.go:925				0xdd2bf0		4839f2			CMPQ DX, SI								
  benchmark.go:925				0xdd2bf3		720a			JB 0xdd2bff								
  benchmark.go:926				0xdd2bf5		488b5108		MOVQ 0x8(CX), DX							
  benchmark.go:926				0xdd2bf9		48895110		MOVQ DX, 0x10(CX)							
  benchmark.go:926				0xdd2bfd		eb17			JMP 0xdd2c16								
  benchmark.go:927				0xdd2bff		488b7908		MOVQ 0x8(CX), DI							
  benchmark.go:927				0xdd2c03		4801fa			ADDQ DI, DX								
  benchmark.go:927				0xdd2c06		4839d6			CMPQ SI, DX								
  benchmark.go:927				0xdd2c09		0f8376010000		JAE 0xdd2d85								
  benchmark.go:928				0xdd2c0f		4829f2			SUBQ SI, DX								
  benchmark.go:928				0xdd2c12		48895110		MOVQ DX, 0x10(CX)							
  benchmark.go:933				0xdd2c16		48ff4910		DECQ 0x10(CX)								
  conditional_kv_contract_bench_test.go:34	0xdd2c1a		488d842480000000	LEAQ 0x80(SP), AX							
  conditional_kv_contract_bench_test.go:34	0xdd2c22		bb10270000		MOVL $0x2710, BX							
  conditional_kv_contract_bench_test.go:34	0xdd2c27		e8d46175ff		CALL math/rand.(*Rand).Intn(SB)						
  conditional_kv_contract_bench_test.go:34	0xdd2c2c		488b4c2458		MOVQ 0x58(SP), CX							
  conditional_kv_contract_bench_test.go:34	0xdd2c31		4839c8			CMPQ AX, CX								
  conditional_kv_contract_bench_test.go:34	0xdd2c34		0f8354010000		JAE 0xdd2d8e								
  conditional_kv_contract_bench_test.go:34	0xdd2c3a		488d1440		LEAQ 0(AX)(AX*2), DX							
  conditional_kv_contract_bench_test.go:34	0xdd2c3e		4c8b542460		MOVQ 0x60(SP), R10							
  conditional_kv_contract_bench_test.go:34	0xdd2c43		498b1cd2		MOVQ 0(R10)(DX*8), BX							
  conditional_kv_contract_bench_test.go:34	0xdd2c47		498b4cd208		MOVQ 0x8(R10)(DX*8), CX							
  conditional_kv_contract_bench_test.go:34	0xdd2c4c		498b7cd210		MOVQ 0x10(R10)(DX*8), DI						
  conditional_kv_contract_bench_test.go:34	0xdd2c51		488b442468		MOVQ 0x68(SP), AX							
  conditional_kv_contract_bench_test.go:34	0xdd2c56		488b742478		MOVQ 0x78(SP), SI							
  conditional_kv_contract_bench_test.go:34	0xdd2c5b		4531c0			XORL R8, R8								
  conditional_kv_contract_bench_test.go:34	0xdd2c5e		4c8b4c2440		MOVQ 0x40(SP), R9							
  conditional_kv_contract_bench_test.go:34	0xdd2c63		e87836c6ff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).GetVersionedAppend(SB)	
  conditional_kv_contract_bench_test.go:34	0xdd2c68		48897c2448		MOVQ DI, 0x48(SP)							
  conditional_kv_contract_bench_test.go:35	0xdd2c6d		4885f6			TESTQ SI, SI								
  conditional_kv_contract_bench_test.go:35	0xdd2c70		7456			JE 0xdd2cc8								
  conditional_kv_contract_bench_test.go:34	0xdd2c72		48895c2450		MOVQ BX, 0x50(SP)							
  conditional_kv_contract_bench_test.go:36	0xdd2c77		440f11bc24e0000000	MOVUPS X15, 0xe0(SP)							
  conditional_kv_contract_bench_test.go:36	0xdd2c80		7404			JE 0xdd2c86								
  conditional_kv_contract_bench_test.go:36	0xdd2c82		488b7608		MOVQ 0x8(SI), SI							
  conditional_kv_contract_bench_test.go:36	0xdd2c86		4889b424e0000000	MOVQ SI, 0xe0(SP)							
  conditional_kv_contract_bench_test.go:36	0xdd2c8e		4c898424e8000000	MOVQ R8, 0xe8(SP)							
  conditional_kv_contract_bench_test.go:36	0xdd2c96		488b442470		MOVQ 0x70(SP), AX							
  conditional_kv_contract_bench_test.go:36	0xdd2c9b		8400			TESTB AL, 0(AX)								
  conditional_kv_contract_bench_test.go:36	0xdd2c9d		488d1d7fc1fa00		LEAQ 0xfac17f(IP), BX							
  conditional_kv_contract_bench_test.go:36	0xdd2ca4		b916000000		MOVL $0x16, CX								
  conditional_kv_contract_bench_test.go:36	0xdd2ca9		488dbc24e0000000	LEAQ 0xe0(SP), DI							
  conditional_kv_contract_bench_test.go:36	0xdd2cb1		be01000000		MOVL $0x1, SI								
  conditional_kv_contract_bench_test.go:36	0xdd2cb6		4989f0			MOVQ SI, R8								
  conditional_kv_contract_bench_test.go:36	0xdd2cb9		e8e26376ff		CALL testing.(*common).Fatalf(SB)					
  conditional_kv_contract_bench_test.go:38	0xdd2cbe		488b5c2450		MOVQ 0x50(SP), BX							
  conditional_kv_contract_bench_test.go:38	0xdd2cc3		488b7c2448		MOVQ 0x48(SP), DI							
  conditional_kv_contract_bench_test.go:38	0xdd2cc8		488b4c2440		MOVQ 0x40(SP), CX							
  conditional_kv_contract_bench_test.go:38	0xdd2ccd		4839cb			CMPQ BX, CX								
  conditional_kv_contract_bench_test.go:38	0xdd2cd0		7509			JNE 0xdd2cdb								
  conditional_kv_contract_bench_test.go:38	0xdd2cd2		4885ff			TESTQ DI, DI								
  conditional_kv_contract_bench_test.go:38	0xdd2cd5		0f85ebfeffff		JNE 0xdd2bc6								
  conditional_kv_contract_bench_test.go:39	0xdd2cdb		488d8c24b0000000	LEAQ 0xb0(SP), CX							
  conditional_kv_contract_bench_test.go:39	0xdd2ce3		440f1139		MOVUPS X15, 0(CX)							
  conditional_kv_contract_bench_test.go:39	0xdd2ce7		440f117910		MOVUPS X15, 0x10(CX)							
  conditional_kv_contract_bench_test.go:39	0xdd2cec		440f117920		MOVUPS X15, 0x20(CX)							
  conditional_kv_contract_bench_test.go:39	0xdd2cf1		4889d8			MOVQ BX, AX								
  conditional_kv_contract_bench_test.go:39	0xdd2cf4		e8876e6bff		CALL runtime.convT64(SB)						
  conditional_kv_contract_bench_test.go:39	0xdd2cf9		488d0de0b5d800		LEAQ 0xd8b5e0(IP), CX							
  conditional_kv_contract_bench_test.go:39	0xdd2d00		48898c24b0000000	MOVQ CX, 0xb0(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d08		48898424b8000000	MOVQ AX, 0xb8(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d10		488b442448		MOVQ 0x48(SP), AX							
  conditional_kv_contract_bench_test.go:39	0xdd2d15		e8666e6bff		CALL runtime.convT64(SB)						
  conditional_kv_contract_bench_test.go:39	0xdd2d1a		488d0dbfc1d800		LEAQ 0xd8c1bf(IP), CX							
  conditional_kv_contract_bench_test.go:39	0xdd2d21		48898c24c0000000	MOVQ CX, 0xc0(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d29		48898424c8000000	MOVQ AX, 0xc8(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d31		488b442440		MOVQ 0x40(SP), AX							
  conditional_kv_contract_bench_test.go:39	0xdd2d36		e8456e6bff		CALL runtime.convT64(SB)						
  conditional_kv_contract_bench_test.go:39	0xdd2d3b		488d0d9eb5d800		LEAQ 0xd8b59e(IP), CX							
  conditional_kv_contract_bench_test.go:39	0xdd2d42		48898c24d0000000	MOVQ CX, 0xd0(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d4a		48898424d8000000	MOVQ AX, 0xd8(SP)							
  conditional_kv_contract_bench_test.go:39	0xdd2d52		488b442470		MOVQ 0x70(SP), AX							
  conditional_kv_contract_bench_test.go:39	0xdd2d57		8400			TESTB AL, 0(AX)								
  conditional_kv_contract_bench_test.go:39	0xdd2d59		488d1d6cd20801		LEAQ 0x108d26c(IP), BX							
  conditional_kv_contract_bench_test.go:39	0xdd2d60		b946000000		MOVL $0x46, CX								
  conditional_kv_contract_bench_test.go:39	0xdd2d65		488dbc24b0000000	LEAQ 0xb0(SP), DI							
  conditional_kv_contract_bench_test.go:39	0xdd2d6d		be03000000		MOVL $0x3, SI								
  conditional_kv_contract_bench_test.go:39	0xdd2d72		4989f0			MOVQ SI, R8								
  conditional_kv_contract_bench_test.go:39	0xdd2d75		e8266376ff		CALL testing.(*common).Fatalf(SB)					
  conditional_kv_contract_bench_test.go:34	0xdd2d7a		488b4c2440		MOVQ 0x40(SP), CX							
  conditional_kv_contract_bench_test.go:34	0xdd2d7f		90			NOPL									
  conditional_kv_contract_bench_test.go:39	0xdd2d80		e941feffff		JMP 0xdd2bc6								
  conditional_kv_contract_bench_test.go:42	0xdd2d85		4881c4f8000000		ADDQ $0xf8, SP								
  conditional_kv_contract_bench_test.go:42	0xdd2d8c		5d			POPQ BP									
  conditional_kv_contract_bench_test.go:42	0xdd2d8d		c3			RET									
  conditional_kv_contract_bench_test.go:34	0xdd2d8e		e86d186cff		CALL runtime.panicBounds(SB)						
  conditional_kv_contract_bench_test.go:34	0xdd2d93		90			NOPL									
  conditional_kv_contract_bench_test.go:30	0xdd2d94		4889442408		MOVQ AX, 0x8(SP)							
  conditional_kv_contract_bench_test.go:30	0xdd2d99		e822f96bff		CALL runtime.morestack.abi0(SB)						
  conditional_kv_contract_bench_test.go:30	0xdd2d9e		488b442408		MOVQ 0x8(SP), AX							
  conditional_kv_contract_bench_test.go:30	0xdd2da3		e9b8fcffff		JMP github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func2(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func1(SB) github.com/snissn/gomap/TreeDB/db/conditional_kv_contract_bench_test.go
  conditional_kv_contract_bench_test.go:17	0xdd2dc0		493b6610		CMPQ SP, 0x10(R14)							
  conditional_kv_contract_bench_test.go:17	0xdd2dc4		7665			JBE 0xdd2e2b								
  conditional_kv_contract_bench_test.go:17	0xdd2dc6		55			PUSHQ BP								
  conditional_kv_contract_bench_test.go:17	0xdd2dc7		4889e5			MOVQ SP, BP								
  conditional_kv_contract_bench_test.go:17	0xdd2dca		4883ec48		SUBQ $0x48, SP								
  conditional_kv_contract_bench_test.go:17	0xdd2dce		488b4208		MOVQ 0x8(DX), AX							
  conditional_kv_contract_bench_test.go:17	0xdd2dd2		488b4a10		MOVQ 0x10(DX), CX							
  conditional_kv_contract_bench_test.go:17	0xdd2dd6		48894c2430		MOVQ CX, 0x30(SP)							
  conditional_kv_contract_bench_test.go:18	0xdd2ddb		0f1f440000		NOPL 0(AX)(AX*1)							
  conditional_kv_contract_bench_test.go:18	0xdd2de0		e87b20ceff		CALL github.com/snissn/gomap/TreeDB/db.(*DB).Close(SB)			
  conditional_kv_contract_bench_test.go:18	0xdd2de5		4885c0			TESTQ AX, AX								
  conditional_kv_contract_bench_test.go:18	0xdd2de8		743b			JE 0xdd2e25								
  conditional_kv_contract_bench_test.go:19	0xdd2dea		440f117c2438		MOVUPS X15, 0x38(SP)							
  conditional_kv_contract_bench_test.go:19	0xdd2df0		7404			JE 0xdd2df6								
  conditional_kv_contract_bench_test.go:19	0xdd2df2		488b4008		MOVQ 0x8(AX), AX							
  conditional_kv_contract_bench_test.go:19	0xdd2df6		4889442438		MOVQ AX, 0x38(SP)							
  conditional_kv_contract_bench_test.go:19	0xdd2dfb		48895c2440		MOVQ BX, 0x40(SP)							
  conditional_kv_contract_bench_test.go:19	0xdd2e00		488b442430		MOVQ 0x30(SP), AX							
  conditional_kv_contract_bench_test.go:19	0xdd2e05		8400			TESTB AL, 0(AX)								
  conditional_kv_contract_bench_test.go:19	0xdd2e07		488d1ddd4cf900		LEAQ 0xf94cdd(IP), BX							
  conditional_kv_contract_bench_test.go:19	0xdd2e0e		b909000000		MOVL $0x9, CX								
  conditional_kv_contract_bench_test.go:19	0xdd2e13		488d7c2438		LEAQ 0x38(SP), DI							
  conditional_kv_contract_bench_test.go:19	0xdd2e18		be01000000		MOVL $0x1, SI								
  conditional_kv_contract_bench_test.go:19	0xdd2e1d		4989f0			MOVQ SI, R8								
  conditional_kv_contract_bench_test.go:19	0xdd2e20		e87b6276ff		CALL testing.(*common).Fatalf(SB)					
  conditional_kv_contract_bench_test.go:21	0xdd2e25		4883c448		ADDQ $0x48, SP								
  conditional_kv_contract_bench_test.go:21	0xdd2e29		5d			POPQ BP									
  conditional_kv_contract_bench_test.go:21	0xdd2e2a		c3			RET									
  conditional_kv_contract_bench_test.go:17	0xdd2e2b		e890f86bff		CALL runtime.morestack.abi0(SB)						
  conditional_kv_contract_bench_test.go:17	0xdd2e30		eb8e			JMP github.com/snissn/gomap/TreeDB/db.BenchmarkGetVersioned.func1(SB)	

TEXT github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close-fm(SB) <autogenerated>
  <autogenerated>:1	0x1166ee0		493b6610		CMPQ SP, 0x10(R14)							
  <autogenerated>:1	0x1166ee4		7617			JBE 0x1166efd								
  <autogenerated>:1	0x1166ee6		55			PUSHQ BP								
  <autogenerated>:1	0x1166ee7		4889e5			MOVQ SP, BP								
  <autogenerated>:1	0x1166eea		4883ec08		SUBQ $0x8, SP								
  <autogenerated>:1	0x1166eee		488b4208		MOVQ 0x8(DX), AX							
  <autogenerated>:1	0x1166ef2		e8c94ca9ff		CALL github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close(SB)		
  <autogenerated>:1	0x1166ef7		4883c408		ADDQ $0x8, SP								
  <autogenerated>:1	0x1166efb		5d			POPQ BP									
  <autogenerated>:1	0x1166efc		c3			RET									
  <autogenerated>:1	0x1166efd		0f1f00			NOPL 0(AX)								
  <autogenerated>:1	0x1166f00		e8bbb732ff		CALL runtime.morestack.abi0(SB)						
  <autogenerated>:1	0x1166f05		ebd9			JMP github.com/snissn/gomap/TreeDB/db.(*oneShotRead).close-fm(SB)	
