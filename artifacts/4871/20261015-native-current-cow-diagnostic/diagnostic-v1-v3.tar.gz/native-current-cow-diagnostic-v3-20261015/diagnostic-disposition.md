V3 serial semantic guard PASS; continuing-write baseline deadlock; STOP.

The same physical DATA deletion, original durable Finish, old reader and reopen passed without a competing writer. No history cell completed. The matrix was stopped by SIGQUIT to exact PID1822044 after65.61s. No scaling or Q32/native ACK claim.

The prune retains the admission Cut while waiting original WaitThrough(seq5). After serialization is released, successor seq6 activation holds durablePublishMu and waits that Cut. The publisher needs durablePublishMu to Finish seq5. This is the missing prune/publication custody handoff; standard ordinary writes do not hold an external Cut this way.

The smallest coherent design uses the existing publication transaction to commit the SAME validated Cut at actual visibility, before releasing build locks, while preserving synchronous physical Finish before return. If the contract requires holding the mutex through Finish, publication admission ordering needs explicit redesign. No further wrapper experiment is recommended.

V2 failure was an invalid DB.Get missing-key oracle: the API returns nil,nil; V3 fixes exactly those four fixture checks. No stale PRIMARY finding: the original finalizer wraps new DATA with BuildPrimaryRoot and installs the new certificate. All3759 source inputs remained identical through this run; production unchanged.
