//go:build treedb_current_cow_diagnostic

package db

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"runtime"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	batchpkg "github.com/snissn/gomap/TreeDB/batch"
	"github.com/snissn/gomap/TreeDB/freelist"
	"github.com/snissn/gomap/TreeDB/internal/adaptive"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/mvccadmission"
	"github.com/snissn/gomap/TreeDB/internal/mvcckey"
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
	"github.com/snissn/gomap/TreeDB/tree"
	"github.com/snissn/gomap/TreeDB/zipper"
)

type currentCOWDiagnosticCell struct {
	Name                    string
	History, Segments, Pins int
	ReleaseHistoryReader    bool
}
type currentCOWDiagnosticResult struct {
	PhysicalDataRemoved                                                                        bool
	Cell                                                                                       currentCOWDiagnosticCell
	Durability                                                                                 string
	Error                                                                                      string
	Accepted, PhysicalFinish, Removed, OldReader, Keeper, Future, Reopen                       bool
	SelectedSnapshotClosedBeforeMutation                                                       bool
	OuterNS, AdmissionNS, ValidateNS, MutationNS, RefDeltaNS, PublishAndFinishNS, GroupCloseNS int64
	OuterBytes, OuterObjects                                                                   uint64
	WriterBefore, WriterAfter                                                                  uint64
	CapturedRoot, CapturedSeq, PublishedSeq                                                    uint64
	Before, After                                                                              freelist.COWPrepareProfileV1
	Geometry                                                                                   zipper.ReadOnlyPrepareResult
	GeometryError                                                                              string
	Metrics                                                                                    adaptive.Metrics
	Publication                                                                                CommandWALPublishTiming
}

// This fixture owns one actual DB admission capability. It does not instantiate
// Store or the native selector/constructor. All selected and anchor bytes come
// from a real immutable backend Snapshot, and the same Request is revalidated
// against the fresh serialized current root before any mutation. It is a source-
// bound diagnostic, never a public-native activation or Q32 acceptance control.
func runCurrentCOWDiagnostic(db *DB, selected, anchor node.LeafEntry, request mvccadmission.Request, r *currentCOWDiagnosticResult) (retErr error) {
	var before, after runtime.MemStats
	runtime.ReadMemStats(&before)
	start := time.Now()
	defer func() {
		r.OuterNS = time.Since(start).Nanoseconds()
		runtime.ReadMemStats(&after)
		r.OuterBytes, r.OuterObjects = after.TotalAlloc-before.TotalAlloc, after.Mallocs-before.Mallocs
	}()
	phase := time.Now()
	group, err := db.BeginRootPublicationBuildGroup()
	r.AdmissionNS = time.Since(phase).Nanoseconds()
	if err != nil {
		return err
	}
	defer func() {
		phase := time.Now()
		retErr = errors.Join(retErr, group.Close())
		r.GroupCloseNS = time.Since(phase).Nanoseconds()
	}()
	group.mu.Lock()
	defer group.mu.Unlock()
	r.CapturedRoot, r.CapturedSeq = group.currentRoot, group.baseSeq
	// Borrow the SAME pinned current value-log Set. No new Snapshot or registry
	// authority is created by this temporary current-root read view.
	current := tree.New(group.idx.pager, newValueReader(db.state.Load().ValueLogSet), group.currentRoot)
	phase = time.Now()
	cut := db.mvccAdmission.Begin()
	defer cut.Abort()
	w := &iterator.OrdinalScanWork{RecordLimit: ^uint64(0), ByteLimit: ^uint64(0)}
	if ready, e := cut.ObservePrune(request, selected.Key, w); !ready || e != nil {
		return errors.Join(e, errors.New("request refused"))
	}
	for _, expected := range []node.LeafEntry{selected, anchor} {
		got, e := current.GetEntry(expected.Key)
		if e != nil {
			return e
		}
		if got.Revision != expected.Revision || got.Flags != expected.Flags || got.ValuePtr != expected.ValuePtr || !bytes.Equal(got.Key, expected.Key) || !bytes.Equal(got.Value, expected.Value) {
			return errors.New("exact current winner changed")
		}
	}
	r.ValidateNS = time.Since(phase).Nanoseconds()
	physical := db.NewPhysicalBatch().(*Batch)
	defer func() { retErr = errors.Join(retErr, physical.Close()) }()
	delta := physical.batch
	if err = delta.SetOps([]batchpkg.Entry{{Type: batchpkg.OpDelete, Key: selected.Key, Revision: selected.Revision}}); err != nil {
		return err
	}
	z := group.idx.zipper.CloneWithAllocator(group.tracker)
	var oldRefs zipper.PointerRefCounts
	var oldRemoved uint64
	phase = time.Now()
	base, _, retired, metrics, err := z.ApplyMaterializedPrimaryDeltaV6(group.currentRoot, delta, &oldRefs, &oldRemoved)
	r.MutationNS, r.Metrics = time.Since(phase).Nanoseconds(), metrics
	if err != nil {
		return err
	}
	phase = time.Now()
	entries, ranges := delta.ApplyPlan()
	refs, err := db.buildValueLogRefDelta(group.idx.pager, group.currentRoot, group.baseSeq, entries, ranges, &oldRefs, oldRemoved, true)
	if err != nil {
		return err
	}
	group.mergeValueLogRefDeltaLocked(refs)
	releaseValueLogRefDelta(refs)
	group.retired = append(group.retired, retired...)
	mergeOrderedRootPublishMetrics(&group.metrics, metrics)
	group.recordVacuumMutationLocked(entries, ranges)
	group.currentRoot = base.Ref.Page
	group.maxEntryRevision = page.EntryRevision(db.meta.MaxEntryRevision)
	if coverage := group.negativeCoverage; coverage != nil {
		coverage.filter.Add(selected.Key)
		coverage.nextRoot = group.currentRoot
	}
	r.RefDeltaNS = time.Since(phase).Nanoseconds()
	phase = time.Now()
	// Reuse the existing ordinary lower finalizer with the real physical batch
	// receipt, retaining the same prune Cut through actual physical Finish.
	retErr = finalizeCurrentCOWDiagnostic(group, physical, &r.Publication)
	r.PublishAndFinishNS = time.Since(phase).Nanoseconds()
	r.Accepted = group.accepted
	if r.Accepted {
		cut.Commit()
		r.PublishedSeq = group.baseSeq + 1
	}
	if retErr == nil {
		stats := db.rootPublication.coordinator.Stats()
		r.PhysicalFinish = stats.DurableCommitSeq >= r.PublishedSeq
		if !r.PhysicalFinish {
			return errors.New("returned before original physical Finish ACK barrier")
		}
	}
	return retErr
}

// Diagnostic-only producer reuse of the existing ordinary lower finalizer.
// This does not modify BuildGroup or authorize logical/mixed producers.
func finalizeCurrentCOWDiagnostic(group *RootPublicationBuildGroup, b *Batch, timing *CommandWALPublishTiming) error {
	if b == nil || b.db != group.db || b.batch == nil || !b.physicalOnly || b.logicalMVCCInput || b.commandWALPublishIntent != nil {
		return errors.New("diagnostic requires existing same-DB physical-only batch receipt")
	}
	db := group.db
	entries, ranges := b.batch.ApplyPlan()
	if len(entries) != 1 || entries[0].Type != batchpkg.OpDelete || len(ranges) != 0 {
		return errors.New("diagnostic requires one exact physical deletion")
	}
	mutation := conditionalCommitMutation{
		entries: entries, ranges: ranges, ownerTxnID: b.conditionalTxnID,
		physicalOnly: b.physicalOnly && !b.logicalMVCCInput,
		admission:    b.batch.MVCCInputSummary(),
	}
	group.releaseWriteLocked()
	guard, err := db.prepareFlushApplyPublish(true)
	if err != nil {
		return err
	}
	defer guard.Release()
	opts := finalizeCommitOptions{
		negativeCoverage:    group.negativeCoverage,
		skipPrePublishFlush: true, skipConditionalRootConflict: true,
		maxEntryRevision:     group.maxEntryRevision,
		durablePublishLocked: true, durablePublishRelease: group.releaseDurablePublishLocked,
		rootPublicationBuilder: group.builder, closeTeardownPinned: true,
		expectedBaseCommitSeq: group.baseSeq, hasExpectedBaseCommitSeq: true,
		releaseRootSerialization: func() {}, durableIndex: group.idx,
		conditionalMutation: mutation, publishTiming: timing,
		recordVacuumMutation: func() {
			for _, m := range group.vacuumMutations {
				db.vacuum.RecordApplyPlan(m.entries, m.ranges)
			}
		},
	}
	post, err := db.finalizeCommitLockedWithOptions(group.currentRoot, group.systemRoot, group.retired,
		true, group.metrics, group.touchedValueLogSegmentSliceLocked(), db.indexOuterLeavesInValueLog,
		group.vlogRefDelta, nil, nil, opts)
	// Original finalizer consumes/releases this same builder on every return.
	group.builder = nil
	if err != nil {
		if post.accepted {
			releaseValueLogRefDelta(group.vlogRefDelta)
			group.observeAcceptedOutputLocked()
			db.clearLeafGenerationReachabilityCaches()
		} else {
			db.observeFlushApplyAbandonedOutput(group.metrics, len(group.retired))
		}
		return err
	}
	group.observeAcceptedOutputLocked()
	db.finalizeCommitPostWork(post)
	db.clearLeafGenerationReachabilityCaches()
	return nil
}

// These guards exercise the real ordinary admission route before any matrix
// cell. -test.failfast stops the matrix if this integration contract fails.
func TestNativeCurrentCOWAdmissionGuardsDiagnostic(t *testing.T) {
	if os.Getenv("CURRENT_COW_RESULT") == "" {
		t.Skip("explicit diagnostic only")
	}
	opts := Options{Dir: t.TempDir(), IndexPrimaryDirectory: true, DisableBackgroundPrune: true, DisableSideStores: true}
	db, err := Open(opts)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if db != nil {
			if err := db.Close(); err != nil {
				t.Error(err)
			}
		}
	}()
	check := func(err error) {
		if err != nil {
			t.Fatal(err)
		}
	}
	b := db.NewBatch().(*Batch)
	var selectedKey, anchorKey []byte
	for i := 1; i <= 33; i++ {
		key, e := mvcckey.Encode([]byte("selected"), uint64(i))
		check(e)
		check(b.Set(key, []byte("original")))
		if i == 1 {
			selectedKey = key
		}
		if i == 33 {
			anchorKey = key
		}
	}
	futureKey, e := mvcckey.Encode([]byte("zz-future"), 100)
	check(e)
	check(b.Set(futureKey, []byte("before")))
	check(b.WriteSync())
	check(b.Close())
	old := db.AcquireSnapshot()
	if old == nil {
		t.Fatal("missing guard snapshot")
	}
	defer func() {
		if old != nil {
			check(old.Close())
		}
	}()
	selected, e := old.GetEntryAtRoot(old.State().RootPageID, selectedKey)
	check(e)
	anchor, e := old.GetEntryAtRoot(old.State().RootPageID, anchorKey)
	check(e)
	selected.Key = bytes.Clone(selected.Key)
	selected.Value = bytes.Clone(selected.Value)
	anchor.Key = bytes.Clone(anchor.Key)
	anchor.Value = bytes.Clone(anchor.Value)
	capability := db.NewMVCCAdmission()
	defer capability.Close()
	floorKey := []byte{0, 'T', 'D', 'B', 'M', 'V', 'C', 'C', 0, 'M', 1, 'd', 'f'}
	floorRecord := []byte{1, 0, 0, 0, 0, 0, 0, 0, 33}
	check(db.SetPointWithMVCCInput(floorKey, floorRecord, true, capability.FloorInput(floorKey, floorRecord, 33)))
	work := func() *iterator.OrdinalScanWork {
		return &iterator.OrdinalScanWork{RecordLimit: ^uint64(0), ByteLimit: ^uint64(0)}
	}
	request, ready, e := capability.CaptureRequest(33, work())
	check(e)
	if !ready {
		t.Fatal("pending guard request")
	}
	before := db.State()
	wrong := selected
	wrong.Revision++
	e = runCurrentCOWDiagnostic(db, wrong, anchor, request, &currentCOWDiagnosticResult{})
	if e == nil || e.Error() != "exact current winner changed" {
		t.Fatalf("wrong winner not refused: %v", e)
	}
	if db.State().CommitSeq != before.CommitSeq || db.State().RootPageID != before.RootPageID {
		t.Fatal("wrong winner changed publication")
	}
	// Merge actual unqualified logical input into a real physical batch. This
	// MUST use unchanged ordinary Batch publication admission, without a prune Cut.
	logical := db.NewBatch().(*Batch)
	check(logical.Set(futureKey, []byte("mixed")))
	mixed := db.NewPhysicalBatch().(*Batch)
	check(mixed.Set(futureKey, []byte("mixed")))
	mixed.MergeMVCCInputSummary(logical.batch.MVCCInputSummary())
	check(mixed.WriteSync())
	check(mixed.Close())
	check(logical.Close())
	if valid, e := request.Validate(work()); valid || !errors.Is(e, mvccadmission.ErrRequestInvalid) {
		t.Fatalf("logical publication bypassed admission: %v %v", valid, e)
	}
	before = db.State()
	e = runCurrentCOWDiagnostic(db, selected, anchor, request, &currentCOWDiagnosticResult{})
	if !errors.Is(e, mvccadmission.ErrRequestInvalid) {
		t.Fatalf("stale request not refused: %v", e)
	}
	if db.State().CommitSeq != before.CommitSeq || db.State().RootPageID != before.RootPageID {
		t.Fatal("stale request changed publication")
	}
	request, ready, e = capability.CaptureRequest(33, work())
	check(e)
	if !ready {
		t.Fatal("pending fresh guard request")
	}
	r := currentCOWDiagnosticResult{}
	check(runCurrentCOWDiagnostic(db, selected, anchor, request, &r))
	if !r.Accepted || !r.PhysicalFinish {
		t.Fatal("physical prune did not Finish")
	}
	_, e = db.Get(selectedKey)
	if !errors.Is(e, tree.ErrKeyNotFound) {
		t.Fatalf("guard deletion not visible: %v", e)
	}
	current := db.AcquireSnapshot()
	if current == nil {
		t.Fatal("missing current snapshot")
	}
	base, _ := db.primaryCurrentRootV5().certificate.Directory().Base()
	_, e = current.GetEntryAtRoot(base.Ref.Page, selectedKey)
	check(current.Close())
	if !errors.Is(e, tree.ErrKeyNotFound) {
		t.Fatalf("selected record remains in physical DATA: %v", e)
	}
	got, e := old.Get(selectedKey)
	check(e)
	if !bytes.Equal(got, []byte("original")) {
		t.Fatal("old guard reader changed")
	}
	check(old.Close())
	old = nil
	check(db.Close())
	db = nil
	reopened, e := Open(opts)
	check(e)
	defer reopened.Close()
	_, e = reopened.Get(selectedKey)
	if !errors.Is(e, tree.ErrKeyNotFound) {
		t.Fatalf("guard deletion resurrected: %v", e)
	}
	got, e = reopened.Get(anchorKey)
	check(e)
	if !bytes.Equal(got, []byte("original")) {
		t.Fatal("guard anchor changed")
	}
	got, e = reopened.Get(futureKey)
	check(e)
	if !bytes.Equal(got, []byte("mixed")) {
		t.Fatal("equal/future logical write changed")
	}
	t.Log("real mixed logical admission invalidation, wrong-winner/stale-Request refusal, held-Cut physical DATA removal, Finish, old reader and reopen PASS")
}

func TestNativeCurrentCOWHistoryDiagnostic(t *testing.T) {
	resultPath := os.Getenv("CURRENT_COW_RESULT")
	if resultPath == "" {
		t.Skip("explicit source-bound diagnostic only")
	}
	cells := []currentCOWDiagnosticCell{
		{Name: "baseline33", Segments: 1},
		{Name: "retirement64", History: 64, Segments: 1},
		{Name: "retirement256", History: 256, Segments: 1},
		{Name: "released256", History: 256, Segments: 1, ReleaseHistoryReader: true},
		{Name: "dependencies8", History: 64, Segments: 8},
		{Name: "pinned_roots4", History: 64, Segments: 1, Pins: 4},
	}
	var results []currentCOWDiagnosticResult
	defer func() {
		data, e := json.MarshalIndent(struct {
			Schema, Scope, AllocationBoundary string
			Results                           []currentCOWDiagnosticResult
		}{"gomap-current-cow-history-diagnostic-v1", "backend-only controlled PRIMARY fixture; actual DB Request, original allocator and publisher; sync=true durable prune Finish in BOTH DB durability profiles (not memtable-ACK latency); Store/native selector+constructor and C1/C3 excluded; Q32 unchanged; no finite-bound claim", "outer memory deltas include concurrent foreground DB work; setup/census/oracles/DB teardown separate; group.Close and physical Finish included", results}, "", "  ")
		if e != nil {
			t.Error(e)
			return
		}
		if e = os.WriteFile(resultPath, append(data, '\n'), 0600); e != nil {
			t.Error(e)
		}
	}()
	for _, relaxed := range []bool{false, true} {
		for _, cell := range cells {
			name := "durable"
			if relaxed {
				name = "wal_on_relaxed"
			}
			t.Run(name+"/"+cell.Name, func(t *testing.T) {
				r := currentCOWDiagnosticResult{Cell: cell, Durability: name}
				defer func() { results = append(results, r) }()
				fail := func(e error) {
					if e != nil {
						r.Error = e.Error()
						t.Fatal(e)
					}
				}
				opts := Options{Dir: t.TempDir(), IndexPrimaryDirectory: true, DisableBackgroundPrune: true, DisableSideStores: true}
				if relaxed {
					opts.Durability = DurabilityWALOnRelaxed
				}
				db, e := Open(opts)
				fail(e)
				defer func() {
					if db != nil {
						if e := db.Close(); e != nil {
							r.Error = e.Error()
							t.Error(e)
						}
					}
				}()
				payload := bytes.Repeat([]byte("persistent selected value|"), 128)
				pointers := appendPointersInNewSegment(t, opts.Dir, 0, 1, 1000, 33, func(int) []byte { return payload })
				var depPointers []page.ValuePtr
				if cell.Segments == 1 {
					depPointers = appendPointersInNewSegment(t, opts.Dir, 0, 2, 2000, 8, func(int) []byte { return payload })
				} else {
					for i := 0; i < 8; i++ {
						depPointers = append(depPointers, appendPointersInNewSegment(t, opts.Dir, 0, uint32(2+i), uint64(2000+i), 1, func(int) []byte { return payload })[0])
					}
				}
				fail(db.RefreshValueLogSet())
				b := db.NewBatch().(*Batch)
				var selectedKey, anchorKey []byte
				for i := 1; i <= 33; i++ {
					key, e := mvcckey.Encode([]byte("selected"), uint64(i))
					fail(e)
					fail(b.SetPointer(key, pointers[i-1]))
					if i == 1 {
						selectedKey = key
					}
					if i == 33 {
						anchorKey = key
					}
				}
				futureKey, e := mvcckey.Encode([]byte("zz-future"), 100)
				fail(e)
				fail(b.Set(futureKey, []byte("0")))
				for i, p := range depPointers {
					fail(b.SetPointer([]byte(fmt.Sprintf("zz-dependency-%02d", i)), p))
				}
				fail(b.WriteSync())
				fail(b.Close())
				old := db.AcquireSnapshot()
				if old == nil {
					t.Fatal("no old reader")
				}
				defer func() {
					if old != nil {
						fail(old.Close())
					}
				}()
				selected, e := old.GetEntryAtRoot(old.State().RootPageID, selectedKey)
				fail(e)
				anchor, e := old.GetEntryAtRoot(old.State().RootPageID, anchorKey)
				fail(e)
				selected.Key = bytes.Clone(selected.Key)
				selected.Value = bytes.Clone(selected.Value)
				anchor.Key = bytes.Clone(anchor.Key)
				anchor.Value = bytes.Clone(anchor.Value)
				// The real persisted floor and Request belong to this single fixture owner.
				capability := db.NewMVCCAdmission()
				defer capability.Close()
				floorKey := []byte{0, 'T', 'D', 'B', 'M', 'V', 'C', 'C', 0, 'M', 1, 'd', 'f'}
				floorRecord := []byte{1, 0, 0, 0, 0, 0, 0, 0, 33}
				fail(db.SetPointWithMVCCInput(floorKey, floorRecord, true, capability.FloorInput(floorKey, floorRecord, 33)))
				w := &iterator.OrdinalScanWork{RecordLimit: ^uint64(0), ByteLimit: ^uint64(0)}
				request, ready, e := capability.CaptureRequest(33, w)
				fail(e)
				if !ready {
					t.Fatal("request pending")
				}
				var pins []*Snapshot
				defer func() {
					for _, s := range pins {
						fail(s.Close())
					}
				}()
				for i := 0; i < cell.History; i++ {
					fail(db.SetPointWithMVCCInput(futureKey, []byte(fmt.Sprintf("history-%d", i)), true, capability.Input(futureKey, 100, 33)))
					if cell.Pins > 0 && i%(cell.History/cell.Pins) == 0 {
						pins = append(pins, db.AcquireSnapshot())
					}
				}
				if cell.ReleaseHistoryReader {
					fail(old.Close())
					old = nil
					r.SelectedSnapshotClosedBeforeMutation = true
				}
				r.Before = db.idx.Load().allocator.COWPrepareProfileV1()
				// Read-only geometry census is setup, not a claimed bounded admission.
				root := db.State().RootPageID
				if db.idx.Load().primary != nil {
					cert := db.primaryCurrentRootV5().certificate
					base, _ := cert.Directory().Base()
					root = base.Ref.Page
				}
				r.Geometry, e = db.idx.Load().zipper.PrepareReadOnlyPlan(root, []batchpkg.Entry{{Type: batchpkg.OpPut, Key: selectedKey, Value: []byte("probe")}}, nil, zipper.ReadOnlyPrepareOptions{CountTouchedOldEntries: true, DiscardLeafSpans: true, OmitKeys: true})
				if e != nil {
					r.GeometryError = e.Error()
				}
				var writes atomic.Uint64
				stop := make(chan struct{})
				writerReady := make(chan struct{})
				writerDone := make(chan error, 1)
				go func() {
					first := true
					for {
						select {
						case <-stop:
							writerDone <- nil
							return
						default:
						}
						n := writes.Load() + 1
						e := db.SetPointWithMVCCInput(futureKey, []byte(fmt.Sprintf("writer-%d", n)), true, capability.Input(futureKey, 100, 33))
						if e != nil {
							writerDone <- e
							return
						}
						writes.Store(n)
						if first {
							close(writerReady)
							first = false
						}
						runtime.Gosched()
					}
				}()
				var stopOnce sync.Once
				var writerErr error
				stopWriter := func() { stopOnce.Do(func() { close(stop); writerErr = <-writerDone }) }
				defer stopWriter()
				select {
				case <-writerReady:
				case e := <-writerDone:
					stopOnce.Do(func() { close(stop); writerErr = e })
					fail(e)
					t.Fatal("writer stopped before ready")
				case <-time.After(5 * time.Second):
					t.Fatal("writer ready timeout")
				}
				r.WriterBefore = writes.Load()
				e = runCurrentCOWDiagnostic(db, selected, anchor, request, &r)
				stopWriter()
				fail(writerErr)
				r.WriterAfter = writes.Load()
				fail(e)
				r.After = db.idx.Load().allocator.COWPrepareProfileV1()
				_, e = db.Get(selectedKey)
				r.Removed = errors.Is(e, tree.ErrKeyNotFound)
				physicalView := db.AcquireSnapshot()
				if physicalView == nil {
					t.Fatal("missing physical view")
				}
				physicalBase, _ := db.primaryCurrentRootV5().certificate.Directory().Base()
				_, physicalErr := physicalView.GetEntryAtRoot(physicalBase.Ref.Page, selectedKey)
				fail(physicalView.Close())
				r.PhysicalDataRemoved = errors.Is(physicalErr, tree.ErrKeyNotFound)
				if !r.Removed {
					fail(errors.New("selected physical key remains"))
				}
				got, e := db.Get(anchorKey)
				fail(e)
				r.Keeper = bytes.Equal(got, payload)
				got, e = db.Get(futureKey)
				fail(e)
				wantFuture := []byte(fmt.Sprintf("writer-%d", r.WriterAfter))
				r.Future = bytes.Equal(got, wantFuture)
				if old != nil {
					got, e = old.Get(selectedKey)
					fail(e)
					r.OldReader = bytes.Equal(got, payload)
				}
				for _, s := range pins {
					fail(s.Close())
				}
				pins = nil
				if old != nil {
					fail(old.Close())
					old = nil
				}
				fail(db.Close())
				db = nil
				reopened, e := Open(opts)
				fail(e)
				_, e = reopened.Get(selectedKey)
				r.Reopen = errors.Is(e, tree.ErrKeyNotFound)
				got, e = reopened.Get(anchorKey)
				fail(e)
				r.Reopen = r.Reopen && bytes.Equal(got, payload)
				got, e = reopened.Get(futureKey)
				fail(e)
				r.Reopen = r.Reopen && bytes.Equal(got, wantFuture)
				for i := range depPointers {
					got, e = reopened.Get([]byte(fmt.Sprintf("zz-dependency-%02d", i)))
					fail(e)
					r.Reopen = r.Reopen && bytes.Equal(got, payload)
				}
				fail(reopened.Close())
				if !r.Accepted || !r.PhysicalFinish || !r.Removed || !r.PhysicalDataRemoved || !r.Keeper || !r.Future || !r.Reopen || (!cell.ReleaseHistoryReader && !r.OldReader) {
					t.Fatalf("semantic oracle failed: %+v", r)
				}
			})
			if t.Failed() {
				return
			}
		}
	}
}
