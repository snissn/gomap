Backend-only current-root COW diagnostic: BLOCKED baseline, no history-scaling evidence.

The pinned offline Go1.26.3 build passed. The sole CPU0/GOMAXPROCS1 matrix run stalled in durable/baseline33 and was stopped with SIGQUIT to exact PID1791448; exit2 and full goroutine dump are retained. No semantic cell completed and no timing/allocation result is qualified.

The retained real MVCC prune Cut is reacquired by original visible activation (root_publication_activation.go:546). RootPublicationBuildGroup.finalizeLocked never forwards conditionalMutation.physicalOnly. Ordinary Batch already constructs and forwards that receipt (batch.go:452/583). This is a harness/integration mismatch, not proof of an existing ordinary production deadlock. Original native64cee only observes prune around sealing and aborts the Cut when that method returns; it supplies no hold-through-ordinary-publication recipe.

Smallest valid next inquiry: audit and faithfully reuse the existing physical-only conditional mutation receipt at the same group finalizer/lower ordinary finalize seam, preserving Request validation and the Cut through original physical Finish/ACK. Do not unlock early, add a publisher, change quotas, or introduce graft/rebase work.

The controlled PRIMARY fixture excludes Store/native selection-construction and C1/C3. Original Q32 remains RED and native ACK remains zero. All full source-input hashes were unchanged across compilation/run. Runtime is released.
