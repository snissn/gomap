package rootpublication

import (
	"errors"
	"testing"
)

func TestGenericEmptyCloneUsesAbsentClosure(t *testing.T) {
	b := NewStableResourceSetBuilder()
	s, err := b.Freeze()
	if err != nil || s == nil || s.Owner() != ResourceOwnerBuilder {
		t.Fatalf("exported Freeze contract: %v %v", s, err)
	}
	clone, err := CloneStableResourceSetExcludingKinds(s)
	if err != nil {
		t.Fatal(err)
	}
	if clone != nil {
		clone.Release()
		t.Error("zero-edge generic clone retained an owner")
	}
	if err = s.ReleaseWithError(); err != nil {
		t.Fatal(err)
	}
	if _, err = CloneStableResourceSetExcludingKinds(s); !errors.Is(err, ErrResourceOwnership) {
		t.Fatalf("released source: %v", err)
	}
}
