The compact metadata representation passes focused ownership/recovery controls and reduces PRIMARY allocations. The complete fixed public guard remains RED: PRIMARY latency is 5.14635% above the exact main baseline, exceeding the 5% limit. No sample was replaced or rerun.

Source and implementation
-------------------------
The frozen eleven-path overlay is candidate-source-manifest.json (SHA256 edae383092f42d84828274a4ac04a9997dc8781d8a8e77bbf95e66d3e51a9fa4). Only the final two paths change in this experiment: primary_bank_metadata_v5.go and primary_bank_metadata_compact_v5_test.go. The earlier nine-path unchanged-base witness repair is retained unchanged.

PrimaryBankMetadataEdgesOwnedV5 keeps the original owned MetadataEdgeScratch interface, original owner charge/refund and parser/CRC. Record and Manifest now retain two inline edge slots; Dependency alone receives the existing full 512-edge/dependency-borrow scratch. Each independently retained result stays independently owned. Close clears all aliases before original-owner accounting and remains idempotent.

Existing arena decision: recursive recovery retains parent metadata edges while decoding children. A resettable shared scratch or singleton arena cannot cover these independent lifetimes. The existing charged owned result remains the maintained owner; only unnecessary capacity was removed. No pool, new ownership abstraction, parser or format was added.

Focused behavior and lifetime
-----------------------------
The new control uses genuine sealed Record/Manifest pages. Its RED on unchanged production was an actual 57,344-byte retained result for two edges, exceeding the one-page bound. It also verifies canonical edge parity, retained parent edges through four independently held Dependency decodes, CRC error refund, double Close, and original-owner final refund.
GREEN ran exactly:
- TestOwnedPrimaryMetadataScratchKeepsOnlyActualEdgesV5
- TestOwnedPrimaryBankMetadataScratchParityRefusalAndDisposal
- TestPrimaryRootV5MetadataBanksRecoverBothIndependentSlotsAndRetainedCut
Exit0, 2.817819s. The actual public TestCommitAtPrimaryOnlyRetainsActualDataGeneration also passed before measurement, including reopen. Commands, raw output and per-source censuses are retained.

Fixed uninstrumented public guard
---------------------------------
Pinned Go1.26.3, GOWORK=off, GOTOOLCHAIN=local, offline dependencies, CPU0/GOMAX1. Prebuilt binaries; three alternating AB/BA/AB pairs for EACH workload. All eighteen fresh processes exit0. No replacement samples, profiling or extra iterations. Baseline is exact main5bca87ffe6e1bfba2d693264d2dc82936adc234f. The PRIMARY benchmark overlay is identical on both binaries. It is fixture-only and distinct from production source; exact sources/build/binary hashes and options are retained.

Median measurements (ratio of candidate median to baseline median):
GetVersioned 500ms: 318.8 -> 330.8 ns/op (+3.764115%), 0 B/op, 0 allocations/op. PASS.
ConditionalTxnBaselineBatchWrite 1000x: 21,294 -> 20,415 ns/op (-4.127923%), 31,943 -> 31,504 B/op, 127 -> 104 allocations/op. PASS.
CommitAtPrimaryOnlyAfterDataGeneration 128x: 143,150 -> 150,517 ns/op (+5.146350%), 279,179 -> 226,679 B/op, 474 -> 390 allocations/op. Strict latency RED. Generation advances/op 2 -> 0 on all cells, as intended by the producer-origin routing and separately validated public lifecycle.

Individual PRIMARY pairs are baseline/candidate ns/op 148345/150517, 142737/150653, 143150/149774. The early short comparison is not final acceptance; the third result cannot be rounded down to a pass. Allocation gains do not waive latency. perf-summary.json contains every raw row and medians.

Attribution and scope
---------------------
The preceding frozen profile identified PrimaryBankMetadataEdgesOwnedV5 at 29,288 KiB flat in the whole 512x profile, not a per-operation private measurement. This public comparison now confirms the changed retained-capacity seam is active: PRIMARY drops 52,500 B/op and 84 allocations/op against main. It does not establish that the remaining 7,367 ns/op overhead is caused by metadata decoding or that another local allocation change will solve it. No further profile/fix/retry is selected.

Get and DATA timing remain bounded guard evidence only. The exported Snapshot custody, immutable witness exclusions, all physical Finish/ACK work, both slots and owner charge/error contracts remain in the packet. The unresolved ordinary CI concurrency/retention/platform/fault gates remain open. Native Q32/public ACK remains independently open; no native source or runtime was used.

Identity and disposition
------------------------
Source census, HEAD and index were identical before build, after build and after all samples. Candidate frozen source copies and all command/environment/raw/receipt files are retained. perf/binaries.json binds all four ELFs, which are still retained for future consumers. Runtime lease is released. Source is frozen pending the next explicit coherent repair decision.
