package zipper

import (
	"testing"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
)

type inputGrowthReaderV6 struct{}

func (inputGrowthReaderV6) BeginProjectionFrame(page.ChildRef, []byte, *iterator.OrdinalScanWork) (bool, error) {
	return false, nil
}
func (inputGrowthReaderV6) StepProjectionFrame(*iterator.OrdinalScanWork) ([]byte, bool, error) {
	return nil, false, nil
}

// Each case supplies enough for the original local traffic and deliberately
// none for the independently required owner resize. Refusal must retain the
// exact original state and governor; the resumed SAME producer then owns its
// allocation until original CloseStep detaches every alias.
func TestMaterializedInputGrowthUsesOriginalFiniteOwnerV6(t *testing.T) {
	for _, kind := range []string{"constructor", "entries", "payload"} {
		t.Run(kind, func(t *testing.T) {
			budget, err := memtable.NewCOWBudget(memtable.DefaultCOWLimits())
			if err != nil {
				t.Fatal(err)
			}
			defer budget.Close()
			var owner retainedalloc.Owner
			owner.Initialize(0)
			enrollment, err := owner.Enroll(budget)
			if err != nil {
				t.Fatal(err)
			}
			defer enrollment.Close()
			// Enrollment controls belong to the original owner independently of
			// this producer. Capture their baseline before any input allocation.
			enrolled, external := owner.Bytes(), budget.Stats().ExternalBytes
			var s *MaterializedInputWorkV6
			local := uint64(1)
			if kind != "constructor" {
				var ready bool
				s, ready, err = NewMaterializedInputWorkV6(&owner, inputGrowthReaderV6{}, 2, nil, nil, []node.LeafEntry{{Key: []byte("delete")}}, &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20})
				if err != nil || !ready {
					t.Fatal(ready, err)
				}
				if kind == "entries" {
					s.phase = 3
				} else {
					s.phase = 24
					s.pending = node.LeafEntry{Key: []byte("component"), Value: []byte("value")}
					local = 2
				}
			}
			before, governed := owner.Bytes(), budget.Stats().ExternalBytes
			tiny := &iterator.OrdinalScanWork{RecordLimit: local, ByteLimit: 1 << 20}
			var ready bool
			if kind == "constructor" {
				s, ready, err = NewMaterializedInputWorkV6(&owner, inputGrowthReaderV6{}, 2, nil, nil, nil, tiny)
			} else {
				ready, err = s.Step(tiny)
			}
			if err != nil || ready || tiny.Records != local || owner.Bytes() != before || budget.Stats().ExternalBytes != governed {
				t.Fatalf("unfunded growth changed custody: ready=%v err=%v work=%+v owner=%d/%d budget=%d/%d", ready, err, tiny, owner.Bytes(), before, budget.Stats().ExternalBytes, governed)
			}
			if kind == "constructor" && s != nil {
				t.Fatal("refused constructor escaped")
			}
			if kind == "entries" && (s.entries != nil || s.phase != 3) {
				t.Fatal("refused entries advanced")
			}
			if kind == "payload" && (s.pending.Key == nil || s.components[0].Key != nil || s.phase != 24) {
				t.Fatal("refused payload advanced")
			}
			full := &iterator.OrdinalScanWork{RecordLimit: local + 6, ByteLimit: 1 << 20}
			if kind == "constructor" {
				s, ready, err = NewMaterializedInputWorkV6(&owner, inputGrowthReaderV6{}, 2, nil, nil, nil, full)
			} else {
				_, err = s.Step(full)
			}
			if err != nil || s == nil || owner.Bytes() <= before {
				t.Fatal("resumed original growth", ready, err)
			}
			if kind == "payload" && (s.pending.Key != nil || string(s.components[0].Key) != "component") {
				t.Fatal("payload not transferred")
			}
			var refund *retainedalloc.Owner
			var charge uint64
			closed := false
			for turn := 0; turn < node.PrimaryDirectoryMaxEntries+4; turn++ {
				done, o, n, e := s.CloseStep(&iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20})
				if e != nil {
					t.Fatal(e)
				}
				if done {
					refund, charge = o, n
					closed = true
					break
				}
			}
			if !closed || refund != &owner || charge == 0 || s.owner != nil || s.entries != nil || s.pending.Key != nil {
				t.Fatal("original alias detachment missing")
			}
			var removal retainedalloc.RemovalWork
			removed := false
			for turn := 0; turn < 16; turn++ {
				done, e := refund.RemovePendingWork(charge, &removal, &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20})
				if e != nil {
					t.Fatal(e)
				}
				if done {
					removed = true
					break
				}
			}
			if !removed || owner.Bytes() != enrolled || budget.Stats().ExternalBytes != external {
				t.Fatalf("producer refund did not restore enrollment baseline: done=%v owner=%d/%d external=%d/%d", removed, owner.Bytes(), enrolled, budget.Stats().ExternalBytes, external)
			}
			enrollment.Close()
			if owner.Bytes() != 0 || budget.Stats().ExternalBytes != 0 {
				t.Fatalf("original enrollment charge remains: owner=%d external=%d", owner.Bytes(), budget.Stats().ExternalBytes)
			}
		})
	}
}
