package rootpublication

import (
	"context"
	"errors"
	"sync"
	"sync/atomic"
	"testing"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
)

// This synthetic original owner deliberately mirrors the cursor's ordering:
// Complete unlinks its embedded receipt, then the containing preparation is
// scrubbed before Close returns its accounting lease. It creates no publication
// authority. The surrounding test keeps the owner alive independently; concurrent
// tests establish mutex/callback behavior, not a concurrent admission-lifetime edge.
type nativeScrubbingJoinOwnerV6 struct {
	physical nativePublicationOwnerControlV6
	mu       sync.Mutex
	settled  bool
	refuse   error
	lease    retainedalloc.Lease
	before   func()
}

type nativeScrubbingJoinLeaseV6 struct{ closes atomic.Uint64 }

func (*nativeScrubbingJoinLeaseV6) Resize(uint64) error { return nil }
func (l *nativeScrubbingJoinLeaseV6) Close()            { l.closes.Add(1) }

func (o *nativeScrubbingJoinOwnerV6) CloseNativePublicationV6() (retainedalloc.Lease, error) {
	if o.before != nil {
		o.before()
	}
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.settled {
		return nil, o.physical.refuse
	}
	if o.refuse != nil {
		lease := o.lease
		o.lease = nil // The still-linked receipt must retain this original lease.
		return lease, o.refuse
	}
	_, err := o.physical.CloseNativePublicationV6()
	// This fixture invokes only successful original completion (possibly with
	// a retained physical error); an unexpected protocol refusal cannot scrub.
	o.physical.c.mu.Lock()
	complete := o.physical.receipt.complete
	o.physical.c.mu.Unlock()
	if !complete {
		return nil, err
	}
	o.settled = true
	o.physical.receipt = NativePublicationV6{}
	lease := o.lease
	o.lease = nil
	return lease, err
}

func bindScrubbingJoinOwnerV6(t *testing.T, c *Coordinator) (*nativeScrubbingJoinOwnerV6, *nativeScrubbingJoinLeaseV6) {
	t.Helper()
	l := &nativeScrubbingJoinLeaseV6{}
	o := &nativeScrubbingJoinOwnerV6{physical: nativePublicationOwnerControlV6{c: c}, lease: l}
	w := iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
	if ready, err := c.BindNativePublicationV6(&o.physical.receipt, o, &w); !ready || err != nil {
		t.Fatal(ready, err)
	}
	return o, l
}

func TestNativePublicationJoinAcceptsScrubbedOriginalV6(t *testing.T) {
	for _, failure := range []bool{false, true} {
		name := "success"
		if failure {
			name = "first-error"
		}
		t.Run(name, func(t *testing.T) {
			c, initial := nativePublicationControlV6(t)
			defer stopClean(t, c)
			tail, tailLease := bindScrubbingJoinOwnerV6(t, c)
			head, headLease := bindScrubbingJoinOwnerV6(t, c)
			var want error
			if failure {
				want = errors.New("original physical completion error")
				head.physical.refuse = want
			}
			before := c.Stats()
			err := c.JoinNativePublicationsV6(context.Background())
			if !errors.Is(err, want) || (want == nil && err != nil) {
				t.Fatal("scrubbed completion lost first result", err)
			}
			if c.HasOutstandingNativePublicationsV6() || headLease.closes.Load() != 1 || tailLease.closes.Load() != 1 || head.physical.closes != 1 || tail.physical.closes != 1 || initial.closes != 1 {
				t.Fatal("join stopped at scrubbed head or replayed original cleanup")
			}
			if head.physical.receipt.refusedCompletion != nil || tail.physical.receipt.refusedCompletion != nil || head.physical.receipt.owner != nil || tail.physical.receipt.owner != nil {
				t.Fatal("join wrote admission/owner aliases into detached storage")
			}
			after := c.Stats()
			if after.DurableCommitSeq != before.DurableCommitSeq || after.PendingCommits != before.PendingCommits {
				t.Fatal("physical join changed publication frontiers")
			}
			if err := c.JoinNativePublicationsV6(context.Background()); err != nil || headLease.closes.Load() != 1 || tailLease.closes.Load() != 1 {
				t.Fatal("completed join replay", err)
			}
		})
	}
}

func TestNativePublicationJoinRetainsLinkedCompletionV6(t *testing.T) {
	for _, fenced := range []bool{false, true} {
		name := "unfenced"
		if fenced {
			name = "fenced-first-error"
		}
		t.Run(name, func(t *testing.T) {
			c, initial := nativePublicationControlV6(t)
			defer stopClean(t, c)
			o, lease := bindScrubbingJoinOwnerV6(t, c)
			if fenced {
				nativeControlFenceV6(t, c, &o.physical)
			}
			want := errors.New("original Close remains incomplete")
			o.refuse = want
			if err := c.JoinNativePublicationsV6(context.Background()); !errors.Is(err, want) {
				t.Fatal(err)
			}
			c.mu.Lock()
			retained := c.nativePublicationsV6 == &o.physical.receipt && o.physical.receipt.refusedCompletion == lease && !o.physical.receipt.complete && c.nativeDispatchV6 == 2
			first := o.physical.receipt.firstError
			c.mu.Unlock()
			if !retained || lease.closes.Load() != 0 || initial.closes != 0 || (fenced && first != want) {
				t.Fatal("incomplete original lost live receipt/lease/first cause")
			}
			// A replay must preserve the same parked original lease without refund.
			if err := c.JoinNativePublicationsV6(context.Background()); !errors.Is(err, want) || lease.closes.Load() != 0 {
				t.Fatal("refused join replay", err)
			}
			// Explicit fixture-owner disposal: retain the physical-error edge through
			// genuine Complete, detach its aliases, then close the parked lease.
			if err := c.CompleteNativePublicationV6(&o.physical.receipt, want, true); !errors.Is(err, want) {
				t.Fatal(err)
			}
			if o.physical.original != nil {
				if err := o.physical.original.releaseFrom(ResourceOwnerCoordinator); err != nil {
					t.Fatal(err)
				}
				o.physical.original = nil
			}
			o.physical.receipt = NativePublicationV6{}
			o.settled = true
			lease.Close()
			if err := c.JoinNativePublicationsV6(context.Background()); err != nil || initial.closes != 1 || lease.closes.Load() != 1 {
				t.Fatal("remaining live receipt did not settle", err)
			}
		})
	}
}

func TestNativePublicationJoinConcurrentScrubbedOriginalV6(t *testing.T) {
	for _, publicClose := range []bool{false, true} {
		name := "two-joins"
		if publicClose {
			name = "join-and-original-close"
		}
		t.Run(name, func(t *testing.T) {
			c, initial := nativePublicationControlV6(t)
			defer stopClean(t, c)
			o, lease := bindScrubbingJoinOwnerV6(t, c)
			entered, resume := make(chan struct{}, 2), make(chan struct{})
			o.before = func() { entered <- struct{}{}; <-resume }
			done := make(chan error, 2)
			go func() { done <- c.JoinNativePublicationsV6(context.Background()) }()
			go func() {
				if !publicClose {
					done <- c.JoinNativePublicationsV6(context.Background())
					return
				}
				completion, err := o.CloseNativePublicationV6()
				if completion != nil {
					completion.Close()
				}
				done <- err
			}()
			<-entered
			<-entered // Both callers have acquired the SAME original owner.
			close(resume)
			for range 2 {
				if err := <-done; err != nil {
					t.Fatal(err)
				}
			}
			if c.HasOutstandingNativePublicationsV6() || o.physical.closes != 1 || initial.closes != 1 || lease.closes.Load() != 1 {
				t.Fatal("concurrent original callbacks replayed/lost cleanup")
			}
		})
	}
}
