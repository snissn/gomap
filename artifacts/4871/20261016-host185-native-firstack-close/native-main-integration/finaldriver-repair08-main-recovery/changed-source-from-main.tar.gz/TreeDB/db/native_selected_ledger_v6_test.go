package db

import (
	"testing"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
)

// The manifest is a genuine original empty constructor output. Only the holder
// descriptor/phase is synthetic: this test grants no seal, slot, receipt or
// publication authority and does not execute native activation or Finish.
func TestNativeSelectedManifestTransferredHolderV6(t *testing.T) {
	if !rootpublication.StableRelativeNamespaceSupported() {
		t.Skip("original stable namespace capability unavailable")
	}
	d, err := Open(Options{Dir: t.TempDir(), ResolvedProfile: ProfileNoWALFast, Durability: DurabilityWALOffRelaxed, DisableBackgroundPrune: true})
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if e := d.Close(); e != nil {
			t.Error(e)
		}
	}()
	q := func() *iterator.OrdinalScanWork {
		return &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
	}
	c := NativeMVCCCurrentDeleteV6{db: d}
	c.rootPreparation.expectedSequence = d.meta.CommitSeq
	// The supported original warm capture initializes PRIMARY before its owner
	// is read, then actually closes all borrowed capture edges.
	var warm nativeStablePagerCaptureV6
	for turn := 0; ; turn++ {
		if turn == 100 {
			t.Fatal("warm capture stalled")
		}
		ready, e := warm.step(&c, true, q())
		if e != nil {
			t.Fatal(e)
		}
		if ready {
			break
		}
	}
	for turn := 0; ; turn++ {
		if turn == 100 {
			t.Fatal("warm close stalled")
		}
		ready, e := warm.closeStep(q())
		if e != nil {
			t.Fatal(e)
		}
		if ready {
			break
		}
	}
	owner := d.idx.Load().primary.MetadataOwner()
	before := owner.Bytes()
	set, ready, err := rootpublication.PrepareEmptyStableResourceSetWithOrdinalWorkV6(owner, nil, q())
	if err != nil || !ready {
		t.Fatal("original Set constructor", ready, err)
	}
	manifest, ready, err := rootpublication.EmptyDependencyManifestWithWorkV6(set, q())
	if err != nil || !ready {
		t.Fatal("original manifest constructor", ready, err)
	}
	defer func() {
		// Detach both possible holder aliases before the original completion
		// refunds its own allocation. Never reset active RemovalWork.
		c.sealPreparation.manifest = nil
		c.sealPreparation.seal = nil
		var completion rootpublication.StableResourceTokenReleaseCompletionV6
		for turn := 0; ; turn++ {
			if turn == 100 {
				t.Error("manifest disposal stalled")
				return
			}
			v, done, e := manifest.ReleaseOwnedMetadataWithWorkV6(q())
			if e != nil {
				t.Error(e)
				return
			}
			if done {
				completion = v
				manifest = nil
				break
			}
		}
		var removal retainedalloc.RemovalWork
		for turn := 0; ; turn++ {
			if turn == 100 {
				t.Error("manifest refund stalled")
				return
			}
			done, e := completion.CompleteWithWorkV6(&removal, q())
			if e != nil {
				t.Error(e)
				return
			}
			if done {
				break
			}
		}
		for turn := 0; ; turn++ {
			if turn == 100 {
				t.Error("Set disposal stalled")
				return
			}
			v, done, e := set.ReleaseFromWithWorkV6(rootpublication.ResourceOwnerBuilder, q())
			if e != nil {
				t.Error(e)
				return
			}
			if done {
				completion = v
				set = nil
				break
			}
		}
		removal = retainedalloc.RemovalWork{}
		for turn := 0; ; turn++ {
			if turn == 100 {
				t.Error("Set refund stalled")
				return
			}
			done, e := completion.CompleteWithWorkV6(&removal, q())
			if e != nil {
				t.Error(e)
				return
			}
			if done {
				break
			}
		}
		if owner.Bytes() != before {
			t.Error("original owner charge not restored", owner.Bytes(), before)
		}
	}()
	s := &c.sealPreparation
	s.phase = 13
	s.manifest = manifest
	s.seal = &rootPublicationSealV1{manifest: s.manifest}
	s.manifest = nil // SAME completed transfer convention as the real binder.
	charged := owner.Bytes()
	observe := func() (rootpublication.NativeManifestAllocationForTestV6, bool, bool) {
		return c.MaintenanceNativeManifestRowForTestV6(q())
	}
	g, same, ok := observe()
	if !ok || !same || !g.Present || !g.Selected || !g.OriginalOwner || g.OpaqueEntryGraph || g.Charge == 0 {
		t.Fatal("genuine transferred empty manifest", g, same, ok)
	}
	if _, _, ok := c.MaintenanceNativeManifestRowForTestV6(&iterator.OrdinalScanWork{}); ok {
		t.Fatal("unadmitted holder observation")
	}
	s.manifest = manifest
	_, same, ok = observe()
	s.manifest = nil
	if !ok || same {
		t.Fatal("dual holder accepted")
	}
	s.phase = 12
	_, same, ok = observe()
	s.phase = 13
	if !ok || same {
		t.Fatal("incomplete transfer phase accepted")
	}
	s.seal.manifest = nil
	g, same, ok = observe()
	s.seal.manifest = manifest
	if !ok || same || g.Present {
		t.Fatal("absent disposing holder interpreted as complete")
	}
	originalDB := c.db
	c.db = nil
	g, _, ok = observe()
	c.db = originalDB
	if !ok || g.OriginalOwner {
		t.Fatal("missing expected owner accepted")
	}
	if owner.Bytes() != charged {
		t.Fatal("holder observation changed original charges")
	}
}

// Genuine Set constructors, synthetic completed-holder position only. This
// exercises transfer guards without constructing successful publication state.
func TestNativeSelectedSetTransferredHoldersV6(t *testing.T) {
	var owner retainedalloc.Owner
	owner.Initialize(0)
	q := func() *iterator.OrdinalScanWork {
		return &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
	}
	var sets [4]*rootpublication.StableResourceSet
	for _, i := range []int{0, 3} {
		s, ready, e := rootpublication.PrepareEmptyStableResourceSetWithOrdinalWorkV6(&owner, nil, q())
		if e != nil || !ready {
			t.Fatal(ready, e)
		}
		sets[i] = s
	}
	for _, i := range []int{1, 2} {
		s, ready, e := rootpublication.CloneAdmittedStableResourceSetWithOrdinalWorkV6(sets[0], q())
		if e != nil || !ready {
			t.Fatal(ready, e)
		}
		sets[i] = s
	}
	c := NativeMVCCCurrentDeleteV6{}
	c.candidatePreparation.resources = sets[0]
	c.candidatePreparation.member = &rootPublicationVisibleMemberV1{resources: sets[1]}
	c.sealPreparation.phase = 13
	c.sealPreparation.seal = &rootPublicationSealV1{resources: sets[2], primary: &primaryPublicationSealV5{proofResources: sets[3]}}
	charged := owner.Bytes()
	for _, role := range []uint8{0, 1, 3, 4} {
		g, ok := c.MaintenanceNativeSetRowForTestV6(role, q())
		if !ok || !g.Present || !g.Selected || !g.Live || !g.OriginalOwner || g.SetCharge == 0 {
			t.Fatal("actual transferred role", role, g, ok)
		}
	}
	g, ok := c.MaintenanceNativeSetRowForTestV6(2, q())
	if !ok || g.Present {
		t.Fatal("cleared prep role", g, ok)
	}
	pair, ok := c.MaintenanceNativeSetPairForTestV6(4, 1, q())
	if !ok || pair.SameSet || pair.SameMetadata || !pair.SameKinds {
		t.Fatal("independent seal wrapper", pair, ok)
	}
	pair, ok = c.MaintenanceNativeSetPairForTestV6(3, 0, q())
	if !ok || pair.SameMetadata || pair.SameKinds {
		t.Fatal("independent proof", pair, ok)
	}
	if _, ok = c.MaintenanceNativeSetPairForTestV6(3, 0, &iterator.OrdinalScanWork{}); ok {
		t.Fatal("unadmitted role pair")
	}
	c.sealPreparation.proofResources = sets[3]
	if _, ok = c.MaintenanceNativeSetRowForTestV6(3, q()); ok {
		t.Fatal("dual proof holder accepted")
	}
	c.sealPreparation.proofResources = nil
	c.sealPreparation.phase = 12
	if _, ok = c.MaintenanceNativeSetRowForTestV6(3, q()); ok {
		t.Fatal("partial proof transfer accepted")
	}
	c.sealPreparation.phase = 13
	c.sealPreparation.seal.primary.proofResources = nil
	g, ok = c.MaintenanceNativeSetRowForTestV6(3, q())
	if !ok || g.Present {
		t.Fatal("absent disposing proof accepted")
	}
	if owner.Bytes() != charged {
		t.Fatal("observation changed charge")
	}
	// Detach every holder before genuine original finite release/refund.
	c.candidatePreparation.resources = nil
	c.candidatePreparation.member = nil
	c.sealPreparation.seal = nil
	for i := range sets {
		var completion rootpublication.StableResourceTokenReleaseCompletionV6
		for turn := 0; ; turn++ {
			if turn == 100 {
				t.Fatal("set release stalled")
			}
			v, done, e := sets[i].ReleaseFromWithWorkV6(rootpublication.ResourceOwnerBuilder, q())
			if e != nil {
				t.Fatal(e)
			}
			if done {
				completion = v
				sets[i] = nil
				break
			}
		}
		var removal retainedalloc.RemovalWork
		for turn := 0; ; turn++ {
			if turn == 100 {
				t.Fatal("set refund stalled")
			}
			done, e := completion.CompleteWithWorkV6(&removal, q())
			if e != nil {
				t.Fatal(e)
			}
			if done {
				break
			}
		}
	}
	if owner.Bytes() != 0 {
		t.Fatal("role cleanup leaked", owner.Bytes())
	}
}
