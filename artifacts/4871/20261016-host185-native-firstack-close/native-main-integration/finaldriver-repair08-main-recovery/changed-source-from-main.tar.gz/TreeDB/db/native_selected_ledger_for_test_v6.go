package db

import (
	"github.com/snissn/gomap/TreeDB/freelist"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
	"unsafe"
)

func (s *Snapshot) MaintenanceNativeEnrollmentLedgerForTestV6(b retainedalloc.Budget, w *iterator.OrdinalScanWork) (g retainedalloc.NativeEnrollmentLedgerForTestV6, ready bool) {
	if s == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(*s))+128) {
		return g, false
	}
	s.iteratorMu.Lock()
	defer s.iteratorMu.Unlock()
	if s.db == nil || !s.nativeMVCC.workOwned || s.nativeMVCC.capturePhase != 4 || s.nativeMVCC.finalizePhase != 0 || s.closed.Load() {
		return g, true
	}
	first, second := s.db.valueLogIdentityPins.MetadataOwner(), (*retainedalloc.Owner)(nil)
	if s.primaryRoot != nil {
		first, second = s.primaryRoot.arena.MetadataOwner(), first
	}
	return s.primaryMetadata.MaintenancePairLedgerForTestV6(b, first, second, w)
}

type NativeSelectedRolesForTestV6 struct {
	Stable, DistinctSnapshots, PrimaryRegistryDistinct, OutputSameRegistry, OutputPointerMapAbsent, OutputScopeAbsent, OutputOwnerBound bool
	ProofTransferred, ResourcesTransferred                                                                                              bool
	SourceParentSame, TargetDistinct, TargetPresent, ClaimRefundAbsent, CandidateChargeTransferred                                      bool
}

// Fixed role identities only; no new edge, collection walk or mutable alias.
func (c *NativeMVCCCurrentDeleteV6) MaintenanceSelectedRoleFactsForTestV6(w *iterator.OrdinalScanWork) (g NativeSelectedRolesForTestV6, ready bool) {
	if c == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(*c))+2*uint64(unsafe.Sizeof(g))+2*uint64(unsafe.Sizeof(nativeMVCCCandidatePreparationV6{}))+2*uint64(unsafe.Sizeof(nativeMVCCSealPreparationV6{}))) {
		return g, false
	}
	s, m := &c.sealPreparation, c.candidatePreparation.member
	if c.db == nil || c.db.rootPublication == nil || c.db.rootPublication.idx == nil || c.db.rootPublication.idx.primary == nil || m == nil || s.seal == nil || m.install == nil {
		return g, true
	}
	g.Stable = c.phase == 4 && c.rootPreparation.phase == 7 && c.allocatorPreparation.phase == 8 && c.candidatePreparation.phase == 8 && c.candidatePreparation.bound && s.phase == 13 && !m.install.activated
	a, b := s.indexCaptures[0].snapshot, s.indexCaptures[1].snapshot
	g.DistinctSnapshots = c.snapshot != nil && a != nil && b != nil && c.snapshot != a && c.snapshot != b && a != b
	g.PrimaryRegistryDistinct = c.db.rootPublication.idx.primary.MetadataOwner() != c.db.valueLogIdentityPins.MetadataOwner()
	var ok bool
	g.OutputOwnerBound, g.OutputSameRegistry, g.OutputPointerMapAbsent, ok = c.output.MaintenanceNativePrivateRolesForTestV6(c.db.valueLogIdentityPins.MetadataOwner(), w)
	if !ok {
		return g, false
	}
	g.OutputScopeAbsent = c.outputScope == nil
	g.SourceParentSame = c.rootPreparation.source == s.parentRoot && s.parentRoot != (primaryarena.Ref{})
	g.TargetPresent = m.install.primaryRoot != nil
	if g.TargetPresent {
		g.TargetDistinct = m.install.primaryRoot.ref != c.rootPreparation.source && m.install.primaryRoot.ref != s.parentRoot
	}
	g.ClaimRefundAbsent = s.claimRefundOwner == nil && s.claimRefundCharge == 0
	g.CandidateChargeTransferred = c.candidatePreparation.charge == 0 && c.candidatePreparation.metadata == nil
	g.ProofTransferred = s.phase == 13 && s.proofResources == nil && s.seal.primary != nil && s.seal.primary.proofResources != nil
	g.ResourcesTransferred = s.phase == 13 && s.resources == nil && s.seal.resources != nil
	return g, true
}

func (c *NativeMVCCCurrentDeleteV6) MaintenanceNativeTokenLedgerForTestV6(index uint8, w *iterator.OrdinalScanWork) (rootpublication.NativeTokenLedgerForTestV6, bool) {
	if c == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(*c))+2*uint64(unsafe.Sizeof(rootPublicationSealV1{}))) || index > 1 || c.sealPreparation.seal == nil {
		return rootpublication.NativeTokenLedgerForTestV6{}, false
	}
	s := c.sealPreparation.seal
	token := s.token
	if index == 1 {
		if s.primary == nil {
			return rootpublication.NativeTokenLedgerForTestV6{}, false
		}
		token = s.primary.token
	}
	return token.MaintenanceAllocationLedgerForTestV6(w)
}
func (c *NativeMVCCCurrentDeleteV6) MaintenanceNativeTokenPairForTestV6(w *iterator.OrdinalScanWork) (rootpublication.NativeTokenPairForTestV6, bool) {
	if c == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(*c))+2*uint64(unsafe.Sizeof(rootPublicationSealV1{}))) || c.sealPreparation.seal == nil || c.sealPreparation.seal.primary == nil {
		return rootpublication.NativeTokenPairForTestV6{}, false
	}
	s := c.sealPreparation.seal
	return rootpublication.MaintenanceSelectedTokenPairForTestV6(s.token, s.primary.token, w)
}

func (c *NativeMVCCCurrentDeleteV6) MaintenanceNativePrivateLedgerForTestV6(w *iterator.OrdinalScanWork) (freelist.NativePrivateLedgerForTestV6, bool) {
	if c == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(*c))) {
		return freelist.NativePrivateLedgerForTestV6{}, false
	}
	return c.allocatorPreparation.preparation.MaintenancePrivateLedgerForTestV6(w)
}
