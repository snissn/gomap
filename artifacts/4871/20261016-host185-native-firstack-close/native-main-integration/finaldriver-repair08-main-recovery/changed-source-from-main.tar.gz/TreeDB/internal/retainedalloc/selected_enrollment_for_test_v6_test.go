package retainedalloc_test

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"testing"
)

func TestSelectedEnrollmentConstructorLedgerV6(t *testing.T) {
	var first, second retainedalloc.Owner
	first.Initialize(256)
	second.Initialize(512)
	budget := enrollmentBudget(t, 1<<20)
	defer budget.Close()
	var constructor retainedalloc.EnrollmentPairWork
	var e *retainedalloc.Enrollment
	for turn := 0; turn < 100; turn++ {
		result, ready, err := retainedalloc.EnrollPairWithWork(&first, &second, budget, &constructor, enrollmentQuantum())
		if err != nil {
			t.Fatal(err)
		}
		if ready {
			e = result
			break
		}
	}
	if e == nil || constructor.DetachResult() != e {
		t.Fatal("original enrollment pair incomplete")
	}
	defer e.Close()
	detached, ready := constructor.MaintenanceDetachedForTestV6(enrollmentQuantum())
	if !ready || !detached {
		t.Fatal("original pair still holds temporary operands")
	}
	beforeFirst, beforeSecond := first.Bytes(), second.Bytes()
	if _, ready := e.MaintenancePairLedgerForTestV6(budget, &first, &second, &iterator.OrdinalScanWork{}); ready {
		t.Fatal("unadmitted visit")
	}
	g, ready := e.MaintenancePairLedgerForTestV6(budget, &first, &second, enrollmentQuantum())
	if !ready || !g.Complete || !g.Companion || !g.DistinctHeaders || !g.DistinctBindings || g.EnrollmentCharges[0] == 0 || g.BindingCharges[1] == 0 || g.LeaseHeaderCharges[1] == 0 {
		t.Fatalf("actual constructor geometry: %+v ready=%v", g, ready)
	}
	bad, ready := e.MaintenancePairLedgerForTestV6(budget, &second, &first, enrollmentQuantum())
	if !ready || bad.Complete || bad.ExpectedOwners {
		t.Fatal("wrong owner role accepted")
	}
	if first.Bytes() != beforeFirst || second.Bytes() != beforeSecond {
		t.Fatal("observer changed original charge")
	}
	e.Close()
	bad, ready = e.MaintenancePairLedgerForTestV6(budget, &first, &second, enrollmentQuantum())
	if !ready || bad.Complete {
		t.Fatal("released enrollment accepted")
	}
	if err := first.Close(); err != nil {
		t.Fatal(err)
	}
	if err := second.Close(); err != nil {
		t.Fatal(err)
	}
}
