package rootpublication

import (
	"errors"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
	"sync"
	"unsafe"
)

// SealPrimaryBaseAbsenceV6 continues this SAME transaction's construction.
// The physical selection proof and fresh current-root cut belong to its DB
// caller. It creates neither a publication issuer nor a replacement owner.
func (t *DurableRootTransaction) SealPrimaryBaseAbsenceV6(current primaryarena.Ref, entry node.PrimaryDirectoryEntry, base node.PrimaryOperand, sequence uint64, scratch []byte, w *iterator.OrdinalScanWork) (bool, error) {
	if t == nil || w == nil {
		return false, ErrDurableRootOwnership
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	c := t.constructionV6
	if c == nil || c.cleanupPhase != 0 || t.phase != durableRootConstructingV6 || c.certificate != nil || c.componentCount != 0 {
		return false, ErrDurableRootOwnership
	}
	cert, ready, err := c.arena.SealConstructedBaseAbsenceV6(c.root, current, entry, base, sequence, scratch, t, w)
	if ready && err == nil {
		c.certificate = cert
	}
	return ready, err
}

// SealPrimaryCurrentAbsenceV6 continues the original constructor with the
// selected physical record's revision and a fresh current directory predicate.
func (t *DurableRootTransaction) SealPrimaryCurrentAbsenceV6(current primaryarena.Ref, entry node.PrimaryDirectoryEntry, base node.PrimaryOperand, sequence uint64, selectedRevision page.EntryRevision, scratch []byte, w *iterator.OrdinalScanWork) (bool, error) {
	if t == nil || w == nil {
		return false, ErrDurableRootOwnership
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	c := t.constructionV6
	if c == nil || c.cleanupPhase != 0 || t.phase != durableRootConstructingV6 || c.certificate != nil || c.componentCount != 0 {
		return false, ErrDurableRootOwnership
	}
	cert, ready, err := c.arena.SealConstructedCurrentAbsenceV6(c.root, current, entry, base, sequence, selectedRevision, scratch, t, w)
	if ready && err == nil {
		c.certificate = cert
	}
	return ready, err
}

// SealPrimaryConstructionWithWorkV6 advances canonical directory validation
// in the SAME native constructor. The original producer admits/retains work;
// no root or prepared allocator slot is installed across a yielded return.
func (t *DurableRootTransaction) SealPrimaryConstructionWithWorkV6(image []byte, groups [1]*primaryarena.Group, work *primaryarena.DirectorySealWorkV6, w *iterator.OrdinalScanWork) (bool, error) {
	if t == nil || work == nil || w == nil {
		return false, ErrDurableRootOwnership
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	c := t.constructionV6
	if c == nil || !c.nativeWorkOwned || c.cleanupPhase != 0 || t.phase != durableRootConstructingV6 || c.componentCount != 0 {
		return false, ErrDurableRootOwnership
	}
	cert, ready, err := work.Step(c.arena, c.root, image, groups, t, w)
	if ready && err == nil {
		if c.certificate != nil && c.certificate != cert {
			return false, ErrDurableRootOwnership
		}
		c.certificate = cert
	}
	return ready, err
}

var ErrNativeMVCCRootWorkRequiredV6 = errors.New("native MVCC transaction requires its original work-bearing caller")

// PrimaryConstructionReleaseWork belongs to the disposing original parent.
// Its containing allocation is admitted by that parent before Bind. It survives
// detaching the original transaction and its private constructor.
type PrimaryConstructionReleaseWork struct {
	mu          sync.Mutex
	transaction *DurableRootTransaction
	terminal    *primaryTerminalCompletionV6
	finishing   bool
	removal     retainedalloc.RemovalWork
	phase       uint8
	owner       ResourceOwnerState
}
type primaryConstructionReleaseState struct {
	owner  *retainedalloc.Owner
	charge uint64
}

func (s *PrimaryConstructionReleaseWork) Bind(t *DurableRootTransaction, w *iterator.OrdinalScanWork) (bool, error) {
	if s == nil || t == nil || w == nil {
		return false, ErrDurableRootOwnership
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.transaction != nil || s.phase != 0 {
		return false, ErrDurableRootOwnership
	}
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*s))+2*uint64(unsafe.Sizeof(*t))) {
		return false, nil
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.physicalCleanupError != nil {
		return false, t.physicalCleanupError
	}
	if (t.phase != durableRootConstructingV6 && t.phase != durableRootPrepared) || t.constructionV6 == nil || !t.constructionV6.nativeWorkOwned || t.constructionV6.cleanupReceipt != nil || (t.ownerLockedV6() != ResourceOwnerBuilder && t.ownerLockedV6() != ResourceOwnerCandidate) {
		return false, ErrDurableRootOwnership
	}
	t.constructionV6.cleanupReceipt = s
	s.transaction, s.owner = t, t.ownerLockedV6()
	return true, nil
}
func (s *PrimaryConstructionReleaseWork) ContinueWork(w *iterator.OrdinalScanWork) (bool, error) {
	if s == nil || w == nil {
		return false, ErrDurableRootOwnership
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.finishing {
		return false, ErrDurableRootOwnership
	}
	if s.phase == 2 {
		return true, nil
	}
	if s.phase == 1 {
		ready, err := s.removal.ContinueWork(w)
		if ready {
			s.phase = 2
		}
		return ready, err
	}
	t := s.transaction
	if t == nil {
		return false, ErrDurableRootOwnership
	}
	// Move the original abort-entry debit before the sticky/owner reads; the
	// admitted child below does not charge that same header a second time.
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*t))+2*uint64(unsafe.Sizeof(primaryTransactionConstructionV6{}))) {
		return false, nil
	}
	t.mu.Lock()
	if t.physicalCleanupError != nil {
		err := t.physicalCleanupError
		t.mu.Unlock()
		return false, err
	}
	if t.ownerLockedV6() != s.owner {
		t.mu.Unlock()
		return false, ErrDurableRootOwnership
	}
	var terminal primaryConstructionReleaseState
	ready, err := t.abortNativeMVCCConstructionStepAdmittedLockedV6(w, &terminal, &s.removal)
	if ready && err == nil {
		s.transaction = nil
		s.phase = 1
	}
	t.mu.Unlock()
	// The original transaction is no longer accessed after its active call joins.
	return false, err
}

// The old receiver-only native path cannot retain a receipt after refund of
// this receiver. Production callers must bind their admitted external receipt.
func (t *DurableRootTransaction) AbortNativeMVCCConstructionStepV6(w *iterator.OrdinalScanWork) (bool, error) {
	return false, ErrNativeMVCCRootWorkRequiredV6
}

// Ordinary Abort loops these exact phases under its ordinary unlimited policy.
// The native path has no opaque callbacks: the unbound private constructor has
// not installed any, and later visibility Finish supplies work-bearing hooks.
func (t *DurableRootTransaction) abortNativeMVCCConstructionStepLockedV6(w *iterator.OrdinalScanWork, terminal *primaryConstructionReleaseState, removal *retainedalloc.RemovalWork) (bool, error) {
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*t))+2*uint64(unsafe.Sizeof(primaryTransactionConstructionV6{}))) {
		return false, nil
	}
	return t.abortNativeMVCCConstructionStepAdmittedLockedV6(w, terminal, removal)
}

func (t *DurableRootTransaction) abortNativeMVCCConstructionStepAdmittedLockedV6(w *iterator.OrdinalScanWork, terminal *primaryConstructionReleaseState, removal *retainedalloc.RemovalWork) (bool, error) {
	if t.physicalCleanupError != nil {
		return false, t.physicalCleanupError
	}
	c := t.constructionV6
	if c == nil || (t.phase != durableRootConstructingV6 && t.phase != durableRootPrepared) {
		return false, ErrDurableRootOwnership
	}
	if c.cleanupPhase == 0 {
		if c.nativeWorkOwned && t.phase == durableRootPrepared {
			if t.abortWithWork == nil || t.abortCompleteWithWork == nil {
				return false, ErrNativeMVCCRootWorkRequiredV6
			}
			ready, err := t.abortWithWork(t.input, w)
			if err != nil {
				return false, t.recordPhysicalCleanupFailureLocked(err)
			}
			if !ready {
				return false, nil
			}
		}
		c.cleanupPhase = 1
	}
	for c.cleanupPhase == 1 && c.componentCount > 0 {
		r := c.components[c.componentCount-1]
		ready, err := c.arena.DropToReleaseQueue(r, &c.cleanupQueue, w)
		if err != nil {
			return false, t.recordPhysicalCleanupFailureLocked(err)
		}
		if !ready {
			return false, nil
		}
		c.componentCount--
		c.components[c.componentCount] = primaryarena.Ref{}
	}
	if c.cleanupPhase == 1 {
		c.cleanupPhase = 2
	}
	if c.cleanupPhase == 2 {
		if c.root != (primaryarena.Ref{}) {
			ready, err := c.arena.DropNativeMVCCConstructionToReleaseQueueV6(c.root, t, &c.cleanupQueue, w)
			if err != nil {
				return false, t.recordPhysicalCleanupFailureLocked(err)
			}
			if !ready {
				return false, nil
			}
			c.root = primaryarena.Ref{}
		}
		c.cleanupPhase = 7
	}
	// A native prepared transaction may retain a private promotion. Its SAME
	// four independent edges must join the original queue before aliases or
	// image/storage admission are withdrawn. No newer publication is consumed.
	for c.cleanupPhase == 7 && c.promotion != nil && c.cleanupPromotionIndex < 4 {
		refs := [4]*primaryarena.Ref{&c.promotion.Root, &c.promotion.Parent, &c.promotion.Closure, &c.promotion.ParentClosure}
		ref := refs[c.cleanupPromotionIndex]
		if *ref != (primaryarena.Ref{}) {
			ready, err := c.arena.DropToReleaseQueue(*ref, &c.cleanupQueue, w)
			if err != nil {
				return false, t.recordPhysicalCleanupFailureLocked(err)
			}
			if !ready {
				return false, nil
			}
			*ref = primaryarena.Ref{}
		}
		c.cleanupPromotionIndex++
	}
	if c.cleanupPhase == 7 {
		c.cleanupPhase = 3
	}
	if c.cleanupPhase == 3 {
		if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*t))+2*uint64(unsafe.Sizeof(*c))) {
			return false, nil
		}
		if c.nativeWorkOwned && t.phase == durableRootPrepared {
			ready, err := t.abortCompleteWithWork(t.input, w)
			if err != nil {
				return false, t.recordPhysicalCleanupFailureLocked(err)
			}
			if !ready {
				return false, nil
			}
		} else if t.abortComplete != nil {
			if err := t.abortComplete(t.input); err != nil {
				return false, t.recordPhysicalCleanupFailureLocked(err)
			}
		}
		// Dispose every certificate/image/callback alias BEFORE the bank's
		// physical release refunds its backing. These descriptors confer no
		// remaining edge; resources retain their own original owner cell.
		c.certificate, c.promotion = nil, nil
		c.candidate, c.members = PreparedRootCandidate{}, [1]*DurableRootTransaction{}
		t.input = DurableRootCallbackInput{}
		t.clearDurableRootCallbacksV6()
		c.cleanupPhase = 6
	}
	if c.cleanupPhase == 6 {
		if c.nativeWorkOwned && c.resources != nil {
			completion, ready, err := c.resources.ReleaseFromWithWorkV6(t.owner, w)
			if err != nil {
				return false, t.recordPhysicalCleanupFailureLocked(err)
			}
			if !ready {
				return false, nil
			}
			c.resources = nil
			// Candidate and callback aliases were detached in phase3. Only
			// this by-value accounting receipt survives the Set release call.
			completion.Complete()
		}
		c.cleanupPhase = 4
	}
	for c.cleanupPhase == 4 {
		var ready, progress bool
		var err error
		if c.nativeWorkOwned {
			ready, progress, err = c.arena.ReleaseNativeQueueStepV6(&c.cleanupQueue, w)
		} else {
			ready, progress, err = c.arena.ReleaseQueueStep(&c.cleanupQueue, w)
		}
		if err != nil {
			return false, t.recordPhysicalCleanupFailureLocked(err)
		}
		if !ready {
			return false, nil
		}
		if !progress {
			c.cleanupPhase = 5
		}
	}
	owner, charge := c.arena.MetadataOwner(), c.metadataCharge
	if removal != nil {
		ready, err := removal.BindPendingWork(owner, charge, w)
		if !ready || err != nil {
			return false, err
		}
	}
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*t))+2*uint64(unsafe.Sizeof(*c))) {
		return false, nil
	}
	t.constructionV6 = nil
	t.input = DurableRootCallbackInput{}
	t.clearDurableRootCallbacksV6()
	*c = primaryTransactionConstructionV6{}
	t.owner, t.phase = ResourceOwnerReleased, durableRootConsumed
	terminal.owner, terminal.charge = owner, charge
	return true, nil
}
