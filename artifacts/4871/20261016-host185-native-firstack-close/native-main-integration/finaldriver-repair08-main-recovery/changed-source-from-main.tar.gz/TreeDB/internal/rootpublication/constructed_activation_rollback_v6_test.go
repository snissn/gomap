package rootpublication

import (
	"context"
	"crypto/sha256"
	"errors"
	"path/filepath"
	"testing"

	"github.com/snissn/gomap/TreeDB/freelist"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
)

// The ordinary Owner() accessor follows the Set owner and can conceal a stale
// raw transaction owner. Exercise the actual constructor and final builder
// handoff, then its original disposer, without publishing a durable frontier.
func TestConstructedPrimaryActivationRollbackPreservesCustodyV6(t *testing.T) {
	for _, name := range []string{"ordinary", "native-work", "native-rollback-failure"} {
		t.Run(name, func(t *testing.T) {
			native := name != "ordinary"
			rollbackFailure := name == "native-rollback-failure"
			a, err := primaryarena.OpenCapsule(filepath.Join(t.TempDir(), "primary"))
			if err != nil {
				t.Fatal(err)
			}
			defer func() {
				if err := a.Close(); err != nil {
					t.Error(err)
				}
			}()
			work := func() *iterator.OrdinalScanWork {
				return &iterator.OrdinalScanWork{RecordLimit: 100, ByteLimit: 1 << 20}
			}
			baseline := a.MetadataOwner().Bytes()
			construct := NewPrimaryConstructionTransactionV6
			if native {
				construct = NewNativeMVCCPrimaryConstructionTransactionV6
			}
			original, ready, err := construct(a, work())
			if !ready || err != nil {
				t.Fatal(ready, err)
			}
			txn := original.(*DurableRootTransaction)
			ref := txn.PrimaryConstructionReferenceV6()
			data := freelist.NewMemoryPageStoreV1()
			base, system := primaryRootTestLeaf(2, "a", "old", 1), primaryRootTestLeaf(3, "system", "s", 1)
			data.Pages[2], data.Pages[3] = base, system
			image := make([]byte, page.PageSize)
			if err := node.EncodePrimaryDirectory(image, ref.PageID, 1, node.PrimaryOperand{Ref: page.PageChildRef(2), Digest: sha256.Sum256(base)}, nil); err != nil {
				t.Fatal(err)
			}
			if ready, err := txn.SealPrimaryConstructionV6(image, [1]*primaryarena.Group{}, work()); !ready || err != nil {
				t.Fatal(ready, err)
			}
			frontier := NewFrontier(1, ref.PageID, 3, 0, 1)
			prepared, ready, err := NewPreparedPrimaryReadRootCertificateV6(txn.PrimaryConstructionCertificateV6(), freelist.MustNewFreelistGenerationV1(1, 4, nil, nil), nil, frontier, data, nil, work())
			if !ready || err != nil {
				t.Fatal(ready, err)
			}
			kinds, err := newResourceKindBacking(a.MetadataOwner(), nil)
			if err != nil {
				t.Fatal(err)
			}
			set, err := newStableResourceSetFromKindViews(kinds)
			if err != nil {
				t.Fatal(err)
			}
			cause := errors.New("constructed activation rejected before visibility")
			activated, aborted, completed := 0, 0, 0
			var stateQueue primaryarena.ReleaseQueue
			a.InitializeReleaseQueue(&stateQueue)
			spec := DurableRootTransactionSpec{
				Lineage: DurableRootLineageID{1}, Sequence: 1, PreparedPrimary: prepared,
				Activate: func(DurableRootCallbackInput) error { activated++; return cause },
				Consume:  func(DurableRootCallbackInput) error { t.Fatal("consume after rejected activation"); return nil },
				Abort: func(DurableRootCallbackInput) error {
					ready, err := a.Drop(ref, work()) // independent state edge from Bind
					if !ready && err == nil {
						return ErrNativeMVCCRootWorkRequiredV6
					}
					if ready && err == nil {
						aborted++
					}
					return err
				},
				Fail: func(DurableRootCallbackInput, error) error { t.Fatal("failure after rejected activation"); return nil },
			}
			if native {
				spec.ActivateWithWork = func(_ DurableRootCallbackInput, w *iterator.OrdinalScanWork) (bool, error) {
					if !w.Reserve(1, 8) {
						return false, nil
					}
					activated++
					if rollbackFailure {
						// Inject a rejected rollback using the SAME original Set
						// transition. Do not forge successful publication/cleanup.
						if err := set.transfer(ResourceOwnerCoordinator, ResourceOwnerCandidate); err != nil {
							t.Fatal(err)
						}
					}
					return false, cause
				}
				spec.ConsumeWithWork = func(DurableRootCallbackInput, *iterator.OrdinalScanWork) (bool, error) {
					t.Fatal("native consume after rejection")
					return false, nil
				}
				spec.AbortWithWork = func(_ DurableRootCallbackInput, w *iterator.OrdinalScanWork) (bool, error) {
					ready, err := a.DropToReleaseQueue(ref, &stateQueue, w)
					if ready && err == nil {
						aborted++
					}
					return ready, err
				}
				spec.AbortCompleteWithWork = func(_ DurableRootCallbackInput, w *iterator.OrdinalScanWork) (bool, error) {
					ready, progress, err := a.ReleaseNativeQueueStepV6(&stateQueue, w)
					if ready && !progress && err == nil {
						completed++
						return true, nil
					}
					return false, err
				}
			}
			if ready, err := txn.BindPrimaryVisibilityV6(spec, set, work()); !ready || err != nil {
				t.Fatal(ready, err)
			}
			candidate, err := NewPreparedRootCandidate(CandidateSpec{Frontier: frontier, TotalPages: 4, ResourceSet: set, DurableRoot: txn})
			if err != nil {
				t.Fatal(err)
			}
			coordinator, err := New(Options{StartupSynchronous: true, Publisher: PublisherFunc(func(context.Context, *PreparedRootCandidate) PublishResult {
				t.Fatal("publisher reached after rejected activation")
				return PublishResult{}
			})})
			if err != nil {
				t.Fatal(err)
			}
			defer stopClean(t, coordinator)
			token, err := coordinator.AcquireBuilder(context.Background())
			if err != nil {
				t.Fatal(err)
			}
			defer token.Release()
			before, counters, construction := coordinator.Stats(), a.Counters(), txn.constructionV6
			var supplied *iterator.OrdinalScanWork
			if native {
				supplied = work()
			}
			if native {
				r, b := enqueueActivationRollbackFailureWorkV6()
				for _, short := range []*iterator.OrdinalScanWork{
					{RecordLimit: r - 1, ByteLimit: 1 << 20},
					{RecordLimit: r, ByteLimit: b - 1},
				} {
					if handoff, err := coordinator.EnqueueBuiltWithWorkV6(candidate, token, short); handoff != nil || !errors.Is(err, ErrNativeMVCCRootWorkRequiredV6) || activated != 0 || txn.owner != ResourceOwnerCandidate || set.Owner() != ResourceOwnerCandidate || a.Counters() != counters || coordinator.Stats().ActiveBuilders != before.ActiveBuilders {
						t.Fatal("failure-latch admission refused after effects", handoff, err)
					}
				}
			}
			handoff, err := coordinator.EnqueueBuiltWithWorkV6(candidate, token, supplied)
			if handoff != nil || !errors.Is(err, cause) {
				t.Fatal("activation cause/handoff changed", handoff, err)
			}
			// This shared builder adapter preserves its ordinary contextual wrapper;
			// the SAME native receipt entry returns the original cause directly.
			// Inspect BOTH original cells, not the derived Owner() alone.
			txn.mu.Lock()
			rawOwner, phase, sameConstruction, cleanupErr := txn.owner, txn.phase, txn.constructionV6 == construction, txn.physicalCleanupError
			txn.mu.Unlock()
			after := coordinator.Stats()
			if rollbackFailure {
				receipt := &txn.physicalCleanupReceipt
				if !errors.Is(err, receipt) || cleanupErr != receipt || coordinator.poison != receipt || !errors.Is(err, ErrResourceOwnership) || !errors.Is(err, ErrDurableRootOwnership) || receipt.original != txn || receipt.causes != [3]error{cause, ErrResourceOwnership, ErrDurableRootOwnership} || rawOwner != ResourceOwnerCoordinator || set.Owner() != ResourceOwnerCandidate || phase != durableRootPrepared || !sameConstruction || activated != 1 || aborted != 0 || a.Counters() != counters || after.VisibleCommitSeq != before.VisibleCommitSeq || after.DurableCommitSeq != before.DurableCommitSeq || after.PendingCommits != 0 || after.ActiveBuilders != before.ActiveBuilders {
					t.Fatal("unexpected rollback did not retain both causes/original custody", err, rawOwner, set.Owner(), before, after)
				}
				charge := a.MetadataOwner().Bytes()
				var bind PrimaryConstructionReleaseWork
				if ready, err := bind.Bind(txn, work()); ready || err != receipt || bind.transaction != nil {
					t.Fatal("Bind lost original sticky receipt", ready, err)
				}
				// A synthetic preexisting continuation position tests only
				// refusal ordering; it cannot confer successful disposal authority.
				continuation := PrimaryConstructionReleaseWork{transaction: txn, owner: ResourceOwnerBuilder}
				if ready, err := continuation.ContinueWork(work()); ready || err != receipt || continuation.transaction != txn || continuation.phase != 0 {
					t.Fatal("Continue lost original sticky receipt", ready, err)
				}
				if err := txn.Abort(); err != receipt || a.MetadataOwner().Bytes() != charge || a.Counters() != counters || txn.owner != rawOwner || txn.constructionV6 != construction || set.Owner() != ResourceOwnerCandidate || aborted != 0 {
					t.Fatal("sticky abort replayed/freed failed handoff", err)
				}
				if err := candidate.Abandon(); err != receipt || a.MetadataOwner().Bytes() != charge || set.Owner() != ResourceOwnerCandidate || aborted != 0 {
					t.Fatal("failed ordinary Abandon released retained Set", err)
				}
				probe, err := token.Nested()
				if err != nil {
					t.Fatal("sticky rollback consumed original builder", err)
				}
				probe.Release()
				// The outer fixture teardown closes its whole isolated arena;
				// no successful transaction cleanup/refund is claimed here.
				return
			}
			if activated != 1 || rawOwner != ResourceOwnerCandidate || set.Owner() != ResourceOwnerCandidate || phase != durableRootPrepared || !sameConstruction || cleanupErr != nil || a.Counters() != counters || coordinator.poison != nil || after.PendingCommits != before.PendingCommits || after.VisibleCommitSeq != before.VisibleCommitSeq || after.DurableCommitSeq != before.DurableCommitSeq || after.ActiveBuilders != before.ActiveBuilders || after.RejectedCandidates != before.RejectedCandidates+1 {
				t.Fatal("rejected constructed handoff split original custody", rawOwner, set.Owner(), phase, before, after)
			}
			probe, err := token.Nested()
			if err != nil {
				t.Fatal("failed activation consumed final builder", err)
			}
			probe.Release()
			if native {
				var receipt PrimaryConstructionReleaseWork
				if ready, err := receipt.Bind(txn, &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}); !ready || err != nil {
					t.Fatal(ready, err)
				}
				done := false
				for turn := 0; turn < 100; turn++ {
					ready, err := receipt.ContinueWork(&iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20})
					if err != nil {
						t.Fatal("original finite abort", turn, err)
					}
					if ready {
						done = true
						break
					}
				}
				if !done || receipt.transaction != nil || receipt.phase != 2 || completed != 1 {
					t.Fatal("original finite receipt did not complete", done, receipt.phase, completed)
				}
				bytes := a.MetadataOwner().Bytes()
				if ready, err := receipt.ContinueWork(&iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}); !ready || err != nil || a.MetadataOwner().Bytes() != bytes {
					t.Fatal("receipt replay changed refund", ready, err)
				}
			} else if err := candidate.Abandon(); err != nil {
				t.Fatal("ordinary original abort and Set release", err)
			}
			if txn.owner != ResourceOwnerReleased || txn.phase != durableRootConsumed || txn.constructionV6 != nil || set.Owner() != ResourceOwnerReleased || a.MetadataOwner().Bytes() != baseline || aborted != 1 || a.Counters().RootDrops != counters.RootDrops+2 || a.Counters().BanksFreed != counters.BanksFreed+1 {
				t.Fatal("original abort lost/replayed custody", txn.owner, txn.phase, set.Owner(), aborted, a.Counters(), a.MetadataOwner().Bytes(), baseline)
			}
		})
	}
}
