package rootpublication

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/pager"
	"sync"
	"unsafe"
)

// Completion carries only the exact original admission after the producer
// method returns. The directory clears its provider alias before consuming it.
type DependencyDirectoryReleaseCompletionV6 struct {
	Metadata *retainedalloc.Owner
	Charge   uint64
}

// A typed original producer performs its actual physical phases. ready=false
// is resumable admission refusal; ready=true, consumed=false is sticky debt.
type DependencyDirectoryReleaseProviderV6 interface {
	ReleaseDependencyDirectoryWorkV6(*iterator.OrdinalScanWork) (consumed, ready bool, completion DependencyDirectoryReleaseCompletionV6, err error)
}

// The original parent admits this external receipt at its own birth. It never
// allocates a callback, substitutes a root owner or builds a disposal list.
type DependencyDirectoryReleaseWork struct {
	mu                              sync.Mutex
	directory                       *DependencyDirectoryV2
	completion                      DependencyDirectoryReleaseCompletionV6
	directoryOwner                  *retainedalloc.Owner
	directoryCharge                 uint64
	producerRefund, directoryRefund retainedalloc.RemovalWork
	phase                           uint8
	bound, consumed                 bool
	readerDetached                  bool
	err                             error
}

func directoryReleaseReserve(w *iterator.OrdinalScanWork, records, bytes uint64) bool {
	return w == nil || w.Reserve(records, bytes)
}

func NewOwnedWorkLocalPrimaryDependencyDirectoryV6(p *pager.Pager, ref DependencyDirectoryRefV2, extent uint64, metadata *retainedalloc.Owner, release DependencyDirectoryReleaseProviderV6) (*DependencyDirectoryV2, error) {
	if release == nil {
		return nil, ErrResourceOwnership
	}
	// The constructor's original canonical geometry and allocation admission
	// remain in one maintained implementation. This static callback never runs.
	directory, err := NewOwnedLocalPrimaryDependencyDirectoryV5(p, ref, extent, metadata, unusedTypedDirectoryRelease)
	if err != nil {
		return nil, err
	}
	directory.ownedRelease = nil
	directory.ownedReleaseWork = release
	return directory, nil
}

// DATA and PRIMARY use the SAME canonical directory constructor and release receipt.
func NewOwnedWorkDependencyDirectoryV6(p *pager.Pager, ref DependencyDirectoryRefV2, extent uint64, metadata *retainedalloc.Owner, provider DependencyDirectoryReleaseProviderV6) (*DependencyDirectoryV2, error) {
	if provider == nil {
		return nil, ErrResourceOwnership
	}
	return newDependencyDirectoryV2(p, ref, extent, nil, metadata, provider)
}

func unusedTypedDirectoryRelease() (bool, error) { return false, ErrResourceOwnership }

func (s *DependencyDirectoryReleaseWork) Bind(directory *DependencyDirectoryV2, w *iterator.OrdinalScanWork) (bool, error) {
	if w == nil {
		return false, retainedalloc.ErrWorkRequired
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.bind(directory, w)
}
func (s *DependencyDirectoryReleaseWork) bind(directory *DependencyDirectoryV2, w *iterator.OrdinalScanWork) (bool, error) {
	if s.bound {
		return false, ErrResourceOwnership
	}
	if directory == nil {
		s.bound = true
		s.consumed = true
		s.phase = 4
		return true, nil
	}
	if w != nil {
		if eligibility, ok := directory.ownedReleaseWork.(interface{ SupportsBoundedDependencyDirectoryReleaseV6() bool }); ok && !eligibility.SupportsBoundedDependencyDirectoryReleaseV6() {
			return false, retainedalloc.ErrWorkRequired
		}
	}
	if w != nil && directory.ownedReleaseWork == nil {
		return false, retainedalloc.ErrWorkRequired
	}
	if !directoryReleaseReserve(w, 1, 2*uint64(unsafe.Sizeof(*directory))+2*uint64(unsafe.Sizeof(*s))) {
		return false, nil
	}
	if directory.cleanupDone.Load() {
		s.bound = true
		s.consumed = directory.cleanupConsumed
		s.phase = 4
		if directory.cleanupFailure.causes[0] != nil {
			if s.consumed {
				s.err = directory.cleanupFailure.causes[0]
			} else {
				s.err = &directory.cleanupFailure
			}
		}
		return true, nil
	}
	last := false
	for refs := directory.refs.Load(); refs > 0; refs = directory.refs.Load() {
		if directory.refs.CompareAndSwap(refs, refs-1) {
			last = refs == 1
			s.bound = true
			break
		}
		if !directoryReleaseReserve(w, 1, 16) {
			return false, nil
		}
	}
	if !s.bound {
		return false, retainedalloc.ErrWorkRequired
	}
	if !last {
		s.phase = 4
		s.consumed = true
		return true, nil
	}
	directory.releaseNative = w != nil
	s.directory = directory
	return true, nil
}
func (s *DependencyDirectoryReleaseWork) ContinueWork(w *iterator.OrdinalScanWork) (consumed, ready bool, err error) {
	if w == nil {
		return false, false, retainedalloc.ErrWorkRequired
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.continueWork(w)
}
func (s *DependencyDirectoryReleaseWork) fail(directory *DependencyDirectoryV2, err error) (bool, bool, error) {
	if err == nil {
		err = ErrResourceOwnership
	}
	directory.cleanupFailure.original = directory
	directory.cleanupFailure.causes[0] = err
	directory.cleanupConsumed = false
	if directory.metadata != nil {
		directory.metadata.CleanupFailed()
	}
	directory.cleanupDone.Store(true)
	s.err = &directory.cleanupFailure
	s.phase = 4
	return false, true, s.err
}
func (s *DependencyDirectoryReleaseWork) continueWork(w *iterator.OrdinalScanWork) (bool, bool, error) {
	if !s.bound {
		return false, false, ErrResourceOwnership
	}
	if s.phase == 4 {
		return s.consumed, true, s.err
	}
	directory := s.directory
	if s.phase < 3 && directory == nil {
		return false, false, ErrResourceOwnership
	}
	if s.phase == 0 {
		if !directoryReleaseReserve(w, 1, 2*uint64(unsafe.Sizeof(*directory))) {
			return false, false, nil
		}
		if !s.readerDetached {
			if directory.tree != nil {
				if !directoryReleaseReserve(w, 1, 2*uint64(unsafe.Sizeof(*directory.tree))) {
					return false, false, nil
				}
				// The last capability edge is already transferred. End the original
				// physical reader alias before its producer can complete physical close.
				directory.tree.Reset(nil, nil, 0)
			}
			s.readerDetached = true
		}
		consumed, ready := true, true
		var err error
		if directory.ownedReleaseWork != nil {
			provider := directory.ownedReleaseWork
			consumed, ready, s.completion, err = provider.ReleaseDependencyDirectoryWorkV6(w)
			provider = nil
		} else if directory.metadata != nil {
			callback := directory.ownedRelease
			consumed, err = callback()
			callback = nil
		} else {
			callback := directory.release
			callback()
			callback = nil
		}
		if !ready && err == nil {
			return false, false, nil
		}
		if !consumed {
			return s.fail(directory, err)
		}
		if !ready {
			return s.fail(directory, err)
		}
		if s.completion.Charge != 0 && (s.completion.Metadata == nil || s.completion.Metadata != directory.metadata) {
			return s.fail(directory, ErrResourceOwnership)
		}
		s.err = err
		s.phase = 1
	}
	if s.phase == 1 {
		if w != nil {
			if s.completion.Charge != 0 {
				ready, err := s.producerRefund.BindPendingWork(s.completion.Metadata, s.completion.Charge, w)
				if !ready || err != nil {
					return false, false, err
				}
			}
			if directory.metadataCharge != 0 {
				ready, err := s.directoryRefund.BindPendingWork(directory.metadata, directory.metadataCharge, w)
				if !ready || err != nil {
					return false, false, err
				}
			}
		}
		s.directoryOwner, s.directoryCharge = directory.metadata, directory.metadataCharge
		s.phase = 2
	}
	if s.phase == 2 {
		if !directoryReleaseReserve(w, 1, 2*uint64(unsafe.Sizeof(*directory))+2*uint64(unsafe.Sizeof(*s))) {
			return false, false, nil
		}
		directory.tree = nil
		directory.release = nil
		directory.ownedRelease = nil
		directory.ownedReleaseWork = nil
		directory.metadata = nil
		directory.metadataCharge = 0
		directory.cleanupConsumed = true
		directory.cleanupFailure.causes[0] = s.err
		directory.cleanupDone.Store(true)
		s.directory = nil
		directory = nil
		s.phase = 3
		// Return through the actual disposing method before containing refunds.
		return false, false, nil
	}
	directory = nil
	if s.completion.Charge != 0 {
		if w == nil {
			s.completion.Metadata.RemovePending(s.completion.Charge)
		} else {
			ready, err := s.producerRefund.ContinueWork(w)
			if !ready || err != nil {
				return false, false, err
			}
		}
		s.completion = DependencyDirectoryReleaseCompletionV6{}
	}
	if s.directoryCharge != 0 {
		if w == nil {
			s.directoryOwner.RemovePending(s.directoryCharge)
		} else {
			ready, err := s.directoryRefund.ContinueWork(w)
			if !ready || err != nil {
				return false, false, err
			}
		}
		s.directoryOwner = nil
		s.directoryCharge = 0
	}
	s.phase = 4
	s.consumed = true
	return true, true, s.err
}

// resetCompletedWork reuses the SAME serial scratch after its previous physical
// and accounting stages completed. No initialized mutex is copied or reset.
func (s *DependencyDirectoryReleaseWork) resetCompletedWork(w *iterator.OrdinalScanWork) (bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.phase != 4 || !s.consumed || s.err != nil || s.directory != nil || s.completion.Metadata != nil || s.directoryOwner != nil {
		return false, ErrResourceOwnership
	}
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*s))) {
		return false, nil
	}
	if ready, err := s.producerRefund.ResetUnusedOrCompletedWork(w); !ready || err != nil {
		return false, err
	}
	if ready, err := s.directoryRefund.ResetUnusedOrCompletedWork(w); !ready || err != nil {
		return false, err
	}
	s.phase, s.bound, s.consumed, s.readerDetached = 0, false, false, false
	return true, nil
}
