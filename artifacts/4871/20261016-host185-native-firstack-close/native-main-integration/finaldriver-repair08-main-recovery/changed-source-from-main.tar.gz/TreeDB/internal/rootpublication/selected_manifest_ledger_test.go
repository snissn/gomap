package rootpublication

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/page"
	"github.com/snissn/gomap/TreeDB/pager"
	"path/filepath"
	"testing"
	"unsafe"
)

func TestSelectedEmptyManifestConstructorLedgerV6(t *testing.T) {
	var owner, other retainedalloc.Owner
	owner.Initialize(0)
	other.Initialize(0)
	q := func() *iterator.OrdinalScanWork {
		return &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
	}
	set, ready, err := PrepareEmptyStableResourceSetWithOrdinalWorkV6(&owner, nil, q())
	if err != nil || !ready {
		t.Fatal("original empty Set", ready, err)
	}
	manifest, ready, err := EmptyDependencyManifestWithWorkV6(set, q())
	if err != nil || !ready {
		t.Fatal("original empty manifest", ready, err)
	}
	before := owner.Bytes()
	if _, ok := manifest.MaintenanceNativeManifestAllocationForTestV6(&iterator.OrdinalScanWork{}); ok {
		t.Fatal("unadmitted manifest visit")
	}
	g, ok := manifest.MaintenanceNativeManifestAllocationForTestV6(q())
	expected := retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(DependencyManifestV1{}))) + retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(resourceAllocation{})))
	if !ok || !g.Present || !g.Selected || g.Released || g.OpaqueEntryGraph || !g.OriginalOwner || g.Charge != expected {
		t.Fatal("independent empty allocation", g)
	}
	if same, ok := manifest.MaintenanceNativeOwnerMatchesForTestV6(&owner, q()); !ok || !same {
		t.Fatal("original owner")
	}
	if same, ok := manifest.MaintenanceNativeOwnerMatchesForTestV6(&other, q()); !ok || same {
		t.Fatal("wrong owner")
	}
	manifest.payload = make([]byte, 0, 1)
	bad, ok := manifest.MaintenanceNativeManifestAllocationForTestV6(q())
	manifest.payload = nil
	if !ok || !bad.OpaqueEntryGraph || owner.Bytes() != before {
		t.Fatal("nonempty backing/observer effects")
	}
	// SAME original finite graph release, then detach parent alias before refund.
	var completion StableResourceTokenReleaseCompletionV6
	for turn := 0; turn < 100; turn++ {
		v, done, e := manifest.ReleaseOwnedMetadataWithWorkV6(q())
		if e != nil {
			t.Fatal(e)
		}
		if done {
			completion = v
			manifest = nil
			break
		}
	}
	if manifest != nil {
		t.Fatal("manifest disposal stalled")
	}
	var removal retainedalloc.RemovalWork
	for turn := 0; turn < 100; turn++ {
		done, e := completion.CompleteWithWorkV6(&removal, q())
		if e != nil {
			t.Fatal(e)
		}
		if done {
			break
		}
		if turn == 99 {
			t.Fatal("manifest refund stalled")
		}
	}
	for turn := 0; turn < 100; turn++ {
		v, done, e := set.ReleaseFromWithWorkV6(ResourceOwnerBuilder, q())
		if e != nil {
			t.Fatal(e)
		}
		if done {
			completion = v
			set = nil
			break
		}
	}
	if set != nil {
		t.Fatal("Set disposal stalled")
	}
	removal = retainedalloc.RemovalWork{}
	for turn := 0; turn < 100; turn++ {
		done, e := completion.CompleteWithWorkV6(&removal, q())
		if e != nil {
			t.Fatal(e)
		}
		if done {
			break
		}
		if turn == 99 {
			t.Fatal("Set refund stalled")
		}
	}
	if owner.Bytes() != 0 {
		t.Fatal("original ownership leaked", owner.Bytes())
	}
}

// This typed fixture collaborator owns only its original counter obligation.
// Its admitted effect is not a real native publication or physical file fence.
type selectedDirectoryCounterV6 struct {
	total   *int
	effects int
}

func (p *selectedDirectoryCounterV6) ReleaseDependencyDirectoryWorkV6(w *iterator.OrdinalScanWork) (bool, bool, DependencyDirectoryReleaseCompletionV6, error) {
	if w == nil {
		return false, false, DependencyDirectoryReleaseCompletionV6{}, retainedalloc.ErrWorkRequired
	}
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*p))+2*uint64(unsafe.Sizeof(int(0)))) {
		return false, false, DependencyDirectoryReleaseCompletionV6{}, nil
	}
	if p.effects == 0 {
		(*p.total)++
		p.effects++
	}
	return true, true, DependencyDirectoryReleaseCompletionV6{}, nil
}

// Genuine constructor outputs; only the role comparisons are diagnostic. No
// candidate/transaction/member authority or publication is fabricated.
func TestSelectedSetAllocationPairsV6(t *testing.T) {
	q := func() *iterator.OrdinalScanWork {
		return &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
	}
	for _, emptyDirectory := range []bool{false, true} {
		name := "kinds"
		if emptyDirectory {
			name = "empty-directory"
		}
		t.Run(name, func(t *testing.T) {
			var owner retainedalloc.Owner
			owner.Initialize(0)
			var directory, independent *DependencyDirectoryV2
			var p *pager.Pager
			calls := 0
			providers := [2]selectedDirectoryCounterV6{{total: &calls}, {total: &calls}}
			if emptyDirectory {
				for i := range providers {
					consumed, ready, completion, err := providers[i].ReleaseDependencyDirectoryWorkV6(&iterator.OrdinalScanWork{})
					if consumed || ready || err != nil || completion.Metadata != nil || completion.Charge != 0 || providers[i].effects != 0 || calls != 0 {
						t.Fatal("unadmitted directory counter effect", consumed, ready, err)
					}
				}
				var err error
				p, err = pager.Open(filepath.Join(t.TempDir(), "primary"), 65536)
				if err != nil {
					t.Fatal(err)
				}
				defer p.Close()
				if err = p.GrowTo(3); err != nil {
					t.Fatal(err)
				}
				ref := DependencyDirectoryRefV2{RootPageID: page.PrimaryBankNamespace + 2}
				directory, err = NewOwnedWorkLocalPrimaryDependencyDirectoryV6(p, ref, 3, &owner, &providers[0])
				if err != nil {
					t.Fatal(err)
				}
				independent, err = NewOwnedWorkLocalPrimaryDependencyDirectoryV6(p, ref, 3, &owner, &providers[1])
				if err != nil {
					t.Fatal(err)
				}
			}
			var sets [3]*StableResourceSet
			if emptyDirectory {
				var err error
				sets[0], err = newStableResourceSetWithEmptyDirectory(&owner, directory)
				if err != nil {
					t.Fatal(err)
				}
				sets[2], err = newStableResourceSetWithEmptyDirectory(&owner, independent)
				if err != nil {
					t.Fatal(err)
				}
			} else {
				for _, i := range []int{0, 2} {
					var ready bool
					var err error
					sets[i], ready, err = PrepareEmptyStableResourceSetWithOrdinalWorkV6(&owner, nil, q())
					if err != nil || !ready {
						t.Fatal(ready, err)
					}
				}
			}
			var ready bool
			var err error
			sets[1], ready, err = CloneAdmittedStableResourceSetWithOrdinalWorkV6(sets[0], q())
			if err != nil || !ready {
				t.Fatal(ready, err)
			}
			charged := owner.Bytes()
			if _, ok := sets[1].MaintenanceNativeSetAllocationForTestV6(sets[0], &iterator.OrdinalScanWork{}); ok {
				t.Fatal("unadmitted pair")
			}
			shared, ok := sets[1].MaintenanceNativeSetAllocationForTestV6(sets[0], q())
			if !ok || !shared.Present || !shared.Live || !shared.OriginalOwner || !shared.SameOwner || shared.SameSet || shared.SameMetadata || shared.OpaqueLogicalGraph || shared.SameKinds == emptyDirectory || shared.SameEmpty != emptyDirectory {
				t.Fatal("original clone allocation facts", shared, ok)
			}
			distinct, ok := sets[2].MaintenanceNativeSetAllocationForTestV6(sets[0], q())
			if !ok || distinct.SameMetadata || distinct.SameSet || distinct.SameKinds || distinct.SameEmpty || !distinct.SameOwner || !distinct.OriginalOwner {
				t.Fatal("independent proof backing collapsed", distinct, ok)
			}
			same, ok := sets[0].MaintenanceNativeSetAllocationForTestV6(sets[0], q())
			if !ok || !same.SameSet || !same.SameMetadata || same.SameKinds == emptyDirectory || same.SameEmpty != emptyDirectory {
				t.Fatal("same allocation", same, ok)
			}
			// Nonempty graph must remain unsupported without a payload traversal.
			if emptyDirectory {
				directory.ref.LogicalCount = 1
			} else {
				sets[0].pinHighWater = map[ResourceKind]uint64{}
			}
			bad, ok := sets[0].MaintenanceNativeSetAllocationForTestV6(nil, q())
			if emptyDirectory {
				directory.ref.LogicalCount = 0
			} else {
				sets[0].pinHighWater = nil
			}
			if !ok || !bad.OpaqueLogicalGraph || owner.Bytes() != charged {
				t.Fatal("unsupported shape/observer effects", bad, ok)
			}
			for i := range sets {
				var completion StableResourceTokenReleaseCompletionV6
				for turn := 0; ; turn++ {
					if turn == 100 {
						t.Fatal("set release stalled")
					}
					v, done, e := sets[i].ReleaseFromWithWorkV6(ResourceOwnerBuilder, q())
					if e != nil {
						t.Fatal(e)
					}
					if done {
						completion = v
						sets[i] = nil
						break
					}
				}
				var removal retainedalloc.RemovalWork
				for turn := 0; ; turn++ {
					if turn == 100 {
						t.Fatal("set refund stalled")
					}
					done, e := completion.CompleteWithWorkV6(&removal, q())
					if e != nil {
						t.Fatal(e)
					}
					if done {
						break
					}
				}
			}
			if emptyDirectory {
				if calls != 0 {
					t.Fatal("nonlast Set edges consumed directory producer", calls)
				}
				for _, held := range []**DependencyDirectoryV2{&directory, &independent} {
					var receipt DependencyDirectoryReleaseWork
					bound := false
					for turn := 0; turn < 100; turn++ {
						ready, err := receipt.Bind(*held, q())
						if err != nil {
							t.Fatal(err)
						}
						if ready {
							*held = nil
							bound = true
							break
						}
					}
					if !bound {
						t.Fatal("directory final-edge bind stalled")
					}
					finished := false
					for turn := 0; turn < 100; turn++ {
						consumed, ready, err := receipt.ContinueWork(q())
						if err != nil {
							t.Fatal(err)
						}
						if ready {
							if !consumed {
								t.Fatal("directory final edge not consumed")
							}
							finished = true
							break
						}
					}
					if !finished {
						t.Fatal("directory final-edge cleanup stalled")
					}
				}
				if calls != 2 || providers[0].effects != 1 || providers[1].effects != 1 {
					t.Fatal("original directory collaborator effects", calls, providers)
				}
			}
			if owner.Bytes() != 0 {
				t.Fatal("constructor pair cleanup leaked", owner.Bytes())
			}
		})
	}
}
