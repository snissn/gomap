package retainedalloc

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"unsafe"
)

// Fixed original capture roles only, not Owner.Controls or a binding-list sum.
type NativeEnrollmentLedgerForTestV6 struct {
	Present, Companion, DistinctHeaders, DistinctBindings, ExpectedOwners, SameBudget bool
	Complete, UnsupportedLease, Closed, Overflow                                      bool
	EnrollmentCharges, BindingCharges, LeaseHeaderCharges                             [2]uint64
}

// The original close lock protects each Enrollment and its companion. Owner.mu
// protects that exact binding, then the original concrete lease observer uses
// its budget exclusion. No retained object or pointer escapes this observation.
func (e *Enrollment) MaintenancePairLedgerForTestV6(budget Budget, first, second *Owner, w *iterator.OrdinalScanWork) (g NativeEnrollmentLedgerForTestV6, ready bool) {
	if w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(Enrollment{}))+2*uint64(unsafe.Sizeof(g))) {
		return g, false
	}
	if e == nil {
		return g, true
	}
	e.closeWork.mu.Lock()
	defer e.closeWork.mu.Unlock()
	g.Present, g.Companion = true, e.companion != nil
	g.DistinctHeaders = e.companion == nil || e != e.companion
	if !g.DistinctHeaders {
		return g, true
	}
	if e.companion != nil {
		e.companion.closeWork.mu.Lock()
		defer e.companion.closeWork.mu.Unlock()
	}
	entries := [2]*Enrollment{e, e.companion}
	expected := [2]*Owner{first, second}
	g.ExpectedOwners, g.SameBudget, g.Complete = first != nil && first != second, true, true
	for i, entry := range entries {
		if !w.Reserve(1, 2*uint64(unsafe.Sizeof(Enrollment{}))+2*uint64(unsafe.Sizeof(binding{}))+2*uint64(unsafe.Sizeof(Owner{}))+64) {
			return g, false
		}
		if entry == nil {
			g.ExpectedOwners = g.ExpectedOwners && expected[i] == nil
			continue
		}
		g.EnrollmentCharges[i] = AllocationCharge(uint64(unsafe.Sizeof(Enrollment{})))
		g.Closed = g.Closed || entry.closed.Load() || entry.closeWork.phase != 0
		o, b := entry.owner, entry.binding
		g.ExpectedOwners = g.ExpectedOwners && o != nil && o == expected[i]
		if o == nil || b == nil {
			g.Complete = false
			continue
		}
		o.mu.Lock()
		g.SameBudget = g.SameBudget && b.budget == budget
		g.Complete = g.Complete && !o.closed && !o.retired && !o.cleanupFailed && b.refs != 0 && b.lease != nil
		g.BindingCharges[i] = AllocationCharge(uint64(unsafe.Sizeof(binding{})))
		observer, ok := b.lease.(nativeRetentionLeaseObserverForTestV6)
		if !ok {
			g.UnsupportedLease = true
			g.Complete = false
			o.mu.Unlock()
			continue
		}
		lease, ok := observer.MaintenanceNativeRetentionGeometryForTestV6(budget, w)
		o.mu.Unlock()
		if !ok {
			return g, false
		}
		g.LeaseHeaderCharges[i] = lease.HeaderCharge
		g.UnsupportedLease = g.UnsupportedLease || !lease.Concrete
		g.SameBudget = g.SameBudget && lease.SameBudget
		g.Complete = g.Complete && lease.Concrete && lease.SameBudget && !lease.Closed && lease.HeaderCharge != 0
	}
	g.DistinctBindings = e.companion == nil || e.binding != e.companion.binding
	// Distinct selected owners imply distinct concrete COWBudget acquisitions;
	// their concrete leases are created once per binding, never shared by that
	// original constructor. Payload reservations are deliberately excluded.
	g.Complete = g.Complete && g.ExpectedOwners && g.SameBudget && g.DistinctHeaders && g.DistinctBindings && !g.Closed && !g.UnsupportedLease
	return g, true
}

// Read only the two embedded completed constructors, never owner.head. After
// DetachResult the Snapshot is sole result owner and no temporary lease remains.
func (s *EnrollmentPairWork) MaintenanceDetachedForTestV6(w *iterator.OrdinalScanWork) (complete, ready bool) {
	if s == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(*s))) {
		return false, false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.first.mu.Lock()
	defer s.first.mu.Unlock()
	s.second.mu.Lock()
	defer s.second.mu.Unlock()
	clean := func(x *EnrollmentWork) bool {
		return x.owner == nil && x.budget == nil && x.cursor == nil && x.found == nil && x.result == nil && x.pending == nil && x.pendingAdmitted == 0 && x.delta == 0 && x.detachedAmount == 0 && x.failure == nil
	}
	return s.phase == 4 && s.failure == nil && s.cancelPhase == 0 && s.primary == nil && s.firstOwner == nil && s.secondOwner == nil && s.budget == nil && s.first.phase == 6 && (s.second.phase == 0 || s.second.phase == 6) && clean(&s.first) && clean(&s.second), true
}
