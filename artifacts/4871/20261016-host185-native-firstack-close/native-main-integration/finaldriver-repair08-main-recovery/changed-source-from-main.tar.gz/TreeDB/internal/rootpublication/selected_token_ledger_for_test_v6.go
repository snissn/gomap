package rootpublication

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"unsafe"
)

// Independent allocations omitted from the older token envelope observer.
// Pin header lives in token metadata; only its original registry STATE is new.
type NativeTokenLedgerForTestV6 struct {
	Present, EmptyAncillary, SameOwner, Live, PinPresent, CanonicalPin, PinNoChannel bool
	NamespaceSupported, Complete                                                     bool
	ObligationCharge, PinStateCharge                                                 uint64
}

func (t *StableResourceToken) MaintenanceAllocationLedgerForTestV6(w *iterator.OrdinalScanWork) (g NativeTokenLedgerForTestV6, ready bool) {
	if w == nil || !w.Reserve(2, 2*uint64(unsafe.Sizeof(StableResourceToken{}))+2*uint64(unsafe.Sizeof(resourceObligationBacking{}))+4*uint64(unsafe.Sizeof(resourceAllocation{}))+2*uint64(unsafe.Sizeof(g))) {
		return g, false
	}
	if t == nil {
		return g, true
	}
	g.Present, g.Live = true, !t.released.Load()
	g.EmptyAncillary = t.diagnostics == nil && t.importedSource == nil && t.importedFields == nil && t.directory == nil && t.frontier.exactRIDs == nil && t.syncedFrontier.exactRIDs == nil && cap(t.logicalObligations) == 0 && t.releaseObservation == nil && t.observationCleanup == nil
	g.SameOwner = t.metadata != nil && t.metadata.owner != nil && t.physicalBacking != nil && t.physicalBacking.owner == t.metadata.owner
	if b := t.obligationBacking; b != nil && b.allocation != nil {
		g.ObligationCharge = b.allocation.charge
		g.EmptyAncillary = g.EmptyAncillary && cap(b.values) == 0
		g.SameOwner = g.SameOwner && t.metadata != nil && b.allocation.owner == t.metadata.owner
	} else {
		g.EmptyAncillary = false
	}
	if ns := t.namespace; ns != nil {
		if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*ns))) {
			return g, false
		}
		ns.mu.Lock()
		_, native := ns.adapter.(nativeNamespaceAdapter)
		g.NamespaceSupported = native && ns.metadataScoped && ns.metadataCharge != 0 && ns.batch == nil && ns.diagnosticSyncs.Load() == nil && ns.failedNext == nil && ns.cleanupErr == nil && ns.stabilizeErr == nil && !ns.released.Load()
		g.SameOwner = g.SameOwner && t.metadata != nil && ns.metadata == t.metadata.owner
		ns.mu.Unlock()
	}
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(IdentityPin{}))+2*uint64(unsafe.Sizeof(identityPinState{}))+4*uint64(unsafe.Sizeof(StableIdentity{}))) {
		return g, false
	}
	pin := t.identityPin
	if pin != nil {
		pin.releaseMu.Lock()
		r, state := pin.registry, pin.state
		if r != nil && state != nil {
			r.mu.Lock()
			g.PinPresent = !pin.released && state.pins > 0 && !state.deleting && !state.retired
			g.CanonicalPin = pin.identity.Generation == 0 && pin.identity == physicalStableIdentity(t.identity)
			g.PinNoChannel = state.zero == nil
			g.PinStateCharge = retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(*state)))
			r.mu.Unlock()
		}
		pin.releaseMu.Unlock()
	}
	g.Complete = g.Live && g.EmptyAncillary && g.SameOwner && g.NamespaceSupported && g.PinPresent && g.CanonicalPin && g.PinNoChannel && g.ObligationCharge != 0
	return g, true
}

type NativeTokenPairForTestV6 struct {
	Present, SameToken, SameMetadata, SameObligation, SamePhysical, SameNamespace, SamePinState, SameRegistry bool
}

// Both original tokens are held by the synchronous prebuilder. Compare fixed
// pointers locally (not content/physical-identity equivalence), returning none.
func MaintenanceSelectedTokenPairForTestV6(a, b *StableResourceToken, w *iterator.OrdinalScanWork) (g NativeTokenPairForTestV6, ready bool) {
	if w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(StableResourceToken{}))+4*uint64(unsafe.Sizeof(IdentityPin{}))+2*uint64(unsafe.Sizeof(g))) {
		return g, false
	}
	if a == nil || b == nil {
		return g, true
	}
	g.Present, g.SameToken = true, a == b
	g.SameMetadata = a.metadata != nil && a.metadata == b.metadata
	g.SameObligation = a.obligationBacking != nil && a.obligationBacking == b.obligationBacking
	g.SamePhysical = a.physicalBacking != nil && a.physicalBacking == b.physicalBacking
	g.SameNamespace = a.namespace != nil && a.namespace == b.namespace
	if a.identityPin != nil && b.identityPin != nil {
		// Prebuilder retains sole consumption authority. These pointer operands
		// are immutable until release; no mutable state counters are read here.
		g.SamePinState = a.identityPin.state != nil && a.identityPin.state == b.identityPin.state
		g.SameRegistry = a.identityPin.registry != nil && a.identityPin.registry == b.identityPin.registry
	}
	return g, true
}
