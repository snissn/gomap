package mvcc

import (
	"bytes"
	"encoding/binary"
	"errors"
	"testing"
	"time"

	treedb "github.com/snissn/gomap/TreeDB"
	"github.com/snissn/gomap/TreeDB/internal/mvcckey"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
)

// This separately selected experiment uses a fresh cursor and a source-derived
// prebirth grant. It never changes/retries the original Q32 refusal cursor.
// Running these arms requires a distinct explicit real-publication grant.
func TestNativeSelectedOriginalSplitDiagnosticV6(t *testing.T) {
	for _, arm := range []string{"ready-cancel", "stale-before-fence", "frozen-limits", "once-ack", "paused-finish-close", "pruner-enabled-refusal"} {
		t.Run(arm, func(t *testing.T) { nativeSelectedOriginalSplitDiagnosticV6(t, arm) })
	}
}

func nativeSelectedOriginalSplitDiagnosticV6(t *testing.T, arm string) {
	t.Helper()
	opts := treedb.OptionsFor(treedb.ProfileNoWALFast, t.TempDir())
	opts.IndexOuterLeavesInValueLog = false
	opts.ValueLog.PointerThreshold = 2048
	opts.BackgroundCheckpointInterval = -1
	// The finite original ordered-post path excludes the ordinary background
	// pruner (validateNativePostActivationV6). Keep one genuine enabled-pruner
	// arm to verify rejection and original cancellation, rather than changing
	// production eligibility or the NoWALFast durability profile.
	opts.DisableBackgroundPrune = arm != "pruner-enabled-refusal"
	d, err := treedb.Open(opts)
	if err != nil {
		t.Fatal(err)
	}
	s := New(d)
	key := []byte("actual-selected-anchor")
	for ts := uint64(1); ts <= 33; ts++ {
		if err := s.CommitAt(ts, []Mutation{{Key: key, Value: []byte{byte(ts)}}}, CommitRelaxed); err != nil {
			t.Fatal(err)
		}
	}
	if err := s.AdvanceDiscardFloor(32, CommitDurable); err != nil {
		t.Fatal(err)
	}
	if err := d.Checkpoint(); err != nil {
		t.Fatal(err)
	}
	if err := d.Close(); err != nil {
		t.Fatal(err)
	}
	d, err = treedb.Open(opts)
	if err != nil {
		t.Fatal(err)
	}
	dbClosed := false
	defer func() {
		if !dbClosed {
			if e := d.Close(); e != nil {
				t.Error(e)
			}
		}
	}()
	s = New(d)
	// The SAME fresh Open constructs empty mutable shards and no queued overlay;
	// only backend Get/AcquireSnapshot/scalar observations occur before the first
	// native call below. No Commit/Set/Checkpoint runs in this interval, so the
	// selected input prefix is empty without manufacturing a cache capture.
	oldKey, _ := mvcckey.Encode(key, 1)
	oldValue, err := d.Get(oldKey)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(oldValue, []byte{recordValueV1, 1}) {
		t.Fatal("unexpected physical old version before cursor", oldValue)
	}
	// The floor shares the same DATA leaf as encoded version records. Its
	// physical value is the fixed tag plus uint64, not a version payload.
	var floorRecord [1 + 8]byte
	floorRecord[0] = discardFloorRecordV1
	binary.BigEndian.PutUint64(floorRecord[1:], 32)
	if v, e := d.Get(discardFloorKey); e != nil || !bytes.Equal(v, floorRecord[:]) {
		t.Fatal("unexpected physical discard floor before cursor", v, e)
	}
	old := d.AcquireSnapshot()
	if old == nil {
		t.Fatal("missing genuine held old reader")
	}
	oldClosed := false
	defer func() {
		if !oldClosed {
			old.Close()
		}
	}()
	g := nativeDiagnosticBackendCensusV6(t, d)
	cache, ready := d.MaintenanceNativePreCursorCacheForTestV6(nativeDiagnosticObservationQuantumV6())
	// StepNativeMVCCCaptureV6 rejects an existing COW cache: this adaptive
	// native route requires the original non-COW cache, not COW configuration.
	if !ready || cache.Closing || cache.COWMode {
		t.Fatal("pre-cursor cache shape unavailable", cache)
	}
	// Bound the actual pre-cursor DATA records: version values carry their
	// recordValueV1 tag, while the floor has its own key and nine-byte encoding.
	// No prepared output or post-ready operand supplies these physical bounds.
	keyBytes := uint64(max(len(oldKey), len(discardFloorKey)))
	valueBytes := uint64(max(len(oldValue), len(floorRecord)))
	envelope := nativeSelectedDiagnosticEnvelopeV6(g, cache.Shards, keyBytes, valueBytes)
	if envelope.Missing != "" {
		t.Fatal("G unavailable BEFORE cursor birth", envelope.Missing)
	}
	t.Logf("native-split prebirth G=%+v birth=%+v prepare=%+v F=%+v Finish=%+v Cancel=%+v Close=%+v Npre=%d L=%d allocator=%+v noQ32Acceptance=true", envelope.Grant, envelope.Birth, envelope.Prepare, envelope.Fence, envelope.Finish, envelope.Cancel, envelope.Close, g.Bank.PagerTable.TableNodeCount, envelope.LookupNodes, envelope.Allocator)
	options := PruneOptions{Mode: CommitDurable, BatchSize: 1, WorkRecords: envelope.Grant.Records, WorkBytes: envelope.Grant.Bytes}
	var c *PruneCursor
	defer func() {
		if c != nil && !dbClosed {
			if e := c.Close(); e != nil {
				t.Error("original cursor cleanup", e)
			}
		}
	}()
	call := func() (PruneStats, error) {
		options.Cursor = c
		stats, e := s.PruneVersions(options)
		if stats.Cursor != nil {
			c = stats.Cursor
		}
		if stats.WorkRecords > options.WorkRecords || stats.WorkBytes > options.WorkBytes {
			t.Fatal("original grant exceeded", stats)
		}
		return stats, e
	}
	for turns := 0; ; turns++ {
		if turns >= 10000 {
			t.Fatal("first ready did not converge")
		}
		stats, e := call()
		if e != nil {
			t.Fatal("prepare", e)
		}
		if c == nil || stats.Pruned != 0 || stats.Batches != 0 || stats.Complete {
			t.Fatal("premature completion", stats)
		}
		if c.publicationReady {
			break
		}
	}
	if c.phase != 26 || len(c.batchEntries) != 1 || c.request.Floor() != 32 || c.recordLimit != options.WorkRecords || c.byteLimit != options.WorkBytes {
		t.Fatal("not SAME first selected ready", c.phase)
	}
	selected := append([]byte(nil), c.batchEntries[0].Key...)
	nativeValidateReadyDiagnosticEnvelopeV6(t, c, envelope)
	testNativeSelectedConstructorLedgerV6(t, c)
	if arm == "pruner-enabled-refusal" {
		selectedExpected, e := old.Get(selected)
		if e != nil || len(selectedExpected) == 0 {
			t.Fatal("held reader missing selected row before pruner refusal", selectedExpected, e)
		}
		stats, e := call()
		if !errors.Is(e, rootpublication.ErrNativeMVCCRootWorkRequiredV6) || stats.Pruned != 0 || stats.Batches != 0 || stats.Complete || c.phase != 26 {
			t.Fatal("enabled pruner did not refuse before visible adoption/ACK", stats, e, c.phase)
		}
		c.mu.Lock()
		position, ok := c.preparation.MaintenanceNativePublishedFinishGeometryForTestV6(c, nativeDiagnosticObservationQuantumV6())
		allocator, allocatorOK := c.preparation.MaintenanceNativeAllocatorGeometryForTestV6(nativeDiagnosticObservationQuantumV6())
		c.mu.Unlock()
		if !ok || !allocatorOK || !allocator.PreVisible || allocator.Activated != 0 || !position.OriginalBinding || !position.Receipt.SameOwner || !position.Receipt.Bound || position.Receipt.Turn || position.Receipt.Fenced || position.Receipt.Complete || position.Receipt.RecoveryRequired {
			t.Fatal("enabled-pruner refusal changed original private custody", position, allocator)
		}
		if e := c.Close(); e != nil {
			t.Fatal("enabled-pruner original cancellation", e)
		}
		if v, e := d.Get(selected); e != nil || !bytes.Equal(v, selectedExpected) {
			t.Fatal("enabled-pruner refusal/cancel changed selected row", v, e)
		}
		if v, e := d.Get(oldKey); e != nil || !bytes.Equal(v, oldValue) {
			t.Fatal("enabled-pruner refusal/cancel changed old value", v, e)
		}
		old.Close()
		oldClosed = true
		if e := d.Close(); e != nil {
			t.Fatal("enabled-pruner actual DB.Close", e)
		}
		dbClosed = true
		return
	}
	if arm == "ready-cancel" {
		selectedExpected, e := old.Get(selected)
		if e != nil || len(selectedExpected) == 0 {
			t.Fatal("held reader missing selected row before cancel", selectedExpected, e)
		}
		if e := c.Close(); e != nil {
			t.Fatal(e)
		}
		if v, e := d.Get(selected); e != nil || !bytes.Equal(v, selectedExpected) {
			t.Fatal("private cancel changed selected row", v, e)
		}
		return
	}
	if arm == "frozen-limits" {
		changed := options
		changed.Cursor = c
		changed.WorkRecords++
		stats, e := s.PruneVersions(changed)
		if e == nil || stats.Pruned != 0 || !c.publicationReady || c.recordLimit != options.WorkRecords {
			t.Fatal("immutable limits accepted change", stats, e)
		}
		if e := c.Close(); e != nil {
			t.Fatal(e)
		}
		return
	}
	writer := func() {
		if e := s.CommitAt(34, []Mutation{{Key: []byte("newer-real-writer"), Value: []byte("newer")}}, CommitDurable); e != nil {
			t.Fatal("newer genuine durable writer", e)
		}
	}
	if arm == "stale-before-fence" {
		writer()
		stats, e := call()
		if e == nil || stats.Pruned != 0 || stats.Batches != 0 {
			t.Fatal("stale selected authority accepted", stats, e)
		}
		if e := c.Close(); e != nil {
			t.Fatal("stale original cancellation", e)
		}
		newer, _ := mvcckey.Encode([]byte("newer-real-writer"), 34)
		if v, e := d.Get(newer); e != nil || !bytes.Equal(v, append([]byte{recordValueV1}, []byte("newer")...)) {
			t.Fatal("stale cancel damaged newer writer", v, e)
		}
		return
	}
	// Real fence must return at the existing mandatory FinishDetached boundary.
	// No fabricated receipt/member/phase creates this position.
	for turns := 0; ; turns++ {
		if turns >= 10000 {
			t.Fatal("genuine FinishDetached did not converge")
		}
		stats, e := call()
		if e != nil {
			t.Fatal("original publish/Finish", e)
		}
		if stats.Pruned != 0 || stats.Batches != 0 {
			t.Fatal("ACK before physical receipt detached", stats)
		}
		c.mu.Lock()
		position, ok := c.preparation.MaintenanceNativePublishedFinishGeometryForTestV6(c, nativeDiagnosticObservationQuantumV6())
		c.mu.Unlock()
		if !ok {
			t.Fatal("genuine Finish observer refused")
		}
		if position.Release.Detached && !position.Release.AccountingComplete {
			if !position.SourceWitnessPresent || !position.OriginalBinding || !position.Receipt.SameOwner || !position.Receipt.Bound || !position.Receipt.Fenced || position.Receipt.Turn || position.Receipt.Complete || position.Receipt.RecoveryRequired || c.phase != 27 {
				t.Fatal("wrong genuine receipt custody", position, c.phase)
			}
			t.Logf("native-split genuine paused Finish position=%+v ACK=0", position)
			break
		}
	}
	if v, e := old.Get(oldKey); e != nil || !bytes.Equal(v, oldValue) {
		t.Fatal("old reader after native publication", v, e)
	}
	writer()
	if v, e := old.Get(oldKey); e != nil || !bytes.Equal(v, oldValue) {
		t.Fatal("old reader after newer durable writer", v, e)
	}
	if arm == "paused-finish-close" {
		old.Close()
		oldClosed = true
		done := make(chan error, 1)
		go func() { done <- d.Close() }()
		select {
		case e := <-done:
			if e != nil {
				t.Fatal("actual DB.Close join", e)
			}
			dbClosed = true
		case <-time.After(20 * time.Second):
			t.Fatal("actual DB.Close did not join original Finish")
		}
		if !c.closed || c.retention != nil {
			t.Fatal("Close left original cursor/lease alive")
		}
	} else {
		for turns := 0; ; turns++ {
			if turns >= 10000 {
				t.Fatal("original Finish/ACK did not converge")
			}
			stats, e := call()
			if e != nil {
				t.Fatal(e)
			}
			if stats.Pruned != 0 {
				if stats.Pruned != 1 || stats.Batches != 1 {
					t.Fatal("wrong exact ACK", stats)
				}
				break
			}
		}
		if e := c.Close(); e != nil {
			t.Fatal(e)
		}
		if e := c.Close(); e != nil {
			t.Fatal("terminal replay", e)
		}
		old.Close()
		oldClosed = true
		if e := d.Close(); e != nil {
			t.Fatal(e)
		}
		dbClosed = true
	}
	// Real reopened DATA verifies native deletion, retained anchor/future and
	// the newer durable writer; successful Close cannot replay an old frontier.
	reopened, e := treedb.Open(opts)
	if e != nil {
		t.Fatal(e)
	}
	defer reopened.Close()
	if v, e := reopened.Get(selected); e != nil || v != nil {
		t.Fatal("native selected row survived reopen", v, e)
	}
	for _, ts := range []uint64{32, 33} {
		k, _ := mvcckey.Encode(key, ts)
		if v, e := reopened.Get(k); e != nil || !bytes.Equal(v, []byte{recordValueV1, byte(ts)}) {
			t.Fatal("anchor/future lost", ts, v, e)
		}
	}
	if v, e := reopened.Get(discardFloorKey); e != nil || !bytes.Equal(v, floorRecord[:]) {
		t.Fatal("discard floor lost after old Finish", v, e)
	}
	newer, _ := mvcckey.Encode([]byte("newer-real-writer"), 34)
	if v, e := reopened.Get(newer); e != nil || !bytes.Equal(v, append([]byte{recordValueV1}, []byte("newer")...)) {
		t.Fatal("newer durable root lost after old Finish", v, e)
	}
}

// Every ready read has its original Q32 quantum. A mismatch rejects BEFORE
// calling Fence and cannot enlarge the grant frozen on cursor birth.
func nativeValidateReadyDiagnosticEnvelopeV6(t *testing.T, c *PruneCursor, e nativeDiagnosticEnvelopeV6) {
	t.Helper()
	c.mu.Lock()
	defer c.mu.Unlock()
	a, ok := c.preparation.MaintenanceNativeAllocatorGeometryForTestV6(nativeDiagnosticObservationQuantumV6())
	// The original observer counts every private DATA entry conservatively;
	// it does not perform an exact distinct-ID discovery scan. That count must
	// still agree with its source and fit the bound fixed before cursor birth.
	if !ok || !a.SourceMatches || !a.PreVisible || a.Overflow || a.Coverage != 0 || !a.PageSizesValid || a.NewIDs != a.Data || a.NewIDs > e.Allocator.Allocated || !a.ExplicitPrivate || !a.PrivateMapsNil || !a.PrivateSameOwner || a.MetadataPages > e.Allocator.MetadataPages || a.PrivateAllocated > e.Allocator.Allocated || a.RetirementIDs > e.Allocator.Retired || a.ChangedMapEntries > e.Allocator.Changed || a.ReplacedMapEntries > e.Allocator.Replaced || a.RequiredHighWater > e.Allocator.HighWater || a.Activated != 0 {
		t.Fatalf("ready allocator escaped prebirth envelope: observed=%+v ready=%v bound=%+v", a, ok, e.Allocator)
	}
	for role := uint8(0); role < 2; role++ {
		o, _, ready := c.capture.MaintenanceNativeOwnerGeometryForTestV6(c.preparation, role, nativeDiagnosticObservationQuantumV6())
		if !ready || !o.Complete || o.UnsupportedLease || o.UnsupportedEnrollment || o.Overflow || o.Closed || o.Retired || o.CleanupFailed || o.ActiveEnrollment || o.Bindings > e.OwnerBindings {
			t.Fatal("ready original owner escaped envelope", role, o)
		}
	}
	for role := uint8(0); role < 4; role++ {
		table, ready := c.preparation.MaintenanceNativeRegistryTableForTestV6(role, nativeDiagnosticObservationQuantumV6())
		capacity, known := rootpublication.NativeSelectedRegistryCapacityForTestV6(e.Source.Registry)
		if !ready || !known || !table.Present || !table.SameOwner || table.Capacity > capacity {
			t.Fatal("ready registry backing escaped precursor", role, table)
		}
	}
	b, _, _, ok := c.preparation.MaintenanceNativeBankGeometryForTestV6(2, nativeDiagnosticObservationQuantumV6())
	if !ok || b.PagerTable.TableNodeCount+1 > e.LookupNodes-4 {
		t.Fatal("ready RAM node bound", b)
	}
	remainder, ok := c.preparation.MaintenanceNativeRemainderGeometryForTestV6(nativeDiagnosticObservationQuantumV6())
	if !ok || !remainder.Complete || remainder.Unsupported || remainder.Overflow || remainder.Bound.Prefix != 1 || remainder.Bound.MetadataPages > e.Allocator.MetadataPages || remainder.Bound.HighWater > e.Allocator.HighWater {
		t.Fatal("ready original publication bound", remainder)
	}
}
