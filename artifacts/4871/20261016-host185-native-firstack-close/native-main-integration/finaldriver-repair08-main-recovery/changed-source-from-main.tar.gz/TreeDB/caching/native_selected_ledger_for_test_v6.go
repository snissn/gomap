package caching

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"unsafe"
)

type NativeCaptureLedgerForTestV6 struct {
	Stable, OuterPresent, CapturePresent, DistinctLeases, ConstructorDetached bool
	Enrollments                                                               retainedalloc.NativeEnrollmentLedgerForTestV6
}

func (c *NativeMVCCCaptureV6) MaintenanceSelectedLedgerForTestV6(outer *memtable.COWExternalLease, w *iterator.OrdinalScanWork) (g NativeCaptureLedgerForTestV6, ready bool) {
	if c == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(*c))+2*uint64(unsafe.Sizeof(g))) {
		return g, false
	}
	g.Stable = c.phase == 3 && c.owned && c.metadataAdopted && c.ownedFailure == nil && c.currentWork == nil && c.primaryMetadata == nil && c.registryMetadata == nil && c.Snapshot != nil
	g.OuterPresent, g.CapturePresent = outer != nil, c.retention != nil
	g.DistinctLeases = g.OuterPresent && g.CapturePresent && outer != c.retention
	var ok bool
	g.ConstructorDetached, ok = c.enrollment.MaintenanceDetachedForTestV6(w)
	if !ok {
		return g, false
	}
	g.Enrollments, ok = c.Snapshot.MaintenanceNativeEnrollmentLedgerForTestV6(c.budget, w)
	return g, ok
}
