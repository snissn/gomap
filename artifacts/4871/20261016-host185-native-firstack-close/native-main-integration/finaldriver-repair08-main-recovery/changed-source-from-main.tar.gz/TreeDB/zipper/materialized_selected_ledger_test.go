package zipper

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/page"
	"testing"
)

func TestMaterializedSelectedLedgerOwnerAndPointerMapV6(t *testing.T) {
	var owner, other retainedalloc.Owner
	owner.Initialize(0)
	other.Initialize(0)
	q := func() *iterator.OrdinalScanWork {
		return &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
	}
	output, ready, err := NewMaterializedWriteWork(&Zipper{}, &owner, page.PageChildRef(2), nil, q())
	if err != nil || !ready || output == nil {
		t.Fatal("original containing constructor", ready, err)
	}
	defer func() {
		for turn := 0; turn < 100; turn++ {
			done, e := output.Cancel(q())
			if e != nil {
				t.Error(e)
				return
			}
			if done {
				metadata, charge, complete, e := output.CompleteWithWorkV6(q())
				if e != nil || !complete {
					t.Error("original output completion", complete, e)
					return
				}
				output = nil
				var removal retainedalloc.RemovalWork
				for step := 0; step < 100; step++ {
					ok, e := removal.CompletePendingWork(&metadata, &charge, q())
					if e != nil {
						t.Error(e)
						return
					}
					if ok {
						if owner.Bytes() != 0 {
							t.Error("original output retained charge", owner.Bytes())
						}
						return
					}
				}
				t.Error("original refund stalled")
				return
			}
		}
		t.Error("original output cleanup stalled")
	}()
	before := owner.Bytes()
	if _, _, _, ok := output.MaintenanceNativePrivateRolesForTestV6(&owner, &iterator.OrdinalScanWork{}); ok {
		t.Fatal("unadmitted read")
	}
	present, same, absent, ok := output.MaintenanceNativePrivateRolesForTestV6(&owner, q())
	if !ok || !present || !same || !absent {
		t.Fatal("genuine owner/map facts")
	}
	_, same, _, ok = output.MaintenanceNativePrivateRolesForTestV6(&other, q())
	if !ok || same {
		t.Fatal("wrong owner")
	}
	output.refs.counts = make(map[uint32]uint64)
	_, _, absent, ok = output.MaintenanceNativePrivateRolesForTestV6(&owner, q())
	output.refs.counts = nil
	if !ok || absent || owner.Bytes() != before {
		t.Fatal("allocated empty map incorrectly absent or observer effects")
	}
}
