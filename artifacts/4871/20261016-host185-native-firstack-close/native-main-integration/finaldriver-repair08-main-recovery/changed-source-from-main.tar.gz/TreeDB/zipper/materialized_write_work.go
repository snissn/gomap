package zipper

import (
	"bytes"
	"crypto/sha256"
	"errors"
	"fmt"
	"unsafe"

	"github.com/snissn/gomap/TreeDB/batch"
	"github.com/snissn/gomap/TreeDB/freelist"
	"github.com/snissn/gomap/TreeDB/internal/adaptive"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/internal/valuelog"
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
)

var ErrMaterializedWriteContinuation = errors.New("zipper: retained materialized split or external-page continuation required")

// MaterializedWriteWork retains the ordinary zipper's physical merge decisions,
// original node encoders and original allocator/Pager operations. It borrows a
// caller-owned immutable DATA basis and sorted point delta. It owns NO root or
// publication authority. Installed pages stay in the original live allocator;
// no prepared candidate, BuildGroup or writer lock survives Step.
// Split outputs retain the original first-right separators and exact ChildRefs.
// Outer-leaf persistence is currently explicit unbounded-diagnostic work;
// production append and installed-page cancellation still require continuation.
type MaterializedWriteWork struct {
	z                                  *Zipper
	owner                              *retainedalloc.Owner
	head, current, root                *materializedWriteFrame
	reader                             MaterializedFrameReaderV6
	leafAppend                         valuelog.LeafAppendWork
	appendTarget                       *materializedWriteFrame
	unboundedLeafPersistenceDiagnostic bool
	charge                             uint64
	refs                               PointerRefCounts
	removed                            uint64
	result                             node.PrimaryOperand
	phase                              uint8
	adoptNext                          *materializedWriteFrame
	adoptionBegun                      bool
}

// MaterializedFrameReaderV6 borrows the original retained basis phased
// page/vlog reader. Destination images belong to admitted output frames.
type MaterializedFrameReaderV6 interface {
	BeginProjectionFrame(page.ChildRef, []byte, *iterator.OrdinalScanWork) (bool, error)
	StepProjectionFrame(*iterator.OrdinalScanWork) ([]byte, bool, error)
}

func (s *MaterializedWriteWork) BindFrameReaderV6(reader MaterializedFrameReaderV6) {
	s.reader = reader
}

// EnableUnboundedLeafPersistenceDiagnosticV6 is only for the existing public
// diagnostic driver. The original append and all codec/registration work stay
// inside its measured call; this grants NO bounded work or production credit.
func (s *MaterializedWriteWork) EnableUnboundedLeafPersistenceDiagnosticV6() {
	s.unboundedLeafPersistenceDiagnostic = true
}

type materializedWriteFrame struct {
	parent, next                        *materializedWriteFrame
	active, segmentNext, childResult    *materializedWriteFrame
	splitPending, written, splitSegment bool
	old                                 node.Node
	oldID                               uint64
	oldRef                              page.ChildRef
	input                               [page.PageSize]byte
	ops                                 []batch.Entry
	output                              [page.PageSize]byte
	scratch, key, nextKey               [page.PageSize]byte
	encoder                             node.Builder
	outputReserved                      bool
	selectLeaf                          leafMergeCursor
	event                               leafMergeEvent
	haveEvent                           bool
	decoder                             node.ProjectionDecoder
	comparison                          node.ProjectionComparison
	child, nextChild                    page.ChildRef
	childIndex                          uint16
	keySize, nextSize, startOp, opIndex int
	append                              freelist.AppendWork
	result                              page.ChildRef
	phase, decodePhase                  uint8
}

func NewMaterializedWriteWork(z *Zipper, owner *retainedalloc.Owner, ref page.ChildRef, ops []batch.Entry, w *iterator.OrdinalScanWork) (*MaterializedWriteWork, bool, error) {
	if z == nil || owner == nil || !ref.IsPage() {
		if w != nil {
			return nil, false, ErrMaterializedWriteContinuation
		}
		return nil, false, fmt.Errorf("%w: root ref=%+v", ErrMaterializedWriteContinuation, ref)
	}
	n := uint64(unsafe.Sizeof(MaterializedWriteWork{}))
	if w != nil {
		if ref.Page < 2 {
			return nil, false, ErrMaterializedWriteContinuation
		}
		frameBytes := uint64(unsafe.Sizeof(materializedWriteFrame{}))
		if ok, err := mergeReserve(w, 2, 2*n+2*frameBytes); !ok || err != nil {
			return nil, false, err
		}
		charge := retainedalloc.AllocationCharge(n) + retainedalloc.AllocationCharge(frameBytes)
		if ready, err := retainedalloc.AddPendingWithOrdinalWork(owner, charge, w); !ready || err != nil {
			return nil, false, err
		}
		// Both original containing objects are admitted together. No fallible
		// operation or hidden temporary-owner refund follows the aggregate Add.
		f := &materializedWriteFrame{oldID: ref.Page, oldRef: ref, ops: ops}
		s := &MaterializedWriteWork{z: z, owner: owner, charge: charge, head: f, root: f, current: f}
		return s, true, nil
	}
	if ok, e := mergeReserve(w, 1, 2*n); !ok || e != nil {
		return nil, false, e
	}
	charge := retainedalloc.AllocationCharge(n)
	if e := owner.AddPending(charge); e != nil {
		return nil, false, e
	}
	s := &MaterializedWriteWork{z: z, owner: owner, charge: charge}
	// Retain this admitted containing object on frame refusal so the caller can
	// retry creation without losing a charged receipt.
	f, ready, e := s.newFrame(nil, ref, ops, w)
	if e != nil || !ready {
		m, c := s.owner, s.charge
		s = nil
		m.RemovePending(c)
		return nil, false, e
	}
	s.root, s.current = f, f
	return s, true, nil
}

// appendWorkspaceForTarget binds the single original producer workspace through
// physical append, wrapper hooks and cache/result admission. Traversal is serial;
// another target cannot borrow it until the previous target is written.
func (s *MaterializedWriteWork) appendWorkspaceForTarget(target *materializedWriteFrame, w *iterator.OrdinalScanWork) (*valuelog.LeafAppendWork, bool, error) {
	if s.appendTarget == target {
		return &s.leafAppend, true, nil
	}
	if s.appendTarget != nil {
		return nil, false, ErrMaterializedWriteContinuation
	}
	if ok, e := mergeReserve(w, 1, uint64(2*unsafe.Sizeof(target))); !ok || e != nil {
		return nil, false, e
	}
	s.appendTarget = target
	return &s.leafAppend, true, nil
}
func (s *MaterializedWriteWork) newFrame(parent *materializedWriteFrame, ref page.ChildRef, ops []batch.Entry, w *iterator.OrdinalScanWork) (*materializedWriteFrame, bool, error) {
	if (!ref.IsPage() || ref.Page < 2) && !ref.IsLeafLog() {
		if w != nil {
			return nil, false, ErrMaterializedWriteContinuation
		}
		return nil, false, fmt.Errorf("%w: child ref=%+v", ErrMaterializedWriteContinuation, ref)
	}
	n := uint64(unsafe.Sizeof(materializedWriteFrame{}))
	if ok, e := mergeReserve(w, 1, 2*n); !ok || e != nil {
		return nil, false, e
	}
	charge := retainedalloc.AllocationCharge(n)
	if ready, e := retainedalloc.AddPendingWithOrdinalWork(s.owner, charge, w); !ready || e != nil {
		return nil, false, e
	}
	f := &materializedWriteFrame{parent: parent, next: s.head, oldID: ref.Page, oldRef: ref, ops: ops}
	s.head = f
	s.charge += charge
	return f, true, nil
}
func (s *MaterializedWriteWork) Step(a *freelist.Allocator, w *iterator.OrdinalScanWork) (bool, error) {
	if s == nil || s.owner == nil {
		return false, ErrMaterializedWriteContinuation
	}
	if s.phase == 1 {
		return true, nil
	}
	for s.current != nil {
		f := s.current
		switch f.phase {
		case 0:
			if f.oldRef.IsLeafLog() {
				if s.reader == nil {
					return false, ErrMaterializedWriteContinuation
				}
				ready, e := s.reader.BeginProjectionFrame(f.oldRef, f.input[:], w)
				if !ready || e != nil {
					return false, e
				}
				f.phase = 12
				continue
			}
			image, ready, e := s.z.pager.GetWithWork(f.oldID, w)
			if !ready || e != nil {
				return false, e
			}
			if ok, e := mergeReserve(w, 1, 2*page.PageSize); !ok || e != nil {
				return false, e
			}
			copy(f.input[:], image)
			f.phase = 13
		case 12:
			image, ready, e := s.reader.StepProjectionFrame(w)
			if !ready || e != nil {
				return false, e
			}
			if len(image) != page.PageSize || &image[0] != &f.input[0] {
				return false, ErrMaterializedWriteContinuation
			}
			f.phase = 13
		case 13:
			if ok, e := mergeReserve(w, 1, page.PageSize+256); !ok || e != nil {
				return false, e
			}
			if !page.VerifyChecksumNonMutating(f.input[:]) {
				return false, node.ErrPrimaryDirectory
			}
			f.old = node.NewNodeView(f.input[:])
			switch f.old.Type() {
			case page.PageTypeLeaf:
				// Preserve the original configured/adaptive format and enclosing revision
				// decision. Diagnostic codec selection/finalization is unbounded.
				revisions := f.old.LeafEntryRevisionsEnabled() || batchHasEntryRevisions(f.ops)
				ready, e := f.encoder.ResetWithOptionsWithWork(f.output[:], page.PageTypeLeaf, s.z.leafBuilderOptionsWithEntryRevisions(f.ops, revisions), w)
				if !ready || e != nil {
					return false, e
				}
				f.selectLeaf = newLeafMergeCursor(&f.old, f.ops, nil, f.scratch[:])
				f.active = f
				f.phase = 1
			case page.PageTypeInternal:
				f.encoder.ResetWithOptions(f.output[:], page.PageTypeInternal, node.BuilderOptions{InternalBaseDelta: s.z.indexInternalBaseDelta})
				f.phase = 2
			default:
				return false, fmt.Errorf("%w: page %d type %d", ErrMaterializedWriteContinuation, f.oldID, f.old.Type())
			}
		case 1:
			if !f.haveEvent {
				event, ready, e := f.selectLeaf.next(w)
				if !ready || e != nil {
					return false, e
				}
				f.event, f.haveEvent = event, true
			}
			if f.event.done {
				f.haveEvent = false
				f.phase = 8
				continue
			}
			if f.event.removes {
				if ok, e := mergeReserve(w, 1, 256); !ok || e != nil {
					return false, e
				}
				old := f.event.removed
				if old.Flags&node.FlagPointer != 0 && old.ValuePtr.FileID != 0 {
					id := old.ValuePtr.FileID
					if s.refs.Count(id) == 0 && int(s.refs.inlineN) == len(s.refs.inline) {
						return false, ErrMaterializedWriteContinuation
					}
					s.refs.add(id, 1)
				}
				s.removed++
				f.event.removes = false
			}
			if f.event.emit {
				r := f.event.entry
				var ready bool
				var e error
				if s.unboundedLeafPersistenceDiagnostic {
					// SAME ordinary sizing, soft split and configured encoder. Its
					// columnar scratch/copy work is intentionally not metered here.
					entrySize, prefixLen, suffixLen := leafEntrySizeWithRevision(&f.active.encoder, r.Key, r.Value, r.Flags, r.Revision)
					if s.z.leafSoftFull(&f.active.encoder, entrySize) {
						e = node.ErrNodeFull
					} else {
						e = f.active.encoder.AddLeafEntryWithPrefixRevision(r.Key, r.Value, r.Flags, r.ValuePtr, r.Revision, entrySize, prefixLen, suffixLen)
					}
					ready = e == nil
				} else {
					ready, e = f.active.encoder.AddLeafEntryWithRevisionWithWorkAndReserve(r.Key, r.Value, r.Flags, r.ValuePtr, r.Revision, s.z.leafReserveBytes, w)
				}
				if e == node.ErrNodeFull {
					if f.active.encoder.Count() == 0 {
						return false, e
					}
					f.splitPending = true
					f.phase = 8
					continue
				}
				if !ready || e != nil {
					return false, e
				}
			}
			f.event = leafMergeEvent{}
			f.haveEvent = false
		case 2:
			if f.childIndex >= f.old.Count() {
				f.phase = 8
				continue
			}
			// Decode current/next separator with the SAME phased layout decoder. The
			// child's low key must remain alive while a recursive child is constructed.
			ready, e := f.decoder.Begin(f.old, f.childIndex, f.scratch[:], w)
			if !ready || e != nil {
				return false, e
			}
			f.phase = 3
		case 3:
			ready, e := f.decoder.Step(w)
			if !ready || e != nil {
				return false, e
			}
			r, ref := f.decoder.Result()
			if len(r.Key) > len(f.key) {
				return false, ErrMaterializedWriteContinuation
			}
			if ok, e := mergeReserve(w, 1, uint64(len(r.Key))+64); !ok || e != nil {
				return false, e
			}
			f.keySize = copy(f.key[:], r.Key)
			f.child = ref
			f.startOp = f.opIndex
			if f.childIndex+1 == f.old.Count() {
				f.opIndex = len(f.ops)
				f.phase = 6
				continue
			}
			f.phase = 4
		case 4:
			ready, e := f.decoder.Begin(f.old, f.childIndex+1, f.scratch[:], w)
			if !ready || e != nil {
				return false, e
			}
			f.phase = 5
		case 5:
			if f.decodePhase == 0 {
				ready, e := f.decoder.Step(w)
				if !ready || e != nil {
					return false, e
				}
				r, ref := f.decoder.Result()
				if len(r.Key) > len(f.nextKey) {
					return false, ErrMaterializedWriteContinuation
				}
				if ok, e := mergeReserve(w, 1, uint64(len(r.Key))+64); !ok || e != nil {
					return false, e
				}
				f.nextSize = copy(f.nextKey[:], r.Key)
				f.nextChild = ref
				f.decodePhase = 1
			}
			for f.opIndex < len(f.ops) {
				if f.decodePhase == 1 {
					if !f.comparison.Begin(f.ops[f.opIndex].Key, f.nextKey[:f.nextSize], w) {
						return false, nil
					}
					f.decodePhase = 2
				}
				cmp, ready := f.comparison.Step(w)
				if !ready {
					return false, nil
				}
				f.decodePhase = 1
				if cmp >= 0 {
					break
				}
				f.opIndex++
			}
			f.decodePhase = 0
			f.phase = 6
		case 6:
			if f.startOp == f.opIndex {
				f.result = f.child
				f.childResult = nil
				f.phase = 7
				continue
			}
			child, ready, e := s.newFrame(f, f.child, f.ops[f.startOp:f.opIndex], w)
			if !ready || e != nil {
				return false, e
			}
			f.phase = 10
			s.current = child
		case 7:
			key := f.key[:f.keySize]
			result := f.result
			segment := f.childResult
			if segment != nil {
				result = segment.result
			}
			if segment != nil && segment.splitSegment {
				key = segment.key[:segment.keySize]
			} else {
				if f.startOp < f.opIndex && (len(key) == 0 || bytes.Compare(f.ops[f.startOp].Key, key) < 0) {
					key = f.ops[f.startOp].Key
				}
				if f.childIndex == 0 {
					key = nil
				}
			}
			ready, e := f.encoder.AddInternalChildRefWithWork(key, result, w)
			if !ready || e != nil {
				return false, e
			}
			if segment != nil && segment.segmentNext != nil {
				f.childResult = segment.segmentNext
				continue
			}
			f.result = page.ChildRef{}
			f.childResult = nil
			f.childIndex++
			f.phase = 2
		case 8:
			target := f
			if f.old.Type() == page.PageTypeLeaf {
				target = f.active
			}
			if f.old.Type() == page.PageTypeLeaf && s.z.outerLeavesInValueLog {
				if !s.unboundedLeafPersistenceDiagnostic {
					producer, ok := s.z.leafPageLog.(interface {
						AppendLeafPageWithWork([]byte, *valuelog.LeafAppendWork, *iterator.OrdinalScanWork) (page.LeafLogPtr, bool, error)
					})
					if !ok {
						return false, ErrMaterializedWriteContinuation
					}
					appendWork, ready, e := s.appendWorkspaceForTarget(target, w)
					if !ready || e != nil {
						return false, e
					}
					if appendWork.Phase == 0 {
						target.encoder.SetPageID(0)
						ready, e := target.encoder.FinishNoNodeWithWork(w)
						if !ready || e != nil {
							return false, e
						}
					}
					if !target.outputReserved {
						if ok, e := mergeReserve(w, 1, 8); !ok || e != nil {
							return false, e
						}
						if e := s.z.outputPageLimit.reserve(1); e != nil {
							return false, e
						}
						target.outputReserved = true
					}
					ptr, ready, e := producer.AppendLeafPageWithWork(target.output[:], appendWork, w)
					if !ready || e != nil {
						return false, e
					}
					if ok, e := mergeReserve(w, 2, uint64(2*page.PageSize+64)); !ok || e != nil {
						return false, e
					}
					s.z.cachePersistedLeafPage(ptr, target.output[:], leafPageCacheClone)
					target.result = page.LeafLogChildRef(ptr)
					f.phase = 9
					continue
				}
				target.encoder.SetPageID(0)
				ready, e := target.encoder.FinishNoNodeWithWork(nil)
				if !ready || e != nil {
					return false, e
				}
				var metrics adaptive.Metrics
				ref, e := s.z.persistLeafPageData(target.output[:], &metrics)
				if e != nil {
					return false, e
				}
				target.result = ref
				f.phase = 9
				continue
			}
			id, ready, e := target.append.Step(a, w)
			if !ready || e != nil {
				return false, e
			}
			if ok, e := mergeReserve(w, 1, 8); !ok || e != nil {
				return false, e
			}
			target.encoder.SetPageID(id)
			if f.old.Type() == page.PageTypeLeaf {
				codecWork := w
				if s.unboundedLeafPersistenceDiagnostic {
					codecWork = nil
				}
				ready, e = target.encoder.FinishNoNodeWithWork(codecWork)
			} else {
				ready, e = target.encoder.FinishInternalWithWork(w)
			}
			if !ready || e != nil {
				return false, e
			}
			target.result = page.PageChildRef(id)
			f.phase = 9
		case 9:
			target := f
			if f.old.Type() == page.PageTypeLeaf {
				target = f.active
			}
			if target.result.IsPage() {
				ready, e := s.z.pager.WriteWithWork(target.result.Page, target.output[:], w)
				if !ready || e != nil {
					return false, e
				}
			}
			target.written = true
			if s.appendTarget != nil {
				if s.appendTarget != target {
					return false, ErrMaterializedWriteContinuation
				}
				ready, e := s.leafAppend.ResetCompletedWithWork(w)
				if !ready || e != nil {
					return false, e
				}
				s.appendTarget = nil
			}
			if f.splitPending {
				f.phase = 14
				continue
			}
			if ok, e := mergeReserve(w, 1, page.PageSize+128); !ok || e != nil {
				return false, e
			}
			if f.parent == nil {
				if f.segmentNext != nil {
					return false, ErrMaterializedWriteContinuation
				}
				if f.result.IsLeafLog() {
					// The maintained ensureRootPage policy wraps a sole outer leaf
					// in one DATA internal page. Keep the completed leaf immutable
					// while the SAME original encoder/append stages install it.
					f.phase = 16
					continue
				}
				s.result = node.PrimaryOperand{Ref: f.result, Digest: sha256.Sum256(f.output[:])}
				s.current = nil
				s.phase = 1
				return true, nil
			}
			parent := f.parent
			parent.result = f.result
			parent.childResult = f
			parent.phase = 7
			s.current = parent
			f.phase = 11
		case 16:
			if f.childResult == nil {
				// newFrame performs the containing admission; its temporary
				// source ref is cleared before this fresh wrapper can be visited.
				wrapper, ready, err := s.newFrame(nil, f.oldRef, nil, w)
				if !ready || err != nil {
					return false, err
				}
				wrapper.oldID, wrapper.oldRef = 0, page.ChildRef{}
				f.childResult = wrapper
			}
			wrapper := f.childResult
			if wrapper.phase == 0 {
				ready, err := wrapper.encoder.ResetWithOptionsWithWork(wrapper.output[:], page.PageTypeInternal, node.BuilderOptions{InternalBaseDelta: s.z.indexInternalBaseDelta}, w)
				if !ready || err != nil {
					return false, err
				}
				wrapper.encoder.SetInternalFenceBoundsBorrowed([]byte{}, nil)
				wrapper.phase = 17 // private wrapper encoder initialized
			}
			ready, err := wrapper.encoder.AddInternalChildRefWithWork([]byte{}, f.result, w)
			if !ready || err != nil {
				return false, err
			}
			wrapper.old = node.NewNodeView(wrapper.output[:])
			wrapper.phase = 8
			s.current = wrapper
		case 14:
			// The original mergeLeaf persists a full target before creating its
			// right sibling. Keep that same separator and pending event alive.
			n := uint64(unsafe.Sizeof(materializedWriteFrame{}))
			if ok, e := mergeReserve(w, 1, 2*n+uint64(len(f.event.entry.Key))); !ok || e != nil {
				return false, e
			}
			charge := retainedalloc.AllocationCharge(n)
			if ready, e := retainedalloc.AddPendingWithOrdinalWork(s.owner, charge, w); !ready || e != nil {
				return false, e
			}
			next := &materializedWriteFrame{parent: f.parent, next: s.head, splitSegment: true}
			s.head = next
			s.charge += charge
			next.keySize = copy(next.key[:], f.event.entry.Key)
			start := f.selectLeaf.opIndex
			if f.event.fromBatch && start > 0 {
				start--
			}
			_ = start // options are bound by the same immutable operation suffix below.
			f.active.segmentNext = next
			f.phase = 15
		case 15:
			next := f.active.segmentNext
			start := f.selectLeaf.opIndex
			if f.event.fromBatch && start > 0 {
				start--
			}
			ready, e := next.encoder.ResetWithOptionsWithWork(next.output[:], page.PageTypeLeaf, s.z.leafBuilderOptionsWithEntryRevisions(f.ops[start:], f.active.encoder.LeafEntryRevisionsEnabled()), w)
			if !ready || e != nil {
				return false, e
			}
			f.active = next
			f.splitPending = false
			f.phase = 1
		default:
			return false, ErrMaterializedWriteContinuation
		}
	}
	return s.phase == 1, nil
}
func (s *MaterializedWriteWork) Result() (node.PrimaryOperand, *PointerRefCounts, uint64, bool) {
	if s == nil || s.phase != 1 {
		return node.PrimaryOperand{}, nil, 0, false
	}
	return s.result, &s.refs, s.removed, true
}

// VisitPages borrows original installed/retired IDs after complete construction.
// The accepting original BuildGroup records them before this receipt is detached.
func (s *MaterializedWriteWork) VisitPages(visit func(allocated, retired uint64)) {
	for f := s.head; f != nil; f = f.next {
		visit(f.result.Page, f.oldID)
	}
}

// MaterializedPageVisitWorkV6 observes the original completed output without
// transferring any installed-page rollback edge. Its original producer embeds
// this control and retains the output until observation and adoption complete.
type MaterializedPageVisitWorkV6 struct {
	self   *MaterializedPageVisitWorkV6
	output *MaterializedWriteWork
	next   *materializedWriteFrame
}

func (s *MaterializedWriteWork) VisitPagesWithWorkV6(cursor *MaterializedPageVisitWorkV6, visit func(uint64, uint64, *iterator.OrdinalScanWork) (bool, error), w *iterator.OrdinalScanWork) (bool, error) {
	if s == nil || s.phase != 1 || cursor == nil || visit == nil || w == nil {
		return false, ErrMaterializedWriteContinuation
	}
	if cursor.self == nil {
		if !w.Reserve(1, uint64(unsafe.Sizeof(*cursor))) {
			return false, nil
		}
		cursor.self, cursor.output, cursor.next = cursor, s, s.head
	} else if cursor.self != cursor || cursor.output != s {
		return false, ErrMaterializedWriteContinuation
	}
	for cursor.next != nil {
		f := cursor.next
		if !w.Reserve(1, 3*8) {
			return false, nil
		}
		ready, err := visit(f.result.Page, f.oldID, w)
		if !ready || err != nil {
			return false, err
		}
		cursor.next = f.next
	}
	return true, nil
}

// AdoptPagesWithWorkV6 moves one original page pair at a time into the
// accepting BuildGroup. A callback returning ready has taken custody; it must
// retain that custody on every later refusal/error. No page pair is replayed.
func (s *MaterializedWriteWork) AdoptPagesWithWorkV6(visit func(uint64, uint64, *iterator.OrdinalScanWork) (bool, error), w *iterator.OrdinalScanWork) (bool, error) {
	if s == nil || s.phase != 1 || visit == nil {
		return false, ErrMaterializedWriteContinuation
	}
	if !s.adoptionBegun {
		s.adoptNext = s.head
		s.adoptionBegun = true
	}
	for s.adoptNext != nil {
		f := s.adoptNext
		if ok, e := mergeReserve(w, 1, uint64(unsafe.Sizeof(f.append))+32); !ok || e != nil {
			return false, e
		}
		ready, e := visit(f.result.Page, f.oldID, w)
		if !ready || e != nil {
			return false, e
		}
		// The BuildGroup owns this installed page, including rollback. Detach the
		// producer's disposing alias before exposing a later public yield.
		f.append = freelist.AppendWork{}
		s.adoptNext = f.next
	}
	return true, nil
}

// ValidateCOWInstalledPagesV6 is the read-only half of the original allocator
// handoff. A refusal leaves EVERY AppendWork disposing edge intact. The same
// call's allocator/ledger cut protects the operands until the admitted transfer.
func (s *MaterializedWriteWork) ValidateCOWInstalledPagesV6(preparation *freelist.COWPreparationWorkV6, w *iterator.OrdinalScanWork) (bool, error) {
	if s == nil || preparation == nil || w == nil {
		return false, ErrMaterializedWriteContinuation
	}
	if ok, err := mergeReserve(w, 1, 2*uint64(unsafe.Sizeof(*s))); !ok || err != nil {
		return false, err
	}
	if s.phase != 1 || s.adoptionBegun || s.appendTarget != nil || s.unboundedLeafPersistenceDiagnostic {
		return false, ErrMaterializedWriteContinuation
	}
	for f := s.head; f != nil; f = f.next {
		// Includes the final nonfallible frame traversal and AppendWork clear.
		if ok, err := mergeReserve(w, 2, 4*uint64(unsafe.Sizeof(f.append))+2*uint64(unsafe.Sizeof(f.result))+32); !ok || err != nil {
			return false, err
		}
		if !f.written || !f.result.IsPage() {
			return false, ErrMaterializedWriteContinuation
		}
		ready, err := preparation.ValidateInstalledPageV6(&f.append, f.result.Page, f.oldID, w)
		if !ready || err != nil {
			return false, err
		}
	}
	return true, nil
}

// AdoptCOWInstalledPagesV6 runs only after the preceding validation completed
// under the original allocator/ledger locks and exact candidate adoption. It
// drops rollback aliases before installActivatedCandidateV6 clears rollbackTxn.
func (s *MaterializedWriteWork) AdoptCOWInstalledPagesV6(_ *freelist.COWPreparationWorkV6) {
	for f := s.head; f != nil; f = f.next {
		f.append = freelist.AppendWork{}
	}
	s.adoptionBegun, s.adoptNext = true, nil
}

// CompleteWithWorkV6 detaches finite frame metadata only after every installed
// page belongs to an accepting owner (or Cancel has retired it). Its caller
// clears the final receipt alias before refunding the returned exact charge.
func (s *MaterializedWriteWork) CompleteWithWorkV6(w *iterator.OrdinalScanWork) (*retainedalloc.Owner, uint64, bool, error) {
	if s == nil {
		return nil, 0, true, nil
	}
	if w != nil && s.head != nil && (!s.adoptionBegun || s.adoptNext != nil) {
		return nil, 0, false, ErrMaterializedWriteContinuation
	}
	for s.head != nil {
		f := s.head
		if ok, e := mergeReserve(w, 1, uint64(unsafe.Sizeof(*f))); !ok || e != nil {
			return nil, 0, false, e
		}
		s.head = f.next
		*f = materializedWriteFrame{}
	}
	if ok, e := mergeReserve(w, 1, uint64(unsafe.Sizeof(*s))); !ok || e != nil {
		return nil, 0, false, e
	}
	m, c := s.owner, s.charge
	*s = MaterializedWriteWork{}
	return m, c, true, nil
}

func (s *MaterializedWriteWork) Complete() (*retainedalloc.Owner, uint64) {
	m, c, _, _ := s.CompleteWithWorkV6(nil)
	return m, c
}
func (s *MaterializedWriteWork) Cancel(w *iterator.OrdinalScanWork) (bool, error) {
	if s.appendTarget != nil {
		ready, e := s.leafAppend.AbandonWithWorkV6(w)
		if !ready || e != nil {
			return false, e
		}
		s.appendTarget = nil
	}
	for s.head != nil {
		f := s.head
		ready, e := f.append.Cancel(w)
		if !ready || e != nil {
			return false, e
		}
		if ok, e := mergeReserve(w, 1, uint64(unsafe.Sizeof(*f))); !ok || e != nil {
			return false, e
		}
		s.head = f.next
		*f = materializedWriteFrame{}
	}
	return true, nil
}

// MaterializedInputV6 is fixed containing metadata for the original PRIMARY
// components moved into DATA. It is part of the admitted native constructor.
// Prefix collection/normalization remains explicitly synchronous diagnostic work.
type MaterializedInputV6 struct {
	Base         node.PrimaryOperand
	Sequence     uint64
	Removed      uint64
	Refs         PointerRefCounts
	Retired      [node.PrimaryDirectoryMaxEntries]uint64
	RetiredCount int
}

func (z *Zipper) PrepareMaterializedInputV6(root uint64, prefix *batch.Batch) (result *batch.Batch, state MaterializedInputV6, err error) {
	image, err := z.pager.Get(root)
	if err != nil {
		return nil, state, err
	}
	state.Base = node.PrimaryOperand{Ref: page.PageChildRef(root), Digest: sha256.Sum256(image)}
	result = batch.New(nil, int(^uint(0)>>1))
	defer func() {
		if err != nil {
			result.Close()
			result = nil
		}
	}()
	points, ranges := prefix.ApplyPlan()
	if len(ranges) != 0 {
		return result, state, ErrMaterializedWriteContinuation
	}
	n := node.NewNodeView(image)
	if n.Type() == page.PageTypePrimaryDirectory {
		d, e := node.DecodePrimaryDirectory(image)
		if e != nil {
			return result, state, e
		}
		state.Base, state.Sequence = d.Base()
		scratch := z.acquireApplyScratch()
		defer z.releaseApplyScratch(scratch)
		var metrics adaptive.Metrics
		if _, e = z.loadPrimaryOperand(state.Base, nil, &metrics, scratch); e != nil {
			return result, state, e
		}
		for i := 0; i < d.Count(); i++ {
			entry, e := d.Entry(i)
			if e != nil {
				return result, state, e
			}
			op := batch.Entry{Type: batch.OpDelete, Key: bytes.Clone(entry.Key), Revision: entry.Revision}
			if !entry.InlineAbsence() {
				leaf, e := z.loadPrimaryOperand(entry.Operand, &entry, &metrics, scratch)
				if e != nil {
					return result, state, e
				}
				k, v, ptr, flags, rev, e := leaf.GetLeafEntryViewWithRevision(0)
				if e != nil {
					return result, state, e
				}
				op = batch.Entry{Type: batch.OpPut, Key: bytes.Clone(k), Value: bytes.Clone(v), ValuePtr: ptr, IsPtr: flags&node.FlagPointer != 0, Revision: rev}
				if flags&node.FlagTombstone != 0 {
					op.Type = batch.OpDelete
					op.Value = nil
				}
				// The original two-pass materializer removes the component if a later
				// prefix op wins. Preserve that physical reference delta in the fused pass.
				for j := range points {
					if bytes.Equal(points[j].Key, k) {
						if flags&node.FlagPointer != 0 && ptr.FileID != 0 {
							if state.Refs.Count(ptr.FileID) == 0 && int(state.Refs.inlineN) == len(state.Refs.inline) {
								return result, state, ErrMaterializedWriteContinuation
							}
							state.Refs.add(ptr.FileID, 1)
						}
						state.Removed++
						break
					}
				}
				if entry.Operand.Ref.IsPage() && !primaryarena.IsPage(entry.Operand.Ref.Page) {
					state.Retired[state.RetiredCount] = entry.Operand.Ref.Page
					state.RetiredCount++
				}
			}
			if e = result.SetOps([]batch.Entry{op}); e != nil {
				return result, state, e
			}
		}
	}
	if err = result.SetOps(points); err != nil {
		return result, state, err
	}
	result.ApplyPlan()
	return result, state, nil
}
func (s *MaterializedWriteWork) BindMaterializedInputAccountingV6(input *MaterializedInputV6) {
	s.refs = input.Refs
	s.removed = input.Removed
}
