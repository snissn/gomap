package freelist

import (
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
)

// privateUint64SetV6 belongs to the containing original preparation/planner.
// No array view escapes it. A suspended mutation excludes other mutations and
// enumeration; its key, version and probe indices identify the original work.
// Zero is represented independently, so every uint64 (including MaxUint64) is
// usable. Nonzero occupancy never exceeds half the power-of-two capacity.
type privateUint64SetV6 struct {
	owner                              *retainedalloc.Owner
	slots, next, snapshot              []uint64
	charge, nextCharge, snapshotCharge uint64
	debtOwner                          *retainedalloc.Owner
	debt                               uint64
	removal                            retainedalloc.RemovalWork
	count, version                     uint64
	zero                               bool
	key, opVersion                     uint64
	index, probes, source              int
	rehashKey                          uint64
	phase                              uint8
	snapshotIndex                      int
	snapshotBound, snapshotLoaded      bool
	snapshotKey                        uint64
	cloneSource                        *privateUint64SetV6
	cloneVersion                       uint64
	cloneIndex                         int
	cloneZero, cloneLoaded             bool
	cloneKey                           uint64
}

// A fixed full-width avalanche; expected distribution is not a worst-case
// collision bound. Every hash and every actual probe is separately admitted.
func privateHashV6(k uint64) uint64 {
	k ^= k >> 30
	k *= 0xbf58476d1ce4e5b9
	k ^= k >> 27
	k *= 0x94d049bb133111eb
	return k ^ (k >> 31)
}
func privateArrayChargeV6(n int) (raw, charge uint64, err error) { return privateObjectChargeV6(n, 8) }
func privateObjectChargeV6(n int, width uint64) (raw, charge uint64, err error) {
	if n < 0 || width == 0 || uint64(n) > ^uint64(0)/width {
		return 0, 0, ErrGenerationFormat
	}
	raw = uint64(n) * width
	charge = retainedalloc.AllocationCharge(raw)
	if charge < raw {
		return 0, 0, ErrGenerationFormat
	}
	return raw, charge, nil
}
func (s *privateUint64SetV6) length() int {
	n := int(s.count)
	if s.zero {
		n++
	}
	return n
}
func (s *privateUint64SetV6) valid() bool {
	n := len(s.slots)
	return s.owner != nil && (n == 0 || n >= 16 && n&(n-1) == 0) && s.count <= uint64(n/2)
}
func (s *privateUint64SetV6) finishDebt(w *iterator.OrdinalScanWork) (bool, error) {
	if s.debt == 0 && s.debtOwner == nil {
		return true, nil
	}
	return s.removal.CompletePendingWork(&s.debtOwner, &s.debt, w)
}

// insert returns whether this exact operation inserted a new key. Returning
// false ready retains the SAME mutation, including a committed insert whose
// old backing has detached but whose original accounting removal is unfinished.
func (s *privateUint64SetV6) insert(key uint64, w *iterator.OrdinalScanWork) (inserted, ready bool, err error) {
	if w == nil || s == nil || s.owner == nil {
		return false, false, retainedalloc.ErrWorkRequired
	}
	if ok, e := appendReserve(w, 1, 2*uint64(unsafe.Sizeof(*s))); !ok || e != nil {
		return false, false, e
	}
	if s.phase != 0 && (s.key != key || s.opVersion != s.version) {
		return false, false, ErrGenerationFormat
	}
	for {
		switch s.phase {
		case 0:
			if ok, e := appendReserve(w, 1, 2*uint64(unsafe.Sizeof(*s))); !ok || e != nil {
				return false, false, e
			}
			if !s.valid() || s.next != nil || s.debt != 0 {
				return false, false, ErrGenerationFormat
			}
			if key == 0 {
				added := !s.zero
				s.zero = true
				if added {
					s.version++
				}
				return added, true, nil
			}
			s.key, s.opVersion, s.phase = key, s.version, 1
		case 1:
			if ok, e := appendReserve(w, 1, 64); !ok || e != nil {
				return false, false, e
			}
			s.index, s.probes = 0, 0
			if len(s.slots) > 0 {
				s.index = int(privateHashV6(key) & uint64(len(s.slots)-1))
			}
			s.phase = 2
		case 2:
			if len(s.slots) == 0 {
				s.phase = 3
				continue
			}
			if s.probes >= len(s.slots) {
				return false, false, ErrGenerationFormat
			}
			if ok, e := appendReserve(w, 1, 32); !ok || e != nil {
				return false, false, e
			}
			cell := s.slots[s.index]
			s.probes++
			if cell == key {
				s.phase = 0
				return false, true, nil
			}
			if cell == 0 {
				if s.count+1 > uint64(len(s.slots)/2) {
					s.phase = 3
				} else {
					s.phase = 7
				}
				continue
			}
			s.index = (s.index + 1) & (len(s.slots) - 1)
		case 3:
			capacity := 16
			if len(s.slots) > 0 {
				if len(s.slots) > int(^uint(0)>>1)/2 {
					return false, false, ErrGenerationFormat
				}
				capacity = 2 * len(s.slots)
			}
			raw, charge, e := privateArrayChargeV6(capacity)
			if e != nil {
				return false, false, e
			}
			if ok, e := appendReserve(w, 1, raw+2*uint64(unsafe.Sizeof(*s))); !ok || e != nil {
				return false, false, e
			}
			ok, e := retainedalloc.AddPendingWithOrdinalWork(s.owner, charge, w)
			if !ok || e != nil {
				return false, false, e
			}
			// No fallible action or return between admission and this allocation.
			s.next = make([]uint64, capacity)
			s.nextCharge = charge
			s.source = 0
			s.phase = 4
		case 4:
			if s.source == len(s.slots) {
				s.phase = 8
				continue
			}
			if ok, e := appendReserve(w, 1, 32); !ok || e != nil {
				return false, false, e
			}
			s.rehashKey = s.slots[s.source]
			s.source++
			if s.rehashKey != 0 {
				s.phase = 5
			}
		case 5:
			if ok, e := appendReserve(w, 1, 64); !ok || e != nil {
				return false, false, e
			}
			s.index = int(privateHashV6(s.rehashKey) & uint64(len(s.next)-1))
			s.probes = 0
			s.phase = 6
		case 6:
			if s.probes >= len(s.next) {
				return false, false, ErrGenerationFormat
			}
			if ok, e := appendReserve(w, 1, 40); !ok || e != nil {
				return false, false, e
			}
			s.probes++
			if s.next[s.index] == 0 {
				s.next[s.index] = s.rehashKey
				s.rehashKey = 0
				s.phase = 4
			} else {
				s.index = (s.index + 1) & (len(s.next) - 1)
			}
		case 7:
			if ok, e := appendReserve(w, 2, 64); !ok || e != nil {
				return false, false, e
			}
			s.slots[s.index] = key
			s.count++
			s.version++
			s.opVersion = s.version
			s.phase = 11
		case 8:
			if ok, e := appendReserve(w, 1, 64); !ok || e != nil {
				return false, false, e
			}
			s.index = int(privateHashV6(key) & uint64(len(s.next)-1))
			s.probes = 0
			s.phase = 9
		case 9:
			if s.probes >= len(s.next) {
				return false, false, ErrGenerationFormat
			}
			if ok, e := appendReserve(w, 1, 32); !ok || e != nil {
				return false, false, e
			}
			s.probes++
			if s.next[s.index] == 0 {
				s.phase = 10
			} else {
				s.index = (s.index + 1) & (len(s.next) - 1)
			}
		case 10:
			if ok, e := appendReserve(w, 2, 2*uint64(unsafe.Sizeof(*s))+8); !ok || e != nil {
				return false, false, e
			}
			s.next[s.index] = key
			// No iterator/cell/source slice aliases survive this swap. Debt is scalar.
			s.debt, s.debtOwner = s.charge, s.owner
			if s.debt == 0 {
				s.debtOwner = nil
			}
			s.slots, s.charge = s.next, s.nextCharge
			s.next, s.nextCharge = nil, 0
			s.source, s.rehashKey = 0, 0
			s.count++
			s.version++
			s.opVersion = s.version
			s.phase = 11
		case 11:
			ok, e := s.finishDebt(w)
			if !ok || e != nil {
				return false, false, e
			}
			s.phase = 12
		case 12:
			if ok, e := appendReserve(w, 1, 2*uint64(unsafe.Sizeof(*s))); !ok || e != nil {
				return false, false, e
			}
			s.key, s.opVersion, s.index, s.probes, s.phase = 0, 0, 0, 0, 0
			return true, true, nil
		default:
			return false, false, ErrGenerationFormat
		}
	}
}

// captureMap is invoked only under the original allocator lock. It performs
// exactly one whole immutable ID-vector snapshot. It never retains a Go map
// iterator, and hash construction runs only after the allocator lock is gone.
func (s *privateUint64SetV6) captureMap(m map[uint64]struct{}, w *iterator.OrdinalScanWork) (bool, error) {
	if w == nil || s.owner == nil {
		return false, retainedalloc.ErrWorkRequired
	}
	if s.snapshotBound {
		return true, nil
	}
	raw, charge, e := privateArrayChargeV6(len(m))
	if e != nil {
		return false, e
	}
	n := uint64(len(m))
	header := 2 * uint64(unsafe.Sizeof(*s))
	if n > (^uint64(0)-header)/32 {
		return false, ErrGenerationFormat
	}
	if ok, e := appendReserve(w, 1+n, header+32*n); !ok || e != nil {
		return false, e
	}
	if n != 0 {
		ok, e := retainedalloc.AddPendingWithOrdinalWork(s.owner, charge, w)
		if !ok || e != nil {
			return false, e
		}
		s.snapshot = make([]uint64, len(m))
		s.snapshotCharge = charge
		i := 0
		for key := range m {
			s.snapshot[i] = key
			i++
		}
	}
	_ = raw // allocation+zeroing+source visits/copy are included in 32*n above.
	s.snapshotBound = true
	return true, nil
}
func (s *privateUint64SetV6) buildSnapshot(w *iterator.OrdinalScanWork) (bool, error) {
	if w == nil {
		return false, retainedalloc.ErrWorkRequired
	}
	if ok, e := appendReserve(w, 1, 2*uint64(unsafe.Sizeof(*s))); !ok || e != nil {
		return false, e
	}
	if !s.snapshotBound {
		return false, ErrGenerationFormat
	}
	for s.snapshotIndex < len(s.snapshot) {
		if !s.snapshotLoaded {
			if ok, e := appendReserve(w, 1, 32); !ok || e != nil {
				return false, e
			}
			s.snapshotKey = s.snapshot[s.snapshotIndex]
			s.snapshotLoaded = true
		}
		_, ok, e := s.insert(s.snapshotKey, w)
		if !ok || e != nil {
			return false, e
		}
		s.snapshotIndex++
		s.snapshotLoaded = false
	}
	if s.snapshot != nil {
		if ok, e := appendReserve(w, 1, 2*uint64(unsafe.Sizeof(*s))); !ok || e != nil {
			return false, e
		}
		s.debt, s.debtOwner = s.snapshotCharge, s.owner
		s.snapshot, s.snapshotCharge = nil, 0
		s.snapshotKey = 0
	}
	return s.finishDebt(w)
}

// cloneFrom incrementally constructs independent planning replacement storage.
// Its source is private/frozen; no canonical map or output gains this backing.
func (s *privateUint64SetV6) cloneFrom(source *privateUint64SetV6, w *iterator.OrdinalScanWork) (bool, error) {
	if w == nil || source == nil || source == s {
		return false, ErrGenerationFormat
	}
	if ok, e := appendReserve(w, 1, 2*uint64(unsafe.Sizeof(*s))); !ok || e != nil {
		return false, e
	}
	if s.cloneSource == nil {
		if ok, e := appendReserve(w, 1, 2*uint64(unsafe.Sizeof(*s))); !ok || e != nil {
			return false, e
		}
		if !source.valid() || source.phase != 0 || s.length() != 0 {
			return false, ErrGenerationFormat
		}
		s.cloneSource, s.cloneVersion = source, source.version
	}
	if s.cloneSource != source || s.cloneVersion != source.version || source.phase != 0 {
		return false, ErrGenerationFormat
	}
	for {
		if !s.cloneZero {
			if ok, e := appendReserve(w, 1, 32); !ok || e != nil {
				return false, e
			}
			s.zero = source.zero
			s.cloneZero = true
			if s.zero {
				s.version++
			}
		}
		if !s.cloneLoaded {
			if s.cloneIndex == len(source.slots) {
				if ok, e := appendReserve(w, 1, 2*uint64(unsafe.Sizeof(*s))); !ok || e != nil {
					return false, e
				}
				s.cloneSource = nil
				return true, nil
			}
			if ok, e := appendReserve(w, 1, 32); !ok || e != nil {
				return false, e
			}
			s.cloneKey = source.slots[s.cloneIndex]
			s.cloneIndex++
			if s.cloneKey == 0 {
				continue
			}
			s.cloneLoaded = true
		}
		_, ok, e := s.insert(s.cloneKey, w)
		if !ok || e != nil {
			return false, e
		}
		s.cloneLoaded = false
	}
}

// close detaches every private physical alias before the original typed refund.
// It never copies/resets an active RemovalWork. Whole containing resets occur
// only after all these receipts have genuinely completed and been checked reset.
func (s *privateUint64SetV6) close(w *iterator.OrdinalScanWork) (bool, error) {
	if w == nil {
		return false, retainedalloc.ErrWorkRequired
	}
	if ok, e := appendReserve(w, 1, 2*uint64(unsafe.Sizeof(*s))); !ok || e != nil {
		return false, e
	}
	if ok, e := s.finishDebt(w); !ok || e != nil {
		return false, e
	}
	if s.slots != nil || s.next != nil || s.snapshot != nil || s.cloneSource != nil || s.cloneZero || s.cloneLoaded || s.cloneIndex != 0 || s.phase != 0 || s.snapshotBound || s.zero || s.count != 0 {
		if ok, e := appendReserve(w, 1, 2*uint64(unsafe.Sizeof(*s))); !ok || e != nil {
			return false, e
		}
		debt := s.charge
		for _, charge := range [2]uint64{s.nextCharge, s.snapshotCharge} {
			if charge > ^uint64(0)-debt {
				return false, ErrGenerationFormat
			}
			debt += charge
		}
		s.slots, s.next, s.snapshot = nil, nil, nil
		s.charge, s.nextCharge, s.snapshotCharge = 0, 0, 0
		s.cloneSource = nil
		s.cloneVersion, s.cloneIndex, s.cloneKey = 0, 0, 0
		s.cloneZero, s.cloneLoaded = false, false
		s.key, s.opVersion, s.rehashKey = 0, 0, 0
		s.index, s.probes, s.source, s.snapshotIndex = 0, 0, 0, 0
		s.phase = 0
		s.snapshotBound, s.snapshotLoaded = false, false
		s.snapshotKey = 0
		s.zero = false
		s.count = 0
		s.version++
		s.debt, s.debtOwner = debt, s.owner
		if debt == 0 {
			s.debtOwner = nil
		}
	}
	return s.finishDebt(w)
}

// Explicit borrowed view; ordinary and canonical-successor maps retain their
// existing stronger valid() and admission semantics. It never owns backing.
type privateTxnViewV6 struct {
	txn               *FreelistTxn
	changed, replaced *privateUint64SetV6
}

func (v *privateTxnViewV6) valid(t *FreelistTxn) bool {
	return v != nil && v.txn == t && t != nil && t.base != nil && t.root != nil && !t.consumed && t.changedChunks == nil && t.replacedMetadata == nil && v.changed != nil && v.replaced != nil && v.changed.valid() && v.replaced.valid()
}
func privateChangedV6(v *privateTxnViewV6) *privateUint64SetV6 {
	if v == nil {
		return nil
	}
	return v.changed
}
func privateReplacedV6(v *privateTxnViewV6) *privateUint64SetV6 {
	if v == nil {
		return nil
	}
	return v.replaced
}
func privateCountV6(m map[uint64]struct{}, s *privateUint64SetV6) int {
	if s != nil {
		return s.length()
	}
	return len(m)
}
func (s *stateMapInsertWorkV1) stepPrivate(m *map[uint64]struct{}, set *privateUint64SetV6, key uint64, w *iterator.OrdinalScanWork) (bool, error) {
	if set == nil {
		return s.step(m, key, w)
	}
	if m == nil || *m != nil {
		return false, ErrGenerationFormat
	}
	_, ready, err := set.insert(key, w)
	return ready, err
}

// NativePrivateCapacityForTestV6 contains only by-value physical provenance.
// Charges are independently rounded allocations, not an Owner envelope total.
// Debt is detached accounting only and must never be added as live backing.
type NativePrivateCapacityForTestV6 struct {
	OwnerBound, SameOwner, Zero, SnapshotBound, CloneBorrowed               bool
	CurrentPresent, NewPresent, SnapshotPresent, RefundOnly                 bool
	Entries, Version, Phase, CurrentCapacity, NewCapacity, SnapshotCapacity uint64
	CurrentCharge, NewCharge, SnapshotCharge, RefundDebt                    uint64
}

func (s *privateUint64SetV6) geometryV6(owner *retainedalloc.Owner, w *iterator.OrdinalScanWork) (g NativePrivateCapacityForTestV6, ready bool) {
	if w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(*s))+2*uint64(unsafe.Sizeof(g))) {
		return g, false
	}
	g.OwnerBound, g.SameOwner = s.owner != nil, s.owner != nil && s.owner == owner
	g.Zero, g.SnapshotBound, g.CloneBorrowed = s.zero, s.snapshotBound, s.cloneSource != nil
	g.CurrentPresent, g.NewPresent, g.SnapshotPresent = s.slots != nil, s.next != nil, s.snapshot != nil
	g.Entries, g.Version, g.Phase = uint64(s.length()), s.version, uint64(s.phase)
	g.CurrentCapacity, g.NewCapacity, g.SnapshotCapacity = uint64(cap(s.slots)), uint64(cap(s.next)), uint64(cap(s.snapshot))
	g.CurrentCharge, g.NewCharge, g.SnapshotCharge, g.RefundDebt = s.charge, s.nextCharge, s.snapshotCharge, s.debt
	g.RefundOnly = s.debt != 0 && !g.CurrentPresent && !g.NewPresent && !g.SnapshotPresent
	return g, true
}
