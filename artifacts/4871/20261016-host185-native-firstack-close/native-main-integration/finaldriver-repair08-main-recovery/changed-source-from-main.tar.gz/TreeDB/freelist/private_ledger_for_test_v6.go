package freelist

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"unsafe"
)

type NativePrivateLedgerForTestV6 struct {
	Stable, ExplicitOwner, MapsNil, CloneSameOwner, CloneChargesExact, Complete bool
	CloneHeader, AllocatedCharge, AbandonedCharge, DetachedRefundDebt           uint64
	AllocatedCapacity, AbandonedCapacity                                        uint64
	Controls                                                                    [4]NativePrivateCapacityForTestV6
	SortCharges, SortCapacities, SortPhases                                     [2]uint64
	SortSameOwner, SortComplete                                                 [2]bool
}

// The original single preparer is the sole private mutator. Read fixed private
// roles only; canonical live maps/allocated DATA are neither walked nor summed.
func (s *COWPreparationWorkV6) MaintenancePrivateLedgerForTestV6(w *iterator.OrdinalScanWork) (g NativePrivateLedgerForTestV6, ready bool) {
	if s == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(*s))+2*uint64(unsafe.Sizeof(g))+2*uint64(unsafe.Sizeof(FreelistTxn{}))) {
		return g, false
	}
	owner := s.changedPrivate.owner
	g.Stable = s.phase == 9 && s.captureStage == 3 && s.cleanupStage == 0 && !s.adopted && !s.cancelled && !s.privateViewsDetached && s.firstErr == nil && s.private != nil && s.prepared != nil && s.result != nil
	g.ExplicitOwner = owner != nil
	if s.private == nil {
		return g, true
	}
	g.MapsNil = s.private.changedChunks == nil && s.private.replacedMetadata == nil && s.materialize.reuse.planned.replacedMetadata == nil && (s.sink == nil || s.sink.pageIDs == nil)
	g.CloneSameOwner = owner != nil && s.replacedPrivate.owner == owner && s.sinkPrivate.owner == owner && (s.privateDebtOwner == nil || s.privateDebtOwner == owner)
	g.CloneHeader, g.AllocatedCharge, g.AbandonedCharge, g.DetachedRefundDebt = s.privateHeaderCharge, s.privateAllocatedCharge, s.privateAbandonedCharge, s.privateDebt
	g.AllocatedCapacity, g.AbandonedCapacity = uint64(cap(s.private.allocated)), uint64(cap(s.private.abandonedAppends))
	_, ac, e := privateObjectChargeV6(cap(s.private.allocated), uint64(unsafe.Sizeof(allocatedPage{})))
	_, bc, f := privateObjectChargeV6(cap(s.private.abandonedAppends), uint64(unsafe.Sizeof(ReservationExtentV1{})))
	_, hc, h := privateObjectChargeV6(1, uint64(unsafe.Sizeof(FreelistTxn{})))
	g.CloneChargesExact = e == nil && f == nil && h == nil && g.CloneHeader == hc && g.AllocatedCharge == ac && g.AbandonedCharge == bc
	g.Complete = g.Stable && g.ExplicitOwner && g.MapsNil && g.CloneSameOwner && g.CloneChargesExact && g.DetachedRefundDebt == 0
	sets := [4]*privateUint64SetV6{&s.changedPrivate, &s.replacedPrivate, &s.materialize.reuse.plannedReplaced, &s.sinkPrivate}
	for i, set := range sets {
		var ok bool
		g.Controls[i], ok = set.geometryV6(owner, w)
		if !ok {
			return g, false
		}
		v := g.Controls[i]
		_, currentCharge, chargeErr := privateObjectChargeV6(cap(set.slots), 8)
		exactCharge := chargeErr == nil && set.charge == currentCharge && (len(set.slots) == 0) == (set.slots == nil)
		// The unneeded planner is a genuinely unallocated optional control.
		unused := i == 2 && !s.materialize.reuse.planBound && set.owner == owner && set.slots == nil && set.next == nil && set.snapshot == nil && set.charge == 0 && set.nextCharge == 0 && set.snapshotCharge == 0 && set.debt == 0 && set.phase == 0 && set.cloneSource == nil
		g.Complete = g.Complete && (unused || v.OwnerBound && v.SameOwner && exactCharge && set.valid() && v.Phase == 0 && !v.NewPresent && !v.SnapshotPresent && !v.CloneBorrowed && v.NewCharge == 0 && v.SnapshotCharge == 0 && v.RefundDebt == 0)
	}
	sorters := [2]*reservationNormalizeWorkV1{&s.materialize.inventory.normalized, &s.materialize.reuse.inventory.normalized}
	for i, n := range sorters {
		if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*n))+64) {
			return g, false
		}
		g.SortCharges[i], g.SortCapacities[i], g.SortPhases[i] = n.scratchCharge, uint64(cap(n.scratch)), uint64(n.phase)
		g.SortSameOwner[i] = owner != nil && n.metadata == owner
		g.SortComplete[i] = n.firstErr == nil && (n.phase == 0 || n.phase == 8) && n.scratchCharge == 0 && n.scratch == nil && n.original == nil
		g.Complete = g.Complete && g.SortSameOwner[i] && g.SortComplete[i]
	}
	return g, true
}
