# Selected native split diagnostic

This construction follows the SAME public cursor, transaction, allocator,
pager, publication coordinator and physical receipt. It does not create another
publisher or change ordinary nil-work operations. No runtime result is claimed
by this document.

A fresh reopened fixture contains Commit1..33, floor32 and one selected delete.
Before its first pruning call it reads original scalar operands with separate
Q32/1MiB observation vectors. It excludes other producers during preparation,
requires one DATA input leaf and an empty newly opened cache prefix, and derives
bounded output cardinalities from directory entries plus one delete. Hash
capacities, metadata pages, ledger candidates, mapped chunks, concrete owner
bindings, registry capacity and historical reader fallback slots are transformed
with checked constructor rules. Lazy budget absence is supported without
constructing one during observation; birth includes its original allocation.

The checked G expression and typed package-local formulas are implemented in
`TreeDB/mvcc/native_finaldriver_envelope_test.go`. G is frozen on the first
cursor call; neither ready-time observation nor a later refusal can increase it.
All missing predicates and arithmetic overflow refuse before birth. Ready checks
validate actual private and registry geometry against the original transform.
The remaining production preflight validates the SAME live authority and
remaining grant before effects.

Ready is pre-Fence and private. After adoption only the original Finish path
may complete. A real mandatory FinishDetached return is the pause point used by
the proposed successor/Close diagnostic. The old reader is checked after native
publication and again after the newer durable writer. ACK and owning DB.Close
are separate arms; Close cannot manufacture cursor accounting ACK. Reopen checks
the selected deletion, anchor, future record and successor durability.

The public Q32/1MiB and original33/80/4096 guards are unchanged. The current
256-record acquisition scan exposes a Q32 progress blocker and refuses before
reading the shards. A larger source-derived diagnostic G is not acceptance of
that product gate. Linux retained-FD barriers, private empty-domain retention,
sticky hard-I/O debt and all remaining platform/history limits retain their
existing scope. Real failure injection/publication tests need distinct review
and runtime authorization.
