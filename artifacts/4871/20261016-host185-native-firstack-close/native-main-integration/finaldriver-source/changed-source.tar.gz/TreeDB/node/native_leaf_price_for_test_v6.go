package node

import (
	"github.com/snissn/gomap/TreeDB/page"
	"unsafe"
)

// NativeLeafPriceForTestV6 forwards actual child sizes/constants without
// acquiring a pool entry or constructing a Builder. Fresh leaf frames only.
func NativeLeafPriceForTestV6(prefix, columnar bool, keyBytes, valueBytes uint64) (records, bytes uint64, complete bool) {
	if columnar && !prefix || keyBytes > page.PageSize || valueBytes > page.PageSize || prefix && !columnar && keyBytes > uint64(len(Builder{}.leafPrevKeyBuf)) {
		return
	}
	add := func(r, b uint64) bool {
		if r > ^uint64(0)-records || b > ^uint64(0)-bytes {
			return false
		}
		records += r
		bytes += b
		return true
	}
	if !add(1, uint64(unsafe.Sizeof(Builder{}))) {
		return
	}
	if columnar {
		q := uint64((page.PageSize - NodeHeaderSize) / leafColumnarPrefixV2MetaSize)
		e := uint64(unsafe.Sizeof(leafColumnarPrefixV2Entry{}))
		if !add(2, leafColumnarEntriesPoolMaxCap*e) || !add(1, 64) || !add(1, 2) || !add(5, q*e+2*(builderByteArenaPoolMaxCap+uint64(unsafe.Sizeof(byteArenaHandle{})))) || !add(6, 2*keyBytes+valueBytes+max(valueBytes, uint64(page.ValuePtrSize))+e+64) || !add(1, 2*page.PageSize) || !add(8, 2*(page.PageSize+page.ValuePtrSize)+leafColumnarPrefixV2MetaSize+page.EntryRevisionSize) || !add(3, 64) {
			return
		}
	} else {
		p := uint64(0)
		if prefix {
			p = min(keyBytes, 64)
		}
		if !add(p+6, 2*p+3*keyBytes+valueBytes+page.ValuePtrSize+page.EntryRevisionSize+64) {
			return
		}
	}
	if !add(2, page.PageSize+NodeHeaderSize) {
		return
	}
	return records, bytes, true
}
