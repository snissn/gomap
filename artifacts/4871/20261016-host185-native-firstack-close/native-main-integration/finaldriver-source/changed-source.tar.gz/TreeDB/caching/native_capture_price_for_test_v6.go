package caching

import (
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/memtable"
)

// NativeCapturePreparationPriceForTestV6 prices the original lazy budget and
// empty-frontier prefix before backend Snapshot birth. shards is the actual
// maintained shard count captured before cursor construction. Counting every
// shard is conservative: the original capture saves its completed probe index.
// Backend birth, metadata enrollment and registry children are separate rows.
// This pure expression creates no governor, capture, lease or authority.
func NativeCapturePreparationPriceForTestV6(shards uint64) (records, bytes uint64, complete bool) {
	var db DB
	rows := [...][2]uint64{
		{1, 2*uint64(unsafe.Sizeof(db.nativeMVCCBudget)) + 2*uint64(unsafe.Sizeof(db.nativeMVCCLimits))},
		{1, 2*uint64(unsafe.Sizeof(memtable.COWBudget{})) + uint64(unsafe.Sizeof(db.nativeMVCCLimits))},
		{1, 2*uint64(unsafe.Sizeof(NativeMVCCCaptureV6{})) + 128},
		{1, 256},
		{1, 2 * uint64(unsafe.Sizeof(rootDomainSnapshot{}))},
	}
	for _, row := range rows {
		if row[0] > ^uint64(0)-records || row[1] > ^uint64(0)-bytes {
			return 0, 0, false
		}
		records += row[0]
		bytes += row[1]
	}
	shardBytes := uint64(unsafe.Sizeof(memShard{})) + 2*uint64(unsafe.Sizeof(rootDomainSnapshot{}))
	if shards > ^uint64(0)-records || shards > (^uint64(0)-bytes)/shardBytes {
		return 0, 0, false
	}
	return records + shards, bytes + shards*shardBytes, true
}

// NativeCaptureClosePrefixForTestV6 contains the original capture header and
// final wrapper-lease admission. Enrollment cancellation and Snapshot cleanup
// keep their separate original typed rows; completed close phases persist.
func NativeCaptureClosePrefixForTestV6() (records, bytes uint64) {
	return 2, 2*uint64(unsafe.Sizeof(NativeMVCCCaptureV6{})) +
		2*uint64(unsafe.Sizeof(memtable.COWExternalLease{})) + 2*uint64(unsafe.Sizeof(memtable.COWBudget{}))
}
