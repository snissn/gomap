package zipper

import (
	"github.com/snissn/gomap/TreeDB/batch"
	"github.com/snissn/gomap/TreeDB/freelist"
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
	"unsafe"
)

// NativeMaterializedPriceForTestV6 forwards original private sizes. The
// selected one-leaf/empty-prefix/outer-off shape excludes recursive internal
// frames. Installed-page validation is explicitly a WHOLE replayed scan.
func NativeMaterializedPriceForTestV6(ops, outputs, allocated, retired, lookupR, lookupB, appendR, appendB, appendCancelR, appendCancelB, leafR, leafB, addR, addB, removeR, removeB, frameBytes uint64) (prepareR, prepareB, cancelR, cancelB uint64, complete bool) {
	type unit struct{ r, b uint64 }
	bad := false
	sum := func(terms ...unit) unit {
		u := unit{}
		for _, v := range terms {
			if v.r > ^uint64(0)-u.r || v.b > ^uint64(0)-u.b {
				bad = true
				return unit{}
			}
			u.r += v.r
			u.b += v.b
		}
		return u
	}
	times := func(u unit, n uint64) unit {
		if n != 0 && (u.r > ^uint64(0)/n || u.b > ^uint64(0)/n) {
			bad = true
			return unit{}
		}
		return unit{u.r * n, u.b * n}
	}
	p := uint64(page.PageSize)
	entry := uint64(unsafe.Sizeof(batch.Entry{}))
	le := uint64(unsafe.Sizeof(node.LeafEntry{}))
	wb := uint64(unsafe.Sizeof(MaterializedWriteWork{}))
	wf := uint64(unsafe.Sizeof(materializedWriteFrame{}))
	add, remove := unit{addR, addB}, unit{removeR, removeB}
	frame := sum(unit{1, frameBytes + uint64(unsafe.Sizeof(page.ChildRef{}))}, unit{1, 128}, unit{7, 1088}, unit{lookupR, lookupB}, unit{1, 2 * p}, unit{1, 64})
	decode := sum(unit{1, uint64(unsafe.Sizeof(node.ProjectionDecoder{})) + uint64(unsafe.Sizeof(node.Node{}))}, unit{1, p + le}, unit{1, 2 * p}, unit{1, le + uint64(unsafe.Sizeof(page.ChildRef{}))})
	input := sum(unit{1, 2 * uint64(unsafe.Sizeof(MaterializedInputWorkV6{}))}, add, times(frame, 3), unit{3, 7 * p}, times(unit{1, 2 * entry}, ops), add, unit{2, 3 * p}, unit{1, p + 2*uint64(unsafe.Sizeof(node.PrimaryDirectoryEntry{}))}, unit{2, 3 * p}, decode, unit{2, 2 * p}, unit{2, 6*p + 2*entry}, add, unit{3, 6*p + 4*entry})
	merge := sum(unit{1, 128}, decode, unit{1, uint64(unsafe.Sizeof(node.ProjectionComparison{}))}, unit{0, 2 * p}, unit{1, 2*le + 64}, unit{1, le + 32})
	writer := sum(unit{2, 2*wb + 2*wf}, add, unit{3, 512}, unit{1, 2 * p}, unit{1, p + 256}, unit{leafR, leafB}, merge, unit{1, 256}, unit{leafR, leafB}, unit{appendR, appendB}, unit{1, 8}, unit{leafR, leafB}, unit{5, 2*p + 1024}, unit{1, p + 128}, unit{1, 2*wf + p}, add, unit{leafR, leafB})
	// Each installed-page child validates both original/live and private vectors.
	allocR, allocB := freelist.NativeAllocatedValidationElementForTestV6()
	one := sum(unit{1, 2*uint64(unsafe.Sizeof(freelist.AppendWork{})) + 64}, times(times(unit{allocR, allocB}, allocated), 2), unit{1, 2 * uint64(unsafe.Sizeof(freelist.COWRetirementV1{}))}, times(unit{1, 16}, retired))
	validation := sum(unit{1, 2 * wb}, times(sum(unit{2, 4*uint64(unsafe.Sizeof(freelist.AppendWork{})) + 2*uint64(unsafe.Sizeof(page.ChildRef{})) + 32}, one), outputs))
	visit := unit{3, uint64(unsafe.Sizeof(MaterializedPageVisitWorkV6{})) + 24 + uint64(unsafe.Sizeof(freelist.AppendWork{})) + 32}
	prep := sum(input, writer, validation, visit)
	inputClose := sum(unit{1, uint64(unsafe.Sizeof(node.ProjectionDecoder{}))}, unit{1, 2*p + 2*entry}, unit{1, 2 * entry}, unit{1, 2 * uint64(unsafe.Sizeof(MaterializedInputWorkV6{}))}, times(remove, 2))
	cancel := sum(inputClose, unit{appendCancelR, appendCancelB}, unit{1, wf}, unit{1, wb}, remove)
	if bad {
		return
	}
	return prep.r, prep.b, cancel.r, cancel.b, true
}
