package treedb

import (
	"github.com/snissn/gomap/TreeDB/caching"
	backenddb "github.com/snissn/gomap/TreeDB/db"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
	"github.com/snissn/gomap/TreeDB/lifecycle"
)

// NativeMVCCCaptureV6 is the original cache capture continuation, embedded in
// its admitted MVCC caller. It creates no independent snapshot owner.
type NativeMVCCCaptureV6 = caching.NativeMVCCCaptureV6

// NativeMVCCBudgetV6 returns the original cache-lifetime admission governor.
// A backend-only handle has no supported native cache route.
func (db *DB) NativeMVCCBudgetV6(w *iterator.OrdinalScanWork) (*memtable.COWBudget, bool, error) {
	if db == nil {
		return nil, false, ErrClosed
	}
	if w == nil || !w.Reserve(1, 64) {
		return nil, false, nil
	}
	db.lifecycleMu.RLock()
	defer db.lifecycleMu.RUnlock()
	if db.cached == nil || db.backend == nil {
		return nil, false, caching.ErrCOWUnsupported
	}
	return db.cached.NativeMVCCBudgetV6(w)
}

// StepNativeMVCCCaptureV6 preserves public lifecycle exclusion while the SAME
// cache cut acquires the original backend Snapshot's admitted physical borrows.
// Initial acceptance does not establish reader readiness or physical Finish.
func (db *DB) StepNativeMVCCCaptureV6(c *NativeMVCCCaptureV6, admit func(backenddb.SnapshotAllocationSizes) error, w *iterator.OrdinalScanWork) (*backenddb.Snapshot, bool, error) {
	if db == nil {
		return nil, false, ErrClosed
	}
	if w == nil || !w.Reserve(1, 64) {
		return nil, false, nil
	}
	db.lifecycleMu.RLock()
	defer db.lifecycleMu.RUnlock()
	if db.cached == nil || db.backend == nil {
		return nil, false, caching.ErrCOWUnsupported
	}
	return db.cached.StepNativeMVCCCaptureV6(c, admit, w)
}

func (db *DB) StepNativeMVCCOwnedCaptureV6(c *NativeMVCCCaptureV6, w *iterator.OrdinalScanWork) (*backenddb.Snapshot, bool, error) {
	if db == nil {
		return nil, false, ErrClosed
	}
	if w == nil || !w.Reserve(1, 64) {
		return nil, false, nil
	}
	db.lifecycleMu.RLock()
	defer db.lifecycleMu.RUnlock()
	if db.cached == nil || db.backend == nil {
		return nil, false, caching.ErrCOWUnsupported
	}
	return db.cached.StepNativeMVCCOwnedCaptureV6(c, w)
}

// MaintenanceNativePreCursorCacheForTestV6 never calls NativeMVCCBudgetV6 and
// therefore never creates a lazy governor merely to price cursor birth.
func (db *DB) MaintenanceNativePreCursorCacheForTestV6(w *iterator.OrdinalScanWork) (g caching.NativePreCursorCacheForTestV6, ready bool) {
	if db == nil || w == nil || !w.Reserve(1, 64) {
		return g, false
	}
	db.lifecycleMu.RLock()
	defer db.lifecycleMu.RUnlock()
	if db.cached == nil || db.backend == nil {
		return g, false
	}
	return db.cached.MaintenanceNativePreCursorCacheForTestV6(w)
}

func (db *DB) MaintenanceNativePreCursorBackendForTestV6(w *iterator.OrdinalScanWork) (g backenddb.NativePreCursorBackendForTestV6, ready bool) {
	if db == nil || w == nil || !w.Reserve(1, 64) {
		return g, false
	}
	db.lifecycleMu.RLock()
	defer db.lifecycleMu.RUnlock()
	if db.cached == nil || db.backend == nil {
		return g, false
	}
	return db.backend.MaintenanceNativePreCursorBackendForTestV6(w)
}

func (db *DB) MaintenanceNativePreCursorBackendRoleForTestV6(role uint8, w *iterator.OrdinalScanWork) (g backenddb.NativePreCursorBackendForTestV6, ready bool) {
	if db == nil || w == nil || !w.Reserve(1, 64) {
		return g, false
	}
	db.lifecycleMu.RLock()
	defer db.lifecycleMu.RUnlock()
	if db.backend == nil {
		return g, false
	}
	return db.backend.MaintenanceNativePreCursorBackendRoleForTestV6(role, w)
}

// Each call carries only scalar census progress. The designated diagnostic
// excludes producers/reopen until all roles have the same original basis.
func (db *DB) MaintenanceNativePreCursorRegistryRoleForTestV6(c *rootpublication.NativePreCursorRegistryScanForTestV6, w *iterator.OrdinalScanWork) (g backenddb.NativePreCursorBackendForTestV6, ready bool) {
	if db == nil || w == nil || !w.Reserve(1, 64) {
		return g, false
	}
	db.lifecycleMu.RLock()
	defer db.lifecycleMu.RUnlock()
	if db.backend == nil {
		return g, false
	}
	return db.backend.MaintenanceNativePreCursorRegistryRoleForTestV6(c, w)
}

func (db *DB) MaintenanceNativeMinimumGeometryForTestV6(w *iterator.OrdinalScanWork) (g lifecycle.NativeMinimumGeometryForTestV6, indexGenerations uint64, ready bool) {
	if db == nil || w == nil || !w.Reserve(1, 64) {
		return g, 0, false
	}
	db.lifecycleMu.RLock()
	defer db.lifecycleMu.RUnlock()
	if db.backend == nil {
		return g, 0, false
	}
	return db.backend.MaintenanceNativeMinimumGeometryForTestV6(w)
}
