package freelist

import (
	"math"
	"testing"
)

func TestNativeSelectedAllocatorStructuralEnvelopeV6(t *testing.T) {
	// Synthetic scalar operands exercise arithmetic only; they are not a real
	// candidate, claimed page, proof, retained owner or runtime allowance.
	g := NativePreCursorAllocatorForTestV6{PageCount: 512, Profile: COWPrepareProfileV1{Valid: true, HighWater: 512, AllocatedPages: 3, AbandonedAppendExtents: 2, ChangedChunks: 4, ReplacedMetadataPages: 5, LedgerHighestReservedEnd: 700}}
	v := NativeSelectedAllocatorEnvelopeForTestV6(g, 7, 6)
	if !v.Complete || v.DataHighWater != 519 || v.Chunks != 3 || v.StatePages != 45 || v.Changed != 7 || v.Replaced != 51 || v.Allocated != 10 || v.Abandoned != 2 || v.Retired != 13 || v.Inventory != 63 || v.TailStart != 700 || v.GapExtents != 1 || v.ChainPages != 1 || v.MetadataPages != 47 || v.HighWater != 747 {
		t.Fatalf("source recurrence changed: %+v", v)
	}
	for _, kind := range []string{"invalid", "physical-ahead", "data-overflow", "inventory-overflow", "chain-format"} {
		t.Run(kind, func(t *testing.T) {
			bad := g
			d := uint64(7)
			switch kind {
			case "invalid":
				bad.Profile.Valid = false
			case "physical-ahead":
				bad.PageCount++
			case "data-overflow":
				d = math.MaxUint64
			case "inventory-overflow":
				bad.Profile.AllocatedPages = math.MaxUint64
			case "chain-format":
				bad.Profile.AbandonedAppendExtents = uint64(reservationEntriesPerPage) * (math.MaxUint16 + 1)
			}
			if got := NativeSelectedAllocatorEnvelopeForTestV6(bad, d, 6); got.Complete {
				t.Fatalf("unsupported shape granted: %+v", got)
			}
		})
	}
}
