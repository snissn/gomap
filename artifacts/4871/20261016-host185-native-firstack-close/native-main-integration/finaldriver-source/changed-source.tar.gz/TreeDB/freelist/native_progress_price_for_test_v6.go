package freelist

import (
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/page"
	"unsafe"
)

type nativePriceV6 struct {
	r, b uint64
	bad  bool
}

func (u *nativePriceV6) add(r, b uint64) {
	r2, b2 := reservationBoundAddV1(u.r, r), reservationBoundAddV1(u.b, b)
	u.bad = u.bad || r2 == ^uint64(0) || b2 == ^uint64(0)
	u.r, u.b = r2, b2
}
func (u *nativePriceV6) join(v nativePriceV6) { u.add(v.r, v.b); u.bad = u.bad || v.bad }
func (u nativePriceV6) times(n uint64) nativePriceV6 {
	r, b := reservationBoundMulV1(u.r, n), reservationBoundMulV1(u.b, n)
	return nativePriceV6{r, b, u.bad || r == ^uint64(0) || b == ^uint64(0)}
}

// NativePreparationPriceForTestV6 sums the source child alternatives and all
// repeated completed-child prefixes. Saved trie/hash/sort indices make each
// row a next-persistent-progress unit, not a whole traversal in one invocation.
// Whole capture/claim rows retain their actual cardinality products.
func NativePreparationPriceForTestV6(g NativePreCursorAllocatorForTestV6, v NativeSelectedAllocatorBoundForTestV6, addR, addB, removeR, removeB uint64) (records, bytes, publishedR, publishedB uint64, complete bool) {
	if !v.Complete {
		return
	}
	add, remove := nativePriceV6{addR, addB, false}, nativePriceV6{removeR, removeB, false}
	mul, plus := reservationBoundMulV1, reservationBoundAddV1
	ss := uint64(unsafe.Sizeof(privateUint64SetV6{}))
	sn := uint64(unsafe.Sizeof(stateNode{}))
	sc := uint64(unsafe.Sizeof(stateChunk{}))
	p := uint64(unsafe.Sizeof((*stateNode)(nil)))
	ex := uint64(unsafe.Sizeof(ReservationExtentV1{}))
	capFor := func(n uint64) uint64 {
		if n == 0 {
			return 0
		}
		n = mul(2, n)
		c := uint64(16)
		for c < n && c <= ^uint64(0)/2 {
			c *= 2
		}
		if c < n {
			return ^uint64(0)
		}
		return c
	}
	c := max(capFor(v.Changed), max(capFor(v.Replaced), capFor(v.MetadataPages)))
	hash := nativePriceV6{15, plus(10*ss+400, mul(8, c)), false}
	hash.join(add)
	hash.join(remove)
	build := hash
	build.add(3, 4*ss+32)
	build.join(remove)
	clone := hash
	clone.add(5, 6*ss+64)
	capture := nativePriceV6{}
	for _, n := range []uint64{v.Changed, v.Replaced} {
		capture.add(plus(1, n), plus(2*ss, mul(32, n)))
		capture.join(add)
	}
	capture.add(1, 3*uint64(unsafe.Sizeof(FreelistTxn{}))+2*uint64(unsafe.Sizeof(COWPreparationWorkV6{})))
	capture.join(add)
	capture.add(1, plus(mul(v.Allocated, uint64(unsafe.Sizeof(allocatedPage{}))), 48))
	capture.join(add)
	capture.add(1, plus(mul(v.Abandoned, ex), 48))
	capture.join(add)
	capture.add(2, 2*uint64(unsafe.Sizeof(allocatedPage{}))+2*ex)
	detach := nativePriceV6{3, sn + sc + 2*p, false}
	summary := nativePriceV6{4, 40 + 32 + 8 + p + 40, false}
	count := nativePriceV6{2, 72 + uint64(unsafe.Sizeof(statePageWalkFrameV1{})), false}
	search := nativePriceV6{2, sn + 8, false}
	pending := nativePriceV6{3, ex + 48, false}
	mark := hash
	mark.add(1, sn)
	mutation := nativePriceV6{13, 6*sn + 2*sc + 9*p + 8 + 24 + 16, false}
	mutation.join(detach)
	mutation.join(pending)
	mutation.join(summary)
	retire := nativePriceV6{3, 64 + uint64(unsafe.Sizeof(privateRetirementWorkV6{})) + uint64(unsafe.Sizeof(COWRetirementV1{})), false}
	retire.join(mark)
	retire.join(mutation)
	retire.join(hash)
	prune := nativePriceV6{2, 48, false}
	prune.join(search)
	prune.join(mark)
	prune.join(mutation)
	prune.join(hash)
	// Reservation-family sum. Entry-wise sort/copy/hash phases persist; atomic
	// tail conflict search and storage use their full original under-lock bound.
	z := plus(plus(v.Inventory, v.GapExtents), 1)
	rfam := nativePriceV6{}
	for _, row := range [][2]uint64{{1, mul(v.Inventory, ex)}, {1, mul(v.Inventory, ex)}, {1, uint64(unsafe.Sizeof(allocatedPage{})) + ex}, {1, 2 * ex}, {1, 32 + ex}, {3, 3 * ex}, {1, 2 * ex}, {3, 3 * ex}, {1, uint64(unsafe.Sizeof(reservationNormalizeWorkV1{}))}, {1, mul(z, ex)}, {5, 5 * ex}, {1, mul(v.ChainPages, 8+uint64(unsafe.Sizeof([]byte{})))}, {1, page.PageSize + reservationHeaderSize + 8}, {1, reservationEntrySize + ex}, {1, page.PageSize}, {1, page.PageSize + 64}, {1, 96}, {1, page.PageSize + 32}} {
		rfam.add(row[0], row[1])
	}
	rfam.join(add)
	rfam.join(remove)
	o, lc, burn := g.Profile.LedgerOwners, plus(g.Profile.LedgerCandidates, 1), g.Profile.LedgerBurnedTailRanges
	claim := func(coverage uint64) nativePriceV6 {
		n := mul(coverage, plus(1, coverage))
		return nativePriceV6{plus(plus(1, lc), n), plus(uint64(unsafe.Sizeof(reservation{})), plus(mul(128, plus(plus(1, lc), o)), mul(uint64(unsafe.Sizeof(reservationInterval{})), n))), false}
	}
	reused := claim(v.Abandoned)
	reused.add(plus(plus(2, burn), mul(v.MetadataPages, plus(plus(1, burn), lc))), 0)
	reused.add(0, mul(24, reused.r))
	tail := claim(plus(v.Inventory, 1))
	n := plus(plus(plus(o, burn), lc), 1)
	tail.add(plus(plus(plus(2, burn), mul(n, n)), v.Inventory), 0)
	tail.add(0, mul(24, tail.r))
	rfam.join(reused)
	rfam.join(tail)
	// Five is the original four speculative reuse attempts plus append fallback.
	rfam = rfam.times(metadataReuseChunkAttempts + 1)
	reuse := nativePriceV6{7, 24 + 24 + sn + uint64(unsafe.Sizeof(FreelistTxn{})) + uint64(unsafe.Sizeof(privateTxnViewV6{})) + 2*uint64(unsafe.Sizeof(reservationInventoryWorkV1{})) + uint64(unsafe.Sizeof(FreelistTxn{})) + uint64(unsafe.Sizeof(candidateBeginWorkV1{})) + 32 + 16, false}
	reuse.join(search)
	reuse.add(plus(1, plus(burn, lc)), plus(32, mul(24, plus(1, plus(burn, lc)))))
	reuse.join(count)
	reuse.join(clone)
	reuse.join(mark.times(2))
	reuse.join(mutation)
	reuse.join(hash)
	reuse.join(remove)
	encoded := nativePriceV6{8, 4*page.PageSize + chunkHeaderSize + 16 + 12 + 80 + indexHeaderSize, false}
	recorded := hash
	recorded.add(plus(2, v.MetadataPages), plus(64, mul(mul(2, plus(v.MetadataPages, 1)), uint64(unsafe.Sizeof(PageImageV1{})))))
	emit := count
	emit.add(1, page.PageSize+16+uint64(unsafe.Sizeof(statePageEncodeWorkV1{})))
	emit.join(encoded)
	emit.join(recorded)
	output := emit
	output.add(1, page.PageSize+16+uint64(unsafe.Sizeof(statePageEncodeWorkV1{})))
	output.join(encoded)
	output.join(recorded.times(4))
	output.add(7, uint64(unsafe.Sizeof(ReservationRecordV1{}))+uint64(unsafe.Sizeof(FreelistGenerationV1{}))+mul(16, v.MetadataPages)+16+page.PageSize+2*generationHeaderSize+32+uint64(unsafe.Sizeof(GenerationRefV1{}))+uint64(unsafe.Sizeof(FreelistTxnStats{}))+uint64(unsafe.Sizeof(PageImageV1{}))+8+uint64(unsafe.Sizeof(FreelistCandidateV1{})))
	material := nativePriceV6{6, uint64(unsafe.Sizeof(recordingSink{})) + 64 + sn + sc + mul(8, v.Allocated) + uint64(unsafe.Sizeof(allocatedPage{})) + 8, false}
	material.join(reuse)
	material.join(detach)
	material.join(hash)
	material.join(count)
	material.join(rfam)
	material.join(output)
	u := capture
	u.join(build.times(2))
	u.join(detach)
	u.join(retire)
	u.join(prune)
	u.join(material)
	u.add(2, 96+uint64(unsafe.Sizeof(PreparedCOWCandidateV1{})))
	// Published private cleanup detaches each table descriptor without scanning
	// backing capacity. Every original accounting-only continuation is retained.
	pub := nativePriceV6{4, 6*uint64(unsafe.Sizeof(COWPreparationWorkV6{})) + 2*uint64(unsafe.Sizeof(PreparedCOWCandidateV1{})), false}
	norm := remove
	norm.add(2, uint64(unsafe.Sizeof(reservationNormalizeWorkV1{}))+2*uint64(unsafe.Sizeof(retainedalloc.RemovalWork{})))
	pub.join(norm.times(2))
	hc := remove.times(2)
	hc.add(2, 4*ss)
	pub.join(hc.times(4))
	pub.join(remove)
	if u.bad || pub.bad || u.r == ^uint64(0) || u.b == ^uint64(0) {
		return
	}
	return u.r, u.b, pub.r, pub.b, true
}

func NativeAllocatedValidationElementForTestV6() (uint64, uint64) {
	return 1, 2 * uint64(unsafe.Sizeof(allocatedPage{}))
}
