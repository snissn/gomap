package freelist

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/pager"
	"math"
	"unsafe"
)

// NativePreCursorAllocatorForTestV6 contains no borrowed transaction, page or
// ledger alias. It neither prepares nor claims a candidate.
type NativePreCursorAllocatorForTestV6 struct {
	Profile                                 COWPrepareProfileV1
	PageCount, Activated, ActivatedCapacity uint64
}

func (a *Allocator) MaintenanceNativePreCursorForTestV6(w *iterator.OrdinalScanWork) (g NativePreCursorAllocatorForTestV6, ready bool) {
	if a == nil || w == nil || !w.Reserve(2, 2*uint64(unsafe.Sizeof(*a))+2*uint64(unsafe.Sizeof(g))+2*uint64(unsafe.Sizeof(allocatorCOWStateV1{}))+2*uint64(unsafe.Sizeof(FreelistTxn{}))) {
		return g, false
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.pager == nil || a.cow == nil || a.cow.txn == nil || a.cow.generation == nil || a.cow.ledger == nil || a.cow.txn.root == nil {
		return g, true
	}
	t, b, l := a.cow.txn, a.cow.generation, a.cow.ledger
	g.PageCount = a.pager.PageCount()
	g.Activated, g.ActivatedCapacity = uint64(len(a.cow.activated)), uint64(cap(a.cow.activated))
	l.mu.Lock()
	defer l.mu.Unlock()
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*l))+uint64(unsafe.Sizeof(*b))) {
		return g, false
	}
	p := &g.Profile
	p.Valid = true
	p.RequiresGeneration = t.requiresGeneration || t.consumed || t.base != b
	p.HighWater = t.highWater
	p.RetiredPages = t.root.retiredCount
	p.AllocatedPages = uint64(len(t.allocated))
	p.AbandonedAppendExtents = uint64(len(t.abandonedAppends))
	p.ChangedChunks = uint64(len(t.changedChunks))
	p.ReplacedMetadataPages = uint64(len(t.replacedMetadata))
	p.BaseReservationExtents = uint64(len(b.record.Extents))
	p.BaseMetadataPages = uint64(len(b.metadataPages))
	p.LedgerOwners = uint64(len(l.owners))
	p.LedgerCandidates = uint64(len(l.candidates))
	p.LedgerBurnedTailRanges = uint64(len(l.burnedTails))
	// Map iteration has no retained discovery cursor. Admit its whole protected
	// geometry before range can inspect the first element, including empty maps.
	nr, nb := uint64(0), uint64(0)
	for _, v := range [][2]uint64{{p.LedgerOwners, 16}, {p.LedgerBurnedTailRanges, 2 * uint64(unsafe.Sizeof(reservationInterval{}))}, {p.LedgerCandidates, 2 * uint64(unsafe.Sizeof(reservation{}))}} {
		if v[0] > math.MaxUint64-nr || v[1] != 0 && v[0] > (math.MaxUint64-nb)/v[1] {
			return g, false
		}
		nr += v[0]
		nb += v[0] * v[1]
	}
	if !w.Reserve(nr, nb) {
		return g, false
	}
	for id := range l.owners {
		if id == math.MaxUint64 {
			p.LedgerHighestReservedEnd = math.MaxUint64
		} else {
			p.LedgerHighestReservedEnd = max(p.LedgerHighestReservedEnd, id+1)
		}
	}
	for _, v := range l.burnedTails {
		p.LedgerHighestReservedEnd = max(p.LedgerHighestReservedEnd, reservationIntervalEndSaturated(v))
	}
	for _, v := range l.candidates {
		if v != nil && v.tailReserved {
			p.LedgerHighestReservedEnd = max(p.LedgerHighestReservedEnd, reservationIntervalEndSaturated(reservationInterval{start: v.tailStart, count: v.tailCount}))
		}
	}
	return g, true
}

// NativeSelectedAllocatorBoundForTestV6 is an arithmetic shape bound, never a
// preparation limit or authority. D and I must come from the selected DATA
// producer proof; BatchSize alone supplies neither.
type NativeSelectedAllocatorBoundForTestV6 struct {
	DataHighWater, Chunks, StatePages, Changed, Replaced, Allocated, Abandoned      uint64
	Retired, Inventory, TailStart, GapExtents, ChainPages, MetadataPages, HighWater uint64
	Complete                                                                        bool
}

func NativeSelectedAllocatorEnvelopeForTestV6(g NativePreCursorAllocatorForTestV6, outputPages, inputRetired uint64) (v NativeSelectedAllocatorBoundForTestV6) {
	p := g.Profile
	if !p.Valid || p.HighWater < g.PageCount {
		return v
	}
	add := func(a, b uint64) (uint64, bool) {
		if b > math.MaxUint64-a {
			return 0, false
		}
		return a + b, true
	}
	mul := func(a, b uint64) (uint64, bool) {
		if b != 0 && a > math.MaxUint64/b {
			return 0, false
		}
		return a * b, true
	}
	ceil := func(a, b uint64) uint64 { return a/b + boolToNativeBoundUintV6(a%b != 0) }
	var ok bool
	if v.DataHighWater, ok = add(max(p.HighWater, g.PageCount), outputPages); !ok {
		return v
	}
	v.Chunks = ceil(v.DataHighWater, freelistChunkSize)
	if v.StatePages, ok = mul(chunkTrieDepth+1, v.Chunks); !ok {
		return v
	}
	v.StatePages = max(1, v.StatePages)
	if v.Changed, ok = add(p.ChangedChunks, v.Chunks); !ok {
		return v
	}
	if v.Replaced, ok = add(p.ReplacedMetadataPages, v.StatePages); !ok {
		return v
	}
	if v.Replaced, ok = add(v.Replaced, 1); !ok {
		return v
	}
	if v.Allocated, ok = add(p.AllocatedPages, outputPages); !ok {
		return v
	}
	v.Abandoned = p.AbandonedAppendExtents
	if v.Retired, ok = add(outputPages, inputRetired); !ok {
		return v
	}
	if v.Inventory, ok = add(v.Allocated, v.Abandoned); !ok {
		return v
	}
	if v.Inventory, ok = add(v.Inventory, v.Replaced); !ok {
		return v
	}
	v.TailStart = max(v.DataHighWater, p.LedgerHighestReservedEnd)
	v.GapExtents = ceil(v.TailStart-p.HighWater, math.MaxUint32)
	n, ok := add(v.Inventory, v.GapExtents)
	if !ok {
		return v
	}
	n, ok = add(n, 1)
	if !ok {
		return v
	}
	v.ChainPages = max(1, ceil(n, reservationEntriesPerPage))
	if v.ChainPages > math.MaxUint16 {
		return v
	}
	if v.MetadataPages, ok = add(v.StatePages, v.ChainPages); !ok {
		return v
	}
	if v.MetadataPages, ok = add(v.MetadataPages, 1); !ok || v.MetadataPages > math.MaxUint32 {
		return v
	}
	if v.HighWater, ok = add(v.TailStart, v.MetadataPages); !ok {
		return v
	}
	// Every original make/index uses int; do not grant a wrapped geometry.
	for _, n := range [...]uint64{v.Changed, v.Replaced, v.Allocated, v.Abandoned, v.Retired, v.Inventory, v.MetadataPages} {
		if n > uint64(^uint(0)>>1) {
			return v
		}
	}
	v.Complete = true
	return v
}
func boolToNativeBoundUintV6(v bool) uint64 {
	if v {
		return 1
	}
	return 0
}

// NativeSelectedPublicationPriceForTestV6 is the source-expression upper
// bound for the one selected prefix with no abandoned coverage. It executes
// no ledger read, activation, count install or write. Actual locked preflight
// remains authoritative and must reject if mutable geometry exceeds this row.
func NativeSelectedPublicationPriceForTestV6(v NativeSelectedAllocatorBoundForTestV6) (g NativePublicationBoundV6, ok bool) {
	if !v.Complete {
		return g, false
	}
	add := reservationBoundAddV1
	mul := reservationBoundMulV1
	g.Prefix, g.MetadataPages, g.ClaimedIDs, g.HighWater = 1, v.MetadataPages, v.Allocated, v.HighWater
	g.PublicationRecords = add(3+9, add(1+1, v.Allocated))
	g.PublicationBytes = add(uint64(unsafe.Sizeof(allocatorCOWStateV1{}))+256+uint64(unsafe.Sizeof(CandidateIDV1{}))+144,
		add(2*uint64(unsafe.Sizeof(COWPublicationScopeV6{}))+uint64(unsafe.Sizeof(PreparedCOWCandidateV1{}))+32, mul(v.Allocated, 32)))
	rw, bw := pager.NativePageWriteWorkV6()
	g.PageRecords = add(1, mul(v.MetadataPages, 2+rw))
	g.PageBytes = add(uint64(unsafe.Sizeof(FreelistCandidateV1{})), mul(v.MetadataPages, uint64(unsafe.Sizeof(PageImageV1{}))+2*uint64(unsafe.Sizeof(CandidatePageViewV1{}))+uint64(unsafe.Sizeof((*pager.Pager)(nil)))+8+bw))
	g.MaterializationRecords = 7 + 3
	g.MaterializationBytes = 2*uint64(unsafe.Sizeof(Allocator{})) + 2*uint64(unsafe.Sizeof(allocatorCOWStateV1{})) + uint64(unsafe.Sizeof(ReservationLedger{})) + uint64(unsafe.Sizeof(FreelistTxn{})) + uint64(unsafe.Sizeof((*pager.Pager)(nil))) + 24 + uint64(unsafe.Sizeof(PreparedCOWCandidateV1{})) + uint64(unsafe.Sizeof(reservation{})) + 2*uint64(unsafe.Sizeof(CandidateIDV1{})) + 16
	for _, x := range [...]uint64{g.PublicationRecords, g.PublicationBytes, g.PageRecords, g.PageBytes, g.MaterializationRecords, g.MaterializationBytes} {
		if x == math.MaxUint64 {
			return g, false
		}
	}
	return g, true
}

// NativeSelectedAppendPriceForTestV6 lifts the original DATA Growth family
// by every repeated append/ledger/vector prefix. Initial spare allocated
// capacity is not copied; replacement capacity is bounded by max(4,2*A).
func NativeSelectedAppendPriceForTestV6(g NativePreCursorAllocatorForTestV6, v NativeSelectedAllocatorBoundForTestV6, growth pager.NativeGrowthBoundForTestV6) (records, bytes, cancelRecords, cancelBytes uint64, complete bool) {
	if !v.Complete || !growth.Complete {
		return
	}
	add := reservationBoundAddV1
	mul := reservationBoundMulV1
	cap := max(uint64(4), mul(2, v.Allocated))
	records = add(growth.Records, add(5, add(v.Allocated, add(g.Profile.LedgerBurnedTailRanges, g.Profile.LedgerCandidates))))
	bytes = add(growth.Bytes, add(4*uint64(unsafe.Sizeof(AppendWork{}))+256, add(mul(add(cap, v.Allocated), uint64(unsafe.Sizeof(allocatedPage{}))), add(64, add(mul(16, g.Profile.LedgerBurnedTailRanges), mul(g.Profile.LedgerCandidates, uint64(unsafe.Sizeof(reservation{}))))))))
	cancelRecords = add(growth.CancelRecords, 1)
	cancelBytes = add(growth.CancelBytes, uint64(unsafe.Sizeof(AppendWork{})))
	complete = records != math.MaxUint64 && bytes != math.MaxUint64 && cancelRecords != math.MaxUint64 && cancelBytes != math.MaxUint64
	return
}

// NativeSelectedClaimPriceForTestV6 evaluates the actual claimStorageBound,
// private DATA validation and activation-tail terms using protected precursor
// caps. It grants nothing; the original final turn revalidates live geometry.
func NativeSelectedClaimPriceForTestV6(g NativePreCursorAllocatorForTestV6, v NativeSelectedAllocatorBoundForTestV6) (records, bytes uint64, complete bool) {
	if !v.Complete {
		return
	}
	add := reservationBoundAddV1
	mul := reservationBoundMulV1
	n, owners, candidates := v.Allocated, g.Profile.LedgerOwners, add(g.Profile.LedgerCandidates, 1)
	// Include a full already claimed DATA vector as well as the exact captured
	// private vector. This deliberately covers both original ownership branches.
	ids := n
	records = add(1, add(candidates, add(mul(n, add(1, add(owners, n))), mul(n, add(1, add(ids, n))))))
	bytes = add(uint64(unsafe.Sizeof(reservation{})), add(mul(128, add(1, add(candidates, add(owners, n)))), mul(8, mul(n, add(1, add(ids, n))))))
	records = add(records, mul(n, add(1, add(g.Profile.LedgerBurnedTailRanges, g.Profile.LedgerCandidates))))
	// Actual activation starts from the selected empty activated prefix; include
	// potential initial backing construction plus the fixed installation tail.
	if g.Activated != 0 {
		return 0, 0, false
	}
	records = add(records, 5)
	bytes = add(bytes, 96+uint64(unsafe.Sizeof((*PreparedCOWCandidateV1)(nil)))+uint64(unsafe.Sizeof(candidateBeginWorkV1{}))+48)
	complete = records != math.MaxUint64 && bytes != math.MaxUint64
	return
}
