package pager

import (
	"errors"
	"fmt"
	"math"
	"os"
	"runtime"
	"sync/atomic"
	"unsafe"
	"weak"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/page"
)

var ErrGrowthStale = errors.New("pager: growth source changed")
var ErrGrowthClosed = errors.New("pager: growth source closed")

const growthReady = 9

// Growth is the ordinary growth operation's private destination. Source
// authorities are non-owning; old mapping descriptors only occur in the actual
// prepared destination. Cancel owns just the newly mapped, unpublished suffix.
type Growth struct {
	targetPages                                                               uint64
	capacityTarget                                                            int64
	logical, policy                                                           bool
	owner                                                                     weak.Pointer[Pager]
	source                                                                    weak.Pointer[chunkList]
	file                                                                      weak.Pointer[os.File]
	verified                                                                  weak.Pointer[verifiedBitset]
	prefetch                                                                  weak.Pointer[prefetchBitset]
	count                                                                     uint64
	oldChunks, totalChunks, oldVerified, needVerified, oldPrefetch, needWords int
	dirtyRevision                                                             uint64
	dirtyCount, dirtyLow, dirtyHigh                                           int
	primary, atomicView                                                       [][]byte
	mappings                                                                  []mappingOwner
	preparedView                                                              *chunkList
	memoryOnly                                                                bool
	verifiedOutput                                                            *verifiedBitset
	prefetchOutput                                                            *prefetchBitset
	dirtyOutput                                                               []uint64
	phase, position, mapped                                                   int
	captured, installed, cancelled                                            bool
	native                                                                    bool
	failure                                                                   error
	cleanupFailure                                                            error
	metadata                                                                  *retainedalloc.Owner
	metadataCharge, metadataOld                                               uint64
}

func NewGrowth(targetPages uint64, w *iterator.OrdinalScanWork) (*Growth, bool, error) {
	if ok, e := pagerReserve(w, 1, 6*uint64(unsafe.Sizeof(Growth{}))+256); !ok || e != nil {
		return nil, false, e
	}
	return &Growth{targetPages: targetPages, logical: true, policy: w != nil}, true, nil
}

// NewGrowthForPager admits its actual private operation wrapper before creation.
func NewGrowthForPager(p *Pager, target uint64, w *iterator.OrdinalScanWork) (*Growth, bool, error) {
	var owner *retainedalloc.Owner
	if p != nil {
		owner = p.immutableReadRoots.retention
	}
	charge := retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(Growth{})))
	if owner != nil {
		if err := owner.Add(charge); err != nil {
			return nil, false, err
		}
	}
	g, ready, err := NewGrowth(target, w)
	if !ready || err != nil {
		if owner != nil {
			owner.Remove(charge)
		}
		return nil, ready, err
	}
	g.metadata = owner
	if owner != nil {
		g.metadataCharge = charge
	}
	return g, true, nil
}

// NewNativeGrowthForPagerV6 retains the SAME Growth wrapper until its Claim
// clears the final child alias and accepts its accounting. Ordinary callers
// keep NewGrowthForPager and its original lifetime policy.
func NewNativeGrowthForPagerV6(p *Pager, target uint64, w *iterator.OrdinalScanWork) (*Growth, bool, error) {
	if p == nil || w == nil {
		return nil, false, retainedalloc.ErrWorkRequired
	}
	if ok, e := pagerReserve(w, 1, 6*uint64(unsafe.Sizeof(Growth{}))+256); !ok || e != nil {
		return nil, false, e
	}
	owner := p.immutableReadRoots.retention
	charge := NativeGrowthWrapperChargeV6()
	if owner != nil {
		if ready, e := retainedalloc.AddWithOrdinalWork(owner, charge, w); !ready || e != nil {
			return nil, false, e
		}
	}
	g := &Growth{targetPages: target, logical: true, policy: true, native: true, metadata: owner}
	if owner != nil {
		g.metadataCharge = charge
	}
	return g, true, nil
}
func NativeGrowthWrapperChargeV6() uint64 {
	return retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(Growth{})))
}

// DetachNativeAccountingV6 transfers accounting only; the SAME original Claim
// must clear its Growth alias before its own terminal accounting can be freed.
func (g *Growth) DetachNativeAccountingV6(expected *retainedalloc.Owner, w *iterator.OrdinalScanWork) (uint64, bool, error) {
	if g == nil || !g.native || w == nil {
		return 0, false, retainedalloc.ErrWorkRequired
	}
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*g))) {
		return 0, false, nil
	}
	if (!g.installed && !g.cancelled) || g.cleanupFailure != nil || g.metadata != expected || g.metadataOld != 0 {
		return 0, false, ErrGrowthStale
	}
	charge := g.metadataCharge
	if expected != nil && charge != NativeGrowthWrapperChargeV6() {
		return 0, false, ErrGrowthStale
	}
	g.metadata = nil
	g.metadataCharge = 0
	return charge, true, nil
}

func (g *Growth) valid(p *Pager) bool {
	return !p.closing && g.owner.Value() == p && g.source.Value() == p.atomicChunks.Load() &&
		g.file.Value() == p.file && g.count == p.numPages.Load() && len(p.chunks) == g.oldChunks &&
		g.verified.Value() == p.verified.Load() && g.prefetch.Value() == p.prefetched.Load() &&
		(g.dirtyOutput == nil || g.dirtyRevision == p.dirtyChunks.revision)
}

func (g *Growth) Step(p *Pager, w *iterator.OrdinalScanWork) (bool, error) {
	return g.StepWithInstall(p, w, 0, 0, nil)
}

// StepWithInstall joins a caller's already guarded, infallible authority install
// to pager publication. It admits both fixed tails once before any live change.
// The callback must acquire no locks, allocate nothing and cannot fail.
func (g *Growth) StepWithInstall(p *Pager, w *iterator.OrdinalScanWork, r, b uint64, install func()) (bool, error) {
	p.allocMu.Lock()
	defer p.allocMu.Unlock()
	return g.stepLocked(p, w, r, b, install)
}

// StepWithInstallAtCount rejects foreign logical growth before capturing the
// source, and keeps that same expected count protected through installation.
func (g *Growth) StepWithInstallAtCount(p *Pager, expected uint64, w *iterator.OrdinalScanWork, r, b uint64, install func()) (bool, error) {
	p.allocMu.Lock()
	defer p.allocMu.Unlock()
	return g.stepLockedAtCount(p, w, r, b, install, expected, true)
}

// InstallAtCount joins a no-growth caller install to the same pager guard. The
// callback obeys the same infallible contract as Growth.StepWithInstall.
func (p *Pager) InstallAtCount(expected uint64, w *iterator.OrdinalScanWork, r, b uint64, install func()) (bool, error) {
	if ok, e := pagerReserve(w, 2+r, 6*uint64(unsafe.Sizeof(Growth{}))+2048+b); !ok || e != nil {
		return false, e
	}
	p.allocMu.Lock()
	defer p.allocMu.Unlock()
	p.growMu.Lock()
	defer p.growMu.Unlock()
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.readOnly {
		return false, ErrReadOnly
	}
	if p.closing {
		return false, ErrGrowthClosed
	}
	if p.numPages.Load() != expected {
		return false, ErrGrowthStale
	}
	install()
	return true, nil
}

// Caller owns allocMu (ordinary allocation), or is a capacity-only grower.
func (g *Growth) stepLocked(p *Pager, w *iterator.OrdinalScanWork, r, b uint64, install func()) (bool, error) {
	return g.stepLockedAtCount(p, w, r, b, install, 0, false)
}

func (g *Growth) stepLockedAtCount(p *Pager, w *iterator.OrdinalScanWork, r, b uint64, install func(), expected uint64, checkCount bool) (bool, error) {
	if g.native && w == nil {
		return false, retainedalloc.ErrWorkRequired
	}
	if g.installed {
		return true, nil
	}
	if g.cancelled {
		return false, g.failure
	}
	if g.failure != nil {
		return g.finishFailure(w)
	}
	if ok, e := pagerReserve(w, 1, 2*uint64(unsafe.Sizeof(Growth{}))+1024); !ok || e != nil {
		return false, e
	}
	p.growMu.Lock()
	defer p.growMu.Unlock()
	p.mu.Lock()
	defer p.mu.Unlock()
	defer runtime.KeepAlive(p)
	if p.readOnly {
		return false, ErrReadOnly
	}
	if p.closing {
		g.failure = ErrGrowthClosed
		return g.finishFailure(w)
	}
	if checkCount && p.numPages.Load() != expected {
		g.failure = ErrGrowthStale
		return g.finishFailure(w)
	}
	if !g.captured {
		if ok, e := pagerReserve(w, 1, 2*uint64(unsafe.Sizeof(Growth{}))+1024); !ok || e != nil {
			return false, e
		}
		if ready, e := g.capture(p, w); !ready || e != nil {
			if !ready && e == nil || g.native && errors.Is(e, retainedalloc.ErrWorkRequired) {
				return false, e
			}
			g.failure = e
			return g.finishFailure(w)
		}
	} else if !g.valid(p) {
		g.failure = ErrGrowthStale
		return g.finishFailure(w)
	}
	for {
		switch g.phase {
		case 0:
			if g.totalChunks > g.oldChunks {
				if ok, e := pagerReserve(w, 1, uint64(g.totalChunks)*(48+2*uint64(unsafe.Sizeof(mappingOwner{})))+256); !ok || e != nil {
					return false, e
				}
				g.primary = make([][]byte, g.totalChunks)
				g.mappings = make([]mappingOwner, g.totalChunks)
				g.phase++
			} else {
				g.phase = 3
			}
		case 1:
			if ok, e := pagerReserve(w, 1, uint64(g.totalChunks)*48+256); !ok || e != nil {
				return false, e
			}
			g.atomicView = make([][]byte, g.totalChunks)
			g.phase++
		case 2:
			for g.position < g.oldChunks {
				if ok, e := pagerReserve(w, 4, 192+2*uint64(unsafe.Sizeof(mappingOwner{}))); !ok || e != nil {
					return false, e
				}
				c := p.chunks[g.position]
				g.primary[g.position] = c
				if g.position < len(p.mappings) {
					g.mappings[g.position] = p.mappings[g.position]
				}
				g.atomicView[g.position] = c
				g.position++
			}
			g.position = 0
			g.phase++
		case 3:
			if g.needVerified > g.oldVerified {
				if g.verifiedOutput == nil {
					if ok, e := pagerReserve(w, 1, uint64(g.needVerified)*48+256); !ok || e != nil {
						return false, e
					}
					g.verifiedOutput = &verifiedBitset{chunks: make([][]uint64, g.needVerified)}
				}
				for g.position < g.needVerified {
					if g.position < g.oldVerified {
						if ok, e := pagerReserve(w, 2, 144); !ok || e != nil {
							return false, e
						}
						g.verifiedOutput.chunks[g.position] = p.verified.Load().chunks[g.position]
					} else {
						if ok, e := pagerReserve(w, 1, 2*verifiedChunkWords*8+256); !ok || e != nil {
							return false, e
						}
						g.verifiedOutput.chunks[g.position] = make([]uint64, verifiedChunkWords)
					}
					g.position++
				}
			}
			g.position = 0
			g.phase++
		case 4:
			if g.needWords > g.oldPrefetch {
				if g.prefetchOutput == nil {
					if ok, e := pagerReserve(w, 1, uint64(g.needWords)*16+256); !ok || e != nil {
						return false, e
					}
					g.prefetchOutput = &prefetchBitset{words: make([]uint64, g.needWords)}
				}
				for g.position < g.oldPrefetch {
					if ok, e := pagerReserve(w, 1, 64); !ok || e != nil {
						return false, e
					}
					g.prefetchOutput.words[g.position] = atomic.LoadUint64(&p.prefetched.Load().words[g.position])
					g.position++
				}
			}
			g.position = 0
			g.phase++
		case 5:
			if g.needWords > len(p.dirtyChunks.words) {
				if g.dirtyOutput == nil {
					if ok, e := pagerReserve(w, 1, uint64(g.needWords)*16+512); !ok || e != nil {
						return false, e
					}
					g.dirtyOutput = make([]uint64, g.needWords)
					g.dirtyRevision = p.dirtyChunks.revision
					g.dirtyCount, g.dirtyLow, g.dirtyHigh = p.dirtyChunks.count, p.dirtyChunks.low, p.dirtyChunks.high
				}
				for g.position < len(p.dirtyChunks.words) {
					if ok, e := pagerReserve(w, 1, 64); !ok || e != nil {
						return false, e
					}
					g.dirtyOutput[g.position] = p.dirtyChunks.words[g.position]
					g.position++
				}
			}
			g.position = 0
			g.phase++
		case 6:
			if g.totalChunks > g.oldChunks && !p.memoryOnly {
				if ok, e := pagerReserve(w, 1, 2048); !ok || e != nil {
					return false, e
				}
				// Hold the file lifetime read guard during physical I/O;
				// concurrent dirty changes are checked again before publication.
				p.mu.Unlock()
				p.mu.RLock()
				var e error
				if !g.valid(p) {
					e = ErrGrowthStale
				} else {
					var info os.FileInfo
					info, e = p.file.Stat()
					if e == nil && info.Size() < g.capacityTarget {
						e = preallocateFile(p.file, g.capacityTarget)
						if e == nil {
							e = p.file.Truncate(g.capacityTarget)
						}
					}
				}
				p.mu.RUnlock()
				p.mu.Lock()
				if e == nil && !g.valid(p) {
					e = ErrGrowthStale
				}
				if e != nil {
					g.failure = e
					return g.finishFailure(w)
				}
			}
			g.mapped = g.oldChunks
			g.phase++
		case 7:
			for g.mapped < g.totalChunks {
				traffic := uint64(2048)
				if p.memoryOnly {
					traffic += 2 * uint64(p.chunkSize)
				} else if p.mmapPopulate {
					traffic += uint64(p.chunkSize)
				}
				if ok, e := pagerReserve(w, 3, traffic); !ok || e != nil {
					return false, e
				}
				var c []byte
				var mapping mappingOwner
				var e error
				if p.memoryOnly {
					c = make([]byte, p.chunkSize)
				} else {
					p.mu.Unlock()
					p.mu.RLock()
					if !g.valid(p) {
						e = ErrGrowthStale
					} else {
						mapping, e = mapConstructor(p.file.Fd(), int64(g.mapped)*p.chunkSize, int(p.chunkSize), p.mmapPopulate, false)
						c = mapping.data
						if e == nil {
							madviseChunk(c)
						}
					}
					p.mu.RUnlock()
					p.mu.Lock()
				}
				if e != nil {
					g.failure = e
					return g.finishFailure(w)
				}
				g.primary[g.mapped] = c
				g.mappings[g.mapped] = mapping
				g.atomicView[g.mapped] = c
				g.mapped++
				if !g.valid(p) {
					g.failure = ErrGrowthStale
					return g.finishFailure(w)
				}
			}
			g.phase++
		case 8:
			// Prepare the immutable carrier before the final swap; no allocation there.
			if g.primary != nil {
				if ok, e := pagerReserve(w, 1, 256); !ok || e != nil {
					return false, e
				}
				g.preparedView = &chunkList{data: g.atomicView}
				g.phase = growthReady
			} else {
				g.phase = growthReady
			}
		case growthReady:
			if ok, e := pagerReserve(w, 2+r, 6*uint64(unsafe.Sizeof(Growth{}))+2048+b); !ok || e != nil {
				return false, e
			}
			// Same uninterrupted mu section as the validation at this invocation's cut.
			// No source or dirty mutation can interleave with the following publication.
			if !g.valid(p) {
				g.failure = ErrGrowthStale
				return g.finishFailure(w)
			}
			if g.native && g.metadata != nil {
				// Readers of replaced descriptors must drain before the SAME
				// owner admission and fixed infallible pager/Claim swap.
				p.metadataReadMu.Lock()
				ready, e := g.metadata.RemoveWithTeardownWork(g.metadataOld, func() {
					g.installEffectsV6(p)
					if install != nil {
						install()
					}
					g.metadataCharge = NativeGrowthWrapperChargeV6()
					g.metadataOld = 0
				}, w)
				p.metadataReadMu.Unlock()
				return ready, e
			}
			g.install(p)
			if install != nil {
				install()
			}
			return true, nil
		}
	}
}

func (g *Growth) capture(p *Pager, w *iterator.OrdinalScanWork) (bool, error) {
	count := p.numPages.Load()
	local := p.localPageCount(max(count, g.targetPages))
	if !g.logical {
		local = p.localPageCount(count)
	}
	if local > math.MaxInt64/page.PageSize {
		return false, fmt.Errorf("pager: growth size overflow")
	}
	capacity := int64(len(p.chunks)) * p.chunkSize
	target := max(capacity, g.capacityTarget)
	if g.logical {
		target = max(target, int64(local)*page.PageSize)
	}
	if g.policy {
		target = max(target, p.growTarget.Load())
	}
	if target > math.MaxInt64-(p.chunkSize-1) {
		return false, fmt.Errorf("pager: growth size overflow")
	}
	target = ((target + p.chunkSize - 1) / p.chunkSize) * p.chunkSize
	if g.policy && p.growWake != nil && p.chunkSize >= minAsyncPregrowChunkSize && target-int64(local)*page.PageSize < p.chunkSize/2 {
		if target > math.MaxInt64-p.chunkSize {
			return false, fmt.Errorf("pager: pregrowth size overflow")
		}
		target += p.chunkSize
	}
	g.owner = weak.Make(p)
	g.source = weak.Make(p.atomicChunks.Load())
	g.file = weak.Make(p.file)
	g.verified = weak.Make(p.verified.Load())
	g.prefetch = weak.Make(p.prefetched.Load())
	g.memoryOnly = p.memoryOnly
	g.count = count
	g.oldChunks = len(p.chunks)
	g.totalChunks = int(target / p.chunkSize)
	g.capacityTarget = target
	if v := p.verified.Load(); v != nil {
		g.oldVerified = len(v.chunks)
	}
	g.needVerified = int((local + verifiedChunkPages - 1) / verifiedChunkPages)
	if v := p.prefetched.Load(); v != nil {
		g.oldPrefetch = len(v.words)
	}
	g.needWords = (g.totalChunks + 63) / 64
	if g.metadata != nil {
		alloc := retainedalloc.AllocationCharge
		ptr := uint64(unsafe.Sizeof(uintptr(0)))
		var next, old uint64
		if g.totalChunks > g.oldChunks {
			next += 2*alloc(uint64(g.totalChunks)*3*ptr) + alloc(uint64(unsafe.Sizeof(chunkList{}))) + alloc(uint64(g.totalChunks)*uint64(unsafe.Sizeof(mappingOwner{})))
			old += alloc(uint64(cap(p.chunks))*3*ptr) + alloc(uint64(cap(p.mappings))*uint64(unsafe.Sizeof(mappingOwner{})))
			if prior := p.atomicChunks.Load(); prior != nil {
				old += alloc(uint64(unsafe.Sizeof(chunkList{})))
				if len(p.chunks) == 0 || len(prior.data) == 0 || &p.chunks[0] != &prior.data[0] {
					old += alloc(uint64(cap(prior.data)) * 3 * ptr)
				}
			}
		}
		if g.needVerified > g.oldVerified {
			next += alloc(uint64(unsafe.Sizeof(verifiedBitset{}))) + alloc(uint64(g.needVerified)*3*ptr) + uint64(g.needVerified-g.oldVerified)*alloc(verifiedChunkWords*8)
			if prior := p.verified.Load(); prior != nil {
				old += alloc(uint64(unsafe.Sizeof(verifiedBitset{}))) + alloc(uint64(cap(prior.chunks))*3*ptr)
			}
		}
		if g.needWords > g.oldPrefetch {
			next += alloc(uint64(unsafe.Sizeof(prefetchBitset{}))) + alloc(uint64(g.needWords)*8)
			if prior := p.prefetched.Load(); prior != nil {
				old += alloc(uint64(unsafe.Sizeof(prefetchBitset{}))) + alloc(uint64(cap(prior.words))*8)
			}
		}
		if g.needWords > len(p.dirtyChunks.words) {
			next += alloc(uint64(g.needWords) * 8)
			old += alloc(uint64(cap(p.dirtyChunks.words)) * 8)
		}
		if next > ^uint64(0)-g.metadataCharge {
			return false, retainedalloc.ErrCapacity
		}
		if g.native {
			if ready, e := retainedalloc.AddWithOrdinalWork(g.metadata, next, w); !ready || e != nil {
				return false, e
			}
		} else if err := g.metadata.Add(next); err != nil {
			return false, err
		}
		g.metadataCharge += next
		g.metadataOld = old
	}
	g.captured = true
	return true, nil
}

func (g *Growth) install(p *Pager) {
	if g.metadata != nil {
		p.metadataReadMu.Lock()
		defer p.metadataReadMu.Unlock()
	}
	g.installEffectsV6(p)
	if g.metadata != nil {
		g.metadata.Remove(g.metadataOld + NativeGrowthWrapperChargeV6())
		g.metadataCharge = 0
		g.metadataOld = 0
	}
}

// Caller owns pager guards and, for governed metadata, metadataReadMu. No
// lock, allocation, owner call or fallible operation occurs in these effects.
func (g *Growth) installEffectsV6(p *Pager) {
	if g.primary != nil {
		p.chunks = g.primary
		p.mappings = g.mappings
		p.atomicChunks.Store(g.preparedView)
	}
	if g.dirtyOutput != nil {
		p.dirtyChunks.words = g.dirtyOutput
		p.dirtyChunks.count = g.dirtyCount
		p.dirtyChunks.low = g.dirtyLow
		p.dirtyChunks.high = g.dirtyHigh
		p.dirtyChunks.revision++
	}
	if g.prefetchOutput != nil {
		p.prefetched.Store(g.prefetchOutput)
	}
	if g.verifiedOutput != nil {
		p.verified.Store(g.verifiedOutput)
	}
	if g.logical && g.targetPages > g.count {
		p.installLogicalCountLocked(g.targetPages)
	}
	g.installed = true
	g.primary = nil
	g.mappings = nil
	g.atomicView = nil
	g.preparedView = nil
	g.dirtyOutput = nil
	g.prefetchOutput = nil
	g.verifiedOutput = nil
}

func (g *Growth) finishFailure(w *iterator.OrdinalScanWork) (bool, error) {
	done, e := g.Cancel(w)
	if !done || e != nil {
		return false, e
	}
	return false, g.failure
}

// Cancel admits each private unmap and clears that ownership only on success.
// It never touches copied source mappings, and needs no live pager/file lease.
func (g *Growth) Cancel(w *iterator.OrdinalScanWork) (bool, error) {
	if g != nil && g.native && w == nil {
		return false, retainedalloc.ErrWorkRequired
	}
	if g == nil || g.installed || g.cancelled {
		return true, nil
	}
	if g.cleanupFailure != nil {
		return false, g.cleanupFailure
	}
	for g.mapped > g.oldChunks {
		i := g.mapped - 1
		c := g.primary[i]
		control := 2*uint64(unsafe.Sizeof(mappingOwner{})) + 128
		if c != nil && !g.memoryOnly {
			m := &g.mappings[i]
			if m.issued {
				amount := uint64(m.remaining())
				if w != nil {
					available := uint64(0)
					if w.Bytes < w.ByteLimit && w.ByteLimit-w.Bytes > control {
						available = w.ByteLimit - w.Bytes - control
					}
					if amount > available {
						amount = available
					}
				}
				amount = amount / uint64(os.Getpagesize()) * uint64(os.Getpagesize())
				if amount == 0 {
					return false, nil
				}
				if ok, e := pagerReserve(w, 1, control+amount); !ok || e != nil {
					return false, e
				}
				if e := unmapConstructor(m, uintptr(amount)); e != nil {
					g.cleanupFailure = e
					if g.metadata != nil {
						g.metadata.CleanupFailed()
					}
					return false, e
				}
				if m.remaining() != 0 {
					continue
				}
			} else {
				if ok, e := pagerReserve(w, 1, control+uint64(len(c))); !ok || e != nil {
					return false, e
				}
				if e := munmapFile(c); e != nil {
					g.cleanupFailure = e
					if g.metadata != nil {
						g.metadata.CleanupFailed()
					}
					return false, e
				}
			}
		} else {
			if ok, e := pagerReserve(w, 1, control); !ok || e != nil {
				return false, e
			}
		}
		g.primary[i] = nil
		g.atomicView[i] = nil
		g.mappings[i] = mappingOwner{}
		g.mapped--
	}
	if ok, e := pagerReserve(w, 1, 6*uint64(unsafe.Sizeof(Growth{}))+512); !ok || e != nil {
		return false, e
	}
	failure := g.failure
	owner, charge := g.metadata, g.metadataCharge
	if g.native {
		wrapper := uint64(0)
		if owner != nil {
			wrapper = NativeGrowthWrapperChargeV6()
		}
		if charge < wrapper {
			return false, retainedalloc.ErrCapacity
		}
		scrub := func() {
			*g = Growth{native: true, cancelled: true, failure: failure, metadata: owner, metadataCharge: wrapper}
		}
		if owner != nil {
			return owner.RemoveWithTeardownWork(charge-wrapper, scrub, w)
		}
		scrub()
		return true, nil
	}
	*g = Growth{cancelled: true, failure: failure}
	if owner != nil {
		owner.Remove(charge)
	}
	return true, nil
}

// installCountWithinCapacity is the original logical publication under the
// same growth and pager guards. It only admits an already represented count;
// every backing-expansion route continues through Growth.
func (p *Pager) installCountWithinCapacity(target uint64) (bool, error) {
	return p.installCountWithinCapacityWithWorkV6(target, nil)
}

// GrowWithinCapacityWithWorkV6 performs the original logical count install,
// with its original alloc->grow->pager exclusion and without constructing a
// Growth. A false result leaves the count unchanged: either work was refused
// or actual backing needs Growth. It never schedules new background growth.
// The native caller must retain original allocator authority for target; this
// operation grants no reservation or page ownership of its own.
func (p *Pager) GrowWithinCapacityWithWorkV6(target uint64, w *iterator.OrdinalScanWork) (bool, error) {
	if p == nil || w == nil {
		return false, ErrGrowthStale
	}
	if ok, err := pagerReserve(w, 1, uint64(unsafe.Sizeof(*p))+16); !ok || err != nil {
		return false, err
	}
	p.allocMu.Lock()
	defer p.allocMu.Unlock()
	if p.readOnly {
		return false, ErrReadOnly
	}
	if target <= p.numPages.Load() {
		return true, nil
	}
	return p.installCountWithinCapacityWithWorkV6(target, w)
}

func (p *Pager) installCountWithinCapacityWithWorkV6(target uint64, w *iterator.OrdinalScanWork) (bool, error) {
	p.growMu.Lock()
	defer p.growMu.Unlock()
	p.mu.Lock()
	defer p.mu.Unlock()
	// The pager, verified/prefetch headers and dirty directory are fixed
	// operands. No backing traversal, allocation, mapping or file extension is
	// reachable here. Admit their inspection and the final atomic count store
	// before reading any containing header or publishing the count.
	if ok, err := pagerReserve(w, 5, uint64(unsafe.Sizeof(*p))+uint64(unsafe.Sizeof(verifiedBitset{}))+uint64(unsafe.Sizeof(prefetchBitset{}))+uint64(unsafe.Sizeof(dirtyChunkBits{}))+32); !ok || err != nil {
		return false, err
	}
	if ready, err := p.validateCountWithinCapacityLockedV6(target, w != nil); !ready || err != nil {
		return false, err
	}
	p.installLogicalCountLocked(target)
	return true, nil
}

// NativeCapacityCountWorkV6 is the upper branch of the original capacity-only
// count install. It includes the early allocMu header and the full locked probe.
func NativeCapacityCountWorkV6() (uint64, uint64) {
	return 6, 2*uint64(unsafe.Sizeof(Pager{})) + uint64(unsafe.Sizeof(verifiedBitset{})) + uint64(unsafe.Sizeof(prefetchBitset{})) + uint64(unsafe.Sizeof(dirtyChunkBits{})) + 48
}

// ValidateNativeCountCapacityWithWorkV6 validates that SAME later operation
// before activation without publishing PageCount, extending the OS file or
// scheduling growth. A retained original Snapshot prevents pager replacement;
// legal intervening growth can only increase this covered capacity.
func (p *Pager) ValidateNativeCountCapacityWithWorkV6(target uint64, w *iterator.OrdinalScanWork) (bool, error) {
	if p == nil || w == nil {
		return false, ErrGrowthStale
	}
	r, b := NativeCapacityCountWorkV6()
	if !w.Reserve(r, b) {
		return false, nil
	}
	p.allocMu.Lock()
	defer p.allocMu.Unlock()
	p.growMu.Lock()
	defer p.growMu.Unlock()
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.readOnly {
		return false, ErrReadOnly
	}
	if target <= p.numPages.Load() {
		return true, nil
	}
	return p.validateCountWithinCapacityLockedV6(target, true)
}

func (p *Pager) validateCountWithinCapacityLockedV6(target uint64, bounded bool) (bool, error) {
	if p.readOnly {
		return false, ErrReadOnly
	}
	if p.closing {
		return false, ErrGrowthClosed
	}
	local := p.localPageCount(target)
	if local > math.MaxInt64/page.PageSize {
		return false, fmt.Errorf("pager: growth size overflow")
	}
	// The native capacity-only entry must not silently remove the ordinary
	// pre-grow policy. Where allocLocked would schedule background growth, the
	// native caller needs that separate finite operation instead. Ordinary
	// nil-work allocation retains its original policy below this helper.
	if bounded && p.growWake != nil && p.chunkSize >= minAsyncPregrowChunkSize && int64(len(p.chunks))*p.chunkSize-int64(local)*page.PageSize < p.chunkSize/2 {
		return false, nil
	}
	if int64(local)*page.PageSize > int64(len(p.chunks))*p.chunkSize {
		return false, nil
	}
	verified := p.verified.Load()
	if verified == nil || uint64(len(verified.chunks)) < (local+verifiedChunkPages-1)/verifiedChunkPages {
		return false, nil
	}
	words := (len(p.chunks) + 63) / 64
	prefetched := p.prefetched.Load()
	if prefetched == nil || len(prefetched.words) < words || len(p.dirtyChunks.words) < words {
		return false, nil
	}
	return true, nil
}
func (p *Pager) installLogicalCountLocked(target uint64) {
	if target > p.numPages.Load() {
		p.numPages.Store(target)
	}
}
