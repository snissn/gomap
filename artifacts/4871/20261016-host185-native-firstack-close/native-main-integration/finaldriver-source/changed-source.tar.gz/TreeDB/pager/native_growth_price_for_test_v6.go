package pager

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/page"
	"math"
	"os"
	"unsafe"
)

// NativePreCursorGrowthForTestV6 returns protected scalar operands only.
// In particular DATA metadata absence is independent of the PRIMARY owner.
type NativePreCursorGrowthForTestV6 struct {
	PageCount, PageIDBase, Chunks, ChunkSize, GrowTarget, Verified, PrefetchWords, DirtyWords uint64
	Async, Populate, DataMetadataAbsent, MetadataSameExpected, FileBacked, Complete           bool
}

func (p *Pager) MaintenanceNativePreCursorGrowthForTestV6(w *iterator.OrdinalScanWork) (NativePreCursorGrowthForTestV6, bool) {
	return p.MaintenanceNativePreCursorGrowthOwnerForTestV6(nil, w)
}
func (p *Pager) MaintenanceNativePreCursorGrowthOwnerForTestV6(expected *retainedalloc.Owner, w *iterator.OrdinalScanWork) (g NativePreCursorGrowthForTestV6, ready bool) {
	if p == nil || w == nil || !w.Reserve(2, 2*uint64(unsafe.Sizeof(*p))+2*uint64(unsafe.Sizeof(g))+uint64(unsafe.Sizeof(verifiedBitset{}))+uint64(unsafe.Sizeof(prefetchBitset{}))) {
		return g, false
	}
	p.mu.RLock()
	defer p.mu.RUnlock()
	g.PageCount = p.numPages.Load()
	g.PageIDBase = p.pageIDBase
	g.Chunks = uint64(len(p.chunks))
	target := p.growTarget.Load()
	if p.chunkSize <= 0 || target < 0 {
		return g, true
	}
	g.ChunkSize = uint64(p.chunkSize)
	g.GrowTarget = uint64(target)
	if v := p.verified.Load(); v != nil {
		g.Verified = uint64(len(v.chunks))
	}
	if v := p.prefetched.Load(); v != nil {
		g.PrefetchWords = uint64(len(v.words))
	}
	g.DirtyWords = uint64(len(p.dirtyChunks.words))
	g.Async = p.growWake != nil
	g.Populate = p.mmapPopulate
	p.immutableReadRoots.mu.RLock()
	g.DataMetadataAbsent = p.immutableReadRoots.retention == nil
	g.MetadataSameExpected = p.immutableReadRoots.retention == expected
	p.immutableReadRoots.mu.RUnlock()
	g.FileBacked = p.file != nil && !p.memoryOnly && !p.closing && !p.readOnly
	g.Complete = g.FileBacked && g.MetadataSameExpected && g.PageIDBase == 0
	return g, true
}

type NativeGrowthBoundForTestV6 struct {
	Chunks, Verified, Words, Records, Bytes, CancelRecords, CancelBytes uint64
	Complete                                                            bool
}

// NativeGrowthPriceForTestV6 is the sum of the original acyclic phase rows,
// with one iteration of each persistent position/mapped loop. Parent Append
// and leaf prefixes must be added by their callers.
func NativeGrowthPriceForTestV6(g NativePreCursorGrowthForTestV6, highWater, outputPages uint64) (v NativeGrowthBoundForTestV6) {
	if !g.Complete || g.ChunkSize == 0 || highWater > math.MaxInt64/page.PageSize {
		return v
	}
	add := func(a, b uint64) (uint64, bool) {
		if b > math.MaxUint64-a {
			return 0, false
		}
		return a + b, true
	}
	mul := func(a, b uint64) (uint64, bool) {
		if b != 0 && a > math.MaxUint64/b {
			return 0, false
		}
		return a * b, true
	}
	ceil := func(a, b uint64) uint64 {
		n := a / b
		if a%b != 0 {
			n++
		}
		return n
	}
	logical := highWater * page.PageSize
	var ok bool
	v.Chunks = max(g.Chunks, ceil(g.GrowTarget, g.ChunkSize), ceil(logical, g.ChunkSize))
	if v.Chunks, ok = add(v.Chunks, outputPages); !ok {
		return v
	}
	capacity, ok := mul(v.Chunks, g.ChunkSize)
	if !ok || capacity > math.MaxInt64 || capacity > math.MaxInt64-g.ChunkSize {
		return v
	}
	v.Verified = max(g.Verified, ceil(highWater, verifiedChunkPages))
	v.Words = max(g.PrefetchWords, g.DirtyWords, ceil(v.Chunks, 64))
	kb, ok := mul(v.Chunks, 48+2*uint64(unsafe.Sizeof(mappingOwner{})))
	if !ok {
		return v
	}
	ab, ok := mul(48, v.Chunks)
	if !ok {
		return v
	}
	vb, ok := mul(48, v.Verified)
	if !ok {
		return v
	}
	wb, ok := mul(16, v.Words)
	if !ok {
		return v
	}
	if kb > math.MaxUint64-256 || ab > math.MaxUint64-256 || vb > math.MaxUint64-256 || wb > math.MaxUint64-512 || g.ChunkSize > math.MaxUint64-2048 {
		return NativeGrowthBoundForTestV6{}
	}
	populate := uint64(0)
	if g.Populate {
		populate = g.ChunkSize
	}
	terms := [...][2]uint64{
		{1, 6*uint64(unsafe.Sizeof(Growth{})) + 256},  // NewGrowth
		{2, 4*uint64(unsafe.Sizeof(Growth{})) + 2048}, // entry and capture
		{1, kb + 256}, {1, ab + 256}, {4, 192 + 2*uint64(unsafe.Sizeof(mappingOwner{}))},
		{1, vb + 256}, {2, 144}, {1, 2*verifiedChunkWords*8 + 256},
		{1, wb + 256}, {1, 64}, {1, wb + 512}, {1, 64}, {1, 2048}, {3, 2048 + populate}, {1, 256},
		{4, 6*uint64(unsafe.Sizeof(Growth{})) + 2112},
	}
	for _, n := range terms {
		if v.Records, ok = add(v.Records, n[0]); !ok {
			return NativeGrowthBoundForTestV6{}
		}
		if v.Bytes, ok = add(v.Bytes, n[1]); !ok {
			return NativeGrowthBoundForTestV6{}
		}
	}
	v.CancelRecords = 2
	if v.CancelBytes, ok = add(2*uint64(unsafe.Sizeof(mappingOwner{}))+128+6*uint64(unsafe.Sizeof(Growth{}))+512, max(g.ChunkSize, uint64(os.Getpagesize()))); !ok {
		return NativeGrowthBoundForTestV6{}
	}
	v.Complete = true
	return v
}

// NativePrimaryGrowthPriceForTestV6 adds the actual finite same-owner growth,
// atomic installation/cancellation shrink and child accounting handoff. The
// original phase geometry is shared; only its explicit origin differs.
func NativePrimaryGrowthPriceForTestV6(g NativePreCursorGrowthForTestV6, highWater, addR, addB, shrinkR, shrinkB uint64) (v NativeGrowthBoundForTestV6) {
	if !g.Complete || !g.MetadataSameExpected || g.DataMetadataAbsent {
		return
	}
	v = NativeGrowthPriceForTestV6(g, highWater, 1)
	if !v.Complete {
		return
	}
	rows := [...][2]uint64{{addR, addB}, {addR, addB}, {shrinkR, shrinkB}, {1, 2 * uint64(unsafe.Sizeof(Growth{}))}}
	for _, n := range rows {
		if n[0] > ^uint64(0)-v.Records || n[1] > ^uint64(0)-v.Bytes {
			return NativeGrowthBoundForTestV6{}
		}
		v.Records += n[0]
		v.Bytes += n[1]
	}
	if shrinkR > ^uint64(0)-v.CancelRecords-1 || shrinkB > ^uint64(0)-v.CancelBytes-2*uint64(unsafe.Sizeof(Growth{})) {
		return NativeGrowthBoundForTestV6{}
	}
	v.CancelRecords += shrinkR + 1
	v.CancelBytes += shrinkB + 2*uint64(unsafe.Sizeof(Growth{}))
	return
}
