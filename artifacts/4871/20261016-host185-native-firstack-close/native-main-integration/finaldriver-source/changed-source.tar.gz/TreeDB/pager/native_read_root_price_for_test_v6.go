package pager

import "unsafe"

// NativeReadRootUnitForTestV6 prices the original nonpersistent protected
// lookup/removal scans. nodes includes the terminal nil lookup sentinel.
func NativeReadRootUnitForTestV6(nodes uint64) (lookupRecords, lookupBytes, removeRecords, removeBytes uint64, complete bool) {
	p := uint64(unsafe.Sizeof((*primaryReadRootEntryV6)(nil)))
	e := uint64(unsafe.Sizeof(primaryReadRootEntryV6{}))
	t := uint64(unsafe.Sizeof(primaryReadRootTableV6{}))
	if nodes == ^uint64(0) || nodes > (^uint64(0)-128)/(p+2*e) || nodes > (^uint64(0)-t)/(p+e) {
		return
	}
	return 1 + nodes, t + nodes*(p+e), 1 + nodes, 128 + nodes*(p+2*e), true
}

// NativeReadRootConstructionHeaderBytesForTestV6 forwards the actual original
// table/entry/interface row; lookup traversal remains priced separately.
func NativeReadRootConstructionHeaderBytesForTestV6() uint64 {
	return 2*uint64(unsafe.Sizeof(primaryReadRootTableV6{})) + 2*uint64(unsafe.Sizeof(primaryReadRootEntryV6{})) + 2*uint64(unsafe.Sizeof(interface{}(nil)))
}
