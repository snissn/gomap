package pager

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/page"
	"testing"
	"unsafe"
)

// These are original standalone Growth/Owner primitives, not DB publication.
func TestNativeGrowthOriginalOwnerAdmissionV6(t *testing.T) {
	for _, bound := range []bool{false, true} {
		name := "unbound"
		if bound {
			name = "concrete"
		}
		t.Run(name, func(t *testing.T) {
			var owner retainedalloc.Owner
			owner.Initialize(128)
			if bound {
				budget, e := memtable.NewCOWBudget(memtable.DefaultCOWLimits())
				if e != nil {
					t.Fatal(e)
				}
				defer budget.Close()
				enrollment, e := owner.Enroll(budget)
				if e != nil {
					t.Fatal(e)
				}
				defer enrollment.Close()
			}
			p := &Pager{memoryOnly: true, chunkSize: page.PageSize}
			p.atomicChunks.Store(&chunkList{})
			p.immutableReadRoots.retention = &owner
			fresh := func(n uint64) *iterator.OrdinalScanWork {
				return &iterator.OrdinalScanWork{RecordLimit: n, ByteLimit: 1 << 20}
			}
			baseline := owner.Bytes()
			if g, ready, e := NewNativeGrowthForPagerV6(p, 0, fresh(1)); g != nil || ready || e != nil || owner.Bytes() != baseline {
				t.Fatal("wrapper growth refusal", ready, e)
			}
			// The exact bound comes from SAME concrete Add, not an enlarged public cap.
			resize := 2*uint64(unsafe.Sizeof(memtable.COWExternalLease{})) + 2*uint64(unsafe.Sizeof(memtable.COWBudget{}))
			bindings := uint64(0)
			if bound {
				bindings = 1
			}
			ar, ab, ok := retainedalloc.NativeOwnerGrowthPriceForTestV6(bindings, resize)
			if !ok {
				t.Fatal("price overflow")
			}
			sr, sb, ok := retainedalloc.NativeAtomicRemovalPriceForTestV6(bindings, resize)
			if !ok {
				t.Fatal("shrink overflow")
			}
			g, ready, e := NewNativeGrowthForPagerV6(p, 0, &iterator.OrdinalScanWork{RecordLimit: 1 + ar, ByteLimit: 6*uint64(unsafe.Sizeof(Growth{})) + 256 + ab})
			if !ready || e != nil || g == nil || owner.Bytes() != baseline+NativeGrowthWrapperChargeV6() {
				t.Fatal("wrapper", ready, e)
			}
			// Capture's existing two prefixes are paid, but not its original Owner Add.
			if ready, e = g.Step(p, fresh(2)); ready || e != nil || g.captured || g.failure != nil || owner.Bytes() != baseline+NativeGrowthWrapperChargeV6() {
				t.Fatal("capture refusal changed custody", ready, e)
			}
			// Empty target has no physical/backing work. All actual prefixes plus Add
			// fit, while final whole shrink has no remaining record: no install callback.
			installed := 0
			w := &iterator.OrdinalScanWork{RecordLimit: 4 + ar, ByteLimit: 4*uint64(unsafe.Sizeof(Growth{})) + 2048 + ab + 6*uint64(unsafe.Sizeof(Growth{})) + 2048}
			if ready, e = g.StepWithInstall(p, w, 0, 0, func() { installed++ }); ready || e != nil || !g.captured || g.installed || installed != 0 || g.phase != growthReady {
				t.Fatal("final admission refusal", ready, e, g.phase, w)
			}
			before := owner.Bytes()
			w = &iterator.OrdinalScanWork{RecordLimit: 3 + sr, ByteLimit: 8*uint64(unsafe.Sizeof(Growth{})) + 3072 + sb}
			if ready, e = g.StepWithInstall(p, w, 0, 0, func() { installed++ }); !ready || e != nil || !g.installed || installed != 1 || owner.Bytes() != before {
				t.Fatal("install", ready, e)
			}
			if ready, e = g.StepWithInstall(p, fresh(0), 0, 0, func() { installed++ }); !ready || e != nil || installed != 1 {
				t.Fatal("install replay", ready, e)
			}
			if charge, ready, e := g.DetachNativeAccountingV6(&owner, fresh(0)); charge != 0 || ready || e != nil || g.metadata != &owner || owner.Bytes() != before {
				t.Fatal("handoff refusal", ready, e)
			}
			charge, ready, e := g.DetachNativeAccountingV6(&owner, fresh(1))
			if !ready || e != nil || charge != NativeGrowthWrapperChargeV6() || owner.Bytes() != before {
				t.Fatal("handoff", ready, e)
			}
			g = nil // original surviving parent clears child alias before typed refund
			var removal retainedalloc.RemovalWork
			for i := 0; i < 8; i++ {
				if ready, e := owner.RemoveWork(charge, &removal, fresh(32)); e != nil {
					t.Fatal(e)
				} else if ready {
					break
				} else if i == 7 {
					t.Fatal("refund stalled")
				}
			}
			if owner.Bytes() != baseline {
				t.Fatal("wrapper debit mismatch")
			}
			// A second actual Growth exercises cancelled wrapper accounting independently.
			g, ready, e = NewNativeGrowthForPagerV6(p, 0, &iterator.OrdinalScanWork{RecordLimit: 1 + ar, ByteLimit: 6*uint64(unsafe.Sizeof(Growth{})) + 256 + ab})
			if !ready || e != nil {
				t.Fatal(ready, e)
			}
			if ready, e = g.Cancel(fresh(1)); ready || e != nil || g.cancelled || owner.Bytes() != baseline+NativeGrowthWrapperChargeV6() {
				t.Fatal("cancel refusal", ready, e)
			}
			if ready, e = g.Cancel(&iterator.OrdinalScanWork{RecordLimit: 1 + sr, ByteLimit: 6*uint64(unsafe.Sizeof(Growth{})) + 512 + sb}); !ready || e != nil || !g.cancelled || g.metadataCharge != NativeGrowthWrapperChargeV6() {
				t.Fatal("cancel", ready, e)
			}
			charge, ready, e = g.DetachNativeAccountingV6(&owner, fresh(1))
			if !ready || e != nil {
				t.Fatal(ready, e)
			}
			g = nil
			var last retainedalloc.RemovalWork
			for i := 0; i < 8; i++ {
				if ready, e := owner.RemoveWork(charge, &last, fresh(32)); e != nil {
					t.Fatal(e)
				} else if ready {
					break
				} else if i == 7 {
					t.Fatal("cancel refund stalled")
				}
			}
			if owner.Bytes() != baseline {
				t.Fatal("cancel wrapper debit mismatch")
			}
		})
	}
}
