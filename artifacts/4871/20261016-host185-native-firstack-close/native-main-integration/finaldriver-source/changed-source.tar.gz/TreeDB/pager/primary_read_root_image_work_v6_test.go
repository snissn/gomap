package pager

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"testing"
)

func TestPrimaryReadRootImageLookupAdmissionV6(t *testing.T) {
	t.Run("empty", func(t *testing.T) {
		p := &Pager{}
		if image, found, ready := p.primaryReadRootImageWithWorkV6(PrimaryReadRootLocalBaseV6, &iterator.OrdinalScanWork{RecordLimit: 1, ByteLimit: 1 << 20}); !ready || found || image != nil {
			t.Fatal("empty", found, ready)
		}
	})
	for _, missing := range []bool{false, true} {
		name := "present"
		if missing {
			name = "missing"
		}
		t.Run(name, func(t *testing.T) {
			p := &Pager{}
			image := []byte{1, 2, 3}
			a, b := &struct{}{}, &struct{}{}
			tail := &primaryReadRootEntryV6{id: PrimaryReadRootLocalBaseV6 + 2, image: image, owner: a}
			head := &primaryReadRootEntryV6{id: PrimaryReadRootLocalBaseV6 + 1, image: []byte{4}, owner: b, next: tail}
			p.immutableReadRoots.heads = []*primaryReadRootEntryV6{head}
			p.immutableReadRoots.count = 2
			target := tail.id
			if missing {
				target++
			}
			for limit := uint64(0); limit < 4; limit++ {
				w := &iterator.OrdinalScanWork{RecordLimit: limit + 1, ByteLimit: 1 << 20}
				got, found, ready := p.primaryReadRootImageWithWorkV6(target, w)
				want := uint64(3)
				if missing {
					want = 4
				}
				if ready != (limit+1 >= want) || found != (ready && !missing) {
					t.Fatalf("limit%d found%v ready%v", limit+1, found, ready)
				}
				if found && &got[0] != &image[0] {
					t.Fatal("image replaced")
				}
				if p.immutableReadRoots.heads[0] != head || head.next != tail || tail.owner != a || head.owner != b || p.immutableReadRoots.count != 2 {
					t.Fatal("lookup consumed custody")
				}
			}
			got, found := p.primaryReadRootImageV6(target)
			if found == missing || found && &got[0] != &image[0] {
				t.Fatal("ordinary lookup changed")
			}
		})
	}
}
