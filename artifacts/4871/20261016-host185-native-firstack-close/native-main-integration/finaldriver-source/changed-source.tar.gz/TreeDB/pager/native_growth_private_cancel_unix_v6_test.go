//go:build !windows

package pager

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"path/filepath"
	"testing"
)

func TestNativeGrowthPrivateBackingCancelCustodyV6(t *testing.T) {
	p, err := Open(filepath.Join(t.TempDir(), "index.db"), 4<<20)
	if err != nil {
		t.Fatal(err)
	}
	defer p.Close()
	p.QuiesceBackgroundGrowth()
	var owner retainedalloc.Owner
	owner.Initialize(128)
	p.immutableReadRoots.retention = &owner
	baseline := owner.Bytes()
	fresh := func(n uint64) *iterator.OrdinalScanWork {
		return &iterator.OrdinalScanWork{RecordLimit: n, ByteLimit: 1 << 20}
	}
	g, ready, err := NewNativeGrowthForPagerV6(p, 2, fresh(32))
	if !ready || err != nil {
		t.Fatal(ready, err)
	}
	for turn := 0; turn < 100; turn++ {
		done, e := g.Step(p, fresh(4))
		if e != nil {
			t.Fatal(e)
		}
		if g.mapped > g.oldChunks {
			break
		}
		if done {
			t.Fatal("installed before private mapping pause")
		}
		if turn == 99 {
			t.Fatal("private mapping not reached")
		}
	}
	if g.installed || len(p.chunks) != 0 || g.metadataCharge <= NativeGrowthWrapperChargeV6() || g.primary == nil || g.mappings == nil {
		t.Fatal("missing actual private backing")
	}
	peak := owner.Bytes()
	oldCount := p.PageCount()
	partial := false
	// Persistent physical unmaps precede the final whole accounting shrink.
	// Four records cannot satisfy that final shrink; descriptors/charge survive.
	for turn := 0; turn < 100; turn++ {
		done, e := g.Cancel(fresh(4))
		if e != nil || done {
			t.Fatal("expected final accounting refusal", done, e)
		}
		if g.mapped == g.oldChunks {
			break
		}
		partial = true
		if turn == 99 {
			t.Fatal("private unmap did not advance")
		}
	}
	if !partial || g.cancelled || g.primary == nil || g.mappings == nil || owner.Bytes() != peak || p.PageCount() != oldCount || len(p.chunks) != 0 {
		t.Fatal("unmap/refusal discarded retained descriptor custody")
	}
	if done, e := g.Cancel(fresh(32)); !done || e != nil || !g.cancelled || g.primary != nil || g.mappings != nil || owner.Bytes() != baseline+NativeGrowthWrapperChargeV6() {
		t.Fatal("cancelled backing charge", done, e)
	}
	charge, ready, e := g.DetachNativeAccountingV6(&owner, fresh(1))
	if !ready || e != nil {
		t.Fatal(ready, e)
	}
	g = nil
	var removal retainedalloc.RemovalWork
	for turn := 0; turn < 100; turn++ {
		done, e := owner.RemoveWork(charge, &removal, fresh(32))
		if e != nil {
			t.Fatal(e)
		}
		if done {
			break
		}
		if turn == 99 {
			t.Fatal("wrapper refund stalled")
		}
	}
	if owner.Bytes() != baseline || p.PageCount() != oldCount || len(p.chunks) != 0 {
		t.Fatal("cancel changed installed pager or lost charge")
	}
	p.immutableReadRoots.retention = nil // no owner-backed pager output was installed
}
