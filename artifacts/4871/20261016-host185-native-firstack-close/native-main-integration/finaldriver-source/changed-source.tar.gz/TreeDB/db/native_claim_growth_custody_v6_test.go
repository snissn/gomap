package db

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"testing"
)

// This is the genuine Claim -> original seal bank-construction cancellation
// path. It installs no publication candidate, capsule, or durable authority.
func TestNativeSealInstalledClaimGrowthHandoffRefusalV6(t *testing.T) {
	d, err := Open(Options{Dir: t.TempDir(), ResolvedProfile: ProfileNoWALFast, Durability: DurabilityWALOffRelaxed, DisableBackgroundPrune: true})
	if err != nil {
		t.Fatal(err)
	}
	defer d.Close()
	if err = d.Set([]byte("warm"), []byte("ordinary")); err != nil {
		t.Fatal(err)
	}
	idx := d.idx.Load()
	a := idx.primary
	fresh := func(n uint64) *iterator.OrdinalScanWork {
		return &iterator.OrdinalScanWork{RecordLimit: n, ByteLimit: 1 << 20}
	}
	baseline := a.MetadataOwner().Bytes()
	banks, ready, err := newNativePrimaryBankConstructionV6(idx, fresh(32))
	if !ready || err != nil {
		t.Fatal("bank parent", ready, err)
	}
	if ready, err = banks.ensureNativeCapacityV6(1, fresh(32)); !ready || err != nil {
		t.Fatal("original bank vector", ready, err)
	}
	claim, ready, err := a.PrepareNativeClaimV6(primaryarena.Manifest, fresh(32))
	if !ready || err != nil {
		t.Fatal("claim", ready, err)
	}
	seal := nativeMVCCSealPreparationV6{banks: banks, claim: claim}
	sr, _, known := retainedalloc.NativeAtomicRemovalPriceForTestV6(0, 0)
	if !known {
		t.Fatal("original unbound owner shrink")
	}
	// Claim entry + Growth entry + original install prefix(2+1) + full
	// original owner shrink fit. Child accounting handoff(1) cannot fit.
	installed := primaryarena.Ref{}
	for turn := 0; turn < 100; turn++ {
		_, done, e := claim.Step(fresh(5 + sr))
		if e != nil {
			t.Fatal(e)
		}
		ref, present, ok, e := claim.NativeInstalledWithWorkV6(fresh(1))
		if !ok || e != nil {
			t.Fatal(e)
		}
		if present {
			if done {
				t.Fatal("expected genuine post-install accounting refusal")
			}
			installed = ref
			break
		}
		if done {
			t.Fatal("claim ready without installed edge")
		}
	}
	if installed == (primaryarena.Ref{}) {
		t.Fatal("actual tail Growth did not install")
	}
	claims := a.Counters().Claims
	charge := a.MetadataOwner().Bytes()
	if done, e := seal.finishClaimV6(true, fresh(2)); done || e != nil || seal.claim != claim || len(banks.refs) != 1 || banks.refs[0] != installed || a.MetadataOwner().Bytes() != charge {
		t.Fatal("installed cancellation lost same edge before handoff", done, e)
	}
	for turn := 0; turn < 100; turn++ {
		done, e := seal.finishClaimV6(true, fresh(32))
		if e != nil {
			t.Fatal(e)
		}
		if done {
			break
		}
		if turn == 99 {
			t.Fatal("claim accounting did not drain")
		}
	}
	for turn := 0; turn < 100; turn++ {
		done, e := seal.refund.CompleteRemovalWork(&seal.claimRefundOwner, &seal.claimRefundCharge, fresh(32))
		if e != nil {
			t.Fatal(e)
		}
		if done {
			break
		}
		if turn == 99 {
			t.Fatal("claim containing refund did not finish")
		}
	}
	if seal.claim != nil || seal.claimRefundOwner != nil || seal.claimRefundCharge != 0 || len(banks.refs) != 1 || banks.refs[0] != installed || a.Counters().Claims != claims {
		t.Fatal("claim handoff replay/lost custody")
	}
	var completion primaryRuntimeDisposalCompletionV6
	for turn := 0; turn < 100; turn++ {
		c, done, e := continuePrimaryBankConstructionReleaseV6(banks, fresh(32))
		if e != nil {
			t.Fatal(e)
		}
		if done {
			completion = c
			banks = nil
			seal.banks = nil
			break
		}
		if turn == 99 {
			t.Fatal("original bank disposal did not finish")
		}
	}
	var removal retainedalloc.RemovalWork
	for turn := 0; turn < 100; turn++ {
		done, e := completion.completeWithWork(&removal, fresh(32))
		if e != nil {
			t.Fatal(e)
		}
		if done {
			break
		}
		if turn == 99 {
			t.Fatal("bank accounting did not finish")
		}
	}
	// Installed page/chunk capacity remains original arena output; only private
	// Claim/Growth/constructor charges are refunded. No claim is replayed.
	if a.MetadataOwner().Bytes() < baseline || a.Counters().Claims != claims {
		t.Fatal("output custody/refund mismatch")
	}
}
