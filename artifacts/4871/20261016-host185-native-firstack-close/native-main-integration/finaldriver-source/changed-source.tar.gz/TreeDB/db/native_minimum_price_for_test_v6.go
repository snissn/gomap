package db

import (
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/lifecycle"
)

// NativeSnapshotAcquisitionScanPriceForTestV6 prices each original fixed atomic
// shard load and accumulator update in snapshotAcquireInFlight.
func NativeSnapshotAcquisitionScanPriceForTestV6() (records, bytes uint64) {
	var d DB
	return uint64(snapshotAcquireShardCount), 2 * uint64(unsafe.Sizeof(d.snapshotAcquireRO))
}

// NativeSnapshotMinimumPriceForTestV6 bounds one entry to a saved minimum index
// or terminal result, not every registry in the eventual traversal. Both fixed
// acquisition scans are included conservatively. The map and fallback lengths
// must remain within their precursor bounds; the current registry may be visited
// again after the map, but currentSeen saves that separate advance.
func NativeSnapshotMinimumPriceForTestV6(indexGenerations, fallbackSlots uint64) (records, bytes uint64, complete bool) {
	r, b, ok := lifecycle.NativeMinimumPriceForTestV6(fallbackSlots)
	if !ok || indexGenerations == ^uint64(0) || indexGenerations > ^uint64(0)/32 {
		return 0, 0, false
	}
	add := func(n, size uint64) bool {
		if n > ^uint64(0)-records || size > ^uint64(0)-bytes {
			return false
		}
		records += n
		bytes += size
		return true
	}
	sr, sb := NativeSnapshotAcquisitionScanPriceForTestV6()
	if !add(1, uint64(unsafe.Sizeof(nativeMVCCSnapshotMinimumV6{}))+32) || !add(1+indexGenerations, 32*indexGenerations) || !add(r, b) || !add(sr, sb) || !add(sr, sb) {
		return 0, 0, false
	}
	return records, bytes, true
}

// Selected precursor: the only original generation is the current one. This
// short observation does not scan readers or acquire a Snapshot. The fixture
// excludes generation changes and ordinary registrations until allocator
// preparation; the fresh native cursor cannot enlarge the fallback vector.
func (db *DB) MaintenanceNativeMinimumGeometryForTestV6(w *iterator.OrdinalScanWork) (g lifecycle.NativeMinimumGeometryForTestV6, indexGenerations uint64, ready bool) {
	if db == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(g))+2*uint64(unsafe.Sizeof(indexGen{}))+64) {
		return g, 0, false
	}
	db.idxMu.Lock()
	defer db.idxMu.Unlock()
	indexGenerations = uint64(len(db.idxAll))
	if indexGenerations != 1 {
		return g, indexGenerations, true
	}
	if !w.Reserve(1, 32) {
		return g, indexGenerations, false
	}
	current := db.idx.Load()
	for _, gen := range db.idxAll {
		if gen == nil || gen != current || gen.registry == nil {
			return g, indexGenerations, true
		}
		g, ready = gen.registry.MaintenanceNativeMinimumGeometryForTestV6(w)
	}
	return g, indexGenerations, ready
}
