package db

import (
	"github.com/snissn/gomap/TreeDB/freelist"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
	"github.com/snissn/gomap/TreeDB/pager"
	"os"
	"path/filepath"
	"unsafe"
)

// No field retains an index, root, certificate, budget, owner or mapped image.
// This is a read-only selected-shape census, not an authority/preparation cut.
type NativePreCursorBackendForTestV6 struct {
	Growth, PrimaryGrowth                                                                                                                                       pager.NativePreCursorGrowthForTestV6
	Allocator                                                                                                                                                   freelist.NativePreCursorAllocatorForTestV6
	Bank                                                                                                                                                        primaryarena.NativeBankGeometryForTestV6
	Registry                                                                                                                                                    rootpublication.NativePreCursorRegistryForTestV6
	PrimaryOwner, RegistryOwner                                                                                                                                 retainedalloc.NativePreCursorOwnerForTestV6
	Debt, Seals, Visible, IndexGenerations, DirectoryEntries, BaseLeafEntries                                                                                   uint64
	DebtCapacity, SealsCapacity, VisibleCapacity, DirectoryPathBytes, IndexFileBytes, IndexNameBytes, ProofParentBytes                                          uint64
	Sequence, IndexGeneration, RootPage, RootIncarnation                                                                                                        uint64
	MinimumFallbackSlots                                                                                                                                        uint64
	SourceLeaf, OuterLeavesOff, AdaptiveEncodingOff, LeafPrefix, LeafColumnar, InternalBaseDeltaOff, EntryRevisions, EmptyValueLog, NoLeafGenerations, Complete bool
}

func (db *DB) MaintenanceNativePreCursorBackendForTestV6(w *iterator.OrdinalScanWork) (NativePreCursorBackendForTestV6, bool) {
	return db.MaintenanceNativePreCursorBackendRoleForTestV6(255, w)
}
func (db *DB) MaintenanceNativePreCursorBackendRoleForTestV6(role uint8, w *iterator.OrdinalScanWork) (g NativePreCursorBackendForTestV6, ready bool) {
	return db.maintenanceNativePreCursorBackendRoleForTestV6(role, nil, w)
}
func (db *DB) MaintenanceNativePreCursorRegistryRoleForTestV6(c *rootpublication.NativePreCursorRegistryScanForTestV6, w *iterator.OrdinalScanWork) (g NativePreCursorBackendForTestV6, ready bool) {
	return db.maintenanceNativePreCursorBackendRoleForTestV6(5, c, w)
}
func (db *DB) maintenanceNativePreCursorBackendRoleForTestV6(role uint8, c *rootpublication.NativePreCursorRegistryScanForTestV6, w *iterator.OrdinalScanWork) (g NativePreCursorBackendForTestV6, ready bool) {
	if db == nil || w == nil || !w.Reserve(2, 2*uint64(unsafe.Sizeof(g))+2*uint64(unsafe.Sizeof(primaryStateRootV5{}))+uint64(unsafe.Sizeof(DBState{}))+uint64(unsafe.Sizeof(rootPublicationRuntimeV1{}))) {
		return g, false
	}
	db.idxMu.Lock()
	g.IndexGenerations = uint64(len(db.idxAll))
	db.idxMu.Unlock()
	db.rootReuseMu.RLock()
	defer db.rootReuseMu.RUnlock()
	db.mu.RLock()
	defer db.mu.RUnlock()
	r, state := db.rootPublication, db.state.Load()
	if r == nil || r.idx == nil || r.idx.primary == nil || state == nil || state.primaryRoot == nil || state.primaryRoot.certificate == nil {
		return g, true
	}
	root := state.primaryRoot
	r.mu.Lock()
	g.Debt, g.Seals, g.Visible = uint64(len(r.debt)), uint64(len(r.seals)), uint64(len(r.visibleMembers)-r.visibleHead)
	g.DebtCapacity = uint64(max(cap(r.debt), r.debtBackingCapacity))
	g.SealsCapacity = uint64(cap(r.seals))
	g.VisibleCapacity = uint64(cap(r.visibleMembers))
	r.mu.Unlock()
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(state.LeafGenerations))+2*uint64(unsafe.Sizeof(state.ValueLogSet))+64) {
		return g, false
	}
	shape, known := state.ValueLogSet.RetentionSizes()
	g.EmptyValueLog = known && shape.FileCount == 0
	g.NoLeafGenerations = state.LeafGenerations == nil
	g.Sequence = state.CommitSeq
	g.IndexGeneration = r.idx.id
	g.RootPage = uint64(root.ref.PageID)
	g.RootIncarnation = root.ref.Incarnation
	g.OuterLeavesOff = !db.indexOuterLeavesInValueLog
	g.AdaptiveEncodingOff = !db.indexAdaptiveLeafEncoding
	g.LeafPrefix = db.leafPrefixCompression
	g.LeafColumnar = db.indexColumnarLeaves
	g.InternalBaseDeltaOff = !db.indexInternalBaseDelta
	var ok bool
	switch role {
	case 7:
		g.PrimaryGrowth, ok = r.idx.primary.Pager().MaintenanceNativePreCursorGrowthOwnerForTestV6(r.idx.primary.MetadataOwner(), w)
		return g, ok
	case 8:
		if !w.Reserve(2, 2*uint64(unsafe.Sizeof(indexGen{}))+2*uint64(unsafe.Sizeof(primaryArenaOwnerV5{}))+256) {
			return g, false
		}
		g.DirectoryPathBytes = uint64(len(db.dir))
		for _, p := range [2]*pager.Pager{r.idx.pager, r.idx.primary.Pager()} {
			if !w.Reserve(1, 2*uint64(unsafe.Sizeof(os.File{}))+2*uint64(unsafe.Sizeof(string("")))+128) {
				return g, false
			}
			admitted := false
			if err := p.WithStableResourceFile(func(f *os.File) error {
				name := f.Name()
				n := uint64(len(name))
				if n > (^uint64(0)-2*uint64(unsafe.Sizeof(name))-64)/2 || !w.Reserve(1, 2*n+2*uint64(unsafe.Sizeof(name))+64) {
					return nil
				}
				admitted = true
				g.IndexFileBytes = max(g.IndexFileBytes, n)
				g.IndexNameBytes = max(g.IndexNameBytes, uint64(len(filepath.Base(name))))
				return nil
			}); err != nil || !admitted {
				return g, false
			}
		}
		r.idx.stableNamespaceMu.Lock()
		g.ProofParentBytes, ok = r.idx.stableNamespaceProof.NativeParentNameBytesForTestV6(w)
		r.idx.stableNamespaceMu.Unlock()
		if !ok {
			return g, false
		}
		r.idx.primaryOwner.namespaceMu.Lock()
		n, known := r.idx.primaryOwner.namespaceProof.NativeParentNameBytesForTestV6(w)
		r.idx.primaryOwner.namespaceMu.Unlock()
		g.ProofParentBytes = max(g.ProofParentBytes, n)
		return g, known
	case 1:
		g.Bank, ok = r.idx.primary.MaintenanceNativeBankGeometryForTestV6(root.ref, w)
		return g, ok
	case 2:
		g.Growth, ok = r.idx.pager.MaintenanceNativePreCursorGrowthForTestV6(w)
		return g, ok
	case 3:
		g.Allocator, ok = r.idx.allocator.MaintenanceNativePreCursorForTestV6(w)
		return g, ok
	case 4:
		g.PrimaryOwner, ok = r.idx.primary.MetadataOwner().MaintenanceNativePreCursorForTestV6(w)
		return g, ok
	case 5:
		if c != nil {
			done, step := db.valueLogIdentityPins.MaintenanceNativePreCursorStepForTestV6(c, w)
			g.Registry = c.Geometry
			return g, done && step && !c.Drift
		}
		g.Registry, ok = db.valueLogIdentityPins.MaintenanceNativePreCursorForTestV6(w)
		return g, ok
	case 6:
		g.RegistryOwner, ok = db.valueLogIdentityPins.MetadataOwner().MaintenanceNativePreCursorForTestV6(w)
		return g, ok
	}

	cert := root.certificate
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(node.PrimaryDirectoryView{}))+uint64(unsafe.Sizeof(node.PrimaryOperand{}))+64) {
		return g, false
	}
	directory := cert.Directory()
	g.DirectoryEntries = uint64(directory.Count())
	base, _ := directory.Base()
	if !base.Ref.IsPage() || primaryarena.IsPage(base.Ref.Page) {
		return g, true
	}
	image, ok, err := r.idx.pager.GetWithWork(base.Ref.Page, w)
	if !ok || err != nil {
		return g, false
	}
	if !w.Reserve(2, 3*page.PageSize+uint64(unsafe.Sizeof(node.Node{}))) {
		return g, false
	}
	n := node.NewNodeView(image)
	g.SourceLeaf = node.VerifyPrimaryOperand(base, image) && n.Type() == page.PageTypeLeaf
	g.BaseLeafEntries = uint64(n.Count())
	g.EntryRevisions = n.LeafEntryRevisionsEnabled()
	if role == 0 {
		return g, true
	}
	g.Bank, ok = r.idx.primary.MaintenanceNativeBankGeometryForTestV6(root.ref, w)
	if !ok {
		return g, false
	}
	g.Growth, ok = r.idx.pager.MaintenanceNativePreCursorGrowthForTestV6(w)
	if !ok {
		return g, false
	}
	g.Allocator, ok = r.idx.allocator.MaintenanceNativePreCursorForTestV6(w)
	if !ok {
		return g, false
	}
	g.PrimaryOwner, ok = r.idx.primary.MetadataOwner().MaintenanceNativePreCursorForTestV6(w)
	if !ok {
		return g, false
	}
	g.Registry, ok = db.valueLogIdentityPins.MaintenanceNativePreCursorForTestV6(w)
	if !ok {
		return g, false
	}
	g.RegistryOwner, ok = db.valueLogIdentityPins.MetadataOwner().MaintenanceNativePreCursorForTestV6(w)
	if !ok {
		return g, false
	}
	g.Complete = g.SourceLeaf && g.OuterLeavesOff && g.AdaptiveEncodingOff && g.InternalBaseDeltaOff && (!g.LeafColumnar || g.LeafPrefix) && g.EntryRevisions && g.EmptyValueLog && g.NoLeafGenerations && g.Allocator.Profile.Valid && g.Growth.Complete && g.Bank.Valid && g.PrimaryOwner.Complete && g.RegistryOwner.Complete && !g.Registry.Closing
	return g, true
}
