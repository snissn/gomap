package db

import (
	"errors"
	"testing"
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/lifecycle"
)

func TestNativeSnapshotMinimumAcquisitionAdmissionV6(t *testing.T) {
	var d DB
	d.snapshotAcquireEpoch.Store(42)
	var s nativeMVCCSnapshotMinimumV6
	entryBytes := uint64(unsafe.Sizeof(s)) + 32
	scanRecords := uint64(len(d.snapshotAcquireRO))
	scanBytes := uint64(unsafe.Sizeof(d.snapshotAcquireRO))
	for _, tc := range []struct {
		name           string
		records, bytes uint64
		unitTooLarge   bool
	}{
		{"original-Q32", 32, entryBytes + scanBytes, true},
		{"byte-unit-too-large", 1 + scanRecords, scanBytes - 1, true},
		{"record-remainder-short", scanRecords, entryBytes + scanBytes, false},
		{"byte-remainder-short", 1 + scanRecords, entryBytes + scanBytes - 1, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			before := s
			w := iterator.OrdinalScanWork{RecordLimit: tc.records, ByteLimit: tc.bytes}
			minimum, ready, err := s.step(&d, &w)
			var tooLarge *iterator.OrdinalUnitTooLarge
			if errors.As(err, &tooLarge) != tc.unitTooLarge || (err != nil && tooLarge == nil) {
				t.Fatalf("wrong scan refusal: %v", err)
			}
			if tooLarge != nil && (tooLarge.Records != scanRecords || tooLarge.Bytes != scanBytes) {
				t.Fatalf("wrong indivisible scan price: %+v", tooLarge)
			}
			if minimum != 0 || ready || s != before || d.snapshotAcquireEpoch.Load() != 42 || w.Records != 1 || w.Bytes != entryBytes {
				t.Fatalf("refused scan consumed observation/state: min=%d ready=%v state=%+v work=%+v", minimum, ready, s, w)
			}
		})
	}
	// The last actual shard must be included, with the exact whole scan charged.
	d.snapshotAcquireRO[len(d.snapshotAcquireRO)-1].Store(1)
	w := iterator.OrdinalScanWork{RecordLimit: 1 + scanRecords, ByteLimit: entryBytes + scanBytes}
	if minimum, ready, err := s.step(&d, &w); minimum != 0 || ready || err != nil || s.begun || w.Records != 1+scanRecords || w.Bytes != entryBytes+scanBytes {
		t.Fatalf("in-flight last shard escaped scan/admission: min=%d ready=%v err=%v state=%+v work=%+v", minimum, ready, err, s, w)
	}
}

func TestNativeSnapshotMinimumTerminalScanAdmissionV6(t *testing.T) {
	var d DB
	d.snapshotAcquireEpoch.Store(42)
	s := nativeMVCCSnapshotMinimumV6{epoch: 42, minimum: 7, begun: true, currentSeen: true}
	before := s
	entryBytes := uint64(unsafe.Sizeof(s)) + 32
	scanRecords := uint64(len(d.snapshotAcquireRO))
	scanBytes := uint64(unsafe.Sizeof(d.snapshotAcquireRO))
	// An empty map still costs its original one-record entry. The first scan
	// and map fit; the terminal rescan must refuse before returning a minimum.
	w := iterator.OrdinalScanWork{RecordLimit: 2 + scanRecords, ByteLimit: entryBytes + 2*scanBytes}
	if minimum, ready, err := s.step(&d, &w); minimum != 0 || ready || err != nil || s != before || w.Records != 2+scanRecords || w.Bytes != entryBytes+scanBytes {
		t.Fatalf("terminal rescan not admitted separately: min=%d ready=%v err=%v state=%+v work=%+v", minimum, ready, err, s, w)
	}
	w = iterator.OrdinalScanWork{RecordLimit: 2 + 2*scanRecords, ByteLimit: entryBytes + 2*scanBytes}
	if minimum, ready, err := s.step(&d, &w); minimum != 7 || !ready || err != nil || s != before || w.Records != w.RecordLimit || w.Bytes != w.ByteLimit {
		t.Fatalf("exact terminal work failed: min=%d ready=%v err=%v state=%+v work=%+v", minimum, ready, err, s, w)
	}
}

func TestNativeSnapshotMinimumHistoricalFallbackEnvelopeV6(t *testing.T) {
	registry := lifecycle.NewReaderRegistry()
	handles := make([]int64, lifecycle.FastReaderShardCount+3)
	for i := range handles {
		handles[i] = registry.Register(100 + uint64(i))
	}
	defer registry.Unregister(handles[0])
	for _, handle := range handles[1:] {
		registry.Unregister(handle)
	}
	gen := &indexGen{id: 1, registry: registry}
	d := DB{idxAll: map[uint64]*indexGen{1: gen}}
	d.idx.Store(gen)
	d.snapshotAcquireEpoch.Store(42)
	observation := iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
	g, generations, ready := d.MaintenanceNativeMinimumGeometryForTestV6(&observation)
	if !ready || !g.Complete || !g.Dirty || g.FallbackSlots != 3 || generations != 1 {
		t.Fatalf("historical free slots lost from precursor: %+v generations=%d ready=%v", g, generations, ready)
	}
	r, b, complete := NativeSnapshotMinimumPriceForTestV6(generations, g.FallbackSlots)
	if !complete {
		t.Fatal("selected source price unavailable")
	}
	var s nativeMVCCSnapshotMinimumV6
	for turn := 0; turn < 3; turn++ {
		w := iterator.OrdinalScanWork{RecordLimit: r, ByteLimit: b}
		minimum, done, err := s.step(&d, &w)
		if err != nil || w.Records > r || w.Bytes > b || done != (turn == 2) {
			t.Fatalf("source price failed map/current/terminal advance %d: min=%d done=%v err=%v state=%+v work=%+v", turn, minimum, done, err, s, w)
		}
		if done && minimum != 100 {
			t.Fatalf("original live reader minimum lost: %d", minimum)
		}
	}
}
