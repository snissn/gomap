package db

import (
	"os"
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/mvccadmission"
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
	"github.com/snissn/gomap/TreeDB/pager"
)

type NativeDBPreparationChildrenForTestV6 struct {
	Arena                                                      primaryarena.NativeConstructionUnitsForTestV6
	Primary                                                    rootpublication.NativePrimaryConstructionUnitsForTestV6
	Capture                                                    rootpublication.NativeCaptureConstructorUnitsForTestV6
	LookupNodes                                                uint64
	AddRecords, AddBytes, RemovalRecords, RemovalBytes         uint64
	QueueRecords, QueueBytes, ObserveRecords, ObserveBytes     uint64
	UnobserveRecords, UnobserveBytes, WriteRecords, WriteBytes uint64
	Complete                                                   bool
}

type NativeDBPreparationUnitsForTestV6 struct {
	RootRecords, RootBytes, CandidateRecords, CandidateBytes uint64
	SealRecords, SealBytes, CaptureRecords, CaptureBytes     uint64
	Complete                                                 bool
}

// NativeDBPreparationPriceForTestV6 forwards the original private DB types.
// It sums saved phases once, including their repeated refund/lookup prefixes.
// The caller proves the selected empty closure, identical captured/current
// components and exclusion of extra producers before ready. Transaction birth,
// current-delete/cursor ancestors, and terminal cancellation remain separate.
// No constructor, allocation, I/O, owner or authority is executed here.
func NativeDBPreparationPriceForTestV6(g NativePreCursorBackendForTestV6, c NativeDBPreparationChildrenForTestV6) (v NativeDBPreparationUnitsForTestV6) {
	if !c.Complete || !c.Arena.Complete || !c.Primary.Complete || !c.Capture.Complete || g.DirectoryEntries > node.PrimaryDirectoryMaxEntries || g.Debt == ^uint64(0) || g.Seals == ^uint64(0) {
		return v
	}
	type unit struct{ r, b uint64 }
	add := func(u *unit, r, b uint64) bool {
		if r > ^uint64(0)-u.r || b > ^uint64(0)-u.b {
			return false
		}
		u.r += r
		u.b += b
		return true
	}
	scaled := func(u *unit, n, r, b uint64) bool {
		if n != 0 && (r > ^uint64(0)/n || b > ^uint64(0)/n) {
			return false
		}
		return add(u, n*r, n*b)
	}
	sum := func(rows ...unit) (u unit, ok bool) {
		for _, x := range rows {
			if !add(&u, x.r, x.b) {
				return unit{}, false
			}
		}
		return u, true
	}
	owner := unit{c.AddRecords, c.AddBytes}
	refund := unit{c.RemovalRecords, c.RemovalBytes}
	lr, lb, _, _, ok := pager.NativeReadRootUnitForTestV6(c.LookupNodes)
	if !ok {
		return v
	}
	lookup := unit{lr, lb}
	p := uint64(page.PageSize)
	ptr := uint64(unsafe.Sizeof(uintptr(0)))
	bank := primaryarena.RefAcquireBytesV6()
	request := unit{1, uint64(unsafe.Sizeof(mvccadmission.Request{})) + uint64(unsafe.Sizeof(mvccadmission.Capability{})) + uint64(unsafe.Sizeof(mvccadmission.Authority{}))}
	entry := uint64(unsafe.Sizeof(node.PrimaryDirectoryEntry{}))
	txn := uint64(unsafe.Sizeof(rootpublication.DurableRootTransaction{}))
	root, ok := sum(request, unit{2, 2*uint64(unsafe.Sizeof(nativeMVCCRootPreparationV6{})) + 2*uint64(unsafe.Sizeof(page.MetaPageBody{}))}, unit{2, bank + 2*p + 2*uint64(unsafe.Sizeof(primaryarena.ReadRootCertificateV6{}))}, lookup, unit{1, bank}, lookup,
		unit{1, 4*entry + 2*p}, unit{1, 2*p + 2*uint64(unsafe.Sizeof(node.PrimaryDirectoryEncodeWorkV6{}))}, unit{1, 2 * p}, unit{1, p}, unit{c.Arena.SealRecords, c.Arena.SealBytes}, unit{1, 2 * uint64(unsafe.Sizeof(nativeMVCCRootPreparationV6{}))}, unit{c.QueueRecords, c.QueueBytes})
	if !ok || !scaled(&root, g.DirectoryEntries, 1, 4*p+2*entry) {
		return v
	}
	// The nonpersistent binary search visits no more than the actual bounded
	// directory count. One outer entry advances persistently after that search.
	member := uint64(unsafe.Sizeof(rootPublicationVisibleMemberV1{}))
	install := uint64(unsafe.Sizeof(rootPublicationVisibleInstallV1{}))
	candidate, ok := sum(refund, request, unit{3, 2*uint64(unsafe.Sizeof(nativeMVCCCandidatePreparationV6{})) + 2*member + 2*install}, unit{c.Primary.EmptyRecords, c.Primary.EmptyBytes}, unit{3, 2*member + 2*install + 10*uint64(unsafe.Sizeof(primaryVisibilityCallbackEnvironmentV6{}))}, owner,
		unit{c.Primary.CloneRecords, c.Primary.CloneBytes}, unit{2, 2*install + 128}, unit{1, 2 * uint64(unsafe.Sizeof(primaryStateRootV5{}))}, unit{1, bank}, lookup, owner,
		refund, refund, unit{2, 2*uint64(unsafe.Sizeof(rootPublicationRuntimeV1{})) + 16}, unit{1, 2*txn + 2*uint64(unsafe.Sizeof(rootpublication.DurableRootTransactionSpec{}))}, unit{2, 2 * bank}, lookup,
		unit{3, 2*uint64(unsafe.Sizeof(rootpublication.CandidateSpec{})) + 2*uint64(unsafe.Sizeof(rootpublication.PreparedRootCandidate{})) + 2*txn})
	if !ok {
		return v
	}
	// Each original runtime slice holds pointers. Its precursor capacity bounds
	// old length, reachable cap and charged full cap (including consumed debt).
	// q=max(4,2*cap) also dominates need<=cap+1. Count a replacement even when
	// actual spare capacity skips it; no ready-time enlargement is used.
	grow := func(capacity uint64) (u unit, ok bool) {
		if capacity > ^uint64(0)/2 {
			return u, false
		}
		q := max(uint64(4), 2*capacity)
		u, ok = sum(unit{2, 2*uint64(unsafe.Sizeof([]uintptr(nil))) + 2*uint64(unsafe.Sizeof(rootPublicationRuntimeV1{})) + 2*uint64(unsafe.Sizeof(primaryBackingRefundV6{})) + 16}, unit{1, 2 * uint64(unsafe.Sizeof([]uintptr(nil)))}, owner)
		if !ok || !scaled(&u, q, 1, ptr) || !scaled(&u, capacity, 2, 3*ptr) {
			return unit{}, false
		}
		return u, true
	}
	if !add(&candidate, 1, 48) || !scaled(&candidate, g.VisibleCapacity, 2, 3*ptr) {
		return v
	}
	for _, capacity := range [...]uint64{g.VisibleCapacity, g.DebtCapacity} {
		u, ok := grow(capacity)
		if !ok || !add(&candidate, u.r, u.b) {
			return v
		}
	}
	seal, ok := sum(refund, refund, request, unit{2, 2*uint64(unsafe.Sizeof(rootpublication.PrimaryCapsuleViewV6{})) + 2*uint64(unsafe.Sizeof(rootpublication.DurableRootRecordV1{})) + 128}, unit{1, 2 * uint64(rootpublication.PrimaryCapsuleSizeV6)}, unit{c.Primary.EmptyRecords, c.Primary.EmptyBytes}, unit{c.Primary.CloneRecords, c.Primary.CloneBytes}, unit{c.Primary.ManifestRecords, c.Primary.ManifestBytes},
		unit{3, 2*uint64(unsafe.Sizeof(primaryBankConstructionV5{})) + 2*uint64(unsafe.Sizeof(primaryarena.Ref{})) + 128}, unit{2, 2*uint64(unsafe.Sizeof(primaryBankConstructionV5{})) + 2*uint64(unsafe.Sizeof(primaryArenaOwnerV5{}))}, owner, unit{1, 2 * uint64(unsafe.Sizeof(primaryBankConstructionV5{}))}, unit{1, 2 * uint64(unsafe.Sizeof(primaryarena.Ref{}))}, owner,
		unit{c.Arena.ClaimRecords, c.Arena.ClaimBytes}, unit{1, 2*uint64(unsafe.Sizeof(primaryBankConstructionV5{})) + 2*uint64(unsafe.Sizeof(primaryarena.Ref{}))}, unit{3, 6*p + 2*uint64(unsafe.Sizeof(primaryManifestImagesV5{}))},
		unit{1, 16*p + bank + 2*uint64(unsafe.Sizeof([2]primaryarena.MetadataEdge{})) + 2*uint64(unsafe.Sizeof([2]uintptr{}))}, unit{c.WriteRecords, c.WriteBytes},
		unit{2, 2*uint64(unsafe.Sizeof(rootpublication.DurableRootRecordV1{})) + 2*uint64(unsafe.Sizeof(rootpublication.PrimaryProjectionV5{})) + 128}, unit{2, 2*uint64(unsafe.Sizeof(rootpublication.DurableRootRecordV1{})) + 2*uint64(unsafe.Sizeof(page.MetaPageBody{})) + 128},
		unit{1, 2*txn + 2*uint64(unsafe.Sizeof(rootpublication.PrimaryPromotionV6{}))}, unit{c.Primary.CapsuleRecords, c.Primary.CapsuleBytes}, unit{4, 4*bank + 4*uint64(unsafe.Sizeof(primaryarena.Ref{}))}, lookup, lookup,
		refund, unit{2, 2*uint64(unsafe.Sizeof(rootpublication.DurableRootRecordV1{})) + 2*uint64(unsafe.Sizeof(page.DurableMetaV1{})) + 128}, unit{3, 2*uint64(unsafe.Sizeof(rootPublicationSealV1{})) + 2*uint64(unsafe.Sizeof(primaryPublicationSealV5{}))}, owner,
		unit{1, uint64(unsafe.Sizeof(primaryDurableRuntimeV5{}))}, owner, unit{1, 0}, owner)
	if !ok || !scaled(&seal, g.Debt+1, 1, 3*ptr) || !scaled(&seal, g.Seals+1, 0, ptr) {
		return v
	}
	u, ok := grow(g.SealsCapacity)
	if !ok || !add(&seal, u.r, u.b) {
		return v
	}
	// One of the two original captures. The seal saves its capture index;
	// completing DATA does not force reconstruction when PRIMARY later yields.
	nameCharge := retainedalloc.AllocationCharge(g.DirectoryPathBytes)
	base, err := rootpublication.StableFileMetadataCharge(0)
	if err != nil || nameCharge == ^uint64(0) || nameCharge > ^uint64(0)-base {
		return v
	}
	file := base + nameCharge
	capSize := uint64(unsafe.Sizeof(nativeStablePagerCaptureV6{}))
	op := uint64(unsafe.Sizeof(stablePagerOwnedOperations{}))
	snap := uint64(unsafe.Sizeof(Snapshot{}))
	idx := uint64(unsafe.Sizeof(indexGen{}))
	capture, ok := sum(unit{3, 2*snap + 2*capSize + 2*idx}, owner, unit{2, 0}, owner, unit{c.Capture.ProofRecords, c.Capture.ProofBytes}, unit{1, 256}, unit{c.Capture.BindRecords, c.Capture.BindBytes}, unit{3, 2*uint64(unsafe.Sizeof(rootpublication.StableResourceSpec{})) + 2*uint64(unsafe.Sizeof(rootpublication.StableIdentity{})) + 256}, unit{c.ObserveRecords, c.ObserveBytes},
		unit{1, 2*capSize + snap + idx + uint64(unsafe.Sizeof(os.File{})) + op}, unit{2, 2 * op}, owner, unit{c.Capture.CustodyRecords, c.Capture.CustodyBytes}, unit{1, 2 * uint64(unsafe.Sizeof(primaryArenaOwnerV5{}))}, unit{c.Capture.TokenRecords, c.Capture.TokenBytes}, unit{c.UnobserveRecords, c.UnobserveBytes},
		unit{1, 2*op + 2*capSize}, unit{1, 2 * uint64(unsafe.Sizeof(rootpublication.StableNamespaceToken{}))}, unit{1, 2 * uint64(unsafe.Sizeof(rootpublication.StableResourceSpec{}))})
	if !ok || !scaled(&capture, 2, 0, file) || !scaled(&capture, 2, 0, g.DirectoryPathBytes) || !scaled(&capture, 2, 0, g.IndexFileBytes) || !scaled(&capture, 6, refund.r, refund.b) {
		return v
	}
	if !add(&seal, capture.r, capture.b) {
		return v
	}
	v.RootRecords, v.RootBytes = root.r, root.b
	v.CandidateRecords, v.CandidateBytes = candidate.r, candidate.b
	v.SealRecords, v.SealBytes = seal.r, seal.b
	v.CaptureRecords, v.CaptureBytes = capture.r, capture.b
	v.Complete = true
	return v
}
