package db

import (
	"errors"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"testing"
)

func TestNativeSnapshotBirthLookupAdmissionAndOriginalCleanupV6(t *testing.T) {
	d, err := Open(Options{Dir: t.TempDir(), ResolvedProfile: ProfileNoWALFast, Durability: DurabilityWALOffRelaxed, DisableBackgroundPrune: true})
	if err != nil {
		t.Fatal(err)
	}
	defer d.Close()
	if err = d.Set([]byte("warm"), []byte("ordinary published root")); err != nil {
		t.Fatal(err)
	}
	state, idx := d.state.Load(), d.idx.Load()
	if state.primaryRoot == nil {
		t.Fatal("missing original PRIMARY root")
	}
	root, owner := state.primaryRoot, idx.primaryOwner
	before := root.arena.Counters()
	owner.mu.Lock()
	refs := owner.refs
	owner.mu.Unlock()
	epoch, captures := d.snapshotAcquireEpoch.Load(), d.stableIndexCaptures.Load()
	rejected := errors.New("original containing admission refusal")
	calls := 0
	admit := func(SnapshotAllocationSizes) error { calls++; return rejected }
	// Common view + actual fixed constructor references fit. No record remains
	// for the newly admitted bank lookup; callback and every birth effect stay out.
	fixed := uint64(6 + 2)
	view := d.snapshotViewRO.Load()
	if view.vlogManager != nil {
		fixed++
	}
	if state.ValueLogSet != nil {
		fixed++
	}
	if state.LeafGenerations != nil && state.LeafGenerations.PinSet != nil {
		fixed++
	}
	short := &iterator.OrdinalScanWork{RecordLimit: 1 + fixed, ByteLimit: 1 << 20}
	if s, ready, e := d.BeginNativeMVCCSnapshotV6(admit, short); s != nil || ready || e != nil || calls != 0 {
		t.Fatal("lookup refusal performed admission", ready, e, calls)
	}
	fresh := func() *iterator.OrdinalScanWork {
		return &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
	}
	if s, ready, e := d.BeginNativeMVCCSnapshotV6(admit, fresh()); s != nil || ready || e != rejected || calls != 1 {
		t.Fatal("callback refusal born partial Snapshot", ready, e, calls)
	}
	owner.mu.Lock()
	sameRefs := owner.refs == refs
	owner.mu.Unlock()
	if !sameRefs || root.arena.Counters() != before || d.snapshotAcquireEpoch.Load() != epoch || d.stableIndexCaptures.Load() != captures {
		t.Fatal("refused birth changed original edges/epoch")
	}
	s, ready, e := d.BeginNativeMVCCSnapshotV6(func(SnapshotAllocationSizes) error { calls++; return nil }, fresh())
	if !ready || e != nil || s == nil || s.primaryRoot != root || s.primaryOwner != owner || s.nativeMVCC.capturePhase != 2 {
		t.Fatal("original containing custody not attached", ready, e)
	}
	owner.mu.Lock()
	sameRefs = owner.refs == refs+1
	owner.mu.Unlock()
	if !sameRefs || root.arena.Counters().RootAcquires != before.RootAcquires+1 {
		t.Fatal("birth did not acquire exactly one original edge")
	}
	// Registry continuation belongs to this SAME Snapshot. No second bank edge
	// is acquired when registration needs additional finite turns.
	for turn := 0; turn < 100; turn++ {
		done, e := s.StepNativeMVCCSnapshotCaptureV6(fresh())
		if e != nil {
			t.Fatal(e)
		}
		if done {
			break
		}
		if turn == 99 {
			t.Fatal("registry continuation stalled")
		}
	}
	if root.arena.Counters().RootAcquires != before.RootAcquires+1 {
		t.Fatal("registry retry replayed bank acquire")
	}
	for turn := 0; turn < 100; turn++ {
		done, e := s.CloseNativeMVCCSnapshotStepV6(fresh())
		if e != nil {
			t.Fatal(e)
		}
		if done {
			break
		}
		if turn == 99 {
			t.Fatal("original cleanup stalled")
		}
	}
	owner.mu.Lock()
	sameRefs = owner.refs == refs
	owner.mu.Unlock()
	if !sameRefs || s.primaryRoot != nil || s.primaryOwner != nil || !s.cleanupFinished || d.stableIndexCaptures.Load() != captures {
		t.Fatal("original Snapshot edges survived cleanup")
	}
}
