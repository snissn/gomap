package db

import (
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
	"github.com/snissn/gomap/TreeDB/lifecycle"
	"github.com/snissn/gomap/TreeDB/tree"
	"unsafe"
)

type NativeTerminalUnitsForTestV6 struct {
	SnapshotRecords, SnapshotBytes, OwnedRecords, OwnedBytes, ProviderRecords, ProviderBytes uint64
	WitnessRecords, WitnessBytes, MemberRecords, MemberBytes, CloseRecords, CloseBytes       uint64
	Complete                                                                                 bool
}

// NativeTerminalUnitsForTestV6ForShape forwards real private source sizes and
// composes the selected original child units. It creates no Snapshot, owner,
// receipt or physical edge. Primary owner releases must remain nonlast while
// cursor join precedes DB.Close withdrawing the live index/runtime owner.
func NativeTerminalUnitsForShapeForTestV6(nodes, removeR, removeB, enrollmentR, enrollmentB, vlogR, vlogB, pathBytes, retiredSealCapacity uint64) (v NativeTerminalUnitsForTestV6) {
	sum := func(terms [][2]uint64) (r, b uint64, ok bool) {
		for _, n := range terms {
			if n[0] > ^uint64(0)-r || n[1] > ^uint64(0)-b {
				return 0, 0, false
			}
			r += n[0]
			b += n[1]
		}
		return r, b, true
	}
	dr, db, qr, qb, ok := primaryarena.NativeReleaseUnitForTestV6(nodes, removeR, removeB)
	if !ok {
		return
	}
	arenaBind := 2*uint64(unsafe.Sizeof(primaryArenaOwnerV5{})) + 2*uint64(unsafe.Sizeof(primaryArenaReleaseWork{})) + 64
	proofSupport := 2*uint64(unsafe.Sizeof(rootpublication.StableNamespaceCreationProof{})) + 64
	// The twelve original finalize phases each have a saved position. Summing
	// their repeated loop prefix is deliberately stronger than a single phase.
	sr, sb, ok := sum([][2]uint64{
		{2, 2*uint64(unsafe.Sizeof(Snapshot{})) + 64},
		{12, 12 * (2*uint64(unsafe.Sizeof(nativeMVCCSnapshotStateV6{})) + 64)},
		{1, 2*uint64(unsafe.Sizeof(lifecycle.NativeMVCCRegistration{})) + 8},
		{dr, db}, {qr, qb}, {vlogR, vlogB},
		{1, 2*uint64(unsafe.Sizeof(leafGenerationPinSet{})) + 2*uint64(unsafe.Sizeof(leafGenerationPinReleaseWork{})) + 64},
		{1, 2*uint64(unsafe.Sizeof(leafGenerationPinSet{})) + uint64(unsafe.Sizeof(leafGenerationPinReleaseWork{}))},
		{2, 2*uint64(unsafe.Sizeof(leafGenerationPinRef{})) + 16},
		{1, 2*uint64(unsafe.Sizeof(leafGenerationPinSet{})) + uint64(unsafe.Sizeof(leafGenerationPinReleaseWork{}))},
		{2, arenaBind + proofSupport},
		{2, 4*uint64(unsafe.Sizeof(Snapshot{})) + 64},
		{enrollmentR, enrollmentB},
		{1, 2*uint64(unsafe.Sizeof(Snapshot{})) + 64},
	})
	if !ok {
		return
	}
	v.SnapshotRecords, v.SnapshotBytes = sr, sb
	v.OwnedRecords, v.OwnedBytes, ok = sum([][2]uint64{
		{removeR, removeB}, {removeR, removeB},
		{1, 2*uint64(unsafe.Sizeof(stablePagerOwnedOperations{})) + 2*uint64(unsafe.Sizeof(nativeStablePagerCaptureV6{}))},
		{1, 2 * uint64(unsafe.Sizeof(Snapshot{}))}, {sr, sb},
		{1, 2 * uint64(unsafe.Sizeof(stablePagerOwnedOperations{}))},
		{2, arenaBind + proofSupport},
		{1, 2*rootpublication.NativePinnedBackingRawForTestV6() + 128}, {removeR, removeB},
		{1, 2*uint64(unsafe.Sizeof(stablePagerOwnedOperations{})) + pathBytes},
	})
	if !ok {
		return
	}
	v.ProviderRecords, v.ProviderBytes, ok = sum([][2]uint64{
		{1, 2*uint64(unsafe.Sizeof(primaryDependencyLeaseV5{})) + 2*uint64(unsafe.Sizeof(primaryArenaOwnerV5{}))},
		{dr, db}, {qr, qb}, {2, arenaBind + proofSupport},
		{1, 2 * uint64(unsafe.Sizeof(primaryDependencyLeaseV5{}))},
	})
	if !ok {
		return
	}
	v.WitnessRecords, v.WitnessBytes, ok = sum([][2]uint64{
		{1, 2 * uint64(unsafe.Sizeof(nativeMVCCRootPreparationV6{}))},
		{1, 2*uint64(unsafe.Sizeof(primaryarena.Ref{})) + 2*uint64(unsafe.Sizeof(uint8(0)))},
		{dr, db}, {qr, qb}, {1, 2 * uint64(unsafe.Sizeof(nativeMVCCRootPreparationV6{}))},
	})
	if !ok {
		return
	}
	var m rootPublicationVisibleMemberV1
	var i rootPublicationVisibleInstallV1
	sealPointer := uint64(unsafe.Sizeof((*rootPublicationSealV1)(nil)))
	if retiredSealCapacity > ^uint64(0)/(2*sealPointer) {
		return
	}
	v.MemberRecords, v.MemberBytes, ok = sum([][2]uint64{
		{1, uint64(unsafe.Sizeof(m))}, {removeR, removeB}, {removeR, removeB}, {removeR, removeB},
		// Original record and post.oldState root both use this same queue.
		{2, 4 * uint64(unsafe.Sizeof(primaryarena.ReleaseQueue{}))},
		{2, 4 * uint64(unsafe.Sizeof(primaryarena.Ref{}))}, {dr, db}, {qr, qb}, {dr, db}, {qr, qb},
		{2, 4 * uint64(unsafe.Sizeof(bool(false)))},
		{3, uint64(unsafe.Sizeof(i.post)) + uint64(unsafe.Sizeof(DBState{})) + uint64(unsafe.Sizeof(primaryStateRootV5{})) + uint64(unsafe.Sizeof(m.retiredPostRoot)) + uint64(unsafe.Sizeof(m.retiredPostSet)) + uint64(unsafe.Sizeof(m.retiredPostManager))},
		{1, 2*uint64(unsafe.Sizeof(m.retiredPostSet)) + 2*uint64(unsafe.Sizeof(m.retiredPostManager))}, {vlogR, vlogB},
		{1, 2 * uint64(unsafe.Sizeof(m.retiredVisibleResources))},
		{1, 2 * sealPointer}, {1, 2 * retiredSealCapacity * sealPointer},
		{3, 2*uint64(unsafe.Sizeof(primaryPublicationSealV5{})) + 2*uint64(unsafe.Sizeof(primaryCleanupFailureV5{})) + 2*rootpublication.NativeOwnerRawForTestV6()},
		{3, 2*uint64(unsafe.Sizeof(rootPublicationSealV1{})) + 2*uint64(unsafe.Sizeof(primaryCleanupFailureV5{})) + 2*rootpublication.NativeOwnerRawForTestV6()},
		{3, 2*uint64(unsafe.Sizeof(primaryDurableRuntimeV5{})) + 2*uint64(unsafe.Sizeof(primaryCleanupFailureV5{})) + 2*rootpublication.NativeOwnerRawForTestV6()},
	})
	if !ok {
		return
	}
	v.CloseRecords, v.CloseBytes, ok = sum([][2]uint64{
		{1, 2 * uint64(unsafe.Sizeof(NativeMVCCCurrentDeleteV6{}))},
		{removeR, removeB},
		{1, 2 * uint64(unsafe.Sizeof(nativeMVCCCandidatePreparationV6{}))},
		{removeR, removeB}, {removeR, removeB},
		{1, 2 * uint64(unsafe.Sizeof(nativeMVCCSealPreparationV6{}))},
		{1, 2 * uint64(unsafe.Sizeof(NativeMVCCFrameReaderV6{}))},
		{1, uint64(unsafe.Sizeof(tree.Tree{})) + 96},
	})
	if !ok {
		return
	}
	v.Complete = true
	return
}
