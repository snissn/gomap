package db

import (
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/internal/valuelog"
	"github.com/snissn/gomap/TreeDB/lifecycle"
	"github.com/snissn/gomap/TreeDB/pager"
)

type NativeSnapshotPreparationUnitsForTestV6 struct {
	BirthRecords, BirthBytes       uint64
	RegistryRecords, RegistryBytes uint64
	Complete                       bool
}

// NativeSnapshotPreparationPriceForTestV6 composes original Snapshot birth
// and registry rows for the selected PRIMARY-root capture. nodes includes the
// lookup sentinel; producers is the actual distinct metadata-owner count.
// All fixed optional reference rows are included conservatively, even when
// their branch is absent. This does not establish eligibility for nonempty
// value logs, stale leaf generations, foreign callbacks or concurrent mutation.
// The original capture census and caller must prove those conditions separately.
func NativeSnapshotPreparationPriceForTestV6(nodes, producers uint64) (v NativeSnapshotPreparationUnitsForTestV6) {
	if nodes == 0 || producers == 0 || producers > 2 {
		return v
	}
	lr, lb, _, _, ok := pager.NativeReadRootUnitForTestV6(nodes)
	if !ok {
		return v
	}
	add := func(r, b uint64) bool {
		if r > ^uint64(0)-v.BirthRecords || b > ^uint64(0)-v.BirthBytes {
			return false
		}
		v.BirthRecords += r
		v.BirthBytes += b
		return true
	}
	rows := [...][2]uint64{
		{1, uint64(unsafe.Sizeof(snapshotView{})) + 128},
		{6, 4*uint64(unsafe.Sizeof(Snapshot{})) + 256},
		{1, 2*uint64(unsafe.Sizeof(valuelog.Manager{})) + 64},
		{1, 2 * uint64(unsafe.Sizeof(leafGenerationPinSet{}))},
		{1, 0}, // owned Set reference, including an owned empty Set
		{2, primaryarena.RefAcquireBytesV6() + 2*uint64(unsafe.Sizeof(primaryArenaOwnerV5{}))},
		// AcquireAfterAdmissionV6 adds its own fixed row and actual lookup;
		// the original fixed constructor preflight above is still charged.
		{1, primaryarena.RefAcquireBytesV6()},
		{lr, lb},
	}
	for _, row := range rows {
		if !add(row[0], row[1]) {
			return v
		}
	}
	q := memtable.COWRetentionAcquireWorkBytes()
	h := retainedalloc.EnrollmentConstructorWorkBytes()
	if h > ^uint64(0)-q || producers > (^uint64(0)-q)/(h+q) {
		return v
	}
	// The callback's remaining-capacity preflight is not effect credit. Its
	// actual wrapper Q and each producer H+Q are included in this compound unit.
	if !add(1+2*producers, q+producers*(h+q)) {
		return v
	}
	registration := uint64(unsafe.Sizeof(lifecycle.NativeMVCCRegistration{}))
	probes := uint64(lifecycle.FastReaderShardCount) * 2 // original join then claim
	probeBytes := 2*registration + 40
	finalBytes := 2*uint64(unsafe.Sizeof(Snapshot{})) + 64
	baseBytes := 2*registration + 8
	if finalBytes > ^uint64(0)-baseBytes {
		return v
	}
	baseBytes += finalBytes
	if probes > (^uint64(0)-3)/5 || probes > (^uint64(0)-baseBytes)/probeBytes {
		return v
	}
	v.RegistryRecords = 3 + probes*5
	v.RegistryBytes = baseBytes + probes*probeBytes
	v.Complete = true
	return v
}
