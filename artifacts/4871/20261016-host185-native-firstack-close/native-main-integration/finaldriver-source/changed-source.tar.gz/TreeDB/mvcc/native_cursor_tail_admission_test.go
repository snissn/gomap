package mvcc

import (
	"bytes"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/node"
	"testing"
	"unsafe"
)

func TestNativeCursorBatchFlushAdmissionPreservesSelectionV6(t *testing.T) {
	c := PruneCursor{phase: 10, record: node.LeafEntry{Key: []byte("next")}, batchEntries: []node.LeafEntry{{Key: []byte("last-buffered-selection")}}}
	before := c.record
	w := iterator.OrdinalScanWork{RecordLimit: 1, ByteLimit: uint64(len(c.batchEntries[0].Key)) + 63}
	if c.beginBatchFlushV6(&w) || c.phase != 10 || c.selectedSize != 0 || c.batchFlushing || !bytes.Equal(c.record.Key, before.Key) {
		t.Fatal("refused flush changed original selection")
	}
	w = iterator.OrdinalScanWork{RecordLimit: 1, ByteLimit: uint64(len(c.batchEntries[0].Key)) + 64}
	if !c.beginBatchFlushV6(&w) || c.phase != 12 || !bytes.Equal(c.selected[:c.selectedSize], c.batchEntries[0].Key) || !bytes.Equal(c.record.Key, before.Key) {
		t.Fatal("same buffered selection not retained")
	}
}

func TestNativeCursorFinalLeaseCloseAdmissionV6(t *testing.T) {
	b, err := memtable.NewCOWBudget(memtable.DefaultCOWLimits())
	if err != nil {
		t.Fatal(err)
	}
	defer b.Close()
	lease, err := b.AcquireExternal(128)
	if err != nil {
		t.Fatal(err)
	}
	c := PruneCursor{retention: lease, retainedBytes: 128, closePhase: 4}
	before := b.Stats()
	// Entry and final alias-clear row fit; concrete final lease Close does not.
	w := iterator.OrdinalScanWork{RecordLimit: 2, ByteLimit: 1 << 20}
	returned, ready, err := c.CloseNativePublicationStepV6(&w)
	if err != nil || ready || returned != nil || c.closed || c.retention != lease || b.Stats() != before {
		t.Fatal("close refusal lost original lease", ready, err)
	}
	w = iterator.OrdinalScanWork{RecordLimit: 3, ByteLimit: 1 << 20}
	returned, ready, err = c.CloseNativePublicationStepV6(&w)
	if err != nil || !ready || returned != lease || !c.closed || c.retention != nil || b.Stats() != before {
		t.Fatal("final admission did not detach same lease", ready, err)
	}
	returned.Close()
	after := b.Stats()
	w = iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
	returned, ready, err = c.CloseNativePublicationStepV6(&w)
	if err != nil || !ready || returned != nil || b.Stats() != after {
		t.Fatal("terminal replay", ready, err)
	}
}

func TestNativeCursorBatchRefundAdmissionV6(t *testing.T) {
	b, err := memtable.NewCOWBudget(memtable.DefaultCOWLimits())
	if err != nil {
		t.Fatal(err)
	}
	defer b.Close()
	lease, err := b.AcquireExternal(256)
	if err != nil {
		t.Fatal(err)
	}
	defer lease.Close()
	c := PruneCursor{retention: lease, retainedBytes: 256, batchPayloadCharge: 128, phase: 20, batchEntries: make([]node.LeafEntry, 0, 1), flushBeforeAnchor: true, anchorSize: 6}
	copy(c.anchorKey[:], "anchor")
	before := b.Stats()
	byteLimit := 2*uint64(unsafe.Sizeof(c)) + 2*uint64(unsafe.Sizeof(memtable.COWExternalLease{})) + 2*uint64(unsafe.Sizeof(memtable.COWBudget{})) + 256
	// The fixed header and actual anchor copy fit; ResizeWork must refuse.
	w := iterator.OrdinalScanWork{RecordLimit: 2, ByteLimit: byteLimit}
	if err := c.step(&PruneStats{}, &w); err != nil {
		t.Fatal(err)
	}
	if c.phase != 20 || c.batchPayloadCharge != 128 || c.retainedBytes != 256 || !c.flushBeforeAnchor || b.Stats() != before {
		t.Fatal("resize refusal changed original debt")
	}
	// Stop just after the same phase20 unit; the following phase12 header cannot
	// fit. This exercises refund/copy without any DB/producer/publication call.
	w = iterator.OrdinalScanWork{RecordLimit: 3, ByteLimit: byteLimit}
	if err := c.step(&PruneStats{}, &w); err != nil {
		t.Fatal(err)
	}
	if c.phase != 12 || c.batchPayloadCharge != 0 || c.retainedBytes != 128 || !bytes.Equal(c.selected[:c.selectedSize], []byte("anchor")) {
		t.Fatal("same refund/copy did not complete")
	}
	if before.TotalBytes-b.Stats().TotalBytes != 128 {
		t.Fatal("wrong original refund")
	}
}
