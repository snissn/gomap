package tree

import (
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
	"unsafe"
)

// NativeProjectionPriceForTestV6 sums each selected local phase alternative
// once, plus each actual completed-child/trailing-reservation compound. This
// conservative acyclic sum bounds next progress; persistent pivots, indices,
// CRC offsets and decoder offsets are not multiplied into a whole scan.
func NativeProjectionPriceForTestV6(keyBytes, frameR, frameB, frameCancelR, frameCancelB uint64) (records, bytes, closeR, closeB uint64, complete bool) {
	if keyBytes > page.PageSize {
		return
	}
	type unit struct{ r, b uint64 }
	sum := func(rows ...unit) (u unit, ok bool) {
		for _, v := range rows {
			if v.r > ^uint64(0)-u.r || v.b > ^uint64(0)-u.b {
				return unit{}, false
			}
			u.r += v.r
			u.b += v.b
		}
		return u, true
	}
	leaf := uint64(unsafe.Sizeof(node.LeafEntry{}))
	decoder := uint64(unsafe.Sizeof(node.ProjectionDecoder{}))
	comparison := uint64(unsafe.Sizeof(node.ProjectionComparison{}))
	ref := uint64(unsafe.Sizeof(page.ChildRef{}))
	item := uint64(unsafe.Sizeof(CursorItem{}))
	decode, ok := sum(unit{1, decoder + uint64(unsafe.Sizeof(node.Node{}))}, unit{1, page.PageSize + leaf}, unit{1, 2 * page.PageSize}, unit{1, leaf + ref})
	if !ok {
		return
	}
	compare := unit{1, comparison + 2*keyBytes}
	rows := []unit{
		{1, ChargedProjectionRetainedCharge() + uint64(unsafe.Sizeof(Tree{}))}, {1, leaf + 64}, {1, 64}, {1, 2 * leaf},
		{1, 2*uint64(unsafe.Sizeof(NativeMVCCSelectionV6{})) + keyBytes}, {1, 2*uint64(unsafe.Sizeof(Tree{})) + 2*leaf + 2*keyBytes},
		{2, 2 * (page.PageSize + 64)}, {1, uint64(unsafe.Sizeof(node.PrimaryOperand{})) + uint64(unsafe.Sizeof(node.PrimaryDirectoryView{}))},
		{1, 64}, {1, 64}, {frameR, frameB}, {1, 24}, {1, 8}, {1, uint64(unsafe.Sizeof(node.PrimaryDirectoryEntry{})) + 64}, compare, {1, 16},
		{1, uint64(unsafe.Sizeof(node.PrimaryDirectoryEntry{})) + 64}, {1, 32}, compare, {1, 16}, {1, leaf}, {1, ref + 32}, {frameR, frameB},
		{1, page.PageSize + uint64(unsafe.Sizeof(node.Node{}))}, {1, page.PageSize + 32}, decode, {1, leaf}, compare, {1, leaf}, compare, compare,
		{1, 32}, {1, leaf + 32}, {1, 2 * keyBytes}, {1, 96}, compare, {1, 64}, {1, 32},
		// One DATA-leaf BaseStep (internal child frames excluded by shape).
		{1, item}, {1, 64}, {1, ref + 32}, {frameR, frameB}, {1, page.PageSize}, {1, 16 + item}, {1, page.PageSize + 32}, {1, 32}, {1, 16}, {1, 8},
		decode, compare, {1, 16}, {1, 8}, decode, {1, leaf}, {1, 8}, {1, item}, {1, leaf + 32},
	}
	u, ok := sum(rows...)
	if !ok {
		return
	}
	records, bytes = u.r, u.b
	// Stack clear is persistent, but summing its actual fixed50 entries is a
	// stronger finite close bound and includes both decoder/comparison cancels.
	c, ok := sum(unit{1, 32}, unit{maxTraversalDepth, uint64(maxTraversalDepth) * item}, unit{2, 2 * decoder}, unit{2, 2 * comparison}, unit{1, 2*leaf + uint64(unsafe.Sizeof(node.PrimaryDirectoryEntry{})) + uint64(unsafe.Sizeof(node.PrimaryDirectoryView{})) + uint64(unsafe.Sizeof(node.Node{})) + 256}, unit{frameCancelR, frameCancelB}, unit{1, uint64(unsafe.Sizeof(Tree{})) + 96})
	if !ok {
		return
	}
	closeR, closeB = c.r, c.b
	complete = true
	return
}
