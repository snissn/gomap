package rootpublication

import (
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/tree"
	"unsafe"
)

// NativeResourceTerminalPriceForTestV6 sums all selected graph alternatives
// once, together with the complete repeated frame prefix. The original graph
// stores current/phase/offset/index before another iteration. ownedPager,
// directory and pin are the separately source-derived typed child units.
// Empty manifest/obligations/wrappers and the ordered no-competing-CAS shape
// must be checked at ready; this function grants no disposal authority.
func NativeResourceTerminalPriceForTestV6(ownerR, ownerB, ownedR, ownedB, directoryR, directoryB, pinR, pinB uint64) (records, bytes uint64, complete bool) {
	terms := [...][2]uint64{
		{1, 2*uint64(unsafe.Sizeof(StableResourceSet{})) + 2*uint64(unsafe.Sizeof(resourceAllocation{}))},
		{1, uint64(unsafe.Sizeof(resourceReleaseFrameV6{}))},
		{ownerR, ownerB}, {ownerR, ownerB},
		{2, 4 * uint64(unsafe.Sizeof(resourceReleaseFrameV6{}))},
		{1, 2 * uint64(unsafe.Sizeof(resourceAllocation{}))},
		{1, 2 * uint64(unsafe.Sizeof(StableResourceSet{}))},
		{1, 2 * uint64(unsafe.Sizeof((*dependencyManifestEncodedEntryV1)(nil)))},
		{1, 2 * uint64(unsafe.Sizeof(dependencyManifestEncodedEntryV1{}))},
		{1, 4096},
		{1, 2 * uint64(unsafe.Sizeof(resourcePinnedBacking{}))},
		{1, 2*uint64(unsafe.Sizeof(resourcePinnedBacking{})) + 128},
		{1, 2*uint64(unsafe.Sizeof(stableResourceEntryNode{})) + 2*uint64(unsafe.Sizeof(resourceAllocation{}))},
		{1, 16}, // original rope CAS; selected schedule has no simultaneous mutation
		{1, 2 * uint64(unsafe.Sizeof(StableResourceToken{}))},
		{1, 2*uint64(unsafe.Sizeof(resourceReleaseFrameV6{})) + 2*uint64(unsafe.Sizeof(resourceAllocation{})) + 2*uint64(unsafe.Sizeof(retainedalloc.Owner{})) + 2*uint64(unsafe.Sizeof(StableResourceSet{})) + 2*uint64(unsafe.Sizeof(StableResourceToken{})) + 2*uint64(unsafe.Sizeof(resourcePinnedBacking{})) + 2*uint64(unsafe.Sizeof(IdentityPinRegistry{}))},
		// Original strict token's actual phase rows (including both namespace FDs).
		{1, 2 * uint64(unsafe.Sizeof(StableResourceToken{}))},
		{1, 2*uint64(unsafe.Sizeof(resourcePinnedBacking{})) + 64},
		{4, 4*uint64(unsafe.Sizeof(StableNamespaceToken{})) + 256},
		{pinR, pinB}, {ownedR, ownedB},
		{1, 2 * uint64(unsafe.Sizeof(resourceAllocation{}))},
		{1, 2 * uint64(unsafe.Sizeof(StableLogicalObligation{}))},
		{1, 2 * uint64(unsafe.Sizeof(resourceObligationBacking{}))},
		{1, 2 * uint64(unsafe.Sizeof(StableResourceToken{}))},
		{directoryR, directoryB},
	}
	for _, v := range terms {
		if v[0] > ^uint64(0)-records || v[1] > ^uint64(0)-bytes {
			return 0, 0, false
		}
		records += v[0]
		bytes += v[1]
	}
	complete = true
	return
}

// Local directory rows include its original scratch constructor and reset.
// provider is the real DB primaryDependencyLease child, not a callback shim.
func NativeDirectoryTerminalPriceForTestV6(ownerR, ownerB, addR, addB, providerR, providerB uint64) (records, bytes uint64, complete bool) {
	terms := [...][2]uint64{
		{1, retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(DependencyDirectoryReleaseWork{})))}, {addR, addB},
		{1, 2*uint64(unsafe.Sizeof(DependencyDirectoryV2{})) + 2*uint64(unsafe.Sizeof(DependencyDirectoryReleaseWork{}))},
		{1, 16}, // no competing ref mutation in selected drain
		{1, 2 * uint64(unsafe.Sizeof(DependencyDirectoryV2{}))},
		{1, 2 * uint64(unsafe.Sizeof(tree.Tree{}))},
		{providerR, providerB},
		{ownerR, ownerB}, {ownerR, ownerB},
		{1, 2*uint64(unsafe.Sizeof(DependencyDirectoryV2{})) + 2*uint64(unsafe.Sizeof(DependencyDirectoryReleaseWork{}))},
		{1, 2 * uint64(unsafe.Sizeof(DependencyDirectoryReleaseWork{}))},
		{2, 4 * uint64(unsafe.Sizeof(retainedalloc.RemovalWork{}))},
	}
	for _, v := range terms {
		if v[0] > ^uint64(0)-records || v[1] > ^uint64(0)-bytes {
			return 0, 0, false
		}
		records += v[0]
		bytes += v[1]
	}
	complete = true
	return
}
