package rootpublication

import (
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
)

// NativeCaptureConstructorGeometryForTestV6 contains precursor bounds for the
// original two index captures. ProofParentNameBytes includes a newly created
// proof's #stable-pin suffix; RegistryCapacity includes both possible births.
// OwnerAdd is the complete original same-owner admission, including bindings.
type NativeCaptureConstructorGeometryForTestV6 struct {
	ParentNameBytes, FileNameBytes, ProofParentNameBytes uint64
	NameBytes, DiagnosticPathBytes, LogicalLaneBytes     uint64
	RegistryCapacity, PlatformBytes                      uint64
	OwnerAddRecords, OwnerAddBytes                       uint64
}

type NativeCaptureConstructorUnitsForTestV6 struct {
	ProofRecords, ProofBytes     uint64
	BindRecords, BindBytes       uint64
	TokenRecords, TokenBytes     uint64
	CustodyRecords, CustodyBytes uint64
	Complete                     bool
}

// NativeCaptureConstructorPriceForTestV6 sums each original saved constructor
// phase once. This suffices for a next-progress unit after the caller's repeated
// capture/operations prefixes are added. Observe, Unobserve and terminal child
// rows remain separate. The selected empty descriptor/obligation shape and no
// competing reference mutation are caller predicates, not facts proved here.
// This expression creates no file, token, owner, registry or disposal authority.
func NativeCaptureConstructorPriceForTestV6(g NativeCaptureConstructorGeometryForTestV6) (v NativeCaptureConstructorUnitsForTestV6) {
	if g.RegistryCapacity == 0 || g.OwnerAddRecords == 0 || g.OwnerAddBytes == 0 {
		return v
	}
	type unit struct{ r, b uint64 }
	add := func(u *unit, r, b uint64) bool {
		if r > ^uint64(0)-u.r || b > ^uint64(0)-u.b {
			return false
		}
		u.r += r
		u.b += b
		return true
	}
	addScaled := func(u *unit, n, r, b uint64) bool {
		if n != 0 && (r > ^uint64(0)/n || b > ^uint64(0)/n) {
			return false
		}
		return add(u, n*r, n*b)
	}
	fileCharge := func(n, suffix uint64) (uint64, bool) {
		if suffix > ^uint64(0)-n {
			return 0, false
		}
		// StableFileMetadataCharge adds two fixed allocator charges to the
		// separately rounded name. Check that sum before invoking it.
		name := retainedalloc.AllocationCharge(n + suffix)
		base, err := StableFileMetadataCharge(0)
		if err != nil || name == ^uint64(0) || name > ^uint64(0)-base {
			return 0, false
		}
		charge, err := StableFileMetadataCharge(n + suffix)
		return charge, err == nil && charge == base+name
	}
	parent, ok := fileCharge(g.ParentNameBytes, uint64(len("#stable-pin")))
	if !ok {
		return v
	}
	child, ok := fileCharge(g.FileNameBytes, uint64(len("#stable-sync-pin")))
	if !ok {
		return v
	}
	boundParent, ok := fileCharge(g.ProofParentNameBytes, uint64(len("#stable-pin")))
	if !ok {
		return v
	}
	file, ok := fileCharge(g.FileNameBytes, uint64(len("#stable-pin")))
	if !ok {
		return v
	}
	var proof, bind, token, custody unit
	if !add(&proof, 18, 2*uint64(unsafe.Sizeof(StableNamespaceCreationProof{}))) ||
		!addScaled(&proof, 4, 0, parent) || !addScaled(&proof, 4, 0, child) ||
		!addScaled(&proof, 4, 0, g.NameBytes) || !add(&proof, g.OwnerAddRecords, g.OwnerAddBytes) {
		return v
	}
	if !add(&bind, 8, 2*uint64(unsafe.Sizeof(StableNamespaceToken{}))) ||
		!addScaled(&bind, 2, 0, boundParent) || !addScaled(&bind, 2, 0, g.NameBytes) ||
		!addScaled(&bind, 2, 0, g.DiagnosticPathBytes) || !add(&bind, g.OwnerAddRecords, g.OwnerAddBytes) {
		return v
	}
	if !add(&custody, 2, 2*uint64(unsafe.Sizeof(IdentityPinRegistry{}))+2*uint64(unsafe.Sizeof(resourcePinnedBacking{}))) ||
		!add(&custody, g.OwnerAddRecords, g.OwnerAddBytes) {
		return v
	}
	// Phase 0 includes both actual policy traversals. Counting the complete
	// static policy inventory is conservative for its first index-file row.
	if !add(&token, 2, 2*uint64(unsafe.Sizeof(StableResourceSpec{}))) ||
		!addScaled(&token, uint64(len(canonicalReachabilityRequirements)), 2, 2*uint64(unsafe.Sizeof(canonicalReachabilityRequirements[0]))) {
		return v
	}
	// Phase 1's complete local row repeats before each missing child. Once
	// a child exists its field persists, so one whole row plus all three
	// admissions dominates the work through the next saved child/phase.
	if !add(&token, 12, 2*(uint64(unsafe.Sizeof(StableResourceToken{}))+3*uint64(unsafe.Sizeof(resourceAllocation{}))+uint64(unsafe.Sizeof(resourceObligationBacking{}))+uint64(unsafe.Sizeof(resourcePinnedBacking{})))) ||
		!addScaled(&token, 2, 0, file) || !addScaled(&token, 3, g.OwnerAddRecords, g.OwnerAddBytes) ||
		!add(&token, 1, 2*uint64(unsafe.Sizeof(StableResourceToken{}))) {
		return v
	}
	// All six original descriptor copies, with an empty identity override.
	strings := [...]uint64{uint64(len(ResourceIndex)), g.LogicalLaneBytes, g.NameBytes, g.DiagnosticPathBytes, uint64(len(ReachabilityIndexFile)), 0}
	for _, n := range strings {
		if !add(&token, 1, 2*uint64(unsafe.Sizeof(""))) || !addScaled(&token, 2, 0, n) {
			return v
		}
	}
	if !add(&token, 1, 0) || !addScaled(&token, 2, 0, file) ||
		!add(&token, 2, 2*uint64(unsafe.Sizeof(StableIdentity{}))+256) {
		return v
	}
	// Pin uses the SAME original canonical state. Its ObjectID is a fixed
	// array; every possible table link and the actual platform bytes are paid.
	if !add(&token, 1, uint64(len(StableIdentity{}.ObjectID))) || !add(&token, 0, g.PlatformBytes) ||
		!addScaled(&token, g.RegistryCapacity, 1, 2*uint64(unsafe.Sizeof(registryCell[StableIdentity, *identityPinState]{}))+2*uint64(unsafe.Sizeof(identityPinState{}))) ||
		!add(&token, 1, 2*uint64(unsafe.Sizeof(IdentityPin{}))+2*uint64(unsafe.Sizeof(identityPinState{}))) ||
		!add(&token, 3, 2*uint64(unsafe.Sizeof(StableResourceToken{}))+2*uint64(unsafe.Sizeof(StableNamespaceToken{}))) ||
		!add(&token, 1, 2*uint64(unsafe.Sizeof(StableIndexTokenConstructionWorkV6{}))) {
		return v
	}
	v.ProofRecords, v.ProofBytes = proof.r, proof.b
	v.BindRecords, v.BindBytes = bind.r, bind.b
	v.TokenRecords, v.TokenBytes = token.r, token.b
	v.CustodyRecords, v.CustodyBytes = custody.r, custody.b
	v.Complete = true
	return v
}
