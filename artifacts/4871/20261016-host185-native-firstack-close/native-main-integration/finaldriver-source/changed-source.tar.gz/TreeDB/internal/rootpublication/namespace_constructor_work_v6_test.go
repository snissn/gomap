package rootpublication

import (
	"errors"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"os"
	"path/filepath"
	"testing"
	"unsafe"
)

func TestNativeNamespaceConstructorOwnerAdmissionV6(t *testing.T) {
	if !StableRelativeNamespaceSupported() {
		t.Skip("relative namespace unsupported")
	}
	for _, shape := range []string{"work-refusal", "unsupported", "success", "duplicate-failure", "ordinary"} {
		t.Run(shape, func(t *testing.T) {
			dir := t.TempDir()
			parent, err := os.Open(dir)
			if err != nil {
				t.Fatal(err)
			}
			defer parent.Close()
			child, err := os.Create(filepath.Join(dir, "primary"))
			if err != nil {
				t.Fatal(err)
			}
			defer child.Close()
			var owner retainedalloc.Owner
			owner.Initialize(0)
			var enrollment *retainedalloc.Enrollment
			if shape == "unsupported" {
				enrollment, err = owner.Enroll(&registryBudget{cap: 1 << 20})
			} else {
				budget, e := memtable.NewCOWBudget(memtable.DefaultCOWLimits())
				if e != nil {
					t.Fatal(e)
				}
				defer budget.Close()
				enrollment, err = owner.Enroll(budget)
			}
			if err != nil {
				t.Fatal(err)
			}
			defer enrollment.Close()
			before := owner.Bytes()
			resize := 2*uint64(unsafe.Sizeof(memtable.COWExternalLease{})) + 2*uint64(unsafe.Sizeof(memtable.COWBudget{}))
			gr, gb, ok := retainedalloc.NativeOwnerGrowthPriceForTestV6(1, resize)
			if !ok {
				t.Fatal("growth price")
			}
			fp, e := StableFileMetadataCharge(uint64(len(parent.Name()) + len("#stable-pin")))
			if e != nil {
				t.Fatal(e)
			}
			fc, e := StableFileMetadataCharge(uint64(len(child.Name()) + len("#stable-sync-pin")))
			if e != nil {
				t.Fatal(e)
			}
			creationBytes := 2*uint64(unsafe.Sizeof(StableNamespaceCreationProof{})) + 4*(fp+fc) + 4*uint64(len("primary"))
			if shape == "work-refusal" {
				p, ready, err := NewOwnedStableNamespaceCreationProofWithWorkV6(parent, child, "primary", &owner, &iterator.OrdinalScanWork{RecordLimit: 18, ByteLimit: creationBytes + gb})
				if p != nil || ready || err != nil || owner.Bytes() != before {
					t.Fatal("refusal allocated proof", p, ready, err)
				}
				return
			}
			if shape == "ordinary" {
				p, err := NewOwnedStableNamespaceCreationProof(parent, child, "primary", &owner)
				if err != nil {
					t.Fatal(err)
				}
				n, err := p.Bind(parent, 1, "primary", "primary")
				if err != nil {
					t.Fatal(err)
				}
				n.Release()
				p.Release()
				if owner.Bytes() != before {
					t.Fatal("ordinary cleanup changed", owner.Bytes(), before)
				}
				return
			}
			p, ready, err := NewOwnedStableNamespaceCreationProofWithWorkV6(parent, child, "primary", &owner, &iterator.OrdinalScanWork{RecordLimit: 18 + gr, ByteLimit: creationBytes + gb})
			if shape == "unsupported" {
				if p != nil || ready || err != retainedalloc.ErrWorkRequired || owner.Bytes() != before {
					t.Fatal("unsupported binding changed proof", ready, err)
				}
				return
			}
			if !ready || err != nil || p == nil {
				t.Fatal(ready, err)
			}
			// The independent Bind's fixed local reservation is insufficient for the
			// SAME concrete owner growth. Original cached proof remains untouched.
			proofBytes := owner.Bytes()
			bindBytes := 2*uint64(unsafe.Sizeof(StableNamespaceToken{})) + 2*fp + 4*uint64(len("primary"))
			if n, ready, err := p.BindWithMetadataWithWorkV6(parent, 1, "primary", "primary", &owner, &iterator.OrdinalScanWork{RecordLimit: 8, ByteLimit: bindBytes + gb}); n != nil || ready || err != nil || owner.Bytes() != proofBytes {
				t.Fatal("binding refusal changed proof", n, ready, err)
			}
			full := &iterator.OrdinalScanWork{RecordLimit: 8 + gr, ByteLimit: bindBytes + gb}
			var n *StableNamespaceToken
			if shape == "duplicate-failure" {
				cause := errors.New("original duplicate failure")
				n, err = p.bindWithMetadataDuplicateV6(parent, 1, "primary", "primary", &owner, true, full, func(*os.File) (*os.File, error) { return nil, cause })
				if n == nil || !errors.Is(err, cause) || n.parent != nil || n.persistence != nil || n.refs.Load() != 1 || n.metadata != &owner || n.metadataCharge == 0 || owner.Bytes() <= proofBytes {
					t.Fatal("partial namespace custody lost", n, err)
				}
			} else {
				n, ready, err = p.BindWithMetadataWithWorkV6(parent, 1, "primary", "primary", &owner, full)
				if !ready || err != nil || n == nil || n.parent == nil || n.refs.Load() != 1 {
					t.Fatal(ready, err)
				}
			}
			var phase uint8
			var removal retainedalloc.RemovalWork
			rr, rb, ok := retainedalloc.NativeRemovalUnitForTestV6(resize)
			if !ok {
				t.Fatal("removal price")
			}
			closeWork := &iterator.OrdinalScanWork{RecordLimit: 4 + rr, ByteLimit: 4*uint64(unsafe.Sizeof(StableNamespaceToken{})) + 256 + rb}
			completion, done, err := n.ReleaseWithWorkV6(&phase, closeWork)
			if !done || err != nil {
				t.Fatal(done, err)
			}
			n = nil // detach original physical alias before refund
			if done, err = completion.CompleteWithWorkV6(&removal, closeWork); !done || err != nil || owner.Bytes() != proofBytes {
				t.Fatal("partial token cleanup", done, err, owner.Bytes(), proofBytes)
			}
			// Bind transfers the original proof edge to its actual finite receipt.
			var proofClose NamespaceProofReleaseWork
			proofCloseBytes := 10*uint64(unsafe.Sizeof(StableNamespaceCreationProof{})) + 4*uint64(unsafe.Sizeof(os.File{})) + 2*uint64(unsafe.Sizeof(NamespaceProofReleaseWork{})) + 256 + rb
			if ready, e := proofClose.Bind(p, &iterator.OrdinalScanWork{RecordLimit: 1, ByteLimit: proofCloseBytes}); !ready || e != nil {
				t.Fatal(ready, e)
			}
			p = nil
			done = false
			for turns := 0; !done && turns < 8; turns++ {
				done, err = proofClose.ContinueWork(&iterator.OrdinalScanWork{RecordLimit: 4 + rr, ByteLimit: proofCloseBytes})
				if err != nil {
					t.Fatal(err)
				}
			}
			if !done || owner.Bytes() != before {
				t.Fatal("original proof cleanup incomplete", owner.Bytes(), before)
			}
		})
	}
}
