package rootpublication

import (
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"unsafe"
)

// NativeCoordinatorTerminalPriceForTestV6 bounds the genuine original
// receipt's recovery view and complete/unlink operation for one linked native
// owner. The fixture must prove this single-owner policy before cursor birth.
// This counts the canonical GC notification service's allocation traffic; it
// does not claim retained-owner refunds for channels or transitive heap size.
func NativeCoordinatorTerminalPriceForTestV6() (records, bytes uint64) {
	notifyBytes := nativeDiagnosticHchanBytesV6 + 3*uint64(unsafe.Sizeof((chan struct{})(nil)))
	return 16, uint64(unsafe.Sizeof(NativePublicationV6{})) +
		uint64(unsafe.Sizeof(NativePublicationV6{})) + uint64(unsafe.Sizeof(builderHandle{})) + uint64(unsafe.Sizeof(builderLease{})) + uint64(unsafe.Sizeof(BuilderHandoffReceipt{})) + 32 +
		notifyBytes + uint64(unsafe.Sizeof((chan struct{})(nil))) +
		uint64(unsafe.Sizeof([]error{})) + 2*uint64(unsafe.Sizeof(error(nil))) +
		uint64(unsafe.Sizeof((**NativePublicationV6)(nil))) + uint64(unsafe.Sizeof((*NativePublicationV6)(nil))) +
		2*uint64(unsafe.Sizeof(NativePublicationV6{})) + 2*uint64(unsafe.Sizeof(PublishAttempt{})) + 32
}

// NativeFinishHeaderPriceForTestV6 is the sum of original transaction and
// terminal-receipt wrappers, including Bind and accounting-only completion.
// Actual DB member/seal callback children are priced separately.
func NativeFinishHeaderPriceForTestV6() (records, bytes uint64) {
	return 4, 4*uint64(unsafe.Sizeof(DurableRootTransaction{})) +
		2*uint64(unsafe.Sizeof(primaryTransactionConstructionV6{})) +
		2*uint64(unsafe.Sizeof(PrimaryConstructionReleaseWork{})) +
		2*uint64(unsafe.Sizeof(primaryTerminalCompletionV6{}))
}

func NativePinnedBackingRawForTestV6() uint64 { return uint64(unsafe.Sizeof(resourcePinnedBacking{})) }
func NativeOwnerRawForTestV6() uint64         { return uint64(unsafe.Sizeof(retainedalloc.Owner{})) }
