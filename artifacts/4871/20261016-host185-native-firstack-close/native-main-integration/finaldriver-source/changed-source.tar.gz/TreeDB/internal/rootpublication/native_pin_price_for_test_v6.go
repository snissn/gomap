package rootpublication

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"unsafe"
)

// The caller excludes all registry mutators between steps. These original
// capacity/count/used scalars detect structural drift; no backing pointer or
// synthetic registry version escapes. Each actual cell/string is read once.
type NativePreCursorRegistryForTestV6 struct {
	StateCapacity, StateCount, StateUsed, NamespaceCapacity, LinkCapacity, DirectoryLinkCapacity, PlatformBytes uint64
	Closing                                                                                                     bool
}
type NativePreCursorRegistryScanForTestV6 struct {
	Geometry                 NativePreCursorRegistryForTestV6
	Next                     uint64
	Started, Complete, Drift bool
}

func (r *IdentityPinRegistry) MaintenanceNativePreCursorStepForTestV6(c *NativePreCursorRegistryScanForTestV6, w *iterator.OrdinalScanWork) (bool, bool) {
	if r == nil || c == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(*c))+2*uint64(unsafe.Sizeof(*r))) {
		return false, false
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	g := NativePreCursorRegistryForTestV6{StateCapacity: uint64(len(r.states.cells)), StateCount: uint64(r.states.count), StateUsed: uint64(r.states.used), NamespaceCapacity: uint64(len(r.namespaces.cells)), LinkCapacity: uint64(len(r.stableLinks.cells)), DirectoryLinkCapacity: uint64(len(r.stableDirectoryLinks.cells)), Closing: r.closing}
	if c.Started {
		old := c.Geometry
		old.PlatformBytes = 0
		if old != g {
			c.Drift = true
			return false, true
		}
	} else {
		c.Geometry = g
		c.Started = true
	}
	if c.Drift {
		return false, true
	}
	for c.Next < g.StateCapacity {
		if !w.Reserve(1, 2*uint64(unsafe.Sizeof(r.states.cells[0]))) {
			return false, false
		}
		cell := &r.states.cells[c.Next]
		if cell.status == 1 {
			n := uint64(len(cell.key.Platform))
			if !w.Reserve(1, n) {
				return false, false
			}
			c.Geometry.PlatformBytes = max(c.Geometry.PlatformBytes, n)
		}
		c.Next++
	}
	c.Complete = true
	return true, true
}
func (r *IdentityPinRegistry) MaintenanceNativePreCursorForTestV6(w *iterator.OrdinalScanWork) (g NativePreCursorRegistryForTestV6, ready bool) {
	var c NativePreCursorRegistryScanForTestV6
	done, ready := r.MaintenanceNativePreCursorStepForTestV6(&c, w)
	return c.Geometry, done && ready && !c.Drift
}

// Original table grows at most twice for the two selected new index physical
// identities; replacement of tombstones never grows more than this. No other
// producer/capture is permitted by this diagnostic shape.
func NativeSelectedRegistryCapacityForTestV6(g NativePreCursorRegistryForTestV6) (uint64, bool) {
	if g.Closing || g.StateCount > g.StateCapacity {
		return 0, false
	}
	n := max(uint64(16), g.StateCapacity)
	if n > ^uint64(0)/4 {
		return 0, false
	}
	return n * 4, true
}
func NativePinReleasePriceForTestV6(capacity, bindings, resizeBytes, platformBytes uint64) (records, bytes uint64, complete bool) {
	r, b, ok := retainedalloc.NativeAtomicRemovalPriceForTestV6(bindings, resizeBytes)
	if !ok {
		return
	}
	cell := 2*uint64(unsafe.Sizeof(registryCell[StableIdentity, *identityPinState]{})) + 2*uint64(unsafe.Sizeof(identityPinState{}))
	if r > ^uint64(0)-4 || capacity > ^uint64(0)-r-4 || capacity > (^uint64(0)-b)/cell {
		return
	}
	records = r + 4 + capacity
	bytes = b + capacity*cell
	fixed := 4*uint64(unsafe.Sizeof(IdentityPin{})) + 4*uint64(unsafe.Sizeof(identityPinState{})) + 2*uint64(unsafe.Sizeof(registryCell[StableIdentity, *identityPinState]{})) + 256 + 16
	if platformBytes > ^uint64(0)-fixed || fixed+platformBytes > ^uint64(0)-bytes {
		return
	}
	bytes += fixed + platformBytes
	complete = true
	return
}

// A source-shaped worst replacement for one of the TWO original captures.
// capacity already includes both possible doublings. Actual Observe rechecks
// every original count and concrete lease under its original locks.
func NativeObservePriceForTestV6(capacity, bindings, resizeBytes, platformBytes uint64) (records, bytes uint64, complete bool) {
	ar, ab, ok := retainedalloc.NativeAtomicRemovalPriceForTestV6(bindings, resizeBytes)
	if !ok {
		return
	}
	gr, gb, ok := retainedalloc.NativeOwnerGrowthPriceForTestV6(bindings, resizeBytes)
	if !ok {
		return
	}
	add := func(r, b uint64) bool {
		if r > ^uint64(0)-records || b > ^uint64(0)-bytes {
			return false
		}
		records += r
		bytes += b
		return true
	}
	cell := uint64(unsafe.Sizeof(registryCell[StableIdentity, *identityPinState]{}))
	state := uint64(unsafe.Sizeof(identityPinState{}))
	if capacity == ^uint64(0) || capacity != 0 && capacity+1 > ^uint64(0)/capacity {
		return
	}
	probes := capacity * (capacity + 1)
	if platformBytes > ^uint64(0)-2*cell-16 {
		return
	}
	comparison := 2*cell + platformBytes + 16
	if probes > ^uint64(0)/comparison || capacity > ^uint64(0)/(4*cell+platformBytes+16) || capacity > (^uint64(0)-2)/2 {
		return
	}
	allocated := 2 * capacity * cell
	probed := probes * comparison
	if allocated > ^uint64(0)-2*state || probed > ^uint64(0)-allocated-2*state {
		return
	}
	// Entry and lookup, admitted old-cell/string census, original backing clear,
	// reinsertion/new insertion, then SAME atomic owner peak+shrink.
	if !add(1, 2*uint64(unsafe.Sizeof(StableIdentity{}))+platformBytes) || !add(1, 2*uint64(unsafe.Sizeof(IdentityPinRegistry{}))) || !add(capacity, capacity*(2*cell+2*state)) || !add(2*capacity, capacity*(2*cell+platformBytes+16)) || !add(2+probes, 2*state+allocated+probed) || !add(ar, ab) || !add(gr, gb) {
		return
	}
	complete = true
	return
}

// Caller holds the original physical owner's namespace exclusion. Only the
// stored parent-name length escapes; no file, proof or namespace edge does.
func (p *StableNamespaceCreationProof) NativeParentNameBytesForTestV6(w *iterator.OrdinalScanWork) (uint64, bool) {
	if w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(StableNamespaceCreationProof{}))+128) {
		return 0, false
	}
	if p == nil || p.parent == nil {
		return 0, true
	}
	return uint64(len(p.parent.Name())), true
}
