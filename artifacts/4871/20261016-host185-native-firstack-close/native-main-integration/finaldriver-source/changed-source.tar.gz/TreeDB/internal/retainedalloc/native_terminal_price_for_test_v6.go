package retainedalloc

import "unsafe"

// NativeRemovalUnitForTestV6 bounds one original resumable shrink advance,
// including its repeated bind/header prefix and optional active-enrollment and
// disposal alternatives. resizeBytes is the actual concrete lease price.
// Binding count bounds turns, rather than this persisted-cursor unit.
func NativeRemovalUnitForTestV6(resizeBytes uint64) (records, bytes uint64, complete bool) {
	terms := [...]uint64{
		2*uint64(unsafe.Sizeof(RemovalWork{})) + 128,
		2*uint64(unsafe.Sizeof(Owner{})) + 2*uint64(unsafe.Sizeof(RemovalWork{})) + 128,
		2*uint64(unsafe.Sizeof(Owner{})) + 2*uint64(unsafe.Sizeof(EnrollmentWork{})),
		resizeBytes,
		2*uint64(unsafe.Sizeof(Owner{})) + 128,
		2*uint64(unsafe.Sizeof(binding{})) + 2*uint64(unsafe.Sizeof(Owner{})) + 128,
		resizeBytes,
		6*uint64(unsafe.Sizeof(binding{})) + 128,
		resizeBytes,
		2 * uint64(unsafe.Sizeof(RemovalWork{})),
	}
	for _, n := range terms {
		if n > ^uint64(0)-bytes {
			return 0, 0, false
		}
		bytes += n
	}
	return 12, bytes, true
}

// NativeEnrollmentUnitForTestV6 is the conservative two-branch cancellation
// plus released-edge prefix. It includes two actual original owner removals.
func NativeEnrollmentUnitForTestV6(removeRecords, removeBytes, resizeBytes uint64) (records, bytes uint64, complete bool) {
	terms := [...][2]uint64{
		{1, 2 * uint64(unsafe.Sizeof(EnrollmentWork{}))},
		{1, 2*uint64(unsafe.Sizeof(EnrollmentWork{})) + 2*uint64(unsafe.Sizeof(Owner{})) + 4*uint64(unsafe.Sizeof(binding{}))},
		{removeRecords, removeBytes},
		{1, 2*uint64(unsafe.Sizeof(EnrollmentWork{})) + 2*uint64(unsafe.Sizeof(Owner{})) + 2*uint64(unsafe.Sizeof(binding{}))},
		{1, resizeBytes}, {removeRecords, removeBytes},
		{1, 2*uint64(unsafe.Sizeof(EnrollmentWork{})) + 2*uint64(unsafe.Sizeof(Owner{}))}, {1, resizeBytes},
		{2, 4*uint64(unsafe.Sizeof(EnrollmentReleaseWork{})) + 4*uint64(unsafe.Sizeof(Enrollment{})) + 256},
		{2, 4*uint64(unsafe.Sizeof(Enrollment{})) + 4*uint64(unsafe.Sizeof(binding{})) + 4*uint64(unsafe.Sizeof(RemovalWork{})) + 256},
		{removeRecords, removeBytes}, {removeRecords, removeBytes},
	}
	for _, n := range terms {
		if n[0] > ^uint64(0)-records || n[1] > ^uint64(0)-bytes {
			return 0, 0, false
		}
		records += n[0]
		bytes += n[1]
	}
	return records, bytes, true
}
func NativeEnrollmentPairHeaderBytesForTestV6() uint64 {
	return 2 * uint64(unsafe.Sizeof(EnrollmentPairWork{}))
}

// NativeAtomicRemovalPriceForTestV6 mirrors every admission of
// RemoveWithTeardownWork, including its census. No active enrollment is
// supported. It excludes the caller's separately priced fixed alias teardown.
func NativeAtomicRemovalPriceForTestV6(bindings, resizeBytes uint64) (records, bytes uint64, complete bool) {
	add := func(a, b uint64) (uint64, bool) {
		if b > ^uint64(0)-a {
			return 0, false
		}
		return a + b, true
	}
	mul := func(a, b uint64) (uint64, bool) {
		if b != 0 && a > ^uint64(0)/b {
			return 0, false
		}
		return a * b, true
	}
	passes, ok := add(bindings, 1)
	if !ok {
		return
	}
	g := uint64(unsafe.Sizeof(NativeOwnerGeometryForTestV6{}))
	o := uint64(unsafe.Sizeof(Owner{}))
	e := uint64(unsafe.Sizeof(EnrollmentWork{}))
	b := uint64(unsafe.Sizeof(binding{}))
	l := uint64(unsafe.Sizeof(NativeRetentionLeaseGeometryForTestV6{}))
	censusPer, ok := add(2*b+2*g+2*l, resizeBytes)
	if !ok {
		return
	}
	perPass, ok := mul(2, resizeBytes)
	if !ok {
		return
	}
	perPass, ok = add(perPass, 8*b+2*o+256)
	if !ok {
		return
	}
	perPass, ok = mul(perPass, bindings)
	if !ok {
		return
	}
	perPass, ok = add(perPass, 4*o+2*e+128)
	if !ok {
		return
	}
	cb, ok := mul(bindings, censusPer)
	if !ok {
		return
	}
	pb, ok := mul(passes, perPass)
	if !ok {
		return
	}
	bytes = 2*g + 2*o + 2*e + 2*o + 2*uint64(unsafe.Sizeof(RemovalWork{})) + 128
	bytes, ok = add(bytes, cb)
	if !ok {
		return
	}
	bytes, ok = add(bytes, pb)
	if !ok {
		return
	}
	cr, ok := mul(3, bindings)
	if !ok {
		return
	}
	pr, ok := mul(6, bindings)
	if !ok {
		return
	}
	pr, ok = add(pr, 2)
	if !ok {
		return
	}
	pr, ok = mul(pr, passes)
	if !ok {
		return
	}
	records, ok = add(3, cr)
	if !ok {
		return
	}
	records, ok = add(records, pr)
	if !ok {
		return
	}
	complete = true
	return
}

// NativeOwnerGrowthPriceForTestV6 is the actual whole original Add admission:
// header plus every protected binding's link/control and both forward and
// possible rollback concrete resize permits.
func NativeOwnerGrowthPriceForTestV6(bindings, resizeBytes uint64) (records, bytes uint64, complete bool) {
	if bindings > (^uint64(0)-1)/5 {
		return
	}
	records = 1 + 5*bindings
	fixed := 2*uint64(unsafe.Sizeof(Owner{})) + 2*uint64(unsafe.Sizeof(EnrollmentWork{}))
	link := 6 * uint64(unsafe.Sizeof(binding{}))
	if resizeBytes > (^uint64(0)-link)/2 {
		return
	}
	link += 2 * resizeBytes
	if link != 0 && bindings > (^uint64(0)-fixed)/link {
		return
	}
	bytes = fixed + bindings*link
	complete = true
	return
}

// NativeEnrollmentPreparationPriceForTestV6 sums the actual saved forward
// phases for one original owner. Binding traversal saves cursor; count affects
// total turns only, while this conservative row also admits a whole old list.
func NativeEnrollmentPreparationPriceForTestV6(bindings, resizeBytes, acquireBytes uint64) (records, bytes uint64, complete bool) {
	type unit struct{ r, b uint64 }
	sum := func(rows ...unit) (u unit, ok bool) {
		for _, v := range rows {
			if v.r > ^uint64(0)-u.r || v.b > ^uint64(0)-u.b {
				return unit{}, false
			}
			u.r += v.r
			u.b += v.b
		}
		return u, true
	}
	o := uint64(unsafe.Sizeof(Owner{}))
	e := uint64(unsafe.Sizeof(EnrollmentWork{}))
	b := uint64(unsafe.Sizeof(binding{}))
	en := uint64(unsafe.Sizeof(Enrollment{}))
	if bindings > ^uint64(0)/2 {
		return
	}
	n := 2 * bindings
	per, ok := sum(unit{1, 2*b + e}, unit{1, resizeBytes})
	if !ok || n != 0 && (per.r > ^uint64(0)/n || per.b > ^uint64(0)/n) {
		return
	}
	u, ok := sum(unit{1, 2*e + 2*o}, unit{1, acquireBytes}, unit{n * per.r, n * per.b}, unit{1, 2*e + 2*o}, unit{1, en + 2*b + 2*o + 2*e}, unit{1, resizeBytes}, unit{1, resizeBytes}, unit{1, 2*e + 2*o}, unit{1, NativeEnrollmentPairHeaderBytesForTestV6()})
	if !ok {
		return
	}
	return u.r, u.b, true
}
