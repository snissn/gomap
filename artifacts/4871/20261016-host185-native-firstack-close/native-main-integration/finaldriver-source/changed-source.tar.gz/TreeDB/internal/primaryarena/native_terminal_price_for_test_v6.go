package primaryarena

import (
	"github.com/snissn/gomap/TreeDB/pager"
	"unsafe"
)

// The queue's bank and edge indices persist. Its repeated lookup prefix does
// not: price every one of the nine original lookups before the next advance.
func NativeReleaseUnitForTestV6(nodes, ownerRecords, ownerBytes uint64) (dropRecords, dropBytes, queueRecords, queueBytes uint64, complete bool) {
	tr, tb, dr, db, ok := pager.NativeReadRootUnitForTestV6(nodes)
	if !ok {
		return
	}
	add := func(a, b uint64) (uint64, bool) {
		if b > ^uint64(0)-a {
			return 0, false
		}
		return a + b, true
	}
	mul := func(a, b uint64) (uint64, bool) {
		if b != 0 && a > ^uint64(0)/b {
			return 0, false
		}
		return a * b, true
	}
	dropRecords, ok = add(2, tr)
	if !ok {
		return
	}
	dropBytes, ok = add(2*uint64(unsafe.Sizeof(bank{}))+2*uint64(unsafe.Sizeof(ReleaseQueue{})), tb)
	if !ok {
		return
	}
	x, ok := mul(9, tr)
	if !ok {
		return
	}
	queueRecords, ok = add(10, x)
	if !ok {
		return
	}
	queueRecords, ok = add(queueRecords, dr)
	if !ok {
		return
	}
	queueRecords, ok = add(queueRecords, ownerRecords)
	if !ok {
		return
	}
	x, ok = mul(9, tb)
	if !ok {
		return
	}
	queueBytes, ok = add(18*uint64(unsafe.Sizeof(bank{}))+2*uint64(unsafe.Sizeof(Group{}))+2*uint64(unsafe.Sizeof(ReleaseQueue{})), x)
	if !ok {
		return
	}
	queueBytes, ok = add(queueBytes, db)
	if !ok {
		return
	}
	queueBytes, ok = add(queueBytes, ownerBytes)
	if !ok {
		return
	}
	complete = true
	return
}
