package rootpublication

import (
	"testing"
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
)

func TestNativeIdentityPinAtomicLastIdleRemovalV6(t *testing.T) {
	for _, kind := range []string{"unbound", "concrete", "unsupported", "ordinary"} {
		t.Run(kind, func(t *testing.T) {
			r := NewIdentityPinRegistry()
			defer r.Close()
			id := testStableIdentity(7)
			if err := r.Observe(id); err != nil {
				t.Fatal(err)
			}
			pin, err := r.Pin(id)
			if err != nil {
				t.Fatal(err)
			}
			if err = r.Unobserve(id); err != nil {
				t.Fatal(err)
			}
			if kind == "concrete" {
				budget, err := memtable.NewCOWBudget(memtable.DefaultCOWLimits())
				if err != nil {
					t.Fatal(err)
				}
				defer budget.Close()
				e, err := r.metadata.Enroll(budget)
				if err != nil {
					t.Fatal(err)
				}
				defer e.Close()
			} else if kind == "unsupported" {
				e, err := r.metadata.Enroll(&registryBudget{cap: 1 << 20})
				if err != nil {
					t.Fatal(err)
				}
				defer e.Close()
			}
			before, state, cells, pins := r.metadata.Bytes(), pin.state, r.states.count, r.activePins
			if kind == "ordinary" {
				pin.Release()
			} else {
				// Price through the canonical lookup but not the owner admission.
				tiny := iterator.OrdinalScanWork{RecordLimit: 3, ByteLimit: 1 << 20}
				if ready, err := pin.ReleaseWithWorkV6(&tiny); ready || err != nil {
					t.Fatal(ready, err)
				}
				if pin.released || pin.state != state || state.pins != 1 || r.states.count != cells || r.activePins != pins || r.metadata.Bytes() != before {
					t.Fatal("refusal consumed original custody")
				}
				full := iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
				ready, err := pin.ReleaseWithWorkV6(&full)
				if kind == "unsupported" {
					if ready || err != retainedalloc.ErrWorkRequired || pin.released || pin.state != state || r.metadata.Bytes() != before || r.states.count != cells || r.activePins != pins {
						t.Fatal("unsupported lease consumed custody", ready, err)
					}
					pin.Release()
					return
				}
				if !ready || err != nil {
					t.Fatal(ready, err)
				}
			}
			if !pin.released || pin.registry != nil || pin.state != nil || r.states.count != cells-1 || r.activePins != pins-1 || r.metadata.Bytes() != before-retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(identityPinState{}))) {
				t.Fatal("last idle edge not consumed exactly once")
			}
			bytes := r.metadata.Bytes()
			if ready, err := pin.ReleaseWithWorkV6(&iterator.OrdinalScanWork{}); !ready || err != nil || r.metadata.Bytes() != bytes {
				t.Fatal("duplicate release replayed accounting", ready, err)
			}
		})
	}
	for _, observed := range []bool{false, true} {
		t.Run(map[bool]string{false: "nonlast", true: "observed"}[observed], func(t *testing.T) {
			r := NewIdentityPinRegistry()
			defer r.Close()
			id := testStableIdentity(8)
			if err := r.Observe(id); err != nil {
				t.Fatal(err)
			}
			p, err := r.Pin(id)
			if err != nil {
				t.Fatal(err)
			}
			if !observed {
				q, err := r.Pin(id)
				if err != nil {
					t.Fatal(err)
				}
				defer q.Release()
				if err = r.Unobserve(id); err != nil {
					t.Fatal(err)
				}
			} else {
				defer r.Unobserve(id)
			}
			before := r.metadata.Bytes()
			if ready, err := p.ReleaseWithWorkV6(&iterator.OrdinalScanWork{RecordLimit: 1, ByteLimit: 1 << 20}); !ready || err != nil || r.metadata.Bytes() != before {
				t.Fatal("nonlast/observed required metadata removal", ready, err)
			}
		})
	}
}

func TestNativeIdentityUnobserveAtomicLastIdleRemovalV6(t *testing.T) {
	for _, count := range []int{1, 2} {
		name := "idle"
		if count == 2 {
			name = "nonlast"
		}
		t.Run(name, func(t *testing.T) {
			r := NewIdentityPinRegistry()
			defer r.Close()
			id := testStableIdentity(9)
			for i := 0; i < count; i++ {
				if err := r.Observe(id); err != nil {
					t.Fatal(err)
				}
			}
			canonical, _ := validateRegistryIdentity(id)
			state := r.states.get(canonical)
			before, cells := r.metadata.Bytes(), r.states.count
			tiny := &iterator.OrdinalScanWork{RecordLimit: 2, ByteLimit: 1 << 20}
			if ready, err := r.UnobserveWithWorkV6(id, tiny); ready || err != nil || state.observers != uint64(count) || r.metadata.Bytes() != before || r.states.count != cells {
				t.Fatal("lookup refusal mutated observation", ready, err)
			}
			if ready, err := r.UnobserveWithWorkV6(id, &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}); !ready || err != nil {
				t.Fatal(ready, err)
			}
			if count == 1 {
				if r.states.count != cells-1 || r.metadata.Bytes() != before-retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(identityPinState{}))) {
					t.Fatal("idle observation charge not removed")
				}
				if ready, err := r.UnobserveWithWorkV6(id, &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}); ready || err != ErrUnbalancedResourcePin {
					t.Fatal("duplicate observation consumed", ready, err)
				}
			} else {
				if state.observers != 1 || r.states.count != cells || r.metadata.Bytes() != before {
					t.Fatal("nonlast observation removed state")
				}
				if err := r.Unobserve(id); err != nil {
					t.Fatal(err)
				}
			}
		})
	}
}
