package valuelog

import "unsafe"

// NativeEmptyTerminalPriceForTestV6 prices only an immutable FileCount==0
// Set. It includes both original manager wrapper alternatives and accounting
// completions. Nonempty files and an active decoder are not priced as empty.
// These are original typed units, without a synthetic Set, Manager or owner.
func NativeEmptyTerminalPriceForTestV6(removeRecords, removeBytes uint64) (records, bytes uint64, complete bool) {
	terms := [...][2]uint64{
		{1, 2*uint64(unsafe.Sizeof(ManagerWrapperReleaseWork{})) + 2*uint64(unsafe.Sizeof(Manager{})) + 64},
		{1, 2 * uint64(unsafe.Sizeof(Set{}))},
		{2, 4*uint64(unsafe.Sizeof(nativeMVCCSetReleaseState{})) + 2*uint64(unsafe.Sizeof(map[uint32]*File{}))},
		// BindSnapshotWrapper and full terminal wrapper path are conservative
		// siblings; only the disposing original receipt executes each effect.
		{1, 2*uint64(unsafe.Sizeof(ManagerWrapperReleaseWork{})) + 64},
		{1, 2*uint64(unsafe.Sizeof(Manager{})) + 2*uint64(unsafe.Sizeof(ManagerWrapperReleaseWork{})) + 64},
		{2, 4*uint64(unsafe.Sizeof(Manager{})) + 128},
		{removeRecords, removeBytes}, {removeRecords, removeBytes},
	}
	for _, n := range terms {
		if n[0] > ^uint64(0)-records || n[1] > ^uint64(0)-bytes {
			return 0, 0, false
		}
		records += n[0]
		bytes += n[1]
	}
	return records, bytes, true
}

// NativeIdleLeafCancelPriceForTestV6 covers the original idle codec and leaf
// descriptors. The selected inline/no-outer-leaf shape never starts a decoder,
// template or compressed stream; nonidle codec state is outside this row.
func NativeIdleLeafCancelPriceForTestV6() (records, bytes uint64) {
	return 5, uint64(unsafe.Sizeof(COWTemplateContinuation{})) + 1 + uint64(unsafe.Sizeof(COWZSTDContinuation{})) + uint64(unsafe.Sizeof(COWBlockContinuation{})) + uint64(unsafe.Sizeof(COWLeafContinuation{}))
}
