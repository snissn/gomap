package retainedalloc

import (
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
)

// RemoveWithTeardownWork admits the whole original shrink while the caller
// still owns its physical aliases. teardown is a fixed infallible alias scrub:
// it must not allocate, lock, fail, or reenter this owner. No permit escapes
// Owner.mu. Unsupported geometry and work refusal leave teardown uncalled.
//
// The concrete lease observation validates original provenance; actual resize
// and Close admission below remains the WorkLease contract. Owner custody
// excludes independent direct Close of these original binding leases.
func (o *Owner) RemoveWithTeardownWork(amount uint64, teardown func(), w *iterator.OrdinalScanWork) (bool, error) {
	if o == nil || teardown == nil || w == nil {
		return false, ErrWorkRequired
	}
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.controls > o.bytes || amount > o.bytes-o.controls {
		return false, ErrCapacity
	}
	if ready, err := o.admitAtomicShrinkLockedV6(w); !ready || err != nil {
		return ready, err
	}
	// No effects occurred above. All possible original shrink operations now
	// have concrete admissions and are nonincreasing on the validated leases.
	// The nil argument selects no additional charging in the SAME locked engine;
	// it is not a native fallback or an unpriced synchronous child.
	teardown()
	o.bytes -= amount
	var shrink shrinkWork
	ready, err := o.shrinkStepLocked(&shrink, nil)
	if err != nil || !ready {
		panic("validated original atomic retained shrink refused")
	}
	return true, nil
}

// Caller holds SAME Owner.mu throughout admission and the original effects.
func (o *Owner) admitAtomicShrinkLockedV6(w *iterator.OrdinalScanWork) (bool, error) {
	if !w.Reserve(2, 2*uint64(unsafe.Sizeof(NativeOwnerGeometryForTestV6{}))+2*uint64(unsafe.Sizeof(*o))+2*uint64(unsafe.Sizeof(EnrollmentWork{}))) {
		return false, nil
	}
	if o.closed || o.retired || o.cleanupFailed || o.enrolling != 0 || o.enrollment != nil {
		return false, ErrWorkRequired
	}
	var count uint64
	for b := o.head; b != nil; b = b.next {
		if !w.Reserve(2, 2*uint64(unsafe.Sizeof(*b))+2*uint64(unsafe.Sizeof(NativeOwnerGeometryForTestV6{}))) {
			return false, nil
		}
		observer, ok := b.lease.(nativeRetentionLeaseObserverForTestV6)
		if !ok {
			return false, ErrWorkRequired
		}
		g, ready := observer.MaintenanceNativeRetentionGeometryForTestV6(b.budget, w)
		if !ready {
			return false, nil
		}
		// rollback is scratch used only inside resizeLocked. Owner.mu excludes
		// such a resize here; the shrink engine never reads old rollback.
		if !g.Concrete || !g.SameBudget || g.Closed || g.Payload < o.bytes || b.admitted < o.bytes {
			return false, ErrWorkRequired
		}
		if _, ok := b.lease.(WorkLease); !ok {
			return false, ErrWorkRequired
		}
		if count == ^uint64(0) {
			return false, ErrCapacity
		}
		count++
	}
	// One debit and at most B+1 passes / B(B+1) visits. Reserve each
	// discovery/control visit BEFORE reading its original link. Admission itself
	// has no lease effect. A disposable binding can request at most one restart.
	if count == ^uint64(0) || count != 0 && count+1 > ^uint64(0)/count {
		return false, ErrCapacity
	}
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*o))+2*uint64(unsafe.Sizeof(RemovalWork{}))+128) {
		return false, nil
	}
	for pass := uint64(0); pass <= count; pass++ {
		if !w.Reserve(2, 4*uint64(unsafe.Sizeof(*o))+2*uint64(unsafe.Sizeof(EnrollmentWork{}))+128) {
			return false, nil
		}
		for b := o.head; b != nil; b = b.next {
			if !w.Reserve(4, 8*uint64(unsafe.Sizeof(*b))+2*uint64(unsafe.Sizeof(*o))+256) {
				return false, nil
			}
			lease := b.lease.(WorkLease) // validated under this same exclusion
			if !lease.AdmitRetentionResize(w) || !lease.AdmitRetentionClose(w) {
				return false, nil
			}
		}
	}
	return true, nil
}

// GrowInstallShrinkWithWork is the original registry constructor's atomic
// peak/install/refund transaction. install must not lock, fail or reenter this
// owner; the caller admits its actual allocations and loops before calling.
func (o *Owner) GrowInstallShrinkWithWork(growth, oldBacking uint64, install func(), w *iterator.OrdinalScanWork) (bool, error) {
	if o == nil || install == nil || w == nil {
		return false, ErrWorkRequired
	}
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.controls > o.bytes || oldBacking > o.bytes-o.controls || growth > ^uint64(0)-o.bytes {
		return false, ErrCapacity
	}
	if ready, err := o.admitAtomicShrinkLockedV6(w); !ready || err != nil {
		return ready, err
	}
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(*o))+2*uint64(unsafe.Sizeof(EnrollmentWork{}))) {
		return false, nil
	}
	for b := o.head; b != nil; b = b.next {
		if !w.Reserve(3, 6*uint64(unsafe.Sizeof(*b))) {
			return false, nil
		}
		lease := b.lease.(WorkLease)
		if !lease.AdmitRetentionResize(w) || !lease.AdmitRetentionResize(w) {
			return false, nil
		}
	}
	if err := o.resizeLocked(growth, true); err != nil {
		return false, err
	}
	install()
	o.bytes -= oldBacking
	var shrink shrinkWork
	if ready, err := o.shrinkStepLocked(&shrink, nil); !ready || err != nil {
		panic("validated original constructor shrink refused")
	}
	return true, nil
}
