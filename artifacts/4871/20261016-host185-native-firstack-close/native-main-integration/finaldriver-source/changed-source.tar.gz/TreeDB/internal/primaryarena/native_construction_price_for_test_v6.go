package primaryarena

import (
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
	"github.com/snissn/gomap/TreeDB/pager"
	"unsafe"
)

// Actual private-size forwarding for the selected first PRIMARY construction.
// No constructor, authority, owner or allocation is executed by this expression.
type NativeConstructionUnitsForTestV6 struct {
	RootRecords, RootBytes, SealRecords, SealBytes, ClaimRecords, ClaimBytes uint64
	Complete                                                                 bool
}

func NativeConstructionPriceForTestV6(nodes, addR, addB, growthR, growthB uint64) (v NativeConstructionUnitsForTestV6) {
	tr, tb, _, _, ok := pager.NativeReadRootUnitForTestV6(nodes)
	if !ok {
		return
	}
	type unit struct{ r, b uint64 }
	sum := func(rows ...unit) (u unit, ok bool) {
		for _, x := range rows {
			if x.r > ^uint64(0)-u.r || x.b > ^uint64(0)-u.b {
				return unit{}, false
			}
			u.r += x.r
			u.b += x.b
		}
		return u, true
	}
	add := unit{addR, addB}
	lookup := unit{tr, tb}
	p := uint64(page.PageSize)
	bankBytes := uint64(unsafe.Sizeof(bank{}))
	cert := uint64(unsafe.Sizeof(ReadRootCertificateV6{}))
	group := uint64(unsafe.Sizeof(Group{}))
	// Root-owner constructor header, table lookup and aggregate bank/node Add.
	root, ok := sum(unit{1, 2*bankBytes + 128}, unit{1, 2*uint64(unsafe.Sizeof(readRootOwnerConstructorV6{})) + 2*bankBytes}, unit{2, pager.NativeReadRootConstructionHeaderBytesForTestV6()}, lookup, lookup, add)
	if !ok {
		return
	}
	// Both lazy certificate and immutable image admissions precede registration.
	// The final seal turn repeats these lookups before its trailing register row.
	seal, ok := sum(lookup, unit{2, 4*p + 2*bankBytes + 2*group + 2*cert}, unit{1, 2*cert + 2*bankBytes}, add, unit{1, 2 * p}, lookup, add, unit{1, 2*p + 128}, lookup, lookup,
		unit{1, 2*p + 2*uint64(unsafe.Sizeof(DirectorySealWorkV6{}))}, unit{1, 2*p + 2*uint64(unsafe.Sizeof(node.PrimaryDirectoryDecodeWorkV6{}))}, unit{1, p}, unit{1, 2*uint64(unsafe.Sizeof(Ref{})) + 2*group})
	if !ok {
		return
	}
	claim, ok := sum(unit{1, 2*uint64(unsafe.Sizeof(Claim{})) + 128}, unit{1, 2*bankBytes + 64}, add, unit{1, 2 * uint64(unsafe.Sizeof(Claim{}))}, unit{1, 2*uint64(unsafe.Sizeof(bankChunk{})) + 128}, add, unit{growthR, growthB}, unit{1, 2*bankBytes + 64}, unit{1, 2 * bankBytes}, unit{2, 4 * uint64(unsafe.Sizeof(Claim{}))})
	if !ok {
		return
	}
	v.RootRecords, v.RootBytes = root.r, root.b
	v.SealRecords, v.SealBytes = seal.r, seal.b
	v.ClaimRecords, v.ClaimBytes = claim.r, claim.b
	v.Complete = true
	return
}
