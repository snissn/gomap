package primaryarena

import (
	"crypto/sha256"
	"fmt"
	"path/filepath"
	"testing"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
)

type lookupConstructionV6 struct{ ref Ref }

func (c *lookupConstructionV6) PrimaryConstructionReferenceV6() Ref { return c.ref }
func (*lookupConstructionV6) OwnPrimaryComponentV6(Ref, *iterator.OrdinalScanWork) (bool, error) {
	return true, nil
}
func (*lookupConstructionV6) SealPrimaryConstructionV6([]byte, [1]*Group, *iterator.OrdinalScanWork) (bool, error) {
	return true, nil
}
func (*lookupConstructionV6) Abort() error { return nil }

// Use actual constructor-installed nodes to put the sealed root behind another
// node in its original bucket. No shadow lookup table or edited bank is involved.
func collisionReadRootV6(t *testing.T, owner *lookupConstructionV6) (*Arena, Ref, *bank, iterator.OrdinalScanWork) {
	t.Helper()
	a, err := OpenCapsule(filepath.Join(t.TempDir(), "index.db.primary"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if err := a.Close(); err != nil {
			t.Error(err)
		}
	})
	var construction ReadRootConstructionV6
	if owner != nil {
		construction = owner
	}
	r, ready, err := a.PrepareConstructedReadRootV6(construction, nil)
	if !ready || err != nil {
		t.Fatalf("prepare root: ready=%t err=%v", ready, err)
	}
	if owner != nil {
		owner.ref = r
	}
	image := make([]byte, page.PageSize)
	base := node.PrimaryOperand{Ref: page.PageChildRef(2), Digest: sha256.Sum256([]byte("separately owned DATA base"))}
	if err := node.EncodePrimaryDirectory(image, r.PageID, 1, base, nil); err != nil {
		t.Fatal(err)
	}
	if _, ready, err := a.SealConstructedReadRootV6(r, image, [1]*Group{}, construction, nil); !ready || err != nil {
		t.Fatalf("seal root: ready=%t err=%v", ready, err)
	}
	for i := 0; i < 256; i++ {
		if _, ready, err := a.PrepareReadRootV6(nil); !ready || err != nil {
			t.Fatalf("prepare collision %d: ready=%t err=%v", i, ready, err)
		}
	}
	b := a.valid(r)
	lookup := iterator.OrdinalScanWork{RecordLimit: 64, ByteLimit: 1 << 20}
	got, ready := a.Pager().PrimaryReadRootOwnerWithWorkV6(Local(r.PageID), &lookup)
	if !ready || got != b || lookup.Records < 3 {
		t.Fatalf("original collision lookup: ready=%t same=%t records=%d", ready, got == b, lookup.Records)
	}
	return a, r, b, lookup
}

func TestPrimaryArenaAcquireAdmitsActualLookupV6(t *testing.T) {
	a, r, b, lookup := collisionReadRootV6(t, nil)
	before, refs, charge := a.Counters(), b.refs, a.MetadataOwner().Bytes()
	limits := []iterator.OrdinalScanWork{
		{RecordLimit: 1, ByteLimit: 1 << 20},
		{RecordLimit: 1 + lookup.Records - 1, ByteLimit: 1 << 20},
		{RecordLimit: 64, ByteLimit: RefAcquireBytesV6() + lookup.Bytes - 1},
	}
	for i := range limits {
		if ready, err := a.Acquire(r, &limits[i]); ready || err != nil {
			t.Fatalf("refused acquire %d: ready=%t err=%v", i, ready, err)
		}
		if b.refs != refs || a.Counters() != before || a.MetadataOwner().Bytes() != charge {
			t.Fatalf("refused acquire %d changed custody", i)
		}
	}
	w := &iterator.OrdinalScanWork{RecordLimit: 1 + lookup.Records, ByteLimit: 1 << 20}
	if ready, err := a.Acquire(r, w); !ready || err != nil || b.refs != refs+1 || w.Records != 1+lookup.Records {
		t.Fatalf("admitted acquire: ready=%t err=%v refs=%d records=%d", ready, err, b.refs, w.Records)
	}
	if ready, err := a.Acquire(r, nil); !ready || err != nil || b.refs != refs+2 {
		t.Fatalf("ordinary acquire: ready=%t err=%v refs=%d", ready, err, b.refs)
	}
}

func TestPrimaryArenaCertificateAdmitsLookupBeforeTransferV6(t *testing.T) {
	a, r, b, lookup := collisionReadRootV6(t, nil)
	before, refs, charge := a.Counters(), b.refs, a.MetadataOwner().Bytes()
	for _, take := range []bool{false, true} {
		w := &iterator.OrdinalScanWork{RecordLimit: 2 + lookup.Records - 1, ByteLimit: 1 << 20}
		var cert *ReadRootCertificateV6
		var ready bool
		var err error
		if take {
			cert, ready, err = a.TakeReadRootCertificateV6(r.PageID, w)
		} else {
			cert, ready, err = a.BorrowReadRootCertificateV6(r, w)
		}
		if cert != nil || ready || err != nil {
			t.Fatalf("refused certificate take=%t: cert=%p ready=%t err=%v", take, cert, ready, err)
		}
		if b.refs != refs || !b.privatePublication || b.readCertificate != nil || a.Counters() != before || a.MetadataOwner().Bytes() != charge {
			t.Fatalf("refused certificate take=%t changed custody", take)
		}
	}
	w := &iterator.OrdinalScanWork{RecordLimit: 128, ByteLimit: 1 << 20}
	borrowed, ready, err := a.BorrowReadRootCertificateV6(r, w)
	if !ready || err != nil || borrowed == nil || borrowed != b.readCertificate || !b.privatePublication {
		t.Fatalf("admitted borrow: ready=%t err=%v", ready, err)
	}
	taken, ready, err := a.TakeReadRootCertificateV6(r.PageID, nil)
	if !ready || err != nil || taken != borrowed || b.privatePublication || b.refs != refs {
		t.Fatalf("ordinary take: ready=%t err=%v same=%t refs=%d", ready, err, taken == borrowed, b.refs)
	}
}

func TestPrimaryArenaAcquireDetachAdmitsLookupBeforeOwnershipChangeV6(t *testing.T) {
	for _, ordinary := range []bool{false, true} {
		t.Run(map[bool]string{false: "finite", true: "ordinary"}[ordinary], func(t *testing.T) {
			owner := &lookupConstructionV6{}
			a, r, b, lookup := collisionReadRootV6(t, owner)
			before, refs, charge := a.Counters(), b.refs, a.MetadataOwner().Bytes()
			short := &iterator.OrdinalScanWork{RecordLimit: 2 + lookup.Records - 1, ByteLimit: 1 << 20}
			if ready, err := a.AcquireAndDetachReadRootConstructionV6(r, owner, short); ready || err != nil {
				t.Fatalf("refused detach: ready=%t err=%v", ready, err)
			}
			if b.refs != refs || b.construction != owner || a.Counters() != before || a.MetadataOwner().Bytes() != charge {
				t.Fatal("refused detach changed constructor custody")
			}
			var w *iterator.OrdinalScanWork
			if !ordinary {
				w = &iterator.OrdinalScanWork{RecordLimit: 2 + lookup.Records, ByteLimit: 1 << 20}
			}
			if ready, err := a.AcquireAndDetachReadRootConstructionV6(r, owner, w); !ready || err != nil || b.refs != refs+1 || b.construction != nil {
				t.Fatalf("admitted detach: ready=%t err=%v refs=%d detached=%t", ready, err, b.refs, b.construction == nil)
			}
			if ready, err := a.AcquireAndDetachReadRootConstructionV6(r, owner, nil); ready || err != ErrStale || b.refs != refs+1 {
				t.Fatalf("repeated detach: ready=%t err=%v refs=%d", ready, err, b.refs)
			}
		})
	}
}

func TestPrimaryArenaPromotionSecondLookupRefusalHasNoAcquireV6(t *testing.T) {
	a, r, b, lookup := collisionReadRootV6(t, nil)
	before, refs, charge := a.Counters(), b.refs, a.MetadataOwner().Bytes()
	// Finish the first lookup and refuse the second before metadata-edge
	// validation. In particular, no earlier root may be acquired speculatively.
	w := &iterator.OrdinalScanWork{RecordLimit: 4 + lookup.Records, ByteLimit: 1 << 20}
	edge, parentEdge, ready, err := a.AcquirePromotionCustodyV6(r, r, MetadataEdge{}, MetadataEdge{}, w)
	if edge != (Ref{}) || parentEdge != (Ref{}) || ready || err != nil {
		t.Fatalf("refused promotion lookup: edges=%v/%v ready=%t err=%v", edge, parentEdge, ready, err)
	}
	if b.refs != refs || a.Counters() != before || a.MetadataOwner().Bytes() != charge {
		t.Fatal("second lookup refusal partially acquired promotion custody")
	}
}

func TestPrimaryArenaAcquireAfterAdmissionUsesOriginalLookupV6(t *testing.T) {
	a, r, b, lookup := collisionReadRootV6(t, nil)
	refs, before := b.refs, a.Counters()
	calls := 0
	rejected := fmt.Errorf("containing admission rejected")
	admit := func() error { calls++; return rejected }
	short := &iterator.OrdinalScanWork{RecordLimit: lookup.Records, ByteLimit: 1 << 20}
	if ready, err := a.AcquireAfterAdmissionV6(r, short, admit); ready || err != nil || calls != 0 || b.refs != refs || a.Counters() != before {
		t.Fatal("lookup refusal invoked admission or acquired bank", ready, err, calls)
	}
	enough := func() *iterator.OrdinalScanWork {
		return &iterator.OrdinalScanWork{RecordLimit: 1 + lookup.Records, ByteLimit: 1 << 20}
	}
	if ready, err := a.AcquireAfterAdmissionV6(r, enough(), admit); ready || err != rejected || calls != 1 || b.refs != refs || a.Counters() != before {
		t.Fatal("admission failure acquired bank", ready, err, calls)
	}
	if ready, err := a.AcquireAfterAdmissionV6(r, enough(), func() error { calls++; return nil }); !ready || err != nil || calls != 2 || b.refs != refs+1 || a.Counters().RootAcquires != before.RootAcquires+1 {
		t.Fatal("successful admitted acquire", ready, err, calls)
	}
}
