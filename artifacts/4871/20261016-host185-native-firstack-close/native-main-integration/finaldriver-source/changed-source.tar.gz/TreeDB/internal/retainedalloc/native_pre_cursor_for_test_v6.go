package retainedalloc

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"unsafe"
)

// NativePreCursorOwnerForTestV6 does not require/create a native budget. It
// checks original concrete resize capability but deliberately does not assert
// identity with the not-yet-born governor. Ready-time observations must do so.
type NativePreCursorOwnerForTestV6 struct {
	Bindings, GrowthRecords, GrowthBytes, LargestResizeBytes   uint64
	Present, Complete, ActiveEnrollment, Unsupported, Overflow bool
}

func (o *Owner) MaintenanceNativePreCursorForTestV6(w *iterator.OrdinalScanWork) (g NativePreCursorOwnerForTestV6, ready bool) {
	if w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(Owner{}))+2*uint64(unsafe.Sizeof(g))) {
		return g, false
	}
	if o == nil {
		g.Complete = true
		return g, true
	}
	o.mu.Lock()
	defer o.mu.Unlock()
	g.Present = true
	g.ActiveEnrollment = o.enrollment != nil
	if g.ActiveEnrollment || o.closed || o.cleanupFailed {
		g.Unsupported = true
		return g, true
	}
	g.GrowthRecords = 1
	g.GrowthBytes = 2*uint64(unsafe.Sizeof(Owner{})) + 2*uint64(unsafe.Sizeof(EnrollmentWork{}))
	for b := o.head; b != nil; {
		if !w.Reserve(1, 2*uint64(unsafe.Sizeof(binding{}))) {
			return g, false
		}
		observer, ok := b.lease.(nativeRetentionLeaseObserverForTestV6)
		if !ok {
			g.Unsupported = true
			return g, true
		}
		lease, ok := observer.MaintenanceNativeRetentionGeometryForTestV6(nil, w)
		if !ok {
			return g, false
		}
		if !lease.Concrete || lease.Closed {
			g.Unsupported = true
			return g, true
		}
		bytes := 6 * uint64(unsafe.Sizeof(binding{}))
		if lease.ResizeBytes > (^uint64(0)-bytes)/2 || 5 > ^uint64(0)-g.GrowthRecords || bytes+2*lease.ResizeBytes > ^uint64(0)-g.GrowthBytes || g.Bindings == ^uint64(0) {
			g.Overflow = true
			return g, true
		}
		g.Bindings++
		g.GrowthRecords += 5
		g.GrowthBytes += bytes + 2*lease.ResizeBytes
		g.LargestResizeBytes = max(g.LargestResizeBytes, lease.ResizeBytes)
		b = b.next
	}
	g.Complete = true
	return g, true
}
