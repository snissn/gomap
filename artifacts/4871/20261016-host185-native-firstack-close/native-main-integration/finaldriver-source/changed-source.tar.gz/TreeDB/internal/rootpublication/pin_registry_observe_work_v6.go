package rootpublication

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"unsafe"
)

// ObserveWithWorkV6 admits the original registry cell and any actual geometric
// backing replacement under the original lock. It creates no parallel table.
func (registry *IdentityPinRegistry) ObserveWithWorkV6(identity StableIdentity, w *iterator.OrdinalScanWork) (bool, error) {
	identity, err := validateRegistryIdentity(identity)
	if err != nil {
		return false, err
	}
	if registry == nil {
		return false, ErrUnresolvedResource
	}
	reserve := func(r, b uint64) (bool, error) {
		if w == nil {
			return true, nil
		}
		if r > w.RecordLimit || b > w.ByteLimit {
			return false, &iterator.OrdinalUnitTooLarge{Records: r, Bytes: b}
		}
		return w.Reserve(r, b), nil
	}
	if ok, e := reserve(1, 2*uint64(unsafe.Sizeof(identity))+uint64(len(identity.Platform))); !ok || e != nil {
		return false, e
	}
	registry.mu.Lock()
	defer registry.mu.Unlock()
	if registry.closing {
		return false, retainedalloc.ErrClosed
	}
	state, _, ready := registry.captureStateLockedV6(identity, w)
	if !ready {
		return false, nil
	}
	if state == nil {
		if w == nil {
			state, err = registry.stateLocked(identity)
			if err != nil {
				return false, err
			}
		} else {
			t := &registry.states
			capacity := len(t.cells)
			// Avoid signed count/threshold overflow while preserving exactly
			// the original geometric/tombstone decision.
			if t.count < 0 || t.used < t.count || t.used > capacity {
				return false, retainedalloc.ErrCapacity
			}
			replace := capacity == 0 || t.used >= capacity/2-1
			if replace {
				if t.count >= capacity/2-1 {
					if capacity > int(^uint(0)>>1)/2 {
						return false, retainedalloc.ErrCapacity
					}
					capacity *= 2
				}
				if capacity == 0 {
					capacity = 16
				}
			}
			oldCapacity := uint64(len(t.cells))
			newCapacity := uint64(capacity)
			cell := uint64(unsafe.Sizeof(registryCell[StableIdentity, *identityPinState]{}))
			if newCapacity == 0 || newCapacity > ^uint64(0)/cell {
				return false, retainedalloc.ErrCapacity
			}
			// Hash every actual old live identity only after admitting each
			// cell. Count no uncharged discovery pass, including tombstones.
			platformBytes := uint64(len(identity.Platform))
			if replace {
				for i := range t.cells {
					if !w.Reserve(1, 2*cell) {
						return false, nil
					}
					if t.cells[i].status == 1 {
						n := uint64(len(t.cells[i].key.Platform)) + 16
						if !w.Reserve(1, n) {
							return false, nil
						}
						platformBytes = max(platformBytes, uint64(len(t.cells[i].key.Platform)))
					}
				}
			}
			probes := newCapacity
			if replace {
				if oldCapacity > (^uint64(0)-probes)/newCapacity {
					return false, retainedalloc.ErrCapacity
				}
				probes += oldCapacity * newCapacity
			}
			comparison := 2*cell + platformBytes + 16
			if probes > ^uint64(0)/comparison {
				return false, retainedalloc.ErrCapacity
			}
			nr, nb := uint64(2), 2*uint64(unsafe.Sizeof(identityPinState{}))
			if replace {
				if newCapacity+oldCapacity > ^uint64(0)/cell {
					return false, retainedalloc.ErrCapacity
				}
				backingBytes := (newCapacity + oldCapacity) * cell
				if backingBytes > ^uint64(0)-nb {
					return false, retainedalloc.ErrCapacity
				}
				nb += backingBytes
			}
			if probes > ^uint64(0)-nr || probes*comparison > ^uint64(0)-nb {
				return false, retainedalloc.ErrCapacity
			}
			if !w.Reserve(nr+probes, nb+probes*comparison) {
				return false, nil
			}
			stateCharge := retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(identityPinState{})))
			backing, oldCharge := uint64(0), uint64(0)
			if replace {
				backing = retainedalloc.AllocationCharge(newCapacity * cell)
				oldCharge = t.charge
			}
			if backing > ^uint64(0)-stateCharge {
				return false, retainedalloc.ErrCapacity
			}
			ready, e := registry.metadata.GrowInstallShrinkWithWork(stateCharge+backing, oldCharge, func() {
				state = &identityPinState{}
				if replace {
					old := t.cells
					t.cells = make([]registryCell[StableIdentity, *identityPinState], capacity)
					t.used = 0
					t.count = 0
					t.charge = backing
					for i := range old {
						if old[i].status == 1 {
							t.insert(old[i].key, old[i].value, old[i].payload)
						}
					}
					clear(old)
					old = nil
				}
				t.insert(identity, state, 0)
			}, w)
			if !ready || e != nil {
				return false, e
			}
		}
	}
	if state.retired || state.deleting {
		return false, ErrResourceConflict
	}
	state.observers++
	return true, nil
}
