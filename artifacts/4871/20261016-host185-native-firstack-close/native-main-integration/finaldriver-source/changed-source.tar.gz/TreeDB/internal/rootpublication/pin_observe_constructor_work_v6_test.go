package rootpublication

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"testing"
	"unsafe"
)

func TestNativeObserveConstructorAdmissionV6(t *testing.T) {
	for _, shape := range []string{"empty", "spare", "collision", "tombstone", "doubling", "bound-replacement", "unsupported", "capacity", "ordinary"} {
		t.Run(shape, func(t *testing.T) {
			r := NewIdentityPinRegistry()
			defer r.Close()
			if shape == "collision" {
				r.states.hash = func(StableIdentity) uint64 { return 0 }
			}
			if shape != "empty" && shape != "ordinary" {
				seed := uint64(7)
				if shape == "spare" {
					seed = 3
				}
				for i := uint64(1); i <= seed; i++ {
					if err := r.Observe(registryTestIdentity(byte(i))); err != nil {
						t.Fatal(err)
					}
				}
				if shape == "tombstone" {
					for i := uint64(1); i <= 6; i++ {
						if err := r.Unobserve(registryTestIdentity(byte(i))); err != nil {
							t.Fatal(err)
						}
					}
				}
			}
			var enrollment *retainedalloc.Enrollment
			var budget *memtable.COWBudget
			if shape == "unsupported" {
				var err error
				enrollment, err = r.metadata.Enroll(&registryBudget{cap: 1 << 20})
				if err != nil {
					t.Fatal(err)
				}
			} else if shape == "capacity" || shape == "bound-replacement" {
				var err error
				limits := memtable.DefaultCOWLimits()
				limits.MaxInFlightBytes = limits.MaxTotalBytes
				budget, err = memtable.NewCOWBudget(limits)
				if err != nil {
					t.Fatal(err)
				}
				defer budget.Close()
				enrollment, err = r.metadata.Enroll(budget)
				if err != nil {
					t.Fatal(err)
				}
			}
			if enrollment != nil {
				defer enrollment.Close()
			}
			id := registryTestIdentity(99)
			before, capacity, count, used := r.metadata.Bytes(), len(r.states.cells), r.states.count, r.states.used
			if shape == "ordinary" {
				if err := r.Observe(id); err != nil {
					t.Fatal(err)
				}
				if r.states.count != count+1 {
					t.Fatal("ordinary constructor lost state")
				}
				return
			}
			// The first admitted lookup cannot construct anything with no remainder.
			tiny := &iterator.OrdinalScanWork{RecordLimit: 1, ByteLimit: 1 << 20}
			if ready, err := r.ObserveWithWorkV6(id, tiny); ready || err != nil || r.metadata.Bytes() != before || len(r.states.cells) != capacity || r.states.count != count || r.states.used != used {
				t.Fatal("refusal changed original authority", ready, err)
			}
			bindings := uint64(0)
			if enrollment != nil {
				bindings = 1
			}
			resize := 2*uint64(unsafe.Sizeof(memtable.COWExternalLease{})) + 2*uint64(unsafe.Sizeof(memtable.COWBudget{}))
			bound := max(uint64(16), 2*uint64(capacity))
			rr, rb, ok := NativeObservePriceForTestV6(bound, bindings, resize, uint64(len(id.Platform)))
			if !ok {
				t.Fatal("price unavailable")
			}
			if shape == "capacity" {
				// Final replacement fits, but original old+new overlap does not. Include
				// budget control, enrollment controls and the new held lease's OWN header.
				stateCharge := retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(identityPinState{})))
				nextCharge := retainedalloc.AllocationCharge(2 * uint64(capacity) * uint64(unsafe.Sizeof(registryCell[StableIdentity, *identityPinState]{})))
				finalDelta := nextCharge - r.states.charge + stateCharge
				leaseHeader := retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(memtable.COWExternalLease{})))
				stats := budget.Stats()
				limit := budget.Limits().MaxTotalBytes
				if stats.TotalBytes+finalDelta+leaseHeader >= limit {
					t.Fatal("fixture headroom")
				}
				held, err := budget.AcquireExternal(limit - stats.TotalBytes - finalDelta - leaseHeader)
				if err != nil {
					t.Fatal(err)
				}
				defer held.Close()
				full := &iterator.OrdinalScanWork{RecordLimit: rr, ByteLimit: rb}
				ready, err := r.ObserveWithWorkV6(id, full)
				if ready || err != memtable.ErrCOWCapacity || r.metadata.Bytes() != before || r.states.count != count || r.states.used != used || len(r.states.cells) != capacity {
					t.Fatal("overlap refusal changed authority", ready, err)
				}
				return
			}
			full := &iterator.OrdinalScanWork{RecordLimit: rr, ByteLimit: rb}
			ready, err := r.ObserveWithWorkV6(id, full)
			if shape == "unsupported" {
				if ready || err != retainedalloc.ErrWorkRequired || r.metadata.Bytes() != before || r.states.count != count || len(r.states.cells) != capacity || r.states.used != used {
					t.Fatal("unsupported lease mutated constructor", ready, err)
				}
				return
			}
			if err != nil || !ready {
				t.Fatal(ready, err, full.Records, rr)
			}
			if shape == "spare" && len(r.states.cells) != capacity {
				t.Fatal("spare capacity unexpectedly replaced")
			}
			if shape == "bound-replacement" && (len(r.states.cells) <= capacity || enrollment == nil || budget.Stats().TotalBytes == 0) {
				t.Fatal("concrete bound replacement did not occur")
			}
			canonical, _ := validateRegistryIdentity(id)
			s := r.states.get(canonical)
			if s == nil || s.observers != 1 || r.states.count != count+1 {
				t.Fatal("original state not installed")
			}
			want := before + retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(identityPinState{})))
			if len(r.states.cells) != capacity {
				want += r.states.charge - retainedalloc.AllocationCharge(uint64(capacity)*uint64(unsafe.Sizeof(registryCell[StableIdentity, *identityPinState]{})))
			}
			if r.metadata.Bytes() != want {
				t.Fatal("peak backing not refunded exactly", r.metadata.Bytes(), want)
			}
			// Existing state retains its original allocation and does not rehash.
			bytes := r.metadata.Bytes()
			if ready, err := r.ObserveWithWorkV6(id, &iterator.OrdinalScanWork{RecordLimit: rr, ByteLimit: rb}); !ready || err != nil || r.metadata.Bytes() != bytes || s.observers != 2 {
				t.Fatal("existing state changed backing", ready, err)
			}
		})
	}
}

func TestNativeRegistryPreCursorScanV6(t *testing.T) {
	r := NewIdentityPinRegistry()
	defer r.Close()
	for i := uint64(1); i <= 20; i++ {
		if err := r.Observe(registryTestIdentity(byte(i))); err != nil {
			t.Fatal(err)
		}
	}
	var c NativePreCursorRegistryScanForTestV6
	for turns := 0; !c.Complete && turns <= len(r.states.cells); turns++ {
		before := c.Next
		done, ready := r.MaintenanceNativePreCursorStepForTestV6(&c, &iterator.OrdinalScanWork{RecordLimit: 4, ByteLimit: 1 << 20})
		if c.Drift || done != c.Complete || ready != done || c.Next < before {
			t.Fatal("invalid scalar census", c, done, ready)
		}
	}
	if !c.Complete || c.Next != uint64(len(r.states.cells)) || c.Geometry.StateCount != 20 || c.Geometry.PlatformBytes == 0 {
		t.Fatal("bounded census incomplete", c)
	}
	if err := r.Observe(registryTestIdentity(90)); err != nil {
		t.Fatal(err)
	}
	if done, ready := r.MaintenanceNativePreCursorStepForTestV6(&c, &iterator.OrdinalScanWork{RecordLimit: 4, ByteLimit: 1 << 20}); done || !ready || !c.Drift {
		t.Fatal("drift accepted", done, ready, c)
	}
}
