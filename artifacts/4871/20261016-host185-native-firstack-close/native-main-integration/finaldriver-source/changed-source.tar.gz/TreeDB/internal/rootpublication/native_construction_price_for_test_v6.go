package rootpublication

import (
	"github.com/snissn/gomap/TreeDB/page"
	"unsafe"
)

// Fixed original transaction/set/manifest/codec rows. The caller adds actual
// arena and DB preparation children; this function executes no preparation.
type NativePrimaryConstructionUnitsForTestV6 struct {
	TransactionRecords, TransactionBytes, PromotionRecords, PromotionBytes             uint64
	EmptyRecords, EmptyBytes, CloneRecords, CloneBytes, ManifestRecords, ManifestBytes uint64
	CapsuleRecords, CapsuleBytes, CompleteRecords, CompleteBytes                       uint64
	Complete                                                                           bool
}

func NativePrimaryConstructionPriceForTestV6(addR, addB uint64) (v NativePrimaryConstructionUnitsForTestV6) {
	type unit struct{ r, b uint64 }
	sum := func(rows ...unit) (u unit, ok bool) {
		for _, x := range rows {
			if x.r > ^uint64(0)-u.r || x.b > ^uint64(0)-u.b {
				return unit{}, false
			}
			u.r += x.r
			u.b += x.b
		}
		return u, true
	}
	txn := uint64(unsafe.Sizeof(DurableRootTransaction{}))
	construction := uint64(unsafe.Sizeof(primaryTransactionConstructionV6{}))
	terminal := uint64(unsafe.Sizeof(primaryTerminalCompletionV6{}))
	promotion := uint64(unsafe.Sizeof(PrimaryPromotionV6{}))
	allocation := uint64(unsafe.Sizeof(resourceAllocation{}))
	set := uint64(unsafe.Sizeof(StableResourceSet{}))
	kind := uint64(unsafe.Sizeof(resourceKindBacking{}))
	add := unit{addR, addB}
	t, ok := sum(unit{3, 2*txn + 2*construction + 2*terminal}, add, unit{1, 2*txn + 2*construction})
	if !ok {
		return
	}
	pr, ok := sum(unit{1, 2*promotion + 2*construction}, unit{1, 2*PrimaryCapsuleSizeV6 + 2*promotion}, add)
	if !ok {
		return
	}
	cl, ok := sum(unit{1, 2*set + 2*allocation}, unit{1, 2*set + allocation + kind + uint64(unsafe.Sizeof(stableResourceSetExtras{})) + 64}, unit{2, 4 * uint64(unsafe.Sizeof(uint64(0)))}, add)
	if !ok {
		return
	}
	empty, ok := sum(unit{1, 2 * set}, unit{6, 2*uint64(unsafe.Sizeof(StableResourceSetBuilder{})) + 2*set + 2*kind + 6*allocation}, add, cl)
	if !ok {
		return
	}
	manifest, ok := sum(unit{4, 2*uint64(unsafe.Sizeof(DependencyManifestV1{})) + 4*allocation + 2*uint64(unsafe.Sizeof(dependencyManifestCursorV1{})) + 128}, add)
	if !ok {
		return
	}
	p := uint64(page.PageSize)
	m := uint64(512)
	c := uint64(PrimaryCapsuleSizeV6)
	capsule, ok := sum(unit{1, 2*m + 256}, unit{1, c + p + 2*m}, unit{2, 8 * p}, unit{1, 2*c + p + 2*m})
	if !ok {
		return
	}
	v.TransactionRecords, v.TransactionBytes = t.r, t.b
	v.PromotionRecords, v.PromotionBytes = pr.r, pr.b
	v.EmptyRecords, v.EmptyBytes = empty.r, empty.b
	v.CloneRecords, v.CloneBytes = cl.r, cl.b
	v.ManifestRecords, v.ManifestBytes = manifest.r, manifest.b
	v.CapsuleRecords, v.CapsuleBytes = capsule.r, capsule.b
	v.CompleteRecords, v.CompleteBytes = NativeFinishHeaderPriceForTestV6()
	v.Complete = true
	return
}
