package lifecycle

import (
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
)

// FallbackSlots is the historical vector length, including free entries. Live
// reader count cannot replace it. This read retains no registry or authority.
type NativeMinimumGeometryForTestV6 struct {
	FallbackSlots uint64
	Dirty         bool
	Complete      bool
}

func (r *ReaderRegistry) MaintenanceNativeMinimumGeometryForTestV6(w *iterator.OrdinalScanWork) (g NativeMinimumGeometryForTestV6, ready bool) {
	if r == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(g))+2*uint64(unsafe.Sizeof(r.seqs))+2*uint64(unsafe.Sizeof(r.dirty))) {
		return g, false
	}
	r.mu.Lock()
	g.FallbackSlots, g.Dirty, g.Complete = uint64(len(r.seqs)), r.dirty, true
	r.mu.Unlock()
	return g, true
}

// NativeMinimumPriceForTestV6 includes the dirty path even when the precursor
// cache is clean. A native registration uses only fixed shards and cannot grow
// seqs. The caller excludes other ordinary registrations until this scan ends.
func NativeMinimumPriceForTestV6(fallbackSlots uint64) (records, bytes uint64, complete bool) {
	const fixedRecords = uint64(1 + fastReaderShardCount)
	const fixedBytes = uint64(fastReaderShardCount*16 + 32)
	if fallbackSlots > ^uint64(0)-fixedRecords || fallbackSlots > (^uint64(0)-fixedBytes)/8 {
		return 0, 0, false
	}
	return fixedRecords + fallbackSlots, fixedBytes + 8*fallbackSlots, true
}
