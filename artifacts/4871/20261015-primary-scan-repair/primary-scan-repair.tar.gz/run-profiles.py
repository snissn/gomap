import os,sys,json,subprocess,time,hashlib,signal
from pathlib import Path
B=Path('/home/mikers/benchmarks/mvcc-4871-repair-20261013')
E=B/'evidence/ordinary-5111-final-base-20261015/ci-read-custody-repair-20261015/primary-scan-repair/perf'
E.mkdir(exist_ok=True)
BASEELF=B/'evidence/ordinary-5111-final-base-20261015/ci-perf-b3c7-20261015/baseline.test'
roots={'baseline':B/'ordinary-5111-b3c7-perf-baseline-20261015','candidate':B/'ordinary-5111-final-main-20261015'}
GR=B/'toolchains/go1.26.3-from-185-20261014'; GO=GR/'bin/go'
env=os.environ.copy();env.update(GOROOT=str(GR),GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',CGO_ENABLED='1',GOMAXPROCS='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def census(root):
 rows={}
 for p in root.rglob('*'):
  if p.is_file() and (p.suffix=='.go' or p.name in ('go.mod','go.sum')) and '.git' not in p.parts:
   rows[str(p.relative_to(root))]=sha(p)
 return rows
def state():
 return {k:{'HEAD':subprocess.check_output(['git','-C',str(v),'rev-parse','HEAD'],text=True).strip(),'index':sha(Path(subprocess.check_output(['git','-C',str(v),'rev-parse','--path-format=absolute','--git-path','index'],text=True).strip())),'census':census(v)} for k,v in roots.items()}
def run(name,cmd,cwd,limit=120):
 rec={'argv':list(map(str,cmd)),'cwd':str(cwd),'env':{k:env[k] for k in ('GOROOT','GOTOOLCHAIN','GOWORK','GOPROXY','GOSUMDB','CGO_ENABLED','GOMAXPROCS')},'timeout_s':limit}
 (E/(name+'.command.json')).write_text(json.dumps(rec,indent=2))
 t=time.monotonic()
 with (E/(name+'.raw')).open('wb') as f:
  p=subprocess.Popen(list(map(str,cmd)),cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);p.wait();rc=124
 rec.update(exit=rc,elapsed_s=time.monotonic()-t)
 (E/(name+'.receipt.json')).write_text(json.dumps(rec,indent=2))
 print(name,rc,rec['elapsed_s'],flush=True)
 if rc:sys.exit(rc)


P=E/'primary-profiles';P.mkdir(exist_ok=True)
expected=json.loads((E/'binaries.json').read_text())
assert json.loads((E/'before.json').read_text())==state()
for rec in expected.values():assert sha(Path(rec['path']))==rec['sha256']
old=E.parent.parent/'absent-closure/perf'
(P/'baseline-reuse.json').write_text(json.dumps({'baseline_elf':expected['baseline-primary'],'profile_root':str(old/'primary-profiles'),'source_identity':json.loads((E/'before.json').read_text())['baseline'],'same_harness_sha256':sha(E/'primary_generation_routing_v6_test.go')},indent=2))
Eold=E;E=P
run('quiet-preflight',['ps','-eo','pid,pcpu,args'],P,10)
binary=Path(expected['candidate-primary']['path'])
common=['taskset','-c','0',binary,'-test.run=^$','-test.bench=^BenchmarkCommitAtPrimaryOnlyAfterDataGeneration$','-test.count=1','-test.benchmem','-test.timeout=90s']
run('candidate-cpu',common+['-test.benchtime=4096x','-test.cpuprofile='+str(P/'candidate-cpu.pprof')],roots['candidate'])
run('candidate-alloc',common+['-test.benchtime=512x','-test.memprofile='+str(P/'candidate-alloc.pprof'),'-test.memprofilerate=1'],roots['candidate'])
for name,profile in [('cpu','candidate-cpu.pprof'),('alloc_space','candidate-alloc.pprof'),('alloc_objects','candidate-alloc.pprof')]:
 for order in ('flat','cum'):
  cmd=[GO,'tool','pprof','-top','-nodecount=45','-sample_index='+('cpu' if name=='cpu' else name)]
  if order=='cum':cmd+=['-cum']
  cmd+=[binary,P/profile]
  run('candidate-'+name+'-'+order,cmd,roots['candidate'])
(P/'after.json').write_text(json.dumps(state(),sort_keys=True))
assert json.loads((Eold/'before.json').read_text())==state()
print('PROFILE COMPLETE SOURCES UNCHANGED',flush=True)
