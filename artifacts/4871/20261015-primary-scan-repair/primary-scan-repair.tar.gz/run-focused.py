import os,sys,json,subprocess,time,hashlib,signal
from pathlib import Path
B=Path('/home/mikers/benchmarks/mvcc-4871-repair-20261013');W=B/'ordinary-5111-final-main-20261015';E=B/'evidence/ordinary-5111-final-base-20261015/ci-read-custody-repair-20261015/primary-scan-repair'
GR=B/'toolchains/go1.26.3-from-185-20261014';GO=GR/'bin/go'
env=os.environ.copy();env.update(GOROOT=str(GR),GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',CGO_ENABLED='1',GOMAXPROCS='4')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def state():
 rows={str(p.relative_to(W)):sha(p) for p in W.rglob('*') if p.is_file() and (p.suffix=='.go' or p.name in ('go.mod','go.sum')) and '.git' not in p.parts}
 return {'HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'index':sha(Path(subprocess.check_output(['git','rev-parse','--path-format=absolute','--git-path','index'],cwd=W,text=True).strip())),'census':rows}
def run(name,cmd,limit=120):
 rec={'argv':list(map(str,cmd)),'cwd':str(W),'env':{k:env[k] for k in ('GOROOT','GOTOOLCHAIN','GOWORK','GOPROXY','GOSUMDB','CGO_ENABLED','GOMAXPROCS')},'timeout_s':limit};(E/(name+'.command.json')).write_text(json.dumps(rec,indent=2))
 t=time.monotonic()
 with (E/(name+'.raw')).open('wb') as f:
  p=subprocess.Popen(list(map(str,cmd)),cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();rc=124
 rec.update(exit=rc,elapsed_s=time.monotonic()-t);(E/(name+'.receipt.json')).write_text(json.dumps(rec,indent=2));print(name,rc,rec['elapsed_s'],flush=True)
 return rc

assert run('focused-preflight',['ps','-eo','pid,pcpu,args'],10)==0
assert run('focused-gofmt',[GR/'bin/gofmt','-w']+['TreeDB/zipper/read_only_prepare.go', 'TreeDB/zipper/zipper.go', 'TreeDB/zipper/primary_directory.go', 'TreeDB/db/vlog_gc_incremental.go', 'TreeDB/db/batch.go', 'TreeDB/db/root_publication_build_group.go', 'TreeDB/db/primary_dependency_projection_test.go', 'TreeDB/zipper/primary_base_evidence.go', 'TreeDB/zipper/primary_base_evidence_test.go'],10)==0
(E/'focused-before.json').write_text(json.dumps(state(),sort_keys=True))
rc=run('focused',[GO,'test','-json','-p=1','-count=1','-timeout=90s','./TreeDB/db','./TreeDB/zipper','-run','^(TestPrimaryUnchangedOuterLeafBaseReusesExactDependencies|TestPrimaryOuterLeafPointerRetargetMatchesFullProjection|TestPrimaryBaseEvidenceExpiresWithOriginalConstruction|TestOuterLeafSteadyStateWriteDoesNotScanCandidateTree|TestPrimaryDirectoryRealSlotsCorruptionFallback|TestPrimarySlotCustodyBothSlotsOverwriteAndReopenV6|TestDurableRootCandidateScanRepairsReferenceTracker|TestDurableRootCandidateScanAbortPreservesReferenceTracker)$'])
(E/'focused-after.json').write_text(json.dumps(state(),sort_keys=True))
assert (E/'focused-before.json').read_bytes()==(E/'focused-after.json').read_bytes()
sys.exit(rc)
