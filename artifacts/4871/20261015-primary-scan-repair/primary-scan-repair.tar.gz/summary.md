# PRIMARY dependency projection repair: bounded ordinary guard

Candidate is frozen at the full source/HEAD/index identity in perf/before.json, unchanged through perf/after.json. Nine authored experiment paths are copied under candidate-source/ and bound by candidate-source-manifest.json. The earlier absent-closure candidate remains immutable and published separately.

The unchanged-production RED observed exactly four candidate scans across four PRIMARY-only replacements. The corrected focused DB/zipper eight-selector run passed; its one earlier assumption failure is retained: insert-only DATA materialization has an independent valid reuse proof, so the corrected destructive fallback overwrites a genuine existing DATA key. New unchanged-base evidence is independently shown absent after materialization.

Actual public Store.CommitAt generation lifecycle passed on the exact candidate binary before timing. The baseline PRIMARY fixture overlay is byte-identical to the candidate fixture. Production baseline is exact main5bca; all tools use pinned Go1.26.3/offline/CPU0/GOMAX1.

All eighteen planned fresh benchmark processes passed, in three AB/BA/AB pairs per workload. Get uses500ms, DATA BatchWrite1000x, PRIMARY post-DATA equal-ts durable CommitAt128x. No replacement samples, profiling or reruns were used. Strict guard remains RED.

|workload|baseline ns/op|candidate ns/op|time change|baseline B/op|candidate B/op|baseline objects|candidate objects|
|---|---:|---:|---:|---:|---:|---:|---:|
|GetVersioned|318.1|334.3|5.093%|0.0|0.0|0.0|0.0|
|ConditionalTxnBaselineBatchWrite|21134.0|20397.0|-3.487%|31943.0|31503.0|127.0|104.0|
|CommitAtPrimaryOnlyAfterDataGeneration|143142.0|154615.0|8.015%|279178.0|283896.0|474.0|390.0|

PRIMARY generation advances/op baseline2 versus candidate0 is the intended producer-routing behavior and is independently checked through the public lifecycle/reopen control. It does not justify the remaining timing/byte regression.

The nine-path projection patch changes no Get read path. PRIMARY source hypothesis: per-decode primaryBankMetadataScratchV5 and retained resource allocation capacity remain; prior whole-harness profiles are not evidence of their current per-operation cost after scan removal. Current residual attribution is pending, with no source changes or timing rerun.

Scope: ordinary public diagnostics only. No native ACK or final CI/qualification claim. Raw commands, exits, ELF identities, fixture overlay, exact source census and the original RED/failed assumption run remain retained.
