package db

import (
	"bytes"
	"fmt"
	"github.com/snissn/gomap/TreeDB/node"
	"testing"
)

func TestPrimaryUnchangedOuterLeafBaseReusesExactDependencies(t *testing.T) {
	opts := Options{Dir: t.TempDir(), Durability: DurabilityWALOffRelaxed, IndexPrimaryDirectory: true, IndexOuterLeavesInValueLog: true}
	d, err := Open(opts)
	if err != nil {
		t.Fatal(err)
	}
	defer d.Close()
	log := &registeredLeafPageLog{db: d, dir: d.dir}
	if err = log.ensureWriter(); err != nil {
		t.Fatal(err)
	}
	d.SetLeafPageLog(log)
	defer closeVacuumTestLeafPageLog(t, d, log)
	// A single ordinary batch exceeding the directory capacity creates a genuine
	// outer-log DATA base before the PRIMARY-only replacements.
	b := d.NewBatch()
	for i := 0; i < node.PrimaryDirectoryMaxEntries+2; i++ {
		if err = b.Set([]byte(fmt.Sprintf("seed/%03d", i)), []byte("old")); err != nil {
			t.Fatal(err)
		}
	}
	if err = b.WriteSync(); err != nil {
		t.Fatal(err)
	}
	b.Close()
	if err = d.SetSync([]byte("hot"), []byte("before")); err != nil {
		t.Fatal(err)
	}
	old := d.AcquireSnapshot()
	defer old.Close()
	base, _ := primaryDBDirectory(t, d).Base()
	scans := 0
	d.testScanCandidateExternalReferencesHook = func() { scans++ }
	for i := 0; i < 4; i++ {
		if err = d.SetSync([]byte("hot"), []byte(fmt.Sprintf("after/%d", i))); err != nil {
			t.Fatal(err)
		}
	}
	d.testScanCandidateExternalReferencesHook = nil
	if scans != 0 {
		t.Fatalf("PRIMARY-only replacement scanned unchanged outer-leaf base %d times", scans)
	}
	gotBase, _ := primaryDBDirectory(t, d).Base()
	if gotBase != base {
		t.Fatal("PRIMARY-only write changed materialized base")
	}
	if got, err := old.Get([]byte("hot")); err != nil || !bytes.Equal(got, []byte("before")) {
		t.Fatalf("held cut %q %v", got, err)
	}
	if got, err := d.Get([]byte("hot")); err != nil || !bytes.Equal(got, []byte("after/3")) {
		t.Fatalf("current %q %v", got, err)
	}
}
