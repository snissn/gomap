package freelist

import (
	"bytes"
	"errors"
	"math"
	"testing"
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
)

func privateQuantumV6() *iterator.OrdinalScanWork {
	return &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
}
func privateInsertTestV6(t testing.TB, s *privateUint64SetV6, key uint64) bool {
	t.Helper()
	for i := 0; i < 100000; i++ {
		added, ready, e := s.insert(key, privateQuantumV6())
		if e != nil {
			t.Fatalf("insert %d phase=%d: %v", key, s.phase, e)
		}
		if ready {
			return added
		}
	}
	t.Fatal("private insert failed to progress")
	return false
}
func privateCloseTestV6(t testing.TB, s *privateUint64SetV6) {
	t.Helper()
	for i := 0; i < 100000; i++ {
		ok, e := s.close(privateQuantumV6())
		if e != nil {
			t.Fatal(e)
		}
		if ok {
			return
		}
	}
	t.Fatal("close failed to progress")
}
func privateContainsTestV6(s *privateUint64SetV6, key uint64) bool {
	if key == 0 {
		return s.zero
	}
	if len(s.slots) == 0 {
		return false
	}
	at := int(privateHashV6(key) & uint64(len(s.slots)-1))
	for i := 0; i < len(s.slots); i++ {
		v := s.slots[at]
		if v == key {
			return true
		}
		if v == 0 {
			return false
		}
		at = (at + 1) & (len(s.slots) - 1)
	}
	return false
}
func TestPrivateCapacitySetSemanticsAndScalingV6(t *testing.T) {
	for _, n := range []int{0, 1, 33, 257, 4097} {
		t.Run(stringNamePrivateV6(n), func(t *testing.T) {
			var owner retainedalloc.Owner
			owner.Initialize(0)
			s := privateUint64SetV6{owner: &owner}
			if s.length() != 0 || owner.Bytes() != 0 || s.slots != nil {
				t.Fatal("empty set allocated storage")
			}
			if !privateInsertTestV6(t, &s, 0) || privateInsertTestV6(t, &s, 0) || s.length() != 1 || s.slots != nil || owner.Bytes() != 0 {
				t.Fatal("zero-only set needs no backing")
			}
			for _, key := range []uint64{math.MaxUint64} {
				if !privateInsertTestV6(t, &s, key) || privateInsertTestV6(t, &s, key) {
					t.Fatal("zero/max/duplicate")
				}
			}
			for i := 1; i <= n; i++ {
				if !privateInsertTestV6(t, &s, uint64(i)) {
					t.Fatal("new key")
				}
			}
			for i := 1; i <= n; i++ {
				if !privateContainsTestV6(&s, uint64(i)) || privateInsertTestV6(t, &s, uint64(i)) {
					t.Fatal("lost or duplicated key", i)
				}
			}
			if !s.valid() || s.length() != n+2 || owner.Bytes() != s.charge || s.count > uint64(len(s.slots)/2) {
				t.Fatal("capacity/owner", s.length(), owner.Bytes(), s.charge)
			}
			privateCloseTestV6(t, &s)
			if owner.Bytes() != 0 || s.slots != nil || s.debt != 0 || s.cloneSource != nil {
				t.Fatal("last alias/refund")
			}
		})
	}
}
func stringNamePrivateV6(n int) string {
	switch n {
	case 0:
		return "empty"
	case 1:
		return "one"
	case 33:
		return "33"
	case 257:
		return "257"
	default:
		return "4097"
	}
}
func TestPrivateCapacityCollisionsOverflowAndUnsupportedV6(t *testing.T) {
	var owner retainedalloc.Owner
	owner.Initialize(0)
	s := privateUint64SetV6{owner: &owner}
	keys := make([]uint64, 0, 9)
	for key := uint64(1); len(keys) < 9; key++ {
		if privateHashV6(key)&15 == 0 {
			keys = append(keys, key)
		}
	}
	for _, key := range keys {
		privateInsertTestV6(t, &s, key)
	}
	for _, key := range keys {
		if !privateContainsTestV6(&s, key) {
			t.Fatal("collision lost key")
		}
	}
	if len(s.slots) != 32 {
		t.Fatal("half load did not grow")
	}
	privateCloseTestV6(t, &s)
	if _, _, e := privateObjectChargeV6(2, math.MaxUint64); e == nil {
		t.Fatal("overflow")
	}
	if _, _, e := privateArrayChargeV6(-1); e == nil {
		t.Fatal("negative capacity")
	}
	if _, _, e := s.insert(1, nil); !errors.Is(e, retainedalloc.ErrWorkRequired) {
		t.Fatal("nil work fallback", e)
	}
	// A corrupt full probe table terminates with an invariant error, never loops.
	s.slots = make([]uint64, 16)
	for i := range s.slots {
		s.slots[i] = uint64(i + 1)
	}
	s.phase, s.key, s.opVersion = 2, 99, s.version
	if _, _, e := s.insert(99, privateQuantumV6()); e == nil {
		t.Fatal("full table accepted")
	}
}
func TestPrivateCapacityEveryTurnRefusalAndCancelV6(t *testing.T) {
	for available := uint64(0); available <= 32; available++ {
		t.Run(stringNamePrivateV6(int(available)), func(t *testing.T) {
			var owner retainedalloc.Owner
			owner.Initialize(0)
			s := privateUint64SetV6{owner: &owner}
			for i := uint64(1); i <= 8; i++ {
				privateInsertTestV6(t, &s, i)
			}
			oldCharge := s.charge
			w := privateQuantumV6()
			w.Records = 32 - available
			_, _, e := s.insert(9, w)
			if e != nil {
				t.Fatal(e)
			}
			if w.Records > 32 || owner.Bytes() < s.charge+s.nextCharge+s.snapshotCharge || owner.Bytes() > s.charge+s.nextCharge+s.snapshotCharge+s.debt || owner.Bytes() < oldCharge {
				t.Fatal("unfunded growth/overlap", owner.Bytes())
			}
			privateCloseTestV6(t, &s)
			if owner.Bytes() != 0 {
				t.Fatal("cancel leaked partial growth", owner.Bytes())
			}
		})
	}
}
func TestPrivateCapacitySnapshotIndependentPlanAndPeakV6(t *testing.T) {
	var owner retainedalloc.Owner
	owner.Initialize(0)
	source := privateUint64SetV6{owner: &owner}
	input := map[uint64]struct{}{0: {}, 2: {}, 9: {}, math.MaxUint64: {}}
	if ok, e := source.captureMap(input, privateQuantumV6()); !ok || e != nil {
		t.Fatal(ok, e)
	}
	snapshotCharge := source.snapshotCharge
	if snapshotCharge == 0 || owner.Bytes() != snapshotCharge {
		t.Fatal("snapshot not charged")
	}
	for i := 0; i < 1000; i++ {
		ok, e := source.buildSnapshot(privateQuantumV6())
		if e != nil {
			t.Fatal(e)
		}
		if ok {
			break
		}
		if source.charge > ^uint64(0)-source.nextCharge || source.charge+source.nextCharge > ^uint64(0)-source.snapshotCharge {
			t.Fatal("snapshot live charge overflow")
		}
		live := source.charge + source.nextCharge + source.snapshotCharge
		if live > ^uint64(0)-source.debt || owner.Bytes() < live || owner.Bytes() > live+source.debt {
			t.Fatal("snapshot overlap/partial accounting completion", owner.Bytes(), live, source.debt)
		}
	}
	if source.snapshot != nil || source.snapshotCharge != 0 || source.debt != 0 || owner.Bytes() != source.charge {
		t.Fatal("snapshot last alias")
	}
	plan := privateUint64SetV6{owner: &owner}
	for attempt := 0; attempt < 2; attempt++ {
		for i := 0; i < 1000; i++ {
			ok, e := plan.cloneFrom(&source, privateQuantumV6())
			if e != nil {
				t.Fatal(e)
			}
			if ok {
				break
			}
		}
		if plan.length() != source.length() || &plan.slots[0] == &source.slots[0] || owner.Bytes() != plan.charge+source.charge {
			t.Fatal("plan backing/borrow")
		}
		privateInsertTestV6(t, &plan, 44)
		if privateContainsTestV6(&source, 44) {
			t.Fatal("independent plan changed source")
		}
		privateCloseTestV6(t, &plan)
		if owner.Bytes() != source.charge {
			t.Fatal("retry prior backing not refunded")
		}
	}
	privateCloseTestV6(t, &source)
	if owner.Bytes() != 0 {
		t.Fatal("leaked")
	}
	// Real governing budget rejects old+new overlap even though the final new
	// array alone fits. The original set/owner remain intact until cancellation.
	limits := memtable.DefaultCOWLimits()
	limits.MaxTotalBytes = 4096
	limits.MaxGenerationBytes = 4096
	limits.MaxRetiredBytes = 4096
	limits.MaxInFlightBytes = 4096
	budget, e := memtable.NewCOWBudget(limits)
	if e != nil {
		t.Fatal(e)
	}
	defer budget.Close()
	var limited retainedalloc.Owner
	limited.Initialize(0)
	enrollment, e := limited.Enroll(budget)
	if e != nil {
		t.Fatal(e)
	}
	defer enrollment.Close()
	set := privateUint64SetV6{owner: &limited}
	for i := uint64(1); i <= 8; i++ {
		privateInsertTestV6(t, &set, i)
	}
	// Leave exactly the replacement delta available, while the real old+new
	// overlap requires the full new array. Budget control and both external
	// lease headers are independent of the producer's own retained bytes.
	_, oldCharge, e := privateArrayChargeV6(len(set.slots))
	if e != nil {
		t.Fatal(e)
	}
	_, newCharge, e := privateArrayChargeV6(2 * len(set.slots))
	if e != nil || newCharge <= oldCharge || set.charge != oldCharge {
		t.Fatal("replacement geometry", oldCharge, newCharge, e)
	}
	headroom := newCharge - oldCharge
	if headroom == 0 || headroom >= newCharge {
		t.Fatal("replacement delta must fit without overlap", headroom)
	}
	stats := budget.Stats()
	leaseCharge := memtable.COWAllocationCharge(uint64(unsafe.Sizeof(memtable.COWExternalLease{})))
	if stats.TotalBytes > limits.MaxTotalBytes || headroom > limits.MaxTotalBytes-stats.TotalBytes || leaseCharge > limits.MaxTotalBytes-stats.TotalBytes-headroom {
		t.Fatal("filler headroom underflow")
	}
	heldPayload := limits.MaxTotalBytes - stats.TotalBytes - headroom - leaseCharge
	held, e := budget.AcquireRetention(heldPayload)
	if e != nil {
		t.Fatal(e)
	}
	filled := budget.Stats()
	if headroom > limits.MaxInFlightBytes || headroom > limits.MaxRetiredBytes || filled.HistoryBytes > math.MaxUint64-filled.ReservedBytes || filled.HistoryBytes+filled.ReservedBytes > math.MaxUint64-filled.DeferredBytes {
		t.Fatal("filler capacity overflow", filled)
	}
	if filled.TotalBytes != limits.MaxTotalBytes-headroom || filled.ReservedBytes > limits.MaxInFlightBytes-headroom || filled.HistoryBytes+filled.ReservedBytes+filled.DeferredBytes > limits.MaxRetiredBytes-headroom {
		t.Fatal("filler did not preserve final replacement capacity", filled)
	}
	before, originalSlots, originalCount, originalVersion := limited.Bytes(), &set.slots[0], set.count, set.version
	failed := false
	for i := 0; i < 100; i++ {
		_, ready, e := set.insert(9, privateQuantumV6())
		if e != nil {
			if !errors.Is(e, memtable.ErrCOWCapacity) {
				t.Fatal("unexpected overlap refusal", e)
			}
			failed = true
			break
		}
		if ready {
			t.Fatal("overlap unexpectedly fit")
		}
	}
	if !failed || limited.Bytes() != before || set.next != nil || &set.slots[0] != originalSlots || set.count != originalCount || set.version != originalVersion || privateContainsTestV6(&set, 9) {
		t.Fatal("peak refusal mutated state")
	}
	held.Close()
	privateCloseTestV6(t, &set)
}

func privatePreparedBoundTestV6(t *testing.T, a *Allocator, name string) (*COWPreparationWorkV6, *retainedalloc.Owner) {
	t.Helper()
	s := &COWPreparationWorkV6{}
	o := &retainedalloc.Owner{}
	o.Initialize(0)
	bindOwnedLedgerFixtureV6(t, a, o)
	if e := s.BindRetainedOwnerV6(o); e != nil {
		t.Fatal(e)
	}
	sink := &CandidatePageSinkV1{}
	for i := 0; i < 10000; i++ {
		_, ok, e := s.Step(a, 2, 2, candidateIDFromString(name), ReuseCapability{}, nil, sink, privateConstructionWorkTestV6(t, a))
		if e != nil {
			t.Fatalf("phase%d/reuse%d: %v", s.phase, s.materialize.reuse.phase, e)
		}
		if ok {
			return s, o
		}
	}
	t.Fatal("bound preparation failed to progress")
	return nil, nil
}
func privateCancelBoundTestV6(t *testing.T, s *COWPreparationWorkV6, o *retainedalloc.Owner, originalLedger *ReservationLedger) {
	t.Helper()
	if originalLedger == nil || originalLedger.metadata != o || s.ledger != nil && s.ledger != originalLedger {
		t.Fatal("cancel lost original allocator ledger or owner before cleanup")
	}
	// A refusal before capture's first allocation legitimately leaves s.ledger
	// nil. The caller still owns the exact allocator ledger; prove that this is
	// an uncaptured constructor, not a lost private/claim cleanup obligation.
	uncaptured := s.ledger == nil
	assertUncaptured := func() {
		t.Helper()
		if s.allocator != nil || s.private != nil || s.prepared != nil || s.result != nil || s.materialize.txn != nil || s.captureStage != 0 || s.privateHeaderCharge != 0 || s.privateAllocatedCharge != 0 || s.privateAbandonedCharge != 0 || s.privateDebtOwner != nil || s.privateDebt != 0 || s.ledgerRollback.bound || s.ledgerRollback.ledger != nil || s.ledgerRollback.debt != 0 {
			t.Fatal("uncaptured refusal retained an unexplained private obligation")
		}
		for _, control := range []*privateUint64SetV6{&s.changedPrivate, &s.replacedPrivate, &s.materialize.reuse.plannedReplaced, &s.sinkPrivate} {
			if control.slots != nil || control.next != nil || control.snapshot != nil || control.cloneSource != nil || control.charge != 0 || control.nextCharge != 0 || control.snapshotCharge != 0 || control.debtOwner != nil || control.debt != 0 {
				t.Fatal("uncaptured refusal retained private backing or debt")
			}
		}
		if o.Bytes() != originalLedger.storageCharge {
			t.Fatal("uncaptured refusal changed original canonical charge", o.Bytes(), originalLedger.storageCharge)
		}
	}
	if uncaptured {
		assertUncaptured()
	}
	for i := 0; i < 10000; i++ {
		ok, e := s.Cancel(privateQuantumV6())
		if e != nil {
			t.Fatal(e)
		}
		if ok {
			if uncaptured {
				assertUncaptured()
			}
			if o.Bytes() != originalLedger.storageCharge {
				t.Fatal("private cleanup failed to leave exact canonical charge", o.Bytes(), originalLedger.storageCharge)
			}
			return
		}
	}
	t.Fatal("cancel stalled")
}
func TestPrivateCapacityBoundCaptureCanonicalAndStaleV6(t *testing.T) {
	for _, reuse := range []bool{false, true} {
		t.Run(map[bool]string{false: "append", true: "reuse"}[reuse], func(t *testing.T) {
			a := newPrivateMetadataPlacementAllocatorV6(t, reuse)
			ordinary := newPrivateMetadataPlacementAllocatorV6(t, reuse)
			id := candidateIDFromString("bound-canonical")
			want, e := ordinary.PrepareCOWCandidateV1(2, 2, id, ReuseCapability{}, 0, NewCandidatePageSinkV1())
			if e != nil {
				t.Fatal(e)
			}
			s, o := privatePreparedBoundTestV6(t, a, "bound-canonical")
			ledger, ready := s.MaintenancePrivateLedgerForTestV6(privateQuantumV6())
			if !ready || !ledger.Complete || !ledger.CloneChargesExact || !ledger.MapsNil {
				t.Fatalf("completed private ledger: %+v ready=%v", ledger, ready)
			}
			if _, ok := s.MaintenancePrivateLedgerForTestV6(&iterator.OrdinalScanWork{}); ok {
				t.Fatal("unadmitted private observation")
			}
			savedCharge := s.privateHeaderCharge
			s.privateHeaderCharge++
			bad, ok := s.MaintenancePrivateLedgerForTestV6(privateQuantumV6())
			s.privateHeaderCharge = savedCharge
			if !ok || bad.Complete || bad.CloneChargesExact {
				t.Fatal("wrong clone charge accepted")
			}
			if reuse && (!s.materialize.reuse.reused || !s.materialize.reuse.planBound || s.materialize.reuse.plannedReplaced.owner != o || s.materialize.reuse.planned.replacedMetadata != nil) {
				t.Fatal("explicit independent planning route not exercised")
			}
			if s.privateHeaderCharge != retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(FreelistTxn{}))) || s.privateAllocatedCharge == 0 || s.private.changedChunks != nil || s.private.replacedMetadata != nil {
				t.Fatal("missing capture provenance")
			}
			if s.result.GenerationRef() != want.Candidate().GenerationRef() || len(s.result.pages) != len(want.Candidate().pages) {
				t.Fatal("canonical shape")
			}
			for i, p := range s.result.pages {
				q := want.Candidate().pages[i]
				if p.PageID != q.PageID || !bytes.Equal(p.Data, q.Data) {
					t.Fatal("canonical page differs", i)
				}
			}
			if _, e = a.Alloc(0); e != nil {
				t.Fatal(e)
			}
			if _, ok, e := s.Adopt(privateQuantumV6()); ok || !errors.Is(e, ErrCOWPreparationStaleV6) {
				t.Fatal("stale source accepted", ok, e)
			}
			current := a.cow.txn
			privateCancelBoundTestV6(t, s, o, a.cow.ledger)
			if a.cow.txn != current || current.changedChunks == nil || current.replacedMetadata == nil {
				t.Fatal("cancel destroyed canonical maps")
			}
			if e := a.CloseReservationLedgerV6(); e != nil || o.Bytes() != 0 {
				t.Fatal("canonical ledger last edge", e, o.Bytes())
			}
		})
	}
}
func TestPrivateCapacityPartialCloneAdmissionCancelV6(t *testing.T) {
	for available := uint64(0); available <= 32; available++ {
		t.Run(stringNamePrivateV6(int(available)), func(t *testing.T) {
			a := newPrivatePrepareAllocatorV6(t)
			var s COWPreparationWorkV6
			var o retainedalloc.Owner
			o.Initialize(0)
			bindOwnedLedgerFixtureV6(t, a, &o)
			originalLedger, originalTxn := a.cow.ledger, a.cow.txn
			if e := s.BindRetainedOwnerV6(&o); e != nil {
				t.Fatal(e)
			}
			// Nonempty original maps are captured by an exact vector, then built outside
			// the lock. Its borrowed planner copy cannot authorize an early refund.
			sink := &CandidatePageSinkV1{}
			w := privateQuantumV6()
			w.Records = 32 - available
			_, _, e := s.Step(a, 2, 2, candidateIDFromString("partial-clone"), ReuseCapability{}, nil, sink, w)
			if e != nil {
				t.Fatal(e)
			}
			if s.private != nil && s.privateHeaderCharge == 0 {
				t.Fatal("uncharged clone")
			}
			if s.private != nil && cap(s.private.allocated) > 0 && s.privateAllocatedCharge == 0 {
				t.Fatal("uncharged vector")
			}
			// Detached scalar debt survives the original owner's debit until the
			// SAME shrink/reset receipt finishes; it is no longer live backing.
			var live, debt uint64
			live = a.cow.ledger.storageCharge
			add := func(total *uint64, n uint64) {
				if n > math.MaxUint64-*total {
					t.Fatal("partial physical provenance overflow")
				}
				*total += n
			}
			for _, n := range []uint64{s.privateHeaderCharge, s.privateAllocatedCharge, s.privateAbandonedCharge, s.materialize.inventory.normalized.scratchCharge, s.materialize.reuse.inventory.normalized.scratchCharge} {
				add(&live, n)
			}
			for _, control := range []*privateUint64SetV6{&s.changedPrivate, &s.replacedPrivate, &s.materialize.reuse.plannedReplaced, &s.sinkPrivate} {
				for _, n := range []uint64{control.charge, control.nextCharge, control.snapshotCharge} {
					add(&live, n)
				}
				add(&debt, control.debt)
			}
			add(&debt, s.privateDebt)
			upper := live
			add(&upper, debt)
			if actual := o.Bytes(); actual < live || actual > upper || debt == 0 && actual != live {
				t.Fatal("partial physical provenance mismatch", actual, live, debt)
			}
			privateCancelBoundTestV6(t, &s, &o, originalLedger)
			if a.cow.ledger != originalLedger || a.cow.txn != originalTxn {
				t.Fatal("partial capture cancellation replaced original allocator custody")
			}
			if e := a.CloseReservationLedgerV6(); e != nil || o.Bytes() != 0 {
				t.Fatal("canonical shutdown", e, o.Bytes())
			}
		})
	}
}
func TestPrivateCapacityPublishedCleanupPreservesCanonicalV6(t *testing.T) {
	a := newPrivateMetadataPlacementAllocatorV6(t, true)
	s, o := privatePreparedBoundTestV6(t, a, "published-private-controls")
	before := o.Bytes()
	if ok, e := s.ClosePublishedWithWorkV6(privateQuantumV6()); ok || !errors.Is(e, ErrCandidateConsumed) || o.Bytes() != before {
		t.Fatal("previsible published cleanup", ok, e)
	}
	var activation COWActivationWorkV1
	for i := 0; i < 10000; i++ {
		ok, e := a.PrepareCOWActivationWithWorkV1(s.result, &activation, privateQuantumV6())
		if e != nil {
			t.Fatal(e)
		}
		if ok {
			break
		}
	}
	prepared, ok, e := s.AdoptAndActivateV6(&activation, privateAtomicWorkTestV6(t, s))
	if !ok || e != nil {
		t.Fatal(ok, e)
	}
	materializeAllocatorCOWCandidateForTest(t, a.pager, prepared)
	if e := a.PublishActivatedCOWPrefixV1([]*PreparedCOWCandidateV1{prepared}, ReuseCapability{}); e != nil {
		t.Fatal(e)
	}
	live, generation := a.cow.txn, a.cow.generation
	pages := prepared.Candidate().pages
	done := false
	for i := 0; i < 10000; i++ {
		done, e = s.ClosePublishedWithWorkV6(privateQuantumV6())
		if e != nil {
			t.Fatal(e)
		}
		if done {
			break
		}
	}
	if !done || o.Bytes() != a.cow.ledger.storageCharge || a.cow.txn != live || a.cow.generation != generation || live.changedChunks == nil || live.replacedMetadata == nil || len(pages) == 0 || len(pages[0].Data) != 4096 {
		t.Fatal("published cleanup damaged canonical output")
	}
	if e := a.CloseReservationLedgerV6(); e != nil || o.Bytes() != 0 {
		t.Fatal("canonical shutdown", e, o.Bytes())
	}
}

// Enabled scaling design: expected hash behavior is measured only when root
// separately selects timing. The normal scaling control above asserts semantics.
func BenchmarkPrivateCapacityInsertV6(b *testing.B) {
	for _, n := range []int{33, 257, 4097} {
		b.Run(stringNamePrivateV6(n), func(b *testing.B) {
			for j := 0; j < b.N; j++ {
				var o retainedalloc.Owner
				o.Initialize(0)
				s := privateUint64SetV6{owner: &o}
				for i := 1; i <= n; i++ {
					privateInsertTestV6(b, &s, uint64(i))
				}
				privateCloseTestV6(b, &s)
			}
		})
	}
}

func TestPrivateCapacityOversizedSnapshotAndAllocationV6(t *testing.T) {
	var o retainedalloc.Owner
	o.Initialize(0)
	s := privateUint64SetV6{owner: &o}
	input := make(map[uint64]struct{}, 33)
	for i := uint64(1); i <= 33; i++ {
		input[i] = struct{}{}
	}
	var tooLarge *iterator.OrdinalUnitTooLarge
	if ok, e := s.captureMap(input, privateQuantumV6()); ok || !errors.As(e, &tooLarge) || o.Bytes() != 0 || s.snapshot != nil {
		t.Fatal("oversized snapshot effects", ok, e)
	}
	// Indivisible allocation fails before admission/make, not by inventing a
	// cardinality limit or increasing the public byte allowance.
	s.phase, s.key, s.opVersion = 3, 17, s.version
	s.slots = make([]uint64, 1<<17)
	if _, ok, e := s.insert(17, privateQuantumV6()); ok || !errors.As(e, &tooLarge) || o.Bytes() != 0 || s.next != nil {
		t.Fatal("oversized growth effects", ok, e)
	}
}
func TestPrivateCapacitySinkDuplicateAndCommittedResumeV6(t *testing.T) {
	var o retainedalloc.Owner
	o.Initialize(0)
	set := privateUint64SetV6{owner: &o}
	for i := uint64(1); i <= 8; i++ {
		privateInsertTestV6(t, &set, i)
	}
	// Preempt at the actual old-array detach. Native retries continue original
	// refund, retaining exactly one committed pending key rather than reinserting.
	for i := 0; i < 1000 && set.phase != 11; i++ {
		w := privateQuantumV6()
		w.Records = 30
		if set.phase == 3 || set.phase == 7 || set.phase == 10 {
			w.Records = 29
		}
		_, _, e := set.insert(9, w)
		if e != nil {
			t.Fatal(e)
		}
	}
	if set.phase != 11 || !privateContainsTestV6(&set, 9) || set.debt == 0 || set.next != nil || o.Bytes() != set.charge+set.debt {
		t.Fatal("commit/refund custody", set.phase)
	}
	if !privateInsertTestV6(t, &set, 9) || privateInsertTestV6(t, &set, 9) {
		t.Fatal("committed insert replay")
	}
	var sink CandidatePageSinkV1
	recorded := recordingSink{sink: &sink, privateIDs: &set}
	data := make([]byte, 4096)
	if _, e := recorded.writeWithWork(9, data, privateQuantumV6()); !errors.Is(e, ErrGenerationFormat) {
		t.Fatal("sink duplicate accepted", e)
	}
	recorded = recordingSink{}
	privateCloseTestV6(t, &set)
	if o.Bytes() != 0 {
		t.Fatal("sink retained backing")
	}
}

// A legitimate original reserved tail makes the live transaction record an
// abandoned append before capture. The copied vector is distinct private
// backing; cancelling it must preserve both the canonical vector and foreign
// ledger reservation. No candidate adoption/publication occurs in this control.
func TestPrivateCapacityAbandonedVectorAdmissionAndCancelV6(t *testing.T) {
	a := newPrivatePrepareAllocatorV6(t)
	var owner retainedalloc.Owner
	owner.Initialize(0)
	bindOwnedLedgerFixtureV6(t, a, &owner)
	foreign := candidateIDFromString("private-capture-foreign-tail")
	start := a.cow.txn.highWater
	if e := a.cow.ledger.reserve(foreign, []uint64{start}); e != nil {
		t.Fatal(e)
	}
	if id, e := a.AllocAppend(); e != nil || id != start+1 {
		t.Fatal(id, e)
	}
	original := a.cow.txn
	if len(original.abandonedAppends) != 1 || len(original.allocated) != 2 {
		t.Fatal("original tail geometry")
	}
	var s COWPreparationWorkV6
	if e := s.BindRetainedOwnerV6(&owner); e != nil {
		t.Fatal(e)
	}
	for calls := 0; calls < 10000 && s.phase < 3; calls++ {
		// Exercise capture itself and stop before materialization/claim.
		ready, e := s.capture(a, privateQuantumV6())
		if e != nil {
			t.Fatal(e)
		}
		if ready {
			break
		}
	}
	_, wantAllocated, _ := privateObjectChargeV6(len(original.allocated), uint64(unsafe.Sizeof(allocatedPage{})))
	_, wantAbandoned, _ := privateObjectChargeV6(len(original.abandonedAppends), uint64(unsafe.Sizeof(ReservationExtentV1{})))
	if s.private == nil || s.privateAllocatedCharge != wantAllocated || s.privateAbandonedCharge != wantAbandoned || wantAbandoned == 0 || &s.private.allocated[0] == &original.allocated[0] || &s.private.abandonedAppends[0] == &original.abandonedAppends[0] || s.private.abandonedAppends[0] != original.abandonedAppends[0] {
		t.Fatal("private copied vectors lack exact independent admission")
	}
	privateCancelBoundTestV6(t, &s, &owner, a.cow.ledger)
	if a.cow.txn != original || len(original.abandonedAppends) != 1 || !a.cow.ledger.Reserved(start) {
		t.Fatal("cancel consumed canonical/foreign tail")
	}
	if e := a.cow.ledger.RollbackPreVisible(foreign); e != nil {
		t.Fatal(e)
	}
	if e := a.CloseReservationLedgerV6(); e != nil || owner.Bytes() != 0 {
		t.Fatal("canonical shutdown", e, owner.Bytes())
	}
}
