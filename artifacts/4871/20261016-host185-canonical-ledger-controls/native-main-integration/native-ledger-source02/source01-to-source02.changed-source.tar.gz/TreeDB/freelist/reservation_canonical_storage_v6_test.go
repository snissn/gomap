package freelist

import (
	"errors"
	"math"
	"testing"
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
)

func finishLedgerWorkTestV6(t *testing.T, s *COWLedgerRetirementWorkV6) {
	t.Helper()
	for i := 0; i < 10000; i++ {
		w := privateQuantumV6()
		ok, e := s.ContinueWithWorkV6(w)
		if e != nil {
			t.Fatal(e)
		}
		if w.Records > 32 || w.Bytes > 1<<20 {
			t.Fatal("retirement exceeded original quantum")
		}
		if ok {
			return
		}
	}
	t.Fatal("original retirement failed to advance")
}
func ownedLedgerTestV6(t *testing.T) (*ReservationLedger, *retainedalloc.Owner) {
	t.Helper()
	o := &retainedalloc.Owner{}
	o.Initialize(0)
	l, e := NewOwnedReservationLedgerV6(o)
	if e != nil {
		t.Fatal(e)
	}
	return l, o
}
func closeOwnedLedgerTestV6(t *testing.T, l *ReservationLedger, o *retainedalloc.Owner) {
	t.Helper()
	m, n, e := l.detachClosedStorageV6()
	if e != nil {
		t.Fatal(e)
	}
	if m != o {
		t.Fatal("different original owner")
	}
	m.Remove(n)
	if o.Bytes() != 0 {
		t.Fatal("canonical last alias charge", o.Bytes())
	}
}
func TestCanonicalLedgerPatriciaSemanticsAndChargesV6(t *testing.T) {
	l, o := ownedLedgerTestV6(t)
	// Equal prefixes, zero and maximal page IDs exercise both fixed-width trees.
	keys := []uint64{0, 1, 2, 3, 1 << 31, 1 << 63, math.MaxUint64 - 1, math.MaxUint64}
	var ids []CandidateIDV1
	for i, key := range keys {
		var id CandidateIDV1
		id[15] = byte(i + 1)
		ids = append(ids, id)
		if e := l.reserve(id, []uint64{key, key}); e != nil {
			t.Fatal(e)
		}
	}
	branchPage := retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(ledgerPageNodeV6{})))
	branchCandidate := retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(ledgerCandidateNodeV6{})))
	per := retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(reservation{}))) + retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(ledgerPageClaimV6{}))) + retainedalloc.AllocationCharge(8)
	want := l.metadataCharge + uint64(len(keys))*per + uint64(len(keys)-1)*(branchPage+branchCandidate)
	if o.Bytes() != want || l.storageCharge != want || l.ownerCount != uint64(len(keys)) || l.candidateCount != uint64(len(keys)) {
		t.Fatal("constructor accounting", o.Bytes(), want, l.storageCharge)
	}
	for i, key := range keys {
		if l.pageClaimLockedV6(key) == nil || ledgerFixtureOwnerIDV6(l, key) != ids[i] {
			t.Fatal("lost key", key)
		}
	}
	replacement := candidateIDFromString("same-original-rekey")
	original := l.candidateLockedV6(ids[0])
	charge := o.Bytes()
	if e := l.Supersede(ids[0], replacement); e != nil {
		t.Fatal(e)
	}
	if l.candidateLockedV6(replacement) != original || l.candidateLockedV6(ids[0]) != nil || ledgerFixtureOwnerIDV6(l, keys[0]) != replacement || o.Bytes() != charge {
		t.Fatal("rekey replaced original claim or allocation")
	}
	ids[0] = replacement
	// Reverse deletion removes branches created by another leaf without losing
	// their independent charge or refunding a still-live branch.
	for i := len(ids) - 1; i >= 0; i-- {
		if e := l.Abandon(ids[i]); e != nil {
			t.Fatal(e)
		}
		if o.Bytes() != l.storageCharge {
			t.Fatal("detached branch charge")
		}
		for j := 0; j < i; j++ {
			if !l.Reserved(keys[j]) {
				t.Fatal("sibling removed", j)
			}
		}
	}
	if l.candidates != nil || l.owners != nil || l.storageCharge != l.metadataCharge {
		t.Fatal("canonical index residue")
	}
	closeOwnedLedgerTestV6(t, l, o)
}
func TestCanonicalLedgerClaimExactAdmissionAndNoEffectsV6(t *testing.T) {
	for _, below := range []bool{true, false} {
		t.Run(map[bool]string{true: "below", false: "exact"}[below], func(t *testing.T) {
			l, o := ownedLedgerTestV6(t)
			id := candidateIDFromString("boundary")
			// Empty original indexes, one distinct ID, no enrollment or replacement.
			r, b := ledgerStoragePriceV6(0, 0, 0, 0, 1, 0)
			ar, ab, ok := retainedalloc.NativeOwnerGrowthPriceForTestV6(0, 0)
			if !ok {
				t.Fatal("add price")
			}
			sr, sb, ok := retainedalloc.NativeAtomicRemovalPriceForTestV6(0, 0)
			if !ok {
				t.Fatal("shrink price")
			}
			w := &iterator.OrdinalScanWork{RecordLimit: r + ar + sr, ByteLimit: b + ab + sb}
			if below {
				w.RecordLimit--
			}
			before := o.Bytes()
			l.mu.Lock()
			claim, ready, e := l.installClaimStorageLockedV6(id, []uint64{7}, nil, nil, reservationInterval{}, false, 0, 0, false, w)
			l.mu.Unlock()
			if below {
				if ready || claim != nil || e != nil && !errors.Is(e, retainedalloc.ErrWorkRequired) {
					var large *iterator.OrdinalUnitTooLarge
					if !errors.As(e, &large) {
						t.Fatal(ready, e)
					}
				}
				if l.candidateCount != 0 || l.ownerCount != 0 || o.Bytes() != before {
					t.Fatal("refusal changed original state")
				}
			} else {
				if !ready || e != nil || claim != l.candidateLockedV6(id) || !l.Reserved(7) || w.Records > w.RecordLimit || w.Bytes > w.ByteLimit {
					t.Fatal("exact admitted claim", ready, e, w)
				}
				if e := l.Abandon(id); e != nil {
					t.Fatal(e)
				}
			}
			closeOwnedLedgerTestV6(t, l, o)
		})
	}
}
func TestCanonicalLedgerSharedOwnerCloseIsolationV6(t *testing.T) {
	l, o := ownedLedgerTestV6(t)
	peer, e := NewOwnedReservationLedgerV6(o)
	if e != nil {
		t.Fatal(e)
	}
	id := candidateIDFromString("live-peer")
	if e := peer.reserve(id, []uint64{11}); e != nil {
		t.Fatal(e)
	}
	before := o.Bytes()
	if _, _, e := peer.detachClosedStorageV6(); e == nil || o.Bytes() != before || !peer.Reserved(11) {
		t.Fatal("failed drain dropped peer custody")
	}
	m, n, e := l.detachClosedStorageV6()
	if e != nil {
		t.Fatal(e)
	}
	m.Remove(n)
	if o.Bytes() != peer.storageCharge || !peer.Reserved(11) {
		t.Fatal("generation refunded shared peer")
	}
	if e := peer.Abandon(id); e != nil {
		t.Fatal(e)
	}
	closeOwnedLedgerTestV6(t, peer, o)
}
func TestCanonicalLedgerCommittedRetirementInterleavesPinnedBurnsV6(t *testing.T) {
	l, o := ownedLedgerTestV6(t)
	burn := candidateIDFromString("burned-original")
	start, burnedPages, e := l.reserveTail(burn, 100, 2, nil, nil)
	if e != nil {
		t.Fatal(e)
	}
	if e = l.markTailWriteAttempted(burn); e != nil {
		t.Fatal(e)
	}
	if e = l.Fail(burn); e != nil {
		t.Fatal(e)
	}
	tomb := l.tailHead
	if tomb == nil || !tomb.burned || !tomb.cleanupDone {
		t.Fatal("failure lost preborn descriptor")
	}
	// reserveTail includes the reservation chain and root in addition to its
	// two state pages. Coverage must describe the SAME entire original range.
	if burnedPages <= 2 || burnedPages > uint64(^uint32(0)) || tomb.tailStart != start || tomb.tailCount != burnedPages || !l.Reserved(start+burnedPages-1) {
		t.Fatal("original burned tail geometry", burnedPages, tomb.tailCount)
	}
	var children [2]COWLedgerRetirementWorkV6
	for i := range children {
		id := candidateIDFromString(string(rune('a' + i)))
		_, _, e = l.reserveTail(id, 200+uint64(i)*10, 1, nil, []ReservationExtentV1{{StartPageID: start, Count: uint32(burnedPages), Kind: ReservationAbandonedAppend}})
		if e != nil {
			t.Fatal(e)
		}
		r := l.candidateLockedV6(id)
		r.state = CandidateCommittedPendingFinish
		children[i] = COWLedgerRetirementWorkV6{ledger: l, single: r, singleMode: true, bound: true, committed: true, native: true, stopIdentity: l.nextTailIdentity}
	}
	// Each admitted control advance may stop exactly at the original list node.
	for i := range children {
		for n := 0; n < 100; n++ {
			w := &iterator.OrdinalScanWork{RecordLimit: 3, ByteLimit: 1 << 20}
			_, e := children[i].ContinueWithWorkV6(w)
			if e != nil {
				t.Fatal(e)
			}
			if children[i].scan == tomb {
				break
			}
		}
		if children[i].scan != tomb {
			t.Fatal("did not pin exact original descriptor")
		}
	}
	if tomb.scanPins != 2 {
		t.Fatal("missing independent exact pins", tomb.scanPins)
	}
	late := candidateIDFromString("new-burn-after-both-stops")
	if _, _, e = l.reserveTail(late, 400, 1, nil, nil); e != nil {
		t.Fatal(e)
	}
	if e = l.markTailWriteAttempted(late); e != nil {
		t.Fatal(e)
	}
	if e = l.Fail(late); e != nil {
		t.Fatal(e)
	}
	// Alternate actual admitted advances while both receipts retain their
	// original positions. A peer may clear a burn or detach a tombstone; it
	// must never make the other receipt restart at the list head.
	var positions [2]uint64
	for round := 0; round < 2; round++ {
		for i := range children {
			w := &iterator.OrdinalScanWork{RecordLimit: 3, ByteLimit: 1 << 20}
			if _, err := children[i].ContinueWithWorkV6(w); err != nil {
				t.Fatal(err)
			}
			if node := children[i].scan; node != nil {
				if node.tailIdentity < positions[i] || node.tailIdentity > children[i].stopIdentity {
					t.Fatal("receipt traversal restarted or crossed captured stop")
				}
				positions[i] = node.tailIdentity
			}
		}
		if round == 0 && (tomb.scanPins != 1 || tomb.metadataCharge == 0 || tomb.burned) {
			t.Fatal("alternating peer lost original pinned tombstone")
		}
	}
	var finished [2]bool
	var turns [2]int
	for round := 0; round < 1000 && (!finished[0] || !finished[1]); round++ {
		for i := range children {
			if finished[i] {
				continue
			}
			turns[i]++
			var err error
			finished[i], err = children[i].ContinueWithWorkV6(privateQuantumV6())
			if err != nil {
				t.Fatal(err)
			}
			if node := children[i].scan; node != nil {
				if node.tailIdentity < positions[i] || node.tailIdentity > children[i].stopIdentity {
					t.Fatal("resumed traversal moved backwards")
				}
				positions[i] = node.tailIdentity
			}
		}
	}
	if !finished[0] || !finished[1] || turns[0] == 0 || turns[1] == 0 {
		t.Fatal("alternating original receipts did not complete", finished, turns)
	}
	if tomb.scanPins != 0 || tomb.metadataCharge != 0 || l.burnedCount != 1 || !l.Reserved(400) || l.Reserved(start) || l.Reserved(start+burnedPages-1) {
		t.Fatal("alternating finish lost later burn or replayed old cleanup")
	}
	before := o.Bytes()
	finishLedgerWorkTestV6(t, &children[1])
	if o.Bytes() != before {
		t.Fatal("retirement replay refunded twice")
	}
	if e := l.reserve(burn, []uint64{500}); e != nil {
		t.Fatal("candidate identity cannot be reused after real finish", e)
	}
	if e := l.Abandon(burn); e != nil {
		t.Fatal(e)
	}
	closeOwnedLedgerTestV6(t, l, o)
}

// Ordinary Lease-only enrollment remains valid. It must never become a
// finite native capability merely because the caller supplied work.
type canonicalOrdinaryBudgetV6 struct{ lease canonicalOrdinaryLeaseV6 }
type canonicalOrdinaryLeaseV6 struct {
	payload uint64
	closed  bool
}

func (b *canonicalOrdinaryBudgetV6) AcquireRetention(n uint64) (retainedalloc.Lease, error) {
	b.lease.payload = n
	return &b.lease, nil
}
func (l *canonicalOrdinaryLeaseV6) Resize(n uint64) error { l.payload = n; return nil }
func (l *canonicalOrdinaryLeaseV6) Close()                { l.closed = true; l.payload = 0 }

func TestCanonicalLedgerGoverningBudgetRefusalsV6(t *testing.T) {
	for _, mode := range []string{"capacity", "ordinary-lease"} {
		t.Run(mode, func(t *testing.T) {
			l, o := ownedLedgerTestV6(t)
			var budget retainedalloc.Budget
			var concrete *memtable.COWBudget
			if mode == "capacity" {
				limits := memtable.DefaultCOWLimits()
				limits.MaxTotalBytes = 4096
				limits.MaxGenerationBytes = 4096
				limits.MaxRetiredBytes = 4096
				limits.MaxInFlightBytes = 4096
				var e error
				concrete, e = memtable.NewCOWBudget(limits)
				if e != nil {
					t.Fatal(e)
				}
				defer concrete.Close()
				budget = concrete
			} else {
				budget = &canonicalOrdinaryBudgetV6{}
			}
			enrollment, e := o.Enroll(budget)
			if e != nil {
				t.Fatal(e)
			}
			defer enrollment.Close()
			before := o.Bytes()
			var external uint64
			if concrete != nil {
				external = concrete.Stats().ExternalBytes
			}
			points := make([]uint64, 100)
			for i := range points {
				points[i] = uint64(i + 1)
			}
			r, b := ledgerStoragePriceV6(0, 0, 0, 0, uint64(len(points)), 0)
			resize := 2*uint64(unsafe.Sizeof(memtable.COWExternalLease{})) + 2*uint64(unsafe.Sizeof(memtable.COWBudget{}))
			ar, ab, ok := retainedalloc.NativeOwnerGrowthPriceForTestV6(1, resize)
			if !ok {
				t.Fatal("growth")
			}
			sr, sb, ok := retainedalloc.NativeAtomicRemovalPriceForTestV6(1, resize)
			if !ok {
				t.Fatal("shrink")
			}
			w := &iterator.OrdinalScanWork{RecordLimit: r + ar + sr, ByteLimit: b + ab + sb}
			id := candidateIDFromString("governing-refusal")
			l.mu.Lock()
			claim, ready, e := l.installClaimStorageLockedV6(id, points, nil, nil, reservationInterval{}, false, 0, 0, false, w)
			l.mu.Unlock()
			if ready || claim != nil || e == nil || l.candidateCount != 0 || l.ownerCount != 0 || l.tailHead != nil || o.Bytes() != before || l.storageCharge != l.metadataCharge {
				t.Fatal("refusal lost original accounting/custody", ready, e, o.Bytes(), before)
			}
			if mode == "ordinary-lease" && !errors.Is(e, retainedalloc.ErrWorkRequired) {
				t.Fatal("unsupported capability", e)
			}
			if concrete != nil && concrete.Stats().ExternalBytes != external {
				t.Fatal("capacity refusal changed real lease")
			}
			enrollment.Close()
			closeOwnedLedgerTestV6(t, l, o)
			if concrete != nil && concrete.Stats().ExternalBytes != 0 {
				t.Fatal("last original budget alias")
			}
		})
	}
}

func TestCanonicalLedgerConstructorCloseOriginalCustodyV6(t *testing.T) {
	for _, mode := range []string{"ordinary-prepared", "failed-abort", "activated"} {
		t.Run(mode, func(t *testing.T) {
			a := newPrivatePrepareAllocatorV6(t)
			var owner retainedalloc.Owner
			owner.Initialize(0)
			bindOwnedLedgerFixtureV6(t, a, &owner)
			p, e := a.PrepareCOWCandidateV1(2, 2, candidateIDFromString("constructor-custody"), ReuseCapability{}, 0, NewCandidatePageSinkV1())
			if e != nil {
				t.Fatal(e)
			}
			if mode == "activated" {
				if e := a.ActivateCOWCandidateV1(p); e != nil {
					t.Fatal(e)
				}
			}
			first := errors.New("original abort failure")
			if mode == "failed-abort" {
				TestHookAbortCOWCandidateFailure = func() error { return first }
				defer func() { TestHookAbortCOWCandidateFailure = nil }()
			}
			original, charge, ledger := a.cow.prepared, owner.Bytes(), a.cow.ledger
			e = a.DrainConstructionLedgerV6()
			if mode == "ordinary-prepared" {
				if e != nil || owner.Bytes() != 0 || a.cow.ledger != nil || a.cow.txn.ledger != nil {
					t.Fatal("ordinary constructor did not drain", e, owner.Bytes())
				}
				return
			}
			if e == nil || a.cow.ledger != ledger || owner.Bytes() != charge || a.cow.prepared != original || p.ledgerClaim == nil {
				t.Fatal("failed drain dropped original graph", e)
			}
			if mode == "failed-abort" {
				if !errors.Is(e, first) {
					t.Fatal(e)
				}
				TestHookAbortCOWCandidateFailure = nil
				if e := a.DrainConstructionLedgerV6(); e != nil || owner.Bytes() != 0 {
					t.Fatal("original retry", e, owner.Bytes())
				}
			} else {
				materializeAllocatorCOWCandidateForTest(t, a.pager, p)
				if e := a.PublishActivatedCOWPrefixV1([]*PreparedCOWCandidateV1{p}, ReuseCapability{}); e != nil {
					t.Fatal(e)
				}
				if e := a.CloseReservationLedgerV6(); e != nil || owner.Bytes() != 0 {
					t.Fatal("published constructor join", e, owner.Bytes())
				}
			}
		})
	}
}
