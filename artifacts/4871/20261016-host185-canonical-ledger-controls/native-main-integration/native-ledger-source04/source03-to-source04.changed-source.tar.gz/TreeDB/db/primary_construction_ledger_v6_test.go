package db

import (
	"context"
	"errors"
	"path/filepath"
	"testing"

	"github.com/snissn/gomap/TreeDB/freelist"
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
)

// Exercise the real capsule selector BEFORE the final temporary allocator drain.
// A late error must not hand a runtime to an offline/vacuum caller that will
// discard it on error; the original replacement generation is its disposer.
func TestPrimaryConstructionLedgerLateHandoffCustodyV6(t *testing.T) {
	for _, mode := range []string{"success", "late-drain", "failed-close", "runtime-release"} {
		t.Run(mode, func(t *testing.T) {
			dir := t.TempDir()
			// Use the established physical producer: real persistent records,
			// RefreshValueLogSet and two SetPointer/WriteSync publications. Backend
			// SetSync intentionally rejects values outside its inline contract.
			prepareOfflinePointerPairV6(t, dir)
			d, err := Open(Options{Dir: dir, ResolvedProfile: ProfileNoWALFast, Durability: DurabilityWALOffRelaxed, DisableBackgroundPrune: true})
			if err != nil {
				t.Fatal(err)
			}
			defer d.Close()
			if primaryOfflineScopePlatformRefusal(t, d) {
				return
			}
			roots, err := d.CaptureRecoverableRootSetForInspection(context.Background())
			if err != nil {
				t.Fatal(err)
			}
			defer roots.Release()
			scope, err := d.captureOfflinePrimaryScopeV6()
			if err != nil {
				t.Fatal(err)
			}
			pair, err := d.newOfflinePrimaryPairV6(scope, defaultChunkSize)
			if err != nil {
				t.Fatal(err)
			}
			failedClose := false
			defer func() {
				freelist.TestHookAbortCOWCandidateFailure = nil
				if !failedClose {
					if e := completeOfflineScopeForTestV6(&scope); e != nil {
						t.Errorf("original pair cleanup: %v", e)
					}
					return
				}
				// Sticky failed-generation controls deliberately stay charged. Join
				// real handles without fabricating successful cleanup or refund.
				_ = pair.pager.Close()
				_ = pair.primary.Close()
				_ = pair.stableNamespaceParent.Close()
			}()
			produce := func(root RecoverableRoot) (rebuiltDurableRootV1, error) {
				value, _, e := d.rebuildRecoverableRootWithPublicationLockV1(context.Background(), roots, root, pair.pager, pair.allocator, false)
				return value, e
			}
			source := roots.durable
			older, err := produce(primaryOfflineRootV6(source, source.slot^1))
			if err != nil {
				t.Fatal(err)
			}
			defer func() {
				if e := d.releaseCapturedRootResources(older.resources); e != nil {
					t.Error(e)
				}
			}()
			latest, err := produce(primaryOfflineRootV6(source, source.slot))
			if err != nil {
				t.Fatal(err)
			}
			defer func() {
				if e := d.releaseCapturedRootResources(latest.resources); e != nil {
					t.Error(e)
				}
			}()
			if older.resources == nil || latest.resources == nil {
				t.Fatal("pointer-backed rebuilt slots lost their real dependency closures")
			}
			older.meta.LastCommitHeight = source.slotRecord[source.slot^1].LastCommitHeight
			latest.meta.LastCommitHeight = source.slotRecord[source.slot].LastCommitHeight
			injected := errors.New("original final construction drain")
			calls := 0
			if mode != "success" {
				freelist.TestHookAbortCOWCandidateFailure = func() error { calls++; return injected }
			}
			selected, runtime, err := d.writeRebuiltPrimaryRootsWithProducerV5(context.Background(), pair, roots, older, latest, filepath.Join(dir, indexNewFileName), produce, nil)
			freelist.TestHookAbortCOWCandidateFailure = nil
			if selected.Record.CommitSeq != latest.meta.CommitSeq {
				t.Fatal("did not reach successful original selection", selected.Record.CommitSeq)
			}
			if mode == "success" {
				if err != nil || runtime == nil || pair.primaryConstructionAllocator != nil || pair.unpublishedPrimary != nil {
					t.Fatal("successful handoff", err)
				}
				for i, set := range selected.SlotResources {
					if set == nil || runtime.slotResources[i] != nil {
						t.Fatal("successful Set handoff")
					}
				}
				pair.unpublishedPrimary, pair.unpublishedSelection = runtime, &selected
				return
			}
			original := pair.unpublishedPrimary
			if !errors.Is(err, injected) || calls != 1 || runtime != nil || original == nil || pair.primaryConstructionAllocator == nil || original.current == nil || original.metadataCharge == 0 {
				t.Fatal("late drain orphaned original construction", calls, err)
			}
			for i, set := range selected.SlotResources {
				if set == nil || original.slotResources[i] != set || set.Owner() == rootpublication.ResourceOwnerReleased {
					t.Fatal("late error transferred/released selected Set")
				}
			}
			owner := pair.primaryOwner
			owner.mu.Lock()
			refs := owner.refs
			owner.mu.Unlock()
			if mode == "failed-close" {
				freelist.TestHookAbortCOWCandidateFailure = func() error { return injected }
			} else if mode == "runtime-release" {
				// A genuine stale original root makes runtime cleanup fail AFTER
				// successful ledger drain. No synthetic error receipt is installed.
				if consumed, e := pair.primary.Drop(original.current.ref, nil); !consumed || e != nil {
					t.Fatal(consumed, e)
				}
			}
			closeErr := pair.close()
			freelist.TestHookAbortCOWCandidateFailure = nil
			if mode == "late-drain" {
				if closeErr != nil || pair.primaryConstructionAllocator != nil || pair.unpublishedPrimary != nil || original.metadataCharge != 0 {
					t.Fatal("original Close did not join late construction", closeErr)
				}
				return
			}
			failedClose = true
			if mode == "failed-close" && !errors.Is(closeErr, injected) || mode == "runtime-release" && !errors.Is(closeErr, primaryarena.ErrStale) {
				t.Fatal("lost original cleanup cause", closeErr)
			}
			owner.mu.Lock()
			retained := owner.failedDataGenerations == pair && owner.refs == refs
			owner.mu.Unlock()
			if !retained || pair.unpublishedPrimary != original || original.metadataCharge == 0 || pair.primary != owner.arena {
				t.Fatal("failed generation/runtime owner edge lost")
			}
			if again := pair.close(); again != closeErr {
				t.Fatal("failed Close replayed or changed receipt")
			}
		})
	}
}
