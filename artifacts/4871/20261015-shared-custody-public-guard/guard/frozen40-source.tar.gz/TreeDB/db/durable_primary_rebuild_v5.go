package db

import (
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"unsafe"

	"github.com/snissn/gomap/TreeDB/freelist"
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
	"github.com/snissn/gomap/TreeDB/page"
)

type rebuiltPrimaryRootV5 struct {
	root   rebuiltDurableRootV1
	source rootpublication.DurableRootRecordV1
}

type rebuiltPrimaryOwnedRecordV5 struct {
	bundle primaryarena.PublicationBundle
	record rootpublication.DurablePrimaryRootRecordV5
	meta   page.DurableMetaV1
}

// The two eligible roots and their direct proofs have a format maximum of four.
// This backing is private construction storage, not an owning publication list.
type primaryRebuildScratchV5 struct {
	sequences        [4]uint64
	inputs           [4]rebuiltPrimaryRootV5
	built            [4]rebuiltPrimaryOwnedRecordV5
	privateResources [4]*rootpublication.StableResourceSet
	count            int
}

func (s *primaryRebuildScratchV5) index(seq uint64) int {
	for i := 0; i < s.count; i++ {
		if s.sequences[i] == seq {
			return i
		}
	}
	return -1
}
func (s *primaryRebuildScratchV5) put(seq uint64, input rebuiltPrimaryRootV5) error {
	if i := s.index(seq); i >= 0 {
		s.inputs[i] = input
		return nil
	}
	if s.count == len(s.sequences) {
		return rootpublication.ErrResourceOwnership
	}
	i := s.count
	s.count++
	s.sequences[i] = seq
	s.inputs[i] = input
	return nil
}

// writeRebuiltPrimaryRootsV5 constructs independent immutable records in the
// retained V5 companion or private V6 companion, while replacement DATA is
// unpublished. V6 copies current/one-hop proof directories into fixed capsules. The one new
// genuine DATA generation owns every rebuilt slot/proof tree. Its sequence is
// the earliest retained record's commit; later bank-only records retain that
// exact generation. No old DATA generation or bank image is relabelled.
func (db *DB) writeRebuiltPrimaryRootsV5(ctx context.Context, idx *indexGen, roots *RecoverableRootSet, older rebuiltDurableRootV1, latest rebuiltDurableRootV1, indexPath string, leafManifest **leafGenerationManifest) (selected durableRootSelectionV1, runtime *primaryDurableRuntimeV5, err error) {
	return db.writeRebuiltPrimaryRootsWithProducerV5(ctx, idx, roots, older, latest, indexPath, nil, leafManifest)
}

// produce is synchronous construction work. It is never stored in a root or
// runtime: offline value-log rewrite must rewrite proof pointers with the same
// producer as the two slots, rather than copying old value-log dependencies.
func (db *DB) writeRebuiltPrimaryRootsWithProducerV5(ctx context.Context, idx *indexGen, roots *RecoverableRootSet, older rebuiltDurableRootV1, latest rebuiltDurableRootV1, indexPath string, produce func(RecoverableRoot) (rebuiltDurableRootV1, error), leafManifest **leafGenerationManifest) (selected durableRootSelectionV1, runtime *primaryDurableRuntimeV5, err error) {
	if idx == nil || idx.primaryOwner == nil || roots == nil {
		return selected, nil, rootpublication.ErrResourceOwnership
	}
	a, p := idx.primary, idx.pager
	source := roots.durable
	scratchCharge := retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(primaryRebuildScratchV5{})))
	headerCharge := primaryRuntimeDescriptorChargeV5()
	if e := a.MetadataOwner().AddPending(scratchCharge + headerCharge); e != nil {
		return selected, nil, e
	}
	construction := &primaryDurableRuntimeV5{}
	bindReservedPrimaryRuntimeV5(construction, a)
	construction.metadataCharge += scratchCharge
	scratch := &primaryRebuildScratchV5{}
	construction.rebuildScratch, construction.rebuildScratchCharge = scratch, scratchCharge
	published := false
	defer func() {
		if !published {
			err = errors.Join(err, db.releaseOriginalPrimaryRuntimeV5(a, construction))
		}
	}()
	if e := scratch.put(older.meta.CommitSeq, rebuiltPrimaryRootV5{root: older, source: source.slotRecord[source.slot^1]}); e != nil {
		return selected, nil, e
	}
	if e := scratch.put(latest.meta.CommitSeq, rebuiltPrimaryRootV5{root: latest, source: source.slotRecord[source.slot]}); e != nil {
		return selected, nil, e
	}
	// Only the two explicitly retained one-hop proofs participate. Their own
	// parent fields are not followed or used for lookup or ownership.
	for proofSlot, proof := range source.primaryProof {
		record := proof.Record
		if record.CommitSeq == 0 {
			continue
		}
		if scratch.index(record.CommitSeq) >= 0 {
			continue
		}
		readRoot := record.UserRootPageID
		if source.primaryReadRoots[proofSlot+2] != 0 {
			readRoot = source.primaryReadRoots[proofSlot+2]
		}
		root := RecoverableRoot{CommitSeq: record.CommitSeq, UserRootPageID: readRoot, SystemRootPageID: record.SystemRootPageID, AppliedCommandLSN: record.AppliedCommandLSN, MaxEntryRevision: record.MaxEntryRevision, Durable: true}
		var rebuilt rebuiltDurableRootV1
		var e error
		if produce != nil {
			rebuilt, e = produce(root)
		} else {
			rebuilt, _, e = db.rebuildRecoverableRootWithPublicationLockV1(ctx, roots, root, p, idx.allocator, true)
		}
		if e != nil {
			return selected, nil, e
		}
		rebuilt.meta.LastCommitHeight = record.LastCommitHeight
		if e = scratch.put(record.CommitSeq, rebuiltPrimaryRootV5{root: rebuilt, source: record}); e != nil {
			return selected, nil, errors.Join(e, db.releaseCapturedRootResources(rebuilt.resources))
		}
		scratch.privateResources[scratch.index(record.CommitSeq)] = rebuilt.resources
	}
	// Proof trees can create real outer-leaf segments too. Freeze their complete
	// original producer closure only after every retained root has been built.
	if db.indexOuterLeavesInValueLog {
		persisted, e := db.prepareRebuiltPrimaryLeafManifestV5(scratch, latest.meta.CommitSeq)
		if e != nil {
			return selected, nil, e
		}
		if leafManifest != nil {
			*leafManifest = persisted
		}
	}
	// Sort the fixed inputs together without an allocated map or sort closure.
	for i := 1; i < scratch.count; i++ {
		for j := i; j > 0 && scratch.sequences[j] < scratch.sequences[j-1]; j-- {
			scratch.sequences[j], scratch.sequences[j-1] = scratch.sequences[j-1], scratch.sequences[j]
			scratch.inputs[j], scratch.inputs[j-1] = scratch.inputs[j-1], scratch.inputs[j]
		}
	}
	sequences := scratch.sequences[:scratch.count]
	if len(sequences) < 2 || len(sequences) > 4 || sequences[0] == 0 {
		return selected, nil, rootpublication.ErrResourceOwnership
	}
	// All effective trees have been materialized before this real allocator cut.
	allocator := freelist.New(p, 0)
	base, e := freelist.NewFreelistGenerationV1(1, p.PageCount(), nil, nil)
	if e != nil {
		return selected, nil, e
	}
	if e = allocator.EnableCOWV1(base, freelist.NewReservationLedger()); e != nil {
		return selected, nil, e
	}
	capability, e := freelist.NewReuseCapability(sequences[0], sequences[0], 0)
	if e != nil {
		return selected, nil, e
	}
	var cid freelist.CandidateIDV1
	binary.LittleEndian.PutUint64(cid[:8], sequences[0])
	binary.LittleEndian.PutUint64(cid[8:], idx.id)
	cow, e := allocator.PrepareCOWCandidateV1(2, sequences[0], cid, capability, 0, freelist.NewCandidatePageSinkV1())
	if e != nil {
		return selected, nil, e
	}
	generation := cow.Candidate().Generation()
	if e = p.Truncate(generation.HighWater()); e != nil {
		return selected, nil, e
	}
	if e = cow.Candidate().WritePagesToV1(durablePagerSinkV1{p}); e != nil {
		return selected, nil, e
	}
	owned := true
	for _, seq := range sequences {
		if e = ctx.Err(); e != nil {
			return selected, nil, e
		}
		input := scratch.inputs[scratch.index(seq)]
		meta := input.root.meta
		root, e := idx.zipper.BuildPrimaryRoot(meta.UserRootPageID, meta.CommitSeq)
		if e != nil {
			return selected, nil, e
		}
		bundle, ready, e := a.TakePublicationBundle(root, nil)
		if !ready || e != nil {
			return selected, nil, errors.Join(e, rootpublication.ErrResourceOwnership)
		}
		// Register both owners immediately so every subsequent failure unwinds only
		// this private construction, never a source slot or current root.
		scratch.built[scratch.index(seq)] = rebuiltPrimaryOwnedRecordV5{bundle: bundle}
		meta.UserRootPageID = root
		meta.TotalPages = generation.HighWater()
		prepared, ready, e := prepareSelectedPrimaryRoot(a, bundle, generation, nil, rootPublicationFrontierV1(meta), p, nil)
		if !ready || e != nil {
			return selected, nil, errors.Join(e, rootpublication.ErrResourceOwnership)
		}
		var manifest rootpublication.DependencyManifestRefV1
		var directory rootpublication.DependencyDirectoryRefV2
		if db.dependencyDirectoryRequiredFeature {
			alloc, e := newPrimaryDependencyAllocatorV5(idx)
			if e != nil {
				return selected, nil, e
			}
			directory, e = rebuildDependencyDirectoryWithRequirementV2(p, alloc, input.root.resources, true)
			if e == nil && directory.RootPageID == 0 {
				e = rootpublication.ErrDependencyManifestFormat
			}
			if e == nil {
				e = alloc.seal(directory.RootPageID)
			}
			// The record acquires its own edge below; keep all construction refs until
			// sealing is complete, including the empty canonical dependency tree.
			if e != nil {
				alloc.release()
				return selected, nil, e
			}
			defer func() { err = errors.Join(err, alloc.release()) }()
		} else {
			m, e := durableManifestFromResourcesV1(input.root.resources)
			if e != nil {
				return selected, nil, e
			}
			// Materialization borrows this private encoding; the resulting banks
			// own independent images, including on a later rebuild failure.
			defer m.ReleaseOwnedMetadataV1()
			var refs *primaryBankConstructionV5
			manifest, refs, e = materializePrimaryManifestV5(idx, m)
			if e != nil {
				return selected, nil, e
			}
			defer func() { err = errors.Join(err, refs.release()) }()
		}
		record := rootpublication.DurableRootRecordV1{CommitSeq: seq, DurableSeq: input.source.DurableSeq, UserRootPageID: root, SystemRootPageID: meta.SystemRootPageID, TotalPages: generation.HighWater(), AppliedCommandLSN: meta.AppliedCommandLSN, LastCommitHeight: meta.LastCommitHeight, MaxEntryRevision: meta.MaxEntryRevision, Freelist: generation.GenerationRef(), FreelistFreeCount: generation.FreeCount(), FreelistRetiredCount: generation.RetiredCount(), Manifest: manifest, Directory: directory, MetaProjectionDigest: page.DurableMetaProjectionDigestV1(seq, input.source.DurableSeq, bundle.Record.PageID)}
		// A slot binds its exact freshly rebuilt retained parent. A proof record
		// outside that slot-parent relation has no further owning/lookup ancestry.
		isSlot := seq == older.meta.CommitSeq || seq == latest.meta.CommitSeq
		if isSlot && !a.CapsuleFormatV6() && input.source.ParentRecordPageID != 0 {
			parentIndex := scratch.index(input.source.ParentCommitSeq)
			if parentIndex < 0 {
				return selected, nil, fmt.Errorf("rebuilt primary: missing retained parent %d", input.source.ParentCommitSeq)
			}
			parent := scratch.built[parentIndex]
			record.ParentRecordPageID = parent.bundle.Record.PageID
			record.ParentCommitSeq = parent.record.Record.CommitSeq
			record.ParentRecordDigest = parent.meta.RootRecordDigest
		}
		projection := prepared.Projection()
		projection.ArenaHighWater = a.Pager().PageCount()
		value := rootpublication.DurablePrimaryRootRecordV5{Record: record, Primary: projection}
		if a.CapsuleFormatV6() {
			// The rebuilt logical image remains independent of slot dependency custody.
			// Fixed images install only after all roots/dependencies sync.
			scratch.built[scratch.index(seq)] = rebuiltPrimaryOwnedRecordV5{bundle: bundle, record: value}
		} else {
			digest, e := sealPrimaryRecordV5(a, bundle.Record, value)
			if e != nil {
				return selected, nil, e
			}
			durableMeta, e := page.NewDurableMetaV1(seq, record.DurableSeq, bundle.Record.PageID, digest)
			if e != nil {
				return selected, nil, e
			}
			scratch.built[scratch.index(seq)] = rebuiltPrimaryOwnedRecordV5{bundle: bundle, record: value, meta: durableMeta}
		}
		// Proof dependencies are also genuine recovery authorities and must be
		// durable even when neither selected slot uses that exact resource frontier.
		if resources := input.root.resources; resources != nil {
			if e = resources.FlushThrough(); e != nil {
				return selected, nil, e
			}
			if _, e = syncStableResourceDependenciesV1(resources, db.dir, resources.SyncThrough, nil); e != nil {
				return selected, nil, e
			}
		}
	}
	primaryName := primaryIndexFileName
	if a.CapsuleFormatV6() {
		primaryName = primaryNewFileName
	}
	namespace, e := idx.stablePagerNamespaceToken(db.dir, primaryName, a.Pager())
	if e != nil {
		return selected, nil, e
	}
	defer func() { err = errors.Join(err, db.retainResourceCleanupError(namespace.ReleaseWithError())) }()
	if a.CapsuleFormatV6() {
		if e = p.Sync(); e != nil {
			return selected, nil, e
		}
		if e = a.Pager().Sync(); e != nil {
			return selected, nil, e
		}
		if e = namespace.Stabilize(); e != nil {
			return selected, nil, e
		}
		imageCharge := retainedalloc.AllocationCharge(rootpublication.PrimaryCapsuleSizeV6)
		descriptorCharge := primaryStateDescriptorChargeV5()
		// Both installation images overlap the selector copies. Selected copies
		// transfer to their independently retained roots only after complete install.
		pendingCharge := 4*imageCharge + descriptorCharge
		if e = a.MetadataOwner().AddPending(pendingCharge); e != nil {
			return selected, nil, e
		}
		var installImages, images [2][]byte
		defer func() {
			clear(installImages[:])
			if owned {
				clear(images[:])
			}
			a.MetadataOwner().RemovePending(pendingCharge)
		}()

		for _, slot := range []uint64{source.slot ^ 1, source.slot} {
			seq := older.meta.CommitSeq
			if slot == source.slot {
				seq = latest.meta.CommitSeq
			}
			value := scratch.built[scratch.index(seq)]
			dir, e := a.Get(value.bundle.Directory.PageID)
			if e != nil {
				return selected, nil, e
			}
			var parent *rootpublication.DurablePrimaryRootRecordV5
			var parentDir []byte
			if proof := source.primaryProof[slot]; proof.Record.CommitSeq != 0 {
				parentIndex := scratch.index(proof.Record.CommitSeq)
				if parentIndex < 0 {
					return selected, nil, rootpublication.ErrResourceOwnership
				}
				retained := &scratch.built[parentIndex]
				parent = &retained.record
				parentDir, e = a.Get(retained.bundle.Directory.PageID)
				if e != nil {
					return selected, nil, e
				}
			}
			r := value.record
			r.Record.MetaProjectionDigest = page.DurableMetaProjectionDigestV1(r.Record.CommitSeq, r.Record.DurableSeq, rootpublication.PrimaryCapsulePageV6(slot))
			if parent != nil {
				pv := *parent
				pv.Record.MetaProjectionDigest = page.DurableMetaProjectionDigestV1(pv.Record.CommitSeq, pv.Record.DurableSeq, rootpublication.PrimaryCapsulePageV6(slot))
				parent = &pv
			}
			image := make([]byte, rootpublication.PrimaryCapsuleSizeV6)
			if e = rootpublication.EncodePrimaryCapsuleV6(image, slot, r, dir, parent, parentDir); e != nil {
				return selected, nil, e
			}
			if _, ok, e := a.Pager().WritePrimaryCapsuleViewWithWork(2+slot*3, image, nil); !ok || e != nil {
				return selected, nil, errors.Join(e, rootpublication.ErrResourceOwnership)
			}
			installImages[slot] = image
		}
		selected, images, e = selectPrimaryCapsuleAuthorityV6(p, a.Pager(), p.PageCount(), a.Pager().PageCount(), a.UUID(), db.validateDurableDependencyManifestV1, db.primaryDependencyDirectoryValidatorV5(idx), a.MetadataOwner())
		runtime = construction
		runtime.projection, runtime.slots = selected.Primary, selected.SlotPrimary
		runtime.proofRecords, runtime.proofResources = selected.ParentRecords, selected.ParentResources
		runtime.capsuleImages, runtime.slotResources = images, selected.SlotResources
		runtime.metadataCharge += descriptorCharge + 2*imageCharge
		pendingCharge -= descriptorCharge + 2*imageCharge
		if e != nil {
			return selected, nil, e
		}
		for slot, image := range images {
			if len(image) == 0 {
				return selected, nil, rootpublication.ErrResourceOwnership
			}
			view, e := rootpublication.DecodePrimaryCapsuleV6(image, uint64(slot), a.UUID())
			if e != nil {
				return selected, nil, e
			}
			runtime.capsuleViews[slot] = view
			root := scratch.built[scratch.index(selected.SlotRecords[slot].CommitSeq)].bundle.Directory
			if ok, e := a.Acquire(root, nil); !ok || e != nil {
				return selected, nil, errors.Join(e, rootpublication.ErrResourceOwnership)
			}
			runtime.records[slot] = root
			runtime.closures[slot], _, e = a.AcquireCapsuleDependencyV6(primaryCapsuleDependencyEdgeV6(view.Current().Record), nil)
			if e != nil {
				return selected, nil, e
			}
			runtime.dataFloor[slot] = generation.CommitSeq()
			if parent := selected.ParentRecords[slot]; parent.Record.CommitSeq != 0 {
				proof := scratch.built[scratch.index(parent.Record.CommitSeq)].bundle.Directory
				if ok, e := a.Acquire(proof, nil); !ok || e != nil {
					return selected, nil, errors.Join(e, rootpublication.ErrResourceOwnership)
				}
				runtime.proofs[slot] = proof
				runtime.proofClosures[slot], _, e = a.AcquireCapsuleDependencyV6(primaryCapsuleDependencyEdgeV6(parent.Record), nil)
				if e != nil {
					return selected, nil, e
				}
				runtime.dataFloor[slot+2] = generation.CommitSeq()
			}
		}
		current := scratch.built[scratch.index(selected.Record.CommitSeq)].bundle.Directory
		runtime.current = &primaryStateRootV5{arena: a, ref: current, dataCommit: generation.CommitSeq()}
		scratch.built[scratch.index(selected.Record.CommitSeq)].bundle.Directory = primaryarena.Ref{} // SAME original edge transferred
		if e = bindPrimaryReadRootCertificateV6(runtime.current); e != nil {
			return selected, nil, e
		}
		for i, image := range images {
			if image != nil {
				runtime.capsuleCharges[i] = imageCharge
			}
		}
		a.AdoptPendingRootMetadata(current, primaryStateDescriptorChargeV5())
		runtime.metadataCharge -= descriptorCharge
		if e = finishPrimaryRuntimeRebuildScratchV5(runtime); e != nil {
			return selected, nil, e
		}
		runtime.slotResources = [2]*rootpublication.StableResourceSet{}
		owned, published = false, true
		return selected, runtime, nil
	}
	for _, slot := range []uint64{source.slot ^ 1, source.slot} {
		seq := older.meta.CommitSeq
		if slot == source.slot {
			seq = latest.meta.CommitSeq
		}
		value := scratch.built[scratch.index(seq)]
		if e = a.Pager().SyncIndexData(); e != nil {
			return selected, nil, e
		}
		if e = namespace.Stabilize(); e != nil {
			return selected, nil, e
		}
		_, e = executeDurableRootStorageTransactionV1(durableRootStorageTransactionV1{syncIndex: p.SyncIndexData, sink: durablePagerSinkV1{p}, target: slot, meta: value.meta, syncMeta: func() error { return p.SyncPages([]uint64{slot}) }, dir: db.dir, indexPath: indexPath})
		if e != nil {
			return selected, nil, e
		}
	}
	descriptorCharge := primaryStateDescriptorChargeV5()
	if e = a.MetadataOwner().AddPending(descriptorCharge); e != nil {
		return selected, nil, e
	}
	construction.metadataCharge += descriptorCharge
	selected, e = selectDurablePrimaryRootWithMetadataV5(p, a.Pager(), p.PageCount(), a.Pager().PageCount(), a.UUID(), db.validateDurableDependencyManifestV1, db.primaryDependencyDirectoryValidatorV5(idx), a.MetadataOwner())
	runtime = construction
	runtime.projection, runtime.slots = selected.Primary, selected.SlotPrimary
	runtime.proofRecords, runtime.proofResources = selected.ParentRecords, selected.ParentResources
	runtime.slotResources = selected.SlotResources
	if e != nil {
		return selected, nil, e
	}
	for slot, record := range selected.SlotRecords {
		if record.CommitSeq == 0 {
			return selected, nil, rootpublication.ErrResourceOwnership
		}
		value := scratch.built[scratch.index(record.CommitSeq)]
		ready, e := a.Acquire(value.bundle.Record, nil)
		if !ready || e != nil {
			return selected, nil, errors.Join(e, rootpublication.ErrResourceOwnership)
		}
		runtime.records[slot] = value.bundle.Record
		runtime.dataFloor[slot] = selected.SlotPrimary[slot].DataCommitSeq
		if parent := selected.ParentRecords[slot]; parent.Record.CommitSeq != 0 {
			proof := scratch.built[scratch.index(parent.Record.CommitSeq)].bundle.Record
			ready, e = a.Acquire(proof, nil)
			if !ready || e != nil {
				return selected, nil, errors.Join(e, rootpublication.ErrResourceOwnership)
			}
			runtime.proofs[slot] = proof
			runtime.dataFloor[slot+2] = parent.Primary.DataCommitSeq
		}
	}
	current := scratch.built[scratch.index(selected.Record.CommitSeq)].bundle.Directory
	runtime.current = &primaryStateRootV5{arena: a, ref: current, dataCommit: generation.CommitSeq()}
	scratch.built[scratch.index(selected.Record.CommitSeq)].bundle.Directory = primaryarena.Ref{} // transfer, no second drop
	// Finish the SAME original scratch once, after state custody is bound.
	// A refused root drop keeps all resource edges and the first receipt.
	a.AdoptPendingRootMetadata(current, primaryStateDescriptorChargeV5())
	runtime.metadataCharge -= descriptorCharge
	if e = finishPrimaryRuntimeRebuildScratchV5(runtime); e != nil {
		return selected, nil, e
	}
	runtime.slotResources = [2]*rootpublication.StableResourceSet{}
	owned, published = false, true
	return selected, runtime, nil
}

// prepareRebuiltPrimaryLeafManifestV5 seals one original manifest producer after
// all retained physical trees exist. Each input receives its own checked resource
// edge; the same admitted scratch retains those edges until construction ends.
func (db *DB) prepareRebuiltPrimaryLeafManifestV5(s *primaryRebuildScratchV5, commit uint64) (persisted *leafGenerationManifest, err error) {
	db.mu.RLock()
	base := db.leafGenerationManifest
	candidate, _, e := db.stagedLeafGenerationManifestWithPending(base, 0, commit)
	db.mu.RUnlock()
	if e != nil {
		return nil, e
	}
	if db.leafGenerationManifestStore == nil {
		return nil, rootpublication.ErrUnresolvedResource
	}
	if db.leafGenerationManifestStore.mode == leafGenerationManifestCompatibility {
		persisted = candidate.clone()
		err = db.persistLeafGenerationManifestAndRecordLengthIndexes(persisted, nil)
		return persisted, err
	}
	if db.leafGenerationManifestStore.mode != leafGenerationManifestStable {
		return nil, rootpublication.ErrNamespacePersistenceUnsupported
	}
	closure, persisted, e := db.prepareLeafGenerationManifestStableCandidate(candidate)
	if e != nil {
		return nil, e
	}
	defer func() { err = errors.Join(err, closure.ReleaseWithError()) }()
	manifest, e := closure.TakeStableResources()
	if e != nil {
		return nil, e
	}
	defer func() { err = errors.Join(err, db.releaseCapturedRootResources(manifest)) }()
	for i := 0; i < s.count; i++ {
		original := s.inputs[i].root.resources
		replaced, e := db.replaceDurableRootManifestResourcesV1(original, manifest)
		if e != nil {
			return nil, e
		}
		// The preborn scratch owns the successor before consuming its predecessor.
		ownedOriginal := false
		for j, old := range s.privateResources {
			if old == original {
				ownedOriginal = true
				s.privateResources[j] = nil
			}
		}
		s.privateResources[i] = replaced
		s.inputs[i].root.resources = replaced
		// Caller-owned slot inputs remain borrowed until that caller disposes
		// them. Only original proof inputs belong to this scratch.
		if ownedOriginal {
			if e = db.releaseCapturedRootResources(original); e != nil {
				return nil, e
			}
		}
	}
	return persisted, nil
}
