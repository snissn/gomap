package lifecycle

import (
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"unsafe"
)

// ReaderRegistryCompletionV6 contains accounting only. All original node/tree
// aliases have ended before transfer to the disposing parent's existing receipt.
type ReaderRegistryCompletionV6 struct {
	Metadata *retainedalloc.Owner
	Charge   uint64
}

// DetachRegistrationWithWorkV6 consumes membership exactly once, without an
// owner refund. Its original parent must own the same metadata completion.
func (r *ReaderRegistry) DetachRegistrationWithWorkV6(id int64, expected *retainedalloc.Owner, w *iterator.OrdinalScanWork) (c ReaderRegistryCompletionV6, ready bool, err error) {
	if r == nil || w == nil {
		return c, false, retainedalloc.ErrWorkRequired
	}
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(ReaderRegistry{}))+64) {
		return c, false, nil
	}
	if id < 0 {
		if !w.Reserve(1, 2*uint64(unsafe.Sizeof(readerRegistryShard{}))) {
			return c, false, nil
		}
		r.unregisterFast(id)
		return c, true, nil
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.metadata != expected {
		return c, false, retainedalloc.ErrWorkRequired
	}
	n := r.root
	depth := uint64(0)
	for n.branch != nil {
		if !w.Reserve(1, 2*uint64(unsafe.Sizeof(readerBranch{}))) {
			return c, false, nil
		}
		n = n.branch.child[readerSide(uint64(id), n.branch.bit)]
		depth++
	}
	if !w.Reserve(1, 2*uint64(unsafe.Sizeof(readerLeaf{}))) {
		return c, false, nil
	}
	if id <= 0 || n.leaf == nil || n.leaf.handle != uint64(id) {
		return c, true, nil
	}
	// Reserve every splice/scrub and ancestor-summary update before mutation.
	if !w.Reserve(2+depth, 2*uint64(unsafe.Sizeof(readerLeaf{}))+4*uint64(unsafe.Sizeof(readerBranch{}))+depth*4*uint64(unsafe.Sizeof(readerBranch{}))) {
		return c, false, nil
	}
	l := n.leaf
	c.Metadata = l.owner
	c.Charge = r.detachLeafLocked(l)
	l.owner = nil
	l = nil
	n = readerNode{}
	return c, true, nil
}

// DetachRegistrationOriginal transfers the same detached charge to an existing
// ordinary parent completion; no refund or node pointer escapes this call.
func (r *ReaderRegistry) DetachRegistrationOriginal(id int64, expected *retainedalloc.Owner) (c ReaderRegistryCompletionV6, err error) {
	if r == nil || id == 0 {
		return c, nil
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if id < 0 {
		r.unregisterFast(id)
		return c, nil
	}
	if r.metadata != expected {
		return c, retainedalloc.ErrCapacity
	}
	n := r.root
	for n.branch != nil {
		n = n.branch.child[readerSide(uint64(id), n.branch.bit)]
	}
	if n.leaf == nil || n.leaf.handle != uint64(id) {
		return c, nil
	}
	l := n.leaf
	c.Metadata = l.owner
	c.Charge = r.detachLeafLocked(l)
	l.owner = nil
	return c, nil
}
