package lifecycle

import (
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
)

// FallbackSlots now reports live slow leaves. The canonical root summary makes
// the minimum price independent of this count; Dirty is always false.
type NativeMinimumGeometryForTestV6 struct {
	FallbackSlots uint64
	Dirty         bool
	Complete      bool
}

func (r *ReaderRegistry) MaintenanceNativeMinimumGeometryForTestV6(w *iterator.OrdinalScanWork) (g NativeMinimumGeometryForTestV6, ready bool) {
	if r == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(g))+2*uint64(unsafe.Sizeof(r.root))+2*uint64(unsafe.Sizeof(r.metadata))) {
		return g, false
	}
	r.mu.Lock()
	g.FallbackSlots, g.Dirty, g.Complete = func() uint64 {
		if r.root.empty() {
			return 0
		}
		return r.root.summary().count
	}(), false, true
	r.mu.Unlock()
	return g, true
}

// NativeMinimumPriceForTestV6 admits sixteen cohorts and one exact root summary.
// The retained compatibility operand is not a historical traversal multiplier.
func NativeMinimumPriceForTestV6(fallbackSlots uint64) (records, bytes uint64, complete bool) {
	return 1 + fastReaderShardCount, fastReaderShardCount*16 + 32 + 2*uint64(unsafe.Sizeof(readerSummary{})), true
}
