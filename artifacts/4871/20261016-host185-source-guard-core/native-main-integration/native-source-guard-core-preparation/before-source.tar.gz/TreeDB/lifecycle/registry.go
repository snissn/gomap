package lifecycle

import (
	"errors"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"math"
	"math/bits"
	"sync"
	"sync/atomic"
	"unsafe"
)

const (
	fastReaderShardCount = 16
	fastReaderShardMask  = fastReaderShardCount - 1
	FastReaderShardMask  = fastReaderShardMask
	FastReaderShardCount = fastReaderShardCount
	registerHintUnset    = -1
)

type readerRegistryShard struct {
	seq   atomic.Uint64
	count atomic.Int32
	_     [52]byte
}
type readerNode struct {
	leaf   *readerLeaf
	branch *readerBranch
}
type readerSummary struct{ minimum, lo, hi, count uint64 }

// Branch allocation/lifetime is independent of the first leaf inserting it.
type readerBranch struct {
	parent  *readerBranch
	child   [2]readerNode
	summary readerSummary
	bit     uint8
}

// Leaves contain only canonical membership; their disposal runs in the
// surviving original registry header, never in the allocation being refunded.
type readerLeaf struct {
	parent           *readerBranch
	handle, sequence uint64
	owner            *retainedalloc.Owner
}

// The header is already admitted by its original generation/scope. Its fixed
// receipt owns accounting only after all disposed node aliases have ended.
func (r *ReaderRegistry) Error() string { return "reader registration accounting cleanup incomplete" }
func (r *ReaderRegistry) Is(target error) bool {
	r.failureMu.Lock()
	causes := r.refundCauses
	r.failureMu.Unlock()
	for _, cause := range causes {
		if cause != nil && errors.Is(cause, target) {
			return true
		}
	}
	return false
}
func (r *ReaderRegistry) As(target any) bool {
	r.failureMu.Lock()
	causes := r.refundCauses
	r.failureMu.Unlock()
	for _, cause := range causes {
		if cause != nil && errors.As(cause, target) {
			return true
		}
	}
	return false
}
func (r *ReaderRegistry) OriginalCleanupPriorAvailable() bool {
	r.failureMu.Lock()
	defer r.failureMu.Unlock()
	return r.refundCauses[2] == nil
}
func (r *ReaderRegistry) TryLinkPriorCleanupError(prior error) bool {
	r.failureMu.Lock()
	defer r.failureMu.Unlock()
	if prior == nil || prior == r || r.refundCauses[2] != nil {
		return false
	}
	r.refundCauses[2] = prior
	return true
}
func (r *ReaderRegistry) LinkPriorCleanupError(prior error) { r.TryLinkPriorCleanupError(prior) }
func ReaderRegistryCleanupFailed(err error) bool            { var r *ReaderRegistry; return errors.As(err, &r) }

// OriginalCleanupError joins an in-flight ordinary refund. No containing
// header completion may pass an unfinished receipt or a later detached debt.
func (r *ReaderRegistry) OriginalCleanupError() error {
	if r == nil {
		return nil
	}
	r.refundMu.Lock()
	defer r.refundMu.Unlock()
	if r.refundAmount != 0 || r.refundDeferred != 0 || r.refundFailed {
		return r
	}
	return nil
}
func (n readerNode) empty() bool { return n.leaf == nil && n.branch == nil }
func (n readerNode) summary() readerSummary {
	if n.leaf != nil {
		return readerSummary{n.leaf.sequence, n.leaf.handle, n.leaf.handle, 1}
	}
	return n.branch.summary
}
func (n readerNode) setParent(p *readerBranch) {
	if n.leaf != nil {
		n.leaf.parent = p
	} else if n.branch != nil {
		n.branch.parent = p
	}
}
func readerSide(key uint64, bit uint8) int { return int((key >> bit) & 1) }
func repairReaderBranch(b *readerBranch) {
	a, c := b.child[0].summary(), b.child[1].summary()
	m := a.minimum
	if c.minimum < m {
		m = c.minimum
	}
	b.summary = readerSummary{m, a.lo, c.hi, a.count + c.count}
}
func repairReaderAncestors(b *readerBranch) {
	for ; b != nil; b = b.parent {
		repairReaderBranch(b)
	}
}
func readerLeafCharge() uint64 {
	return retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(readerLeaf{})))
}
func readerBranchCharge() uint64 {
	return retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(readerBranch{})))
}
func ReaderRegistryHeaderCharge() uint64 {
	return retainedalloc.AllocationCharge(uint64(unsafe.Sizeof(ReaderRegistry{})))
}

type ReaderRegistry struct {
	// Never hold mu while entering Owner. This independent serialization leaves
	// minimum queries and fast unregister available to governing callbacks.
	refundMu                     sync.Mutex
	refundWork                   retainedalloc.RemovalWork
	refundAmount, refundDeferred uint64
	refundFailed                 bool
	failureMu                    sync.Mutex
	refundCauses                 [3]error
	mu                           sync.Mutex
	root                         readerNode
	metadata                     *retainedalloc.Owner
	fastShards                   [fastReaderShardCount]readerRegistryShard
	nextFastShard                atomic.Uint64
}

// NewReaderRegistry is explicitly standalone, GC-owned construction.
func NewReaderRegistry() *ReaderRegistry { return &ReaderRegistry{} }

// NewOwnedReaderRegistry admits the separate header before its actual birth.
// Its charge transfers only through the original generation terminal receipt.
func NewOwnedReaderRegistry(owner *retainedalloc.Owner) (*ReaderRegistry, error) {
	if owner == nil {
		return nil, retainedalloc.ErrCapacity
	}
	if err := owner.AddPending(ReaderRegistryHeaderCharge()); err != nil {
		return nil, err
	}
	return NewReaderRegistryWithAdmittedHeader(owner), nil
}
func (r *ReaderRegistry) Register(seq uint64) (int64, error) {
	id, _, err := r.RegisterWithHint(seq, registerHintUnset)
	return id, err
}
func (r *ReaderRegistry) hint(h int) int {
	if h < 0 {
		return int(r.nextFastShard.Add(1)-1) & fastReaderShardMask
	}
	return h & fastReaderShardMask
}
func (r *ReaderRegistry) fastLocked(seq uint64, h int) (int64, int) {
	for i := 0; i < fastReaderShardCount; i++ {
		j := (h + i) & fastReaderShardMask
		if id := r.tryJoinFast(seq, j); id != 0 {
			return id, j
		}
	}
	for i := 0; i < fastReaderShardCount; i++ {
		j := (h + i) & fastReaderShardMask
		if id := r.tryClaimFast(seq, j); id != 0 {
			return id, j
		}
	}
	return 0, registerHintUnset
}
func (r *ReaderRegistry) RegisterWithHint(seq uint64, hint int) (int64, int, error) {
	if r == nil {
		return 0, registerHintUnset, retainedalloc.ErrClosed
	}
	hint = r.hint(hint)
	if id := r.tryJoinFast(seq, hint); id != 0 {
		return id, hint, nil
	}
	r.mu.Lock()
	id, h := r.fastLocked(seq, hint)
	owner := r.metadata
	r.mu.Unlock()
	if id != 0 {
		return id, h, nil
	}
	// Governing lease callbacks run OUTSIDE registry.mu. Recheck after admission.
	charge := readerLeafCharge() + readerBranchCharge()
	if owner != nil {
		if err := owner.AddPending(charge); err != nil {
			return 0, hint, err
		}
	}
	leaf, branch := &readerLeaf{owner: owner}, &readerBranch{}
	r.mu.Lock()
	id, h = r.fastLocked(seq, hint)
	used := uint64(0)
	if id == 0 {
		key, err := r.firstHoleLocked()
		if err != nil {
			r.mu.Unlock()
			return 0, hint, r.refundUnusedNodes(&leaf, &branch, charge, err)
		}
		leaf.handle, leaf.sequence = key, seq
		if r.root.empty() {
			r.root = readerNode{leaf: leaf}
			used = readerLeafCharge()
		} else {
			r.insertLocked(leaf, branch)
			used = charge
		}
		id, h = int64(key), registerHintUnset
	}
	r.mu.Unlock()
	if used == charge {
		branch = nil
		return id, h, nil
	}
	// An unused leaf is disposed together with its speculative branch. A root
	// leaf remains charged and reachable during a branch-only completion.
	var refundErr error
	if used == 0 {
		refundErr = r.refundUnusedNodes(&leaf, &branch, charge, nil)
	} else {
		*branch = readerBranch{}
		branch = nil
		refundErr = r.refund(charge-used, nil)
	}
	if err := refundErr; err != nil {
		// A failed attempt cannot expose a registration with unsettled speculation.
		if used != 0 {
			r.mu.Lock()
			extra := r.detachLeafLocked(leaf)
			r.mu.Unlock()
			leaf.owner = nil
			leaf = nil
			// The first failed header receipt is not overwritten. This exact
			// subsequent detached charge stays in its fixed deferred scalar.
			r.refund(extra, nil)
		} else {
			r.unregisterFast(id)
		}
		return 0, hint, err
	}
	return id, h, nil
}

// refundUnusedNodes is shared by a failed first-hole search and a locked
// fast-path recheck. The caller's actual speculative aliases are cleared before
// entering the surviving header receipt; no leaf-owned completion survives.
func (r *ReaderRegistry) refundUnusedNodes(leaf **readerLeaf, branch **readerBranch, charge uint64, first error) error {
	if *leaf != nil {
		**leaf = readerLeaf{}
		*leaf = nil
	}
	if *branch != nil {
		**branch = readerBranch{}
		*branch = nil
	}
	return r.refund(charge, first)
}

// refund consumes accounting only; no disposed leaf/branch reaches this
// method. The original header survives every Owner callback and receipt access.
func (r *ReaderRegistry) refund(amount uint64, first error) error {
	if r.metadata == nil || amount == 0 {
		return first
	}
	r.refundMu.Lock()
	defer r.refundMu.Unlock()
	if r.refundFailed {
		// Each deferred delta is still pending in this SAME original owner:
		// AddPending admitted it before allocation, and no other consumer can
		// refund a detached node. Thus deferred+amount <= owner.pending <=
		// MaxUint64, even if the FAILED active delta was already debited.
		// The guard is defensive; no amount is discarded on a reachable path.
		if amount > math.MaxUint64-r.refundDeferred {
			return r
		}
		r.refundDeferred += amount
		return r
	}
	r.refundAmount = amount
	fail := func(cause error) error {
		r.refundFailed = true
		r.failureMu.Lock()
		r.refundCauses[0], r.refundCauses[1] = first, cause
		r.failureMu.Unlock()
		r.metadata.CleanupFailed()
		return r
	}
	if _, err := r.refundWork.BindPendingOriginal(r.metadata, amount); err != nil {
		return fail(err)
	}
	for {
		done, err := r.refundWork.ContinueOriginal()
		if err != nil {
			return fail(err)
		}
		if done {
			break
		}
	}
	if _, err := r.refundWork.ResetCompletedOriginal(); err != nil {
		return fail(err)
	}
	r.refundAmount = 0
	return first
}
func (r *ReaderRegistry) firstHoleLocked() (uint64, error) {
	if r.root.empty() {
		return 1, nil
	}
	n := r.root
	s := n.summary()
	if s.lo > 1 {
		return 1, nil
	}
	if s.count == s.hi-s.lo+1 {
		if s.hi == math.MaxInt64 {
			return 0, retainedalloc.ErrCapacity
		}
		return s.hi + 1, nil
	}
	for n.branch != nil {
		a, b := n.branch.child[0].summary(), n.branch.child[1].summary()
		if a.count != a.hi-a.lo+1 {
			n = n.branch.child[0]
			continue
		}
		if a.hi+1 < b.lo {
			return a.hi + 1, nil
		}
		n = n.branch.child[1]
	}
	return 0, retainedalloc.ErrCapacity
}
func (r *ReaderRegistry) insertLocked(l *readerLeaf, b *readerBranch) {
	n := r.root
	for n.branch != nil {
		n = n.branch.child[readerSide(l.handle, n.branch.bit)]
	}
	bit := uint8(bits.Len64(l.handle^n.leaf.handle) - 1)
	n = r.root
	var parent *readerBranch
	for n.branch != nil && n.branch.bit > bit {
		parent = n.branch
		n = n.branch.child[readerSide(l.handle, n.branch.bit)]
	}
	b.parent, b.bit = parent, bit
	side := readerSide(l.handle, bit)
	b.child[side] = readerNode{leaf: l}
	b.child[1-side] = n
	l.parent = b
	n.setParent(b)
	if parent == nil {
		r.root = readerNode{branch: b}
	} else {
		parent.child[readerSide(l.handle, parent.bit)] = readerNode{branch: b}
	}
	repairReaderAncestors(b)
}
func (r *ReaderRegistry) detachLeafLocked(l *readerLeaf) uint64 {
	charge := readerLeafCharge()
	p := l.parent
	if p == nil {
		r.root = readerNode{}
	} else {
		side := readerSide(l.handle, p.bit)
		sibling := p.child[1-side]
		gp := p.parent
		sibling.setParent(gp)
		if gp == nil {
			r.root = sibling
		} else {
			gp.child[readerSide(l.handle, gp.bit)] = sibling
		}
		*p = readerBranch{}
		charge += readerBranchCharge()
		repairReaderAncestors(gp)
	}
	l.parent = nil
	l.handle, l.sequence = 0, 0
	return charge
}
func (r *ReaderRegistry) RegisterFastWithHint(seq uint64, hint int) (int64, int) {
	hint = r.hint(hint)
	if id := r.tryJoinFast(seq, hint); id != 0 {
		return id, hint
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.fastLocked(seq, hint)
}
func (r *ReaderRegistry) Unregister(id int64) error {
	if r == nil || id == 0 {
		return nil
	}
	if id < 0 {
		r.unregisterFast(id)
		return nil
	}
	r.mu.Lock()
	n := r.root
	for n.branch != nil {
		n = n.branch.child[readerSide(uint64(id), n.branch.bit)]
	}
	if n.leaf == nil || n.leaf.handle != uint64(id) {
		r.mu.Unlock()
		return nil
	}
	l := n.leaf
	charge := r.detachLeafLocked(l)
	l.owner = nil
	l = nil
	n = readerNode{}
	r.mu.Unlock()
	return r.refund(charge, nil)
}
func (r *ReaderRegistry) unregisterFast(id int64) {
	shard := int(-id - 1)
	if shard < 0 || shard >= fastReaderShardCount {
		return
	}
	if c := r.fastShards[shard].count.Add(-1); c < 0 {
		r.fastShards[shard].count.Store(0)
	}
}
func (r *ReaderRegistry) minLocked() uint64 {
	m := r.loadFastMin()
	if !r.root.empty() {
		if s := r.root.summary().minimum; s < m {
			m = s
		}
	}
	return m
}
func (r *ReaderRegistry) MinPinnedSeq() uint64 {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.minLocked()
}
func (r *ReaderRegistry) MinPinnedSeqWithWorkV6(w *iterator.OrdinalScanWork) (uint64, bool, error) {
	if r == nil || w == nil {
		return 0, false, nil
	}
	records, bytes, _ := NativeMinimumPriceForTestV6(0)
	if !w.Reserve(records, bytes) {
		if records > w.RecordLimit || bytes > w.ByteLimit {
			return 0, false, &iterator.OrdinalUnitTooLarge{Records: records, Bytes: bytes}
		}
		return 0, false, nil
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.minLocked(), true, nil
}
func (r *ReaderRegistry) loadFastMin() uint64 {
	min := uint64(math.MaxUint64)
	for i := range r.fastShards {
		// Read seq before count to bias races toward a conservative (lower)
		// min rather than a potentially over-optimistic recycled seq value.
		seq := r.fastShards[i].seq.Load()
		if r.fastShards[i].count.Load() <= 0 {
			continue
		}
		if seq < min {
			min = seq
		}
	}
	return min
}

func makeFastHandle(shard int) int64 {
	return int64(-1 - shard)
}

func (r *ReaderRegistry) tryAcquireFast(seq uint64, hint int) int64 {
	if id := r.tryJoinFast(seq, hint); id != 0 {
		return id
	}
	return r.tryClaimFast(seq, hint)
}

func (r *ReaderRegistry) tryJoinFast(seq uint64, shard int) int64 {
	if r.fastShards[shard].seq.Load() != seq {
		return 0
	}

	for {
		c := r.fastShards[shard].count.Load()
		if c <= 0 || c >= math.MaxInt32 {
			return 0
		}
		if !r.fastShards[shard].count.CompareAndSwap(c, c+1) {
			continue
		}
		if r.fastShards[shard].seq.Load() == seq {
			return makeFastHandle(shard)
		}
		r.fastShards[shard].count.Add(-1)
		return 0
	}
}

func (r *ReaderRegistry) tryClaimFast(seq uint64, shard int) int64 {
	// Only the goroutine that wins this CAS is allowed to publish a new seq for
	// the shard. This prevents claim losers from overwriting an active shard seq.
	if !r.fastShards[shard].count.CompareAndSwap(0, -1) {
		return r.tryJoinFast(seq, shard)
	}

	// Publish the candidate sequence before making the counter positive so that
	// concurrent min-seq readers never observe a stale higher watermark.
	r.fastShards[shard].seq.Store(seq)
	r.fastShards[shard].count.Store(1)
	return makeFastHandle(shard)
}

// NewReaderRegistryWithAdmittedHeader is for the original generation constructor
// that has already admitted Q(indexGen)+ReaderRegistryHeaderCharge together.
// The containing terminal completion must retain and refund this exact header.
func NewReaderRegistryWithAdmittedHeader(owner *retainedalloc.Owner) *ReaderRegistry {
	return &ReaderRegistry{metadata: owner}
}
