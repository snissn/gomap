package lifecycle

import (
	"errors"
	"math"
	"testing"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
)

func guardQuantumV6() *iterator.OrdinalScanWork {
	return &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
}
func guardRegistryV6(t *testing.T) (*ReaderRegistry, *retainedalloc.Owner) {
	t.Helper()
	o := new(retainedalloc.Owner)
	o.Initialize(0)
	r, err := NewOwnedReaderRegistry(o)
	if err != nil {
		t.Fatal(err)
	}
	return r, o
}
func constructGuardV6(t *testing.T, r *ReaderRegistry, id SourceGuardIdentity, floor uint64, g *SourceGuardRef, s *SourceGuardConstruction) {
	t.Helper()
	for i := 0; i < 1024; i++ {
		ready, err := r.ConstructSourceGuard(id, floor, g, s, guardQuantumV6())
		if err != nil {
			t.Fatal(err)
		}
		if ready {
			return
		}
		if r.MinPinnedSeq() > floor {
			t.Fatal("pending minimum advanced above source")
		}
	}
	t.Fatal("guard construction did not finish")
}
func dropGuardV6(t *testing.T, r *ReaderRegistry, id SourceGuardIdentity, g *SourceGuardRef) (s *SourceGuardWithdrawal, calls int) {
	t.Helper()
	s = new(SourceGuardWithdrawal)
	for calls = 1; calls < 1024; calls++ {
		ready, err := r.WithdrawSourceGuard(g, id, s, guardQuantumV6())
		if err != nil {
			t.Fatal(err)
		}
		if ready {
			return
		}
	}
	t.Fatal("withdrawal did not finish")
	return
}
func ackGuardBirthV6(t *testing.T, r *ReaderRegistry, s *SourceGuardConstruction) {
	t.Helper()
	for i := 0; i < 64; i++ {
		_, ready, err := r.AcknowledgeSourceGuardConstruction(s, guardQuantumV6())
		if err != nil && !errors.Is(err, retainedalloc.ErrClosed) {
			t.Fatal(err)
		}
		if ready {
			return
		}
	}
	t.Fatal("birth ack did not finish")
}
func ackGuardDropV6(t *testing.T, r *ReaderRegistry, s *SourceGuardWithdrawal) {
	t.Helper()
	for i := 0; i < 64; i++ {
		_, ready, err := r.AcknowledgeSourceGuardWithdrawal(s, guardQuantumV6())
		if err != nil {
			t.Fatal(err)
		}
		if ready {
			return
		}
	}
	t.Fatal("drop ack did not finish")
}

func TestSourceGuardCanonicalHoleAndCountedAuthorityV6(t *testing.T) {
	r, o := guardRegistryV6(t)
	fast := fillReaderFastV6(t, r)
	for i := 1; i <= 6; i++ {
		h, err := r.Register(100)
		if err != nil || h != int64(i) {
			t.Fatal(h, err)
		}
	}
	if err := r.Unregister(5); err != nil {
		t.Fatal(err)
	}
	id := SourceGuardIdentity{Generation: 7, Source: 9}
	var g, child, moved SourceGuardRef
	var birth SourceGuardConstruction
	constructGuardV6(t, r, id, 0, &g, &birth)
	// Root children are adjacent {1,2,3}/{4,6}: the saved right-subtree
	// descent must discover 5, rather than reusing the root-only hole-1 rule.
	if g.leaf.handle != 5 || g.leaf.guardRefs != 1 || r.MinPinnedSeq() != 0 {
		t.Fatal("right-subtree hole/floor", g.leaf.handle)
	}
	copied := g
	if ready, err := r.RetainSourceGuard(&copied, &child, id, guardQuantumV6()); ready || !errors.Is(err, retainedalloc.ErrClosed) {
		t.Fatal("copy acquired authority", ready, err)
	}
	if err := r.Unregister(5); !errors.Is(err, retainedalloc.ErrWorkRequired) {
		t.Fatal("ordinary handle consumed guard", err)
	}
	if _, ready, err := r.DetachRegistrationWithWorkV6(5, o, guardQuantumV6()); ready || !errors.Is(err, retainedalloc.ErrWorkRequired) {
		t.Fatal("native scalar handle consumed guard", ready, err)
	}
	if ready, err := r.RetainSourceGuard(&g, &child, id, guardQuantumV6()); !ready || err != nil {
		t.Fatal(ready, err)
	}
	if ready, err := r.TransferSourceGuard(&child, &moved, id, guardQuantumV6()); !ready || err != nil || child.self != nil || g.leaf.guardRefs != 2 {
		t.Fatal("transfer changed edge count", ready, err)
	}
	ackGuardBirthV6(t, r, &birth)
	a, _ := dropGuardV6(t, r, id, &g)
	ackGuardDropV6(t, r, a)
	if moved.leaf.guardRefs != 1 || r.MinPinnedSeq() != 0 {
		t.Fatal("ancestor overlap lost")
	}
	b, _ := dropGuardV6(t, r, id, &moved)
	ackGuardDropV6(t, r, b)
	for _, h := range []int64{1, 2, 3, 4, 6} {
		if err := r.Unregister(h); err != nil {
			t.Fatal(err)
		}
	}
	for _, h := range fast {
		if err := r.Unregister(h); err != nil {
			t.Fatal(err)
		}
	}
	if !r.root.empty() || o.Bytes() != ReaderRegistryHeaderCharge() {
		t.Fatal("original canonical capacity not refunded", o.Bytes())
	}
	o.RemovePending(ReaderRegistryHeaderCharge())
}

func TestSourceGuardDepth63SavedRepairV6(t *testing.T) {
	r, o := guardRegistryV6(t)
	// Genuine original nodes with exact owner admission construct a worst-depth
	// Patricia shape without pretending that the entire 63-bit domain is full.
	insert := func(h uint64) {
		t.Helper()
		charge := readerLeafCharge()
		r.mu.Lock()
		nonempty := !r.root.empty()
		r.mu.Unlock()
		if nonempty {
			charge += readerBranchCharge()
		}
		if err := o.AddPending(charge); err != nil {
			t.Fatal(err)
		}
		l := &readerLeaf{handle: h, sequence: 1000, owner: o}
		r.mu.Lock()
		if r.root.empty() {
			r.root = readerNode{leaf: l}
		} else {
			r.insertLocked(l, &readerBranch{})
		}
		r.mu.Unlock()
	}
	insert(1)
	id := SourceGuardIdentity{Generation: 11, Source: 17}
	var g SourceGuardRef
	var birth SourceGuardConstruction
	constructGuardV6(t, r, id, 9, &g, &birth)
	ackGuardBirthV6(t, r, &birth)
	if g.leaf.handle != 2 {
		t.Fatal("wrong original handle")
	}
	for bit := uint(0); bit < 63; bit++ {
		h := uint64(2) ^ (uint64(1) << bit)
		if h != 0 {
			insert(h)
		}
	}
	depth := 0
	for p := g.leaf.parent; p != nil; p = p.parent {
		depth++
	}
	if depth != 63 {
		t.Fatal("fixture did not reach actual handle depth", depth)
	}
	before := o.Bytes()
	var drop SourceGuardWithdrawal
	yielded := false
	for i := 0; i < 128; i++ {
		ready, err := r.WithdrawSourceGuard(&g, id, &drop, guardQuantumV6())
		if err != nil {
			t.Fatal(err)
		}
		if ready {
			break
		}
		yielded = true
		if r.MinPinnedSeq() != 9 {
			t.Fatal("half-repaired minimum exposed")
		}
		if i == 127 {
			t.Fatal("saved repair starved")
		}
	}
	if !yielded || !drop.done || g.self != nil || o.Bytes() != before-readerLeafCharge()-readerBranchCharge() || r.MinPinnedSeq() != 1000 {
		t.Fatal("depth repair/refund mismatch", yielded, drop.done)
	}
	ackGuardDropV6(t, r, &drop)
	// Remove every remaining original leaf through its maintained ordinary API.
	handles := []uint64{1}
	for bit := uint(0); bit < 63; bit++ {
		h := uint64(2) ^ (uint64(1) << bit)
		if h != 0 {
			handles = append(handles, h)
		}
	}
	for _, h := range handles {
		if err := r.Unregister(int64(h)); err != nil {
			t.Fatal(err)
		}
	}
	if o.Bytes() != ReaderRegistryHeaderCharge() {
		t.Fatal("deep shape charge drift", o.Bytes())
	}
	o.RemovePending(ReaderRegistryHeaderCharge())
}

func TestSourceGuardReservedCellCancellationV6(t *testing.T) {
	r, o := guardRegistryV6(t)
	baseline := o.Bytes()
	var g SourceGuardRef
	var birth SourceGuardConstruction
	w := guardQuantumV6()
	w.Records = w.RecordLimit - 1
	if ready, err := r.ConstructSourceGuard(SourceGuardIdentity{3, 4}, 0, &g, &birth, w); ready || err != nil || g.self != &g || g.leaf != nil || birth.admitted {
		t.Fatal("wrong reserved-cell cut", ready, err)
	}
	for i := 0; i < 64; i++ {
		ready, err := r.CancelSourceGuardConstruction(&birth, guardQuantumV6())
		if err != nil {
			t.Fatal(err)
		}
		if ready {
			break
		}
	}
	if !birth.cancelled || g.self != nil || g.leaf != nil || o.Bytes() != baseline || r.structural != nil {
		t.Fatal("unbound cancellation leaked reservation")
	}
	ackGuardBirthV6(t, r, &birth)
	o.RemovePending(ReaderRegistryHeaderCharge())
}

func TestSourceGuardHelperAndOriginRefusalV6(t *testing.T) {
	r, o := guardRegistryV6(t)
	budget, err := memtable.NewCOWBudget(memtable.DefaultCOWLimits())
	if err != nil {
		t.Fatal(err)
	}
	edge, err := o.Enroll(budget)
	if err != nil {
		t.Fatal(err)
	}
	id := SourceGuardIdentity{23, 29}
	var g SourceGuardRef
	var birth SourceGuardConstruction
	constructGuardV6(t, r, id, 4, &g, &birth)
	ackGuardBirthV6(t, r, &birth)
	// A fresh original ordinary role has its own origin-bound counted edge.
	var ordinary SourceGuardRef
	if ready, err := r.RetainSourceGuardOriginal(&g, &ordinary, id); !ready || err != nil {
		t.Fatal(ready, err)
	}
	var ordinaryDrop SourceGuardWithdrawal
	if ready, err := r.WithdrawSourceGuardOriginal(&ordinary, id, &ordinaryDrop); !ready || err != nil {
		t.Fatal(ready, err)
	}
	ackGuardDropV6(t, r, &ordinaryDrop)
	var nativeDrop SourceGuardWithdrawal
	w := guardQuantumV6()
	w.Records = w.RecordLimit - 1
	if ready, err := r.WithdrawSourceGuard(&g, id, &nativeDrop, w); ready || err != nil || !g.leaf.withdrawing {
		t.Fatal("last edge not protected", ready, err)
	}
	var newRef SourceGuardRef
	if ready, err := r.RetainSourceGuard(&g, &newRef, id, guardQuantumV6()); ready || !errors.Is(err, retainedalloc.ErrClosed) {
		t.Fatal("retain raced last drop", ready, err)
	}
	// The Owner operation was not yet bound. A normal original mutation first
	// binds it on resume, then another original mutator can complete it unaided.
	w = guardQuantumV6()
	w.Records = w.RecordLimit - 2
	if ready, err := r.WithdrawSourceGuard(&g, id, &nativeDrop, w); ready || err != nil {
		t.Fatal(ready, err)
	}
	if err := o.Add(0); err != nil {
		t.Fatal("ordinary helper", err)
	}
	for i := 0; i < 64; i++ {
		ready, err := r.WithdrawSourceGuard(&g, id, &nativeDrop, guardQuantumV6())
		if err != nil {
			t.Fatal(err)
		}
		if ready {
			break
		}
	}
	if !nativeDrop.done || g.self != nil || nativeDrop.removal.HelperRecords == 0 {
		t.Fatal("same original participant not helped")
	}
	ackGuardDropV6(t, r, &nativeDrop)
	edge.Close()
	o.RemovePending(ReaderRegistryHeaderCharge())
	budget.Close()
	if stats := budget.Stats(); stats.ExternalBytes != 0 || stats.ExternalLeases != 0 {
		t.Fatal("governor leaked", stats)
	}
}

func TestSourceGuardFullSearchFailureSharedCleanupV6(t *testing.T) {
	r, o := guardRegistryV6(t)
	baseline := o.Bytes()
	charge := readerLeafCharge() + readerBranchCharge()
	var g SourceGuardRef
	id := SourceGuardIdentity{31, 37}
	g = SourceGuardRef{self: &g, registry: r, identity: id, native: true}
	s := SourceGuardConstruction{registry: r, ref: &g, identity: id, admitted: true}
	s.self = &s
	r.guardContinuations++
	for i := 0; i < 64; i++ {
		ready, err := o.StepPendingMutation(charge, true, true, &s.admission, guardQuantumV6())
		if err != nil {
			t.Fatal(err)
		}
		if ready {
			break
		}
	}
	// Full 2^63-1 physical membership cannot be a bounded fixture. Exercise its
	// exact pre-splice failure/alias scrub with genuinely admitted speculative
	// nodes, then the same constructor cancellation/refund branch.
	s.mutation = guardMutation{registry: r, ref: &g, leaf: &readerLeaf{owner: o}, branch: &readerBranch{}, kind: 1}
	r.structural = &s.mutation
	r.mu.Lock()
	ready, cause := r.failStructuralLocked(&s.mutation, retainedalloc.ErrCapacity)
	r.mu.Unlock()
	if !ready || !errors.Is(cause, retainedalloc.ErrCapacity) {
		t.Fatal(ready, cause)
	}
	// The same original constructor owns admission and the shared failure refund.
	for i := 0; i < 64; i++ {
		ready, err := r.CancelSourceGuardConstruction(&s, guardQuantumV6())
		if err != nil {
			t.Fatal(err)
		}
		if ready {
			break
		}
	}
	if !s.cancelled || s.unusedAmount != 0 || g.self != nil || o.Bytes() != baseline || r.structural != nil {
		t.Fatal("failed search left original reservation/refund")
	}
	ackGuardBirthV6(t, r, &s)
	o.RemovePending(ReaderRegistryHeaderCharge())
}

func TestSourceGuardStructuralTrafficOverflowV6(t *testing.T) {
	r, o := guardRegistryV6(t)
	m := guardMutation{registry: r, kind: 1, NativeRecords: math.MaxUint64}
	r.mu.Lock()
	ready, err := r.advanceStructuralLocked(&m, guardQuantumV6(), false)
	r.mu.Unlock()
	if ready || !errors.Is(err, retainedalloc.ErrCapacity) || !m.accountingFailure {
		t.Fatal("overflow became yield", ready, err)
	}
	o.RemovePending(ReaderRegistryHeaderCharge())
}

func TestSourceGuardLaterLeaseOnlyRefusalKeepsOriginalDebtV6(t *testing.T) {
	r, o := guardRegistryV6(t)
	id := SourceGuardIdentity{41, 43}
	var g SourceGuardRef
	var birth SourceGuardConstruction
	constructGuardV6(t, r, id, 5, &g, &birth)
	ackGuardBirthV6(t, r, &birth)
	// Later ordinary enrollment remains supported; it cannot change the origin
	// of the already native counted edge or authorize an unmetered last drop.
	b := &registryBudgetV6{cap: math.MaxUint64}
	e, err := o.Enroll(b)
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	baseline := o.Bytes()
	leaf := g.leaf
	var drop SourceGuardWithdrawal
	var first error
	for i := 0; i < 64; i++ {
		ready, cause := r.WithdrawSourceGuard(&g, id, &drop, guardQuantumV6())
		if ready {
			t.Fatal("unsupported native withdrawal completed")
		}
		if cause != nil {
			first = cause
			break
		}
	}
	if !errors.Is(first, retainedalloc.ErrWorkRequired) || drop.detached || g.leaf != leaf || !leaf.withdrawing || leaf.guardRefs != 1 || o.Bytes() != baseline || b.bytes != baseline || r.MinPinnedSeq() != 5 {
		t.Fatal("native refusal lost actual guard/debt", first)
	}
	if ready, cause := r.WithdrawSourceGuard(&g, id, &drop, guardQuantumV6()); ready || cause != first {
		t.Fatal("native first refusal changed", ready, cause)
	}
	if ready, cause := r.WithdrawSourceGuardOriginal(&g, id, &drop); ready || cause == nil {
		t.Fatal("ordinary call changed bound native origin", ready, cause)
	}
	var other SourceGuardWithdrawal
	if ready, cause := r.WithdrawSourceGuardOriginal(&g, id, &other); ready || cause == nil || other.self != nil {
		t.Fatal("new receipt stole frozen native edge", ready, cause)
	}
	if _, ready, cause := r.AcknowledgeSourceGuardWithdrawal(&drop, guardQuantumV6()); ready || cause == nil || r.OriginalCleanupError() == nil {
		t.Fatal("unsettled debt was acknowledged", ready, cause)
	}
	// This control intentionally retains unsupported ORIGINAL debt. It neither
	// closes its header nor converts the edge to ordinary disposal for cleanup.
}

func TestSourceGuardOrdinaryLeaseOnlyPolicyV6(t *testing.T) {
	r, o, b, e := ownedReaderV6(t)
	fast := fillReaderFastV6(t, r)
	id := SourceGuardIdentity{47, 53}
	var g SourceGuardRef
	var birth SourceGuardConstruction
	called := false
	b.callback = func() {
		called = true
		_ = r.MinPinnedSeq() // original budget callback must not hold registry.mu
		if err := r.Unregister(fast[0]); err != nil {
			t.Fatal(err)
		}
	}
	if ready, err := r.ConstructSourceGuardOriginal(id, 0, &g, &birth); !ready || err != nil || !called || g.native {
		t.Fatal("ordinary Lease-only birth", ready, err, called)
	}
	ackGuardBirthV6(t, r, &birth)
	var nativeDrop SourceGuardWithdrawal
	if ready, err := r.WithdrawSourceGuard(&g, id, &nativeDrop, guardQuantumV6()); ready || err == nil || nativeDrop.self != nil {
		t.Fatal("native call relabeled ordinary edge", ready, err)
	}
	var drop SourceGuardWithdrawal
	if ready, err := r.WithdrawSourceGuardOriginal(&g, id, &drop); !ready || err != nil {
		t.Fatal(ready, err)
	}
	ackGuardDropV6(t, r, &drop)
	for _, h := range fast[1:] {
		if err := r.Unregister(h); err != nil {
			t.Fatal(err)
		}
	}
	if !r.root.empty() || r.OriginalCleanupError() != nil {
		t.Fatal("ordinary guard did not settle")
	}
	e.Close()
	o.RemovePending(ReaderRegistryHeaderCharge())
	if o.Bytes() != 0 || b.bytes != 0 {
		t.Fatal("ordinary original charges leaked", o.Bytes(), b.bytes)
	}
}

func TestSourceGuardWithdrawalUsesProtectedActualSpliceChargeV6(t *testing.T) {
	r, o := guardRegistryV6(t)
	id := SourceGuardIdentity{59, 61}
	var g SourceGuardRef
	var birth SourceGuardConstruction
	constructGuardV6(t, r, id, 4, &g, &birth)
	ackGuardBirthV6(t, r, &birth)
	if g.leaf.parent != nil {
		t.Fatal("fixture not initially leaf-only")
	}
	fast := fillReaderFastV6(t, r)
	var drop SourceGuardWithdrawal
	w := guardQuantumV6()
	w.Records = w.RecordLimit - 1
	if ready, err := r.WithdrawSourceGuard(&g, id, &drop, w); ready || err != nil || !g.leaf.withdrawing {
		t.Fatal(ready, err)
	}
	// Genuine ordinary mutation between last-ref freeze and owner preflight
	// changes the actual detached topology from leaf to leaf+branch.
	h, err := r.Register(2000)
	if err != nil || h <= 0 || g.leaf.parent == nil {
		t.Fatal(h, err)
	}
	before := o.Bytes()
	for i := 0; i < 128; i++ {
		ready, err := r.WithdrawSourceGuard(&g, id, &drop, guardQuantumV6())
		if err != nil {
			t.Fatal(err)
		}
		if ready {
			break
		}
	}
	if !drop.done || o.Bytes() != before-readerLeafCharge()-readerBranchCharge() || g.self != nil {
		t.Fatal("stale leaf-only prediction used", drop.done, o.Bytes())
	}
	ackGuardDropV6(t, r, &drop)
	if err := r.Unregister(h); err != nil {
		t.Fatal(err)
	}
	for _, h := range fast {
		if err := r.Unregister(h); err != nil {
			t.Fatal(err)
		}
	}
	o.RemovePending(ReaderRegistryHeaderCharge())
}

func TestSourceGuardCancellationAcknowledgmentAndReuseV6(t *testing.T) {
	r, o := guardRegistryV6(t)
	var g SourceGuardRef
	var birth SourceGuardConstruction
	for cycle := 0; cycle < 3; cycle++ {
		id := SourceGuardIdentity{67, uint64(cycle + 1)}
		constructGuardV6(t, r, id, uint64(cycle), &g, &birth)
		if r.OriginalCleanupError() == nil || r.guardContinuations != 1 || r.guardLeaves != 1 {
			t.Fatal("original containing lifetime not held")
		}
		if ready, err := birth.ResetAcknowledged(guardQuantumV6()); ready || err == nil {
			t.Fatal("unacknowledged constructor reset", ready, err)
		}
		for i := 0; i < 128; i++ {
			ready, err := r.CancelSourceGuardConstruction(&birth, guardQuantumV6())
			if err != nil {
				t.Fatal(err)
			}
			if ready {
				break
			}
		}
		if !birth.cancelled || !birth.withdrawal.done || g.self != nil || r.guardLeaves != 0 || r.guardContinuations != 2 || o.Bytes() != ReaderRegistryHeaderCharge() {
			t.Fatal("nested cancellation lost acknowledgment obligation", r.guardContinuations)
		}
		ackGuardBirthV6(t, r, &birth)
		if r.OriginalCleanupError() != nil || r.guardContinuations != 0 || birth.withdrawal.registry != nil || birth.withdrawal.owner != nil {
			t.Fatal("child alias survived parent acknowledgment")
		}
		w := guardQuantumV6()
		w.RecordLimit = 0
		if ready, err := birth.ResetAcknowledged(w); ready || err != nil || birth.self != &birth {
			t.Fatal("unadmitted reset changed cell", ready, err)
		}
		if ready, err := birth.ResetAcknowledged(guardQuantumV6()); !ready || err != nil || birth.self != nil || birth.withdrawal.self != nil {
			t.Fatal("same mutex-containing parent not reusable", ready, err)
		}
	}
	o.RemovePending(ReaderRegistryHeaderCharge())
}

func TestSourceGuardEntryAdmissionAndResetRowsV6(t *testing.T) {
	r, o := guardRegistryV6(t)
	p := SourceGuardPriceForTestV6()
	for _, dimension := range []string{"records", "bytes"} {
		t.Run(dimension, func(t *testing.T) {
			var g SourceGuardRef
			var birth SourceGuardConstruction
			w := guardQuantumV6()
			if dimension == "records" {
				w.RecordLimit = p.ConstructEntry.Records - 1
			} else {
				w.ByteLimit = p.ConstructEntry.Bytes - 1
			}
			before := o.Bytes()
			if ready, err := r.ConstructSourceGuard(SourceGuardIdentity{71, 73}, 0, &g, &birth, w); ready || err != nil || birth.self != nil || g.self != nil || r.guardContinuations != 0 || o.Bytes() != before {
				t.Fatal("entry refusal changed original cells", ready, err)
			}
		})
	}
	if p.Structural.Records+p.Splice.Records+1+1 > 32 || p.HeaderCharge != ReaderRegistryHeaderCharge() {
		t.Fatal("local structural progress price invalid")
	}
	o.RemovePending(ReaderRegistryHeaderCharge())
}

func TestSourceGuardRenewalAndOrdinaryChurnV6(t *testing.T) {
	for _, tc := range []struct {
		name  string
		floor uint64
	}{{"increasing", 17}, {"equal", 9}, {"lower", 3}, {"zero", 0}} {
		t.Run(tc.name, func(t *testing.T) {
			r, o := guardRegistryV6(t)
			fast := fillReaderFastV6(t, r)
			oldID, nextID := SourceGuardIdentity{83, 89}, SourceGuardIdentity{83, 97}
			var old, next SourceGuardRef
			var oldBirth, nextBirth SourceGuardConstruction
			constructGuardV6(t, r, oldID, 9, &old, &oldBirth)
			ackGuardBirthV6(t, r, &oldBirth)
			churn := func() {
				h, err := r.Register(10000)
				if err != nil || h <= 0 {
					t.Fatal("ordinary structural producer", h, err)
				}
				if err := r.Unregister(h); err != nil {
					t.Fatal(err)
				}
			}
			// Force a real admission boundary while preserving total Q32 capability.
			w := guardQuantumV6()
			w.Records = 31
			if ready, err := r.ConstructSourceGuard(nextID, tc.floor, &next, &nextBirth, w); ready || err != nil {
				t.Fatal(ready, err)
			}
			churn()
			for i := 0; i < 128; i++ {
				ready, err := r.ConstructSourceGuard(nextID, tc.floor, &next, &nextBirth, guardQuantumV6())
				if err != nil {
					t.Fatal(err)
				}
				if r.MinPinnedSeq() > 9 {
					t.Fatal("held ancestor lost during renewal")
				}
				if ready {
					break
				}
				churn() // real insertion/removal after EVERY native yield
			}
			if !nextBirth.installed || r.MinPinnedSeq() != min(uint64(9), tc.floor) {
				t.Fatal("renewal did not finish/exact minimum")
			}
			ackGuardBirthV6(t, r, &nextBirth)
			oldHandle := old.leaf.handle
			saved := old // deliberately uncounted copy must never become authority
			drop, _ := dropGuardV6(t, r, oldID, &old)
			ackGuardDropV6(t, r, drop)
			if r.MinPinnedSeq() != tc.floor {
				t.Fatal("obsolete ancestor kept minimum")
			}
			var replacement SourceGuardRef
			var replacementBirth SourceGuardConstruction
			constructGuardV6(t, r, SourceGuardIdentity{83, 101}, tc.floor, &replacement, &replacementBirth)
			if replacement.leaf.handle != oldHandle {
				t.Fatal("original positive hole not reused")
			}
			var stolen SourceGuardRef
			if ready, err := r.RetainSourceGuard(&saved, &stolen, oldID, guardQuantumV6()); ready || !errors.Is(err, retainedalloc.ErrClosed) {
				t.Fatal("stale copied handle gained authority", ready, err)
			}
			saved = SourceGuardRef{}
			ackGuardBirthV6(t, r, &replacementBirth)
			for _, item := range []struct {
				ref *SourceGuardRef
				id  SourceGuardIdentity
			}{{&next, nextID}, {&replacement, SourceGuardIdentity{83, 101}}} {
				d, _ := dropGuardV6(t, r, item.id, item.ref)
				ackGuardDropV6(t, r, d)
			}
			for _, h := range fast {
				if err := r.Unregister(h); err != nil {
					t.Fatal(err)
				}
			}
			if r.OriginalCleanupError() != nil || o.Bytes() != ReaderRegistryHeaderCharge() {
				t.Fatal("renewal/churn debt")
			}
			o.RemovePending(ReaderRegistryHeaderCharge())
		})
	}
}
