package db

import (
	"errors"
	"math"
	"os"
	"path/filepath"
	"sync"
	"testing"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/lockfile"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/lifecycle"
)

// Ordinary lease failures exercise the real registry refund path, rather than
// altering a registry receipt or declaring a synthetic generation complete.
type registryHeaderFailureBudgetV6 struct {
	mu            sync.Mutex
	failShrink    bool
	target        func(old, next uint64) bool
	beforeFailure func()
	failures      uint64
}

func (b *registryHeaderFailureBudgetV6) arm(target func(old, next uint64) bool, beforeFailure func()) {
	b.mu.Lock()
	b.failShrink, b.target, b.beforeFailure = true, target, beforeFailure
	b.mu.Unlock()
}
func (b *registryHeaderFailureBudgetV6) disarm() {
	b.mu.Lock()
	b.failShrink = false
	b.mu.Unlock()
}
func (b *registryHeaderFailureBudgetV6) failureCount() uint64 {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.failures
}

// This original scalar query takes only registry.mu, never the governing Owner
// or its refund receipt. Registry disposal releases registry.mu before Resize.
func registryHeaderSlowCountV6(r *lifecycle.ReaderRegistry) (uint64, bool) {
	w := iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
	g, ready := r.MaintenanceNativeMinimumGeometryForTestV6(&w)
	return g.FallbackSlots, ready && g.Complete && !g.Dirty
}

type registryHeaderFailureLeaseV6 struct {
	budget *registryHeaderFailureBudgetV6
	bytes  uint64
}

func (b *registryHeaderFailureBudgetV6) AcquireRetention(n uint64) (retainedalloc.Lease, error) {
	return &registryHeaderFailureLeaseV6{b, n}, nil
}
func (l *registryHeaderFailureLeaseV6) Resize(n uint64) error {
	b := l.budget
	b.mu.Lock()
	if n < l.bytes && b.failShrink && (b.target == nil || b.target(l.bytes, n)) {
		// Consume only this selected real failure. The original header receipt
		// remains failed; unrelated refunds on the same Owner may now succeed.
		b.failShrink = false
		b.failures++
		beforeFailure := b.beforeFailure
		b.mu.Unlock()
		if beforeFailure != nil {
			beforeFailure()
		}
		return retainedalloc.ErrCapacity
	}
	l.bytes = n
	b.mu.Unlock()
	return nil
}
func (l *registryHeaderFailureLeaseV6) Close() {}
func fillGenerationRegistryFastV6(t *testing.T, r *lifecycle.ReaderRegistry) {
	t.Helper()
	for i := 0; i < lifecycle.FastReaderShardCount; i++ {
		id, err := r.Register(1000 + uint64(i))
		if err != nil || id >= 0 {
			t.Fatal(id, err)
		}
	}
}
func bindRegistryHeaderFailureV6(t *testing.T, metadata *retainedalloc.Owner) *registryHeaderFailureBudgetV6 {
	t.Helper()
	b := new(registryHeaderFailureBudgetV6)
	if _, err := metadata.Enroll(b); err != nil {
		t.Fatal(err)
	}
	return b
}

func TestReaderRegistryFailedBirthRetainsGenerationV6(t *testing.T) {
	d, err := Open(Options{Dir: t.TempDir(), DisableBackgroundPrune: true})
	if err != nil {
		t.Fatal(err)
	}
	g := d.idx.Load()
	r, charge := g.registry, g.metadataCharge
	fillGenerationRegistryFastV6(t, r)
	budget := bindRegistryHeaderFailureV6(t, g.metadata)
	// Register installs its sole slow leaf before returning the unused branch
	// through the original header. No Manager/root setup has happened yet.
	budget.arm(func(old, next uint64) bool {
		count, ready := registryHeaderSlowCountV6(r)
		return ready && count == 1
	}, nil)
	beforeBorrow := g.wrapperBorrowCountV6()
	snapshot, err := d.AcquireSnapshot()
	if snapshot != nil {
		t.Fatal("failed birth fabricated Snapshot", snapshot)
	}
	if !lifecycle.ReaderRegistryCleanupFailed(err) || err != r {
		t.Fatal("failed birth lost SAME registry header", err)
	}
	if !errors.Is(err, retainedalloc.ErrCapacity) {
		t.Fatal("failed birth lost original capacity cause", err)
	}
	if after := g.wrapperBorrowCountV6(); after != beforeBorrow {
		t.Fatal("failed birth changed original wrapper baseline", beforeBorrow, after)
	}
	if budget.failureCount() != 1 {
		t.Fatal("registry refund fault did not occur exactly once")
	}
	original := r.OriginalCleanupError()
	if original == nil {
		t.Fatal("missing original header receipt")
	}
	if err = d.Close(); !errors.Is(err, retainedalloc.ErrCapacity) {
		t.Fatal("real Close erased failed birth", err)
	}
	if g.registry != r || g.metadataCharge != charge || g.metadata == nil || g.physicalCompleted || !g.closeCompleted || g.closeFailure.payload != g {
		t.Fatal("failed birth header or physical custody was refunded")
	}
	before := g.metadata.Bytes()
	metadata, n, again := g.detachGenerationMetadataCompletionV6()
	if metadata != nil || n != 0 || again == nil || !errors.Is(again, retainedalloc.ErrCapacity) || g.metadata.Bytes() != before || r.OriginalCleanupError() != original {
		t.Fatal("containing completion bypassed original registry debt", metadata, n, again)
	}
	if err = d.Close(); !errors.Is(err, retainedalloc.ErrCapacity) || g.metadata.Bytes() != before {
		t.Fatal("repeated Close replayed failed completion", err)
	}
}

func TestReaderRegistryLateWrapperFailureRetainsHeaderV6(t *testing.T) {
	d, err := Open(Options{Dir: t.TempDir(), DisableBackgroundPrune: true})
	if err != nil {
		t.Fatal(err)
	}
	g := d.idx.Load()
	r, charge := g.registry, g.metadataCharge
	fillGenerationRegistryFastV6(t, r)
	budget := bindRegistryHeaderFailureV6(t, g.metadata)
	s, err := d.AcquireSnapshot()
	if err != nil || s.registryID <= 0 {
		t.Fatal("actual positive Snapshot registration", s, err)
	}
	if err = d.Close(); err != nil {
		t.Fatal(err)
	}
	if !g.physicalCompleted || g.registry != r || g.metadataCharge != charge {
		t.Fatal("held Snapshot lost original header before late failure")
	}
	budget.arm(nil, nil)
	if err = s.Close(); !errors.Is(err, retainedalloc.ErrCapacity) {
		t.Fatal("late unregister failure lost", err)
	}
	if budget.failureCount() != 1 {
		t.Fatal("late registry fault did not occur exactly once")
	}
	if g.registry != r || g.metadataCharge != charge || g.metadata == nil || g.wrapperBorrowCountV6() != 1 || g.failedSnapshots != s || g.closeFailure.payload != g {
		t.Fatal("late wrapper failure lost original payload/charge")
	}
	before := g.metadata.Bytes()
	if err = s.Close(); err != nil || g.metadata.Bytes() != before || !errors.Is(r.OriginalCleanupError(), retainedalloc.ErrCapacity) {
		t.Fatal("failed wrapper replayed cleanup", err)
	}
	metadata, n, e := g.detachGenerationMetadataCompletionV6()
	if metadata != nil || n != 0 || !errors.Is(e, retainedalloc.ErrCapacity) || g.metadata.Bytes() != before {
		t.Fatal("late debt passed terminal gate", metadata, n, e)
	}
}

func TestOfflineReaderRegistryFailureRetainsOriginalScopeV6(t *testing.T) {
	dir := t.TempDir()
	preparePrimaryJointCrashV6(t, dir)
	d, err := Open(Options{Dir: dir, ResolvedProfile: ProfileNoWALFast, Durability: DurabilityWALOffRelaxed, DisableBackgroundPrune: true})
	if err != nil {
		t.Fatal(err)
	}
	defer d.Close()
	if primaryOfflineScopePlatformRefusal(t, d) {
		return
	}
	scope, err := d.captureOfflinePrimaryScopeV6()
	if err != nil {
		t.Fatal(err)
	}
	r, parent, owner := scope.registry, scope.stableNamespaceParent, scope.offlineScopePhysicalOwner
	metadata := scope.stableNamespaceMetadata
	control := scope.offlineScopeControlCharge
	fileCharge := scope.stableNamespaceParentCharge - control
	fillGenerationRegistryFastV6(t, r)
	budget := bindRegistryHeaderFailureV6(t, metadata)
	id, err := r.Register(math.MaxUint64)
	if err != nil || id <= 0 {
		t.Fatal(id, err)
	}
	budget.arm(nil, nil)
	if err = r.Unregister(id); !errors.Is(err, retainedalloc.ErrCapacity) {
		t.Fatal(err)
	}
	if budget.failureCount() != 1 {
		t.Fatal("offline registry fault did not occur exactly once")
	}
	original := r.OriginalCleanupError()
	before := metadata.Bytes()
	// Unrelated namespace-file accounting may complete successfully even though
	// the SAME original registry receipt is permanently failed.
	budget.disarm()
	actual, n, e := scope.releaseOfflineNamespaceScopeV6()
	if actual != metadata || n != fileCharge || !errors.Is(e, retainedalloc.ErrCapacity) || scope.registry != r || scope.offlineScopeControlCharge != control || scope.physicalCompleted || !scope.offlineScopeRetained {
		t.Fatal("failed scope passed physical/header gate", actual, n, e)
	}
	owner.mu.Lock()
	retained := owner.failedDataGenerations == scope && scope.failedNext == nil
	owner.mu.Unlock()
	if !retained {
		t.Fatal("original PRIMARY owner lost exact scope edge")
	}
	if _, err = parent.Stat(); !errors.Is(err, os.ErrClosed) {
		t.Fatal("successfully completed parent file retained", err)
	}
	actual.RemovePending(n)
	if metadata.Bytes() != before-fileCharge {
		t.Fatal("file-only completion refunded containing controls")
	}
	actual, n, e = scope.releaseOfflineNamespaceScopeV6()
	if actual != nil || n != 0 || !errors.Is(e, retainedalloc.ErrCapacity) || metadata.Bytes() != before-fileCharge || r.OriginalCleanupError() != original {
		t.Fatal("scope replay changed original debt", actual, n, e)
	}
	owner.mu.Lock()
	duplicate := scope.failedNext == scope
	owner.mu.Unlock()
	if duplicate {
		t.Fatal("duplicate original retained edge")
	}
}

// Open has not returned a Snapshot/index borrow when registration fails. Its
// SAME startup generation, custody and LOCK must survive the terminal gate.
func TestReaderRegistryStartupFailureRetainsOriginalHeaderV6(t *testing.T) {
	dir := t.TempDir()
	operation := errors.New("original startup registration refusal")
	var g *indexGen
	prior := testDBOpenHook
	testDBOpenHook = func(d *DB) error {
		g = d.idx.Load()
		fillGenerationRegistryFastV6(t, g.registry)
		b := bindRegistryHeaderFailureV6(t, g.metadata)
		b.arm(func(old, next uint64) bool {
			count, ready := registryHeaderSlowCountV6(g.registry)
			return ready && count == 1
		}, nil)
		s, err := d.AcquireSnapshot()
		if s != nil || !lifecycle.ReaderRegistryCleanupFailed(err) || err != g.registry || !errors.Is(err, retainedalloc.ErrCapacity) || b.failureCount() != 1 {
			t.Error("startup did not hit one actual registry cleanup failure", s, err)
		}
		return errors.Join(operation, err)
	}
	defer func() { testDBOpenHook = prior }()
	d, err := Open(Options{Dir: dir, DisableBackgroundPrune: true})
	var receipt *OpenRecoveryCleanupError
	if d != nil || !errors.Is(err, operation) || !errors.Is(err, retainedalloc.ErrCapacity) || !errors.As(err, &receipt) || g == nil || receipt.generation != g || g.startupDB == nil || g.startupCustody == nil || g.startupLock == nil || g.metadataCharge == 0 || g.registry == nil || g.physicalCompleted {
		t.Fatal("startup lost original containing custody", d, err)
	}
	other, e := lockfile.Acquire(filepath.Join(dir, "LOCK"))
	if other != nil {
		_ = other.Close()
	}
	if !errors.Is(e, lockfile.ErrLocked) {
		t.Fatal("startup header failure released original LOCK", e)
	}
	before := g.metadata.Bytes()
	metadata, n, e := g.detachGenerationMetadataCompletionV6()
	if metadata != nil || n != 0 || !errors.Is(e, retainedalloc.ErrCapacity) || g.metadata.Bytes() != before {
		t.Fatal("startup gate refunded header", metadata, n, e)
	}
	// Process-shutdown model follows existing fatal-startup controls: releasing
	// the OS LOCK does not retry/refund any original failed accounting or file.
	if e := g.startupLock.Close(); e != nil {
		t.Error(e)
	}
}

// These are real original Close/positive-Unregister operations. Both valid
// schedules are covered: a pre-terminal refusal blocks the physical result;
// a refusal after successful physical Close retains the Snapshot's own edge.
func TestReaderRegistryCloseRacesFailedUnregisterV6(t *testing.T) {
	for i := 0; i < 16; i++ {
		d, err := Open(Options{Dir: t.TempDir(), DisableBackgroundPrune: true})
		if err != nil {
			t.Fatal(err)
		}
		g := d.idx.Load()
		r, charge := g.registry, g.metadataCharge
		fillGenerationRegistryFastV6(t, r)
		b := bindRegistryHeaderFailureV6(t, g.metadata)
		if count, ready := registryHeaderSlowCountV6(r); !ready || count != 0 {
			t.Fatal("expected original empty slow tree", count, ready)
		}
		before := g.metadata.Bytes()
		s, err := d.AcquireSnapshot()
		if err != nil || s.registryID <= 0 {
			t.Fatal(s, err)
		}
		originalID := s.registryID
		after := g.metadata.Bytes()
		if after <= before {
			t.Fatal("missing admitted positive registration contribution", before, after)
		}
		contribution := after - before
		if count, ready := registryHeaderSlowCountV6(r); !ready || count != 1 {
			t.Fatal("expected one original slow leaf", count, ready)
		}
		targetEntered, releaseTarget := make(chan struct{}), make(chan struct{})
		closeEntered, closeDone, snapshotDone := make(chan struct{}), make(chan struct{}), make(chan struct{})
		d.RegisterCloseHook(func() error { close(closeEntered); return nil })
		b.arm(func(old, next uint64) bool {
			// Only Snapshot.Close writes registryID here; this callback runs inline
			// on that same goroutine. Atomic finalized/closed and registry.mu protect
			// the other observations. No Owner/refundMu callback reentry occurs.
			count, ready := registryHeaderSlowCountV6(r)
			return old-next == contribution && s.closed.Load() && s.finalized.Load() && s.registryID == originalID && ready && count == 0
		}, func() { close(targetEntered); <-releaseTarget })
		var wg sync.WaitGroup
		var closeErr, snapshotErr error
		wg.Add(1)
		go func() { defer wg.Done(); defer close(snapshotDone); snapshotErr = s.Close() }()
		select {
		case <-targetEntered:
		case <-snapshotDone:
			_ = d.Close()
			t.Fatal("original unregister never reached the exact selected shrink", snapshotErr, contribution)
		}
		// Hold the SAME real governing Resize until the actual public DB.Close
		// has entered. This covers a concurrent physical result without allowing
		// tracker cleanup to steal an undifferentiated first-shrink fault.
		wg.Add(1)
		go func() { defer wg.Done(); defer close(closeDone); closeErr = d.Close() }()
		select {
		case <-closeEntered:
		case <-closeDone:
			close(releaseTarget)
			wg.Wait()
			t.Fatal("public Close skipped its original entry hook", closeErr)
		}
		close(releaseTarget)
		wg.Wait()
		if b.failureCount() != 1 {
			t.Fatal("wrong or repeated original shrink failure", b.failureCount())
		}
		if !errors.Is(snapshotErr, retainedalloc.ErrCapacity) || (closeErr != nil && !errors.Is(closeErr, retainedalloc.ErrCapacity)) {
			t.Fatal("original errors lost", closeErr, snapshotErr)
		}
		if g.registry != r || g.metadataCharge != charge || g.metadata == nil || g.failedSnapshots != s || g.wrapperBorrowCountV6() != 1 {
			t.Fatal("concurrent failed unregister refunded its header/borrow")
		}
		// A later successful physical local result cannot erase this SAME
		// original header receipt, nor can repeated completion refund it.
		if !errors.Is(g.close(), retainedalloc.ErrCapacity) || !errors.Is(&g.closeFailure, retainedalloc.ErrCapacity) {
			t.Fatal("registry error overwritten")
		}
		terminalBytes := g.metadata.Bytes()
		metadata, n, e := g.detachGenerationMetadataCompletionV6()
		if metadata != nil || n != 0 || !errors.Is(e, retainedalloc.ErrCapacity) || g.metadata.Bytes() != terminalBytes {
			t.Fatal("concurrent containing completion bypass", metadata, n, e)
		}
	}
}

// This is the distinct physicalDebt branch of the SAME original generation
// owner handoff, rather than a registry failure or a nonlast sibling error.
func TestReaderRegistryGenerationPhysicalDebtRetainsOriginalEdgeV6(t *testing.T) {
	dir := t.TempDir()
	preparePrimaryJointCrashV6(t, dir)
	d, err := Open(Options{Dir: dir, ResolvedProfile: ProfileNoWALFast, Durability: DurabilityWALOffRelaxed, DisableBackgroundPrune: true})
	if err != nil {
		t.Fatal(err)
	}
	defer d.Close()
	if primaryOfflineScopePlatformRefusal(t, d) {
		return
	}
	scope, err := d.captureOfflinePrimaryScopeV6()
	if err != nil {
		t.Fatal(err)
	}
	pair, err := d.newOfflinePrimaryPairV6(scope, defaultChunkSize)
	if err != nil {
		t.Fatal(err)
	}
	owner := pair.primaryOwner
	// DATA Close succeeds; the actual last PRIMARY physical close reports a
	// genuine original-file failure and must retain the same generation edge.
	if err = pair.primary.Pager().WithStableResourceFile(func(f *os.File) error { return f.Close() }); err != nil {
		t.Fatal(err)
	}
	if err = completeOfflineScopeForTestV6(&scope); !errors.Is(err, os.ErrClosed) {
		t.Fatal("missing actual last-owner physical debt", err)
	}
	if scope.primaryEdgeReleased || !scope.failedPhysicalEdgeRetained || scope.physicalCompleted || scope.metadataCharge != 0 || scope.offlineScopeControlCharge == 0 {
		t.Fatal("last-owner physical debt consumed/refunded original generation")
	}
	owner.mu.Lock()
	retained := owner.failedDataGenerations == scope && scope.failedNext == nil
	owner.mu.Unlock()
	if !retained {
		t.Fatal("physical-debt generation lost original owner custody")
	}
	before := scope.stableNamespaceMetadata.Bytes()
	if err = completeOfflineScopeForTestV6(&scope); !errors.Is(err, os.ErrClosed) || scope.stableNamespaceMetadata.Bytes() != before || scope.failedNext == scope {
		t.Fatal("physical debt replayed or duplicated retained edge", err)
	}
}
