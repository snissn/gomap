package mvcc

import (
	"github.com/snissn/gomap/TreeDB/caching"
	backenddb "github.com/snissn/gomap/TreeDB/db"
	"github.com/snissn/gomap/TreeDB/freelist"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/internal/mvccadmission"
	"github.com/snissn/gomap/TreeDB/internal/primaryarena"
	"github.com/snissn/gomap/TreeDB/internal/retainedalloc"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
	"github.com/snissn/gomap/TreeDB/internal/valuelog"
	"github.com/snissn/gomap/TreeDB/node"
	"github.com/snissn/gomap/TreeDB/page"
	"github.com/snissn/gomap/TreeDB/pager"
	"github.com/snissn/gomap/TreeDB/tree"
	"github.com/snissn/gomap/TreeDB/zipper"
	"math"
	"runtime"
	"testing"
	"unsafe"
)

// This fixed selected diagnostic expression is not a production allowance or
// generic graph traversal. Every operand is frozen BEFORE the first public
// cursor call; ready-time checks may reject, never enlarge these limits.
type nativeDiagnosticUnitV6 struct{ Records, Bytes uint64 }

func (u *nativeDiagnosticUnitV6) add(r, b uint64) bool {
	if r > math.MaxUint64-u.Records || b > math.MaxUint64-u.Bytes {
		return false
	}
	u.Records += r
	u.Bytes += b
	return true
}
func (u *nativeDiagnosticUnitV6) times(n uint64) bool {
	if n != 0 && (u.Records > math.MaxUint64/n || u.Bytes > math.MaxUint64/n) {
		return false
	}
	u.Records *= n
	u.Bytes *= n
	return true
}
func (u *nativeDiagnosticUnitV6) join(v nativeDiagnosticUnitV6) bool {
	return u.add(v.Records, v.Bytes)
}
func (u *nativeDiagnosticUnitV6) maximum(v nativeDiagnosticUnitV6) {
	u.Records = max(u.Records, v.Records)
	u.Bytes = max(u.Bytes, v.Bytes)
}

type nativeDiagnosticEnvelopeV6 struct {
	Source                                                       backenddb.NativePreCursorBackendForTestV6
	Allocator                                                    freelist.NativeSelectedAllocatorBoundForTestV6
	Growth                                                       pager.NativeGrowthBoundForTestV6
	Birth, Prepare, Fence, Finish, Cancel, Close, Observe, Grant nativeDiagnosticUnitV6
	LookupNodes, OutputPages, InputRetired, OwnerBindings        uint64
	Missing                                                      string
}

// key/value bounds come from the unchanged selected fixture's encoded inputs,
// not a scan or the later prepared output. shards is an original precursor.
func nativeSelectedDiagnosticEnvelopeV6(g backenddb.NativePreCursorBackendForTestV6, shards, keyBytes, valueBytes uint64) (e nativeDiagnosticEnvelopeV6) {
	e.Source = g
	if runtime.GOOS != "linux" || !g.Complete || g.Debt != 0 || g.Visible != 0 || g.IndexGenerations != 1 || g.Allocator.Activated != 0 || g.Allocator.Profile.AbandonedAppendExtents != 0 || g.PrimaryOwner.ActiveEnrollment || g.RegistryOwner.ActiveEnrollment || g.PrimaryOwner.Unsupported || g.RegistryOwner.Unsupported || shards == 0 || keyBytes == 0 || keyBytes > 64 || valueBytes > page.PageSize {
		e.Missing = "selected precursor shape"
		return
	}
	bad := false
	sum := func(rows ...nativeDiagnosticUnitV6) (u nativeDiagnosticUnitV6) {
		for _, v := range rows {
			if !u.join(v) {
				bad = true
				return nativeDiagnosticUnitV6{}
			}
		}
		return
	}
	scale := func(u nativeDiagnosticUnitV6, n uint64) nativeDiagnosticUnitV6 {
		if !u.times(n) {
			bad = true
			return nativeDiagnosticUnitV6{}
		}
		return u
	}
	unit := func(r, b uint64, ok bool) nativeDiagnosticUnitV6 {
		if !ok {
			bad = true
		}
		return nativeDiagnosticUnitV6{r, b}
	}
	if g.Bank.PagerTable.TableNodeCount > math.MaxUint64-6 || max(g.PrimaryOwner.Bindings, g.RegistryOwner.Bindings) == math.MaxUint64 || g.Seals == math.MaxUint64 {
		e.Missing = "precursor overflow"
		return
	}
	if g.Bank.PagerTable.HeadCapacity == 0 || g.Bank.PagerTable.HeadCapacity > math.MaxUint64/2 || g.Bank.PagerTable.TableNodeCount >= 2*g.Bank.PagerTable.HeadCapacity {
		e.Missing = "native root table no-rehash shape"
		return
	}
	e.LookupNodes = g.Bank.PagerTable.TableNodeCount + 6
	e.OwnerBindings = max(g.PrimaryOwner.Bindings, g.RegistryOwner.Bindings) + 1 // SAME original capture enrollment per owner
	if g.DirectoryEntries > node.PrimaryDirectoryMaxEntries || g.BaseLeafEntries > math.MaxUint16 || g.BaseLeafEntries > math.MaxUint64-g.DirectoryEntries-1 {
		e.Missing = "leaf input bound"
		return
	}
	ops := g.DirectoryEntries + 1
	e.OutputPages = max(uint64(1), g.BaseLeafEntries+ops)
	e.InputRetired = g.DirectoryEntries
	e.Allocator = freelist.NativeSelectedAllocatorEnvelopeForTestV6(g.Allocator, e.OutputPages, e.InputRetired)
	if !e.Allocator.Complete {
		e.Missing = "allocator structural overflow/format"
		return
	}
	e.Growth = pager.NativeGrowthPriceForTestV6(g.Growth, e.Allocator.DataHighWater, e.OutputPages)
	if !e.Growth.Complete || !g.Growth.DataMetadataAbsent {
		e.Missing = "DATA Growth shape/overflow"
		return
	}
	resizeBytes := 2*uint64(unsafe.Sizeof(memtable.COWExternalLease{})) + 2*uint64(unsafe.Sizeof(memtable.COWBudget{}))
	add := unit(retainedalloc.NativeOwnerGrowthPriceForTestV6(e.OwnerBindings, resizeBytes))
	remove := unit(retainedalloc.NativeRemovalUnitForTestV6(resizeBytes))
	atomicRemove := unit(retainedalloc.NativeAtomicRemovalPriceForTestV6(e.OwnerBindings, resizeBytes))
	enroll := unit(retainedalloc.NativeEnrollmentUnitForTestV6(remove.Records, remove.Bytes, resizeBytes))
	forward := unit(retainedalloc.NativeEnrollmentPreparationPriceForTestV6(e.OwnerBindings, resizeBytes, memtable.COWRetentionAcquireWorkBytes()))
	vlog := unit(valuelog.NativeEmptyTerminalPriceForTestV6(remove.Records, remove.Bytes))
	capacity, ok := rootpublication.NativeSelectedRegistryCapacityForTestV6(g.Registry)
	if !ok {
		e.Missing = "registry capacity"
		return
	}
	platform := max(uint64(len("linux")), g.Registry.PlatformBytes)
	observe := unit(rootpublication.NativeObservePriceForTestV6(capacity, e.OwnerBindings, resizeBytes, platform))
	pin := unit(rootpublication.NativePinReleasePriceForTestV6(capacity, e.OwnerBindings, resizeBytes, platform))
	lr, lb, _, _, ok := pager.NativeReadRootUnitForTestV6(e.LookupNodes)
	lookup := unit(lr, lb, ok)
	_, _, qr, qb, ok := primaryarena.NativeReleaseUnitForTestV6(e.LookupNodes, remove.Records, remove.Bytes)
	queue := unit(qr, qb, ok)
	// The only native linked RAM root consumes no PRIMARY page. The original
	// capsule and empty manifest each consume at most one of its real pages.
	if g.Bank.NextPage > math.MaxUint64-2 {
		e.Missing = "PRIMARY page bound"
		return
	}
	primaryGrowth := pager.NativePrimaryGrowthPriceForTestV6(g.PrimaryGrowth, g.Bank.NextPage+2, add.Records, add.Bytes, atomicRemove.Records, atomicRemove.Bytes)
	if !primaryGrowth.Complete {
		e.Missing = "PRIMARY Growth"
		return
	}
	arena := primaryarena.NativeConstructionPriceForTestV6(e.LookupNodes, add.Records, add.Bytes, primaryGrowth.Records, primaryGrowth.Bytes)
	primary := rootpublication.NativePrimaryConstructionPriceForTestV6(add.Records, add.Bytes)
	if g.DirectoryPathBytes > math.MaxUint64-11 {
		e.Missing = "path bound"
		return
	}
	paths := rootpublication.NativeCaptureConstructorGeometryForTestV6{ParentNameBytes: g.DirectoryPathBytes, FileNameBytes: g.IndexFileBytes, ProofParentNameBytes: max(g.DirectoryPathBytes+11, g.ProofParentBytes), NameBytes: g.IndexNameBytes, DiagnosticPathBytes: g.IndexFileBytes, LogicalLaneBytes: uint64(len("primary-index")), RegistryCapacity: capacity, PlatformBytes: platform, OwnerAddRecords: add.Records, OwnerAddBytes: add.Bytes}
	capture := rootpublication.NativeCaptureConstructorPriceForTestV6(paths)
	dbprep := backenddb.NativeDBPreparationPriceForTestV6(g, backenddb.NativeDBPreparationChildrenForTestV6{Arena: arena, Primary: primary, Capture: capture, LookupNodes: e.LookupNodes, AddRecords: add.Records, AddBytes: add.Bytes, RemovalRecords: remove.Records, RemovalBytes: remove.Bytes, QueueRecords: queue.Records, QueueBytes: queue.Bytes, ObserveRecords: observe.Records, ObserveBytes: observe.Bytes, UnobserveRecords: pin.Records, UnobserveBytes: pin.Bytes, WriteRecords: 5, WriteBytes: 2*page.PageSize + 1024, Complete: !bad})
	if !arena.Complete || !primary.Complete || !capture.Complete || !dbprep.Complete {
		e.Missing = "original constructor arithmetic"
		return
	}
	// Backend birth, owned admission callback and final registry phases are
	// separate original units; the fixed selected capture has two owner roles.
	snap := backenddb.NativeSnapshotPreparationPriceForTestV6(e.LookupNodes, 2)
	cache := unit(caching.NativeCapturePreparationPriceForTestV6(shards))
	if !snap.Complete {
		e.Missing = "Snapshot birth"
		return
	}
	birth := sum(cache, nativeDiagnosticUnitV6{1, uint64(unsafe.Sizeof(PruneCursor{}))}, nativeDiagnosticUnitV6{1, memtable.COWRetentionAcquireWorkBytes()}, nativeDiagnosticUnitV6{1, uint64(unsafe.Sizeof(node.LeafEntry{}))}, nativeDiagnosticUnitV6{1, resizeBytes}, nativeDiagnosticUnitV6{snap.BirthRecords, snap.BirthBytes}, nativeDiagnosticUnitV6{snap.RegistryRecords, snap.RegistryBytes}, scale(forward, 2))
	// The child loops persist their frame/probe/offset. These are sums of their
	// actual source next-progress alternatives plus repeated ancestor prefixes.
	frameRaw := uint64(unsafe.Sizeof(backenddb.NativeMVCCFrameReaderV6{}))
	frame := sum(nativeDiagnosticUnitV6{1, frameRaw + uint64(unsafe.Sizeof(page.ChildRef{}))}, nativeDiagnosticUnitV6{1, 128}, nativeDiagnosticUnitV6{7, 1088}, lookup, nativeDiagnosticUnitV6{1, 2 * page.PageSize}, nativeDiagnosticUnitV6{1, 64})
	idleR, idleB := valuelog.NativeIdleLeafCancelPriceForTestV6()
	idleCancel := nativeDiagnosticUnitV6{idleR, idleB}
	frameCancel := sum(nativeDiagnosticUnitV6{1, frameRaw}, idleCancel, nativeDiagnosticUnitV6{1, uint64(unsafe.Sizeof(valuelog.COWLeafProjectionReader{}))})
	pr, pb, pcR, pcB, ok := tree.NativeProjectionPriceForTestV6(keyBytes, frame.Records, frame.Bytes, frameCancel.Records, frameCancel.Bytes)
	projection := unit(pr, pb, ok)
	projectionClose := nativeDiagnosticUnitV6{pcR, pcB}
	leaf := unit(node.NativeLeafPriceForTestV6(g.LeafPrefix, g.LeafColumnar, keyBytes, valueBytes))
	appR, appB, appCR, appCB, ok := freelist.NativeSelectedAppendPriceForTestV6(g.Allocator, e.Allocator, e.Growth)
	appendUnit := unit(appR, appB, ok)
	wr, wb, wcr, wcb, ok := zipper.NativeMaterializedPriceForTestV6(ops, e.OutputPages, e.Allocator.Allocated, e.Allocator.Retired, lookup.Records, lookup.Bytes, appendUnit.Records, appendUnit.Bytes, appCR, appCB, leaf.Records, leaf.Bytes, add.Records, add.Bytes, remove.Records, remove.Bytes, frameRaw)
	writer := unit(wr, wb, ok)
	writerCancel := nativeDiagnosticUnitV6{wcr, wcb}
	alR, alB, alPR, alPB, ok := freelist.NativePreparationPriceForTestV6(g.Allocator, e.Allocator, add.Records, add.Bytes, remove.Records, remove.Bytes)
	allocator := unit(alR, alB, ok)
	publishedPrivate := nativeDiagnosticUnitV6{alPR, alPB}
	request := uint64(unsafe.Sizeof(mvccadmission.Request{})) + uint64(unsafe.Sizeof(mvccadmission.Capability{})) + uint64(unsafe.Sizeof(mvccadmission.Authority{}))
	le := uint64(unsafe.Sizeof(node.LeafEntry{}))
	cd := uint64(unsafe.Sizeof(backenddb.NativeMVCCCurrentDeleteV6{}))
	sel := uint64(unsafe.Sizeof(tree.NativeMVCCSelectionV6{}))
	// Fixed public phases 1..26, including a repeated complete child before the
	// parent's later reservation, and both current-delete selection witnesses.
	parent := sum(nativeDiagnosticUnitV6{1, 64}, nativeDiagnosticUnitV6{1, resizeBytes}, nativeDiagnosticUnitV6{1, uint64(unsafe.Sizeof(backenddb.Snapshot{}))}, nativeDiagnosticUnitV6{2, 128}, nativeDiagnosticUnitV6{2, 512}, nativeDiagnosticUnitV6{1, 3 * keyBytes}, nativeDiagnosticUnitV6{1, 137}, nativeDiagnosticUnitV6{1, request}, nativeDiagnosticUnitV6{1, 8*keyBytes + valueBytes + 128}, nativeDiagnosticUnitV6{2, 2 * (keyBytes + 64)}, nativeDiagnosticUnitV6{1, 2*sel + keyBytes}, nativeDiagnosticUnitV6{1, 2*(keyBytes+valueBytes) + le}, nativeDiagnosticUnitV6{1, resizeBytes}, nativeDiagnosticUnitV6{1, 2*cd + sel}, nativeDiagnosticUnitV6{1, 128}, nativeDiagnosticUnitV6{1, 2*uint64(unsafe.Sizeof(tree.Tree{})) + 2*le + 2*keyBytes}, nativeDiagnosticUnitV6{1, request}, nativeDiagnosticUnitV6{2, 2*cd + 128}, nativeDiagnosticUnitV6{primary.TransactionRecords, primary.TransactionBytes}, nativeDiagnosticUnitV6{arena.RootRecords, arena.RootBytes}, nativeDiagnosticUnitV6{primary.PromotionRecords, primary.PromotionBytes}, nativeDiagnosticUnitV6{1, keyBytes + 64}, nativeDiagnosticUnitV6{1, uint64(unsafe.Sizeof(uint64(0))) + 32}, nativeDiagnosticUnitV6{g.IndexGenerations + 1, 32 * g.IndexGenerations}, nativeDiagnosticUnitV6{1, nativePublicationReadyReadBytesV6()}, nativeDiagnosticUnitV6{1, 2 * uint64(unsafe.Sizeof(bool(false)))})
	// Minimum next-progress price includes saved acquisition loads and epoch
	// revalidation, plus the unchanged whole map/registry alternatives. It is
	// distinct from total 512-load traffic across a quiet successful attempt.
	minimum := sum(unit(backenddb.NativeSnapshotMinimumPriceForTestV6(g.IndexGenerations, g.MinimumFallbackSlots)), nativeDiagnosticUnitV6{1, 256}) // original capability tail after ready
	e.Birth = birth
	e.Prepare = sum(parent, minimum, projection, frame, writer, allocator, nativeDiagnosticUnitV6{dbprep.RootRecords, dbprep.RootBytes}, nativeDiagnosticUnitV6{dbprep.CandidateRecords, dbprep.CandidateBytes}, nativeDiagnosticUnitV6{dbprep.SealRecords, dbprep.SealBytes})
	pub, ok := freelist.NativeSelectedPublicationPriceForTestV6(e.Allocator)
	if !ok {
		e.Missing = "publication prefix bound"
		return
	}
	remainder := backenddb.NativeRemainderPriceForGeometryForTestV6(pub, g.Seals+1)
	if !remainder.Complete {
		e.Missing = "original remainder"
		return
	}
	for role := uint8(0); role < 7; role++ {
		row, known := backenddb.NativeFPriceForGeometryForTestV6(role, g.Debt+1, 1, keyBytes, request, remainder)
		if !known || !row.Complete {
			bad = true
		}
		e.Fence = sum(e.Fence, nativeDiagnosticUnitV6{row.Records, row.Bytes})
	}
	co := rootpublication.NativeCoordinatorPriceForTestV6()
	if !co.RuntimeEvidenceSupported {
		e.Missing = "canonical coordinator service"
		return
	}
	e.Fence = sum(e.Fence, nativeDiagnosticUnitV6{co.AcquireRecords, co.AcquireBytes}, nativeDiagnosticUnitV6{co.EnqueueRecords, co.EnqueueBytes}, nativeDiagnosticUnitV6{co.CompletionRecords, co.CompletionBytes}, nativeDiagnosticUnitV6{co.BuilderReleaseRecords, co.BuilderReleaseBytes}, nativeDiagnosticUnitV6{remainder.Records, remainder.Bytes})
	e.Fence = sum(e.Fence, unit(freelist.NativeSelectedClaimPriceForTestV6(g.Allocator, e.Allocator)), writer) // whole ValidateAll is a contained subrow of writer
	dr, db := rootpublication.NativeActivationDispatchWorkForTestV6()
	cr, cb := nativePublicationCallerTailWorkV6()
	e.Fence = sum(e.Fence, nativeDiagnosticUnitV6{dr, db}, nativeDiagnosticUnitV6{cr + 1, cb + nativePublicationReadyReadBytesV6()})
	terminal := backenddb.NativeTerminalUnitsForShapeForTestV6(e.LookupNodes, remove.Records, remove.Bytes, enroll.Records, enroll.Bytes, vlog.Records, vlog.Bytes, g.IndexFileBytes, g.Seals+1)
	if !terminal.Complete {
		e.Missing = "typed terminal"
		return
	}
	directory := unit(rootpublication.NativeDirectoryTerminalPriceForTestV6(remove.Records, remove.Bytes, add.Records, add.Bytes, terminal.ProviderRecords, terminal.ProviderBytes))
	resource := unit(rootpublication.NativeResourceTerminalPriceForTestV6(remove.Records, remove.Bytes, terminal.OwnedRecords, terminal.OwnedBytes, directory.Records, directory.Bytes, pin.Records, pin.Bytes))
	fr, fb := rootpublication.NativeFinishHeaderPriceForTestV6()
	cor, cob := rootpublication.NativeCoordinatorTerminalPriceForTestV6()
	// Both graph and member callbacks have saved original indices. Summing their
	// completed-child prefixes closes the same turn; no nil-work cleanup credit.
	e.Finish = sum(nativeDiagnosticUnitV6{fr, fb}, resource, nativeDiagnosticUnitV6{terminal.MemberRecords, terminal.MemberBytes}, nativeDiagnosticUnitV6{terminal.WitnessRecords, terminal.WitnessBytes}, publishedPrivate, writerCancel, remove, nativeDiagnosticUnitV6{cor, cob}, nativeDiagnosticUnitV6{terminal.CloseRecords, terminal.CloseBytes}, nativeDiagnosticUnitV6{1, 2 * cd}, nativeDiagnosticUnitV6{1, nativePublicationACKBytesV6()})
	// Genuine cancellation shares original transaction/graph/capture parents.
	// The two close captures restart their outer selector, hence the explicit
	// two completed-prefix alternatives rather than two copied resource owners.
	capClose := sum(resource, nativeDiagnosticUnitV6{terminal.OwnedRecords, terminal.OwnedBytes}, enroll, remove)
	e.Cancel = sum(e.Finish, scale(capClose, 2), writerCancel, allocator, nativeDiagnosticUnitV6{primaryGrowth.CancelRecords, primaryGrowth.CancelBytes})
	ccr, ccb := caching.NativeCaptureClosePrefixForTestV6()
	cursorClose := sum(nativeDiagnosticUnitV6{1, 2*uint64(unsafe.Sizeof(uint8(0))) + 2*uint64(unsafe.Sizeof(bool(false))) + 2*uint64(unsafe.Sizeof((*backenddb.NativeMVCCCurrentDeleteV6)(nil)))}, nativeDiagnosticUnitV6{1, 2 * cd}, projectionClose, idleCancel, frameCancel, nativeDiagnosticUnitV6{1, 2*le + 2*uint64(unsafe.Sizeof(valuelog.COWLeafContinuation{}))}, frameCancel, nativeDiagnosticUnitV6{1, 2*frameRaw + 2*uint64(unsafe.Sizeof(valuelog.COWLeafProjectionReader{}))}, nativeDiagnosticUnitV6{ccr, ccb}, enroll, nativeDiagnosticUnitV6{terminal.SnapshotRecords, terminal.SnapshotBytes}, nativeDiagnosticUnitV6{1, 2 * le}, nativeDiagnosticUnitV6{1, resizeBytes})
	e.Close = sum(e.Cancel, cursorClose)
	// Reset phase20 includes the actual retained anchor copy and the original
	// concrete Resize, even after every selected entry has already been cleared.
	tail := sum(nativeDiagnosticUnitV6{1, 2*cd + 128 + 2}, nativeDiagnosticUnitV6{1, 2 * le}, nativeDiagnosticUnitV6{1, 64 + keyBytes}, nativeDiagnosticUnitV6{1, resizeBytes}, nativeDiagnosticUnitV6{1, 2*le + uint64(unsafe.Sizeof(valuelog.COWLeafContinuation{}))}, frameCancel)
	e.Prepare = sum(e.Prepare, tail)
	// Observation is not production credit. Original per-role Q32 vectors are
	// separate from the immutable public grant, and must themselves succeed.
	e.Observe = nativeDiagnosticUnitV6{32, 1 << 20}
	if bad {
		e.Missing = "checked unit composition overflow"
		return
	}
	// Componentwise sum deliberately overbounds a turn crossing several saved
	// stages. Each nested nonpersistent prefix is already included above.
	e.Grant = sum(e.Birth, e.Prepare, e.Fence, e.Finish, e.Cancel, e.Close)
	if bad || e.Grant.Records == 0 || e.Grant.Bytes == 0 {
		e.Grant = nativeDiagnosticUnitV6{}
		e.Missing = "checked grant overflow"
		return
	}
	return
}

func TestNativeFinaldriverEnvelopeCheckedArithmeticV6(t *testing.T) {
	t.Run("supported-selected-shape", func(t *testing.T) {
		if runtime.GOOS != "linux" {
			t.Skip("selected native FD barrier is Linux only")
		}
		var g backenddb.NativePreCursorBackendForTestV6
		g.Complete = true
		g.IndexGenerations = 1
		g.SourceLeaf = true
		g.OuterLeavesOff = true
		g.AdaptiveEncodingOff = true
		g.InternalBaseDeltaOff = true
		g.EntryRevisions = true
		g.EmptyValueLog = true
		g.NoLeafGenerations = true
		g.Bank.Valid = true
		g.Bank.PagerTable.HeadCapacity = 256
		g.Bank.PagerTable.TableNodeCount = 4
		g.Bank.NextPage = 4
		g.Allocator.Profile.Valid = true
		g.Allocator.Profile.HighWater = 16
		g.Allocator.PageCount = 16
		g.Growth = pager.NativePreCursorGrowthForTestV6{PageCount: 16, Chunks: 1, ChunkSize: 1 << 20, DataMetadataAbsent: true, MetadataSameExpected: true, FileBacked: true, Complete: true}
		g.PrimaryGrowth = g.Growth
		g.PrimaryGrowth.DataMetadataAbsent = false
		g.PrimaryOwner.Complete = true
		g.RegistryOwner.Complete = true
		e := nativeSelectedDiagnosticEnvelopeV6(g, 16, 32, 1)
		if e.Missing != "" || e.Grant.Records == 0 || e.Grant.Bytes == 0 || e.LookupNodes != 10 {
			t.Fatal("source-supported selected expression unavailable", e.Missing, e)
		}
		total := nativeDiagnosticUnitV6{}
		for _, row := range []nativeDiagnosticUnitV6{e.Birth, e.Prepare, e.Fence, e.Finish, e.Cancel, e.Close} {
			if !total.join(row) {
				t.Fatal("unexpected sum overflow")
			}
		}
		if total != e.Grant {
			t.Fatal("grant omitted a named family", total, e.Grant)
		}
		g.MinimumFallbackSlots = math.MaxUint64
		if broken := nativeSelectedDiagnosticEnvelopeV6(g, 16, 32, 1); broken.Missing == "" || broken.Grant != (nativeDiagnosticUnitV6{}) {
			t.Fatal("dirty fallback overflow granted", broken)
		}
	})
	t.Run("sum", func(t *testing.T) {
		u := nativeDiagnosticUnitV6{math.MaxUint64, 7}
		if u.add(1, 0) || u.Records != math.MaxUint64 || u.Bytes != 7 {
			t.Fatal("overflow mutated unit")
		}
	})
	t.Run("multiply", func(t *testing.T) {
		u := nativeDiagnosticUnitV6{2, math.MaxUint64}
		if u.times(2) || u.Records != 2 || u.Bytes != math.MaxUint64 {
			t.Fatal("overflow mutated unit")
		}
	})
	t.Run("missing-shape", func(t *testing.T) {
		if e := nativeSelectedDiagnosticEnvelopeV6(backenddb.NativePreCursorBackendForTestV6{}, 0, 0, 0); e.Missing == "" || e.Grant != (nativeDiagnosticUnitV6{}) {
			t.Fatal("unproved grant", e)
		}
	})
}

// Original Q32/1MiB quantum for precursor/ready observations only. It does not
// create a second work grant for a public pruning invocation.
func nativeDiagnosticObservationQuantumV6() *iterator.OrdinalScanWork {
	return &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
}
