package db

import (
	"errors"
	"math"
	"testing"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/lifecycle"
)

func nativeMinimumQuantumForTestV6() *iterator.OrdinalScanWork {
	return &iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: 1 << 20}
}

// Count the actual source load rows, not inferred unique shards. Initial/terminal
// entries pay two headers; an accepted scan transition pays one additional row.
// This helper requires a quiet epoch and stops at the FIRST ready result.
func nativeMinimumDrainForTestV6(t *testing.T, d *DB, s *nativeMVCCSnapshotMinimumV6) (minimum, loads, entries, records, bytes uint64) {
	t.Helper()
	for entries = 0; entries < 2000; {
		before := s.phase
		w := nativeMinimumQuantumForTestV6()
		value, ready, err := s.step(d, w)
		entries++
		records, bytes = records+w.Records, bytes+w.Bytes
		if err != nil || w.Records > 32 || w.Bytes > 1<<20 {
			t.Fatalf("minimum failed within Q32: ready=%v err=%v state=%+v work=%+v", ready, err, s, w)
		}
		if before == 0 || before == nativeMinimumInitialV6 || before == nativeMinimumTerminalV6 {
			n := w.Records - 2
			if s.phase == nativeMinimumRegistryV6 || s.phase == nativeMinimumCompleteV6 {
				n--
			}
			loads += n
		}
		if ready {
			return value, loads, entries, records, bytes
		}
	}
	t.Fatal("quiet SAME minimum did not converge")
	return
}

func TestNativeSnapshotMinimumAcquisitionAdmissionV6(t *testing.T) {
	var d DB
	d.snapshotAcquireEpoch.Store(42)
	for _, tc := range []struct {
		name           string
		records, bytes uint64
	}{
		{"record-remainder-short", 2, 1 << 20},
		{"byte-remainder-short", 32, nativeMinimumEntryBytesV6() + nativeMinimumEpochBytesV6() + nativeMinimumLoadBytesV6() - 1},
	} {
		t.Run(tc.name, func(t *testing.T) {
			s := nativeMVCCSnapshotMinimumV6{epoch: 42, minimum: math.MaxUint64, phase: nativeMinimumInitialV6, scanIndex: 3}
			before := s
			d.snapshotAcquireRO[3].Store(1)
			defer d.snapshotAcquireRO[3].Store(0)
			w := iterator.OrdinalScanWork{RecordLimit: tc.records, ByteLimit: tc.bytes}
			minimum, ready, err := s.step(&d, &w)
			if minimum != 0 || ready || err != nil || s != before || w.Records != 2 || w.Bytes != nativeMinimumEntryBytesV6()+nativeMinimumEpochBytesV6() {
				t.Fatalf("refused load read/reset/advanced saved evidence: min=%d ready=%v err=%v state=%+v work=%+v", minimum, ready, err, s, w)
			}
			// Exactly one load now fits and sees the unchanged positive shard.
			w = iterator.OrdinalScanWork{RecordLimit: 3, ByteLimit: nativeMinimumEntryBytesV6() + nativeMinimumEpochBytesV6() + nativeMinimumLoadBytesV6()}
			if minimum, ready, err = s.step(&d, &w); minimum != 0 || ready || err != nil || s != (nativeMVCCSnapshotMinimumV6{}) || w.Records != 3 || w.Bytes != w.ByteLimit {
				t.Fatalf("admitted next load missed actual counter: min=%d ready=%v err=%v state=%+v work=%+v", minimum, ready, err, s, w)
			}
		})
	}
	for _, shard := range []int{0, snapshotAcquireShardCount - 1} {
		t.Run(map[bool]string{true: "first-shard", false: "last-shard"}[shard == 0], func(t *testing.T) {
			var s nativeMVCCSnapshotMinimumV6
			d.snapshotAcquireRO[shard].Store(1)
			defer d.snapshotAcquireRO[shard].Store(0)
			var loads uint64
			for turn := 0; turn < 20; turn++ {
				w := nativeMinimumQuantumForTestV6()
				minimum, ready, err := s.step(&d, w)
				loads += w.Records - 2
				if minimum != 0 || ready || err != nil {
					t.Fatal("in-flight actual shard escaped", minimum, ready, err)
				}
				if s.phase == 0 {
					if loads != uint64(shard+1) {
						t.Fatal("wrong actual admitted prefix", loads, shard)
					}
					return
				}
			}
			t.Fatal("positive shard was not observed")
		})
	}
	var s nativeMVCCSnapshotMinimumV6
	minimum, loads, entries, records, bytes := nativeMinimumDrainForTestV6(t, &d, &s)
	if minimum != math.MaxUint64 || loads != 2*snapshotAcquireShardCount || s.phase != nativeMinimumCompleteV6 || s.scanIndex != snapshotAcquireShardCount {
		t.Fatal("not exact two saved scans", minimum, loads, s)
	}
	// Empty-map path visits current once and then saves terminal phase.
	wantRecords := 2*entries + 2*snapshotAcquireShardCount + 2 + 2
	wantBytes := entries*(nativeMinimumEntryBytesV6()+nativeMinimumEpochBytesV6()) + 2*snapshotAcquireShardCount*nativeMinimumLoadBytesV6() + 2*nativeMinimumEpochBytesV6() + 2*nativeMinimumMapBytesV6(0)
	if records != wantRecords || bytes != wantBytes {
		t.Fatal("whole actual successful traffic differs", records, wantRecords, bytes, wantBytes)
	}
	wholeR, wholeB, complete := NativeSnapshotMinimumWholePriceForTestV6(0, 0, entries)
	if !complete || records > wholeR || bytes > wholeB {
		t.Fatal("whole-attempt envelope underpriced", records, bytes, wholeR, wholeB)
	}
}

func TestNativeSnapshotMinimumTerminalScanAdmissionV6(t *testing.T) {
	registry := lifecycle.NewReaderRegistry()
	handle := registry.Register(7)
	defer registry.Unregister(handle)
	gen := &indexGen{id: 1, registry: registry}
	d := DB{idxAll: map[uint64]*indexGen{1: gen}}
	d.idx.Store(gen)
	d.snapshotAcquireEpoch.Store(42)
	var s nativeMVCCSnapshotMinimumV6
	for turn := 0; s.phase != nativeMinimumTerminalV6; turn++ {
		if turn > 100 {
			t.Fatal("registry-to-terminal phase did not persist")
		}
		if _, ready, err := s.step(&d, nativeMinimumQuantumForTestV6()); ready || err != nil {
			t.Fatal("premature result", ready, err)
		}
	}
	before := s
	byteShort := iterator.OrdinalScanWork{RecordLimit: 32, ByteLimit: nativeMinimumEntryBytesV6() + nativeMinimumEpochBytesV6() + nativeMinimumLoadBytesV6() - 1}
	if minimum, ready, err := s.step(&d, &byteShort); minimum != 0 || ready || err != nil || s != before || byteShort.Records != 2 {
		t.Fatal("terminal byte refusal consumed evidence", minimum, ready, err, s, byteShort)
	}
	w := iterator.OrdinalScanWork{RecordLimit: 2, ByteLimit: 1 << 20}
	if minimum, ready, err := s.step(&d, &w); minimum != 0 || ready || err != nil || s != before || w.Records != 2 {
		t.Fatal("terminal refused load consumed evidence", minimum, ready, err, s, w)
	}
	minimum, loads, _, _, _ := nativeMinimumDrainForTestV6(t, &d, &s)
	if minimum != 7 || loads != snapshotAcquireShardCount {
		t.Fatal("terminal restarted completed registry/initial scan", minimum, loads)
	}
	// SAME completion survives the actual containing capability row refusing.
	w = iterator.OrdinalScanWork{RecordLimit: 2, ByteLimit: 1 << 20}
	before = s
	minimum, ready, err := s.step(&d, &w)
	if minimum != 7 || !ready || err != nil || w.Reserve(1, 256) || s != before || w.Records != 2 {
		t.Fatal("completed reuse/tail refusal", minimum, ready, err, s, w)
	}
	// Completion reuse must refuse before epoch read if its second row cannot fit.
	w = iterator.OrdinalScanWork{RecordLimit: 1, ByteLimit: 1 << 20}
	if minimum, ready, err = s.step(&d, &w); minimum != 0 || ready || err != nil || s != before || w.Records != 1 {
		t.Fatal("unadmitted completed evidence reused", minimum, ready, err, s, w)
	}
	d.snapshotAcquireEpoch.Add(2) // genuine begin/end order, no outstanding counter
	if minimum, ready, err = s.step(&d, nativeMinimumQuantumForTestV6()); minimum != 0 || ready || err != nil || s != (nativeMVCCSnapshotMinimumV6{}) {
		t.Fatal("stale completed result survived", minimum, ready, err, s)
	}
	if minimum, _, _, _, _ = nativeMinimumDrainForTestV6(t, &d, &s); minimum != 7 {
		t.Fatal("held original registry reader lost after restart", minimum)
	}
}

func TestNativeSnapshotMinimumHistoricalFallbackEnvelopeV6(t *testing.T) {
	registry := lifecycle.NewReaderRegistry()
	handles := make([]int64, lifecycle.FastReaderShardCount+3)
	for i := range handles {
		handles[i] = registry.Register(100 + uint64(i))
	}
	defer registry.Unregister(handles[0])
	for _, handle := range handles[1:] {
		registry.Unregister(handle)
	}
	gen := &indexGen{id: 1, registry: registry}
	d := DB{idxAll: map[uint64]*indexGen{1: gen}}
	d.idx.Store(gen)
	d.snapshotAcquireEpoch.Store(42)
	g, generations, ready := d.MaintenanceNativeMinimumGeometryForTestV6(nativeMinimumQuantumForTestV6())
	if !ready || !g.Complete || !g.Dirty || g.FallbackSlots != 3 || generations != 1 {
		t.Fatalf("historical free slots lost: %+v generations=%d ready=%v", g, generations, ready)
	}
	r, b, complete := NativeSnapshotMinimumPriceForTestV6(generations, g.FallbackSlots)
	if !complete || r > 32 {
		t.Fatal("selected next-progress price unavailable under Q32", r, b)
	}
	var s nativeMVCCSnapshotMinimumV6
	for turn := 0; turn < 100; turn++ {
		before := s
		w := iterator.OrdinalScanWork{RecordLimit: r, ByteLimit: b}
		minimum, done, err := s.step(&d, &w)
		if err != nil || w.Records > r || w.Bytes > b || (!done && before == s) {
			t.Fatalf("next-progress envelope failed: done=%v err=%v state=%+v work=%+v", done, err, s, w)
		}
		if done {
			if minimum != 100 {
				t.Fatal("original live reader minimum lost", minimum)
			}
			return
		}
	}
	t.Fatal("quiet priced observer did not converge")
}

func TestNativeSnapshotMinimumUnsupportedGeometryV6(t *testing.T) {
	t.Run("whole-map", func(t *testing.T) {
		var d DB
		d.idxAll = make(map[uint64]*indexGen)
		for id := uint64(1); id <= 32; id++ {
			d.idxAll[id] = nil
		}
		s := nativeMVCCSnapshotMinimumV6{minimum: math.MaxUint64, phase: nativeMinimumRegistryV6}
		before := s
		_, ready, err := s.step(&d, nativeMinimumQuantumForTestV6())
		var tooLarge *iterator.OrdinalUnitTooLarge
		if ready || !errors.As(err, &tooLarge) || tooLarge.Records != 33 || s != before {
			t.Fatal("large map silently qualified", ready, err, s)
		}
	})
	t.Run("dirty-fallback", func(t *testing.T) {
		r := lifecycle.NewReaderRegistry()
		var handles []int64
		for i := 0; i < lifecycle.FastReaderShardCount+32; i++ {
			handles = append(handles, r.Register(uint64(i+1)))
		}
		defer func() {
			for _, h := range handles {
				r.Unregister(h)
			}
		}()
		// Remove the actual fallback minimum: the original registry keeps all
		// 32 historical slots and marks its cached minimum dirty.
		r.Unregister(handles[lifecycle.FastReaderShardCount])
		gen := &indexGen{id: 1, registry: r}
		d := DB{idxAll: map[uint64]*indexGen{1: gen}}
		d.idx.Store(gen)
		s := nativeMVCCSnapshotMinimumV6{minimum: math.MaxUint64, phase: nativeMinimumRegistryV6}
		before := s
		_, ready, err := s.step(&d, nativeMinimumQuantumForTestV6())
		var tooLarge *iterator.OrdinalUnitTooLarge
		if ready || !errors.As(err, &tooLarge) || tooLarge.Records != 17+32 || s != before {
			t.Fatal("large historical fallback silently qualified", ready, err, s)
		}
	})
	if _, _, ok := NativeSnapshotMinimumPriceForTestV6(^uint64(0), 0); ok {
		t.Fatal("map overflow accepted")
	}
	if _, _, ok := NativeSnapshotMinimumWholePriceForTestV6(1, 0, ^uint64(0)); ok {
		t.Fatal("entry-product overflow accepted")
	}
	if _, _, ok := NativeSnapshotMinimumWholePriceForTestV6(1, 0, 0); ok {
		t.Fatal("zero-entry whole-success claim accepted")
	}
}
