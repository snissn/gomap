package db

import (
	"unsafe"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/lifecycle"
)

// NativeSnapshotAcquisitionScanPriceForTestV6 is whole ONE-pass traffic, not
// an indivisible admission or the next-progress allowance. A quiet successful
// attempt performs exactly TWO such actual 256-load passes.
func NativeSnapshotAcquisitionScanPriceForTestV6() (records, bytes uint64) {
	return uint64(snapshotAcquireShardCount), uint64(snapshotAcquireShardCount) * nativeMinimumLoadBytesV6()
}

// NativeSnapshotMinimumPriceForTestV6 bounds an entry through its next saved
// progress/result. It sums alternative load/transition/map/registry branches
// conservatively, but NEVER charges/runs an entire scan as one primitive.
// Completed reuse pays the actual entry and fresh epoch comparison. Whole map
// walks/dirty fallback remain indivisible and may exceed Q32 on larger shapes.
func NativeSnapshotMinimumPriceForTestV6(indexGenerations, fallbackSlots uint64) (records, bytes uint64, complete bool) {
	r, b, ok := lifecycle.NativeMinimumPriceForTestV6(fallbackSlots)
	if !ok || indexGenerations == ^uint64(0) || indexGenerations > (^uint64(0)-nativeMinimumMapBytesV6(0))/32 {
		return 0, 0, false
	}
	add := func(n, size uint64) bool {
		if n > ^uint64(0)-records || size > ^uint64(0)-bytes {
			return false
		}
		records += n
		bytes += size
		return true
	}
	if !add(1, nativeMinimumEntryBytesV6()) || !add(1, nativeMinimumEpochBytesV6()) || !add(1, nativeMinimumLoadBytesV6()) || !add(1, nativeMinimumEpochBytesV6()) || !add(1+indexGenerations, nativeMinimumMapBytesV6(indexGenerations)) || !add(r, b) {
		return 0, 0, false
	}
	return records, bytes, true
}

// NativeSnapshotMinimumWholePriceForTestV6 bounds TOTAL traffic of one quiet,
// successful attempt given an explicit number of entries (including every
// refusal/replay and completed-result reuse). It is NOT the invocation grant.
// Each entry conservatively includes the whole map/registry alternative; the
// 512 actual load rows and two scan transitions are added exactly once. Churn
// can cause arbitrarily many attempts; no unconditional total-turn bound exists.
func NativeSnapshotMinimumWholePriceForTestV6(indexGenerations, fallbackSlots, entries uint64) (records, bytes uint64, complete bool) {
	r, b, ok := lifecycle.NativeMinimumPriceForTestV6(fallbackSlots)
	if !ok || entries == 0 || indexGenerations == ^uint64(0) || indexGenerations > (^uint64(0)-nativeMinimumMapBytesV6(0))/32 {
		return 0, 0, false
	}
	addProduct := func(count, rowRecords, rowBytes uint64) bool {
		if count != 0 && (rowRecords > (^uint64(0)-records)/count || rowBytes > (^uint64(0)-bytes)/count) {
			return false
		}
		records += count * rowRecords
		bytes += count * rowBytes
		return true
	}
	if !addProduct(entries, 1, nativeMinimumEntryBytesV6()) || !addProduct(entries, 1, nativeMinimumEpochBytesV6()) || !addProduct(entries, 1+indexGenerations, nativeMinimumMapBytesV6(indexGenerations)) || !addProduct(entries, r, b) || !addProduct(2*uint64(snapshotAcquireShardCount), 1, nativeMinimumLoadBytesV6()) || !addProduct(2, 1, nativeMinimumEpochBytesV6()) {
		return 0, 0, false
	}
	return records, bytes, true
}

// Selected precursor: the only original generation is the current one. This
// short observation does not scan readers or acquire a Snapshot. The fixture
// excludes generation changes and ordinary registrations until allocator
// preparation; the fresh native cursor cannot enlarge the fallback vector.
func (db *DB) MaintenanceNativeMinimumGeometryForTestV6(w *iterator.OrdinalScanWork) (g lifecycle.NativeMinimumGeometryForTestV6, indexGenerations uint64, ready bool) {
	if db == nil || w == nil || !w.Reserve(1, 2*uint64(unsafe.Sizeof(g))+2*uint64(unsafe.Sizeof(indexGen{}))+64) {
		return g, 0, false
	}
	db.idxMu.Lock()
	defer db.idxMu.Unlock()
	indexGenerations = uint64(len(db.idxAll))
	if indexGenerations != 1 {
		return g, indexGenerations, true
	}
	if !w.Reserve(1, 32) {
		return g, indexGenerations, false
	}
	current := db.idx.Load()
	for _, gen := range db.idxAll {
		if gen == nil || gen != current || gen.registry == nil {
			return g, indexGenerations, true
		}
		g, ready = gen.registry.MaintenanceNativeMinimumGeometryForTestV6(w)
	}
	return g, indexGenerations, ready
}
