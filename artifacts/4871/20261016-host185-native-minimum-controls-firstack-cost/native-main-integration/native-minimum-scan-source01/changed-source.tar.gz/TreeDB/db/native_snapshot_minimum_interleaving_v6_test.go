package db

import (
	"math"
	"testing"

	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/memtable"
	"github.com/snissn/gomap/TreeDB/lifecycle"
)

func TestNativeSnapshotMinimumEpochInvalidationV6(t *testing.T) {
	for _, tc := range []struct {
		name  string
		phase uint8
	}{
		{"initial", nativeMinimumInitialV6},
		{"registry", nativeMinimumRegistryV6},
		{"terminal", nativeMinimumTerminalV6},
		{"completed-reuse", nativeMinimumCompleteV6},
	} {
		t.Run(tc.name, func(t *testing.T) {
			r := lifecycle.NewReaderRegistry()
			h := r.Register(7)
			defer r.Unregister(h)
			gen := &indexGen{id: 1, registry: r}
			d := DB{idxAll: map[uint64]*indexGen{1: gen}}
			d.idx.Store(gen)
			var s nativeMVCCSnapshotMinimumV6
			for turn := 0; s.phase != tc.phase; turn++ {
				if turn > 100 {
					t.Fatal("target actual phase not reached", s)
				}
				if _, _, err := s.step(&d, nativeMinimumQuantumForTestV6()); err != nil {
					t.Fatal(err)
				}
			}
			// In the scanning phases, shard zero has already been examined. An
			// entire original acquisition can begin/end between calls, leaving
			// every counter zero; only the SAME saved epoch detects this history.
			if tc.phase == nativeMinimumTerminalV6 {
				if _, ready, err := s.step(&d, nativeMinimumQuantumForTestV6()); ready || err != nil || s.scanIndex == 0 {
					t.Fatal("no saved terminal prefix", ready, err, s)
				}
			}
			d.snapshotAcquireRO[0].Add(1)
			d.snapshotAcquireEpoch.Add(1)
			newHandle := r.Register(3) // actual lower cohort publishes before end
			defer r.Unregister(newHandle)
			d.snapshotAcquireEpoch.Add(1)
			d.snapshotAcquireRO[0].Add(-1)
			w := nativeMinimumQuantumForTestV6()
			if minimum, ready, err := s.step(&d, w); minimum != 0 || ready || err != nil || s != (nativeMVCCSnapshotMinimumV6{}) || w.Records != 2 || w.Bytes != nativeMinimumEntryBytesV6()+nativeMinimumEpochBytesV6() {
				t.Fatal("changed epoch reused accumulated evidence", minimum, ready, err, s, w)
			}
			if minimum, _, _, _, _ := nativeMinimumDrainForTestV6(t, &d, &s); minimum != 3 {
				t.Fatal("new real registry minimum omitted", minimum)
			}
		})
	}
	// Counter-before-begin-epoch is a real publication window. It must block
	// when encountered even though the begin epoch has not yet changed.
	t.Run("counter-before-begin-epoch", func(t *testing.T) {
		var d DB
		d.snapshotAcquireRO[0].Add(1)
		var s nativeMVCCSnapshotMinimumV6
		if minimum, ready, err := s.step(&d, nativeMinimumQuantumForTestV6()); minimum != 0 || ready || err != nil || s.phase != 0 {
			t.Fatal("pre-begin counter missed", minimum, ready, err, s)
		}
		d.snapshotAcquireEpoch.Add(1)
		// End epoch is visible before counter decrement: this window remains
		// conservative, and no uncertain minimum is replaced by zero.
		d.snapshotAcquireEpoch.Add(1)
		if minimum, ready, err := s.step(&d, nativeMinimumQuantumForTestV6()); minimum != 0 || ready || err != nil || s.phase != 0 {
			t.Fatal("pre-decrement counter missed", minimum, ready, err, s)
		}
		d.snapshotAcquireRO[0].Add(-1)
		if minimum, _, _, _, _ := nativeMinimumDrainForTestV6(t, &d, &s); minimum != math.MaxUint64 {
			t.Fatal(minimum)
		}
	})
}

func TestNativeSnapshotMinimumChurnThenQuietProgressV6(t *testing.T) {
	r := lifecycle.NewReaderRegistry()
	h := r.Register(5)
	defer r.Unregister(h)
	gen := &indexGen{id: 1, registry: r}
	d := DB{idxAll: map[uint64]*indexGen{1: gen}}
	d.idx.Store(gen)
	var s nativeMVCCSnapshotMinimumV6
	for turn := 0; turn < 40; turn++ {
		// An acquisition on an already scanned first shard finishes between
		// every pair of yields. This is controlled churn, not a progress claim.
		d.snapshotAcquireRO[0].Add(1)
		d.snapshotAcquireEpoch.Add(1)
		d.snapshotAcquireEpoch.Add(1)
		d.snapshotAcquireRO[0].Add(-1)
		if minimum, ready, err := s.step(&d, nativeMinimumQuantumForTestV6()); minimum != 0 || ready || err != nil {
			t.Fatal("churning attempt returned evidence", minimum, ready, err)
		}
	}
	if minimum, _, _, _, _ := nativeMinimumDrainForTestV6(t, &d, &s); minimum != 5 {
		t.Fatal("same observer failed after churn stopped", minimum)
	}
}

func TestNativeSnapshotMinimumHeldReaderAndPartialCaptureV6(t *testing.T) {
	d, err := Open(Options{Dir: t.TempDir(), DisableBackgroundPrune: true})
	if err != nil {
		t.Fatal(err)
	}
	defer d.Close()
	if err := d.Set([]byte("held"), []byte("original")); err != nil {
		t.Fatal(err)
	}
	old := d.AcquireSnapshot()
	if old == nil {
		t.Fatal("missing original held reader")
	}
	defer old.Close()
	oldSequence := old.state.primaryRetentionCommitV5()
	var minimum nativeMVCCSnapshotMinimumV6
	if _, ready, err := minimum.step(d, nativeMinimumQuantumForTestV6()); ready || err != nil || minimum.scanIndex == 0 {
		t.Fatal("missing saved initial prefix", ready, err, minimum)
	}
	budget, err := memtable.NewCOWBudget(memtable.DefaultCOWLimits())
	if err != nil {
		t.Fatal(err)
	}
	defer budget.Close()
	budgetBaseline := budget.Stats().TotalBytes
	var lease *memtable.COWExternalLease
	admit := func(sizes SnapshotAllocationSizes) error {
		var err error
		lease, err = budget.AcquireExternal(memtable.COWAllocationCharge(sizes.Wrapper))
		return err
	}
	partial, ready, err := d.BeginNativeMVCCSnapshotV6(admit, nativeMinimumQuantumForTestV6())
	if !d.idx.Load().pager.SupportsBoundedPhysicalClose() {
		if partial != nil || ready || err != ErrNativeMVCCSnapshotWork || lease != nil {
			t.Fatal("unsupported capture altered custody", ready, err)
		}
		return
	}
	if partial == nil || !ready || err != nil || !partial.nativeMVCC.epochLive || lease == nil {
		t.Fatal("missing genuine partial original capture", ready, err)
	}
	closed := false
	defer func() {
		if !closed {
			for turn := 0; turn < 1000; turn++ {
				done, e := partial.CloseNativeMVCCSnapshotStepV6(nativeMinimumQuantumForTestV6())
				if e != nil {
					t.Error(e)
					return
				}
				if done {
					lease.Close()
					return
				}
			}
			t.Error("partial capture cleanup did not converge")
		}
	}()
	// The actual Begin changed epoch; even a previously examined shard cannot
	// let the saved observation bypass this unregistered original Snapshot.
	if value, ready, err := minimum.step(d, nativeMinimumQuantumForTestV6()); value != 0 || ready || err != nil || minimum.phase != 0 {
		t.Fatal("capture birth failed to invalidate", value, ready, err, minimum)
	}
	// Admit ONLY original registration Begin, then refuse its first 5-record
	// probe. The capture remains genuinely partially registered and epoch-live.
	registration := iterator.OrdinalScanWork{RecordLimit: 1, ByteLimit: 1 << 20}
	if done, err := partial.StepNativeMVCCSnapshotCaptureV6(&registration); done || err != nil || partial.nativeMVCC.capturePhase != 3 || !partial.nativeMVCC.epochLive {
		t.Fatal("partial registration custody lost", done, err)
	}
	for turn := 0; turn < 30; turn++ {
		if value, ready, err := minimum.step(d, nativeMinimumQuantumForTestV6()); value != 0 || ready || err != nil {
			t.Fatal("unregistered capture permitted minimum", value, ready, err)
		}
	}
	beforeCancel := d.snapshotAcquireEpoch.Load()
	if done, err := partial.CloseNativeMVCCSnapshotStepV6(&iterator.OrdinalScanWork{}); done || err != nil || !partial.nativeMVCC.epochLive || d.snapshotAcquireEpoch.Load() != beforeCancel {
		t.Fatal("refused cancel consumed epoch", done, err)
	}
	for turn := 0; turn < 1000; turn++ {
		done, err := partial.CloseNativeMVCCSnapshotStepV6(nativeMinimumQuantumForTestV6())
		if err != nil {
			t.Fatal(err)
		}
		if done {
			closed = true
			break
		}
	}
	if !closed || partial.nativeMVCC.epochLive || d.snapshotAcquireInFlight() != 0 || d.snapshotAcquireEpoch.Load() <= beforeCancel || !partial.cleanupFinished {
		t.Fatal("original cancel did not settle capture/epoch")
	}
	lease.Close()
	if budget.Stats().TotalBytes != budgetBaseline {
		t.Fatal("cancel left original Snapshot allocation")
	}
	budget.Close()
	if budget.Stats().TotalBytes != 0 {
		t.Fatal("closed budget retained its original control")
	}
	value, _, _, _, _ := nativeMinimumDrainForTestV6(t, d, &minimum)
	if value != oldSequence {
		t.Fatal("genuinely held reader was not minimum after cancel", value, oldSequence)
	}
	if got, err := old.Get([]byte("held")); err != nil || string(got) != "original" {
		t.Fatal("held reader changed", got, err)
	}
}

func TestNativeSnapshotMinimumConcurrentReadersV6(t *testing.T) {
	gen := &indexGen{id: 1, registry: lifecycle.NewReaderRegistry()}
	gen.refs.Store(1)
	state := &DBState{CommitSeq: 101}
	d := &DB{snapPool: NewSnapshotPool()}
	d.idx.Store(gen)
	d.state.Store(state)
	d.trackIndex(gen)
	d.publishSnapshotView(gen, state, nil)
	held := d.AcquireSnapshot()
	if held == nil {
		t.Fatal("missing actual original reader")
	}
	defer held.Close()
	done := make(chan bool, 1)
	go func() {
		ok := true
		for i := 0; i < 200; i++ {
			s := d.AcquireSnapshot()
			if s == nil {
				ok = false
				break
			}
			if err := s.Close(); err != nil {
				ok = false
				break
			}
		}
		done <- ok
	}()
	joined := false
	defer func() {
		if !joined {
			<-done
		}
	}()
	var s nativeMVCCSnapshotMinimumV6
	for turn := 0; turn < 200; turn++ {
		value, ready, err := s.step(d, nativeMinimumQuantumForTestV6())
		if err != nil || (ready && value != 101) {
			t.Fatal("concurrent reader escaped held minimum", value, ready, err)
		}
	}
	ok := <-done
	joined = true
	if !ok {
		t.Fatal("actual concurrent Snapshot acquire/close failed")
	}
	if value, _, _, _, _ := nativeMinimumDrainForTestV6(t, d, &s); value != 101 {
		t.Fatal("same observer failed after concurrent readers stopped", value)
	}
}
