package mvcc

import (
	backenddb "github.com/snissn/gomap/TreeDB/db"
	"github.com/snissn/gomap/TreeDB/internal/iterator"
	"github.com/snissn/gomap/TreeDB/internal/rootpublication"
	"github.com/snissn/gomap/TreeDB/lifecycle"
	"testing"
)

// Every original role receives a fresh Q32/1MiB quantum before its reads. No
// cursor/budget/owner is born here; table scan retains only scalar position.
// The selected fixture excludes other producers for this short census series.

func nativeDiagnosticBackendCensusV6(t testing.TB, db interface {
	MaintenanceNativeMinimumGeometryForTestV6(*iterator.OrdinalScanWork) (lifecycle.NativeMinimumGeometryForTestV6, uint64, bool)
	MaintenanceNativePreCursorBackendRoleForTestV6(uint8, *iterator.OrdinalScanWork) (backenddb.NativePreCursorBackendForTestV6, bool)
	MaintenanceNativePreCursorRegistryRoleForTestV6(*rootpublication.NativePreCursorRegistryScanForTestV6, *iterator.OrdinalScanWork) (backenddb.NativePreCursorBackendForTestV6, bool)
}) (g backenddb.NativePreCursorBackendForTestV6) {
	t.Helper()
	var first bool
	same := func(v backenddb.NativePreCursorBackendForTestV6) {
		if !first {
			g = v
			first = true
			return
		}
		if v.Sequence != g.Sequence || v.IndexGeneration != g.IndexGeneration || v.RootPage != g.RootPage || v.RootIncarnation != g.RootIncarnation || v.Debt != g.Debt || v.Seals != g.Seals || v.Visible != g.Visible {
			t.Fatal("precursor original basis changed")
		}
	}
	for role := uint8(0); role <= 8; role++ {
		if role == 5 {
			var scan rootpublication.NativePreCursorRegistryScanForTestV6
			for calls := 0; ; calls++ {
				if calls > 10000 {
					t.Fatal("registry census did not progress")
				}
				v, ready := db.MaintenanceNativePreCursorRegistryRoleForTestV6(&scan, nativeDiagnosticObservationQuantumV6())
				same(v)
				if scan.Drift {
					t.Fatal("registry drift")
				}
				if ready {
					g.Registry = v.Registry
					break
				}
				if scan.Complete {
					t.Fatal("registry census unavailable")
				}
			}
			continue
		}
		v, ready := db.MaintenanceNativePreCursorBackendRoleForTestV6(role, nativeDiagnosticObservationQuantumV6())
		if !ready {
			t.Fatalf("precursor role%d unavailable under original observation quantum", role)
		}
		same(v)
		switch role {
		case 0:
			g.SourceLeaf = v.SourceLeaf
			g.BaseLeafEntries = v.BaseLeafEntries
			g.DirectoryEntries = v.DirectoryEntries
			g.EntryRevisions = v.EntryRevisions
		case 1:
			g.Bank = v.Bank
		case 2:
			g.Growth = v.Growth
		case 3:
			g.Allocator = v.Allocator
		case 4:
			g.PrimaryOwner = v.PrimaryOwner
		case 6:
			g.RegistryOwner = v.RegistryOwner
		case 7:
			g.PrimaryGrowth = v.PrimaryGrowth
		case 8:
			g.DirectoryPathBytes = v.DirectoryPathBytes
			g.IndexFileBytes = v.IndexFileBytes
			g.IndexNameBytes = v.IndexNameBytes
			g.ProofParentBytes = v.ProofParentBytes
		}
	}
	minimum, n, ready := db.MaintenanceNativeMinimumGeometryForTestV6(nativeDiagnosticObservationQuantumV6())
	if !ready || !minimum.Complete || n != g.IndexGenerations {
		t.Fatal("pre-cursor minimum geometry unavailable", minimum, n)
	}
	g.MinimumFallbackSlots = minimum.FallbackSlots
	g.Complete = g.SourceLeaf && g.OuterLeavesOff && g.AdaptiveEncodingOff && g.InternalBaseDeltaOff && (!g.LeafColumnar || g.LeafPrefix) && g.EntryRevisions && g.EmptyValueLog && g.NoLeafGenerations && g.Allocator.Profile.Valid && g.Growth.Complete && g.Growth.DataMetadataAbsent && g.PrimaryGrowth.Complete && !g.PrimaryGrowth.DataMetadataAbsent && g.PrimaryGrowth.MetadataSameExpected && g.Bank.Valid && g.PrimaryOwner.Complete && g.RegistryOwner.Complete && !g.Registry.Closing
	return
}
