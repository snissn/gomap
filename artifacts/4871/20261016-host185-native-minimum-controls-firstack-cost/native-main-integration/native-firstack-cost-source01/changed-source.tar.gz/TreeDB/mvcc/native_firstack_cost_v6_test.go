package mvcc

import (
	"testing"
	"time"
)

// This meter belongs only to the separately selected first-ACK experiment.
// It measures public calls, not phase costs, allocations, or a complete prune.
// Sample storage and all reporting happen outside each measured call interval.
type nativeFirstACKCostSampleV6 struct {
	startingPhase int
	wallNanos     uint64
	workRecords   uint64
	workBytes     uint64
}

type nativeFirstACKCostMeterV6 struct {
	samples                 []nativeFirstACKCostSampleV6
	birthStart, firstACKEnd time.Time
	callNanos, maxCallNanos uint64
	workRecords, workBytes  uint64
	ackReturns              uint64
}

func (m *nativeFirstACKCostMeterV6) record(t testing.TB, phase int, start, end time.Time, stats PruneStats) {
	t.Helper()
	elapsed := end.Sub(start)
	if elapsed < 0 {
		t.Fatal("negative monotonic public-call interval")
	}
	nanos := uint64(elapsed)
	if ^uint64(0)-m.callNanos < nanos || ^uint64(0)-m.workRecords < stats.WorkRecords || ^uint64(0)-m.workBytes < stats.WorkBytes {
		t.Fatal("first-ACK meter counter overflow")
	}
	if len(m.samples) == 0 {
		if phase != -1 {
			t.Fatal("first measured public call was not cursor birth")
		}
		m.birthStart = start
	}
	if stats.Pruned == 1 && stats.Batches == 1 {
		m.ackReturns++
		if m.ackReturns == 1 {
			// Preserve the actual return endpoint before any ACK bookkeeping,
			// cursor cleanup, DB.Close, or reopen oracle.
			m.firstACKEnd = end
		}
	}
	m.callNanos += nanos
	m.maxCallNanos = max(m.maxCallNanos, nanos)
	m.workRecords += stats.WorkRecords
	m.workBytes += stats.WorkBytes
	m.samples = append(m.samples, nativeFirstACKCostSampleV6{phase, nanos, stats.WorkRecords, stats.WorkBytes})
}

func (m *nativeFirstACKCostMeterV6) report(b *testing.B) {
	b.Helper()
	if len(m.samples) == 0 || m.ackReturns != 1 || m.firstACKEnd.IsZero() || m.firstACKEnd.Before(m.birthStart) {
		b.Fatal("missing exact first-ACK measurement", len(m.samples), m.ackReturns)
	}
	wholeNanos := uint64(m.firstACKEnd.Sub(m.birthStart))
	if wholeNanos < m.callNanos {
		b.Fatal("public-call sum exceeds whole birth-to-ACK interval")
	}
	// Go 1.26.3 testing.B.ReportMetric overrides built-in ns/op. The
	// framework timer stays stopped; these manual wall intervals are the metric.
	b.ReportMetric(float64(m.callNanos), "ns/op")
	b.ReportMetric(float64(wholeNanos), "birth-to-ack-ns/op")
	b.ReportMetric(float64(m.maxCallNanos), "max-call-ns/op")
	b.ReportMetric(float64(len(m.samples)), "public-calls/op")
	b.ReportMetric(float64(m.workRecords), "work-records/op")
	b.ReportMetric(float64(m.workBytes), "work-bytes/op")
	b.Logf("first-ACK wall-only totals publicCallNanos=%d wholeBirthToACKNanos=%d maxCallNanos=%d publicCalls=%d workRecords=%d workBytes=%d exactACKReturns=%d startingPhaseLabelsOnly=true noAllocationClaim=true", m.callNanos, wholeNanos, m.maxCallNanos, len(m.samples), m.workRecords, m.workBytes, m.ackReturns)
	for i, sample := range m.samples {
		if sample.startingPhase == -1 {
			b.Logf("first-ACK call=%d start=cursor-birth wallNanos=%d workRecords=%d workBytes=%d", i, sample.wallNanos, sample.workRecords, sample.workBytes)
		} else {
			b.Logf("first-ACK call=%d start-phase=%d wallNanos=%d workRecords=%d workBytes=%d", i, sample.startingPhase, sample.wallNanos, sample.workRecords, sample.workBytes)
		}
	}
}

func BenchmarkNativeSelectedOriginalFirstACKCostV6(b *testing.B) {
	// Reject calibration before any fixture/database effects. Each selected
	// process must run exactly one complete original once-ACK oracle.
	if b.N != 1 {
		b.Fatal("first-ACK diagnostic requires -test.benchtime=1x and b.N==1")
	}
	b.StopTimer()
	b.ResetTimer()
	var meter nativeFirstACKCostMeterV6
	nativeSelectedOriginalSplitDiagnosticV6(b, "once-ack", &meter)
	// Report only after every original Close and reopen assertion succeeds.
	meter.report(b)
}
