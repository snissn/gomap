"""C3-read artifact protocol. Construction only until independently reviewed."""
import base64
import datetime
import hashlib
import itertools
import json
import math
import os
import re
import stat
from pathlib import Path

SCHEMA = "gomap-c3-read-matched-v3"
LOAD_READINESS = {"schema": "gomap-c3-load-readiness-v1", "poll_seconds": 5,
                  "total_wait_seconds": 600, "max_load1": 4.5, "max_load5": 4.5}

def validate_load_readiness(value):
    need(type(value) is dict and set(value) == set(LOAD_READINESS)
         and value["schema"] == LOAD_READINESS["schema"], "missing/invalid load-readiness policy")
    # Integer seconds avoid float/NaN and type-coercion ambiguity. Budget is
    # global, never renewed by a new cell or product. No disabled/unbounded mode.
    need(type(value["poll_seconds"]) is int and value["poll_seconds"] == 5
         and type(value["total_wait_seconds"]) is int and value["total_wait_seconds"] == 600,
         "finite load-readiness poll/global budget required")
    need(all(type(value[k]) is float and value[k] == 4.5 for k in ("max_load1", "max_load5")),
         "fixed conservative load-readiness ceiling required")

def host_nonload_gate(snapshot, policy):
    need(snapshot["uname"]["system"] == policy["system"] and type(snapshot["cpu_count"]) is int
         and snapshot["cpu_count"] == policy["cpu_count"], "host identity changed")
    need(validate_cpu_affinity(snapshot.get("cpu_affinity")) == validate_cpu_affinity(policy.get("cpu_affinity")), "CPU affinity changed")
    for key in ("node", "machine", "release"):
        need(snapshot["uname"][key] == policy[key], "host " + key + " mismatch")
    need(type(snapshot["free_bytes"]) is int and snapshot["free_bytes"] >= policy["min_free_bytes"], "storage admission refused")
    need(snapshot["storage_path"] == policy["tmpdir"] and type(snapshot["storage_device"]) is int
         and snapshot["storage_device"] == policy["tmpdir_device"], "temporary database filesystem changed")
    need(type(snapshot["load"]) is list and len(snapshot["load"]) == 3
         and all(finite_number(x) and x >= 0 for x in snapshot["load"]), "malformed host load")

def host_load_ready(snapshot, policy):
    return snapshot["load"][0] <= policy["max_load1"] and snapshot["load"][1] <= policy["max_load5"]

def host_gate(snapshot, policy):
    host_nonload_gate(snapshot, policy)
    need(host_load_ready(snapshot, policy), "host contention exceeds predeclared bound")

def load_wait_reason(snapshot, host, readiness):
    if not host_load_ready(snapshot, host):
        return "predeclared-host-load-bound"
    if not host_load_ready(snapshot, readiness):
        return "readiness-headroom"
    return None
# Fixed observation protocol, not tunable benchmark controls. Shorter foreign
# processes can escape sampling; no receipt asserts universal host exclusivity.
HOST_ISOLATION = {"schema": "gomap-go-process-census-v1",
                  "ps_fields": "pid,ppid,etimes,pcpu,rss,stat,pgid,comm",
                  "sample_interval_seconds": 0.1, "max_observation_gap_seconds": 0.5,
                  "claim": "sampled endpoints and owned-child lifetime; not universal detection"}
GO_PROCESS_NAMES = frozenset(("go", "compile", "link", "asm", "cgo", "vet", "cover", "test2json", "preprofile"))

def validate_host_isolation(value):
    need(type(value) is dict and value == HOST_ISOLATION, "missing/changed host-isolation contract")

def validate_owner(owner):
    need(type(owner) is dict and set(owner) == {"pid", "ppid", "pgid", "comm"}, "invalid owned PID custody")
    need(all(type(owner[k]) is int and owner[k] > 0 for k in ("pid", "ppid", "pgid")), "invalid owned PID custody")
    need(owner["pid"] == owner["pgid"] and owner["pid"] != owner["ppid"], "invalid owned PID custody")
    need(type(owner["comm"]) is str and owner["comm"] and owner["comm"].isascii() and len(owner["comm"]) <= 15
         and not any(ord(c) < 32 for c in owner["comm"]), "invalid owned process comm")

def linux_comm(binary):
    need(type(binary) is str, "unsupported configured executable comm")
    name = Path(binary).name
    need(name and name.isascii() and not any(ord(c) < 32 for c in name), "unsupported configured executable comm")
    return name[:15]

def benchmark_comms(config):
    return sorted({linux_comm(v["binary"]) for v in config["variants"].values()})

def process_census(text, owner=None, benchmark_names=()):
    """Parse comm only: never use arguments, path allowlists, or load as proof."""
    if owner is not None:
        validate_owner(owner)
    need(type(text) is str and text.strip(), "empty process census")
    seen, foreign = set(), []
    for line in text.splitlines():
        fields = line.split(None, 7)
        need(len(fields) == 8, "malformed process census row")
        pid, ppid, elapsed, cpu, rss, state, pgid, comm = fields
        need(all(re.fullmatch(r"[0-9]+", v) for v in (pid, ppid, elapsed, rss, pgid)), "malformed process census integers")
        pid, ppid, pgid = int(pid), int(ppid), int(pgid)
        need(pid > 0 and pid not in seen, "invalid/duplicate census PID")
        seen.add(pid)
        need(re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", cpu) and math.isfinite(float(cpu)), "malformed census CPU")
        need(re.fullmatch(r"[RSDTtZXI][<NLSsl+]*", state), "malformed census state")
        need(comm.strip() == comm and comm and not any(ord(c) < 32 for c in comm), "malformed census comm")
        if state.startswith("Z"):
            continue
        if owner is not None and pid == owner["pid"]:
            need(ppid == owner["ppid"] and pgid == owner["pgid"] and comm == owner["comm"], "owned PID custody mismatch")
            continue
        # Linux comm truncates to 15 bytes. A visible partial .test suffix at
        # that boundary is conservatively foreign even when not configured.
        truncated_test = len(comm.encode("utf-8")) == 15 and comm.endswith((".t", ".te", ".tes"))
        if comm in GO_PROCESS_NAMES or comm.endswith(".test") or truncated_test or comm in benchmark_names:
            foreign.append({"pid": pid, "ppid": ppid, "pgid": pgid, "state": state, "comm": comm})
    need(not foreign, "foreign active Go/build/test work: " + json.dumps(foreign, sort_keys=True))
    return len(seen)

def validate_census_file(path, expected_sha, owner=None, benchmark_names=()):
    need(Path(path).is_file() and not Path(path).is_symlink(), "missing/nonregular process census")
    need(sha(path) == expected_sha, "process census drift")
    return process_census(Path(path).read_text(), owner, benchmark_names)

def validate_monitor(packet, name, receipt, benchmark_names=()):
    """Offline proof: every raw observation plus the actual wait4 join is bound."""
    path = Path(packet) / (name + "-monitor.json")
    need(path.is_file() and not path.is_symlink(), "missing/tampered monitor proof")
    need(sha(path) == receipt.get("monitor_sha256"), "missing/tampered monitor proof")
    value = json.loads(path.read_text())
    fields = {"contract", "owner", "benchmark_comms", "started_monotonic_ns", "reaped_monotonic_ns", "waited_pid", "wait_status", "samples", "failure", "stopped_on_contamination"}
    need(type(value) is dict and set(value) == fields, "invalid monitor proof fields")
    validate_host_isolation(value["contract"])
    owner = value["owner"]
    need(value["benchmark_comms"] == list(benchmark_names), "unbound configured benchmark comms")
    declared_owner = {"pid": receipt.get("child_pid"), "ppid": receipt.get("collector_pid"), "pgid": receipt.get("child_pgid"), "comm": receipt.get("child_comm")}
    need(owner == declared_owner, "unbound owned PID custody")
    validate_owner(owner)
    validate_owner(declared_owner)
    need(type(receipt.get("command")) is list and receipt["command"] and owner["comm"] == linux_comm(receipt["command"][0]), "owned child command/comm mismatch")
    need(type(value["waited_pid"]) is int and value["waited_pid"] == owner["pid"] == receipt.get("waited_pid"), "missing/invalid child PID join")
    need(type(receipt.get("waited_pid")) is int and type(receipt.get("wait_status")) is int and type(receipt.get("exit_code")) is int, "invalid child wait-status join")
    need(type(value["wait_status"]) is int and value["wait_status"] == receipt["wait_status"] and os.waitstatus_to_exitcode(value["wait_status"]) == receipt["exit_code"], "invalid child wait-status join")
    need(value["failure"] is None and value["stopped_on_contamination"] is False, "contaminated monitor proof")
    start, end = value["started_monotonic_ns"], value["reaped_monotonic_ns"]
    need(type(start) is int and type(end) is int and 0 < start <= end, "invalid monitor lifetime")
    samples = value["samples"]
    need(type(samples) is list and samples, "missing during-child census")
    previous = start
    for index, sample in enumerate(samples):
        need(type(sample) is dict and set(sample) == {"index", "started_monotonic_ns", "completed_monotonic_ns", "path", "sha256"}, "invalid monitor sample")
        need(type(sample["index"]) is int and sample["index"] == index, "missing/reordered monitor sample")
        a, b = sample["started_monotonic_ns"], sample["completed_monotonic_ns"]
        need(type(a) is int and type(b) is int and previous <= a <= b <= end, "invalid monitor sample interval")
        need(a - previous <= int(HOST_ISOLATION["max_observation_gap_seconds"] * 1e9), "monitor observation gap")
        need(b - a <= int(HOST_ISOLATION["max_observation_gap_seconds"] * 1e9), "slow census observation")
        expected = name + "-monitor-" + format(index, "06d") + "-processes.txt"
        need(sample["path"] == expected, "unbound monitor census path")
        validate_census_file(Path(packet) / expected, sample["sha256"], owner, benchmark_names)
        previous = b
    need(end - previous <= int(HOST_ISOLATION["max_observation_gap_seconds"] * 1e9), "monitor observation gap before join")
    expected_paths = {s["path"] for s in samples}
    need({p.name for p in Path(packet).glob(name + "-monitor-*-processes.txt")} == expected_paths, "missing/extra monitor census files")
    return value

def validate_run_processes(packet, name, receipt, benchmark_names=()):
    validate_monitor(packet, name, receipt, benchmark_names)
    # No owned PID exception before spawn or after wait4: a reused PID is foreign.
    for direction in ("before", "after"):
        validate_census_file(Path(packet) / (name + "-" + direction + "-processes.txt"),
                             receipt[direction]["processes_sha256"], benchmark_names=benchmark_names)

def validate_readiness(packet, c, receipts, terminal):
    """Audit complete or failed admission evidence; never accept failed timings."""
    packet = Path(packet)
    path = packet / "readiness.json"
    need(path.is_file() and not path.is_symlink() and sha(path) == terminal.get("readiness_sha256"), "missing/tampered readiness ledger")
    v = json.loads(path.read_text())
    need(type(v) is dict and set(v) == {"policy", "probes", "waits", "blocked_intervals", "total_wait_ns", "status", "failure"}, "invalid readiness fields")
    validate_load_readiness(v["policy"])
    need(v["policy"] == c["load_readiness"], "unbound readiness policy")
    failed = v["status"] == "failed"
    need(v["status"] in ("complete", "failed"), "unfinished readiness ledger")
    if failed:
        need(v["failure"] == {"type": terminal.get("type"), "error": terminal.get("error")}
             and type(terminal.get("retained_runs")) is int and terminal["retained_runs"] == len(receipts), "unbound readiness failure")
    else:
        need(v["failure"] is None and type(terminal.get("runs")) is int and terminal["runs"] == len(receipts), "unbound readiness completion")
    need(all(type(v[k]) is list for k in ("probes", "waits", "blocked_intervals")), "invalid readiness inventory")
    budget = v["policy"]["total_wait_seconds"] * 1_000_000_000
    blocks, total, previous_end = {}, 0, 0
    for b in v["blocked_intervals"]:
        need(type(b) is dict and set(b) == {"label", "first_probe_index", "started_monotonic_ns", "completed_monotonic_ns"}, "invalid readiness blocked interval")
        a, z = b["started_monotonic_ns"], b["completed_monotonic_ns"]
        need(type(b["label"]) is str and b["label"] not in blocks and type(b["first_probe_index"]) is int
             and type(a) is int and type(z) is int and 0 < a <= z and previous_end <= a, "invalid/reordered readiness blocked interval")
        blocks[b["label"]] = dict(b, prior_total=total)
        total += z - a; previous_end = z
    need(type(v["total_wait_ns"]) is int and v["total_wait_ns"] == total, "unbound total readiness wait")
    def spent(at):
        return sum(max(0, min(at, b["completed_monotonic_ns"]) - b["started_monotonic_ns"])
                   for b in blocks.values() if b["started_monotonic_ns"] <= at)
    plan = list(schedule(c)); labels = [label(item) for item in plan]
    variants = {label(item): item["variant"] for item in plan}
    expected_preflight = {name: {"source_tree_sha256": product["source_tree_sha256"], "binary_sha256": product["binary_sha256"], "drift": []} for name, product in c["variants"].items()}
    admitted, expected_files, seen_blocks, previous, wait_index, refresh = [], set(), set(), 0, 0, False
    for index, p in enumerate(v["probes"]):
        need(type(p) is dict and set(p) == {"index", "label", "prefix", "started_monotonic_ns", "completed_monotonic_ns", "host_sha256", "preflight", "decision", "wait_reason", "error"}, "invalid readiness probe")
        need(type(p["index"]) is int and p["index"] == index and len(admitted) < len(labels)
             and p["label"] == labels[len(admitted)], "missing/reordered readiness probe/leaf")
        prefix = p["label"] + "-readiness-" + format(index, "06d")
        need(p["prefix"] == prefix, "unbound readiness probe path")
        a, z = p["started_monotonic_ns"], p["completed_monotonic_ns"]
        need(type(a) is int and type(z) is int and 0 < a <= z and previous <= a, "invalid readiness monotonic interval")
        need(spent(a) < budget, "probe after exhausted readiness budget")
        previous = z
        refused = p["decision"] == "refused"
        need(p["decision"] in ("wait", "refresh", "admitted", "refused"), "unfinished readiness probe")
        if refused:
            need(failed and index == len(v["probes"]) - 1 and p["error"] == v["failure"], "unbound readiness refusal")
            need(p["wait_reason"] is None, "load wait hides readiness refusal")
        else:
            need(p["error"] is None, "readiness error ignored")
        need(p["preflight"] in (None, expected_preflight), "readiness source/binary preflight drift")
        if not refused:
            need((p["preflight"] is not None) == refresh, "missing/stale readiness preflight")
        elif p["preflight"] is not None:
            need(refresh, "unexpected readiness preflight")
        h = None
        if p["host_sha256"] is not None:
            host_path = packet / (prefix + "-host.json")
            need(host_path.is_file() and not host_path.is_symlink() and sha(host_path) == p["host_sha256"], "readiness host snapshot drift")
            h = json.loads(host_path.read_text())
            need(h["source_path"] == c["variants"][variants[p["label"]]]["source"], "readiness source path mismatch")
            expected_files.add(host_path.name)
            for raw in ("meminfo", "cpuinfo", "mounts", "processes"):
                f = packet / (prefix + "-" + raw + ".txt")
                need(f.is_file() and not f.is_symlink() and sha(f) == h[raw + "_sha256"], "readiness raw snapshot drift")
                expected_files.add(f.name)
            error = None
            try:
                host_nonload_gate(h, c["host"])
                validate_census_file(packet / (prefix + "-processes.txt"), h["processes_sha256"], benchmark_names=benchmark_comms(c))
            except (ValueError, KeyError, TypeError) as e:
                error = {"type": type(e).__name__, "error": str(e)}
            exhausted = p["error"] == {"type": "ValueError", "error": "total load-readiness wait budget exhausted"} and spent(z) >= budget
            if refused:
                need(error == p["error"] or p["error"]["type"] == "KeyboardInterrupt" or (error is None and exhausted), "readiness refusal not reproduced")
            else:
                reason = load_wait_reason(h, c["host"], v["policy"])
                decision = "wait" if reason else ("admitted" if refresh else "refresh")
                need(error is None and p["decision"] == decision and p["wait_reason"] == reason, "readiness decision bypasses original gates")
                need(spent(z) < budget, "admission/probe after exhausted readiness budget")
        else:
            need(refused, "missing readiness host evidence")
            # An incomplete capture/preflight can prove failure, never admission.
            expected_files.update(f.name for f in packet.glob(prefix + "-*") if f.is_file() and not f.is_symlink())
        block = blocks.get(p["label"])
        if p["decision"] == "wait" or (block and block["first_probe_index"] == index):
            need(block is not None, "missing readiness blocked interval")
            if p["label"] not in seen_blocks:
                need(block["first_probe_index"] == index and block["started_monotonic_ns"] == a
                     and (p["decision"] == "wait" or (refused and h is not None
                          and load_wait_reason(h, c["host"], v["policy"]) is not None)), "unbound readiness blocked start")
                seen_blocks.add(p["label"])
        if block and p["label"] in seen_blocks:
            need(z <= block["completed_monotonic_ns"], "unaccounted readiness probe time")
        if p["decision"] == "wait" and wait_index < len(v["waits"]) and v["waits"][wait_index].get("after_probe_index") == index:
            w = v["waits"][wait_index]
            need(type(w) is dict and set(w) == {"after_probe_index", "requested_ns", "started_monotonic_ns", "completed_monotonic_ns"}, "invalid readiness wait")
            a, z = w["started_monotonic_ns"], w["completed_monotonic_ns"]
            need(type(w["after_probe_index"]) is int and type(a) is int and type(z) is int and previous <= a <= z
                 and z <= block["completed_monotonic_ns"], "invalid readiness wait interval")
            need(type(w["requested_ns"]) is int and w["requested_ns"] == min(budget - spent(a), v["policy"]["poll_seconds"] * 1_000_000_000)
                 and w["requested_ns"] > 0, "changed readiness polling/budget")
            cancelled = failed and v["failure"]["type"] == "KeyboardInterrupt" and index == len(v["probes"]) - 1
            need(z - a >= w["requested_ns"] or cancelled, "shortened readiness wait")
            previous = z; wait_index += 1
        elif p["decision"] == "wait":
            need(failed and index == len(v["probes"]) - 1
                 and (v["failure"]["type"] == "KeyboardInterrupt" or spent(block["completed_monotonic_ns"]) >= budget), "missing readiness wait")
        if p["decision"] == "admitted":
            need(h is not None and p["preflight"] == expected_preflight, "missing final admission preflight")
            if block:
                need(block["completed_monotonic_ns"] == p["completed_monotonic_ns"], "unbound readiness blocked end")
            admitted.append(p)
            if len(admitted) <= len(receipts):
                r = receipts[len(admitted) - 1]
                need(r["label"] == p["label"] and type(r.get("readiness_probe_index")) is int
                     and r["readiness_probe_index"] == index and r.get("readiness_probe_sha256") == digest(p)
                     and r["before"] == h, "unbound final readiness admission")
                need(type(r.get("spawn_monotonic_ns")) is int and p["completed_monotonic_ns"] <= r["spawn_monotonic_ns"], "child started before readiness admission")
                monitor = json.loads((packet / (r["label"] + "-monitor.json")).read_text())
                need(r["spawn_monotonic_ns"] <= monitor["started_monotonic_ns"], "unbound readiness/spawn interval")
                previous = monitor["reaped_monotonic_ns"]
        refresh = p["decision"] == "refresh"
    need(seen_blocks == set(blocks) and wait_index == len(v["waits"]), "missing/extra readiness blocked intervals/waits")
    need({p.name for p in packet.glob("*-readiness-*")} == expected_files, "missing/extra readiness raw evidence")
    need(len(receipts) <= len(admitted) <= len(receipts) + int(failed), "missing/extra readiness admissions")
    if not failed:
        need(len(admitted) == len(labels) and total < budget, "incomplete/exhausted readiness campaign")
    elif total >= budget:
        need(v["failure"] == {"type": "ValueError", "error": "total load-readiness wait budget exhausted"}
             or v["failure"]["type"] == "KeyboardInterrupt", "ignored readiness budget exhaustion")
    return {"probes": len(v["probes"]), "waits": len(v["waits"]), "blocked_intervals": len(blocks), "total_wait_ns": total, "status": v["status"]}

PROFILES = {"no_wal_fast", "command_wal_relaxed", "command_wal_durable"}
MODES = {"append_only", "btree", "cow_btree"}
LAYOUTS = {"inline", "pointer"}
WORKLOADS = {"point", "group_all_versions", "concurrent"}
CONTROLS = {"GOROOT", "GOCACHE", "GOMODCACHE", "GOWORK", "GOMAXPROCS", "GOGC", "GOMEMLIMIT", "GOFLAGS", "TMPDIR"}
C3_PACKAGE = "github.com/snissn/gomap/TreeDB/mvcc/cowbench"
C3_PRODUCT = "github.com/snissn/gomap/TreeDB/mvcc"
C3_HARNESS_ROOTS = ("TreeDB/mvcc/cowbench/", "TreeDB/internal/cowbench/")
C3_FIXTURE = "TreeDB/mvcc/cowbench/cow_c3_public_bench_test.go"
C3_HARNESS_FILES = (C3_FIXTURE, "TreeDB/mvcc/cowbench/cow_public_admission_test.go",
                    "TreeDB/mvcc/cowbench/leak_test.go", "TreeDB/internal/cowbench/admission.go")
C4_PACKAGE = "github.com/snissn/gomap/TreeDB/mvcc/cowsustained"
HARNESS_PACKAGES = {"c3": C3_PACKAGE, "c4": C4_PACKAGE}
HARNESS_ROOTS = {"c3": C3_HARNESS_ROOTS,
                 "c4": ("TreeDB/mvcc/cowsustained/", "TreeDB/internal/cowbench/")}
HARNESS_FILES = {"c3": C3_HARNESS_FILES,
                 "c4": ("TreeDB/mvcc/cowsustained/cow_c4_public_bench_test.go",
                        "TreeDB/mvcc/cowsustained/cow_c4_public_fixture_test.go",
                        "TreeDB/mvcc/cowsustained/leak_test.go", "TreeDB/internal/cowbench/admission.go")}
C3_ITERATIONS, C3_WARMUP_ITERATIONS = 1024, 128

def variant_paths(variant, *, live=False):
    """Keep declared custody paths verbatim; offline packets need no live paths."""
    paths = {}
    for key in ("source", "binary", "manifest", "build_receipt"):
        value = variant[key]
        need(isinstance(value, str), "noncanonical variant path " + key)
        path = Path(value)
        need(path.is_absolute() and path.anchor == "/" and str(path) == value and ".." not in path.parts,
             "noncanonical variant path " + key)
        if live:
            need(path.exists() and not path.is_symlink() and path.resolve() == path,
                 "noncanonical live variant path " + key)
        paths[key] = path
    return paths

def variant_git_ids(variant):
    head, tree = variant["production_commit"], variant["production_git_tree"]
    need(isinstance(head, str) and isinstance(tree, str)
         and re.fullmatch(r"(?:[0-9a-f]{40}|[0-9a-f]{64})", head)
         and re.fullmatch(r"(?:[0-9a-f]{40}|[0-9a-f]{64})", tree)
         and len(head) == len(tree), "missing exact Git revision/tree")

def fixture_manifest(fixtures, ident):
    """Bind the declared workload bytes in each retained source inventory."""
    files = {item["path"]: item["sha256"] for item in ident["files"]}
    for fixture in fixtures:
        need(files.get(fixture["path"]) == fixture["sha256"],
             "fixture differs from frozen source: " + fixture["path"])

def validate_harness_fixtures(fixtures, suite="c3"):
    need(suite in HARNESS_ROOTS, "unknown ordinary build suite")
    message = "canonical " + suite.upper() + " fixture required"
    need(type(fixtures) is list and fixtures, message)
    paths = []
    for item in fixtures:
        need(type(item) is dict and set(item) == {"path", "sha256", "mode"}
             and type(item["path"]) is str
             and any(item["path"].startswith(root) for root in HARNESS_ROOTS[suite])
             and ".." not in Path(item["path"]).parts
             and str(Path(item["path"])) == item["path"]
             and type(item["sha256"]) is str and re.fullmatch(r"[0-9a-f]{64}", item["sha256"])
             and type(item["mode"]) is int and item["mode"] in (0o644, 0o755),
             message)
        paths.append(item["path"])
    need(paths == sorted(set(paths)) and set(HARNESS_FILES[suite]) <= set(paths), message)

def git_object_id(kind, raw, object_format):
    need(object_format in ("sha1", "sha256"), "unsupported Git object format")
    return hashlib.new(object_format, kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()

def git_file_bytes(authority, raw, object_format, path):
    """Prove raw bytes against a receipt-verified Git blob and its manifest."""
    width = {"sha1": 40, "sha256": 64}.get(object_format)
    need(width is not None, "unsupported Git object format")
    blob = authority.get("git_blob")
    need(isinstance(blob, str) and re.fullmatch(r"[0-9a-f]{%d}" % width, blob),
         "invalid Git file blob authority: " + path)
    need(git_object_id("blob", raw, object_format) == blob,
         "retained Git blob hash mismatch: " + path)
    need(hashlib.sha256(raw).hexdigest() == authority.get("sha256") and len(raw) == authority.get("bytes"),
         "Git blob content differs from source manifest: " + path)

def retained_tooling(packet, ident, scripts):
    """Retained scripts are already raw blob proofs; they are not Go inputs."""
    files = {item["path"]: item for item in ident["files"]}
    for name, value in scripts.items():
        path = "scripts/cow_c3_read/" + name
        need(path in files and files[path]["sha256"] == value,
             "retained tooling differs from frozen source: " + name)
        git_file_bytes(files[path], (Path(packet) / name).read_bytes(),
                       ident["original_manifest"]["git_object_format"], path)

def repository_inputs(closure, ident):
    """Bind every selected repository input to this product's Git authority."""
    need(isinstance(ident, dict) and isinstance(ident.get("files"), list) and ident["files"],
         "repository compiler source authority missing")
    need(all(isinstance(item, dict) and isinstance(item.get("path"), str) for item in ident["files"]),
         "invalid Git source authority paths")
    files = {item["path"]: item for item in ident["files"]}
    need(len(files) == len(ident["files"]), "duplicate Git source authority paths")
    object_format = ident.get("original_manifest", {}).get("git_object_format")
    need(object_format in ("sha1", "sha256"), "unsupported Git object format")
    for key, item in closure.items():
        if not key.startswith("REPO/"):
            continue
        path = key[5:]
        need(path in files, "repository compiler input missing from Git source authority: " + path)
        authority = files[path]
        mode = {"100644": 0o644, "100755": 0o755}.get(authority.get("git_mode"))
        need(mode is not None and {"sha256", "bytes"} <= set(authority),
             "invalid Git compiler input authority: " + path)
        expected = {"sha256": authority["sha256"], "bytes": authority["bytes"], "mode": mode}
        file_identity(expected)
        proof = item.get("git_blob_bytes")
        need(isinstance(proof, str), "missing retained repository Git blob proof: " + path)
        try:
            raw = base64.b64decode(proof, validate=True)
        except (ValueError, TypeError):
            raise ValueError("invalid retained repository Git blob proof: " + path) from None
        need(base64.b64encode(raw).decode("ascii") == proof,
             "noncanonical retained repository Git blob proof: " + path)
        git_file_bytes(authority, raw, object_format, path)
        need({field: item[field] for field in expected} == expected,
             "repository compiler input differs from Git source authority: " + path)

def harness_manifest(packages, closure, ident, source, environment, suite="c3"):
    """Bind all standalone harness inputs while allowing ordinary product deltas."""
    need(suite in HARNESS_ROOTS, "unknown ordinary build suite")
    repository_inputs(closure, ident)
    roots = [p for p in packages if p.get("ImportPath") == C3_PRODUCT and not p.get("ForTest")]
    need(len(roots) == 1 and type(roots[0].get("Deps")) is list, "ordinary product dependency closure missing")
    products = set(roots[0]["Deps"]) | {C3_PRODUCT}
    product_packages = [p for p in packages if p.get("ImportPath") in products and not p.get("ForTest")]
    need({p["ImportPath"] for p in product_packages} == products, "incomplete ordinary product dependency closure")
    product_paths, _ = selected_input_paths(product_packages, source, environment)
    repo = {key[5:] for key in set(closure) - set(product_paths) if key.startswith("REPO/")}
    need(repo and all(any(path.startswith(root) for root in HARNESS_ROOTS[suite]) for path in repo),
         "undeclared repository test harness input")
    files = {f["path"]: f for f in ident["files"]}
    inventory = {path for path in files if any(path.startswith(root) for root in HARNESS_ROOTS[suite])}
    need(repo == inventory, "complete " + suite.upper() + " harness source/selected-input closure mismatch")
    result = [{"path": path, **{field: closure["REPO/" + path][field] for field in ("sha256", "mode")}}
              for path in sorted(inventory)]
    validate_harness_fixtures(result, suite)
    return result

def matched_products(variants):
    """C3 compares two products; candidate-only construction has no such rule."""
    baseline, candidate = variants["baseline"], variants["candidate"]
    for key in ("production_commit", "production_git_tree", "source_tree_sha256", "binary_sha256"):
        need(baseline[key] != candidate[key], "matched products must have distinct " + key)
    left, right = variant_paths(baseline), variant_paths(candidate)
    for a in left.values():
        for b in right.values():
            need(not a.is_relative_to(b) and not b.is_relative_to(a), "matched products must have independent custody")
    a, b = left["build_receipt"].parent, right["build_receipt"].parent
    need(not a.is_relative_to(b) and not b.is_relative_to(a), "matched products must have independent build custody")

def validate_toolchain(value):
    need(set(value) == {"go_binary_sha256", "executables", "headers", "go_env"}
         and isinstance(value["go_binary_sha256"], str)
         and re.fullmatch(r"[0-9a-f]{64}", value["go_binary_sha256"]), "invalid Go toolchain inventory")
    records = value["executables"]
    need(isinstance(records, list) and records, "empty Go toolchain inventory")
    paths = []
    for item in records:
        need(set(item) == {"path", "sha256", "bytes", "mode"}, "invalid Go toolchain executable")
        path = Path(item["path"])
        need(not path.is_absolute() and str(path) == item["path"] and ".." not in path.parts
             and path.parts[:2] == ("pkg", "tool") and len(path.parts) >= 4,
             "invalid Go toolchain executable path")
        need(isinstance(item["sha256"], str) and re.fullmatch(r"[0-9a-f]{64}", item["sha256"])
             and type(item["bytes"]) is int and item["bytes"] > 0
             and type(item["mode"]) is int and 0 < item["mode"] <= 0o777 and item["mode"] & 0o111,
             "invalid Go toolchain executable identity")
        paths.append(item["path"])
    need(paths == sorted(set(paths)) and {"compile", "link", "asm"} <= {Path(p).name for p in paths},
         "incomplete/duplicate Go toolchain inventory")
    headers = value["headers"]
    need(isinstance(headers, list) and headers, "empty Go assembler header inventory")
    paths = []
    for item in headers:
        need(set(item) == {"path", "sha256", "bytes", "mode"}, "invalid Go assembler header")
        path = Path(item["path"])
        need(not path.is_absolute() and str(path) == item["path"] and ".." not in path.parts
             and path.parts[:2] == ("pkg", "include") and len(path.parts) >= 3,
             "invalid Go assembler header path")
        file_identity(item)
        paths.append(item["path"])
    need(paths == sorted(set(paths)) and {"pkg/include/textflag.h", "pkg/include/funcdata.h"} <= set(paths),
         "incomplete/duplicate Go assembler header inventory")
    go_env = value["go_env"]
    need(isinstance(go_env, dict) and set(go_env) == {"path", "sha256", "bytes", "mode"}
         and go_env["path"] == "go.env", "invalid GOROOT go.env inventory")
    file_identity(go_env)
    return digest(value)

def toolchain_inventory(goroot):
    """Observe every Go tool executable without executing or trusting the launcher."""
    root = Path(goroot)
    need(root.is_absolute() and not root.is_symlink() and root.resolve() == root, "noncanonical GOROOT")
    go, directory = root / "bin/go", root / "pkg/tool"
    need(go.is_file() and not go.is_symlink() and go.resolve() == go and go.stat().st_mode & 0o111,
         "invalid Go launcher custody")
    need(directory.is_dir() and not directory.is_symlink() and directory.resolve() == directory,
         "invalid Go tool directory custody")
    records = []
    for path in sorted(directory.rglob("*")):
        need(not path.is_symlink(), "symlink in Go tool directory")
        mode = path.stat().st_mode
        if stat.S_ISDIR(mode):
            continue
        need(stat.S_ISREG(mode), "nonregular Go tool input")
        if mode & 0o111:
            records.append({"path": path.relative_to(root).as_posix(), "sha256": sha(path),
                            "bytes": path.stat().st_size, "mode": stat.S_IMODE(mode)})
    directory = root / "pkg/include"
    need(directory.is_dir() and not directory.is_symlink() and directory.resolve() == directory,
         "invalid Go assembler include directory custody")
    headers = []
    for path in sorted(directory.rglob("*")):
        need(not path.is_symlink(), "symlink in Go assembler include directory")
        mode = path.stat().st_mode
        if stat.S_ISDIR(mode):
            continue
        need(stat.S_ISREG(mode), "nonregular Go assembler header")
        headers.append({"path": path.relative_to(root).as_posix(), "sha256": sha(path),
                        "bytes": path.stat().st_size, "mode": stat.S_IMODE(mode)})
    go_env = root / "go.env"
    need(go_env.is_file() and not go_env.is_symlink() and go_env.resolve() == go_env,
         "invalid GOROOT go.env custody")
    value = {"go_binary_sha256": sha(go), "executables": records, "headers": headers,
             "go_env": {"path": "go.env", "sha256": sha(go_env), "bytes": go_env.stat().st_size,
                        "mode": stat.S_IMODE(go_env.stat().st_mode)}}
    validate_toolchain(value)
    return value

def build_toolchain(build, frozen, inventory):
    need(build["go_version"] == frozen["go_version"]
         and build["go_binary_sha256"] == frozen["go_binary_sha256"], "toolchain mismatch")
    need(inventory["go_binary_sha256"] == frozen["go_binary_sha256"]
         and validate_toolchain(inventory) == build["toolchain_identity"] == frozen["toolchain_identity"],
         "Go toolchain inventory mismatch")

def validate_no_cgo(packages):
    need(packages and not any(package.get("CgoFiles") for package in packages), "compiled Cgo inputs forbidden")

def file_identity(item):
    need(isinstance(item.get("sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", item["sha256"])
         and type(item.get("bytes")) is int and item["bytes"] >= 0
         and type(item.get("mode")) is int and 0 <= item["mode"] <= 0o777,
         "invalid persistent input identity")

def selected_input_paths(packages, source, environment):
    """Derive finite persistent inputs and recognized generated test-main inputs.

    Paths are retained for same-build custody; normalized keys separate repository
    product deltas from actual external compiler inputs and survive relocation.
    """
    source, goroot, cache = Path(source), Path(environment["GOROOT"]), Path(environment["GOCACHE"])
    files, generated = {}, []
    def add(key, path):
        path = Path(path)
        need(path.is_absolute() and ".." not in path.parts, "invalid selected input path")
        need(key not in files or files[key] == str(path), "conflicting selected input custody")
        files[key] = str(path)
    for package in packages:
        directory = Path(package["Dir"])
        module = package.get("Module", {})
        effective = module.get("Replace", module)
        external = not package.get("Standard") and not module.get("Main") and effective.get("Version")
        module_key = digest({k: effective[k] for k in ("Path", "Version", "Sum", "GoModSum") if k in effective})
        for category in ("GoFiles", "CgoFiles", "CFiles", "HFiles", "SFiles", "SysoFiles", "EmbedFiles", "CompiledGoFiles"):
            for name in package.get(category, []):
                path = directory / name
                # go list -test emits a derived test main in GOCACHE. No ordinary
                # missing Go/header/assembly input is granted this exception.
                if (package.get("ImportPath", "").endswith(".test") and category in ("GoFiles", "CompiledGoFiles")
                        and Path(name).is_absolute() and path.is_relative_to(cache) and path.name.endswith("-d")):
                    generated.append({"package": package["ImportPath"], "category": category,
                                      "kind": "go-list-generated-test-main", "path": str(path)})
                    continue
                if path.is_relative_to(source):
                    key = "REPO/" + path.relative_to(source).as_posix()
                elif package.get("Standard") and path.is_relative_to(goroot):
                    key = "GOROOT/" + path.relative_to(goroot).as_posix()
                elif external and path.is_relative_to(Path(effective["Dir"])):
                    key = "MODULE/" + module_key + "/" + path.relative_to(Path(effective["Dir"])).as_posix()
                else:
                    need(False, "unrecognized persistent compiler input: " + str(path))
                add(key, path)
        if external:
            need(effective.get("GoMod"), "selected module metadata missing")
            add("MODULE_META/" + module_key + "/go.mod", effective["GoMod"])
    for name in ("go.mod", "go.sum"):
        add("REPO/" + name, source / name)
    need(files and any(key.startswith("GOROOT/") for key in files), "empty selected external input closure")
    return dict(sorted(files.items())), sorted(generated, key=lambda item: (item["package"], item["category"], item["path"]))

def selected_inputs(packages, source, environment):
    paths, generated = selected_input_paths(packages, source, environment)
    result = {}
    for key, name in paths.items():
        path = Path(name)
        need(path.is_file() and not path.is_symlink() and path.resolve() == path,
             "missing/nonregular/noncanonical persistent compiler input: " + name)
        raw = path.read_bytes()
        result[key] = {"path": name, "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw),
                       "mode": stat.S_IMODE(path.stat().st_mode)}
        if key.startswith("REPO/"):
            result[key]["git_blob_bytes"] = base64.b64encode(raw).decode("ascii")
    return result, generated

def build_inputs(build, frozen, packages, before, after, generated, source, ident=None):
    """Validate retained actual inputs offline, without reading original host paths."""
    paths, expected_generated = selected_input_paths(packages, source, build["environment"])
    need(set(before) == set(after) == set(paths), "selected persistent input closure mismatch")
    for key, name in paths.items():
        for closure in (before, after):
            item = closure[key]
            fields = {"path", "sha256", "bytes", "mode"}
            if key.startswith("REPO/"):
                need("git_blob_bytes" in item, "missing retained repository Git blob proof: " + key[5:])
                fields.add("git_blob_bytes")
            need(set(item) == fields and item["path"] == name,
                 "selected persistent input custody mismatch")
            file_identity(item)
    need(before == after, "selected persistent inputs drift during build")
    need(generated == expected_generated, "unrecognized generated compiler inputs")
    external = {key: {k: value[k] for k in ("sha256", "bytes", "mode")}
                for key, value in after.items() if not key.startswith("REPO/")}
    need(digest(external) == build["external_input_identity"] == frozen["external_input_identity"],
         "actual external compiler inputs differ")
    for field, artifact in (("compiled_inputs_before_sha256", "compiled_inputs_before"),
                            ("compiled_input_closure_sha256", "compiled_input_closure"),
                            ("generated_nonpersistent_inputs_sha256", "generated_nonpersistent_inputs")):
        need(build[field] == build["artifacts"][artifact]["sha256"], "unbound selected compiler input artifact")
    package = frozen.get("cases", [{}])[0].get("package")
    suites = {name: suite for suite, name in HARNESS_PACKAGES.items()}
    if package in suites:
        suite = suites[package]
        need(ident is not None, suite.upper() + " harness source authority missing")
        need(build.get("suite") == suite, "build/harness suite mismatch")
        harness = harness_manifest(packages, after, ident, source, build["environment"], suite)
        need(harness == frozen["fixtures"] and build.get("harness_input_identity") == digest(harness),
             "complete frozen " + suite.upper() + " harness mismatch")
    else:
        repository_inputs(after, ident)
    return external

def case_names(case):
    shape = "forced_pointer" if case["layout"] == "pointer" else "inline"
    leaf = "group_versions" if case["workload"] == "group_all_versions" else case["workload"]
    parts = (case["profile"], case["mode"], shape, leaf)
    return "-".join(parts), "/".join(("BenchmarkC3PublicReadAdmission",) + parts)

def need(value, message):
    if not value:
        raise ValueError(message)

def process_environment(controls):
    """Build the complete child environment without reading ambient settings."""
    need(set(controls) == CONTROLS and all(isinstance(v, str) for v in controls.values()),
         "missing/extra/non-string process controls")
    cache = Path(controls["GOMODCACHE"])
    need(cache.is_absolute() and str(cache) == controls["GOMODCACHE"] and ".." not in cache.parts
         and cache.parent.parent != Path("/"), "unresolved GOMODCACHE/GOPATH")
    return dict(controls, PATH=os.defpath, GOENV="off", GOTOOLCHAIN="local",
                GOPATH=str(cache.parent.parent), LC_ALL="C", CGO_ENABLED="0",
                GOAMD64="v1", GOEXPERIMENT="")

def validate_go_environment(observed, env):
    # Go's cfg.EnvFile reports the disabled GOENV=off setting as an empty
    # filename in `go env -json`; the actual process environment still is off.
    for key in ("GOROOT", "GOFLAGS", "GOWORK", "GOCACHE", "GOMODCACHE", "GOENV", "GOTOOLCHAIN", "GOPATH", "CGO_ENABLED", "GOAMD64", "GOEXPERIMENT"):
        expected = "" if key == "GOENV" else env[key]
        need(observed[key] == expected, "actual go env mismatch " + key)
    need(observed["GOOS"] == "linux" and observed["GOARCH"] == "amd64", "actual build platform mismatch")

def build_target(suite="c3"):
    need(suite in ("c3", "c4"), "unknown ordinary build suite")
    return "./" + HARNESS_PACKAGES[suite].removeprefix("github.com/snissn/gomap/")

def build_command(go, binary, suite="c3"):
    return [str(go), "test", "-c", "-trimpath", "-o", str(binary), build_target(suite)]

def module_command(go, suite="c3"):
    return [str(go), "list", "-compiled", "-deps", "-test", "-json", build_target(suite)]

def validate_build_command(build, go, binary, suite="c3"):
    need(type(build.get("exit_code")) is int and build["exit_code"] == 0
         and build.get("suite") == suite and build.get("command") == build_command(go, binary, suite), "actual ordinary build invocation mismatch")
    need(build.get("module_producer_command") == module_command(go, suite), "actual module producer invocation mismatch")

ACK_CONTRACT = "CommitRelaxed; durable WAL append/sync=1/1, relaxed=1/0, NoWAL=0/0; exact profile counts required"
TIMED_SCOPE = "actual calls, owned point output, borrowed complete EntryView scan, validation, clocks; seed/physical layout probes/stats/Close excluded"

def workload_contract(workload):
    need(workload in WORKLOADS, "unknown workload")
    return {"keys": ["c3-a", "c3-ab"], "seed_timestamps": [10, 20], "read_timestamp": 100,
            "value_bytes": 256, "value_byte": 99, "history_growth": False,
            "writers": 1, "point_readers": 0 if workload == "group_all_versions" else 1,
            "scan_readers": 0 if workload == "point" else 1,
            "writer_records_per_call": 1 if workload == "point" else 4,
            "concurrency": workload == "concurrent", "clock_calls_retained": True,
            "read_overlap_is_internal_preparation_proof": False, "physical_layout_records": 4,
            "layout_probes_outside_counter_boundaries": True}

def work_contract(case, phase):
    need(phase in ("warmup", "measured"), "unknown workload phase")
    return case["workload_contract"]

def workload_metrics(workload):
    contract = workload_contract(workload)
    point, scan = contract["point_readers"], contract["scan_readers"]
    return {"point_calls/op": point, "scan_calls/op": scan, "visited/op": 2 * scan,
            "output/op": point + 2 * scan}, ["writer"] + (["point"] if point else []) + (["scan"] if scan else [])

def metric_contract(profile, layout, workload, mode):
    need(profile in PROFILES and layout in LAYOUTS and mode in MODES, "unknown metric dimensions")
    work, latency = workload_metrics(workload)
    rules = {"ns/op": {"min": 1}, "B/op": {"min": 1}, "allocs/op": {"min": 1},
             "writer_ops/s": {"min": 0.000001}, "reader_ops/s": {"min": 0.000001},
             "readers_while_writer_active/op": {"min": 0, "max": 2} if workload == "concurrent" else {"eq": 0},
             "wal_appends/op": {"eq": 0 if profile == "no_wal_fast" else 1},
             "wal_syncs/op": {"eq": 1 if profile == "command_wal_durable" else 0},
             "close_ok": {"eq": 1}}
    rules.update({unit: {"eq": count} for unit, count in work.items()})
    rules.update({"layout_expected_records": {"eq": 4},
                  "ack_routing_before_ok": {"eq": 1}, "ack_routing_after_ok": {"eq": 1}})
    for phase in ("before", "after"):
        rules["layout_" + phase + "_inline"] = {"eq": 4 if layout == "inline" else 0}
        rules["layout_" + phase + "_pointer"] = {"eq": 4 if layout == "pointer" else 0}
        for name in ("wal_appends", "wal_syncs"):
            rules[name + "_" + phase] = {"eq": 0} if profile == "no_wal_fast" else {"min": 0, "integer": True}
    for name in ("snapshot_rotations/op", "rotated_shards/op", "enqueued_records/op"):
        rules[name] = {"eq": 0} if mode == "cow_btree" else {"min": 0}
    comparisons = {"ns/op": "lower", "B/op": "lower", "allocs/op": "lower",
                   "writer_ops/s": "higher", "reader_ops/s": "higher"}
    if workload == "concurrent":
        for group in ("point", "scan"):
            rules[group + "_phase_elapsed_ns"] = {"min": 1}
            rules[group + "_phase_ops/s"] = {"min": 0.000001}
            comparisons[group + "_phase_elapsed_ns"] = "lower"
            comparisons[group + "_phase_ops/s"] = "higher"
    for group in latency:
        for p in (50, 95, 99):
            name = f"{group}_p{p}_ns"
            rules[name] = {"min": 1}
            comparisons[name] = "lower"
    if mode == "cow_btree":
        for name in ("capture_calls_total", "prepare_calls_total", "publications_total"):
            rules["cow_" + name + "/op"] = {"min": 1}
        for name in ("total_bytes", "peak_bytes", "external_leases"):
            rules["cow_end_" + name] = {"min": 1, "integer": True}
        rules["cow_end_views"] = {"eq": 0}
        rules["cow_end_active_cuts"] = {"eq": 1}
    return rules, comparisons

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()

def identity(path):
    # Reuses the C2 sorted sha256 + two spaces + relative path identity primitive;
    # supports both list manifests and the root's sparse {path:{sha256,bytes}} form.
    data = json.loads(Path(path).read_text())
    files = data["files"]
    if isinstance(files, dict):
        files = [{"path": p, "sha256": v["sha256"] if isinstance(v, dict) else v}
                 for p, v in sorted(files.items())]
    need(files and len({f["path"] for f in files}) == len(files), "empty/duplicate source paths")
    for item in files:
        p = Path(item["path"])
        need(not p.is_absolute() and ".." not in p.parts and str(p) == item["path"], "unsafe source path")
        need(re.fullmatch(r"[0-9a-f]{64}", item["sha256"]), "invalid source hash")
    encoded = "".join(f'{f["sha256"]}  {f["path"]}\n' for f in sorted(files, key=lambda x: x["path"]))
    calculated = hashlib.sha256(encoded.encode()).hexdigest()
    # Other historical manifest digests may use another derivation; bind them
    # separately instead of silently treating them as this tree digest.
    return {"original_manifest": data, "manifest_sha256": sha(path), "files": files,
            "tree_sha256": calculated, "derivation": "sorted sha256 + two spaces + path + newline"}

def drift(source, ident):
    source = Path(source)
    expected = {f["path"] for f in ident["files"]}
    actual = {p.relative_to(source).as_posix() for p in source.rglob("*") if p.is_file() or p.is_symlink()}
    wrong = []
    for item in ident["files"]:
        p = source / item["path"]
        wrong_mode = p.is_file() and "git_mode" in item and ("100755" if p.stat().st_mode & 0o111 else "100644") != item["git_mode"]
        if p.is_symlink() or not p.is_file() or sha(p) != item["sha256"] or wrong_mode:
            wrong.append(item["path"])
    return wrong + ["EXTRA:" + p for p in sorted(actual - expected)]

def finite_number(value):
    # JSON booleans are integers in Python; admission must keep them distinct.
    # Arbitrarily large JSON integers are finite without a float conversion.
    return type(value) is int or (type(value) is float and math.isfinite(value))

def validate_cpu_affinity(mask):
    need(type(mask) is list and len(mask) >= 4
         and all(type(cpu) is int and cpu >= 0 for cpu in mask)
         and mask == sorted(set(mask)), "CPU affinity must be sorted distinct nonnegative integers with at least four CPUs")
    return mask

def cpu_affinity():
    need(callable(getattr(os, "sched_getaffinity", None)), "CPU affinity observation unavailable")
    try:
        mask = sorted(os.sched_getaffinity(0))
    except OSError as error:
        raise ValueError("CPU affinity observation unavailable") from error
    return validate_cpu_affinity(mask)

def config(path):
    c = json.loads(Path(path).read_text())
    need(c["schema"] == SCHEMA and c["status"] == "frozen-approved", "unfrozen configuration")
    validate_host_isolation(c.get("host_isolation"))
    validate_load_readiness(c.get("load_readiness"))
    need(isinstance(c["coordinator_acceptance"], str) and c["coordinator_acceptance"], "missing coordinator freeze acceptance")
    need(type(c["cycles"]) is int and c["cycles"] == 3 and c["order"] == ["baseline", "candidate", "candidate", "baseline"], "requires three ABBA cycles")
    need(type(c["timeout_seconds"]) is int and c["timeout_seconds"] > 0, "positive integer timeout required")
    need(c["environment"]["GOMAXPROCS"] == "4" and c["environment"]["GOWORK"] == "off", "runtime control mismatch")
    need(set(c["environment"]) == CONTROLS, "missing/extra explicit environment controls")
    need(all(isinstance(v, str) for v in c["environment"].values()), "unresolved environment controls")
    need(c["environment"]["GOFLAGS"] == "", "GOFLAGS must be empty")
    process_environment(c["environment"])
    need(isinstance(c["go_version"], str) and c["go_version"], "missing frozen Go version")
    for key in ("go_binary_sha256", "toolchain_identity", "external_input_identity"):
        need(isinstance(c[key], str) and re.fullmatch(r"[0-9a-f]{64}", c[key]), "missing frozen " + key)
    need(c["go_binary"] == str(Path(c["environment"]["GOROOT"]) / "bin/go"), "unbound Go launcher path")
    need(c["host"]["system"] == "Linux" and type(c["host"]["cpu_count"]) is int and c["host"]["cpu_count"] >= 4, "Linux host contract")
    validate_cpu_affinity(c["host"].get("cpu_affinity"))
    tmpdir = Path(c["environment"]["TMPDIR"])
    need(tmpdir.is_absolute() and str(tmpdir) == c["environment"]["TMPDIR"] and ".." not in tmpdir.parts, "unresolved TMPDIR")
    need(c["host"]["tmpdir"] == str(tmpdir) and type(c["host"]["tmpdir_device"]) is int and c["host"]["tmpdir_device"] >= 0, "unbound temporary database filesystem")
    for key in ("max_load1", "max_load5"):
        need(finite_number(c["host"][key]) and c["host"][key] > 0, "missing host admission bound")
    need(type(c["host"]["min_free_bytes"]) is int and c["host"]["min_free_bytes"] > 0, "missing host admission bound")
    noise = c["noise_policy"]
    for key in ("max_spread_fraction", "material_regression_fraction", "minimum_effect_fraction"):
        need(finite_number(noise[key]) and 0 < noise[key] < 1, "predeclare noise/regression bounds")
    need(noise["exclusions"] == "none; retain and stop on contamination", "no post-hoc exclusions")
    need(c["fixtures"] and c["comparison_metrics"] and c["cases"], "missing frozen fixture/metric/cases")
    validate_harness_fixtures(c["fixtures"])
    need(set(c["variants"]) == {"baseline", "candidate"}, "two exact variants required")
    for variant in c["variants"].values():
        variant_git_ids(variant)
        variant_paths(variant)
        for key in ("binary_sha256", "source_tree_sha256"):
            need(isinstance(variant[key], str) and re.fullmatch(r"[0-9a-f]{64}", variant[key]),
                 "missing exact product hash " + key)
    matched_products(c["variants"])
    cases = c["cases"]
    need(len({x["id"] for x in cases}) == len(cases), "duplicate case ids")
    coverage = {(x["profile"], x["layout"], x["workload"], x["mode"]) for x in cases}
    need(coverage == set(itertools.product(PROFILES, LAYOUTS, WORKLOADS, MODES)), "incomplete/extra matrix")
    need(len(cases) == len(coverage), "duplicate matrix cell")
    need(len({x["benchmark"] for x in cases}) == len(cases), "duplicate benchmark leaves")
    for x in cases:
        need(re.fullmatch(r"[A-Za-z0-9_.-]+", x["id"]), "unsafe case id")
        expected_id, expected_benchmark = case_names(x)
        need(x["id"] == expected_id and x["benchmark"] == expected_benchmark, "benchmark/id does not match case dimensions")
        need(x["package"] == C3_PACKAGE, "unexpected benchmark package")
        need(type(x["iterations"]) is int and x["iterations"] == C3_ITERATIONS, "canonical measured iterations required")
        need(type(x["warmup_iterations"]) is int and x["warmup_iterations"] == C3_WARMUP_ITERATIONS, "canonical warmup iterations required")
        need(x["workload_contract"] and x["comparable_metrics"] and x["timed_scope"] and x["ack_contract"], "missing work/ACK comparability")
        need(set(x["rules"]) == {"baseline", "candidate"}, "variant metric rules missing")
        need({"wal_appends/op", "wal_syncs/op"} <= set(x["comparable_metrics"]), "WAL comparability missing")
        expected_wal = {"command_wal_durable": (1, 1), "command_wal_relaxed": (1, 0), "no_wal_fast": (0, 0)}[x["profile"]]
        for variant in ("baseline", "candidate"):
            for unit, expected in zip(("wal_appends/op", "wal_syncs/op"), expected_wal):
                rule = x["rules"][variant].get(unit)
                need(isinstance(rule, dict) and set(rule) == {"eq"} and type(rule["eq"]) is int
                     and rule["eq"] == expected, "profile WAL exact rule mismatch")
        # Canonical JSON equality is type-sensitive (True must not equal 1),
        # recursively binds list elements, and rejects missing/extra fields.
        need(digest(x["workload_contract"]) == digest(workload_contract(x["workload"])),
             "literal workload contract mismatch")
        expected_work, expected_latency = workload_metrics(x["workload"])
        need(x["latency_groups"] == expected_latency, "literal workload latency groups mismatch")
        need(x["ack_contract"] == ACK_CONTRACT and x["timed_scope"] == TIMED_SCOPE,
             "literal workload ACK/timed scope mismatch")
        need(set(expected_work) <= set(x["comparable_metrics"]), "work-count comparability missing")
        for variant in ("baseline", "candidate"):
            for unit, expected in expected_work.items():
                rule = x["rules"][variant].get(unit)
                need(isinstance(rule, dict) and set(rule) == {"eq"} and type(rule["eq"]) is int
                     and rule["eq"] == expected, "literal workload count rule mismatch")
        for variant in ("baseline", "candidate"):
            expected_layout = {"layout_expected_records": 4, "ack_routing_before_ok": 1, "ack_routing_after_ok": 1}
            for phase in ("before", "after"):
                expected_layout["layout_" + phase + "_inline"] = 4 if x["layout"] == "inline" else 0
                expected_layout["layout_" + phase + "_pointer"] = 4 if x["layout"] == "pointer" else 0
                for counter in ("wal_appends", "wal_syncs"):
                    expected = {"eq": 0} if x["profile"] == "no_wal_fast" else {"min": 0, "integer": True}
                    rule = x["rules"][variant].get(counter + "_" + phase)
                    need(isinstance(rule, dict) and rule == expected
                         and (type(rule.get("eq")) is int if "eq" in expected
                              else type(rule.get("min")) is int and rule.get("integer") is True),
                         "actual WAL boundary rule mismatch")
            for unit, expected in expected_layout.items():
                rule = x["rules"][variant].get(unit)
                need(isinstance(rule, dict) and set(rule) == {"eq"} and type(rule["eq"]) is int and rule["eq"] == expected,
                     "actual layout/routing exact rule mismatch")
        units = set(x["rules"]["baseline"])
        need(units == set(x["rules"]["candidate"]), "unmatched metric sets")
        need({"ns/op", "B/op", "allocs/op"} <= units and x["latency_groups"], "allocation/latency metrics missing")
        for group in x["latency_groups"]:
            need({group + "_p" + str(p) + "_ns" for p in (50, 95, 99)} <= units, "missing active latency group")
        need(set(x["comparable_metrics"]) <= units and set(c["comparison_metrics"]) <= units, "unavailable comparison metric")
        need(set(c["comparison_metrics"]) <= set(x["comparison_metrics"]), "globally required comparison metric missing from case")
        need(set(x["comparison_metrics"]) <= units and all(v in ("lower", "higher") for v in x["comparison_metrics"].values()), "missing effect direction")
        for variant in ("baseline", "candidate"):
            for unit, rule in x["rules"][variant].items():
                need(set(rule) <= {"min", "max", "eq", "integer"} and ("eq" in rule or "min" in rule), "explicit zero/nonzero metric rule required")
                need(all(finite_number(v) and v >= 0 for k, v in rule.items() if k != "integer"), "invalid metric bounds")
        canonical_rules, canonical_directions = metric_contract(x["profile"], x["layout"], x["workload"], x["mode"])
        need(digest(x["comparison_metrics"]) == digest(canonical_directions), "canonical effect directions mismatch")
        for variant in ("baseline", "candidate"):
            need(digest(x["rules"][variant]) == digest(canonical_rules), "canonical operational rules mismatch")
    benchmark_comms(c)
    return c

def schedule(c):
    for case in c["cases"]:
        for variant in ("baseline", "candidate"):
            yield {"case": case["id"], "phase": "warmup", "cycle": 0, "slot": 0, "variant": variant}
        for cycle in range(1, 4):
            for slot, variant in enumerate(c["order"], 1):
                yield {"case": case["id"], "phase": "measured", "cycle": cycle, "slot": slot, "variant": variant}

def label(item):
    return f'{item["case"]}-{item["phase"]}-c{item["cycle"]}-s{item["slot"]}-{item["variant"]}'

def command(binary, case, item, timeout):
    # Go matches slash-separated benchmark components separately.
    pattern = "/".join("^" + re.escape(p) + "$" for p in case["benchmark"].split("/"))
    count = case["warmup_iterations"] if item["phase"] == "warmup" else case["iterations"]
    return [str(binary), "-test.run=^$", "-test.bench=" + pattern, f"-test.benchtime={count}x",
            "-test.benchmem", "-test.count=1", f"-test.timeout={timeout}s"]

def row(stdout, stderr, case, variant, phase):
    need(not Path(stderr).read_bytes(), "unexpected stderr")
    found, metadata, passed = [], {}, 0
    for line in Path(stdout).read_text().splitlines():
        if not line.strip():
            continue
        if line == "PASS":
            passed += 1
            continue
        matched = re.fullmatch(r"(goos|goarch|pkg|cpu): (.+)", line)
        if matched:
            need(matched[1] not in metadata, "duplicate Go metadata")
            metadata[matched[1]] = matched[2]
            continue
        matched = re.fullmatch(re.escape(case["benchmark"]) + r"-4\s+(\d+)\s+(.+)", line)
        need(matched is not None, "unexpected stdout: " + line[:160])
        tokens = matched[2].split()
        need(len(tokens) % 2 == 0, "malformed benchmark metric pairs")
        metrics = {}
        for number, unit in zip(tokens[::2], tokens[1::2]):
            need(unit not in metrics, "duplicate metric " + unit)
            value = float(number)
            need(math.isfinite(value) and value >= 0, "invalid metric " + unit)
            metrics[unit] = value
        rules = case["rules"][variant]
        need(set(metrics) == set(rules), "missing/extra metrics")
        for unit, rule in rules.items():
            value = metrics[unit]
            need("min" not in rule or value >= rule["min"], "underflow/zero " + unit)
            need("max" not in rule or value <= rule["max"], "overflow " + unit)
            need("eq" not in rule or value == rule["eq"], "unexpected counter " + unit)
            need(not rule.get("integer") or value.is_integer(), "noninteger counter " + unit)
        count = case["warmup_iterations"] if phase == "warmup" else case["iterations"]
        need(int(matched[1]) == count, "unexpected benchmark work count")
        for counter, unit in (("wal_appends", "wal_appends/op"), ("wal_syncs", "wal_syncs/op")):
            before, after = metrics[counter + "_before"], metrics[counter + "_after"]
            need(after >= before and after - before == metrics[unit] * count,
                 "actual WAL boundary/delta mismatch")
        for group in case["latency_groups"]:
            need(metrics[group + "_p50_ns"] <= metrics[group + "_p95_ns"] <= metrics[group + "_p99_ns"], "invalid latency ordering")
        found.append({"iterations": count, "metrics": metrics})
    need(passed == 1 and len(found) == 1, "missing/extra benchmark row or PASS")
    need(set(metadata) == {"goos", "goarch", "pkg", "cpu"} and metadata["goos"] == "linux", "missing/unexpected benchmark metadata")
    need(metadata["pkg"] == case["package"], "unexpected benchmark package")
    return dict(found[0], metadata=metadata)
