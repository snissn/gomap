"""Source-only staged Git closure; no Go or behavioral/runtime execution."""
import hashlib,json,os,pathlib,subprocess,sys,tarfile,types
from pathlib import Path
sys.dont_write_bytecode=True
N=Path(__file__).resolve().parent
meta=json.loads((N/"source-products.json").read_text())
assert meta["namespace"]==str(N) and set(meta["products"])=={"c4"}
assert meta["runtime_grant"]=="HELD" and meta["Go_executions"]==0
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(__file__)==meta["source_provision_sha256"]
pack=N/"source-authority.pack"
assert sha(pack)==meta["pack_sha256"] and pack.stat().st_size==meta["pack_bytes"]
commands=[]
call_in_flight=False
streams=N/"source-provision-streams";streams.mkdir()
custody_path=N / "custody.py"
assert custody_path.is_file() and not custody_path.is_symlink() and sha(custody_path)==meta["custody_sha256"]
from custody import StickySignals, durable, supervise
def call(argv,stdin_path=None,env=None):
 global call_in_flight
 assert not phase_sticky.signals, "source provision cancelled before next owned Git child"
 index=len(commands);label=str(index)
 # Git authority needs only these explicit controls. Do not retain shell secrets.
 effective={"PATH":"/usr/bin:/bin","LC_ALL":"C","GIT_CONFIG_NOSYSTEM":"1",
            "GIT_CONFIG_GLOBAL":os.devnull,"GIT_NO_LAZY_FETCH":"1"}
 if env is not None:
  for key in ("GIT_CONFIG_NOSYSTEM","GIT_CONFIG_GLOBAL","GIT_NO_LAZY_FETCH"):
   assert env.get(key)==effective[key],key
 incoming=Path(stdin_path).read_bytes() if stdin_path is not None else None
 fields={"stdout_path":str(streams/(label+".stdout")),"stderr_path":str(streams/(label+".stderr"))}
 if stdin_path is not None:fields.update(stdin_path=str(stdin_path),stdin_sha256=sha(stdin_path))
 with StickySignals() as sticky:
  call_in_flight=True
  record=supervise(label,argv,N,effective,180,streams,sticky,input_data=incoming,receipt_fields=fields)
  commands.append(record)
  call_in_flight=False
  snapshot=N/("source-provision-commands-"+label+".json")
  durable(snapshot,commands)
  os.replace(snapshot,N/"source-provision-commands.json")
  assert record["custody_released"] and record["child_joined"],"source child remains HELD"
  if sticky.signals:raise InterruptedError("source provision cancelled; owned Git child joined")
  assert record["exit_code"]==0 and not record["timed_out"] and record["exception"] is None,argv
 return pathlib.Path(record["stdout_path"]).read_bytes()
with StickySignals() as phase_sticky:
 counts={};failure=None
 try:
  authority=N/"authority.git"
  assert not authority.exists()
  call(["git","init","--bare",str(authority)])
  call(["git","--git-dir",str(authority),"index-pack","--stdin"],stdin_path=pack)
  proof=N/"staging-proof";proof.mkdir()
  for label,v in meta["products"].items():
   source=N/label/"source";source.mkdir(parents=True)
   assert call(["git","--git-dir",str(authority),"cat-file","commit",v["head"]]).splitlines()[0]==b"tree "+v["tree"].encode()
   archive=N/(label+"-source.tar")
   call(["git","--git-dir",str(authority),"archive","--format=tar","-o",str(archive),v["head"]])
   with tarfile.open(archive) as stream:
    for member in stream.getmembers():
     name=Path(member.name)
     assert not name.is_absolute() and ".." not in name.parts and (member.isfile() or member.isdir()),member.name
    stream.extractall(source,filter="data")
   rows=call(["git","--git-dir",str(authority),"ls-tree","-r","-z",v["head"]]).split(b"\0")
   for row in rows:
    if not row:continue
    fields,name=row.split(b"\t",1);mode,kind,oid=fields.split()
    assert mode in (b"100644",b"100755") and kind==b"blob"
    (source/os.fsdecode(name)).chmod(0o755 if mode==b"100755" else 0o644)
   for name,want in meta["shared_tooling_sha256"].items():
    assert sha(source/"scripts/cow_c3_read"/name)==want,(label,name)
   sys.path.insert(0,str(source/"scripts/cow_c3_read"))
   import build
   def supervised_authority_run(argv,input=None,env=None,stdout=None,stderr=None):
    assert stdout==subprocess.PIPE and stderr==subprocess.PIPE
    assert input is None or isinstance(input,bytes)
    incoming=None
    if input is not None:
     incoming=streams/(str(len(commands))+".stdin");incoming.write_bytes(input)
    raw=call(argv,stdin_path=incoming,env=env)
    return subprocess.CompletedProcess(argv,commands[-1]["exit_code"],raw,Path(commands[-1]["stderr_path"]).read_bytes())
   # Only this root-local module seam changes; frozen build.py bytes stay exact.
   # Every authority Git subprocess uses the pinned shared finite custody.
   original_subprocess=build.subprocess
   try:
    build.subprocess=types.SimpleNamespace(run=supervised_authority_run,PIPE=subprocess.PIPE)
    manifest,objects=build.git_source_authority(source,authority,v["head"],v["tree"])
   finally:build.subprocess=original_subprocess
   for suffix,data in (("source-manifest",manifest),("git-authority",objects)):
    path=proof/(label+"-"+suffix+".json");path.write_text(json.dumps(data,indent=2)+"\n")
   modes={f["path"]:(source/f["path"]).stat().st_mode&0o777 for f in manifest["files"]}
   assert all(modes[f["path"]]==(0o755 if f["git_mode"]=="100755" else 0o644) for f in manifest["files"])
   path=proof/(label+"-modes.json");path.write_text(json.dumps(modes,indent=2,sort_keys=True)+"\n")
   counts[label]={"head":v["head"],"tree":v["tree"],"files":len(manifest["files"]),"source_manifest_sha256":sha(proof/(label+"-source-manifest.json")),"git_authority_sha256":sha(proof/(label+"-git-authority.json")),"mode_manifest_sha256":sha(path),"archive_sha256":sha(archive)}
   sys.path.pop(0)
  for name in ("tmp","cache"):
   (N/name).mkdir()

  assert not phase_sticky.signals, "source provision cancelled before terminal success"
 except BaseException as error:
  failure={"type":type(error).__name__,"error":str(error)}
 finally:
  result={"status":"SOURCE_ONLY_SELF_CONTAINED_GIT_BYTES_MODES" if failure is None else "SOURCE_ONLY_PROVISION_FAILED",
          "functional_status":"SUCCEEDED" if failure is None else "FAILED", "failure":failure,
          "requested_products":meta["products"],"products":counts,"pack_sha256":sha(pack),
          "authority_alternate_consumers":[],"Go_executions":0,"runtime_grant":"HELD",
          "source_provision_sha256":sha(__file__),"custody_sha256":sha(N/"custody.py"),
          "all_children_joined":not call_in_flight and all(x["child_joined"] is True and x["custody_released"] is True for x in commands),
          "signals":list(phase_sticky.signals)}
  durable(N/"source-provision-receipt.json",result)
  print(json.dumps(result),flush=True)
raise SystemExit(1 if failure is not None else 0)
