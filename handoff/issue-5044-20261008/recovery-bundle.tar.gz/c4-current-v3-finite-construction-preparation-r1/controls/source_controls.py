"""Bounded pure controls. Never import/execute operational controller mains."""
import ast,copy,datetime,hashlib,importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('current_c4_source',D/'controllers/c4_source.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def load(p):return json.loads(Path(p).read_text())
def local(j):
 if isinstance(j,str):return j.replace('/home/mikers/gomap-cow-c4-current-v3-20261008-r1',str(D))
 if isinstance(j,list):return [local(v) for v in j]
 if isinstance(j,dict):return {k:local(v) for k,v in j.items()}
 return j
results=[]
def check(name,fn,refuse=False):
 try:fn()
 except (ValueError,KeyError,TypeError) as e:
  assert refuse,(name,type(e).__name__,str(e));results.append({'name':name,'pass':True,'expected_refusal':True,'type':type(e).__name__,'error':str(e)})
 else:
  assert not refuse,(name,'unexpected acceptance');results.append({'name':name,'pass':True,'expected_refusal':False})
settings=load(D/'settings.draft.json')
check('held_runtime_settings_refuse',lambda:m.settings_shape(settings),True)
owner=load(D/'templates/owner-window.pending.json')
check('held_owner_refuses',lambda:m.validate_owner_window(owner,settings),True)
owner.update(status='APPROVED_BY_NATIVE_OWNER',not_before='2026-10-09T00:00:00Z',expires_at='2026-10-09T04:32:00Z')
start=datetime.datetime(2026,10,9,tzinfo=datetime.timezone.utc)
check('pure_full_window_shape',lambda:m.validate_owner_window(owner,settings,start))
for key,value in [('host','foreign'),('namespace','/foreign'),('not_before','2026-10-09T00:00:00+00:00'),('expires_at','2026-10-09T04:32:01Z'),('wall_cap_seconds',16320.0),('runtime_seconds',14400.0)]:
 altered=copy.deepcopy(owner);altered[key]=value
 check('owner_refuses_'+key,lambda altered=altered:m.validate_owner_window(altered,settings,start),True)
check('owner_started_too_early',lambda:m.validate_owner_window(owner,settings,start-datetime.timedelta(seconds=1)),True)
check('owner_transport_margin_exhausted',lambda:m.validate_owner_window(owner,settings,start+datetime.timedelta(seconds=601)),True)
check('owner_expired',lambda:m.validate_owner_window(owner,settings,start+datetime.timedelta(hours=5)),True)
short=copy.deepcopy(owner);short.update(wall_cap_seconds=3600,runtime_seconds=1680,expires_at='2026-10-09T01:00:00Z')
check('pure_short_window_preserves_outer_deadline',lambda:m.validate_owner_window(short,settings,start))

# These controls consume unchanged actual b8 receipts/raw streams; no new Go run.
proof=local(load(D/'current-functional-applicability.json'));variant=settings['variants']['c4']
expected_sha=hashlib.sha256((D/'expected-current-compiler-closure.json').read_bytes()).hexdigest()
check('actual_current65_normal_race_source_applicability',lambda:m.validate_current_functional(proof,variant,expected_sha))
for name,fn in [('count_float',lambda p:p.update(normal_race_unit_names_each=65.0)),('runtime_head_tampered',lambda p:p.update(runtime_head='f'*40)),('closure_hash_tampered',lambda p:p.update(expected_normal_compiler_closure_sha256='0'*64)),('old_runtime_relabelled',lambda p:p.update(original_runtime_relabelled=True)),('missing_independent_acceptance',lambda p:p['actual_receipts'].pop('independent_acceptance')),('raw_hash_tampered',lambda p:p['actual_receipts']['normal_stdout'].update(sha256='0'*64))]:
 altered=copy.deepcopy(proof);fn(altered)
 check('current_functional_refuses_'+name,lambda altered=altered:m.validate_current_functional(altered,variant,expected_sha),True)

# Synthetic receipt inputs exercise the source-derived EXPECTED contract only.
# They are never written as actual build evidence or runtime authority.
old=load(D/'prior-scope/original-C4-build-receipt.json');oracle=load(D/'prior-scope/accepted-P4-trimpath-build-receipt.json')
closure=load(D/'expected-current-compiler-closure.json');controls=settings['controls']
env=copy.deepcopy(old['effective_process_environment']);env.update(controls);env['GOPATH']=str(Path(controls['GOMODCACHE']).parent.parent)
fresh=copy.deepcopy(oracle);fresh.update(environment=controls,effective_process_environment=env,binary_sha256='a'*64)
relocation=load(D/'path-relocation.json');inventory=settings['full_toolchain_inventory']['sha256'];old_sha=hashlib.sha256((D/'prior-scope/original-C4-build-receipt.json').read_bytes()).hexdigest()
call=lambda actual,receipt=fresh:m.validate_current_build(old,oracle,receipt,actual,closure,controls,env,relocation,settings['namespace'],inventory,old_sha)
check('pure_current_closure_allows_fresh_binary_distinct_from_historical',lambda:call(closure))
historical=load(D/'prior-scope/original-C4-compiled-input-closure.json')
check('pure_current_closure_rejects_historical_mvcc',lambda:call(historical),True)
for name,fn in [('missing_entry',lambda c:c.pop(next(iter(c)))),('foreign_entry',lambda c:c.update(FOREIGN=copy.deepcopy(next(iter(c.values()))))),('wrong_mode',lambda c:c['REPO/TreeDB/mvcc/mvcc.go'].update(mode=0o755)),('wrong_hash',lambda c:c['REPO/TreeDB/mvcc/mvcc.go'].update(sha256='0'*64))]:
 altered=copy.deepcopy(closure);fn(altered)
 check('pure_current_closure_refuses_'+name,lambda altered=altered:call(altered),True)
altered=copy.deepcopy(fresh);altered['go_binary_sha256']='0'*64
check('pure_current_closure_rejects_foreign_go',lambda:call(closure,altered),True)
altered=copy.deepcopy(fresh);altered['effective_process_environment']=dict(env,EXTRA='1')
check('pure_current_closure_rejects_extra_env',lambda:call(closure,altered),True)

# Extract exact source AST gates; execute only expressions, not mains/children.
runner=ast.parse((D/'controllers/c4_affected_runner.py').read_text())
maintry=next(n for n in runner.body if isinstance(n,ast.Try))
def call_gate(fragment,namespace):
 calls=[n for n in ast.walk(maintry) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='need' and len(n.args)>1 and isinstance(n.args[1],ast.Constant) and fragment in str(n.args[1].value)]
 assert len(calls)==1,fragment
 eval(compile(ast.Expression(calls[0]),'<exact-controller-source-gate>','eval'),dict(namespace,need=m.need))
completed={'schema':m.V3_SCHEMA,'capture_root':'/producer/packet','runs':36}
actual=[{'phase':'construction','variant':'candidate','row':{'iterations':1}} for _ in range(36)]
gate=lambda c,r:call_gate('fresh genuine36',{'completed':c,'actual':r,'V3_SCHEMA':m.V3_SCHEMA,'packet':Path('/producer/packet')})
check('pure_exact_v3_36_one_epoch_gate',lambda:gate(completed,actual))
for name,fn in [('v2_schema',lambda c:c.update(schema='gomap-cow-sustained-public-v2')),('wrong_capture_root',lambda c:c.update(capture_root='/foreign/packet')),('missing_capture_root',lambda c:c.pop('capture_root')),('wrong_count',lambda c:c.update(runs=35))]:
 changed=copy.deepcopy(completed);fn(changed)
 check('exact_v3_gate_refuses_'+name,lambda changed=changed:gate(changed,actual),True)
changed=copy.deepcopy(actual);changed[0]['row']['iterations']=8
check('exact_v3_gate_refuses_epochs8',lambda:gate(completed,changed),True)
check('exact_v3_gate_refuses_short_rows',lambda:gate(completed,actual[:-1]),True)
sticky=type('Sticky',(),{'signals':[]})()
check('final_release_no_cancel',lambda:call_gate('cancellation retained during final',{'sticky':sticky}))
sticky.signals=[15]
check('final_release_cancel_refuses_success',lambda:call_gate('cancellation retained during final',{'sticky':sticky}),True)
assert any(isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='durable' for n in maintry.finalbody)
check('final_release_retains_source_and_join_receipt_before_refusal',lambda:None)
selected=next(n.value for n in ast.walk(maintry) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='selected' for t in n.targets))
selected=ast.literal_eval(selected)
assert len(selected)==len(set(selected))==12
assert selected[:6]==['unrelated-absolute-raw-directory','missing-capture-root','tampered-capture-root','relative-capture-root','missing-raw-directory','mismatched-output-command']
check('exact_original6_plus_current_capture6_refusals',lambda:None)
run_calls=[n for n in ast.walk(runner) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='run']
assert len(run_calls)==5
check('exact_five_actions_no_new_test_or_benchmark_children',lambda:None)
closer=ast.parse((D/'controllers/close_packet.py').read_text())
assert "result['fresh_copied_refusals']==12" in (D/'controllers/close_packet.py').read_text()
assert "result['schema']=='gomap-cow-sustained-public-v3'" in (D/'controllers/close_packet.py').read_text()
check('mandatory_closer_exact_v3_result_contract',lambda:None)
for name in ('custody.py','remote_outer.py','remote_execute_once.py'):
 assert (D/'controllers'/name).read_bytes()==(D/'origins/controllers'/name).read_bytes()
check('three_shared_custody_helpers_byte_unchanged',lambda:None)
out={'status':'PASS','controls':results,'control_count':len(results),'actual_source_bound_functional_inputs_reused':True,'synthetic_window_and_build_fixtures_are_controls_only':True,'Go_executions':0,'SSH_executions':0,'operational_mains_executed':0,'all_owned_processes_joined':True,'all_source_and_artifact_readers_released':True}
(D/'controls/source-controls-result.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('PASS',len(results),'bounded pure controls; no Go/SSH/operational mains')
