"""Root-run preparation only: validate staged source/lane custody, then seal actions.

No subprocess, Go, SSH, or runtime invocation. Do not run until root explicitly
accepts this exact source and supplies the bound authorization/actual receipts.
"""
import argparse,hashlib,importlib.util,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/mikers/gomap-cow-c4-current-affected-20261007')
HEAD='4282ce946d0e9e169731d1dd3865ddaadc5ffc12'
TREE='9595e67d57a60c7ec81f79356481cc759d3df235'
BUNDLE_SHA256='82cab3c081132fa5cf4da53dc3169b875a0cba7c5d7899543dc0049988968cc4'
SCOPE='AFFECTED_C4_CURRENT_SOURCE_CONSTRUCTION_ONLY'
def need(value,message):
 if not value:raise ValueError(message)
def sha(path):
 p=Path(path);need(p.is_file() and not p.is_symlink(),'nonregular input '+str(p));return hashlib.sha256(p.read_bytes()).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def descriptor(path):return {'path':str(path),'sha256':sha(path)}
def bound(row):
 need(type(row) is dict and type(row.get('path')) is str and type(row.get('sha256')) is str,'missing bound authority');need(sha(row['path'])==row['sha256'],'authority drift');return load(row['path'])
def dump(path,value):
 with Path(path).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def check_lane(release):
 need(release.get('status')=='RELEASED' and release.get('all_children_joined') is True and type(release.get('Go_or_test_jobs')) is int and release['Go_or_test_jobs']==0,'previous lane remains HELD')
def check_authorization(auth,source_receipt,lane,shared):
 need(auth.get('runtime_grant')=='GRANTED_BY_ROOT' and auth.get('namespace')==str(N) and auth.get('scope')==SCOPE and auth.get('head')==HEAD and auth.get('tree')==TREE,'root C4 authorization pending')
 need(type(auth.get('C3_runs')) is int and type(auth.get('matched_runs')) is int and auth['C3_runs']==auth['matched_runs']==0 and auth.get('native_qualification') is False,'wrong root scope')
 need(auth.get('sealer_sha256')==sha(__file__) and auth.get('bundle_sha256')==BUNDLE_SHA256,'sealer not accepted by root')
 for key,path in [('source_provision',source_receipt),('previous_lane_release',lane),('shared_helper_acceptance',shared)]:need(auth.get(key)==descriptor(path),'root actual prerequisite unbound '+key)
def seal(source_receipt,lane,shared,authorization):
 need(Path(__file__).resolve().parent==N and N.resolve()==N and not N.is_symlink(),'seal only exact remote staged namespace')
 base=N/'local-draft';need(base.resolve()==base and not base.is_symlink(),'noncanonical draft root')
 need(sha(base/'bundle-index.json')==BUNDLE_SHA256,'draft generation drift');index=load(base/'bundle-index.json')
 for name,row in index.items():
  rel=Path(name);need(not rel.is_absolute() and '..' not in rel.parts and rel.as_posix()==name,'unsafe draft member')
  p=base/rel;need(p.resolve()==p and sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],'draft bytes drift '+name)
 settings=load(base/'settings.draft.json');source=load(base/'source-binding.draft.json');binding=load(base/'controller-binding.draft.json')
 need(settings['runtime_grant']==source['runtime_grant']=='HELD' and binding['status']=='HELD','draft must remain HELD')
 for name,want in binding['controller_files'].items():need(sha(N/name)==want,'controller drift '+name)
 # All retained importing Python files are proven current Git blob bytes before import.
 for name,row in source['retained_scripts'].items():
  p=Path(settings['variants']['c4']['source'])/name
  need(p.resolve()==p and sha(p)==row['sha256'] and p.stat().st_size==row['bytes'] and p.stat().st_mode&0o777==int(row['git_mode'][-3:],8),'current script drift '+name)
 actual=load(source_receipt);meta=load(N/'source-products.json');expected_meta=load(base/'root-source-products.json')
 need(meta==expected_meta and actual['requested_products']==meta['products'],'actual source requests drift')
 need(meta['namespace']==str(N) and set(meta['products'])=={'c4'} and meta['products']['c4']=={k:settings['variants']['c4'][k] for k in ('head','tree','source','build')},'wrong actual C4 product')
 need(meta['runtime_grant']=='HELD' and meta['Go_executions']==0,'source runtime scope drift')
 need(sha(N/'source-authority.pack')==meta['pack_sha256'] and (N/'source-authority.pack').stat().st_size==meta['pack_bytes'],'pack drift')
 need(sha(N/'source-provision-self-contained-c4.py')==meta['source_provision_sha256'] and sha(N/'custody.py')==meta['custody_sha256'],'provider/custody drift')
 need(actual.get('status')=='SOURCE_ONLY_SELF_CONTAINED_GIT_BYTES_MODES' and actual.get('functional_status')=='SUCCEEDED' and actual.get('failure') is None and actual.get('all_children_joined') is True and actual.get('signals')==[],'source function/custody incomplete')
 need(actual['Go_executions']==0 and actual['runtime_grant']=='HELD' and actual['authority_alternate_consumers']==[] and set(actual['products'])=={'c4'},'wrong source scope')
 for key in ('pack_sha256','source_provision_sha256','custody_sha256'):need(actual[key]==meta[key],'source identity drift '+key)
 commands=load(N/'source-provision-commands.json');need(type(commands) is list and 0<len(commands)<=32,'source Git custody absent/unbounded')
 for i,row in enumerate(commands):
  need(row['label']==str(i) and row['child_joined'] is True and row['custody_released'] is True and row['owned_process_group_closed'] is True and row['exit_code']==0 and row['timed_out'] is False and row['exception'] is None and row['signals']==[],'source Git join unproven')
  need(Path(row['argv'][0]).name=='git','source-only Git scope')
  need(load(N/'source-provision-streams'/f'{i}.json')==row,'source inner receipt mismatch')
  for stream in ('stdout','stderr'):
   p=N/'source-provision-streams'/f'{i}.{stream}';need(row[stream+'_path']==str(p) and sha(p)==row[stream+'_sha256'],'source stream drift')
 release=load(lane);check_lane(release);reviewed=load(shared)
 need(reviewed.get('accepted') is True and all(reviewed['controller_files'][n]==binding['controller_files'][n] for n in ('custody.py','remote_outer.py','remote_execute_once.py')),'shared custody acceptance missing')
 auth=load(authorization);check_authorization(auth,source_receipt,lane,shared)
 spec=importlib.util.spec_from_file_location('c4_source',N/'c4_source.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);sys.modules['c4_source']=m
 need(set(binding['controller_files'])==m.CONTROLLERS and set(source['retained_scripts'])=={'scripts/cow_c3_read/'+n for n in m.SCRIPTS},'incomplete exact controller/tool membership')
 sys.path.insert(0,settings['variants']['c4']['source']+'/scripts/cow_c3_read')
 v=settings['variants']['c4'];product=actual['products']['c4']
 for key,path in [('source_manifest_sha256',v['staged_source_manifest']),('git_authority_sha256',v['staged_git_authority']),('mode_manifest_sha256',settings['staged_post_mode_manifests']['c4']['path'])]:need(product[key]==sha(path),'actual retained product drift '+key)
 need(product['archive_sha256']==sha(N/'c4-source.tar'),'source archive drift')
 source['products']['c4'].update(product,pack_sha256=meta['pack_sha256'],source_provision_sha256=meta['source_provision_sha256'])
 # Stage exact copied P2/P4 files and relocation beforehand; descriptors already name N.
 for key in ('selected_compiler_equality','prior_scoped_C4_correctness_acceptance','path_relocation'):bound(source[key])
 equality=bound(source['selected_compiler_equality']);need(equality['head']==HEAD and equality['tree']==TREE and equality['selected_repository_inputs']==408 and equality['all_bytes_modes_blobs_equal'] is True,'selected scope drift')
 manifest=load(v['staged_source_manifest']);git=load(v['staged_git_authority']);modes=bound(descriptor(settings['staged_post_mode_manifests']['c4']['path']))
 m.verify_source(v,manifest,git,modes)
 rows={r['path']:r for r in manifest['files']};need(len(equality['files'])==408,'selected proof count drift')
 for row in equality['files']:
  current=rows[row['path']];need(all(current[k]==row[k] for k in ('sha256','bytes','git_blob')) and int(current['git_mode'][-3:],8)==row['mode'],'selected source differs '+row['path'])
 for path,want in source['C4_fixed_fixture_bindings'].items():need(sha(Path(v['source'])/path)==want,'fixed fixture drift')
 for proof in equality['proofs'].values():bound(proof)
 accepted=bound(source['prior_scoped_C4_correctness_acceptance']);prior=accepted['C4']
 need(accepted['verdict']=='ACCEPT_SCOPED_C3_FROZEN_FUNCTIONAL_CONSTRUCTION_AND_C4_SCHEMA_REPAIR' and prior['schema_and_unchanged_runtime_applicability_accepted'] is True and prior['normal_race_unit_names_each']==65 and prior['phase_iterations']==[1,8] and prior['original_pipeline_status']=='CLOSED_FAILURE','P2 scoped acceptance drift')
 oracle=source['accepted_trimpath_oracle'];oracle_receipt=bound(oracle['build_receipt']);m.validate_trimpath_oracle(bound(oracle['acceptance']),oracle_receipt,oracle['build_receipt']['sha256']);need(oracle['closure']['sha256']==oracle_receipt['artifacts']['compiled_input_closure']['sha256'],'oracle closure unbound')
 old=bound(equality['proofs']['original-C4-build-receipt.json']);oldcl=bound(equality['proofs']['original-C4-compiled-input-closure.json']);oraclecl=bound(oracle['closure']);normal=lambda cl:{k:{f:r[f] for f in ('sha256','bytes','mode')} for k,r in cl.items()}
 need(len(oldcl)==len(oraclecl)==1846 and normal(oldcl)==normal(oraclecl) and all(old[k]==oracle_receipt[k] for k in m.COMPILER_IDENTITIES),'P2/P4 compiler proof drift')
 from protocol import process_environment
 m.validate_relocation(old,settings['controls'],process_environment(settings['controls']),bound(source['path_relocation']),str(N),settings['full_toolchain_inventory']['sha256'],equality['proofs']['original-C4-build-receipt.json']['sha256'])
 m.full_toolchain(settings['controls']['GOROOT'],settings['full_toolchain_inventory'])
 settings['provision_receipt']=descriptor(source_receipt);settings['staged_post_mode_manifests']['c4']=descriptor(settings['staged_post_mode_manifests']['c4']['path'])
 source['runtime_grant']='GRANTED_BY_ROOT';m.verify_provision(settings,source,actual)
 outputs=[N/n for n in ('root-source-binding.json','settings.json','root-grant.json','controller-binding.json','outer-actions.json','runtime-action.json','closure-action.json')]
 need(all(not p.exists() and not p.is_symlink() for p in outputs),'sealing is once only; existing outputs refuse')
 # All prerequisite validation above precedes any operative output. Binding is last.
 dump(N/'root-source-binding.json',source);settings.update(runtime_grant='GRANTED_BY_ROOT',status='ROOT_BOUND_CURRENT_C4_SOURCE',root_source_binding_path=str(N/'root-source-binding.json'),root_source_binding_sha256=sha(N/'root-source-binding.json'));dump(N/'settings.json',settings)
 dump(N/'root-grant.json',auth);binding.update(status='GRANTED_BY_ROOT',settings_sha256=sha(N/'settings.json'),previous_lane_release=descriptor(lane),shared_helper_acceptance=descriptor(shared),root_grant=descriptor(N/'root-grant.json'));dump(N/'controller-binding.json',binding)
 m.authority(N/'settings.json',N/'controller-binding.json',sha(N/'controller-binding.json'))
 actions=[{'label':label,'argv':['/usr/bin/python3','-B',str(N/name),str(N/'settings.json'),str(N/'controller-binding.json'),sha(N/'controller-binding.json')],'cwd':str(N),'environment':{'PATH':'/bin:/usr/bin','LC_ALL':'C'},'timeout_seconds':timeout,'receipt_directory':str(N/'outer-receipts'),'custody_proof':str(proof)} for label,name,timeout,proof in [('standalone-runtime','c4_affected_runner.py',14400,N/'admission/source-after-finally.json'),('standalone-closure','close_packet.py',1200,N/'handoff.json')]]
 for name,value in [('outer-actions.json',actions),('runtime-action.json',actions[:1]),('closure-action.json',actions[1:])]:dump(N/name,value)
 return {'status':'ROOT_SEALED_ACTIONS_NOT_EXECUTED','binding_sha256':sha(N/'controller-binding.json'),'Go_executions':0}
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--source-provision',required=True);parser.add_argument('--previous-lane-release',required=True);parser.add_argument('--shared-helper-acceptance',required=True);parser.add_argument('--root-authorization',required=True);args=parser.parse_args();print(json.dumps(seal(Path(args.source_provision),Path(args.previous_lane_release),Path(args.shared_helper_acceptance),Path(args.root_authorization)),sort_keys=True))
if __name__=='__main__':main()
