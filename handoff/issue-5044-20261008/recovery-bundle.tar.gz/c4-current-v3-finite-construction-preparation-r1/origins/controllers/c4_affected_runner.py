"""Five supervised current C4 construction actions; no matched/native qualification."""
import json,os,platform,shutil,sys
from pathlib import Path
from c4_source import authority,load_bound,verify_source,full_toolchain,endpoint,need,sha,validate_relocation,validate_trimpath_oracle,validate_build_reuse
settings_path=Path(sys.argv[1]);settings,binding,source_binding=authority(settings_path,sys.argv[2],sys.argv[3])
from custody import StickySignals,supervise,monitored_release,durable
variants=settings['variants'];out=Path(settings['out']);out.mkdir(exist_ok=False)
sys.path.insert(0,str(Path(variants['c4']['source'])/'scripts/cow_c3_read'))
from build import verify_git_receipt,objects
from protocol import (now,write,digest,identity,process_environment,harness_manifest,build_inputs,
    validate_build_command,validate_go_environment,toolchain_inventory,build_toolchain)
import c4_protocol as c4
from prepare_c4_config import draft as c4_draft
need_pre=need;hash_file=sha
controls=settings['controls'];env=process_environment(controls);commands=[];pre_sources={}
for key in ('selected_compiler_equality','prior_scoped_C4_correctness_acceptance'):
    proof=source_binding[key]
    need_pre(hash_file(proof['path'])==proof['sha256'], 'unbound original scope proof '+key)
equality=json.loads(Path(source_binding['selected_compiler_equality']['path']).read_text())
need_pre(set(settings['variants'])=={'c4'} and set(source_binding['products'])=={'c4'}, 'C4-only source scope')
need_pre(equality['status']=='CURRENT_C4_SELECTED_GO_COMPILER_BYTES_MODES_BLOBS_EQUAL_ORIGINAL_P2'
         and equality['all_bytes_modes_blobs_equal'] is True and equality['selected_repository_inputs']==408
         and all(equality[k]==settings['variants']['c4'][k] for k in ('head','tree')), 'selected C4 Go inputs not accepted')
for name,proof in equality['proofs'].items():
    need_pre(hash_file(proof['path'])==proof['sha256'], 'unbound original scope proof '+name)
reuse={'original_build_receipt_path':equality['proofs']['original-C4-build-receipt.json']['path'],
       'original_closure_path':equality['proofs']['original-C4-compiled-input-closure.json']['path']}
accepted=json.loads(Path(source_binding['prior_scoped_C4_correctness_acceptance']['path']).read_text())
prior=accepted['C4']
need_pre(accepted['verdict']=='ACCEPT_SCOPED_C3_FROZEN_FUNCTIONAL_CONSTRUCTION_AND_C4_SCHEMA_REPAIR'
         and prior['schema_and_unchanged_runtime_applicability_accepted'] is True
         and prior['normal_race_unit_names_each']==65 and prior['phase_iterations']==[1,8]
         and prior['original_pipeline_status']=='CLOSED_FAILURE', 'prior scoped C4 correctness not accepted')

relocation=load_bound(source_binding['path_relocation'])
old_build=load_bound(equality['proofs']['original-C4-build-receipt.json'])
old_closure=load_bound(equality['proofs']['original-C4-compiled-input-closure.json'])
oracle_proofs=source_binding['accepted_trimpath_oracle']
oracle_acceptance=load_bound(oracle_proofs['acceptance'])
oracle_build=load_bound(oracle_proofs['build_receipt'])
oracle_closure=load_bound(oracle_proofs['closure'])
validate_trimpath_oracle(oracle_acceptance,oracle_build,oracle_proofs['build_receipt']['sha256'])
need(oracle_proofs['closure']['sha256']==oracle_build['artifacts']['compiled_input_closure']['sha256'], 'P4 oracle closure not receipt-bound')
relocation_comparison=validate_relocation(old_build,controls,env,relocation,settings['namespace'],
    settings['full_toolchain_inventory']['sha256'],equality['proofs']['original-C4-build-receipt.json']['sha256'])
write(out/'path-relocation-admission.json',relocation_comparison)
write(out/'controls.json',controls);write(out/'operative-runtime-binding.json',binding)
write(out/'resource-reservation.json',source_binding['resource_reservation'])
proof_dir=out/'prior-scope';proof_dir.mkdir()
for name,path in {'root-source-binding.json':settings['root_source_binding_path'],
    'selected-compiler-equality.json':source_binding['selected_compiler_equality']['path'],
    'prior-C4-acceptance.json':source_binding['prior_scoped_C4_correctness_acceptance']['path'],
    'original-C4-compiled-input-closure.json':reuse['original_closure_path'],
    'original-C4-build-receipt.json':reuse['original_build_receipt_path'],
    'path-relocation.json':source_binding['path_relocation']['path'],
    'accepted-P4-trimpath-acceptance.json':oracle_proofs['acceptance']['path'],
    'accepted-P4-trimpath-build-receipt.json':oracle_proofs['build_receipt']['path'],
    'accepted-P4-trimpath-closure.json':oracle_proofs['closure']['path']}.items():
    shutil.copyfile(path,proof_dir/name)
write(out/'runner-receipt.json',{'runner_sha256':sha(__file__),'settings_sha256':sha(settings_path),
    'settings':settings,'effective_process_environment':env,'matched_runs':0,'native_qualification':False})

def run(label,argv,source,timeout=600,command_env=None):
    effective=env if command_env is None else command_env
    need(len(effective)==17,'closed seventeen-field environment')
    proof=(lambda r:monitored_release(out/'c4'/'packet')) if label=='c4-collect36' else None
    receipt=supervise(label,argv,source,effective,timeout,out,sticky,owner_proof=proof)
    receipt['effective_process_environment']=effective
    commands.append(receipt);write(out/'commands.json',commands)
    need(receipt['started_child'] and receipt['custody_released'] and receipt['exit_code']==0
         and not receipt['timed_out'] and not sticky.signals,label+' failed; retained, no retry')

def build_product(label, suite):
    need(label=='c4' and suite=='c4', 'C4-only canonical build scope')
    v=variants[label];source=Path(v['source']);build=Path(v['build'])
    run(label+'-build',[sys.executable,'-B',str(source/'scripts/cow_c3_read/build.py'),
        '--suite',suite,'--source',str(source),'--git-head',v['head'],'--git-tree',v['tree'],
        '--git-repository',settings['git_repository'],'--controls',str(out/'controls.json'),'--out',str(build)],source)
    receipt=json.loads((build/'build-receipt.json').read_text())
    binary=build/'cowsustained-normal.test'
    need(sha(binary)==receipt['binary_sha256'], 'actual canonical binary hash drift')
    validate_build_command(receipt,str(Path(controls['GOROOT'])/'bin/go'),str(binary),suite)
    need(receipt['command'].count('-trimpath')==1,'canonical build must contain exactly one -trimpath')
    need(len(receipt['artifacts'])==12,'complete twelve build provenance artifacts')
    for artifact in receipt['artifacts'].values():
        path=Path(artifact['path'])
        need(path.parent == build, 'build artifact path outside frozen build')
        need(path.is_file() and not path.is_symlink() and sha(path)==artifact['sha256'],'actual retained build artifact hash')
    validate_go_environment(json.loads((build/'go-env.stdout').read_text()),env)
    ident=identity(build/'source-manifest.json')
    verify_git_receipt(source,ident['original_manifest'],json.loads((build/'git-source-authority.json').read_text()))
    packages=objects((build/'compiled-dependencies.stdout').read_text())
    harness=harness_manifest(packages,json.loads((build/'compiled-input-closure.json').read_text()),ident,str(source),controls,suite)
    need(receipt['harness_input_identity']==digest(harness),'actual complete harness identity')
    frozen={'external_input_identity':receipt['external_input_identity'],'fixtures':harness,
            'cases':[{'package':c4.C4_PACKAGE}]}
    build_inputs(receipt,frozen,packages,json.loads((build/'compiled-inputs-before.json').read_text()),
        json.loads((build/'compiled-input-closure.json').read_text()),json.loads((build/'generated-nonpersistent-inputs.json').read_text()),str(source),ident)
    write(out/(label+'-complete-build-validation.json'),{'suite':suite,'complete_harness':harness,
        'harness_input_identity':digest(harness),'artifact_count':12,'build_receipt_sha256':sha(build/'build-receipt.json')})
    return binary,receipt,harness


sticky=StickySignals();sticky.__enter__()
try:
    write(out/'initial-full-toolchain.json',full_toolchain(controls['GOROOT'],settings['full_toolchain_inventory']))
    write(out/'initial-host-admission.json',endpoint('initial-census',out,settings,env,sticky))
    need(not sticky.signals,'cancelled before build')
    # Exact current C4 full Git/blob inventory is proved before any Go child starts.
    for label,v in variants.items():
        manifest=json.loads(Path(v['staged_source_manifest']).read_text());authority=json.loads(Path(v['staged_git_authority']).read_text())
        verify_source(v,manifest,authority,{f['path']:(Path(v['source'])/f['path']).stat().st_mode & 0o777 for f in manifest['files']})
        write(out/(label+'-source-before.json'),manifest);write(out/(label+'-git-before.json'),authority)
        modes={f['path']: (Path(v['source'])/f['path']).stat().st_mode & 0o777 for f in manifest['files']}
        need(all(modes[f['path']] == (0o755 if f['git_mode']=='100755' else 0o644) for f in manifest['files']), 'canonical complete staged source modes')
        write(out/(label+'-modes-before.json'), modes)
        pre_sources[label]=(manifest,authority,modes)
    source=Path(variants['c4']['source']);root=out/'c4';root.mkdir()
    binary,receipt,harness=build_product('c4','c4')
    # Preserve original accepted unit/phase identity; reuse only exact selected
    # persistent compiler bytes/modes and identical actual toolchain/modules/env.
    new_closure=json.loads((Path(variants['c4']['build'])/'compiled-input-closure.json').read_text())
    relocation_comparison=validate_build_reuse(old_build,old_closure,oracle_build,oracle_closure,receipt,new_closure,
        controls,env,relocation,settings['namespace'],settings['full_toolchain_inventory']['sha256'],
        equality['proofs']['original-C4-build-receipt.json']['sha256'])
    need({item['path']:item['sha256'] for item in harness if item['path'] in source_binding['C4_fixed_fixture_bindings']}
         ==source_binding['C4_fixed_fixture_bindings'], 'fixed C4 fixture bindings changed')
    write(out/'c4-reused-unit-phase-applicability.json',{'original_head':prior['runtime_head'],
        'current_head':variants['c4']['head'],'persistent_compiler_bytes_modes_equal':True,
        'normal_unit_RUN_PASS':65,'race_unit_RUN_PASS':65,'phase_epochs':[1,8],
        'old_evidence_identity_preserved':True,'controls_comparison':relocation_comparison,'claim':'Scoped source/input applicability; original runtime not relabeled to current head'})

    config=c4_draft();ident=identity(Path(variants['c4']['build'])/'source-manifest.json')
    config.update(status='frozen-approved',coordinator_acceptance='Root approved affected C4 integer-domain candidate-only construction; no matched/native/whole-parent acceptance',
        go_binary=str(Path(controls['GOROOT'])/'bin/go'),go_version=receipt['go_version'],go_binary_sha256=receipt['go_binary_sha256'],
        toolchain_identity=receipt['toolchain_identity'],external_input_identity=receipt['external_input_identity'],environment=controls,fixtures=harness)
    uname=platform.uname();storage=Path(controls['TMPDIR'])
    config['host'].update(system=uname.system,node=uname.node,machine=uname.machine,release=uname.release,cpu_count=os.cpu_count(),cpu_affinity=sorted(os.sched_getaffinity(0)),
        max_load1=5,max_load5=5,min_free_bytes=20<<30,tmpdir=str(storage),tmpdir_device=storage.stat().st_dev)
    config['noise_policy'].update(max_spread_fraction=.30,material_regression_fraction=.05,minimum_effect_fraction=.10)
    build=Path(variants['c4']['build'])
    for v in config['variants'].values():
        v.update(production_commit=variants['c4']['head'],production_git_tree=variants['c4']['tree'],source=str(source),
            manifest=str(build/'source-manifest.json'),manifest_sha256=sha(build/'source-manifest.json'),source_tree_sha256=ident['tree_sha256'],
            binary=str(binary),binary_sha256=receipt['binary_sha256'],build_receipt=str(build/'build-receipt.json'),build_receipt_sha256=sha(build/'build-receipt.json'))
    need(config['result_class']=='construction','candidate-only C4 construction scope')
    for case in config['cases']:
        case.update(iterations=1,warmup_iterations=1,workload_contract=c4.workload(case['keys'],1))
    c4.validate_config(config);build_toolchain(receipt,config,toolchain_inventory(controls['GOROOT']))
    write(root/'config.json',config)
    write(out/'c4-construction-freeze.json',{'config_sha256':sha(root/'config.json'),'same_product_both_labels':True,'matched_runs':0,'complete_harness':harness})
    packet=root/'packet'
    scripts=source/'scripts/cow_c3_read'
    run('c4-collect36',[sys.executable,'-B',str(scripts/'collect.py'),'--suite','c4-sustained',
        '--config',str(root/'config.json'),'--out',str(packet)],source,timeout=10800)
    completed=json.loads((packet/'completion.json').read_text())
    actual=json.loads((packet/'receipts.json').read_text())
    need(completed['runs']==36 and len(actual)==36
         and all(r['phase']=='construction' and r['variant']=='candidate' and r['row']['iterations']==1 for r in actual),
         'fresh genuine36 one-epoch candidate-only construction required')
    run('c4-analyze',[sys.executable,'-B',str(scripts/'c4_analyze.py'),str(packet)],source)
    analysis=json.loads((packet/'c4-analysis-validation.json').read_text())
    need(analysis['result_class']=='construction' and analysis['runs']==36 and analysis['cases']==36,'fresh C4 analyzer census')
    selected=['float-cycles','overflow-layout-owner','overflow-pointer-bytes',
              'overflow-call-time','float-finite-limit','overflow-backend-counter']
    refusal_out=root/'integer-packet-refusals'
    run('c4-integer-packet-refusals6',[sys.executable,'-B',str(scripts/'c4_packet_smoke.py'),
        '--positive',str(packet),'--out',str(refusal_out)]+[arg for name in selected for arg in ('--case',name)],source)
    refusal=json.loads((refusal_out/'smoke-results.json').read_text())['results']
    need(len(refusal)==6 and {r['case'] for r in refusal}==set(selected)
         and all(r['refused'] is True and r['error'] for r in refusal),'exact six affected copied-packet refusals')
    domain_out=root/'integer-serialized-checks'
    run('c4-integer-serialized-checks63',[sys.executable,'-B',str(scripts/'c4_integer_domain_smoke.py'),
        '--positive',str(packet),'--out',str(domain_out)],source)
    domain=json.loads((domain_out/'result.json').read_text())
    need(len(domain['controls'])==3 and len(domain['results'])==63 and domain['failures']==[]
         and sum(r.get('accepted') is True for r in domain['results'])==3
         and domain['script_sha256']==sha(scripts/'c4_integer_domain_smoke.py')
         and domain['protocol_sha256']==sha(scripts/'c4_protocol.py'),'complete exact-source integer-domain checks')
    need(len(commands)==5 and all(c.get('child_joined') and c.get('custody_released') and c.get('exit_code')==0 and not c.get('timed_out') for c in commands),'exact five supervised commands')
    write(out/'result.json',{'at':now(),'all_commands_pass':True,'commands':5,
        'canonical_trimpath_builds':1,'build_provenance_artifacts_each':12,
        'c4_fresh_one_epoch_candidate_only_leaves':36,
        'c4_reused_normal_race_units_each':65,'c4_reused_phase_epochs':[1,8],
        'fresh_copied_refusals':6,'serialized_actual_controls':3,'serialized_domain_checks':63,
        'upper_bound_admissions':3,'C3_runs':0,'matched_runs':0,'native_qualification':False})
except BaseException as error:
    write(out/'failure.json',{'at':now(),'type':type(error).__name__,'error':str(error),'hidden_retries':0})
    raise
finally:
    closing=[]
    for label,(manifest,authority,modes) in pre_sources.items():
        try:
            verify_source(variants[label],manifest,authority,modes)
            after_modes={f['path']: (Path(variants[label]['source'])/f['path']).stat().st_mode & 0o777 for f in manifest['files']}
            write(out/(label+'-modes-after.json'),after_modes)
            need(after_modes == modes, 'full source modes drift')
            closing.append({'label':label,'full_Git_blob_mode_inventory_unchanged':True})
        except BaseException as error:
            closing.append({'label':label,'full_Git_blob_mode_inventory_unchanged':False,'error':str(error)})
    try:
        toolchain_after=full_toolchain(controls['GOROOT'],settings['full_toolchain_inventory'])
        write(out/'final-full-toolchain.json',toolchain_after)
    except BaseException as error:
        closing.append({'full_toolchain_unchanged':False,'error':str(error)})
    observer_receipts=[json.loads(p.read_text()) for p in out.glob('*-census.json')]
    released=all(c['child_joined'] and c['custody_released'] for c in commands) and all(c['custody_released'] for c in observer_receipts)
    durable(out/'source-after-finally.json',{'at':now(),'sources':closing,
        'all_launched_children_joined':released,'custody_released':released,
        'signals':sticky.signals,'matched_runs':0})
    try:
        need(len(closing)==1 and closing[0]['label']=='c4' and closing[0]['full_Git_blob_mode_inventory_unchanged'], 'complete C4 closing source proof')
    finally:
        sticky.__exit__(None,None,None)
