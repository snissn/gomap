"""C4-only once closer. Failed outcomes remain sealed; unjoined custody refuses export."""
import json,os,shutil,sys,tarfile
from pathlib import Path
from c4_source import authority,verify_source,full_toolchain,endpoint,need,sha,CONTROLLERS,SCRIPTS
settings_path=Path(sys.argv[1])
settings,binding,source_binding=authority(settings_path,sys.argv[2],sys.argv[3])
from custody import StickySignals,durable
namespace=Path(settings['namespace']);admission=Path(settings['out']);v=settings['variants']['c4']
sys.path.insert(0,str(Path(v['source'])/'scripts/cow_c3_read'))
from protocol import write,now,process_environment
sticky=StickySignals();sticky.__enter__()
try:
    after=json.loads((admission/'source-after-finally.json').read_text())
    need(after['custody_released'] is True and after['all_launched_children_joined'] is True,'runtime custody unproven; closer refused')
    commands=json.loads((admission/'commands.json').read_text()) if (admission/'commands.json').exists() else []
    need(all(c['child_joined'] and c['custody_released'] for c in commands),'unjoined controller descendants')
    # Every actual command receipt is retained and authoritative even on failure.
    for c in commands:
        raw=json.loads((admission/(c['label']+'.json')).read_text())
        need(all(c[k]==raw[k] for k in raw),'command/raw custody receipt mismatch')
        for ext in ('stdout','stderr'):
            need(sha(admission/(c['label']+'.'+ext))==c[ext+'_sha256'],'command stream drift')
    errors=[];host=None
    if len(after.get('sources',[]))!=1 or not after['sources'][0].get('full_Git_blob_mode_inventory_unchanged'):
        errors.append({'scope':'runtime-final-source','error':'runtime final source/toolchain proof failed'})
    if after.get('signals'):errors.append({'scope':'runtime-cancellation','error':'runtime retained cancellation'})
    try:host=endpoint('closing-census',namespace,settings,process_environment(settings['controls']),sticky)
    except BaseException as error:errors.append({'scope':'host','type':type(error).__name__,'error':str(error)})
    # Observation failure may retain a failed packet only if its owned ps child is joined.
    raw_host=json.loads((namespace/'closing-census.json').read_text())
    need(raw_host['custody_released'] is True,'closing observer unjoined')
    write(namespace/'closing-host.json',{'observation':host,'errors':errors,'claim':'Bounded observation; no host exclusivity claim'})
    sources=[]
    before=admission/'c4-source-before.json'
    if before.exists():
        try:
            manifest=json.loads(before.read_text());git=json.loads((admission/'c4-git-before.json').read_text())
            modes=json.loads((admission/'c4-modes-before.json').read_text());verify_source(v,manifest,git,modes)
            sources.append({'head':v['head'],'tree':v['tree'],'full_Git_bytes_modes_unchanged':True})
        except BaseException as error:errors.append({'scope':'source','error':str(error)})
    else:errors.append({'scope':'source','error':'source proof not reached'})
    try:write(namespace/'closing-full-toolchain.json',full_toolchain(settings['controls']['GOROOT'],settings['full_toolchain_inventory']))
    except BaseException as error:errors.append({'scope':'toolchain','error':str(error)})
    # Current analyzer is the performance/contract admission authority. The
    # closer records failure; it never converts incomplete/failed monitor data.
    passed=(admission/'result.json').exists() and not (admission/'failure.json').exists() and not errors and not sticky.signals
    if passed:
        need(len(commands)==5 and all(c['exit_code']==0 and not c['timed_out'] for c in commands),'wrong complete action count')
        result=json.loads((admission/'result.json').read_text())
        need(result['c4_fresh_one_epoch_candidate_only_leaves']==36 and result['fresh_copied_refusals']==6
             and result['serialized_domain_checks']==63 and result['serialized_actual_controls']==3,'wrong C4 result scope')
    durable(namespace/'custody-release.json',{'status':'RELEASED','custody_released':True,'all_children_joined':True,
        'functional_pass':passed,'sources':sources,'errors':errors,'signals':sticky.signals,
        'Go_or_test_jobs':0 if host is not None else None,'C3_runs':0,'matched_runs':0,'native_qualification':False})
    packet=namespace/'closed-packet';packet.mkdir(exist_ok=False)
    for name in ('admission','c4/build'):
        source=namespace/name
        if source.exists():shutil.copytree(source,packet/name,copy_function=os.link,symlinks=True)
    for name in ('settings.json','root-final-runtime-binding.json','root-grant.json','previous-lane-release.json',
                 'root-source-binding.json','selected-compiler-equality.json','source-provision-receipt.json',
                 'closing-census.json','closing-census.stdout','closing-census.stderr','closing-host.json',
                 'closing-full-toolchain.json','custody-release.json'):
        source=namespace/name
        if source.exists():shutil.copyfile(source,packet/name)
    shutil.copyfile(settings['full_toolchain_inventory']['path'],packet/'original-full-toolchain-inventory.json')
    for name in CONTROLLERS:shutil.copyfile(Path(__file__).with_name(name),packet/name)
    # Integer smoke is outside the collector's nine script closure; retain it explicitly.
    shutil.copyfile(Path(v['source'])/'scripts/cow_c3_read/c4_integer_domain_smoke.py',packet/'c4_integer_domain_smoke.py')
    files=[]
    for path in sorted(packet.rglob('*')):
        need(not path.is_symlink(),'unexpected portable symlink')
        if path.is_file():files.append({'path':path.relative_to(packet).as_posix(),'bytes':path.stat().st_size,
                                      'mode':path.stat().st_mode & 0o777,'sha256':sha(path)})
        else:need(path.is_dir(),'unexpected portable object')
    write(packet/'packet-file-manifest.json',{'self_excluded':True,'files':files,'links':[],
        'omitted_remote_only':['c4/source','authority.git','source-pack'],'outer_streams':'Retain separately after their actual join; archive cannot seal its own still-open outer stream.'})
    archive=namespace/'standalone-admission-portable.tar.gz';need(not archive.exists(),'archive already attempted')
    with tarfile.open(archive,'w:gz',dereference=False) as tar:tar.add(packet,arcname='packet')
    durable(namespace/'handoff.json',{'status':'RELEASED','custody_released':True,'all_children_joined':True,
        'functional_status':'CLOSED_PASS' if passed else 'CLOSED_FAILURE','functional_pass':passed,
        'errors':errors,'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),
        'manifest_sha256':sha(packet/'packet-file-manifest.json'),'actual_controller_commands':len(commands),
        'C3_runs':0,'matched_runs':0,'native_qualification':False})
finally:
    sticky.__exit__(None,None,None)
