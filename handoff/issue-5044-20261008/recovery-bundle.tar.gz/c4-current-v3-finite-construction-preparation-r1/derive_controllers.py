"""Derive source only; this file never calls any operational controller."""
from pathlib import Path
import ast,json,hashlib,difflib
D=Path(__file__).resolve().parent
N="/home/mikers/gomap-cow-c4-current-v3-20261008-r1"
H="100ca3f775a947ff69564b97ac0c0b86a1dd2cc0";T="549678866e9c6ce065bc9e50c84b9b9139e4a676"
def replace(s,a,b):
 assert a in s,a[:100]
 return s.replace(a,b)
source=(D/"origins/controllers/c4_source.py").read_text()
source=replace(source,"import hashlib","import datetime\nimport platform\nimport hashlib")
source=replace(source,"    verify_provision(settings, source, load_bound(settings['provision_receipt']))","    validate_final_admission(settings, grant, source)\n    verify_provision(settings, source, load_bound(settings['provision_receipt']))")
source=replace(source,"    need(len(affinity)>=4 and load[0]<=host['max_load1']", "    declared=settings['host_identity'];actual=platform.uname()\n    need(actual.system==declared['system']=='Linux' and actual.machine==declared['machine']=='x86_64'\n         and actual.node==declared['node'] and actual.release==declared['release']\n         and os.cpu_count()==declared['cpu_count'] and type(os.cpu_count()) is int and os.cpu_count()>=4, 'declared host identity/CPU admission failed')\n    need(len(affinity)>=4 and load[0]<=host['max_load1']")
source += '''
\nWINDOW_CAP_SECONDS = 16320
V3_SCHEMA = "gomap-cow-sustained-public-v3"

def validate_owner_window(owner, settings, now=None):
    need(owner.get('status')=='APPROVED_BY_NATIVE_OWNER'
         and owner.get('host')=='185'
         and owner.get('namespace')==settings['namespace']
         and owner.get('host_identity')==settings['host_identity']
         and owner.get('wall_cap_seconds')==WINDOW_CAP_SECONDS
         and owner.get('runtime_seconds')==14400 and owner.get('closer_seconds')==1200
         and owner.get('outer_driver_margin_seconds_each')==60
         and owner.get('transport_margin_seconds')==600,
         'specific finite owner window pending')
    def instant(value):
        need(type(value) is str and re.fullmatch(r'\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}Z',value), 'owner UTC window malformed')
        return datetime.datetime.strptime(value,'%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=datetime.timezone.utc)
    start,end=instant(owner.get('not_before')),instant(owner.get('expires_at'))
    need((end-start).total_seconds()==WINDOW_CAP_SECONDS, 'owner wall cap mismatch')
    if now is not None:
        need(start<=now and (end-now).total_seconds()>=15720,
             'owner runtime-plus-mandatory-closer window expired/insufficient')
    return {'not_before':owner['not_before'],'expires_at':owner['expires_at'],
            'wall_cap_seconds':WINDOW_CAP_SECONDS}

def validate_current_functional(proof, variant, expected_closure_sha):
    # This is a required future accepted actual receipt, never an author grant.
    need(proof.get('status')=='ROOT_ACCEPTED_ACTUAL_CURRENT_C4_FUNCTIONAL_APPLICABILITY'
         and proof.get('head')==variant['head'] and proof.get('tree')==variant['tree']
         and proof.get('normal_race_unit_names_each')==65
         and proof.get('phase_iterations')==[1,8]
         and proof.get('expected_normal_compiler_closure_sha256')==expected_closure_sha
         and proof.get('all_source_and_artifact_readers_released') is True
         and proof.get('original_runtime_relabelled') is False,
         'current ordinary normal/race65 applicability pending')
    need(set(proof.get('actual_receipts',{}))=={'normal','race','independent_acceptance'},
         'current actual functional receipt closure missing')
    for row in proof['actual_receipts'].values():load_bound(row)
    return proof

def validate_final_admission(settings, grant, source):
    final=load_bound(source['final_post_C3_applicability'])
    v=settings['variants']['c4']
    need(final.get('status')=='ROOT_ACCEPTED_POST_C3_CURRENT_C4_SOURCE'
         and final.get('C3_landing_complete') is True
         and final.get('head')==v['head']==grant.get('final_after_C3_head')
         and final.get('tree')==v['tree']
         and final.get('selected_current_input_sha256')==source['selected_current_compiler_inputs']['sha256']
         and final.get('current_v3_source_acceptance')==source['current_v3_source_acceptance'],
         'final post-C3 source applicability pending')
    accepted=load_bound(source['current_v3_source_acceptance'])
    need(accepted.get('verdict')=='ACCEPT_C4_CAPTURE_ROOT_BINDING_TOOLING_SOURCE'
         and accepted.get('uncommitted_index_tree')==final.get('tooling_source_tree')
         and accepted.get('findings')==[]
         and accepted.get('all_source_and_artifact_readers_released') is True,
         'v3 tooling source acceptance missing')
    need(grant.get('owner_window')==source['owner_window'], 'root owner window unbound')
    validate_owner_window(load_bound(source['owner_window']),settings)
    validate_current_functional(load_bound(source['current_functional_applicability']),v,
                               source['expected_current_compiler_closure']['sha256'])

def validate_current_build(old, oracle, receipt, actual_closure, expected_closure,
                           controls, env, relocation, namespace, inventory_sha, old_sha):
    normalized=lambda closure:{key:{field:item[field] for field in ('sha256','bytes','mode')} for key,item in closure.items()}
    need(len(actual_closure)==len(expected_closure)==1846
         and normalized(actual_closure)==normalized(expected_closure),
         'complete current1846 actual compiler closure differs from expected inputs')
    for field in COMPILER_IDENTITIES:
        need(old[field]==oracle[field]==receipt[field], 'unchanged nonproduct compiler identity changed '+field)
    comparison=validate_relocation(old,controls,env,relocation,namespace,inventory_sha,old_sha)
    need(receipt['environment']==controls and receipt['effective_process_environment']==env,
         'fresh receipt controls/environment drift')
    comparison.update(normalized_current_compiler_entries=1846,
        historical_P4_binary_sha256=oracle['binary_sha256'],
        fresh_current_binary_sha256=receipt['binary_sha256'],
        historical_binary_reuse_or_relabel=False)
    return comparison
'''
(D/"controllers/c4_source.py").write_text(source)
runner=(D/"origins/controllers/c4_affected_runner.py").read_text()
runner=replace(runner,"validate_trimpath_oracle,validate_build_reuse","validate_trimpath_oracle,validate_current_build,validate_owner_window,validate_current_functional,V3_SCHEMA")
runner=replace(runner,"settings_path=Path(sys.argv[1]);settings,binding,source_binding=authority(settings_path,sys.argv[2],sys.argv[3])","settings_path=Path(sys.argv[1]);settings,binding,source_binding=authority(settings_path,sys.argv[2],sys.argv[3])\nimport datetime\nvalidate_owner_window(load_bound(source_binding['owner_window']),settings,datetime.datetime.now(datetime.timezone.utc))")
runner=replace(runner,"selected_compiler_equality","selected_current_compiler_inputs")
runner=replace(runner,"equality['status']=='CURRENT_C4_SELECTED_GO_COMPILER_BYTES_MODES_BLOBS_EQUAL_ORIGINAL_P2'\n         and equality['all_bytes_modes_blobs_equal'] is True", "equality['status']=='CURRENT_C4_SELECTED_GO_INPUTS_DIFFER_FROM_HISTORICAL_P2'\n         and equality['all_bytes_modes_blobs_equal'] is False\n         and [r['path'] for r in equality['changed_selected_inputs']]==['TreeDB/mvcc/mvcc.go']")
runner=replace(runner," 'selected C4 Go inputs not accepted'"," 'selected current C4 Go input scope changed'")
runner=replace(runner,"relocation=load_bound(source_binding['path_relocation'])","current_functional=validate_current_functional(load_bound(source_binding['current_functional_applicability']),variants['c4'],source_binding['expected_current_compiler_closure']['sha256'])\nexpected_closure=load_bound(source_binding['expected_current_compiler_closure'])\nrelocation=load_bound(source_binding['path_relocation'])")
runner=replace(runner,"relocation_comparison=validate_build_reuse(old_build,old_closure,oracle_build,oracle_closure,receipt,new_closure,","relocation_comparison=validate_current_build(old_build,oracle_build,receipt,new_closure,expected_closure,")
runner=replace(runner,"write(out/'c4-reused-unit-phase-applicability.json'","write(out/'c4-current-unit-phase-applicability.json'")
runner=replace(runner,"'persistent_compiler_bytes_modes_equal':True,","'current_functional_receipt_sha256':source_binding['current_functional_applicability']['sha256'],\n        'historical_selected_input_bytes_equal':False,")
runner=replace(runner,"'claim':'Scoped source/input applicability; original runtime not relabeled to current head'","'claim':'Required current functional receipt bound; original historical runtime not relabeled'")
runner=replace(runner,"Root approved affected C4 integer-domain candidate-only construction","Root approved current v3 C4 candidate-only construction")
runner=replace(runner,"need(completed['runs']==36 and len(actual)==36","c4.validate_completion(completed)\n    need(completed['schema']==V3_SCHEMA and completed['capture_root']==str(packet)\n         and completed['runs']==36 and len(actual)==36")
runner=replace(runner,"    selected=['float-cycles'","    selected=['unrelated-absolute-raw-directory','missing-capture-root','tampered-capture-root',\n              'relative-capture-root','missing-raw-directory','mismatched-output-command',\n              'float-cycles'")
runner=replace(runner,"refusal_out=root/'integer-packet-refusals'","refusal_out=root/'current-v3-packet-refusals'")
runner=replace(runner,"c4-integer-packet-refusals6","c4-current-v3-packet-refusals12")
runner=replace(runner,"need(len(refusal)==6","need(len(refusal)==12")
runner=replace(runner,"exact six affected copied-packet refusals","exact twelve original integer and capture-root copied-packet refusals")
runner=replace(runner,"'c4_reused_normal_race_units_each':65,'c4_reused_phase_epochs':[1,8],","'c4_current_normal_race_units_each':65,'c4_current_phase_epochs':[1,8],")
runner=replace(runner,"'fresh_copied_refusals':6","'schema':V3_SCHEMA,'fresh_copied_refusals':12,'integer_packet_refusals':6,'capture_root_packet_refusals':6")
runner=replace(runner,"need(len(closing)==1 and closing[0]['label']=='c4' and closing[0]['full_Git_blob_mode_inventory_unchanged'], 'complete C4 closing source proof')","need(len(closing)==1 and closing[0]['label']=='c4' and closing[0]['full_Git_blob_mode_inventory_unchanged'], 'complete C4 closing source proof')\n        need(not sticky.signals, 'cancellation retained during final source/toolchain release')")
(D/"controllers/c4_affected_runner.py").write_text(runner)
closer=(D/"origins/controllers/close_packet.py").read_text()
closer=replace(closer,"and result['fresh_copied_refusals']==6","and result['fresh_copied_refusals']==12\n             and result['schema']=='gomap-cow-sustained-public-v3'\n             and result['integer_packet_refusals']==result['capture_root_packet_refusals']==6\n             and result['c4_current_normal_race_units_each']==65 and result['c4_current_phase_epochs']==[1,8]")
(D/"controllers/close_packet.py").write_text(closer)
for p in (D/"controllers").glob("*.py"):ast.parse(p.read_bytes(),filename=str(p))
for name in ("c4_source.py","c4_affected_runner.py","close_packet.py"):
 before=(D/"origins/controllers"/name).read_text().splitlines(keepends=True)
 after=(D/"controllers"/name).read_text().splitlines(keepends=True)
 (D/(name+".patch")).write_text("".join(difflib.unified_diff(before,after,fromfile="original/"+name,tofile="derivative/"+name)))
print("PASS: source-only derivative AST; shared three custody controllers unchanged")
