"""Local source-only preparation; Git reads and private artifact writes only."""
import ast,copy,difflib,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
F=D.parent
L=Path('/private/tmp/gomap-cow-current-authority-20261007')
W=Path('/private/tmp/gomap-cow-execution-o2nauuzm/c4-tools')
N='/home/mikers/gomap-cow-c4-current-v3-20261008-r1'
OLD='/home/mikers/gomap-cow-c4-current-affected-20261007'
H='100ca3f775a947ff69564b97ac0c0b86a1dd2cc0'
T='549678866e9c6ce065bc9e50c84b9b9139e4a676'
B8='b8ef2e4b8a125362a91c7587d474095a339855ae'
B8T='980f0d4d6e6785fa4e21ec0b0f825c15fe513dcd'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def dump(p,j):Path(p).write_text(json.dumps(j,indent=2,sort_keys=True)+'\n')
def desc(p,remote=None):return {'path':remote or str(p),'sha256':sha(p)}
def relocate(j):
 if isinstance(j,str):return j.replace(OLD,N)
 if isinstance(j,list):return [relocate(v) for v in j]
 if isinstance(j,dict):return {k:relocate(v) for k,v in j.items()}
 return j
def copy_exact(p,q,expected=None):
 if expected:assert sha(p)==expected,(p,'original hash mismatch')
 shutil.copyfile(p,q);assert sha(p)==sha(q)
def git(label,args,input=None):
 argv=['git','-C',str(W),*args];begin=time.time()
 r=subprocess.run(argv,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 p=D/'git-observations'/label
 p.with_suffix('.stdout').write_bytes(r.stdout);p.with_suffix('.stderr').write_bytes(r.stderr)
 dump(p.with_suffix('.receipt.json'),{'argv':argv,'elapsed_seconds':time.time()-begin,'exit_code':r.returncode,'joined':True,'stdout_sha256':sha(p.with_suffix('.stdout')),'stderr_sha256':sha(p.with_suffix('.stderr')),'source_checkout_mutated':False})
 assert r.returncode==0,(label,r.stderr)
 return r.stdout
def inventory(raw):
 out={}
 for row in raw.split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,kind,blob=meta.decode().split();out[path.decode()]={'git_mode':mode,'kind':kind,'git_blob':blob}
 return out

# Current source applicability is proved with Git object reads, never a checkout.
assert git('current-tree-r2',['rev-parse',H+'^{tree}']).decode().strip()==T
old=inventory(git('b8-full-tree',['ls-tree','-rz','--full-tree',B8]))
current=load(D/'full-current-Git-mode-object-inventory.json')['files']
selected=load(D/'selected-current-compiler-inputs.json')
for row in selected['files']:
 prior=old[row['path']]
 assert prior['git_blob']==row['git_blob'] and int(prior['git_mode'][-3:],8)==row['mode']
assert len(selected['files'])==408
go_names={p for p in old if p.endswith('.go')}
assert go_names=={p for p in current if p.endswith('.go')}
assert all(old[p]==current[p] for p in go_names)
mods={p for p in old if Path(p).name in ('go.mod','go.sum')}
assert mods=={p for p in current if Path(p).name in ('go.mod','go.sum')}
assert all(old[p]==current[p] for p in mods)
app={'status':'SOURCE_ONLY_GIT_OBJECT_APPLICABILITY','head':H,'tree':T,'runtime_head':B8,'runtime_tree':B8T,'selected_repository_inputs':408,'all_selected_Git_bytes_modes_equal':True,'all_Go_paths':len(go_names),'all_Go_Git_bytes_modes_equal':True,'module_paths':sorted(mods),'all_module_Git_bytes_modes_equal':True,'files':{r['path']:old[r['path']] for r in selected['files']},'runtime_identity_relabelled':False,'Go_executions':0}
dump(D/'current-functional-source-applicability.json',app)

# Retain actual current functional receipt and original streams byte for byte.
P=L/'c4-current-c3-conflict-resolution-r1'
(D/'current-functional-inputs').mkdir(exist_ok=True)
for name in ['functional-local-result.json','source-binding.json','freeze.json']+[mode+'.'+ext for mode in ('c4-fixture-normal-expanded','c4-fixture-race-expanded') for ext in ('stdout','stderr','receipt.json')]:
 copy_exact(P/name,D/'current-functional-inputs'/name)
copy_exact(L/'c4-current-c3-conflict-independent-review-r1/acceptance-receipt.json',D/'current-functional-inputs/independent-acceptance.json','7ec7105cf046a4de4919d10300c0cc9546f1e5563c997d6ab520a1e67bf80aba')
copy_exact(L/'c4-current-c3-conflict-publication-r1/root-acceptance.json',D/'current-functional-inputs/root-acceptance.json','c8ca872af54531d50bb4a18f6cf6969c275c11f0af0afe467429d7266de29cf7')
copy_exact(F/'pr5082-raw-directory-binding-independent-r1/acceptance-receipt.json',D/'prior-scope/current-v3-source-acceptance.json','f379f5cdfaec708fc662b0fa262e0481d5c536b8456849c475a3f29cb9d02495')

# Normative expected closure replaces only the actually changed repository file.
# This is an expected source contract, not an observed fresh compiler closure.
normal=lambda j:{k:{f:r[f] for f in ('sha256','bytes','mode')} for k,r in j.items()}
oldcl=normal(load(D/'prior-scope/original-C4-compiled-input-closure.json'))
assert len(oldcl)==1846 and oldcl==normal(load(D/'prior-scope/accepted-P4-trimpath-closure.json'))
expected=copy.deepcopy(oldcl)
changed=selected['changed_selected_inputs'];assert len(changed)==1 and changed[0]['path']=='TreeDB/mvcc/mvcc.go'
key='REPO/'+changed[0]['path'];assert oldcl[key]=={f:changed[0]['before'][f] for f in ('sha256','bytes','mode')}
expected[key]={f:changed[0]['after'][f] for f in ('sha256','bytes','mode')}
assert sum(oldcl[k]!=expected[k] for k in oldcl)==1
dump(D/'expected-current-compiler-closure.json',expected)
dump(D/'expected-current-compiler-closure-origin.json',{'status':'EXPECTED_SOURCE_DERIVED_CONTRACT_NOT_ACTUAL_FRESH_COMPILER_OBSERVATION','entries':1846,'changed_keys':[key],'unchanged_entries':1845,'original_actual_closure':desc(D/'prior-scope/original-C4-compiled-input-closure.json'),'current_selected_source':desc(D/'selected-current-compiler-inputs.json'),'fresh_actual_closure_required':True,'old_binary_equality_required':False})
selected['proofs']={name:desc(D/'prior-scope'/name,N+'/prior-scope/'+name) for name in ('original-C4-build-receipt.json','original-C4-compiled-input-closure.json','prior-C4-acceptance.json')}
dump(D/'selected-current-compiler-inputs.json',selected)
dump(D/'expected-current-compiler-closure-origin.json',{**load(D/'expected-current-compiler-closure-origin.json'),'current_selected_source':desc(D/'selected-current-compiler-inputs.json')})
def functional_desc(name):return desc(D/'current-functional-inputs'/name,N+'/current-functional-inputs/'+name)
rows={'result':functional_desc('functional-local-result.json'),'source_binding':functional_desc('source-binding.json'),'independent_acceptance':functional_desc('independent-acceptance.json')}
for mode in ('normal','race'):
 base='c4-fixture-'+mode+'-expanded'
 rows[mode]=functional_desc(base+'.receipt.json')
 for ext in ('stdout','stderr'):rows[mode+'_'+ext]=functional_desc(base+'.'+ext)
functional={'status':'SOURCE_DERIVED_CURRENT_C4_FUNCTIONAL_APPLICABILITY','head':H,'tree':T,'runtime_head':B8,'runtime_tree':B8T,'normal_race_unit_names_each':65,'expected_normal_compiler_closure_sha256':sha(D/'expected-current-compiler-closure.json'),'actual_receipts':rows,'independent_acceptance_verdict':'ACCEPT_SOURCE_AND_SCOPED_LOCAL_FUNCTIONAL_C4_CURRENT_C3_CONFLICT_RESOLUTION','source_applicability':desc(D/'current-functional-source-applicability.json',N+'/current-functional-source-applicability.json'),'historical_phase_iterations':[1,8],'current_phase_runtime_relabelled':False,'original_runtime_relabelled':False,'all_source_and_artifact_readers_released':True,'linux_performance_qualification':False}
dump(D/'current-functional-applicability.json',functional)

# Coherent pending final-base and owner contracts remain explicit refusals.
settings=relocate(load(D/'origins/settings.draft.json'));v=settings['variants']['c4'];v.update(head=H,tree=T)
settings['status']='HELD_PROVISIONAL_CURRENT_V3_BEFORE_C3_FINAL_BASE_AND_OWNER_ADMISSION'
settings['controls']['GOMODCACHE']=N+'/go/pkg/mod'
settings['host_identity']={'system':'Linux','node':'mikers-B560-DS3H-AC-Y1','machine':'x86_64','release':'6.8.0-138-generic'}
dump(D/'settings.draft.json',settings)
rel=relocate(load(D/'origins/path-relocation.draft.json'))
rel['paths']['GOMODCACHE']['after']=settings['controls']['GOMODCACHE']
dump(D/'path-relocation.json',rel)
source=relocate(load(D/'origins/source-binding.draft.json'))
source['products']['c4'].update(head=H,tree=T)
source.pop('selected_compiler_equality')
source['retained_scripts']=load(D/'current-C4-eleven-script-bindings.json')['retained_scripts']
for key,name in [('selected_current_compiler_inputs','selected-current-compiler-inputs.json'),('expected_current_compiler_closure','expected-current-compiler-closure.json'),('current_functional_applicability','current-functional-applicability.json'),('path_relocation','path-relocation.json')]:source[key]=desc(D/name,N+'/'+name)
source['current_v3_source_acceptance']=desc(D/'prior-scope/current-v3-source-acceptance.json',N+'/prior-scope/current-v3-source-acceptance.json')
for key,name in [('final_post_C3_applicability','final-post-C3-applicability.json'),('owner_window','owner-window.json')]:source[key]={'path':N+'/'+name,'sha256':None}
source['resource_reservation']={'status':'HELD_NATIVE_OWNER_DECLINES_WHILE_185_PACKET_ACTIVE','host':'185','owner_window_required':True,'claim':'No current host observation, exclusion, reservation or runtime authority'}
dump(D/'source-binding.draft.json',source)
owner={'status':'HELD_NATIVE_OWNER_DECLINES_ACTIVE_PACKET','host':'185','namespace':N,'host_identity':settings['host_identity'],'not_before':None,'expires_at':None,'wall_cap_seconds':16320,'runtime_seconds':14400,'closer_seconds':1200,'outer_driver_margin_seconds_each':60,'transport_margin_seconds':600,'runtime_grant':'HELD','claim':'Proposed finite window; only native owner may approve actual dates/host lane'}
dump(D/'templates/owner-window.pending.json',owner)
final={'status':'HELD_C3_LANDING_AND_FINAL_BASE_RECONCILIATION_REQUIRED','C3_landing_complete':False,'head':None,'tree':None,'provisional_head':H,'provisional_tree':T,'selected_current_input_sha256':None,'current_v3_source_acceptance':source['current_v3_source_acceptance'],'tooling_source_tree':T,'required_documentation_refresh':{'path':'scripts/cow_c3_read/README.md','old':'The C4 schema v2 finite construction disables','new':'The finite C4 construction disables'},'runtime_grant':'HELD'}
dump(D/'templates/final-post-C3-applicability.pending.json',final)

# Bind actual acceptance to its actual source/result semantics, not an alias.
p=D/'controllers/c4_source.py';s=p.read_text()
s=s.replace("and proof['independent_acceptance_verdict'].startswith('ACCEPT')", "and proof['independent_acceptance_verdict']=='ACCEPT_SOURCE_AND_SCOPED_LOCAL_FUNCTIONAL_C4_CURRENT_C3_CONFLICT_RESOLUTION'\n         and accepted.get('head')==source['head'] and accepted.get('tree')==source['tree']\n         and accepted.get('author_source_binding_sha256')==rows['source_binding']['sha256']")
p.write_text(s)
p=D/'controllers/c4_affected_runner.py';s=p.read_text();needle="write(out/'runner-receipt.json'"
s=s.replace(needle,"shutil.copytree(Path(settings['namespace'])/'current-functional-inputs',proof_dir/'current-functional-inputs')\nshutil.copyfile(Path(settings['namespace'])/'current-functional-source-applicability.json',proof_dir/'current-functional-source-applicability.json')\n"+needle)
p.write_text(s)
for name in ('c4_source.py','c4_affected_runner.py','close_packet.py'):
 ast.parse((D/'controllers'/name).read_text())
 (D/(name+'.patch')).write_text(''.join(difflib.unified_diff((D/'origins/controllers'/name).read_text().splitlines(True),(D/'controllers'/name).read_text().splitlines(True),fromfile='historical/'+name,tofile='current-v3/'+name)))
binding=relocate(load(D/'origins/controller-binding.draft.json'))
binding['controller_files']={p.name:sha(p) for p in (D/'controllers').iterdir() if p.is_file()}
assert len(binding['controller_files'])==6
dump(D/'controller-binding.draft.json',binding)
provider=Path('/private/tmp/gomap-cow-c4-source-transport-preparation-20261007/source-provision-self-contained-c4.py')
copy_exact(provider,D/'source-provision-self-contained-c4.py','b8405cd9d6ff1c960467428b1ad2a108be00edbcca307f5884d781c9a8c7ca94')
products=relocate(load(D/'origins/root-source-products.json'))
products.update(status='HELD_PROVISIONAL_SOURCE_PACK_REQUIRES_FINAL_C3_BASE_REFRESH',pack_bytes=None,pack_sha256=None)
products['products']['c4'].update(head=H,tree=T)
products['shared_tooling_sha256']={Path(k).name:r['sha256'] for k,r in source['retained_scripts'].items()}
dump(D/'root-source-products.json',products)

# The old source-only sealer is narrowly derived; its operational main is never run.
s=(D/'origins/seal_c4_preparation.py').read_text().replace(OLD,N).replace('4282ce946d0e9e169731d1dd3865ddaadc5ffc12',H).replace('9595e67d57a60c7ec81f79356481cc759d3df235',T)
s=s.replace("selected_compiler_equality","selected_current_compiler_inputs")
s=s.replace("equality['all_bytes_modes_blobs_equal'] is True", "equality['all_bytes_modes_blobs_equal'] is False and [r['path'] for r in equality['changed_selected_inputs']]==['TreeDB/mvcc/mvcc.go']")
needle=" settings['provision_receipt']=descriptor(source_receipt);"
s=s.replace(needle," m.validate_final_admission(settings,auth,source)\n import datetime\n m.validate_owner_window(bound(source['owner_window']),settings,datetime.datetime.now(datetime.timezone.utc))\n"+needle)
s=s.replace("'82cab3c081132fa5cf4da53dc3169b875a0cba7c5d7899543dc0049988968cc4'","'BUNDLE_PENDING_FINAL_HASH'")
(D/'seal_c4_preparation.py').write_text(s);ast.parse(s)
auth=relocate(load(D/'origins/root-authorization.pending.json'))
auth.update(head=H,tree=T,final_after_C3_head=None,owner_window=source['owner_window'],bundle_sha256=None,sealer_sha256=None,status='HELD_SOURCE_REVIEW_FINAL_C3_BASE_ACTUAL_PROVISION_OWNER_WINDOW_LANE_RELEASE_REQUIRED')
dump(D/'root-authorization.pending.json',auth)

# Draft configuration carries genuine schema/matrix/limits, no fabricated build.
sys.path.insert(0,str(D/'retained-scripts'))
from prepare_c4_config import draft
config=draft();config['environment']=settings['controls']
config['status']='draft';config['coordinator_acceptance']=None
config['noise_policy'].update(max_spread_fraction=.30,material_regression_fraction=.05,minimum_effect_fraction=.10)
for variant in config['variants'].values():variant.update(production_commit=H,production_git_tree=T,source=N+'/c4/source')
config['host'].update(**settings['host_identity'],cpu_count=None,cpu_affinity=None,max_load1=5,max_load5=5,min_free_bytes=20<<30,tmpdir=N+'/tmp',tmpdir_device=None)
assert config['schema']=='gomap-cow-sustained-public-v3' and len(config['cases'])==36 and all(c['iterations']==c['warmup_iterations']==1 for c in config['cases'])
dump(D/'config.draft.json',config)
dump(D/'preparation-local-result.json',{'status':'PASS_SOURCE_ONLY_DERIVATION_HELD_RUNTIME','head':H,'tree':T,'selected_inputs':408,'historical_changed_selected_paths':['TreeDB/mvcc/mvcc.go'],'b8_selected_Git_bytes_modes_equal':True,'all_b8_Go_inputs':len(go_names),'all_b8_Go_modules_Git_bytes_modes_equal':True,'expected_current_compiler_entries':1846,'actual_current_compiler_observation':False,'current65normal_race_runtime_identity':B8,'actual_v3_leaves_generated':0,'Go_executions':0,'SSH_executions':0,'operational_mains_executed':0,'source_checkout_mutations':0,'runtime_grant':'HELD'})
print('PASS source-only current408 applicability, actual65 bindings, expected1846 closure and coherent held derivative')
