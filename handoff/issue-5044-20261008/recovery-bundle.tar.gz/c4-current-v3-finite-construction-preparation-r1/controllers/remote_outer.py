"""Once action sequence; an owner proof gates mandatory closure after runtime."""
import json
from pathlib import Path
import sys
from custody import StickySignals,supervise,read_release,durable


def execute(action,sticky,cleanup=False):
    proof=Path(action['custody_proof'])
    row=supervise(action['label'],action['argv'],action['cwd'],action['environment'],
        action['timeout_seconds'],action['receipt_directory'],sticky,
        owner_proof=lambda r:read_release(proof),cleanup=cleanup,receipt_fields=action)
    # Preserve the exact root-granted action alongside actual supervised facts.
    # The supervised receipt is itself durable before any cancellation restore.
    return row


def main():
    actions=json.loads(Path(sys.argv[1]).read_text())
    assert len(actions) in (1,2)
    records=[]
    root=Path(actions[0]['cwd'])
    with StickySignals() as sticky:
        for index,action in enumerate(actions):
            if index and not records[-1]['custody_released']:
                break
            records.append(execute(action,sticky,cleanup=index>0))
        summary={'records':records,'signals':sticky.signals,
                 'custody_released':len(records)==len(actions) and all(r['custody_released'] for r in records),
                 'mandatory_closer_skipped_if_runtime_unproven':len(records)!=len(actions)}
        # A single-action construction driver is proved by its retained action
        # receipt; the matched pair additionally retains the sequence proof.
        if len(actions)==2:durable(root/'outer-sequence-custody.json',summary)
        code=next((r['exit_code'] for r in records if r['exit_code']),0)
        if sticky.signals:code=128+sticky.signals[0]['signal']
        if not summary['custody_released']:code=code or 1
        return 128+(-code) if code<0 else code


if __name__=='__main__':sys.exit(main())
