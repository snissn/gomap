"""Once supervised outer drivers; remote custody is never inferred from transport loss."""
import fcntl,hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def group_exists(pgid):
    try:
        os.killpg(pgid,0)
        return True
    except ProcessLookupError:
        return False

def signal_group(pgid,signum):
    try:
        os.killpg(pgid,signum)
    except ProcessLookupError:
        pass

from custody import StickySignals,supervise as protected_supervise,read_release,durable

def supervise(label,argv,cwd,environment,timeout,directory,sticky,proof,cleanup=False):
    return protected_supervise(label,argv,cwd,environment,timeout,directory,sticky,
                               owner_proof=lambda r:read_release(proof),cleanup=cleanup)

def seal_inner_receipt(action,driver):
    # A normally exited driver alone says nothing about its separate-session
    # child. Require the actual sealed action receipt and both retained streams.
    directory=Path(action['receipt_directory']);label=action['label']
    path=directory/(label+'.json')
    assert path.is_file() and not path.is_symlink(), 'missing regular inner receipt: '+label
    receipt=json.loads(path.read_text())
    for key,value in action.items():
        assert receipt[key]==value, 'inner action drift: '+label+' '+key
    assert receipt['joined'] is True and receipt['custody_released'] is True, 'inner descendant custody unproven: '+label
    status=receipt['wait_status']
    assert type(status) is int and (os.WIFEXITED(status) or os.WIFSIGNALED(status)), 'invalid inner wait status: '+label
    assert type(receipt['exit_code']) is int and receipt['exit_code']==os.waitstatus_to_exitcode(status), 'inner exit mismatch: '+label
    # Cancellation can change the driver's own exit; the exact retained inner
    # wait4 and descendant proof, rather than exit equality, prove completion.
    assert type(receipt['timed_out']) is bool, 'missing inner timeout state: '+label
    for extension in ('stdout','stderr'):
        stream=directory/(label+'.'+extension)
        assert stream.is_file() and not stream.is_symlink(), 'missing regular inner stream: '+label
        assert digest(stream)==receipt[extension+'_sha256'], 'inner stream hash drift: '+label
    return {'label':label,'path':str(path),'sha256':digest(path),'joined':True,
            'actual_action_exact':True,'stream_hashes_verified':True,
            'exit_code':receipt['exit_code'],'timed_out':receipt['timed_out']}

def main():
    root=Path(__file__).resolve().parent
    # Keep the owned namespace lock through both runtime and mandatory closure.
    # The non-inheritable descriptor is released when this supervisor exits.
    lock_fd=os.open(root/'collection.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
    fcntl.flock(lock_fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for name in ('admission','outer-receipts','closed-packet','handoff.json','runtime-execution.json','outer-driver-receipts'):
        assert not (root/name).exists(), 'runtime already attempted: '+name
    fd=os.open(root/'runtime-launch.claim',os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o644)
    with os.fdopen(fd,'w') as f:f.write(json.dumps({'pid':os.getpid(),'at':time.time()})+'\n')
    actions=json.loads((root/'outer-actions.json').read_text())
    assert len(actions)==2 and [a['label'] for a in actions]==['standalone-runtime','standalone-closure']
    assert json.loads((root/'runtime-action.json').read_text())==[actions[0]]
    assert json.loads((root/'closure-action.json').read_text())==[actions[1]]
    directory=root/'outer-driver-receipts';directory.mkdir(exist_ok=False)
    sticky=StickySignals();sticky.__enter__();signals=sticky.signals
    records=[];inner_receipts=[];first=1;second=None;custody='REMOTE_CUSTODY_UNCERTAIN_HELD';failure=None
    try:
        environment={'PATH':'/bin:/usr/bin','LC_ALL':'C'}
        runtime=supervise('runtime-outer-driver',['/usr/bin/python3','-B',str(root/'remote_outer.py'),str(root/'runtime-action.json')],
                           root,environment,actions[0]['timeout_seconds']+60,directory,sticky,
                           Path(actions[0]['receipt_directory'])/(actions[0]['label']+'.json'))
        records.append(runtime);first=runtime['exit_code'] if runtime['exit_code'] is not None else 1
        if runtime['outer_driver_completion_proven']:
            inner_receipts.append(seal_inner_receipt(actions[0],runtime))
            # Ordinary nonzero exit still gets exactly one mandatory closure.
            closure=supervise('closure-outer-driver',['/usr/bin/python3','-B',str(root/'remote_outer.py'),str(root/'closure-action.json')],
                               root,environment,actions[1]['timeout_seconds']+60,directory,sticky,
                               Path(actions[1]['receipt_directory'])/(actions[1]['label']+'.json'),cleanup=True)
            records.append(closure);second=closure['exit_code']
            if closure['outer_driver_completion_proven']:
                inner_receipts.append(seal_inner_receipt(actions[1],closure))
                custody='RELEASE_REQUIRES_SUCCESSFUL_SEALED_CLOSURE_AND_ROOT_AUDIT'
    except BaseException as error:
        failure={'type':type(error).__name__,'error':str(error)}
        custody='REMOTE_CUSTODY_UNCERTAIN_HELD'
    finally:
        if signals and custody!='REMOTE_CUSTODY_UNCERTAIN_HELD':custody='JOINED_SIGNAL_REFUSAL_HELD_ROOT_REVIEW'
        durable(root/'runtime-execution.json',{'records':records,'signals':signals,
            'inner_receipts':inner_receipts,'inner_receipt_validation_exception':failure,
            'both_inner_action_receipts_sealed':len(inner_receipts)==2,
            'signal_refusal':bool(signals),'runtime_exit':first,'closure_exit':second,'custody':custody,
            'closure_skipped_if_runtime_outer_completion_unproven':second is None})
        sticky.__exit__(None,None,None)
    return (128+signals[0]['signal']) if signals else (first or second or (1 if custody=='REMOTE_CUSTODY_UNCERTAIN_HELD' else 0))

if __name__=='__main__':
    sys.exit(main())
