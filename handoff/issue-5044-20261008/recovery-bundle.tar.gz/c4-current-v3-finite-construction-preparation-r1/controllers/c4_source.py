"""C4-only authority and observation helpers. No operational entrypoint."""
import datetime
import platform
import hashlib
import json
import os
import re
import shutil
from pathlib import Path

CONTROLLERS = {'c4_source.py', 'c4_affected_runner.py', 'close_packet.py',
               'custody.py', 'remote_outer.py', 'remote_execute_once.py'}
SCRIPTS = {'protocol.py', 'build.py', 'collect.py', 'analyze.py', 'c4_protocol.py',
           'prepare_c4_config.py', 'c4_analyze.py', 'c4_packet_smoke.py',
           'prepare_config.py', 'c4_integer_domain_smoke.py', 'host_isolation_test.py'}

def need(value, message):
    if not value: raise ValueError(message)

def sha(path):
    p = Path(path)
    need(p.is_file() and not p.is_symlink(), 'nonregular input ' + str(p))
    return hashlib.sha256(p.read_bytes()).hexdigest()

def load_bound(proof):
    need(type(proof) is dict and set(proof) >= {'path', 'sha256'}, 'missing descriptor')
    need(type(proof['sha256']) is str and re.fullmatch('[0-9a-f]{64}', proof['sha256']), 'pending proof hash')
    need(sha(proof['path']) == proof['sha256'], 'proof drift')
    return json.loads(Path(proof['path']).read_text())

def settings_shape(settings):
    need(settings.get('runtime_grant') == 'GRANTED_BY_ROOT', 'runtime grant pending')
    n = settings['namespace']; need(type(n) is str,'namespace pending'); root = Path(n)
    need(type(n) is str and root.is_absolute() and str(root) == n and '..' not in root.parts, 'noncanonical namespace')
    need(set(settings['variants']) == {'c4'}, 'C4-only product')
    v = settings['variants']['c4']
    for k in ('head', 'tree'):
        need(type(v[k]) is str and re.fullmatch('[0-9a-f]{40}', v[k]), 'final Git pin pending')
    for k, suffix in [('source', 'c4/source'), ('build', 'c4/build')]:
        need(v[k] == str(root / suffix), 'product path outside owned namespace')
    need(settings['out'] == str(root / 'admission'), 'wrong admission root')
    need(settings['git_repository'] == str(root / 'authority.git'), 'wrong Git authority')
    need(settings['controls']['TMPDIR'] == str(root / 'tmp'), 'wrong owned TMPDIR')
    need(set(settings['staged_post_mode_manifests']) == {'c4'}, 'missing staging proof')
    return root, v

def authority(settings_path, binding_path, expected_sha):
    need(type(expected_sha) is str and re.fullmatch('[0-9a-f]{64}', expected_sha), 'operative binding pending')
    settings = json.loads(Path(settings_path).read_text()); root, v = settings_shape(settings)
    binding = load_bound({'path':str(binding_path), 'sha256':expected_sha})
    need(binding['status'] == 'GRANTED_BY_ROOT' and binding['settings_sha256'] == sha(settings_path), 'unbound settings/grant')
    need(set(binding['controller_files']) == CONTROLLERS, 'incomplete controller closure')
    here = Path(__file__).resolve().parent
    for name, wanted in binding['controller_files'].items():
        need(type(wanted) is str and re.fullmatch('[0-9a-f]{64}', wanted) and sha(here/name)==wanted, 'unbound controller ' + name)
    reviewed = load_bound(binding['shared_helper_acceptance'])
    need(reviewed['accepted'] is True and all(reviewed['controller_files'][name] == binding['controller_files'][name]
         for name in ('custody.py','remote_outer.py','remote_execute_once.py')), 'shared utility not accepted')
    grant = load_bound(binding['root_grant']); release = load_bound(binding['previous_lane_release'])
    need(grant['runtime_grant']=='GRANTED_BY_ROOT' and grant['namespace']==str(root)
         and grant['scope']=='AFFECTED_C4_CURRENT_SOURCE_CONSTRUCTION_ONLY'
         and grant['head']==v['head'] and grant['tree']==v['tree']
         and grant['C3_runs']==grant['matched_runs']==0 and grant['native_qualification'] is False, 'wrong root grant')
    need(release['status']=='RELEASED' and release['all_children_joined'] is True
         and release['Go_or_test_jobs']==0, 'prior lane unreleased')
    source = load_bound({'path':settings['root_source_binding_path'], 'sha256':settings['root_source_binding_sha256']})
    need(set(source['products'])=={'c4'} and all(source['products']['c4'][k]==v[k] for k in ('head','tree')), 'source pin drift')
    pins = source['retained_scripts']
    need(set(pins)=={'scripts/cow_c3_read/'+x for x in SCRIPTS}, 'incomplete current C4 tooling closure')
    for name, row in pins.items():
        path=Path(v['source'])/name
        need(sha(path)==row['sha256'] and path.stat().st_size==row['bytes']
             and path.stat().st_mode & 0o777 == int(row['git_mode'][-3:],8), 'source script drift '+name)
    validate_final_admission(settings, grant, source)
    verify_provision(settings, source, load_bound(settings['provision_receipt']))
    return settings, binding, source

def verify_source(v, before, git_proof, modes):
    from build import verify_git_receipt
    verify_git_receipt(v['source'], before, git_proof) # offline retained raw Git objects
    need(before['git_head']==v['head'] and before['git_tree']==v['tree'], 'Git proof product drift')
    names={row['path'] for row in before['files']}
    root=Path(v['source']); need(root.is_dir() and not root.is_symlink() and root.resolve()==root, 'noncanonical source')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() or p.is_symlink()}
    need(actual==names, 'extra/missing source entries')
    for row in before['files']:
        path=root/row['path'];need(not path.is_symlink() and path.is_file(), 'nonregular Git source')
        need(path.stat().st_mode & 0o777 == modes[row['path']] == (0o755 if row['git_mode']=='100755' else 0o644), 'source mode drift')

def full_toolchain(goroot, proof):
    old=load_bound(proof); files=old['files']; root=Path(goroot)
    need(len(files)==15036 and old['Go_executions']==0, 'full official toolchain authority')
    need(root.is_dir() and not root.is_symlink() and root.resolve()==root, 'noncanonical toolchain')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() or p.is_symlink()}
    need(actual==set(files), 'full toolchain file set drift')
    for name,row in files.items():
        rel=Path(name);need(not rel.is_absolute() and '..' not in rel.parts and rel.as_posix()==name, 'unsafe inventory path')
        p=root/rel;need(row['symlink'] is False and sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
                       and p.stat().st_mode & 0o777 == row['mode'], 'toolchain file drift '+name)
    return {'files':len(files),'inventory_sha256':proof['sha256'],'Go_executions':0}

def endpoint(label, out, settings, env, sticky):
    from custody import supervise
    from protocol import HOST_ISOLATION, process_census, linux_comm
    v=settings['variants']['c4']
    row=supervise(label,['ps','-eo',HOST_ISOLATION['ps_fields'],'--no-headers'],v['source'],env,
                  HOST_ISOLATION['max_observation_gap_seconds'],out,sticky)
    need(row['started_child'] and row['custody_released'] and row['exit_code']==0 and not row['timed_out'], 'endpoint capture failed')
    process_census((Path(out)/(label+'.stdout')).read_text(), benchmark_names=(linux_comm(str(Path(v['build'])/'cowsustained-normal.test')),))
    load=list(os.getloadavg()); free=shutil.disk_usage(settings['namespace']).free
    host=settings['host_gate'];affinity=sorted(os.sched_getaffinity(0))
    declared=settings['host_identity'];actual=platform.uname()
    need(actual.system==declared['system']=='Linux' and actual.machine==declared['machine']=='x86_64'
         and actual.node==declared['node'] and actual.release==declared['release']
         and os.cpu_count()==declared['cpu_count'] and type(os.cpu_count()) is int and os.cpu_count()>=4, 'declared host identity/CPU admission failed')
    need(len(affinity)>=4 and load[0]<=host['max_load1'] and load[1]<=host['max_load5'] and free>=host['min_free_bytes'], 'quiet host/load/storage admission failed')
    return {'raw_receipt':row,'load':load,'free_bytes':free,'cpu_count':os.cpu_count(),'cpu_affinity':affinity,'Go_or_test_jobs':0,'claim':'Bounded comm-only observation, not exclusive-host proof'}

PATH_CONTROLS = {'GOCACHE', 'GOROOT', 'GOMODCACHE', 'TMPDIR'}
SEMANTIC_CONTROLS = {'GOFLAGS':'', 'GOGC':'100', 'GOMAXPROCS':'4', 'GOMEMLIMIT':'off', 'GOWORK':'off'}
TRIMPATH_BINARY = '7b0aaef75a157e41395c3f4e4e9031006aa6b54ef0422d70d9810ce6d4f1721c'
TRIMPATH_RECEIPT = '3754385c0d95c0aa6cc8278cd0d4b8e2e79770960733ad85bb6d9032f7cf18c1'
COMPILER_IDENTITIES = ('go_version','go_binary_sha256','toolchain_identity',
                       'external_input_identity','effective_module_identity','harness_input_identity')

def canonical_path(value):
    need(type(value) is str and Path(value).is_absolute() and str(Path(value))==value
         and '..' not in Path(value).parts, 'noncanonical relocation path')

def validate_relocation(old, controls, env, relocation, namespace, inventory_sha, old_sha):
    need(relocation['status']=='ROOT_BOUND_PATH_RELOCATION'
         and relocation['original_build_receipt_sha256']==old_sha
         and relocation['full_toolchain_inventory_sha256']==inventory_sha, 'relocation proof authority mismatch')
    need(set(relocation['paths'])==PATH_CONTROLS, 'closed four path relocation map')
    need(set(controls)==PATH_CONTROLS|set(SEMANTIC_CONTROLS)
         and set(old['environment'])==set(controls), 'closed nine controls')
    for key,wanted in SEMANTIC_CONTROLS.items():
        need(old['environment'][key]==controls[key]==wanted, 'semantic control changed '+key)
    for key,row in relocation['paths'].items():
        need(set(row)=={'before','after'}, 'closed relocation row')
        canonical_path(row['before']);canonical_path(row['after'])
        need(row['before']==old['environment'][key] and row['after']==controls[key], 'unbound path '+key)
    need(controls['TMPDIR']==str(Path(namespace)/'tmp'), 'wrong owned relocated TMPDIR')
    expected=dict(old['effective_process_environment']);need(len(expected)==17 and set(env)==set(expected), 'closed seventeen environment fields')
    for key in controls:expected[key]=controls[key]
    for values in (old['environment'],controls):
        need(Path(values['GOMODCACHE']).parts[-2:]==('pkg','mod'), 'GOMODCACHE cannot derive GOPATH')
    need(old['effective_process_environment']['GOPATH']==str(Path(old['environment']['GOMODCACHE']).parent.parent), 'historical GOPATH mismatch')
    expected['GOPATH']=str(Path(controls['GOMODCACHE']).parent.parent)
    need(env==expected, 'effective environment changed outside explicit relocation/derived GOPATH')
    return {'paths':relocation['paths'], 'literal_semantic_controls':SEMANTIC_CONTROLS,
            'derived_GOPATH':{'before':old['effective_process_environment']['GOPATH'],'after':expected['GOPATH']},
            'complete_environment_fields':17,'nonpath_environment_equal':True,
            'relocation_proof_bound':True}

def verify_provision(settings, source, provision):
    v=settings['variants']['c4'];bound=source['products']['c4']
    need(provision['status']=='SOURCE_ONLY_SELF_CONTAINED_GIT_BYTES_MODES'
         and set(provision['products'])=={'c4'} and provision['Go_executions']==0
         and provision['runtime_grant']=='HELD' and provision['authority_alternate_consumers']==[], 'invalid C4 provision receipt')
    product=provision['products']['c4']
    for key in ('head','tree'):need(product[key]==bound[key]==v[key], 'provision product pin drift')
    joins={'source_manifest_sha256':v['staged_source_manifest'],
           'git_authority_sha256':v['staged_git_authority'],
           'mode_manifest_sha256':settings['staged_post_mode_manifests']['c4']['path']}
    for key,path in joins.items():
        need(product[key]==bound[key]==sha(path), 'provision staged hash drift '+key)
    manifest=json.loads(Path(v['staged_source_manifest']).read_text())
    need(manifest['git_head']==v['head'] and manifest['git_tree']==v['tree']
         and type(product['files']) is int and product['files']==len(manifest['files']), 'provision manifest/source count drift')
    load_bound(settings['staged_post_mode_manifests']['c4'])
    for key in ('pack_sha256','source_provision_sha256'):
        need(type(bound[key]) is str and re.fullmatch('[0-9a-f]{64}',bound[key])
             and provision[key]==bound[key], 'provision authority hash drift '+key)
    need(type(bound['archive_sha256']) is str and re.fullmatch('[0-9a-f]{64}',bound['archive_sha256'])
         and product['archive_sha256']==bound['archive_sha256'], 'provision archive hash drift')
    return {'product':'c4','head':v['head'],'tree':v['tree'],'source':v['source'],
            'actual_product_schema_joined':True,'files':product['files']}

def validate_trimpath_oracle(acceptance, oracle, receipt_sha):
    need(acceptance['verdict']=='ACCEPT_ACTUAL_SCOPED_TRIMPATH_AFFINITY_FRESH_CONSTRUCTION', 'P4 trimpath acceptance missing')
    products=[p for p in acceptance['products'] if p['label']=='c4']
    need(len(products)==1 and products[0]['receipt_sha256']==receipt_sha==TRIMPATH_RECEIPT
         and products[0]['binary_sha256']==oracle['binary_sha256']==TRIMPATH_BINARY, 'P4 trimpath binary/receipt authority drift')
    command=oracle['command']
    need(command==[str(Path(oracle['environment']['GOROOT'])/'bin/go'),'test','-c','-trimpath','-o',command[5],'./TreeDB/mvcc/cowsustained']
         and Path(command[5]).name=='cowsustained-normal.test'
         and oracle['suite']=='c4' and oracle['race'] is False and oracle['build_tags']==[]
         and oracle['exit_code']==0, 'noncanonical P4 trimpath oracle')

WINDOW_CAP_SECONDS = 16320
V3_SCHEMA = "gomap-cow-sustained-public-v3"

def validate_owner_window(owner, settings, now=None):
    need(owner.get('status')=='APPROVED_BY_NATIVE_OWNER'
         and owner.get('host')=='185'
         and owner.get('namespace')==settings['namespace']
         and owner.get('host_identity')==settings['host_identity']
         and all(type(owner.get(k)) is int for k in ('wall_cap_seconds','runtime_seconds','closer_seconds','outer_driver_margin_seconds_each','transport_margin_seconds'))
         and 1920<owner.get('wall_cap_seconds')<=WINDOW_CAP_SECONDS
         and owner.get('runtime_seconds')==min(14400,owner['wall_cap_seconds']-1920) and owner.get('closer_seconds')==1200
         and owner.get('outer_driver_margin_seconds_each')==60
         and owner.get('transport_margin_seconds')==600,
         'specific finite owner window pending')
    def instant(value):
        need(type(value) is str and re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z',value), 'owner UTC window malformed')
        return datetime.datetime.strptime(value,'%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=datetime.timezone.utc)
    start,end=instant(owner.get('not_before')),instant(owner.get('expires_at'))
    need((end-start).total_seconds()==owner['wall_cap_seconds'], 'owner wall cap mismatch')
    if now is not None:
        need(start<=now and (end-now).total_seconds()>=owner['runtime_seconds']+1320,
             'owner runtime-plus-mandatory-closer window expired/insufficient')
    return {'not_before':owner['not_before'],'expires_at':owner['expires_at'],
            'wall_cap_seconds':owner['wall_cap_seconds'],'runtime_seconds':owner['runtime_seconds'],
            'inner_action_caps_unchanged':[600,10800,600,600,600]}

def validate_current_functional(proof, variant, expected_closure_sha):
    # Source-derived applicability binds the unchanged actual b8 packet. It is
    # not a replacement actual execution or author/root runtime grant.
    need(proof.get('status')=='SOURCE_DERIVED_CURRENT_C4_FUNCTIONAL_APPLICABILITY'
         and proof.get('head')==variant['head'] and proof.get('tree')==variant['tree']
         and type(proof.get('normal_race_unit_names_each')) is int
         and proof.get('normal_race_unit_names_each')==65
         and proof.get('expected_normal_compiler_closure_sha256')==expected_closure_sha
         and proof.get('all_source_and_artifact_readers_released') is True
         and proof.get('original_runtime_relabelled') is False,
         'current ordinary normal/race65 applicability pending')
    need(set(proof.get('actual_receipts',{}))=={'result','source_binding','normal','race','normal_stdout','normal_stderr','race_stdout','race_stderr','independent_acceptance'},
         'current actual functional receipt closure missing')
    rows=proof['actual_receipts']
    result=load_bound(rows['result']); source=load_bound(rows['source_binding'])
    need(source['head']==proof['runtime_head'] and source['tree']==proof['runtime_tree'], 'actual functional source drift')
    applicability=load_bound(proof['source_applicability'])
    need(applicability['all_selected_Git_bytes_modes_equal'] is True
         and applicability['runtime_head']==source['head'] and applicability['runtime_tree']==source['tree']
         and applicability['head']==variant['head'] and applicability['tree']==variant['tree']
         and applicability['selected_repository_inputs']==408, 'current selected-source applicability drift')
    accepted=load_bound(rows['independent_acceptance'])
    need(accepted.get('verdict')==proof.get('independent_acceptance_verdict')
         and type(proof.get('independent_acceptance_verdict')) is str
         and proof['independent_acceptance_verdict']=='ACCEPT_SOURCE_AND_SCOPED_LOCAL_FUNCTIONAL_C4_CURRENT_C3_CONFLICT_RESOLUTION'
         and accepted.get('head')==source['head'] and accepted.get('tree')==source['tree']
         and accepted.get('author_source_binding_sha256')==rows['source_binding']['sha256']
         and accepted.get('findings')==[]
         and accepted.get('all_source_and_artifact_readers_released') is True,
         'current independent functional acceptance pending')
    need(len(result['checks'])==2 and result['linux_qualification'] is False
         and result['performance_acceptance'] is False, 'wrong actual functional scope')
    names=[]
    for index,mode in enumerate(('normal','race')):
        row=load_bound(rows[mode]);need(row==result['checks'][index], 'actual functional receipt/result mismatch')
        need(row['exit_code']==0 and row['joined'] is True and row['group_absent'] is True
             and row['signals_sent']==[] and row['test_pass_events']==65
             and row['fail_or_skip_events']==0 and row['package_pass'] is True,
             'actual normal/race functional result failed')
        for stream in ('stdout','stderr'):
            descriptor=rows[mode+'_'+stream]
            need(sha(descriptor['path'])==descriptor['sha256']==row[stream+'_sha256'], 'actual functional stream drift')
        events=[json.loads(line) for line in Path(rows[mode+'_stdout']['path']).read_text().splitlines()]
        passed=[event['Test'] for event in events if event.get('Action')=='pass' and 'Test' in event]
        need(len(passed)==len(set(passed))==65 and not any(event.get('Action') in ('fail','skip') for event in events), 'actual functional event census failed')
        names.append(set(passed))
    need(names[0]==names[1], 'normal/race65 test names differ')
    return proof

def validate_final_admission(settings, grant, source):
    final=load_bound(source['final_post_C3_applicability'])
    v=settings['variants']['c4']
    need(final.get('status')=='ROOT_ACCEPTED_POST_C3_CURRENT_C4_SOURCE'
         and final.get('C3_landing_complete') is True
         and final.get('head')==v['head']==grant.get('final_after_C3_head')
         and final.get('tree')==v['tree']
         and final.get('selected_current_input_sha256')==source['selected_current_compiler_inputs']['sha256']
         and final.get('current_v3_source_acceptance')==source['current_v3_source_acceptance'],
         'final post-C3 source applicability pending')
    accepted=load_bound(source['current_v3_source_acceptance'])
    need(accepted.get('verdict')=='ACCEPT_C4_CAPTURE_ROOT_BINDING_TOOLING_SOURCE'
         and accepted.get('uncommitted_index_tree')==final.get('tooling_source_tree')
         and accepted.get('findings')==[]
         and accepted.get('all_source_and_artifact_readers_released') is True,
         'v3 tooling source acceptance missing')
    need(grant.get('owner_window')==source['owner_window'], 'root owner window unbound')
    validate_owner_window(load_bound(source['owner_window']),settings)
    validate_current_functional(load_bound(source['current_functional_applicability']),v,
                               source['expected_current_compiler_closure']['sha256'])

def validate_current_build(old, oracle, receipt, actual_closure, expected_closure,
                           controls, env, relocation, namespace, inventory_sha, old_sha):
    normalized=lambda closure:{key:{field:item[field] for field in ('sha256','bytes','mode')} for key,item in closure.items()}
    need(len(actual_closure)==len(expected_closure)==1846
         and normalized(actual_closure)==normalized(expected_closure),
         'complete current1846 actual compiler closure differs from expected inputs')
    for field in COMPILER_IDENTITIES:
        need(old[field]==oracle[field]==receipt[field], 'unchanged nonproduct compiler identity changed '+field)
    comparison=validate_relocation(old,controls,env,relocation,namespace,inventory_sha,old_sha)
    need(receipt['environment']==controls and receipt['effective_process_environment']==env,
         'fresh receipt controls/environment drift')
    comparison.update(normalized_current_compiler_entries=1846,
        historical_P4_binary_sha256=oracle['binary_sha256'],
        fresh_current_binary_sha256=receipt['binary_sha256'],
        historical_binary_reuse_or_relabel=False)
    return comparison
