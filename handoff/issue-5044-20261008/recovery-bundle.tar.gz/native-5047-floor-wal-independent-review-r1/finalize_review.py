import datetime,hashlib,json,os,pathlib,re,stat,subprocess
R=pathlib.Path("/Volumes/FlashDrive/gomap-cow-github-hosted-actual-20261008/native-5047-floor-wal-independent-review-r1")
N=R/"corrected-go126-attempt-r2"
T=pathlib.Path("/private/tmp/gomap-cow-execution-o2nauuzm/c3-native-floor-reopen")
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+"\n")
assert not (R/"acceptance-receipt.json").exists()
results=json.loads((N/"execution-results.json").read_text())["results"]
assert [x["mode"] for x in results]==["normal","race"]
assert all(x["returncode"]==0 and x["signals"]==[] and x["owned_leader_joined"] for x in results)
reviews={}
expected_pairs={(p,q) for p in ("command_wal_durable","command_wal_relaxed") for q in ("false","true")}
for result in results:
 mode=result["mode"]
 out=(N/"raw"/(mode+".stdout")).read_text()
 err=(N/"raw"/(mode+".stderr")).read_text()
 assert h(N/"raw"/(mode+".stdout"))==result["stdout_sha256"]
 assert h(N/"raw"/(mode+".stderr"))==result["stderr_sha256"]
 passes=re.findall(r"^\s*--- PASS: (\S+) ",out,re.M)
 assert len(passes)==13 and len(set(passes))==13
 assert sum("/reopen=" in x for x in passes)==8
 assert not re.search(r"--- (?:FAIL|SKIP):|WARNING: DATA RACE|panic:",out+"\n"+err)
 assert re.search(r"^PASS$",out,re.M)
 assert re.search(r"^ok\s+github.com/snissn/gomap/TreeDB/mvcc\s+",out,re.M)
 witnesses=re.findall(r"joined process-exit child: \{Profile:(\S+) Pointers:(false|true) Mode:(\S+) Shards:(\d+) Syncs:(\d+) Appends:(\d+) Checkpoints:(\d+)\}",out)
 assert len(witnesses)==4 and {(x[0],x[1]) for x in witnesses}==expected_pairs
 assert all(x[2]=="cow_btree" and int(x[3])==4 and int(x[4])>=3 and int(x[5])>=3 and int(x[6])==0 for x in witnesses)
 binary=N/"bin"/(mode+".test")
 assert h(binary)==result["binary"]["sha256"]
 if mode=="race":
  live=json.loads((N/"live-race-executed-binary.json").read_text())
  assert live["sha256"]==h(binary) and live["bytes"]==binary.stat().st_size
  assert live["file_stable_during_live_read"]
  review={"top_level_tests":1,"pass_test_nodes":passes,"profile_pointer_cases":4,"reopen_cases":8,"child_witnesses":witnesses,"fail_nodes":0,"skip_nodes":0,"result_sha256":h(N/(mode+"-result.json")),"retained_output_binary":result["binary"],"live_executed_binary_sha256":live["sha256"],"live_and_retained_bytes_equal":True,"binary_custody":"Independent live executed binary measurement equals retained post-run Go installation"}
  save(N/"race-evidence-review.json",review)
 else:review=json.loads((N/"normal-evidence-review.json").read_text())
 reviews[mode]=review
post={}
pre=json.loads((R/"source-pre-map.json").read_text())
for name,expected in pre.items():
 p=T/name
 mode=p.lstat().st_mode
 assert stat.S_ISREG(mode),(name,"not regular")
 data=p.read_bytes()
 gitmode="100755" if mode&0o111 else "100644"
 actual={"blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest(),"bytes":len(data),"git_mode":gitmode,"sha256":hashlib.sha256(data).hexdigest()}
 assert actual==expected,(name,actual,expected)
 post[name]=actual
save(N/"source-post-map.json",post)
commands=[]
for i,argv in enumerate((["git","rev-parse","HEAD"],["git","diff","--cached","f3efffc7e6131daff6a61828021a15e2854761ea","--exit-code"],["git","diff","--name-only"])):
 e=dict(os.environ);e["GIT_OPTIONAL_LOCKS"]="0"
 p=subprocess.run(argv,cwd=T,env=e,capture_output=True)
 (N/"raw"/("post-git-"+str(i)+".stdout")).write_bytes(p.stdout)
 (N/"raw"/("post-git-"+str(i)+".stderr")).write_bytes(p.stderr)
 assert p.returncode==0
 if i==0:assert p.stdout.decode().strip()=="17aaa84a7cd0c8efe7ab87a1db71c764eddde416"
 else:assert not p.stdout
 commands.append({"argv":argv,"returncode":p.returncode,"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest()})
env=json.loads((N/"environment.json").read_text())["declared"]
G=pathlib.Path(env["GOROOT"])
inventory=json.loads((R/"toolchain-inventory.json").read_text())
for name in ("bin/go","pkg/tool/darwin_arm64/compile","pkg/tool/darwin_arm64/link","pkg/tool/darwin_arm64/asm","pkg/tool/darwin_arm64/cgo","VERSION"):
 assert h(G/name)==inventory["files"][name]["sha256"],name
cc=json.loads((N/"compiler.json").read_text())
assert h(pathlib.Path(cc["path"]))==cc["sha256"]
prep=json.loads((R/"minimal-modulecache-preparation.json").read_text())
# Validate read-only aliases rather than recursively inspecting unrelated caches.
alias_records=prep.get("readonly_aliases",prep.get("aliases",[]))
alias_check=[]
if isinstance(alias_records,dict):alias_records=[{"path":k,"target":v} for k,v in alias_records.items()]
for a in alias_records:
 path=a.get("path",a.get("module_path",a.get("relative_path")))
 target=a.get("target",a.get("source"))
 if path and target:
  q=N/"minimal-modulecache"/path
  assert q.is_symlink() and str(q.resolve())==str(pathlib.Path(target).resolve())
  alias_check.append({"path":path,"target":target})
for mode in ("normal","race"):
 prefix=str(G/"bin/go")+" test -work -o "+str(N/"bin"/(mode+".test"))
 p=subprocess.run(["pgrep","-f",prefix],capture_output=True)
 assert p.returncode==1 and not p.stdout,(mode,p.stdout)
save(N/"post-verification.json",{"physical_source_entries":len(post),"physical_source_equal_to_pre":True,"source_pre_sha256":h(R/"source-pre-map.json"),"source_post_sha256":h(N/"source-post-map.json"),"git_commands":commands,"critical_go_executables_and_version_unchanged":True,"compiler_unchanged":True,"readonly_alias_checks":alias_check,"owned_normal_and_race_go_processes_absent":True})
path="TreeDB/mvcc/cow_floor_wal_recovery_external_test.go"
receipt={"verdict":"ACCEPT_PUBLIC_COW_ACKNOWLEDGED_WAL_PROCESS_EXIT_RECOVERY_TEST","findings":[],"source_files":{path:pre[path]},"full_source_pre_map_sha256":h(R/"source-pre-map.json"),"full_source_post_map_sha256":h(N/"source-post-map.json"),"source_entry_count":len(post),"original_9921_entries_unchanged":True,"author_freeze_sha256":"0b9e4e8dc2fb95a8a3dd86afe27d8791b58de331cd2dff908ed6c028270bfbb0","author_receipt_sha256":"083dfe52a821b7f6929d5fd96004cf1ebea9b393bfb1c6dab5cf4eb8345cd891","base_head":"17aaa84a7cd0c8efe7ab87a1db71c764eddde416","uncommitted_index_tree":"f3efffc7e6131daff6a61828021a15e2854761ea","source_review_sha256":h(R/"source-review.json"),"corrected_attempt_namespace":str(N),"environment_sha256":h(N/"environment.json"),"environment_admission_sha256":h(N/"environment-admission.json"),"full_go_toolchain_inventory_sha256":h(R/"toolchain-inventory.json"),"compiler_sha256":cc["sha256"],"post_verification_sha256":h(N/"post-verification.json"),"normal":{"result_sha256":h(N/"normal-result.json"),"evidence_review_sha256":h(N/"normal-evidence-review.json"),"binary_sha256":reviews["normal"]["retained_output_binary"]["sha256"],"pass_nodes":13,"top_level_tests":1,"profile_pointer_cases":4,"joined_process_exit_children":4,"reopen_cases":8,"natural_exit_code":0,"signals":[],"binary_custody":"Observed actual work path; pinned Go source binds completed execution to retained installed bytes; separate pre-install hash was not measured"},"race":{"result_sha256":h(N/"race-result.json"),"evidence_review_sha256":h(N/"race-evidence-review.json"),"binary_sha256":reviews["race"]["retained_output_binary"]["sha256"],"live_executed_binary_sha256":reviews["race"]["live_executed_binary_sha256"],"live_and_retained_bytes_equal":True,"pass_nodes":13,"top_level_tests":1,"profile_pointer_cases":4,"joined_process_exit_children":4,"reopen_cases":8,"natural_exit_code":0,"signals":[]},"first_valid_normal_and_race_executed_once_each":True,"old_checkpoint_test_executed":False,"original_failed_setup_preserved":{"receipt_sha256":h(R/"failed-attempt-receipt.json"),"freeze_sha256":h(R/"failed-attempt-freeze.json"),"status":"INCOMPATIBLE_INHERITED_GVM_GOROOT_BEFORE_TEST_EXECUTION","tests_executed":0,"race_withheld":True},"interrupted_owned_cache_copy_preserved":True,"working_caches_and_partial_preparation_retained_excluded_from_artifact_freeze":True,"acceptance_scope":"Public COW acknowledged WAL process-exit recovery, inline and persistent pointers, four shards, first-Prune preflight, atomic floor refusal, tombstone history and two reopens","power_loss_acceptance":False,"native_positive_prune_acceptance":False,"performance_acceptance":False,"whole_issue_5047_acceptance":False,"full756_identity_relabel":False,"new_runtime_authority":False,"reader_release":"RELEASED","all_source_and_artifact_readers_released":True,"all_owned_test_commands_joined":True,"utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}
save(R/"acceptance-receipt.json",receipt)
excluded={"modulecache","minimal-modulecache","gocache","gopath","tmp","gotmp","clangcache","xdgcache"}
files=[];dirs=[]
for root,ds,fs in os.walk(R,followlinks=False):
 rootp=pathlib.Path(root)
 ds[:]=[d for d in ds if d not in excluded and not (rootp/d).is_symlink()]
 dirs.append(rootp)
 for fn in fs:
  p=rootp/fn
  if p.name=="freeze.json" and p.parent==R:continue
  assert p.is_file() and not p.is_symlink(),str(p)
  files.append(p)
manifest={}
for p in sorted(files):
 mode=0o555 if p.parent==N/"bin" else 0o444
 p.chmod(mode)
 manifest[str(p.relative_to(R))]={"sha256":h(p),"bytes":p.stat().st_size,"mode":mode}
save(R/"freeze.json",{"receipt_sha256":h(R/"acceptance-receipt.json"),"files":manifest,"excluded_working_directory_names":sorted(excluded),"reader_release":"RELEASED","all_owned_test_commands_joined":True})
(R/"freeze.json").chmod(0o444)
for p in sorted(dirs,key=lambda x:len(x.parts),reverse=True):p.chmod(0o555)
print(json.dumps({"receipt_sha256":h(R/"acceptance-receipt.json"),"freeze_sha256":h(R/"freeze.json"),"artifact_files":len(manifest),"source_entries":len(post),"normal_and_race_pass_nodes":[13,13],"readers":"RELEASED"}),flush=True)
