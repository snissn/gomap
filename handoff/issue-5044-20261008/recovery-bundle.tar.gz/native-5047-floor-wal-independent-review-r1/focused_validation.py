import datetime,hashlib,json,os,pathlib,signal,stat,subprocess,time
R=pathlib.Path(__file__).resolve().parent
T=pathlib.Path("/private/tmp/gomap-cow-execution-o2nauuzm/c3-native-floor-reopen")
G=pathlib.Path("/Users/michaelseiler/.gvm/pkgsets/go1.25.5/global/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.0.darwin-arm64")
C=pathlib.Path("/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang")
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(root):
 result={}
 for p in sorted(root.rglob("*")):
  relative=str(p.relative_to(root));m=p.lstat().st_mode
  if stat.S_ISREG(m): result[relative]={"bytes":p.stat().st_size,"mode":stat.S_IMODE(m),"sha256":h(p)}
  elif stat.S_ISLNK(m):result[relative]={"mode":stat.S_IMODE(m),"symlink":os.readlink(p)}
 return result
toolchain=inventory(G)
(R/"toolchain-inventory.json").write_text(json.dumps({"root":str(G),"files":toolchain},indent=2,sort_keys=True)+"\n")
version=subprocess.run([str(C),"--version"],capture_output=True)
(R/"raw/compiler-version.stdout").write_bytes(version.stdout)
(R/"raw/compiler-version.stderr").write_bytes(version.stderr)
assert version.returncode==0
(R/"compiler.json").write_text(json.dumps({"path":str(C),"resolved_path":str(C.resolve()),"mode":stat.S_IMODE(C.stat().st_mode),"bytes":C.stat().st_size,"sha256":h(C),"version_exit_code":version.returncode},indent=2)+"\n")
env=dict(os.environ)
for key in list(env):
 if key.startswith("TREEDB_COW_FLOOR_WAL_CHILD_DIR"):del env[key]
declared={"GOTOOLCHAIN":"local","GOWORK":"off","GOPROXY":"off","GOSUMDB":"off","GOCACHE":str(R/"gocache"),"GOMODCACHE":str(R/"minimal-modulecache"),"GOPATH":str(R/"gopath"),"TMPDIR":str(R/"tmp"),"GOTMPDIR":str(R/"gotmp"),"GOENV":"off","GOFLAGS":"-mod=readonly -p=1","CC":str(C),"CXX":str(C.parent/"clang++"),"CGO_ENABLED":"1","CLANG_MODULE_CACHE_PATH":str(R/"clangcache"),"XDG_CACHE_HOME":str(R/"xdgcache"),"GOCACHEPROG":""}
env.update(declared)
(R/"environment.json").write_text(json.dumps({"declared":declared,"inherited_path":env.get("PATH"),"host":"darwin-arm64","toolchain_version_file":(G/"VERSION").read_text(),"test_scope":"^TestPublicCOWDiscardFloorWALProcessRecovery$","network_fetch_allowed":False},indent=2,sort_keys=True)+"\n")
results=[]
for mode in ("normal","race"):
 argv=[str(G/"bin/go"),"test","-work","-o",str(R/"bin"/(mode+".test"))]
 if mode=="race":argv+=["-race"]
 argv+=["./TreeDB/mvcc","-run","^TestPublicCOWDiscardFloorWALProcessRecovery$","-count=1","-timeout=10m","-v"]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();begin=time.monotonic();signals=[]
 (R/(mode+"-command.json")).write_text(json.dumps({"argv":argv,"cwd":str(T),"environment":declared,"started_utc":start,"deadline_seconds":1200},indent=2)+"\n")
 print(json.dumps({"mode":mode,"state":"STARTED","started_utc":start}),flush=True)
 with (R/"raw"/(mode+".stdout")).open("wb") as out,(R/"raw"/(mode+".stderr")).open("wb") as err:
  p=subprocess.Popen(argv,cwd=T,env=env,stdout=out,stderr=err,start_new_session=True)
  while True:
   try:
    rc=p.wait(timeout=45);break
   except subprocess.TimeoutExpired:
    elapsed=time.monotonic()-begin
    print(json.dumps({"mode":mode,"state":"RUNNING","elapsed_seconds":round(elapsed)}),flush=True)
    if elapsed>1200:
     signals.append("SIGTERM");os.killpg(p.pid,signal.SIGTERM)
     try:rc=p.wait(timeout=10)
     except subprocess.TimeoutExpired:signals.append("SIGKILL");os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
     break
 result={"mode":mode,"argv":argv,"cwd":str(T),"environment":declared,"started_utc":start,"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsed_seconds":time.monotonic()-begin,"returncode":rc,"signals":signals,"owned_leader_joined":True,"stdout_sha256":h(R/"raw"/(mode+".stdout")),"stderr_sha256":h(R/"raw"/(mode+".stderr"))}
 binary=R/"bin"/(mode+".test")
 if binary.exists():result["binary"]={"path":str(binary),"bytes":binary.stat().st_size,"mode":stat.S_IMODE(binary.stat().st_mode),"sha256":h(binary)}
 (R/(mode+"-result.json")).write_text(json.dumps(result,indent=2,sort_keys=True)+"\n");results.append(result)
 print(json.dumps({"mode":mode,"state":"JOINED","returncode":rc,"signals":signals,"elapsed_seconds":round(result["elapsed_seconds"])}),flush=True)
 if rc!=0:
  print("Focused validation failed; race is withheld when preceding normal cannot establish the candidate.",flush=True)
  break
(R/"execution-results.json").write_text(json.dumps({"results":results,"all_owned_commands_joined":True},indent=2,sort_keys=True)+"\n")
