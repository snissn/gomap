Run from the exact reviewed source snapshot (root may commit this same staged tree).

```sh
python3 -B scripts/cow_c3_read/c4_contract_test.py
```

```sh
python3 -B /Volumes/FlashDrive/gomap-cow-github-hosted-actual-20261008/pr5082-cow-boundary-budget-preparation-r1/controls/real_raw_green.py
```

```sh
env PYTHONPATH=/Users/michaelseiler/.cache/uv/archive-v0/E3e7kLKm4Fs2aRMzT_Dst python3 -B .github/scripts/refresh_ci_impact_inventory.py --check
```

The following25 selected mutators require a genuine successful current-source v3 packet. They have not been run against a fresh v3 packet; their raw mutation functions were tested offline against the original historical raw bytes. Original v2 packets retain historical identity.

```sh
python3 -B scripts/cow_c3_read/c4_packet_smoke.py --positive '<GENUINE_CURRENT_V3_PACKET>' --out '<NEW_DISTINCT_OUTPUT>' --case cow-budget-views-opened --case cow-budget-views-seed --case cow-budget-views-epoch_1_growth --case cow-budget-views-epoch_1_joined --case cow-budget-views-pinned_checkpoint --case cow-budget-opened-generations --case cow-budget-opened-sources --case cow-budget-opened-frozen_roots --case cow-budget-opened-total_bytes --case cow-budget-opened-peak_bytes --case cow-budget-opened-control_bytes --case cow-budget-opened-history_bytes --case cow-budget-opened-retired_bytes --case cow-budget-opened-deferred_bytes --case cow-budget-opened-reserved_bytes --case cow-budget-opened-external_bytes --case cow-budget-opened-external_leases --case cow-budget-opened-active_cuts --case cow-budget-opened-current_roots --case cow-budget-layout-seed_layout-owners_before --case cow-budget-layout-seed_layout-owners_after --case cow-budget-layout-checkpoint_layout-owners_before --case cow-budget-layout-checkpoint_layout-owners_after --case cow-budget-layout-reopen_layout-owners_before --case cow-budget-layout-reopen_layout-owners_after
```

No construction/runtime command is authorized by this handoff.
