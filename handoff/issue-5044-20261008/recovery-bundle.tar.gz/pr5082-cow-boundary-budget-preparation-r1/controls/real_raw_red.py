"""Real historical raw evidence only; no synthetic v3 packet or runtime."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parents[1]
sys.path.insert(0,'/private/tmp/gomap-cow-execution-o2nauuzm/c4-tools/scripts/cow_c3_read')
p=D/'origins/scripts/cow_c3_read/c4_protocol.py'
spec=importlib.util.spec_from_file_location('original_c4_protocol',p)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
raw=D/'raw/original-actual-cow-lifecycle.json'
r=json.loads(raw.read_text());case={k:r[k] for k in ('profile','mode','layout','keys')}
case['benchmark']='BenchmarkCOWSustainedPublicMVCC/'+r['leaf']
m.validate_raw(r,case,r['epochs'])
results=[]
for phase in ('opened','seed','epoch_1_growth','epoch_1_joined','pinned_checkpoint'):
 c=copy.deepcopy(r)
 next(b for b in c['boundaries'] if b['phase']==phase)['stats']['treedb.cache.cow.views']='257'
 m.validate_raw(c,case,c['epochs'])
 results.append({'phase':phase,'over_limit_views':257,'accepted_before_fix':True})
out={'status':'CONFIRMED_REAL_HISTORICAL_RAW_VALIDATOR_GAP','original_raw_pass':True,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'cases':results,'new_v3_producer_claim':False,'Go_executions':0,'operational_mains_executed':0}
(D/'real-raw-red-result.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('RED',len(results),'over-MaxViews mutations of unchanged actual raw accepted')
