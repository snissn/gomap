from pathlib import Path
import datetime,json,os,subprocess,sys,time
D=Path(__file__).resolve().parents[1];W=Path('/private/tmp/gomap-cow-execution-o2nauuzm/c4-tools')
cache='/Users/michaelseiler/.cache/uv/archive-v0/E3e7kLKm4Fs2aRMzT_Dst'
env=dict(os.environ,PYTHONPATH=cache,TMPDIR=str(D/'local-tmp'),PYTHONDONTWRITEBYTECODE='1')
for label,args in [('inventory-refresh',[]),('inventory-check',['--check'])]:
 argv=[sys.executable,'-B','.github/scripts/refresh_ci_impact_inventory.py']+args
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();before=time.monotonic()
 p=subprocess.Popen(argv,cwd=W,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=p.communicate()
 (D/'raw'/f'{label}-stdout.txt').write_bytes(out);(D/'raw'/f'{label}-stderr.txt').write_bytes(err)
 r=dict(argv=argv,cwd=str(W),pid=p.pid,start_utc=start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),duration_seconds=time.monotonic()-before,exit_code=p.returncode,naturally_joined=True,signals_sent=[],environment_overrides={k:env[k] for k in ('PYTHONPATH','TMPDIR','PYTHONDONTWRITEBYTECODE')},dependency='PyYAML 6.0.3 from existing readonly uv archive; no download/install/cache writes')
 (D/'raw'/f'{label}-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(label,p.returncode,out.decode().strip(),err.decode().strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
