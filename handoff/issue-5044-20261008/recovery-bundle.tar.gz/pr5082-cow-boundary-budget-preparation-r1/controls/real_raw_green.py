"""Targeted offline controls over one untouched real historical COW raw lifecycle."""
from pathlib import Path
import ast,copy,hashlib,json,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parents[1]
W=Path('/private/tmp/gomap-cow-execution-o2nauuzm/c4-tools')
sys.path.insert(0,str(W/'scripts/cow_c3_read'))
import c4_protocol as p
rawpath=D/'raw/original-actual-cow-lifecycle.json'
rawbytes=rawpath.read_bytes();raw=json.loads(rawbytes)
case={k:raw[k] for k in ('profile','mode','layout','keys')}
case['benchmark']='BenchmarkCOWSustainedPublicMVCC/'+raw['leaf']
results=[]
def validate(r):return p.validate_raw(r,case,r['epochs'])
def positive(name,r):
 validate(r);results.append(dict(name=name,expected='ACCEPT',actual='ACCEPT'))
def negative(name,r,expected=None):
 try:validate(r)
 except ValueError as e:
  if expected is not None:assert expected in str(e),(name,str(e))
  results.append(dict(name=name,expected='REFUSE',actual='REFUSE',error=str(e)))
 else:raise AssertionError('accepted damaged real raw '+name)
positive('unchanged-real-raw',raw)
# Execute precisely the new future-packet mutator definitions, without any
# packet/analyzer/collector operational main or invented v3 provenance.
source=W/'scripts/cow_c3_read/c4_packet_smoke.py'
tree=ast.parse(source.read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
start=next(i for i,n in enumerate(main.body) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='phase' and isinstance(n.iter,ast.Tuple) and any(isinstance(x,ast.Constant) and x.value=='opened' for x in n.iter.elts))
end=next(i for i,n in enumerate(main.body[start:],start) if isinstance(n,ast.If) and isinstance(n.test,ast.Attribute) and n.test.attr=='case')
def capture(change,profile=None,mode=None,layout=None):
 assert mode=='cow_btree' and profile is None and layout is None
 return change
namespace={'cases':{},'raw_mutation':capture}
exec(compile(ast.fix_missing_locations(ast.Module(body=main.body[start:end],type_ignores=[])),str(source),'exec'),namespace)
assert len(namespace['cases'])==25
for name,mutation in namespace['cases'].items():
 r=copy.deepcopy(raw);mutation(r);negative(name,r,'COW budget exceeded')
# Verify dispatch covers every retained boundary, including quiescent/reopen;
# the reset boundary has no census and intentionally carries an empty map.
for boundary in raw['boundaries']:
 if not boundary['stats']:continue
 if 'cow-budget-views-'+boundary['phase'] in namespace['cases']:continue
 r=copy.deepcopy(raw);next(b for b in r['boundaries'] if b['phase']==boundary['phase'])['stats']['treedb.cache.cow.views']='257'
 negative('all-boundary-views-'+boundary['phase'],r,'COW budget exceeded')
# The original unsigned domain and cumulative monotonic checks remain active.
r=copy.deepcopy(raw);r['boundaries'][0]['stats']['treedb.cache.cow.views']=str(1<<64)
negative('retained-uint64-domain',r,'out-of-range')
r=copy.deepcopy(raw)
for b in r['boundaries']:
 if b['stats']:
  for key in p.COW_COUNTERS:
   if key.endswith('_total'):b['stats']['treedb.cache.cow.'+key]=str((1<<64)-1)
positive('cumulative-uint64-maximum-has-no-live-cap',r)
r=copy.deepcopy(raw);r['boundaries'][0]['stats']['treedb.cache.cow.capture_calls_total']=str((1<<64)-1)
negative('retained-cumulative-monotonic',r,'counter regression')
# Layout owner caps are applied before equality can mask consistent damage.
for proof in raw['layout_proofs']:
 for gauge,value,expected in [('active_cuts',p.LIMITS['MaxInFlightBytes']+1,'COW budget exceeded'),('external_leases',p.LIMITS['MaxInFlightBytes']+1,'COW budget exceeded'),('active_cuts',int(proof['owners_before']['treedb.cache.cow.external_leases'])+1,'cut/lease accounting')]:
  r=copy.deepcopy(raw);pr=next(x for x in r['layout_proofs'] if x['phase']==proof['phase'])
  for side in ('owners_before','owners_after'):pr[side]['treedb.cache.cow.'+gauge]=str(value)
  negative('balanced-layout-'+proof['phase']+'-'+gauge+'-'+expected,r,expected)
assert rawpath.read_bytes()==rawbytes
out=dict(status='PASS',scope='OFFLINE_REAL_HISTORICAL_RAW_AND_SOURCE_CONTROL_ONLY',new_v3_packet_claim=False,runtime_grant=False,Go_executions=0,operational_mains=0,raw_sha256=hashlib.sha256(rawbytes).hexdigest(),parser_sha256=p.sha(W/'scripts/cow_c3_read/c4_protocol.py'),future_case_source_sha256=p.sha(source),future_cases=list(namespace['cases']),controls=results,count=len(results),positive_count=sum(x['actual']=='ACCEPT' for x in results),refusal_count=sum(x['actual']=='REFUSE' for x in results))
(D/'targeted-green-result.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:out[k] for k in ('status','count','positive_count','refusal_count')}))
