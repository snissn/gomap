from pathlib import Path
import datetime,json,os,subprocess,sys,time
D=Path(__file__).resolve().parents[1];W=Path('/private/tmp/gomap-cow-execution-o2nauuzm/c4-tools')
env=dict(os.environ,TMPDIR=str(D/'local-tmp'),PYTHONDONTWRITEBYTECODE='1')
commands=[('unit', [sys.executable,'-B','scripts/cow_c3_read/c4_contract_test.py']),('green',[sys.executable,'-B',str(D/'controls/real_raw_green.py')])]
results=[]
for label,argv in commands:
 before=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
 p=subprocess.Popen(argv,cwd=W,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=p.communicate();elapsed=time.monotonic()-start
 (D/'raw'/f'{label}-stdout.txt').write_bytes(stdout);(D/'raw'/f'{label}-stderr.txt').write_bytes(stderr)
 r=dict(label=label,argv=argv,cwd=str(W),pid=p.pid,start_utc=before,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),duration_seconds=elapsed,exit_code=p.returncode,naturally_joined=True,signals_sent=[],environment_overrides={k:env[k] for k in ('TMPDIR','PYTHONDONTWRITEBYTECODE')})
 (D/'raw'/f'{label}-receipt.json').write_text(json.dumps(r,indent=2)+'\n');results.append(r)
 print(label,p.returncode,stdout.decode().strip(),stderr.decode().strip(),flush=True)
 if p.returncode:sys.exit(p.returncode)
(D/'focused-validation.json').write_text(json.dumps(dict(status='PASS',python_version=sys.version,results=results,all_owned_children_joined=True),indent=2)+'\n')
