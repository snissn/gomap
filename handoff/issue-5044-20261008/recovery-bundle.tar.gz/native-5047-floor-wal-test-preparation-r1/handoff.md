One additive source-only #5047 public Store COW floor/WAL recovery candidate, based on exact 17aaa84a. All existing files including the checkpoint/Close fixture remain byte-identical in the index; all original tree blob/mode entries are retained in unchanged-original-tree-map.json. No change to production, native, docs, canonical tools, modules or embeds. Original full756 8d and current C3 3f identities are not relabeled.

Four cases select command_wal_durable/command_wal_relaxed × inline/forced persistent pointers; actual public resolved profile, COW mode, four shards and live/reopened pointer flags are asserted. Three sequential durable public operations (group, floor, group) must observe >=3 append/sync calls and zero checkpoint delta. The child exits normally without DB.Close/Checkpoint. A 90-second subprocess deadline bounds each child; CombinedOutput waits/reaps it, and failure/context expiry refuses the case. Child test errors are checked before deliberate exit0 so snapshot-close errors cannot be hidden.

Every fresh Store prunes first, then proves zero unsupported stats/effects, positive persisted-floor capture, equal-floor reader refusal, below/equal-floor writer refusal, atomic admissible-first mixed-group rejection, exact tombstone/point/history values, and a repeat clean reopen. Layout inspection alone uses the existing internal key encoder and public Snapshot.GetEntry; all writes/admission and recovery assertions use public Store/DB. The existing external history helper is reused without editing it. Parent snapshot/iterator/DB Close errors fail the test. This characterizes acknowledged process-exit WAL recovery, not power loss, native deletion/bounds, maintenance concurrency, performance or full #5047 completion.

Source syntax was parsed/formatted by standalone gofmt; staged diff-check and exact source/index/tree/mode checks succeeded. No Go compilation/typecheck/test/build/benchmark/profile, module fetch, SSH, GitHub operation, commit or push occurred. Actual functional validation remains PENDING; independent source review precedes any authorized run. Local disk constraint was respected with one ~12KiB source file and index update; evidence is retained only in this new FlashDrive namespace.

Focused commands for a later authorized toolchain/storage lane (NOT EXECUTED):

```sh
GOWORK=off go test ./TreeDB/mvcc -run '^TestPublicCOWDiscardFloorWALProcessRecovery$' -count=1 -timeout=10m -v
GOWORK=off CGO_ENABLED=1 go test -race ./TreeDB/mvcc -run '^TestPublicCOWDiscardFloorWALProcessRecovery$' -count=1 -timeout=10m -v
```

Use the pinned qualified Go toolchain and actual declared C compiler for the race command; retain raw streams and natural command/child joins. Do not claim test pass from this source-only packet. All source/artifact readers and the writer are RELEASED; only the staged new file remains for the root integrator.
