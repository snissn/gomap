The original 756 raw rows and all 720 metric summaries were independently recomputed from immutable stdout/stderr using SHA-matched reviewed canonical protocol helpers. All cached rows, six values per variant, cycle means/ratios, median effects, spreads and flags matched exactly.

| Scope | Cells | Noisy pairs | Adverse pairs | Nonnoisy adverse | Unique flagged pairs |
|---|---:|---:|---:|---:|---:|
| cow_concurrent | 6 | 43 | 0 | 0 | 43 |
| cow_sequential | 12 | 24 | 6 | 1 | 25 |
| legacy | 36 | 76 | 51 | 23 | 99 |

Totals: 143 noisy, 57 adverse, 33 overlapping, 167 unique flagged metric pairs in 49 cells. There are 54 nonnoisy benefit pairs (52 COW concurrent and 2 legacy). All flags are retained in independent-metric-recalculation.json; none is excluded or resolved by this audit.

| COW concurrent target | Reader throughput paired effect | Noisy |
|---|---:|---|
| command_wal_durable-cow_btree-inline-concurrent | +13.0207% | false |
| command_wal_durable-cow_btree-forced_pointer-concurrent | +14.3064% | false |
| command_wal_relaxed-cow_btree-inline-concurrent | +99.5485% | false |
| command_wal_relaxed-cow_btree-forced_pointer-concurrent | +46.6149% | false |
| no_wal_fast-cow_btree-inline-concurrent | +94.6099% | false |
| no_wal_fast-cow_btree-forced_pointer-concurrent | +141.0414% | false |

The sole nonnoisy COW sequential adverse pair is command_wal_relaxed-cow_btree-forced_pointer-point / point_p95_ns: +6.0325% paired; sample medians 20713.5 -> 22653.0 ns. All 23 nonnoisy legacy adverse pairs remain measured costs requiring disposition.

Contract ruling: the retained #5076 body permits repair OR explicit coordinator acceptance with evidence for material regressions. A scoped coordinator tradeoff is therefore available after structural validation, provided all 167 original flagged pairs receive explicit disposition, the 24 nonnoisy adverse pairs remain measured costs, and 143 noisy pairs remain inconclusive. Intended concurrent benefit cannot turn noisy results into no-regression or waive original work/ACK/layout/retention/source gates. No source-level causal attribution is established by this packet. The coordinator must explicitly reconcile the checklist wording rather than silently mark unexplained regressions repaired.

Original production identities remain baseline2d6b07f58902537cfe8d2b3e3a8c3c9ba0f3c07c and candidate8d8806b495422e44f7802a96f5737f536a3fb2f0. Any later tooling-only alias requires its separate unchanged-compiled-input proof; these rows are never relabeled. No native, parent, or automatic performance acceptance.

Reader-specific phase rates provide evidence separate from combined rates. Combined writer_ops/s and reader_ops/s share the all-worker completion denominator; the six combined benefits above do not independently establish reader progress. Phase clocks run from barrier release to each reader completion and do not identify writer preparation time.

| COW concurrent case | Point phase rate ratio | Point noisy | Scan phase rate ratio | Scan noisy |
|---|---:|---|---:|---|
| command_wal_durable-cow_btree-inline-concurrent | 132.73671 | true | 58.75913 | false |
| command_wal_durable-cow_btree-forced_pointer-concurrent | 29.11820 | false | 17.39114 | false |
| command_wal_relaxed-cow_btree-inline-concurrent | 15.02602 | true | 6.56763 | true |
| command_wal_relaxed-cow_btree-forced_pointer-concurrent | 14.45762 | false | 9.50118 | false |
| no_wal_fast-cow_btree-inline-concurrent | 8.05404 | true | 4.01526 | false |
| no_wal_fast-cow_btree-forced_pointer-concurrent | 6.14795 | false | 3.57193 | false |

Forced-pointer point and scan phase rates improve nonnoisily across all three profiles; durable and NoWAL inline scan phase rates also improve nonnoisily. Relaxed-inline reader phases and all inline point phase rates remain noisy. NoWAL inline scan elapsed time is noisy despite its rounded rate being nonnoisy; these are separate original flags and neither is removed. Old-cut progress during deliberately paused preparation is established by the separately accepted functional fixture, not by locating preparation inside these timed phase totals.

The root proposal retains 110 inconclusive-only, 33 inconclusive-plus-adverse, and 24 explicit measured-cost entries. All proposed values and all54 work/ACK/layout/activity/allocation/RSS/load ledgers match original receipts. This supports a scoped coordinator decision after structural validation; it is not a decision by this reviewer.
